function confirm_logout(){
    msg = "Are you absolutely sure that you want to log out?\n To go ahead and delete, hit OK. Otherwise hit CANCEL.";
    return confirm(msg);
}