<?

$SITE_name = "circeOS Curriculum";

/*--------------------------------------------------------------*/
/* CV DB ORACLE CONFIGURATION									*/
/*--------------------------------------------------------------*/

$CV_ORACLE_db_name		= "(DESCRIPTION=(ADDRESS =(PROTOCOL = TCP)(HOST = sytrmworacle2)(PORT = 1521))(CONNECT_DATA = (SID = CURRICUL)))";
$CV_ORACLE_db_user		= "curricadmin";
$CV_ORACLE_db_password	= "curricadmin";

?>