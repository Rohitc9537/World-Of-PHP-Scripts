<?php
#Domains - your domain(s) with no http:// or www. - to learn how to add more domains, read the readme
$domains[] = "";
#WHM user - your WHM username
$cpuser = "";
#WHM password - your WHM password
$cppass = "";
#Quota - The storage limit in MB for users
$quota = "";
#FTP - maximum ftp accounts for users
$ftp = "";
#Mail - the maximum email accounts for users
$mail = "";
#List - the maximum mailing lists for users
$list = "";
#SQL - the maximum mysql databases for users
$sql = "";
#Addon - the maximum addon domains for users
$addon = "";
#Subdomains - the maximum subdomains for users
$subdomains = "";
#Park - the maximum parked domains for users
$park = "";
#Bandwidth - the maximum bandwidth for users in MB
$bandwidth = "";
#Host - your mysql host
$host = "";
#DBuser - your mysql username
$dbuser = "";
#DBuser - your mysql password
$dbpass = "";
#DBname - your mysql database
$dbname = "";
#Admin Username - used for the admin control panel
$ausername = "";
#Admin Password - used for the admin control panel
$apassword = "";
#Use signup keys - "yes" or "no" - read the readme to learn about signup keys
$skeys = "";
#Multiple use signup keys - "yes" or "no" - allow multiple people to use a signup key
$mkeys = ""; 
#NS1 and NS2 - please set these to your nameservers - e.g. ns1.domain.com and ns2.domain.com
$ns1 = "";
$ns2 = "";
#Image verification - "yes" or "no" - use image verification to prevent bots - requires GD
$image = "";
?>