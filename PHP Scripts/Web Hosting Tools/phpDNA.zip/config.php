<?PHP
// Upload the files to your server and place them into a folder called whois
// Place the path to get to the whois folder
// For Example: http://www.yoursite.com/
// Do not include the whois folder in the path
$path="http://www.yoursite.com/";
?>