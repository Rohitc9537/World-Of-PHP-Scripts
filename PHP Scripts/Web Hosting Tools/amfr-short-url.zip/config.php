<?php
# Your domain with no http:// - e.g. www.example.com
$config['domain'] = "";
# Admin username
$config['username'] = "";
# Admin password
$config['password'] = "";
?>