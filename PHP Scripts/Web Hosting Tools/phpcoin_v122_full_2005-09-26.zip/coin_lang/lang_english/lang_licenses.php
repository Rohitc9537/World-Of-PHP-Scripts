<?php
/**************************************************************
 * File: 	Language- Licenses Module
 * Author:	Stephen M. Kitching (http://phpcoin.com)
 * Date:	2004-05-01 (V1.0)
 * License:	DO NOT Remove this text block. See /coin_docs/license.txt
 *			Copyright � 2004 Stephen M. Kitching
 * Notes:	- Global language ($_LANG) vars.
 *			- Language: 		English (USA)
 *			- Translation By:
 *				Stephen Kitching (http://www.phpcoin.com)
**************************************************************/

/**************************************************************
 * Configuration Loaded Flag
**************************************************************/
	global $F_LANG_LICENSES;
	$F_LANG_LICENSES	= 1;

/**************************************************************
 * Language Variables
**************************************************************/
# Language Variables: Common

?>
