
/**************************************************************
 * File: 		Documentation: Manual changes when fixing v1.2.2
 * Author:	Stephen M. Kitching (http://phpcoin.com)
 * Date:		2005-03-08 (v1.2.2)
 * License:	DO NOT Remove this text block. See /coin_docs/license.txt
 *			Copyright � 2003-2004-2005 phpCOIN.com
 * Notes:
 *
**************************************************************/



Fixes as of 2005-09-26:
=======================
1: Replace the files on your web-server with the corresponding files from the fix-file.
   There are no datbase changes, only some file changes

2: Fix-files will not over-write your custom strings anymore IF you make a file called
   lang_xxx_override.php where xxx is the lang_xxx.php file that you have edited strings