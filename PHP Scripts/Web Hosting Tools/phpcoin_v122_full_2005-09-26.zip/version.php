<?
$ThisVersion	= '1.2.2'; // Current Release Version
$ThisFix		= '2005-09-26'; // Current fix-file
?>