<html>
<head>
<title>Fail.php</title>
</head>
<body>
<p>Your session expired
<a href=login.php>Click</a> here to re-login
</p>
</body>
</html>