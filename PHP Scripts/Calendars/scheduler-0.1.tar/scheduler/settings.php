<?php
$hostname = "localhost";  //Edit needed here
$uname = "";              //Edit needed here
$login_password = "";     //Edit needed here
$database_name = "";      //Edit needed here
$table_name = "my_vote";

#scheduler properties
$schedule_users_tb="TB_USERS";
$schedule_items_tb="TB_SCHEDULE_ITEM";
$schedule_friends_tb="TB_FRIENDS";
?>