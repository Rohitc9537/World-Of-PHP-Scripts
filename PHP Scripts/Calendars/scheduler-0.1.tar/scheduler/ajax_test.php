<html>
<head>
<script src="ajax.js">
</script>
</head>
<body>
<input type="text" size="5" name="zip" id="zip" onblur="sndReq('foo');" />
<a href="javascript:sndReq('foo')">[foo]</a>
</body>
<div id="AddItemDiv">
</div>
</html>
