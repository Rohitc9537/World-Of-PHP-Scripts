<?php
    header("Content-Type: text/calendar");
    header("Content-Disposition: inline; filename=icalendar.ics");
?>