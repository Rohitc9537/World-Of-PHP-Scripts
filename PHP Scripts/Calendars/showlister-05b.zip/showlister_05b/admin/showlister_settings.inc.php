<?php
    // =============================
    // database connection variables
    // =============================
    $site = "localhost";
    $user = "root";
    $pass = "";
    $database = "showlister_04b";
    $database_table ="showlister_shows";
    $database_table_artists ="showlister_artists";
?>