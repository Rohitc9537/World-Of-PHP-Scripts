<?php
    // include the methods
    include("showlister_methods.inc.php");
    // parse the $_POST vars into something useful 
    // also check for nulls
    $the_id = $_POST['artist_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $url = $_POST['url'];
    $phone = $_POST['phone'];
?>
<html>
<head>
    <title>showlister :: artist edit confirmation</title>
    <link rel="stylesheet" type="text/css" href="showlister.css">
</head>
<body>

<?php
    // read in the connection settings
    require("showlister_settings.inc.php");

    // connect to the RDBMS
    $db = mysql_connect("$site","$user","$pass") 
        or die_now("<h2>Could not connect to database server</h2><p>Check passwords and sockets</p>");

    // select the database
    mysql_select_db("$database",$db) 
        or die_now("<h2>Could not select database $database</h2><p>Check database name</p>");

    // update the database record
    $result = mysql_query("update $database_table_artists
        set artist_name='$name', artist_email='$email', artist_url='$url', artist_phone='$phone'   
        where artist_id = '$the_id'",$db) 
        or die_now("<h2>Could not change artist</h2>");

    // echo out a status report and show id
    echo("<div class='box'>\n\t<h3>showlister :: edit artist</h3>\n</div>\n");
    echo("<div class='box'>artist (id='$the_id') updated</div>\n");
?>
<?php
  footer();
?>