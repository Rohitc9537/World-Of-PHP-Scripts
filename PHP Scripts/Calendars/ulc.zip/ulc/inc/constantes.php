<?
define("ONEDAY",86400);
?>
