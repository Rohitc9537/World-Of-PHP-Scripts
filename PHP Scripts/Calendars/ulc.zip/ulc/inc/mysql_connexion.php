<?
$mysql_link = mysql_connect(mysql_db_host,mysql_db_user,mysql_db_password);
mysql_select_db(mysql_db_name,$mysql_link);
?>
