<?
session_name(app_name);
session_start();
?>
