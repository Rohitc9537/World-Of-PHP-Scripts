<?
ini_set("register_globals","Off");
ini_set("magic_quotes_runtime","Off");
define("mysql_db_name","ulc");
define("mysql_db_host","localhost");
define("mysql_db_user","root");
define("mysql_db_password","");

define("app_name","ulc");
define("session_life",3600);

define("app_language","fr");
// you can create files like : etc/local/lang-<language>.php

?>
