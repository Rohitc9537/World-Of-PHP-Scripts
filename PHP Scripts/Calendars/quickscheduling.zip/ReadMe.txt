http://www.quickscheduling.com
Version 2.1

1 CopyRight
2 Install

1. ALL copyright tags must remain in the footer template.

By using Employee Time Management by TimeMagnum you agree to these terms and accept full
responsibility for the removal of copyright material.  The name Employee Time Management by TimeMagnum
nor its contributors may be used without permission.

This software is provided by the copyright holders and contributor
"as is" and any express or implied warranties, including, but not
limited to, the implied warranties of merchantability and fitness for
a particular purpose are disclaimed. In no event shall the regents
or contributors be liable for any direct, indirect, incidental, special,
exemplary or consequential damages. Including but not limited to,
procurement of substitute goods or services, loss of data, profits or
business interruption.

By using this software you are granted a basic license, you may NOT
however use the software for.

- Distribution with a paid/free product without permission
- Offer hosting with preinstalled Employee Time Management by TimeMagnum without permission
- Charge for the use of Employee Time Management by TimeMagnum
- Create profit resulting from the use of the Employee Time Management by TimeMagnum
- You may not distribute the software
- You must not remove the embedded html or copyright footer
- You cannot copyright the Employee Time Management by TimeMagnum in any format

- You may change or modify the code, but may not remove the footer stating our copyright.

To report abuse of material please email email@publicintranet.com

2.  Installation
Requires PHP, MYSQL

Extract the zip file, maintain directory structure

run: calandar_install.php

contact email@publicintranet.com for support
include email title : TimeMagnun Support Question
