SZCalendar 1.4.1
-------------------------------------

Installation:
1. View the calendar.sql file and choose proper query to execute.
2. Configure the config.inc.php file

REQUIREMENTS:
MmySQLHandler (it can be found on the project page where you dwonloaded this file)

TODO:
-----------
- Password protected administration area
- Email notification
- multiuser support
- overview for administrator

Changes 1.4.1
-----------
- Fixed bug where non-admins could add events

Changes 1.4
-----------
- Added new feature "duration". Enables you to set a duration for your events!
- New Event Type "Daily Event".
- Plus other small fixes...
- Possibility to display events in a popup window (tip from Jomanix)
- Possibility to change target window to display events

Changes 1.3
-----------
- Fixed bug with day of week not displayed correctly when adding reoccuting events.

Changes 1.2
-----------
- Fixed bug with translation strings not being used everywhere.

Changes 1.1
-----------
- Fixed bug that prevented events to be added to months below october.


-------------------------------------
Email: subzane@home.se
WWW:   http://www.seduction747.com
FORUM: http://www.seduction747.com/forum