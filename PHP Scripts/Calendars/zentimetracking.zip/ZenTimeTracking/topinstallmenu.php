<?
print('<html><head><title>- - - Zen Time Tracking - - -</title>');
print('<link rel="stylesheet" type="text/css" href="incl/style.css"></head>');
echo('<body bgcolor="#BABABA" topmargin=0 leftmargin=0>');

print('<table border="0" cellspacing="0" width="100%" bgcolor="#9999CC">');
print('<tr><td align="center"  height="10%" valign="middle"><font face="Arial" color="#FFFFFF"><br><h3>Zen Time Tracking</h3></font></td></tr>');
print('</table>');
?>