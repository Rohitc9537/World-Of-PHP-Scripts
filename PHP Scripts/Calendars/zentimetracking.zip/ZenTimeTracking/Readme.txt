ZenTracking.com Zen Time Tracking 
Version 2.2

----------------------------------------------------------

ZenTracking CopyRight 2004
By using Zen Time Track (source: ZenTracking.com) you agree to these terms and accept full
responsibility for the use of this copyright material.

This software is provided by the copyright holders and contributor
"as is" and any express or implied warranties, including, but not
limited to, the implied warranties of merchantability and fitness for
a particular purpose are disclaimed. In no event shall the regents
or contributors be liable for any direct, indirect, incidental, special,
exemplary or consequential damages. Including but not limited to,
procurement of substitute goods or services, loss of data, profits or
business interruption.

By using this software you are granted a basic license, you may NOT
however use the software for.

- Distribution with a paid/free product without permission
- Offer hosting with preinstalled ZenTracking without permission
- Charge for the use of ZenTracking
- You may not distribute the software
- You must not remove the embedded html


Installation ::::

0 .Set Dataaccess.php and DataAccess1.php to writeable.

1. Browse the install.php in IE (Please give the database information).
     By entered optional keywords we can enter optional extendion to tables.
     By using Softupdate we can enter the exsiting database without deleting existing datas.
    1st Install use this option: By using Forceupdate we can enter the exsiting database with deleting existing datas.
 
2.After entered the database detail, it will go to admin registration section.
     Enter the admin/Manager username and password there.

Application Flow ::

3. This ZenTimeTracking is having two section.
	 
Admin Section :: In index.php page by clicking manager link you can login to Admin section..
    
	Admin can create more than one admin and user.Also admin can create and assign group 
to user.Admin can generate daily, monthly, yearly report based on user and groups.


User Section :: In index.php page by clicking register user link you can register user 
and by clicking by clicking user link you can login to user.

	User can create own category and add tasks in that category.Also they can generate 
more than one fields for adding their tasks.



        

   
       