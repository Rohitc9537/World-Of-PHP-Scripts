<?ob_start();?>
<html>
<?
    include ("menu.php");
?>

<br><br><br>
</form>
<?ob_end_flush();?>
</body>
</html>