<?php

#   CaLogic Language Table
#
#
#   SWEDISH
#
#
# Remove old global language table entry

$sqlstr = "delete from ".$tabpre."_languages where name = 'Swedish'";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

#
# Add entry to global language table
#

$sqlstr = "INSERT INTO ".$tabpre."_languages VALUES ('', 'Swedish', 'Entered by Christian Sahl�')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

# --------------------------------------------------------

#
# Table structure for table `".$tabpre."_lang_Swedish`
#

$sqlstr = "DROP TABLE IF EXISTS ".$tabpre."_lang_Swedish";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$sqlstr = "CREATE TABLE ".$tabpre."_lang_Swedish (
  uid int(11) NOT NULL auto_increment,
  keyid varchar(100) NOT NULL default '',
  phrase mediumtext,
  remark varchar(254) default NULL,
  PRIMARY KEY  (uid),
  UNIQUE KEY keyid (keyid)
) TYPE=MyISAM COMMENT='A CaLogic Language Table'";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

#
# Dumping data for table `".$tabpre."_lang_Swedish`
#

$entrynum = 0;



$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl1', 'M�ndag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl2', 'Tisdag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl3', 'Onsdag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl4', 'Torsdag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl5', 'Fredag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl6', 'L�rdag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdnl7', 'S�ndag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns1', 'M�n', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns2', 'Tis', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns3', 'Ons', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns4', 'Tor', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns5', 'Fre', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns6', 'L�r', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wdns7', 'S�n', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl1', 'Januari', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl2', 'Februari', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl3', 'Mars', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl4', 'April', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl5', 'May', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl6', 'Juni', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl7', 'Juli', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl8', 'Augusti', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl9', 'September', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl10', 'Oktober', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl11', 'November', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl12', 'December', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns1', 'Jan', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns2', 'Feb', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns3', 'Mar', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns4', 'Apr', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns5', 'May', 'Abbr. Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns6', 'Jun', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns7', 'Jul', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns8', 'Aug', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns9', 'Sep', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns10', 'Okt', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns11', 'Nov', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns12', 'Dec', 'Abbr. Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dnl', 'Dag', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dns', 'Dg', 'F�rk. f�r Dag, Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wnl', 'Vecka', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wns', 'WK', 'F�rk. f�r Week, Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mnl', 'M�nad', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mns', 'Mn', 'F�rk. f�r M�nad, Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ynl', '�r', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yns', '�r', 'F�rk. f�r �r, Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'prefl', 'Setup', 'Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'prefs', 'Prefr', 'F�rk. f�r Preferenser, Used in the different calendar views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butgo', 'G�', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butnew', 'Ny', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butedit', 'Redigera', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'prev', 'F�reg�ende', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'next', 'N�sta', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'allDag', 'Alla Dagar', 'Used on the Week and Dag views')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'events', 'Evenemang', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'event', 'Evenemang', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'nyrt', 'Va? Inte en registrerad anv�ndare �n?<br>Okej, du/ni �r bara 3 klick fr�n att bli en registrerad anv�ndare.<br>Som en Registrerad anv�ndare f�r du m�jlighet att skapa och konfigurera en egen online Webb kalender.<br>', 'Used on Login Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'liw', 'Logga in', 'Used on Login Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'low', 'Logga ut', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'lsel', 'V�lj ett spr�k', 'Used on Login Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pli', 'V�nligen skriv in ditt Anv�ndar namn och L�senord', 'Used on Login Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'un', 'Anv�ndar namn', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pw', 'L�senord', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'subut', 'Skicka', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rebut', 'Rensa', 'Knapp Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rlnk', 'Klicka h�r f�r att registrera.', 'Used on Login Form as a link to the registration form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'urth', 'Anv�ndar Registrering', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'urfh', 'F�lt', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ureh', 'Tilltr�de', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'urrh', 'Anm�rkningar', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fnt', 'F�r namn', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'lnt', 'Efter namn', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'emt', 'E-Mail', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwa', 'L�senord Igen', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'llt', 'Spr�k', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ungt', 'V�lj ett <b> Anv�ndar namn</b>. Du kommer anv�nda detta f�r att logga in till kalendern. Detta m�ste vara ett unikt namn och kan inte vara l�ngre �n 10 bokst�ver. Det kan endast inneh�lla bokst�ver och nummer, inga mellanslag och olika special tecken f�r anv�ndas.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fngt', 'V�nligen skriv ditt <b>F�r namn</b>', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'lngt', 'V�nligen skriv ditt <b>Efter namn</b>', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'emgt', 'V�nligen skriv din <b> E-Mail adress</b>. Detta m�ste vara en riktig/giltig adress. Efter registrerings formul�ret �r skickat, kommer det en bekr�ftelse via E-Mail. Du m�ste f�lja l�nken i E-Mailet f�r att fullf�lja registrerings processen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwgt', 'V�nligen skriv ett <b>L�senord</b>. Ditt L�senord kommer bli krypterat. Mellanslag fram och bak kommer att bli intrimmade.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwagt', 'V�nligen bekr�fta ditt <b>L�senord</b>.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'llgt', 'V�nligen v�lj det <b>Spr�k</b> du �nskar anv�nda fr�n listan av tillg�ngliga spr�k.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega1', 'Du gl�mde fylla i Anv�ndar Namn f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega2', 'Du gl�mde fylla i F�r Namn f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega3', 'Du gl�mde fylla i Efter Namn f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega4', 'Du gl�mde fylla i E-Mail f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega5', 'Du gl�mde fylla i L�senord f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega6', 'Du gl�mde fylla i L�senord Bekr�ftelse f�ltet. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rega7', 'L�senordet St�mde inte. V�nligen r�tta till det och skicka-igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'emar', 'Det E-Mail du skrev finns redan i databasen. V�nligen g� tillbak och f�rs�k igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'badem', 'Det E-Mail du skrev verkar inte vara r�tt formaterat. V�nligen r�tta till och f�rs�k igen.', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwreg', 'V�nligen v�nta medan din registrering blir bekr�ftad....', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'badun', 'Det Anv�ndar Namn du beg�rde, har redan blivit anv�ndt. V�nligen g� tillbaka och v�lj ett annat. <b>Gl�m inte, stora bokst�ver b�de med Anv�ndar Namn and L�senord!</b>', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ldbp', 'Det �r ett problem med Spr�k databasen. V�nligen kontakta Administrat�ren', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'regok', '<br><br>Tack. <br><br>Din registrering har blivit bekr�ftad. <br>Bekr�ftelse E-Mailet har ocks� blivit skickat. Du m�ste f�lja l�nken i bekr�ftelse E-Mailet innan du kan b�rja anv�nda kalendern. <br><br>Om du inte bekr�ftar din registrering inom 7 dagar,  kommer det att bli annullerat och du f�r �ter-registrera om du vill anv�nda kalendern.<br>', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pier', '<br><br>Databasen har indikerat ett inl�ggs fel. Om problem kvarst�r, V�nligen tveka inte att kontakta Administrat�ren.<br><br>Tack', 'User Registration Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'regconf', '<br>V�lkommen tillbaks %name% <br> <br>Tack f�r att du bekr�ftar registreringen. Du kan nu forts�tta till Logg in och skapa din egen kalender.<br><br>V�nligen informera mig med alla problem du uppt�cker. Om du beh�ver, <a href=\"FAQ.php\">klicka h�r f�r att se FAQ\'s</A><br><br><a href=\"%index%\">Eller klicka h�r f�r att se din kalender!</A>', 'Anv�ndar Registration confirmed')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'regfu', '<br>Tyv�rr, vi kan inte lokalisera bekr�ftelse nyckeln du skickade. Du kanske hade v�ntat f�r l�nge. <br><br><a href=\"Anv�ndarreg.php\">V�nligen klicka h�r f�r att registrera.</a>', 'User Registration Confirmation Error')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'rereg', '<br>Bekr�ftelse nyckeln du skickade har redan anv�nts av n�gon annan. <br><br><a href=\"%index%\">V�nligen klicka h�r f�r att logga in.</a>', 'User Registration Re-Confirmation Error')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'regnotconf', '<br>Du har inte bekr�ftat din registrering. V�nligen f�lj l�nken i ditt bekr�ftelse E-Mail vilket just har blivit �rer-s�nt till dig. Email adressen du skickade �r: %email% <br>Om inte detta �r din Email adress, m�ste du �ter-registrera dig f�r att kunna anv�nda denna kalender.', 'User Registration not yet confirmed')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wrongli', 'Ogiltig inloggning. V�nligen f�rs�k igen.', 'Login failed')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'goli', '<br>Du har blivit in loggad. <A HREF=\"%s\">klicka h�r</A> om din webl�sare inte st�der automatisk uppdatering...', 'no longer needed')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'tuid', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'calid', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'calname', 'Kalender Namn', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'userid', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'username', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'caltitle', 'Kalender Titel', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'caltype', 'Kalender Typ', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'showweek', 'Visa vecko nummer', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'preferedview', 'Preferens vy', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'weekstartonmonday', 'Vecka startar p�', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'weekselreact', 'Vecko vals box', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'daybeginhour', 'Dagen b�rjar p�', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dayendhour', 'Dagen slutar p�', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'timetype', '12 eller 24 timmars format', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcdividerlinecolor', 'Avdelar l�nk f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcttcolor', 'M�nads l�nk huvud teckensnitt f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcttbgcolor', 'M�nads l�nk huvud teckensnitt bakgrunds f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcttstyle', 'M�nads l�nk huvud stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcttcellcolor', 'M�nads l�nk huvud Cell f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcheaderwdcolour', 'Veckodags huvud teckensnitt f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcheaderwdbgcolour', 'Veckodags huvud teckensnitt bakgrunds f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcheaderwecolour', 'Veckodags huvud teckensnitt f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcheaderwebgcolour', 'Veckodags huvud teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwdcolour', 'Veckodags l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwdbgcolour', 'Veckodags l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwdstyle', 'Veckodags l�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwdcellcolour', 'Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwecolour', 'Veckosluts dags l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwebgcolor', 'Veckosluts dags l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwestyle', 'Veckosluts dags l�nk stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcwecellcolor', 'Veckosluts Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mccdcolor', 'Aktuell dag l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mccdbgcolor', 'Aktuell dag l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mccdstyle', 'Aktuell dag l�nk stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mccdcellcolor', 'Aktuell dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcnccolor', 'M�nads dag som inte �r aktuell (f�reg�ende/kommande) l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcncbgcolor', 'M�nads dag som inte �r aktuell (f�reg�ende/kommande) l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcncstyle', 'M�nads dag utanf�r aktuell L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcnccellcolor', 'M�nads dag utanf�r aktuell Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvdividerlinecolor', 'Avdelare linje F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvheadercolor', 'Huvud F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvttcolor', 'M�nads l�nk Huvud teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvttbgcolor', 'M�nads l�nk Huvud teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvttstyle', 'M�nads l�nk Huvud Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvttcellcolor', 'M�nads l�nk Huvud Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvheaderwdcolor', 'Veckodags Huvud teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvheaderwdbgcolor', 'Veckodags Huvud teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvheaderwecolor', 'Veckoslut Huvud teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvheaderwebgcolor', 'Veckoslut Huvud teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwdcolor', 'Veckodags L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwdbgcolor', 'Veckodags L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwdstyle', 'Veckodags L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwdcellcolor', 'Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwecolor', 'Veckoslut dag l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwebgcolor', 'Veckoslut dag l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwestyle', 'Veckoslut dag l�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvwecellcolor', 'Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvcdcolor', 'Aktuell dag l�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvcdbgcolor', 'Aktuell dag l�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvcdstyle', 'Aktuell dag l�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvcdcellcolor', 'Aktuell Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvnccellcolor', 'Utan f�r aktuell m�nad Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvdividerlinecolor', 'Avdelare linje F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvheadercolor', 'Huvud F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvheaderwdcolor', 'Huvud Veckodags teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvheaderwdbgcolor', 'Huvud Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvheaderwecolor', 'Huvud Veckoslut teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvheaderwebgcolor', 'Huvud Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwdcolor', 'Veckodags L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwdbgcolor', 'Veckodags L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwdstyle', 'Veckodags L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwdcellcolor', 'Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwecolor', 'Veckoslut dag L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwebgcolor', 'Veckoslut Dag L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwestyle', 'Veckoslut Dag L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwecellcolor', 'Veckoslut Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvcdcolor', 'Aktuell Dag L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvcdbgcolor', 'Aktuell Dag L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvcdstyle', 'Aktuell Dag L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvcdcellcolor', 'Aktuell Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvnccolor', 'Utan f�r aktuell m�nad L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvncbgcolor', 'Utan f�r aktuell m�nad L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvncstyle', 'Utan f�r aktuell m�nad L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvnccellcolor', 'Utan f�r aktuell m�nad Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwlcolor', 'Vecka L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwlbgcolor', 'Vecka L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvwlstyle', 'Vecka L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvdividerlinecolor', 'avdelare linje F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheadercolor', 'Huvud F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwdcolor', 'Huvud Veckodags L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwdbgcolor', 'Huvud Veckodags L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwdstyle', 'Huvud Veckodags L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwdcellcolor', 'Huvud Veckodags L�nk Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwecolor', 'Huvud Veckoslut Dag L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwebgcolor', 'Huvud Veckoslut Dag L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwestyle', 'Huvud Veckoslut Dag L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderwecellcolor', 'Huvud Veckoslut Dag L�nk Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheadercdcolor', 'Huvud aktuell Dag L�nk teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheadercdbgcolor', 'Huvud aktuell Dag L�nk teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheadercdstyle', 'Huvud aktuell Dag L�nk Stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheadercdcellcolor', 'Huvud aktuell Dag L�nk Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderadcolor', 'Alla evenemangs dagars Huvud teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderadbgcolor', 'Alla evenemangs dagars Huvud teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvheaderadcellcolor', 'Alla evenemangs dagars Huvud Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawdcellcolor', 'Alla evenemangs dagars Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawecolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawebgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvawecellcolor', 'Alla evenemangs dagars Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvacdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvacdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvacdcellcolor', 'All Dag Events Aktuell Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwdcellcolor', 'Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwecolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwebgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvwecellcolor', 'Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvcdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvcdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvcdcellcolor', 'Aktuell Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvtc', 'Timmar teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvtcbg', 'Timmar teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvtccellcolor', 'Timmar Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvdividerlinecolor', 'Delare Linje F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvheadercolor', 'Huvud F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvadcolor', 'Alla dagars evenemang Huvud Font F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvadbgcolor', 'Alla dagars evenemang Huvud Font Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvadcellcolor', 'Alla dagars evenemang Huvud Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawdcellcolor', 'Alla dagars evenemang Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawecolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawebgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvawecellcolor', 'Alla dagars evenemang Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvacdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvacdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvacdcellcolor', 'Alla dagars evenemang Aktuell Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwdcellcolor', 'Veckodags Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwecolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwebgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvwecellcolor', 'Veckoslut Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvcdcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvcdbgcolor', 'inte anv�nd', 'inte anv�nd')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvcdcellcolor', 'Aktuell Dag Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvtccolor', 'Timmar teckensnitt F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvtcbgcolor', 'Timmar teckensnitt Bakgrunds F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvtccellcolor', 'Timmar Cell F�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'alcn', 'Kalender Namnet f�r inte vara blankt.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'alct', 'Kalender Titel f�r inte vara blankt.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'alts', 'Tiden d� Dagen b�rjar f�r inte vara h�gre �n dagens slut tid.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'alncc', 'Vill du verkligen skapa en ny kalender stil', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'calword', 'Kalender', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'aldel1', 'Vill du verkligen radera', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'aldel2', 'Radera', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'aldel3', 'Kalender kommer ocks� att radera alla evenemang som �r associerade med den, �r du s�ker?', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'funcan', 'Funktionen avbryten', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'scgbut', 'Generellt', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'sgcbut', 'Global', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'smcbut', 'Mini Kalender', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'syvbut', '�rs �versikt', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'smvbut', 'M�nads �versikt', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'swvbut', 'Vecko �versikt', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'sdvbut', 'Dag �versikt', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'srvbut', 'R�ttigheter', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ssvbut', 'Beskrivningar', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'scabut', 'Kategorier', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mycword', 'Min Kalender:', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'opcalword', 'Annan (�ppen / Publik) Kalender:', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butadd', 'L�gg till', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butdel', 'Radera', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fcalname', 'Detta �r namnet p� din kalender. Det m�ste vara unikt bland de andra namnen av dina kalendrar. Skriv upp till 50 bokst�ver.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fcaltitle', 'Kalender Titeln visas upp p� varje �versikt.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fcaltype', 'Det finns tre typer av kalendrar, vissa som endast Site Admin kan se.<br><b>�ppna</b>: Vilken Anv�ndar / grupp kan se och eller l�gga till / radera inl�gg. Vilken Anv�ndar / grupp kan g�ra inl�gg i �ppna kalendrar.<br><b>Publik</b>: Vilken Anv�ndar / grupp kan se och eller g�ra inl�gg till denna typ av kalender, men endast de Anv�ndar / grupp som �r specifierad av dig kan l�gga till / radera inl�gg.<br><b>Privata</b>: Du m�ste specifiera vad varje anv�ndare f�r g�ra. Visa, l�gga till, radera,  och komentera r�ttigheter �r alla inst�llt individuellt f�r varje anv�ndare.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fshowweek', 'V�lj ja om du kunna se vecko nummer i m�nads �versikten.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fpreview', 'V�lj den �versikt du f�redrar. Denna �versikt anv�nds som din start �versikt.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fmonday', 'M�nDag', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fsunday', 'S�ndag', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fwson', 'V�lj hurvida du vill att din kalender ska b�rja med m�ndag eller s�ndag.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wfyes', 'Ja', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wfno', 'Nej', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wftype1', 'Typ1', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wftype2', 'Typ2', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ftype', '<b>Typ1</b>: Vecko v�ljar menyn kommer f�r-v�lja aktuell vecka, om det �r inom 6 weeks av den aktuella visade datumen, annars blir f�rsta veckan av m�naden f�r-vald.<br><b>Typ 2</b>: Den f�rsta visade veckan av m�naden kommer alltid att vara f�r-vald.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ftimetype', 'V�lj hurvida du vill ha 24 timmars visning eller 12 timmar med am och pm.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wf12', '12 timmar', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wf24', '24 timmar', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fdayst', 'V�lj start timmen f�r vecka och dag visning', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fdayen', 'V�lj slut timmen f�r vecka och dag visning.', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'ffcaltxt', '<b>Du m�ste kompletera denna initial Setup (uppbyggnad) innan du kan forts�tta.</b>', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butsavech', 'Spara inst�llningar', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butpv', 'F�reg�ende v�rden', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butgoc', 'G� till kalendern', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fnword', 'ingen', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'funword', 'understrykning', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'folword', '�verstrykning', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'fstword', 'linje genom', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'funolword', 'understrykning och �verstrykning', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'edlt1', 'Redigera ', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'edltt', 'Spr�k tabell', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'keyidt', 'KEYID (kan inte �ndras)', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pht', 'Fras (HTML till�ten)', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'leaved', 'L�mna Editorn utan att spara �ndringar', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'descword', 'Beskrivning', 'Language Editor')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'edlang', 'Redigera spr�k:', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mkst', 'G�r till standard', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'entry', 'Intr�de', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'opcw', '�ppen', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pucw', 'Publik', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'prcw', 'Privat', 'Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'userlo', 'Du har blivit ut loggad', 'Logon Screen')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'linff', 'Anv�ndar Namn kan inte vara blankt.', 'Logon Screen')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'lipff', 'L�senord kan inte vara blankt.', 'Logon Screen')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'endwelc', 'Grattis! Du har gjort din f�rsta CaLogic Kalender.<br><br>Kalendern har blivit gjord med standard stilen, <br><a href=\"%index%?goprefs=1\">klicka h�r f�r att g� till setup</a> och designa kalendern som du vill ha den.<br>Or <a href=\"%index%\">klicka h�r f�r att se din kalender.</a><br><br>Du kan �terv�nda till setup menyn n�r du vill.', 'First Cal Setup Success')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwsnc1', 'Spara kalender konfigurering', 'First Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwsnc2', 'V�nligen v�nta medan din kalender', 'First Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwsnc3', 'blir sparad....', 'First Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwlet', 'Sparar spr�k', 'Language Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwles', 'V�nligen v�nta medan �ndringarna sparas', 'Language Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pwlec', 'Spara komplett.', 'Language Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butgoset', 'G� till Setup', 'Language Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'butgoled', 'Konfigurera de valda redigerade spr�ket', 'Language Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'badcalnt', 'Kalender namnet �r redan taget', 'Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'pctta', 'V�nligen klicka h�r och f�rs�k igen.', 'Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'badcaln', 'Du har redan en kalender med namnet', 'Calendar Save')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvdtsl', 'Sommartid fungerar p� denna server n�r CaLogic k�rs.', 'Dag View DTS Text')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dtss', 'DST', 'Sommartid')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'calownerword', 'Kalender �gare', 'used in the Setup Area')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'tzofword', 'Tidzon Offset', 'used on the login form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'tztext', 'Detta �r din tidzon Offset fr�n GMT och visas i timmar. Det �r baserad p� din dators tid och land inst�llningar. Tidzon Offset beh�vs f�r att visa den korekta datum och tiden och f�rs�kra dig att p�minnare skickas i tid.<br>Om tidzon Offset inte �r korrekt, d� �r din dators tidsinst�llningar fel. Du ska inte justera tidzon Offset, men h�ldre �ndra din dators tid inst�llningar.', 'used on the login form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mcdwecellcolor', 'Dag med evenemang Cell F�rg', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvdwecellcolor', 'Dag med evenemang Cell F�rg', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_btxtfont', 'Standard Font', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_btxtcolor', 'Standard Font Color', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_standardbgcolor', 'Standard Back Ground Color', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_btxtsize', 'Standard Font Size in points', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_standardbgimg', 'Skriv in URL f�r bakgrunds bilden som ska anv�ndas till din kalender', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_prevcolor', '\"F�reg�ende\" L�nk f�rg ', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_prevbgcolor', '\"F�reg�ende\" L�nk bakgrunds f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscosf_prevstyle', '\"F�reg�ende\" L�nk stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_nextcolor', '\"N�sta\" L�nk f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_nextbgcolor', '\"N�sta\" L�nk bakgrunds f�rg', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscosf_nextstyle', '\"N�sta\" L�nk stil', 'Calendar Setup Form')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_prefcolor', 'inte anv�nd', 'Used in all Headers')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscosf_prefstyle', 'inte anv�nd', 'Used in all Headers')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum += 1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscocf_cssc', 'Aktuell Setup sektion knapp Cell Bakgrunds F�rg', 'Anv�nds i setup f�r att belysa Aktuell sektions knapp')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);


$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_subtitletxt', 'Event Sub Title Descriptor', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_headpic', 'Header Banner Pic URL', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_headtext', 'Header Banner Picture alternat text', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_headlink', 'Header Banner Link', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_headtarget', 'Header Banner Link Target', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_footpic', 'Footer Banner Pic URL', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_foottext', 'Footer Banner Picture alternat text', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_footlink', 'Footer Banner Link', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoif_foottarget', 'Footer Banner Link Target', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_allowdv', 'Allow Day View', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_allowwv', 'Allow Week View', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_allowmv', 'Allow Month View', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_allowyv', 'Allow Year View', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_dispwvpd', 'Display Week View Selector', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_dispmvpd', 'Display Month View Selector', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_dispyvpd', 'Display Year View Selector', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_dispcnpd', 'Display Calendar Selector', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_dispevcr', 'Display Event Creator', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_withesb', 'Display Month View Event Scroll Box', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_withwvesb', 'Display Week View Event Scroll Box', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_withdvesb', 'Display Day View Event Scroll Box', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_showomd', 'Display Out of Month Day Numbers', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_showwvtime', 'Show the time column in Week View<br>(not yet implemented)', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

$entrynum +=1;
$sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'gcscoyn_showdvtime', 'Show the time column in Day View<br>(not yet implemented)', 'Calendar Setup')";
mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);


        $entrynum +=1;
        $sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'yvselmc_mcyv', 'Select if and where you want the mini calendar to show up in the year view<br>if only left or right is selected then the current month will be shown. If both is selected the the previous and next months will be shown.', 'Calendar Setup')";
        mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

        $entrynum +=1;
        $sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'mvselmc_mcmv', 'Select if and where you want the mini calendar to show up in the month view<br>if only left or right is selected then the current month will be shown. If both is selected the the previous and next months will be shown.', 'Calendar Setup')";
        mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

        $entrynum +=1;
        $sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'wvselmc_mcwv', 'Select if and where you want the mini calendar to show up in the week view<br>if only left or right is selected then the current month will be shown. If both is selected the the previous and next months will be shown.', 'Calendar Setup')";
        mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

        $entrynum +=1;
        $sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", 'dvselmc_mcdv', 'Select if and where you want the mini calendar to show up in the day view<br>if only left or right is selected then the current month will be shown. If both is selected the the previous and next months will be shown.', 'Calendar Setup')";
        mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

# menu

# DO NOT CHANGE THE TEXT HERE!!!
        $newlangkeys = array("pu_functionmenutype", "pu_MenuBarColor",
        "pu_MenuBarFont",
        "pu_MenuBarFontColor",
        "pu_MenuBarFontSize",
        "pu_MenuBarHighlightColor",
        "pu_MenuBarHighlightFont",
        "pu_MenuBarHighlightFontColor",
        "pu_MenuItemBorderColor",
        "pu_MenuItemColor",
        "pu_MenuItemFont",
        "pu_MenuItemFontColor",
        "pu_MenuItemFontSize",
        "pu_MenuItemHighlightColor",
        "pu_MenuItemHighlightFont",
        "pu_MenuItemHighlightFontColor",
        "pu_PopupDayCaptionColor",
        "pu_PopupDayCaptionFont",
        "pu_PopupDayCaptionFontColor",
        "pu_PopupDayCaptionSize",
        "pu_PopupDayColor",
        "pu_PopupDayFont",
        "pu_PopupDayFontColor",
        "pu_PopupDayFontSize",
        "pu_PopupEventCaptionColor",
        "pu_PopupEventCaptionFont",
        "pu_PopupEventCaptionFontColor",
        "pu_PopupEventCaptionSize",
        "pu_PopupEventColor",
        "pu_PopupEventFont",
        "pu_PopupEventFontColor",
        "pu_PopupEventFontSize",
        "pu_PopupCreatorCaptionColor",
        "pu_PopupCreatorCaptionFont",
        "pu_PopupCreatorCaptionFontColor",
        "pu_PopupCreatorCaptionSize",
        "pu_PopupCreatorColor",
        "pu_PopupCreatorFont",
        "pu_PopupCreatorFontColor",
        "pu_PopupCreatorFontSize");


# CHANGE THE TEXT HERE IF YOU WANT!
        $newlangvals = array("Function Menu Type", "Horizontal Menu Bar Color",
        "Horizontal Menu Bar Font",
        "Horizontal Menu Bar Font Color",
        "Horizontal Menu Bar Font Size in ponts",
        "Horizontal Menu Bar Highlight Color",
        "Horizontal Menu Bar Highlight Font",
        "Horizontal Menu Bar Highlight Font Color",
        "Menu Item Border Color",
        "Menu Item Color",
        "Menu Item Font",
        "Menu Item Font Color",
        "Menu Item Font Size in points",
        "Menu Item Highlight Color",
        "Menu Item Highlight Font",
        "Menu Item Highlight Font Color",
        "Day Popup Caption Color",
        "Day Popup Caption Font",
        "Day Popup Caption Font Color",
        "Day Popup Caption Size (1 to 7)",
        "Day Popup Color",
        "Day Popup Font",
        "Day Popup Font Color",
        "Day Popup Font Size (1 to 7)",
        "Event Popup Caption Color",
        "Event Popup Caption Font",
        "Event Popup Caption Font Color",
        "Event Popup Caption Size (1 to 7)",
        "Event Popup Color",
        "Event Popup Font",
        "Event Popup Font Color",
        "Event Popup Font Size (1 to 7)",
        "Creator Popup Caption Color",
        "Creator Popup Caption Font",
        "Creator Popup Caption Font Color",
        "Creator Popup Caption Size (1 to 7)",
        "Creator Popup Color",
        "Creator Popup Font",
        "Creator Popup Font Color",
        "Creator Popup Font Size (1 to 7)");

        #$keycount = 0;
## DONT CHANGE THIS FOREACH LOOP!!
        foreach($newlangkeys as $key => $val) {

            $keyval = $val;
            $val = $newlangvals["$key"];

            $entrynum +=1;
            $sqlstr = "INSERT INTO ".$tabpre."_lang_Swedish VALUES (".$entrynum.", '".$keyval."', '".$val."', 'Calendar Setup')";
            mysql_query($sqlstr) or die("Database setup error.<br><br>MySQL said: ".mysql_error()."<br><br>SQL String: ".$sqlstr."<br><br>File: ".substr(__FILE__,strrpos(__FILE__,"/"))."<br><br>Line: ".__LINE__.$GLOBALS["errep"]);

        }
# --------------------------------------------------------

?>






