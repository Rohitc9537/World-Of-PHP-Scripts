<?php
include_once("calogic_lang_english.php");
include_once("calogic_lang_deutsch.php");
include_once("calogic_lang_french.php");
include_once("calogic_lang_swedish.php");
?>
