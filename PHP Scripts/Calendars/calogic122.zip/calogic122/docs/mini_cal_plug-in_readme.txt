CaLogic Mini Calendar Plug-In usage/install instructions
or
How to embed the CaLogic Mini Calendar into any web page
==========================================================

Please read all documentation in the docs folder.


The information in this file will help you to use the "Mini Cal Plug.in"

The Mini Cal Plug-in is a feature that allows you to "plug" the mini calendar
from any calendar into any php web page. The mini cal plug-in will display
all events and colors just as the mini calendar in the main CaLogic program
does.

The Requirement for this plug-in is that CaLogic must be installed and
operational.

A demo of how to implement the plug-in is included.

mcpi-demo.php
    This is the demo "template" file. Use it as a guide line on how to
    implement the mini cal plug-in. There are also instructions in this
    file on how to set the variables needed.


Ah yes, one final note. The name of HTML document that you intend
to embed the Mini Cal in, must end with .php

For example, you want to plug the mini cal into your index.html file. No Problem.
Make a copy of the index.html file and name the copy index.php
Modify the index.php file as outlined in mcpi-demo.php file.
Point your links to index.php instead of index.html and that's it!
You can also have index.html automatically relocate to index.php, that way
no one will notice the change. Except for the new really cool mini cal plug in
your page now has!


If you have any problems or questions, please feel free to contact me.

philip@calogic.de

Visit www.calogic.de for all the latest information about CaLogic.


Thanks

Philip
