<?php

############################################################
#
#  THIS IS A DYNAMICALLY CREATED FILE
#  DO NOT ALTER ANYTHING WITH IN THIS FILE
#  TO ALTER VALUES IN THIS FILE USE THE SETUP.PHP PROGRAM
#
############################################################

/*** SET VARIABLES HERE *****/ 
$dbhost = "my.sqlhost.com";
$dbname = "calogic";
$dbuser = "calogic";
$dbpass = "mypassword";

$tabpre = "clc";
$idxfile = "index.php";

?>