<STYLE type="text/css">
<!--

.newlink {
  color: ;
  background-color: ;
  text-decoration: none;
  cursor: hand;
}

.gcprevlink {
  color: <?php print $curcalcfg["gcscocf_prevcolor"]; ?>;
  background-color: <?php print $curcalcfg["gcscocf_prevbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["gcscosf_prevstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gcprevfont {
  color: <?php print $curcalcfg["gcscocf_prevcolor"]; ?>;
  background-color: <?php print $curcalcfg["gcscocf_prevbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["gcscosf_prevstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;

}

.gcnextlink {
  color: <?php print $curcalcfg["gcscocf_nextcolor"]; ?>;
  background-color: <?php print $curcalcfg["gcscocf_nextbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["gcscosf_nextstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gcnextfont {
  color: <?php print $curcalcfg["gcscocf_nexecolor"]; ?>;
  background-color: <?php print $curcalcfg["gcscocf_nextbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["gcscosf_nextstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;

}
.gcpreflink {
  color: <?php print $curcalcfg["gcscocf_prefcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["gcscosf_prefstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gccssc {
  background-color: <?php print $curcalcfg["gcscocf_cssc"]; ?>;
}

.mcdivider {
  background-color: <?php print $curcalcfg["mcdividerlinecolor"]; ?>;
}

.mcmlink {
  color: <?php print $curcalcfg["mcttcolor"]; ?>;
  background-color: <?php print $curcalcfg["mcttbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcttstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
  FONT-WEIGHT: bold;
}

.mcmcell {
  background-color: <?php print $curcalcfg["mcttcellcolor"]; ?>;
}

.mchwd {
  color: <?php print $curcalcfg["mcheaderwdcolor"]; ?>;
  font-size: 9pt;
}

.mchwdcell {
  background-color: <?php print $curcalcfg["mcheaderwdbgcolor"]; ?>;
}

.mchwe {
  color: <?php print $curcalcfg["mcheaderwecolor"]; ?>;
  font-size: 9pt;
}

.mchwecell {
  background-color: <?php print $curcalcfg["mcheaderwebgcolor"]; ?>;
}

.mcwdlink {
  color: <?php print $curcalcfg["mcwdcolor"]; ?>;
  background-color: <?php print $curcalcfg["mcwdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcwdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwdcell {
  background-color: <?php print $curcalcfg["mcwdcellcolor"]; ?>;
}

.mcwelink {
  color: <?php print $curcalcfg["mcwecolor"]; ?>;
  background-color: <?php print $curcalcfg["mcwebgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcwestyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwecell {
  background-color: <?php print $curcalcfg["mcwecellcolor"]; ?>;
}

.mccdlink {
  color: <?php print $curcalcfg["mccdcolor"]; ?>;
  background-color: <?php print $curcalcfg["mccdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mccdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mccdcell {
  background-color: <?php print $curcalcfg["mccdcellcolor"]; ?>;
}

.mcnclink {
  color: <?php print $curcalcfg["mcnccolor"]; ?>;
  background-color: <?php print $curcalcfg["mcncbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcncstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcnccell {
  background-color: <?php print $curcalcfg["mcnccellcolor"]; ?>;
}

.mcdwecell {
  background-color: <?php print $curcalcfg["mcdwecellcolor"]; ?>;
}

.mcwdwelink {
  background-color: <?php print $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php print $curcalcfg["mcwdcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcwdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwewelink {
  background-color: <?php print $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php print $curcalcfg["mcwecolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcwestyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcncdwelink {
  background-color: <?php print $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php print $curcalcfg["mcnccolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mcncstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.yvdivider {
  background-color: <?php print $curcalcfg["yvdividerlinecolor"]; ?>;
}

.yvhead {
  color: <?php print $curcalcfg["yvheadercolor"]; ?>;
}

.yvmlink {
  color: <?php print $curcalcfg["yvttcolor"]; ?>;
  background-color: <?php print $curcalcfg["yvttbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvttstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.yvmcell {
  background-color: <?php print $curcalcfg["yvttcellcolor"]; ?>;
}

.yvhwd {
  color: <?php print $curcalcfg["yvheaderwdcolor"]; ?>;
  font-size: 9pt;
}

.yvhwdcell {
  background-color: <?php print $curcalcfg["yvheaderwdbgcolor"]; ?>;
}

.yvhwe {
  color: <?php print $curcalcfg["yvheaderwecolor"]; ?>;
  font-size: 9pt;
}

.yvhwecell {
  background-color: <?php print $curcalcfg["yvheaderwebgcolor"]; ?>;
}

.yvwdlink {
  color: <?php print $curcalcfg["yvwdcolor"]; ?>;
  background-color: <?php print $curcalcfg["yvwdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwdcell {
  background-color: <?php print $curcalcfg["yvwdcellcolor"]; ?>;
}

.yvwelink {
  color: <?php print $curcalcfg["yvwecolor"]; ?>;
  background-color: <?php print $curcalcfg["yvwebgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwecell {
  background-color: <?php print $curcalcfg["yvwecellcolor"]; ?>;
}

.yvcdlink {
  color: <?php print $curcalcfg["yvcdcolor"]; ?>;
  background-color: <?php print $curcalcfg["yvcdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvcdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvcdcell {
  background-color: <?php print $curcalcfg["yvcdcellcolor"]; ?>;
}

.yvnccell {
  background-color: <?php print $curcalcfg["yvnccellcolor"]; ?>;
}

.yvdwecell {
  background-color: <?php print $curcalcfg["yvdwecellcolor"]; ?>;
}

.yvwdwelink {
  color: <?php print $curcalcfg["yvwdcolor"]; ?>;
  background-color: <?php print $curcalcfg["yvdwecellcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwewelink {
  color: <?php print $curcalcfg["yvwecolor"]; ?>;
  background-color: <?php print $curcalcfg["yvdwecellcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["yvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvdivider {
  background-color: <?php print $curcalcfg["mvdividerlinecolor"]; ?>;
}

.mvhead {
  color: <?php print $curcalcfg["mvheadercolor"]; ?>;
}

.mvhwd {
  color: <?php print $curcalcfg["mvheaderwdcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.mvhwdcell {
  background-color: <?php print $curcalcfg["mvheaderwdbgcolor"]; ?>;
}

.mvhwe {
  color: <?php print $curcalcfg["mvheaderwecolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.mvhwecell {
  background-color: <?php print $curcalcfg["mvheaderwebgcolor"]; ?>;
}

.mvwdlink {
  color: <?php print $curcalcfg["mvwdcolor"]; ?>;
  background-color: <?php print $curcalcfg["mvwdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvwdcell {
  background-color: <?php print $curcalcfg["mvwdcellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvwelink {
  color: <?php print $curcalcfg["mvwecolor"]; ?>;
  background-color: <?php print $curcalcfg["mvwebgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvwecell {
  background-color: <?php print $curcalcfg["mvwecellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvcdlink {
  color: <?php print $curcalcfg["mvcdcolor"]; ?>;
  background-color: <?php print $curcalcfg["mvcdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mvcdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvcdcell {
  background-color: <?php print $curcalcfg["mvcdcellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvnclink {
  color: <?php print $curcalcfg["mvnccolor"]; ?>;
  background-color: <?php print $curcalcfg["mvncbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mvncstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvnccell {
  background-color: <?php print $curcalcfg["mvnccellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvkwlink {
  color: <?php print $curcalcfg["mvwlcolor"]; ?>;
  background-color: <?php print $curcalcfg["mvwlbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["mvwlstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.wvdivider {
  background-color: <?php print $curcalcfg["wvdividerlinecolor"]; ?>;
}

.wvhead {
  color: <?php print $curcalcfg["wvheadercolor"]; ?>;
}

.wvhwdlink {
  color: <?php print $curcalcfg["wvheaderwdcolor"]; ?>;
  background-color: <?php print $curcalcfg["wvheaderwdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["wvheaderwdstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhwdcell {
  background-color: <?php print $curcalcfg["wvheaderwdcellcolor"]; ?>;
}

.wvhwelink {
  color: <?php print $curcalcfg["wvheaderwecolor"]; ?>;
  background-color: <?php print $curcalcfg["wvheaderwebgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["wvheaderwestyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhwecell {
  background-color: <?php print $curcalcfg["wvheaderwecellcolor"]; ?>;
}

.wvhcdlink {
  color: <?php print $curcalcfg["wvheadercdcolor"]; ?>;
  background-color: <?php print $curcalcfg["wvheadercdbgcolor"]; ?>;
  text-decoration: <?php print $curcalcfg["wvheadercdstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhcdcell {
  background-color: <?php print $curcalcfg["wvheadercdcellcolor"]; ?>;
}

.wvhadtext {
  color: <?php print $curcalcfg["wvheaderadcolor"]; ?>;
  background-color: <?php print $curcalcfg["wvheaderadbgcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhadcell {
  background-color: <?php print $curcalcfg["wvheaderadcellcolor"]; ?>;
}

.wvawdcell {
  background-color: <?php print $curcalcfg["wvawdcellcolor"]; ?>;
}

.wvawecell {
  background-color: <?php print $curcalcfg["wvawecellcolor"]; ?>;
}

.wvacdcell {
  background-color: <?php print $curcalcfg["wvacdcellcolor"]; ?>;
}

.wvwdcell {
  background-color: <?php print $curcalcfg["wvwdcellcolor"]; ?>;
}

.wvwecell {
  background-color: <?php print $curcalcfg["wvwecellcolor"]; ?>;
}

.wvcdcell {
  background-color: <?php print $curcalcfg["wvcdcellcolor"]; ?>;
}

.wvtctext {
  color: <?php print $curcalcfg["wvtccolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvtccell {
  background-color: <?php print $curcalcfg["wvtccellcolor"]; ?>;
}

.dvdivider {
  background-color: <?php print $curcalcfg["dvdividerlinecolor"]; ?>;
}

.dvhead {
  color: <?php print $curcalcfg["dvheadercolor"]; ?>;
}

.dvadtext {
  color: <?php print $curcalcfg["dvadcolor"]; ?>;
  background-color: <?php print $curcalcfg["dvadbgcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.dvadcell {
  background-color: <?php print $curcalcfg["dvadcellcolor"]; ?>;
}

.dvawdcell {
  background-color: <?php print $curcalcfg["dvawdcellcolor"]; ?>;
}

.dvawecell {
  background-color: <?php print $curcalcfg["dvawecellcolor"]; ?>;
}

.dvacdcell {
  background-color: <?php print $curcalcfg["dvacdcellcolor"]; ?>;
}

.dvwdcell {
  background-color: <?php print $curcalcfg["dvwdcellcolor"]; ?>;
}

.dvwecell {
  background-color: <?php print $curcalcfg["dvwecellcolor"]; ?>;
}

.dvcdcell {
  background-color: <?php print $curcalcfg["dvcdcellcolor"]; ?>;
}

.dvtctext {
  color: <?php print $curcalcfg["dvtccolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.dvtccell {
  background-color: <?php print $curcalcfg["dvtccellcolor"]; ?>;
}

.ssmHdr {
color: white;
font: bold 14px verdana;
	}

.ssmHdr:link {
color: white;
text-decoration: none;
	}

.ssmHdr:visited {
color: white;
text-decoration: none;
	}

.ssmHdr:hover {
color: white;
text-decoration: underline;
	}

.ssmHdr:active {
color: white;
text-decoration: underline;
	}

.ssmItem {
color: black;
font: 12px verdana;
	}

.ssmItem:link {
color: black;
text-decoration: none;
	}

.ssmItem:visited {
color: black;
text-decoration: none;
	}

.ssmItem:hover {
color: black;
text-decoration: underline;
	}

.ssmItem:active {
color: black;
text-decoration: underline;
	}

.ssmBar {
color: white;
font: bold 14px verdana;
	}



-->
</STYLE>
<!--body{margin:0}-->
