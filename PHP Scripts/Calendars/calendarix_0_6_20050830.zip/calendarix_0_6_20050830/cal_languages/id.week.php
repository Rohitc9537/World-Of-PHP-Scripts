<?php
$week[1]="Minggu";
$week[2]="Senin";
$week[3]="Selasa";
$week[4]="Rabu";
$week[5]="Kamis";
$week[6]="Jum'at";
$week[7]="Sabtu";
?>