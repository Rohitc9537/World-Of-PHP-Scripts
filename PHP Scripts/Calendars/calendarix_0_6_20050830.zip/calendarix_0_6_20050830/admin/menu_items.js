
/* --- menu items --- */
var MENU_ITEMS = [
		
	['Events','#',{'sb' :'Events'},
	['Add','cal_event.php?op=eventform',{'sb' :'Add'}],
	['Approvals','calendar.php?op=approval',{'sb' :'Approvals'}],
	['Historical Items','cal_history.php?op=hist',{'sb' :'Historical Items'}]],
	['View','#',{'sb' :'View'},
	['Categories','cal_cat.php?op=cats',{'sb' :'Categories'}],
	['Current Month','calendar.php?op=cal',{'sb' :'Current Month'}],
	['Current Week','cal_adminweek.php?op=week',{'sb' :'Current Week'}],
	['Today','cal_adminday.php?op=day',{'sb' :'Today'}],
	['Users','cal_user.php?op=users',{'sb' :'Users'}]],
	['User Calendar','../calendar.php',{'sb' :'User Calendar'}],
	['Logout','cal_login.php?op=logout',{'sb' :'Logout'}]
];
	