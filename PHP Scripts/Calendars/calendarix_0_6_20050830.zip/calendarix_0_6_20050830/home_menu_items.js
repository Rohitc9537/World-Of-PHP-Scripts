
/* --- menu items --- */
var MENU_ITEMS = [
		
	['About','../index.php',{'sb' :'About'},
	['Credits','../credits.php',{'sb' :'Credits'}],
	['Users','../users.php',{'sb' :'Users'}]],
	['Demo','../demo/index.php',{'sb' :'Demo'},
	['Basic','../demo/calendar.php',{'sb' :'Basic'}],
	['Advanced','../advanced/calendar.php',{'sb' :'Advanced'}]],
	['Download','../download_basic.php',{'sb' :'Download'},
	['Basic','../download_basic.php',{'sb' :'Basic'}],
	['Advanced','../download_advanced.php',{'sb' :'Advanced'}]],
	['Features','../features.php',{'sb' :'Features'},
	['List','../features.php',{'sb' :'List'}],
	['Mini-Calendar','../minicalendar.php',{'sb' :'Mini-Calendar'}],
	['Screen Shots','../screens.php',{'sb' :'Screen Shots'},
	['Basic','../screens.php',{'sb' :'Basic'}],
	['Advanced','../screen_advanced.php',{'sb' :'Advanced'}]]],
	['Pricing','../pricing.php',{'sb' :'Pricing'}],
	['Support','../forum/index.php',{'sb' :'Support'},
	['FAQ','../faq.php',{'sb' :'FAQ'}],
	['Forum','../forum/index.php',{'sb' :'Forum'}],
	['Installation','../installation.php',{'sb' :'Installation'}],
	['Tools','../tools.php',{'sb' :'Tools'}]]
];
	