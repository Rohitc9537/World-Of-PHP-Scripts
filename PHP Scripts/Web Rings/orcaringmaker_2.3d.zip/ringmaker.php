<?php 

include "orca/orm_lang_en.php";
include "orca/orm_head.php";

?><html>
<head>
  <title><?php echo $rData['UA']; ?></title>

  <link rel="stylesheet" type="text/css" href="orca/orm_style.css" />
  <style type="text/css">

body {
  background-color:#ffffff;
  font:normal 100% Arial,sans-serif;
}

  </style>
</head>

<body>

  <?php include "orca/orm_body.php"; ?>

</body>
</html>