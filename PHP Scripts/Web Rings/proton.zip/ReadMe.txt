			Quick Installation Of Proton-CJ

1. Copy file 'install.php' to root directory of your server (BINARY mode!).
2. Chmod the root directory to "755" or "777".
3. Call http://www.yoursite.com/install.php from a browser.
4. Make sure that file "install.php" deleted from the server after successfull installation.