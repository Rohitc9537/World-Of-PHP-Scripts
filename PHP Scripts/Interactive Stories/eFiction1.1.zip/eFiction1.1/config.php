<?php

//Config File--you can edit this by hand, but it's preferable to use the admin panel

//Sitename

$sitename = "Enter Sitename";

//Slogan

$slogan = "This is a great slogan!";

//Site URL

$url = "http://www.rivkashome.com/fanfiction";

//Admin E-mail

$siteemail = "rivka@danger-room.net";

//Database Config Path

$databasepath = "data";

//Store stories

$store = "files";

//Automatically validate stories; yes = 1, no = 0

$autovalidate = "0";

//Number of categories; if only one, will shorten some processes

$numcats = "0";

//Allow readers to submit reviews; yes = 1, no = 0

$reviewsallowed = "1";

//Rating system, in addition to reviews; none = 0, stars = 1, like/dislike = 2

$ratings = "1";

//Allow Round Robins; yes = 1, no = 0

$roundrobins = "0";

//Turn off submissions completely; yes = 1, no = 0

$submissionsoff = "0";

//Allow Anonymous reviews; yes = 1, no = 0

$anonreviews = "1";

//Number of items per page in search results

$itemsperpage = "3";

//Allow image uploads with stories; yes = 1, no = 0

$imageupload = "1";

//Max image height

$imageheight = "200";

//Max image width

$imagewidth = "200";

//Default Skin

$skin = "bluepurple";

?>