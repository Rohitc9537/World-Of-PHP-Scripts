I've decided to include the skin I made for my site 
in Rivka's eFiction release.

As you can see, I've included a little notice saying:
"Skin Design by Khuffie of Zelda Legends."

PLEASE DO NOT REMOVE THAT!

I've worked hard on this, and I'd like a bit of 
recognition! If you want to remove it and place it 
someplace else, e-mail me at khuffie@zeldalegends.net

I've also included blank files for the top image
(called top-blank.gif), the logo (called logo-blank.jpg)
and I've included a PSD file for the sidebar text in 
case you need to add anything.

I'll do my best to keep this as up to date as possible.
If you find any bugs, don't hesititate to contact me!

Khuffie
http://www.zeldalegends.net
http://www.khuffie.com