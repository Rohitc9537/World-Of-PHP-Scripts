<SCRIPT language="JavaScript">
<!--
function n_window(theurl)
{
 // set the width and height
 var the_width=400;
 var the_height=200;
 // set window position
 var from_top=20;
 var from_left=20;
 // set other attributes
 var has_toolbar='no';
 var has_location='no';
 var has_directories='no';
 var has_status='no';
 var has_menubar='no';
 var has_scrollbars='yes';
 var is_resizable='yes';
 // attributes put together
 var the_atts='width='+the_width+',height='+the_height+',top='+from_top+',screenY='+from_top+',left='+from_left+',screenX='+from_left;
 the_atts+=',toolbar='+has_toolbar+',location='+has_location+',directories='+has_directories+',status='+has_status;
 the_atts+=',menubar='+has_menubar+',scrollbars='+has_scrollbars+',resizable='+is_resizable;
 // open window
 window.open(theurl,'',the_atts);
}
//-->

</SCRIPT>

<script language="JavaScript"><!--
function submit1() {
    document.passwordform.email.value;
    return false;
}

//--></script>

<script language="JavaScript"><!--
function myopen(filename,windowname,properties) {
    mywindow = window.open(filename,windowname,properties);
}
//--></script>

<script language="Javascript">
function disableSubmit(menu)
{
if (menu.options[menu.selectedIndex].id == "disable")
{
menu.form.submit.disabled = true;
}
if (menu.options[menu.selectedIndex].id == "enable")
{
menu.form.submit.disabled = false;
}
}
</script>