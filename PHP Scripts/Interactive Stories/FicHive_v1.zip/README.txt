INSTALLATION
[1] Upload, maintaining the directory structure.
[2] CHMOD 0777 "config.inc.php", "avatars/upload", "skins" and ALL the folders and tmpl.php files within "skins", "language" and ALL the folders and lang.php and mail.php files within "language"
[3] Create your database if you haven't already done so. The script will automatically create and populate the tables, but it CANNOT create the database.
[4] Run the install.php in your browser and follow the instructions
[5] Delete install.php once you have finished with it.

UPGRADE
This will upgrade you from 0.9 to 1.0
[1] Upload upgrade0910.php into the same directory as your config.inc.php file. Run from browser and follow on screen instructions.
[2] Delete upgrade0910.php once you have finished with it.
[3] Set the Auto mailer address in the general settings area of the Admin panel.
[4] Set the News time format in the general settings area of the Admin panel.

TERMS OF USE
There's usually a lot of legalese here but what it would probably boil down to is:

[1] This is free, not GNU. The "Powered By" notice must remain visible. Make changes to the code if that floats your boat, but the notice stays ;)

[2] No guarantees, no liability - install this at your own risk. It's not designed for a superheavy load of traffic, your CPU rate may spike with heavy use. Updates with patches will be available as and when. The creator is also not liable for the use this script is put to.

SUPPORT
None guaranteed, but there is a forum at http://www.alter-idem.com/forum/ where you can post with any issues.


Peace