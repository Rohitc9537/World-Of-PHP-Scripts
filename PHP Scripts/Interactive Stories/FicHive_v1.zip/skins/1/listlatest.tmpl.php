<b><%TITLE%></b><br>
<%DESCRIPTION%><br>
<span class='small'><%WIP%> <%AUTHOR%> &bull; <%CATEGORY%> &bull; <%RATING%> &bull; <%CHAPTERS%> &bull; <%WORDS%> &bull; <%REVIEWS%> &bull; <%HITS%> &bull; <%UPLOADED%> &bull; <%UPDATED%></span>