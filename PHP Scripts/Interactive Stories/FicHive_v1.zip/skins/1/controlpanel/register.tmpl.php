<table border='0' width='100%'>
<tr><td colspan='2' class='chapter'><%TAC%></td></tr>
<tr><td class='fframe'><%USERNAME%></td><td><input type='text' name='u_name'></td></tr>
<tr><td class='fframe'><%EMAIL%></td><td><input type='text' name='u_email'></td></tr>
<tr><td class='fframe'><input type='checkbox' name='agree' value='1'></td><td><%AGREES%></td></tr>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>