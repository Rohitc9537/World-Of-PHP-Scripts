<table border='0' width='100%'><tr>
<td class='fframe' valign='top'><%NAVIGATION%></td>
<td class='frame' valign='top'><%CONTENT%></td>
</tr></table>