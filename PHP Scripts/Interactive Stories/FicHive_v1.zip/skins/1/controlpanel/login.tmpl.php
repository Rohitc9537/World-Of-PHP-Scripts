<table border='0' width='100%'>
<tr><td class='fframe'><%EMAIL%></td><td><input type='text' name='u_email'></td></tr>
<tr><td class='fframe'><%PASSWORD%></td><td><input type='password' name='u_pass'></td></tr>
<tr><td class='fframe'><%FORGOTTEN%></td><td><input type='checkbox' name='forgotten' value='1' style='width:15px'> <%FORGOTTENB%></td></tr>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>
<%REGISTER%>