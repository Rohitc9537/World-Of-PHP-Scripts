<table border='0' width='100%'>
<%FAVORITES%>
<tr><td colspan='4'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
</table>