<table border='0' width='100%'>
<tr><td class='frame'><select name='sid' size='17'><%STORYLIST%></select></td></tr>
<tr><td class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>