<table border='0' width='100%'>
<tr><td class='fframe'><%REVIEWNO%></td><td><input type='text' name='rid'></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
</table>