<table border='0' width='100%'>
<%FAVORITES%>
<tr><td colspan='2'><input type='submit' value='<%REMOVE%>' onClick='return confirm("<%AREYOUSURE%>")'></td></tr>
</table>