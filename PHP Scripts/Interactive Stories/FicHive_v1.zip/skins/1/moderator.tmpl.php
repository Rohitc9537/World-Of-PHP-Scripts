<table border='0' width='100%'>
<tr><td class='fframe'><%DELETESTORY%></td><td>
<select name='moddel'><option value=''><%CHOOSESTORY%><%DELETESTORY_VAL%></select></td></tr>
<tr><td class='fframe' rowspan='2'><%MOVESTORY%></td>
<td><select name='modmove'><option value=''><%CHOOSESTORY%><%MOVESTORY_VAL%></select></td></tr>
<tr><td><select name='ncid'><%CATEGORIES%></select></td></tr>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
<tr><td>
</table>
<%APPROVE%>