<%RESULT%>
<p>
<table border='0' width='100%'>
<tr><td class='fframe'><%FOR%></td><td><input type='text' name='for'></td></tr>
<tr><td class='fframe'><%BOOLEAN%></td><td><select name='st'>
<option value=1><%STITLE%><option value=2><%SSUMM%><option value=3><%SFULL%></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>
<p>
<center><%QUICKNAV%>: <%RANGE%></center>
<p>
<a name='boolean'></a>
<span id='small'><%BOOEXP%></span>
