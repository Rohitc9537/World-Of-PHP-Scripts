<table border='0' width='100%'>
<%LANGFILES%>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>