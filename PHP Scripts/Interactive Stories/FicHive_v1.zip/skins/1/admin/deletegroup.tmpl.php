<table border='0' width='100%'>
<tr><td class='fframe'><%DELETEGROUP%></td><td><select name='gida'><%GROUPLIST%></select></td></tr>
<tr><td class='fframe'><%CHANGETO%></td><td><select name='gidb'><%GROUPLIST%></select></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
</table>