<table border='0' width='100%'>
<tr><td class='fframe' colspan='2'><%DATABASE%></td></tr>
<tr><td class='fframe'><%DBSERVER%></td><td><input type='text' name='db[dbserver]' value='<%DBSERVER_VAL%>'></td></tr>
<tr><td class='fframe'><%DBNAME%></td><td><input type='text' name='db[dbname]' value='<%DBNAME_VAL%>'></td></tr>
<tr><td class='fframe'><%DBUSER%></td><td><input type='text' name='db[dbuser]' value='<%DBUSER_VAL%>'></td></tr>
<tr><td class='fframe'><%DBPASS%></td><td><input type='text' name='db[dbpass]' value='<%DBPASS_VAL%>'></td></tr>
<tr><td class='fframe'><%DBPRE%></td><td><input type='text' name='db[dbpre]' value='<%DBPRE_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%SITE%></td></tr>
<tr><td class='fframe'><%TITLE%></td><td><input type='text' name='con[title]' value='<%TITLE_VAL%>'></td></tr>
<tr><td class='fframe'><%PATH%></td><td><input type='text' name='con[path]' value='<%PATH_VAL%>'></td></tr>
<tr><td class='fframe'><%URL%></td><td><input type='text' name='con[url]' value='<%URL_VAL%>'></td></tr>
<tr><td class='fframe'><%BOTEMAIL%></td><td><input type='text' name='con[email_bot]' value='<%BOTEMAIL_VAL%>'></td></tr>
<tr><td class='fframe'><%STATUS%></td><td><select name='con[open]'><%STATUS_VAL%></select></td></tr>
<tr><td class='fframe' colspan='2'><%GENERAL%></td></tr>
<tr><td class='fframe'><%TIME%></td><td><input type='text' name='con[time]' value='<%TIME_VAL%>'></td></tr>
<tr><td class='fframe'><%TIMEFORMAT%></td><td><input type='text' name='con[time_format]' value='<%TIMEFORMAT_VAL%>'></td></tr>
<tr><td class='fframe'><%TIMEFORMATNEWS%></td><td><input type='text' name='con[time_format_news]' value='<%TIMEFORMATNEWS_VAL%>'></td></tr>
<tr><td class='fframe'><%ALLOWEDHTML%></td><td><input type='text' name='con[allowed_html]' value='<%ALLOWEDHTML_VAL%>'></td></tr>
<tr><td class='fframe'><%PASSWORDSALT%></td><td><input type='text' name='con[salt]' value='<%PASSWORDSALT_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%USERS%></td></tr>
<tr><td class='fframe'><%MAGE%></td><td><input type='text' name='con[mage]' value='<%MAGE_VAL%>'></td></tr>
<tr><td class='fframe'><%USERNAMELIMIT%></td><td><input type='text' name='con[penname_length]' value='<%USERNAMELIMIT_VAL%>'></td></tr>
<tr><td class='fframe'><%USERPASSLIMIT%></td><td><input type='text' name='con[password_length]' value='<%USERPASSLIMIT_VAL%>'></td></tr>
<tr><td class='fframe'><%USERAVAWIDTH%></td><td><input type='text' name='con[avatar_width]' value='<%USERAVAWIDTH_VAL%>'></td></tr>
<tr><td class='fframe'><%USERAVAHEIGHT%></td><td><input type='text' name='con[avatar_height]' value='<%USERAVAHEIGHT_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%FICTION%></td></tr>
<tr><td class='fframe'><%FICWORDS%></td><td><input type='text' name='con[fiction_words]' value='<%FICWORDS_VAL%>'></td></tr>
<tr><td class='fframe'><%FICUPLOAD%></td><td><select name='con[fiction_upload]'><%FICUPLOAD_VAL%></select></td></tr>
<tr><td class='fframe'><%FICTYPES%></td><td><input type='text' name='con[fiction_types]' value='<%FICTYPES_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%DEFAULTS%></td></tr>
<tr><td class='fframe'><%DEFAULTSKIN%></td><td><select name='con[default_skin]'><%DEFAULTSKIN_VAL%></select></td></tr>
<tr><td class='fframe'><%DEFAULTLANG%></td><td><select name='con[default_lang]'><%DEFAULTLANG_VAL%></select></td></tr>
<tr><td class='fframe'><%DEFAULTGROUP%></td><td><select name='con[default_group]'><%DEFAULTGROUP_VAL%></select></td></tr>
<tr><td class='fframe' colspan='2'><%COOKIES%></td></tr>
<tr><td class='fframe'><%COOKIEPRE%></td><td><input type='text' name='con[cookie]' value='<%COOKIEPRE_VAL%>'></td></tr>
<tr><td class='fframe'><%COOKIEPATH%></td><td><input type='text' name='con[cookie_path]' value='<%COOKIEPATH_VAL%>'></td></tr>
<tr><td class='fframe'><%COOKIEDOMAIN%></td><td><input type='text' name='con[cookie_domain]' value='<%COOKIEDOMAIN_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%SEPARATORS%></td></tr>
<tr><td class='fframe'><%SEPTITLE%></td><td><input type='text' name='con[sep_title]' value='<%SEPTITLE_VAL%>'></td></tr>
<tr><td class='fframe'><%SEPCRUMB%></td><td><input type='text' name='con[sep_crumb]' value='<%SEPCRUMB_VAL%>'></td></tr>
<tr><td class='fframe'><%SEPNAV%></td><td><input type='text' name='con[sep_navig]' value='<%SEPNAV_VAL%>'></td></tr>
<tr><td class='fframe'><%SEPMISC%></td><td><input type='text' name='con[sep_misc]' value='<%SEPMISC_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%LAYOUT%></td></tr>
<tr><td class='fframe'><%LAYCOLUMNS%></td><td><input type='text' name='con[cols]' value='<%LAYCOLUMNS_VAL%>'></td></tr>
<tr><td class='fframe'><%LAYPPAGE%></td><td><input type='text' name='con[ppage]' value='<%LAYPPAGE_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%LATEST%></td></tr>
<tr><td class='fframe'><%LATESTLIMIT%></td><td><input type='text' name='con[latest_limit]' value='<%LATESTLIMIT_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%SEARCH%></td></tr>
<tr><td class='fframe'><%SEARCHLIMIT%></td><td><input type='text' name='con[search_limit]' value='<%SEARCHLIMIT_VAL%>'></td></tr>
<tr><td class='fframe'><%SEARCHWAIT%></td><td><input type='text' name='con[search_time]' value='<%SEARCHWAIT_VAL%>'></td></tr>
<tr><td class='fframe' colspan='2'><%MAILER%></td></tr>
<tr><td class='fframe'><%UPDATEALERT%></td><td><select name='con[mailer_updatealert]'><%UPDATEALERT_VAL%></select></td></tr>
<tr><td class='fframe'><%REVIEWALERT%></td><td><select name='con[mailer_reviewalert]'><%REVIEWALERT_VAL%></select></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>