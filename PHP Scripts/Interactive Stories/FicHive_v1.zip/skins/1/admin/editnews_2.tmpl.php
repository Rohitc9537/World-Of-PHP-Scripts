<table border='0' width='100%'>
<tr><td class='fframe'><%DATE%></td><td><input type='text' value='<%DATE_VAL%>' name='ndate'></td></tr>
<tr><td colspan='2' class='frame'><textarea name='nnews'><%NEWS_VAL%></textarea></td></tr>
<tr><td colspan='2' class='frame'><textarea name='ncomment'><%COMMENT_VAL%></textarea></td></tr>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>