<table border='0' width='100%'>
<tr><td class='fframe'><%DELETELANG%></td><td><select name='lgida'><%LANGLIST%></select></td></tr>
<tr><td class='fframe'><%CHANGETO%></td><td><select name='lgidb'><%LANGLIST%></select></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
</table>