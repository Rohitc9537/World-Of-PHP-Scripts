<select name='edit'><%NEWS%></select><br>
<input type='submit' value='<%GO%>'>