<table border='0' width='100%'>
<tr><td class='fframe'><%BASEON%></td><td><select name='skid'><%SKINLIST%></select></td></tr>
<tr><td class='fframe'><%SKINNAME%></td><td><input type='text' name='skname'></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>