<table border='0' width='100%'>
<tr><td class='fframe'><%BASEON%></td><td><select name='lgid'><%LANGLIST%></select></td></tr>
<tr><td class='fframe'><%LANGNAME%></td><td><input type='text' name='lgname'></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>