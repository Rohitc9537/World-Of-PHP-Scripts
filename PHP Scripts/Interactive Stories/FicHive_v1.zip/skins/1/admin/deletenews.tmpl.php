<select name='delete'><%NEWS%></select><br>
<input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'>