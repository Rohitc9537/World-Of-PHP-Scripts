<table border='0' width='100%'><tr>
<td class='fframe' valign='top'><%NAVIGATION%>
<p>
<iframe frameborder='0' style='width:100%; height:100' src='http://www.alter-idem.com/scripts/fichive/updates.html' scrolling='no'></iframe>
</td>
<td class='frame' valign='top'><%CONTENT%></td>
</tr></table>