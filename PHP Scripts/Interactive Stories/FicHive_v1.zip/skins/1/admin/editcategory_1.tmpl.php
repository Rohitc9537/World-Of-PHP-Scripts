<table border='0' width='100%'>
<tr><td class='frame'><select name='edit' size='17'><%SELECTCATEGORY%></select></td></tr>
<tr><td class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>