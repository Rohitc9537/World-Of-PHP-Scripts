<table border='0' width='100%'>
<tr><td class='fframe'><%ACCOUNTNO%></td><td><input type='text' name='edit'></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>