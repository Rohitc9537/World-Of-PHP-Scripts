<textarea name='nnews'></textarea>
<input type='submit' value='<%GO%>'>