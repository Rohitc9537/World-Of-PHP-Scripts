<table border='0' width='100%'>
<tr><td class='fframe'><%GROUPNAME%></td><td><input type='text' name='gname' value='<%GROUPNAME_VAL%>'></td></tr>
<tr><td class='fframe'><%GROUPCOLOR%></td><td><input type='text' name='gcolor' value='<%GROUPCOLOR_VAL%>'></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>'></td></tr>
</table>