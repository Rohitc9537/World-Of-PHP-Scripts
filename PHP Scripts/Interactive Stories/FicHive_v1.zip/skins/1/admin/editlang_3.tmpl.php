<table border='0' width='100%'>
<tr><td class='fframe'><%FILENAME%></td></tr>
<tr><td class='frame'><textarea name='lgcontent' style='height:300'><%LANGFILE%></textarea></td></tr>
<tr><td class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>