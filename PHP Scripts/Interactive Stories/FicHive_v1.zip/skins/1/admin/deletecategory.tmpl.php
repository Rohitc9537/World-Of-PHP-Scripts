<table border='0' width='100%'>
<tr><td class='fframe'><%DELETECATEGORY%></td><td><select name='cida'><%CATEGORYLIST%></td></tr>
<tr><td class='fframe'><%CHANGETO%></td><td><select name='cidb'><option value='0'><%TOPLEVEL%><%CATEGORYLIST%></td></tr>
<tr><td class='frame' colspan='2'><input type='submit' value='<%GO%>' onClick='javascript:return confirm("<%AREYOUSURE%>")'></td></tr>
</table>