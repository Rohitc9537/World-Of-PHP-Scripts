<table border='0' width='100%'>
<%ORDERCATEGORIES%>
<tr><td class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>
