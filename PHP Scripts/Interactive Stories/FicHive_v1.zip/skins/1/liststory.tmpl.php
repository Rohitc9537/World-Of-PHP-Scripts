<b><%TITLE%></b><br>
<%DESCRIPTION%><br>
<span class='small'><%WIP%> <%PRIMARYGENRE%>/<%SECONDARYGENRE%> &bull; <%AUTHOR%> &bull; <%RATING%> &bull; <%CHAPTERS%> &bull; <%WORDS%> &bull; <%REVIEWS%> &bull; <%HITS%> &bull; <%UPLOADED%> &bull; <%UPDATED%></span>