<tr><td valign='top'><input type='checkbox' name='fav[]' value='<%ID%>'></td>
<td><%TITLE%><br>
<%DESCRIPTION%><br>
<%AUTHOR%> &raquo; <%CATEGORY%></td></tr>