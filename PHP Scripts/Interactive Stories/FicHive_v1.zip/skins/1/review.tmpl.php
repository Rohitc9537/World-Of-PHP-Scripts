<table border='0' width='100%'>
<tr><td class='fframe'><%RNAMEA%></td><td><%RNAMEB%></td></tr>
<tr><td colspan='2' class='frame'><textarea name='rreview' class='large'></textarea></td></tr>
<tr><td colspan='2' class='frame'><input type='submit' value='<%GO%>'></td></tr>
</table>