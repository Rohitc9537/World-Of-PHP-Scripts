<table border='0' width='100%'>
<tr><td width='70%' class='frame'><%RNAME%></td><td class='fframe'><%RDATE%></td><td width='5%'><div align='right'># <%RID%></div></td></tr>
<tr><td colspan='3' class='frame'><%RCOMMENT%></td></tr>
</table>