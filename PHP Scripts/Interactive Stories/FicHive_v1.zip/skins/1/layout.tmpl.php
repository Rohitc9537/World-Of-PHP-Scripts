<html>
<head>
<title><%TITLE%></title>
<link rel='stylesheet' href='skins/1/style.css'>
</head>
<body>
<center>
<table border='0' width='100%'>
<tr><td class='navigation'>

	<table border='0' width='100%' cellpadding='0' cellspacing='0'>
	<tr><td width='70%'><b><%NAVIGATION%></b></td><td align='right' width='30%'><%QUICKNAV%></td></tr>
	</table>

</td></tr>
<tr><td class='fframe'><%CRUMBS%></td></tr>
<tr><td class='frame'><%CONTENT%></td></tr>
<tr><td class='fframe'><%POWEREDBY%></td></tr>
</table>
</body>
</html>