<table border='0' width='100%'>
<tr><td valign='top' class='fframe'><center><%AVATAR%></center></td>
<td class='chapter'><b><%AUTHORNAME%></b><br>
<%STARTED%>: <%STARTED_VAL%><br>
<%GROUP%>: <%GROUP_VAL%></td></tr>
<tr><td class='chapter' colspan='2'><%AUTHORBIOGRAPHY%></td></tr>
<tr><td class='chapter' colspan='2'><%WRITTEN%></td></tr>
<tr><td class='chapter' colspan='2'><%FAVORITES%></td></tr>
</table>