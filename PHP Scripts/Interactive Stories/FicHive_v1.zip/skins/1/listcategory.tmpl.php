<table border='0' width='100%'>
<tr><td><%IMG%></td><td width='100%' valign='top'><%NAME%><br><%DESCRIPTION%></td></tr>
</table>