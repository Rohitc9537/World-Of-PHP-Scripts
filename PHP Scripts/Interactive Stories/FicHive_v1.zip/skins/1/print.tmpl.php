<html>
<head><title><%TITLE%></title></head>
<body>
<center>
<table border='0' width='600' cellspacing='0'><tr><td>
<font size=2 face='verdana'>
<b><%TITLE%></b><br>
<%AUTHOR%>
<hr><%CHAPTER%><hr>
</td></tr></table>
</center>
</body>
</html>