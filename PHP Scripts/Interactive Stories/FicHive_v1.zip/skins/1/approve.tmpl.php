<a name='<%FICTITLE%>'></a>
<table border='0' width='100%'>
<tr><td colspan='2'><b><%FICTITLE%></b><td></tr>
<%CHAPTERS%>
<tr><td colspan='2'><input type='submit' name='approve' value='<%APPROVE%>' class='mid'>
<input type='submit' name='reject' value='<%REJECT%>' onClick='return confirm("<%AREYOUSURE%>")' class='mid'></td></tr>
</table>