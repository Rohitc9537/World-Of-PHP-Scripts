<?php
$lang['skinname'] = "Default";
?>