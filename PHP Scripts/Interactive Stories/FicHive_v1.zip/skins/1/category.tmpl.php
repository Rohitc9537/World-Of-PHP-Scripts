<center><%IMG%></center>
<%SUBCATS%>
<table border='0' width='100%'><tr>
<td width='50%'><%MODERATORS%></td>
<td width='50%'><div align='right'><%PAGES%></div></td>
</tr><tr>
<td colspan='2'><center><%SORTER%> <%GENRE%> <%CHARACTER%></div></td></tr></table>
<table border='0' width='100%'><tr><td class='frame'><%STORIES%></td></tr></table>
<%MODERATOROPTIONS%>