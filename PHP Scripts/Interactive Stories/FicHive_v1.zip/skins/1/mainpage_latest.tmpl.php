<b><%TITLE%></b><br>
<span class='small'><%AUTHOR%> &bull; <%RATING%> &bull; <%CATEGORY%></span><br>
<%DESCRIPTION%>