<table border='0' width='100%'>
<tr>
<td width='80%' valign='top'><%CATEGORIES%></td>
<td width='20%' valign='top' rowspan='2'>
	<table border='0' width='100%'>
	<tr><td class='fframe'><%LATEST%></td></tr>
	<tr><td class='frame'><%LATESTFICS%></td></tr>
	<tr><td class='fframe'><%STATISTICS%></td></tr>
	<tr><td class='frame'><%STATS%></td></tr>
	</table>
</td>
</tr>
<tr><td valign='bottom'><table border='0' width='100%'><tr><td class='frame'><%WELCOME%></td></tr></table></td></tr>
<tr><td colspan='2'><%NEWS%></td></tr>
</table>