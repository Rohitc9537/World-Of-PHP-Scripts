<table border='0' width='100%'>
<tr><td class='navigation'><%DATE%> (<%POSTER%>)</td></tr>
<tr><td colspan='2' class='frame'><%NEWS%></td></tr>
<tr><td colspan='2' class='fframe'><%COMMENTS%></td></tr>
</table>