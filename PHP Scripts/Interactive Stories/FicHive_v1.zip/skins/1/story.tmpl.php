<table border='0' width='100%'>
<tr><td class='fframe'>
<table width='100%'><tr><td><b><%TITLE%></b><br><%AUTHOR%> &bull; <%RATING%> &bull; <%PUBLISHED%> &bull; <%REVIEWS%></td>
<td><%REVIEW%> <%ADD2FAV%> <%PRINTOUT%> <%BOOKMARK%></td>
<td><div align='right'><%CHNAV%></div></td></tr></table></td></tr>
<tr><td class='chapter'><%CHAPTER%></td></tr>
<tr><td class='fframe'><div align='right'><%CHNAV%></div></td></tr>
</table>