Hi <%NAME%>,

Your password has been set to <%PASSWORD%>. You can alter it as usual within your profile area.

<%FROM%>