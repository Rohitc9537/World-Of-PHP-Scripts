Hi <%NAME%>,
<p>
Thank you for registering at <%TITLE%>! Your log in details are:
<p>
Email: <%EMAIL%><br>
Password: <%PASSWORD%>
<p>
<%FROM%>