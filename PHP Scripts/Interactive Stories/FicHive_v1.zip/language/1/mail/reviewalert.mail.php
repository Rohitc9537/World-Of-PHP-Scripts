Hi <%NAME%>,
<p>
You have recieved a review for your story <%TITLE%> at <%URL%>
<p>
<%FROM%>