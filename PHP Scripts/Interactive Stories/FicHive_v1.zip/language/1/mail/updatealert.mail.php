Hi <%NAME%>,
<p>
<%AUTHOR%> has updated their story <%TITLE%> at <%URL%>. 
<p>
If the category requires story approval, the update may not yet be accessible.
<p>
<%FROM%>