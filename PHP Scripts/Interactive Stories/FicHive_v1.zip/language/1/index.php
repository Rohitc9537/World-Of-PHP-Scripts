<?php
$lang['langname'] = "English";
?>