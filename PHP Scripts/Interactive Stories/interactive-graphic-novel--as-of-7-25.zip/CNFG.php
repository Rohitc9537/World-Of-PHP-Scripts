<?php 
$host = 'localhost'; 
$user = 'Tsukasa'; 
$pass = ''; 
$database_name = 'Stories'; 
?>