function unstage() {
var txtarea = document.builder.STORY;
txtarea.value = txtarea.value + "[UNSTAGE]";
txtarea.focus();
}