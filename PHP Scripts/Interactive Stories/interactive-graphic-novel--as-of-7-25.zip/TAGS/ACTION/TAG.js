function actions() {
var txtarea = document.builder.STORY;
txtarea.value = txtarea.value + "[ACTION]";
txtarea.focus();
}