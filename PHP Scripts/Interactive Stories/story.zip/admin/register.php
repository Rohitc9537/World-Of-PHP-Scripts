<html>
<form method="post" action="reguser.php">
Type Username Here: <input type="text" name="username" size="15"><br>
Type Password Here: <input type="text" name="password" size="15"><br>
Retype password: <input type="text" name="pass2" size="15"><br>
<input type="submit" value="submit">


</form>
</html>
