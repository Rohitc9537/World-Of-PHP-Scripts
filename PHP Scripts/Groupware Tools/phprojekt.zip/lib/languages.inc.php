<?php

// $Id: languages.inc.php,v 1.3 2005/03/17 15:59:40 fgraf Exp $

$languages = array(
                    'al' => 'Albanian',
                    'br' => 'Brazilian',
                    'bg' => 'Bulgarian',
                    'ct' => 'Catalan',
                    'zh' => 'China,P.R.C.(GB)',
                    'cz' => 'Czech',
                    'da' => 'Danish',
                    'nl' => 'Dutch',
                    'ee' => 'Estonian',
                    'en' => 'English',
                    'es' => 'Espanol (Castellano)',
                    'sp' => 'Espanol (latin)',
                    'eh' => 'Euskadi',
                    'fi' => 'Finnish',
                    'fr' => 'French',
                    'ge' => 'Georgian',
                    'de' => 'German',
                    'gr' => 'Greek',
                    'he' => 'Hebrew',
                    'hu' => 'Hungarian',
                    'it' => 'Italiano',
                    'is' => 'Icelandic',
                    'jp' => 'Japanese',
                    'ko' => 'Korean',
                    'lt' => 'Lithuanian',
                    'lv' => 'Latvian',
                    'no' => 'Norwegian',
                    'pt' => 'Portugues',
                    'pl' => 'Polish',
                    'ro' => 'Romanian',
                    'ru' => 'Russian',
                    'si' => 'Slovenian',
                    'sk' => 'Slovak',
                    'se' => 'Svenska',
                    'tr' => 'Turkish',
                    'tw' => 'Taiwan,R.O.C.(TW)'
                );

?>
