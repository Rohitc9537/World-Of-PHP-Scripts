<?php

header("Content-type: text/css");

?>
/**
 * PHProjekt CSS-File
 *
 * $Id: merkur_css_ie.php,v 1.4 2005/07/20 12:14:27 paolo Exp $
 *
 */

.navbutton,
a.navbutton,
a.navbutton:hover,
a.navbutton:visited {
    position: relative;
    top: 1px;
    left: 3px;
    padding-top: 1px;
    padding-left: 10px;
    padding-right :10px;
    border-width: 2px;
    color: #ffffff;
    font-size: 1em;
    font-weight:bold;
    border-style:solid;
    cursor: pointer;
    width: auto;
    text-decoration: none;
}
div.navImage {
    display:inline;
}
.navi li{
    height:1.8em;
}
