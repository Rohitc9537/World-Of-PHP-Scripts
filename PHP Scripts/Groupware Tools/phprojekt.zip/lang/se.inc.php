<?php
// se.inc.php, Swedish version, rev.25 june. 2005 /Tib
// translation by Sven-Erik Tiberg <set@dc.luth.se> and Andrzej Szyszkiewicz <Andrzej.Szyszkiewicz@data.slu.se> 18 dec. 2000

$chars = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","�","�","�");
$name_month = array("", "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec");
$l_text31a = array("standard", "15 min.", "30 min.", " 1 timme", " 2 timmar", " 4 timmar", " 1 dag");
$l_text31b = array(0, 15, 30, 60, 120, 240, 1440);
$name_day = array("S�ndag", "M�ndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "L�rdag");
$name_day2 = array("M�", "Ti", "On", "To", "Fr", "L�", "S�");

$_lang['No Entries Found']= "Inga svar har hittats";
$_lang['No Todays Events']= "Ingen h�ndelse idag";
$_lang['No new forum postings']= "Inga nya inl�gg i forumet";
$_lang['in category']= "i kategorier";
$_lang['Filtered']= "Filtererad";
$_lang['Sorted by']= "Sorterad efter";
$_lang['go'] = "utf�r";
$_lang['back'] = "�ter";
$_lang['print'] = "Skriv ut";
$_lang['export'] = "exportera";
$_lang['| (help)'] = "| (hj�lp/anvisningar)";
$_lang['Are you sure?'] = "�r du s�ker?";
$_lang['items/page'] = "punkter per sida";
$_lang['records'] = "poster"; // elements
$_lang['previous page'] = "f�reg�ende sida";
$_lang['next page'] = "n�sta sida";
$_lang['first page'] = "f�rsta sidan";
$_lang['last page'] = "sista sidan";
$_lang['Move']  = "Flytta";
$_lang['Copy'] = "Kopiera";
$_lang['Delete'] = "Ta bort";
$_lang['delete'] = "delete";
$_lang['Save'] = "spara";
$_lang['Directory'] = "mapp";
$_lang['Also Delete Contents'] = "ta bort inneh�llet";
$_lang['Sum'] = "Summa";
$_lang['Filter'] = "Filtrera";
$_lang['Please fill in the following field'] = "Fyll i f�ljande f�lt";
$_lang['approve'] = "bekr�fta";
$_lang['undo'] = "�terkalla";
$_lang['Please select!']="V�lj!";
$_lang['New'] = "Ny";
$_lang['Select all'] = "markera alla";
$_lang['Printable view'] = "Skrivarv�nligt format";
$_lang['New record in module '] = "Ny post i modul ";
$_lang['Notify all group members'] = "Meddela alla gruppmedlemmar";
$_lang['Yes'] = "Ja";
$_lang['No'] = "Nej";
$_lang['Close window'] = "St�ng f�nster";
$_lang['No Value'] = "Inget v�rde";
$_lang['Standard'] = "Standard";
$_lang['Create'] = "Skapa";
$_lang['Modify'] = "�ndra";   
$_lang['today'] = "Idag";

// admin.php
$_lang['Password'] = "L�senord";
$_lang['Login'] = "Logga in";
$_lang['Administration section'] = "Administrativa delar";
$_lang['Your password'] = "Ditt l�senord f�r dessa funktioner";
$_lang['Sorry you are not allowed to enter. '] = " Du har tyv�rr inte r�ttighet att logga in";
$_lang['Help'] = "Hj�lp";
$_lang['User management'] = "Anv�ndar hantering";
$_lang['Create'] = "ny";
$_lang['Projects'] = "Projekt hantering";
$_lang['Resources'] = "Resurs hantering";
$_lang['Resources management'] = "Resources management";
$_lang['Bookmarks'] = "Bokm�rke hantering";
$_lang['for invalid links'] = "efter tappade l�nkar";
$_lang['Check'] = "Kontrollera";
$_lang['delete Bookmark'] = "ta bort bokm�rken";
$_lang['(multiple select with the Ctrl-key)'] = "( m�jlighet till flera val med 'Ctrl'-tangenten)";
$_lang['Forum'] = "Forum";
$_lang['forum'] = "Forum";
$_lang['Threads older than'] = "�renden �ldre �n";
$_lang[' days '] = " dagar ";
$_lang['Chat'] = "E-samtal";
$_lang['save script of current Chat'] = "Spara inl�gg av aktuellt e-samtal";
$_lang['Chat script'] = "inl�gg i e-samtal";
$_lang['New password'] = "Nytt l�senord";
$_lang['(keep old password: leave empty)'] = "(l�mna tomt f�r att beh�lla nuvarande l�senord)";
$_lang['Default Group<br> (must be selected below as well)'] = "Standard Grupp<br> (m�ste v�ljas  nedan ocks�)";
$_lang['Access rights'] = "Anv�ndar r�ttigheter";
$_lang['Zip code'] = "Postnummer";
$_lang['Language'] = "Spr�k";
$_lang['schedule readable to others'] = "punkter i kalendern som �r publika";
$_lang['schedule invisible to others'] = "punkter i kalendern som �r privata";
$_lang['schedule visible but not readable'] = "kalendern �r synlig f�r andra men kan inte l�sas";
$_lang['these fields have to be filled in.'] = "dessa f�lt m�ste fyllas i.";
$_lang['You have to fill in the following fields: family name, short name and password.'] = "du m�ste fylla i f�lten: efternamn, signatur och l�senord";
$_lang['This family name already exists! '] = "Detta efternamn �r upptaget!, l�gg till ett andra efternamn eller en bokstav/siffra ";
$_lang['This short name already exists!'] = "Denna signatur �r upptagen!";
$_lang['This login name already exists! Please chosse another one.'] = "Detta inloggningsnamn finns redan! V�nligen v�lj ett annat.";
$_lang['This password already exists!'] = "Detta l�senord �r upptaget!";
$_lang['This combination first name/family name already exists.'] = "Denna kombination av f�r och efternamn finns redan.";
$_lang['the user is now in the list.'] = "anv�ndaren �r registrerad i systemet.";
$_lang['the data set is now modified.'] = "informationen f�r anv�ndaren";
$_lang['Please choose a user'] = "V�lj en anv�ndare";
$_lang['is still listed in some projects. Please remove it.'] = " ing�r i n�gra projekt, var sn�ll och ta bort anv�ndaren fr�n projekt-listan";
$_lang['All profiles are deleted'] = "Alla profiler �r raderade";
$_lang['A Profile with the same name already exists'] = "Det finns redan en profil med samma namn";
$_lang['is taken out of all user profiles'] = "�r bortagna ur alla profiler";
$_lang['All todo lists of the user are deleted'] = "Anv�ndarens \"att g�ra\" listor �r raderade";
$_lang['is taken out of these votes where he/she has not yet participated'] = "�r bortagan fr�n detta val, d� han/hon �nnu inte anm�lt sig som deltagare";
$_lang['All events are deleted'] = "Alla aktiviter �r borttagna";
$_lang['user file deleted'] = "anv�ndarens data �r borttagna";
$_lang['bank account deleted'] = "bankkontot �r borttaget";
$_lang['finished'] = "klart";
$_lang['Please choose a project'] = "V�lj ett projekt";
$_lang['The project is deleted'] = "Projektet �r avslutat och borttaget";
$_lang['All links in events to this project are deleted'] = "All l�nkar till aktiviteter i detta projekt �r borttagna";
$_lang['The duration of the project is incorrect.'] = "Projekts varatighet �r inte korrekt.";
$_lang['The project is now in the list'] = "Projekt �r inf�rt i projektlistan";
$_lang['The project has been modified'] = "Projektet har modifierats";
$_lang['Please choose a resource'] = "V�lj ut en resurs";
$_lang['The resource is deleted'] = "Resursen �r borttagen";
$_lang['All links in events to this resource are deleted'] = "Alla l�nkar som var kopplade till h�ndelser i detta projekt �r borttagna";
$_lang[' The resource is now in the list.'] = " Resursen finns nu i resurslistan.";
$_lang[' The resource has been modified.'] = " Resursen �r modifierad.";
$_lang['The server sent an error message.'] = "Servern har skickat f�ljande felmeddelande";
$_lang['All Links are valid.'] = "All l�nkar �r aktiva.";
$_lang['Please select at least one bookmark'] = "Var v�nlig och v�lj minst ett bokm�rke";
$_lang['The bookmark is deleted'] = "Bokm�rket �r borttaget";
$_lang['threads older than x days are deleted.'] = "Alla bidrag som �r �ldre �n x har tagits bort.";
$_lang['All chat scripts are removed'] = "Alla e-samtal �r borttagna";
$_lang['or'] = "eller";
$_lang['Timecard management'] = "Tidkorts hantering";
$_lang['View'] = "Visa";
$_lang['Choose group'] = "V�lj grupp";
$_lang['Group name'] = "Gruppnamn";
$_lang['Short form'] = "Signatur ";
$_lang['Category'] = "Kategori";
$_lang['Remark'] = "Kommentar";
$_lang['Group management'] = "Grupphantering";
$_lang['Please insert a name'] = "Ange ett namn";
$_lang['Name or short form already exists'] = "Namn eller signatur finns redan";
$_lang['Automatic assign to group:'] = "Automatiskt tilldelning till gruppen:";
$_lang['Automatic assign to user:'] = "Automatiskt tilldelning till anv�ndare:";
$_lang['Help Desk Category Management'] = "�rende system (RTS) kategori hantering";
$_lang['Category deleted'] = "Kategori borttagen";
$_lang['The category has been created'] = "Kategorin har skapats";
$_lang['The category has been modified'] = "Kategorin har modifierats";
$_lang['Member of following groups'] = "Medlem av f�ljande grupper";
$_lang['Primary group is not in group list'] = "Standard gruppen finns inte i grupplistan";
$_lang['Login name'] = "Inloggningsnamn";
$_lang['You cannot delete the default group'] = "Du kan inte ta bort standardgruppen";
$_lang['Delete group and merge contents with group'] = "Ta bort en grupp och sl� samman inneh�llet till gruppen";
$_lang['Please choose an element'] = "V�lj ett element";
$_lang['Group created'] = "Gruppen �r skapad";
$_lang['File management'] = "Fil hantering";
$_lang['Orphan files'] = "Filer som har raderad �gare";
$_lang['Deletion of super admin root not possible'] = "Du kan inte ta bort ( super admin root )";
$_lang['ldap name'] = "ldap namn";
$_lang['mobile // mobile phone'] = "mobil nummer"; // mobil phone
$_lang['Normal user'] = "Normal anv�ndare";
$_lang['User w/Chief Rights'] = "Anv�ndare med chefs r�ttigheter";
$_lang['Administrator'] = "Administrat�r";
$_lang['Logging'] = "Logga";
$_lang['Logout'] = "Logga ut";
$_lang['posting (and all comments) with an ID'] = "posta (inkl. alla kommentarer) med ett ID";
$_lang['Role deleted, assignment to users for this role removed'] = "Roll borttagen, anv�ndare med denna roll har modifierats";
$_lang['The role has been created'] = "Roll skapad";
$_lang['The role has been modified'] = "Rollen har modifierats";
$_lang['Access rights'] = "Anv�ndar r�ttigheter";
$_lang['Usergroup'] = "Anv�ndargrupp";
$_lang['logged in as'] = "Inloggad som";

//chat.php
$_lang['Quit chat']= "L�mna chat";

//contacts.php
$_lang['Contact Manager'] = "Kontakt hanterare";
$_lang['New contact'] = "Ny kontakt";
$_lang['Group members'] = "Gruppmedlemmar";
$_lang['External contacts'] = "Externa kontakter";
$_lang['&nbsp;New&nbsp;'] = "&nbsp;Ny&nbsp;";
$_lang['Import'] = "Import";
$_lang['The new contact has been added'] = "Den nya kontakten har lagts till";
$_lang['The date of the contact was modified'] = "Kontakten har �ndrats";
$_lang['The contact has been deleted'] = "Kontakten har tagits bort";
$_lang['Open to all'] = "�ppen f�r alla";
$_lang['Picture'] = "Bild";
$_lang['Please select a vcard (*.vcf)'] = "V�lj ett e-visitkort / vcard (*.vcf)";
$_lang['create vcard'] = "Skapa ett e-visitkort / vcard";
$_lang['import address book'] = "importera adressboken";
$_lang['Please select a file (*.csv)'] = "V�lj en fil (*.csv)";
$_lang['Howto: Open your outlook express address book and select file/export/other book<br>Then give the file a name, select all fields in the next dialog and finish'] = 
"Hur g�r man: �ppna din outlook adressbok och v�lj 'file'/'export'/'other book'<br> V�lj 'text' som filtyp och markera alla f�lten i n�sta dialogruta och v�lj 'finish'";
$_lang['Open outlook at file/export/export in file,<br>choose comma separated values (Win), then select contacts in the next form,<br>give the export 
file a name and finish.'] = "�ppna i outlook 'file/export/export in file',<br> v�lj 'komma separated values (WIN)', v�lj sedan 'kontakter' i 
n�sta formruta,<br> ge exportfilen ett namn och slutf�r.";
$_lang['Please choose an export file (*.csv)'] = "V�lj en exportfil (*.csv)";
$_lang['Please export your address book into a comma separated value file (.csv), and either<br>1) apply an import pattern OR<br>2) modify the 
columns of the table with a spread sheet to this format<br>(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):'] = "V�nligen exportera din adressbok till en kommaseparerad fil (.csv), Och antingen<br> 
1) Anv�nd en importmall ELLER<br> 
2) modifiera filen i excel f�r att passa detta format<br> (Ta bort kolumner som inte finns h�r och l�gg till tomma kolumner f�r dom som saknas i din fil):";
$_lang['Please insert at least the family name'] = "Ange minst ett efternamnet";
$_lang['Record import failed because of wrong field count'] = "Importen av filen gick inte att g�ra d� det �r fel antal kolumner";
$_lang['Import to approve'] = "Importera f�r godk�nnande";
$_lang['Import list'] = "Importera listan";
$_lang['The list has been imported.'] = "Listan har importerats.";
$_lang['The list has been rejected.'] = "Listan har inte importerats p.g.a. fel i listan.";
$_lang['Profiles'] = "Profiler";
$_lang['Parent object'] = "F�r�ldra objekt";
$_lang['Check for duplicates during import'] = "Kontrollera dubbletter vid import";
$_lang['Fields to match'] = "F�lt att matcha";
$_lang['Action for duplicates'] = "H�ndelse vid dubbletter";
$_lang['Discard duplicates'] = "Avvisa dubblett";
$_lang['Dispose as child'] = "Ange som underobjekt";
$_lang['Store as profile'] = "Spara som profil";    
$_lang['Apply import pattern'] = "Applicera import specifikation";
$_lang['Import pattern'] = "Import specifikation";
$_lang['For modification or creation<br>upload an example csv file'] = "Ladda upp import fil (csv)";
$_lang['Skip field'] = "Hoppa �ver f�lt";
$_lang['Field separator'] = "F�lt separator";
$_lang['Contact selector'] = "Kontakt v�ljare";
$_lang['Use doublet'] = "Anv�nd dublett";
$_lang['Doublets'] = "Dubletter";

// filemanager.php
$_lang['Please select a file'] = "V�lj en fil";
$_lang['A file with this name already exists!'] = "En fil med detta namn finns redan!";
$_lang['Name'] = "Namn";
$_lang['Comment'] = "Kommentar";
$_lang['Date'] = "Datum";
$_lang['Upload'] = "Spara";
$_lang['Filename and path'] = "Filnamn och s�kv�g";
$_lang['Delete file'] = "Radera filen";
$_lang['Overwrite'] = "Skriv �ver";
$_lang['Access'] = "r�ttigheter";
$_lang['Me'] = "jag";
$_lang['Group'] = "grupp";
$_lang['Some'] = "n�gra";
$_lang['As parent object'] = "samma som bibliotek";
$_lang['All groups'] = "Alla grupper";
$_lang['You are not allowed to overwrite this file since somebody else uploaded it'] = "Du kan inte skriva ned denna fil just nu eftersom n�gon annan anv�nder den";
$_lang['personal'] = "personlig";
$_lang['Link'] = "L�nk";
$_lang['name and network path'] = "Ange n�tverks s�kv�g och filnamn";
$_lang['with new values'] = "med nya v�rden";
$_lang['All files in this directory will be removed! Continue?'] = "Alla filer i denna folder kommer att tas bort, vill du g�ra det?";
$_lang['This name already exists'] = "Namnet �r upptaget av en annan fil";
$_lang['Max. file size'] = "Max. fil storlek";
$_lang['links to'] = "l�nk till";
$_lang['objects'] = "objekt";
$_lang['Action in same directory not possible'] = "Du kan inte �ndra i samma folder";
$_lang['Upload = replace file'] = "Upload = ers�tt filen";
$_lang['Insert password for crypted file'] = "Ange l�senord f�r krypterad fil";
$_lang['Crypt upload file with password'] = "kryptera fil med l�senord";
$_lang['Repeat'] = "Repetera";
$_lang['Passwords dont match!'] = "l�senorden st�mmer inte �verens!";
$_lang['Download of the password protected file '] = "Ladda ned den l�senordskyddade filen ";
$_lang['notify all users with access'] = "meddela alla anv�ndare med r�ttigheter ";
$_lang['Write access'] = "Skriv r�ttighet";
$_lang['Version'] = "Version";
$_lang['Version management'] = "Versions hantering";
$_lang['lock'] = "l�s";
$_lang['unlock'] = "l�s upp";
$_lang['locked by'] = "l�st av";
$_lang['Alternative Download'] = "Alternativ Nedladdning";
$_lang['Download'] = "Ladda ned";
$_lang['Select type'] = "V�lj typ";
$_lang['Create directory'] = "Skapa mapp ";
$_lang['filesize (Byte)'] = "Fil storlek (Byte)";

// filter
$_lang['contains'] = 'Inneh�ller';
$_lang['exact'] = 'exakt';
$_lang['starts with'] = 'B�rjar med';
$_lang['ends with'] = 'slutar med';
$_lang['>'] = '>';
$_lang['>='] = '>=';
$_lang['<'] = '<';
$_lang['<='] = '<=';
$_lang['does not contain'] = 'inneh�ller inte'; 
$_lang['Please set (other) filters - too many hits!'] = "V�nligen ange ett mer exakt filer - f�r m�nga tr�ffar!";

$_lang['Edit filter'] = "�ndra filtret";
$_lang['Filter configuration'] = "Konfigurera filter ";
$_lang['Disable set filters'] = "Inaktivera set av filter";
$_lang['Load filter'] = "Ladda filter";
$_lang['Delete saved filter'] = "Ta bort sparat filter";
$_lang['Save currently set filters'] = "Spara aktuellt set av filter";
$_lang['Save as'] = "Spara som";
$_lang['News'] = 'Nyheter';

// form designer
$_lang['Module Designer'] = "Modul Designer";
$_lang['Module element'] = "Modul element";
$_lang['Module'] = "Modul";
$_lang['Active'] = "Aktiv";
$_lang['Inactive'] = "Inaktiv";
$_lang['Activate'] = "Aktivera";
$_lang['Deactivate'] = "Inaktivera";
$_lang['Create new element'] = "Skapa nytt element";
$_lang['Modify element'] = "Modifiera element";
$_lang['Field name in database'] = "F�ltnamn i databas";
$_lang['Use only normal characters and numbers, no special characters,spaces etc.'] = "Anv�nd endast normala tecken och siffror, inga specialtecken och mellanrum mm.";
$_lang['Field name in form'] = "F�ltnamn p� formul�r";
$_lang['(could be modified later)'] = "(kan modifieras senare)"; 
$_lang['Single Text line'] = "Enkelradig text";
$_lang['Textarea'] = "Textarea";
$_lang['Display'] = "Visa";
$_lang['First insert'] = "F�rsta f�lt";
$_lang['Predefined selection'] = "F�rdefinierat urval";
$_lang['Select by db query'] = "V�lj med databasfr�ga";
$_lang['File'] = "Fil";

$_lang['Email Address'] = "Epost adress";
$_lang['url'] = "url";
$_lang['Checkbox'] = "Kryssruta";
$_lang['Multiple select'] = "Multipelt val";
$_lang['Display value from db query'] = "Visa v�rde fr�n databas fr�ga";
$_lang['Time'] = "Tid";
$_lang['Tooltip'] = "Verktygstips";
$_lang['Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied'] = "Visas som ett tips n�r musen h�lls �ver f�ltet: Extra kommenterar till f�ltet eller f�rklaring om en formel anv�nds";
$_lang['Position'] = "Position";
$_lang['is current position, other free positions are:'] = "�r aktuell position, andra fria positioner �r:";
$_lang['Regular Expression:'] = "Regulj�rt uttryck:";
$_lang['Please enter a regular expression to check the input on this field'] = "V�nligen ange en formel f�r att testa detta f�lt";
$_lang['Default value'] = "Standard v�rde";
$_lang['Predefined value for creation of a record. Could be used in combination with a hidden field as well'] = "Standardv�rde f�r skapande av post. Kan ocks� anv�ndas i samband med ett dolt f�lt";
$_lang['Content for select Box'] = "Inneh�ll i urvalsbox";
$_lang['Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type'] = "Anv�nds f�r ett fixed antal v�rden (separerade med teknet: | ) eller f�r sql kommandot, se element typ";
$_lang['Position in list view'] = "Postition i list vy";
$_lang['Only insert a number > 0 if you want that this field appears in the list of this module'] = "Ange endast ett nummer > 0 om du vill att detta f�lt ska visas i listan f�r denna modul";
$_lang['Alternative list view'] = "Alternativ listvy";
$_lang['Value appears in the alt tag of the blue button (mouse over) in the list view'] = "V�rdet visas i alt taggen f�r den bl� knappen (mouse over) i listvyn";
$_lang['Filter element'] = "Filtrera element";
$_lang['Appears in the filter select box in the list view'] = "Visas i filter urvalsboxen i listvyn";
$_lang['Element Type'] = "Element Typ";
$_lang['Select the type of this form element'] = "V�lj typ f�r detta formul�r element";
$_lang['Check the content of the previous field!'] = "Kontrollera v�rdet i f�reg�ende f�lt!";
$_lang['Span element over'] = "Ut�ka f�lt �ver";
$_lang['columns'] = "kolumner";
$_lang['rows'] = "rader";
$_lang['Telephone'] = "Telefon";
$_lang['History'] = "Historia";
$_lang['Field'] = "F�lt";
$_lang['Old value'] = "Gammalt v�rde";
$_lang['New value'] = "Nytt v�rde";
$_lang['Author'] = "F�rfattare"; 
$_lang['Show Date'] = "Visa datum";
$_lang['Creation date'] = "Datum f�r skapande";
$_lang['Last modification date'] = "Senast modifierad";
$_lang['Email (at record cration)'] = "Epost (Vid postens skapande)";
$_lang['Contact (at record cration)'] = "kontakt (Vid postens skapande)";
$_lang['Select user'] = "V�lj anv�ndare";
$_lang['Show user'] = "Visa anv�ndare";

// forum.php
$_lang['Please give your thread a title'] = "Ge den nya tr�den en rubrik";
$_lang['New Thread'] = "Ny tr�d";
$_lang['Title'] = "Titel";
$_lang['Text'] = "Text";
$_lang['Post'] = "Post";
$_lang['From'] = "Fr�n";
$_lang['open'] = "�ppen";
$_lang['closed'] = "st�ngd";
$_lang['Notify me on comments'] = "Meddela mig om det kommer svar";
$_lang['Answer to your posting in the forum'] = "Svar p� ditt inl�gg i forumet";
$_lang['You got an answer to your posting'] = "Du har f�tt ett svar p� ditt inl�gg \n ";
$_lang['New posting'] = "Nya inl�gg";
$_lang['Create new forum'] = "Skapa ett nytt forum";
$_lang['down'] ='ner';
$_lang['up']= "upp";
$_lang['Forums']= "Forum";
$_lang['Topics']="�mne";
$_lang['Threads']="Tr�d";
$_lang['Latest Thread']="Senaste tr�den";
$_lang['Overview forums']= "�verblick av forumen";
$_lang['Succeeding answers']= "Efterf�ljande svar";
$_lang['Count']= "R�kna";
$_lang['from']= "fr�n";
$_lang['Path']= "Path";
$_lang['Thread title']= "Titel f�r tr�den";
$_lang['Notification']= "Meddela";
$_lang['Delete forum']= "Ta bort forum";
$_lang['Delete posting']= "Ta bort inl�gg";
$_lang['In this table you can find all forums listed']= "Alla forum finns listade i denna tabell";
$_lang['In this table you can find all threads listed']= "Alla tr�dar finns listade i denna tabell";

// index.php
$_lang['Last name'] = "Efternamn";
$_lang['Short name'] = "Signatur";
$_lang['Sorry you are not allowed to enter.'] = "Du har inte till�telse att �ppna detta.";
$_lang['Please run index.php: '] = "K�r index.php: ";
$_lang['Reminder'] = "P�minnare";
$_lang['Session time over, please login again'] = "Sessions tiden har l�pt ut, logga in igen";
$_lang['&nbsp;Hide read elements'] = "&nbsp;G�m l�sta element";
$_lang['&nbsp;Show read elements'] = "&nbsp;Visa l�sta element";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide arkiverade element";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Visa arkiverade element";
$_lang['Tree view'] = "Tr�d vy";
$_lang['flat view'] = "Platt vy";
$_lang['New todo'] = "Ny att g�ra";
$_lang['New note'] = "Ny notering";
$_lang['New document'] = "Nytt dokument";
$_lang['Set bookmark'] = "Skapa bokm�rke";
$_lang['Move to archive'] = "Flytta till arkhiv";
$_lang['Mark as read'] = "Markera som l�st";
$_lang['Export as csv file'] = "Exportera som csv fil";
$_lang['Deselect all'] = "�ngra urvalet allt";
$_lang['selected elements'] = "valda element";
$_lang['wider'] = "bredare";
$_lang['narrower'] = "smalare";
$_lang['ascending'] = "Stigande";
$_lang['descending'] = "Fallande";
$_lang['Column'] = "Kolumn";
$_lang['Sorting'] = "Sortera";
$_lang['Save width'] = "Spara bredd";
$_lang['Width'] = "Bredd";
$_lang['switch off html editor'] = "st�ng av html editor";
$_lang['switch on html editor'] = "sl� p� html editor";
$_lang['hits were shown for'] = "tr�ffar visas f�r";
$_lang['there were no hits found.'] = "det gav inga tr�ffar.";
$_lang['Filename'] = "Filenamn";
$_lang['First Name'] = "F�rnamn";
$_lang['Family Name'] = "Efternamn";
$_lang['Company'] = "F�retag";
$_lang['Street'] = "Gatuadress";
$_lang['City'] = "Ort/Stad";
$_lang['Country'] = "Land";
$_lang['Please select the modules where the keyword will be searched'] = "Ange vilka moduler som skall s�kas i";
$_lang['Enter your keyword(s)'] = "Ange nyckelord";
$_lang['Salutation'] = "H�lsning";
$_lang['State'] = "L�n";
$_lang['Add to link list'] = "L�gg till i l�nk listan";

// setup.php
$_lang['Welcome to the setup of PHProject!<br>'] = "V�lkommen att s�tta upp PHProjekt!<br>";
$_lang['Please remark:<ul><li>A blank database must be available<li>Please ensure that the webserver is able to write the file config.inc.php'] = "Notera att:<ul> 
<li>Det m�ste finnas en tom databas. 
<li>Konfigurera webservern att till�ta skrivning av filen 'config.inc.php' f�r webserverns publika konto<br> (e.g. 'chmod 777')";
$_lang['<li>If you encounter any errors during the installation, please look into the <a href=help/faq_install.html target=_blank>install faq
</a>or visit the <a href=http://www.PHProjekt.com/forum.html target=_blank>Installation forum</a></i>'] = "<li>Om du f�r problem under installationen, ta en titt p� <a href='help/faq_install.html' target=_blank>install faq</a> eller bes�k <a href='http://www.PHProjekt.com/forum.html' target=_blank>Installations forum</a></i>";
$_lang['Please fill in the fields below'] = "Fyll i f�lten nedan";
$_lang['(In few cases the script wont respond.<br>Cancel the script, close the browser and try it again).<br>'] = "(Det kan h�nda att scriptet inte k�rs).<br> 
Avsluta scriptet och web-l�saren, prova sedan igen<br>";
$_lang['Type of database'] = "Databas typ";
$_lang['Hostname'] = "namnet p� servern som k�r databasen";
$_lang['Username'] = "Anv�ndarnamn";

$_lang['Name of the existing database'] = "Namnet p� en existernade databas";
$_lang['config.inc.php not found! Do you really want to update? Please read INSTALL ...'] = "Hittar inte filen config.inc.php! Vill du forts�tta med uppgraderingen av PHProject? L�s igenom INSTALL ...";
$_lang['config.inc.php found! Maybe you prefer to update PHProject? Please read INSTALL ...'] = "Hittat filen config.inc.php! Vi du forts�tta med uppgraderingen av PHProject? L�s igenom INSTALL ...";
$_lang['Please choose Installation,Update or Configure!'] = "V�lj \"Installtion\" eller \"uppdatering\"! sen �ter.....";
$_lang['Sorry, I cannot connect to the database! <br>Please close all browser windows and restart the installation.'] = "Det har blivit fel p� installationen <br>�tg�rda felet och prova att installera igen.";
$_lang['Sorry, it does not work! <br> Please set DBDATE to Y4MD- or let phprojekt change this environment-variable (php.ini)!'] = "Det blev ett fel under installationen! <br> S�tt DBDATE till 'Y4MD-' eller l�t phprojekt modifiera denna inst�llnings-variabel (php.ini)!";
$_lang['Seems that You have a valid database connection!'] = "Gratulerar, du har en aktiv databasanslutning!";
$_lang['Please select the modules you are going to use.<br> (You can disable them later in the config.inc.php)<br>'] = "V�lj de moduler som du vill anv�nda.<br> (Du kan avaktivera dom senare i config.inc.php)<br>";
$_lang['Install component: insert a 1, otherwise keep the field empty'] = "Installera modulerna: infoga '1', eller l�mna f�ltet tomt";
$_lang['Group views'] = "Grupp vy i kalendern";
$_lang['Todo lists'] = "Att g�ra lista";

$_lang['Voting system'] = "Omr�stnings system";


$_lang['Contact manager'] = "Kontakthanterare";
$_lang['Name of userdefined field'] = "Namn p� anv�nda definerade f�lt";
$_lang['Userdefined'] = "Defienerad av anv�ndare";
$_lang['Profiles for contacts'] = "Profil f�r kontakter";
$_lang['Mail'] = "epost";
$_lang['send mail'] = " skicka epost";
$_lang[' only,<br> &nbsp; &nbsp; full mail client'] = " bara,<br> &nbsp; &nbsp; epost l�sare (skicka &amp; l�sa)";



$_lang['1 to show appointment list in separate window,<br>&nbsp; &nbsp; 2 for an additional alert.'] = 
"'1' f�r att visa lista �ver bokade tider,<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'2' f�r ytterligare p�minnelser.";
$_lang['Alarm'] = "P�minnelse/Larm";
$_lang['max. minutes before the event'] = "max. minuter till p�minnelse";
$_lang['SMS/Mail reminder'] = "SMS/Mail p�minnelse";
$_lang['Reminds via SMS/Email'] = "P�minnelse via SMS/Email";
$_lang['1= Create projects,<br>&nbsp; &nbsp; 2= assign worktime to projects only with timecard entry<br>
&nbsp; &nbsp; 3= assign worktime to projects without timecard entry<br>&nbsp; &nbsp; 
(Selection 2 or 3 only with module timecard!)'] = "'1'= Skapa projekt,�ndra status<br> &nbsp; &nbsp; '2'= ange arbetstid i projekt med endast tidkort<br> &nbsp; &nbsp; '3'= ange arbetstid i projekt utan att anv�nda tidkort<br> ";

$_lang['Name of the directory where the files will be stored<br>( no file management: empty field)'] = "S�kv�gen till mappen d�r filerna lagras<br>( Ingen filhaterare: tom s�kv�g)";
$_lang['absolute path to this directory (no files = empty field)'] = "absolut s�kv�g till denna mapp( inga filer = tomt f�lt)";
$_lang['Time card'] = "Tidkort";
$_lang['1 time card system,<br>&nbsp; &nbsp; 2 manual insert afterwards sends copy to the chief'] = "'1' aktivera tidkort ,<br> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '2' manual l�gg till ett tidkort manuellt med kopia till projektledaren";
$_lang['Notes'] = "Noteringar";
$_lang['Password change'] = "�ndra l�senord";
$_lang['New passwords by the user - 0: none - 1: only random passwords - 2: choose own'] = "Nytt l�senord f�r anv�ndaren - 0: inget - 1: slumpvis skapade - 2: manuellt skapade";
$_lang['Encrypt passwords'] = "Krypterat l�senord";
$_lang['Login via '] = "Login via ";
$_lang['Extra page for login via SSL'] = "Extra sida for login via SSL";
$_lang['Groups'] = "Gruppen";
$_lang['User and module functions are assigned to groups<br>&nbsp; &nbsp; (recommended for user numbers > 40)'] = 
"Anv�ndare och modul funktioner �r kopplade till grupper<br> &nbsp;&nbsp;&nbsp;&nbsp;(recommenderas f�r > 40 anv�ndare)";
$_lang['User and module functions are assigned to groups'] = "Anv�ndare och funktioner �r kopplade till grupper";
$_lang['Help desk'] = "�rende hantering (Help desk)";
$_lang['Help Desk Manager / Trouble Ticket System'] = "Help desk operat�r / Fel hanterings system";
$_lang['RT Option: Customer can set a due date'] = "RT Till�gg: Anv�ndaren kan s�tta senaste giltigt datum";
$_lang['RT Option: Customer Authentification'] = "RT Till�gg: Anv�ndar identifiering";
$_lang['0: open to all, email-address is sufficient<br>1: registered contact enter his family name<br>2: his email'] = "0: �ppen f�r alla, email-adress �r tillr�ckligt, 1: kunden m�ste finnas i systemets anv�ndar-lista och ange sig med efternamnet";
$_lang['RT Option: Assigning request'] = "RT Till�gg: Aktivera request";
$_lang['0: by everybody, 1: only by persons with status chief'] = "0: av alla, 1: bara av person med arbetsledaruppgift 'chief'";
$_lang['Email Address of the support'] = "Epostadress till support";
$_lang['Scramble filenames'] = "Kodade fil namn";
$_lang['creates scrambled filenames on the server<br>assigns previous name at download'] = "skapa tillf�lliga fil namn p� servern<br> 
tilldelar riktiga namnet p� filen vid nedladdning";

$_lang['0: last name, 1: short name, 2: login name'] = "0: Efternamn, 1: Signartur, 2: Inloggnings namn";
$_lang['Prefix for table names in db'] = "Prefix f�r tabellnamnen i databasen";
$_lang['Alert: Cannot create file config.inc.php!<br>Installation directory needs rwx access for your server and rx access to all others.'] = 
"Varning: kan inte skapa filen 'config.inc.php'!<br> det m�ste vara komplett r�ttighet f�r din administrator/server och rx f�r alla andra.";
$_lang['Location of the database'] = "Placering av databasen";
$_lang['Type of database system'] = "Typ av databassystem";
$_lang['Username for the access'] = "Anv�ndare f�r databaskopplingen";
$_lang['Password for the access'] = "L�senord f�r databaskopplingen";
$_lang['Name of the database'] = "Namnet p� databasen";
$_lang['Prefix for database table names'] = "Prefix f�r tabellnamn i databasen ";
$_lang['First background color'] = "Prim�r bakgrundsf�rg";
$_lang['Second background color'] = "Sekund�r bakgrundsf�rg";
$_lang['Third background color'] = "Tredjevalet av bakgrundsf�rg";
$_lang['Color to mark rows'] = "F�rg f�r att markera rader";
$_lang['Color to highlight rows'] = "F�rg f�r �verstrykningsmarkering";
$_lang['Event color in the tables'] = "F�rg p� h�ndelser i tabellen";
$_lang['company icon yes = insert name of image'] = "F�retags logo: ja = skriv in filnamnet p� logon";
$_lang['URL to the homepage of the company'] = "URL till f�retagets hemsida";
$_lang['no = leave empty'] = "nej = l�mna tomt";
$_lang['First hour of the day:'] = "Arbetsdagen b�rjar:";
$_lang['Last hour of the day:'] = "Arbetsdagen slutar:";
$_lang['An error ocurred while creating table: '] = "Ett fel uppstod vid skapande av tabellen: ";
$_lang['Table dateien (for file-handling) created'] = "Tabellen 'dateien' (f�r fil hantering) har skapats";
$_lang['File management no = leave empty'] = "Fil hanterare - ingen = l�mna tomt";
$_lang['yes = insert full path'] = "ja = fyll in hela s�kv�gen";
$_lang['and the relative path to the PHProjekt directory'] = "fyll ocks� i relativ s�k till root-mappen";
$_lang['Table profile (for user-profiles) created'] = "Tabellen 'profile' (f�r anv�ndar profiler) har skapats";
$_lang['User Profiles yes = 1, no = 0'] = "Grupper ja = 1, nej = 0";
$_lang['Table todo (for todo-lists) created'] = "Tabellen 'todo' (f�r att-g�ra listan ) har skapats";
$_lang['Todo-Lists yes = 1, no = 0'] = "Att-g�ra lista ja = 1, nej = 0";
$_lang['Table forum (for discssions etc.) created'] = "Tabellen 'forum' (f�r diskussioner m.m.) har skapats";
$_lang['Forum yes = 1, no = 0'] = "Forum ja = 1, nej = 0";
$_lang['Table votum (for polls) created'] = "Tabellen 'votum' (f�r omr�stning) har skapats";
$_lang['Voting system yes = 1, no = 0'] = "Omr�stnings system ja = 1, nej = 0";
$_lang['Table lesezeichen (for bookmarks) created'] = "Tabellen 'lesezeichen' (f�r bokm�rken) har skapats";
$_lang['Bookmarks yes = 1, no = 0'] = "Bokm�rken ja = 1, nej = 0";
$_lang['Table ressourcen (for management of additional ressources) created'] = "Tabellen 'ressourcen' (f�r hantering av nya resurser ) har skapats";
$_lang['Resources yes = 1, no = 0'] = "Resurser ja = 1, nej = 0";
$_lang['Table projekte (for project management) created'] = "Tabellen 'projekte' (f�r projekt hantering) har skapats";
$_lang['Table contacts (for external contacts) created'] = "Tabellen 'contacts' (f�r externa kontakter) har skapats";
$_lang['Table notes (for notes) created'] = "Tabellen 'notes' (f�r noteringar) har skapats";
$_lang['Table timecard (for time sheet system) created'] = "Tabellen 'timecard' (for tidkort systemet) har skapats";
$_lang['Table groups (for group management) created'] = "Tabellen groups (f�r grupp hantering) har skapats";
$_lang['Table timeproj (assigning work time to projects) created'] = "tabellen timeproj (tilldeling av arbetstid till projekt) har skapats";
$_lang['Table rts and rts_cat (for the help desk) created'] = "Tabellerna rts och rts_cat (f�r help desk) har skapats";
$_lang['Table mail_account, mail_attach, mail_client und mail_rules (for the mail reader) created'] = "Tabellerna mail_account, mail_attach, mail_client och mail_rules (f�r epost l�saren) har skapats";
$_lang['Table logs (for user login/-out tracking) created'] = "Tabellen logs (f�r loggin av in- och utloggong av anv�ndare) har skapats";
$_lang['Tables contacts_profiles und contacts_prof_rel created'] = "Tabellen contacts_profiles och contacts_prof_rel har skapats";
$_lang['Project management yes = 1, no = 0'] = "Projekthantering ja = 1, nej = 0";
$_lang['additionally assign resources to events'] = "f�r att l�gga in ytterligare resurser i projekt";
$_lang['Address book  = 1, nein = 0'] = "Adressbok  ja = 1, nej = 0";
$_lang['Mail no = 0, only send = 1, send and receive = 2'] = "Epost nej=0, bara skicka = 1, skicka och ta emot = 2";
$_lang['Chat yes = 1, no = 0'] = "Chat Ja = 1, nej = 0";
$_lang['Name format in chat list'] = "Namnformat i chat listan";
$_lang['0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name'] = "0: efternamn, 1: f�rnamn, 2: f�rnamn, efternamn,<br> &nbsp; &nbsp; 3: efternamn, f�rnamn";
$_lang['Timestamp for chat messages'] = "Tidsmarkering f�r chat meddelanden";
$_lang['users (for authentification and address management)'] = "Tabellen 'users' (f�r identifiering och adress hantering) har skapats";
$_lang['Table termine (for events) created'] = "Tabellen 'termine' (f�r h�ndelser) har skapats";
$_lang['The following users have been inserted successfully in the table user:<br>root - (superuser with all administrative privileges)<br>
test - (chief user with restricted access)'] = "F�ljande anv�ndare har laggts till i tabellen 'user':
<br> 'root' - (administrat�rer med fullst�ndiga r�ttiheter)<br> 'test' - (normal�nv�ndare med begr�nsade r�ttigheter)";
$_lang['The group default has been created'] = "Gruppen 'default' har skapats";
$_lang['Please do not change anything below this line!'] = "�ndra ingenting efter denna rad!";
$_lang['Database error'] = "Fel i databasen";
$_lang['Finished'] = "Klart";
$_lang['There were errors, please have a look at the messages above'] = "Det finns fel, felen �r listade i meddelandet ovan";
$_lang['All required tables are installed and <br>the configuration file config.inc.php is rewritten<br>
It would be a good idea to makea backup of this file.<br>'] = "Alla tabeller �r installerade och <br> 
konfigurationsfilen 'config.inc.php' �r skapad/uppdaterad<br>Du b�r nu g�ra en s�kerhetskopia p� denna fil.<br> 
St�ng alla web-f�nster<br>";
$_lang['The administrator root has the password root. Please change his password here:'] = "Administratorn 'root' har l�senordet 'root'. Byt ut detta l�senord s� snart som m�jligt.<br>";
$_lang['Please define here a password for the administrator "root":'] = "Please define here a password for the administrator 'root':";
$_lang['The user test is now member of the group default.<br>Now you can create new groups and add new users to the group'] = 
"Anv�ndarna 'test' �r medlem av gruppen 'default'.<br> Du kan nu skapa nya grupper och l�gga till nya medlemmar till grupperna";
$_lang['To use PHProject with your Browser go to <b>index.php</b><br>Please test your configuration, especially the modules Mail and Files.'] = 
"F�r att anv�nda PHProject i din web-l�sare klicka p� <b><a href='index.php'>index.php</a></b><br> Prova din konfiguration och speciellt modulerna 'epost' och 'filer'.";

$_lang['Alarm x minutes before the event'] = "Larm x minuter f�re p�minnelse";
$_lang['Additional Alarmbox'] = "Ytterligare p�minnelser";
$_lang['Mail to the chief'] = "Post till arbetsledaren";
$_lang['Out/Back counts as: 1: Pause - 0: Workingtime'] = "Ute/�ter s�tts till: 1: Paus - 0: Arbetstid";
$_lang['Passwords will now be encrypted ...'] = "L�senordet kommer nu att krypteras";
$_lang['Filenames will now be crypted ...'] = "Filnamen kommer nu att krypteras ...";
$_lang['Do you want to backup your database right now? (And zip it together with the config.inc.php ...)<br>Of course I will wait!'] = 
"Vill du s�kerhets kopiera din database nu? (Och packa den tillsammans med config.inc.php zip-fil...)<br> Jag g�r det senare!";
$_lang['Next'] = "N�sta";
$_lang['Notification on new event in others calendar'] = "Skapa nya h�ndelser i andras kalendrar";
$_lang['Path to sendfax'] = "S�kv�g till sendfax";
$_lang['no fax option: leave blank'] = "ingen faxfunktion: l�mna tom";
$_lang['Please read the FAQ about the installation with postgres'] = "L�s FAQ f�r installation med postgres";
$_lang['Length of short names<br> (Number of letters: 3-6)'] = "Antal bokst�ver i signatur<br> (minst 3, max 6)";
$_lang['If you want to install PHProjekt manually, you find<a href=http://www.phprojekt.com/files/sql_dump.tar.gz target=_blank>here</a> 
a mysql dump and a default config.inc.php'] = "Om du vill installera PHProjekt manuellt, s� finns instruktioner p� <a href='http://www.phprojekt.com/files/sql_dump.tar.gz' target=_blank>here</a> a mysql dump and a default config.inc.php";
$_lang['The server needs the privilege to write to the directories'] = "Servern m�sta ha skrivr�ttigheter till foldern";
$_lang['Header groupviews'] = "Huvudteman visade i grupper";
$_lang['name, F.'] = "efternamn, F.";
$_lang['shortname'] = "signatur";
$_lang['loginname'] = "anv�ndar namn";
$_lang['Please create the file directory'] = "Skapa foldern f�r filerna";
$_lang['default mode for forum tree: 1 - open, 0 - closed'] = "standard inst�llning f�r forum tr�det: 1 - expanderad, 0 - minimerad";
$_lang['Currency symbol'] = "Valutasymbol";
$_lang['current'] = "aktuell";
$_lang['Default size of form elements'] = "Standardstorlek f�r formelement";
$_lang['use LDAP'] = "anv�nd LDAP";
$_lang['Allow parallel events'] = "Till�t parallella h�ndelser";
$_lang['Timezone difference [h] Server - user'] = "Skillnader i tidzon [timmar] mellan Server och anv�ndare";
$_lang['Timezone'] = "Tidszon";
$_lang['max. hits displayed in search module'] = "max. antal tr�ffar som syns i s�kmodulen";
$_lang['Time limit for sessions'] = "Tidsgr�ns f�r sessioner";
$_lang['0: default mode, 1: Only for debugging mode'] = "0: Standard l�ge, 1: Fels�knings l�ge";
$_lang['Enables mail notification on new elements'] = "Aktiverar epost meddelande av nya element";
$_lang['Enables versioning for files'] = "Aktiverar versionskontroll f�r filer";
$_lang['no link to contacts in other modules'] = "ingen l�nk till kontakter i andra moduler";
$_lang['Highlight list records with mouseover'] = "Markera listporter med 'mouseover'";
$_lang['Track user login/logout'] = "Logga anv�ndar inlogging/utloggning";
$_lang['Access for all groups'] = "Tillg�nglig f�r alla grupper";
$_lang['Option to release objects in all groups'] = "Val f�r att sl�ppa objekt i alla grupper";
$_lang['Default access mode: private=0, group=1'] = "Standard access l�ge: privat=0, grupp=1";
$_lang['Adds -f as 5. parameter to mail(), see php manual'] = "L�gger till '-f' som 5. parameter f�r mail(), se php manualen";
$_lang['end of line in body; e.g. \r\n (conform to RFC 2821 / 2822)'] = "radslut i meddelandekropp; e.g. \\r\\n (i enlighet med RFC 2821 / 2822)";
$_lang['end of header line; e.g. \r\n (conform to RFC 2821 / 2822)'] = "Slut p� header rad; e.g. \\r\\n (i enlighet med RFC 2821 / 2822)";
$_lang['Sendmail mode: 0: use mail(); 1: use socket'] = "Sendmail l�ge: 0: anv�nd mail(); 1: anv�nd socket";
$_lang['the real address of the SMTP mail server, you have access to (maybe localhost)'] = "den riktiga adressen till SMTP mail servern, du har access till (m�jligtvis localhost)";
$_lang['name of the local server to identify it while HELO procedure'] = "namn p� den lokala servern f�r att identifiera den under HELO proceduren";
$_lang['Authentication'] = "Autenticiering";
$_lang['fill out in case of authentication via POP before SMTP'] = "fyll i om autenticiering via POP f�re SMTP ska ske";
$_lang['real username for POP before SMTP'] = "anv�ndarnamn f�r POP f�re SMTP";
$_lang['password for this pop account'] = "l�senord f�r detta pop konto";
$_lang['the POP server'] = "POP servern";
$_lang['fill out in case of SMTP authentication'] = "fylls i om SMTP autenticiering ska anv�ndas";
$_lang['real username for SMTP auth'] = "Anv�ndare f�r SMTP auth";
$_lang['password for this account'] = "l�senord f�r kontot";
$_lang['SMTP account data (only needed in case of socket)'] = "SMTP konto data (beh�vs endast om socketl�ge anv�nds)";
$_lang['No Authentication'] = "Ingen autenticiering"; 
$_lang['with POP before SMTP'] = "med POP f�re SMTP";
$_lang['SMTP auth (via socket only!)'] = "SMTP auth (via socket endast!)";
$_lang['Log history of records'] = "Loggga historiken f�r poster";
$_lang['Send'] = " Skicka";
$_lang['Host-Path'] = "Host-Path";
$_lang['Installation directory'] = "Installations folder";
$_lang['0 Date assignment by chief, 1 Invitation System'] = "0 Tid f�rdelad av chef, 1 Invitera deltagare";
$_lang['0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System'] = "0 Tid f�rdelad av chef,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitera deltagare";
$_lang['Default write access mode: private=0, group=1'] = "Standard mode f�r skrivr�ttigheter: privat=0, grupp=1";
$_lang['Select-Option accepted available = 1, not available = 0'] = "Select-Option funktionen tillg�nglig = 1, inte tillg�nglig = 0";
$_lang['absolute path to host, e.g. http://myhost/'] = "absolut s�kv�g till host, t.ex. http://myhost/";
$_lang['installation directory below host, e.g. myInstallation/of/phprojekt5/'] = "installation folder, t.ex. myInstallation/of/phprojekt5/";

// l.php
$_lang['Resource List'] = "Resurslista";
$_lang['Event List'] = "H�ndelselista";
$_lang['Calendar Views'] = "Gruppvy";

$_lang['Personnel'] = "Personal";
$_lang['Create new event'] = "Skapa/ta bort h�ndelse";
$_lang['Day'] = "Dag";

$_lang['Until'] = "till";

$_lang['Note'] = "Notis";
$_lang['Project'] = "Projekt";
$_lang['Res'] = "Resurs";
$_lang['Once'] = "en g�ng";
$_lang['Daily'] = "dagligen";
$_lang['Weekly'] = "veckovis";
$_lang['Monthly'] = "m�nadsvis";
$_lang['Yearly'] = "�rsvis";

$_lang['Create'] = "skapa";

$_lang['Begin'] = "B�rjan";
$_lang['Out of office'] = "Ute p� tj�nste�rende";
$_lang['Back in office'] = "�ter fr�n tj�nste�rende";
$_lang['End'] = "Slut";
$_lang['@work'] = "@jobb";
$_lang['We'] = "Var";
$_lang['group events'] = "Grupp h�ndelser";
$_lang['or profile'] = "eller profil";
$_lang['All Day Event'] = "h�ndelser under hela dagen";
$_lang['time-axis:'] = "tids-axel:";
$_lang['vertical'] = "vertikal";
$_lang['horizontal'] = "horisontell";
$_lang['Horz. Narrow'] = "hor. begr�nsad";
$_lang['-interval:'] = "-interval:";
$_lang['Self'] = "Privat";

$_lang['...write'] = "...skriv";

$_lang['Calendar dates'] = "Kalender datum";
$_lang['List'] = "Lista";
$_lang['Year'] = "�r";
$_lang['Month'] = "M�nad";
$_lang['Week'] = "Vecka";
$_lang['Substitution'] = "Substitution";
$_lang['Substitution for'] = "Substitution for";
$_lang['Extended&nbsp;selection'] = "Extended&nbsp;selection";
$_lang['New Date'] = "New date entered";
$_lang['Date changed'] = "Date changed";
$_lang['Date deleted'] = "Date deleted";

// links
$_lang['Database table'] = "Databas tabell";
$_lang['Record set'] = "Record set";
$_lang['Resubmission at:'] = "Resubmission at:";
$_lang['Set Links'] = "Linkar";
$_lang['From date'] = "Fr�n dag";
$_lang['Call record set'] = "Call record set";


//login.php
$_lang['Please call login.php!'] = "Starta login.php!";

// m1.php
$_lang['There are other events!<br>the critical appointment is: '] = "Flera h�ndelse finns<br>Kritiskt m�te: ";
$_lang['Sorry, this resource is already occupied: '] = "Tyv�rr, resursen �r upptagen: ";
$_lang[' This event does not exist.<br> <br> Please check the date and time. '] = "H�ndelsen finns ej<br> <br> Kontrollera datum och tid. ";
$_lang['Please check your date and time format! '] = "Kontrollera formatet f�r datum, och tid! ";
$_lang['Please check the date!'] = "Kontrollera datum!";
$_lang['Please check the start time! '] = "Kontrollera starttid! ";
$_lang['Please check the end time! '] = "Kontrollera sluttid! ";
$_lang['Please give a text or note!'] = "Ange text eller kommentar!";
$_lang['Please check start and end time! '] = "kontrollera start- och sluttid! ";
$_lang['Please check the format of the end date! '] = "Kontrollera slutdatumsformat! ";
$_lang['Please check the end date! '] = "Kontrollera slutdatum! ";



$_lang['Resource'] = "Resurs";
$_lang['User'] = "Anv�ndare";

$_lang['delete event'] = "Ta bort h�ndelse";
$_lang['Address book'] = "Adressbok";
$_lang['Short Form'] = "Signatur";
$_lang['Phone'] = "Telefon";
$_lang['Fax'] = "Fax";

$_lang['Bookmark'] = "Bokm�rke";
$_lang['Description'] = "Beskrivning";
$_lang['Entire List'] = "Komplett lista";

$_lang['New event'] = "Ny h�ndelse";
$_lang['Created by'] = "skapad av";
$_lang['Red button -> delete a day event'] = "Radera en daglig h�ndelse med den r�da knappen";
$_lang['multiple events'] = "flera h�ndelser";
$_lang['Year view'] = "�rsvis vy";
$_lang['calendar week'] = "kalendervecka"; 

//m2.php
$_lang['Create &amp; Delete Events'] = "Skapa &amp; ta bort h�ndelser";
$_lang['normal'] = "normal";
$_lang['private'] = "privat";
$_lang['public'] = "allm�n";
$_lang['Visibility'] = "Synlighet";

//mail module
$_lang['Please select at least one (valid) address.'] = "Ange minst en (giltig) epost adress.";
$_lang['Your mail has been sent successfully'] = "Epost meddelandet har skickats";
$_lang['Attachment'] = "Bilaga";
$_lang['Send single mails'] = "skicka enstaka e-post";
$_lang['Does not exist'] = "existerar inte";
$_lang['Additional number'] = "till�ggs nummer";  //not. origin "additional numbers" kan vara "ytterligare adresser"
$_lang['has been canceled'] = "har inte skickat";

$_lang['marked objects'] = "markerat objekt";
$_lang['Additional address'] = "Ytterligare mottagare";
$_lang['in mails'] = "i epost";
$_lang['Mail account'] = "Epost konto";
$_lang['Body'] = "Meddelande";
$_lang['Sender'] = "S�ndare";

$_lang['Receiver'] = "Mottagare";
$_lang['Reply'] = "Svar";
$_lang['Forward'] = "Vidarebefodra";
$_lang['Access error for mailbox'] = "Fel i r�ttigheterna till epost-l�dan";
$_lang['Receive'] = "Ta emot";
$_lang['Write'] = "S�nd";
$_lang['Accounts'] = "Konton";
$_lang['Rules'] = "Regler";
$_lang['host name'] = "v�rd namn (host name)";
$_lang['Type'] = "Typ";
$_lang['misses'] = "saknas";
$_lang['has been created'] = "har skapats";
$_lang['has been changed'] = "har �ndrats";
$_lang['is in field'] = "�r i f�ltet";
$_lang['and leave on server'] = "Ta emot epost och spara dom p� servern";
$_lang['name of the rule'] = "namn p� regeln";
$_lang['part of the word'] = "delar av ordet";
$_lang['in'] = "i";
$_lang['sent mails'] = "skickat epost";
$_lang['Send date'] = "Avs�nt den";
$_lang['Received'] = "Mottaget";
$_lang['to'] = "till";
$_lang['imcoming Mails'] = "inkommande epost";
$_lang['sent Mails'] = "skickad epost";
$_lang['Contact Profile'] = "Kontakt Profil";
$_lang['unread'] = "ej l�st";
$_lang['view mail list'] = "visa post lista";
$_lang['insert db field (only for contacts)'] = "l�gg in db f�lt (bara f�r kontakter)";
$_lang['Signature'] = "Signatur";

$_lang['SMS'] = "SMS";
$_lang['Single account query'] = "Enkel konto fr�ga";
$_lang['Notice of receipt'] = "Meddelande om kvitto";
$_lang['Assign to project'] = "Koppla till projekt";
$_lang['Assign to contact'] = "Koppla till kontakt";  
$_lang['Assign to contact according to address'] = "Koppla till kontakt i enlighet med adress";
$_lang['Include account for default receipt'] = "Inkludera konto f�r standard kvitto";
$_lang['Your token has already been used.<br>If it wasnt you, who used the token please contact your administrator.'] = "Denna token �r upptagen.<br>Om du inte anv�nder den, kontakta din administrator";
$_lang['Your token has already been expired.'] = "Din token har passerat slutdatumet";
$_lang['Unconfirmed Events'] = "Ej bekr�ftade h�ndelser";
$_lang['Visibility presetting when creating an event'] = "Synlighet �terst�lld n�r man skapar en ny h�ndelse";
$_lang['Subject'] = "�mne";
$_lang['Content'] = "Inneh�ll";
$_lang['answer all'] = "svara alla";
$_lang['Create new message'] = "Skapa nytt meddelande";
$_lang['Attachments'] = "Bifogade dokument";
$_lang['Recipients'] = "Mottagare";
$_lang['file away message'] = "meddelande om borttagen fil";
$_lang['Message from:'] = "Meddelande fr�n:";

//notes.php
$_lang['Mail note to'] = "Notis";
$_lang['added'] = "laggt till";
$_lang['changed'] = "�ndrad";

// o.php
$_lang['Calendar'] = "Kalender";
$_lang['Contacts'] = "Kontakter";

$_lang['Files'] = "Filer";

$_lang['Options'] = "�vrigt";
$_lang['Timecard'] = "Tidkort"; /* Kontrollkort ??? */

$_lang['Helpdesk'] = "Helpdesk";

$_lang['Info'] = "Info";
$_lang['Todo'] = "Uppgifter";
$_lang['News'] = "Nyheter";
$_lang['Other'] = "�vrigt";
$_lang['Settings'] = "Inst�llningar";
$_lang['Summary'] = "�versikt";

// options.php
$_lang['Description:'] = "Beskrivning:";
$_lang['Comment:'] = "Kommentar:";
$_lang['Insert a valid Internet address! '] = "Fyll i giltig Internetadress! ";
$_lang['Please specify a description!'] = "Fyll i beskrivning!";
$_lang['This address already exists with a different description'] = "denna adress finns redan i annan beskrivning";
$_lang[' already exists. '] = " finns redan. ";
$_lang['is taken to the bookmark list.'] = " lagt till bokm�rke.";
$_lang[' is changed.'] = " �ndrades.";
$_lang[' is deleted.'] = " togs bort.";
$_lang['Please specify a description! '] = "Fyll i beskrivning! ";
$_lang['Please select at least one name! '] = "Fyll i minst ett namn! ";
$_lang[' is created as a profile.<br>'] = " profilen skapades.<br> Profilen syns efter att du uppdaterat kalender- eller huvudsidan.";
$_lang['is changed.<br>'] = " �ndrades.<br> Profilen syns efter att du uppdaterat kalender- eller huvudsidan.";
$_lang['The profile has been deleted.'] = "Profil borttagen.";
$_lang['Please specify the question for the poll! '] = "Fyll i fr�ga f�r omr�stning! ";
$_lang['You should give at least one answer! '] = "Minst ett svar kr�vs! ";
$_lang['Your call for votes is now active. '] = "Omr�stnings upprop har aktiveras. ";
$_lang['<h2>Bookmarks</h2>In this section you can create, modify or delete bookmarks:'] = "<h4>Bokm�rken</h4>H�r kan du skapa, �ndra och ta bort bokm�rken:";
$_lang['Create'] = "skapa";

$_lang['<h2>Profiles</h2>In this section you can create, modify or delete profiles:'] = "<h4>Profil</h4>H�r kan du skapa, �ndra och ta bort profil:";
$_lang['<h2>Voting Formula</h2>'] = "<h4>Formul�r f�r omr�stning</h4>";
$_lang['In this section you can create a call for votes.'] = "H�r kan du skapa �rende f�r omr�stning.";
$_lang['Question:'] = "Fr�ga:";
$_lang['just one <b>Alternative</b> or'] = "endast ett <b>alternativ</b> eller";
$_lang['several to choose?'] = "fler att v�lja?";

$_lang['Participants:'] = "Deltagare:";

$_lang['<h3>Password Change</h3> In this section you can choose a new random generated password.'] = "<h3>�ndra L�senord</h3> H�r kan du generera nytt tillf�lligt l�senord.";
$_lang['Old Password'] = "Gammalt l�senord";
$_lang['Generate a new password'] = "Generera nytt l�senord";
$_lang['Save password'] = "Spara l�senord";
$_lang['Your new password has been stored'] = "Ditt nya l�senord har sparats";
$_lang['Wrong password'] = "Felaktigt l�senord";
$_lang['Delete poll'] = "Radera r�st";
$_lang['<h4>Delete forum threads</h4> Here you can delete your own threads<br>Only threads without a comment will appear.'] = "<h4>Radera diskussion</h4> du kan bara ta bort dom diskussioner som du startat<br> Endast diskussioner utan kommentarer visas.";

$_lang['Old password'] = "Nuvarande l�senord";
$_lang['New Password'] = "Nytt l�senord";
$_lang['Retype new password'] = "Skriv in det nya l�senordet igen";
$_lang['The new password must have 5 letters at least'] = "Det nya l�senordet m�ste ha minst 5 bokst�ver";
$_lang['You didnt repeat the new password correctly'] = "Skrev du in det nya l�senordet korrekt b�da g�ngerna";

$_lang['Show bookings'] = "Visa bokningar";
$_lang['Valid characters'] = "Till�tna tecken";
$_lang['Suggestion'] = "F�rslag";
$_lang['Put the word AND between several phrases'] = "Anv�nd ordet AND mellan olika fraser"; // translators: please leave the word AND as it is
$_lang['Write access for calendar'] = "Skrivr�ttigheter f�r kalender";
$_lang['Write access for other users to your calendar'] = "Skrivr�ttigheter f�r andra anv�ndare i din kalender";
$_lang['User with chief status still have write access'] = "Anv�ndare med chefsr�ttigheter har fortfarande skrivr�ttighet";

// projects
$_lang['Project Listing'] = "Projektlista";
$_lang['Project Name'] = "Projektnamn";

$_lang['o_files'] = "Files";
$_lang['o_notes'] = "Notes";
$_lang['o_projects'] = "Projekt";
$_lang['o_todo'] = "Att g�ra";
$_lang['Copyright']="Copyright";
$_lang['Links'] = "L�nkar";
$_lang['New profile'] = "Ny profil";
$_lang['In this section you can choose a new random generated password.'] = "I denna sektion s� kan du v�lja ett slumpm�ssigt genererat l�senord.";
$_lang['timescale'] = "tidsskala";
$_lang['Manual Scaling'] = "Manuell skalning";
$_lang['column view'] = "kolumn vy";
$_lang['display format'] = "display format";
$_lang['for chart only'] = "Bara f�r chart:";
$_lang['scaling:'] = "skalning:";
$_lang['colours:'] = "f�rger";
$_lang['display project colours'] = "visa f�rgerna f�r projektet";
$_lang['weekly'] = "veckovis �terkommande";
$_lang['monthly'] = "m�nadsvis �terkommande";
$_lang['annually'] = "�rligt";
$_lang['automatic'] = "automatiskt";
$_lang['New project'] = "Nytt projekt";
$_lang['Basis data'] = "Grund data";
$_lang['Categorization'] = "kategorisering";
$_lang['Real End'] = "Verkligt slut";
$_lang['Participants'] = "Deltagare";
$_lang['Priority'] = "Prioritet";
$_lang['Status'] = "Status";
$_lang['Last status change'] = "Senaste �ndring";
$_lang['Leader'] = "Projektledare";
$_lang['Statistics'] = "Statistik";
$_lang['My Statistic'] = "Min statistik";

$_lang['Person'] = "Person";
$_lang['Hours'] = "Timmar";
$_lang['Project summary'] = "Projektsummering";
$_lang[' Choose a combination Project/Person'] = " V�lj kombination Projekt/Person";
$_lang['(multiple select with the Ctrl/Cmd-key)'] = "(fler val med 'Ctrl')";

$_lang['Persons'] = "Person(er)";
$_lang['Begin:'] = "B�rjan:";
$_lang['End:'] = "Slut:";
$_lang['All'] = "Alla";
$_lang['Work time booked on'] = "Arbetstiden bokad f�r";
$_lang['Sub-Project of'] = "Underprojekt till";
$_lang['Aim'] = "M�ls�ttning";
$_lang['Contact'] = "Kontakt";
$_lang['Hourly rate'] = "timkostnad";
$_lang['Calculated budget'] = "ber�knad budget";
$_lang['New Sub-Project'] = "Nytt underprojekt";
$_lang['Booked To Date'] = "Bokad just nu";
$_lang['Budget'] = "Budget";
$_lang['Detailed list'] = "Detaljerad lista";
$_lang['Gantt'] = "Tidslinje";
$_lang['offered'] = "erbjuden";
$_lang['ordered'] = "avdelad";
$_lang['Working'] = "arbetar";
$_lang['ended'] = "avslutat";
$_lang['stopped'] = "stannad";
$_lang['Re-Opened'] = "�ppnad igen";
$_lang['waiting'] = "v�ntar";
$_lang['Only main projects'] = "Bara huvud projekt";
$_lang['Only this project'] = "Bara f�r detta projekt";
$_lang['Begin > End'] = "B�rjan > Slut";
$_lang['ISO-Format: yyyy-mm-dd'] = "ISO-Format: ����-mm-dd";
$_lang['The timespan of this project must be within the timespan of the parent project. Please adjust'] = "Tidsomf�nget p� detta projekt m�ste ligga inom tidsomf�ngen f�r huvud projektet.  Korrigera tidsomf�ngen ";
$_lang['Please choose at least one person'] = "V�lj minst en person";
$_lang['Please choose at least one project'] = "V�lj minst ett projekt";
$_lang['Dependency'] = "Beroende";
$_lang['Previous'] = "F�reg�ende";

$_lang['cannot start before the end of project'] = "Kan inte b�rja innan slutet p� projekt";
$_lang['cannot start before the start of project'] = "Kan inte starta f�re starten av projekt";
$_lang['cannot end before the start of project'] = "Kan inte sluta innan starten av projekt";
$_lang['cannot end before the end of project'] = "Kan inte sluta innan slutet av projekt";
$_lang['Warning, violation of dependency'] = "Varning, brott mot beroenden";
$_lang['Container'] = "kontainer";
$_lang['External project'] = "Externa projekt";
$_lang['Automatic scaling'] = "Automatisk skalning";
$_lang['Legend'] = "Historia";
$_lang['No value'] = "Inget v�rde";
$_lang['Copy project branch'] = "Kopiera projekt gren";
$_lang['Copy this element<br> (and all elements below)'] = "Kopiera detta element<br> (och alla underliggande element)";
$_lang['And put it below this element'] = "Och infoga under detta element";
$_lang['Edit timeframe of a project branch'] = "�ndra tidsramen f�r en projektgren"; 

$_lang['of this element<br> (and all elements below)'] = "av detta element<br> (och alla underliggande element)";
$_lang['by'] = "av";
$_lang['Probability'] = "Sannolikhet";
$_lang['Please delete all subelements first'] = "V�nligen radera alla underprojekt f�rst";
$_lang['Assignment'] ="Tilldelning";
$_lang['display'] = "Display";
$_lang['Normal'] = "Normal";
$_lang['sort by date'] = "Sortera per dag";
$_lang['sort by'] = "Sortera per";
$_lang['Calculated budget has a wrong format'] = "Den ber�knade budgeten har ett felaktigt format";
$_lang['Hourly rate has a wrong format'] = "Timkostnaden har ett felaktigt format";

// r.php
$_lang['please check the status!'] = "Kontrollera status!";
$_lang['Todo List: '] = "Att G�ra: ";
$_lang['New Remark: '] = "Ny minneslapp: ";
$_lang['Delete Remark '] = "Ta bort minneslapp";
$_lang['Keyword Search'] = "Fulltexts�kning: ";
$_lang['Events'] = "H�ndelse";
$_lang['the forum'] = "i forum";
$_lang['the files'] = "i filer";
$_lang['Addresses'] = "Adresser";
$_lang['Extended'] = "Ut�kat";
$_lang['all modules'] = "alla moduler";
$_lang['Bookmarks:'] = "Bokm�rke:";
$_lang['List'] = "Lista";
$_lang['Projects:'] = "Projekt:";

$_lang['Deadline'] = "Tid";

$_lang['Polls:'] = "R�ster:";

$_lang['Poll created on the '] = "�mr�stning skapad ";


// reminder.php
$_lang['Starts in'] = "b�rjar om";
$_lang['minutes'] = "minut(er)";
$_lang['No events yet today'] = "Ingen h�ndelse f�r tillf�llet bokad idag";
$_lang['New mail arrived'] = "Ny post har anl�nt";

//ress.php

$_lang['List of Resources'] =  "Resurslista";
$_lang['Name of Resource'] = "Resursnamn";
$_lang['Comments'] =  "Kommentar";


// roles
$_lang['Roles'] = "Roller";
$_lang['No access'] = "Inga r�ttigheter";
$_lang['Read access'] = "L�sr�ttighet";
$_lang['Role'] = "Roll";

// helpdesk - rts
$_lang['Request'] = "�rende";
$_lang['pending requests'] = "�renden i v�ntelista";
$_lang['show queue'] = "visa �rendek�";
$_lang['Search the knowledge database'] = "S�k i kunskaps databasen";
$_lang['Keyword'] = "Nyckelord";
$_lang['show results'] = "visa resultatet";
$_lang['request form'] = "�rende formul�r";
$_lang['Enter your keyword'] = "skriv in nyckelord";
$_lang['Enter your email'] = "Skriv in din email-adress";
$_lang['Give your request a name'] = "Ge ditt �rende ett namn";
$_lang['Describe your request'] = "Beskriv ditt �rende";
$_lang['Due date'] = "Giltig till datum";
$_lang['Days'] = "Dagar";
$_lang['Sorry, you are not in the list'] = "Du �r finns tyv�rr inte i listan";
$_lang['Your request Nr. is'] = "Ditt �rendenummer �r";
$_lang['Customer'] = "Kund";
$_lang['Search'] = "S�k";
$_lang['at'] = "hos";
$_lang['all fields'] = "alla f�lt";
$_lang['Solution'] = "Svar";
$_lang['AND'] = "OCH";
$_lang['pending'] = "i v�ntek�n";
$_lang['stalled'] = "vilande";
$_lang['moved'] = "flyttat";
$_lang['solved'] = "klart";
$_lang['Submit'] = "Datum";
$_lang['Ass.'] = "hos";
$_lang['Pri.'] = "Pri.";
$_lang['access'] = "tillg�ng";
$_lang['Assigned'] = "Ansvarig";
$_lang['update'] = "uppdatera";
$_lang['remark'] = "Kommetar";
$_lang['solve'] = "Svar";
$_lang['stall'] = "vilande";
$_lang['cancel'] = "tillbaka";
$_lang['Move to request'] = "Flytta till �rende";
$_lang['Dear customer, please refer to the number given above by contacting us.Will will perform your request as soon as possible.'] = "Kan du vara v�nlig och ange detta �rende nummer vid fr�gor till oss. Vi kommer att b�rja med ditt �rende inom kort.";
$_lang['Your request has been added into the request queue.<br>You will receive a confirmation email in some moments.'] = "Din �rende finns nu i �rende k�n.<br> Du kommer inom kort att f� ett e-mail som bekr�ftelse.";
$_lang['n/a'] = "inte tillg�nglig";
$_lang['internal'] = "internt";
$_lang['has reassigned the following request'] = "har skickat f�ljande �rende till kollega";
$_lang['New request'] = "Nytt �rende";
$_lang['Assign work time'] = "Boka arbetstid";
$_lang['Assigned to:'] = "Tilldelad till:";
$_lang['Your solution was mailed to the customer and taken into the database.'] = "Ditt svar har epostats till kunden och sparats i databasen.";
$_lang['Answer to your request Nr.'] = "Svar p� ditt �rende nummer";
$_lang['Fetch new request by mail'] = "H�mta �rende med epost";
$_lang['Your request was solved by'] = "Ditt �rende har utf�rts av";
$_lang['Your solution was mailed to the customer and taken into the database'] = "Ditt f�rslag p� l�sning har skickats till kunden som har detta problem och sparats i informations databasen. Tack f�r din hj�lp";
$_lang['Search term'] = "S�k term";
$_lang['Search area'] = "S�k omr�de ";
$_lang['Extended search'] = "Ut�kad s�kning";
$_lang['knowledge database'] = "kunskapsdatabas";
$_lang['Cancel'] = "�ngra";
$_lang['New ticket'] = "Nytt �rende";
$_lang['Ticket status'] ="�rendet status";

// please adjust this states as you want -> add/remove states in helpdesk.php
$_lang['unconfirmed'] = 'inte bekr�ftad';
$_lang['new'] = 'ny';
$_lang['assigned'] = 'tilldelad';
$_lang['reopened'] = '�ter �ppnad';
$_lang['resolved'] = 'avklarad';
$_lang['verified'] = 'verifierad';

// settings.php
$_lang['The settings have been modified'] = "Inst�llningarna har modifierats";
$_lang['Skin'] = "Skinn";
$_lang['First module view on startup'] = "Standard modulvy vid uppstart";
$_lang['none'] = "Ingen";
$_lang['Check for mail'] = "Kontollera nya Email";
$_lang['Additional alert box'] = "Extra alert box";
$_lang['Horizontal screen resolution <br>(i.e. 1024, 800)'] = "Horisontell sk�rm uppl�sning<br>(i.e. 1024, 800)";
$_lang['Chat Entry'] = "Chat skrivbox";
$_lang['single line'] = "Enkel rad";
$_lang['multi lines'] = "Flerradig";
$_lang['Chat Direction'] = "Chat sortering";
$_lang['Newest messages on top'] = "Nyaste inl�gg �verst";
$_lang['Newest messages at bottom'] = "Nyaste inl�gg nederst";
$_lang['File Downloads'] = "Nedladdningar av filer";

$_lang['Inline'] = "Inline";
$_lang['Lock file'] = "L�s filen";
$_lang['Unlock file'] = "L�s upp filen";
$_lang['New file here'] = "Ny fil skapas h�r";
$_lang['New directory here'] = "Ny folder skapas h�r";
$_lang['Position of form'] = "Position f�r form";
$_lang['On a separate page'] = "P� en separat sida";
$_lang['Below the list'] = "Nedanf�r listan";
$_lang['Treeview mode on module startup'] = "Modulerna visas i tr�d struktur vid start";
$_lang['Elements per page on module startup'] = "Antal elementen per sida n�r modulerna startas";
$_lang['General Settings'] = "Allm�nna inst�llningar";
$_lang['First view on module startup'] = "F�rsta vyn vid modulestart";
$_lang['Left frame width [px]'] = "V�nster frame bredd [px]";
$_lang['Timestep Daywiew [min]'] = "Tidssteg i dags vyn [min]";
$_lang['Timestep Weekwiew [min]'] = "Tidssteg i vecko vyn [min]";
$_lang['px per char for event text<br>(not exact in case of proportional font)'] = "px per charakt�r f�r h�ndelse text<br>(inte exact f�r proportionella fonter)";
$_lang['Text length of events will be cut'] = "Textens l�ngd f�r h�ndelser kan klippas av";
$_lang['Standard View'] = "Standard vy";
$_lang['Standard View 1'] = "Standard vy 1";
$_lang['Standard View 2'] = "Standard vy 2";
$_lang['Own Schedule'] = "Egen tidsplan";
$_lang['Group Schedule'] = "Gruppens tidsplan";
$_lang['Group - Create Event'] = "Grupp - Skapa h�ndelse";
$_lang['Group, only representation'] = "Grupp, representation";
$_lang['Holiday file'] = "Helgdags file";

// summary
$_lang['Todays Events'] = "H�ndelser idag";
$_lang['New files'] = "Nya filer";
$_lang['New notes'] = "Nya notiser";
$_lang['New Polls'] = "Nya �mr�stningar";
$_lang['Current projects'] = "Aktuella projekt";
$_lang['Help Desk Requests'] = "Helpdesk fr�gor";
$_lang['Current todos'] = "Aktuella uppgifter";
$_lang['New forum postings'] = "Nya forum inl�gg";
$_lang['New Mails'] = "Nya Email";

//timecard

$_lang['Theres an error in your time sheet: '] = "Fel i ditt tidkort! Kontrollera tidkortet.";




$_lang['Consistency check'] = "Rimlighetskontroll";
$_lang['Please enter the end afterwards at the'] = "Fyll i sluttidpunkt";
$_lang['insert'] = "l�gg i";
$_lang['Enter records afterwards'] = "Skriv in tiden";
$_lang['Please fill in only emtpy records'] = "Fyll i endast tomma noteringar";

$_lang['Insert a period, all records in this period will be assigned to this project'] = "Fyll i period, samtliga tidsangivelser inom perioden kommer att tilldelas det aktuella projektet";
$_lang['There is no record on this day'] = "Detta datum finns inte";
$_lang['This field is not empty. Please ask the administrator'] = "F�ltet �r inte tomt, kontakta administratoren";
$_lang['There is no open record with a begin time on this day!'] = "Felaktiga datum! V.g. kontrollera.";
$_lang['Please close the open record on this day first!'] = "Fyll i starttiden f�rst";
$_lang['Please check the given time'] = "Kontrollera tiden";
$_lang['Assigning projects'] = "Tilldelning till flera projekt";
$_lang['Select a day'] = "V�lj en dag";
$_lang['Copy to the boss'] = "Kopia till chefen";
$_lang['Change in the timecard'] = "�ndra tidkort ";
$_lang['Sum for'] = "Summa f�r";

$_lang['Unassigned time'] = "Icke tilldelad tid";
$_lang['delete record of this day'] = "Ta bort tilldelningar f�r denna dag";
$_lang['Bookings'] = "Bokningar";

$_lang['insert additional working time'] = "infoga icke ordinarie arbetstid";
$_lang['Project assignment']= "Projekt tilldelning";
$_lang['Working time stop watch']= "Stopptid f�r arbetstid";
$_lang['stop watches']= "stopptid";
$_lang['Project stop watch']= "Stopptid f�r projekt";
$_lang['Overview my working time']= "�verblick av arbetstid";
$_lang['GO']= "GO";
$_lang['Day view']= "Visning per dag";
$_lang['Project view']= "Projekt vy";
$_lang['Weekday']= "Veckodag";
$_lang['Start']= "Start";
$_lang['Net time']= "N�ttid";
$_lang['Project bookings']= "Projekt bokningar";
$_lang['save+close']= "spara och st�ng";
$_lang['Working times']= "Arbetstid";
$_lang['Working times start']= "Start av arbetsdag";
$_lang['Working times stop']= "Slut p� arbetsdag";
$_lang['Project booking start']= "Start f�r projekt bokning";
$_lang['Project booking stop']= "Stop f�r projekt bokning";
$_lang['choose day']= "v�lj dag";
$_lang['choose month']= "v�lj m�nad";
$_lang['1 day back']= "i g�r";
$_lang['1 day forward']= "i morgon";
$_lang['Sum working time']= "Summa arbetstid";
$_lang['Time: h / m']= "Tid: tim / minut";
$_lang['activate project stop watch']= "aktivera projektets stoppur";
$_lang['activate']= "aktivera";
$_lang['project choice']= "valt projekt";
$_lang['stop stop watch']= "stanna stoppuret";
$_lang['still to allocate:']= "lediga f�r tilldelning:";
$_lang['You are not allowed to delete entries from timecard. Please contact your administrator']= "Du har inte till�telse att ta bort entries fr�n tidkortet. Kontakta din administrator";
$_lang['You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "Du kan inte ta bort entries, d� dom funnits i %s dagar. Du kan bara �ndra entries som �r yngre �n %s dagar.";
$_lang['You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.']= "Du kan inte radera bokningar jst nu. D� det g�tt %s dagar. Du kan bara �ndra bokningar of entries som �r yngre �n %s dagar.";
$_lang['You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "Du kan inte l�gga till entries d� entries funnits i %s dagar. Du kan bara �ndra entries som �r yngre �n %s dagar.";
$_lang['You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.']= "Du kan inte l�gga till bokningar just nu. D� det har g�tt %s dagar. Du kan bara l�gga till bokningar f�r entries som �r yngre �n %s dagar.";
$_lang['activate+close']="aktivera och st�ng";

// todos
$_lang['accepted'] = "Accepterad";
$_lang['rejected'] = "Avvisad";
$_lang['own'] = "egen";
$_lang['progress'] = "framg�ng";
$_lang['delegated to'] = "delegerad till";
$_lang['Assigned from'] = "tilldelad fr�n";
$_lang['done'] = "klar";
$_lang['Not yet assigned'] = "�nnu ej tilldelad";
$_lang['Undertake'] = "Utf�r";
$_lang['New todo'] = "Ny uppgift"; 
$_lang['Notify recipient'] = "Meddela mottagare";

// votum.php
$_lang['results of the vote: '] = "Resultat av omr�stningen: ";
$_lang['Poll Question: '] = "R�sta om fr�gan: ";
$_lang['several answers possible'] = "(flera val �r m�jliga)";
$_lang['Alternative '] = "Alternativ ";
$_lang['no vote: '] = "R�st saknas: ";
$_lang['of'] = "av";
$_lang['participants have voted in this poll'] = "deltagarna har r�stat";
$_lang['Current Open Polls'] = "Aktuella omr�stningar";
$_lang['Results of Polls'] = "Visa resultat av alla r�ster";
$_lang['New survey'] ="Ny unders�kning";
$_lang['Alternatives'] ="Alternativ";
$_lang['currently no open polls'] = "Det finns inga omr�stningar f�r tillf�llet";

// export_page.php
$_lang['export_timecard']       = "Exportera Tidkort";
$_lang['export_timecard_admin'] = "Exportera Tidkort";
$_lang['export_users']          = "Exportera anv�ndare i denna grupp";
$_lang['export_contacts']       = "Exportera kontakter";
$_lang['export_projects']       = "Exportera projektdata";
$_lang['export_bookmarks']      = "Exportera bokm�rken";
$_lang['export_timeproj']       = "Exportera tid-f�r-projekt data";
$_lang['export_project_stat']   = "Exportera projekt status";
$_lang['export_todo']           = "Exportera att g�ra";
$_lang['export_notes']          = "Exportera noteringar";
$_lang['export_calendar']       = "Exportera alla kalenerh�ndelser";
$_lang['export_calendar_detail']= "Exportera en kalendarh�ndelse";
$_lang['submit'] = "acceptera";
$_lang['Address'] = "Adress";
$_lang['Next Project'] = "N�sta Projekt";
$_lang['Dependend projects'] = "Beronende mellan projekt";
$_lang['db_type'] = "Database typ";
$_lang['Log in, please'] = "Logga in";
$_lang['Recipient'] = "Mottagare";
$_lang['untreated'] = "inte behandlade";
$_lang['Select participants'] = "V�lj deltagare";
$_lang['Participation'] = "Deltagare";
$_lang['not yet decided'] = "�nnu inte beslutat";
$_lang['accept'] = "accepterat";
$_lang['reject'] = "avvisa";
$_lang['Substitute for'] = "Ers�ttare f�r";
$_lang['Calendar user'] = "Anv�ndare av Kalendern";
$_lang['Refresh'] = "Uppdatera";
$_lang['Event'] = "H�ndelse";
$_lang['Upload file size is too big'] = "Uppladdad fil �r f�r stor size";
$_lang['Upload has been interrupted'] = "Uppladdning av filen har avbrutits";
$_lang['view'] = "vy";
$_lang['found elements'] = "hittat elementen";
$_lang['chosen elements'] = "v�lj elementen";
$_lang['too many hits'] = "Resultate �r f�r stort f�r att visas.";
$_lang['please extend filter'] = "Expandera dina filer.";
$_lang['Edit profile'] = "�ndra profilen";
$_lang['add profile'] = "l�gg till profil";
$_lang['Add profile'] = "L�gg till profil";
$_lang['Added profile'] = "Nya profil(er).";
$_lang['No profile found'] = "Hittade inga profiler.";
$_lang['add project participants'] = "l�gg till projekt deltagare";
$_lang['Added project participants'] = "Laggt till projekt deltagare.";
$_lang['add group of participants'] = "l�gg till grupp av deltagare";
$_lang['Added group of participants'] = "Laggt till grupp av deltagare.";
$_lang['add user'] = "l�gg till anv�ndare ";
$_lang['Added users'] = "Laggt till anv�ndare.";
$_lang['Selection'] = "Urval";
$_lang['selector'] = "urval";
$_lang['Send email notification']= "Meddelande med epost";
$_lang['Member selection'] = "Val av deltagare";
$_lang['Collision check'] = "kollisions kontroll";
$_lang['Collision'] = "Kollisioon";
$_lang['Users, who can represent me'] = "Deltagare som kan representera mig";
$_lang['Users, who can see my private events'] = "Deltagare som kan se<br />mina privata h�ndelser";
$_lang['Users, who can read my normal events'] = "Deltagare som kan l�sa<br />mina normala h�ndelser";
$_lang['quickadd'] = "L�gga till, f�renklat";
$_lang['set filter'] = "Set filter";
$_lang['Select date'] = "V�lj datum";
$_lang['Next serial events'] = "N�sta �terkommande h�ndelse";
$_lang['All day event'] = "Alla h�ndelser idag";
$_lang['Event is canceled'] = "H�ndelsen&nbsp;�r&nbsp;inst�lld";
$_lang['Please enter a password!'] = "Skriv in ditt l�senord";
$_lang['You are not allowed to create an event!'] = "Du har inte r�ttiheter att l�gga in en ny h�ndelse!";
$_lang['Event successfully created.'] = "H�ndelsen har skapats.";
$_lang['You are not allowed to edit this event!'] = "Du har inte r�ttighet att �ndra i denna h�ndelse!";
$_lang['Event successfully updated.'] = "H�ndelsen har �ndrats.";
$_lang['You are not allowed to remove this event!'] = "Du har inte r�ttigheter att ta bort denna h�ndelse!";
$_lang['Event successfully removed.'] = "H�ndelsen har tagits bort.";
$_lang['Please give a text!'] = "Skriv in en text!";
$_lang['Please check the event date!'] = "Kontrollera datumet f�r h�ndelsen!";
$_lang['Please check your time format!'] = "Kontrollera formatet p� h�ndelsens tisdangivelse!";
$_lang['Please check start and end time!'] = "Kontrolelra start och sluttiden f�r h�ndelsen!";
$_lang['Please check the serial event date!'] = "Kontrollera datumet f�r den �terkommande h�ndelsen!";
$_lang['The serial event data has no result!'] = "Inneh�llet i den �terkomamnde h�ndelsen �r tomt!";
$_lang['Really delete this event?'] = "Vill du verkligen ta bort denna h�ndelse?";
$_lang['use'] = "Anv�nda";
$_lang[':'] = ":";
$_lang['Mobile Phone'] = "Mobil";
$_lang['submit'] = "utf�r";
$_lang['Further events'] = "Flera h�ndelser";
$_lang['Remove settings only'] = "Ta bara bort inst�llningarna";
$_lang['Settings removed.'] = "Inst�llningarna borttagna.";
$_lang['User selection'] = "Anv�ndarens val";
$_lang['Release'] = "Frig�r";
$_lang['none'] = "ingen";
$_lang['only read access to selection'] = "bara skrivr�ttigheter p� urvalet";
$_lang['read and write access to selection'] = "l�s och skrivr�ttigheter p� urvalet";
$_lang['Available time'] = "Tillg�nglig tid";
$_lang['flat view'] = "List Vy";
$_lang['o_dateien'] = "Filhanterare";
$_lang['Location'] = "Placering";
$_lang['date_received'] = "datum_motttaget";
$_lang['subject'] = "�mne";
$_lang['kat'] = "Kategori";
$_lang['projekt'] = "Projekt";
$_lang['Location'] = "Placering";
$_lang['name'] = "Titel";
$_lang['contact'] = "Kontakt";
$_lang['div1'] = "Framst�llning";
$_lang['div2'] = "�ndring";
$_lang['kategorie'] = "Kategori";
$_lang['anfang'] = "Start";
$_lang['ende'] = "Slut";
$_lang['status'] = "Status";
$_lang['filename'] = "Filnamn";
$_lang['deadline'] = "Termin";
$_lang['ext'] = "i";
$_lang['priority'] = "Prioritet";
$_lang['project'] = "Projekt";
$_lang['Accept'] = "Acceptera";
$_lang['Please enter your user name here.'] = "Skriv in ditt anv�ndarnamn h�r.";
$_lang['Please enter your password here.'] = "Skriv in ditt l�senord h�r.";
$_lang['Click here to login.'] = "klicka h�r f�r att logga in.";
$_lang['No New Polls'] = "Ingen ny oomr�stning";
$_lang['&nbsp;Hide read elements'] = "&nbsp;D�lj l�sta element";
$_lang['&nbsp;Show read elements'] = "&nbsp;Visa l�sta element";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;D�lj arkiverade element";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Visa arkiverade element";
?>