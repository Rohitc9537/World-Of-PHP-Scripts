<?php  
// lv.inc.php, latvian version
// translation by Janis Indans <mr.lsd@navigator.lv>

$chars = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
$name_month = array("", "Jan", "Feb", "Mar", "Apr", "Mai", "J�n", "J�l", "Aug", "Sep", "Okt", "Nov", "Dec");
$l_text31a = array("default", "15 min.", "30 min.", " 1 hour", " 2 hours", " 4 hours", " 1 day");
$l_text31b = array(0, 15, 30, 60, 120, 240, 1440);
$name_day = array("Sv�tdiena", "Pirmdiena", "Otrdiena", "Tre�diena", "Ceturtdiena", "Piektdiena", "Sestdiena");
$name_day2 = array("P", "O", "T", "C", "P", "S","Sv");

$_lang['No Entries Found']= "No Entries Found";
$_lang['No Todays Events']= "HNo Todays Events";
$_lang['No new forum postings']= "No new forum postings";
$_lang['in category']= "in category";
$_lang['Filtered']= "Filtered";
$_lang['Sorted by']= "Sorted by";
$_lang['go'] = "Aiziet";
$_lang['back'] = "Atpaka�";
$_lang['print'] = "print�t";
$_lang['export'] = "eksport�t";
$_lang['| (help)'] = "| (pal�dz�ba)";
$_lang['Are you sure?'] = "Vai esat p�rliecin�ts?";
$_lang['items/page'] = "skaits/lap�";
$_lang['records'] = "ieraksti";
$_lang['previous page'] = "iepriek��j� lapa";
$_lang['next page'] = "n�ko�� lapa";
$_lang['first page'] = "first page";
$_lang['last page'] = "last page";
$_lang['Move']  = "&nbsp;&nbsp;P�rvietot";
$_lang['Copy'] = "&nbsp;&nbsp;Kop�t";
$_lang['Delete'] = "Dz�st";
$_lang['Save'] = "saglab�t";
$_lang['Directory'] = "Direktorija";
$_lang['Also Delete Contents'] = "nodz�st ar� saturu";
$_lang['Sum'] = "Kop�";
$_lang['Filter'] = "Filtrs";
$_lang['Please fill in the following field'] = "L�dzu aizpildiet sekojo�os laukus";
$_lang['approve'] = "apstiprin�t";
$_lang['undo'] = "anul�t";
$_lang['Please select!'] = "L�dzu izv�laties";
$_lang['New'] = "Jauns";
$_lang['Select all'] = "Izv�l�ties visu";
$_lang['Printable view'] = "Print��anas skats";
$_lang['New record in module '] = "Jauns ieraksts modul� ";
$_lang['Notify all group members'] = "Pazi�ot visiem grupas locek�iem";
$_lang['Yes'] = "J�";
$_lang['No'] = "N�";
$_lang['Close window'] = "Close window";
$_lang['No Value'] = "No Value";
$_lang['Standard'] = "Standard";
$_lang['Create'] = "Anlegen";
$_lang['Modify'] = "�ndern";   
$_lang['today'] = "today";

// admin.php
$_lang['Password'] = "Parole";
$_lang['Login'] = "Autoriz�cija";
$_lang['Administration section'] = "Administr�tora sekcija";
$_lang['Your password'] = "J�su parole";
$_lang['Sorry you are not allowed to enter. '] = "Atvainojiet, bet jums pieeja ir liegta. ";
$_lang['Help'] = "Pal�dz�ba";
$_lang['User management'] = "Lietot�ju vad�ba";
$_lang['Create'] = "Izveidot";
$_lang['Projects'] = "Projekts";
$_lang['Resources'] = "Resurs";
$_lang['Resources management'] = "Resources management";
$_lang['Bookmarks'] = "Gr�matz�me";
$_lang['for invalid links'] = "priek� nestr�d�jo�iem linkiem";
$_lang['Check'] = "P�rbaude";
$_lang['delete Bookmark'] = "dz�st Gr�matz�mi";
$_lang['(multiple select with the Ctrl-key)'] = "(daudzej�da izv�le ar 'Ctrl'-tausti�u)";
$_lang['Forum'] = "Forums";
$_lang['Threads older than'] = "Threads older than";
$_lang[' days '] = " dienas ";
$_lang['Chat'] = "�ats";
$_lang['save script of current Chat'] = "saglab�t eso�� �ata skriptu";
$_lang['Chat script'] = "�ata skripts";
$_lang['New password'] = "jauna parole";
$_lang['(keep old password: leave empty)'] = "(patur�t veco paroli: atst�t tuk�u)";
$_lang['Default Group<br> (must be selected below as well)'] = "Standarta Grupa<br> (j�izv�las k�du no apak�as)";
$_lang['Access rights'] = "Piek�uves ties�bas";
$_lang['Zip code'] = "Zip kods";
$_lang['Language'] = "Valoda";
$_lang['schedule readable to others'] = "pl�nojumu var las�t ar� citi";
$_lang['schedule invisible to others'] = "pl�nojumu nevar citi las�t";
$_lang['schedule visible but not readable'] = "pl�nojums redzams, bet nav las�ms";
$_lang['these fields have to be filled in.'] = "<font color=\"#CC0000\"><b>�os laukus ir oblig�ti j�aizpilda.</b></font>";
$_lang['You have to fill in the following fields: family name, short name and password.'] = "Jums ir j�aizpilda sekojo�ie lauki: uzv�rds, v�rds sa�sin�ti un parole.";
$_lang['This family name already exists! '] = "�is uzv�rds jau eksist�! ";
$_lang['This short name already exists!'] = "�is v�rda sa�sin�jums jau eksist�!";
$_lang['This login name already exists! Please chosse another one.'] = "Lietot�ja autoriz�cijas v�rds jau eksist�! L�dzu izv�laties citu.";
$_lang['This password already exists!'] = "�� parole jau eksist�!";
$_lang['This combination first name/family name already exists.'] = "V�rda un uzv�rda kombin�cija jau eksist�.";
$_lang['the user is now in the list.'] = "lietot�js nav sarakst�.";
$_lang['the data set is now modified.'] = "ievad�tie dati ir izveidoti un modific�ti.";
$_lang['Please choose a user'] = "L�dzu izv�laties lietot�ju";
$_lang['is still listed in some projects. Please remove it.'] = "ir atrodams v�l projektu sarakstos. L�dzu nodz��at to.";
$_lang['All profiles are deleted'] = "Viss profils ir nodz�sts";
$_lang['A Profile with the same name already exists'] = "A profile with the same name already exists";
$_lang['is taken out of all user profiles'] = "tas ir iz�emts no lietot�ju profiliem";
$_lang['All todo lists of the user are deleted'] = "Viss lietot�ju darb�bas pl�na saraksts ir dz�sts";
$_lang['is taken out of these votes where he/she has not yet participated'] = "tas ir �emts no balso�anas, jo vi��/vi�a nav v�l piedal�jusies";
$_lang['All events are deleted'] = "Visi notikumi ir nodz�sti";
$_lang['user file deleted'] = "lietot�ja faili ir nodz�sti";
$_lang['bank account deleted'] = "bankas konts ir dz�sts";
$_lang['finished'] = "pabeigts";
$_lang['Please choose a project'] = "L�dzu izv�laties projektu";
$_lang['The project is deleted'] = "Projekts ir nodz�sts";
$_lang['All links in events to this project are deleted'] = "Visi linki un pas�kumi �aj� projekt� ir dz�sti";
$_lang['The duration of the project is incorrect.'] = "projekta ilgums ir nepareizs.";
$_lang['The project is now in the list'] = "Projekts ir iek�auts sarakstos";
$_lang['The project has been modified'] = "Projekts ir modific�ts";
$_lang['Please choose a resource'] = "L�dzu izv�laties resursu";
$_lang['The resource is deleted'] = "Resurss ir nodz�sts";
$_lang['All links in events to this resource are deleted'] = "Visi notikumu linki �im resursam ir nodz�sti";
$_lang[' The resource is now in the list.'] = "Resurss ir iek�auts sarakstos.";
$_lang[' The resource has been modified.'] = "Resurss ir modific�ts";
$_lang['The server sent an error message.'] = "Serveris nos�ta �o k��das pazi�ojumu.";
$_lang['All Links are valid.'] = "Visi linki ir der�gi.";
$_lang['Please select at least one bookmark'] = "Izv�laties vismaz vienu gr�matz�mi";
$_lang['The bookmark is deleted'] = "Gr�matz�me ir nodz�sta";
$_lang['threads older than x days are deleted.'] = "pavedieni, kas ir vec�ki k� x dienas ir dz�sti.";
$_lang['All chat scripts are removed'] = "Visi �ata skripti ir nodz�sti";
$_lang['or'] = "vai";
$_lang['Timecard management'] = "Kontrolsaraksta vad�ba";
$_lang['View'] = "Skats";
$_lang['Choose group'] = "Izv�laties grupu";
$_lang['Group name'] = "Grupas nosaukums";
$_lang['Short form'] = "Sa�sin�t� forma";
$_lang['Category'] = "Kategorija";
$_lang['Remark'] = "Piez�mes";
$_lang['Group management'] = "Grupas vad�ba";
$_lang['Please insert a name'] = "L�dzu ievadiet nosaukumu";
$_lang['Name or short form already exists'] = "nosaukums vai sa�sin�t� forma jau eksist�";
$_lang['Automatic assign to group:'] = "Autom�tiski pievienot grupai:";
$_lang['Automatic assign to user:'] = "Autom�tiski pie��irt lietot�jam:";
$_lang['Help Desk Category Management'] = "Pal�dz�bas dienesta kategoriju vad�ba";
$_lang['Category deleted'] = "Kategorija nodz�sta";
$_lang['The category has been created'] = "Kategorija ir izveidota";
$_lang['The category has been modified'] = "Kategorija ir modific�ta";
$_lang['Member of following groups'] = "Eso��s grupas loceklis";
$_lang['Primary group is not in group list'] = "Galven� grupa nav grupu sarakst�";
$_lang['Login name'] = "Autoriz�cijas v�rds";
$_lang['You cannot delete the default group'] = "J�s nevarat nodz�st standarta grupu";
$_lang['Delete group and merge contents with group'] = "Dz�st grupu un pasl�pt saturu ar grupu";
$_lang['Please choose an element'] = "L�duz izv�laties elementu";
$_lang['Group created'] = "Grupa izveidota";
$_lang['File management'] = "Failu vad�ba";
$_lang['Orphan files'] = "Nevienam nepiedero�ie faili";
$_lang['Deletion of super admin root not possible'] = "Galven� administr�tora dz��ana nav iesp�jama";
$_lang['ldap name'] = "ldap nosaukums";
$_lang['mobile // mobile phone'] = "mobailais"; // mobile phone
$_lang['Normal user'] = "Parasts lietot�js";
$_lang['User w/Chief Rights'] = "Lietot�js ar vad�t�ja ties�b�m";
$_lang['Administrator'] = "Administr�tors";
$_lang['Logging'] = "Autoriz�ties";
$_lang['Logout'] = "Iziet no konta";
$_lang['posting (and all comments) with an ID'] = "rakst�t (visos koment�ros) ar ID";
$_lang['Role deleted, assignment to users for this role removed'] = "Loma dz�sta, pie��irt�s ties�bas uz �iem noteikumiem lietot�jam dz�stas";
$_lang['The role has been created'] = "Noteikumi ir izveidota";
$_lang['The role has been modified'] = "Noteikumi ir modific�ti";
$_lang['Access rights'] = "Access rights";
$_lang['Usergroup'] = "Gruppe";
$_lang['logged in as'] = "Angemeldet als";

//chat.php
$_lang['Quit chat']= "Quit chat";

//contacts.php
$_lang['Contact Manager'] = "Kontaktu Vad�ba";
$_lang['New contact'] = "Jauns kontakts";
$_lang['Group members'] = "Grupas locek�i";
$_lang['External contacts'] = "�r�jie kontakti";
$_lang['&nbsp;New&nbsp;'] = "&nbsp;Jauns&nbsp;";
$_lang['Import'] = "Import�t";
$_lang['The new contact has been added'] = "Jaunai kontakts ir pievienots";
$_lang['The date of the contact was modified'] = "Datums, kad kontakts bija modific�ts";
$_lang['The contact has been deleted'] = "Kontakts ir nodz�sts";
$_lang['Open to all'] = "Atv�rt visiem";
$_lang['Picture'] = "Bilde";
$_lang['Please select a vcard (*.vcf)'] = "Izv�laties viz�tkarti (*.vcf)";
$_lang['create vcard'] = "veidot viz�tkari";
$_lang['import address book'] = "import�t adre�u gr�matu";
$_lang['Please select a file (*.csv)'] = "L�dzu izv�laties failu (*.csv)";
$_lang['Howto: Open your outlook express address book and select file/export/other book<br>Then give the file a name, select all fields in the next dialog and finish'] = "K�: Atveriet savu outlook express address gr�matu un izv�laties 'file'/'export'/'other book'<br>
,  tad dodat failam nosaukumu, izv�laties all fields => next dialog un 'finish'";
$_lang['Open outlook at file/export/export in file,<br>choose comma separated values (Win), then select contacts in the next form,<br>give the export file a name and finish.'] = "Atveriet outlook 'file/export/export in file',<br>
izv�laties 'comma separated values (Win)', tad izv�laties 'contacts' nako�aj� form�,<br>
dodat eksport�tajam failam nosaukumu un beidzat darbu.";
$_lang['Please choose an export file (*.csv)'] = "L�dzu izv�laties eksport�t failu (*.csv)";
$_lang['Please export your address book into a comma separated value file (.csv), and either<br>1) apply an import pattern OR<br>2) modify the columns of the table with a spread sheet to this format<br>(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):'] = "Please export your address book into a comma separated value file (.csv), and either<br>
1) apply an import pattern OR<br>
2) modify the columns of the table with a spread sheet to this format<br>
(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):";
$_lang['Please insert at least the family name'] = "Vismaz ierakstiet uzv�rdu";
$_lang['Record import failed because of wrong field count'] = "Ieraksta import��ana neizdev�s, jo napareizs lauku skaits";
$_lang['Import to approve'] = "Apstipriniet ipmport��anu";
$_lang['Import list'] = "Import�jamais saraksts";
$_lang['The list has been imported.'] = "Saraksts import�ts.";
$_lang['The list has been rejected.'] = "Saraksts izb�r��ts.";
$_lang['Profiles'] = "Profils";
$_lang['Parent object'] = "Augst�kst�vo�s objekts";
$_lang['Check for duplicates during import'] = "Check for doublets during import";
$_lang['Fields to match'] = "Fields to match";
$_lang['Action for duplicates'] = "Action for doublets";
$_lang['Discard duplicates'] = "Discard doublet";
$_lang['Dispose as child'] = "Dispose as child";
$_lang['Store as profile'] = "Store as profile";    
$_lang['Apply import pattern'] = "Apply import pattern";
$_lang['Import pattern'] = "Import pattern";
$_lang['For modification or creation<br>upload an example csv file'] = "Upload import file (csv)"; 
$_lang['Skip field'] = "Skip field";
$_lang['Field separator'] = "Field separator"; 
$_lang['Contact selector'] = "Contact selector";
$_lang['Use doublet'] = "Use doublet";
$_lang['Doublets'] = "Doublets";

// filemanager.php
$_lang['Please select a file'] = "L�dzu izv�laties failu";
$_lang['A file with this name already exists!'] = "Fails ar �o nosukumu jau eksist�!";
$_lang['Name'] = "Nosaukums";
$_lang['Comment'] = "Koment�rs";
$_lang['Date'] = "Datums";
$_lang['Upload'] = "Pievienot uz servera";
$_lang['Filename and path'] = "Faila nosaukums un ce��";
$_lang['Delete file'] = "Dz�st failu";
$_lang['Overwrite'] = "P�rrakst�t";
$_lang['Access'] = "Piek�uve";
$_lang['Me'] = "es";
$_lang['Group'] = "group";
$_lang['Some'] = "&nbsp;&nbsp;k�ds";
$_lang['As parent object'] = "t�pat k� direktorija";
$_lang['All groups'] = "All groups";
$_lang['You are not allowed to overwrite this file since somebody else uploaded it'] = "Jums nav at�auts modific�t �o failu, kam�r k�ds jau to ir pievienojis uz servera";
$_lang['personal'] = "person�gs";
$_lang['Link'] = "Links";
$_lang['name and network path'] = "nosaukums un t�kla ce��";
$_lang['with new values'] = "ar jaunu v�rt�bu";
$_lang['All files in this directory will be removed! Continue?'] = "Visi faili �aj� direktorij� ir nodz�sti! Turpin�t?";
$_lang['This name already exists'] = "�is v�rds jau eksist�";
$_lang['Max. file size'] = "Maksim�lais faila izm�rs";
$_lang['links to'] = "links uz";
$_lang['objects'] = "faili";
$_lang['Action in same directory not possible'] = "Darb�ba taj� pa�� direktorij� nav iesp�jama";
$_lang['Upload = replace file'] = "Pievienot uz servera = aizst�t failu";
$_lang['Insert password for crypted file'] = "Ievad�t paroli priek� kript�ta faila";
$_lang['Crypt upload file with password'] = "Nokript�t uz servera pievienoto veco failu ar paroli";
$_lang['Repeat'] = "Atk�rtot";
$_lang['Passwords dont match!'] = "Parole nesakr�t!";
$_lang['Download of the password protected file '] = "Iel�d�t paroli aizsarg�tajam failam ";
$_lang['notify all users with access'] = "re�istr�t visus lietot�jus ar piek�uves ties�b�m";
$_lang['Write access'] = "Rakst�t pie�uves ties�ba";
$_lang['Version'] = "Verija";
$_lang['Version management'] = "Versijas vad�ba";
$_lang['lock'] = "aizsl�gt";
$_lang['unlock'] = "atsl�gt";
$_lang['locked by'] = "aizsl�dza";
$_lang['Alternative Download'] = "Alternat�va iel�de";
$_lang['Download'] = "Download";
$_lang['Select type'] = "Select type";
$_lang['Create directory'] = "Create directory";
$_lang['filesize (Byte)'] = "Filesize (Byte)";

// filter
$_lang['contains'] = 'contains';
$_lang['exact'] = 'exact';
$_lang['starts with'] = 'starts with';
$_lang['ends with'] = 'ends with';
$_lang['>'] = '>';
$_lang['>='] = '>=';
$_lang['<'] = '<';
$_lang['<='] = '<=';
$_lang['does not contain'] = 'does not contain';
$_lang['Please set (other) filters - too many hits!'] = "Please set (other) filters - too many hits!";

$_lang['Edit filter'] = "Edit filter";
$_lang['Filter configuration'] = "Filter configuration";
$_lang['Disable set filters'] = "Disable set filters";
$_lang['Load filter'] = "Load filter";
$_lang['Delete saved filter'] = "Delete saved filter";
$_lang['Save currently set filters'] = "Save currently set filters";
$_lang['Save as'] = "Save as";
$_lang['News'] = 'Nachrichten';

// form designer
$_lang['Module Designer'] = "Module Designer";
$_lang['Module element'] = "Module element"; 
$_lang['Module'] = "Module";
$_lang['Active'] = "Activ";
$_lang['Inactive'] = "Inactiv";
$_lang['Activate'] = "Aktivate";
$_lang['Deactivate'] = "Deaktivate"; 
$_lang['Create new element'] = "Create new element";
$_lang['Modify element'] = "Modify element";
$_lang['Field name in database'] = "Field name in database";
$_lang['Use only normal characters and numbers, no special characters,spaces etc.'] = "Use only normal characters and numbers, no special characters,spaces etc.";
$_lang['Field name in form'] = "Field name in form";
$_lang['(could be modified later)'] = "(could be modified later)"; 
$_lang['Single Text line'] = "Single Text line";
$_lang['Textarea'] = "Textarea";
$_lang['Display'] = "Display";
$_lang['First insert'] = "First insert";
$_lang['Predefined selection'] = "Predefined selection";
$_lang['Select by db query'] = "Select by db query";
$_lang['File'] = "File";

$_lang['Email Address'] = "Email Address";
$_lang['url'] = "url";
$_lang['Checkbox'] = "Checkbox";
$_lang['Multiple select'] = "Multiple select";
$_lang['Display value from db query'] = "Display value from db query";
$_lang['Time'] = "Time";
$_lang['Tooltip'] = "Tooltip"; 
$_lang['Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied'] = "Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied";
$_lang['Position'] = "Position";
$_lang['is current position, other free positions are:'] = "is current position, other free positions are:"; 
$_lang['Regular Expression:'] = "Regular Expression:";
$_lang['Please enter a regular expression to check the input on this field'] = "Please enter a regular expression to check the input on this field";
$_lang['Default value'] = "Default value";
$_lang['Predefined value for creation of a record. Could be used in combination with a hidden field as well'] = "Predefined value for creation of a record. Could be used in combination with a hidden field as well";
$_lang['Content for select Box'] = "Content for select Box";
$_lang['Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type'] = "Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type";
$_lang['Position in list view'] = "Position in list view";
$_lang['Only insert a number > 0 if you want that this field appears in the list of this module'] = "Only insert a number > 0 if you want that this field appears in the list of this module";
$_lang['Alternative list view'] = "Alternative list view";
$_lang['Value appears in the alt tag of the blue button (mouse over) in the list view'] = "Value appears in the alt tag of the blue button (mouse over) in the list view";
$_lang['Filter element'] = "Filter element";
$_lang['Appears in the filter select box in the list view'] = "Appears in the filter select box in the list view";
$_lang['Element Type'] = "Element Type";
$_lang['Select the type of this form element'] = "Select the type of this form element";
$_lang['Check the content of the previous field!'] = "Check the content of the previous field!";
$_lang['Span element over'] = "Span element over";
$_lang['columns'] = "columns";
$_lang['rows'] = "rows";
$_lang['Telephone'] = "Telephone";
$_lang['History'] = "History";
$_lang['Field'] = "Field";
$_lang['Old value'] = "Old value";
$_lang['New value'] = "New value";
$_lang['Author'] = "Author"; 
$_lang['Show Date'] = "Show Date";
$_lang['Creation date'] = "Creation date";
$_lang['Last modification date'] = "Last modification date";
$_lang['Email (at record cration)'] = "Email (at record cration)";
$_lang['Contact (at record cration)'] = "Contact (at record cration)"; 
$_lang['Select user'] = "Select user";
$_lang['Show user'] = "Show user";

// forum.php
$_lang['Please give your thread a title'] = "Please give your thread a title";
$_lang['New Thread'] = "New Thread";
$_lang['Title'] = "Title";
$_lang['Text'] = "Text";
$_lang['Post'] = "Post";
$_lang['From'] = "From";
$_lang['open'] = "open";
$_lang['closed'] = "closed";
$_lang['Notify me on comments'] = "Notify me on comments";
$_lang['Answer to your posting in the forum'] = "Answer to your posting in the forum";
$_lang['You got an answer to your posting'] = "You got an answer to your posting \n ";
$_lang['New posting'] = "New posting";
$_lang['Create new forum'] = "Create new forum";
$_lang['down'] ='down';
$_lang['up']= "up";
$_lang['Forums']= "Forums";
$_lang['Topics']="Topics";
$_lang['Threads']="Threads";
$_lang['Latest Thread']="Latest Thread";
$_lang['Overview forums']= "Overview forums";
$_lang['Succeeding answers']= "Succeeding answers";
$_lang['Count']= "Count";
$_lang['from']= "from";
$_lang['Path']= "Path";
$_lang['Thread title']= "Thread title";
$_lang['Notification']= "Notification";
$_lang['Delete forum']= "Delete forum";
$_lang['Delete posting']= "Delete posting";
$_lang['In this table you can find all forums listed']= "In this table you can find all forums listed";
$_lang['In this table you can find all threads listed']= "In this table you can find all threads listed";

// index.php
$_lang['Last name'] = "Last name";
$_lang['Short name'] = "Short name";
$_lang['Sorry you are not allowed to enter.'] = "Sorry you are not allowed to enter.";
$_lang['Please run index.php: '] = "Please run index.php: ";
$_lang['Reminder'] = "Reminder";
$_lang['Session time over, please login again'] = "Session time over, please login again";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
$_lang['Tree view'] = "Tree view";
$_lang['flat view'] = "flat view";
$_lang['New todo'] = "New todo";
$_lang['New note'] = "New note";
$_lang['New document'] = "New document";
$_lang['Set bookmark'] = "Set bookmark";
$_lang['Move to archive'] = "Move to archive";
$_lang['Mark as read'] = "Mark as read";
$_lang['Export as csv file'] = "Export as csv file";
$_lang['Deselect all'] = "Deselect all";
$_lang['selected elements'] = "selected elements";
$_lang['wider'] = "wider";
$_lang['narrower'] = "narrower";
$_lang['ascending'] = "Aufsteigend";
$_lang['descending'] = "descending";
$_lang['Column'] = "Column";
$_lang['Sorting'] = "Sorting";
$_lang['Save width'] = "Save width";
$_lang['Width'] = "Width";
$_lang['switch off html editor'] = "switch off html editor";
$_lang['switch on html editor'] = "switch on html editor";
$_lang['hits were shown for'] = "hits were shown for";
$_lang['there were no hits found.'] = "there were no hits found.";
$_lang['Filename'] = "Filename";
$_lang['First Name'] = "First Name";
$_lang['Family Name'] = "Family Name";
$_lang['Company'] = "Company";
$_lang['Street'] = "Street";
$_lang['City'] = "City";
$_lang['Country'] = "Country";
$_lang['Please select the modules where the keyword will be searched'] = "Please select the modules where the keyword will be searched";
$_lang['Enter your keyword(s)'] = "Enter your keyword(s)";
$_lang['Salutation'] = "Salutation";
$_lang['State'] = "State";
$_lang['Add to link list'] = "Add to link list";

// setup.php
$_lang['Welcome to the setup of PHProject!<br>'] = "Sveicin�ti PHProjekta uzst�d��an�!<br>";
$_lang['Please remark:<ul><li>A blank database must be available<li>Please ensure that the webserver is able to write the file config.inc.php'] = "Piez�me:<ul>
<li>J�b�t pieejamai tuk�ai datu b�zei
<li>P�rliecinaties vai webserveris var ierakst�t 'config.inc.php'";
$_lang['<li>If you encounter any errors during the installation, please look into the <a href=help/faq_install.html target=_blank>install faq</a>or visit the <a href=http://www.PHProjekt.com/forum.html target=_blank>Installation forum</a></i>'] = "<li>Ja J�s sastapsiet k�du k��mi uzst�d��anas laik�, l�dzu lasat <a href='help/faq_install.html' target=_blank>uzst�d��anas faq</a>
vai apmekl�jat <a href='http://www.PHProjekt.com/forum.html' target=_blank>Uzst�d��anas forumu</a></i>";
$_lang['Please fill in the fields below'] = "L�dzu aizpildat apak��jos laukus";
$_lang['(In few cases the script wont respond.<br>Cancel the script, close the browser and try it again).<br>'] = "(Da�os gad�jumos skripts nedarbojas.<br>
Atce�at skriptu un aiztaisat savu p�rl�kprogrammu un mai�inat v�l).<br>";
$_lang['Type of database'] = "Ierakstat datu b�zi";
$_lang['Hostname'] = "Hosta v�rds";
$_lang['Username'] = "Lietot�ja v�rds";

$_lang['Name of the existing database'] = "Eksist�jo��s datu b�zes nosaukums";
$_lang['config.inc.php not found! Do you really want to update? Please read INSTALL ...'] = "config.inc.php nav atrodams! Vai tie��m v�laties mniz�t? L�dzu las�t INSTALL ...";
$_lang['config.inc.php found! Maybe you prefer to update PHProject? Please read INSTALL ...'] = "config.inc.php atrasts! Varb�t J�s lab�k v�l�tos mniz�t PHProjektu? L�dzu las�t INSTALL ...";
$_lang['Please choose Installation,Update or Configure!'] = "L�dzu izv�laties 'Uzst�d��ana','Mniz�cija' vai 'Konfigur�cija'!";
$_lang['Sorry, I cannot connect to the database! <br>Please close all browser windows and restart the installation.'] = "Atvainojiet, nav iesp�jams piesl�gties pie datu b�zes! <br>L�dzu veicat izmai�s un atk�rtojiet uzst�d��anu no jauna.";
$_lang['Sorry, it does not work! <br> Please set DBDATE to Y4MD- or let phprojekt change this environment-variable (php.ini)!'] = "Atvainojiet, tas nedarbojas! <br> L�dzu uzst�diet DBDATE uz 'Y4MD-' vai ar� �aujiet phprojektam veikt izmai�as environment-variable (php.ini) fail�!";
$_lang['Seems that You have a valid database connection!'] = "Izskat�s, ka ir savienojums ar datub�zi!";
$_lang['Please select the modules you are going to use.<br> (You can disable them later in the config.inc.php)<br>'] = "L�dzu izv�laties modu�us ko v�aties lietot.<br> (V�l�k j�s var�siet tos aizliegt (config.inc.php)fail�<br>";
$_lang['Install component: insert a 1, otherwise keep the field empty'] = "Uzst�d��anas komponenti: ievad�t '1', sav�d�k lauki paliks tuk�i";
$_lang['Group views'] = "Grupas apskats";
$_lang['Todo lists'] = "Atg�din�jumu saraksts";

$_lang['Voting system'] = "Balso�anas sist�ma";


$_lang['Contact manager'] = "Kontaktu vad�ba";
$_lang['Name of userdefined field'] = "lietot�ja defin�t� lauka nosaukums";
$_lang['Userdefined'] = "Lietot�ja dafin�ts";
$_lang['Profiles for contacts'] = "Kontaktu noteikumi";
$_lang['Mail'] = "E-mails";
$_lang['send mail'] = " nos�t�t e-mailu";
$_lang[' only,<br> &nbsp; &nbsp; full mail client'] = " tikai,<br> &nbsp; &nbsp; pilns e-maila klients";



$_lang['1 to show appointment list in separate window,<br>&nbsp; &nbsp; 2 for an additional alert.'] = "'1' par�d�t apmekl�juma sarakstu atsevi��� log�,<br>
&nbsp; &nbsp; '2' priek� papildus br�din�jumiem.";
$_lang['Alarm'] = "Modin�t�jpulkstenis";
$_lang['max. minutes before the event'] = "maksimums min�tes pirms notikuma";
$_lang['SMS/Mail reminder'] = "SMS/E-maila atg�din�t�js";
$_lang['Reminds via SMS/Email'] = "Atg�dina caur SMS/E-mailu";
$_lang['1= Create projects,<br>&nbsp; &nbsp; 2= assign worktime to projects only with timecard entry<br>&nbsp; &nbsp; 3= assign worktime to projects without timecard entry<br>&nbsp; &nbsp; (Selection 2 or 3 only with module timecard!)'] = "'1'= Izveidot projektu,<br>
&nbsp; &nbsp; '2'= pie��irt darba laiku projektiem, kas ir kotrolsarakst�<br>
&nbsp; &nbsp; '3'= pie��irt darba laiku projektiem, kas nav kotrolsarakst�<br>&nbsp; &nbsp; (Atlas�t '2' vai '3' tikai ar modu�a kotrolsarakstu!)";

$_lang['Name of the directory where the files will be stored<br>( no file management: empty field)'] = "Direktorijas nosaukums kur faili tiks tur�ti<br>( nav failu vad�bas: atst�t tuk�u lauku)";
$_lang['absolute path to this directory (no files = empty field)'] = "piln�gs ce�� uz �o direktoriju (ja nav faili = atst�t tuk�u lauku)";
$_lang['Time card'] = "Darba laika uzskaites karte";
$_lang['1 time card system,<br>&nbsp; &nbsp; 2 manual insert afterwards sends copy to the chief'] = "'1' Darba laika uzskaites sist�ma,<br>
&nbsp; &nbsp; '2' pa�roc�gi ievad�t un v�l�k nos�t�t kopiju priek�niekam";
$_lang['Notes'] = "Piez�mes";
$_lang['Password change'] = "Paroles nomai�a";
$_lang['New passwords by the user - 0: none - 1: only random passwords - 2: choose own'] = "Jaunu paroli uzst�da lietot�js - 0: neviens - 1: tikai nejau�as paroles - 2: izv�las pats";
$_lang['Encrypt passwords'] = "Paro�u kript��ana";
$_lang['Login via '] = "Autoriz�cija caur ";
$_lang['Extra page for login via SSL'] = "Papildus lapa priek� SSL";
$_lang['Groups'] = "Gupas";
$_lang['User and module functions are assigned to groups<br>&nbsp; &nbsp; (recommended for user numbers > 40)'] = "Lietot�js un modu�a funkcijas tiek pie��irtas grup�m<br>
&nbsp; &nbsp; (rekomend�jamais lietot�ju skaits ir > 40)";
$_lang['User and module functions are assigned to groups'] = "Lietot�js un modu�a funkcijas tiek pie��irtas grup�m";
$_lang['Help desk'] = "Pal�dz�bas dienests";
$_lang['Help Desk Manager / Trouble Ticket System'] = "Pal�dz�bas Dienesta Vad�ba / Probl�mu Risin�juma Sist�ma";
$_lang['RT Option: Customer can set a due date'] = "RT Opcija: Klients var uzst�d�t paredz�to datumu";
$_lang['RT Option: Customer Authentification'] = "RT Opcija: Klients Autentiskums";
$_lang['0: open to all, email-address is sufficient<br>1: registered contact enter his family name<br>2: his email'] = "0: atv�rt visiem, ar e-maila adresi ir pietiekami, 1: klientam j�b�t kontaktu sarakst� un j�ievada uzv�rds";
$_lang['RT Option: Assigning request'] = "RT Opcijas: Uztic�ties piepras�jumam";
$_lang['0: by everybody, 1: only by persons with status chief'] = "0: visi, 1: tikai personas ar priek�nieka satusu";
$_lang['Email Address of the support'] = "Atbalsta E-maila adrese";
$_lang['Scramble filenames'] = "Pak�peniskus failu nosaukumus";
$_lang['creates scrambled filenames on the server<br>assigns previous name at download'] = "veido pak�peniskus failu nosaukumus uz server<br>
assigns iepriek��jos v�rdus pie iel�des";

$_lang['0: last name, 1: short name, 2: login name'] = "0: Uzv�rds, 1: v�rds sa�sin�ti, 2: atoriz�cijas v�rds";
$_lang['Prefix for table names in db'] = "Prefix for table names in db";
$_lang['Alert: Cannot create file config.inc.php!<br>Installation directory needs rwx access for your server and rx access to all others.'] = "Uzman�bu: Nav iesp�jams izveidot 'config.inc.php' failu!<br>
Uzst�d��anas direktorijai uz j�su servera ir nepiecie�ama rwx un rx piek�uve.";
$_lang['Location of the database'] = "Datu b�zes atra�an�s vieta";
$_lang['Type of database system'] = "Datu b�zes sist�mas tips";
$_lang['Username for the access'] = "Lietot�ja v�rds piek�uvei";
$_lang['Password for the access'] = "Parole piek�uvei";
$_lang['Name of the database'] = "Datub�zes v�rds";
$_lang['Prefix for database table names'] = "Prefix for database table names";
$_lang['First background color'] = "Pirm� aizmugures kr�sa";
$_lang['Second background color'] = "Otr� aizmugures kr�sa";
$_lang['Third background color'] = "Tre�� aizmugures kr�sa";
$_lang['Color to mark rows'] = "Color to mark rows";
$_lang['Color to highlight rows'] = "Color to highlight rows";
$_lang['Event color in the tables'] = "Notikumu kr�sa tabul�s";
$_lang['company icon yes = insert name of image'] = "Ja komp�nijas ikona = bildes nosaukumu";
$_lang['URL to the homepage of the company'] = "URL komp�nijas m�jas lapu";
$_lang['no = leave empty'] = "n� = atst�t tuk�u";
$_lang['First hour of the day:'] = "Dienas pirmaj� stund�:";
$_lang['Last hour of the day:'] = "Dienas beidzamaj� stund�:";
$_lang['An error ocurred while creating table: '] = "Veidojot tabulu notika k��me: ";
$_lang['Table dateien (for file-handling) created'] = "Tabula 'dateien' (priek� file-handling) izveidota";
$_lang['File management no = leave empty'] = "Failu vad�ba N� = atst�t tuk�u";
$_lang['yes = insert full path'] = "j� = nor�d�t pilnu ce�u";
$_lang['and the relative path to the PHProjekt directory'] = "un relat�vu ce�u uz PHProjekta direktoriju";
$_lang['Table profile (for user-profiles) created'] = "Tabula 'profile' (priek� user-profiles) izveidota";
$_lang['User Profiles yes = 1, no = 0'] = "Lietot�ju profili J� = 1, N� = 0";
$_lang['Table todo (for todo-lists) created'] = "Tabula 'todo' (priek� todo-lists) izveidota";
$_lang['Todo-Lists yes = 1, no = 0'] = "Kas J�dara - Saraksts j� = 1, n� = 0";
$_lang['Table forum (for discssions etc.) created'] = "Tabula 'forum' (diskusij�m u.t.t) izveidota";
$_lang['Forum yes = 1, no = 0'] = "Forums j� = 1, n� = 0";
$_lang['Table votum (for polls) created'] = "Tabula 'votum' (balso�anai) izveidota";
$_lang['Voting system yes = 1, no = 0'] = "Balso�anas sist�ma j� = 1, n� = 0";
$_lang['Table lesezeichen (for bookmarks) created'] = "Tabula 'lesezeichen' (gr�matz�m�m) izveidota";
$_lang['Bookmarks yes = 1, no = 0'] = "Gr�matz�mes j� = 1, n� = 0";
$_lang['Table ressourcen (for management of additional ressources) created'] = "Tabula 'ressourcen' (papildus resursu vad�bai) izveidota";
$_lang['Resources yes = 1, no = 0'] = "Resursi j� = 1, n� = 0";
$_lang['Table projekte (for project management) created'] = "Tabula 'projekte' (projektu vad�bai) izveidota";
$_lang['Table contacts (for external contacts) created'] = "Tabula kontakti (�r�jiem kotaktiem) izveidota";
$_lang['Table notes (for notes) created'] = "Tabula piez�mes (priek� piez�m�m) izveidota";
$_lang['Table timecard (for time sheet system) created'] = "Tabula kotrolsaraksts (laika saraksta sist�mai) izveidota";
$_lang['Table groups (for group management) created'] = "Tabula grupas (grupu vad�bai) izveidota";
$_lang['Table timeproj (assigning work time to projects) created'] = "Tabula timeproj (pie��ir projektiem darba laiku) izveidota";
$_lang['Table rts and rts_cat (for the help desk) created'] = "Tabula rts un rts_cat (pal�dz�bas dienestam) izveidota";
$_lang['Table mail_account, mail_attach, mail_client und mail_rules (for the mail reader) created'] = "Tabula mail_account, mail_attach, mail_client un mail_rules (e-mailu las��anai) izveidota";
$_lang['Table logs (for user login/-out tracking) created'] = "Tabula logs (lietot�ju autoriz�cijas/-izie�anas veik�anai) izveidota";
$_lang['Tables contacts_profiles und contacts_prof_rel created'] = "Tabula contacts_profiles un contacts_prof_rel izveidota";
$_lang['Project management yes = 1, no = 0'] = "Projetktu vad�ba j� = 1, n� = 0";
$_lang['additionally assign resources to events'] = "Notikumiem papildus pie��irtie resursi";
$_lang['Address book  = 1, nein = 0'] = "Adre�u gr�mata j� = 1, n� = 0";
$_lang['Mail no = 0, only send = 1, send and receive = 2'] = "E-mails n� = 0, tikai nos�t�t = 1, nos�t�t un sa�emt = 2";
$_lang['Chat yes = 1, no = 0'] = "Chat yes = 1, no = 0";
$_lang['Name format in chat list'] = "Name format in chat list";
$_lang['0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name'] = "0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name";
$_lang['Timestamp for chat messages'] = "Timestamp for chat messages";
$_lang['users (for authentification and address management)'] = "'users' (autentiskumam un adre�u vad�bai)";
$_lang['Table termine (for events) created'] = "'Table termine' (notikumiem) izveidots";
$_lang['The following users have been inserted successfully in the table user:<br>root - (superuser with all administrative privileges)<br>test - (chief user with restricted access)'] = "sekojo�ie lietot�ji ir pievienoti tabul� 'user':<br>
'root' - (superlietot�js ar vis�m administr�tora privil��ij�m)<br>
'test' - (lietot�ju vad�t�js ar ierobe�ot�m ties�b�m)";
$_lang['The group default has been created'] = "Grupa 'default' ir izveidota";
$_lang['Please do not change anything below this line!'] = "L�dzu neko neizmainiet zem�k par �o l�niju!";
$_lang['Database error'] = "K��da datub�z�";
$_lang['Finished'] = "Pabeigts";
$_lang['There were errors, please have a look at the messages above'] = "�eit ir k��das, l�dzu izlasiet zi�u";
$_lang['All required tables are installed and <br>the configuration file config.inc.php is rewritten<br>It would be a good idea to makea backup of this file.<br>'] = "Visas piepras�t�s tabulas ir uzst�d�tas un<br>
konfigur�cijas fails 'config.inc.php' 
ir p�rrakst�ts<br>
L�dzu veicat �� faila dubl��anu.<br>";
$_lang['The administrator root has the password root. Please change his password here:'] = "Administr�tors 'root' ir ar paroli 'root'. L�dzu, nomainiet paroli:";
$_lang['The user test is now member of the group default.<br>Now you can create new groups and add new users to the group'] = "Lietot�js 'test' ir standarta grupas loceklis 'default'.<br>
Tagad varat izveidot jaunu grupu un pievienot jaunus lietot�jus �ajai grupai";
$_lang['To use PHProject with your Browser go to <b>index.php</b><br>Please test your configuration, especially the modules Mail and Files.'] = "Lai s�ktu lietot PHProjektu dodaties uz <b>index.php</b><br>
L�dzu p�rbaudiet savu konfigur�ciju un it �pa�i 'Mail' , 'Files' modu�us.";

$_lang['Alarm x minutes before the event'] = "Modin�t�js x min�tes pirms notikuma";
$_lang['Additional Alarmbox'] = "Papildus Modin�t�jakaste";
$_lang['Mail to the chief'] = "E-mails vad�t�jam";
$_lang['Out/Back counts as: 1: Pause - 0: Workingtime'] = "Prom/Atpaka� skait�t k�: 1: Pauze - 0: Darba laiks";
$_lang['Passwords will now be encrypted ...'] = "Tagad paroles b�s kript�tas ...";
$_lang['Filenames will now be crypted ...'] = "Failu nosaukumi b�s kript�ti ...";
$_lang['Do you want to backup your database right now? (And zip it together with the config.inc.php ...)<br>Of course I will wait!'] = "Vai v�laties savu datu b�zi dubl�t jau �obr�d? (zipot kop� ar config.inc.php ...)<br>
Nu labi varu pagaid�t!";
$_lang['Next'] = "T�l�k";
$_lang['Notification on new event in others calendar'] = "Pazi�ojums par jaunu notikumu citu kalend�r�";
$_lang['Path to sendfax'] = "Ce�� uz faksa nos�t��anu";
$_lang['no fax option: leave blank'] = "no fax option: leave blank";
$_lang['Please read the FAQ about the installation with postgres'] = "L�dzu lasat FAQ par postgres uzst�d��anu";
$_lang['Length of short names<br> (Number of letters: 3-6)'] = "V�rdu sa�sin�jums<br> (Burtu skaits: 3-6)";
$_lang['If you want to install PHProjekt manually, you find<a href=http://www.phprojekt.com/files/sql_dump.tar.gz target=_blank>here</a> a mysql dump and a default config.inc.php'] = "Ja j�s uzst�d�t PHProjekt manu�li, j�s varat
<a href='http://www.phprojekt.com/files/sql_dump.tar.gz' target=_blank>�eit</a> mysql dump un standartat config.inc.php failu";
$_lang['The server needs the privilege to write to the directories'] = "Uz servera ir j�b�t 'write' ties�b�m uz direktorij�m";
$_lang['Header groupviews'] = "Aug��j�s grupas apskats";
$_lang['name, F.'] = "v�rds, F.";
$_lang['shortname'] = "v�rds sa�sin�ti";
$_lang['loginname'] = "autoriz�cijas v�rds";
$_lang['Please create the file directory'] = "L�dzu izveidojiet faila direktoriju";
$_lang['default mode for forum tree: 1 - open, 0 - closed'] = "standarta veids forumam ir koks: 1 - atv�rt, 0 - aizv�rt";
$_lang['Currency symbol'] = "Naudas simbols";
$_lang['current'] = "faktisks";
$_lang['Default size of form elements'] = "Default size of form elements";
$_lang['use LDAP'] = "lietot LDAP";
$_lang['Allow parallel events'] = "At�aut paral�lus notikumus";
$_lang['Timezone difference [h] Server - user'] = "Laika joslas at��ir�ba [h] Serveris - lietot�js";
$_lang['Timezone'] = "Laika josla";
$_lang['max. hits displayed in search module'] = "maksim�li. par�d�tais rezult�ts mekl��anas modul�";
$_lang['Time limit for sessions'] = "Time limit for sessions";
$_lang['0: default mode, 1: Only for debugging mode'] = "0: default mode, 1: Only for debugging mode";
$_lang['Enables mail notification on new elements'] = "Enables mail notification on new elements";
$_lang['Enables versioning for files'] = "Enables versioning for files";
$_lang['no link to contacts in other modules'] = "no link to contacts in other modules";
$_lang['Highlight list records with mouseover'] = "Highlight list records with 'mouseover'";
$_lang['Track user login/logout'] = "Track user login/logout";
$_lang['Access for all groups'] = "Access for all groups";
$_lang['Option to release objects in all groups'] = "Option to release objects in all groups";
$_lang['Default access mode: private=0, group=1'] = "Default access mode: private=0, group=1"; 
$_lang['Adds -f as 5. parameter to mail(), see php manual'] = "Adds '-f' as 5. parameter to mail(), see php manual";
$_lang['end of line in body; e.g. \r\n (conform to RFC 2821 / 2822)'] = "end of line in body; e.g. \\r\\n (conform to RFC 2821 / 2822)";
$_lang['end of header line; e.g. \r\n (conform to RFC 2821 / 2822)'] = "end of header line; e.g. \\r\\n (conform to RFC 2821 / 2822)";
$_lang['Sendmail mode: 0: use mail(); 1: use socket'] = "Sendmail mode: 0: use mail(); 1: use socket";
$_lang['the real address of the SMTP mail server, you have access to (maybe localhost)'] = "the real address of the SMTP mail server, you have access to (maybe localhost)";
$_lang['name of the local server to identify it while HELO procedure'] = "name of the local server to identify it while HELO procedure";
$_lang['Authentication'] = "Authentication";
$_lang['fill out in case of authentication via POP before SMTP'] = "fill out in case of authentication via POP before SMTP";
$_lang['real username for POP before SMTP'] = "real username for POP before SMTP";
$_lang['password for this pop account'] = "password for this pop account"; 
$_lang['the POP server'] = "the POP server";
$_lang['fill out in case of SMTP authentication'] = "fill out in case of SMTP authentication";
$_lang['real username for SMTP auth'] = "real username for SMTP auth";
$_lang['password for this account'] = "password for this account";
$_lang['SMTP account data (only needed in case of socket)'] = "SMTP account data (only needed in case of socket)";
$_lang['No Authentication'] = "No Authentication"; 
$_lang['with POP before SMTP'] = "with POP before SMTP";
$_lang['SMTP auth (via socket only!)'] = "SMTP auth (via socket only!)"; 
$_lang['Log history of records'] = "Log history of records";
$_lang['Send'] = " Senden";
$_lang['Host-Path'] = "Host-Path";
$_lang['Installation directory'] = "Installation directory";
$_lang['0 Date assignment by chief, 1 Invitation System'] = "0 Date assignment by chief, 1 Invitation System";
$_lang['0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System'] = "0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System";
$_lang['Default write access mode: private=0, group=1'] = "Default write access mode: private=0, group=1";
$_lang['Select-Option accepted available = 1, not available = 0'] = "Select-Option accepted available = 1, not available = 0";
$_lang['absolute path to host, e.g. http://myhost/'] = "absolute path to host, e.g. http://myhost/";
$_lang['installation directory below host, e.g. myInstallation/of/phprojekt5/'] = "installation directory below host, e.g. myInstallation/of/phprojekt5/";

// l.php
$_lang['Resource List'] = "Resursu Saraksts";
$_lang['Event List'] = "Notikumu Saraksts";
$_lang['Calendar Views'] = "Kalend�ra Apskats";

$_lang['Personnel'] = "Person�ls";
$_lang['Create new event'] = "Izveidot Notikumu";
$_lang['Day'] = "Diena";

$_lang['Until'] = "L�dz";

$_lang['Note'] = "Piez�me";
$_lang['Project'] = "Projekts";
$_lang['Res'] = "Resurs";
$_lang['Once'] = "Vienreiz";
$_lang['Daily'] = "Katru Dienu";
$_lang['Weekly'] = "Katru Ned��u";
$_lang['Monthly'] = "Katru M�nesi";
$_lang['Yearly'] = "Katru Gadu";

$_lang['Create'] = "Izveidot";

$_lang['Begin'] = "Uzs�kt";
$_lang['Out of office'] = "�rpus darba";
$_lang['Back in office'] = "Atpaka� darb�";
$_lang['End'] = "Beidzas";
$_lang['@work'] = "@darbs";
$_lang['We'] = "Ne";
$_lang['group events'] = "grupas notikumi";
$_lang['or profile'] = "vai profils";
$_lang['All Day Event'] = "notikums uz viesu dienu";
$_lang['time-axis:'] = "laika-ass:";
$_lang['vertical'] = "vertik�li";
$_lang['horizontal'] = "horizont�li";
$_lang['Horz. Narrow'] = "hor. sa�aurin�ti";
$_lang['-interval:'] = "-interv�ls:";
$_lang['Self'] = "Mans";

$_lang['...write'] = "...rakst�t";

$_lang['Calendar dates'] = "Calendar dates";
$_lang['List'] = "List";
$_lang['Year'] = "Year";
$_lang['Month'] = "Month";
$_lang['Week'] = "Week";
$_lang['Substitution'] = "Substitution";
$_lang['Substitution for'] = "Substitution for";
$_lang['Extended&nbsp;selection'] = "Extended&nbsp;selection";
$_lang['New Date'] = "New date entered";
$_lang['Date changed'] = "Date changed";
$_lang['Date deleted'] = "Date deleted";

// links
$_lang['Database table'] = "Database table";
$_lang['Record set'] = "Record set";
$_lang['Resubmission at:'] = "Resubmission at:";
$_lang['Set Links'] = "Links";
$_lang['From date'] = "From date";
$_lang['Call record set'] = "Call record set";


//login.php
$_lang['Please call login.php!'] = "Dodaties uz login.php!";

// m1.php
$_lang['There are other events!<br>the critical appointment is: '] = "Pa�laik notikums!<br>tuv�k� norun�t� tik�an�s ir: ";
$_lang['Sorry, this resource is already occupied: '] = "Atvainojiet �is resurs jau ir aiz�emts: ";
$_lang[' This event does not exist.<br> <br> Please check the date and time. '] = " ��da notikuma nav.<br> <br> L�dzu izv�laties datumu un laiku. ";
$_lang['Please check your date and time format! '] = "P�rbaudiet datumu un laika form�tu! ";
$_lang['Please check the date!'] = "P�rbaudiet datumu!";
$_lang['Please check the start time! '] = "P�rbaudiet starta laiku! ";
$_lang['Please check the end time! '] = "P�rbaudiet beigu laiku! ";
$_lang['Please give a text or note!'] = "L�dzu ierakstie tekstu vai piez�mi!";
$_lang['Please check start and end time! '] = "P�rbaudiet starta laiku un beigu laiku! ";
$_lang['Please check the format of the end date! '] = "P�rbaudiet beigu laika form�tu! ";
$_lang['Please check the end date! '] = "P�rbaudiet beigu datumu! ";





$_lang['Resource'] = "Resurs";
$_lang['User'] = "lietot�js";

$_lang['delete event'] = "dz�st notikumu";
$_lang['Address book'] = "Adre�u gr�mata";


$_lang['Short Form'] = "Sa�sint�ts v�rds";

$_lang['Phone'] = "Telefons";
$_lang['Fax'] = "Fakss";



$_lang['Bookmark'] = "Gr�matz�me";
$_lang['Description'] = "Apraksts";

$_lang['Entire List'] = "Piln�gs saraksts";

$_lang['New event'] = "Jauns notikums?";
$_lang['Created by'] = "Izveidoja";
$_lang['Red button -> delete a day event'] = "Las�t poga -> dz�st dienas notikumus";
$_lang['multiple events'] = "daudzk�rt�jie notikumi";
$_lang['Year view'] = "Gada p�rskats";
$_lang['calendar week'] = "calendar week";

//m2.php
$_lang['Create &amp; Delete Events'] = "Veidot &amp; Dz�st Notikumus";
$_lang['normal'] = "norm�li";
$_lang['private'] = "priv�ti";
$_lang['public'] = "publiski";
$_lang['Visibility'] = "Redzam�ba";

//mail module
$_lang['Please select at least one (valid) address.'] = "L�dzu izv�laties vismaz vienu pareizu adresi.";
$_lang['Your mail has been sent successfully'] = "E-mails veiksm�gi nos�t�ts";
$_lang['Attachment'] = "Pielikums";
$_lang['Send single mails'] = "Nos�t�t vienu e-mailu";
$_lang['Does not exist'] = "Neeksist�";
$_lang['Additional number'] = "papildus nummuri";
$_lang['has been canceled'] = "ir atcelts";

$_lang['marked objects'] = "atz�m�tos objektus";
$_lang['Additional address'] = "Papildus adreses";
$_lang['in mails'] = "ien�ko�ie e-maili";
$_lang['Mail account'] = "E-maila konts";
$_lang['Body'] = "Body (pie��irt)";
$_lang['Sender'] = "S�t�t�js";

$_lang['Receiver'] = "Sa�em�js";
$_lang['Reply'] = "Atbilde";
$_lang['Forward'] = "P�rs�t�t";
$_lang['Access error for mailbox'] = "Autoriz�cijas k��da piek���anai pie e-mailiem";
$_lang['Receive'] = "Sa�emt";
$_lang['Write'] = "Rakst�t";
$_lang['Accounts'] = "Konts";
$_lang['Rules'] = "Noteikumi";
$_lang['host name'] = "hosta v�rds";
$_lang['Type'] = "Tips";
$_lang['misses'] = "k��mes";
$_lang['has been created'] = "ir izveidots";
$_lang['has been changed'] = "ir izmain�ts";
$_lang['is in field'] = "ir lauk�";
$_lang['and leave on server'] = "un atst�t uz servera";
$_lang['name of the rule'] = "noteikuma nosaukums";
$_lang['part of the word'] = "v�rda da�a";
$_lang['in'] = "iek��";
$_lang['sent mails'] = "nos�t�tie e-maili";
$_lang['Send date'] = "Nos�t��anas datums";
$_lang['Received'] = "Received";
$_lang['to'] = "uz";
$_lang['imcoming Mails'] = "ien�ko�ais E-mails";
$_lang['sent Mails'] = "nos�t�tie E-maili";
$_lang['Contact Profile'] = "Kontaktu Profils";
$_lang['unread'] = "neizlas�tie";
$_lang['view mail list'] = "skat�t e-mailu sarakstu";
$_lang['insert db field (only for contacts)'] = "ievad�t db lauk� (tikai priek� kontaktiem)";
$_lang['Signature'] = "Paraksts";

$_lang['SMS'] = "SMS";
$_lang['Single account query'] = "Viena pa�a konta jaut�jums";
$_lang['Notice of receipt'] = "Pazi�ot par sa�em�anu";
$_lang['Assign to project'] = "Assign to project";
$_lang['Assign to contact'] = "Assign to contact";  
$_lang['Assign to contact according to address'] = "Assign to contact according to address";
$_lang['Include account for default receipt'] = "Include account for default receipt";
$_lang['Your token has already been used.<br>If it wasnt you, who used the token please contact your administrator.'] = "Your token has already been used.<br>If it wasn't you, who used the token please contact your administrator";
$_lang['Your token has already been expired.'] = "Your token has already been expired";
$_lang['Unconfirmed Events'] = "Unconfirmed Events";
$_lang['Visibility presetting when creating an event'] = "Voreinstellung der Sichtbarkeit beim Anlegen eines Termins";
$_lang['Subject'] = "Subject";
$_lang['Content'] = "Inhalt";
$_lang['answer all'] = "answer to all";
$_lang['Create new message'] = "Create new message";
$_lang['Attachments'] = "Attachments";
$_lang['Recipients'] = "Recipients";
$_lang['file away message'] = "file away message";
$_lang['Message from:'] = "Message from:";

//notes.php
$_lang['Mail note to'] = "Nos�t�t piez�mi uz";
$_lang['added'] = "pievienots";
$_lang['changed'] = "izmain�ts";

// o.php
$_lang['Calendar'] = "Kalend�rs";
$_lang['Contacts'] = "Kontakti";


$_lang['Files'] = "Faili";



$_lang['Options'] = "Opcijas";
$_lang['Timecard'] = "Kontrolsaraksts";

$_lang['Helpdesk'] = "Pal�dz�bas dienests";

$_lang['Info'] = "Info";
$_lang['Todo'] = "Atg�din�jumi";
$_lang['News'] = "Jaunumi";
$_lang['Other'] = "Cits";
$_lang['Settings'] = "Uzst�d�jumi";
$_lang['Summary'] = "Kopsumma";

// options.php
$_lang['Description:'] = "Apraksts:";
$_lang['Comment:'] = "Koment�rs:";
$_lang['Insert a valid Internet address! '] = "Ievadiet pareizu Interneta adresi! ";
$_lang['Please specify a description!'] = "L�dzu aizpildat aprakstu!";
$_lang['This address already exists with a different description'] = "�� adrese jau eksist� ar citu aprakstu";
$_lang[' already exists. '] = " jau eksist�. ";
$_lang['is taken to the bookmark list.'] = "is taken to the bookmark list.";
$_lang[' is changed.'] = " ir izmain�ts.";
$_lang[' is deleted.'] = " ir dz�sts.";
$_lang['Please specify a description! '] = "L�dzu veicat detaliz�tu aprakstu! ";
$_lang['Please select at least one name! '] = "L�dzu izv�laties vismaz vienu v�rdu! ";
$_lang[' is created as a profile.<br>'] = " ir izveidots k� profils.<br>";
$_lang['is changed.<br>'] = "ir izmain�ts.<br>";
$_lang['The profile has been deleted.'] = "Profils ir nodz�sts.";
$_lang['Please specify the question for the poll! '] = "Izv�laties jaut�jumu balso�anai! ";
$_lang['You should give at least one answer! '] = "Jums ir j�dod vismaz viena atbilde! ";
$_lang['Your call for votes is now active. '] = "J�su izveidot� balo�ana ir aktiviz�ta. ";
$_lang['<h2>Bookmarks</h2>In this section you can create, modify or delete bookmarks:'] = "<h2>Gr�matz�mes</h2>�aj� sekcij� j�s varat veidot, modofic�t un dz�st gr�matz�mes:";
$_lang['Create'] = "Izveidot";


$_lang['<h2>Profiles</h2>In this section you can create, modify or delete profiles:'] = "<h2>Profili</h2>�aj� sekcij� j�s varat veidot, modofic�t un dz�st profilus:";
$_lang['<h2>Voting Formula</h2>'] = "<h2>Balsojumu Forma</h2>";
$_lang['In this section you can create a call for votes.'] = "�eit j�s varat izveidot balsojuma formu.";
$_lang['Question:'] = "Jaut�jumi:";
$_lang['just one <b>Alternative</b> or'] = "tikai viens<b>Alternat�vs</b> vai";
$_lang['several to choose?'] = "izv�l�ties da��das?";

$_lang['Participants:'] = "Dal�bnieki:";

$_lang['<h3>Password Change</h3> In this section you can choose a new random generated password.'] = "<h3>Paroles nomai�a</h3> �aj� sekcij� j�s varat izv�l�ties  nejau�i izveidotu paroli.";
$_lang['Old Password'] = "Vec� Parole";
$_lang['Generate a new password'] = "�ener�t jaunu";
$_lang['Save password'] = "Saglab�t paroli";
$_lang['Your new password has been stored'] = "J�su jaun� parole ir saglab�ta";
$_lang['Wrong password'] = "Nepareiza parole";
$_lang['Delete poll'] = "Dz�st balsojumu";
$_lang['<h4>Delete forum threads</h4> Here you can delete your own threads<br>Only threads without a comment will appear.'] = "<h4>Dz�st forumu</h4> �eit ir iesp�jams nodz�st pa�a rakst�tos pavedienus<br>
Par�d�sies tie pavedieni, kas ir bez koment�riem.";

$_lang['Old password'] = "Vec� parole";
$_lang['New Password'] = "Jaun� parole";
$_lang['Retype new password'] = "P�rrakst�t jauno paroli";
$_lang['The new password must have 5 letters at least'] = "Jaunajai parolei ir j�b�t vismaz ar 5 simboliem";
$_lang['You didnt repeat the new password correctly'] = "J�s neievad�j�t jauno paroles atk�rtojumu pareizi";

$_lang['Show bookings'] = "Par�d�t Re�istrus";
$_lang['Valid characters'] = "Pareiz�s rakstu z�mes";
$_lang['Suggestion'] = "Ierosin�jums";
$_lang['Put the word AND between several phrases'] = "Ievietot v�rdu AND starp da��d�m fr�z�m"; // translators: please leave the word AND as it is
$_lang['Write access for calendar'] = "Kalend�r� rakst�t ties�bas";
$_lang['Write access for other users to your calendar'] = "Citiem tie�bas rakst�t j�su kalend�r� ";
$_lang['User with chief status still have write access'] = "Lietot�jiem ar vad�t�ju statusu tom�r b�s ties�bas uz rakst��anu";

// projects
$_lang['Project Listing'] = "Projektu saraksts";
$_lang['Project Name'] = "Projekta nosaukums";


$_lang['o_files'] = "Files";
$_lang['o_notes'] = "Notes";
$_lang['o_projects'] = "Projects";
$_lang['o_todo'] = "Todo";
$_lang['Copyright']="Copyright";
$_lang['Links'] = "Links";
$_lang['New profile'] = "Neuer Verteiler";
$_lang['In this section you can choose a new random generated password.'] = "In this section you can choose a new random generated password.";
$_lang['timescale'] = "timescale";
$_lang['Manual Scaling'] = "Manual scaling";
$_lang['column view'] = "column view";
$_lang['display format'] = "display format";
$_lang['for chart only'] = "For chart only:";
$_lang['scaling:'] = "scling:";
$_lang['colours:'] = "colours";
$_lang['display project colours'] = "display project colours";
$_lang['weekly'] = "weekly";
$_lang['monthly'] = "monthly";
$_lang['annually'] = "annually";
$_lang['automatic'] = "automatic";
$_lang['New project'] = "New project";
$_lang['Basis data'] = "Basis data";
$_lang['Categorization'] = "Categorization";
$_lang['Real End'] = "Real End";
$_lang['Participants'] = "Dal�bnieki";
$_lang['Priority'] = "Priorit�te";
$_lang['Status'] = "Status";
$_lang['Last status change'] = "Beidzam�s <br>izmai�as";
$_lang['Leader'] = "L�deris";
$_lang['Statistics'] = "Statistika";
$_lang['My Statistic'] = "Mana Statistika";

$_lang['Person'] = "Persona";
$_lang['Hours'] = "Stundas";
$_lang['Project summary'] = "Kopum� par projektu";
$_lang[' Choose a combination Project/Person'] = " Izv�laties kobin�ciju Projets/Persona";
$_lang['(multiple select with the Ctrl/Cmd-key)'] = "(daudzk�rt�ja izv�lne ar 'Ctrl'-tausti�u)";

$_lang['Persons'] = "Personas";
$_lang['Begin:'] = "Uzs�k:";
$_lang['End:'] = "Beigt:";
$_lang['All'] = "Visu";
$_lang['Work time booked on'] = "Darba laiks iegr�matots";
$_lang['Sub-Project of'] = "Apak�projekts atsl�gts";
$_lang['Aim'] = "M�r�is";
$_lang['Contact'] = "Kontakti";
$_lang['Hourly rate'] = "Ikstundas likme";
$_lang['Calculated budget'] = "Aprei�in�t bud�etu";
$_lang['New Sub-Project'] = "Jauns apak�projekts";
$_lang['Booked To Date'] = "L�dz �im iegr�matots";
$_lang['Budget'] = "Bud�ets";
$_lang['Detailed list'] = "Detaliz�ts saraksts";
$_lang['Gantt'] = "Gantt";
$_lang['offered'] = "pied�v�jums";
$_lang['ordered'] = "pas�t�ts";
$_lang['Working'] = "darb�ba";
$_lang['ended'] = "nosl�dzies";
$_lang['stopped'] = "apst�din�ts";
$_lang['Re-Opened'] = "opened again";
$_lang['waiting'] = "nogaido�s";
$_lang['Only main projects'] = "Tikai galvenie projekti";
$_lang['Only this project'] = "Tikai �is projekti";
$_lang['Begin > End'] = "Uzs�k > Beigt";
$_lang['ISO-Format: yyyy-mm-dd'] = "ISO-Form�ts: yyyy-mm-dd";
$_lang['The timespan of this project must be within the timespan of the parent project. Please adjust'] = "Laika br�dis �im projektam ir jab�t starposm� ar galveno projektu. L�dzu uzst�d�t";
$_lang['Please choose at least one person'] = "Izv�laties vismaz vienu personu";
$_lang['Please choose at least one project'] = "Izv�laties vismaz vienu projektu";
$_lang['Dependency'] = "Padot�ba";
$_lang['Previous'] = "Iepriek��js";

$_lang['cannot start before the end of project'] = "nav iesp�jams uzs�kt pirms projekta beig�m";
$_lang['cannot start before the start of project'] = "nav iesp�jams uzs�kt pirms projekta s�kuma";
$_lang['cannot end before the start of project'] = "nav iesp�jams pabeigt pirms projekta s�kuma";
$_lang['cannot end before the end of project'] = "nav iesp�jams pabeigt pirms projekta beig�m";
$_lang['Warning, violation of dependency'] = "Uzman�bu, padot�bas p�rk�pums";
$_lang['Container'] = "Kontainers";
$_lang['External project'] = "�r�js projekts";
$_lang['Automatic scaling'] = "Autom�tiska m�rogo�ana";
$_lang['Legend'] = "Le�enda";
$_lang['No value'] = "Nav v�rt�bas";
$_lang['Copy project branch'] = "Copy project branch";
$_lang['Copy this element<br> (and all elements below)'] = "Copy this element<br> (and all elements below)";
$_lang['And put it below this element'] = "And put it below this element";
$_lang['Edit timeframe of a project branch'] = "Edit timeframe of a project branch"; 

$_lang['of this element<br> (and all elements below)'] = "of this element<br> (and all elements below)";  
$_lang['by'] = "by";
$_lang['Probability'] = "Probability";
$_lang['Please delete all subelements first'] = "Please delete all subprojects first";
$_lang['Assignment'] ="Assignment";
$_lang['display'] = "Display";
$_lang['Normal'] = "Normal";
$_lang['sort by date'] = "Sort by date";
$_lang['sort by'] = "Sort by";
$_lang['Calculated budget has a wrong format'] = "Calculated budget has a wrong format";
$_lang['Hourly rate has a wrong format'] = "Hourly rate has a wrong format";

// r.php
$_lang['please check the status!'] = "p�rbaudiet statusu!";
$_lang['Todo List: '] = "Kas J�dara Saraksts: ";
$_lang['New Remark: '] = "Jauna Piez�me: ";
$_lang['Delete Remark '] = "Dz�st Piez�mi ";
$_lang['Keyword Search'] = "Atsl�gas V�rda Mekl��ana";
$_lang['Events'] = "Notikumi";
$_lang['the forum'] = "forums";
$_lang['the files'] = "faili";
$_lang['Addresses'] = "Adreses";
$_lang['Extended'] = "Papla�in�t";
$_lang['all modules'] = "visi modu�i";
$_lang['Bookmarks:'] = "Gr�matz�mes:";
$_lang['List'] = "Saraksts";
$_lang['Projects:'] = "Projekts:";

$_lang['Deadline'] = "P�d�jais termi��";

$_lang['Polls:'] = "Balsojumi:";

$_lang['Poll created on the '] = "Balso�ana izveidota ";


// reminder.php
$_lang['Starts in'] = "S�kas ";
$_lang['minutes'] = "min�tes";
$_lang['No events yet today'] = "�odien notikumu nav";
$_lang['New mail arrived'] = "Jums pien�cis ir e-mails";

//ress.php

$_lang['List of Resources'] =  "Resursu Saraksts";
$_lang['Name of Resource'] = "Resursa nosaukums";
$_lang['Comments'] =  "Koment�ri";


// roles
$_lang['Roles'] = "Noteikumi";
$_lang['No access'] = "Nav piek�uves";
$_lang['Read access'] = "Las�t ties�bas";

$_lang['Role'] = "Noteikums";

// helpdesk - rts
$_lang['Request'] = "Piepras�t";

$_lang['pending requests'] = "neatbild�tie piepras�jumi";
$_lang['show queue'] = "par�d�t rind�";
$_lang['Search the knowledge database'] = "Mekl�t zin��anu datu b�z�";
$_lang['Keyword'] = "Atsl�gv�rds";
$_lang['show results'] = "par�d�t rezult�tus";
$_lang['request form'] = "piepras�juma forma";
$_lang['Enter your keyword'] = "Ievadiet savu atsl�gas v�rdu";
$_lang['Enter your email'] = "Ievad�t J�su e-mailu";
$_lang['Give your request a name'] = "Dodiet savam piepras�jumam nosaukumu";
$_lang['Describe your request'] = "Aprakstiet savu piepras�jumu";

$_lang['Due date'] = "Paredz�tais datums";
$_lang['Days'] = "Dienas";
$_lang['Sorry, you are not in the list'] = "Atvainojiet, bet j�s neesat sarakst�";
$_lang['Your request Nr. is'] = "J�su piepras�juma Nr. ir";
$_lang['Customer'] = "Pas�t�t�js";


$_lang['Search'] = "Mekl�t";
$_lang['at'] = "kur";
$_lang['all fields'] = "visi lauki";


$_lang['Solution'] = "Risin�jums";
$_lang['AND'] = "AND"; //kas tas ir par AND

$_lang['pending'] = "nenok�rtots";
$_lang['stalled'] = "novietots";
$_lang['moved'] = "p�rcelts";
$_lang['solved'] = "atrisin�ts";
$_lang['Submit'] = "Iesniegt";
$_lang['Ass.'] = "Mu���bas.";
$_lang['Pri.'] = "Pri.";
$_lang['access'] = "piek�uve";
$_lang['Assigned'] = "Pie��irts";

$_lang['update'] = "pievienot";
$_lang['remark'] = "piez�me";
$_lang['solve'] = "atrisin�t";
$_lang['stall'] = "novietots";
$_lang['cancel'] = "atcelt";
$_lang['Move to request'] = "P�rcelt piepras�jumu uz";
$_lang['Dear customer, please refer to the number given above by contacting us.Will will perform your request as soon as possible.'] = "Cien�tais pas�t�t�j, l�dzu nos�tiet ieprie�min�tos nummurus kontakt�joties ar mums.
M�s izpild�sim J�su piepras�jumu p�c iesp�jas �tr�k.";
$_lang['Your request has been added into the request queue.<br>You will receive a confirmation email in some moments.'] = "J�su piepras�jums ir veiksm�gi pievienots m�su datu b�zei.<br>
Dr�zum� j�s sa�emsiet apstiprin�juma e-mailu.";
$_lang['n/a'] = "n/a";
$_lang['internal'] = "iek��js";

$_lang['has reassigned the following request'] = "atk�rtoti noz�m�ts sekojo�s piepras�jums";
$_lang['New request'] = "Jauns piepras�jums";
$_lang['Assign work time'] = "Pie��irtais darba laiks";
$_lang['Assigned to:'] = "Pie��its:";

$_lang['Your solution was mailed to the customer and taken into the database.'] = "J�su risin�jums ir nos�t�ts pas�t�t�jam un pa�emts m�su datu b�z�.";
$_lang['Answer to your request Nr.'] = "Atbilde uz piepras�jumu Nr.";
$_lang['Fetch new request by mail'] = "Sa�emt piepras�jumu caur e-mailu";
$_lang['Your request was solved by'] = "J�su piepras�jums ir atrisin�ts";

$_lang['Your solution was mailed to the customer and taken into the database'] = "J�su risin�jums ir nos�t�ts pas�t�t�jam un pa�emts datub�z�";
$_lang['Search term'] = "Search term";
$_lang['Search area'] = "Search area";
$_lang['Extended search'] = "Extended search";
$_lang['knowledge database'] = "knowledge database";
$_lang['Cancel'] = "Cancel";
$_lang['New ticket'] = "New ticket";
$_lang['Ticket status'] ="Ticket status";

// please adjust this states as you want -> add/remove states in helpdesk.php
$_lang['unconfirmed'] = 'unconfirmed';
$_lang['new'] = 'new';
$_lang['assigned'] = 'assigned';
$_lang['reopened'] = 'reopened';
$_lang['resolved'] = 'resolved';
$_lang['verified'] = 'verified';

// settings.php
$_lang['The settings have been modified'] = "Uzst�d�jumi ir modific�ti";
$_lang['Skin'] = "Izskats";
$_lang['First module view on startup'] = "Pirmais modulis ko redz start�joties";
$_lang['none'] = "nekas";
$_lang['Check for mail'] = "P�rbaud�t p�c e-maila";
$_lang['Additional alert box'] = "Papildus zi�ojumu kaste";
$_lang['Horizontal screen resolution <br>(i.e. 1024, 800)'] = "Horizot�la ekr�na iz��irtsp�ja <br>(i.e. 1024, 800)";
$_lang['Chat Entry'] = "�ata ievads";
$_lang['single line'] = "vien� l�nij�";
$_lang['multi lines'] = "vair�k�s l�nij�s ";
$_lang['Chat Direction'] = "Chat Direction";
$_lang['Newest messages on top'] = "Newest messages on top";
$_lang['Newest messages at bottom'] = "Newest messages at bottom";
$_lang['File Downloads'] = "Failu Lejupiel�de";

$_lang['Inline'] = "Inline";
$_lang['Lock file'] = "Lock file";
$_lang['Unlock file'] = "nlock file";
$_lang['New file here'] = "New file here";
$_lang['New directory here'] = "New directory here";
$_lang['Position of form'] = "Position of form";
$_lang['On a separate page'] = "On a separate page";
$_lang['Below the list'] = "Below the list";
$_lang['Treeview mode on module startup'] = "Treeview mode on module startup";
$_lang['Elements per page on module startup'] = "Elements per page on module startup";
$_lang['General Settings'] = "General Settings";
$_lang['First view on module startup'] = "First view on module startup";
$_lang['Left frame width [px]'] = "Left frame width [px]";
$_lang['Timestep Daywiew [min]'] = "Timestep Dayview [min]";
$_lang['Timestep Weekwiew [min]'] = "Timestep Weekview [min]";
$_lang['px per char for event text<br>(not exact in case of proportional font)'] = "px per char for event text<br>(not exact in case of proportional font)";
$_lang['Text length of events will be cut'] = "Text length of events will be cut";
$_lang['Standard View'] = "Standard View";
$_lang['Standard View 1'] = "Standard View 1";
$_lang['Standard View 2'] = "Standard View 2";
$_lang['Own Schedule'] = "Own Schedule";
$_lang['Group Schedule'] = "Group Schedule";
$_lang['Group - Create Event'] = "Group - Create Event";
$_lang['Group, only representation'] = "Group, only representation";
$_lang['Holiday file'] = "Holiday file";

// summary
$_lang['Todays Events'] = "�odienas pas�kumi";
$_lang['New files'] = "Jaunie faili";
$_lang['New notes'] = "Jaun�s piez�mes";
$_lang['New Polls'] = "Jaun�kais balso�an�";
$_lang['Current projects'] = "Pa�reiz�jie projekti";
$_lang['Help Desk Requests'] = "Piepras�t� pal�dz�ba";
$_lang['Current todos'] = "Ko dar�t";
$_lang['New forum postings'] = "Jaun�kais forum�";
$_lang['New Mails'] = "Jaunie e-maili";

//timecard

$_lang['Theres an error in your time sheet: '] = "K��da laika sarakst�: ";




$_lang['Consistency check'] = "Sec�bas p�rbaude";
$_lang['Please enter the end afterwards at the'] = "Dodaties uz sec�bas galu";
$_lang['insert'] = "iel�m�t";
$_lang['Enter records afterwards'] = "Ievadiet dokumnt�ciju sec�b�";
$_lang['Please fill in only emtpy records'] = "Aizpildiet tikai tuk�o dokument�ciju";

$_lang['Insert a period, all records in this period will be assigned to this project'] = "Ievietojiet periodu, visas atskaites �aj� period� b�s pie��irtas �im projektam";
$_lang['There is no record on this day'] = "�odien atskai�u nav";
$_lang['This field is not empty. Please ask the administrator'] = "�is lauks nav tuk�s. L�dzu vaic�jiet administr�toram";
$_lang['There is no open record with a begin time on this day!'] = "Uz ��s dienas s�kumu nav nevienas atv�rtas atskaites!";
$_lang['Please close the open record on this day first!'] = "Pispirms �odien, l�dzu, aizveriet atv�rto dokument�ciju!";
$_lang['Please check the given time'] = "P�rbaudiet nor�d�to laiku";
$_lang['Assigning projects'] = "Pie��irtie projekti";
$_lang['Select a day'] = "Izv�laties dienu";
$_lang['Copy to the boss'] = "Kopija Priek�niekam";
$_lang['Change in the timecard'] = "Korolsaraksta izmai�as";
$_lang['Sum for'] = "Summa priek�";

$_lang['Unassigned time'] = "Nepie��irtais laiks";
$_lang['delete record of this day'] = "dz�st ��s dienas atskaites";
$_lang['Bookings'] = "Pieteikumi";

$_lang['insert additional working time'] = "insert additional working time";
$_lang['Project assignment']= "Project assignment";
$_lang['Working time stop watch']= "Working time stop watch";
$_lang['stop watches']= "stop watches";
$_lang['Project stop watch']= "Project stop watch";
$_lang['Overview my working time']= "Overview my working time";
$_lang['GO']= "GO";
$_lang['Day view']= "Day view";
$_lang['Project view']= "Project view";
$_lang['Weekday']= "Weekday";
$_lang['Start']= "Start";
$_lang['Net time']= "Net time";
$_lang['Project bookings']= "Project bookings";
$_lang['save+close']= "save+close";
$_lang['Working times']= "Working times";
$_lang['Working times start']= "Working times start";
$_lang['Working times stop']= "Working times stop";
$_lang['Project booking start']= "Project booking start";
$_lang['Project booking stop']= "Project booking stop";
$_lang['choose day']= "choose day";
$_lang['choose month']= "choose month";
$_lang['1 day back']= "1 day back";
$_lang['1 day forward']= "1 day forward";
$_lang['Sum working time']= "Sum working time";
$_lang['Time: h / m']= "Time: h / m";
$_lang['activate project stop watch']= "activate project stop watch";
$_lang['activate']= "activate";
$_lang['project choice']= "project choice";
$_lang['stop stop watch']= "stop stop watch";
$_lang['still to allocate:']= "still to allocate:";
$_lang['You are not allowed to delete entries from timecard. Please contact your administrator']= "You are not allowed to delete entries from timecard. Please contact your administrator";
$_lang['You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.']= "You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.";
$_lang['You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.']= "You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.";
$_lang['activate+close']="activate+close";

// todos
$_lang['accepted'] = "pie�emts";
$_lang['rejected'] = "atteikts";
$_lang['own'] = "pa�a";
$_lang['progress'] = "progress";
$_lang['delegated to'] = "uztic�t";
$_lang['Assigned from'] = "iecelt no";
$_lang['done'] = "paveikts";
$_lang['Not yet assigned'] = "Not yet assigned";
$_lang['Undertake'] = "Undertake";
$_lang['New todo'] = "New todo"; 
$_lang['Notify recipient'] = "Notify recipient";

// votum.php
$_lang['results of the vote: '] = "balojuma rezult�ts: ";
$_lang['Poll Question: '] = "balojuma jaut�jums: ";
$_lang['several answers possible'] = "iesp�jamas da��das atbildes";
$_lang['Alternative '] = "Alternat�va ";
$_lang['no vote: '] = "nek�da bals: ";
$_lang['of'] = "par";
$_lang['participants have voted in this poll'] = "dal�bnieki nobalsoju�i";
$_lang['Current Open Polls'] = "Pa�reiz balso�an�";
$_lang['Results of Polls'] = "Balsojuma rezult�ta saraksts";
$_lang['New survey'] ="New survey";
$_lang['Alternatives'] ="Alternatives";
$_lang['currently no open polls'] = "Currently there are no open polls";

// export_page.php
$_lang['export_timecard']       = "Export Timecard";
$_lang['export_timecard_admin'] = "Export Timecard";
$_lang['export_users']          = "Export users of this group";
$_lang['export_contacts']       = "Export contacts";
$_lang['export_projects']       = "Export projectdata";
$_lang['export_bookmarks']      = "Export bookmarks";
$_lang['export_timeproj']       = "Export time-to-project data";
$_lang['export_project_stat']   = "Export projectstats";
$_lang['export_todo']           = "Export todos";
$_lang['export_notes']          = "Export notes";
$_lang['export_calendar']       = "Export all calendarevents";
$_lang['export_calendar_detail']= "Export one calendarevent";
$_lang['submit'] = "submit";
$_lang['Address'] = "Address";
$_lang['Next Project'] = "Next Project";
$_lang['Dependend projects'] = "Dependend projects";
$_lang['db_type'] = "Database type";
$_lang['Log in, please'] = "Log in, please";
$_lang['Recipient'] = "Recipient";
$_lang['untreated'] = "untreated";
$_lang['Select participants'] = "Select participants";
$_lang['Participation'] = "Participation";
$_lang['not yet decided'] = "not yet decided";
$_lang['accept'] = "accept";
$_lang['reject'] = "reject";
$_lang['Substitute for'] = "Substitute for";
$_lang['Calendar user'] = "Kalenderbenutzer";
$_lang['Refresh'] = "Refresh";
$_lang['Event'] = "Event";
$_lang['Upload file size is too big'] = "Upload file size is too big";
$_lang['Upload has been interrupted'] = "Upload has been interrupted";
$_lang['view'] = "view";
$_lang['found elements'] = "found elements";
$_lang['chosen elements'] = "chosen elements";
$_lang['too many hits'] = "The result is bigger than we're able to display.";
$_lang['please extend filter'] = "Please extend your filters.";
$_lang['Edit profile'] = "Edit profile";
$_lang['add profile'] = "add profile";
$_lang['Add profile'] = "Add profile";
$_lang['Added profile'] = "Added profile(s).";
$_lang['No profile found'] = "No profile found.";
$_lang['add project participants'] = "add project participants";
$_lang['Added project participants'] = "Added project participants.";
$_lang['add group of participants'] = "add group of participants";
$_lang['Added group of participants'] = "Added group of participants.";
$_lang['add user'] = "add user";
$_lang['Added users'] = "Added user(s).";
$_lang['Selection'] = "Selection";
$_lang['selector'] = "selector";
$_lang['Send email notification']= "Send&nbsp;email&nbsp;notification";
$_lang['Member selection'] = "Member&nbsp;selection";
$_lang['Collision check'] = "Collision check";
$_lang['Collision'] = "Collision";
$_lang['Users, who can represent me'] = "Users, who can represent me";
$_lang['Users, who can see my private events'] = "Users, who can see<br />my private events";
$_lang['Users, who can read my normal events'] = "Users, who can read<br />my normal events";
$_lang['quickadd'] = "Quickadd";
$_lang['set filter'] = "Set filter";
$_lang['Select date'] = "Select date";
$_lang['Next serial events'] = "Next serial events";
$_lang['All day event'] = "All day event";
$_lang['Event is canceled'] = "Event&nbsp;is&nbsp;canceled";
$_lang['Please enter a password!'] = "Please enter a password!";
$_lang['You are not allowed to create an event!'] = "You are not allowed to create an event!";
$_lang['Event successfully created.'] = "Event successfully created.";
$_lang['You are not allowed to edit this event!'] = "You are not allowed to edit this event!";
$_lang['Event successfully updated.'] = "Event successfully updated.";
$_lang['You are not allowed to remove this event!'] = "You are not allowed to remove this event!";
$_lang['Event successfully removed.'] = "Event successfully removed.";
$_lang['Please give a text!'] = "Please give a text!";
$_lang['Please check the event date!'] = "Please check the event date!";
$_lang['Please check your time format!'] = "Please check your time format!";
$_lang['Please check start and end time!'] = "Please check start and end time!";
$_lang['Please check the serial event date!'] = "Please check the serial event date!";
$_lang['The serial event data has no result!'] = "The serial event data has no result!";
$_lang['Really delete this event?'] = "Really delete this event?";
$_lang['use'] = "Use";
$_lang[':'] = ":";
$_lang['Mobile Phone'] = "Mobile Phone";
$_lang['submit'] = "Submit";
$_lang['Further events'] = "Weitere Termine";
$_lang['Remove settings only'] = "Remove settings only";
$_lang['Settings removed.'] = "Settings removed.";
$_lang['User selection'] = "User selection";
$_lang['Release'] = "Release";
$_lang['none'] = "none";
$_lang['only read access to selection'] = "only write access to selection";
$_lang['read and write access to selection'] = "read and write access to selection";
$_lang['Available time'] = "Available time";
$_lang['flat view'] = "List View";
$_lang['o_dateien'] = "Filemanager";
$_lang['Location'] = "Location";
$_lang['date_received'] = "date_received";
$_lang['subject'] = "Subject";
$_lang['kat'] = "Category";
$_lang['projekt'] = "Project";
$_lang['Location'] = "Location";
$_lang['name'] = "Titel";
$_lang['contact'] = "Kontakt";
$_lang['div1'] = "Erstellung";
$_lang['div2'] = "�nderung";
$_lang['kategorie'] = "Kategorie";
$_lang['anfang'] = "Beginn";
$_lang['ende'] = "Ende";
$_lang['status'] = "Status";
$_lang['filename'] = "Titel";
$_lang['deadline'] = "Termin";
$_lang['ext'] = "an";
$_lang['priority'] = "Priorit�t";
$_lang['project'] = "Projekt";
$_lang['Accept'] = "�bernehmen";
$_lang['Please enter your user name here.'] = "Please enter your user name here.";
$_lang['Please enter your password here.'] = "Please enter your password here.";
$_lang['Click here to login.'] = "Click here to login.";
$_lang['No New Polls'] = "No New Polls";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
?>