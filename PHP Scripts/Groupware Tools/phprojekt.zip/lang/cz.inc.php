<?php   // cz.inc.php, Czech (ISO 8859-2) version translated by Luk� Vondr��ek <phprojekt@xaoz.net>
// <translation note: Pokud m�te k p�ekladu jak�koliv n�vrhy nebo p�ipom�nky, pros�m, neprodlen� mne kontaktujte.
// $_lang['iso-8859-2']  = "iso-8859-2";

$chars = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
$name_month = array("", "Led", "�nor", "B�ez", "Duben", "Kv�ten", "�erven", "�ervc.", "Srpen", "Z���", "��jen", "Listop.", "Pros.");
$l_text31a = array("v�choz�", "15 min.", "30 min.", " 1 hod", " 2 hod", " 4 hod", " 1 den");
$l_text31b = array(0, 15, 30, 60, 120, 240, 1440);
$name_day = array("Ned�le", "Pond�l�", "�ter�", "St�eda", "�tvrtek", "P�tek", "Sobota");
$name_day2 = array("Po", "�t", "St", "�t", "P�", "So","Ne");

$_lang['No Entries Found']= "No Entries Found";
$_lang['No Todays Events']= "HNo Todays Events";
$_lang['No new forum postings']= "No new forum postings";
$_lang['in category']= "in category";
$_lang['Filtered']= "Filtered";
$_lang['Sorted by']= "Sorted by";
$_lang['go'] = "OK";
$_lang['back'] = "Zru�it";
$_lang['print'] = "tisk";
$_lang['export'] = "export";
$_lang['| (help)'] = "| (pomoc)";
$_lang['Are you sure?'] = "Jste si jist(a)?";
$_lang['items/page'] = "polo�ek/stran";
$_lang['records'] = "z�znam�"; // elements
$_lang['previous page'] = "p�edchoz� strana";
$_lang['next page'] = "n�sleduj�c� strana";
$_lang['first page'] = "first page";
$_lang['last page'] = "last page";
$_lang['Move']  = "P�esunout";
$_lang['Copy'] = "Kop�rovat";
$_lang['Delete'] = "Smazat";
$_lang['Save'] = "ulo�it";
$_lang['Directory'] = "adres��";
$_lang['Also Delete Contents'] = "smazat tak� obsah";
$_lang['Sum'] = "Sou�et";
$_lang['Filter'] = "Filtr";
$_lang['Please fill in the following field'] = "Pros�m vypl�te n�sleduj�c� pole";
$_lang['approve'] = "povolit";
$_lang['undo'] = "zp�t";
$_lang['Please select!']="Pros�m, prove�te v�b�r!";
$_lang['New'] = "Nov�";
$_lang['Select all'] = "Vybrat v�e";
$_lang['Printable view'] = "Tiskov� n�hled";
$_lang['New record in module '] = "Nov� z�znam v modulu ";
$_lang['Notify all group members'] = "Upozornit v�echny �leny skupiny";
$_lang['Yes'] = "Ano";
$_lang['No'] = "Ne";
$_lang['Close window'] = "Zav��t okno";
$_lang['No Value'] = "nen� hodnota";
$_lang['Standard'] = "Standard";
$_lang['Create'] = "Vytvo�it";
$_lang['Modify'] = "Upravit";   
$_lang['today'] = "Dnes";

// admin.php
$_lang['Password'] = "Heslo";
$_lang['Login'] = "Login";
$_lang['Administration section'] = "Odd�l administr�tora";
$_lang['Your password'] = "Va�e heslo";
$_lang['Sorry you are not allowed to enter. '] = "Je mi l�to, ale sem nem�te p��stup.";
$_lang['Help'] = "Pomoc";
$_lang['User management'] = "Spr�va u�ivatel�";
$_lang['Create'] = "P�idat";
$_lang['Projects'] = "Projekty";
$_lang['Resources'] = "Zdroje";
$_lang['Resources management'] = "Resources management";
$_lang['Bookmarks'] = "Z�lo�ky";
$_lang['for invalid links'] = "Ov��en� platnosti odkaz�";
$_lang['Check'] = "Ov��";
$_lang['delete Bookmark'] = "odstra� z�lo�ku";
$_lang['(multiple select with the Ctrl-key)'] = "(pro v�cen�sobn� v�b�r p�idr�te 'Ctrl')";
$_lang['Forum'] = "Forum";
$_lang['Threads older than'] = "P��sp�vky star�� ne�";
$_lang[' days '] = " dn� ";
$_lang['Chat'] = "Diskuze";
$_lang['save script of current Chat'] = "ulo�en� skriptu b��c� diskuze";
$_lang['Chat script'] = "Script diskuze";
$_lang['New password'] = "Nov� heslo";
$_lang['(keep old password: leave empty)'] = "(bez zm�n: nechte pr�zdn�)";
$_lang['Default Group<br> (must be selected below as well)'] = "V�choz� skupina<br> (mus� b�t vybr�na v��e)";
$_lang['Access rights'] = "P��stup";
$_lang['Zip code'] = "PS�";
$_lang['Language'] = "Jazyk";
$_lang['schedule readable to others'] = "rozvrh viditeln� ostatn�m";
$_lang['schedule invisible to others'] = "rozvrh skryt� p�ed ostatn�mi";
$_lang['schedule visible but not readable'] = "rozvrh bez text� viditeln� ostatn�m";
$_lang['these fields have to be filled in.'] = "tyto polo�ky mus� b�t vypln�ny.";
$_lang['You have to fill in the following fields: family name, short name and password.'] = "Mus�te vyplnit n�sleduj�c� polo�ky: p��jmen�, jm�no a heslo.";
$_lang['This family name already exists! '] = "Toto p��jmen� ji� existuje! ";
$_lang['This short name already exists!'] = "Toto jm�no ji� existuje!";
$_lang['This login name already exists! Please chosse another one.'] = "This login name already exists! Please chosse another one.";
$_lang['This password already exists!'] = "Toto heslo ji� existuje!";
$_lang['This combination first name/family name already exists.'] = "Tato kombinace k�estn�ho jm�na a p��jmen� ji� existuje.";
$_lang['the user is now in the list.'] = "u�ivatel je nyn� za�azen v seznamu.";
$_lang['the data set is now modified.'] = "data set je nyn� modifikov�n.";
$_lang['Please choose a user'] = "Pros�m vyberte u�ivatele";
$_lang['is still listed in some projects. Please remove it.'] = "je st�le za�azen v n�kter�ch projektech. Pros�m odstra�te toto p�i�azen�.";
$_lang['All profiles are deleted'] = "V�echny profily byly odstran�ny";
$_lang['A Profile with the same name already exists'] = "A profile with the same name already exists";
$_lang['is taken out of all user profiles'] = "je odstran�n ze v�ech profil�";
$_lang['All todo lists of the user are deleted'] = "V�echny �kolov� listy u�ivatele byly vymaz�ny";
$_lang['is taken out of these votes where he/she has not yet participated'] = "je odstran�n ze v�ech hlasov�n�, kde je�t� nehlasoval";
$_lang['All events are deleted'] = "V�echny ud�losti byly vymaz�ny";
$_lang['user file deleted'] = "u�ivatelsk� soubor vymaz�n";
$_lang['bank account deleted'] = "bankovn� u�et vymaz�n";
$_lang['finished'] = "dokon�eno";
$_lang['Please choose a project'] = "Pros�m, vyberte projekt";
$_lang['The project is deleted'] = "Projekt byl vymaz�n";
$_lang['All links in events to this project are deleted'] = "V�echny odkazy v ud�lostech tohoto projektu byly vymaz�ny";
$_lang['The duration of the project is incorrect.'] = "Trv�n� projektu nen� v po��dku.";
$_lang['The project is now in the list'] = "Projekt je nyn� za�azen v seznamu";
$_lang['The project has been modified'] = "Projekt byl upraven";
$_lang['Please choose a resource'] = "Pros�m vyberte zdroje";
$_lang['The resource is deleted'] = "Zdroje byly vymaz�ny";
$_lang['All links in events to this resource are deleted'] = "V�echny odkazy v ud�lostech tohoto zdroje byly vymaz�ny";
$_lang[' The resource is now in the list.'] = " Zdroj je nyn� za�azen v seznamu";
$_lang[' The resource has been modified.'] = " Zdroj byl upraven.";
$_lang['The server sent an error message.'] = "Server vr�til n�sleduj�c� chybov� hl�en�";
$_lang['All Links are valid.'] = "V�echny odkazy jsou OK.";
$_lang['Please select at least one bookmark'] = "Pros�m, vyberte alespon jednu z�lo�ku";
$_lang['The bookmark is deleted'] = "Z�lo�ka byla odstran�na";
$_lang['threads older than x days are deleted.'] = "V�echny p��sp�vky star�� ne� x dn� byly vymaz�ny.";
$_lang['All chat scripts are removed'] = "V�echny skripty byly odstra�nny";
$_lang['or'] = "nebo";
$_lang['Timecard management'] = "Management �asov�ch zn�mek";
$_lang['View'] = "Pohled";
$_lang['Choose group'] = "Vyberte skupinu";
$_lang['Group name'] = "Jm�no skupiny";
$_lang['Short form'] = "Zkratka";
$_lang['Category'] = "Kategorie";
$_lang['Remark'] = "Zna�ka";
$_lang['Group management'] = "Spr�va skupin";
$_lang['Please insert a name'] = "Pros�m zadejte jm�no";
$_lang['Name or short form already exists'] = "Jm�no nebo zkratka ji� existuje";
$_lang['Automatic assign to group:'] = "Automatick� p�i�azen� do skupiny:";
$_lang['Automatic assign to user:'] = "Automatick� p�i�azen� k u�ivateli :";
$_lang['Help Desk Category Management'] = "Spr�va RTS kategori�";
$_lang['Category deleted'] = "Kategorie odstran�na";
$_lang['The category has been created'] = "Kategorie byla vytvo�ena";
$_lang['The category has been modified'] = "Kategorie byla zm�n�na";
$_lang['Member of following groups'] = "�len n�sleduj�c�ch skupin";
$_lang['Primary group is not in group list'] = "V�choz� skupina nen� v seznamu";
$_lang['Login name'] = "P�ihla�ovac� jm�no";
$_lang['You cannot delete the default group'] = "Nem��ete vymazat v�choz� skupinu";
$_lang['Delete group and merge contents with group'] = "Vymazat skupinu a p�ipojit jej� obsah ke skupin�";
$_lang['Please choose an element'] = "Pros�m vyberte prvek";
$_lang['Group created'] = "Skupina vytvo�ena";
$_lang['File management'] = "Souborov� management";
$_lang['Orphan files'] = "soubory - sirotci";
$_lang['Deletion of super admin root not possible'] = "Vymaz�n� superadministr�tora root nen� mo�n�";
$_lang['ldap name'] = "ldap jm�no";
$_lang['mobile // mobile phone'] = "mobil"; // mobil phone
$_lang['Normal user'] = "Norm�ln� u�ivatel";
$_lang['User w/Chief Rights'] = "U�ivatel s pr�vy ��fa";
$_lang['Administrator'] = "Administr�tor";
$_lang['Logging'] = "Z�znam";
$_lang['Logout'] = "Logout";
$_lang['posting (and all comments) with an ID'] = "z�pis (a v�echny koment��e) s ID";
$_lang['Role deleted, assignment to users for this role removed'] = "Role vymaz�na, p�i�azen� role u�ivatel�m bylo odstran�no";
$_lang['The role has been created'] = "Role byla vytvo�ena";
$_lang['The role has been modified'] = "Role byla zm�n�na";
$_lang['Access rights'] = "Access rights";
$_lang['Usergroup'] = "Gruppe";
$_lang['logged in as'] = "Angemeldet als";

//chat.php
$_lang['Quit chat']= "Quit chat";

//contacts.php
$_lang['Contact Manager'] = "Kontakt Manager";
$_lang['New contact'] = "Nov� kontakt";
$_lang['Group members'] = "�lenov� skupiny";
$_lang['External contacts'] = "Extern� kontakty";
$_lang['&nbsp;New&nbsp;'] = "&nbsp;Nov�&nbsp;";
$_lang['Import'] = "Import";
$_lang['The new contact has been added'] = "Nov� kontakt byl za�azen";
$_lang['The date of the contact was modified'] = "Datum kontaktu bylo upraveno";
$_lang['The contact has been deleted'] = "Kontakt byl odstran�n";
$_lang['Open to all'] = "Otev��t v�em";
$_lang['Picture'] = "Obr�zek";
$_lang['Please select a vcard (*.vcf)'] = "Pros�m vyberte elektronickou vizitku (*.vcf)";
$_lang['create vcard'] = "vytvo�it elektronickou vizitku";
$_lang['import address book'] = "importovat adresn� knihu";
$_lang['Please select a file (*.csv)'] = "Pros�m, vyberte soubor (*.csv)";
$_lang['Howto: Open your outlook express address book and select file/export/other book<br>Then give the file a name, select all fields in the next dialog and finish'] = "Howto: Otev�ete adresn� knihu sv�ho outlook express a vyberte 'soubor'/'exportovat'/'jin� adres��'<br>
Pot� zadejte jm�no souboru, vyberte v�echna pole v n�sleduj�c�m dialogu a 'dokon�it'";
$_lang['Open outlook at file/export/export in file,<br>choose comma separated values (Win), then select contacts in the next form,<br>give the export file a name and finish.'] = "Zvolte v outlooku 'soubor/exportovat/exportovat do souboru',<br>vyberte 'comma separated values (Win)',
n�sledn� vyberte 'kontakty' v n�sleduj�c�m formul��i,<br>
zadejte jm�no c�lov�ho souboru a dokon�it.";
$_lang['Please choose an export file (*.csv)'] = "Pros�m, vyberte jm�no c�lov�ho souboru (*.csv)";
$_lang['Please export your address book into a comma separated value file (.csv), and either<br>1) apply an import pattern OR<br>2) modify the columns of the table with a spread sheet to this format<br>(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):'] = "Please export your address book into a comma separated value file (.csv), and either<br>
1) apply an import pattern OR<br>
2) modify the columns of the table with a spread sheet to this format<br>
(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):";
$_lang['Please insert at least the family name'] = "Pros�m, uve�te alespo� p��jmen�";
$_lang['Record import failed because of wrong field count'] = "Import z�znam� selhal z d�vodu nespr�vn�ho po�tu sloupc�";
$_lang['Import to approve'] = "Import ke schv�len�";
$_lang['Import list'] = "Import seznamu";
$_lang['The list has been imported.'] = "Seznam byl naimportov�n.";
$_lang['The list has been rejected.'] = "Seznam byl odm�tnut.";
$_lang['Profiles'] = "Profily";
$_lang['Parent object'] = "Nad�azen� objekt";
$_lang['Check for duplicates during import'] = "Hl�dat duplicitn� polo�ky p�i importu";
$_lang['Fields to match'] = "Pole shody";
$_lang['Action for duplicates'] = "Akce p�i duplicit�";
$_lang['Discard duplicates'] = "Nedovolit duplicitu";
$_lang['Dispose as child'] = "Za�adit jako pod��zen�";
$_lang['Store as profile'] = "Ulo�it jako profil";    
$_lang['Apply import pattern'] = "Pou��t sch�ma importu";
$_lang['Import pattern'] = "Sch�ma importu";
$_lang['For modification or creation<br>upload an example csv file'] = "Uploadovat soubor (csv) k importu"; 
$_lang['Skip field'] = "P�esko�it pole";
$_lang['Field separator'] = "Odd�lova�";  
$_lang['Contact selector'] = "P�ep�na� kontaktu";
$_lang['Use doublet'] = "Use doublet";
$_lang['Doublets'] = "Doublets";

// filemanager.php
$_lang['Please select a file'] = "Pros�m, vyberte soubor";
$_lang['A file with this name already exists!'] = "Soubor tohoto jm�na ji� existuje!";
$_lang['Name'] = "N�zev";
$_lang['Comment'] = "Koment��";
$_lang['Date'] = "Datum";
$_lang['Upload'] = "Upload";
$_lang['Filename and path'] = "Jm�no a cesta souboru";
$_lang['Delete file'] = "Odstranit soubor";
$_lang['Overwrite'] = "P�epsat";
$_lang['Access'] = "P��stup";
$_lang['Me'] = "j�";
$_lang['Group'] = "group";
$_lang['Some'] = "n�kdo";
$_lang['As parent object'] = "stejn� jako adres��";
$_lang['All groups'] = "All groups";
$_lang['You are not allowed to overwrite this file since somebody else uploaded it'] = "Nem��ete p�epsat tento soubor, proto�e jej nahr�l n�kdo jin�";
$_lang['personal'] = "osobn�";
$_lang['Link'] = "Odkaz";
$_lang['name and network path'] = "Zadejte cestu";
$_lang['with new values'] = "nov�mi hodnotami";
$_lang['All files in this directory will be removed! Continue?'] = "V�echny soubory v tomto adres��i budou odstran�ny! Pokra�ovat?";
$_lang['This name already exists'] = "Toto jm�no ji� existuje";
$_lang['Max. file size'] = "Max. velikost souboru";
$_lang['links to'] = "odkazuje na";
$_lang['objects'] = "objekty";
$_lang['Action in same directory not possible'] = "Proveden� ve stejn�m adres��i nen� mo�n�";
$_lang['Upload = replace file'] = "Upload = p�eps�n� souboru";
$_lang['Insert password for crypted file'] = "Zadejte heslo k chr�n�n�mu souboru";
$_lang['Crypt upload file with password'] = "Ochr�nit soubor heslem";
$_lang['Repeat'] = "Opakovat";
$_lang['Passwords dont match!'] = "Heslo se neshoduje!";
$_lang['Download of the password protected file '] = "Download souboru chr�n�n�ho heslem ";
$_lang['notify all users with access'] = "upozornit v�echny u�ivatele s p��stupem";
$_lang['Write access'] = "Pr�vo z�pisu";
$_lang['Version'] = "Verze";
$_lang['Version management'] = "Spr�va verz�";
$_lang['lock'] = "zamknout";
$_lang['unlock'] = "odemknout";
$_lang['locked by'] = "uzam�eno - k�m";
$_lang['Alternative Download'] = "Alternativn� download";
$_lang['Download'] = "Download";
$_lang['Select type'] = "Select type";
$_lang['Create directory'] = "Create directory";
$_lang['filesize (Byte)'] = "Filesize (Byte)";

// filter
$_lang['contains'] = 'obsahuje';
$_lang['exact'] = 'p�esn�';
$_lang['starts with'] = 'za��n�';
$_lang['ends with'] = 'kon��';
$_lang['>'] = '>';
$_lang['>='] = '>=';
$_lang['<'] = '<';
$_lang['<='] = '<=';
$_lang['does not contain'] = 'neobsahuje';
$_lang['Please set (other) filters - too many hits!'] = "Please set (other) filters - too many hits!";

$_lang['Edit filter'] = "Edit filter";
$_lang['Filter configuration'] = "Filter configuration";
$_lang['Disable set filters'] = "Disable set filters";
$_lang['Load filter'] = "Load filter";
$_lang['Delete saved filter'] = "Delete saved filter";
$_lang['Save currently set filters'] = "Save currently set filters";
$_lang['Save as'] = "Save as";
$_lang['News'] = 'Nachrichten';

// form designer
$_lang['Module Designer'] = "Modul Designer";
$_lang['Module element'] = "prvek modulu"; 
$_lang['Module'] = "Modul";
$_lang['Active'] = "Aktivn�";
$_lang['Inactive'] = "Neaktivn�";
$_lang['Activate'] = "Aktivovat";
$_lang['Deactivate'] = "Deaktivovat"; 
$_lang['Create new element'] = "Vytvo�it nov� prvek";
$_lang['Modify element'] = "Upravit prvek";
$_lang['Field name in database'] = "jm�no pole v datab�zi";
$_lang['Use only normal characters and numbers, no special characters,spaces etc.'] = "Pou��vejte jen norm�ln� znaky, p�smena a ��sla. Nepou��vejte speci�ln� znaky, mezery apod.";
$_lang['Field name in form'] = "jm�no pole ve formul��i";
$_lang['(could be modified later)'] = "(m��e b�t pozd�ji zm�n�no)"; 
$_lang['Single Text line'] = "jedno��dkov� text";
$_lang['Textarea'] = "Textov� oblast";
$_lang['Display'] = "Zobrazen�";
$_lang['First insert'] = "First insert";
$_lang['Predefined selection'] = "P�eddefinovan� volba";
$_lang['Select by db query'] = "Dotaz do datab�ze";
$_lang['File'] = "Soubor";

$_lang['Email Address'] = "Emailov� Adresa";
$_lang['url'] = "url";
$_lang['Checkbox'] = "Checkbox";
$_lang['Multiple select'] = "V�cen�sobn� v�b�r";
$_lang['Display value from db query'] = "Zobrazit hodnotu dotazu datab�ze";
$_lang['Time'] = "�as";
$_lang['Tooltip'] = "Pom�cky"; 
$_lang['Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied'] = "Zobrazuje se jako p�i pohybu kurzoru polem: Dal�� koment��e k poli nebo vysv�tlen�, pokud je pou�it regul�rn� v�raz";
$_lang['Position'] = "Pozice";
$_lang['is current position, other free positions are:'] = "je aktu�ln� pozic�, ostatn� voln� pozice:"; 
$_lang['Regular Expression:'] = "Regul�rn� v�raz:";
$_lang['Please enter a regular expression to check the input on this field'] = "Pros�m zadejte regul�rn� v�raz pro ov��ov�n� vstupu tohoto pole";
$_lang['Default value'] = "V�choz� hodnota";
$_lang['Predefined value for creation of a record. Could be used in combination with a hidden field as well'] = "P�eddefinovan� hodnota pro vytvo�en� z�znamu. M��e b�t pou�ito tak� v kombinaci se skryt�m pole";
$_lang['Content for select Box'] = "Obsah v�b�rov�ho boxu";
$_lang['Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type'] = "Pou��v� se p�i pevn�m po�tu hodnot (odd�len�ch svisl�tkem: | ) nebo pro v�sledek SQL dotazu, viz. typ prvku";
$_lang['Position in list view'] = "Pozice v pohled seznamu";
$_lang['Only insert a number > 0 if you want that this field appears in the list of this module'] = "Jen zadejte ��slo v�t�� ne� 0 pokud se m� pole zpbrazovat v seznamu tohoto modulu";
$_lang['Alternative list view'] = "Alternativn� pohled seznamu";
$_lang['Value appears in the alt tag of the blue button (mouse over) in the list view'] = "Hodnota bude zobrazena v ALT tagu modr�ho tla��tka (mouse over) v pohledu seznamu";
$_lang['Filter element'] = "Prvek filtru";
$_lang['Appears in the filter select box in the list view'] = "Zobraz� se ve v�b�rov�m boxu filtru v pohledu seznamu";
$_lang['Element Type'] = "Typ prvku";
$_lang['Select the type of this form element'] = "Vyberte typ tohoto prvku formul��e";
$_lang['Check the content of the previous field!'] = "Ov��it hodnotu p�edchoz�ho pole!";
$_lang['Span element over'] = "P�esunout prvek p�es";
$_lang['columns'] = "sloupce";
$_lang['rows'] = "��dky"; 
$_lang['Telephone'] = "Telefon";
$_lang['History'] = "Historie";
$_lang['Field'] = "Pole";
$_lang['Old value'] = "P�vodn� hodnota";
$_lang['New value'] = "Nov� hodnota";
$_lang['Author'] = "Autor"; 
$_lang['Show Date'] = "Zobraz datum";
$_lang['Creation date'] = "Datum vytvo�en�";
$_lang['Last modification date'] = "Datum posledn� �pravy";
$_lang['Email (at record cration)'] = "Email (p�i vlo�en� z�znamu)";
$_lang['Contact (at record cration)'] = "Kontakt (p�i vlo�en� z�znamu)"; 
$_lang['Select user'] = "Vyber u�ivatele";
$_lang['Show user'] = "Zobrazit u�ivatele";

// forum.php
$_lang['Please give your thread a title'] = "Please give your thread a title";
$_lang['New Thread'] = "New Thread";
$_lang['Title'] = "Title";
$_lang['Text'] = "Text";
$_lang['Post'] = "Post";
$_lang['From'] = "From";
$_lang['open'] = "open";
$_lang['closed'] = "closed";
$_lang['Notify me on comments'] = "Notify me on comments";
$_lang['Answer to your posting in the forum'] = "Answer to your posting in the forum";
$_lang['You got an answer to your posting'] = "You got an answer to your posting \n ";
$_lang['New posting'] = "New posting";
$_lang['Create new forum'] = "Create new forum";
$_lang['down'] ='down';
$_lang['up']= "up";
$_lang['Forums']= "Forums";
$_lang['Topics']="Topics";
$_lang['Threads']="Threads";
$_lang['Latest Thread']="Latest Thread";
$_lang['Overview forums']= "Overview forums";
$_lang['Succeeding answers']= "Succeeding answers";
$_lang['Count']= "Count";
$_lang['from']= "from";
$_lang['Path']= "Path";
$_lang['Thread title']= "Thread title";
$_lang['Notification']= "Notification";
$_lang['Delete forum']= "Delete forum";
$_lang['Delete posting']= "Delete posting";
$_lang['In this table you can find all forums listed']= "In this table you can find all forums listed";
$_lang['In this table you can find all threads listed']= "In this table you can find all threads listed";

// index.php
$_lang['Last name'] = "Last name";
$_lang['Short name'] = "Short name";
$_lang['Sorry you are not allowed to enter.'] = "Sorry you are not allowed to enter.";
$_lang['Please run index.php: '] = "Please run index.php: ";
$_lang['Reminder'] = "Reminder";
$_lang['Session time over, please login again'] = "Session time over, please login again";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
$_lang['Tree view'] = "Tree view";
$_lang['flat view'] = "flat view";
$_lang['New todo'] = "New todo";
$_lang['New note'] = "New note";
$_lang['New document'] = "New document";
$_lang['Set bookmark'] = "Set bookmark";
$_lang['Move to archive'] = "Move to archive";
$_lang['Mark as read'] = "Mark as read";
$_lang['Export as csv file'] = "Export as csv file";
$_lang['Deselect all'] = "Deselect all";
$_lang['selected elements'] = "selected elements";
$_lang['wider'] = "wider";
$_lang['narrower'] = "narrower";
$_lang['ascending'] = "Aufsteigend";
$_lang['descending'] = "descending";
$_lang['Column'] = "Column";
$_lang['Sorting'] = "Sorting";
$_lang['Save width'] = "Save width";
$_lang['Width'] = "Width";
$_lang['switch off html editor'] = "switch off html editor";
$_lang['switch on html editor'] = "switch on html editor";
$_lang['hits were shown for'] = "hits were shown for";
$_lang['there were no hits found.'] = "there were no hits found.";
$_lang['Filename'] = "Filename";
$_lang['First Name'] = "First Name";
$_lang['Family Name'] = "Family Name";
$_lang['Company'] = "Company";
$_lang['Street'] = "Street";
$_lang['City'] = "City";
$_lang['Country'] = "Country";
$_lang['Please select the modules where the keyword will be searched'] = "Please select the modules where the keyword will be searched";
$_lang['Enter your keyword(s)'] = "Enter your keyword(s)";
$_lang['Salutation'] = "Salutation";
$_lang['State'] = "State";
$_lang['Add to link list'] = "Add to link list";

// setup.php
$_lang['Welcome to the setup of PHProject!<br>'] = "V�tejte u instalace PHProjekt!<br>";
$_lang['Please remark:<ul><li>A blank database must be available<li>Please ensure that the webserver is able to write the file config.inc.php'] = "Ujist�te se, �e :<ul>
<li>je dostupn� pr�zdn� datab�ze,
<li>a webserver m��e zapisovat do souboru 'config.inc.php'<br> (nap�. 'chmod 777')";
$_lang['<li>If you encounter any errors during the installation, please look into the <a href=help/faq_install.html target=_blank>install faq</a>or visit the <a href=http://www.PHProjekt.com/forum.html target=_blank>Installation forum</a></i>'] = "<li>Pokud naraz�te v pr�b�hu instalace na jak�koliv probl�m, pros�m prostudujte si <a href='help/faq_install.html' target=_blank>dokumentaci</a> 
(zat�m jen v angli�tin� *pozn. p�ekladatele) nebo nav�tivte Instala�n� forum</a> na domovsk� str�nce PHProjektu.</i>";
$_lang['Please fill in the fields below'] = "Pros�m, dopl�te polo�ky uveden� n��e";
$_lang['(In few cases the script wont respond.<br>Cancel the script, close the browser and try it again).<br>'] = "(Ob�as skript vytuhne.<br>
Ukon�ete skript,zav�ete prohl��e� a zkuste to je�t� jednou).<br>";
$_lang['Type of database'] = "Typ datab�ze";
$_lang['Hostname'] = "jm�no po��ta�e";
$_lang['Username'] = "U�ivatel";

$_lang['Name of the existing database'] = "Jm�no existuj�c� datab�ze";
$_lang['config.inc.php not found! Do you really want to update? Please read INSTALL ...'] = "config.inc.php nebyl nalezen! Opravdu hodl�te prov�st update? Pros�m pro�t�te si dokumentaci INSTALL ...";
$_lang['config.inc.php found! Maybe you prefer to update PHProject? Please read INSTALL ...'] = "config.inc.php nalezen! Mo�n� budete cht�t rad�ji update PHProject? Pros�m pro�t�te si dokumentaci INSTALL ...";
$_lang['Please choose Installation,Update or Configure!'] = "Pros�m vyberte 'Installation' nebo 'Update'! zp�t ...";
$_lang['Sorry, I cannot connect to the database! <br>Please close all browser windows and restart the installation.'] = "Sorry, nepracuje to! <br>Pros�m provedte opravu a restartujte instalaci.";
$_lang['Sorry, it does not work! <br> Please set DBDATE to Y4MD- or let phprojekt change this environment-variable (php.ini)!'] = "Sorry, nepracuje to! <br>Pros�m nastavte DBDATE na 'Y4MD-' nebo umo�n�te phprojektu zm�nu prom�nn� prost�ed� (php.ini)!";
$_lang['Seems that You have a valid database connection!'] = "Gratuluji! M�te platn� p�ipojen� k datab�zi!";
$_lang['Please select the modules you are going to use.<br> (You can disable them later in the config.inc.php)<br>'] = "Pros�m, vyberte moduly, kter� si p�ejete instalovat.<br> (Pozd�ji je m��ete zak�zat v config.inc.php)<br>";
$_lang['Install component: insert a 1, otherwise keep the field empty'] = "Instalace komponenty: vlo�te '1', jinak nechejte polo�ku pr�zdnou";
$_lang['Group views'] = "Skupinov� pohledy";
$_lang['Todo lists'] = "�kolov� listy";

$_lang['Voting system'] = "Hlasovac� system";


$_lang['Contact manager'] = "Kontakt manager";
$_lang['Name of userdefined field'] = "Jm�no u�ivatelsky definovan�ho pole";
$_lang['Userdefined'] = "U�ivatelsky definovan�";
$_lang['Profiles for contacts'] = "Profily kontakt�";
$_lang['Mail'] = "Mail";
$_lang['send mail'] = " zas�l�n� zpr�v";
$_lang[' only,<br> &nbsp; &nbsp; full mail client'] = " (jen),<br> &nbsp; &nbsp; �pln� mail klient";



$_lang['1 to show appointment list in separate window,<br>&nbsp; &nbsp; 2 for an additional alert.'] = "'1' ke zobrazen� seznamu p��sp�vk� v separ�tn�m okn�,<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'2' pro p��davn� upozorn�n�.";
$_lang['Alarm'] = "Alarm";
$_lang['max. minutes before the event'] = "max. minut p�ed ud�lost�";
$_lang['SMS/Mail reminder'] = "p�ipom�n�n� SMS/Mail";
$_lang['Reminds via SMS/Email'] = "Upozor�ovat prost�ednictv�m SMS/Email";
$_lang['1= Create projects,<br>&nbsp; &nbsp; 2= assign worktime to projects only with timecard entry<br>&nbsp; &nbsp; 3= assign worktime to projects without timecard entry<br>&nbsp; &nbsp; (Selection 2 or 3 only with module timecard!)'] = "'1'= Vytvo�it projekty,<br>
&nbsp; &nbsp; '2'= p�i�azovat pracovn� �as pouze projekt�m s �asov�mi zn�mkami<br>
&nbsp; &nbsp; '3'= p�i�azovat pracovn� �as i projekt�m bez �asov�ch zn�mek<br> ";

$_lang['Name of the directory where the files will be stored<br>( no file management: empty field)'] = "Jm�no adres��e, kde budou ulo�eny soubory<br>( nebudete=li pou��vat souborov� management: pr�zdn� pole)";
$_lang['absolute path to this directory (no files = empty field)'] = "absolutn� cesta k tomuto adres��i (nebudete=li pou��vat souborov� management: pr�zdn� pole)";
$_lang['Time card'] = "�asov� zn�mky";
$_lang['1 time card system,<br>&nbsp; &nbsp; 2 manual insert afterwards sends copy to the chief'] = "'1' Syst�m �asov�ch zn�mek,<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '2' manu�ln� vlo�en� a zasl�n� zpo�d�nky ��fovi";
$_lang['Notes'] = "Pozn�mky";
$_lang['Password change'] = "Zm�na hesla";
$_lang['New passwords by the user - 0: none - 1: only random passwords - 2: choose own'] = "Nov� hesla zad�van� u�ivatelem - 0: ne - 1: jen n�hodn� - 2: vybrat vlastn�";
$_lang['Encrypt passwords'] = "�ifrovat hesla";
$_lang['Login via '] = "P�ihl�sit prost�ednictv�m ";
$_lang['Extra page for login via SSL'] = "Zvl�tn� str�nka pro p�ihl�en� prost�ednictv�m SSL";
$_lang['Groups'] = "Skupiny";
$_lang['User and module functions are assigned to groups<br>&nbsp; &nbsp; (recommended for user numbers > 40)'] = "Funkce u�ivatel� a modul� jsou p�i�azeny ke skupin�m<br>
&nbsp;&nbsp;&nbsp;&nbsp;(doporu�eno pro po�et u�ivatel� > 40)";
$_lang['User and module functions are assigned to groups'] = "Funkce u�ivatel� a modul� jsou p�i�azeny ke skupin�m";
$_lang['Help desk'] = "Sledov�n� po�adavk� (RT)";
$_lang['Help Desk Manager / Trouble Ticket System'] = "Help desk Manager / Trouble Ticket System";
$_lang['RT Option: Customer can set a due date'] = "RT volba: Z�kazn�k m��e nastavit datum do";
$_lang['RT Option: Customer Authentification'] = "RT volba: Autentikace z�kazn�ka";
$_lang['0: open to all, email-address is sufficient<br>1: registered contact enter his family name<br>2: his email'] = "0: povoleno v�em, email-adresa sta��, 1: z�kazn�k mus� b�t za�azen v kontaktech a mus� zadat p��jmen�";
$_lang['RT Option: Assigning request'] = "RT volba: P�i�azen� po�adavku";
$_lang['0: by everybody, 1: only by persons with status chief'] = "0: k�mkoliv, 1: jen osobou se statutem '��f'";
$_lang['Email Address of the support'] = "Emailov� adresa podpory";
$_lang['Scramble filenames'] = "Skr�vat jm�na soubor�";
$_lang['creates scrambled filenames on the server<br>assigns previous name at download'] = "vytv��� skryt� jm�na soubor� na serveru<br>
a p�i�azuje p�vodn� jm�na a� p�i downloadu";

$_lang['0: last name, 1: short name, 2: login name'] = "0: P��jmen�, 1: p�ezd�vka, 2: login name";
$_lang['Prefix for table names in db'] = "Prefix for table names in db";
$_lang['Alert: Cannot create file config.inc.php!<br>Installation directory needs rwx access for your server and rx access to all others.'] = "Upozorn�n�: Nemohu vytvo�it soubor 'config.inc.php'!<br>
Instala�n� adres�� pot�ebuje RWX p��stup pro v� server a RX p��stup na v�echny ostatn�.";
$_lang['Location of the database'] = "Cesta k datab�zi";
$_lang['Type of database system'] = "Typ datab�zov�ho syst�mu";
$_lang['Username for the access'] = "Jm�no pro p��stup";
$_lang['Password for the access'] = "Heslo pro p��stup";
$_lang['Name of the database'] = "Jm�no datab�ze";
$_lang['Prefix for database table names'] = "Prefix for database table names";
$_lang['First background color'] = "Prvn� podkladov� barva";
$_lang['Second background color'] = "Druh� podkladov� barva";
$_lang['Third background color'] = "T�et� podkladov� barva"; 
$_lang['Color to mark rows'] = "Color to mark rows";
$_lang['Color to highlight rows'] = "Color to highlight rows";
$_lang['Event color in the tables'] = "Barva ud�losti v tabulk�ch";
$_lang['company icon yes = insert name of image'] = "ikona firmy ano = vlo�� logo spole�nosti";
$_lang['URL to the homepage of the company'] = "URL homepage spole�nosti";
$_lang['no = leave empty'] = "ne = nechat pr�zdn�";
$_lang['First hour of the day:'] = "Prvn� hodina dne:";
$_lang['Last hour of the day:'] = "Posledn� hodina dne:";
$_lang['An error ocurred while creating table: '] = "Nastala chyba p�i vytv��en� tabulky: ";
$_lang['Table dateien (for file-handling) created'] = "Tabulka 'dateien' (pro nakl�d�n� soubory) vytvo�ena";
$_lang['File management no = leave empty'] = "Souborov� management ne = nechat pr�zdn�";
$_lang['yes = insert full path'] = "ano = vlo�it uplnou cestu";
$_lang['and the relative path to the PHProjekt directory'] = "a tak� relativn� cestu ke ko�enov�mu adres��i";
$_lang['Table profile (for user-profiles) created'] = "Tabulka 'profile' (pro profily u�ivatel�) vytvo�ena";
$_lang['User Profiles yes = 1, no = 0'] = "Profily ano = 1, ne = 0";
$_lang['Table todo (for todo-lists) created'] = "Tabulka 'todo' (pro seznamy ukol�) vytvo�ena";
$_lang['Todo-Lists yes = 1, no = 0'] = "Seznamy ukol� ano = 1, ne = 0";
$_lang['Table forum (for discssions etc.) created'] = "Tabulka 'forum' (pro diskuze apod.) vytvo�ena";
$_lang['Forum yes = 1, no = 0'] = "Forum ano = 1, ne = 0";
$_lang['Table votum (for polls) created'] = "Tabulka 'votum' (pro hlasov�n�) vytvo�ena";
$_lang['Voting system yes = 1, no = 0'] = "Hlasovac� system ano = 1, ne = 0";
$_lang['Table lesezeichen (for bookmarks) created'] = "Tabulka 'lesezeichen' (pro z�lo�ky) vytvo�ena";
$_lang['Bookmarks yes = 1, no = 0'] = "Z�lo�ky ano = 1, ne = 0";
$_lang['Table ressourcen (for management of additional ressources) created'] = "Tabulka 'ressourcen' (pro management p�idan�ch zdroj�) vytvo�ena";
$_lang['Resources yes = 1, no = 0'] = "Zdroje ano = 1, ne = 0";
$_lang['Table projekte (for project management) created'] = "Tabulka 'projekte' (pro projektov� management) vytvo�ena";
$_lang['Table contacts (for external contacts) created'] = "Tabulka 'contacts' (pro extern� kontakty) vytvo�ena";
$_lang['Table notes (for notes) created'] = "Tabulka notes (pro pozn�mky) vytvo�ena";
$_lang['Table timecard (for time sheet system) created'] = "Tabulka timecard (pro system �asov�ch rozvrh�) vytvo�ena";
$_lang['Table groups (for group management) created'] = "Tabulka groups (pro spr�vu skupin) vytvo�ena";
$_lang['Table timeproj (assigning work time to projects) created'] = "Tabulka timeproj (p�i�azen� �asu projekt�m) vytvo�ena";
$_lang['Table rts and rts_cat (for the help desk) created'] = "Tabulky rts a rts_cat (pro syst�m sledov�n� po�adavk�) vytvo�ena";
$_lang['Table mail_account, mail_attach, mail_client und mail_rules (for the mail reader) created'] = "Tabulky mail_account, mail_attach, mail_client a mail_rules (pro mail reader) vytvo�eny";
$_lang['Table logs (for user login/-out tracking) created'] = "Tabulka logs (pro z�znamy o p�ihla�ov�n�/odhla�ov�n�) vytvo�ena";
$_lang['Tables contacts_profiles und contacts_prof_rel created'] = "Tabulka contacts_profiles a contacts_prof_rel vytvo�ena";
$_lang['Project management yes = 1, no = 0'] = "Projekt management ano = 1, ne = 0";
$_lang['additionally assign resources to events'] = "nav�c p�i�azen� zdroje k ud�lostem";
$_lang['Address book  = 1, nein = 0'] = "Adres�� ano = 1, ne = 0";
$_lang['Mail no = 0, only send = 1, send and receive = 2'] = "Mail ne = 0, jen zas�l�n� = 1, zas�l�n� i p��jem = 2";
$_lang['Chat yes = 1, no = 0'] = "Chat yes = 1, no = 0";
$_lang['Name format in chat list'] = "Name format in chat list";
$_lang['0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name'] = "0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name";
$_lang['Timestamp for chat messages'] = "Timestamp for chat messages";
$_lang['users (for authentification and address management)'] = "Tabulka 'users' (pro autentifikaci a address management) vytvo�ena";
$_lang['Table termine (for events) created'] = "Tabulka 'termine' (pro ud�losti) vytvo�ena";
$_lang['The following users have been inserted successfully in the table user:<br>root - (superuser with all administrative privileges)<br>test - (chief user with restricted access)'] = "N�sleduj�c� u�ivatel� byli p�id�ni do tabulky 'user':<br>
'root' - (superu�ivatel se v�emi administrativn�mi pr�vy)<br>
'test' - (norm�ln� u�ivatel s omezen�mi pr�vy)";
$_lang['The group default has been created'] = "Skupina 'default' byla vytvo�ena";
$_lang['Please do not change anything below this line!'] = "Pros�m, nem�nte nic pod touto �arou!";
$_lang['Database error'] = "Chyba datab�ze";
$_lang['Finished'] = "Ukon�eno";
$_lang['There were errors, please have a look at the messages above'] = "Nalezeny chyby, pros�m zkontrolujte v��e uveden� v�pis chyb";
$_lang['All required tables are installed and <br>the configuration file config.inc.php is rewritten<br>It would be a good idea to makea backup of this file.<br>'] = "V�echny po�adovan� tabulky jsou vytvo�eny.<br>
Konfigura�n� soubor 'config.inc.php'byl p�eps�n<br>
Nebude od v�ci si jej zaz�lohovat.<br>
Nyn� zav�ete v�echna okna prohl��e�e<br>";
$_lang['The administrator root has the password root. Please change his password here:'] = "Administrator 'root' m� heslo 'root'. Toto heslo si pros�m zm��te:";
$_lang['The user test is now member of the group default.<br>Now you can create new groups and add new users to the group'] = "U�ivatel� 'test' jsou �leny skupiny 'default'.<br>
Nyn� m��ete vytv��ete nov� skupiny a jejich u�ivatele";
$_lang['To use PHProject with your Browser go to <b>index.php</b><br>Please test your configuration, especially the modules Mail and Files.'] = "K pou�it� PHProjectu pros�m b�te na <b>index.php</b><br>
Pros�m otestujte si konfiguraci , obzvl�t� 'Mail' a 'Soubory'.";

$_lang['Alarm x minutes before the event'] = "Alarm x minut p�ed ud�lost�";
$_lang['Additional Alarmbox'] = "P��davn� Alarmbox";
$_lang['Mail to the chief'] = "Mail ��fovi";
$_lang['Out/Back counts as: 1: Pause - 0: Workingtime'] = "Voln�/obsazen� �as se po��t� jako: 1: Pauza - 0: doba pr�ce";
$_lang['Passwords will now be encrypted ...'] = "Nyn� budou hesla �ifrov�na";
$_lang['Filenames will now be crypted ...'] = "Jm�na soubor� budou nyn� �ifrov�na ...";
$_lang['Do you want to backup your database right now? (And zip it together with the config.inc.php ...)<br>Of course I will wait!'] = "P�ejete si nyn� zaz�lohovat Va�i datab�zi ? (A zazipovat ji spole�n� s config.inc.php ...)<br>
Jist�, po�k�m!";
$_lang['Next'] = "Dal��";
$_lang['Notification on new event in others calendar'] = "Upozorn�n� na ud�lost v jin�m kalend��i";
$_lang['Path to sendfax'] = "Cesta k sendfaxu";
$_lang['no fax option: leave blank'] = "Pokud nelze faxovat: ponechte pr�zdn�";
$_lang['Please read the FAQ about the installation with postgres'] = "Pros�m, pro�t�te si FAQ k instalaci s datab�z� postgres";
$_lang['Length of short names<br> (Number of letters: 3-6)'] = "D�lka zkr�cen�ch jmen<br> (po�et znak�: 3-6)";
$_lang['If you want to install PHProjekt manually, you find<a href=http://www.phprojekt.com/files/sql_dump.tar.gz target=_blank>here</a> a mysql dump and a default config.inc.php'] = "Pokud hodl�te instalovat PHProjekt ru�n�, pou�ijte soubor
<a href='http://www.phprojekt.com/files/sql_dump.tar.gz' target=_blank>sql_dump</a> nebo mysql dump a v�choz� konfigura�n� soubor config.inc.php";
$_lang['The server needs the privilege to write to the directories'] = "Server mus� m�t pr�vo z�pisu do adres��e";
$_lang['Header groupviews'] = "Hlavi�ka skupinov�ho pohledu";
$_lang['name, F.'] = "jm�no, P.";
$_lang['shortname'] = "p�ezd�vka";
$_lang['loginname'] = "p�ihla�ovac� jm�no";
$_lang['Please create the file directory'] = "Pros�m vytvo�te adres�� pro soubory";
$_lang['default mode for forum tree: 1 - open, 0 - closed'] = "v�choz� m�d pro strom fora: 1 - otev�en�, 0 - uzav�en�";
$_lang['Currency symbol'] = "Znak m�ny";
$_lang['current'] = "sou�asn�";      
$_lang['Default size of form elements'] = "V�choz� velikost prvk� formul��e";
$_lang['use LDAP'] = "pou��t LDAP";
$_lang['Allow parallel events'] = "Povolit paraleln� ud�losti";
$_lang['Timezone difference [h] Server - user'] = "Rozd�l �asov�ch z�n [h] Server - u�ivatel";
$_lang['Timezone'] = "�asov� z�na";
$_lang['max. hits displayed in search module'] = "max. po�et zobrazen�ch v�sledk� vyhled�v�n�";
$_lang['Time limit for sessions'] = "�asov� limit pro sezen�";
$_lang['0: default mode, 1: Only for debugging mode'] = "0: v�choz� m�d, 1: Jen pro lad�c� m�d";
$_lang['Enables mail notification on new elements'] = "Povol� upozorn�t emailem na nov� prvky";
$_lang['Enables versioning for files'] = "Povol� verzov�n� soubor�";
$_lang['no link to contacts in other modules'] = "nezobrazovat odkaz do kontakt� v ostatn�ch modulech";
$_lang['Highlight list records with mouseover'] = "Prosv�t� z�znamy p�i 'mouseover'";
$_lang['Track user login/logout'] = "Sledovat p�ihla�ov�n�/odhla�ov�n�";
$_lang['Access for all groups'] = "P��stup pro v�echny skupiny";
$_lang['Option to release objects in all groups'] = "Umo�nit uvoln�n� objektu ve v�ech skupin�ch";
$_lang['Default access mode: private=0, group=1'] = "V�choz� re�im p��stupu: private=0, group=1"; 
$_lang['Adds -f as 5. parameter to mail(), see php manual'] = "P�id� '-f' jako  5. parametr funkce mail(), viz. php manu�l";
$_lang['end of line in body; e.g. \r\n (conform to RFC 2821 / 2822)'] = "konec ��dku v t�le; nap�. \\r\\n (odpov�d� RFC 2821 / 2822)";
$_lang['end of header line; e.g. \r\n (conform to RFC 2821 / 2822)'] = "konec ��dku v hlavi�ce; e.g. \\r\\n (odpov�d� RFC 2821 / 2822)";
$_lang['Sendmail mode: 0: use mail(); 1: use socket'] = "Sendmail m�d: 0: pou��t mail(); 1: pou��t socket";
$_lang['the real address of the SMTP mail server, you have access to (maybe localhost)'] = "skute�n� adresa SMTP mail serveru, kter� m�te p��stupn� (nap� localhost)";
$_lang['name of the local server to identify it while HELO procedure'] = "jm�no lok�ln�ho serveru k identifikaci p�i HELO procedu�e";
$_lang['Authentication'] = "Autentizace";
$_lang['fill out in case of authentication via POP before SMTP'] = "vypl�te, pokud pou��v�te autentizaci s pou�it�m POP before SMTP";
$_lang['real username for POP before SMTP'] = "skute�n� jm�no u�ivatelsk�ho ��tu pro POP before SMTP";
$_lang['password for this pop account'] = "heslo dan�ho POP ��tu"; 
$_lang['the POP server'] = "POP server";
$_lang['fill out in case of SMTP authentication'] = "vypl�te v p��pad�, �e pou��v�te SMTP autentizaci";
$_lang['real username for SMTP auth'] = "skute�n� jm�no u�ivatelsk�ho ��tu pro SMTP auth";
$_lang['password for this account'] = "heslo dan�ho ��tu";
$_lang['SMTP account data (only needed in case of socket)'] = "data SMTP ��tu (je pot�ebn� jen p�i pou�it� socket�)";
$_lang['No Authentication'] = "Bez Autentizace"; 
$_lang['with POP before SMTP'] = "s POP before SMTP";
$_lang['SMTP auth (via socket only!)'] = "SMTP auth (JEN p�es socket!)";
$_lang['Log history of records'] = "Logovat historii z�znam�";
$_lang['Send'] = " Senden";
$_lang['Host-Path'] = "Host-Path";
$_lang['Installation directory'] = "Installation directory";
$_lang['0 Date assignment by chief, 1 Invitation System'] = "0 Date assignment by chief, 1 Invitation System";
$_lang['0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System'] = "0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System";
$_lang['Default write access mode: private=0, group=1'] = "Default write access mode: private=0, group=1";
$_lang['Select-Option accepted available = 1, not available = 0'] = "Select-Option accepted available = 1, not available = 0";
$_lang['absolute path to host, e.g. http://myhost/'] = "absolute path to host, e.g. http://myhost/";
$_lang['installation directory below host, e.g. myInstallation/of/phprojekt5/'] = "installation directory below host, e.g. myInstallation/of/phprojekt5/";

// l.php
$_lang['Resource List'] = "P�ehled zdroj�";
$_lang['Event List'] = "P�ehled ud�lost�";
$_lang['Calendar Views'] = "Skupiny";

$_lang['Personnel'] = "Personal";
$_lang['Create new event'] = "Vytvo�it &amp; Zru�it ud�lost";
$_lang['Day'] = "Den";

$_lang['Until'] = "Do";

$_lang['Note'] = "Pozn�mka";
$_lang['Project'] = "Projekt";
$_lang['Res'] = "Zdroj";
$_lang['Once'] = "Jednou";
$_lang['Daily'] = "Denn�";
$_lang['Weekly'] = "T�dn�";
$_lang['Monthly'] = "M�s��n�";
$_lang['Yearly'] = "Ro�n�";

$_lang['Create'] = "Vytvo�it";

$_lang['Begin'] = "Za��tek";
$_lang['Out of office'] = "Mimo kancel��";
$_lang['Back in office'] = "Zp�t v kancel��i";
$_lang['End'] = "Konec";
$_lang['@work'] = "@work";
$_lang['We'] = "t�";
$_lang['group events'] = "ud�losti skupin";
$_lang['or profile'] = "nebo profilu";
$_lang['All Day Event'] = "ud�lost na cel� den";
$_lang['time-axis:'] = "�asov� osa:";
$_lang['vertical'] = "vertik�ln�";
$_lang['horizontal'] = "horizont�ln�";
$_lang['Horz. Narrow'] = "hor. omezen�";
$_lang['-interval:'] = "-interval:";
$_lang['Self'] = "Sebe";

$_lang['...write'] = "...z�pis";

$_lang['Calendar dates'] = "Calendar dates";
$_lang['List'] = "List";
$_lang['Year'] = "Year";
$_lang['Month'] = "Month";
$_lang['Week'] = "Week";
$_lang['Substitution'] = "Substitution";
$_lang['Substitution for'] = "Substitution for";
$_lang['Extended&nbsp;selection'] = "Extended&nbsp;selection";
$_lang['New Date'] = "New date entered";
$_lang['Date changed'] = "Date changed";
$_lang['Date deleted'] = "Date deleted";

// links
$_lang['Database table'] = "Database table";
$_lang['Record set'] = "Record set";
$_lang['Resubmission at:'] = "Resubmission at:";
$_lang['Set Links'] = "Links";
$_lang['From date'] = "From date";
$_lang['Call record set'] = "Call record set";


//login.php
$_lang['Please call login.php!'] = "Pros�m spus�te login.php!";

// m1.php
$_lang['There are other events!<br>the critical appointment is: '] = "V uveden� dob� jsou registrov�ny jin� ud�losti!<br>dle�itou polo�kou je: ";
$_lang['Sorry, this resource is already occupied: '] = "Je mi l�to, ale vybran� zdroj je ji� vyu��v�n: ";
$_lang[' This event does not exist.<br> <br> Please check the date and time. '] = " Tato ud�lost neexistuje.<br> <br> Pros�m ov��te si datum a �as. ";
$_lang['Please check your date and time format! '] = "Pros�m, ov��te si form�t data a �asu! ";
$_lang['Please check the date!'] = "Pros�m, ov��te si datum!";
$_lang['Please check the start time! '] = "Pros�m, ov��te si  �as za��tku! ";
$_lang['Please check the end time! '] = "Pros�m, ov��te si �as ukon�en�! ";
$_lang['Please give a text or note!'] = "Pros�m, dopl�te text nebo pozn�mku!";
$_lang['Please check start and end time! '] = "Pros�m, ov��te si �as za��tku a ukon�en�! ";
$_lang['Please check the format of the end date! '] = "Pros�m, ov��te si form�t data ukon�en�! ";
$_lang['Please check the end date! '] = "Pros�m, ov��te si datum ukon�en�! ";





$_lang['Resource'] = "Zdroj";
$_lang['User'] = "U�ivatel";

$_lang['delete event'] = "odstranit ud�lost";
$_lang['Address book'] = "Kniha adres";


$_lang['Short Form'] = "Zkr�cen�";

$_lang['Phone'] = "telefon";
$_lang['Fax'] = "fax";



$_lang['Bookmark'] = "Z�lo�ka";
$_lang['Description'] = "Pozn�mka";

$_lang['Entire List'] = "cel� p�ehled";

$_lang['New event'] = "Nov� ud�lost";
$_lang['Created by'] = "vytvo�eno";
$_lang['Red button -> delete a day event'] = "�erven� tla��tko -> v�maz ud�losti dne";
$_lang['multiple events'] = "v�ce ud�lost�";
$_lang['Year view'] = "Rok";
$_lang['calendar week'] = "kalend��n� t�den";

//m2.php
$_lang['Create &amp; Delete Events'] = "Vytvo�it &amp; odstranit polo�ky";
$_lang['normal'] = "norm�ln�";
$_lang['private'] = "priv�tn�";
$_lang['public'] = "ve�ejn�";
$_lang['Visibility'] = "Viditeln�";

//mail module
$_lang['Please select at least one (valid) address.'] = "Pros�m, vyberte alespo� jednu (platnou) adresu.";
$_lang['Your mail has been sent successfully'] = "Va�e zpr�va byla �sp�n� odesl�na";
$_lang['Attachment'] = "P��loha";
$_lang['Send single mails'] = "zaslat jednotliv� zpr�vy";
$_lang['Does not exist'] = "neexistuje";
$_lang['Additional number'] = "dal�� ��slo";
$_lang['has been canceled'] = "byl(o) zru�en(o)";

$_lang['marked objects'] = "marked objects";
$_lang['Additional address'] = "dal�� adresa";
$_lang['in mails'] = "ve zpr�v�ch";
$_lang['Mail account'] = "e-mail ��et";
$_lang['Body'] = "T�lo";
$_lang['Sender'] = "Odesilatel";

$_lang['Receiver'] = "Adres�t";
$_lang['Reply'] = "Odpov�d�t";
$_lang['Forward'] = "Postoupit";
$_lang['Access error for mailbox'] = "Chyba p��stupu ke schr�nce";
$_lang['Receive'] = "P�ijmout";
$_lang['Write'] = "Odeslat";
$_lang['Accounts'] = "��ty";
$_lang['Rules'] = "Pravidla";
$_lang['host name'] = "jm�no po��ta�e";
$_lang['Type'] = "Typ";
$_lang['misses'] = "pozdr�en";
$_lang['has been created'] = "byl vytvo�en";
$_lang['has been changed'] = "byl zm�n�n";
$_lang['is in field'] = "je v poli";
$_lang['and leave on server'] = "P�ijmout zpr�vy a ponechat je na serveru";
$_lang['name of the rule'] = "jm�no pravidla";
$_lang['part of the word'] = "��st slova";
$_lang['in'] = "v";
$_lang['sent mails'] = "odeslan� zpr�vy";
$_lang['Send date'] = "Odesl�no";
$_lang['Received'] = "P�ijato";
$_lang['to'] = "komu";
$_lang['imcoming Mails'] = "Doru�en� po�ta";
$_lang['sent Mails'] = "Odeslan� po�ta";
$_lang['Contact Profile'] = "Profil kontaktu";
$_lang['unread'] = "nep�e�teno";
$_lang['view mail list'] = "seznam zpr�v";
$_lang['insert db field (only for contacts)'] = "vlo�it pole datab�ze (jen kontakty)";
$_lang['Signature'] = "Podpis";

$_lang['SMS'] = "SMS";
$_lang['Single account query'] = "Jednou�ivatelsk� dotaz";
$_lang['Notice of receipt'] = "Doru�enka"; 
$_lang['Assign to project'] = "P�i�adit k projektu";
$_lang['Assign to contact'] = "P�i�adit ke kontaktu";  
$_lang['Assign to contact according to address'] = "P�i�adit ke kontaktu na z�klad� adresy";
$_lang['Include account for default receipt'] = "P�idat v�choz� ��et pro p��jmy";
$_lang['Your token has already been used.<br>If it wasnt you, who used the token please contact your administrator.'] = "Your token has already been used.<br>If it wasn't you, who used the token please contact your administrator";
$_lang['Your token has already been expired.'] = "Your token has already been expired";
$_lang['Unconfirmed Events'] = "Unconfirmed Events";
$_lang['Visibility presetting when creating an event'] = "Voreinstellung der Sichtbarkeit beim Anlegen eines Termins";
$_lang['Subject'] = "Subject";
$_lang['Content'] = "Inhalt";
$_lang['answer all'] = "answer to all";
$_lang['Create new message'] = "Create new message";
$_lang['Attachments'] = "Attachments";
$_lang['Recipients'] = "Recipients";
$_lang['file away message'] = "file away message";
$_lang['Message from:'] = "Message from:";

//notes.php
$_lang['Mail note to'] = "Odeslat pozn�mku";
$_lang['added'] = "p�id�no";
$_lang['changed'] = "zm�n�no";

// o.php
$_lang['Calendar'] = "Kalend��";
$_lang['Contacts'] = "Kontakty";


$_lang['Files'] = "Soubory";



$_lang['Options'] = "Mo�nosti";
$_lang['Timecard'] = "�asov� zn.";

$_lang['Helpdesk'] = "Helpdesk";

$_lang['Info'] = "Info";
$_lang['Todo'] = "�koly";
$_lang['News'] = "Novinky";
$_lang['Other'] = "Ostatn�";
$_lang['Settings'] = "Nastaven�";
$_lang['Summary'] = "Souhrn";

// options.php
$_lang['Description:'] = "Pozn�mka:";
$_lang['Comment:'] = "Koment��:";
$_lang['Insert a valid Internet address! '] = "Vlo�te platnou Internetovou adresu! ";
$_lang['Please specify a description!'] = "Pros�m up�esn�te pozn�mku!";
$_lang['This address already exists with a different description'] = "Tato adresa ji� existuje, av�ak s jin�m popisem";
$_lang[' already exists. '] = " ji� existuje. ";
$_lang['is taken to the bookmark list.'] = "byla zalo�ena do seznamu odkaz�.";
$_lang[' is changed.'] = " byla zm�n�na.";
$_lang[' is deleted.'] = " byla odstran�na.";
$_lang['Please specify a description! '] = "Pros�m up�esn�te pozn�mku! ";
$_lang['Please select at least one name! '] = "Pros�m vyberte alespo� jedno jm�no! ";
$_lang[' is created as a profile.<br>'] = " byl vytvo�en jako profil.<br> Po obnoven� ��sti Kalend�� bude profil aktivn�.";
$_lang['is changed.<br>'] = "byl zm�n�n.<br> Po obnoven� ��sti Kalend�� bude profil aktivn�.";
$_lang['The profile has been deleted.'] = "Profil byl odstran�n.";
$_lang['Please specify the question for the poll! '] = "Pros�m zadejte ot�zku k hlasov�n�! ";
$_lang['You should give at least one answer! '] = "Mus�te specifikovat alespo� jednu odpov��! ";
$_lang['Your call for votes is now active. '] = "Va�e hlasov�n� je nyn� v chodu. ";
$_lang['<h2>Bookmarks</h2>In this section you can create, modify or delete bookmarks:'] = "<h2>Z�lo�ky</h2>V t�to sekci m��ete vytv��et, m�nit nebo ru�it z�lo�ky:";
$_lang['Create'] = "vytvo�it";


$_lang['<h2>Profiles</h2>In this section you can create, modify or delete profiles:'] = "<h2>Profily</h2>V t�to sekci m��ete vytv��et, m�nit nebo ru�it profily:";
$_lang['<h2>Voting Formula</h2>'] = "<h2>Hlasovac� ot�zka</h2>";
$_lang['In this section you can create a call for votes.'] = "V t�to sekci m��ete vyzvat ostatn� k hlasov�n�.";
$_lang['Question:'] = "Ot�zka:";
$_lang['just one <b>Alternative</b> or'] = "jen jedna <b>Alternativa</b> or";
$_lang['several to choose?'] = "v�ce mo�nost�?";

$_lang['Participants:'] = "��astn�ci:";

$_lang['<h3>Password Change</h3> In this section you can choose a new random generated password.'] = "<h3>Zm�na hesla</h3>V t�to ��sti si m��ete zvolit nov�, n�hodn� generovan� heslo.";
$_lang['Old Password'] = "P�vodn� heslo";
$_lang['Generate a new password'] = "Generuj nov� heslo";
$_lang['Save password'] = "Ulo�it heslo";
$_lang['Your new password has been stored'] = "Va�e nov� heslo bylo ulo�eno";
$_lang['Wrong password'] = "Nespr�vn� heslo";
$_lang['Delete poll'] = "Odstranit volbu";
$_lang['<h4>Delete forum threads</h4> Here you can delete your own threads<br>Only threads without a comment will appear.'] = "<h4>Odstranit diskuzn� vl�kno</h4>Zde m��ete odstranit va�e vlastn� vl�kna v diskuzi<br>
Dot�ena budou jen vl�kna bez koment���.";

$_lang['Old password'] = "P�vodn� heslo";
$_lang['New Password'] = "Nov� heslo";
$_lang['Retype new password'] = "Potvr�te nov� heslo";
$_lang['The new password must have 5 letters at least'] = "Heslo mus� obsahovat nejm�n�  5 znak�";
$_lang['You didnt repeat the new password correctly'] = "Nezopakoval(a) jste heslo spr�vn�";

$_lang['Show bookings'] = "Zobrazit zaknihov�n�";
$_lang['Valid characters'] = "Platn� znaky";
$_lang['Suggestion'] = "Rada";
$_lang['Put the word AND between several phrases'] = "Mezi jednotliv� v�razy vlo�te oper�tor AND "; // translators: please leave the word AND as it is
$_lang['Write access for calendar'] = "Opr�vn�n� k z�pisu do kalend��e";
$_lang['Write access for other users to your calendar'] = "Opr�vn�n� ostatn�ch u�ivatel� k z�pisu do va�eho kalend��e";
$_lang['User with chief status still have write access'] = "U�ivatel se statutem ��fa m� st�le opr�vn�n� k z�pisu";

// projects
$_lang['Project Listing'] = "P�ehled projekt�";
$_lang['Project Name'] = "N�zev projektu";


$_lang['o_files'] = "Files";
$_lang['o_notes'] = "Notes";
$_lang['o_projects'] = "Projects";
$_lang['o_todo'] = "Todo";
$_lang['Copyright']="Copyright";
$_lang['Links'] = "Links";
$_lang['New profile'] = "Neuer Verteiler";
$_lang['In this section you can choose a new random generated password.'] = "In this section you can choose a new random generated password.";
$_lang['timescale'] = "timescale";
$_lang['Manual Scaling'] = "Manual scaling";
$_lang['column view'] = "column view";
$_lang['display format'] = "display format";
$_lang['for chart only'] = "For chart only:";
$_lang['scaling:'] = "scling:";
$_lang['colours:'] = "colours";
$_lang['display project colours'] = "display project colours";
$_lang['weekly'] = "weekly";
$_lang['monthly'] = "monthly";
$_lang['annually'] = "annually";
$_lang['automatic'] = "automatic";
$_lang['New project'] = "New project";
$_lang['Basis data'] = "Basis data";
$_lang['Categorization'] = "Categorization";
$_lang['Real End'] = "Real End";
$_lang['Participants'] = "��astn�ci";
$_lang['Priority'] = "Priorita";
$_lang['Status'] = "Status";
$_lang['Last status change'] = "Posledn� <br>zm�na";
$_lang['Leader'] = "vedouc�";
$_lang['Statistics'] = "Statistiky";
$_lang['My Statistic'] = "My Statistic";

$_lang['Person'] = "Osoba";
$_lang['Hours'] = "Hodin";
$_lang['Project summary'] = "souhrn projektu";
$_lang[' Choose a combination Project/Person'] = " Vyberte kombinaci Projekt/Osoba";
$_lang['(multiple select with the Ctrl/Cmd-key)'] = "(pro v�cen�sobn� v�b�r p�idr� 'Ctrl')";

$_lang['Persons'] = "Ososby";
$_lang['Begin:'] = "Za��tek:";
$_lang['End:'] = "Konec:";
$_lang['All'] = "V�e";
$_lang['Work time booked on'] = "P�i�azen� pracovn� �as";
$_lang['Sub-Project of'] = "Subprojekt";
$_lang['Aim'] = "C�l";
$_lang['Contact'] = "Kontakt";
$_lang['Hourly rate'] = "hodinov� sazba";
$_lang['Calculated budget'] = "p�edkalkulace";
$_lang['New Sub-Project'] = "Nov� subprojekt";
$_lang['Booked To Date'] = "Zaknihov�n od te�";
$_lang['Budget'] = "Rozpo�et";
$_lang['Detailed list'] = "Detailn� seznam";
$_lang['Gantt'] = "�asov� osa";
$_lang['offered'] = "nab�dnuto";
$_lang['ordered'] = "objedn�no";
$_lang['Working'] = "pracuje";
$_lang['ended'] = "ukon�eno";
$_lang['stopped'] = "zastaveno";
$_lang['Re-Opened'] = "znovuotev�eno";
$_lang['waiting'] = "�ek�";
$_lang['Only main projects'] = "Jen hlavn� projekty";
$_lang['Only this project'] = "Only this project";
$_lang['Begin > End'] = "Za��tek > Konec";
$_lang['ISO-Format: yyyy-mm-dd'] = "ISO-Form�t: yyyy-mm-dd";
$_lang['The timespan of this project must be within the timespan of the parent project. Please adjust'] = "�asov� r�mec tohoto projektu se mus� vej�t do r�mce nad�azen�ho projektu. Pros�m, upravte";
$_lang['Please choose at least one person'] = "Pros�m vyberte alespo� jednu osobu";
$_lang['Please choose at least one project'] = "Pros�m vyberte alespo� jeden projekt";
$_lang['Dependency'] = "Z�vislost";
$_lang['Previous'] = "P�edchoz�";

$_lang['cannot start before the end of project'] = "nezle za��t p�ed koncem projektu";
$_lang['cannot start before the start of project'] = "nezle za��t p�ed za��tkem projektu";
$_lang['cannot end before the start of project'] = "nezle skon�it p�ed za��tkem projektu";
$_lang['cannot end before the end of project'] = "nelze skon�it p�ed koncem projektu";
$_lang['Warning, violation of dependency'] = "Upozorn�n�, naru�ena z�vislost";
$_lang['Container'] = "Kontajner";
$_lang['External project'] = "Extern� project";
$_lang['Automatic scaling'] = "Automatick� �k�lov�n�";
$_lang['Legend'] = "Legenda";
$_lang['No value'] = "pr�zdn� hodnota";
$_lang['Copy project branch'] = "Kop�rovat oblast projektu";
$_lang['Copy this element<br> (and all elements below)'] = "Kop�rovat tento prvek<br> (a v�echny prvky n��e)";
$_lang['And put it below this element'] = "A za�adit pod tento prvek";
$_lang['Edit timeframe of a project branch'] = "Editovat �asov� r�mec oblasti projektu"; 

$_lang['of this element<br> (and all elements below)'] = "tento prvek<br> (a v�echny prvky n��e)";  
$_lang['by'] = "k�m";
$_lang['Probability'] = "Pravd�podobnost";
$_lang['Please delete all subelements first'] = "Pros�m nap�ed odstra�te v�echny subprojekty";
$_lang['Assignment'] ="Assignment";
$_lang['display'] = "Display";
$_lang['Normal'] = "Normal";
$_lang['sort by date'] = "Sort by date";
$_lang['sort by'] = "Sort by";
$_lang['Calculated budget has a wrong format'] = "Calculated budget has a wrong format";
$_lang['Hourly rate has a wrong format'] = "Hourly rate has a wrong format";

// r.php
$_lang['please check the status!'] = "pros�m ov��te statut!";
$_lang['Todo List: '] = "P�ehled �kol�: ";
$_lang['New Remark: '] = "Nov� z�znam: ";
$_lang['Delete Remark '] = "Odstarnit z�znam ";
$_lang['Keyword Search'] = "Vyhled�v�n�: ";
$_lang['Events'] = "Ud�losti";
$_lang['the forum'] = "ve foru";
$_lang['the files'] = "v souborech";
$_lang['Addresses'] = "Adresy";
$_lang['Extended'] = "Roz���en�";
$_lang['all modules'] = "v�echny moduly";
$_lang['Bookmarks:'] = "Z�lo�ky:";
$_lang['List'] = "P�ehled";
$_lang['Projects:'] = "Projekty:";

$_lang['Deadline'] = "Deadline";

$_lang['Polls:'] = "Hlasov�n�:";

$_lang['Poll created on the '] = "hlasov�n� vytvo�eno na ";


// reminder.php
$_lang['Starts in'] = "za��n� za";
$_lang['minutes'] = "minut";
$_lang['No events yet today'] = "Zat�m ��dn� dne�n� ud�losti";
$_lang['New mail arrived'] = "Nov� zpr�va";

//ress.php

$_lang['List of Resources'] =  "P�ehled zdroj�";
$_lang['Name of Resource'] = "N�zev zdroje";
$_lang['Comments'] =  "Koment��";


// roles
$_lang['Roles'] = "Role";
$_lang['No access'] = "Bez p��stupu";
$_lang['Read access'] = "�ten�";

$_lang['Role'] = "Role";

//helpdesk - rts
$_lang['Request'] = "Po�adavek";

$_lang['pending requests'] = "existuj�c� po�adavky";
$_lang['show queue'] = "zobrazit frontu";
$_lang['Search the knowledge database'] = "Prohledat datab�zi znalost�";
$_lang['Keyword'] = "Kl��ov� slovo";
$_lang['show results'] = "Zobrazen� v�sledk�";
$_lang['request form'] = "formul�� po�adavku";
$_lang['Enter your keyword'] = "vlo�te kl��ov� slovo";
$_lang['Enter your email'] = "Zadejte sv�j e-mail";
$_lang['Give your request a name'] = "Pojmenujte sv�j po�adavek";
$_lang['Describe your request'] = "Uve�te po�adavek";

$_lang['Due date'] = "Datum do";
$_lang['Days'] = "Dn�";
$_lang['Sorry, you are not in the list'] = "Sorry, nejste v seznamu";
$_lang['Your request Nr. is'] = "V� po�adavek m� ��slo";
$_lang['Customer'] = "Z�kazn�k";


$_lang['Search'] = "Vyhledat";
$_lang['at'] = "k";
$_lang['all fields'] = "v�echna pole";


$_lang['Solution'] = "�e�en�";
$_lang['AND'] = "a";

$_lang['pending'] = "prob�h�";
$_lang['stalled'] = "pozastaven";
$_lang['moved'] = "p�esunut";
$_lang['solved'] = "vy�e�en";
$_lang['Submit'] = "Odeslat";
$_lang['Ass.'] = "P�i�.";
$_lang['Pri.'] = "Pri.";
$_lang['access'] = "p��stup";
$_lang['Assigned'] = "P�i�azen";

$_lang['update'] = "zm�na";
$_lang['remark'] = "zna�ka";
$_lang['solve'] = "�e��";
$_lang['stall'] = "pozastavuje";
$_lang['cancel'] = "Zru�en�";
$_lang['Move to request'] = "P�esunout k po�adavku";
$_lang['Dear customer, please refer to the number given above by contacting us.Will will perform your request as soon as possible.'] = "V�en� z�kazn�ku, pros�m pou��vejte ��slo uveden� v��e p�i kontaktu s n�mi.
V� po�adavek tak bude vy��zen co nejd��ve..";
$_lang['Your request has been added into the request queue.<br>You will receive a confirmation email in some moments.'] = "V� po�adavek byl za�azen do fronty po�adavk�.<br>
Za okam�ik V�m bude zasl�no potvrzen� e-mailem.";
$_lang['n/a'] = "n/a";
$_lang['internal'] = "vnit�n�";

$_lang['has reassigned the following request'] = "byl p�e�azen na�sleduj�c�m po�adavkem";
$_lang['New request'] = "Nov� po�adavek";
$_lang['Assign work time'] = "P�i�adit �as";
$_lang['Assigned to:'] = "P�i�azeno:";

$_lang['Your solution was mailed to the customer and taken into the database.'] = "Va�e �e�en� bylo odesl�no �adateli a uo�eno do datab�za.";
$_lang['Answer to your request Nr.'] = "Odpov�� na V� po�adavek ��slo";
$_lang['Fetch new request by mail'] = "Vyzved�vat nov� po�adavky e-mailem";
$_lang['Your request was solved by'] = "V� po�adavek vy�e�il";

$_lang['Your solution was mailed to the customer and taken into the database'] = "Va�e �e�en� bylo odesl�no zadavateli a ulo�eno do datab�ze";
$_lang['Search term'] = "Search term";
$_lang['Search area'] = "Search area";
$_lang['Extended search'] = "Extended search";
$_lang['knowledge database'] = "knowledge database";
$_lang['Cancel'] = "Cancel";
$_lang['New ticket'] = "New ticket";
$_lang['Ticket status'] ="Ticket status";

// please adjust this states as you want -> add/remove states in helpdesk.php
$_lang['unconfirmed'] = 'unconfirmed';
$_lang['new'] = 'new';
$_lang['assigned'] = 'assigned';
$_lang['reopened'] = 'reopened';
$_lang['resolved'] = 'resolved';
$_lang['verified'] = 'verified';

// settings.php
$_lang['The settings have been modified'] = "Nastaven� bylo zm�n�no";
$_lang['Skin'] = "Skin";
$_lang['First module view on startup'] = "Prvn� modul po startu";
$_lang['none'] = "nic";
$_lang['Check for mail'] = "Odeslat-p�ijmout zpr�vy";
$_lang['Additional alert box'] = "Dopl�uj�c� alert box";
$_lang['Horizontal screen resolution <br>(i.e. 1024, 800)'] = "Horizot�ln� rozli�en� <br>(nap�. 1024, 800)";
$_lang['Chat Entry'] = "Chatov� zpr�va";
$_lang['single line'] = "jedna ��dka";
$_lang['multi lines'] = "v�ce ��dk�";
$_lang['Chat Direction'] = "Chat Direction";
$_lang['Newest messages on top'] = "Newest messages on top";
$_lang['Newest messages at bottom'] = "Newest messages at bottom";
$_lang['File Downloads'] = "Soubory ke sta�en�";

$_lang['Inline'] = "Inline";
$_lang['Lock file'] = "Lock file";
$_lang['Unlock file'] = "nlock file";
$_lang['New file here'] = "New file here";
$_lang['New directory here'] = "New directory here";
$_lang['Position of form'] = "Position of form";
$_lang['On a separate page'] = "On a separate page";
$_lang['Below the list'] = "Below the list";
$_lang['Treeview mode on module startup'] = "Treeview mode on module startup";
$_lang['Elements per page on module startup'] = "Elements per page on module startup";
$_lang['General Settings'] = "General Settings";
$_lang['First view on module startup'] = "First view on module startup";
$_lang['Left frame width [px]'] = "Left frame width [px]";
$_lang['Timestep Daywiew [min]'] = "Timestep Dayview [min]";
$_lang['Timestep Weekwiew [min]'] = "Timestep Weekview [min]";
$_lang['px per char for event text<br>(not exact in case of proportional font)'] = "px per char for event text<br>(not exact in case of proportional font)";
$_lang['Text length of events will be cut'] = "Text length of events will be cut";
$_lang['Standard View'] = "Standard View";
$_lang['Standard View 1'] = "Standard View 1";
$_lang['Standard View 2'] = "Standard View 2";
$_lang['Own Schedule'] = "Own Schedule";
$_lang['Group Schedule'] = "Group Schedule";
$_lang['Group - Create Event'] = "Group - Create Event";
$_lang['Group, only representation'] = "Group, only representation";
$_lang['Holiday file'] = "Holiday file";

// summary
$_lang['Todays Events'] = "Ud�lost� dnes";
$_lang['New files'] = "Nov�ch soubor�";
$_lang['New notes'] = "Nov�ch pozn�mek";
$_lang['New Polls'] = "Nov�ch hlasov�n�";
$_lang['Current projects'] = "Platn�ch projekt�";
$_lang['Help Desk Requests'] = "Po�adavk� helpdesku";
$_lang['Current todos'] = "Platn�ch �kol�";
$_lang['New forum postings'] = "Nov�ch p��sp�vk� ve f�rech";
$_lang['New Mails'] = "Nov�ch zpr�v";

//timecard

$_lang['Theres an error in your time sheet: '] = "Chyba  ve va�em �asov�m v�kazu! Pros�m, zkontrolujte sv� �asov� zn�mky.";




$_lang['Consistency check'] = "Ov��en� konzistence";
$_lang['Please enter the end afterwards at the'] = "pros�m zadejte konec pr�ce";
$_lang['insert'] = "Vlo�it";
$_lang['Enter records afterwards'] = "Zad�vejte z�znamy zp�tn�";
$_lang['Please fill in only emtpy records'] = "Pros�m, vypl�ujte jen pr�zdn� z�znamy";

$_lang['Insert a period, all records in this period will be assigned to this project'] = "Zadejte �asovou periodu. V�echny z�znamy v period� budou p�i�azeny k tomuto projektu";
$_lang['There is no record on this day'] = "V tomto dni nen� ��dn� z�znam";
$_lang['This field is not empty. Please ask the administrator'] = "Toto pole nen� pr�zdn�. Kontaktujte administr�tora";
$_lang['There is no open record with a begin time on this day!'] = "Zadan� datumy nejsou spr�vn�, pros�m ov��te si je.";
$_lang['Please close the open record on this day first!'] = "pros�m zadejte nap�ed zah�jen�";
$_lang['Please check the given time'] = "pros�m ov��te si zadan� �as";
$_lang['Assigning projects'] = "P�i�azuji projekty";
$_lang['Select a day'] = "Vyber den";
$_lang['Copy to the boss'] = "Kopie vedouc�mu";
$_lang['Change in the timecard'] = "Zm�na �asov� zn�mky";
$_lang['Sum for'] = "Suma za";

$_lang['Unassigned time'] = "Nep�i�azen� �as";
$_lang['delete record of this day'] = "vymazat z�znamy tohoto dne";
$_lang['Bookings'] = "Zaknihov�n�";

$_lang['insert additional working time'] = "insert additional working time";
$_lang['Project assignment']= "Project assignment";
$_lang['Working time stop watch']= "Working time stop watch";
$_lang['stop watches']= "stop watches";
$_lang['Project stop watch']= "Project stop watch";
$_lang['Overview my working time']= "Overview my working time";
$_lang['GO']= "GO";
$_lang['Day view']= "Day view";
$_lang['Project view']= "Project view";
$_lang['Weekday']= "Weekday";
$_lang['Start']= "Start";
$_lang['Net time']= "Net time";
$_lang['Project bookings']= "Project bookings";
$_lang['save+close']= "save+close";
$_lang['Working times']= "Working times";
$_lang['Working times start']= "Working times start";
$_lang['Working times stop']= "Working times stop";
$_lang['Project booking start']= "Project booking start";
$_lang['Project booking stop']= "Project booking stop";
$_lang['choose day']= "choose day";
$_lang['choose month']= "choose month";
$_lang['1 day back']= "1 day back";
$_lang['1 day forward']= "1 day forward";
$_lang['Sum working time']= "Sum working time";
$_lang['Time: h / m']= "Time: h / m";
$_lang['activate project stop watch']= "activate project stop watch";
$_lang['activate']= "activate";
$_lang['project choice']= "project choice";
$_lang['stop stop watch']= "stop stop watch";
$_lang['still to allocate:']= "still to allocate:";
$_lang['You are not allowed to delete entries from timecard. Please contact your administrator']= "You are not allowed to delete entries from timecard. Please contact your administrator";
$_lang['You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.']= "You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.";
$_lang['You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.']= "You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.";
$_lang['activate+close']="activate+close";

// todos
$_lang['accepted'] = "p�ijato";
$_lang['rejected'] = "odm�tnuto";
$_lang['own'] = "vlastn�";
$_lang['progress'] = "v�voj";
$_lang['delegated to'] = "delegov�no na";
$_lang['Assigned from'] = "ulo�eno od";
$_lang['done'] = "hotovo";
$_lang['Not yet assigned'] = "zat�m nep�i�azeno";
$_lang['Undertake'] = "P�evz�t";
$_lang['New todo'] = "Nov� �kol"; 
$_lang['Notify recipient'] = "Upozornit p��jemce";

// votum.php
$_lang['results of the vote: '] = "v�sledky hlasov�n�: ";
$_lang['Poll Question: '] = "hlasovac� ot�zka: ";
$_lang['several answers possible'] = "v�ce mo�n�ch odpov�d�";
$_lang['Alternative '] = "Alternativy ";
$_lang['no vote: '] = "bez hlasov�n�: ";
$_lang['of'] = "z";
$_lang['participants have voted in this poll'] = "��astn�ci hlasovali";
$_lang['Current Open Polls'] = "Aktu�ln� otev�en�ch hlasov�n�";
$_lang['Results of Polls'] = "V�sledky v�ech hlasov�n�";
$_lang['New survey'] ="New survey";
$_lang['Alternatives'] ="Alternatives";
$_lang['currently no open polls'] = "Currently there are no open polls";

// export_page.php
$_lang['export_timecard']       = "Export Timecard";
$_lang['export_timecard_admin'] = "Export Timecard";
$_lang['export_users']          = "Export users of this group";
$_lang['export_contacts']       = "Export contacts";
$_lang['export_projects']       = "Export projectdata";
$_lang['export_bookmarks']      = "Export bookmarks";
$_lang['export_timeproj']       = "Export time-to-project data";
$_lang['export_project_stat']   = "Export projectstats";
$_lang['export_todo']           = "Export todos";
$_lang['export_notes']          = "Export notes";
$_lang['export_calendar']       = "Export all calendarevents";
$_lang['export_calendar_detail']= "Export one calendarevent";
$_lang['submit'] = "submit";
$_lang['Address'] = "Address";
$_lang['Next Project'] = "Next Project";
$_lang['Dependend projects'] = "Dependend projects";
$_lang['db_type'] = "Database type";
$_lang['Log in, please'] = "Log in, please";
$_lang['Recipient'] = "Recipient";
$_lang['untreated'] = "untreated";
$_lang['Select participants'] = "Select participants";
$_lang['Participation'] = "Participation";
$_lang['not yet decided'] = "not yet decided";
$_lang['accept'] = "accept";
$_lang['reject'] = "reject";
$_lang['Substitute for'] = "Substitute for";
$_lang['Calendar user'] = "Kalenderbenutzer";
$_lang['Refresh'] = "Refresh";
$_lang['Event'] = "Event";
$_lang['Upload file size is too big'] = "Upload file size is too big";
$_lang['Upload has been interrupted'] = "Upload has been interrupted";
$_lang['view'] = "view";
$_lang['found elements'] = "found elements";
$_lang['chosen elements'] = "chosen elements";
$_lang['too many hits'] = "The result is bigger than we're able to display.";
$_lang['please extend filter'] = "Please extend your filters.";
$_lang['Edit profile'] = "Edit profile";
$_lang['add profile'] = "add profile";
$_lang['Add profile'] = "Add profile";
$_lang['Added profile'] = "Added profile(s).";
$_lang['No profile found'] = "No profile found.";
$_lang['add project participants'] = "add project participants";
$_lang['Added project participants'] = "Added project participants.";
$_lang['add group of participants'] = "add group of participants";
$_lang['Added group of participants'] = "Added group of participants.";
$_lang['add user'] = "add user";
$_lang['Added users'] = "Added user(s).";
$_lang['Selection'] = "Selection";
$_lang['selector'] = "selector";
$_lang['Send email notification']= "Send&nbsp;email&nbsp;notification";
$_lang['Member selection'] = "Member&nbsp;selection";
$_lang['Collision check'] = "Collision check";
$_lang['Collision'] = "Collision";
$_lang['Users, who can represent me'] = "Users, who can represent me";
$_lang['Users, who can see my private events'] = "Users, who can see<br />my private events";
$_lang['Users, who can read my normal events'] = "Users, who can read<br />my normal events";
$_lang['quickadd'] = "Quickadd";
$_lang['set filter'] = "Set filter";
$_lang['Select date'] = "Select date";
$_lang['Next serial events'] = "Next serial events";
$_lang['All day event'] = "All day event";
$_lang['Event is canceled'] = "Event&nbsp;is&nbsp;canceled";
$_lang['Please enter a password!'] = "Please enter a password!";
$_lang['You are not allowed to create an event!'] = "You are not allowed to create an event!";
$_lang['Event successfully created.'] = "Event successfully created.";
$_lang['You are not allowed to edit this event!'] = "You are not allowed to edit this event!";
$_lang['Event successfully updated.'] = "Event successfully updated.";
$_lang['You are not allowed to remove this event!'] = "You are not allowed to remove this event!";
$_lang['Event successfully removed.'] = "Event successfully removed.";
$_lang['Please give a text!'] = "Please give a text!";
$_lang['Please check the event date!'] = "Please check the event date!";
$_lang['Please check your time format!'] = "Please check your time format!";
$_lang['Please check start and end time!'] = "Please check start and end time!";
$_lang['Please check the serial event date!'] = "Please check the serial event date!";
$_lang['The serial event data has no result!'] = "The serial event data has no result!";
$_lang['Really delete this event?'] = "Really delete this event?";
$_lang['use'] = "Use";
$_lang[':'] = ":";
$_lang['Mobile Phone'] = "Mobile Phone";
$_lang['submit'] = "Submit";
$_lang['Further events'] = "Weitere Termine";
$_lang['Remove settings only'] = "Remove settings only";
$_lang['Settings removed.'] = "Settings removed.";
$_lang['User selection'] = "User selection";
$_lang['Release'] = "Release";
$_lang['none'] = "none";
$_lang['only read access to selection'] = "only write access to selection";
$_lang['read and write access to selection'] = "read and write access to selection";
$_lang['Available time'] = "Available time";
$_lang['flat view'] = "List View";
$_lang['o_dateien'] = "Filemanager";
$_lang['Location'] = "Location";
$_lang['date_received'] = "date_received";
$_lang['subject'] = "Subject";
$_lang['kat'] = "Category";
$_lang['projekt'] = "Project";
$_lang['Location'] = "Location";
$_lang['name'] = "Titel";
$_lang['contact'] = "Kontakt";
$_lang['div1'] = "Erstellung";
$_lang['div2'] = "�nderung";
$_lang['kategorie'] = "Kategorie";
$_lang['anfang'] = "Beginn";
$_lang['ende'] = "Ende";
$_lang['status'] = "Status";
$_lang['filename'] = "Titel";
$_lang['deadline'] = "Termin";
$_lang['ext'] = "an";
$_lang['priority'] = "Priorit�t";
$_lang['project'] = "Projekt";
$_lang['Accept'] = "�bernehmen";
$_lang['Please enter your user name here.'] = "Please enter your user name here.";
$_lang['Please enter your password here.'] = "Please enter your password here.";
$_lang['Click here to login.'] = "Click here to login.";
$_lang['No New Polls'] = "No New Polls";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
?>