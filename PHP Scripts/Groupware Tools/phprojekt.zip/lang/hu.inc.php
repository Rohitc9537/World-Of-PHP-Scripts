<?php  // hu.inc.php, hungarian version,
// initial translation by Sandor Feher <fehers@linux-perfect.hu>
// modified by Zoltan Fekete <fekete@mail.szivarvanynet.hu>, 2004.02.13, Budapest v1.2

$chars = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
$name_month = array("", "Jan", "Feb", "M�r", "�pr", "M�j", "J�n", "J�l", "Aug", "Szep", "Okt", "Nov", "Dec");
$l_text31a = array("alap�rtelmez�s", "15 perc", "30 perc", " 1 �ra", " 2 �ra", " 4 �ra", " 1 nap");
$l_text31b = array(0, 15, 30, 60, 120, 240, 1440);
$name_day = array("Vas�rnap", "H�tf�", "Kedd", "Szerda", "Cs�t�rt�k", "P�ntek", "Szombat");
$name_day2 = array("H�", "Ke", "Sze", "Cs�", "P�", "Szo","Vas");

$_lang['No Entries Found']= "No Entries Found";
$_lang['No Todays Events']= "HNo Todays Events";
$_lang['No new forum postings']= "No new forum postings";
$_lang['in category']= "in category";
$_lang['Filtered']= "Filtered";
$_lang['Sorted by']= "Sorted by";
$_lang['submit'] = "mehet";
$_lang['back'] = "vissza";
$_lang['print'] = "nyomtat�s";
$_lang['export'] = "export";
$_lang['| (help)'] = "| (s�g�)";
$_lang['Are you sure?'] = "Biztos benne?";
$_lang['items/page'] = "bejyegyz�s/lap";
$_lang['records'] = "bejegyz�s";
$_lang['previous page'] = "el�z� lap";
$_lang['next page'] = "k�vetkez� lap";
$_lang['first page'] = "first page";
$_lang['last page'] = "last page";
$_lang['Move']  = "Mozgat�s";
$_lang['Copy'] = "M�sol�s";
$_lang['Delete'] = "T�rl�s";
$_lang['Save'] = "ment�s";
$_lang['Directory'] = "K�nyvt�r";
$_lang['Also Delete Contents'] = "t�rli a tartalm�t is";                                                                                 
$_lang['Sum'] = "�sszes�t�";
$_lang['Filter'] = "Sz�r�";
$_lang['Please fill in the following field'] = "K�rem t�ltse ki a k�vetkez� mez�t";
$_lang['approve'] = "j�v�hagy�s";
$_lang['undo'] = "visszavon�s";
$_lang['Please select!']="K�rem v�lasszon!";
$_lang['New'] = "�j";
$_lang['Select all'] = "�sszes kijel�l�se";
$_lang['Printable view'] = "Nyomtat� n�zet";
$_lang['New record in module '] = "�j sor a modulban ";
$_lang['Notify all group members'] = "Minden csoporttag �rtes�t�se";
$_lang['Yes'] = "Igen";
$_lang['No'] = "Nem";
$_lang['Close window'] = "Ablak bez�r�sa";
$_lang['No Value'] = "Nincs �rt�k";
$_lang['Standard'] = "Standard";
$_lang['Create'] = "Anlegen";
$_lang['Modify'] = "�ndern";   
$_lang['today'] = "today";

// admin.php
$_lang['Password'] = "Jelsz�";
$_lang['Login'] = "N�v";
$_lang['Administration section'] = "Adminisztr�ci�s r�sz";
$_lang['Your password'] = "Az �n jelszava";
$_lang['Sorry you are not allowed to enter. '] = "Sajn�lom, nem jogosult a bel�p�sre ! ";
$_lang['Help'] = "S�g�";
$_lang['User management'] = "Felhaszn�l�kezel�";
$_lang['Create'] = "�j...";
$_lang['Projects'] = "Projektek";
$_lang['Resources'] = "Er�forr�sok";
$_lang['Resources management'] = "Resources management";
$_lang['Bookmarks'] = "K�nyvjelz�k";
$_lang['for invalid links'] = "az �rv�nytelen hivatkoz�sokra";
$_lang['Check'] = "Ellen�rz�s";
$_lang['delete Bookmark'] = "K�nyvjelz� t�rl�se";
$_lang['(multiple select with the Ctrl-key)'] = "(t�bbsz�r�s kijel�l�s a 'Ctrl'-gombbal)";
$_lang['Forum'] = "F�rum";
$_lang['Threads older than'] = "";
$_lang[' days '] = " napn�l r�gebbi t�m�k";
$_lang['Chat'] = "Cseveg�s";
$_lang['save script of current Chat'] = "elmenti az aktu�lis cseveg�st";
$_lang['Chat script'] = "Cseveg�";
$_lang['New password'] = "�j jelsz�";
$_lang['(keep old password: leave empty)'] = "(a jelenlegi jelsz� megtart�s�hoz hagyja �resen)";
$_lang['Default Group<br> (must be selected below as well)'] = "Alap�rtelmezett Csoport<br> (ki kell v�lasztani al�bb)";
$_lang['Access rights'] = "Hozz�f�r�si jogok";
$_lang['Zip code'] = "Ir�ny�t�sz�m";
$_lang['Language'] = "Nyelv";
$_lang['schedule readable to others'] = "m�sok �ltal olvashat� id�pont";
$_lang['schedule invisible to others'] = "m�sok �ltal l�thatatlan id�pont";
$_lang['schedule visible but not readable'] = "m�sok �ltal l�that�, de nem olvashat� id�pont";
$_lang['these fields have to be filled in.'] = "ezeket a mez�ket ki kell t�lteni.";
$_lang['You have to fill in the following fields: family name, short name and password.'] = "Ki kell t�ltenie a k�vetkez� mez�ket: csal�dn�v, r�vidn�v �s jelsz�.";
$_lang['This family name already exists! '] = "Ez a csal�dn�v m�r l�tezik! ";
$_lang['This short name already exists!'] = "Ez a r�vidn�v m�r l�tezik!";
$_lang['This login name already exists! Please chosse another one.'] = "A megadott felhaszn�l�i azonos�t� m�r l�tezik! K�rem, v�lasszon m�sikat.";
$_lang['This password already exists!'] = "Ez a jelsz� m�r l�tezik!";
$_lang['This combination first name/family name already exists.'] = "A keresztn�v/csal�dn�v ebben a kombin�ci�ban m�r l�tezik.";
$_lang['the user is now in the list.'] = "a felhaszn�l� beker�lt a list�ba.";
$_lang['the data set is now modified.'] = "az adatok m�dosultak.";
$_lang['Please choose a user'] = "K�rem v�lasszon egy felhaszn�l�t";
$_lang['is still listed in some projects. Please remove it.'] = "m�g szerepel n�h�ny projektben. K�rem t�vol�tsa el.";
$_lang['All profiles are deleted'] = "Minden profil t�r�lve";
$_lang['A Profile with the same name already exists'] = "A profile with the same name already exists";
$_lang['is taken out of all user profiles'] = "kiv�ve az �sszes profilb�l";
$_lang['All todo lists of the user are deleted'] = "A felhaszn�l� �sszes teend�je t�r�lve lett a list�r�l";
$_lang['is taken out of these votes where he/she has not yet participated'] = "kiv�ve azon szavazatokb�l amikben m�g nem vett r�szt eddig";
$_lang['All events are deleted'] = "�sszes esem�ny t�r�lve";
$_lang['user file deleted'] = "a felhaszn�l� f�jlai t�rl�dtek";
$_lang['bank account deleted'] = "a banksz�mla t�rl�d�tt";
$_lang['finished'] = "k�sz";
$_lang['Please choose a project'] = "K�rem v�lasszon egy projektet";
$_lang['The project is deleted'] = "A projekt t�r�lve";
$_lang['All links in events to this project are deleted'] = "Az �sszes ehhez a projekthez tartoz� link t�r�lve lett";
$_lang['The duration of the project is incorrect.'] = "A projekt id�tartama �rv�nytelen.";
$_lang['The project is now in the list'] = "A projekt a list�ban van";
$_lang['The project has been modified'] = "A projekt m�dos�tva lett";
$_lang['Please choose a resource'] = "K�rem v�lasszon egy er�forr�st";
$_lang['The resource is deleted'] = "Az er�forr�s t�r�lve";
$_lang['All links in events to this resource are deleted'] = "Az �sszes ehhez az er�forr�shoz tartoz� link t�r�lve lett";
$_lang[' The resource is now in the list.'] = " Az er�forr�s a list�ban van.";
$_lang[' The resource has been modified.'] = " Az er�forr�s m�dosult.";
$_lang['The server sent an error message.'] = "A szerver hiba�zenetet k�ld�tt.";
$_lang['All Links are valid.'] = "Az �sszes link �rv�nyes.";
$_lang['Please select at least one bookmark'] = "K�rem v�lasszon legal�bb egy k�nyvjelz�t";
$_lang['The bookmark is deleted'] = "A k�nyvjelz� t�r�lve";
$_lang['threads older than x days are deleted.'] = "A x napn�l r�gebbi t�m�k t�r�lve lettek.";
$_lang['All chat scripts are removed'] = "Az �sszes cseveg� script el lett t�vol�tva";
$_lang['or'] = "vagy";
$_lang['Timecard management'] = "Id�k�rtya menedzsment";
$_lang['View'] = "Megtekint";
$_lang['Choose group'] = "V�lasszon csoportot";
$_lang['Group name'] = "Csoport neve";
$_lang['Short form'] = "R�vid forma";
$_lang['Category'] = "Kateg�ria";
$_lang['Remark'] = "Megjegyz�s";
$_lang['Group management'] = "Csoport menedzsment";
$_lang['Please insert a name'] = "K�rem adjon meg egy nevet";
$_lang['Name or short form already exists'] = "A n�v vagy a r�vid forma m�r l�tezik";
$_lang['Automatic assign to group:'] = "Automatikus hozz�rendel�s ehhez a csoporthoz:";
$_lang['Automatic assign to user:'] = "Automatikus hozz�rendel�s ehhez a felhaszn�l�hoz:";
$_lang['Help Desk Category Management'] = "Helpdesk kateg�ria menedzsment";
$_lang['Category deleted'] = "Kateg�ria t�rlve";
$_lang['The category has been created'] = "A kateg�ria l�trej�tt";
$_lang['The category has been modified'] = "A kateg�ria m�dosult";
$_lang['Member of following groups'] = "Tagja a k�vetkez� csoportoknak";
$_lang['Primary group is not in group list'] = "Az els�dleges csoport nincs a csoportlist�ban";
$_lang['Login name'] = "Login n�v";
$_lang['You cannot delete the default group'] = "Nem t�r�lheti az alap�rtelmezett csoportot";
$_lang['Delete group and merge contents with group'] = "T�rli a csoportot �s �sszef�zi a csoport tartalm�t egy m�sik csoporttal";
$_lang['Please choose an element'] = "K�rem v�lasszon egy elemet";
$_lang['Group created'] = "A csoport l�trej�tt";
$_lang['File management'] = "F�jl menedzsment";
$_lang['Orphan files'] = "�rva f�jlok";
$_lang['Deletion of super admin root not possible'] = "A szuperfelhaszn�l� nem t�r�lhet�";
$_lang['ldap name'] = "ldap n�v";
$_lang['mobile // mobile phone'] = "mobiltelefon";
$_lang['Normal user'] = "Norm�l felhaszn�l�";
$_lang['User w/Chief Rights'] = "Felhaszn�l� f�n�k jogokkal";
$_lang['Administrator'] = "Adminisztr�tor";
$_lang['Logging'] = "Logging";
$_lang['Logout'] = "Logout";
$_lang['posting (and all comments) with an ID'] = "posting (and all comments) with an ID";
$_lang['Role deleted, assignment to users for this role removed'] = "Role deleted, assignment to users for this role removed";
$_lang['The role has been created'] = "The role has been created";
$_lang['The role has been modified'] = "The role has been modified";
$_lang['Access rights'] = "Access rights";
$_lang['Usergroup'] = "Gruppe";
$_lang['logged in as'] = "Angemeldet als";

//chat.php
$_lang['Quit chat']= "Quit chat";

//contacts.php
$_lang['Contact Manager'] = "Kapcsolatkezel�";
$_lang['New contact'] = "�j kapcsolat";
$_lang['Group members'] = "Csoport tagjai";
$_lang['External contacts'] = "K�ls� kapcsolatok";
$_lang['&nbsp;New&nbsp;'] = "�j l�trehoz�sa";
$_lang['Import'] = "Import�l�s";
$_lang['The new contact has been added'] = "Az �j kapcsolat hozz�adva";
$_lang['The date of the contact was modified'] = "A kapcsolat d�tuma m�dos�tva";
$_lang['The contact has been deleted'] = "A kapcsolat t�r�lve";
$_lang['Open to all'] = "Minden felhaszn�l� l�thatja";
$_lang['Picture'] = "K�p";
$_lang['Please select a vcard (*.vcf)'] = "K�rem v�lasszon egy n�vjegyet (*.vcf)";
$_lang['create vcard'] = "n�vjegy l�trehoz�sa";
$_lang['import address book'] = "c�mjegyz�k import�l�s";
$_lang['Please select a file (*.csv)'] = "K�rem v�lasszon egy f�jlt (*.csv)";
$_lang['Howto: Open your outlook express address book and select file/export/other book<br>Then give the file a name, select all fields in the next dialog and finish'] = "Hogyan: Nyissa meg az �n Outlook Express-�nek c�mjegyz�k�t �s v�lassza a 'f�jl'/'export'/'m�sik k�nyvet'<br>
Ezut�n adja meg a f�jlnevet, v�lassza ki az �sszes mez�t a k�vetkez� dial�gusban �s 'k�sz'";
$_lang['Open outlook at file/export/export in file,<br>choose comma separated values (Win), then select contacts in the next form,<br>give the export file a name and finish.'] = "Nyissa meg az outlook-ot a 'f�le/export/export f�jlba pontn�l',<br>
v�lassza a 'vessz�vel elv�laszott �rt�keket (Win)', azut�n v�lassza a
'kapcsolatokat' a k�vetkez� form�ban,<br> adja meg az export f�jl nev�t �s k�sz.";
$_lang['Please choose an export file (*.csv)'] = "K�rem v�lasszon egy export f�jl nevet (*.csv)";
$_lang['Please export your address book into a comma separated value file (.csv), and either<br>1) apply an import pattern OR<br>2) modify the columns of the table with a spread sheet to this format<br>(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):'] = "Please export your address book into a comma separated value file (.csv), and either<br>
1) apply an import pattern OR<br>
2) modify the columns of the table with a spread sheet to this format<br>
(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):";
$_lang['Please insert at least the family name'] = "K�rem adja meg legal�bba a csal�dnevet";
$_lang['Record import failed because of wrong field count'] = "A rekord beolvas�s elbukott a rossz mez�sz�m miatt";
$_lang['Import to approve'] = "A j�v�hagyand� import";
$_lang['Import list'] = "Import lista";
$_lang['The list has been imported.'] = "A lista import�lva.";
$_lang['The list has been rejected.'] = "A lista elutat�tva.";
$_lang['Profiles'] = "Profilok";
$_lang['Parent object'] = "Sz�l�objektum";
$_lang['Check for duplicates during import'] = "Az import�l�s alatt a kett�s t�telek ellen�rz�se";
$_lang['Fields to match'] = "Illeszked� mez�k";
$_lang['Action for duplicates'] = "Kett�s bejegyz�sek eset�n";
$_lang['Discard duplicates'] = "Elutas�t�s";
$_lang['Dispose as child'] = "Elhelyez�s, mint gyermek objektum";
$_lang['Store as profile'] = "T�rol�s profilk�nt";    
$_lang['Apply import pattern'] = "Import�l�si minta alkalmaz�sa";
$_lang['Import pattern'] = "Import�l�si minta";
$_lang['For modification or creation<br>upload an example csv file'] = "Import f�jl felt�lt�se (.csv)"; 
$_lang['Skip field'] = "Mez� �tugr�sa";
$_lang['Field separator'] = "Mez�hat�rol�";
$_lang['Contact selector'] = "Contact selector";
$_lang['Use doublet'] = "Use doublet";
$_lang['Doublets'] = "Doublets";

// filemanager.php
$_lang['Please select a file'] = "K�rem v�lasszon egy f�jlnevet";
$_lang['A file with this name already exists!'] = "Ilyen nev� f�jln�v m�r l�tezik!";
$_lang['Name'] = "N�v";
$_lang['Comment'] = "Megjegyz�s";
$_lang['Date'] = "D�tum";
$_lang['Upload'] = "Felt�lt�s";
$_lang['Filename and path'] = "F�jln�v �s el�r�si �t";
$_lang['Delete file'] = "F�jlt t�rl�se";
$_lang['Overwrite'] = "Fel�l�r�s";
$_lang['Access'] = "Hozz�f�r�s";
$_lang['Me'] = "�n";
$_lang['Group'] = "csoport";
$_lang['Some'] = "az al�bbiak: ";
$_lang['As parent object'] = "a k�nyvt�rral megegyez�en";
$_lang['All groups'] = "Minden csoport";
$_lang['You are not allowed to overwrite this file since somebody else uploaded it'] = "Nem jogosult fel�l�rni ezt a f�jlt, mert valaki m�s id�k�zben megv�ltoztatta";
$_lang['personal'] = "szem�lyes";
$_lang['Link'] = "Hivatkoz�s";
$_lang['name and network path'] = "n�v �s h�l�zati el�r�si �t";
$_lang['with new values'] = "�j �rt�kekkel";
$_lang['All files in this directory will be removed! Continue?'] = "A k�nyvt�r �sszes �llom�nya t�rl�dik! Folytatja?";
$_lang['This name already exists'] = "Ez a n�v m�r l�tezik";
$_lang['Max. file size'] = "Max. f�jlm�ret";
$_lang['links to'] = "hivatkoz�st a";
$_lang['objects'] = "objektumok";
$_lang['Action in same directory not possible'] = "Nem lehets�ges azonos k�nyvt�ron bel�li m�velet";
$_lang['Upload = replace file'] = "Felt�lt�s = f�jlcsere";
$_lang['Insert password for crypted file'] = "Titkos�t�si jelsz�";
$_lang['Crypt upload file with password'] = "Titkos�t�s";
$_lang['Repeat'] = "Jelsz� m�gegyszer";
$_lang['Passwords dont match!'] = "A jelszavak nem egyeznek meg!";
$_lang['Download of the password protected file '] = "Titkos�tott f�jl let�lt�se ";
$_lang['notify all users with access'] = "Minden �rintett felhaszn�l� �rtes�t�se";
$_lang['Write access'] = "�r�si jog";
$_lang['Version'] = "V�ltozat";
$_lang['Version management'] = "V�ltozatok k�vet�se";
$_lang['lock'] = "z�rol�s";
$_lang['unlock'] = "z�rol�s felold�sa";
$_lang['locked by'] = "z�rolja: ";
$_lang['Alternative Download'] = "Let�lt�s m�sk�nt";
$_lang['Download'] = "Download";
$_lang['Select type'] = "Select type";
$_lang['Create directory'] = "Create directory";
$_lang['filesize (Byte)'] = "Filesize (Byte)";

// filter
$_lang['contains'] = 'tartalmazza';
$_lang['exact'] = 'pontosan';
$_lang['starts with'] = 'kezd�dik';
$_lang['ends with'] = 'v�gz�dik';
$_lang['>'] = '>';
$_lang['>='] = '>=';
$_lang['<'] = '<';
$_lang['<='] = '<=';
$_lang['does not contain'] = 'nem tartalmazza';
$_lang['Please set (other) filters - too many hits!'] = "Please set (other) filters - too many hits!";

$_lang['Edit filter'] = "Edit filter";
$_lang['Filter configuration'] = "Filter configuration";
$_lang['Disable set filters'] = "Disable set filters";
$_lang['Load filter'] = "Load filter";
$_lang['Delete saved filter'] = "Delete saved filter";
$_lang['Save currently set filters'] = "Save currently set filters";
$_lang['Save as'] = "Save as";
$_lang['News'] = 'Nachrichten';

// form designer
$_lang['Module Designer'] = "Modultervez�";
$_lang['Module element'] = "Module elem"; 
$_lang['Module'] = "Modul";
$_lang['Active'] = "Akt�v";
$_lang['Inactive'] = "Inakt�v";
$_lang['Activate'] = "Aktiv�l�s";
$_lang['Deactivate'] = "Inaktiv�l�s"; 
$_lang['Create new element'] = "�j elem l�trehoz�sa";
$_lang['Modify element'] = "Elem m�dos�t�sa";
$_lang['Field name in database'] = "Mez� neve az adatb�zisban";
$_lang['Use only normal characters and numbers, no special characters,spaces etc.'] = "Csak az angol ABC bet�it �s sz�mokat haszn�ljon, a speci�lis jeleket, sz�k�z�ket ker�lje!";
$_lang['Field name in form'] = "Mez� neve az �rlapon";
$_lang['(could be modified later)'] = "(k�s�bb nem m�dos�that�)"; 
$_lang['Single Text line'] = "Egy sornyi sz�veg";
$_lang['Textarea'] = "Sz�vegmez�";
$_lang['Display'] = "K�perny�";
$_lang['First insert'] = "El�sz�r besz�r�s";
$_lang['Predefined selection'] = "El�re defini�lt kijel�l�s";
$_lang['Select by db query'] = "Adatb�zis lek�rdez�s";
$_lang['File'] = "�llom�ny";

$_lang['Email Address'] = "Elektronikus lev�lc�m";
$_lang['url'] = "url";
$_lang['Checkbox'] = "Jel�l�n�gyzet";
$_lang['Multiple select'] = "T�bbsz�r�s v�laszt�s";
$_lang['Display value from db query'] = "Display value from db query";
$_lang['Time'] = "Time";
$_lang['Tooltip'] = "Eszk�ztipp"; 
$_lang['Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied'] = "Ha az eg�rrel a mez� f�l� �ll, tippet jelen�t meg";
$_lang['Position'] = "Poz�cio";
$_lang['is current position, other free positions are:'] = "a jelenlegi poz�ci�, egy�b szabad poz�ci�k:"; 
$_lang['Regular Expression:'] = "Szab�lyos kifejez�s:";
$_lang['Please enter a regular expression to check the input on this field'] = "Adjon meg szab�lyos kifejez�st a mez� ellen�rz�s�hez";
$_lang['Default value'] = "Alap�rt�k";
$_lang['Predefined value for creation of a record. Could be used in combination with a hidden field as well'] = "A mez� el�re megadott alap�rt�ke. Rejtett mez�vel egy�tt is haszn�lhat�";
$_lang['Content for select Box'] = "Content for select Box";
$_lang['Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type'] = "Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type";
$_lang['Position in list view'] = "Poz�ci� a lista n�zetben";
$_lang['Only insert a number > 0 if you want that this field appears in the list of this module'] = "Csak akkor adjon 0-n�l nagyobb �rt�ket, ha szeretn�, hogy ez a mez� megjelenjen a modul list�j�ban";
$_lang['Alternative list view'] = "Alternat�v lista n�zet";
$_lang['Value appears in the alt tag of the blue button (mouse over) in the list view'] = "Value appears in the alt tag of the blue button (mouse over) in the list view";
$_lang['Filter element'] = "Sz�r� elem";
$_lang['Appears in the filter select box in the list view'] = "Lista n�zet alatt a sz�r� kiv�laszt� dobozban jelenik meg";
$_lang['Element Type'] = "Elemt�pus";
$_lang['Select the type of this form element'] = "V�lassza ki az �rlap t�pus�t";
$_lang['Check the content of the previous field!'] = "Ellen�rizze az el�z� mez� tartalm�t!";
$_lang['Span element over'] = "�ltesse az elemet a(z)";
$_lang['columns'] = "oszlopokra";
$_lang['rows'] = "sorokra";
$_lang['Telephone'] = "Telephone";
$_lang['History'] = "History";
$_lang['Field'] = "Field";
$_lang['Old value'] = "Old value";
$_lang['New value'] = "New value";
$_lang['Author'] = "Author"; 
$_lang['Show Date'] = "Show Date";
$_lang['Creation date'] = "Creation date";
$_lang['Last modification date'] = "Last modification date";
$_lang['Email (at record cration)'] = "Email (at record cration)";
$_lang['Contact (at record cration)'] = "Contact (at record cration)"; 
$_lang['Select user'] = "Select user";
$_lang['Show user'] = "Show user";

// forum.php
$_lang['Please give your thread a title'] = "Please give your thread a title";
$_lang['New Thread'] = "New Thread";
$_lang['Title'] = "Title";
$_lang['Text'] = "Text";
$_lang['Post'] = "Post";
$_lang['From'] = "From";
$_lang['open'] = "open";
$_lang['closed'] = "closed";
$_lang['Notify me on comments'] = "Notify me on comments";
$_lang['Answer to your posting in the forum'] = "Answer to your posting in the forum";
$_lang['You got an answer to your posting'] = "You got an answer to your posting \n ";
$_lang['New posting'] = "New posting";
$_lang['Create new forum'] = "Create new forum";
$_lang['down'] ='down';
$_lang['up']= "up";
$_lang['Forums']= "Forums";
$_lang['Topics']="Topics";
$_lang['Threads']="Threads";
$_lang['Latest Thread']="Latest Thread";
$_lang['Overview forums']= "Overview forums";
$_lang['Succeeding answers']= "Succeeding answers";
$_lang['Count']= "Count";
$_lang['from']= "from";
$_lang['Path']= "Path";
$_lang['Thread title']= "Thread title";
$_lang['Notification']= "Notification";
$_lang['Delete forum']= "Delete forum";
$_lang['Delete posting']= "Delete posting";
$_lang['In this table you can find all forums listed']= "In this table you can find all forums listed";
$_lang['In this table you can find all threads listed']= "In this table you can find all threads listed";

// index.php
$_lang['Last name'] = "Last name";
$_lang['Short name'] = "Short name";
$_lang['Sorry you are not allowed to enter.'] = "Sorry you are not allowed to enter.";
$_lang['Please run index.php: '] = "Please run index.php: ";
$_lang['Reminder'] = "Reminder";
$_lang['Session time over, please login again'] = "Session time over, please login again";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
$_lang['Tree view'] = "Tree view";
$_lang['flat view'] = "flat view";
$_lang['New todo'] = "New todo";
$_lang['New note'] = "New note";
$_lang['New document'] = "New document";
$_lang['Set bookmark'] = "Set bookmark";
$_lang['Move to archive'] = "Move to archive";
$_lang['Mark as read'] = "Mark as read";
$_lang['Export as csv file'] = "Export as csv file";
$_lang['Deselect all'] = "Deselect all";
$_lang['selected elements'] = "selected elements";
$_lang['wider'] = "wider";
$_lang['narrower'] = "narrower";
$_lang['ascending'] = "Aufsteigend";
$_lang['descending'] = "descending";
$_lang['Column'] = "Column";
$_lang['Sorting'] = "Sorting";
$_lang['Save width'] = "Save width";
$_lang['Width'] = "Width";
$_lang['switch off html editor'] = "switch off html editor";
$_lang['switch on html editor'] = "switch on html editor";
$_lang['hits were shown for'] = "hits were shown for";
$_lang['there were no hits found.'] = "there were no hits found.";
$_lang['Filename'] = "Filename";
$_lang['First Name'] = "First Name";
$_lang['Family Name'] = "Family Name";
$_lang['Company'] = "Company";
$_lang['Street'] = "Street";
$_lang['City'] = "City";
$_lang['Country'] = "Country";
$_lang['Please select the modules where the keyword will be searched'] = "Please select the modules where the keyword will be searched";
$_lang['Enter your keyword(s)'] = "Enter your keyword(s)";
$_lang['Salutation'] = "Salutation";
$_lang['State'] = "State";
$_lang['Add to link list'] = "Add to link list";

// setup.php
$_lang['Welcome to the setup of PHProject!<br>'] = "A PHProject install�l� programja �dv�zli �nt!<br>";
$_lang['Please remark:<ul><li>A blank database must be available<li>Please ensure that the webserver is able to write the file config.inc.php'] = "K�rem jegyezze meg a k�vetkez�ket:<ul>
<li>Egy �res adatb�zis kell, hogy rendelkez�sre �lljon
<li>Gy�z�dj�n meg r�la, hogy a webszerver k�pes �rni a 'config.inc.php'<br> f�jlt (e.g. 'chmod 777')";
$_lang['<li>If you encounter any errors during the installation, please look into the <a href=help/faq_install.html target=_blank>install faq</a>or visit the <a href=http://www.PHProjekt.com/forum.html target=_blank>Installation forum</a></i>'] = "<li>Ha b�rmilyen hib�t tapasztal az install�ci� alatt k�rem n�zzen bele a <a href='help/faq_install.html' target=_blank>install�ci�s GYIK-be</a>
vagy l�togassa meg a <a href='http://www.PHProjekt.com/forum.html' target=_blank>Install�ci�s f�rumot</a></i>";
$_lang['Please fill in the fields below'] = "K�rem t�ltse ki az al�bbi mez�ket";
$_lang['(In few cases the script wont respond.<br>Cancel the script, close the browser and try it again).<br>'] = "(N�h�ny esetben a script nem fog reag�lni.<br>
Szak�tsa meg a scriptet, z�rja be a b�ng�sz�t �s pr�b�lja �jra).<br>";
$_lang['Type of database'] = "Az adatb�zis t�pusa";
$_lang['Hostname'] = "Gazdan�v";
$_lang['Username'] = "Felhaszn�l�n�v";

$_lang['Name of the existing database'] = "A l�tez� adatb�zis neve";
$_lang['config.inc.php not found! Do you really want to update? Please read INSTALL ...'] = "config.inc.php nem tal�lhat�! Val�ban friss�teni akar? K�rem olvassa el az INSTALL-t...";
$_lang['config.inc.php found! Maybe you prefer to update PHProject? Please read INSTALL ...'] = "config.inc.php megvan! Ink�bb szeretn� friss�teni a PHProject-et? K�rem olvassa el az INSTALL-t ...";
$_lang['Please choose Installation,Update or Configure!'] = "K�rem v�lassza aze 'Install�ci�' vagy a 'Friss�t�s' pontokat! vissza ...";
$_lang['Sorry, I cannot connect to the database! <br>Please close all browser windows and restart the installation.'] = "Sajn�lom, ez nem m�k�dik! <br>K�rem jav�tsa ki �s ind�tsa �jra az install�l�st.";
$_lang['Sorry, it does not work! <br> Please set DBDATE to Y4MD- or let phprojekt change this environment-variable (php.ini)!'] = "Sajn�lom, ez nem m�k�dik! <br> K�rem �ll�tsa a DBDATE v�ltoz�t 'Y4MD-'-re vagy hagyja hogy a phprojekt v�ltoztassa meg azt (php.ini)!";
$_lang['Seems that You have a valid database connection!'] = "�gy t�nik, hogy van egy �rv�nyes adatb�zis kapcsolata!";
$_lang['Please select the modules you are going to use.<br> (You can disable them later in the config.inc.php)<br>'] = "K�rem v�lassza ki azokat a modulokat amiket haszn�lni akar.<br> (Kikapcsolhatja �ket k�s�bb a config.inc.php f�jlban)<br>";
$_lang['Install component: insert a 1, otherwise keep the field empty'] = "�sszetev� install�l�sa: adjon meg egy '1'-est, vagy hagyja �resen a mez�t.";
$_lang['Group views'] = "Csoport n�zetek";
$_lang['Todo lists'] = "Tennival�k list�ja";

$_lang['Voting system'] = "Szavaz�rendszer";


$_lang['Contact manager'] = "Kapcsolat menedzser";
$_lang['Name of userdefined field'] = "Name of userdefined field";
$_lang['Userdefined'] = "Userdefined";
$_lang['Profiles for contacts'] = "Profiles for contacts";
$_lang['send mail'] = " csak levelet";
$_lang[' only,<br> &nbsp; &nbsp; full mail client'] = " k�ld,<br> &nbsp; &nbsp; teljes levelez� kliens";
$_lang['Mail'] = "Gyorslev�l";



$_lang['1 to show appointment list in separate window,<br>&nbsp; &nbsp; 2 for an additional alert.'] = "'1', hogy k�l�nb�z� ablakokban l�ssa a tal�lkoz�k list�j�t,<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'2' egy tov�bbi eml�keztet�h�z.";
$_lang['Alarm'] = "Riaszt�s";
$_lang['max. minutes before the event'] = "max. percek sz�ma az esem�ny el�tt";
$_lang['SMS/Mail reminder'] = "SMS/Mail reminder";
$_lang['Reminds via SMS/Email'] = "Reminds via SMS/Email";
$_lang['1= Create projects,<br>&nbsp; &nbsp; 2= assign worktime to projects only with timecard entry<br>&nbsp; &nbsp; 3= assign worktime to projects without timecard entry<br>&nbsp; &nbsp; (Selection 2 or 3 only with module timecard!)'] = "'1'= Projekteket hoz l�tre,<br>
&nbsp; &nbsp; '2'= csak az id�k�rty�kon szerepl� id� rendelhet� a projekthez<br>
&nbsp; &nbsp; '3'= az id�k�rtya bejegyz�sen k�v�li id� is hozz�rendelhet� a projekthez<br> ";

$_lang['Name of the directory where the files will be stored<br>( no file management: empty field)'] = "A k�nyvt�r neve, ahol a f�jlok t�rolva lesznek<br>( nincs f�jl menedzsment: �res mez�)";
$_lang['absolute path to this directory (no files = empty field)'] = "abszolut el�r�si �t ehhez a k�nyvt�rhoz (nincsenek f�jlok = �res mez�)";
$_lang['Time card'] = "Id�k�tya";
$_lang['1 time card system,<br>&nbsp; &nbsp; 2 manual insert afterwards sends copy to the chief'] = "'1' id�k�rtya rendszer,<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '2' k�zi beilleszt�s miut�n m�solatot k�ld�tt a s�fnek";
$_lang['Notes'] = "Megjegyz�sek";
$_lang['Password change'] = "Jelsz�v�lt�s";
$_lang['New passwords by the user - 0: none - 1: only random passwords - 2: choose own'] = "A felhaszn�l� �ltal adhat� �j jelszavak - 0: nincs - 1: v�letlen jelszavak - 2: saj�tot v�laszt";
$_lang['Encrypt passwords'] = "Jelszavak titkos�t�sa";
$_lang['Login via '] = "Bel�p ";
$_lang['Extra page for login via SSL'] = "Extra lap az SSL-en kereszt�li bejelentkez�shez";
$_lang['Groups'] = "Csoport";
$_lang['User and module functions are assigned to groups<br>&nbsp; &nbsp; (recommended for user numbers > 40)'] = "Felhaszn�l�i �s modul funkci�k csoportokhoz vannak rendelve<br>
&nbsp;&nbsp;&nbsp;&nbsp;(javasolt 40 feletti felhaszn�l�sz�m eset�n)";
$_lang['User and module functions are assigned to groups'] = "Felhaszn�l�i �s modul funkci�k csoportokhoz vannak rendelve";
$_lang['Help desk'] = "K�r�s K�vet�s (RT)";
$_lang['Help Desk Manager / Trouble Ticket System'] = "Help Desk Menedzser / Trouble Ticket Rendszer";
$_lang['RT Option: Customer can set a due date'] = "RT Opci�: Az �gyf�l be�ll�thatja a hat�rid�t";
$_lang['RT Option: Customer Authentification'] = "RT Opci�: �gyf�l azonos�t�s";
$_lang['0: open to all, email-address is sufficient<br>1: registered contact enter his family name<br>2: his email'] = "0: nyitva mindenkinek, email-c�m el�gs�ges, 1: �gyf�l rajta kell, hogy legyen a kapcsolat list�n �s meg kell adnia a vezet�knev�t";
$_lang['RT Option: Assigning request'] = "RT Opci�: K�r�sek hozz�rendel�se";
$_lang['0: by everybody, 1: only by persons with status chief'] = "0: mindenki �ltal, 1: csak a 's�f' st�tusz� szem�lyek �ltal";
$_lang['Email Address of the support'] = "A support email c�me";
$_lang['Scramble filenames'] = "�sszekeveri a f�jlneveket";
$_lang['creates scrambled filenames on the server<br>assigns previous name at download'] = "�sszekevert f�jlneveket hoz l�tre a szerveren<br>
az eredeti nevet hozz�rendeli let�lt�skor";

$_lang['0: last name, 1: short name, 2: login name'] = "0: keresztn�v, 1: r�vidn�v, 2: login n�v";
$_lang['Prefix for table names in db'] = "Prefix for table names in db";
$_lang['Alert: Cannot create file config.inc.php!<br>Installation directory needs rwx access for your server and rx access to all others.'] = "Figyelem: Nem hozhat� l�tre a 'config.inc.php' f�jl!<br>
Az install�ci�s k�nyvt�rnak rwx enged�lyekre van sz�ks�ge a szerveren �s rx enged�lyekre minden egy�bre.";
$_lang['Location of the database'] = "Az adatb�zis helye";
$_lang['Type of database system'] = "Az adatb�zis t�pusa";
$_lang['Username for the access'] = "Felhaszn�l�n�v az adatb�zishoz";
$_lang['Password for the access'] = "Jelsz� az adatb�zishoz";
$_lang['Name of the database'] = "Az adatb�zis neve";
$_lang['Prefix for database table names'] = "Prefix for database table names";
$_lang['First background color'] = "Els� h�tt�rsz�n";
$_lang['Second background color'] = "M�sodik h�tt�rsz�n";
$_lang['Third background color'] = "Harmadik h�tt�rsz�n"; 
$_lang['Color to mark rows'] = "Color to mark rows";
$_lang['Color to highlight rows'] = "Color to highlight rows";
$_lang['Event color in the tables'] = "Esem�nysz�nek a t�bl�kban";
$_lang['company icon yes = insert name of image'] = "c�ges ikon igen = adja meg a k�p nev�t";
$_lang['URL to the homepage of the company'] = "URL a c�g honlapj�ra";
$_lang['no = leave empty'] = "nincs = hagyja �resen";
$_lang['First hour of the day:'] = "A nap els� �r�ja:";
$_lang['Last hour of the day:'] = "A nap utols� �r�ja:";
$_lang['An error ocurred while creating table: '] = "Hiba a k�vetkez� t�bla l�trehoz�sa k�zben: ";
$_lang['Table dateien (for file-handling) created'] = "A 'dateien' t�bla (f�jlkezel�sre) l�trej�tt";
$_lang['File management no = leave empty'] = "F�jl menedzsment nincs = hagyja �resen";
$_lang['yes = insert full path'] = "igen = adja meg a teljes el�r�si utat";
$_lang['and the relative path to the PHProjekt directory'] = "�s j�rul�kosan a gy�k�r k�nyvt�r el�r�si �tj�t";
$_lang['Table profile (for user-profiles) created'] = "A 'profile' k�nyvt�r (a felhaszn�l�i profilok r�sz�re) l�trej�tt";
$_lang['User Profiles yes = 1, no = 0'] = "Profilok igen = 1, nem = 0";
$_lang['Table todo (for todo-lists) created'] = "A 'todo' t�bla (a tennival�k list�j�hoz) l�trej�tt";
$_lang['Todo-Lists yes = 1, no = 0'] = "Tennival�k list�ja igen = 1, nem = 0";
$_lang['Table forum (for discssions etc.) created'] = "A 'forum' t�bla (a vitaf�rumokhoz stb.) l�trej�tt";
$_lang['Forum yes = 1, no = 0'] = "F�rum igen = 1, nem = 0";
$_lang['Table votum (for polls) created'] = "A 'votum' t�bla (a szavaz�sokhoz) l�trej�tt";
$_lang['Voting system yes = 1, no = 0'] = "Szavaz�rendszer igen = 1, nem = 0";
$_lang['Table lesezeichen (for bookmarks) created'] = "A 'lesezeichen' t�bla (a k�nyvjelz�knek) l�trej�tt";
$_lang['Bookmarks yes = 1, no = 0'] = "K�nyvjelz�k igen = 1, nem = 0";
$_lang['Table ressourcen (for management of additional ressources) created'] = "A 'ressourcen't�bla (a j�rul�kos er�forr�sok menedzsel�s�hez) l�trej�tt";
$_lang['Resources yes = 1, no = 0'] = "Er�forr�sok igen = 1, nem = 0";
$_lang['Table projekte (for project management) created'] = "A 'projekte' t�bla (a projekt menedzsmenthez) l�trej�tt";
$_lang['Table contacts (for external contacts) created'] = "A contacts t�bla (k�ls� kapcsolatok kezel�s�hez) l�trej�tt";
$_lang['Table notes (for notes) created'] = "A notes t�bla (a megjegyz�sekhez) l�trej�tt";
$_lang['Table timecard (for time sheet system) created'] = "A timecard t�bla (az id�kezel� rendszerhez) l�trej�tt";
$_lang['Table groups (for group management) created'] = "A groups t�bla (a csoport menedzsmenthez) l�trej�tt";
$_lang['Table timeproj (assigning work time to projects) created'] = "A timeproj t�bla (munkaid� hozz�rendel�s projektekhez) l�trej�tt";
$_lang['Table rts and rts_cat (for the help desk) created'] = "Az rts �s rts_cat t�bl�k (a k�r�skezel� rendszerhez) l�trej�ttek";
$_lang['Table mail_account, mail_attach, mail_client und mail_rules (for the mail reader) created'] = "A mail_account, mail_attach, mail_client �s mail_rules t�bl�k (a lev�l olvas�hoz) l�trej�ttek";
$_lang['Table logs (for user login/-out tracking) created'] = "Table logs (for user login/-out tracking) created";
$_lang['Tables contacts_profiles und contacts_prof_rel created'] = "Tables contacts_profiles und contacts_prof_rel created";
$_lang['Project management yes = 1, no = 0'] = "Projekt menedzsment igen = 1, nem = 0";
$_lang['additionally assign resources to events'] = "j�rul�kos er�forr�sok hozz�rendel�se esem�nyekhez";
$_lang['Address book  = 1, nein = 0'] = "C�mjegyz�k igen = 1, nem = 0";
$_lang['Mail no = 0, only send = 1, send and receive = 2'] = "Gyorslev�l igen = 1, nem = 0";
$_lang['Chat yes = 1, no = 0'] = "Chat yes = 1, no = 0";
$_lang['Name format in chat list'] = "Name format in chat list";
$_lang['0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name'] = "0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name";
$_lang['Timestamp for chat messages'] = "Timestamp for chat messages";
$_lang['users (for authentification and address management)'] = "'users' t�bla (az azonos�t�shoz �s c�mkezel�shez)";
$_lang['Table termine (for events) created'] = "A 'termine' t�bla (az esem�nyekhez) l�trej�tt";
$_lang['The following users have been inserted successfully in the table user:<br>root - (superuser with all administrative privileges)<br>test - (chief user with restricted access)'] = "A k�vetkez� felhaszn�l�k sikeresen beker�ltek a k�vetkez� t�bl�ba 'user':<br>
'root' - (szuperfelhaszn�l� az �sszes adminiszt�ci�s joggal)<br>
'test' - (s�f felhaszn�l� szab�lyozott hozz�f�r�ssel";
$_lang['The group default has been created'] = "A 'default' csoport sikeresen l�trej�tt";
$_lang['Please do not change anything below this line!'] = "K�rem semmit ne v�ltoztasson meg ezalatt a vonal alatt!";
$_lang['Database error'] = "Adatb�zis hiba";
$_lang['Finished'] = "K�sz";
$_lang['There were errors, please have a look at the messages above'] = "Hib�k fordultak el�, k�rem vessen egy pillant�st az al�bbi �zenetre";
$_lang['All required tables are installed and <br>the configuration file config.inc.php is rewritten<br>It would be a good idea to makea backup of this file.<br>'] = "Az �sszes sz�ks�ges t�bla sikeresen install�lva lett �s <br>
a 'config.inc.php' konfigur�ci�s f�jl �jra lett �rva<br>
J� �tlet, ha csin�l egy m�solatot err�l a f�jlr�l.<br>
Most z�rja be az �sszes b�ng�sz�ablakot.<br>";
$_lang['The administrator root has the password root. Please change his password here:'] = "Az adminisztr�tor 'root' jelszava 'root' lesz. K�rem cser�lje le ezt a jelsz�t.<br>";
$_lang['The user test is now member of the group default.<br>Now you can create new groups and add new users to the group'] = "A 'test' felhaszn�l� a 'default' csoport tagja lett.<br>
Most l�tre tud hozni �j csoportokat �s hozz� tud adni �j felhaszn�l�kat a csoportokhoz";
$_lang['To use PHProject with your Browser go to <b>index.php</b><br>Please test your configuration, especially the modules Mail and Files.'] = "A PHProject haszn�lat�hoz a b�ng�sz�j�vel menjen az <b>index.php</b>-ra<br>
K�rem, tesztelje a konfigur�ci�t k�l�n�s tekintettel a 'Gyorslev�l' �s 'F�jlok' modulokra.";

$_lang['Alarm x minutes before the event'] = "Riaszt�s x perccel az esem�ny el�tt";
$_lang['Additional Alarmbox'] = "J�rul�kos Riaszt�doboz";
$_lang['Mail to the chief'] = "Lev�l a s�fnek";
$_lang['Out/Back counts as: 1: Pause - 0: Workingtime'] = "Ki/Vissza sz�mol, mint: 1: Sz�net - 0: Munkaid�";
$_lang['Passwords will now be encrypted ...'] = "A jelszavak most m�r titkos�tva vannak";
$_lang['Filenames will now be crypted ...'] = "A f�jlnevek mostant�l titkos�tva lesznek ...";
$_lang['Do you want to backup your database right now? (And zip it together with the config.inc.php ...)<br>Of course I will wait!'] = "Szeretne most biztons�gi m�solatot k�sz�teni az adatb�zisr�l?
(�s zip-elje �ket �ssze a config.inc.php -vel...)<br>Persze, hogy v�rok!";
$_lang['Next'] = "K�vetkez�";
$_lang['Notification on new event in others calendar'] = "A m�sok napt�r�ban l�trej�v� �j esem�nyekr�l �rtes�t�s";
$_lang['Path to sendfax'] = "A sendfax el�r�si �tja";
$_lang['no fax option: leave blank'] = "nincs fax opci�: hagyja �resen";
$_lang['Please read the FAQ about the installation with postgres'] = "K�rem olvassal el a GYIK a postgres install�ci�r�l";
$_lang['Length of short names<br> (Number of letters: 3-6)'] = "A r�vidnevek hossza<br> (Bet�k sz�ma: 3-6)";
$_lang['If you want to install PHProjekt manually, you find<a href=http://www.phprojekt.com/files/sql_dump.tar.gz target=_blank>here</a> a mysql dump and a default config.inc.php'] = "Ha k�zzel install�lja a PHProjekt-et, megtal�lja a
<a href='http://www.phprojekt.com/files/sql_dump.tar.gz' target=_blank>c�men</a> egy mysql dump �s egy alap�rtelmezett config.inc.php f�jl is megtal�lhat�";
$_lang['The server needs the privilege to write to the directories'] = "A szervernek sz�ks�ge van '�r�si'jogosults�gra ehhez a k�nyvt�rhoz";
$_lang['Header groupviews'] = "A csoport n�zetek fejl�ce";
$_lang['name, F.'] = "n�v, F.";
$_lang['shortname'] = "r�vidn�v";
$_lang['loginname'] = "loginn�v";
$_lang['Please create the file directory'] = "K�rem hozza l�tre a f�jl k�nyvt�rat";
$_lang['default mode for forum tree: 1 - open, 0 - closed'] = "az alap�rtelmezett m�d a f�rum f�hoz: 1 - nyitva, 0 - z�rva";
$_lang['Currency symbol'] = "Valuta szimb�lum";
$_lang['current'] = "aktu�lis";
$_lang['Default size of form elements'] = "Default size of form elements";
$_lang['use LDAP'] = "LDAP-t haszn�l";
$_lang['Allow parallel events'] = "Megengedi a p�rhuzamos esem�nyeket";
$_lang['Timezone difference [h] Server - user'] = "Id�z�na elt�r�s [h] Szerver - felhaszn�l�";
$_lang['Timezone'] = "Id�z�na";
$_lang['max. hits displayed in search module'] = "max. megjelen�tett tal�latok sz�ma a keres�si modulban";
$_lang['Time limit for sessions'] = "Time limit for sessions";
$_lang['0: default mode, 1: Only for debugging mode'] = "0: default mode, 1: Only for debugging mode";
$_lang['Enables mail notification on new elements'] = "Enables mail notification on new elements";
$_lang['Enables versioning for files'] = "Enables versioning for files";
$_lang['no link to contacts in other modules'] = "no link to contacts in other modules";
$_lang['Highlight list records with mouseover'] = "Highlight list records with 'mouseover'";
$_lang['Track user login/logout'] = "Track user login/logout";
$_lang['Access for all groups'] = "Access for all groups";
$_lang['Option to release objects in all groups'] = "Option to release objects in all groups";
$_lang['Default access mode: private=0, group=1'] = "Default access mode: private=0, group=1"; 
$_lang['Adds -f as 5. parameter to mail(), see php manual'] = "Adds '-f' as 5. parameter to mail(), see php manual";
$_lang['end of line in body; e.g. \r\n (conform to RFC 2821 / 2822)'] = "end of line in body; e.g. \\r\\n (conform to RFC 2821 / 2822)";
$_lang['end of header line; e.g. \r\n (conform to RFC 2821 / 2822)'] = "end of header line; e.g. \\r\\n (conform to RFC 2821 / 2822)";
$_lang['Sendmail mode: 0: use mail(); 1: use socket'] = "Sendmail mode: 0: use mail(); 1: use socket";
$_lang['the real address of the SMTP mail server, you have access to (maybe localhost)'] = "the real address of the SMTP mail server, you have access to (maybe localhost)";
$_lang['name of the local server to identify it while HELO procedure'] = "name of the local server to identify it while HELO procedure";
$_lang['Authentication'] = "Authentication";
$_lang['fill out in case of authentication via POP before SMTP'] = "fill out in case of authentication via POP before SMTP";
$_lang['real username for POP before SMTP'] = "real username for POP before SMTP";
$_lang['password for this pop account'] = "password for this pop account"; 
$_lang['the POP server'] = "the POP server";
$_lang['fill out in case of SMTP authentication'] = "fill out in case of SMTP authentication";
$_lang['real username for SMTP auth'] = "real username for SMTP auth";
$_lang['password for this account'] = "password for this account";
$_lang['SMTP account data (only needed in case of socket)'] = "SMTP account data (only needed in case of socket)";
$_lang['No Authentication'] = "No Authentication"; 
$_lang['with POP before SMTP'] = "with POP before SMTP";
$_lang['SMTP auth (via socket only!)'] = "SMTP auth (via socket only!)";
$_lang['Log history of records'] = "Log history of records";
$_lang['Send'] = " Senden";
$_lang['Host-Path'] = "Host-Path";
$_lang['Installation directory'] = "Installation directory";
$_lang['0 Date assignment by chief, 1 Invitation System'] = "0 Date assignment by chief, 1 Invitation System";
$_lang['0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System'] = "0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System";
$_lang['Default write access mode: private=0, group=1'] = "Default write access mode: private=0, group=1";
$_lang['Select-Option accepted available = 1, not available = 0'] = "Select-Option accepted available = 1, not available = 0";
$_lang['absolute path to host, e.g. http://myhost/'] = "absolute path to host, e.g. http://myhost/";
$_lang['installation directory below host, e.g. myInstallation/of/phprojekt5/'] = "installation directory below host, e.g. myInstallation/of/phprojekt5/";

// l.php
$_lang['Resource List'] = "Er�forr�slista";
$_lang['Event List'] = "Esem�nylista";
$_lang['Calendar Views'] = "Csoport n�zet";

$_lang['Personnel'] = "Szem�lyes";
$_lang['Create new event'] = "Esem�nyek l�trehoz�sa �s t�rl�se";
$_lang['Day'] = "Nap";

$_lang['Until'] = "V�ge";

$_lang['Note'] = "Feljegyz�s";
$_lang['Project'] = "Projekt";
$_lang['Res'] = "Er.f.";
$_lang['Once'] = "Egyszer";
$_lang['Daily'] = "Naponta";
$_lang['Weekly'] = "Hetente";
$_lang['Monthly'] = "Havonta";
$_lang['Yearly'] = "�vente";

$_lang['Create'] = "L�trehoz�s";

$_lang['Begin'] = "Kezdete";
$_lang['Out of office'] = "Irod�n k�v�l";
$_lang['Back in office'] = "Vissza az irod�ba";
$_lang['End'] = "V�ge";
$_lang['@work'] = "munk�ban";
$_lang['We'] = "H�t";
$_lang['group events'] = "csoportos esem�nyek";
$_lang['or profile'] = "vagy profil";
$_lang['All Day Event'] = "esem�ny eg�sz napra";
$_lang['time-axis:'] = "id�tengely:";
$_lang['vertical'] = "v�zszintes";
$_lang['horizontal'] = "f�gg�leges";
$_lang['Horz. Narrow'] = "f�gg. ny�l";
$_lang['-interval:'] = "-sz�net:";
$_lang['Self'] = "Saj�t";

$_lang['...write'] = "Kiterjesztett m�d";

$_lang['Calendar dates'] = "Calendar dates";
$_lang['List'] = "List";
$_lang['Year'] = "Year";
$_lang['Month'] = "Month";
$_lang['Week'] = "Week";
$_lang['Substitution'] = "Substitution";
$_lang['Substitution for'] = "Substitution for";
$_lang['Extended&nbsp;selection'] = "Extended&nbsp;selection";
$_lang['New Date'] = "New date entered";
$_lang['Date changed'] = "Date changed";
$_lang['Date deleted'] = "Date deleted";

// links
$_lang['Database table'] = "Database table";
$_lang['Record set'] = "Record set";
$_lang['Resubmission at:'] = "Resubmission at:";
$_lang['Set Links'] = "Links";
$_lang['From date'] = "From date";
$_lang['Call record set'] = "Call record set";


//login.php
$_lang['Please call login.php!'] = "K�rem futtassa a login.php-t!";

// m1.php
$_lang['There are other events!<br>the critical appointment is: '] = "T�bb esem�ny is van!<br>a kritikus tal�lkoz�: ";
$_lang['Sorry, this resource is already occupied: '] = "Sajn�lom ez az er�forr�s m�r foglalt: ";
$_lang[' This event does not exist.<br> <br> Please check the date and time. '] = " Ez az esem�ny nem l�tezik.<br> <br> K�rem ellen�rizze a d�tumot �s az id�t. ";
$_lang['Please check your date and time format! '] = "K�rem ellen�rizze a d�tum �s id� form�tum�t! ";
$_lang['Please check the date!'] = "K�rem ellen�rizze a d�tumot!";
$_lang['Please check the start time! '] = "K�rem ellen�rizze a kezd�si id�t! ";
$_lang['Please check the end time! '] = "K�rem ellen�rizze a befejez�si id�t! ";
$_lang['Please give a text or note!'] = "K�rem adjon meg egy sz�veget vagy megjegyz�st!";
$_lang['Please check start and end time! '] = "K�rem ellen�rizze a kezd� �s a befejez�si id�t! ";
$_lang['Please check the format of the end date! '] = "K�rem ellen�rizze a befejez�si d�tum form�tum�t! ";
$_lang['Please check the end date! '] = "K�rem ellen�rizze a befejez�si d�tumot! ";





$_lang['Resource'] = "Er�forr�s";
$_lang['User'] = "Felhaszn�l�";

$_lang['delete event'] = "esem�ny t�rl�se";
$_lang['Address book'] = "C�mjegyz�k";


$_lang['Short Form'] = "R�vid n�v";

$_lang['Phone'] = "Telefon";
$_lang['Fax'] = "Fax";



$_lang['Bookmark'] = "K�nyvjelz�";
$_lang['Description'] = "Le�r�s";

$_lang['Entire List'] = "Teljes lista";

$_lang['New event'] = "�j esem�ny";
$_lang['Created by'] = "L�trehozta";
$_lang['Red button -> delete a day event'] = "Piros gomb -> egynapi esem�ny t�rl�se";
$_lang['multiple events'] = "Ism�tl�d� esem�nyek";
$_lang['Year view'] = "N�zet �vekben";
$_lang['calendar week'] = "Napt�ri h�t";

//m2.php
$_lang['Create &amp; Delete Events'] = "Esem�nyek l�trehoz�sa �s t�rl�se";
$_lang['normal'] = "alap";
$_lang['private'] = "saj�tom";
$_lang['public'] = "nyilv�nos";
$_lang['Visibility'] = "L�that�s�g";

//mail module
$_lang['Please select at least one (valid) address.'] = "K�rem v�lasszon legal�bb egy (�rv�nyes) c�met.";
$_lang['Your mail has been sent successfully'] = "A lev�l post�zva";
$_lang['Attachment'] = "Csatol�s";
$_lang['Send single mails'] = "K�ld�s egyenk�nt (rejtett c�mzettek)";
$_lang['Does not exist'] = "Nem l�tezik";
$_lang['Additional number'] = "J�rul�kos sz�m";
$_lang['has been canceled'] = "visszavonva";

$_lang['marked objects'] = "Kijel�ltek t�rl�se";
$_lang['Additional address'] = "Tov�bbi c�mek";
$_lang['in mails'] = "a levelekben";
$_lang['Mail account'] = "";
$_lang['Body'] = "Lev�lt�zs";
$_lang['Sender'] = "Felad�";

$_lang['Receiver'] = "C�mzett";
$_lang['Reply'] = "V�lasz";
$_lang['Forward'] = "Tov�bb�t�s";
$_lang['Access error for mailbox'] = "HIBA: A postafi�k nem el�rhet� !";
$_lang['Receive'] = "Levelek let�lt�se...";
$_lang['Write'] = "�j lev�l szerkeszt�se... ";
$_lang['Accounts'] = "Fi�kok";
$_lang['Rules'] = "Szab�lyok";
$_lang['host name'] = "Kiszolg�l� g�p neve";
$_lang['Type'] = "T�pusa";
$_lang['misses'] = "hi�nyzik";
$_lang['has been created'] = "l�trej�tt";
$_lang['has been changed'] = "megv�ltozott";
$_lang['is in field'] = "a mez�ben van";
$_lang['and leave on server'] = " ";
$_lang['name of the rule'] = "a szab�ly neve";
$_lang['part of the word'] = "a sz� r�sze";
$_lang['in'] = "az";
$_lang['sent mails'] = "elk�ld�tt levelekben";
$_lang['Send date'] = "K�ld�s d�tuma";
$_lang['Received'] = "�rkezett";
$_lang['to'] = "C�mzett";
$_lang['imcoming Mails'] = "bej�v� Levelek";
$_lang['sent Mails'] = "elk�ld�tt Levelek";
$_lang['Contact Profile'] = "Kapcsolat profil";
$_lang['unread'] = "olvasatlan";
$_lang['view mail list'] = "�j levelek list�ja..";
$_lang['insert db field (only for contacts)'] = "Adatmez� besz�r�sa a kapcsolatokb�l";
$_lang['Signature'] = "Al��r�s";

$_lang['SMS'] = "SMS";
$_lang['Single account query'] = "Egyedi postafi�k lek�rdez�se";
$_lang['Notice of receipt'] = "T�rtivev�ny k�r�se";
$_lang['Assign to project'] = "Levelek fogad�sa a t�bbi postafi�kkal egy�tt";
$_lang['Assign to contact'] = "K�ld�s"; 
$_lang['Assign to contact according to address'] = "Assign to contact according to address";
$_lang['Include account for default receipt'] = "Include account for default receipt";
$_lang['Your token has already been used.<br>If it wasnt you, who used the token please contact your administrator.'] = "Your token has already been used.<br>If it wasn't you, who used the token please contact your administrator";
$_lang['Your token has already been expired.'] = "Your token has already been expired";
$_lang['Unconfirmed Events'] = "Unconfirmed Events";
$_lang['Visibility presetting when creating an event'] = "Voreinstellung der Sichtbarkeit beim Anlegen eines Termins";
$_lang['Subject'] = "Subject";
$_lang['Content'] = "Inhalt";
$_lang['answer all'] = "answer to all";
$_lang['Create new message'] = "Create new message";
$_lang['Attachments'] = "Attachments";
$_lang['Recipients'] = "Recipients";
$_lang['file away message'] = "file away message";
$_lang['Message from:'] = "Message from:";

//notes.php
$_lang['Mail note to'] = "Megjegyz�s elk�ld�se";
$_lang['added'] = "hozz�adva";
$_lang['changed'] = "megv�ltoztatva";

// o.php
$_lang['Calendar'] = "Napt�r";
$_lang['Contacts'] = "Kapcsolatok";


$_lang['Files'] = "F�jlok";



$_lang['Options'] = "Be�ll�t�sok";
$_lang['Timecard'] = "Id�k�rtya";

$_lang['Helpdesk'] = "helpdesk";

$_lang['Info'] = "Inf�";
$_lang['Todo'] = "Teend�k";
$_lang['News'] = "�jdons�gok";
$_lang['Other'] = "Egyebek";
$_lang['Settings'] = "Be�ll�t�sok";
$_lang['Summary'] = "�sszes�t�";

// options.php
$_lang['Description:'] = "Le�r�s:";
$_lang['Comment:'] = "Megjegyz�s:";
$_lang['Insert a valid Internet address! '] = "Adjon meg egy �rv�nyes Internet c�met! ";
$_lang['Please specify a description!'] = "K�rem adjon meg egy le�r�st!";
$_lang['This address already exists with a different description'] = "Ez a c�m m�r l�tezik egy m�sik le�r�ssal";
$_lang[' already exists. '] = " m�r l�tezik. ";
$_lang['is taken to the bookmark list.'] = "a c�mlist�r�l v�ve.";
$_lang[' is changed.'] = " megv�ltozott.";
$_lang[' is deleted.'] = " t�r�lve lett.";
$_lang['Please specify a description! '] = "K�rem adjon meg egy le�r�st! ";
$_lang['Please select at least one name! '] = "K�rem v�lasszon legal�bb egy nevet! ";
$_lang[' is created as a profile.<br>'] = " mint profil j�tt l�tre.<br> Miut�n a napt�r szekci� friss�tve lesz a profil azut�n lesz akt�v.";
$_lang['is changed.<br>'] = "megv�ltozott.<br> Miut�n a napt�r szekci� friss�tve lesz a profil azut�n lesz akt�v.";
$_lang['The profile has been deleted.'] = "A profil t�rl�d�tt.";
$_lang['Please specify the question for the poll! '] = "K�rem adjon meg egy k�rd�st a szavaz�shoz! ";
$_lang['You should give at least one answer! '] = "Legal�bb egy v�laszlehet�s�get meg kell adnia! ";
$_lang['Your call for votes is now active. '] = "Az �n szavaz�g�pe most m�r akt�v. ";
$_lang['<h2>Bookmarks</h2>In this section you can create, modify or delete bookmarks:'] = "<h2>K�nyvjelz�k</h2>Ebben a szekci�ban l�trehozhat, m�dos�that, t�r�lhet k�nyvjelz�ket:";
$_lang['Create'] = "L�trehoz";


$_lang['<h2>Profiles</h2>In this section you can create, modify or delete profiles:'] = "<h2>Profilok</h2>Ebben a szekci�ban l�trehozhat, m�dos�that, t�r�lhet profilokat:";
$_lang['<h2>Voting Formula</h2>'] = "<h2>Szavaz� K�plet</h2>";
$_lang['In this section you can create a call for votes.'] = "Ebben a szekci�ban l�trehozhat egy szavaz�g�pet.";
$_lang['Question:'] = "K�rd�s:";
$_lang['just one <b>Alternative</b> or'] = "csak egy alternat�va vagy";
$_lang['several to choose?'] = "t�bb v�laszt�si lehet�s�g?";

$_lang['Participants:'] = "R�sztvev�k:";

$_lang['<h3>Password Change</h3> In this section you can choose a new random generated password.'] = "<h3>Jelsz�v�lt�s</h3>Ebben a szekci�ban v�laszthat mag�nak egy �j v�letlen�l gener�lt jelsz�t.";
$_lang['Old Password'] = "R�gi jelsz�";
$_lang['Generate a new password'] = "�j jelsz� gener�l�sa";
$_lang['Save password'] = "Elmenti a jelsz�t";
$_lang['Your new password has been stored'] = "Az �n �j jelszava elment�sre ker�lt";
$_lang['Wrong password'] = "Hib�s jelsz�";
$_lang['Delete poll'] = "T�rli a szavazatot";
$_lang['<h4>Delete forum threads</h4> Here you can delete your own threads<br>Only threads without a comment will appear.'] = "<h4>T�rli a f�rum t�m�kat</h4> Itt tudja t�r�lni a saj�t t�m�it<br>
Csak hozz�sz�l�sok n�lk�li t�m�k jelennek meg.";

$_lang['Old password'] = "R�gi jelsz�";
$_lang['New Password'] = "�j jelsz�";
$_lang['Retype new password'] = "Adja meg �jra az �j jelsz�t";
$_lang['The new password must have 5 letters at least'] = "Az �j jelsz� legal�bb 5 hossz� kell, hogy legyen";
$_lang['You didnt repeat the new password correctly'] = "Nem ism�telte meg az �j jelsz�t helyesen";

$_lang['Show bookings'] = "Mutatja a foglal�sokat";
$_lang['Valid characters'] = "�rv�nyes karakterek";
$_lang['Suggestion'] = "Javaslat";
$_lang['Put the word AND between several phrases'] = "Put the word AND between several phrases"; // translators: please leave the word AND as it is
$_lang['Write access for calendar'] = "Write access for calendar";
$_lang['Write access for other users to your calendar'] = "Write access for other users to your calendar";
$_lang['User with chief status still have write access'] = "User with chief status still have write access";

// projects
$_lang['Project Listing'] = "Projektek List�ja";
$_lang['Project Name'] = "Projekt neve";


$_lang['o_files'] = "Files";
$_lang['o_notes'] = "Notes";
$_lang['o_projects'] = "Projects";
$_lang['o_todo'] = "Todo";
$_lang['Copyright']="Copyright";
$_lang['Links'] = "Links";
$_lang['New profile'] = "Neuer Verteiler";
$_lang['In this section you can choose a new random generated password.'] = "In this section you can choose a new random generated password.";
$_lang['timescale'] = "timescale";
$_lang['Manual Scaling'] = "Manual scaling";
$_lang['column view'] = "column view";
$_lang['display format'] = "display format";
$_lang['for chart only'] = "For chart only:";
$_lang['scaling:'] = "scling:";
$_lang['colours:'] = "colours";
$_lang['display project colours'] = "display project colours";
$_lang['weekly'] = "weekly";
$_lang['monthly'] = "monthly";
$_lang['annually'] = "annually";
$_lang['automatic'] = "automatic";
$_lang['New project'] = "New project";
$_lang['Basis data'] = "Basis data";
$_lang['Categorization'] = "Categorization";
$_lang['Real End'] = "Real End";
$_lang['Participants'] = "R�sztvev�k";
$_lang['Priority'] = "Priorit�s";
$_lang['Status'] = "�llapot";
$_lang['Last status change'] = "Legut�bbi <br>v�ltoz�s";
$_lang['Leader'] = "Vezet�";
$_lang['Statistics'] = "Statisztika";
$_lang['My Statistic'] = "My Statistic";

$_lang['Person'] = "Szem�ly";
$_lang['Hours'] = "�ra";
$_lang['Project summary'] = "Projekt �sszegz�s";
$_lang[' Choose a combination Project/Person'] = " V�lasszon egy Projekt/Szem�ly �sszerendel�st";
$_lang['(multiple select with the Ctrl/Cmd-key)'] = "(t�bbsz�r�s kiv�laszt�s a 'Ctrl'-billenty�vel)";

$_lang['Persons'] = "Szem�lyek";
$_lang['Begin:'] = "Kezdete:";
$_lang['End:'] = "V�ge:";
$_lang['All'] = "�sszes";
$_lang['Work time booked on'] = "Bejegyzett munkaid�";
$_lang['Sub-Project of'] = "Alprojekt";
$_lang['Aim'] = "C�l";
$_lang['Contact'] = "Kapcsolat";
$_lang['Hourly rate'] = "�rad�j";
$_lang['Calculated budget'] = "Kalkul�lt k�lts�gvet�s";
$_lang['New Sub-Project'] = "�j alprojekt";
$_lang['Booked To Date'] = "Bejegyezve mostan�ig";
$_lang['Budget'] = "K�lts�gvet�s";
$_lang['Detailed list'] = "R�szletes lista";
$_lang['Gantt'] = "Hat�rid�";
$_lang['offered'] = "javasolt";
$_lang['ordered'] = "megrendelt";
$_lang['Working'] = "munk�ban t�lt�tt";
$_lang['ended'] = "v�get �rt";
$_lang['stopped'] = "le�ll�tott";
$_lang['Re-Opened'] = "megnyitva �jra";
$_lang['waiting'] = "v�rakoz�";
$_lang['Only main projects'] = "Csak a f� projektek";
$_lang['Only this project'] = "Only this project";
$_lang['Begin > End'] = "Begin > End";
$_lang['ISO-Format: yyyy-mm-dd'] = "A k�v�nt d�tumform�tum: ����-hh-nn";
$_lang['The timespan of this project must be within the timespan of the parent project. Please adjust'] = "The timespan of this project must be within the timespan of the parent project. Please adjust";
$_lang['Please choose at least one person'] = "Please choose at least one person";
$_lang['Please choose at least one project'] = "Please choose at least one project";
$_lang['Dependency'] = "Dependency";
$_lang['Previous'] = "Previous";

$_lang['cannot start before the end of project'] = "cannot start before the end of project";
$_lang['cannot start before the start of project'] = "cannot start before the start of project";
$_lang['cannot end before the start of project'] = "cannot end before the start of project";
$_lang['cannot end before the end of project'] = "cannot end before the end of project";
$_lang['Warning, violation of dependency'] = "Attention, violation of dependency";
$_lang['Container'] = "Container";
$_lang['External project'] = "External project";
$_lang['Automatic scaling'] = "Automatic scaling";
$_lang['Legend'] = "Legend";
$_lang['No value'] = "No value";
$_lang['Copy project branch'] = "Copy project branch";
$_lang['Copy this element<br> (and all elements below)'] = "Copy this element<br> (and all elements below)";
$_lang['And put it below this element'] = "And put it below this element";
$_lang['Edit timeframe of a project branch'] = "Edit timeframe of a project branch"; 

$_lang['of this element<br> (and all elements below)'] = "of this element<br> (and all elements below)";  
$_lang['by'] = "by";
$_lang['Probability'] = "Probability";
$_lang['Please delete all subelements first'] = "Please delete all subprojects first";
$_lang['Assignment'] ="Assignment";
$_lang['display'] = "Display";
$_lang['Normal'] = "Normal";
$_lang['sort by date'] = "Sort by date";
$_lang['sort by'] = "Sort by";
$_lang['Calculated budget has a wrong format'] = "Calculated budget has a wrong format";
$_lang['Hourly rate has a wrong format'] = "Hourly rate has a wrong format";

// r.php
$_lang['please check the status!'] = "k�rem ellen�rizze az �llapotot!";
$_lang['Todo List: '] = "Teend�k list�ja: ";
$_lang['New Remark: '] = "�j bejegyz�s: ";
$_lang['Delete Remark '] = "Megjegyz�st t�r�l ";
$_lang['Keyword Search'] = "Keres�s kulcssz�ra: ";
$_lang['Events'] = "Esem�nyek";
$_lang['the forum'] = "a f�rum";
$_lang['the files'] = "a f�jlok";
$_lang['Addresses'] = "C�mek";
$_lang['Extended'] = "R�szletes n�zet";
$_lang['all modules'] = "�sszes modul";
$_lang['Bookmarks:'] = "K�nyvjelz�k:";
$_lang['List'] = "Lista";
$_lang['Projects:'] = "Projektek:";

$_lang['Deadline'] = "Hat�rid�";

$_lang['Polls:'] = "Szavazatok:";

$_lang['Poll created on the '] = "Szavazatok l�trehozva a  ";


// reminder.php
$_lang['Starts in'] = "Indul�s";
$_lang['minutes'] = "perc";
$_lang['No events yet today'] = "Ma m�g nincs esem�ny";
$_lang['New mail arrived'] = "�j levele �rkezett !";

//ress.php

$_lang['List of Resources'] =  "Er�forr�sok list�ja";
$_lang['Name of Resource'] = "Er�forr�s neve";
$_lang['Comments'] =  "Megjegyz�sek";


// roles
$_lang['Roles'] = "Szerepek";
$_lang['No access'] = "Nincs jogosults�g";
$_lang['Read access'] = "Olvas�si jog";

$_lang['Role'] = "Szerep";

// helpdesk - rts
$_lang['Request'] = "K�r�s";

$_lang['pending requests'] = "f�gg� k�r�sek";
$_lang['show queue'] = "sor megjelen�t�se";
$_lang['Search the knowledge database'] = "Keres�s a tud�sb�zisban";
$_lang['Keyword'] = "Kulcssz�";
$_lang['show results'] = "Eredm�nyek megjelen�t�se";
$_lang['request form'] = "k�r�s forma";
$_lang['Enter your keyword'] = "Adja meg a kulcssz�t";
$_lang['Enter your email'] = "Adja meg az email-j�t";
$_lang['Give your request a name'] = "Adjon nevet a k�r�snek";
$_lang['Describe your request'] = "Irja le a k�r�st";

$_lang['Due date'] = "Hat�rid�";
$_lang['Days'] = "Napok";
$_lang['Sorry, you are not in the list'] = "Sajn�lom, �n nincs a list�n";
$_lang['Your request Nr. is'] = "Az �n k�r�s�nek a sz�ma";
$_lang['Customer'] = "�gyf�l";


$_lang['Search'] = "Keres�s";
$_lang['at'] = "az";
$_lang['all fields'] = "�sszes mez�ben";


$_lang['Solution'] = "Megold�s";
$_lang['AND'] = "�S";

$_lang['pending'] = "f�gg�";
$_lang['stalled'] = "�ll�";
$_lang['moved'] = "mozg�";
$_lang['solved'] = "megoldott";
$_lang['Submit'] = "Rendben";
$_lang['Ass.'] = "Hren.";
$_lang['Pri.'] = "Pri.";
$_lang['access'] = "hozz�f�r�s";
$_lang['Assigned'] = "Hozz�rendelt";

$_lang['update'] = "friss�t";
$_lang['remark'] = "bejegyez";
$_lang['solve'] = "megold";
$_lang['stall'] = "meg�ll�t";
$_lang['cancel'] = "t�r�l";
$_lang['Move to request'] = "�thelyezi a k�r�st";
$_lang['Dear customer, please refer to the number given above by contacting us.Will will perform your request as soon as possible.'] = "Kedves �gyfel�nk, k�rem n�zze meg az al�bbi sz�mot, hogy kapcsolatba l�pjen vel�nk.
Foglalkozunk a k�r�s�vel amilyen gyorsan csak lehet.";
$_lang['Your request has been added into the request queue.<br>You will receive a confirmation email in some moments.'] = "Az �n k�r�se hozz� lett adva a k�r�sek sor�hoz.<br>
Meg fogja kapni a j�v�hagy� levelet p�r percen bel�l.";
$_lang['n/a'] = "n/a";
$_lang['internal'] = "bels�";

$_lang['has reassigned the following request'] = "�jrarendeli a k�vetkez� k�r�st";
$_lang['New request'] = "�j k�r�s";
$_lang['Assign work time'] = "Munkaid�t rendel hozz�";
$_lang['Assigned to:'] = "Hozz�rendelve:";

$_lang['Your solution was mailed to the customer and taken into the database.'] = "A megold�sa el lett k�ldve az �gyf�lnek �s beker�lt az adatb�zisba.";
$_lang['Answer to your request Nr.'] = "V�lasz a k�rd�s�re.";
$_lang['Fetch new request by mail'] = "Kigy�jti az �j k�r�seket lev�lben";
$_lang['Your request was solved by'] = "Az �n probl�m�j�t megoldotta";

$_lang['Your solution was mailed to the customer and taken into the database'] = "Az �n k�r�se/probl�m�ja e-mail form�ban tov�bb�t�sra ker�lt �nh�z �s beker�lt az adatb�zisunkba";
$_lang['Search term'] = "Search term";
$_lang['Search area'] = "Search area";
$_lang['Extended search'] = "Extended search";
$_lang['knowledge database'] = "knowledge database";
$_lang['Cancel'] = "Cancel";
$_lang['New ticket'] = "New ticket";
$_lang['Ticket status'] ="Ticket status";

// please adjust this states as you want -> add/remove states in helpdesk.php
$_lang['unconfirmed'] = 'unconfirmed';
$_lang['new'] = 'new';
$_lang['assigned'] = 'assigned';
$_lang['reopened'] = 'reopened';
$_lang['resolved'] = 'resolved';
$_lang['verified'] = 'verified';

// settings.php
$_lang['The settings have been modified'] = "A be�ll�t�sok m�dos�tva";
$_lang['Skin'] = "St�lus";
$_lang['First module view on startup'] = "Bejelentkez�skor megjelen� modul";
$_lang['none'] = "semmi";
$_lang['Check for mail'] = "�j levelek let�lt�se";
$_lang['Additional alert box'] = "Tov�bbi eml�keztet� doboz";
$_lang['Horizontal screen resolution <br>(i.e. 1024, 800)'] = "V�zszintes k�pfelbont�s <br>(pl. 1024, 800)";
$_lang['Chat Entry'] = "Cseveg�s mez�";
$_lang['single line'] = "Egysoros";
$_lang['multi lines'] = "T�bbsoros";
$_lang['Chat Direction'] = "Cseveg�s ir�nya";
$_lang['Newest messages on top'] = "Leg�jabb �zenet fel�l";
$_lang['Newest messages at bottom'] = "Leg�jabb �zenet alul";
$_lang['File Downloads'] = "�llom�nyok let�lt�se";

$_lang['Inline'] = "Inline";
$_lang['Lock file'] = "Lock file";
$_lang['Unlock file'] = "nlock file";
$_lang['New file here'] = "New file here";
$_lang['New directory here'] = "New directory here";
$_lang['Position of form'] = "Position of form";
$_lang['On a separate page'] = "On a separate page";
$_lang['Below the list'] = "Below the list";
$_lang['Treeview mode on module startup'] = "Treeview mode on module startup";
$_lang['Elements per page on module startup'] = "Elements per page on module startup";
$_lang['General Settings'] = "General Settings";
$_lang['First view on module startup'] = "First view on module startup";
$_lang['Left frame width [px]'] = "Left frame width [px]";
$_lang['Timestep Daywiew [min]'] = "Timestep Dayview [min]";
$_lang['Timestep Weekwiew [min]'] = "Timestep Weekview [min]";
$_lang['px per char for event text<br>(not exact in case of proportional font)'] = "px per char for event text<br>(not exact in case of proportional font)";
$_lang['Text length of events will be cut'] = "Text length of events will be cut";
$_lang['Standard View'] = "Standard View";
$_lang['Standard View 1'] = "Standard View 1";
$_lang['Standard View 2'] = "Standard View 2";
$_lang['Own Schedule'] = "Own Schedule";
$_lang['Group Schedule'] = "Group Schedule";
$_lang['Group - Create Event'] = "Group - Create Event";
$_lang['Group, only representation'] = "Group, only representation";
$_lang['Holiday file'] = "Holiday file";

// summary
$_lang['Todays Events'] = "Mai esem�nyek";
$_lang['New files'] = "Leg�jabb f�jlok";
$_lang['New notes'] = "Leg�jabb feljegyz�sek";
$_lang['New Polls'] = "Leg�jabb szavazatok";
$_lang['Current projects'] = "Fut� projektek";
$_lang['Help Desk Requests'] = "HelpDesk k�rd�sek";
$_lang['Current todos'] = "Aktu�lis teend�k";
$_lang['New forum postings'] = "Leg�jabb f�rum t�m�k";
$_lang['New Mails'] = "Leg�jabb levelek.";

//timecard

$_lang['Theres an error in your time sheet: '] = "Hiba van az id�beoszt�s�ban! K�rem n�zze meg az id�k�rty�j�t.";




$_lang['Consistency check'] = "Konzisztencia ellen�rz�s";
$_lang['Please enter the end afterwards at the'] = "K�rem adja meg a v�g�t a(z)";
$_lang['insert'] = "beilleszt";
$_lang['Enter records afterwards'] = "Adjon meg rekordokat ezut�n";
$_lang['Please fill in only emtpy records'] = "K�rem csak az �res rekordokat t�ltse ki";

$_lang['Insert a period, all records in this period will be assigned to this project'] = "Adjon meg egy id�szakot, az �sszes rekord ebben az id�szakban ehhez a projekthez lesz rendelve";
$_lang['There is no record on this day'] = "Nincs rekord ezen a napon!";
$_lang['This field is not empty. Please ask the administrator'] = "Ez a mez� nem �res. K�rem k�rje meg az adminisztr�tort!";
$_lang['There is no open record with a begin time on this day!'] = "A megadott adatok rosszak! K�rem ellen�rizze �ket.";
$_lang['Please close the open record on this day first!'] = "K�rem adja meg a kezd� id�t";
$_lang['Please check the given time'] = "K�rem ellen�rizze a megadott id�t";
$_lang['Assigning projects'] = "Projektekhez val� hozz�rendel�s";
$_lang['Select a day'] = "V�lasszon egy napot";
$_lang['Copy to the boss'] = "M�solat a f�n�knek";
$_lang['Change in the timecard'] = "V�ltoztassa meg az id�k�rty�n";
$_lang['Sum for'] = "�sszegz�s";

$_lang['Unassigned time'] = "Nem hozz�rendelt id�";
$_lang['delete record of this day'] = "t�rli ennek a napnak a rekordj�t";
$_lang['Bookings'] = "Bookings";

$_lang['insert additional working time'] = "insert additional working time";
$_lang['Project assignment']= "Project assignment";
$_lang['Working time stop watch']= "Working time stop watch";
$_lang['stop watches']= "stop watches";
$_lang['Project stop watch']= "Project stop watch";
$_lang['Overview my working time']= "Overview my working time";
$_lang['GO']= "GO";
$_lang['Day view']= "Day view";
$_lang['Project view']= "Project view";
$_lang['Weekday']= "Weekday";
$_lang['Start']= "Start";
$_lang['Net time']= "Net time";
$_lang['Project bookings']= "Project bookings";
$_lang['save+close']= "save+close";
$_lang['Working times']= "Working times";
$_lang['Working times start']= "Working times start";
$_lang['Working times stop']= "Working times stop";
$_lang['Project booking start']= "Project booking start";
$_lang['Project booking stop']= "Project booking stop";
$_lang['choose day']= "choose day";
$_lang['choose month']= "choose month";
$_lang['1 day back']= "1 day back";
$_lang['1 day forward']= "1 day forward";
$_lang['Sum working time']= "Sum working time";
$_lang['Time: h / m']= "Time: h / m";
$_lang['activate project stop watch']= "activate project stop watch";
$_lang['activate']= "activate";
$_lang['project choice']= "project choice";
$_lang['stop stop watch']= "stop stop watch";
$_lang['still to allocate:']= "still to allocate:";
$_lang['You are not allowed to delete entries from timecard. Please contact your administrator']= "You are not allowed to delete entries from timecard. Please contact your administrator";
$_lang['You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.']= "You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.";
$_lang['You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.']= "You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.";
$_lang['activate+close']="activate+close";

// todos
$_lang['accepted'] = "elfogadva";
$_lang['rejected'] = "visszautas�tva";
$_lang['own'] = "saj�t";
$_lang['progress'] = "feldolgoz�s";
$_lang['delegated to'] = "kiadva: ";
$_lang['Assigned from'] = "k�ldte: ";
$_lang['done'] = "k�sz";
$_lang['Not yet assigned'] = "M�g nincs kiadva";
$_lang['Undertake'] = "Undertake";
$_lang['New todo'] = "�j teend�"; 
$_lang['Notify recipient'] = "Notify recipient";

// votum.php
$_lang['results of the vote: '] = "a szavaz�s eredm�nye: ";
$_lang['Poll Question: '] = "a szavaz�s k�rd�se: ";
$_lang['several answers possible'] = "t�bb v�lasz is lehets�ges";
$_lang['Alternative '] = "Alternat�v ";
$_lang['no vote: '] = "nincs szavazat: ";
$_lang['of'] = "a(z)";
$_lang['participants have voted in this poll'] = "a r�sztvev� szavazott";
$_lang['Current Open Polls'] = "Nyitott szavazatok";
$_lang['Results of Polls'] = "Eredm�nyek �sszegz�se";
$_lang['New survey'] ="New survey";
$_lang['Alternatives'] ="Alternatives";
$_lang['currently no open polls'] = "Currently there are no open polls";

// export_page.php
$_lang['export_timecard']       = "Export Timecard";
$_lang['export_timecard_admin'] = "Export Timecard";
$_lang['export_users']          = "Export users of this group";
$_lang['export_contacts']       = "Export contacts";
$_lang['export_projects']       = "Export projectdata";
$_lang['export_bookmarks']      = "Export bookmarks";
$_lang['export_timeproj']       = "Export time-to-project data";
$_lang['export_project_stat']   = "Export projectstats";
$_lang['export_todo']           = "Export todos";
$_lang['export_notes']          = "Export notes";
$_lang['export_calendar']       = "Export all calendarevents";
$_lang['export_calendar_detail']= "Export one calendarevent";
$_lang['submit'] = "submit";
$_lang['Address'] = "Address";
$_lang['Next Project'] = "Next Project";
$_lang['Dependend projects'] = "Dependend projects";
$_lang['db_type'] = "Database type";
$_lang['Log in, please'] = "Log in, please";
$_lang['Recipient'] = "Recipient";
$_lang['untreated'] = "untreated";
$_lang['Select participants'] = "Select participants";
$_lang['Participation'] = "Participation";
$_lang['not yet decided'] = "not yet decided";
$_lang['accept'] = "accept";
$_lang['reject'] = "reject";
$_lang['Substitute for'] = "Substitute for";
$_lang['Calendar user'] = "Kalenderbenutzer";
$_lang['Refresh'] = "Refresh";
$_lang['Event'] = "Event";
$_lang['Upload file size is too big'] = "Upload file size is too big";
$_lang['Upload has been interrupted'] = "Upload has been interrupted";
$_lang['view'] = "view";
$_lang['found elements'] = "found elements";
$_lang['chosen elements'] = "chosen elements";
$_lang['too many hits'] = "The result is bigger than we're able to display.";
$_lang['please extend filter'] = "Please extend your filters.";
$_lang['Edit profile'] = "Edit profile";
$_lang['add profile'] = "add profile";
$_lang['Add profile'] = "Add profile";
$_lang['Added profile'] = "Added profile(s).";
$_lang['No profile found'] = "No profile found.";
$_lang['add project participants'] = "add project participants";
$_lang['Added project participants'] = "Added project participants.";
$_lang['add group of participants'] = "add group of participants";
$_lang['Added group of participants'] = "Added group of participants.";
$_lang['add user'] = "add user";
$_lang['Added users'] = "Added user(s).";
$_lang['Selection'] = "Selection";
$_lang['selector'] = "selector";
$_lang['Send email notification']= "Send&nbsp;email&nbsp;notification";
$_lang['Member selection'] = "Member&nbsp;selection";
$_lang['Collision check'] = "Collision check";
$_lang['Collision'] = "Collision";
$_lang['Users, who can represent me'] = "Users, who can represent me";
$_lang['Users, who can see my private events'] = "Users, who can see<br />my private events";
$_lang['Users, who can read my normal events'] = "Users, who can read<br />my normal events";
$_lang['quickadd'] = "Quickadd";
$_lang['set filter'] = "Set filter";
$_lang['Select date'] = "Select date";
$_lang['Next serial events'] = "Next serial events";
$_lang['All day event'] = "All day event";
$_lang['Event is canceled'] = "Event&nbsp;is&nbsp;canceled";
$_lang['Please enter a password!'] = "Please enter a password!";
$_lang['You are not allowed to create an event!'] = "You are not allowed to create an event!";
$_lang['Event successfully created.'] = "Event successfully created.";
$_lang['You are not allowed to edit this event!'] = "You are not allowed to edit this event!";
$_lang['Event successfully updated.'] = "Event successfully updated.";
$_lang['You are not allowed to remove this event!'] = "You are not allowed to remove this event!";
$_lang['Event successfully removed.'] = "Event successfully removed.";
$_lang['Please give a text!'] = "Please give a text!";
$_lang['Please check the event date!'] = "Please check the event date!";
$_lang['Please check your time format!'] = "Please check your time format!";
$_lang['Please check start and end time!'] = "Please check start and end time!";
$_lang['Please check the serial event date!'] = "Please check the serial event date!";
$_lang['The serial event data has no result!'] = "The serial event data has no result!";
$_lang['Really delete this event?'] = "Really delete this event?";
$_lang['use'] = "Use";
$_lang[':'] = ":";
$_lang['Mobile Phone'] = "Mobile Phone";
$_lang['submit'] = "Submit";
$_lang['Further events'] = "Weitere Termine";
$_lang['Remove settings only'] = "Remove settings only";
$_lang['Settings removed.'] = "Settings removed.";
$_lang['User selection'] = "User selection";
$_lang['Release'] = "Release";
$_lang['none'] = "none";
$_lang['only read access to selection'] = "only write access to selection";
$_lang['read and write access to selection'] = "read and write access to selection";
$_lang['Available time'] = "Available time";
$_lang['flat view'] = "List View";
$_lang['o_dateien'] = "Filemanager";
$_lang['Location'] = "Location";
$_lang['date_received'] = "date_received";
$_lang['subject'] = "Subject";
$_lang['kat'] = "Category";
$_lang['projekt'] = "Project";
$_lang['Location'] = "Location";
$_lang['name'] = "Titel";
$_lang['contact'] = "Kontakt";
$_lang['div1'] = "Erstellung";
$_lang['div2'] = "�nderung";
$_lang['kategorie'] = "Kategorie";
$_lang['anfang'] = "Beginn";
$_lang['ende'] = "Ende";
$_lang['status'] = "Status";
$_lang['filename'] = "Titel";
$_lang['deadline'] = "Termin";
$_lang['ext'] = "an";
$_lang['priority'] = "Priorit�t";
$_lang['project'] = "Projekt";
$_lang['Accept'] = "�bernehmen";
$_lang['Please enter your user name here.'] = "Please enter your user name here.";
$_lang['Please enter your password here.'] = "Please enter your password here.";
$_lang['Click here to login.'] = "Click here to login.";
$_lang['No New Polls'] = "No New Polls";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
?>