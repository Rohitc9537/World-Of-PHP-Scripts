<?php

//Georgian version

$chars = array("�?","ბ","გ","დ","ე","ვ","ზ","თ","ი","კ","ლ","მ","ნ","�?","პ","ჟ","რ","ს","ტ","უ","ფ","ქ","ყ","ძ","ჭ","ხ","ჯ", "ჰ" );
$name_month = array("", "ი�?ნ", "თებ", "მ�?რ", "�?პრ", "მ�?ისი", "ივნ", "ივლ", "�?გვ", "სექ", "�?ქტ", "ნ�?ემ", "დეკ");
$l_text31a = array("სტ�?ნდ�?რტული", "15 წუთი.", "30 წუთი.", " 1 ს�?�?თი", " 2 ს�?�?თი", " 4 ს�?�?თი", " 1 დღე");
$l_text31b = array(0, 15, 30, 60, 120, 240, 1440);
$name_day = array("კვირ�?", "�?რშ�?ბ�?თი", "ს�?მშ�?ბ�?თი", "�?თხშ�?ბ�?თი", "ხუთშ�?ბ�?თი", "პ�?რ�?სკევი", "შ�?ბ�?თი");
$name_day2 = array("�?რ", "ს�?მ", "�?თხ", "ხუთ", "პ�?რ", "შ�?ბ","კვ");

$_lang['No Entries Found']= "No Entries Found";
$_lang['No Todays Events']= "HNo Todays Events";
$_lang['No new forum postings']= "No new forum postings";
$_lang['in category']= "in category";
$_lang['Filtered']= "Filtered";
$_lang['Sorted by']= "Sorted by";
$_lang['submit'] = "შეყვ�?ნ�?";
$_lang['back'] = "უკ�?ნ";
$_lang['print'] = "დ�?ბეჭდვ�?";
$_lang['export'] = "ექსპ�?რტი";
$_lang['| (help)'] = "| (დ�?ხმ�?რებ�?)";
$_lang['Are you sure?'] = "დ�?რწმუნებული ხ�?რთ?";
$_lang['items/page'] = "პუნქტი/გვერდი";
$_lang['records'] = "ჩ�?ნ�?წერი";
$_lang['previous page'] = "წინ�? გვერდი";
$_lang['next page'] = "შემდეგი გვერდი";
$_lang['first page'] = "first page";
$_lang['last page'] = "last page";
$_lang['Move']  = "გ�?დ�?�?დგილებ�?";
$_lang['Copy'] = "კ�?პირებ�?";
$_lang['Delete'] = "წ�?შლ�?";
$_lang['Save'] = "დ�?მ�?ხს�?ვრებ�?";
$_lang['Directory'] = "დირექტ�?რი�?";
$_lang['Also Delete Contents'] = "წ�?შლ�? კ�?მენტ�?რთ�?ნ ერთ�?დ";
$_lang['Sum'] = "ჯ�?მი";
$_lang['Filter'] = "ფილტრი";
$_lang['Please fill in the following field'] = "შე�?ვსეთ შემდეგი ველები";
$_lang['approve'] = "დ�?მტკიცებ�?";
$_lang['undo'] = "მ�?ქმედების დ�?ბრუნებ�?";
$_lang['Please select!'] = "�?ირჩიეთ!";
$_lang['New'] = "�?ხ�?ლი";
$_lang['Select all'] = "�?ირჩი�?თ ყველ�?";
$_lang['Printable view'] = "ფ�?რმ�?ტი �?მ�?ბეჭდისთვის";
$_lang['New record in module '] = "�?ხ�?ლი ჩ�?ნ�?წერები მ�?დულში";
$_lang['Notify all group members'] =  "ჯგუფის წევრების შეტყ�?ბინებ�?";
$_lang['Yes'] = "დი�?ხ";
$_lang['No'] = "�?რ�?";
$_lang['Close window'] =  "დ�?ხურეთ ფ�?ნჯ�?რ�?";
$_lang['No Value'] =  "�?რ �?რსებ�?ბს მნიშვნელ�?ბ�?";
$_lang['Standard'] = "სტ�?ნდ�?რტული";
$_lang['Create'] = "Anlegen";
$_lang['Modify'] = "�ndern";   
$_lang['today'] = "today";

// admin.php
$_lang['Password'] = "პ�?რ�?ლი";
$_lang['Login'] = "რეგისტრ�?ციის ს�?ხელი";
$_lang['Administration section'] = "ს�?�?დმინისტრ�?ცი�? გ�?ნყ�?ფილებ�?";
$_lang['Your password'] = "თქვენი პ�?რ�?ლი";
$_lang['Sorry you are not allowed to enter. '] = "შესვლ�? �?კრძ�?ლული�?";
$_lang['Help'] = "დ�?ხმ�?რებ�?";
$_lang['User management'] = "მ�?მხმ�?რებლებით მ�?რთვ�?";
$_lang['Create'] = "შექმნ�?";
$_lang['Projects'] = "პრ�?ექტები";
$_lang['Resources'] = "რესურსები";
$_lang['Resources management'] = "Resources management";
$_lang['Bookmarks'] = "ს�?ნიშნე";
$_lang['for invalid links'] = "�?რ�?სწ�?რი ბმულებისთვის";
$_lang['Check'] =  "შემ�?წმებ�?";
$_lang['delete Bookmark'] =  "ს�?ნიშნეს წ�?შლ�?";
$_lang['(multiple select with the Ctrl-key)'] = "(რ�?მ�?დენიმეს �?რთდრ�?ულ�?დ �?რჩევის�?თვის დ�?�?ჭირეთ 'Ctrl')";
$_lang['Forum'] = "ფ�?რუმი";
$_lang['Threads older than'] = "თენები �?მ რიცხვძე ძველი";
$_lang[' days '] = " დღე ";
$_lang['Chat'] = "დისკუსი�?";
$_lang['save script of current Chat'] = "დისკუსიის ტექსტის შენ�?ხვ�?";
$_lang['Chat script'] = "დისკუსიის ტექსტი";
$_lang['New password'] = "�?ხ�?ლი პ�?რ�?ლი!";
$_lang['(keep old password: leave empty)'] = "(ნუ შე�?ვსებთ, თუ გსურთ ძველი პ�?რ�?ლის შენ�?რჩუნებ�?)";
$_lang['Default Group<br> (must be selected below as well)'] = "სტ�?ნდ�?რტული ჯგუფი<br> (�?ირჩიეთ ქვემ�?თ ჩ�?მ�?თვლილიდ�?ნ)";
$_lang['Access rights'] = "წვდ�?მის უფლებები";
$_lang['Zip code'] = "ს�?ფ�?სტ�? ინდექსი";
$_lang['Language'] = "ენ�?";
$_lang['schedule readable to others'] = "გ�?ნრიგს სხვებიც ხედ�?ვენ";
$_lang['schedule invisible to others'] = "გ�?ნრიგს სხვები ვერ ხედ�?ვენ";
$_lang['schedule visible but not readable'] = "სხვები მხ�?ლ�?დ დ�?ს�?ხელებ�?ს ხედ�?ვენ";
$_lang['these fields have to be filled in.'] = "შე�?ვსეთ ეს ველები!";
$_lang['You have to fill in the following fields: family name, short name and password.'] = "�?უცილებლ�?დ შეს�?ვსები ველები: გვ�?რი, ს�?ხელი დ�? პ�?რ�?ლი.";
$_lang['This family name already exists! '] ="ეს გვ�?რი უკვე �?რსებ�?ბს სისტემ�?ში";
$_lang['This short name already exists!'] = "ეს ს�?ხელე დ�?კ�?ვებული�?!";
$_lang['This login name already exists! Please chosse another one.'] =  "ეს ს�?რეგისტრ�?ცი�? ს�?ხელი უკვე �?რსებ�?ბს, �?ირჩიეთ სხვ�?.";
$_lang['This password already exists!'] = "ეს პ�?რ�?ლი უკვე �?რსებ�?ბს!";
$_lang['This combination first name/family name already exists.'] = "ს�?ხელის დ�? გვ�?რის კ�?მბინ�?ცი�? უკვე დ�?კ�?ვებული�?!";
$_lang['the user is now in the list.'] ="მ�?მხმ�?რებელი შეტ�?ნილი�? სი�?ში";
$_lang['the data set is now modified.'] = "თ�?რიღები შეცვლილი�?";
$_lang['Please choose a user'] = "�?ირჩიეთ მ�?მხმ�?რებელი";
$_lang['is still listed in some projects. Please remove it.'] = "კვლ�?ვ�?ც ჩ�?მ�?თვლილი�? ზ�?გიერთ პრ�?ექტში. წ�?შ�?ლეთ.";
$_lang['All profiles are deleted'] = "ყველ�? კ�?ტეგ�?რი�? წ�?შლილი�?";
$_lang['A Profile with the same name already exists'] = "A profile with the same name already exists";
$_lang['is taken out of all user profiles'] = "�?მ�?ღებული�? მ�?მხმ�?რებლის ყველ�? კ�?ტეგ�?რიიდ�?ნ";
$_lang['All todo lists of the user are deleted'] = "მ�?მხმ�?რებლის ყველ�? გეგმები წ�?შლილი�?";
$_lang['is taken out of these votes where he/she has not yet participated'] = "�?მ�?ღებული�? იმ კენჭისყრიდ�?ნ, ს�?დ�?ც �?რ�? �?ქვს მიღებული მ�?ნ�?წილე�?ბ�?";
$_lang['All events are deleted'] = " ყველ�? მ�?ვლენ�? წ�?შლილი�?";
$_lang['user file deleted'] =  "ყველ�? ფ�?ილი წ�?შლილი�?";
$_lang['bank account deleted'] = "ს�?ბ�?ნკ�? �?ნგ�?რიში წ�?შლილი�?";
$_lang['finished'] = "დ�?სრულებული�?";
$_lang['Please choose a project'] = "�?ირჩიეთ პრ�?ექტი";
$_lang['The project is deleted'] = "პრ�?ექტი წ�?შლილი�?";
$_lang['All links in events to this project are deleted'] = "�?მ პრ�?ექტის მ�?ვლენების ყველ�? ბმული წ�?შლილი�?";
$_lang['The duration of the project is incorrect.'] = "პრ�?ექტისთვის გ�?ნკუთვნილი დრ�? �?რ�?სწ�?რედ �?რის მ�?ცემული";
$_lang['The project is now in the list'] = "პრ�?ექტი შეტ�?ნილი�? სი�?ში";
$_lang['The project has been modified'] = "პრ�?ექტი შეცვლილი�?";
$_lang['Please choose a resource'] = "�?ირჩიეთ რესურსი";
$_lang['The resource is deleted'] = "რესურსი წ�?შლილი�?";
$_lang['All links in events to this resource are deleted'] = "კველ�? ბმული მ�?ვლენებიდ�?ნ �?მ რესურსთ�?ნ წ�?შლილი�?";
$_lang[' The resource is now in the list.'] = "რესურსი შეტ�?ნილი�? სი�?ში";
$_lang[' The resource has been modified.'] = "რესურსი შეცვლილი�?";
$_lang['The server sent an error message.'] = "სერვერმ�? გ�?მ�?�?გზ�?ვნ�? შეტყ�?ბინებ�? შეცდ�?მ�?ზე:";
$_lang['All Links are valid.'] = "ყველ�? ბმული სწ�?რი�?";
$_lang['Please select at least one bookmark'] = " �?ირჩიეთ ერთი ს�?ნიშნე მ�?ინც";
$_lang['The bookmark is deleted'] =  "ს�?ნიშნე წ�?შლილი�?";
$_lang['threads older than x days are deleted.'] = "თემები x დღეზე ძველი წ�?შლილი�?.";
$_lang['All chat scripts are removed'] = "დისკუსიის ყველ�? ტექსტი წ�?შლილი�?";
$_lang['or'] = "�?ნ";
$_lang['Timecard management'] = "კ�?ლენდ�?რით მ�?რთვ�?";
$_lang['View'] = "დ�?თვ�?ლიერებ�?";
$_lang['Choose group'] = "�?ირჩიეთ ჯგუფი";
$_lang['Group name'] = "ჯგუფის ს�?ხელი";
$_lang['Short form'] = "მ�?კლე ფ�?რმ�?";
$_lang['Category'] = "კ�?ტეგ�?რი�?";
$_lang['Remark'] = "კ�?მენტ�?რი";
$_lang['Group management'] = "ჯგუფით მ�?რთვ�?";
$_lang['Please insert a name'] = "შეიყვ�?ნეთ ს�?ხელი";
$_lang['Name or short form already exists'] = "ს�?ხელი �?ნ შემ�?კლებული ს�?ხელი უკვე �?რსებ�?ბს";
$_lang['Automatic assign to group:'] = "�?ვტ�?მ�?ტიურ�?დ დ�?ენიშნებ�? ჯგუფს:";
$_lang['Automatic assign to user:'] = "�?ვტ�?მ�?ტიურ�?დ დ�?ენიშნებ�? მ�?მხმ�?რებელს:";
$_lang['Help Desk Category Management'] = "ს�?ინფ�?რმ�?ცი�?ს კ�?ტეგ�?რიებით მ�?რთვ�?";
$_lang['Category deleted'] = "კ�?ტე�?რი�? წ�?შლილი�?";
$_lang['The category has been created'] = "კ�?ტეგ�?რი�? შექმნილი�?";
$_lang['The category has been modified'] = "კ�?ტეგ�?რი�? შეცვლილი�?";
$_lang['Member of following groups'] = "�?რის შემდეგ ჯგუფებში";
$_lang['Primary group is not in group list'] = "პირველ�?დი ჯგუფი �?რ �?რის სი�?ში";
$_lang['Login name'] =  "რეგისტრ�?ციის ს�?ხელი";
$_lang['You cannot delete the default group'] = "�?მ ჯგუფის წ�?შლ�? შეუძლებელი�?";
$_lang['Delete group and merge contents with group'] = "ჯგუფის წ�?შლ�? დ�? ინფ�?რმ�?ციის გ�?დ�?ტ�?ნ�? სხვ�? ჯგუფისთვის";
$_lang['Please choose an element'] = "�?ირჩიეთ ელემენტი";
$_lang['Group created'] = "ჯგუფი შექმნილი�?";
$_lang['File management'] = "ფ�?ილებით მ�?რთვ�?";
$_lang['Orphan files'] ="�?რ�?ვისი ფ�?ილები";
$_lang['Deletion of super admin root not possible'] = "სუპერ �?დმინისტრ�?ტ�?რის წ�?შლ�? შეუძლებელი�?";
$_lang['ldap name'] = "ldap-ის დ�?ს�?ხელებ�?";
$_lang['mobile // mobile phone'] = "მ�?ბილური";
$_lang['Normal user'] =  "რიგითი მ�?მხმ�?რებელი";
$_lang['User w/Chief Rights'] =  "მ�?მხმ�?რებელი უფრ�?სის უფლებებით";
$_lang['Administrator'] =  "�?დმინისტრ�?ტ�?რი";
$_lang['Logging'] = "შემ�?სვლის სტ�?ტისტიკ�?";
$_lang['Logout'] =  "გ�?მ�?სვლ�?";
$_lang['posting (and all comments) with an ID'] = "წერილის (კ�?მენტ�?რის) გ�?გზ�?ვნ�? ID-ს მითითებით";
$_lang['Role deleted, assignment to users for this role removed'] = "რ�?ლი წ�?შლილი�?, �?მ რ�?ლის მიკუთვნებ�? მ�?მხმ�?რებლებისთვის გ�?უქმებული�?";
$_lang['The role has been created'] = "რ�?ლი შექმნილი�?";
$_lang['The role has been modified'] = "რ�?ლი მ�?დიფიცირებული�?";
$_lang['Access rights'] = "Access rights";
$_lang['Usergroup'] = "Gruppe";
$_lang['logged in as'] = "Angemeldet als";

//chat.php
$_lang['Quit chat']= "Quit chat";

//contacts.php
$_lang['Contact Manager'] = "კ�?ნტ�?ქტების მენეჯერი";
$_lang['New contact'] = "�?ხ�?ლი კ�?ნტ�?ქტი";
$_lang['Group members'] ="ჯგუფის წევრები";
$_lang['External contacts'] = "გ�?რე კ�?ნტ�?ქტი";
$_lang['&nbsp;New&nbsp;'] = "�?ხ�?ლი&nbsp;";
$_lang['Import'] = "იმპ�?რტი";
$_lang['The new contact has been added'] = "�?ხ�?ლი კ�?ნტ�?ქტები მ�?მ�?ტებული�?";
$_lang['The date of the contact was modified'] ="კ�?ნტ�?ქტის თ�?რიღი შეცვლილი�?";
$_lang['The contact has been deleted'] = "კ�?ნტ�?ქტი წ�?შლილი�?";
$_lang['Open to all'] = "ყველ�?ს�?თვის ღი�?�?";
$_lang['Picture'] ="სურ�?თი";
$_lang['Please select a vcard (*.vcf)'] = "�?ირჩიეთ vcard-ი (*.vcf)";
$_lang['create vcard'] = "vcard-ის შექმნ�?";
$_lang['import address book'] = "მის�?მ�?რტების წიგნის იმპ�?რტირებ�?";
$_lang['Please select a file (*.csv)'] = "�?ირჩიეთ ფ�?ილი (*.csv)";
$_lang['Howto: Open your outlook express address book and select file/export/other book<br>Then give the file a name, select all fields in the next dialog and finish'] = "რ�?გ�?რ: გ�?ხსენით outlook express-ის მის�?მ�?რთების წიგნი (address book) 
�?ირჩიეთ 'file'/'export'/'other book'<br>მიუთითეთ ფ�?ილის ს�?ხელი, 
შემდეგ მ�?ნიშნეთ ყველ�? ველი დ�? დ�?�?ჭირეთ 'finish'-ს";
$_lang['Open outlook at file/export/export in file,<br>choose comma separated values (Win), then select contacts in the next form,<br>give the export file a name and finish.'] = "გ�?ხსენით outlook, შეიდთ  'file/export/export in file',<br>
�?ირჩიეთ 'comma separated values (Win)' (მძიმეთი დ�?ყ�?ფილი ველები), �?ირჩიეთ 'contacts' შემდეგ ფ�?რმ�?ში,<br>დ�?�?რქვით ფ�?ილს ს�?ხელი დ�? დ�?�?სრულეთ.";
$_lang['Please choose an export file (*.csv)'] = "�?ირჩიეთ ფ�?ილი ეხპ�?რტირებისთვის (*.csv)";
$_lang['Please export your address book into a comma separated value file (.csv), and either<br>1) apply an import pattern OR<br>2) modify the columns of the table with a spread sheet to this format<br>(Delete colums in you file that are not listed here and create empty colums for fields that do not exist in your file):'] = "ექსპ�?რტირებ�? გ�?უქეთეთ თქვენს მის�?მ�?რთების წიგნს  
(.csv) ფ�?ილის ფ�?რმ�?ტში (მძიმეთი დ�?ყ�?ფილი ველებით), დ�? <b>�?ნ</b> <br>
1) გ�?დ�?იყვ�?ნეთ იმპ�?რტირებულ ფ�?რმ�?ტში <b>�?ნ</b><br>
2) წ�?შ�?ლეთ ტქვენს ფ�?ილში ის სვეტი, რ�?მელიც �?რ �?რის ჩ�?მ�?თვლილი �?ქ დ�? შექმენით ც�?რიელი სვეტები იმ ველებისთვის, რ�?მელიც �?რ �?რის თხვენს ფ�?ილში:";
$_lang['Please insert at least the family name'] = "შეიყვ�?ნეთ გვ�?რი მ�?ინც";
$_lang['Record import failed because of wrong field count'] = "ჩ�?ნ�?წერის იმპ�?რტირებ�? �?რ გ�?მ�?დის ველების �?რ�?სწ�?რი რ�?�?დენ�?ბის გ�?მ�?";
$_lang['Import to approve'] = "დ�?მტკიცებ�?";
$_lang['Import list'] = "იმპ�?რტირების სი�?";
$_lang['The list has been imported.'] = "სი�? იმპ�?რტირებული�?.";
$_lang['The list has been rejected.'] = "სი�? �?კრძ�?ლული�?.";
$_lang['Profiles'] =  "კ�?ტეგ�?რიები";
$_lang['Parent object'] = "მშ�?ბლიური �?ბიექტი";
$_lang['Check for duplicates during import'] = "იმპ�?რტირების დრ�?ს დუბლირებ�?ზე შემ�?წმებ�?";
$_lang['Fields to match'] = "ველები, რ�?მელიც უნდ�? დ�?ემთხვ�?ს";
$_lang['Action for duplicates'] = "დუბლირებ�?:";
$_lang['Discard duplicates'] = "კ�?პიების გ�?მ�?ტ�?ვებ�?";
$_lang['Dispose as child'] = "ქვე-�?ბიექტი";
$_lang['Store as profile'] = "კ�?ტეგ�?რიის შენ�?ხვ�?";    
$_lang['Apply import pattern'] = "იმპ�?რტირებულ ნიმუშის მსგ�?ვს�?დ ფ�?რმ�?ტირებ�?";
$_lang['Import pattern'] = "ნიმუშის იმპ�?რტირებ�?";
$_lang['For modification or creation<br>upload an example csv file'] = "შექმნისთვის �?ნ მ�?დიფიკ�?ციისთვის<br>�?ტვირთეთ ს�?ნიმუშ�? csv ფ�?ილი"; 
$_lang['Skip field'] =  "ველის გ�?მ�?ტ�?ვებ�?";
$_lang['Field separator'] = "ველების გ�?ს�?ყ�?ფი სიმბ�?ლ�?";
$_lang['Contact selector'] = "Contact selector";

// filemanager.php
$_lang['Please select a file'] = "�?ირჩიეთ ფ�?ილი";
$_lang['A file with this name already exists!'] = "�?სეთი ფ�?ილი უკვე �?რსებ�?ბს";
$_lang['Name'] ="ს�?ხელი";
$_lang['Comment'] ="კ�?მენტ�?რი";

$_lang['Date'] ="თ�?რიღი";
$_lang['Upload'] = "ჩ�?წერ�?";
$_lang['Filename and path'] = "ფ�?ილის მდებ�?რე�?ბ�? დ�? ჩ�?ს�?ხელი";
$_lang['Delete file'] = "ფ�?ილის წ�?შლ�?";
$_lang['Overwrite'] = "ზედ გ�?დ�?წერ�?";
$_lang['Access'] = "მიწვდ�?მ�?";
$_lang['Me'] = "მე";
$_lang['Group'] = "ჯგუფი";
$_lang['Some'] =  "რ�?მ�?დენიმე";
$_lang['As parent object'] = "რ�?გ�?რც მშ�?ბლიური �?ბიექტი"; 
$_lang['All groups'] =  "ყველ�? ჯგუფი";
$_lang['You are not allowed to overwrite this file since somebody else uploaded it'] = "თქვენ �?რ შეგიძლი�?თ ფ�?ილის გ�?დ�?წერ�?, მ�?ს ეხლ�? იწერს სხვ�?";
$_lang['personal'] = "პირ�?დი";

$_lang['Link'] = "ბმული";
$_lang['name and network path'] = "გზის დ�?მ�?ტებ�?";
$_lang['with new values'] = "�?ხ�?ლი მნიშვნელ�?ბებით";
$_lang['All files in this directory will be removed! Continue?'] = "ყველ�? ფ�?ილი კ�?ტ�?ლ�?გში წ�?შლილი იქნებ�?, გ�?ვ�?გრძელ�?თ?";
$_lang['This name already exists'] =  "ეს ს�?ხელი უკვე �?რსებ�?ბს";
$_lang['Max. file size'] = "ფ�?ილის მ�?ქსიმ�?ლური ზ�?მ�?";
$_lang['links to'] =  "ბმული";
$_lang['objects'] = "�?ბიექტები";
$_lang['Action in same directory not possible'] = "მ�?ქმედებ�? იმ�?ვე კ�?ტ�?ლ�?გში შეუძლებელი�?";
$_lang['Upload = replace file'] = "ჩ�?წერ�? = ფ�?ილების შეცვლ�?";
$_lang['Insert password for crypted file'] = "შეიყვ�?ნეთ პ�?რ�?ლი ფ�?ილისთვის";
$_lang['Crypt upload file with password'] = "პ�?რ�?ლით ფ�?ილის დ�?ცვისთვის";
$_lang['Repeat'] =  "პ�?რ�?ლის გ�?მე�?რებ�?";
$_lang['Passwords dont match!'] =  "პ�?რ�?ლები �?რ ემთხვევ�?!";
$_lang['Download of the password protected file '] = "პ�?რ�?ლით დ�?ცული ფ�?ილების გ�?დმ�?წერ�? ";
$_lang['notify all users with access'] = "ყველ�? მ�?მხმ�?რებლის შეტყ�?ბინებ�? მიწვდ�?მ�?ზე";
$_lang['Write access'] = "მიწვდ�?მ�? ჩ�?წერის უფლებით";
$_lang['Version'] =  "ვერსი�?";
$_lang['Version management'] =  "ვერსიების მ�?რთვ�?";
$_lang['lock'] =  "ბლ�?კირებ�?";
$_lang['unlock'] =  "ბლ�?კირების მ�?ხსნ�?";
$_lang['locked by'] =  "ვის მიერ ბლ�?კირებული�?";
$_lang['Alternative Download'] = "�?ლტერნ�?ტიული გ�?დმ�?ცერ�?";
$_lang['Download'] = "Download";
$_lang['Select type'] = "Select type";
$_lang['Create directory'] = "Create directory";
$_lang['filesize (Byte)'] = "Filesize (Byte)";

// filter
$_lang['contains'] =  'შეიც�?ვს';
$_lang['exact'] = 'ზუსტ�?დ';
$_lang['starts with'] =  'იწყებ�?';
$_lang['ends with'] =  'მთ�?ვრდებ�?';
$_lang['>'] = '>';
$_lang['>='] = '>=';
$_lang['<'] = '<';
$_lang['<='] = '<=';
$_lang['does not contain'] =  '�?რ შეიც�?ვს'; 
$_lang['Please set (other) filters - too many hits!'] = "Please set (other) filters - too many hits!";

$_lang['Edit filter'] = "Edit filter";
$_lang['Filter configuration'] = "Filter configuration";
$_lang['Disable set filters'] = "Disable set filters";
$_lang['Load filter'] = "Load filter";
$_lang['Delete saved filter'] = "Delete saved filter";
$_lang['Save currently set filters'] = "Save currently set filters";
$_lang['Save as'] = "Save as";
$_lang['News'] = 'Nachrichten';

// form designer
$_lang['Module Designer'] = "მ�?დულების დიზ�?ინი";  //Module Designer
$_lang['Module element'] = "მ�?დულის ელემენტი"; 
$_lang['Module'] = "მ�?დული";
$_lang['Active'] =  "�?ქტიური";
$_lang['Inactive'] =  "�?რ�?�?ქტიური";
$_lang['Activate'] =  "�?ქტივიზირებ�?";
$_lang['Deactivate'] =  "დე�?ქტივიზირებ�?"; 
$_lang['Create new element'] =  "�?ხ�?ლი ელემენტის შექმნ�?";
$_lang['Modify element'] = "ელემენტის შეცვლ�?";
$_lang['Field name in database'] = "ველის დ�?ს�?ხელებ�? მ�?ნ�?ცემთ�? ბ�?ზ�?ში";
$_lang['Use only normal characters and numbers, no special characters,spaces etc.'] = "მც�?ლ�?დ ნ�?რმ�?ლური ციფრების დ�? �?ს�?ების გ�?მ�?ყენებ�?, სპეცი�?ლური სიბ�?ლ�?ები დ�?უშვებელი�?";
$_lang['Field name in form'] = "ველის დ�?ს�?ხელებ�? ფ�?რმ�?ში";
$_lang['(could be modified later)'] = "(შეს�?ძლ�?�? შეიცვ�?ლ�?ს მ�?გვი�?ნებით)"; 
$_lang['Single Text line'] = "ც�?ლი ხ�?ზი";
$_lang['Textarea'] = "ტექსტური �?რე";
$_lang['Display'] = "გ�?მ�?ჩენ�?";
$_lang['First insert'] = "პირველ�?დ შეყვ�?ნ�?";
$_lang['Predefined selection'] = "წინ�?სწ�?რ გ�?ნს�?ძღვრული �?რჩევ�?ნი";
$_lang['Select by db query'] = "�?ირჩიეთ მ�?ნ�?ცემთ�? ბ�?ზ�?სთ�?ნ მიმ�?რთვ�?";
$_lang['File'] =  "ფ�?ილი";

$_lang['Email Address'] =  "ელ. ფ�?სტის მის�?მ�?რთი";
$_lang['url'] =  "ინტერნეტის მის�?მ�?რთი";
$_lang['Checkbox'] = "ჩ�?მრთველი";
$_lang['Multiple select'] = "რ�?მ�?დენიმეს ერთდრ�?ულ�?დ �?რჩევ�?";
$_lang['Display value from db query'] = "Display value from db query";
$_lang['Time'] = "Time";
$_lang['Tooltip'] = "რჩევ�?"; 
$_lang['Appears as a tipp while moving the mouse over the field: Additional comments to the field or explanation if a regular expression is applied'] = "გ�?მ�?ჩნდებ�? გ�?ნმ�?რტებ�? ველზე კურს�?რის დ�?ყენების დრ�?ს: ველისთვის დ�?მ�?ტებითი კ�?მენტ�?რი, იმ შემთხვევ�?ში თუ ველისთვის გ�?მ�?ყენებული�? შებლ�?ნი";
$_lang['Position'] =  "გ�?ნლ�?გებ�?";
$_lang['is current position, other free positions are:'] = "�?რის მიმდინ�?რე პ�?ზიცი�?, სხვ�? თ�?ვისუფ�?ლი პ�?ზიციები:"; 
$_lang['Regular Expression:'] = "შ�?ბლ�?ნი:";
$_lang['Please enter a regular expression to check the input on this field'] = "გ�?მ�?იყენეთ შებლ�?ნი ველში ჩ�?წერილი მ�?ნ�?ცემების შეს�?მ�?წმებლ�?დ";
$_lang['Default value'] = "ნ�?გულისხმევი მნიშვნელ�?ბ�?";
$_lang['Predefined value for creation of a record. Could be used in combination with a hidden field as well'] = "ჩ�?ნ�?წერის შექმნისთვის წინ�?სწ�?რ გ�?ნს�?ზღვრული მნიშვნელ�?ბ�?. შეიძლებ�? გ�?მ�?ყენებული იყ�?ს �?დ�?მ�?ლული�? ველების შემთხვევ�?შიც";
$_lang['Content for select Box'] = "ვ�?რი�?ნტების მნიშვნელ�?ბ�? სელეცტ�?რისთვის (Select Box)";
$_lang['Used for fixed amount of values (separate with the pipe: | ) or for the sql statement, see element type'] = "გ�?მ�?იყენებ�? მნიშვნელ�?ბების გ�?ნს�?ზღვრულ რ�?�?დენ�?ბ�?სთ�?ნ (გ�?ყ�?ვით �?|�? სიმბ�?ლ�?თი ) �?ნ sql მტკიცების მეშვე�?ბით, იხილეთ ელემენტების ტიპები";
$_lang['Position in list view'] = "პ�?ზიცი�? სი�?ში";                                                                                     
$_lang['Only insert a number > 0 if you want that this field appears in the list of this module'] = "შეიყვ�?ნეთ მხ�?ლ�?დ რიცხვი > 0 თუ გსურთ ველის ფ�?მ�?ჩენ�? �?მ მ�?დულის სი�?ში";
$_lang['Alternative list view'] = "�?ლტერნ�?ტიული სიის ნ�?ხვ�?";
$_lang['Value appears in the alt tag of the blue button (mouse over) in the list view'] = "მნიშვნელ�?ბები გ�?მ�?ჩნდებ�? კურს�?რის ლურჯ ღილ�?კზე დ�?ყენების�?ს";
$_lang['Filter element'] = "ფილტრის ელემენტი";                                                                                   
$_lang['Appears in the filter select box in the list view'] = "გ�?მ�?ცნდებ�? ფილტრის ვ�?რი�?ნტების ჩ�?მ�?ნ�?თვ�?ლში";
$_lang['Element Type'] = " ელემენტის ტიპი";
$_lang['Select the type of this form element'] = "�?ირჩიეთ ფ�?რმის ელემენტის ტიპი";
$_lang['Check the content of the previous field!'] = "შე�?მ�?წმეთ წინ�? ველის მნიშვნელ�?ბ�?!";
$_lang['Span element over'] = "ელემენტის გ�?ვრცელებ�?";
$_lang['columns'] =  "სვეტი";
$_lang['rows'] =  "რიგი"; 
$_lang['Telephone'] = "Telephone";
$_lang['History'] = "History";
$_lang['Field'] = "Field";
$_lang['Old value'] = "Old value";
$_lang['New value'] = "New value";
$_lang['Author'] = "Author"; 
$_lang['Show Date'] = "Show Date";
$_lang['Creation date'] = "Creation date";
$_lang['Last modification date'] = "Last modification date";
$_lang['Email (at record cration)'] = "Email (at record cration)";
$_lang['Contact (at record cration)'] = "Contact (at record cration)"; 
$_lang['Select user'] = "Select user";
$_lang['Show user'] = "Show user";

// forum.php
$_lang['Please give your thread a title'] = "Please give your thread a title";
$_lang['New Thread'] = "New Thread";
$_lang['Title'] = "Title";
$_lang['Text'] = "Text";
$_lang['Post'] = "Post";
$_lang['From'] = "From";
$_lang['open'] = "open";
$_lang['closed'] = "closed";
$_lang['Notify me on comments'] = "Notify me on comments";
$_lang['Answer to your posting in the forum'] = "Answer to your posting in the forum";
$_lang['You got an answer to your posting'] = "You got an answer to your posting \n ";
$_lang['New posting'] = "New posting";
$_lang['Create new forum'] = "Create new forum";
$_lang['down'] ='down';
$_lang['up']= "up";
$_lang['Forums']= "Forums";
$_lang['Topics']="Topics";
$_lang['Threads']="Threads";
$_lang['Latest Thread']="Latest Thread";
$_lang['Overview forums']= "Overview forums";
$_lang['Succeeding answers']= "Succeeding answers";
$_lang['Count']= "Count";
$_lang['from']= "from";
$_lang['Path']= "Path";
$_lang['Thread title']= "Thread title";
$_lang['Notification']= "Notification";
$_lang['Delete forum']= "Delete forum";
$_lang['Delete posting']= "Delete posting";
$_lang['In this table you can find all forums listed']= "In this table you can find all forums listed";
$_lang['In this table you can find all threads listed']= "In this table you can find all threads listed";

// index.php
$_lang['Last name'] = "Last name";
$_lang['Short name'] = "Short name";
$_lang['Sorry you are not allowed to enter.'] = "Sorry you are not allowed to enter.";
$_lang['Please run index.php: '] = "Please run index.php: ";
$_lang['Reminder'] = "Reminder";
$_lang['Session time over, please login again'] = "Session time over, please login again";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
$_lang['Tree view'] = "Tree view";
$_lang['flat view'] = "flat view";
$_lang['New todo'] = "New todo";
$_lang['New note'] = "New note";
$_lang['New document'] = "New document";
$_lang['Set bookmark'] = "Set bookmark";
$_lang['Move to archive'] = "Move to archive";
$_lang['Mark as read'] = "Mark as read";
$_lang['Export as csv file'] = "Export as csv file";
$_lang['Deselect all'] = "Deselect all";
$_lang['selected elements'] = "selected elements";
$_lang['wider'] = "wider";
$_lang['narrower'] = "narrower";
$_lang['ascending'] = "Aufsteigend";
$_lang['descending'] = "descending";
$_lang['Column'] = "Column";
$_lang['Sorting'] = "Sorting";
$_lang['Save width'] = "Save width";
$_lang['Width'] = "Width";
$_lang['switch off html editor'] = "switch off html editor";
$_lang['switch on html editor'] = "switch on html editor";
$_lang['hits were shown for'] = "hits were shown for";
$_lang['there were no hits found.'] = "there were no hits found.";
$_lang['Filename'] = "Filename";
$_lang['First Name'] = "First Name";
$_lang['Family Name'] = "Family Name";
$_lang['Company'] = "Company";
$_lang['Street'] = "Street";
$_lang['City'] = "City";
$_lang['Country'] = "Country";
$_lang['Please select the modules where the keyword will be searched'] = "Please select the modules where the keyword will be searched";
$_lang['Enter your keyword(s)'] = "Enter your keyword(s)";
$_lang['Salutation'] = "Salutation";
$_lang['State'] = "State";
$_lang['Add to link list'] = "Add to link list";

// setup.php
$_lang['Welcome to the setup of PHProject!<br>'] = "<b>PHProjekt SETUP</b><br>";
$_lang['Please remark:<ul><li>A blank database must be available<li>Please ensure that the webserver is able to write the file config.inc.php'] = "გ�?ითვ�?ლისწინეთ:<ul><li>ს�?ჭირ�?�? �?ხ�?ლი 
მ�?ნ�?ცემთ�? ბ�?ზ�?<li>შე�?მ�?წმეთ, შეუძლი�? თუ �?რ�? ვებსერვერს 
ფ�?ილის ჩ�?წერ�? ფ�?ილში 'config.inc.php'";
$_lang['<li>If you encounter any errors during the installation, please look into the <a href=help/faq_install.html target=_blank>install faq</a>or visit the <a href=http://www.PHProjekt.com/forum.html target=_blank>Installation forum</a></i>'] = "<li>თუ ინსტ�?ლირების პრ�?ცესში მ�?ხდ�? შეცდ�?მები, იხილეთ 
<a href='help/faq_install.html' target=_blank>install faq (შეკითხვები ინსტ�?ლ�?ცი�?ზე)</a>�?ნ <a href='http://www.PHProjekt.com/forum.html' target=_blank>Installation forum (ფ�?რუმი ინსტ�?ლ�?ცი�?ზე)</a></i>";
$_lang['Please fill in the fields below'] = "შე�?ვსეთ შემდეგი ველები";
$_lang['(In few cases the script wont respond.<br>Cancel the script, close the browser and try it again).<br>'] = "(თუ სკრიპტი ვერ გ�?ეშვ�?, �?ნ �?რ პ�?სუხ�?ბს.<br>გ�?�?უქმეთ იგი, 
დ�?ხურეთ ბრ�?უზერის ფ�?ნჯ�?რ�? დ�? სც�?დეთ კიდევ).<br>";
$_lang['Type of database'] ="მ�?ნ�?ცემთ�? ბ�?ზის ტიპი";
$_lang['Hostname'] = "ჰ�?სტნ�?მე";
$_lang['Username'] = "მ�?მხმ�?რებლის ს�?ხელი";

$_lang['Name of the existing database'] ="�?რსებული მ�?ნ�?ცემთ�? ბ�?ზის ს�?ხელი";
$_lang['config.inc.php not found! Do you really want to update? Please read INSTALL ...'] = "ვერ ვპ�?ულ�?ბ ფ�?ილს config.inc.php! ნ�?მდვილ�?დ გსურთ გ�?ნ�?ხლებ�?? წ�?იკითხეთ ინსტ�?ლ�?ციის წესები ...";
$_lang['config.inc.php found! Maybe you prefer to update PHProject? Please read INSTALL ...'] = "config.inc.php ნ�?პ�?ვნი�?! ხ�?მ �?რ გსურთ PHProject-ის გ�?ნ�?ხლებ�?? წ�?იკითხეთ ინსტ�?ლ�?ციის წესები ...";
$_lang['Please choose Installation,Update or Configure!'] = "�?ირჩიეთ 'ინსტ�?ლ�?ცი�?','გ�?ნ�?ხლებ�?' �?ნ 'კ�?ნფიგურირებ�?'!";
$_lang['Sorry, I cannot connect to the database! <br>Please close all browser windows and restart the installation.'] = "მ�?ნ�?ცემთ�? ბ�?ზ�?სთ�?ნ �?რ �?რის კ�?ვშირი! <br>დ�?ხურეთ ბრ�?უზერის ყველ�? ფ�?ნჯ�?რ�? დ�? დ�?იწყეთ ინსტ�?ლ�?ციის პრ�?ცესი თ�?ვიდ�?ნ.";
$_lang['Sorry, it does not work! <br> Please set DBDATE to Y4MD- or let phprojekt change this environment-variable (php.ini)!'] = "�?რ მუშ�?�?ბს! <br> გ�?დ�?�?სწ�?რეთ DBDATE:  'Y4MD-' �?ნ �?ც�?ლეთ phprojekt-ს ცვლ�?დის შესწ�?რებ�? (php.ini)!";
$_lang['Seems that You have a valid database connection!'] = "მ�?ნ�?ცემთ�? ბ�?ზ�?სთ�?ნ კ�?ვშირი �?რის!";
$_lang['Please select the modules you are going to use.<br> (You can disable them later in the config.inc.php)<br>'] = "�?ირჩიეთ მ�?დულები.<br> (შემდგ�?მში ს�?შუ�?ლებ�? გექნებ�?თ მ�?თი გ�?მ�?რთვ�? config.inc.php ფ�?ილიდ�?ნ)<br>";
$_lang['Install component: insert a 1, otherwise keep the field empty'] = "კ�?მპ�?ნენტის დ�?ყენებისთვის ჩ�?წერეთ '1', სხვ�? შემთხვევ�?ში დ�?ტ�?ვეთ ც�?რიელი";
$_lang['Group views'] = "ჯგუფური დ�?თვ�?ლიერებ�?";
$_lang['Todo lists'] = "გეგმები";

$_lang['Voting system'] =  "კენჭისყრის სისტემ�?";


$_lang['Contact manager'] = "კ�?ნტ�?ქტები";
$_lang['Name of userdefined field'] =   "მ�?მხმ�?რებლის მიერ �?რჩეული ველის ს�?თ�?ური";
$_lang['Userdefined'] = "მ�?მხმ�?რებლის გ�?ნს�?ზღვრული";
$_lang['Profiles for contacts'] =  "კ�?ტეგ�?რიები კ�?ნტ�?ქტებისთვის";
$_lang['Mail'] = "ფ�?სტ�?";
$_lang['send mail'] = " ფ�?სტის გ�?გზ�?ვნ�?";
$_lang[' only,<br> &nbsp; &nbsp; full mail client'] = " მხ�?ლ�?დ,<br> &nbsp; &nbsp; სრულყ�?ფილი ელ. ფ�?სტის კლიენტი";



$_lang['1 to show appointment list in separate window,<br>&nbsp; &nbsp; 2 for an additional alert.'] = "'1' შეხხვედრების სიის გ�?მ�?ტ�?ნ�? ც�?ლკე ფ�?ნჯ�?რ�?ში,<br>
&nbsp; &nbsp; '2' დ�?მ�?ტებითი გ�?ფრთხილების�?თვის.";
$_lang['Alarm'] = "გ�?ნგ�?ში";
$_lang['max. minutes before the event'] = "წუთების მ�?ქს. რ�?�?დენ�?ბ�? მ�?ვლენ�?მდე";
$_lang['SMS/Mail reminder'] = "SMS/ელ. ფ�?სტით შეხსენებ�?";
$_lang['Reminds via SMS/Email'] = "შეხსენებ�? SMS/ელ. ფ�?სტით";
$_lang['1= Create projects,<br>&nbsp; &nbsp; 2= assign worktime to projects only with timecard entry<br>&nbsp; &nbsp; 3= assign worktime to projects without timecard entry<br>&nbsp; &nbsp; (Selection 2 or 3 only with module timecard!)'] = "'1'= პრ�?ექტების შექმნ�?,<br>&nbsp; &nbsp; '2'= პრ�?ექტებისთვის ს�?მუშ�?�? დრ
�?ის მითითებ�? მხ�?ლ�?დ ტ�?ბელში შეტ�?ნის�?ს<br>&nbsp; &nbsp; '3'= პრ�?ექტებისთვის 
ს�?მუშ�?�? დრ�?ის მითითებ�? ტ�?ბელებშ შეტ�?ნის გ�?რეშე<br>&nbsp; &nbsp; (ვ�?რი�?ნტი '2' �?ნ '3' მხ�?ლ�?დ ტ�?ბელების მ�?დულის დ�?ყენების შემთხვევ�?ში!)";

$_lang['Name of the directory where the files will be stored<br>( no file management: empty field)'] = "ს�?ქ�?ღ�?ლდეს ს�?ხელი, ს�?დ�?ც შენ�?ხული იქნებ�? ფ�?ილები<br>( ნუ შე�?ვსებთ �?მ ველს თუ ფ�?ილებთ�?ნ მუშ�?�?ბის მ�?დული �?რ �?რის �?რჩეული)";
$_lang['absolute path to this directory (no files = empty field)'] = "კ�?ტ�?ლ�?გთ�?ნ �?ბს�?ლუტური გზ�?";
$_lang['Time card'] = "ტ�?ბელი";
$_lang['1 time card system,<br>&nbsp; &nbsp; 2 manual insert afterwards sends copy to the chief'] = "'1' ტ�?ბელების სისტემ�?,<br>&nbsp; &nbsp; '2' ხელით ჩ�?წერ�? დ�? 
ხელმძღვ�?ნეთ�?ნ კ�?პიის გ�?გზ�?ვნ�?";
$_lang['Notes'] = "შენიშვნები";
$_lang['Password change'] =  "პ�?რ�?ლის შეცვლ�?";
$_lang['New passwords by the user - 0: none - 1: only random passwords - 2: choose own'] = "პ�?რ�?ლის შეცვლის უფლებ�? �?ქვს მ�?მხმ�?რებელს - 0: �?რ�? - 1: პ�?რ�?ლში მხ�?ლ�?დ შემთხვევითი კ�?მბინ�?ციები - 2: შერჩევით";
$_lang['Encrypt passwords'] ="პ�?რ�?ლის შიფრ�?ცი�?";
$_lang['Login via '] = "სისტემ�?ში შესვლ�?  ";
$_lang['Extra page for login via SSL'] = "დ�?მ�?ტებითი გვერი SSL პრ�?ტ�?კ�?ლის გ�?მ�?ყენების შემთხვევ�?ში";
$_lang['Groups'] = "ჯგუფები";
$_lang['User and module functions are assigned to groups<br>&nbsp; &nbsp; (recommended for user numbers > 40)'] = "მ�?მხმ�?რებლების დ�? მ�?დულების ფ�?ნქციები მიბმული�? 
ჯგუფებთ�?ნ<br>&nbsp; &nbsp; (რეკ�?მენდირებული�?, თუ სისტემ�?ში 40-ზე მეტი მ�?მხმ�?რებელი�?)";
$_lang['User and module functions are assigned to groups'] = "მ�?მხმ�?რებლების დ�? მ�?დულების ფ�?ნქციები მიბმული�? ჯგუფებთ�?ნ";
$_lang['Help desk'] = "ს�?ინფ�?რმ�?ცი�?";
$_lang['Help Desk Manager / Trouble Ticket System'] = "ს�?ინფ�?რმ�?ცი�?/ (Trouble Ticket System)";
$_lang['RT Option: Customer can set a due date'] = "ს�?ინფ�?რმ�?ცი�?ს პ�?რ�?მეტრი: კლიენტს შეუძლი�? შესრულების თ�?რიღის მითითებ�?";
$_lang['RT Option: Customer Authentification'] = "ს�?ინფ�?რმ�?ცი�?ს პ�?რ�?მეტრი: კლიენტების �?უტენტიფიკ�?ცი�?";
$_lang['0: open to all, email-address is sufficient<br>1: registered contact enter his family name<br>2: his email'] = "0: ყველ�?სთვის ღის, ს�?კმ�?რისი�? ელ. ფ�?სტის მის�?მ�?რთი<br>1: რეგისტრირებული კ�?ნტ�?ქტი, გვ�?რის შეყვ�?ნ�?<br>2: ელ. ფ�?სტის მის�?მ�?რთის შეყვ�?ნ�?";
$_lang['RT Option: Assigning request'] = "ს�?ინფ�?რმ�?ცი�?ს პ�?რ�?მეტრი: მ�?თხ�?ვნილების �?დრეს�?ტის მითითებ�?";
$_lang['0: by everybody, 1: only by persons with status chief'] = "0: შეუძლი�? ყველ�?ს მიერ, 1: შეუძლი�? მხ�?ლ�?დ ხელმძღვ�?ნელს'";
$_lang['Email Address of the support'] = "ელ. მის�?მ�?რთი ხმ�?რებისთვის";
$_lang['Scramble filenames'] = "ფ�?ილების ს�?ხელების მ�?დიფიცირებ�?";
$_lang['creates scrambled filenames on the server<br>assigns previous name at download'] = "სერვერზე ხდებ�? ფ�?ილების ს�?ხელების მ�?დიფიცირებ�?<br>
ხ�?ლ�? გ�?დმ�?წერის�?ს ხდებ�? მ�?თი �?ღდგენ�?";

$_lang['0: last name, 1: short name, 2: login name'] =  "0: გვ�?რი, 1: მ�?კლე ს�?ხელი, 2: რეგისტრ�?ციის ს�?ხელი"; 
$_lang['Prefix for table names in db'] = "მ�?ნ�?ცემთ�? ბ�?ზის ფ�?ილების დ�?ს�?ხელების პრეფიქსი";
$_lang['Alert: Cannot create file config.inc.php!<br>Installation directory needs rwx access for your server and rx access to all others.'] = "გ�?ფრთხილებ�?: 'config.inc.php'  ფ�?ილის შექმნ�? ვერ გ�?მ�?დის!<br>ს�?ინს
ტ�?ლ�?ცი�? დირექტ�?რი�?ს უნდ�? ჰქ�?ნდეს rwx access სერვერისთვის დ�? rx access სხვებისთვის.";
$_lang['Location of the database'] = "მ�?ნ�?ცემთ�? ბ�?ზის �?დგილმდებ�?რე�?ბ�?";
$_lang['Type of database system'] = "მ�?ნ�?ცემთ�? ბ�?ზის სისტემის ტიპი";
$_lang['Username for the access'] =  "მ�?მხმ�?რებლის ს�?ხელი შესვლის�?თვის";
$_lang['Password for the access'] = "პ�?რ�?ლი შესვლის�?თვის";
$_lang['Name of the database'] = "მ�?ნ�?ცემთ�? ბ�?ზის ს�?ხელი";
$_lang['Prefix for database table names'] = "მ�?ნ�?ცემთ�? ბ�?ზის წხრილების ს�?თ�?ურის პრეფიქსი";
$_lang['First background color'] =  "პირველი ფ�?ნის ფერი";
$_lang['Second background color'] =  "მე�?რე ფ�?ნის ფერი";
$_lang['Third background color'] =  "მეს�?მე ფ�?ნის ფერი";
$_lang['Color to mark rows'] = "Color to mark rows";
$_lang['Color to highlight rows'] = "Color to highlight rows";
$_lang['Event color in the tables'] = "მ�?ვლენის ფერი ცხრილში";
$_lang['company icon yes = insert name of image'] = "კ�?მპ�?ნიის ლ�?გ�?ტიპის გ�?მ�?ყენების შემთხვევ�?ში მიუთითეთ გზ�? გრ�?ფიკულ ფ�?ილთ�?ნ";
$_lang['URL to the homepage of the company'] = "კ�?მპ�?ნიის ვებგვერდის მის�?მ�?რთი";
$_lang['no = leave empty'] = "�?რ�? = დ�?ტ�?ვეთ ც�?რიელი";
$_lang['First hour of the day:'] =  "დღის პირველი ს�?�?თი";
$_lang['Last hour of the day:'] =  "დღის ბ�?ლ�? ს�?�?თი";
$_lang['An error ocurred while creating table: '] =  "ცხრილის შექმნის დრ�?ს შეცდ�?მ�? მ�?ხდ�?: ";
$_lang['Table dateien (for file-handling) created'] = "ცხრილი 'dateien' (ფ�?ილების შეს�?ნ�?ხ�?დ) შექმნილი�?";
$_lang['File management no = leave empty'] = "ფ�?ილებთ�?ნ მუშ�?�?ბ�?: �?რ�? = ნუ შე�?ვსებთ";
$_lang['yes = insert full path'] = "დი�?ხ = �?წერეთ სრული გზ�?";
$_lang['and the relative path to the PHProjekt directory'] = "გზ�? PHProjekt-ის დირექტ�?რი�?სთ�?ნ";
$_lang['Table profile (for user-profiles) created'] = "ცხრილი 'Profile' (მ�?მხმ�?რებლების კ�?ტეგ�?რიებისთვის) შექმნილი�?";
$_lang['User Profiles yes = 1, no = 0'] = "მ�?მხმ�?რებლების კ�?ტეგ�?რიები: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table todo (for todo-lists) created'] = "ცხრილი 'todo' (გეგმებისთვის) შექმნილი�?";
$_lang['Todo-Lists yes = 1, no = 0'] = "გეგმები: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table forum (for discssions etc.) created'] = "ცხრილის 'forum' (ფ�?რუმისთვის) შექმნილი�?";
$_lang['Forum yes = 1, no = 0'] = "ფ�?რუმი: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table votum (for polls) created'] = "ცხრილი 'votum' (კენჭისყრისთვის) შექმნილი�?";
$_lang['Voting system yes = 1, no = 0'] = "კენჭისყრის მ�?დული: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table lesezeichen (for bookmarks) created'] = "ცხრილი 'lesezeichen' (ს�?ნიშნებისთვის) შექმნილი�?";
$_lang['Bookmarks yes = 1, no = 0'] = "ს�?ნიშნები: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table ressourcen (for management of additional ressources) created'] = "ცვრილი 'ressourcen' (დ�?მ�?ტებით რესუსრსებთ�?ნ მუშ�?�?ბისთვის) შექმნილი�?";
$_lang['Resources yes = 1, no = 0'] = "რესურსები: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Table projekte (for project management) created'] = "ცხრილი 'projekte' (პრ�?ექტების მ�?რთვისთვის) შექმნილი�?";
$_lang['Table contacts (for external contacts) created'] = "ცხრილი 'contacts' (გ�?რე კ�?ნტ�?ქტებისთვის) შექმნილი�?";
$_lang['Table notes (for notes) created'] = "ცხრილი 'notes' (შენიშვნებისთვის) შექმნილი�?";
$_lang['Table timecard (for time sheet system) created'] = "ცხრილი 'timecard' (ტ�?ბელებისთვის) შექმნილი�?";
$_lang['Table groups (for group management) created'] = "ცხრილი 'groups' (ჯგუფების �?დმინისტრირებისთვის) შექმნილი�?";
$_lang['Table timeproj (assigning work time to projects) created'] = "ცხრილი 'timeproj' (დრ�?ის პერი�?დის მითითებ�? პრ�?ექტისთვის) შექმნილი�?";
$_lang['Table rts and rts_cat (for the help desk) created'] = "ცხრილები 'rts' დ�? 'rts_cat' (ს�?ინფ�?რმ�?ცი�?სთვის) შექმნილი�?";
$_lang['Table mail_account, mail_attach, mail_client und mail_rules (for the mail reader) created'] = "ცხრილები 'mail_account', 'mail_attach', 'mail_client' დ�? 'mail_rules' (ელ. ფ�?სტის წ�?კითხვისთვის) შექმნილი�?";
$_lang['Table logs (for user login/-out tracking) created'] = "ცხრილი 'logs' (მ�?მხმ�?რებლების გვერდზე შესვლის სტ�?ტისტიკის დ�?ს�?გრ�?ვემბლ�?დ) შექმნილი�?";
$_lang['Tables contacts_profiles und contacts_prof_rel created'] = "ცხრილი 'contacts_profiles' დ�? c'ontacts_prof_rel' შექმნილი�?";
$_lang['Project management yes = 1, no = 0'] = "პრ�?ექტების მ�?რთვ�?: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['additionally assign resources to events'] = "მ�?ვლენისთვის დ�?მ�?ტებით გ�?მ�?ყ�?ფილი რესურსები";
$_lang['Address book  = 1, nein = 0'] = "მის�?მ�?რთების წიგნი: იყ�?ს  = 1, �?რ იყ�?ს = 0";
$_lang['Mail no = 0, only send = 1, send and receive = 2'] = "ელ. ფ�?სტ�?: �?რ იყ�?ს = 0, მხ�?ლ�?დ გ�?გზ�?ვნ�? = 1, გ�?გზ�?ვნ�? დ�? მიღბ�?= 2";
$_lang['Chat yes = 1, no = 0'] = "დისკუსი�?: იყ�?ს = 1, �?რ იყ�?ს = 0";
$_lang['Name format in chat list'] = "ს�?ხელების ფ�?რმ�?ტი დისკუსიის სი�?ში";
$_lang['0: last name, 1: first name, 2: first name, last name,<br> &nbsp; &nbsp; 3: last name, first name'] = "0: გვ�?რი, 1: ს�?ხელი, 2: სეხელი, გვერი,<br> &nbsp; &nbsp; 3: გვ�?რი, ს�?ხელი";
$_lang['Timestamp for chat messages'] = "დრ�?ის მითითებ�? გ�?მ�?თქმებისთვის  დისკუსი�?ში";
$_lang['users (for authentification and address management)'] = "'მ�?მხმ�?რებლები' (�?უტენტიფიკ�?ციის დ�? მის�?მ�?რთების მ�?რთვისთვის)";
$_lang['Table termine (for events) created'] = "ცხრილი  'termine' (მ�?ვლენებისთვის) შექმნილი�?";
$_lang['The following users have been inserted successfully in the table user:<br>root - (superuser with all administrative privileges)<br>test - (chief user with restricted access)'] = "შემდეგი მ�?მხმ�?რებლები ჩ�?ცერილი�? ცხრილში 'user':<br>
'root' - (�?დმინისტრ�?ტ�?რი)<br>'test' - (მ�?მხმ�?რებელი ხელმძღვ�?ნელის 
პრივილეგიებით, შეზღუდული მიწვდ�?მის უფლებებით)";
$_lang['The group default has been created'] = "შექმნილი�? ჯგუფი 'default' (სტ�?ნდ�?რტული)";
$_lang['Please do not change anything below this line!'] = "�?რ�?ფერი �?რ შე�?სწ�?რ�?თ �?მ ხ�?ზის ქვემ�?დ!";
$_lang['Database error'] = "მ�?ნ�?ცემთ�? ბ�?ზის შეცდ�?მ�?";
$_lang['Finished'] = "დ�?სრულებული�?";
$_lang['There were errors, please have a look at the messages above'] = "შეცდ�?მები�?! წ�?იყითხეთ შეტყ�?ბინებ�?!";
$_lang['All required tables are installed and <br>the configuration file config.inc.php is rewritten<br>It would be a good idea to makea backup of this file.<br>'] = "ყველ�? ს�?ჭირ�? ცხრილი ინსტ�?ლირებული�? დ�? <br> 
კ�?ნფიგურ�?ციის 
ფ�?ილი 'config.inc.php' შესც�?რებული�?<br>ს�?სურველი�? �?მ ფ�?ილის ს�?რეზერვ�? 
კ�?პიის შექმნ�?.<br>";
$_lang['The administrator root has the password root. Please change his password here:'] = "�?დმინისტრ�?ტ�?რს'root' �?ქვს პ�?რ�?ლი 'root'. შეცვ�?ლეთ �?ქ მისი პ�?რ�?ლი:";
$_lang['The user test is now member of the group default.<br>Now you can create new groups and add new users to the group'] = "მ�?მხმ�?რებელი 'test' ჯგუფის 'default' წევრი�?.<br>ეხლ�? თქვენ შეგ
იძლი�?თ �?ხ�?ლი ჯგუფების შექმნ�? დ�? �?ხ�?ლი მ�?მხმ�?რებლების დ�?მ�?ტებ�?";
$_lang['To use PHProject with your Browser go to <b>index.php</b><br>Please test your configuration, especially the modules Mail and Files.'] = " PHProject-თ�?ნ მუშ�?�?ბისთვის ბრ�?უზერში გ�?დ�?დით ფ�?ილზე<b>index.php</b><br>
შ�?მ�?წმეთ თქვენი კ�?ნფიგურ�?ცი�?, გ�?ნს�?კუთრებით მ�?დულები 'Mail' დ�? 'Files'.";

$_lang['Alarm x minutes before the event'] = "შეტყ�?ბინებ�? მ�?ვლენ�?ზე x წუთით �?დრე";
$_lang['Additional Alarmbox'] = "დ�?მ�?ტებითი შეტყ�?ბინებ�?";
$_lang['Mail to the chief'] = "წერილი უფრ�?სთ�?ნ";
$_lang['Out/Back counts as: 1: Pause - 0: Workingtime'] = "შემ�?სვლ�?/გ�?სვლ�?: 1: პ�?უზ�? - 0: ს�?მუშ�?�? დრ�?";
$_lang['Passwords will now be encrypted ...'] = "პ�?რ�?ლები დ�?იშიფრებ�? ...";
$_lang['Filenames will now be crypted ...'] = "ფ�?ილის ს�?ხელები �?რ დ�?იშიფრებ�? ...";
$_lang['Do you want to backup your database right now? (And zip it together with the config.inc.php ...)<br>Of course I will wait!'] = "ს�?სურველი�? მ�?ნ�?ცემთ�? ბ�?ზის  დ�? ფ�?ილის config.inc.php ს�?რეზერვ�? 
კ�?პიების შექმნ�?";
$_lang['Next'] = "შემდეგი";
$_lang['Notification on new event in others calendar'] = "შეტყ�?ბინებ�? მ�?ვლენ�?ზე სხვის კ�?ლენდრებში";
$_lang['Path to sendfax'] = "გზ�? ფ�?ქსთ�?ნ";
$_lang['no fax option: leave blank'] = "ფ�?ქსი �?რ �?რის: ნუ შე�?ვსებთ";
$_lang['Please read the FAQ about the installation with postgres'] = "წ�?იყითხეთ FAQ ს�?ნ�?მ დ�?იწყებთ ინსტ�?ლ�?ცი�?ს postgres-ის გ�?მ�?ყენებით";
$_lang['Length of short names<br> (Number of letters: 3-6)'] = "შემ�?კლებული ს�?ხელების სიგრძე (3-6 სიმბ�?ლ�?)";
$_lang['If you want to install PHProjekt manually, you find<a href=http://www.phprojekt.com/files/sql_dump.tar.gz target=_blank>here</a> a mysql dump and a default config.inc.php'] = "თუ გსურთ PHProjekt-ის ინსტ�?ლ�?ცი�? თქვენით, 
<a href='http://www.phprojekt.com/files/sql_dump.tar.gz' target=_blank>�?ქ შეგიძლი�?თ ნ�?ხ�?თ</a>mysql dump დ�? სტ�?ნდ�?რტული config.inc.php";
$_lang['The server needs the privilege to write to the directories'] = "ს�?ჭირ�?�? პრიველეგი�? 'write' �?მ დირექტ�?რიისთვის";
$_lang['Header groupviews'] = "ჯგუფური დ�?თვ�?ლიერების ს�?თ�?ურები";
$_lang['name, F.'] = "ს�?ხელი";
$_lang['shortname'] = "შემ�?კლებული ს�?ხელი";
$_lang['loginname'] = "რეგისტრ�?ციის ს�?ხელი";
$_lang['Please create the file directory'] = "შექმენით კ�?ტ�?ლ�?გი  ფ�?ილებისთვის";
$_lang['default mode for forum tree: 1 - open, 0 - closed'] = "ფ�?რუმის სიის რეჟიმი: 1 - გ�?ხსნილი, 0 - დ�?ხურული ";
$_lang['Currency symbol'] = "ვ�?ლუტის სიმბ�?ლ�?";
$_lang['current'] = "მიმდინ�?რე";      
$_lang['Default size of form elements'] = "ფ�?რმების ელემენტების სტ�?ნდ�?რტული სიგრძე";
$_lang['use LDAP'] = "LDAP-ის გ�?მ�?ყენებ�?";
$_lang['Allow parallel events'] = "პ�?რ�?ლელური მ�?ვლენების დ�?შვებ�?";
$_lang['Timezone difference [h] Server - user'] = "დრ�?ის სხვ�?�?ბ�? [ს�?�?თი] სერვერი - მ�?მხმ�?რებელი";
$_lang['Timezone'] = "დრ�?ის ს�?რტყელი";
$_lang['max. hits displayed in search module'] = "ძიების მ�?დულში ნ�?ჩვენები შემ�?სვლების მ�?ქს. რ�?�?დენ�?ბ�?"; 
$_lang['Time limit for sessions'] = "სესიის მ�?ქსიმ�?ლური ხ�?ნგრძლი�?ბ�?";
$_lang['0: default mode, 1: Only for debugging mode'] = "0: ნ�?რმ�?ლური რეჟიმი, 1: ს�?ტესტ�? რეჟიმი";
$_lang['Enables mail notification on new elements'] = "შეტყ�?ბინებ�? ელ. ფ�?სტით �?ხ�?ლი ელემენტების შეს�?ხებ";
$_lang['Enables versioning for files'] = "ფ�?ილების ვერსიების შენ�?ხვ�?";
$_lang['no link to contacts in other modules'] = "სხვ�? მ�?დულებში კ�?ნტ�?ქტებთ�?ნ დ�?კ�?ვშირების გ�?რეშე";
$_lang['Highlight list records with mouseover'] = "კურს�?რის დ�?ყენებ�?ზე სიის ელემენტებზე მ�?თი ფერის შეცვლ�?'";
$_lang['Track user login/logout'] = "მ�?მხმ�?რებლების გვერდზე შემ�?სვლის, გ�?სვლის კ�?ნტრ�?ლი";
$_lang['Access for all groups'] = "მიწვდ�?მ�? ყველ�? ჯგუფისთვის";
$_lang['Option to release objects in all groups'] = "ყველ�? ჯგუფის �?ბიექტის გ�?შვებ�?";
$_lang['Default access mode: private=0, group=1'] = "სტ�?ნდ�?რტული მიწვდ�?მის რეჟიმი: პირ�?დი=0, ჯგუფის=1"; 
$_lang['Adds -f as 5. parameter to mail(), see php manual'] = "Adds '-f' as 5. mail() ფუნქციის პ�?რ�?მეტრი, იხილეთ php-ს დ�?მხმ�?რე დ�?კუმენტ�?ცი�?";
$_lang['end of line in body; e.g. \r\n (conform to RFC 2821 / 2822)'] = "წერილში სტრიქ�?ნის შეწყვეტ�?; მ�?გ. \\r\\n ";
$_lang['end of header line; e.g. \r\n (conform to RFC 2821 / 2822)'] = " ზედ�? კ�?ლ�?ნტიტულის სტრიქ�?ნის შეწყვეტ�?; მ�?გ. \\r\\n ";
$_lang['Sendmail mode: 0: use mail(); 1: use socket'] = "ელ. ფ�?სტის გ�?გზ�?ვნის მ�?დული:  mail() -ის გ�?მ�?ყენებ�?: 0; socket-ის გ�?მ�?ყენებ�?: 1";
$_lang['the real address of the SMTP mail server, you have access to (maybe localhost)'] = "SMTP სერვერის რე�?ლური მის�?მ�?რთი";
$_lang['name of the local server to identify it while HELO procedure'] = "ლ�?კ�?ლური სერვერის ს�?ხელი HELO პრ�?ცედურისთვის";
$_lang['Authentication'] = "�?უტენტიფიკ�?ცი�?";
$_lang['fill out in case of authentication via POP before SMTP'] = "შე�?ვსეთ POPდ SMTP  �?უტენტიფიკ�?ციის შემთხვევ�?ში ";
$_lang['real username for POP before SMTP'] = "რე�?ლური მ�?მხმ�?რებლის ს�?ხელი სერვისებისთვის POP,  SMTP";
$_lang['password for this pop account'] = "პ�?რ�?ლები �?მ pop ჩ�?ნ�?წერისთვი�?"; 
$_lang['the POP server'] = "POP სერვერი";
$_lang['fill out in case of SMTP authentication'] = "შე�?ვსეთ SMTP-ს �?უტენტიფიკ�?ციის შემთხვევ�?ში";
$_lang['real username for SMTP auth'] = "რე�?ლური მ�?მხმ�?რებლის ს�?ხელი SMTP-სთვის";
$_lang['password for this account'] = "პ�?რ�?ლი �?მ ჩ�?ნ�?წერისთვის";
$_lang['SMTP account data (only needed in case of socket)'] = "მ�?ნ�?ცემები SMTP-ს შეს�?ხებ  (ს�?ჭირ�?�? მხ�?ლ�?დ  socket-ის შემთხვევ�?ში)";
$_lang['No Authentication'] = "�?უტენტიფიკ�?ციის გ�?რეშე"; 
$_lang['with POP before SMTP'] = "POP, SMTP";
$_lang['SMTP auth (via socket only!)'] = "SMTP �?უტენტიფიკ�?ცი�? (მხ�?ლ�?დ socket-ის შემთხვევ�?ში!)";
$_lang['Log history of records'] = "Log history of records";
$_lang['Send'] = " Senden";
$_lang['Host-Path'] = "Host-Path";
$_lang['Installation directory'] = "Installation directory";
$_lang['0 Date assignment by chief, 1 Invitation System'] = "0 Date assignment by chief, 1 Invitation System";
$_lang['0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System'] = "0 Date assignment by chief,<br>&nbsp;&nbsp;&nbsp;&nbsp; 1 Invitation System";
$_lang['Default write access mode: private=0, group=1'] = "Default write access mode: private=0, group=1";
$_lang['Select-Option accepted available = 1, not available = 0'] = "Select-Option accepted available = 1, not available = 0";
$_lang['absolute path to host, e.g. http://myhost/'] = "absolute path to host, e.g. http://myhost/";
$_lang['installation directory below host, e.g. myInstallation/of/phprojekt5/'] = "installation directory below host, e.g. myInstallation/of/phprojekt5/";

// l.php
$_lang['Resource List'] ="რესურსების სი�?";
$_lang['Event List'] = "მ�?ვლენების სი�?";
$_lang['Calendar Views'] = "კ�?ლენდ�?რი";

$_lang['Personnel'] = "პერს�?ნ�?ლი";
$_lang['Create new event'] = "მ�?ვლენის შექმნ�?";
$_lang['Day'] = "დღე";

$_lang['Until'] = "მდე";

$_lang['Note'] = "შენიშვნ�?";
$_lang['Project'] = "პრ�?ექტი";
$_lang['Res'] = "რეს";
$_lang['Once'] = "ერთხელ";
$_lang['Daily'] = "ყ�?ველდღიურ�?დ";
$_lang['Weekly'] = "ყ�?ველკვირეულ�?დ";
$_lang['Monthly'] = "ყ�?ველთვიურ�?დ";
$_lang['Yearly'] = "ყ�?ველწლიურ�?დ";

$_lang['Create'] = "შექმნ�?";

$_lang['Begin'] = "დ�?წყებ�?";
$_lang['Out of office'] = "�?ფისიდ�?ნ";
$_lang['Back in office'] = "უკ�?ნ �?ფისში";
$_lang['End'] = "დ�?ს�?სრული";
$_lang['@work'] = "ს�?მს�?ხურში";
$_lang['We'] = "ჩვენ";
$_lang['group events'] = "ჯგუფური მ�?ვლენ�?";
$_lang['or profile'] = "�?ნ კ�?ტეგ�?რი�?";
$_lang['All Day Event'] = "მ�?ვლენ�? მთლი�?ნი დღის გ�?ნვმ�?ლ�?ბ�?ში";
$_lang['time-axis:'] = "დღის წესრიგი";
$_lang['vertical'] = "ვერტიკ�?ლურ�?დ";
$_lang['horizontal'] = "ჰ�?რიზ�?ნტ�?ლურ�?დ";
$_lang['Horz. Narrow'] = "ჰ�?რ. წვრილი";
$_lang['-interval:'] = "ინტერვ�?ლი";
$_lang['Self'] = "პირ�?დი";

$_lang['...write'] = "...ჩ�?წერ�?";

$_lang['Calendar dates'] = "Calendar dates";
$_lang['List'] = "List";
$_lang['Year'] = "Year";
$_lang['Month'] = "Month";
$_lang['Week'] = "Week";
$_lang['Substitution'] = "Substitution";
$_lang['Substitution for'] = "Substitution for";
$_lang['Extended&nbsp;selection'] = "Extended&nbsp;selection";
$_lang['New Date'] = "New date entered";
$_lang['Date changed'] = "Date changed";
$_lang['Date deleted'] = "Date deleted";

// links
$_lang['Database table'] = "Database table";
$_lang['Record set'] = "Record set";
$_lang['Resubmission at:'] = "Resubmission at:";
$_lang['Set Links'] = "Links";
$_lang['From date'] = "From date";
$_lang['Call record set'] = "Call record set";


//login.php
$_lang['Please call login.php!'] = "გ�?მ�?იძ�?ხეთ login.php!";

// m1.php
$_lang['There are other events!<br>the critical appointment is: '] = "�?რსებ�?ბს სხვ�? მ�?ვლენები!<br>მნიშვნელ�?ვ�?ნი�?: ";
$_lang['Sorry, this resource is already occupied: '] = "ეს რესურსი უკვე დ�?კ�?ვებული�?:";
$_lang[' This event does not exist.<br> <br> Please check the date and time. '] = " �?სეთი მ�?ვლენ�? �?რ �?რსებ�?ბს.<br> <br> გ�?დ�?�?მ�?წმეთ თ�?რიღი დ�? დრ�?. ";
$_lang['Please check your date and time format! '] = "შე�?მ�?წმეთ დრ�?ს დ�? თ�?რიღის ფ�?რმ�?ტი";
$_lang['Please check the date!'] = "შე�?მ�?წმეთ თ�?რიღი";
$_lang['Please check the start time! '] = "შე�?მ�?წმეთ დ�?წყების თ�?რიღი";
$_lang['Please check the end time! '] = "შე�?მ�?წმეთ დ�?სრულების თ�?რიღი";
$_lang['Please give a text or note!'] = "შეიყვ�?ნეთ ტექსტი �?ნ შენიშვნ�?";
$_lang['Please check start and end time! '] ="შე�?მ�?წმეთ დ�?წყების დ�? დ�?სრულების თ�?რიღი";
$_lang['Please check the format of the end date! '] = "შე�?მ�?წმეთ დ�?სრულების თ�?რიღის ფ�?რმ�?ტი";
$_lang['Please check the end date! '] = "შე�?მ�?წმეთ დ�?სრულების თ�?რიღი";





$_lang['Resource'] = "რესურსი";
$_lang['User'] = "მ�?მხმ�?რებელი";

$_lang['delete event'] = "მ�?ვლენის წ�?შლ�?";
$_lang['Address book'] = "მის�?მ�?რთების წიგნი";


$_lang['Short Form'] = "შემ�?კლებული ფ�?რმ�?";

$_lang['Phone'] = "ტელეფ�?ნი";
$_lang['Fax'] = "ფ�?ქსი";



$_lang['Bookmark'] = "ს�?ნიშნები";
$_lang['Description'] = "�?ღწერილ�?ბ�?";

$_lang['Entire List'] = "მთლი�?ნი სი�?";

$_lang['New event'] = "�?ხ�?ლი მ�?ვლენ�?";
$_lang['Created by'] = "შემქმნელი:";
$_lang['Red button -> delete a day event'] = "წითელი ღილ�?კი-> დღის მ�?ვლენის წ�?შლ�?";
$_lang['multiple events'] = "მრ�?ვ�?ლჯერ�?დი მ�?ვლენ�?";
$_lang['Year view'] = "მთელი წელი";
$_lang['calendar week'] = "კ�?ლენდ�?რული კვირ�?";

//m2.php
$_lang['Create &amp; Delete Events'] = "მ�?ვლენი�? შექმნ�?&amp; წ�?შლ�?";
$_lang['normal'] = "ნ�?რმ�?ლური";
$_lang['private'] = "პირ�?დი";
$_lang['public'] = "ს�?ჯ�?რ�?";
$_lang['Visibility'] = "ნ�?ხვის უფლებ�?";

//mail module
$_lang['Please select at least one (valid) address.'] = "�?ირჩიეთ მინიმუმ ერთი მის�?მ�?რთი.";
$_lang['Your mail has been sent successfully'] = "წერილი გ�?გზ�?ვნილი�?";
$_lang['Attachment'] = "ფ�?ილის მიმ�?გრებ�? -";
$_lang['Send single mails'] = "წერილების თით�?-თით�?დ გ�?გზ�?ვნ�?";
$_lang['Does not exist'] = "�?რ �?რსებ�?ბს";
$_lang['Additional number'] = "დ�?მ�?ტებითი ნ�?მერი";
$_lang['has been canceled'] = "გ�?უქმებული�?";

$_lang['marked objects'] = "მ�?ნიშნული �?ბიექტები";
$_lang['Additional address'] = "დ�?მ�?ტებითი მის�?მ�?რთი";
$_lang['in mails'] = "შემ�?სულები";
$_lang['Mail account'] = "ს�?ფ�?სტ�? ყუთი";
$_lang['Body'] = "ტექსტი";
$_lang['Sender'] = "გ�?მგზ�?ვნელი";

$_lang['Receiver'] = "მიმღები";
$_lang['Reply'] = "პ�?სუხის გ�?ცემ�?";
$_lang['Forward'] = "გ�?დ�?გზ�?ვნ�?";
$_lang['Access error for mailbox'] = "�?რ �?რის კ�?ვშირი ს�?ფ�?სტ�? ყუთთ�?ნ";
$_lang['Receive'] = "მიღებ�?";
$_lang['Write'] = "გ�?გზ�?ვნ�?";
$_lang['Accounts'] = "ჩ�?ნ�?წერები";
$_lang['Rules'] = "რ�?ლები";
$_lang['host name'] = "host name (�?ნ IP მის�?მ�?რთი)";
$_lang['Type'] = "ტიპი";
$_lang['misses'] = "გ�?მ�?ტ�?ვებული�?";
$_lang['has been created'] = "შექმნილი�?";
$_lang['has been changed'] = "შეცვლილი�?";
$_lang['is in field'] ="ველში";
$_lang['and leave on server'] = "დ�? დ�?ტ�?ვე სერვერზე";
$_lang['name of the rule'] = "წესის დ�?ს�?ხელებ�?";
$_lang['part of the word'] = "სიტყვის ნ�?წილი";
$_lang['in'] = "მიღებულები";
$_lang['sent mails'] = "გ�?გზ�?ვნილები";
$_lang['Send date'] = "გ�?გზ�?ვნის თ�?რიღი";
$_lang['Received'] ="მიღებული�?";
$_lang['to'] = "ვისთვის";
$_lang['imcoming Mails'] = "შემ�?სული წერილები";
$_lang['sent Mails'] = "გ�?სული წერილები";
$_lang['Contact Profile'] = "ს�?კ�?ნტ�?ქტ�? ინფ�?რმ�?ცი�?";
$_lang['unread'] = "წ�?უკითხ�?ვი";
$_lang['view mail list'] = "წერილების სიის ნ�?ხვ�?";
$_lang['insert db field (only for contacts)'] = "შეიყვ�?ნეთ მ�?ნ�?ცემთ�? ბ�?ზის ველი (მხ�?ლ�?დ კ�?ნტ�?ქტებისთვის)";
$_lang['Signature'] = "ხელმ�?წერ�?";

$_lang['SMS'] = "SMS";
$_lang['Single account query'] = "მ�?თხ�?ვნ�? ერთ ჩ�?ნ�?წერზე";
$_lang['Notice of receipt'] = "შეტყ�?ბინებ�? მიღებ�?ზე";
$_lang['Assign to project'] = "მიღებულების სი�?ში შეტ�?ნ�?";
$_lang['Assign to contact'] = "გ�?გზ�?ვნ�?"; 
$_lang['Assign to contact according to address'] = "Assign to contact according to address";
$_lang['Include account for default receipt'] = "Include account for default receipt";
$_lang['Your token has already been used.<br>If it wasnt you, who used the token please contact your administrator.'] = "Your token has already been used.<br>If it wasn't you, who used the token please contact your administrator";
$_lang['Your token has already been expired.'] = "Your token has already been expired";
$_lang['Unconfirmed Events'] = "Unconfirmed Events";
$_lang['Visibility presetting when creating an event'] = "Voreinstellung der Sichtbarkeit beim Anlegen eines Termins";
$_lang['Subject'] = "Subject";
$_lang['Content'] = "Inhalt";
$_lang['answer all'] = "answer to all";
$_lang['Create new message'] = "Create new message";
$_lang['Attachments'] = "Attachments";
$_lang['Recipients'] = "Recipients";
$_lang['file away message'] = "file away message";
$_lang['Message from:'] = "Message from:";

//notes.php
$_lang['Mail note to'] = "წერილ�?ბითი შეტყ�?ბინებ�? ";
$_lang['added'] = "დ�?მ�?ტებული�?";
$_lang['changed'] = "შეცვლილი�?";

// o.php
$_lang['Calendar'] ="კ�?ლენდ�?რი";
$_lang['Contacts'] = "კ�?ნტ�?ქტები";


$_lang['Files'] = "ფ�?ილები";



$_lang['Options'] = "პ�?რ�?მეტრები";
$_lang['Timecard'] = "ტ�?ბელი";

$_lang['Helpdesk'] = "ს�?ინფ�?რმ�?ცი�?";

$_lang['Info'] = "ინფ�?";
$_lang['Todo'] =  "გეგმები";
$_lang['News'] = "სი�?ხლეები";
$_lang['Other'] = "სხვ�?";
$_lang['Settings'] = "�?ნ�?წყ�?ბი";
$_lang['Summary'] = "მთ�?ვ�?რი";

// options.php
$_lang['Description:'] = "�?ღწერილ�?ბ�?:";
$_lang['Comment:'] = "კ�?მენტ�?რი:";
$_lang['Insert a valid Internet address! '] = "შეიყვ�?ნეთ ინტერნეტ-მის�?მ�?რთი სწ�?რედ!";
$_lang['Please specify a description!'] = "შეიყვ�?ნეთ �?ღწერილ�?ბ�?";
$_lang['This address already exists with a different description'] = "ეს მის�?მ�?რთი სხვ�? �?ღწერილ�?ბით უკვე �?რსებ�?ბს";
$_lang[' already exists. '] = " უკვე �?რსებ�?ბს.";
$_lang['is taken to the bookmark list.'] = " შეტ�?ნილი�? ს�?ნიშნების სი�?ში.";
$_lang[' is changed.'] = " შეცვლილი�?.";
$_lang[' is deleted.'] =  " წ�?შლილი�?.";
$_lang['Please specify a description! '] = "შეიყვ�?ნეთ �?ღწერილ�?ბ�?!";
$_lang['Please select at least one name! '] = "�?ირჩიეთ მინიმუმ ერთი ს�?ხელი! ";
$_lang[' is created as a profile.<br>'] = " შექმნილი�? რ�?გ�?რც კ�?ტეგ�?რი�?.<br>";
$_lang['is changed.<br>'] = "შეცვლილი�?.<br>";
$_lang['The profile has been deleted.'] = "კ�?ტეგ�?რი�? წ�?შლილი�?.";
$_lang['Please specify the question for the poll! '] = "შეიყვ�?ნეთ კენჭისყრის შეკითხვ�?! ";
$_lang['You should give at least one answer! '] = "უნდ�? გ�?სცეთ მინიმუმ ერთი პ�?სუხი! ";
$_lang['Your call for votes is now active. '] = "კენჭისყრ�? �?ქტიური�?. ";
$_lang['<h2>Bookmarks</h2>In this section you can create, modify or delete bookmarks:'] = "<h2>ს�?ნიშნეები</h2>�?მ ნ�?წილში შეგიძლი�?თ შექმნ�?თ, შეცვშეცვ�?ლ�?თ �?ნ წ�?შ�?ლ�?თ ს�?ნიშნეები:";
$_lang['Create'] = "შექმნ�?";


$_lang['<h2>Profiles</h2>In this section you can create, modify or delete profiles:'] = "<h2>კ�?ტეგ�?რიები</h2>�?მ ნ�?წილში შეგიძლი�?თ შექმნ�?თ, შეცვ�?ლ�?თ �?ნ წ�?შ�?ლ�?თ კ�?ტეგ�?რიები:";
$_lang['<h2>Voting Formula</h2>'] = "<h2>კენჭისყრის ფ�?რმულ�?</h2>";
$_lang['In this section you can create a call for votes.'] = "�?მ სექცი�?ში წინ�?დ�?დების შეტ�?ნ�? წეგიძლი�?თ.";
$_lang['Question:'] = "შეკითხვ�?:";
$_lang['just one <b>Alternative</b> or'] = "მხ�?ლ�?დ ერთი <b>�?ლტერნ�?ტივ�?</b> �?ნ";
$_lang['several to choose?'] = "რ�?მ�?დენიმე?";

$_lang['Participants:'] = "მ�?ნ�?წილეები:";

$_lang['<h3>Password Change</h3> In this section you can choose a new random generated password.'] = "<h3>პ�?რ�?ლის შეცვლ�?</h3> �?მ ნ�?წილში შეგიძლი�?თ შე�?რჩი�?თ �?ხ�?ლი შემთხვევით�?დ გენერირებული პ�?რ�?ლი.";
$_lang['Old Password'] = "ძველი პ�?რ�?ლი";
$_lang['Generate a new password'] = "�?ხ�?ლი პ�?რ�?ლის გენერირებ�?";
$_lang['Save password'] = "პ�?რ�?ლის შენ�?ხვ�?";
$_lang['Your new password has been stored'] = "თქვენი �?ხ�?ლი პ�?რ�?ლი შენ�?ხული�?";
$_lang['Wrong password'] ="�?რ�?სწ�?რი პ�?რ�?ლი";
$_lang['Delete poll'] = "ხმის წ�?შლ�?";
$_lang['<h4>Delete forum threads</h4> Here you can delete your own threads<br>Only threads without a comment will appear.'] = "<h4>ფ�?რუმის თემების წ�?შლ�?</h4> �?ქ შეგიძლი�?თ წ�?შ�?ლ�?თ 
თქვენი თემები.";

$_lang['Old password'] ="ძველი პ�?რ�?ლი";
$_lang['New Password'] = "�?ხ�?ლი პ�?რ�?ლი";
$_lang['Retype new password'] = "პ�?რ�?ლის გ�?მე�?რებ�?";
$_lang['The new password must have 5 letters at least'] = "პ�?რ�?ლი - �?რ�?ნ�?კლებ 5 სიმბ�?ლ�?";
$_lang['You didnt repeat the new password correctly'] = "�?რი �?ხ�?ლი პ�?რ�?ლი ერთნ�?ირი უნდ�? იყ�?ს";

$_lang['Show bookings'] = "რეზერვის ნ�?ხვ�?";
$_lang['Valid characters'] = "დ�?შვებული სიმბ�?ლ�?ები";
$_lang['Suggestion'] = "წინ�?დ�?დებ�?";
$_lang['Put the word AND between several phrases'] = "ფრ�?ზების დ�?ს�?კ�?ვშირებლ�?დ გ�?მ�?იყენეთ 'AND'"; // translators: please leave the word AND as it is
$_lang['Write access for calendar'] = "კ�?ლენდრის შეცვლის უფლებ�?";
$_lang['Write access for other users to your calendar'] = "თქვენი კ�?ლენდრის შეცვლის უფკებ�? სხვ�? მ�?მხმ�?რებლების მიერ";
$_lang['User with chief status still have write access'] = "ხელმძღვ�?ნელს მ�?ინც შენ�?რჩუნებული �?წვს შეცვლის უფლებ�?";

// projects
$_lang['Project Listing'] = "პრ�?ექტები";
$_lang['Project Name'] = "პრ�?ექტის დ�?ს�?ხელებ�?";


$_lang['o_files'] = "Files";
$_lang['o_notes'] = "Notes";
$_lang['o_projects'] = "Projects";
$_lang['o_todo'] = "Todo";
$_lang['Copyright']="Copyright";
$_lang['Links'] = "Links";
$_lang['New profile'] = "Neuer Verteiler";
$_lang['In this section you can choose a new random generated password.'] = "In this section you can choose a new random generated password.";
$_lang['timescale'] = "timescale";
$_lang['Manual Scaling'] = "Manual scaling";
$_lang['column view'] = "column view";
$_lang['display format'] = "display format";
$_lang['for chart only'] = "For chart only:";
$_lang['scaling:'] = "scling:";
$_lang['colours:'] = "colours";
$_lang['display project colours'] = "display project colours";
$_lang['weekly'] = "weekly";
$_lang['monthly'] = "monthly";
$_lang['annually'] = "annually";
$_lang['automatic'] = "automatic";
$_lang['New project'] = "New project";
$_lang['Basis data'] = "Basis data";
$_lang['Categorization'] = "Categorization";
$_lang['Real End'] = "ფ�?ქტიური დ�?ს�?სრული";
$_lang['Participants'] ="მ�?ნ�?წილეები";
$_lang['Priority'] = "პრი�?რიტეტი";
$_lang['Status'] = "სტ�?ტუსი";
$_lang['Last status change'] = "სტ�?ტუსის ბ�?ლ�? ცვლილებ�?";
$_lang['Leader'] = "ლიდერი";
$_lang['Statistics'] = "სტ�?ტისტიკ�?";
$_lang['My Statistic'] = "ჩემი სტ�?ტისტიკ�?";

$_lang['Person'] = "მ�?ნ�?წილე";
$_lang['Hours'] = "ს�?�?თი";
$_lang['Project summary'] = "პრ�?ექტის რეზიუმე";
$_lang[' Choose a combination Project/Person'] =" �?ირჩიეთ პრ�?ექტი/მ�?ნ�?წილეს კ�?მბინ�?ცი�?";
$_lang['(multiple select with the Ctrl/Cmd-key)'] =  "(რ�?მ�?დენიმეს �?რთდრ�?ულ�?დ �?რჩევის�?თვის დ�?�?ჭირეთ 'Ctrl')";

$_lang['Persons'] = "მ�?ნ�?წილეები";
$_lang['Begin:'] = "დ�?ს�?წყისი:";
$_lang['End:'] = "დ�?ს�?სრული:";
$_lang['All'] = "ყველ�?";
$_lang['Work time booked on'] = "ს�?მუშ�?�? დრ�? დ�?რეზერვებული�?";
$_lang['Sub-Project of'] = "ქვეპრ�?ექტი";
$_lang['Aim'] = "მიზ�?ნი";
$_lang['Contact'] = "კ�?ნტ�?ქტი";
$_lang['Hourly rate'] = "ს�?�?თ�?ბრივი გ�?დ�?ს�?ხ�?დი";
$_lang['Calculated budget'] ="გ�?მ�?ყ�?ფილი ბიუჯეტი";
$_lang['New Sub-Project'] = "�?ხ�?ლი ქვეპრ�?ექტი";
$_lang['Booked To Date'] = "დღეის�?თვის რეზერვში";
$_lang['Budget'] = "ბიუჯეტი";
$_lang['Detailed list'] ="დ�?წვრილებითი სი�?";
$_lang['Gantt'] = "Gantt";
$_lang['offered'] = "შემ�?თ�?ვ�?ზებული";
$_lang['ordered'] = "შეკვეთილი";
$_lang['Working'] = "მიმდინ�?რე";
$_lang['ended'] = "დ�?სრულებული";
$_lang['stopped'] = "შეჩერებული";
$_lang['Re-Opened'] = "კვლ�?ვ გ�?ხსნილი";
$_lang['waiting'] = "მ�?ლ�?დინში";
$_lang['Only main projects'] = "მხ�?ლ�?დ ძირით�?დი პრ�?ექტები";
$_lang['Only this project'] = "მხ�?ლ�?დ ეს პრ�?ექტი";
$_lang['Begin > End'] = "დ�?ს�?წყისი > დ�?ს�?სრული";
$_lang['ISO-Format: yyyy-mm-dd'] = "ISO-ფ�?რმ�?ტი: yyyy-mm-dd";
$_lang['The timespan of this project must be within the timespan of the parent project. Please adjust'] = "�?მ პრ�?ექტის გ�?ნხ�?რციელების პერი�?დი უნდ�? იყ�?ს მშ�?ბლიური პრ�?ექტის პერი�?დის ფ�?რგლებში. შე�?სწ�?რეთ";
$_lang['Please choose at least one person'] = "�?ირჩიეთ მინიმუმ ერთი მ�?ნ�?წილე";
$_lang['Please choose at least one project'] = "�?ირჩიეთ მინიმუმ ერთი პრ�?ექტი";
$_lang['Dependency'] = "დ�?მ�?კიდებულებ�?";
$_lang['Previous'] = "წინ�?";

$_lang['cannot start before the end of project'] = "დ�?წყებ�? შეუძლებელი�? პრ�?ექტის დ�?სრულებ�?მდე";
$_lang['cannot start before the start of project'] = "დ�?წყებ�? შეუძლებელი�? პრ�?ექტის დ�?წყებ�?მდე";
$_lang['cannot end before the start of project'] = "დ�?სრულებ�? შეუძლებელი�? პრ�?ექტის დ�?წყებ�?მდე";
$_lang['cannot end before the end of project'] = "დ�?სრულებ�? შეუძლებელი�? პრ�?ექტის დ�?სრულებ�?მდე";
$_lang['Warning, violation of dependency'] = "ყურ�?დღებ�?, დ�?მ�?კიდებულების დ�?რღვევ�?!";
$_lang['Container'] = "კ�?ნტეინერი";
$_lang['External project'] = "გ�?რე პრ�?ექტი";
$_lang['Automatic scaling'] = "�?ვტ�?მ�?ტური მ�?სშტ�?ბირებ�?";
$_lang['Legend'] = "პირ�?ბითი ნიშნები";
$_lang['No value'] = "მნიშვნელ�?ბ�? �?რ �?რის";
$_lang['Copy project branch'] = "პრ�?ექტის გ�?ნშტ�?ების კ�?პირებ�?";
$_lang['Copy this element<br> (and all elements below)'] = "�?მ ელემენტის გ�?დ�?წერ�?<br> (ქვემ�? ელემენტების ჩ�?თვლით ერთ�?დ)";
$_lang['And put it below this element'] = "ელემენტის ქვემ�?თ გ�?ნთ�?ვსებ�?";
$_lang['Edit timeframe of a project branch'] = "პრ�?ექტის გ�?ნშტ�?ებისთვის დრ�?ის პერი�?დის რედ�?ქტირებ�?"; 

$_lang['of this element<br> (and all elements below)'] = "�?მ ელემენტის<br> (დ�? ყველ�? ქვემ�?თ მ�?ცემული ელემენტის)";  
$_lang['by'] = "რ�?მდენი ხნით";
$_lang['Probability'] = "მ�?ს�?ლ�?დნელ�?ბ�?";
$_lang['Please delete all subelements first'] = "Please delete all subprojects first";
$_lang['Assignment'] ="Assignment";
$_lang['display'] = "Display";
$_lang['Normal'] = "Normal";
$_lang['sort by date'] = "Sort by date";
$_lang['sort by'] = "Sort by";
$_lang['Calculated budget has a wrong format'] = "Calculated budget has a wrong format";
$_lang['Hourly rate has a wrong format'] = "Hourly rate has a wrong format";

// r.php
$_lang['please check the status!'] = "შე�?მ�?წმეთ სტ�?ტუსი!";
$_lang['Todo List: '] = "გეგმების სი�?: ";
$_lang['New Remark: '] = "�?ხ�?ლი შენიშვნ�?: ";
$_lang['Delete Remark '] = "შენიშვნის წ�?შლ�? ";
$_lang['Keyword Search'] = "ძიებ�?";
$_lang['Events'] = "მ�?ვლენები";
$_lang['the forum'] = "ფ�?რუმი";
$_lang['the files'] = "ფ�?ილები";
$_lang['Addresses'] = "მის�?მ�?რთები";
$_lang['Extended'] = "გ�?ფ�?რთ�?ებული";
$_lang['all modules'] = "ყველ�? მ�?დული";
$_lang['Bookmarks:'] = "ს�?ნიშნები:";
$_lang['List'] = "სი�?";
$_lang['Projects:'] = "პრ�?ექტები:";

$_lang['Deadline'] = "ბ�?ლ�? ვ�?დ�?";

$_lang['Polls:'] = "კენჭისყრ�?:";

$_lang['Poll created on the '] = "კენჭისყრ�? შექმნილი�? ";


// reminder.php
$_lang['Starts in'] = "იწყებ�?";
$_lang['minutes'] = "წუთი";
$_lang['No events yet today'] = "დღეისთვის მ�?ვლენები �?რ �?რის";
$_lang['New mail arrived'] = "მიღებული�? �?ხ�?ლი წერილი";

//ress.php

$_lang['List of Resources'] =  "რესურსების სი�?";
$_lang['Name of Resource'] = "რესურსის დ�?ს�?ხელებ�?";
$_lang['Comments'] =  "კ�?მენტ�?რები";


// roles
$_lang['Roles'] = "რ�?ლები";
$_lang['No access'] = "მიწვდ�?მ�? �?კრძ�?ლული�?";
$_lang['Read access'] = "მიწვდ�?მ�? წ�?კითხვის უფლებით";

$_lang['Role'] = "რ�?ლი";

// helpdesk - rts
$_lang['Request'] = "მ�?თხ�?ვნ�?";

$_lang['pending requests'] = "ითხ�?ვს გ�?დ�?წყვეტილებ�?ს";
$_lang['show queue'] = "რიგის ნ�?ხვ�?";
$_lang['Search the knowledge database'] = "ც�?დნის მ�?ნ�?ცემთ�? ბ�?ზ�?ში ძიებ�?";
$_lang['Keyword'] = "ს�?კვ�?ნძ�? სიტყვები";
$_lang['show results'] = "შედეგების ნ�?ხვ�?";
$_lang['request form'] = "მ�?თხ�?ვნის ფ�?რმ�?";
$_lang['Enter your keyword'] = "ჩ�?წერეთ ს�?კვ�?ნძ�? სიტყვ�?";
$_lang['Enter your email'] = "შეიყვ�?ნეთ ელ. ფ�?სტის მის�?მ�?რთი";
$_lang['Give your request a name'] = "მიუთითეთ თქვენი მ�?თხ�?ვნის ს�?თ�?ური";
$_lang['Describe your request'] = "ჩ�?მ�?�?ყ�?ლიბეთ თქვენი თხ�?ვნ�?";

$_lang['Due date'] = "�?მ თ�?რიღისთვის";
$_lang['Days'] = "დღე";
$_lang['Sorry, you are not in the list'] = "უკ�?ცრ�?ვ�?დ, თქვენ �?რ ხ�?რთ სი�?ში";
$_lang['Your request Nr. is'] = "თქვენი მ�?ღხ�?ვნის No. �?რის ";
$_lang['Customer'] = "კლიენტი";


$_lang['Search'] = "ძიებ�?";
$_lang['at'] = "ს�?დ";
$_lang['all fields'] = "ყველ�? ველი";


$_lang['Solution'] = "გ�?დ�?წყვეტილებ�?";
$_lang['AND'] = "დ�?";

$_lang['pending'] = "მ�?ლ�?დინში";
$_lang['stalled'] = "შეჩერებული";
$_lang['moved'] = "გ�?დ�?�?დგილებული�?";
$_lang['solved'] = "გ�?დ�?წყვეტილი";
$_lang['Submit'] = "შეყვ�?ნ�?";
$_lang['Ass.'] = "ვის";
$_lang['Pri.'] = "პრი�?რ.";
$_lang['access'] = "მიწვდ�?მ�? წ�?კითხვის უფლებით";
$_lang['Assigned'] = "დ�?ნიშვნ�?";

$_lang['update'] = "გ�?ნ�?ხლებ�?";
$_lang['remark'] = "შენიშვნ�?";
$_lang['solve'] = "გ�?დ�?წყვეტილი";
$_lang['stall'] = "შეჩერებული";
$_lang['cancel'] = "გ�?უქმებ�?";
$_lang['Move to request'] = "გ�?დ�?სვლ�? მ�?თხ�?ვნ�?სთ�?ნ";
$_lang['Dear customer, please refer to the number given above by contacting us.Will will perform your request as soon as possible.'] = "ჩვენთ�?ნ მიმ�?რთვის�?ს მიუთითეთ ზემ�?დ მ�?ცემული ნ�?მერი, 
ჩვენ გ�?ნვიხილ�?ვთ თქვენს მ�?თხ�?ვნ�?ს რ�?ც შეიძლებ�? მ�?ლე.";
$_lang['Your request has been added into the request queue.<br>You will receive a confirmation email in some moments.'] = "თქვენი მ�?თხ�?ვნ�? შეტ�?ნილი�? რიგში.<br>რ�?მ�?დენიმე წუთში 
თქვენ მიიღებთ დ�?დ�?სტურებ�?ს ელ. ფ�?სტით.";
$_lang['n/a'] = "�?რ �?რის მ�?ცემული";
$_lang['internal'] = "შიდ�?";

$_lang['has reassigned the following request'] = "შეცვ�?ლ�? მ�?თხ�?ვნის �?დრეს�?ტი";
$_lang['New request'] = "�?ხ�?ლი მ�?თხ�?ვნ�?";
$_lang['Assign work time'] = "დ�?ნიშნეთ ს�?მუშ�?�? დრ�?";
$_lang['Assigned to:'] = "�?ნიშნული�?:";

$_lang['Your solution was mailed to the customer and taken into the database.'] = "თქვენი გ�?დ�?წყვეტილებ�? გ�?გზ�?ვნილი�? კლიენტთ�?ნ დ�? შეტ�?ნილი�? მ�?ნ�?ცემთ�? ბ�?ზ�?ში.";
$_lang['Answer to your request Nr.'] = "პ�?სუხი თქვენს მ�?თხ�?ვნ�?ზე: Nr.";
$_lang['Fetch new request by mail'] = "�?ხ�?ლი მ�?თხ�?ვნების მიღებ�? ფ�?სტით";
$_lang['Your request was solved by'] = "თქვენი პრ�?ბლემ�? გ�?დ�?წყვეტილი�?";

$_lang['Your solution was mailed to the customer and taken into the database'] = "თხვენი გ�?დ�?წყვეტილებ�? შეყვ�?ნილი�? მ�?ნ�?ცემთ�? ბ�?ზ�?ში დ�? გ�?გზ�?ვნილი�? მ�?მხმ�?რებელთ�?ნ";
$_lang['Search term'] = "Search term";
$_lang['Search area'] = "Search area";
$_lang['Extended search'] = "Extended search";
$_lang['knowledge database'] = "knowledge database";
$_lang['Cancel'] = "Cancel";
$_lang['New ticket'] = "New ticket";
$_lang['Ticket status'] ="Ticket status";

// please adjust this states as you want -> add/remove states in helpdesk.php
$_lang['unconfirmed'] = 'unconfirmed';
$_lang['new'] = 'new';
$_lang['assigned'] = 'assigned';
$_lang['reopened'] = 'reopened';
$_lang['resolved'] = 'resolved';
$_lang['verified'] = 'verified';

// settings.php
$_lang['The settings have been modified'] = "პ�?რ�?მეტრები შეცვლილი�?";
$_lang['Skin'] = "დიზ�?ინი";
$_lang['First module view on startup'] = "პირველი მ�?დული სისტემ�?ში შესვლის�?ს";
$_lang['none'] = "�?რცერთი";
$_lang['Check for mail'] = "ფ�?სტის შემ�?წმებ�?";
$_lang['Additional alert box'] = "დ�?მ�?ტებითი გ�?მ�?ფრთხილებელი შტყ�?ბინებ�?";
$_lang['Horizontal screen resolution <br>(i.e. 1024, 800)'] = "ეკრ�?ნის ჰ�?რიზ�?ნტ�?ლური გ�?რჩევ�?დ�?ბ�? <br>(მ�?გ. 1024, 800)";
$_lang['Chat Entry'] = "ჩ�?ნ�?წერი დისკუსი�?ში";
$_lang['single line'] = "ც�?ლი ხ�?ზი";
$_lang['multi lines'] = "რ�?მ�?დენიმე ხ�?ზი";
$_lang['Chat Direction'] = "დისკუსიის მიმ�?რთულებ�?";
$_lang['Newest messages on top'] = "უ�?ხლეში შეტყ�?ბინებ�? სიის თ�?ვში";
$_lang['Newest messages at bottom'] = "უ�?ხლეში შეტყ�?ბინებ�? სიის ბ�?ლ�?ში";
$_lang['File Downloads'] = "ფ�?ილების გ�?დმ�?წერ�?";

$_lang['Inline'] = "Inline";
$_lang['Lock file'] = "Lock file";
$_lang['Unlock file'] = "nlock file";
$_lang['New file here'] = "New file here";
$_lang['New directory here'] = "New directory here";
$_lang['Position of form'] = "Position of form";
$_lang['On a separate page'] = "On a separate page";
$_lang['Below the list'] = "Below the list";
$_lang['Treeview mode on module startup'] = "Treeview mode on module startup";
$_lang['Elements per page on module startup'] = "Elements per page on module startup";
$_lang['General Settings'] = "General Settings";
$_lang['First view on module startup'] = "First view on module startup";
$_lang['Left frame width [px]'] = "Left frame width [px]";
$_lang['Timestep Daywiew [min]'] = "Timestep Dayview [min]";
$_lang['Timestep Weekwiew [min]'] = "Timestep Weekview [min]";
$_lang['px per char for event text<br>(not exact in case of proportional font)'] = "px per char for event text<br>(not exact in case of proportional font)";
$_lang['Text length of events will be cut'] = "Text length of events will be cut";
$_lang['Standard View'] = "Standard View";
$_lang['Standard View 1'] = "Standard View 1";
$_lang['Standard View 2'] = "Standard View 2";
$_lang['Own Schedule'] = "Own Schedule";
$_lang['Group Schedule'] = "Group Schedule";
$_lang['Group - Create Event'] = "Group - Create Event";
$_lang['Group, only representation'] = "Group, only representation";
$_lang['Holiday file'] = "Holiday file";

// summary
$_lang['Todays Events'] = "დღეის მ�?ვლენები";
$_lang['New files'] = "�?ხ�?ლი ფ�?ილები";
$_lang['New notes'] = "�?ხ�?ლი შენიშვნები";
$_lang['New Polls'] = "კენჭისყრის �?ხ�?ლი მ�?ნ�?ცემები";
$_lang['Current projects'] = "მიმდინ�?რე პრ�?ექტები";
$_lang['Help Desk Requests'] = "მ�?თხ�?ვნები ს�?ინფ�?რმ�?ცი�?დ�?ნ";
$_lang['Current todos'] = "მიმდინ�?რე გეგმები";
$_lang['New forum postings'] = "�?ხ�?ლი ინფ�?რმ�?ცი�? ფ�?რუმზე";
$_lang['New Mails'] = "�?ხ�?ლი ფ�?სტ�?";

//timecard

$_lang['Theres an error in your time sheet: '] = "ტ�?ბელში შეცდ�?მ�?�?: ";




$_lang['Consistency check'] = "მიმდინ�?რე�?ბის შემ�?წმებ�?";
$_lang['Please enter the end afterwards at the'] = "შიყვ�?ნეთ დ�?სრულების დრ�?";
$_lang['insert'] = "შეტ�?ნ�?";
$_lang['Enter records afterwards'] = "გ�?სული თ�?რიღით შეყვ�?ნ�?";
$_lang['Please fill in only emtpy records'] = "შე�?ვსეთ მხ�?ლ�?დ ც�?რიელი ჩ�?ნ�?წერები";

$_lang['Insert a period, all records in this period will be assigned to this project'] = "შეიყვ�?ნეთ პერი�?დი, �?მ პერი�?დის ყველ�? მ�?ვლენ�? მიბმული იქნებ�? პრ�?ექტთ�?ნ";
$_lang['There is no record on this day'] = "�?მ დღეზე ჩ�?ნ�?წერი �?რ �?რის";
$_lang['This field is not empty. Please ask the administrator'] = "ველი �?რ �?რის ც�?რიელი. მიმ�?რთეთ �?დმინისტრ�?ტ�?რს.";
$_lang['There is no open record with a begin time on this day!'] = "�?მ დღეს �?რ �?რის მ�?ვლენის დ�?ს�?წტისის ჩ�?ნ�?წერი!";
$_lang['Please close the open record on this day first!'] = "ჯერ დ�?ხურეთ �?მ დღის დ�?წყებული ჩ�?ნ�?წერი!";
$_lang['Please check the given time'] = "გ�?დ�?�?მ�?წმეთ მ�?ცემული დრ�?";
$_lang['Assigning projects'] = "დ�?ნიშნული პრ�?ექტები";
$_lang['Select a day'] = "�?ირჩიეთ დღე";
$_lang['Copy to the boss'] = "კ�?პი�? უფრ�?სს";
$_lang['Change in the timecard'] = "ტ�?ბელის შეცვლ�?";
$_lang['Sum for'] = "ჯ�?მი";

$_lang['Unassigned time'] = "დრ�? დ�?უნიშნ�?ვი�?";
$_lang['delete record of this day'] = "�?მ დღის ჩ�?ნ�?წერების წ�?შლ�?";
$_lang['Bookings'] = "რეზერვი";

$_lang['insert additional working time'] = "insert additional working time";
$_lang['Project assignment']= "Project assignment";
$_lang['Working time stop watch']= "Working time stop watch";
$_lang['stop watches']= "stop watches";
$_lang['Project stop watch']= "Project stop watch";
$_lang['Overview my working time']= "Overview my working time";
$_lang['GO']= "GO";
$_lang['Day view']= "Day view";
$_lang['Project view']= "Project view";
$_lang['Weekday']= "Weekday";
$_lang['Start']= "Start";
$_lang['Net time']= "Net time";
$_lang['Project bookings']= "Project bookings";
$_lang['save+close']= "save+close";
$_lang['Working times']= "Working times";
$_lang['Working times start']= "Working times start";
$_lang['Working times stop']= "Working times stop";
$_lang['Project booking start']= "Project booking start";
$_lang['Project booking stop']= "Project booking stop";
$_lang['choose day']= "choose day";
$_lang['choose month']= "choose month";
$_lang['1 day back']= "1 day back";
$_lang['1 day forward']= "1 day forward";
$_lang['Sum working time']= "Sum working time";
$_lang['Time: h / m']= "Time: h / m";
$_lang['activate project stop watch']= "activate project stop watch";
$_lang['activate']= "activate";
$_lang['project choice']= "project choice";
$_lang['stop stop watch']= "stop stop watch";
$_lang['still to allocate:']= "still to allocate:";
$_lang['You are not allowed to delete entries from timecard. Please contact your administrator']= "You are not allowed to delete entries from timecard. Please contact your administrator";
$_lang['You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot delete entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.']= "You cannot delete bookings at this date. Since there have been %s days. You just can edit bookings of entries not older than %s days.";
$_lang['You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.']= "You cannot add entries at this date. Since there have been %s days. You just can edit entries not older than %s days.";
$_lang['You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.']= "You cannot add  bookings at this date. Since there have been %s days. You just can add bookings for entries not older than %s days.";
$_lang['activate+close']="activate+close";

// todos
$_lang['accepted'] = "მიღებული�?";
$_lang['rejected'] = "�?კრძ�?ლული�?";
$_lang['own'] = "პირ�?დი";
$_lang['progress'] = "პრ�?გრესი";
$_lang['delegated to'] = "ვისთვის გ�?ნკუთვნილი�?";
$_lang['Assigned from'] = "ვის მიერ დ�?ნიშნული";
$_lang['done'] = "მზ�?დ �?რი";
$_lang['Not yet assigned'] = "ჯერ �?რ �?რის დ�?ნიშნული";
$_lang['Undertake'] = "ს�?კუთ�?რ თ�?ვზე �?ღებ�?";
$_lang['New todo'] = "�?ხ�?ლი გეგმ�?"; 
$_lang['Notify recipient'] = "მიმღბის შეტყ�?ბინებ�?";

// votum.php
$_lang['results of the vote: '] = "კენჭისყრის შედეგები: ";
$_lang['Poll Question: '] = "კ�?ნჩისყრის შეკითხვ�?: ";
$_lang['several answers possible'] = "შეს�?ძლ�?�? რ�?მ�?დენიმე პ�?სუხის გ�?ცემ�?";
$_lang['Alternative '] = "�?ლტერნ�?ტიული ";
$_lang['no vote: '] = "ყველ�?ს წინ�?�?ღმდეგ";
$_lang['of'] = "";
$_lang['participants have voted in this poll'] = "მ�?მხმ�?რებელმ�? მიიღ�? მ�?ნ�?წილე�?ბ�?";
$_lang['Current Open Polls'] = "მიმდინ�?რე კენჭისყრ�?";
$_lang['Results of Polls'] = "ყველ�? კენჭისყრის შედეგი";
$_lang['New survey'] ="New survey";
$_lang['Alternatives'] ="Alternatives";
$_lang['currently no open polls'] = "Currently there are no open polls";

// export_page.php
$_lang['export_timecard']       = "Export Timecard";
$_lang['export_timecard_admin'] = "Export Timecard";
$_lang['export_users']          = "Export users of this group";
$_lang['export_contacts']       = "Export contacts";
$_lang['export_projects']       = "Export projectdata";
$_lang['export_bookmarks']      = "Export bookmarks";
$_lang['export_timeproj']       = "Export time-to-project data";
$_lang['export_project_stat']   = "Export projectstats";
$_lang['export_todo']           = "Export todos";
$_lang['export_notes']          = "Export notes";
$_lang['export_calendar']       = "Export all calendarevents";
$_lang['export_calendar_detail']= "Export one calendarevent";
$_lang['submit'] = "submit";
$_lang['Address'] = "Address";
$_lang['Next Project'] = "Next Project";
$_lang['Dependend projects'] = "Dependend projects";
$_lang['db_type'] = "Database type";
$_lang['Log in, please'] = "Log in, please";
$_lang['Recipient'] = "Recipient";
$_lang['untreated'] = "untreated";
$_lang['Select participants'] = "Select participants";
$_lang['Participation'] = "Participation";
$_lang['not yet decided'] = "not yet decided";
$_lang['accept'] = "accept";
$_lang['reject'] = "reject";
$_lang['Substitute for'] = "Substitute for";
$_lang['Calendar user'] = "Kalenderbenutzer";
$_lang['Refresh'] = "Refresh";
$_lang['Event'] = "Event";
$_lang['Upload file size is too big'] = "Upload file size is too big";
$_lang['Upload has been interrupted'] = "Upload has been interrupted";
$_lang['view'] = "view";
$_lang['found elements'] = "found elements";
$_lang['chosen elements'] = "chosen elements";
$_lang['too many hits'] = "The result is bigger than we're able to display.";
$_lang['please extend filter'] = "Please extend your filters.";
$_lang['Edit profile'] = "Edit profile";
$_lang['add profile'] = "add profile";
$_lang['Add profile'] = "Add profile";
$_lang['Added profile'] = "Added profile(s).";
$_lang['No profile found'] = "No profile found.";
$_lang['add project participants'] = "add project participants";
$_lang['Added project participants'] = "Added project participants.";
$_lang['add group of participants'] = "add group of participants";
$_lang['Added group of participants'] = "Added group of participants.";
$_lang['add user'] = "add user";
$_lang['Added users'] = "Added user(s).";
$_lang['Selection'] = "Selection";
$_lang['selector'] = "selector";
$_lang['Send email notification']= "Send&nbsp;email&nbsp;notification";
$_lang['Member selection'] = "Member&nbsp;selection";
$_lang['Collision check'] = "Collision check";
$_lang['Collision'] = "Collision";
$_lang['Users, who can represent me'] = "Users, who can represent me";
$_lang['Users, who can see my private events'] = "Users, who can see<br />my private events";
$_lang['Users, who can read my normal events'] = "Users, who can read<br />my normal events";
$_lang['quickadd'] = "Quickadd";
$_lang['set filter'] = "Set filter";
$_lang['Select date'] = "Select date";
$_lang['Next serial events'] = "Next serial events";
$_lang['All day event'] = "All day event";
$_lang['Event is canceled'] = "Event&nbsp;is&nbsp;canceled";
$_lang['Please enter a password!'] = "Please enter a password!";
$_lang['You are not allowed to create an event!'] = "You are not allowed to create an event!";
$_lang['Event successfully created.'] = "Event successfully created.";
$_lang['You are not allowed to edit this event!'] = "You are not allowed to edit this event!";
$_lang['Event successfully updated.'] = "Event successfully updated.";
$_lang['You are not allowed to remove this event!'] = "You are not allowed to remove this event!";
$_lang['Event successfully removed.'] = "Event successfully removed.";
$_lang['Please give a text!'] = "Please give a text!";
$_lang['Please check the event date!'] = "Please check the event date!";
$_lang['Please check your time format!'] = "Please check your time format!";
$_lang['Please check start and end time!'] = "Please check start and end time!";
$_lang['Please check the serial event date!'] = "Please check the serial event date!";
$_lang['The serial event data has no result!'] = "The serial event data has no result!";
$_lang['Really delete this event?'] = "Really delete this event?";
$_lang['use'] = "Use";
$_lang[':'] = ":";
$_lang['Mobile Phone'] = "Mobile Phone";
$_lang['submit'] = "Submit";
$_lang['Further events'] = "Weitere Termine";
$_lang['Remove settings only'] = "Remove settings only";
$_lang['Settings removed.'] = "Settings removed.";
$_lang['User selection'] = "User selection";
$_lang['Release'] = "Release";
$_lang['none'] = "none";
$_lang['only read access to selection'] = "only write access to selection";
$_lang['read and write access to selection'] = "read and write access to selection";
$_lang['Available time'] = "Available time";
$_lang['flat view'] = "List View";
$_lang['o_dateien'] = "Filemanager";
$_lang['Location'] = "Location";
$_lang['date_received'] = "date_received";
$_lang['subject'] = "Subject";
$_lang['kat'] = "Category";
$_lang['projekt'] = "Project";
$_lang['Location'] = "Location";
$_lang['name'] = "Titel";
$_lang['contact'] = "Kontakt";
$_lang['div1'] = "Erstellung";
$_lang['div2'] = "�nderung";
$_lang['kategorie'] = "Kategorie";
$_lang['anfang'] = "Beginn";
$_lang['ende'] = "Ende";
$_lang['status'] = "Status";
$_lang['filename'] = "Titel";
$_lang['deadline'] = "Termin";
$_lang['ext'] = "an";
$_lang['priority'] = "Priorit�t";
$_lang['project'] = "Projekt";
$_lang['Accept'] = "�bernehmen";
$_lang['Please enter your user name here.'] = "Please enter your user name here.";
$_lang['Please enter your password here.'] = "Please enter your password here.";
$_lang['Click here to login.'] = "Click here to login.";
$_lang['No New Polls'] = "No New Polls";
$_lang['&nbsp;Hide read elements'] = "&nbsp;Hide read elements";
$_lang['&nbsp;Show read elements'] = "&nbsp;Show read elements";
$_lang['&nbsp;Hide archive elements'] = "&nbsp;Hide archive elements";
$_lang['&nbsp;Show archive elements'] = "&nbsp;Show archive elements";
?>