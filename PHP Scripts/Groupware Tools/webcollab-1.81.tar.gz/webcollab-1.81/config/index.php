<?php
/*
This file is to prevent users browsing the listing of this directory.
*/ 
?>

<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>403 Forbidden</TITLE>
</HEAD><BODY>
<H1>Forbidden</H1>
You don't have permission to access <?php echo $_SERVER['REQUEST_URI']; ?> on this server.<P>
<HR>
<?php echo $_SERVER['SERVER_SIGNATURE']; ?>
</BODY></HTML>