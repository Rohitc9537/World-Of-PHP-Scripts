<?php

require_once('path.php');

define('BASE_CONFIG', BASE.'config/' );
define('BASE_CSS', BASE.'css/' );

?>