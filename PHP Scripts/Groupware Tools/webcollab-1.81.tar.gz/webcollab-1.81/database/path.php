<?php

//we shouldn't get here...
die('Direct access to database directory is not permitted' );

?>