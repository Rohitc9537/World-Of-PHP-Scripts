<?php
  
define('BASE', '' );

?>