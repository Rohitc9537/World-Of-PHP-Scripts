This is a PHP Censor written by Garrett P. It's simply a PHP function that takes one paramater, $content. $content is what you would like to be censored. It will return the censored content. Make a file called censorwords.txt, and place each word you would like censored on a new line. Make sure there are no blank lines, they tend to magically appear at the end of some files.

Happy censoring!

(not responsible for the angry crowds who realize they can no evade the filter on your webspace)