function placeFocus()
{
  if (document.forms.length > 0) 
  {
    var field = document.forms[0];
    for (i = 0; i < field.length; i++) 
    {
      if ((field.elements[i].type == "text") || (field.elements[i].type =="textarea") || (field.elements[i].type.toString().charAt(0) == "s")) 
      {
        document.forms[0].elements[i].focus();
        break;
      }
    }
  }
}
