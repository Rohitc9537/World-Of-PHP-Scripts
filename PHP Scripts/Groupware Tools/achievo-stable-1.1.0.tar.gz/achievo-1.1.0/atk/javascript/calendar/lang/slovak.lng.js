// ** I18N
Calendar._DN = new Array
("Nede�a",
 "Pondelok",
 "Utorok",
 "Streda",
 "�tvrtok",
 "Piatok",
 "Sobota",
 "Nede�a");
Calendar._MN = new Array
("Janu�r",
 "Febru�r",
 "Marec",
 "Apr�l",
 "M�j",
 "J�n",
 "J�l",
 "August",
 "September",
 "Okt�ber",
 "November",
 "December");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Zmena prv�ho d�a v t��dni";
Calendar._TT["PREV_YEAR"] = "Predch. rok (pridr� pre menu)";
Calendar._TT["PREV_MONTH"] = "Predch. mesiac (pridr� pre menu)";
Calendar._TT["GO_TODAY"] = "Dne�n� d�tum";
Calendar._TT["NEXT_MONTH"] = "�al�� mesiac (pridr� pre menu)";
Calendar._TT["NEXT_YEAR"] = "�al�� rok (pridr� pre menu)";
Calendar._TT["SEL_DATE"] = "Vyber d�tum";
Calendar._TT["DRAG_TO_MOVE"] = "Chy� a presu�";
Calendar._TT["PART_TODAY"] = " (dnes)";
Calendar._TT["MON_FIRST"] = "Zobraz ako prv� Pondelok";
Calendar._TT["SUN_FIRST"] = "Zobraz ako prv� Nede�u";
Calendar._TT["CLOSE"] = "Zatvor";
Calendar._TT["TODAY"] = "Dnes";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "d.mm.yy";
Calendar._TT["TT_DATE_FORMAT"] = "D, M y";

Calendar._TT["WK"] = "t��";
