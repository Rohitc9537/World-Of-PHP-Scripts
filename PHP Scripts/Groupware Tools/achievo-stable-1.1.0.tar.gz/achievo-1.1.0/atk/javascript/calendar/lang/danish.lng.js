// ** I18N
Calendar._DN = new Array
("S�ndag",
 "Mandag",
 "Tirsdag",
 "Onsdag",
 "Torsdag",
 "Fredag",
 "L�rdag",
 "S�ndag");
Calendar._MN = new Array
("January",
 "Februar",
 "Marts",
 "April",
 "Maj",
 "Juni",
 "Juli",
 "August",
 "September",
 "Oktober",
 "November",
 "December");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Skift f�rste ugedag";
Calendar._TT["PREV_YEAR"] = "�t �r tilbage (hold for menu)";
Calendar._TT["PREV_MONTH"] = "�n m�ned tilbage (hold for menu)";
Calendar._TT["GO_TODAY"] = "G� til i dag";
Calendar._TT["NEXT_MONTH"] = "�n m�ned frem (hold for menu)";
Calendar._TT["NEXT_YEAR"] = "�t �r frem (hold for menu)";
Calendar._TT["SEL_DATE"] = "V�lg dag";
Calendar._TT["DRAG_TO_MOVE"] = "Tr�k vinduet";
Calendar._TT["PART_TODAY"] = " (i dag)";
Calendar._TT["MON_FIRST"] = "Vis mandag f�rst";
Calendar._TT["SUN_FIRST"] = "Vis s�ndag f�rst";
Calendar._TT["CLOSE"] = "Luk vinduet";
Calendar._TT["TODAY"] = "I dag";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "D d. M, y";

Calendar._TT["WK"] = "wk";
