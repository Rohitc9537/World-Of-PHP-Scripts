<?php
/************************************************************************/
/* dplink                     (lang/eng/admin.php)                      */
/************************************************************************/

/*---ADMIN-TEXT--------------------------------------------------------------*/
define("_MODSUBJECT", "The Location of the dotProject installation");
define("_MODWARNING", "Do not use the trailing slash !!!!");
define("_MODERROR", "Error message when logon fails");
define("_MODWINDOW", "Open Application Full Screen");
define("_MODUSERS", "Create PostNuke users as user (not operator) :");
define("_MODWRAP", "Use PostWrap");
define("_SHIMLINKNOAUTH", "You are not authorised for this action");
define("_SHIMLINK", "dPLink 1.01");
define("_SHIMLINKMODIFYCONFIG", "Modify dPLink Configuration");
define("_SHIMLINKUPDATE", "Update dPLink Configuration");
/*---END-ADMIN-TEXT----------------------------------------------------------*/
?>
