<?php
if(empty($s) || strlen(trim($s)) ==0){
$a = "index";
$AppUI->setMsg( "Please enter a search value" );
}

?>
