<?php
header('Location: acl_admin.php');
?>