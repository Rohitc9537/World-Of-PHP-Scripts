<?php
    $options = '';
    $cnt     = 0;
   	$GLOBALS['LANG']['explain carer'] = "Alternativ implementation of get_carer_options";
    
?>