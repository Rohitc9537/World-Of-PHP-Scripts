// PT lang variables


tinyMCELang['lang_bold_desc'] = 'Negrito';
tinyMCELang['lang_italic_desc'] = 'It�lico';
tinyMCELang['lang_underline_desc'] = 'Sublinhar';
tinyMCELang['lang_striketrough_desc'] = 'Riscado';
tinyMCELang['lang_justifyleft_desc'] = 'Alinhar � esquerda';
tinyMCELang['lang_justifycenter_desc'] = 'Alinhar ao centro';
tinyMCELang['lang_justifyright_desc'] = 'Alinhar � direita';
tinyMCELang['lang_justifyfull_desc'] = 'Justificado';
tinyMCELang['lang_bullist_desc'] = 'Lista n�o ordenada';
tinyMCELang['lang_numlist_desc'] = 'Lista ordenada';
tinyMCELang['lang_outdent_desc'] = 'Retirar indenta��o';
tinyMCELang['lang_indent_desc'] = 'Indentar';
tinyMCELang['lang_undo_desc'] = 'Desfazer';
tinyMCELang['lang_redo_desc'] = 'Refazer';
tinyMCELang['lang_link_desc'] = 'Inserir Hiperliga��o';
tinyMCELang['lang_unlink_desc'] = 'Remover hiperliga��o';
tinyMCELang['lang_image_desc'] = 'Inserir Refer�ncia a imagem externa';
tinyMCELang['lang_object_desc'] = 'Inserir Objecto Multim�dia da Galeria';
tinyMCELang['lang_cleanup_desc'] = 'Limpeza de c�digo';
tinyMCELang['lang_focus_alert'] = 'Uma inst�ncia do editor dever� estar seleccionada antes de utilizar este comando.';
tinyMCELang['lang_edit_confirm'] = 'Deseja utilizar o modo visual de edi��o para ezta �rea de texto?';
tinyMCELang['lang_insert_link_title'] = 'Inserir/editar hiperliga��o';
tinyMCELang['lang_insert'] = 'Inserir';
tinyMCELang['lang_update'] = 'Actualizar';
tinyMCELang['lang_cancel'] = 'Cancelar';
tinyMCELang['lang_insert_link_url'] = 'URL de hiperliga��o';
tinyMCELang['lang_insert_link_target'] = 'Destino';
tinyMCELang['lang_insert_link_target_same'] = 'Abrir endere�o na mesma janela';
tinyMCELang['lang_insert_link_target_blank'] = 'Abrir endere�o numa nova janela';
tinyMCELang['lang_insert_image_title'] = 'Inserir/editar imagem';
tinyMCELang['lang_insert_image_src'] = 'Endere�o da imagem';
tinyMCELang['lang_insert_image_alt'] = 'Descri��o alt.';
tinyMCELang['lang_help_desc'] = 'Ajuda';
tinyMCELang['lang_bold_img'] = "bold.gif";
tinyMCELang['lang_italic_img'] = "italic.gif";
tinyMCELang['lang_underline_img'] = "underline.gif";
tinyMCELang['lang_clipboard_msg'] = 'Copiar/Cortar/Colar n�o est� dispon�vel em Mozilla and Firefox.\nPretende obter mais informa��o acerca desta quest�o?';

