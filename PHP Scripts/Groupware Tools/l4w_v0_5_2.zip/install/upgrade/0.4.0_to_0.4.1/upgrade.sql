INSERT INTO gacl_acl VALUES("15", "user", "1", "1", "", "", "1100674140");

INSERT INTO gacl_acl_seq VALUES("15");

INSERT INTO gacl_aco VALUES("23", "Treemanager", "Show Treemanager", "1", "Show Treemanager", "0");
INSERT INTO gacl_aco VALUES("24", "Treemanager", "Add Element", "2", "Add Element", "0");
INSERT INTO gacl_aco VALUES("25", "Treemanager", "Edit Element", "3", "Edit Element", "0");
INSERT INTO gacl_aco VALUES("26", "Treemanager", "Delete Element", "4", "Delete Element", "0");
INSERT INTO gacl_aco VALUES("27", "Treemanager", "Edit Permissions", "5", "Edit Permissions", "0");

INSERT INTO gacl_aco_map VALUES("15", "Treemanager", "Add Element");
INSERT INTO gacl_aco_map VALUES("15", "Treemanager", "Delete Element");
INSERT INTO gacl_aco_map VALUES("15", "Treemanager", "Edit Element");
INSERT INTO gacl_aco_map VALUES("15", "Treemanager", "Edit Permissions");
INSERT INTO gacl_aco_map VALUES("15", "Treemanager", "Show Treemanager");

INSERT INTO gacl_aco_sections VALUES("13", "Treemanager", "4", "Treemanager", "0");

INSERT INTO gacl_aco_sections_seq VALUES("13");

INSERT INTO gacl_aco_seq VALUES("27");

INSERT INTO gacl_aro_map VALUES("15", "Person", "2");





