# MySQL-Front Dump 2.5
#
# Host: localhost   Database: gacl
# --------------------------------------------------------
# adjust gacl tables to be of type InnoDB

ALTER TABLE ###TABLE_PREFIX###gacl_aro_groups TYPE = InnoDB;

