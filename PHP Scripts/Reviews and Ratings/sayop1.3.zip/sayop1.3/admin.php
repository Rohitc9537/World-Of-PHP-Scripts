<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
   <head>
      <title>Administartion Login Form</title>
      <link rel="stylesheet" type="text/css" href="style_1.css" />
      <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   </head>
   <body>
<center><h3>SayOp administrator login</h3></center>
<form method="post" action="com/login.php">
<div style='background: #CCFF99; border: solid 1px; padding: 15px; margin-left: 100px; margin-right: 100px;'>
<div style='background: #CCFF99;' align="center">Username :<input type="text" name="username" /></div><br />
<div align="center">Password :<input type="password" name="password" /></div><br />
<center><input type="submit" name="submit" value="Login" /></center>
</div>
</form>
   </body>
</html> 