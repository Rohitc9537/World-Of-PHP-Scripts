<?php 
/////////////////////////////////////////////////////////////////////////////////////
//Please modify the values below to configure the control panel access and script functionality.//
/////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////
//Username

$user = "Username";

///////////////////////////////////////////
//Password

$pass = "Password";

///////////////////////////////////////////
//The full URL to the script directory: (NO trailing slash)     

$fullurl = "http://www.yourdomain.com/comments";

///////////////Optional below////////////////////
//Email alerts
//Set $mail_posts to "1" (one)  if you want to receive an email alert when somone makes a comment, othervise leave it "0" (zero)

$mail_posts = "0";

//If the above is set to "1", specify the email address you want to use for receiving the alerts.

$alerts_email_addy = "foo@bar.com";
?>