IMAGEUPLOADER

Simple image upload script
---------------------------------------------------


upload both '~off' and 'upload' to your webserver

edit 'upload/index.php' (first lines)

(.htaccess the 'upload' dir (if you want to passprotect it)

chmod '~off/images' so you are able to write in 'images'


