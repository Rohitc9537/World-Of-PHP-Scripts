<?php
/*******************************************************************************
* instalar/plantillas/instalar.inc.php
*
* plantilla para la visualizaci�n de la pantalla de instalaci�n
*

PHPfileNavigator versi�n 2.1.0

Copyright (C) 2004-2005 Lito <lito@eordes.com>

http://phpfilenavigator.litoweb.net/

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo los
t�rminos de la Licencia P�blica General de GNU seg�n es publicada por la Free
Software Foundation, bien de la versi�n 2 de dicha Licencia o bien (seg�n su
elecci�n) de cualquier versi�n posterior. 

Este programa se distribuye con la esperanza de que sea �til, pero SIN NINGUNA
GARANT�A, incluso sin la garant�a MERCANTIL impl�cita o sin garantizar la
CONVENIENCIA PARA UN PROP�SITO PARTICULAR. V�ase la Licencia P�blica General de
GNU para m�s detalles. 

Deber�a haber recibido una copia de la Licencia P�blica General junto con este
programa. Si no ha sido as�, escriba a la Free Software Foundation, Inc., en
675 Mass Ave, Cambridge, MA 02139, EEUU. 
*******************************************************************************/

defined('OK') or die();
?>
	<tr>
		<td><a href="#" onclick="Xamosa_axuda(20); return false;">(?)</a> <?php echo $conf->t('aviso_instalacion'); ?>:</td>
		<td><input type="checkbox" name="aviso_instalacion" value="true" class="checkbox" tabindex="55" checked="checked" /></td>
	</tr>
	<tr id="tr_axuda20" style="display: none;">
		<td colspan="2"><?php echo $conf->t('axuda','aviso_instalacion'); ?></td>
	</tr>
