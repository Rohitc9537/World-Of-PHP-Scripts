<?php
/*******************************************************************************
* instalar/plantillas/ok.inc.php
*
* plantilla para la visualizaci�n de la pantalla del resultado de una
* instalaci�n correcta
*

PHPfileNavigator versi�n 2.0.0

Copyright (C) 2004-2005 Lito <lito@eordes.com>

http://phpfilenavigator.litoweb.net/

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo los
t�rminos de la Licencia P�blica General de GNU seg�n es publicada por la Free
Software Foundation, bien de la versi�n 2 de dicha Licencia o bien (seg�n su
elecci�n) de cualquier versi�n posterior. 

Este programa se distribuye con la esperanza de que sea �til, pero SIN NINGUNA
GARANT�A, incluso sin la garant�a MERCANTIL impl�cita o sin garantizar la
CONVENIENCIA PARA UN PROP�SITO PARTICULAR. V�ase la Licencia P�blica General de
GNU para m�s detalles. 

Deber�a haber recibido una copia de la Licencia P�blica General junto con este
programa. Si no ha sido as�, escriba a la Free Software Foundation, Inc., en
675 Mass Ave, Cambridge, MA 02139, EEUU. 
*******************************************************************************/

defined('OK') or die();
?>
<script type="text/javascript"><!--

document.write('<link rel="stylesheet" href="instalar/instalar.css" type="text/css" />');

//--></script>

<div id="inst_benvido"><?php echo $conf->t('benvido'); ?></div>
<div style="margin: 10px; text-align: center;"><img src="estilos/pfn/imx/logo.png" alt="PHPfileNavigator v2" /></div>
<div id="inst_correcto"><?php echo $conf->t('instalacion_correcta'); ?></div>
<div class="inst_aviso"><a href="http://sourceforge.net/donate/index.php?group_id=142312" onclick="window.open(this.href,'_blank'); return false;"><img src="http://images.sourceforge.net/images/project-support.jpg" width="88" height="32" border="0" alt="Support This Project" id="inst_doazon" /></a><?php echo $conf->t('doazon'); ?><br class="nada" /></div>
