<?php
/****************************************************************************
* xestion/configuracions/eliminar.inc.php
*
* Elimina un fichero de configuraci�n y sus relaciones en la base de datos
*

PHPfileNavigator versi�n 2.0.0

Copyright (C) 2004-2005 Lito <lito@eordes.com>

http://phpfilenavigator.litoweb.net/

Este programa es software libre. Puede redistribuirlo y/o modificarlo bajo los
t�rminos de la Licencia P�blica General de GNU seg�n es publicada por la Free
Software Foundation, bien de la versi�n 2 de dicha Licencia o bien (seg�n su
elecci�n) de cualquier versi�n posterior. 

Este programa se distribuye con la esperanza de que sea �til, pero SIN NINGUNA
GARANT�A, incluso sin la garant�a MERCANTIL impl�cita o sin garantizar la
CONVENIENCIA PARA UN PROP�SITO PARTICULAR. V�ase la Licencia P�blica General de
GNU para m�s detalles. 

Deber�a haber recibido una copia de la Licencia P�blica General junto con este
programa. Si no ha sido as�, escriba a la Free Software Foundation, Inc., en
675 Mass Ave, Cambridge, MA 02139, EEUU. 
*******************************************************************************/

$relativo = '../../';

include ($relativo.'paths.php');
include_once ($paths['include'].'basicweb.php');
include_once ($paths['include'].'Xusuarios.php');

PFN_quita_url_SERVER('id_conf');

session_write_close();

$ok = 0;
$erros = array();

$id_conf = $vars->get('id_conf');
$existe = $usuarios->init('configuracion', $id_conf);
$nome_arq = $niveles->path_correcto($paths['conf'].$usuarios->get('conf').'.inc.php');

if (!$existe) {
	$erros[] = 18;
} elseif ($usuarios->get('vale') != 1) {
	$erros[] = 25;
} elseif ($usuarios->init('configuracion_raices', $id_conf)) {
	$erros[] = 26;
} elseif ($usuarios->init('configuracion_grupos', $id_conf)) {
	$erros[] = 27;
}

if (count($erros) == 0) {
	$usuarios->accion('conf_eliminar', $id_conf);
	@unlink($nome_arq);
}

$ok = count($erros)?false:4;

if ($ok) {
	Header('Location: ../index.php?'.PFN_cambia_url(array('id_conf','opc','ok'), array('',4,$ok), false, true));
} else {
	Header('Location: index.php?'.PFN_cambia_url(array('id_conf','erros'), array($id_conf,implode(',', $erros)), false, true));
}

exit;
?>
