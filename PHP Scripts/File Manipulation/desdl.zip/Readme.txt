This script is increadibly easy to set up, There are only 3 steps

1) Upload the download.php file to your web server
2) Open the download.php file and change the value if $path to the path to where your downloads are
3) Test the script, an example link is below

<a href="download.php?file=filename.zip">Click me</a>

And so on.