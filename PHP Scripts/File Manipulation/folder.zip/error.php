<html><head><title>RFX-Folder Program</title><link rel="stylesheet" href="styles.css">
</head><body><table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="800" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="17"><img src="images/box_top_left.png" width="17" height="30"></td>
        <td width="766" background="images/box_top_center.png"><span class="title">RFX-Folder: Error</span></td>
        <td width="17"><img src="images/box_top_right.png" width="17" height="30"></td>
      </tr>
      <tr>
        <td colspan="3"><table width="800" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="4" background="images/box_middle_left.png">&nbsp;</td>
            <td width="792"><table width="792" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="41" background="images/button_bg.png" class="button_set"><img src="images/back.png" onMouseOver="this.src='images/back_over.png';" onMouseOut="this.src='images/back.png';" onClick="javascript:history.go(-1);" width="77" class="buttons" height="37"><img src="images/forward_disabled.png" class="buttons" width="51" height="37"><img src="images/up_folder_disabled.png" class="buttons" width="32" height="37"></td>
              </tr>
              <tr>
                <td background="images/address_bg.png"><img src="images/address.png" width="49" height="23" align="top"> <input name="address" type="text" class="address" id="address" size="120" value=" /error"></td>
              </tr>
              <tr>
                <td><table width="790" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td background="images/main_bg.png"><table width="790" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="210" valign="top"><br>
                          <table width="185" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td><img src="images/tab.png" width="185" height="25"></td>
                            </tr>
                            <tr>
                              <td bgcolor="#D6DFF7">                                <table width="160" border="0" align="center" cellpadding="0" cellspacing="0"><tr>
                                    <td colspan="2" height="5"></td>
                                    </tr><tr>
                                    <td width="16"><img src="images/denied.png" width="16" height="16"></td>
                                    <td class="style1">&nbsp;<a href="javascript:history.go(-1);">Back</a></td>
                                  </tr><tr>
                                    <td colspan="2" height="5"></td>
                                    </tr>
                                </table>
                                </td>
                            </tr>
                          </table>
                          <p>&nbsp;</p>
                        </div></td>
                        <td width="580" valign="top" class="medium">ERROR_LOCATION</tr>
                      <tr>
                        <td colspan="2" valign="top" bgcolor="#FFFFFF" height="1"></td>
                        </tr>
                    </table></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
            <td width="4" background="images/box_middle_right.png">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td><img src="images/box_bottom_left.png" width="17" height="4"></td>
        <td background="images/box_bottom_center.png"></td>
        <td><img src="images/box_bottom_right.png" width="17" height="4"></td>
      </tr>
    </table></td>
  </tr>
</table>
</body></html>