--- README for RFX-Folder ---
--- By www.radiantfx.com/ ---

To install the program copy all the files within the folder to /RFX-Folder/ as the script
goes one level above the folder it is in so /RFX-Folder/ will goto /

Once the files are uploaded you should chmod777 all the directories and files you wish to
be changing.

To make a user unable to view a file set the World (Or Guest) read permissions to false,
similarily with writing to files, set the world (Or Guest) write permissions to false.

--- Copyright 2005 RadiantFX.com ---