#---------------------------------------#
# file upload manager
#---------------------------------------#

author: 	thepeak (adam medici)
version:	1.3
date:		13.10.2003

email:		thepeak@gmx.net
www 1:		http://webdev.mtnpeak.net
www 2:		http://www.xd3v.com

#---------------------------------------#

Description:

A simple, powerful tool to upload and 
manage files using your web browser.

#---------------------------------------#

What needed:

	-A webserver with PHP 4+
	-Very basic PHP Knowledge
	-A JavaScript capable web-browser

#---------------------------------------#

Instructions:

Open "index.php" in a text editor and edit 
the configurations if needed.
Upload all files in "fileupload" directory
to your webserver (PHP files in ASCII mode) 
preferably in it's own folder and for *Unix 
webservers, CHMOD the "store" directory to 0777. 
Now run it! (yoursite.com/fileupload/index.php)

There are 2 CSS (stylesheet) files located 
in the "img" directory. You can change 
between each one (style-def OR style-dot)
through the configuration part of index.php.

Enjoy and please send me feedback!

#---------------------------------------#

License:

This program is free software; you can redistribute it and/or 
modify it under the terms of the GNU General Public License 
as published by the Free Software Foundation; either version 2 
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
GNU General Public License (included in this ZIP) for more details.

#---------------------------------------#