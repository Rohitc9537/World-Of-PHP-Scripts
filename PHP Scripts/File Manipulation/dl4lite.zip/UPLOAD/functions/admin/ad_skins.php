<?php

$loader = new admin_skins();

class admin_skins
{
	var $html	= "";
	var $output = "";
	function admin_skins()
	{
		global $IN, $OUTPUT;
		
		//$this->html = $OUTPUT->load_template("skin_files");

		switch($IN["act"])
		{
			case 'test':
				$this->skins_php2sql(1);
				break;
			
			case 'manage':
				$this->skins_manage($IN["editskin"]);
				break;
				
			case 'edit':
				$this->skins_edit();
				break;
				
			case 'save':
				$this->skins_save();
				break;
				
			case 'new':
				$this->skins_new();
				break;
				
			case 'import':
				$this->skins_import();
				break;
				
			case 'export':
				$this->skins_export();
				break;

            case 'delete':
                $this->skins_delete();
                break;

            case 'gEdit':
                $this->skins_gElement();
                break;
		}
		
		$OUTPUT->add_output($this->output);
	}
	
	function skins_new()
	{
		global $DB, $IN, $std, $sid;
		
		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_newskin"));
				
		if ($IN['submit']) 
		{
			$DB->query("SELECT `name`,`author` FROM `dl_skinsets` WHERE setid='{$IN['skinid']}'");
			if (!($myrow = $DB->fetch_row()))
			{
				$std->error(GETLANG("invalid_skin"));
				$this->output .= admin_foot();
				return;
			}
			$insert['name'] = $myrow['name']." [copy]";
			$insert['author'] = $myrow['author'];
			$DB->insert($insert, "dl_skinsets");
			$newid = $DB->insert_id();
			
			$std->mycopy(ROOT_PATH."/skins/skin{$IN['skinid']}/", ROOT_PATH."/skins/skin{$newid}/");
			$this->skins_php2sql($newid);
			$this->output .= GETLANG("skin_created")."<br><br>";
            $this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=new'>".GETLANG("backto")." ".GETLANG("nav_newskin")."</a><br>";
            $this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage'>".GETLANG("backto")." ".GETLANG("nav_editskins")."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=main'>".GETLANG("backto")." ".GETLANG("nav_adhome")."</a><br>";
			$this->output .= admin_foot();
			return;
		}
		
		$this->output .= "<form method=POST action='admin.php?sid=$sid&area=skins&act=new'>";
		$DB->query("SELECT * FROM `dl_skinsets`");
		$this->output .= new_table();
		$this->output .= new_row(2, "acptablesubhead", "", "16")."&nbsp;";
		$this->output .= GETLANG("select_skin");
		$this->output .= new_row();
		$this->output .= GETLANG("baseskin");
		$this->output .= new_col();
		$this->output .= "<select name='skinid'>";
		while ( $myrow = $DB->fetch_row() )
		{
			$this->output .= "<option value={$myrow['setid']}>{$myrow['name']}</option>";
		} 
		$this->output .= "</select>";
		$this->output .= " <input type='submit' name='submit' value='Submit'>";
		$this->output .= "</form>";
		$this->output .= end_table();
		$this->output .= admin_foot();
	}
	
	function skins_import()
	{
		global $CONFIG, $IN, $DB, $rwdInfo, $sid, $std;
		$langpath = $CONFIG['sitepath'].'/archive_in/';
		
		require_once ROOT_PATH."/functions/tar.php";
		
		$dir_handle = @opendir($langpath) or die("Unable to open $langpath");
		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_importskin"));
		
		if ($IN['import']) 
		{
			$insert = array("name" => "",
							"author" => "");
			$DB->insert($insert, "dl_skinsets");
			$newid = $DB->insert_id();
			if (@mkdir($CONFIG['sitepath']."/skins/skin{$newid}/", 0777))
			{
			    $tar = new tar();
				$tar->new_tar($langpath, $IN['import'].".tar");
				$files = $tar->list_files();
				$tar->extract_files( $CONFIG['sitepath']."/skins/skin{$newid}/" );
				
				$filename = $CONFIG['sitepath']."/skins/skin{$newid}/skin.data";
				$handle = fopen($filename, "rb");
				$contents = fread($handle, filesize($filename));
				fclose($handle);
				$types = explode("|", $contents);
				
				$update = array("name" => $types[0]." [import]",
								"author" => $types[1]);
				$DB->update($update, "dl_skinsets", "setid={$newid}");
				
				$this->skins_php2sql($newid);
				$this->output .= GETLANG("import_successful");
			}
			else
			{
				$std->error(GETLANG("no_skin_directory"));
			}
			$this->output .= admin_foot();
			return;
		}
		
		if ($IN['delete']) 
		{
			
			if (unlink($langpath.$IN['delete'].".tar"))
			{
				$this->output .= GETLANG("tar_deleted");
			}
			else
			{
				$std->error .= GETLANG("delete_failed");
			}
			$this->output .= admin_foot();
			return;
		}
		$this->output .= new_table();
		$this->output .= new_row(4, "acptablesubhead");
		$this->output .= GETLANG("skin_import");
		$counter = 0;
		while($filename = readdir($dir_handle)) 
		{
			if (($filename != ".") && ($filename != ".."))
			{
				if ( preg_match( "/\.tar$/", $filename ) )
				{
					if (strstr($filename, "skin_")) 
					{
						$counter++;
						$this->output .= new_row(-1, "", "", "16")."<img src='{$rwdInfo->skinurl}/images/edit.gif'>";
						$this->output .= new_col();
						$this->output .= $std->strip_ext($filename);
						$this->output .= new_col();
						$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=import&import=".$std->strip_ext($filename)."'>".GETLANG("import")."</a>";
						$this->output .= new_col();
						$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=import&delete=".$std->strip_ext($filename)."'>".GETLANG("delete")."</a>";
					}
				}
			}
		} 
		closedir($dir_handle);
		if ( $counter == 0 ) 
		{
		    $this->output .= new_row();
			$this->output .= GETLANG("no_imports");
		}
		$this->output .= end_table();
		$this->output .= admin_foot();
		return;
	}
	
	function skins_export()
	{
		global $std, $sid, $IN, $DB, $CONFIG;
		require_once ROOT_PATH."/functions/tar.php";
		
		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_exportskins"));
		
		if ( $IN['submit'] )
		{
			$DB->query("SELECT * FROM `dl_skinsets` WHERE `setid`={$IN['skinid']}");
			$myrow = $DB->fetch_row();
			$fileName = $CONFIG['sitepath']."/skins/skin{$IN['skinid']}/skin.data";
			if ( $fp = @fopen( $fileName, 'w' ) )
			{
				$langdata = "{$myrow['name']}|{$myrow['author']}";
				fwrite($fp, $langdata, strlen($langdata) );
				fclose($fp);
				$tar = new tar();
				$tar->new_tar($CONFIG['sitepath']."/archive_out/" , "skin_{$IN['skinid']}.tar");
				$std->error .= "<p>".$tar->error;
				$tar->current_dir($CONFIG['sitepath']);
				$std->error .= "<p>".$tar->error;
				$tar->add_directory($CONFIG['sitepath']."/skins/skin{$IN['skinid']}");
				$std->error .= "<p>".$tar->error;
				$tar->write_tar();
				$std->error .= "<p>".$tar->error;
				$this->output .= GETLANG("export_complete");
				$this->output .= "<p>".GETLANG("click_download")." [ <a href='{$CONFIG['siteurl']}/archive_out/skin_{$IN['skinid']}.tar'>".GETLANG("download")."</a> ]";
				$this->output .= admin_foot();
				
			}
			else
		    {
				$this->error(GETLANG("nodatafile"));
		    }  
			return;
		}
		
		$this->output .= "<form method=POST action='admin.php?sid=$sid&area=skins&act=export'>";
		$DB->query("SELECT * FROM `dl_skinsets`");
		$this->output .= new_table();
		$this->output .= new_row(-1, "acptablesubhead", "", "16")."&nbsp;";
		$this->output .= GETLANG("select_lang");
		$this->output .= new_row();
		$this->output .= "<select name='skinid'>";
		while ( $myrow = $DB->fetch_row() )
		{
			$this->output .= "<option value={$myrow['setid']}>{$myrow['name']}</option>";
		} 
		$this->output .= "</select>";
		$this->output .= " <input type='submit' name='submit' value='".GETLANG("submit")."'>";
		$this->output .= "</form>";
		$this->output .= end_table();

		$this->output .= admin_foot();
	}
	
	function skins_edit()
	{
		global $std, $sid, $rwdInfo, $IN, $DB;
		
		$skinid = $IN["skinid"];
		
		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_editskins"));
		$this->output .= "<form method=POST action='admin.php?sid=$sid&area=skins&act=save'>";
		$DB->query("SELECT * FROM `dl_templates` WHERE `tid`='$skinid'");
		if ( !$myrow = $DB->fetch_row() )
		{
			 $std->error(GETLANG("skingsetmissing"));
			 $this->output .= admin_foot();
			 return;
		}
		$output = htmlspecialchars($myrow['content']);
		$this->output .= "<textarea cols='60' rows='20' name='content' style='width:100%'>{$output}</textarea>";
		$this->output .= "<center><input type='submit' name='saveskin' value='".GETLANG("save_changes")."'> ";
		$this->output .= "<input type='reset' name='reset' value='{$rwdInfo->lang['reset']}'></center>";
		$this->output .= "<input type='hidden' name='class' value='{$myrow['groupname']}'>";
		$this->output .= "<input type='hidden' name='setid' value='{$myrow['setid']}'>";
		$this->output .= "<input type='hidden' name='function' value='{$myrow['funcname']}'>";
		$this->output .= "<input type='hidden' name='tid' value='{$myrow['tid']}'>";
		
		$this->output .= "</form>";
		$this->output .= admin_foot();
	}

    function skins_gElement()
	{
		global $std, $sid, $rwdInfo, $IN, $DB;

		$skinid = $IN["skinid"];
        $type = $IN['type'];

        if ( $type == 0 )
		{
            $this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_editcss"));
            $filename = $rwdInfo->path."/skins/skin{$skinid}/style.css";
        }
        else
        {
            $this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_edittemplate"));
            $filename = $rwdInfo->path."/skins/skin{$skinid}/main.htm";
        }

        if ( $IN['saveskin'] )
        {
            // Let's make sure the file exists and is writeable first.
            if (is_writable($filename))
            {
                if (!$handle = fopen($filename, 'w'))
                {
                    $std->error(GETLANG("notwritable")."<br>".$filename);
                    return;
                }

		$IN = $std->my_stripslashes($IN);
		
		$content = str_replace( "&quot;", 	"\"", 	$IN['content'] );
		$content = str_replace( "&#39;", 	"'", 	$content );
		$content = str_replace( "&amp;", 	"&", 	$content );
		$content = str_replace( "&#036;", 	"$", 	$content );
                $content = str_replace( "&#60;script",  "<script ", $content);
		$content = str_replace( "&#60;&#33;--", "<!--", $content );
		$content = str_replace( "--&#62;",	"-->",	$content );
		$content = str_replace( "&#33;",	"!",	$content );
		$content = str_replace( "&gt;", 	">", 	$content );
		$content = str_replace( "&lt;", 	"<", 	$content );
		
		if (fwrite($handle, $content) === FALSE)
                {
                   $std->error(GETLANG("notwritable")."<br>".$filename);
                   return;
                }

                $this->output .= GETLANG("skinupdated")."<br><br>";

    			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage'>".GETLANG("backto")." ".GETLANG("nav_editskins")."</a><br>";
                if ( $type == 0 )
                    "+ <a href='admin.php?sid=$sid&area=skins&act=gEdit&type={$type}'>".GETLANG("backto")." ".GETLANG("nav_editcss")."</a><br>";
                else
                    "+ <a href='admin.php?sid=$sid&area=skins&act=gEdit&type={$type}'>".GETLANG("backto")." ".GETLANG("nav_edittemplate")."</a><br>";
    			$this->output .= "+ <a href='admin.php?sid=$sid&area=main'>".GETLANG("backto")." ".GETLANG("nav_adhome")."</a><br>";

               fclose($handle);

            }
            else
            {
                $std->error(GETLANG("notwritable")."<br>".$filename);
                return;
            }
            $this->output .= admin_foot();
            return;
        }

		$this->output .= "<form method=POST action='admin.php?sid=$sid&area=skins&act=gEdit'>";

        $handle = fopen($filename, "r");
        if ( !$handle )
        {
			 $std->error(GETLANG("globalskinmissing")."<br>".$filename);
			 $this->output .= admin_foot();
			 return;
		}
        $contents = fread($handle, filesize($filename));
        fclose($handle);

		$output = htmlspecialchars($contents);
		$this->output .= "<textarea cols='60' rows='20' name='content' style='width:100%'>{$output}</textarea>";
		$this->output .= "<center><input type='submit' name='saveskin' value='".GETLANG("save_changes")."'> ";
		$this->output .= "<input type='reset' name='reset' value='{$rwdInfo->lang['reset']}'></center>";
		$this->output .= "<input type='hidden' name='type' value='{$type}'>";
		$this->output .= "<input type='hidden' name='skinid' value='{$skinid}'>";

		$this->output .= "</form>";
		$this->output .= admin_foot();
	}
	
	function skins_save()
	{
		global $IN, $DB, $sid, $std;
		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_editskins"));

		$IN = $std->my_stripslashes($IN);
		
		$content = str_replace( "&quot;", 	"\"", 	$IN['content'] );
		$content = str_replace( "&#39;", 	"'", 	$content );
		$content = str_replace( "&amp;", 	"&", 	$content );
		$content = str_replace( "&#036;", 	"$", 	$content );
        $content = str_replace( "&#60;script",  "<script ", $content);
		$content = str_replace( "&#60;&#33;--", "<!--", $content );
		$content = str_replace( "--&#62;",	"-->",	$content );
		$content = str_replace( "&#33;",	"!",	$content );
		$content = str_replace( "&gt;", 	">", 	$content );
		$content = str_replace( "&lt;", 	"<", 	$content );

		
		if ( $this->skins_sql2php($IN['setid'], $IN['class'], $IN['function'], $content))
		{
			$update = array ( "content" => addslashes($content) );
			$DB->update($update, "dl_templates", "tid={$IN['tid']}");
			$this->output .= GETLANG("skinupdated")."<br><br>";

			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage'>".GETLANG("backto")." ".GETLANG("nav_editskins")."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=edit&skinid={$IN['tid']}'>".GETLANG("backto")." ".GETLANG("nav_editskins")." ".$IN['function']."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=main'>".GETLANG("backto")." ".GETLANG("nav_adhome")."</a><br>";
		}
		
		$this->output .= admin_foot();
	}

    function skins_delete()
    {
        global $std, $sid, $rwdInfo, $IN, $DB;

        $id = $IN['id'];

		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_deleteskins"));
        if ($IN["confirm"])
		{
            $DB->query("DELETE FROM `dl_templates` WHERE `setid`='{$id}'");
            $DB->query("DELETE FROM `dl_skinsets` WHERE `setid`='{$id}'");
            if ( $std->rmdirr($rwdInfo->path."/skins/skin{$id}/") )
            	$this->output .= GETLANG("skindeleted")."<br><br>";
            else
                $this->output .= GETLANG("skindelfail")."<br><br>";

			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage'>".GETLANG("backto")." ".GETLANG("nav_editskins")."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=main'>".GETLANG("backto")." ".GETLANG("nav_adhome")."</a><br>";

		}
		else if ($IN["cancel"])
		{
			$this->output .= GETLANG("delcancel")."<br><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage'>".GETLANG("backto")." ".GETLANG("nav_editskins")."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=skins&act=manage&editskin=".$IN['id']."'>".GETLANG("backto")." ".GETLANG("nav_editskinset")."</a><br>";
			$this->output .= "+ <a href='admin.php?sid=$sid&area=main'>".GETLANG("backto")." ".GETLANG("nav_adhome")."</a><br>";
		}
		else
		{
			$std->warning (GETLANG("warn_dldel")."<p>"
					."<form method='post' action='admin.php?sid=$sid&area=skins&act=delete'>"
					."<input type='hidden' name='id' value='{$id}'>"
					."<input type='Submit' name='confirm' value='".GETLANG("yes")."'> <input type='Submit' name='cancel' value='".GETLANG("no")."'> </form>");
		}
		$this->output .= admin_foot();
    }

	function skins_manage($id = 0)
	{
		global $std, $sid, $rwdInfo, $IN, $DB;

		$this->output .= admin_head(GETLANG("nav_skins"), GETLANG("nav_editskins"));
		if ( $id )
		{
			$result = $DB->query("SELECT * FROM `dl_templates` WHERE `setid`='{$id}' ORDER BY `groupname`");
			if ( !$myrow = $DB->fetch_row($result) )
			{
				 $std->error(GETLANG("skingsetmissing"));
				 $this->output .= admin_foot();
				 return;
			}
			if ($IN['submit']) 
			{
			    $update = array("name" => $IN['name'],
								"author" => $IN['author']);
				$DB->update($update, "dl_skinsets", "setid={$id}");
				$this->output .= GETLANG("details_saved");
			}
			$DB->query("SELECT * FROM `dl_skinsets` WHERE `setid`='{$id}'");
			$myrow2 = $DB->fetch_row();
			$this->output .= "<form method=POST action='admin.php?sid=$sid&area=skins&act=manage&editskin={$id}'>";
			$this->output .= new_table();
			$this->output .= new_row(2, "acptablesubhead", "", "16");
			$this->output .= GETLANG("edit_details");
			$this->output .= new_row();
			$this->output .= GETLANG("name");
			$this->output .= new_col();
			$this->output .= "<input type='text' name='name' value='{$myrow2['name']}' size='30'>";
			$this->output .= new_row();
			$this->output .= GETLANG("author");
			$this->output .= new_col();
			$this->output .= "<input type='text' name='author' value='{$myrow2['author']}' size='30'>";
			$this->output .= new_row();
			$this->output .= new_col();
			$this->output .= "<input type='submit' name='submit' value='Submit'>";
			$this->output .= end_table();
			$this->output .= "</form>";

			$this->output .= new_table();

            $this->output .= new_row(-1, "acptablesubhead", "", "16")."<img src='{$rwdInfo->skinurl}/images/open.gif'>";;
			$this->output .= new_col();
			$this->output .= GETLANG("globalelements");
            $this->output .= new_row(-1, "", "", "16")."<img src='{$rwdInfo->skinurl}/images/edit.gif'>";
			$this->output .= new_col();
			$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=gEdit&skinid={$id}&type=0'>".GETLANG("css")."</a>";
            $this->output .= new_row(-1, "", "", "16")."<img src='{$rwdInfo->skinurl}/images/edit.gif'>";
			$this->output .= new_col();
			$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=gEdit&skinid={$id}&type=1'>".GETLANG("template")."</a>";

			$lastgroup = "";
			do
			{
				if ( $lastgroup != $myrow['groupname'] )
				{
					$this->output .= new_row(-1, "acptablesubhead", "", "16")."<img src='{$rwdInfo->skinurl}/images/open.gif'>";;
					$this->output .= new_col();
					$this->output .= $myrow['groupname'];
					$lastgroup = $myrow['groupname'];
				}
				
				$this->output .= new_row(-1, "", "", "16")."<img src='{$rwdInfo->skinurl}/images/edit.gif'>";
				$this->output .= new_col();
				$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=edit&skinid={$myrow['tid']}'>{$myrow['funcname']}</a>";
				
			} while ( $myrow = $DB->fetch_row($result) );
			$this->output .= end_table();
			
		}
		else
		{
			$DB->query("SELECT * FROM `dl_skinsets`");
			if ( !$myrow = $DB->fetch_row() )
			{
				 $std->error(GETLANG("noskins"));
				 $this->output .= admin_foot();
				 return;
			}
			$this->output .= new_table();
			$this->output .= new_row(-1, "acptablesubhead", "", "16")."&nbsp;";
			$this->output .= new_col();
			$this->output .= GETLANG("skinname");
            $this->output .= new_col();
			$this->output .= GETLANG("delete");
			do
			{
				$this->output .= new_row(-1, "", "", "16");
				$this->output .= "<img src='{$rwdInfo->skinurl}/images/closed.gif'>";
				$this->output .= new_col();
				$this->output .= "<a href='admin.php?sid=$sid&area=skins&act=manage&editskin={$myrow['setid']}'>{$myrow['name']}</a>";
                $this->output .= new_col();
			    $this->output .= "[ <a href='admin.php?sid=$sid&area=skins&act=delete&id={$myrow['setid']}'>".GETLANG("delete")."</a> ]";
			} while ( $myrow = $DB->fetch_row() );
			$this->output .= end_table();
		}
		$this->output .= admin_foot();
	}
	
	function trim_newlines($code)
	{
		$code = preg_replace("/^\n{1,}/s", "", $code );
		$code = preg_replace("/\n{1,}$/s", "", $code );
		return $code;
	}
	
	// Booyakasha!
	function skins_wrap_php( $html, $after="", $before="" )
	{
		$html = $this->trim_newlines($html);
		
		// So we dont get whitespace breaking up if else statements and the like
		if ( ! trim($html) )
		{
			return $before."\n".$html.$after;
		}
		return $before."\n\$SHTML .= <<<RWS\n$html\nRWS;\n".$after;
	}
	
	function skins_convert_logic($html)
	{
		$html = preg_replace( "#(?:\s+?)?<if=[\"'](.+?)[\"']>(.+?)</if>#ise", "\$this->skins_parse_if('\\1', '\\2')", $html );
		$html = preg_replace( "#(?:\s+?)?<else if=[\"'](.+?)[\"']>(.+?)</if>#ise", "\$this->skins_parse_elseif('\\1', '\\2')", $html );
		$html = preg_replace( "#(?:\s+?)?<else>(.+?)</else>#ise", "\$this->skins_parse_else('\\1')", $html );
		
		return $html;
	}
	
	function skins_sql2php($setid, $class, $function, $incontent)
	{
		global $DB, $IN, $OUTPUT, $std, $version;
		
		$skin_dir = ROOT_PATH."/skins/skin".$setid;
		
		if ( ! is_readable($skin_dir) )
		{
			$std->error("Cannot write into '$skin_dir', please check the CHMOD value, and if needed, CHMOD to 0777 via FTP.");
			return 0;
		}
		
		$DB->query("SELECT * FROM `dl_templates` WHERE `setid`='{$setid}' AND `groupname`='{$class}'");
		
		$output  = "<?php \n\n// {$class}.php\n";
		$output .= "// Skin file auto generated by RW::Download {$version}\n";
		$output .= "// It is highly recommended you do NOT edit this file\n";
		$output .= "// Doing so could break the skinning engine and the script\n";
		$output .= "// This skin can be edited by using the Skin Controls in the Admin CP\n\n";

		$output .= "class {$class}\n";
		$output .= "{\n";
		
		while ( $myrow=$DB->fetch_row() )
		{
			if ( $myrow['funcname'] != $function )
			{
				$content = $myrow['content'];
			}
			else
				$content = $incontent;
				
			// Do custom codes
			$content = preg_replace('/{lang.([^}]+)}/i','{$rwdInfo->lang[\'$1\']}',$content);
			$content = preg_replace('/{#([^}]+)#}/i','{$data[\'$1\']}',$content);

			// Logic found
			if ( preg_match( "#<if=[\"'].+?[\"']>#si", $content ) )
			{
				$content = $this->skins_convert_logic($content);
				
				// Make sure we close the tags above and below logic! Parse errors bad
				$content = preg_replace( "#^(.+?)(//startif)#ise", "\$this->skins_wrap_php('\\1', '\\2');", $content );
				$content = preg_replace( "#(}//endif|}//endelse)(.+?)(//startif|else)#ise", "\$this->skins_wrap_php('\\2', '\\3', '\\1');", $content );
				
				if ( preg_match( "#^(.*)(}//endelse)(.+?)$#is", $content, $match ) )
				{
					if ( $match[1] and $match[2] and ( ! strstr( $match[3], "<<<RWS\n" ) ) )
						$content = preg_replace( "#^(.*}//endelse)(.+?)$#ise", "\$this->skins_wrap_php('\\2', '', '\\1');", $content );
				}
				
				if ( preg_match( "#^(.*)(}//endif)(.+?)$#is", $content, $match ) )
				{
					if ( $match[1] and $match[2] and ( ! strstr( $match[3], "<<<RWS\n" ) ) )
						$content = preg_replace( "#^(.*}//endif)(.+?)$#ise", "\$this->skins_wrap_php('\\2', '', '\\1');", $content );
				}
				
			}
			else
				$content = $this->skins_wrap_php($content);

			
				
			$output .= "function {$myrow['funcname']}(\$data=NULL)\n{\n";
			$output .= "global \$rwdInfo;\n";
			$output .= "//--START--//\n";
			$output .= $content;
			$output .= "//--END--//\n";
			$output .= "return \$SHTML;\n}\n\n";
		}
		$output .= "}\n\n?>\n";
		
		$fileName = $skin_dir."/".$class.".php";
		if ( $fp = fopen( $fileName, 'w' ) )
		{
			fwrite($fp, $output, strlen($output) );
			fclose($fp);
			return $output;
		}
		else
	    {
			$std->error(GETLANG("no_skin_files")."<br>".$fileName);
			return "";
	    }
		return $output;
	}
	
	function skins_php2sql($id)
	{
		global $rwdInfo, $DB, $std;
		
		$skin_dir = ROOT_PATH."/skins/skin".$id;
				
		if ( ! file_exists( $skin_dir ) )
		{
			$std->error(GETLANG("no_template"));
			return 0;
		}
		
		if ( ! is_readable($skin_dir) )
		{
			$std->error(GETLANG("no_skin_files")."<br>".$fileName);
			return 0;
		}
		
		if ( is_dir($skin_dir) )
		{
			if ( $handle = opendir($skin_dir) )
			{
				// Remove the old skin data
				$DB->query("DELETE FROM `dl_templates` WHERE `setid`='$id'");
				
				while (($filename = readdir($handle)) !== false)
				{
					if (($filename != ".") && ($filename != ".."))
					{
						if ( preg_match( "/\.php$/", $filename ) )
						{
							$name = preg_replace( "/^(\S+)\.(\S+)$/", "\\1", $filename );
							
							if ($FH = fopen($skin_dir."/".$filename, 'r') )
							{
								$fdata = fread( $FH, filesize($skin_dir."/".$filename) );
								fclose($FH);
							}
							else
							{
								$std->warning(GETLANG("couldnotread")."<br>".$filename);
								continue;
							}
							
							// Convert windows line breaks and strip unnecessary new lines
							$fdata = str_replace( "\r", "\n", $fdata );
							$fdata = str_replace( "\n\n", "\n", $fdata );
							
							if ( ! preg_match( "/\n/", $fdata ) )
							{
								$std->error(GETLANG("no_line_end")."<br>".$filename);
								continue;
							}
							
							$farray = explode( "\n", $fdata );
							
							$functions = array();
							$flag = 0;
							foreach($farray as $f)
							{
								if ( preg_match( "/^function\s*([\w\_]+)\s*\((.*)\)/i", $f, $matches ) )
								{
									$functions[$matches[1]] = '';
									$config[$matches[1]]    = $matches[2];
									$flag = $matches[1];
									continue;
								}
														
								if ($flag)
								{
									$functions[$flag] .= $f."\n";
									continue;
								}
								 
							}
							
							$final = "";
							$flag  = 0;
							
							foreach($functions as $fname => $ftext)
							{
								// Get the useful bit out
								preg_match( "#//--START--//(.+?)//--END--//#s", $ftext, $matches );
								
								//$content = preg_replace('/{lang.([^}]+)}/i','{$rwdInfo->lang[\'$1\']}',$content);
								$str = preg_replace("/\\\$data\['([^']+)'\]/i",'#$1#',$matches[1]);
								$str = preg_replace("/\\\$rwdInfo->lang\['([^']+)'\]/i",'lang.$1',$str);		
								//$str = preg_replace("/\\\$rwdInfo->([^']+)/i",'$2',$str);
								$code = preg_replace("/\\\$SHTML\s+?\.?= <<<RWS\n(.+?)\nRWS;\s?/si", '$1', $str );
								$code = trim($code);
								// FILTHY HACK
								if ( $code == "\$SHTML .= <<<RWS\nRWS;" )
									$code = "";
								if ( $code )
								{
									// Unconvert(?) the logic stuff first
									$code = preg_replace( "#else if\s+?\((.+?)\)\s+?{(.+?)}//endif(\n)?#ise", "\$this->skins_unparse_if('\\1', '\\2', 'else if')", $code );
									$code = preg_replace( "#//startif\nif\s+?\((.+?)\)\s+?{(.+?)}//endif(\n)?#ise", "\$this->skins_unparse_if('\\1', '\\2', 'if')", $code );
									$code = preg_replace( "#else\s+?{(.+?)}//endelse(\n)?#ise", "\$this->skins_unparse_else( '\\1' )", $code );
									
									$code = str_replace( "//startif\n", "\n", $code );
									$code = preg_replace( "#(</if>|</else>)\s+?(<if|<else)#is", "\\1\n\\2", $code );
								}
								$insert = array("setid" => $id,
												"groupname" => $name,
												"content" => addslashes($code),
												"funcname" => $fname);
											
								$DB->insert($insert, "dl_templates");
							}
							
							//reset the array
							$functions = array();
						} 
					} 
				} 
				
				closedir($handle);
				
			}
			else
			{
				$std->error(GETLANG("no_skin_dir")."<br>".$skin_dir);
				return 0;
			}
		}
		else
		{
			$std->error($skin_dir." ".GETLANG("not_a_dir"));
			return 0;
		}
		
		$this->output .= GETLANG("rebuild_done")."<br>";
		return 1;
	}
	
	function skins_parse_if( $code, $html )
	{
		// TODO: AND OR logic?
		// Get rid of curly braces
		$code = preg_replace('/{([^}]+)}/i','$1',$code);
		// Trim whitespace
		$html = trim($html);
		return "\n//startif\nif ( $code )\n{\n\$SHTML .= <<<RWS\n$html\nRWS;\n}//endif\n";
	}
	
	function skins_parse_elseif( $code, $html )
	{
		// Trim whitespace
		$html = trim($html);
		return "\nelse if ( $code )\n{\n\$SHTML .= <<<RWS\n$html\nRWS;\n}//endif\n";
	}

	function skins_parse_else( $html )
	{
		// Trim whitespace
		$html = trim($html);
		return "\nelse\n{\n\$SHTML .= <<<RWS\n$html\nRWS;\n}//endelse\n";
	}
	
	// Unparse if's and if else's
	function skins_unparse_if( $code, $php, $start='if' )
	{
		$code = trim($code);
		$code = preg_replace('/#([^}]+)#/i','{#$1#}',$code);
		return "\n<".$start."=\"".$code."\">\n".trim($php)."\n</if>\n";
	}
	
	function skins_unparse_else( $php )
	{
		return "<else>\n".trim($php)."\n</else>\n";
	
	}
}

?>
