<?php
/*********************************************************
* Name: lang_download.php
* Author: RW::Download 4.0
* Contact: realworld@blazefans.com
* Description: Language variables
* Version: 4.00
*********************************************************/
$lang = array(

'noreferer' => "No refering URL was found. The admin has chosen not to allow downloads from users with no refering urls. This is usually because you are using a firewall that blocks this URL. Disabling or closing your firewall will often solve this problem and allow you to download files.",
'invalidreferer' => "LEECH ALERT: We have determined that the website you have come from is directly linking to our files. You are only allowed to download files from our website. Please return to our home page to download this file.",
)

?>