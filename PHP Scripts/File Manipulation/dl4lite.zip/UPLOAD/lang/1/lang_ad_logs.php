<?php
/*********************************************************
* Name: lang_ad_files.php
* Author: RW::Download 4.0
* Contact: realworld@blazefans.com
* Description: Language variables
* Version: 4.00
*********************************************************/
$lang = array(

'log_file' => "File",
'log_refer' => "Referer",
'log_time' => "Time",
'log_ip' => "IP",

)

?>