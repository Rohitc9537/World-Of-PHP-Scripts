<?php
/*********************************************************
* Name: lang_login.php
* Author: RW::Download 4.0
* Contact: realworld@blazefans.com
* Description: Language variables
* Version: 4.00
*********************************************************/
$lang = array(

'login_ok' => "Thankyou for logging in. Please wait while we redirect you.",
'logout_ok' => "Your cookies have been cleared and you are now logged out. Please wait while we redirect you.",
'stayloggedin' => "Stay Logged In",
'thankyou' => "Thankyou for logging in. Please wait while we redirect you to ",
'cleared' => "Your cookies have been cleared and you are now logged out. Please wait while we redirect you.", 
)

?>