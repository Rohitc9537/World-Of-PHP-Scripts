<?php
/*********************************************************
* Name: lang_ad_main.php
* Author: RW::Download 4.0
* Contact: realworld@blazefans.com
* Description: Language variables
* Version: 4.00
*********************************************************/
$lang = array(

'rwdownload' => "RW::Download",
'acp' => "Admin Control Panel",
'stats_newdls' => "Stats - Latest Downloads",
'stats_mostdl' => "Stats - Most Downloaded",
'stats_topdls' => "Stats - Top Rated Downloads",
'news' => "News",


)

?>