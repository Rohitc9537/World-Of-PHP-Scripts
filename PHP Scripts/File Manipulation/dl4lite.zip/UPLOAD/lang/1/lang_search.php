<?php
/*********************************************************
* Name: lang_search.php
* Author: RW::Download 4.0
* Contact: realworld@blazefans.com
* Description: Language variables
* Version: 4.00
*********************************************************/
$lang = array(

'search_terms' => "Search Terms",
'search_results' => "Search Results",
)

?>