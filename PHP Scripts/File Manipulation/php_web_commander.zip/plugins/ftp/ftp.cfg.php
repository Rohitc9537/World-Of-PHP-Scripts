<?php

//
// +----------------------------------------------------------------------+
// | Web Manager                                                          |
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 Protung Dragos (www.protung.ro)                   |
// +----------------------------------------------------------------------+
// +----------------------------------------------------------------------+
// |   filename             : files.cfg.php                               |
// |   begin                : 30 07 2004                                  |
// |   copyright            : (C) 2004 Dragos Protung                     |
// |   email                : dragos@protung.ro                           |
// |   lastedit             : 30/07/2004 14:52                            |
// |                                                                      |
// |                                                                      |
// +----------------------------------------------------------------------+
// | Author: Protung Dragos <dragos@protung.ro>                           |
// +----------------------------------------------------------------------+
//


$PLUGIN_NAME_LONG     = 'FTP Client';
$PLUGIN_NAME_SHORT    = 'ftp';
$INCLUDE              = true;

$START_SERVER         = 'localhost';
$START_SERVER_PORT    = 21;
$START_SERVER_TIMEOUT = 1;
$START_SERVER_USER    = 'dragos';
$START_SERVER_PASS    = 'dragos';
$START_DIR            = 'test'


?>