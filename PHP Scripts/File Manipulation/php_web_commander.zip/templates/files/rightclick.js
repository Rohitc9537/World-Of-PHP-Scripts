var ie5 =  document.all && document.getElementById;
var ns6 = !document.all && document.getElementById;

if (ie5 || ns6) {

	var menuobj=document.getElementById("right_click_menu");
}

function show_right_click_menu(e) {

	//Find out how close the mouse is to the corner of the window
	var rightedge=ie5? document.body.clientWidth-event.clientX : window.innerWidth-e.clientX
	var bottomedge=ie5? document.body.clientHeight-event.clientY : window.innerHeight-e.clientY

	//if the horizontal distance isn't enough to accomodate the width of the context menu
	if (rightedge<menuobj.offsetWidth)
	//move the horizontal position of the menu to the left by it's width
	menuobj.style.left=ie5? document.body.scrollLeft+event.clientX-menuobj.offsetWidth : window.pageXOffset+e.clientX-menuobj.offsetWidth
	else
	//position the horizontal position of the menu where the mouse was clicked
	menuobj.style.left=ie5? document.body.scrollLeft+event.clientX : window.pageXOffset+e.clientX

	//same concept with the vertical position
	if (bottomedge<menuobj.offsetHeight)
	menuobj.style.top=ie5? document.body.scrollTop+event.clientY-menuobj.offsetHeight : window.pageYOffset+e.clientY-menuobj.offsetHeight
	else
	menuobj.style.top=ie5? document.body.scrollTop+event.clientY : window.pageYOffset+e.clientY

	menuobj.style.visibility="visible"
	return false
}

function hide_right_click_menu(){

	menuobj.style.visibility="hidden";
}



if (ie5 || ns6) {

	menuobj.style.display = '';
	document.oncontextmenu = show_right_click_menu;
	document.onclick = hide_right_click_menu;
}