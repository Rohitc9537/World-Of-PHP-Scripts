<?php
/*
 * files.php - Version 15/Jun/2002
 *
 * Copyright (c) 2000-2002 Jochen Kupperschmidt <jochen@kupperschmidt.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */


# configuration
$ftp   = 'ftp://ftp.example.com/';
$local = '/ext/ftp/';


# getting the right subdir
if (isset($subdir))
{
    parse_str($QUERY_STRING);
    if (is_dir($local . $subdir))
        $subdir .= '/';
    else
        $subdir = '';
}
else $subdir = '';
?>
<html>
  <head>
    <title><?= $ftp . $subdir; ?></title>
    <style type="text/css">
    <!--
      body              { color: #000000; background-color: #ffffff; }
      body, th, td	{ font-family: arial; font-size: 10pt; }

      a:link, a:visited	{ color: #3377aa; text-decoration: none; }
      a:active, a:hover	{ color: #3377aa; text-decoration: underline; }

      table.files       { color: #444444;
                          background-color: #eeeeee;
                          border: 2px solid #3377aa;
                          border-spacing: 1px;
                          width: 100%;
                        }
    -->
    </style>
  </head>
<body>

<div align="center">



<br>

<table width="560" cellspacing="2" cellpadding="2" border="0">
  <tr>
    <td>
      <!-- path -->
      <table class="files">
        <tr>
          <td><b><?= filesPath(); ?></b></td>
        </tr>
      </table>
      <!-- path -->
    </td>
  </tr>
  <tr>
    <td>
      <!-- files -->
      <table class="files" cellpadding="0">
<? filesList(); ?>
      </table>
      <!-- files -->
    </td>
  </tr>
  <tr>
    <td>
      <!-- copyright -->
      <table class="files">
        <tr>
          <td style="font-size: 8pt; text-align: center">files.php - Copyright &copy; 2000-2001 Jochen Kupperschmidt aka Y0Gi</td>
        </tr>
      </table>
      <!-- copyright -->
    </td>
  </tr>
</table>

<br>&nbsp;



</div>

</body>
</html>
<?
/* ------------ functions ------------ */

function filesPath()
{
    global $SCRIPT_NAME, $ftp, $subdir;
    $path = '<a href="' . $SCRIPT_NAME . '">' . substr($ftp, 0, -1) . '</a> / ';
    if ($subdir != '')
    {
        $array = explode('/', substr($subdir, 0, -1));
        for ($i = 0; $i < count($array); $i++)
        {
            $link = $url_bak . $array[$i];
            $path .= '<a href="' . $SCRIPT_NAME . '?subdir=' . $link . '">' . $array[$i] . '</a> / ';
            $url_bak .= $array[$i] . '/';
        }
    }
    return $path;
}


function filesList()
{
    global $SCRIPT_NAME, $ftp, $subdir, $local;
    $path = $local . $subdir;

    $dirs  = array();
    $files = array();

    $dir = dir($path);
    while ($file = $dir->read())
        if (substr($file, 0, 1) != '.')
            if (is_dir($path . $file))
                array_push($dirs, $file);
            else
                array_push($files, $file);
    $dir->close();

    sort($dirs);
    sort($files);

    for ($i = 0; $i < count($dirs); $i++)
    {
        $link = $subdir . $dirs[$i];
        echo "  <tr>\n";
        echo '    <td><a href="' . $SCRIPT_NAME . '?subdir=' . rawurlencode($link) . '">' . icon('dir') . $dirs[$i] . "</a></td>\n";
        echo '    <td align="right">&lt;dir&gt;' . "</td>\n";
        echo "  </tr>\n";
    }
    for ($i = 0; $i < count($files); $i++)
    {
        $link = $subdir . $files[$i];
        echo "  <tr>\n";
        echo '    <td><a href="' . $ftp . rawurlencode($link) . '">' . icon($files[$i]) . $files[$i] . "</a></td>\n";
        echo '    <td align="right">' . number_format(filesize($path.$files[$i]), 0, ',', '.') . "&nbsp;bytes</td>\n";
        echo "  </tr>\n";
    }
}


function icon($file)
{
    $icons = array(
        'dir'  => 'dir',
        'ace'  => 'arc',
        'aif'  => 'qt',
        'aiff' => 'qt',
        'arj'  => 'arc',
        'avi'  => 'avi',
        'bat'  => 'dos',
        'bmp'  => 'bmp',
        'bz2'  => 'arc',
        'cfg'  => 'txt',
        'com'  => 'dos',
        'conf' => 'txt',
        'css'  => 'txt',
        'divx' => 'divx',
        'diz'  => 'txt',
        'doc'  => 'doc',
        'eps'  => 'ps',
        'exe'  => 'exe',
        'fla'  => 'flash',
        'fon'  => 'font',
        'gif'  => 'gif',
        'gz'   => 'arc',
        'ini'  => 'txt',
        'iso'  => 'cd',
        'htm'  => 'txt',
        'html' => 'txt',
        'jar'  => 'java',
        'java' => 'java',
        'jpeg' => 'jpeg',
        'jpg'  => 'jpeg',
        'lzh'  => 'arc',
        'm3u'  => 'mp3',
        'mid'  => 'mid',
        'mp3'  => 'mp3',
        'mpeg' => 'mpeg',
        'mpg'  => 'mpeg',
        'mov'  => 'qt',
        'nfo'  => 'txt',
        'ogg'  => 'mp3',
        'pcx'  => 'pcx',
        'pdf'  => 'pdf',
        'php'  => 'php',
        'pls'  => 'mp3',
        'png'  => 'png',
        'ppt'  => 'ppt',
        'ps'   => 'ps',
        'py'   => 'py',
        'pyc'  => 'py',
        'ra'   => 'real',
        'rar'  => 'rar',
        'rm'   => 'real',
        'rtf'  => 'doc',
        'sql'  => 'txt',
        'swf'  => 'flash',
        'tar'  => 'arc',
        'tga'  => 'tga',
        'tgz'  => 'arc',
        'tif'  => 'tiff',
        'tiff' => 'tiff',
        'ttf'  => 'font',
        'txt'  => 'txt',
        'wma'  => 'wmv',
        'wmf'  => 'wmf',
        'wmv'  => 'wmv',
        'xls'  => 'xls',
        'xml'  => 'txt',
        'zip'  => 'arc'
    );

    if ($file == 'dir') $file = '.dir';
    $ext = substr($file, strrpos($file, '.')+1);
    if (array_key_exists($ext, $icons))
        $icon = $icons[$ext];
    else
        $icon = 'unknown';

    return '<img src="icon_' . $icon . '.png" width="16" height="16" border="0" align="texttop" vspace="0"> ';
}

/* ------------ functions ------------ */
?>
