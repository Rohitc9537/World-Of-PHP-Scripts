<?php

echo "
<table width=\"100%\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" bgcolor=\"#E9EBF4\">
	<tr>
		<td><b>Willkommen</b></td>
	</tr>
</table>
<br>
Klicken Sie auf eine Kategorie auf der linken Seite um deren Inhalt anzuzeigen..
<br><br>
";

?>