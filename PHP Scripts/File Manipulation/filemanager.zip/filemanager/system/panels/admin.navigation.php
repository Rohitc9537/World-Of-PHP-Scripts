<?php

echo "
<div id=\"navigationAdmin\">
	<a class=\"navigationAdmin\" href=\"admin.php?action=main.display\">&nbsp;&raquo;&nbsp;Home</a>
	<a class=\"navigationAdmin\" href=\"admin.php?action=settings.display\">&nbsp;&raquo;&nbsp;Settings</a>
	<a class=\"navigationAdmin\" href=\"admin.php?action=categorys.display\">&nbsp;&raquo;&nbsp;Kategorien</a>
	<a class=\"navigationAdmin\" href=\"admin.php?action=files.display\">&nbsp;&raquo;&nbsp;Dateien</a>
	<a class=\"navigationAdmin\" href=\"admin.php?action=groups.display\">&nbsp;&raquo;&nbsp;Gruppen</a>
	<a class=\"navigationAdmin\" href=\"admin.php?action=users.display\">&nbsp;&raquo;&nbsp;Benutzer</a>
	<a class=\"navigationAdmin\" href=\"index.php\">&nbsp;&raquo;&nbsp;Zur Website</a>
	<a class=\"navigationAdmin\" href=\"process.php?action=user.checkout\">&nbsp;&raquo;&nbsp;Logout</a>
</div>
";

?>