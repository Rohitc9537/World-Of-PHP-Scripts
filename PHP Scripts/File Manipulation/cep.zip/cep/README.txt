--------------------------------------------------------------------------------
CJG EXPLORER PRO v3.2 - WEB FILE MANAGEMENT - Copyright (C) 2003 CARLOS GUERLLOY
CJGSOFT Software
cjgexplorerpro@guerlloy.com
guerlloy@hotmail.com
carlos@weinstein.com.ar
Buenos Aires, Argentina
--------------------------------------------------------------------------------
This program is free software; you can  redistribute it and/or  modify it  under
the terms   of the   GNU General   Public License   as published   by the   Free
Software Foundation; either  version 2   of the  License, or  (at  your  option)
any  later version. This program  is  distributed in  the hope that  it  will be
useful,  but  WITHOUT  ANY  WARRANTY;  without  even  the   implied  warranty of
MERCHANTABILITY  or FITNESS  FOR A  PARTICULAR  PURPOSE.  See the  GNU   General
Public License for   more details. You  should have received  a copy of  the GNU
General Public License along  with this  program; if   not, write  to the   Free
Software  Foundation, Inc.,  59 Temple Place,  Suite 330, Boston,  MA 02111-1307
USA
--------------------------------------------------------------------------------

Any suggestions, comments or questions are welcome.
Feel free to write me to cjgexplorerpro@guerlloy.com
-Carlos


Instructions to install
-----------------------
1) Unpack and copy the files (preserving directories) to the desired folder.
2) Examine and (if necessary) modify the config.php file (config is self-explanatory).
3) Ok!

Php prerrequsites
-----------------
The zlib library should be enabled (for zip and tgz archiving)

Manual and help
---------------
Use help.php

Translation utility
-------------------
Use trans.php
