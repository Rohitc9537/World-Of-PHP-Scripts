<?php

print "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">";

print "<html>";
 print "<head>";
  print "<title>PHPFM ".VERSION." - a file manager written in PHP</title>";
  print "<link rel='stylesheet' href='incl/phpfm.css' type='text/css'>";
 print "</head>";
 print "<body link='#0000FF' alink='#0000FF' vlink='#0000FF' bgcolor='#FFFFFF'>";
  print "<center>";
  print "<table class='top' cellpadding=0 cellspacing=0>";
   print "<tr>";
    print "<td align='center'><font class='headline'>PHPFM ".VERSION."</font></td>";
   print "</tr>";
  print "</table><br />";

?>