<?php
   header('Content-Type: application/x-javascript');
   $engine_path = "../../../"; 
   include ($engine_path . "lib.inc.php"); // CONTENIDO
   include $_ENGINE['eng_dir'].'admin/includes/spaw/config/spaw_control.config.php';

   include $_ENGINE['eng_dir'].'admin/includes/spaw/class/script.js.php';

?>

