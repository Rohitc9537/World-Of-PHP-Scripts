<?php
/**
*
* Sample file #1 for pdfTag
*
**/
require_once("lib/pdfTag.php");

$srcXML = 'xml/sample1.xml';
$pdf = new pdfTag();
$pdf->readFromFile($srcXML);
/* decide if only generate or generate and show */
if(!isset($_GET["show"])) {
        $pdf->printDebug = true;
        $pdf->pdfProfile = true;
        $pdf->generatePDF();
?>
<center>
<a href="sample1.php?show">click here to display/download</a>
</center>
<?php
} else {
        $pdf->generatePDF();
        $pdf->dumpPDF();
}
?>
