<?php
/**
*
* Sample file #2 for pdfTag
*
* first only generating, second genrating and displaying the pdf in the user's browser
*
**/
require_once("lib/pdfTag.php");

$srcXML = 'xml/sample2.xml';
$pdf = new pdfTag();
$pdf->readFromFile($srcXML);
$pdf->setParser('SAX');

/* decide if only generate or generate and show */
if( !isset($_GET["show"])):
	$pdf->Debug = true;
	$pdf->pdfProfile = true;
	$pdf->generatePDF();
?>
<center>
<a href="sample2.php?show">click here to display/download</a>
</center>
<?php
else:
	$pdf->generatePDF();
	$pdf->dumpPDF();
endif;
?>
