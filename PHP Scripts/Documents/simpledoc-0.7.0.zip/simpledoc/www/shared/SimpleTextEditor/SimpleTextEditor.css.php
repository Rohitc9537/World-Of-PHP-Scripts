<?php
require '../../config.php';
header('Content-type: text/css');
?>
.ste .bar { background: #ECE9D8; padding: 3px; border: #ACA899 1px; border-style: solid solid none solid; }
.ste .frame { border: 1px solid; border-color: #716F64 #ECE9D8 #ECE9D8 #716F64; }
.ste .frame iframe { width: <?php echo $CONFIG['editor-width']; ?>px; height: <?php echo $CONFIG['editor-height']; ?>px; }
.ste img { border: 0; }
.ste .button { padding: 1px; border: #ECE9D8 1px solid; }
.ste .button-hover { padding: 1px; border: 1px solid; border-color: #ffffff #ACA899 #ACA899 #ffffff; }
.ste .button-click { padding: 1px; border: 1px solid; border-color: #ACA899 #ffffff #ffffff #ACA899; }
.ste .separator { width: 0px; height: 18px; border-left: #aca899 1px solid; border-right: #ffffff 1px solid; margin: 0 5px; }
.ste .source { padding-top: 5px; }