<?php
$CONFIG['username'] = 'admin';
$CONFIG['password'] = 'admin';
$CONFIG['encoding'] = 'iso-8859-1';
$CONFIG['editor-width'] = '600';
$CONFIG['editor-height'] = '350';
$CONFIG['publish_dir'] = 'publish';
?>