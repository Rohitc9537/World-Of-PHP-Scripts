<html>
<head>
  <title>Testimonial Rotator</title>
  <style>
    BODY
    {
      background: whitesmoke;
      font-family: Verdana;
      font-size: 12px;
    }
    TD
    {
      font-size: 12px;
    }
    A,A:active,A:visited
    {
      color: blue;
      text-decoration: none;
    }
    A:hover
    {
      text-decoration: underline;
      color: red;
    }
  </style>
</head>
<body>


<center><table width="750" cellspacing="0" cellpadding="0" border="0"><tr><td bgcolor="#000000">
<center><table width="750" cellspacing="1" cellpadding="0" border="0"><tr><td bgcolor="#FFFFFF">

<table width="730" align="center"><tr><td>

<script type="text/javascript"><!--
google_ad_client = "pub-4433979169039312";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_channel ="2237638589";
google_color_border = "FFFFFF";
google_color_bg = "FFFFFF";
google_color_link = "0000FF";
google_color_url = "FFFFFF";
google_color_text = "000000";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

<center><br><font size="5" face="tahoma" color="#FF0000"><b>Testimonial Rotator</b></font></center><p>


(<a href="index.html">Home Page</a>) (<a href="quotes.php?new=1">Submit A Testimonial</a>)<p>