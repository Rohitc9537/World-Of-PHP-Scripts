<?php

// HTML which will be printed infront of each quote
$quote_html_start="<i>";

// HTML that is printed after each quote
$quote_html_end="";

// HTML that comes right after the quote text (and before the name of the person who submitted that quote)
$quote_html_middle="</i> - ";

// HTML that will seperate the name of a person from their company name (if necessary)
$quote_html_sep=" from ";

// HTML that will seperate each quote (if more than one quote is displayed)
$quote_html_sep2="<p>";

?>