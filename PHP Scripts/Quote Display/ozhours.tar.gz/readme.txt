*******************************************************
* author: paul radford          owner: ozscripts.com  *
*                                                     *
* script name: ozhours          version: 1.0          *
*                                                     *
*******************************************************

description:

ozhours is used to show visually in either text or an image if you
office is actually open.

installation: 
to install place in directory and change file called 

  open_closed.ini.php 

there are further directions in this file.

usage:
to call the script as text you will need to use a php include.

  <?php include('/path/to/script/open.php'); ?>

or as an image you can use a img tag call

  <img src='/url/to/script/open.php'>

