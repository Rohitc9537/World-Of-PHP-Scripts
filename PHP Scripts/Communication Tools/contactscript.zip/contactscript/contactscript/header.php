<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
</head>
<body
 style="color: rgb(255, 255, 255); background-color: rgb(0, 0, 0);"
 alink="#ffffff" link="#ffffff" vlink="#fffff0">
<center style="color: rgb(255, 255, 255);"><big><big><big><big><span
 style="font-weight: bold;"><img
 style="width: 750px; height: 83px;" alt="logo"
 src="logo.gif"></span></big></big></big></big><br>
&nbsp; script that you enter your myspace url and ms user id <br>
it creates A code so that you can place a contact box on your website!!!
<br><br><font size="1"><b>* THIS SCRIPT TAKES YOUR URL AND ID & PUTS IT INTO A DATABASE THIS IS ONLY USED TO KEEP TRACK OF WHO IS USEING THIS SCRIPT <br>THIS INFO WILL NOT BE SOLD!!!<br></b>
</center></font>