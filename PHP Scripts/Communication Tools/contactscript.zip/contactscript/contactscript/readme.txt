*********************************************************************************   
*********************************************************************************   
**  a script that you enter your myspace url and ms user idit creates a code   **
**          so that users can place a contact box on there website             **
**      Copyright (C) 2005  <Mark Beard markbeardwebdesign@gmail.com>          **
**                                                                             **
**     This program is free software; you can redistribute it and/or modify    **  
**     it under the terms of the GNU General Public License as published by    **  
**       the Free Software Foundation; either version 2 of the License, or     **  
**                     (at your option) any later version.                     **  
**                                                                             **  
**         This program is distributed in the hope that it will be useful,     **  
**         but WITHOUT ANY WARRANTY; without even the implied warranty of      **  
**          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the      **  
**              GNU General Public License for more details.                   **  
**                                                                             **  
**        You should have received a copy of the GNU General Public License    **  
**        along with this program; if not, write to the Free Software          **  
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  **   
*********************************************************************************
*********************************************************************************

Thank you for downloading my script.

to install 
1.Unzip the file

2.Open the config.php file and edit your database info

3.save and close

4.Open login.php 

5.Find $_POST['txtUserId'] === 'USERNAME' && 
$_POST['txtPassword'] === 'PASSWORD') 

6.edit USERNAME and PASSWORD

7.save and close

8.upload all the files 
 
9.Run install.php

10.Delete install.php

and thats it!

*Bugs*
Not Known at this time

*Version*

v.1.0 
This version was basicly a bata. it took the info and made the script but you had to right click and viw source

v.1.0.2
This version was basicly a bata. it took the info and made the script

v.2.0.0
Out of bata. now uses a database to keep track of visitors. Released under the name MySpaceContactScript.tk

v.2.0.1
there was minor changed to the script. mostly update the the files with the new name of the project. Plese view press.txt
 for more info

v.3.0.0
Admin Area Compleately Redone 