<?
include "html_header.php";

echo "
    <p><font size=+1 color=red>You have been logged out!</font>
    <p>Click <b><a href=index.php target=_top>here</a></b> to return to login page
";

include "html_footer.php";
?>