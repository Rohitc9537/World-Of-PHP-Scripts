<tr><td width=100%>
<table width=100% cellpadding=0 cellspacing=0 border=0>
<tr>
    <td width=200 valign=top nowrap>
	<? include "fr_left.php"; ?>
    </td>
    <td width=100% valign=top>
	<? include "fr_right.php"; ?>
    </td>
</tr>
</table>

</td></tr>