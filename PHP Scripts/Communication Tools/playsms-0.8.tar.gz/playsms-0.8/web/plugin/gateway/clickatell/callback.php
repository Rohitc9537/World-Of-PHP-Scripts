<?
chdir("../../../");
include "init.php";
include "$apps_path[libs]/function.php";
chdir("plugin/gateway/clickatell/");

$cb_from = $_GET[from];
$cb_to = $_GET[to];
$cb_timestamp = $_GET[timestamp];
$cb_text = $_GET[text];
$cb_status = $_GET[status];
$cb_charge = $_GET[charge];
$cb_apimsgid = $_GET[apiMsgId];

/*
$fc = "$cb_from - $cb_to - $cb_timestamp - $cb_text - $cb_status - $cb_charge - $cb_apimsgid\n";
$fn = "/tmp/clktl_callback";
umask(0);
$fd = fopen($fn,"a+");
fputs($fd,$fc);
fclose($fd);
*/

if ($cb_datetime && $cb_from && $cb_text)
{
    $cb_datetime = date($datetime_format, $cb_timestamp);
    $sms_datetime = trim($cb_datetime);
    $sms_sender = trim($cb_from);
    $message = trim($cb_text);
    $array_target_code = explode(" ",$message);
    $target_code = strtoupper(trim($array_target_code[0]));
    $message = $array_target_code[1];
    for ($i=2;$i<count($array_target_code);$i++)
    {
	$message .= " ".$array_target_code[$i];
    }
    // collected:
    // $sms_datetime, $sms_sender, $target_code, $message
    setsmsincomingaction($sms_datetime,$sms_sender,$target_code,$message);
}

if ($cb_status && $cb_apimsgid)
{
    $db_query = "
	SELECT playsms_tblSMSOutgoing.smslog_id AS smslog_id,playsms_tblSMSOutgoing.uid AS uid 
	FROM playsms_tblSMSOutgoing,playsms_gwmodClickatell_apidata
	WHERE 
	    playsms_tblSMSOutgoing.smslog_id=playsms_gwmodClickatell_apidata.smslog_id AND 
	    playsms_gwmodClickatell_apidata.apimsgid='$cb_apimsgid'
    ";
    $db_result = dba_query($db_query);
    $db_row = dba_fetch_array($db_result);
    $uid = $db_row[uid];
    $smslog_id = $db_row[smslog_id];
    if ($uid && $smslog_id)
    {
	$c_sms_status = 0;
	switch ($cb_status)
	{
	    case "001":
	    case "002":
	    case "011": $c_sms_status = 0; break; // pending
	    case "003":
	    case "008": $c_sms_status = 1; break; // sent
	    case "005":
	    case "006":
	    case "007":
	    case "009":
	    case "010":
	    case "012": $c_sms_status = 2; break; // failed
	    case "004": $c_sms_status = 3; break; // delivered
	}
	$c_sms_credit = ceil($cb_charge);
	// pending
	$p_status = 0;
	if ($c_sms_status)
	{
	    $p_status = $c_sms_status;
	}
	setsmsdeliverystatus($smslog_id,$uid,$p_status);
    }
}

?>