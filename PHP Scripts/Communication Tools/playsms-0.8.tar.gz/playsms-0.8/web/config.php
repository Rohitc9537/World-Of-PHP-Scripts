<?

// PEAR compatible database engine: 
// dbase, fbsql, interbase, informix, msql, mssql, mysql, oci8, odbc, pgsql, sqlite, sybase 
// note that authors can only play with MySQL :)
$db_param[type]	= "mysql";	// database engine
$db_param[host]	= "localhost";	// database host/server
$db_param[port]	= "";		// database port
$db_param[user]	= "root";	// database username
$db_param[pass]	= "";		// database password
$db_param[name]	= "playsms";	// database name

// base application directory
$apps_path[base]	= "/home/playsms/public_html";

// libraries directory
$apps_path[libs]	= "$apps_path[base]/lib";

// plugins directory
$apps_path[plug]	= "$apps_path[base]/plugin";

// includes directories
$apps_path[incs]	= "$apps_path[base]/inc";

// SMTP sendmail
define("_SMTP_RELM_","");
define("_SMTP_USER_","");
define("_SMTP_PASS_","");
define("_SMTP_HOST_","localhost");
define("_SMTP_PORT_","25");

// SMS command security parameter
$feat_command_path[bin]	= $apps_path[base]."/bin";

?>