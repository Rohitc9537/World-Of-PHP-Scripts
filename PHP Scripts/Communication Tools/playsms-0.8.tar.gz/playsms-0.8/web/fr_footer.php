<? 
include "init.php"; 
include "html_header.php";
?>

<table width=100% cellpadding=0 cellspacing=0 border=0>
<tr>
    <td width=100%>
    <center><?=$footer_title?></center>
    </td>
</tr>
<table>

<?
include "html_footer.php";
?>
