<?
include "init.php";
include "$apps_path[libs]/function.php";

forcelogout();
?>