<?
$COM_LANG['header'] = "Comments";
$COM_LANG['no_comments_yet'] = "No comments yet";
$COM_LANG['Name'] = "Name";
$COM_LANG['r_disc_name'] = "Field 'Name' must be not empty";
$COM_LANG['E-mail'] = "Email";
$COM_LANG['Notify'] = "Notify me about new comments on this page";
$COM_LANG['Dont_show_email'] = "Hide my email";
$COM_LANG['Text'] = "Text";
$COM_LANG['r_disc_text'] = "Field 'Text' must be not empty";
$COM_LANG['Submit'] = "Submit";
$COM_LANG['not_allowed'] = "You are not allowed to post comments here";

$COM_LANG['months'] = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");

$COM_LANG['email_new_comment'] = "New comment on the page";
$COM_LANG['email_from'] = "From";
$COM_LANG['email_to_unsubscribe'] = "If you don't want to receive emails about new comments on this page use this link:";

$COM_LANG['unsubscribed'] = "You've been unsubscribed"; 
$COM_LANG['not_unsubscribed'] = "You are not subscribed"; 

$COM_LANG['admin_panel_name'] = "Comments admin panel";

?>