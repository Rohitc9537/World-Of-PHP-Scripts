<?
print<<<EOF
<p><a href="{$COM_CONF['admin_script_url']}">Home</a> | <a href="{$COM_CONF['admin_script_url']}?action=bannedlist">Banned IPs</a> | <a href="{$COM_CONF['admin_script_url']}?action=logout">Logout</a> </p>
EOF;
?>