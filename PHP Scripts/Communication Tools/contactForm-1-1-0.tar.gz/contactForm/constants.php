<?php
/* Constants */
$siteName   = "example.com"; // The name of your site (e.g. example.com)
$scriptName = "index.php"; // The filename of this script.
$gd_version = true; // True if you are using GD lib +2.0, false if you are using a previous version.
$captcha = 2;

/* Maximum Lengths */
$maxSubject  = 1000;     // The maximum subject length.
$maxMessage  = 10000;    // The maximum message length.
$maxName     = 500;     // The maximum from name length.
$maxAddress  = 500;     // The maximum from address length.
$maxAttempts = 20;      // The maximum number of bad attampts.
?>
