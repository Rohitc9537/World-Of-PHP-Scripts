Contact Form
============

About
-----
This "Contact Us" page for your website allows your users to leave you feedback. 
It uses PHP so send the information to you per e-mail.

It is extremely easy to use. Simply upload the contact.php file and configure 
your e-mail address.

The HTML and PHP code is easy to read, allowing you to change the layout and 
expand the script to your liking.

Installation
------------
1) Open the contact.php file and set your e-mail address in: 
   define("kContactEmail","your@email.com");
2) Upload the contact.php file to your website
3) Test is using http://www.yoursite.com/contact.php

-------------------------------
Feaser LLC
3430 E. Jefferson, #143
Detroit, MI 48207
Ph. (877) 293-1452
Fx. (877) 852-0523
Em. info@feaser.com
Wb. http://webdesign.feaser.com
-------------------------------
