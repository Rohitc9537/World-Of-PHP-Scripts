<div id="footer">
     <span>Copyright &copy; <a target="_new" href="http://www.xeweb.net" title="Visit XEWeb">XEWeb</a> 2005. All rights reserved.
     <br /><a target="_new" href="http://flashlight.xeweb.net" title="Visit Flashlight Homepage">Flashlight Free Edition</a> v<?=$ver?> used by <a target="_new" href="<?=$company_url?>" title="Visit <?=$company_name?>"><?=$company_name?></a>.</span>
</div>

</div>
</body>
</html>
<? mysql_close(); ?>