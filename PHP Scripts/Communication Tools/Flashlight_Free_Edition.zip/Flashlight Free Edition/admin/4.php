<div id="textbox" align="center">
<form name="search" action="admin.php?action=u4" method="post" onSubmit="return validateID(document.search.id.value)">
<b>Search for a User</b><br /><br />
By User ID:<br /><input type="text" name="id" size="4"><br /><br />
By First Name:<br /><input type="text" name="first" size="20"><br /><br />
By Last Name:<br /><input type="text" name="last" size="20"><br /><br />
<input type="submit" value="Search">
</div>