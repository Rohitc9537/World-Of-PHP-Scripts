<?
if ($page=="home") include "home.php";
if ($page=="e-post") include "e-post/e-post.php";
if ($page=="e-open") include "e-post/e-open.php";
if ($page=="e-new") include "e-post/e-new.php";
if ($page=="reg") include "register.php";
if ($page=="pref") include "preferences.php";
if ($page=="users") include "users.php";
if ($page=="friends") include "friends.php";
?>
