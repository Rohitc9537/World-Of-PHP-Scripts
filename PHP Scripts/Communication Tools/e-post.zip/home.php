<table cellpadding="5" border="0" cellspacing="0" height="750">
<tr>
<td valign="top">
<h3>Welcome to e-post!</h3>
<p>e-post is a simple online messaging system that enables users of the same group to message each other on-site. What you see here is a simple template for e-post with 2 test users setup for you to try out.</p>
<p>These test users are:</p>
<ul>
<li>Logon:test1 Password:test1</li>
<li>Logon:test2 Password:test2</li>
</ul>
<p>Further users can be created as you see fit the login script used is a modified version of i-auth.zip another irealms.co.uk script, if you have any problems or questions you may email <a href="mailto:ryanmarshall@irealms.co.uk" />Ryan Marshall</a> or post on the forums at <a href="http://www.irealms.co.uk" />www.irealms.co.uk</a>.</p>
</td>
</tr>
</table>