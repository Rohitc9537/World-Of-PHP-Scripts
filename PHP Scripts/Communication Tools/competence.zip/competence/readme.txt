/-----------------
Installation:
/----------------

Comptence version 1.3

/-----------------

update in file "prive/conf.php" the values you want to update

 the application test if tables are created if not the application create the tables

/-----------------


