<?
//---------------------------------------------------------------------------------------------------
//							
//  messages en francais
//
//---------------------------------------------------------------------------------------------------

$mess[0] = "Derni�re version";
$mess[1] = "Login";
$mess[2] = " Mot de passe";
$mess[3] = "Valider";
$mess[4] = "S enregistrer";
$mess[5] = "Cr�ation d'un utilisateur";
$mess[6] = "Nom";
$mess[7] = "Pr�nom";
$mess[8] = "Login";
$mess[9] = "V�rification mot de passe";
$mess[10] = "Erreur Table ";
$mess[11] = "Liste des Syst�mes - Domaines - Comp�tences";
$mess[12] = "Syst�me";
$mess[13] = "Domaines";
$mess[14] = "Comp�tences";
$mess[15] = "Supprimer";
$mess[16] = "Ce Login existe d�ja veuillez en choisir un autre";
$mess[17] = "Nouvel essai";
$mess[18] = "Cr�er";
$mess[19] = "Cr�ation";
$mess[20] = "Liste des �valuations effectu�es";
$mess[21] = "Cr�ation nouvelle �valuation";
$mess[22] = "Evaluation";
$mess[23] = "Objectif";
$mess[25] = "Niveau";
$mess[26] = "Liste des Objectifs d�finis";
$mess[27] = "Afficher les �valuations coch�es";
$mess[28] = "Afficher";
$mess[29] = "Administration";
$mess[30] = "modifier competences";
$mess[31] = "Aide";
$mess[32] = "Saisie des parametres";
$mess[33] = "Date Evaluation";
$mess[34] = "Type evaluation";
$mess[35] = "Consolidation equipe";
$mess[36] = "Derni�re connection";
$mess[37] = "Liste des utilisateurs";
$mess[38] = "Param�tres utilisateur";
?>