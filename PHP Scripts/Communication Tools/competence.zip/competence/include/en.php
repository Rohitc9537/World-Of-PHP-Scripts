<?
//---------------------------------------------------------------------------------------------------
//								
//
//---------------------------------------------------------------------------------------------------
$mess[0] = "Last version";
$mess[1] = "Login";
$mess[2] = "Password";
$mess[3] = "Valide";
$mess[4] = "Register";
$mess[5] = "Create user";
$mess[6] = "Last Name";
$mess[7] = "First Name";
$mess[8] = "Login";
$mess[9] = "Check password";
$mess[10] = "Error:Table ";
$mess[11] = "List  Stages - Fieds - Knowledge";
$mess[12] = "Stage";
$mess[13] = "Field";
$mess[14] = "Knowledge";
$mess[15] = "Supress";
$mess[16] = "This login exist choose an other";
$mess[17] = "Try again";
$mess[18] = "Create";
$mess[19] = "Creation";
$mess[20] = "List evaluations avalaibles";
$mess[21] = "Create a new evaluation";
$mess[22] = "Evaluation";
$mess[23] = "Objective";
$mess[25] = "Level";
$mess[26] = "Defined Objectives list";
$mess[27] = "Show the checks evaluations";
$mess[28] = "Show";
$mess[29] = "Administration";
$mess[30] = "Update knowledge";
$mess[31] = "Help";
$mess[32] = "Parameters input";
$mess[33] = "Evaluation Date";
$mess[34] = "Type evaluation";
$mess[35] = "Team Consolidation";
$mess[36] = "Last connexion";
$mess[37] = "Users List";
$mess[38] = "User Parameters";
?>