<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// module = classf / classifications
// gestione classificazione :::
$title = "Gestione Classificazione Utenti Sms";
require("common.inc.php"); 
?>

<?php
function edit_classf_form($db, $id) {
	$priv = $_SESSION["priv"];
   global $uclass, $id, $descript;
   $uclass = $db->Execute("SELECT id, descript FROM classf WHERE id='$id'"); 
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Classification description.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$uclass = $db->Execute("SELECT id, descript FROM classf WHERE id='$id'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($uclass->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>classf Classification not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   	if ($priv > 5) {
  ?>
  
<table class="default" align="center" border="0" cellspacing="0" cellpadding="0">
      <form name="form1" method="post" action="ne_classf.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>CLASS MODIFICATION AREA</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">ID:</td>
            <td colspan="3"> <?php echo $uclass->fields["id"]; ?> </td>
         </tr>
         <tr class="row_even">
            <td nowrap align="right">Description:</td>
            <td colspan="3"><input type="text" name="descript" size="30" value="<?php echo $uclass->fields["descript"]; ?>"> </td>
         </tr>		
		 <tr class="row_foot"> 
            <td colspan="4" nowrap><div align="center">
               <img src="images/pub/bt_update.gif" border="0" alt="Modifica"
                  onClick="document.form1.submit();">
               <a href="ne_classf.php?action=Abort">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Elimina - Delete <?php echo $id; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this classf Description<?php echo $id; ?> - [ <?php echo $uclass->fields["descript"]; ?> ] ?')) { window.location='ne_classf.php?action=delete&uid=<?php echo $id; ?>'; }"></div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.form1.descript.focus();
   </script> 
 <?php
 	} // end if priv >5
	   echo "<table class=\"notice\" width=\"100%\"><tr><td><b>Operation not allowed.</b></td></tr><tr><td>You cam add, but not modify the classes!</td></tr></table>";
} // end function
 ?>  

<?php // *** ADD ********************
function display_form($db) {
?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
       <tr class="row_head"> 
         <td><b>New classf Classification for sms-users</b></td>
         <td align="right">CLASS</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
   <form action="ne_classf.php" method="post" name="form2">	   
       <tr class="row_even">
         <td align="right">Description:</td>
         <td>
			<input type="text" name="descript" size="40" value="">
         </td>
       </tr>
       <tr class="row_foot"> 
         <td colspan="2"> 
            <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
               onClick="document.form2.submit();">
            <a href="ne_classf.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">  
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.form2.descript.focus();
   </script> <?php
} ?>

<?php
function paint_table($db) { 
   $summclassf = $db->Execute("SELECT * FROM classf ORDER BY descript");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td>&nbsp;</td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>classf</b></td>
      </tr> <?php
      $i = 1;
      while (!$summclassf->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
            <td>

               <a href="ne_classf.php?action=edit&descript=<?php echo $summclassf->fields["descript"]; ?>&id=<?php echo $summclassf->fields["id"]; ?>">
                  <?php echo /$i //$summclassf->fields["id"]; ?></a>
            </td>
            <td> <a href="ne_classf.php?action=edit&descript=<?php echo $summclassf->fields["descript"]; ?>&id=<?php echo $summclassf->fields["id"]; ?>"><b><?php echo $summclassf->fields["descript"]; ?></b></a>
			</td>
         </tr> <?php
         $i++;
         $summclassf->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_classf.php?action=addptel">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Aggiungi Classe">
			   </a></div></td>
      </tr>
   </table>

 <?php
} ?>


<?php
if ($priv > 5) {
   $action = strtolower($action);
   switch ($action) {
   	  case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation Aborted.</td></tr></table><br>";
			paint_table($db);
         break;
	   case "addptel":
            display_form($db);
            break;
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The classf Classification ID <b>$id</b> was successfully added!.</td></tr></table>";
		  paint_table($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  display_form($db);
         break;
	  case "delete":
          if (!$db->Execute("DELETE FROM classf WHERE id='$uid'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>The classf Classification ID <b>$id</b> $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
      case "create":
		 if ($descript == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description for this filed (descript)!</td></tr></table>";
            display_form($db);
            break;
         }
         $classf_desc = $db->GenID("classf_seq");
		 $descript = addslash_text($descript);
         $query = "INSERT INTO classf (intid, descript)"
                . " VALUES ('$classf_desc', '$descript')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_classf.php";
         </script><?php
         break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid description for that field.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $descript = addslash_text($descript);
         $query = "UPDATE classf SET"
                . " descript='$descript'"
                 . " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         //require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_classf.php?k=ok";
         </script> <?php
         break;
	  case "edit":
         edit_classf_form($db, $id);
		 	break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
