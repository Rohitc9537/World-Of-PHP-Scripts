<html>
<head>
<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/


$hostW = $_SERVER['HTTP_HOST'];
if ($hostW == '192.168.0.9') {
	$javscr = 'ksms-menumngr.js'; }
elseif ($hostW == 'viabazar.net') {
	$javscr = 'kimenu.js'; }
else ($javscr = 'ksms-menumngr.js');

// 
 // $privileges = $_SESSION["priv"];
 // $id_of_orgz = $_SESSION["id_company"];
 $privileges = $priv;
 $id_of_orgz = $id_company;
if ($privileges == "1") { $menuscr = 'ksms-000.js'; $pvl = "LCK";}
if ($privileges == "2") { $menuscr = 'ksms-003.js'; $pvl = "DMO"; }
if ($privileges == "3") { $menuscr = 'ksms-003.js'; $pvl = "TST"; }
if ($privileges == "4") { $menuscr = 'ksms-005.js'; $pvl = "GUEST"; }
if ($privileges == "5") { $menuscr = 'ksms-005.js'; $pvl = "NORUSR"; }
if ($privileges == "6") { $menuscr = 'ksms-005.js'; $pvl = "MASTER"; }
if ($privileges == "7") { $menuscr = 'ksms-007.js'; $pvl = "S.VISOR"; }
global $title;

?>

  	<script type="text/javascript" language="JavaScript1.2" src="<?php echo $javscr ?>"></script>
	<script language="JavaScript1.2" src="kSmsvalidation.js"></script>
	<link href="kSms-style.css" rel="stylesheet" type="text/css">
<title><?php echo $cfg["sysver"]; ?><?php echo $title; ?> by Viabazar.com</title>
<meta name="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="Mon, 23 Jul 2000 16:20:18 GMT">
</head>
<body class="Ksmsman">
	<script type="text/javascript" language="JavaScript1.2" src="<?php echo $menuscr ?>"></script>

<?php
// old menu ::: <script type="text/javascript" language="JavaScript1.2" src="ksms_dataMenu.js"></script>
// echo ($urlB);
if (isset($username)) {
	$check_queue = $db->Execute("SELECT COUNT(*) AS ku_row FROM sendgatenumbs WHERE id_organization='$id_of_orgz' AND myserv_queue = 'MTCC' OR myserv_queue = 'MIKV' OR myserv_queue = 'MTCS' OR myserv_queue = 'MKSN' OR myserv_queue = 'MTCC' OR myserv_queue = 'MMCY' OR myserv_queue = 'MMER' OR myserv_queue = 'MMCT'");
$idsgnb = $check_queue->fields["ku_row"];
?>
	<table bgcolor="#6787BA" height="33" width="100%" cellspacing="3" cellpadding="3" border="0">
<tr>
    <td width="105">&nbsp;</td>
	<td width="655">
	<?PHP

	if ($idsgnb) { echo "<b><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='white'>There is ".$idsgnb." messages on queue! <b>(This is a future,...)</b></font></b>"; }
		else { echo "<b><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='3' color='#F8FB82'>Click on the <font size='4' color='#FACCA3'>MENU</font> button!</font></b>"; }
	?>
	</td>
    <td align="right"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#E8FDFF">Ksms - <?php echo $cfg["version"]." ".$cfg["datevD"].$cfg["datevM"].$cfg["datevY"]; ?></font></td>
</tr>
</table>
   <table class="default" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_even">
	     <td><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000099"><b>KSMS</b> - <?php echo $title; ?>&nbsp;&nbsp;&nbsp;&nbsp;Operator: <b><?php echo $company."&nbsp; (".$pvl.")"; ?></b></font>

</td>
         <td align="right"> <?php
            if ($priv == 69) { ?>
               <a href="admin.php"><img src="images/admin_btn.gif" alt="Administration" border="0"></a> <?php
            } ?>
            <a href="logout.php"><img src="images/pub/logout_btn.gif" alt="Log Out" border="0"></a>
         </td>
      </tr>
   </table> <?php
}

//echo "--------...---- ".$_GET['incm']."<br><br>";
?>

