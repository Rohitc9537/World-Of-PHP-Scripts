<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/
// TRANSLATE MODULE
// example to use : $klang_errs['par_missing']

// info about translators and translated language
$klang_info = array(
	'klang_source' => 'English',
	'klang_native' => 'English',
	'klang_country_code' => 'us', // us - gb - ...
	'klang_trans_who'=> 'Ksms development team',
	'klang_trans_email' => '',
	'klang_trans_website' => 'http://ksms.sourceforge.net/',
	'klang_trans_date_01' => '2005-05-12',
	'klang_trans_latupdate' => '2005-05-12',
);

$klang_charset = 'iso-8859-1';

// Day of weeks and months
$klang_weekday = array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
$klang_month = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');

// Some common strings
$klang_yes = 'Yes';
$klang_no  = 'No';
$klang_back = 'BACK';
$klang_continue = 'CONTINUE';
$klang_info = 'Information';
$klang_error = 'Error';

// For the word censor
$klang_badwords = array('*fuck*', 'asshole', 'assramer', 'bitch*', 'c0ck', 'clits', 'Cock', 'cum', 'cunt*', 'dago', 'daygo', 'dego', 'dick*', 'dildo', 'fanculo', 'feces', 'foreskin', 'Fu\(*', 'fuk*', 'honkey', 'hore', 'injun', 'kike', 'lesbo', 'masturbat*', 'motherfucker', 'nazis', 'nigger*', 'nutsack', 'penis', 'phuck', 'poop', 'pussy', 'scrotum', 'shit', 'slut', 'titties', 'titty', 'twaty', 'wank*', 'whore', 'wop*');

$klang_err = array(
	'access_denied' => 'You don\'t have permission to access this page.',
	'perm_denied' => 'You don\'t have permission to perform this operation.',
  	'param_missing' => 'Script called without the required parameter(s).',
);

// echo $klang_sendms['pg_waiting'];
$klang_sendms = array(
  	'pg_waiting' => 'Attendi un messaggio di <b>conferma invio avvenuto</b>, prima di chiudere o cambiare pagina.',
	'what_msel' => 'In selezione &laquo;manuale&raquo; hai scelto di spedire un messaggio a ',
  	'numbs' => ' numeri!',
  	'ms_waiting' => '...attendere pochi secondi, grazie!',
);

?>