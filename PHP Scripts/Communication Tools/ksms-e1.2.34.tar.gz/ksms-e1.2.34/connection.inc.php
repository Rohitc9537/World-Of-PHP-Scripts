<?php

// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// Include the ADODB library.
require("adodb/adodb.inc.php");
### CHANGE IT !!!
$ADODB_CACHE_DIR = '/.../public/KSMS/SQLcache';

// Connect to the database.
$db = &ADONewConnection($cfg["db_type"]);
if ($cfg["db_persist"] == TRUE) { // Persistant DB connection.
   switch ($cfg["db_type"]) {
      case "sqlite":
         $db->PConnect($cfg["db_host"]);
         break;
      case "access":
      case "odbc":
         $db->PConnect($cfg["db_host"], $cfg["uid"], $cfg["pwd"]);
         break;
      default:
         $db->PConnect($cfg["db_host"], $cfg["uid"], $cfg["pwd"], $cfg["db"]);
   }
} else { // Non-persistent DB connection.
   switch ($cfg["db_type"]) {
      case "sqlite":
         $db->Connect($cfg["db_host"]);
         break;
      case "access":
      case "odbc":
         $db->Connect($cfg["db_host"], $cfg["uid"], $cfg["pwd"]);
         break;
      default:
         $db->Connect($cfg["db_host"], $cfg["uid"], $cfg["pwd"], $cfg["db"]);
   }
}
// For debugging
if ($cfg["view_debug"] == TRUE) {
require("adodb/tohtml.inc.php");
$db->debug = TRUE;
}
?>
