<?PHP

// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

//	DBsend.php

if ($aokk == "OK_CRsupNR" OR $bokk == "okCR_OptSelected")
 {
 	echo "<table class='foottbl' width='100%'><tr><td><div align='center'>";
	echo $klang_sendms['pg_waiting'];
	echo "</b></div></td></tr></table>";
		$smorg = $db->Execute("SELECT * FROM organization WHERE id='$idORG'");
		$smsID = $smsk->fields["id"];
		$Kmessage = $smsk->fields["sms_text"];  // THE MESSAGE!!!
		$smstext = addslash_text($Kmessage);
		$dtsend = date("Y-m-d"); // date (when send to the ksms server)
		$tmsend = date("H:i:s"); // times ()
		$dtmsnd = (date("Y-m-d")." ".date("H:i:s")); // date and times
		$internalid = ("4".date("ymd")."000".date("His").".ksms");
		$gw_user = $smorg->fields["gway_account"];
		$gw_pwd = $smorg->fields["gway_pass"];
		$tx_head = $smorg->fields["txt_head_sender"];
		// head of the message, will appear in substitute of the sender's number
		$mobile_sender = $tx_head;
		//$KuidOrg = $smorg->fields["id"]; // id organization
		$Kprivs = $smorg->fields["priv"];  // privileges
		// is it authorized by admin to send messages?
		$Kauth = $smorg->fields["auth_adm"]; 
		$idgatewayprovider = $gwfile->fields["id"];
		$gate_name = $gwfile->fields["UCPinterface"];
		$sended = "N";
		$mailed = "N";
		$mmyserv_queue = "MTCC";
		$refern = rand(100, 1009997);
		$refer = "rf".$refern."k";
		// $internal_smsc_type ===> what plugin i used (eg.KANN=KANNEL), max 5 chars.
		if ($gate_name == "kannel")
				{ $internal_smsc_type = 'KANN'; } else { $internal_smsc_type = 'OTHER'; }
// Insert only main data into table "sendgate_data"
			$query2 = "INSERT INTO sendgate_data (id_gateway_provider, id_sms, id_organization, selection_type, selection, sms_text, internal_id_mex, ip_sender_organ, txt_head_sender, smsc_type, tpl_times, tpl_date, tpl_sended, tpl_mailed, tpl_myserv_queue, ref)"
			. " VALUES ('$idgatewayprovider', '$smsID', '$idORG', '$strsm', '$strsm3', '$smstext', '$internalid', '$ip_sender_organ','$tx_head', '$internal_smsc_type', '$tmsend', '$dtsend', '$sended', '$mailed', '$mmyserv_queue', '$refer')";
         if (!$db->Execute($query2)) {
           echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
			}
## Routine selector
## selected by category or group or class   ##
   if ($strsm == "CA" OR $strsm == "CL" OR $strsm == "GR" OR $strsm == "XG")
	{
//  Insert numbers, date and status in "sendgatenumbs" 							//
 ########################################################################
 	if ($smopt == "auto") {
	// myserv_queue = MTCC - MTCS (default)
	$query3 = "INSERT INTO sendgatenumbs (id_sendgate_data, id_organization, sms_id, toserver_times, toserver_date, id_user, mob_countrycode, mobile_prenumber, mobile_phone_number, sended, mailed, myserv_queue, ref)"
				. " SELECT sendgate_data.id_sendgate_data, sendgate_data.id_organization, sendgate_data.id_sms, sendgate_data.tpl_times, sendgate_data.tpl_date, userz.id_user, userz.country_code, userz.mobile_pref, userz.mobile_phone, sendgate_data.tpl_sended, sendgate_data.tpl_mailed, sendgate_data.tpl_myserv_queue, sendgate_data.ref FROM sendgate_data LEFT JOIN userz ON sendgate_data.id_organization=userz.id_organization WHERE userz.id_organization='$idORG' AND $slclause='$strsm3' AND sendgate_data.id_sms='$smsID' AND sendgate_data.ref='$refer' LIMIT $cust_credsrem_it";
	}
		else {
		$query3 = "INSERT INTO sendgatenumbs (id_sendgate_data, id_organization, sms_id, toserver_times, toserver_date, id_user, mob_countrycode, mobile_prenumber, mobile_phone_number, sended, mailed, myserv_queue, ref)"
				. " SELECT sendgate_data.id_sendgate_data, sendgate_data.id_organization, sendgate_data.id_sms, sendgate_data.tpl_times, sendgate_data.tpl_date, userz.id_user, userz.country_code, userz.mobile_pref, userz.mobile_phone, sendgate_data.tpl_sended, sendgate_data.tpl_mailed, sendgate_data.tpl_myserv_queue, sendgate_data.ref FROM sendgate_data LEFT JOIN userz ON sendgate_data.id_organization=userz.id_organization WHERE userz.id_organization='$idORG' AND $slclause='$strsm3' AND sendgate_data.id_sms='$smsID' AND sendgate_data.ref='$refer'";
			}
//
         if (!$db->Execute($query3)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
			}
				$querysendd1 = "UPDATE ksms SET"
                . " sms_sended ='Y', send_datetime_desired='$dtmsnd' "
                . " WHERE id='$smsID'";
         	if (!$db->Execute($querysendd1)) {
    			echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         		}
}  // end if number-select is_NOT_single (>>>>($strsm == "CA" OR $strsm == "CL" OR $strsm == "GR"...)<<<)
	if ($strsm == "single") 
	{
		$totnri = count($sms_numbers);
	echo "<p class='cell_of_evidence'>".$klang_sendms['what_msel'].$totnri.$klang_sendms['numbs'];
	echo "<br>";
	echo $klang_sendms['ms_waiting']."</p>";

		$IDmnumber_user = implode(",",$sms_numbers);
			$query4 = "INSERT INTO sendgatenumbs (id_sendgate_data, id_organization, sms_id, toserver_times, toserver_date, id_user, mob_countrycode, mobile_prenumber, mobile_phone_number, sended, mailed, myserv_queue, ref, groupselect)"
			. " SELECT sendgate_data.id_sendgate_data, sendgate_data.id_organization, sendgate_data.id_sms, sendgate_data.tpl_times, sendgate_data.tpl_date, userz.id_user, userz.country_code, userz.mobile_pref, userz.mobile_phone, sendgate_data.tpl_sended, sendgate_data.tpl_mailed, sendgate_data.tpl_myserv_queue, sendgate_data.ref, sendgate_data.selection_type FROM sendgate_data LEFT JOIN userz ON sendgate_data.id_organization=userz.id_organization WHERE userz.id_organization='$idORG' AND userz.id_user IN($IDmnumber_user) AND sendgate_data.id_sms='$smsID' AND sendgate_data.ref='$refer'";
         if (!$db->Execute($query4)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
			}
		$querysendd = "UPDATE ksms SET"
			. " sms_sended ='Y', send_datetime_desired='$dtmsnd' "
			. " WHERE id='$smsID'";
         if (!$db->Execute($querysendd)) {
    			echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
           		 break;
         			}
  } // end if ... == "single"
 include ("newpart.php");

 } // end if ($aokk == "OK_CRsupNR")
 	else {
// IF       $aokk ARE_NOT = "OK_CRsupNR"         OR $bokk ARE_NOT = "okCR_OptSelected"
	echo "<p class='body_of_evidence'> SINTAX CREDITS ERROR (DBC52262) </p>"; 
	include("footer.inc.php");
	break;
	  }