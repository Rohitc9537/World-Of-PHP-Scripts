<?PHP
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
?>

<TEXTAREA onblur=countChars(event) onload=countChars(event) onkeypress=countChars(event) id=txtmplMxg onkeydown=countChars(event) onkeyup=countChars(event) name="t_text" rows="3" cols="30" wrap=ON><?php echo $Ktext; ?></TEXTAREA>
                  <BR>
                  <B>Caratteri disponibili:</B> 
                  <INPUT VALUE=159 NAME="ch_remain" size="5">
                  <SCRIPT language="JavaScript">
				//<!--
					if (navigator.appName.indexOf("Netscape")>=0 && parseInt(navigator.appVersion) >=4) { var nn4 = true } document.tmplform.t_text.onkeydown = countChars;
					if (nn4) document.captureEvents(Event.KEYDOWN);
					var oldString = "";
					function countChars(d)
						{
							if (document.tmplform.t_text.value.length> 159)
								{
									document.tmplform.t_text.value = oldString;
    							}
 
							else
								{
    								document.tmplform.ch_remain.value = 159 - document.tmplform.t_text.value.length;
    								oldString = document.tmplform.t_text.value.substring(0,159);
    							}    
  						}
 				// -->
			</SCRIPT>