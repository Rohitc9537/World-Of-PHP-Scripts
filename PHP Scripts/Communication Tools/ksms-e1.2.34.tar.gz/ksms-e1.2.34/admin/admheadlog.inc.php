<html>
<head>
<!--
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//

  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
-->

	<script language="JavaScript1.2" src="KsmsAdminValid.js"></script>
<link rel="stylesheet" type="text/css" href="admstyle.css">
<title>Ksms Admin Area - The sms services by viabazar.com</title>
<meta name="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="Mon, 28 Aug 2000 16:20:18 GMT">
</head>
<body class="admbody">

<br><br>
<table cellspacing="2" cellpadding="2" border="0">
<tr>
    <td><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000099"><b>KSMS [admin area reserved]</b></font></td>
</tr>
</table>
<br>
<p class="addnotes"><b>YOU MUST LOG IN TO ACCESS IN THIS AREA !!!</b></p>
