<?PHP
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
?>
<br><br><br>
<table align="center" cellspacing="1" cellpadding="1" border="0" width="90%">
<tr class="news2">
    <td colspan="4">
  Privilegi Utenti:</td>
</tr>
<tr class="priv01">
<td>1.</td><td><b>Lock</b></td><td>===></td>
<td>se abilitato ::: NON INVIA SMS (nemmeno a monitor) !!!</td>
</tr> 
<tr class="priv01">
<td>2.</td><td><b>Demo</b>(only_screen)</td><td>===></td>
<td>se abilitato ::: invia SMS come testo a Monitor (a tutti i nr. scelti) [GESTIONE = NIENTE]</td>
</tr>
<tr class="priv01">
<td>3.</td>
<td><b>Test</b>  (only_email)</td>
<td>===></td>
<td>se abilitato ::: invia tutti gli sms, che ha acquistato, in EMAIL a chiunque[GESTIONE = tabelle "users" + "sms"]</td>
</tr>
<tr class="priv01">
<td>4.</td>
<td><b>Guest</b>  (only_email)</td>
<td>===></td>
<td>se abilitato ::: invia tutti gli sms, che ha acquistato, in EMAIL a chiunque[GESTIONE = tabelle "users" + "sms" + "configurazione"]</td>
</tr>
<tr class="priv01">
<td>5.</td>
<td><b>NormalUser</b></td>
<td>===></td>
<td>se abilitato ::: invia tutti gli sms, che ha acquistato, a chiunque[GESTIONE = tabelle "users" + "sms" + "configurazione"]</td>
</tr>
<tr class="priv01">
<td>6.</td>
<td><b>MasterUser</b></td>
<td>===></td>
<td>se abilitato ::: NON ATTIVO !!!</td>
</tr>
<tr class="priv01">
<td>7.</td>
<td><b>Supervisor</b></td>
<td>===></td>
<td>se abilitato ::: invia tutti gli sms, che ha acquistato, a chiunque[GESTIONE = tabelle "users" + "sms" + "configurazione"]</td>
</tr> 

</table>
<br><br><br>