<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/
require("admcommon.inc.php"); ?>

<?php
function display_form() {
  global $refer; 
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   echo "<br>DIRECTORY OF IMAGES HERE : ".$imgs_admin_dir."<br>";
  ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="new_vendor.php" method="post" name="form1">
    <tr class="row_head"> 
      <td colspan="4"><b>New Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td colspan="3"> 
        <input type="text" name="name" size="50">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 1:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="50">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 2:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="50">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">City:</td>
      <td colspan="3"> 
        <input type="text" name="city" size="50">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
	  </tr>
	  <tr class="row_even">
      <td align="right">Province:</td>
      <td colspan="3">
        <?php require("ItProv.inc.php"); ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Postal Code / ZIP:</td>
      <td> 
        <input type="text" name="p_code" size="20">
      </td>
      <td align="right">Country:</td>
      <td> 
        <input type="text" name="country" size="20" value="Italy">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Attention:</td>
      <td>
        <input type="text" name="attn" size="50">&nbsp;&nbsp;<font size="-2">(max 50 chars)</font>
      </td>
	  <td align="right">Part.IVA</td>
	  <td><input type="text" name="PIVA_vendor" size="30"></td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="main_phone" size="20">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="main_fax" size="20">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="main_email" size="50">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="main_www" size="50" value="http://">
      </td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Technical or Support Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="tech_phone" size="20">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="tech_fax" size="20">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="tech_email" size="50">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="tech_www" size="50" value="http://">
      </td>
    </tr>
    <tr class="row_even"> 
      <td valign="top" align="right">Comments:</td>
      <td colspan="3"> 
        <textarea name="comments" cols="50" rows="5" wrap="VIRTUAL"></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4"> <div align="center">
         <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" alt="Enter" align="middle"
            onClick="if (valid_vendor_form(document.form1)) { document.form1.submit(); }">
         <img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
            onClick="document.form1.reset();">
         <a href="new_vendor.php?action=cancel">
         <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
			</a></div>
      </td>
    </tr> <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
   <input type="hidden" name="action" value="insert">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.name.focus();
   </script> <?php
} ?>

<?php
if ($privs == '69') {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary update cancelled.</td></tr></table>";
         break;
      case "insert":
         if ($name == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid vendor name.</td></tr></table>";
            display_form();
            break;
         }
         $id = $db->GenID("vendor_seq");
         $query = "INSERT INTO vendor (intid, name, attn, address1, address2, city, province, country, p_code, PIVAvendor, main_phone, main_fax, main_email, main_www, tech_phone, tech_fax, tech_email, tech_www, comments)"
                . " VALUES ('$id', '$name', '$attn', '$address1', '$address2', '$city', '$province', '$country', '$p_code', '$PIVA_vendor', '$main_phone', '$main_fax', '$main_email', '$main_www', '$tech_phone', '$tech_fax', '$tech_email', '$tech_www', '$comments')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if (isset($refer)) {
            require("footer.inc.php"); ?>
            <script language="JavaScript">
               window.location="<?php echo $refer; ?>";
            </script> <?php
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary updated OK.<a href=\"new_vendor.php\"><img src=\"".$imgs_admin_dir."add_btn.gif\" border=\"0\" alt=\"Add\"></a> another new vendor.</td></tr></table>";
         break;
      default:
         display_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
