<?php 
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
require("admcommon.inc.php"); 
?>

<?php
function new_org_form($db) { 
global $gway_account, $gway_pass;
	   	$imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   		$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
		//$vendors = $db->Execute("SELECT name FROM vendor ORDER BY name");
		//$gatewayprovider = $db->Execute("SELECT name_gwprovider FROM gwprovider ORDER BY name_gwprovider");
   	   if (!$vendors = $db->Execute("SELECT name,id FROM vendor ORDER BY name")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		return FALSE;
		}
   	   if (!$gatewayprovider = $db->Execute("SELECT name_gwprovider,id FROM gwprovider ORDER BY name_gwprovider")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		return FALSE;
		}

?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form1" method="post" action="admin_sms.php">
         <tr class="row_head"> 
            <td colspan="4" nowrap><b>NUOVO UTENTE DEL PROGRAMMA : OVVERO CHI POTRA' INVIARE GLI SMS (organization)</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Username:</td>
            <td colspan="3"> 
               <input type="text" name="prgmusername" size="30" value="">&nbsp;&nbsp;<font size="-2">Max 16 char.&nbsp;&nbsp;(minuscolo-no spazi)</font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Password:</td>
            <td colspan="3">
			   <input type="password" name="apasswd1" size="30" value=""> <font size="-2">min. 4 caratteri</font>
            </td>
			<tr class="row_even">
            <td nowrap align="right">Retype Password:</td>
            <td colspan="3">
               <input type="password" name="apasswd2" size="30" value=""> <font size="-2">min. 4 caratteri</font>
            </td>
         </tr>		 
		 <tr class="row_even">
         <td align="right">Venditore:</td>
         <td colspan="3">
            <?php echo $vendors->GetMenu2("vendor", "", FALSE); ?>&nbsp;&nbsp;
		<a href="new_vendor.php?refer=admin_sms.php?action=new" target="_blank">
               <img src="<?PHP echo $imgs_admin_dir ?>Add_Vendor.gif" alt="Add Vendor" width="100" height="31" border="0" align="middle"></a>
         </td>
       </tr>
	   <tr class="row_even">
         <td align="right">GwayProvider abbinato:</td>
         <td colspan="3">
            <?php echo $gatewayprovider->GetMenu("gway_provider", "", FALSE); ?>&nbsp;&nbsp;
			<a href="new_gateway.php?admin_sms.php?action=new" target="_blank">
               <img src="<?PHP echo $imgs_admin_dir ?>Add_GatewayProvider.gif" alt="Add new Gateway Provider" width="100" height="31" border="0" align="middle"></a>
         </td>
       </tr>
	   <tr class="row_even"> 
            <td nowrap align="right">Head Invio:</td>
            <td> 
               <input type="text" name="txt_head_sender" size="15" value="">&nbsp;&nbsp;<font size="-2">Max 11 char. - Appare come intestazione sms</font>
            </td>
          <td colspan="2"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="-2" color="#E8FDFF">&laquo;&laquo;&laquo; Il sender del messaggio</font></td>
		 </tr>
	   <tr class="row_even"> 
            <td nowrap align="right">Privilege:</td>
           <td colspan="3"> 
               <select name="privilege">
			   <option value="1">Lock (no sms)</option>
			   <option value="2">Demo (sms to screen)</option>
			   <option value="3">Test (sms to email)</option>
			   <option value="4">Guest (sms to email)</option>
			   <option value="5" selected>Normal User</option>
			   <option value="6">Master User</option>
			   <option value="7">Supervisor (all)</option>
               </select>&nbsp;&nbsp;
			Lock,Demo,Test e Guest non inviano SMS
		</td>
		 </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Sistema Connessione:</td>
            <td colspan="3">
               <select name="sistemconnect">
			   <option value="" selected>---Selezionare---</option>
			   <option value="oto">One To One (1:1)</option>
			   <option value="fee">Credits con Fee</option>
			   <option value="nnt">Non Attivo</option>
               </select>&nbsp;
			   <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#E6FFF2"><b>Credits con Fee</b>:1 sms spedito,si toglie xx credits. <b>One To One</b>:1 sms spedito,si toglie 1 credito!</font>
			</td>
		 </tr>
		 <tr class="row_head"> 
      <td colspan="4"><b>Dati Aziendali</b></td>
    </tr>
		 <tr class="row_even">
      <td align="right">Rag. Sociale:</td>
      <td> 
        <input type="text" name="company" size="59">&raquo;&raquo;&raquo;&raquo;&raquo;&raquo;
      </td>
      <td colspan="2"><b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#F7EC2B">La Ragione Sociale &egrave; obbligatoria!!!</font></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede principale:</td>
      <td> 
        <input type="text" name="address1" size="59">
      </td>
      <td align="right">Esente IVA?</td>
      <td>
         <input type="checkbox" name="tax_exempt" value="Y">
      </td>
    </tr>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede secondaria:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="59">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Citt�:</td>
      <td><input type="text" name="city" size="59"></td>
      <td align="right">Provincia:</td>
      <td>
	  <?php require("ItProv.inc.php"); ?>
	  </td>
    </tr>
	 <tr class="row_even">
      	<td align="right">CAP/ZIP:</td>
      	<td><input type="text" name="zip_code" size="6">
		&nbsp;Country:&nbsp;<input type="text" name="country" size="15" value="Italy"></td>	
    	<td align="right">Part.IVA:</td>
      	<td><input type="text" name="PIVA" size="20"></td>		
    </tr>	
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Nome e Cognome:</td>
      <td> 
        <input type="text" name="contact" size="30">
      </td>
	  <td align="right" bgcolor="#F7EC2B"><font color="#0450AC">E-Mail:</font></td>
      <td bgcolor="#F7EC2B"> 
        <input type="text" name="email" size="30">&nbsp;
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="phone" size="20">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="fax" size="20">
      </td>
    </tr>
	</tr>
<?PHP
// questa parte non serve se si utilizza l'interfaccia KANNEL
/*
    <tr class="row_reddark"> 
      <td align="right">Gateway Account/User:</td>
      <td> 
        <input type="text" name="gway_account" size="30">
      </td>
      <td align="right">Gateway Password:</td>
      <td> 
        <input type="text" name="gway_pass" size="20">
      </td>
    </tr>
*/
?>
         <tr class="row_even"> 
            <td nowrap align="right">Commenti da Admin:</td>
            <td> 
               <textarea name="master_comments" cols="50" rows="3" wrap="VIRTUAL"></textarea>
            </td>

		 <td align="right" colspan="2">L'utente pu� inviare sms? &nbsp;<input type="checkbox" name="auth_adm" value="Y">
      </td>
         </tr>         
         <tr class="row_even_hg"> 
            <td colspan="4" nowrap> <div align="center">
			<img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" alt="invia" width="100" height="31" border="0" align="middle"
                  onClick="document.form1.submit();">
			<img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
                  onClick="document.form1.reset();">
               <a href="admin_sms.php?action=cancel">
				<img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
			   </a></div>
            </td>
         </tr>
		 <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
      <input type="hidden" name="action" value="insertorg">
      </form>
   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
<tr>
    <td><div align="center">
		<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#ff3300">
	Il campo <b>E-Mail</b> &egrave; evidenziato in quanto qui si deve inserire l'indirizzo a cui far arrivare reports logs vari!!!
		</font></div>
	</td>
</tr>
</table>

   <br>
   <?php require("help_privs.inc.php"); ?>
   <script language="JavaScript">
      document.form1.prgmusername.focus();
   </script> <?php
} ?>

<?php //-------   EDIT ---------------//
function edit_org_form($db, $auid) {
	   	$imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   		$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
//echo $org->fields["fullname"];
   global $cfg, $prgmusername, $priv;
   			//$org2 = $db->Execute("SELECT * FROM organization WHERE id='$auid'");
    if (!$org2 = $db->Execute("SELECT * FROM organization WHERE id='$auid'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } 
						// $gatewayprovider = $db->Execute("SELECT name FROM gwprovider ORDER BY name");
	if (!$gatewayprovider = $db->Execute("SELECT name_gwprovider,id FROM gwprovider ORDER BY name_gwprovider")) {
      	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      	return FALSE;
	}
	if (!$vendors = $db->Execute("SELECT name,id FROM vendor ORDER BY name")) {
      	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      	return FALSE;
	}
   if ($auid == "") {
      	echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Username or ID.</td></tr></table>";
      	paint_table($db);
      	return FALSE;
   }
   if ($org2->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Customer Organization not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
 ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form2" method="post" action="admin_sms.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>MODIFICA ORGANIZATION, OVVERO CHI POTRA' INVIARE GLI SMS</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Username:</td>
            <td colspan="3"> 
   <input type="text" name="uname" size="30" value="<?php echo $org2->fields["username"]; ?>"> &nbsp;&nbsp;Max 16 char.&nbsp;&nbsp;(minuscolo-no spazi)
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Password:</td>
            <td colspan="3" bgcolor="#A4D2EE">
			   <input type="password" name="apasswd1" size="30">&nbsp;&nbsp;<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000cc">Se non inserisci la PWD, non cambi quella gi&agrave; salvata in DB! (min.4)</font>
            </td>
			<tr class="row_even">
            <td nowrap align="right">Retype Password:</td>
            <td colspan="3" bgcolor="#A4D2EE">
               <input type="password" name="apasswd2" size="30">&nbsp;&nbsp;<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000cc">Riscrivere PWD, solo se si vuole cambiare quella gi� salvata! (min.4)</font>
            </td>
         </tr>		 
		 <tr class="row_even">
         <td align="right">Venditore:</td>
         <td>
            <?php 
			$vendselect = $org2->fields["vendor"];
			echo $vendors->GetMenu("vendor", $vendselect, FALSE, FALSE, 0, ""); ?>&nbsp;&nbsp; <font size="-2">era : <?php echo $vendselect; ?></font>
         </td>
		 <td colspan="2">
            <a href="new_vendor.php?refer=admin_sms.php&action=new">
				<img src="<?PHP echo $imgs_admin_dir ?>Add_Vendor.gif" alt="add vendor" width="100" height="31" border="0" align="absmiddle"></a>
         </td>
       </tr>
		 <tr class="row_even">
         <td align="right">GwayProvider abbinato:</td>
         <td>
            <?php 
			$gpro=$org2->fields["gway_provider"];
			echo $gatewayprovider->GetMenu("gway_provider", $gpro, TRUE, FALSE); ?>&nbsp;&nbsp;<font size="-2"> era : <?php echo $org2->fields["gway_provider"]; ?></font>
         </td>
         <td colspan="2">
            <a href="new_gateway.php?refer=admin_sms.php">
				<img src="<?PHP echo $imgs_admin_dir ?>Add_GatewayProvider.gif" alt="Add Gateway Provider" width="100" height="31" border="0" align="middle">
			</a>&nbsp;<font size="-2">(Nuovo Gateway)</font>
		</td>
	   <tr class="row_even"> 
            <td nowrap align="right">Head Invio:</td>
            <td>
               <input type="text" name="txt_head_sender" size="15" value="<?php echo $org2->fields["txt_head_sender"]; ?>">&nbsp;&nbsp;<font size="-2">Max 11 char. - Appare come intestazione sms</font>
            </td>
          <td colspan="2"><font size="1" color="#E8FDFF">&laquo;&laquo;&laquo; Il sender del messaggio</font></td>
		 </tr>
	   <tr class="row_even">
            <td nowrap align="right">Privilege:</td>
            <td>
               <select name="privilege">
			   	  <option value="" <?php if ($org2->fields["priv"] == "") echo "selected"; ?>>--- Please Select ---</option>	
                  <option value="1" <?php if ($org2->fields["priv"] == 1) echo "selected"; ?>>Lock (no sms)</option>
                  <option value="2" <?php if ($org2->fields["priv"] == 2) echo "selected"; ?>>Demo (sms to screen)</option>
                  <option value="3" <?php if ($org2->fields["priv"] == 3) echo "selected"; ?>>Test (sms to email)</option>			   
                  <option value="4" <?php if ($org2->fields["priv"] == 4) echo "selected"; ?>>Guest (sms to email)</option>
                  <option value="5" <?php if ($org2->fields["priv"] == 5) echo "selected"; ?>>Normal User</option>
                  <option value="6" <?php if ($org2->fields["priv"] == 6) echo "selected"; ?>>Master User</option>
                  <option value="7" <?php if ($org2->fields["priv"] == 7) echo "selected"; ?>>Supervisor (all)</option>
               </select>
			 </td>
          <td colspan="2">Demo e Test non inviano SMS</td>
		 </tr>
	   <tr class="row_even">
            <td nowrap align="right">Tipo Connessione:</td>
            <td colspan="3">
               <select name="sistemconnect">
			   	  <option value="" <?php if ($org2->fields["connext_type"] == "") echo "selected"; ?>>--- Please Select ---</option>	
                  <option value="oto" <?php if ($org2->fields["connext_type"] == "oto") echo "selected"; ?>>One To One (1:1)</option>
                  <option value="fee" <?php if ($org2->fields["connext_type"] == "fee") echo "selected"; ?>>Credits con Fee</option> 
				  <option value="nnt" <?php if ($org2->fields["connext_type"] == "nnt") echo "selected"; ?>>Non Attivo</option>                 
               </select>
			 &nbsp;<font size="1" color="#E6FFF2">Credits con Fee:1 sms spedito,si toglie xx credits. One To One:1 sms spedito,si toglie 1 credito!</font>
			</td>
		 </tr>
		 <tr class="row_head"> 
      <td colspan="4"><b>Dati Aziendali</b></td>
    </tr>
		 <tr class="row_even"> 
      <td align="right">Rag. Sociale:</td>
      <td class="td_warn"> 
        <input type="text" name="company" size="59" value="<?php echo $org2->fields["company"]; ?>"><br><b><font size="2" color="#ffff00">Campo Obbligatorio !!!</font></b>
      </td>  
<?php
         if ($org2->fields["tax_exempt"] == "Y") { ?>
		 <td align="right" class="td_notice">Esente IVA?</td>
         <td class="td_notice"><input type="checkbox" name="tax_exempt" value="Y" checked></td> <?php
         } else { ?>
		 	<td align="right">Esente IVA?</td>
            <td><input type="checkbox" name="tax_exempt" value="Y"></td> <?php
         } ?>

    </tr>
    <tr class="row_even"> 
      <td align="right">Sede principale:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="59" value="<?php echo $org2->fields["address1"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede secondaria:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="59" value="<?php echo $org2->fields["address2"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Citt�:</td>
      <td>
	  	<input type="text" name="city" size="59" value="<?php echo $org2->fields["city"]; ?>">
	  </td>
      <td align="right">Provincia:</td>
      <td>
	 <?php 
	 	$org = $org2;
	 include("ItProvSelect.inc.php"); ?>
	  </td>
    </tr>
	 <tr class="row_even">
      	<td align="right">CAP/ZIP:</td>
      	<td><input type="text" name="zip_code" size="6" value="<?php echo $org2->fields["zip_code"]; ?>">
		&nbsp;Country:&nbsp;<input type="text" name="country" size="15" value="<?php echo $org2->fields["country"]; ?>">
		</td>	
    	<td align="right">Part.IVA:</td>
      	<td>
		<input type="text" name="PIVA" size="20" value="<?php echo $org2->fields["PIVA"]; ?>">
		</td>		
    </tr>	
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information of Assiplan's Customer</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Nome e Cognome:</td>
      <td> 
        <input type="text" name="contact" size="30" value="<?php echo $org2->fields["contact"]; ?>">
      </td>
	  <td bgcolor="#FC5301" align="right">E-Mail:</td>
      <td bgcolor="#FC5301"> 
        <input type="text" name="email" size="30" value="<?php echo $org2->fields["email"]; ?>">&nbsp;
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="phone" size="20" value="<?php echo $org2->fields["phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="fax" size="20" value="<?php echo $org2->fields["fax"]; ?>">
      </td>
    </tr>
	<?PHP
// questa parte non serve se si utilizza l'interfaccia KANNEL
/*
	<tr class="row_yellowdark"> 
      <td align="right">Gateway Account/User:</td>
      <td> 
        <input type="text" name="gway_account" size="30" value="< ?php echo $org2->fields["gway_account"]; ? >">
      </td>
      <td align="right">Gateway Password:</td>
      <td> 
        <input type="text" name="gway_pass" size="20" value="< ?php echo $org2->fields["gway_pass"]; ? >">
      </td>
    </tr>
*/
?>
         <tr class="row_even"> 
            <td nowrap align="right">Commenti da Admin:</td>
            <td> 
               <textarea name="master_comments" cols="50" rows="3" wrap="VIRTUAL"><?php echo $org2->fields["master_comments"]; ?></textarea>
            </td>
         <?php
		 // td_warn
         if ($org2->fields["auth_adm"] == "Y") { ?>
		 	<td align="right" class="td_warn" colspan="2">L'utente pu� inviare sms?&nbsp;<input type="checkbox" name="auth_adm" value="Y" checked><b>Utente Abilitato!!!</b></td> <?php
         } else { ?>
		 	<td align="right" colspan="2">L'utente pu� inviare sms?&nbsp;<input type="checkbox" name="auth_adm" value="Y"></td> <?php
         } ?>
         </tr>         
         <tr class="row_even_hg"> 
            <td colspan="4" nowrap> 
				<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" alt="Enter" align="middle"
                  onClick="document.form2.submit();">
               <img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
                  onClick="document.form2.reset();">
				<img src="<?PHP echo $imgs_admin_dir ?>delete_elimina.gif" alt="Delete <?php echo $auid; ?>" border="0" align="middle"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Organization ?')) { window.location='admin_sms.php?action=delete&auid=<?php echo $auid; ?>'; }">
               <a href="admin_sms.php?action=cancel">
		<img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
				</a>
           		</div>
         </tr>
		 <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
   	  <input type="hidden" name="auid" value="<?php echo $auid; ?>">
      <input type="hidden" name="action" value="orgt_update">
      </form>
   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
<tr>
    <td><div align="center">
		<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000fff">
	Il campo <b>E-Mail</b> &egrave; evidenziato in quanto qui si deve inserire l'indirizzo a cui far arrivare reports logs vari!!!
		</font></div>
	</td>
</tr>
</table>

   <br>
 <?php require("help_privs.inc.php"); ?>
   <script language="JavaScript">
      document.form2.uname.focus();
   </script> <?php
} ?>
	
<?php
function new_config_form($db) { 
$confs = $db->Execute("SELECT * FROM config WHERE id_config='1'");
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="formConf" method="post" action="admin_sms.php">
         <tr class="row_head"> 
            <td colspan="2" nowrap><b>CONFIGURAZIONE DEL PROGRAMMA KSMS</b></td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Project Name:</td>
            <td> 
               <input type="text" name="project_name" size="40" value="<?php echo $confs->fields["project_name"]; ?>">&nbsp;&nbsp;<font size="-2">(KeySMS)</font>
            </td>
         </tr>
		<tr class="row_even">
			<td nowrap align="right">DIR admin-images,with trailing slashes!:</td>
            <td> 
               <input type="text" name="imgs_admin_dir" size="40" value="<?php echo $confs->fields["imgs_admin_dir"]; ?>">&nbsp;&nbsp;<font size="-2">(RELATIVE to &quot;admin directory&quot;  <b>../img/admin/</b>)</font>
            </td>
		</tr>
         <tr class="row_even">
			<td nowrap align="right">DIR public-images,with trailing slashes! :</td>
            <td> 
               <input type="text" name="imgs_pub_dir" size="40" value="<?php echo $confs->fields["imgs_pub_dir"]; ?>">&nbsp;&nbsp;<font size="-2">(RELATIVE to &quot;public directory&quot; <b>/img/pub/</b>)</font>
            </td>
		</tr>
        <tr class="row_even">
			<td nowrap align="right">Admin Name:</td>
            <td> 
               <input type="text" name="adm_login" size="40" value="<?php echo $confs->fields["adm_login"]; ?>">&nbsp;&nbsp;<font size="-2">(Admin username to login (usually <b>&quot;admin&quot;</b>)</font>
            </td>
		</tr>
        <tr class="row_even">
			<td nowrap align="right">Admin Password:</td>
            <td> 
               <input type="password" name="adm_pass1" size="40">
            </td>
		</tr>
        <tr class="row_even">
			<td nowrap align="right">Retype Password:</td>
            <td> 
               <input type="password" name="adm_pass2" size="40">
            </td>
         <tr class="row_even"> 
            <td nowrap align="right">Email principale a cui inviare conferma sms inviati:</td>
            <td> 
               <input type="text" name="email_admin" size="40" value="<?php echo $confs->fields["email_admin"]; ?>">&nbsp;&nbsp;<font size="-2">(emailAdmin)</font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Email secondaria a cui inviare conferma sms inviati:</td>
            <td> 
               <input type="text" name="email_copy" size="40" value="<?php echo $confs->fields["email_copy"]; ?>">&nbsp;&nbsp;<font size="-2">(emailCopy)</font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Path completa per lo storage delle sessioni:</td>
            <td> 
               <input type="text" name="session_path" size="40" value="<?php echo $confs->fields["session_path"]; ?>">&nbsp;&nbsp;<font size="-2">[not in use, at this moment]</font>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Path relativa per lo storage dei reports di invio:</td>
            <td> 
               <input type="text" name="reports_path" size="40" value="<?php echo $confs->fields["reports_path"]; ?>">&nbsp;&nbsp;<font size="-2">(eg.: <b>&quot;Reports&quot;</b>, no traling slash)</font>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">URL relativo del programma :</td>
            <td> 
               <input type="text" name="rel_prgmURL" size="40" value="<?php echo $confs->fields["prgmURL"]; ?>">&nbsp;&nbsp;<font size="-2">No trailing slashes! eg:(<b>sms</b>)</font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Data Inserimento Nuova Config:</td>
            <td> 
               <input type="text" name="ins_date" value="<?php echo $confs->fields["ins_date"]; ?>">&nbsp;&nbsp;<font size="-2">(YYYY-MM-DD)</font>
            </td>
         </tr>
         <tr class="row_even_hg"> 
            <td colspan="2" nowrap>
			<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" alt="Enter" align="middle"
                  onClick="document.formConf.submit();">
             <img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
                  onClick="document.formConf.reset();">
               <a href="admin_sms.php?action=cancel">
               <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
				  </a></div>
            </td>
         </tr>
      <input type="hidden" name="action" value="configupdate">
      </form>
   </table>
   <br>
   <script language="JavaScript">
      document.formConf.email_admin.focus();
   </script> <?php
} ?>

<?php
function paint_table($db) { 
   $summary = $db->Execute("SELECT id, username, company, email, vendor, auth_adm, priv, connext_type FROM organization ORDER BY username");
?>
   <table border="0" width="100%" cellspacing="0" cellpadding="1"><tr class="row_even"><td>
      <!-- 
	  <a href="admin_sms.php?action=new">
         <img src="../images/new_user_xp.gif" alt="Add New User" border="0"></a>
      <a href="admin_sms.php?action=po_info">
	 
         <img src="../images/po_info_xp.gif" alt="Edit PO Information" border="0"></a>
      <a href="admin_sms.php?action=inv_info">
         <img src="../images/inv_info_xp.gif" alt="Edit Invoice Information" border="0"></a>
	   -->
   </td></tr></table>
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>Username</b></td>
         <td><b>Company</b></td>
         <td><b>E-Mail Address</b></td>
		 <td><b>Vendit.Associato</b></td>
		 <td align="center"><b>Connessione</b></td>
		 <td align="center"><b>Invia Sms?</b></td>
         <td><b>Privilege</b></td>
      </tr> <?php
      $i = 1;
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?> 
            <td>
               <a href="admin_sms.php?action=edit&auid=<?php echo $summary->fields["id"]; ?>" class="wlink">
                  <?php echo $summary->fields["username"]; ?></a>
            </td>
            <td><?php echo $summary->fields["company"]; ?></td>
            <td><?php echo $summary->fields["email"]; ?></td>
			<td><?php echo $summary->fields["vendor"]; ?></td>
			<td align="center"><?php echo $summary->fields["connext_type"]; ?></td>
			<td align="center"><?php echo $summary->fields["auth_adm"]; ?></td>
            <td> <?php
               $x = $summary->fields["priv"];
               switch ($x) {
                  case "1":
                     echo "Lock (no sms)";
                     break;
                  case "2":
                     echo "Demo (sms to screen)";
                     break;
                  case "3":
                     echo "Test (sms to email)";
                     break;
                  case "4":
                     echo "Guest (sms to email)";
                     break;
				  case "5":
                     echo "Normal User";
                     break;
				  case "6":
                     echo "Master User";
                     break;
				  case "7":
                     echo "Supervisor (all)";
                     break;
               } ?>
            </td>
         </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><div align="center"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#0450AC"><b>Tipo di connessione : <font color="#D31238">oto (OneToOne)</font> = 1 credito per 1 sms spedito! || <font color="#D31238">fee (sms_credits)</font> = xx crediti addebitati per 1 sms spedito! || <font color="#D31238">nnt</font> = non attivo!</b></font></div></td>
      </tr>
   </table>
     <br>
 <?php require("help_privs.inc.php");
} ?>

<?php
if ($privs == '69') {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         paint_table($db);
         break;
      case "delete":
         if (!$db->Execute("DELETE FROM organization WHERE id='$auid'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>User $prgmusername (id $auid) was deleted OK.</td></tr></table>";
         paint_table($db);
         break;
      case "edit":
         edit_org_form($db, $auid);
         break;
      case "insertorg":
	  	if ($company == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Company Field Is Required!.</td></tr></table>";
            new_org_form($db);
            break;
         }
         if ($prgmusername == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The Username field is required.</td></tr></table>";
            new_org_form($db);
            break;
         }
		 if ($sistemconnect == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Please select the type of connection! Seleziona il tipo di connessione (diretta o interconnect)</td></tr></table>";
            new_org_form($db);
            break;
         }
         if ((strlen($apasswd1) < 4) || ($apasswd1 != $apasswd2)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The password is less than 4 characters or the passwords don't match.</td></tr></table>";
            new_org_form($db);
            break;
         }
		 if (!isset($tax_exempt)) {
            $tax_exempt = "N";
         	} else {
		    $tax_exempt = "Y";
			}
		 if (!isset($sistemconnect)) {
            $sistemconnect = "fee";
         }
		 if (!isset($auth_adm)) {
            $auth_adm = "N";
         }
	$id = $db->GenID("organization_seq");
	$idvend = $db->Execute("SELECT id,name FROM vendor WHERE id = '$vendor'");
	$vnam = $idvend ->fields["name"];
	$vid = $idvend ->fields["id"];
	//echo "<table class=\"notice\" width=\"100%\"><tr><td>STOP!!! idvenditore=".$vid."</td></tr><tr><td>nome venditore= ".$vnam."</td></tr></table><br><br>";
	$idprov = $db->Execute("SELECT name_gwprovider,id FROM gwprovider WHERE id = '$gway_provider'");
	$gwnam = $idprov ->fields["name_gwprovider"];
	$gwid = $idprov ->fields["id"];
	$gway_account = "";
	$gway_pass = "";
	if (!isset($tax_exempt)) {
		$tax_exempt = "N";
		  } else {
		$tax_exempt = "Y";
		   }
	//echo "<table class=\"notice\" width=\"100%\"><tr><td>--- id provider= ".$gwid."</td></tr><tr><td>nome provider = ".$gwnam."</td></tr></table><br><br>";
         $query = "INSERT INTO organization (intid, username, password, vendor, id_vendor, priv, company, address1, address2, city, province, country, zip_code, contact, PIVA, phone, fax, email, tax_exempt, auth_adm, gway_account, gway_pass, gway_provider, id_gwprovider, txt_head_sender, connext_type, master_comments)"
                . " VALUES ('$id', '$prgmusername','" . md5($apasswd1) . "', '$vnam', '$vid', '$privilege', '$company', '$address1', '$address2', '$city', '$province','$country', '$zip_code', '$contact', '$PIVA', '$phone', '$fax', '$email', '$tax_exempt', '$auth_adm', '$gway_account', '$gway_pass', '$gwnam', '$gwid', '$txt_head_sender', '$sistemconnect', '$master_comments')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if (isset($refer)) {
            require("footer.inc.php"); ?>
            <script language="JavaScript">
               window.location="<?php echo $refer; ?>";
            </script> <?php
         }
         echo "<table class='notice' width='100%'><tr><td>Organization Dictionary updated OK.<a href='admin_sms.php?action=new'><img src='".$imgs_admin_dir."add_btn.gif' border='0' alt='Add'></a> another new organization.</td></tr></table>";
         break;
      case "new":
         new_org_form($db);
         break;
      case "orgt_update":
	  		if ($company == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td><div align='center'>Please filled the field <b>&quot;Company&quot;</b> (required)! &divide; Inserisci un nome in <b>&quot;Rag.Sociale&quot;</b> (campo richiesto)</div></td></tr></table>";
            // new_org_form($db);
			edit_org_form($db, $auid);
            break;
         	}
	  		$idvend = $db->Execute("SELECT id,name FROM vendor WHERE id = '$vendor'");
			//$org2 = $db->Execute("SELECT * FROM organization WHERE id='$auid'");
			$vnam = $idvend ->fields["name"];
			$vids = $vendor;
			$idprov = $db->Execute("SELECT name_gwprovider,id FROM gwprovider WHERE id = '$gway_provider'");
			$gwnm = $idprov ->fields["name_gwprovider"];
			$gwid = $gway_provider;
		if ($sistemconnect == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Please select the type of connection! Seleziona il tipo di connessione (diretta o interconnect)</td></tr></table>";
            // new_org_form($db);
			edit_org_form($db, $auid);
            break;
         	}
		if (!isset($sistemconnect)) {
            $sistemconnect = "fee";
         }
		 if (!isset($auth_adm)) {
            $auth_adm = "N";
         }
		if (!isset($tax_exempt)) {
			$tax_exempt = "N";
		  	  } else {
			$tax_exempt = "Y";
		   	  }
	//echo "<table class=\"notice\" width=\"100%\"><tr><td>STOP!!! idvenditore=".$vids."</td></tr><tr><td>nome venditore= ".$vnam."</td></tr></table><br><br>";
	//echo "<table class=\"notice\" width=\"100%\"><tr><td>--- id provider= ".$gwid."</td></tr><tr><td>nome provider = ".$gwnm."</td></tr></table><br><br>";
	//  break;
		$gway_account = "";
		$gway_pass = "";
         if ($apasswd1 == "") {
		//non utilizzate qui ---> | smscredits_buyed | smscredits_sended |
            $query = "UPDATE organization SET"
	. " username='$uname', vendor='$vnam', id_vendor='$vids', priv='$privilege', company='$company',"
	. " address1='$address1', address2='$address2', city='$city', province='$province',"
	. " country='$country', zip_code='$zip_code', contact='$contact', PIVA='$PIVA', phone='$phone',"
	. " fax='$fax', email='$email', tax_exempt='$tax_exempt', auth_adm='$auth_adm',"
	. " gway_account='$gway_account', gway_pass='$gway_pass', gway_provider='$gwnm',"
	. " id_gwprovider='$gwid',txt_head_sender='$txt_head_sender', connext_type='$sistemconnect', master_comments='$master_comments'"
	. " WHERE id='$auid'";
         } else if ((strlen($apasswd1) >= 4) && ($apasswd1 == $apasswd2)) {
            $query = "UPDATE organization SET"
        . " username='$uname', password='" . md5($apasswd1) . "', vendor='$vnam', id_vendor='$vids',"
		. " priv='$privilege', company='$company',address1='$address1', address2='$address2',"
        . " city='$city',province='$province',country='$country', zip_code='$zip_code',"
        . " contact='$contact', PIVA='$PIVA', phone='$phone',fax='$fax', email='$email',"
        . " tax_exempt='$tax_exempt', auth_adm='$auth_adm', gway_account='$gway_account',"
		. " gway_pass='$gway_pass',gway_provider='$gwnm', id_gwprovider='$gwid',"
		. " txt_head_sender='$txt_head_sender', connext_type='$sistemconnect',"
		. " master_comments='$master_comments'"
        . " WHERE id='$auid'";
         } else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The password is less than 4 characters or the passwords don't match.</td></tr></table>";
            edit_org_form($db, $auid);
            break;
         }
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         paint_table($db);
         break;
		 case "configupdate":
		 if ($adm_pass1 == "") {
            $query = "UPDATE config SET"
					. " project_name='$project_name', imgs_admin_dir='$imgs_admin_dir',"
					. " imgs_pub_dir='$imgs_pub_dir',adm_login='$adm_login', "
                   	. " email_admin='$email_admin', email_copy='$email_copy',"
					. " session_path='$session_path',"
                   	. " reports_path='$reports_path', ins_date='$ins_date', prgmURL='$rel_prgmURL'"
					. " WHERE id_config='1'";
					} else if ((strlen($adm_pass1) >= 4) && ($adm_pass1 == $adm_pass2)) {
            $query = "UPDATE config SET"
					. " project_name='$project_name', imgs_admin_dir='$imgs_admin_dir',"
					. " imgs_pub_dir='$imgs_pub_dir', adm_login='$adm_login', "
                   	. " adm_pass='" . md5($adm_pass1) . "', email_admin='$email_admin',"
					. " email_copy='$email_copy',session_path='$session_path',"
                   	. " reports_path='$reports_path', ins_date='$ins_date', prgmURL='$rel_prgmURL'"
					. " WHERE id_config='1'";
		} else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The password is less than 4 characters or the passwords don't match.</td></tr></table>";
            new_config_form($db, $auid);
            break;
		}
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
		 case "newconfi":
         new_config_form($db);
         break;
      default:
      //new_config_form($db); 
	  paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer2.inc.php");
?>
