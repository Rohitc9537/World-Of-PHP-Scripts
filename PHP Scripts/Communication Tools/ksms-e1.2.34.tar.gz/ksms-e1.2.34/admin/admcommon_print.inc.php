<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		| 	admcommon_print.inc.php*/

require("admconfig.inc.php");
$sesspth = $cfg["sespath"];
session_save_path($sesspth);
session_start();
if (!empty($_SESSION) && isset($_SESSION["adm_login"])) {
   $adm_login = $_SESSION["adm_login"];
   $project_name = $_SESSION["project_name"];
   $privs = $_SESSION["privs"];
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
} else {
   header("Status: 302 moved");
   header("Location: admlogin.php");
}

// Tell browsers not to cache this page
header("Expires: Mon, 23 Jul 2002 07:07:07 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");

// Include required files
require("admgrab_globals.inc.php");
require("admconnection.inc.php");
$title = "Administration Area";
?>