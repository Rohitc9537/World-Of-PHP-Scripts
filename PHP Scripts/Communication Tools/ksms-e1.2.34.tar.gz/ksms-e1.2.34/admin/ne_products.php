<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/
require("admcommon.inc.php"); 
?>

<?php  //*****INSERT-ADD***************
function new_price_form($db) {
	global $refer, $priv, $tax1, $internal_code, $descript1;
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   	   if (!$prices = $db->Execute("SELECT * FROM products ORDER BY descript1")) {
      echo "<table class='notice'><tr><td>DB ERROR: ".$db->ErrorMsg()."</td></tr></table>";
       break;
   		}
?>
<table bgcolor="#919DA2" width="502" cellspacing="2" cellpadding="2" border="0" align="center">
<tr>
    <td>
   <table class="kdefault" align="center" border="0" cellspacing="0" cellpadding="1" width="500">
      <form name="form1price" method="post" action="ne_products.php">
         <tr class="row_head"> 
            <td colspan="4" nowrap><b>LISTINO PREZZI VENDITA - Aggiunta di un prodotto o servizio</b></td>
         </tr>
         <tr class="row_even">
			 <td nowrap align="right">Codice:</td>
            <td colspan="3">
               <input type="text" name="internal_code" size="12" value="">&nbsp;&nbsp;Max 12 char.
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Descrizione 1:</td>
            <td colspan="3">
			   <input type="text" name="descript1" size="50" value="Pacchetto">&nbsp;&nbsp;Max 50 char.
            </td>
			<tr class="row_even"> 
            <td nowrap align="right">Descrizione 2:</td>
            <td colspan="3">
			   <input type="text" name="descript2" size="50" value="Crediti sms da inviare tramite gateway ksms">&nbsp;&nbsp;Max 90 char.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Unit� di misura:</td>
            <td colspan="3">
			   <select name="unit">
				<option value="Pz">Pz.</option>
				<option value="Kg">Kg.</option>
				<option value="Nr" selected>Nr.</option>
				<option value="NN">NN</option>
    		   </select>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Acquisto Pacchetto:</td>
            <td colspan="3">
		<input type="text" name="buyed_price" size="16" value="0">&nbsp;&nbsp;(senza I.V.A.) Riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Vendita Pacchetto:</td>
            <td colspan="3">
		<input type="text" name="sale_price" size="16" value="">&nbsp;&nbsp;(senza I.V.A.) Riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">% IVA:</td>
            <td colspan="3">
			   <input type="text" name="tax1" size="2" value="20">
            </td>
		</tr>
		 <tr class="row_even">
			<td nowrap align="right">Pezzi Pacchetto:</td>
            <td colspan="3">
			   <input type="text" name="single_packet_qty" size="8" value="">&nbsp; nr. di pezzi che compongono quanto in descrizione!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Descrizione Addizionale (es.:"interconnessione"):</td>
            <td colspan="3">
			  <input type="text" name="single_additional_descript" size="50" value="internetworking fee">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Prezzo Unitario Addizionale:</td>
            <td colspan="3">
		<input type="text" name="single_add_price" size="14" value="0.025">&nbsp;&nbsp; 3 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Crediti Addebitati x ogni invio:</td>
            <td colspan="3">
		<input type="text" name="credits_sale_value" size="14" value="1.7884">&nbsp;&nbsp; 4 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even">
            <td colspan="4">
				<hr width="100%" color="#ffff00">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Acquisto:</td>
            <td colspan="3">
			   <input type="text" name="single_purchase_price" size="14" value="0.000">&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Vendita:</td>
            <td colspan="3">
			   <input type="text" name="single_sale_price" size="14" value="0.000">&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">IDFornitore:</td>
            <td colspan="3">
		<input type="text" name="ID_fornit" size="11" value="" disabled>&nbsp;non usato!!!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Produttore:</td>
            <td colspan="3">
		<input type="text" name="manufacturer" size="30" value="">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Marca:</td>
            <td colspan="3">
		<input type="text" name="brand" size="30" value="">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Scheda Inserita Da:</td>
            <td colspan="3">
			   <select name="created_by">
				<option selected value="Paolo">Paolo</option>
				<option value="Carlo">Carlo</option>
				<option value="Riccardo">Riccardo</option>
				<option value="Barbara">Barbara</option>
    		   </select>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Formato del prodotto:</td>
            <td colspan="3">
			   <select name="pr_available">
				<option value="N" selected>Not Available</option>
				<option value="P">Package</option>
				<option value="W">On Line (web)</option>
				<option value="L">On Local PC</option>
				<option value="I">Internal Use Only</option>
				<option value="T">Not Specified</option>
    		   </select>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Commenti:</td>
            <td> 
               <textarea name="master_comments" cols="50" rows="2" wrap="VIRTUAL"></textarea>
            </td>
         </tr>
		 <tr class="row_foot"> 
         <td colspan="2"> <div align="center">
            <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" align="middle" border="0" alt="Add Price"
               onClick="document.form1price.submit();">
			<img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
                  onClick="document.form1price.reset();">
            <a href="ne_products.php?action=cancel">
               <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" align="middle" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
		 <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
      <input type="hidden" name="action" value="insprice">
      </form>
   </table>
</td>
</tr>
</table>
<div align="center">  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#D31238">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font></div>   
   <br>
   <script language="JavaScript">
      document.form1price.internal_code.focus();
   </script> <?php
} 

//-------   EDIT ---------------//
function edit_price_form($db, $pruid) {
   global $internal_code, $pruid, $priv;
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   	   if (!$prices = $db->Execute("SELECT * FROM products WHERE ID='$pruid'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } 
   if ($pruid == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid ID.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if ($prices->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Nessun prezzo trovato nel database.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
 ?>
   <table class="kdefault" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form2" method="post" action="ne_products.php">
	  <tr class="row_head">
            <td colspan="4" nowrap><b>MODIFICA LISTINO PREZZI</b></td>
         </tr>
		 <tr class="row_even">
			 <td nowrap align="right">Codice:</td>
            <td colspan="3">
            <input type="text" name="internal_code" size="12" value="<?php echo $prices->fields["internal_code"]; ?>">&nbsp;&nbsp;Max 12 char.
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Descrizione 1:</td>
            <td colspan="3">
			   <input type="text" name="descript1" size="50" value="<?php echo $prices->fields["descript1"]; ?>">&nbsp;&nbsp;Max 50 char.
            </td>
			<tr class="row_even"> 
            <td nowrap align="right">Descrizione 2:</td>
            <td colspan="3">
			   <input type="text" name="descript2" size="50" value="<?php echo $prices->fields["descript2"]; ?>">&nbsp;&nbsp;Max 50 char.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Unit� di misura:</td>
            <td colspan="3">
			   <select name="unit">
		<option value="Pz" <?php if ($prices->fields["unit_m"] == "Pz") echo "selected"; ?>>Pz.</option>			   
		<option value="Kg" <?php if ($prices->fields["unit_m"] == "Kg") echo "selected"; ?>>Kg.</option>
		<option value="Nr" <?php if ($prices->fields["unit_m"] == "Nr") echo "selected"; ?>>Nr.</option>
		<option value="NN" <?php if ($prices->fields["unit_m"] == "NN") echo "selected"; ?>>NN</option
              </select>
		</td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Acquisto:</td>
            <td colspan="3">
			   <input type="text" name="buyed_price" size="14" value="<?php echo $prices->fields["buyed_price"]; ?>">&nbsp;(senza I.V.A.) Costo riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Vendita:</td>
            <td colspan="3">
			   <input type="text" name="sale_price" size="14" value="<?php echo $prices->fields["sale_price"]; ?>">&nbsp;(senza I.V.A.) Costo riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">% IVA:</td>
            <td colspan="3">
		<input type="text" name="tax1" size="2" value="<?php echo $prices->fields["tax1"]; ?>">
            </td>
		</tr>
		 <tr class="row_even">
			<td nowrap align="right">Pezzi Pacchetto:</td>
            <td colspan="3">
		<input type="text" name="single_packet_qty" size="8" value="<?php echo $prices->fields["single_packet_qty"]; ?>">&nbsp; nr. di pezzi che compongono quanto in descrizione!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Descrizione Addizionale (es.:"interconnessione"):</td>
            <td colspan="3">
		<input type="text" name="single_additional_descript" size="50" value="<?php echo $prices->fields["single_additional_descript"]; ?>">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Prezzo Unitario Addizionale:</td>
            <td colspan="3">
		<input type="text" name="single_add_price" size="14" value="<?php echo $prices->fields["single_add_price"]; ?>">&nbsp;&nbsp; 3 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Crediti Addebitati x ogni invio:</td>
            <td colspan="3">
		<input type="text" name="credits_sale_value" size="14" value="<?php echo $prices->fields["credits_sale_value"]; ?>">&nbsp;&nbsp; 4 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even">
            <td colspan="4">
				<hr width="100%" color="#D31238">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Acquisto:</td>
            <td colspan="3">
			   <input type="text" name="single_purchase_price" size="14" value="<?php echo $prices->fields["single_purchase_price"]; ?>">&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Vendita:</td>
            <td colspan="3">
			   <input type="text" name="single_sale_price" size="14" value="<?php echo $prices->fields["single_sale_price"]; ?>">&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">IDFornitore:</td>
            <td colspan="3">
		<input type="Text" name="ID_fornit" size="11" value="<?php echo $prices->fields["ID_fornit"]; ?>" disabled>&nbsp;non usato!!!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Produttore:</td>
            <td colspan="3">
		<input type="text" name="manufacturer" size="30" value="<?php echo $prices->fields["manufacturer"]; ?>">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Marca:</td>
            <td colspan="3">
		<input type="text" name="brand" size="30" value="<?php echo $prices->fields["brand"]; ?>">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Scheda Inserita Da:</td>
            <td colspan="3">
			   <select name="created_by">
		<option value="Paolo" <?php if ($prices->fields["created_by"] == "Paolo") echo "selected"; ?>>Paolo</option>
        <option value="Carlo" <?php if ($prices->fields["created_by"] == "Carlo") echo "selected"; ?>>Carlo</option>
        <option value="Riccardo" <?php if ($prices->fields["created_by"] == "Riccardo") echo "selected"; ?>>Riccardo</option>
		<option value="Barbara" <?php if ($prices->fields["created_by"] == "Barbara") echo "selected"; ?>>Barbara</option>
    		   </select>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Formato del prodotto:</td>
            <td colspan="3">
			   <select name="pr_available">
		<option value="N" <?php if ($prices->fields["available"] == "N") echo "selected"; ?>>Not Available</option>
		<option value="P" <?php if ($prices->fields["available"] == "P") echo "selected"; ?>>Package</option>
		<option value="W" <?php if ($prices->fields["available"] == "W") echo "selected"; ?>>On Line (web)</option>
		<option value="L" <?php if ($prices->fields["available"] == "L") echo "selected"; ?>>On Local PC</option>
		<option value="I" <?php if ($prices->fields["available"] == "I") echo "selected"; ?>>Internal Use Only</option>
		<option value="T" <?php if ($prices->fields["available"] == "T") echo "selected"; ?>>Not Specified</option>
    		   </select>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Commenti:</td>
            <td> 
               <textarea name="master_comments" cols="50" rows="2" wrap="VIRTUAL"><?php echo $prices->fields["comments"]; ?></textarea>
            </td>
         </tr>
         </tr>         
         <tr class="row_even"> 
            <td colspan="4" nowrap>
			<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" align="middle" border="0" alt="Enter"
                  onClick="document.form2.submit();">
              <img src="<?PHP echo $imgs_admin_dir ?>reset.gif" alt="reset all in the form!" width="100" height="31" border="0" align="middle"
                  onClick="document.form2.reset();">
				<img src="<?PHP echo $imgs_admin_dir ?>delete_elimina.gif" align="middle" alt="Delete <?php echo $pruid; ?>" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Products ?')) { window.location='ne_products.php?action=delete&ID=<?php echo $pruid; ?>'; }">
               <a href="ne_products.php?action=cancel">
              <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
				  </a></div>
            </td>
         </tr>
		 <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
   	  <input type="hidden" name="ID" value="<?php echo $pruid; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <div align="center">  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#D31238">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font></div>
   <br>
   <script language="JavaScript">
      document.form2.internal_code.focus();
   </script> <?php
} ?>
	


<?php
function paint_table($db) {
include("admconfig.inc.php");
   	$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	$crr = $cfg["curr"];
   	$psummary = $db->Execute("SELECT * FROM products ORDER BY internal_code");
?>
	<table align="center" bgcolor="#919DA2" cellspacing="2" cellpadding="2" border="0">
<tr>
    <td><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="3" color="#F8FB82"><b>Listino Prezzi di vendita</b></font></td>
</tr>
</table>

   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td align="center"><b>Cod</b></td>
         <td><b>Descr.1</b></td>
		 <td><b>Descr.2</b></td>
         <td align="right"><b>VENDI (pack)</b></td>
		 <td align="right"><b>Addizionale</b></td>
		 <td align="right"><b>%IVA</b></td>
		 <td align="right"><b>Prezzo Singolo</b></td>
         <td align="center"><b>Disp.?</b></td>
      </tr> <?php
      $i = 1;
      while (!$psummary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_fst\">";
         } else {
            echo "<tr class=\"row_scd\">";
         } ?> 
	<td>
               <a href="ne_products.php?action=edit&ID=<?php echo $psummary->fields["ID"]; ?>">
                  <?php echo $psummary->fields["internal_code"]; ?></a>
            </td>
	<?php
			$desc1=$psummary->fields["descript1"];
			$desc01=substr($desc1, 0, 30);
			$desc2=$psummary->fields["descript2"];
			$desc02=substr($desc2, 0, 30);
			 ?>
			 		
		<td><a href="ne_products.php?action=edit&pruid=<?php echo $psummary->fields["ID"]; ?>"><b><?php echo $desc01; ?>...</b></a></td>
		<td class="descrtx"><?php echo $desc02; ?>...</td>
		<td class="descrtx" align="right"><b><?php echo $crr.$psummary->fields["sale_price"]; ?></b></td>
		<td class="descrtx" align="right"><?php echo $crr.$psummary->fields["single_add_price"]; ?></td>
		<td class="descrtx" align="right"><?php echo $psummary->fields["tax1"]; ?></td>
		<td class="descrtx" align="right"><?php echo $psummary->fields["single_sale_price"]; ?></td>
		<td class="descrtx" align="center"><?php echo $psummary->fields["available"]; ?></td>
         </tr> <?php
         $i++;
         $psummary->MoveNext();
      } ?>
	 <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_products.php?action=addprice">
			<img src="<?PHP echo $imgs_admin_dir ?>Add-Aggiungi.gif" border="0" alt="Aggiungi Prezzo">
			   </a></div></td>
      </tr>
   </table>
   <p class="small">&nbsp;&nbsp;DISPONIBILITA' : N = Not Available, P = Package, W =On Line (web), L = On Local PC, I = Internal Use Only, T = Not Specified</p>
 <?php
} ?>

<?php
if ($privs == '69') {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
	  echo "<table class=\"notice\" width=\"100%\"><tr><td>Operazione Annullata !!!</td></tr></table>";
         paint_table($db);
         break;
      case "delete":
	  	   $prdel = $db->Execute("SELECT id, descript1 FROM productst WHERE ID='$ID'");
		   $pritem = $psummary->fields["descript1"];
         if (!$db->Execute("DELETE FROM products WHERE ID='$ID'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Cancellato senza errori! Articolo : $pritem.</td></tr></table>";
         paint_table($db);
         break;
	  case "addprice":
         new_price_form($db);
         break;
      case "edit":
         edit_price_form($db, $pruid);
         break;
      case "insprice":
	  if ($descript1 == "" AND $internal_code == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Devi inserire <b>codice</b> e <b>descrizione primaria</b>!</td></tr></table>";
            new_price_form($db);
            break;
         }
	  if ($internal_code == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Il <b>codice prodotto</b> deve essere inserito.</td></tr></table>";
            new_price_form($db);
            break;
         }
         if ($descript1 == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Inserisci almeno una <b>descrizione principale</b>.</td></tr></table>";
            new_price_form($db);
            break;
         }
		 if (!isset($tax1)) {
            $tax1 = "20";
         }
		 $ins_date = date("Y-m-d");
		 $addebito_credits_sms = $addebito_credits;
 //        $query = "INSERT INTO products (internal_code, ins_date, descript1, descript2, unit_m, single_purchase_price, sale_unit_price, tax1, additional_price_descript, additional_price, credit_debited_value, amount_price, ID_fornit, manufacturer, brand, created_by, available, comments)"
//			. " VALUES ('$internal_code', '$ins_date', '$descript1', '$descript2', '$unit', '$single_purchase_price', '$sale_unit_price', '$tax1', '$additional_price_descript', '$additional_price', '$credit_debited_value', '$amount_price', '$ID_fornit', '$manufacturer', '$brand', '$created_by', '$pr_available', '$comments')";
			$query = "INSERT INTO products (internal_code, ins_date, descript1, descript2, unit_m, buyed_price, sale_price, tax1, single_packet_qty, single_additional_descript, single_add_price, single_purchase_price, single_sale_price, credits_sale_value, ID_fornit, manufacturer, brand, created_by, available, comments)"
			. " VALUES ('$internal_code', '$ins_date', '$descript1', '$descript2', '$unit', '$buyed_price', '$sale_price', '$tax1', '$single_packet_qty', '$single_additional_descript', '$single_add_price', '$single_purchase_price', '$single_sale_price', '$credits_sale_value', '$ID_fornit', '$manufacturer', '$brand', '$created_by', '$pr_available', '$comments')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if (isset($refer)) {
            require("footer.inc.php"); ?>
            <script language="JavaScript">
               window.location="<?php echo $refer; ?>";
            </script> <?php
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Prodooto e prezzo inseriti.<a href=\"ne_products.php?action=new\"><img src=\"".$imgs_admin_dir."add_btn.gif\" border=\"0\" alt=\"Add\"></a> un nuovo prodotto.</td></tr></table>";
         break;
      case "new":
         new_price_form($db);
         break;
      case "update":
         if ($descript1 == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Inserisci almeno una descrizione principale.</td></tr></table>";
            new_price_form($db);
            break;
         }
         if ($internal_code == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Il codice prodotto deve essere inserito.</td></tr></table>";
            new_price_form($db);
            break;
         }
		 	$addebito_credits_sms = $addebito_credits;
			$ID_fornit = "0000";
            $queryupd = "UPDATE products SET"
   . " internal_code='$internal_code', descript1='$descript1', descript2='$descript2',"
   . " unit_m='$unit', buyed_price='$buyed_price', sale_price='$sale_price', tax1='$tax1',"
   . " single_packet_qty='$single_packet_qty', single_additional_descript='$single_additional_descript',"
   . " single_add_price='$single_add_price', single_purchase_price='$single_purchase_price',"
   . " single_sale_price='$single_sale_price', credits_sale_value='$credits_sale_value',"
   . " ID_fornit='$ID_fornit', manufacturer='$manufacturer',brand='$brand', created_by='$created_by',"
   . " available='$pr_available', comments='$master_comments'"
   . " WHERE ID='$ID'";
         if (!$db->Execute($queryupd)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
		echo "<table class=\"notice\" width=\"100%\"><tr><td>Prodotto aggiornato!</td></tr></table>";
         paint_table($db);
         break;
      default:
	  paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer2.inc.php");
?>
