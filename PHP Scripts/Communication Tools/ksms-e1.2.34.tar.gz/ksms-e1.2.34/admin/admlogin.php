<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Copyright (C) 2002-2005 Paolo Remonato                                   //
// http://www.assiplan.it/sms/                                              //
// -------------------------------------------------------------------------//
// version: (see /KSMS/vers.inc.php)										//
// -------------------------------------------------------------------------//

require("admconfig.inc.php");
$sesspth = $cfg["sespath"];
session_save_path($sesspth);
session_start();
unset($adm_login, $project_name, $imgs_admin_dir, $imgs_pub_dir, $privs);
require("admgrab_globals.inc.php");
require("admconnection.inc.php");
require("admheadlog.inc.php");

      if (!$adconf = $db->Execute("SELECT * FROM config")) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>DB SELECT_ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
         break;
      }
$imgs_pub_dir=$adconf->fields["imgs_pub_dir"];
$imgs_admin_dir=$adconf->fields["imgs_admin_dir"];

function user_form() { 
?>
   <table class="default" border="0" cellpadding="10" width="100%"><tr><td>
      <table class="default" border="0" cellpadding="0" cellspacing="0" width="100%">
         <tr>
            <td align="left">
               <a href="../../KSMS/">
                  <img src="../images/logoKS.gif" alt="visit our main site!" width="199" height="84" border="0">
				  </a>
               <hr>
            </td>
            <td align="center">
			<img src="../images/base.gif" alt="KSMS BY ASSIPLAN.IT" width="107" height="149" border="0">
            </td>
         </tr>
      </table>
      <table class="default" align="center" border="0" cellpadding="1" cellspacing="0">
         <form action="admlogin.php" method="post" name="form1">
         <tr class="row_head">
            <td align="center" colspan="2"><b>Per accedere, inserisci username e password fornite</b></td>
         </tr>
         <tr class="row_even">
            <td align="center" colspan="2">&nbsp;</td>
         </tr>
         <tr class="row_even">
            <td align="right">Username:</td>
            <td><input type="text" name="auid" size="16"></td>
         </tr>
         <tr class="row_even">
            <td align="right">Password:</td>
            <td><input type="password" name="apasswd" size="16" value=""></td>
         </tr>
         <tr class="row_even">
            <td colspan="2">
               <input type="submit" value="Login"
            </td>
         </tr>
         <input type="hidden" name="action" value="check_user">
         </form>
      </table>
	  <br>
	<div align="center"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#FC5301">  La pagina di help e' nel menu' sotto la voce <b>Services</b></font></div>
   </td></tr></table>
   <script language="JavaScript">
      document.form1.auid.focus();
   </script> 
   
  <?php
}

$action = strtolower($action);
switch ($action) {
   case "check_user":
      if (!$user = $db->Execute("SELECT * FROM config WHERE adm_login='$auid'")) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
         break;
      }
      if ($user->RecordCount() > 0) {
         if (md5($apasswd) != $user->fields["adm_pass"]) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Password. </td></tr></table><br><br>";
            user_form();
            break;
         }
         $_SESSION["adm_login"] = $user->fields["adm_login"];
         $_SESSION["project_name"] = $user->fields["project_name"];
         $_SESSION["imgs_pub_dir"] = $user->fields["imgs_pub_dir"];
		 $_SESSION["imgs_admin_dir"] = $user->fields["imgs_admin_dir"];
		 $_SESSION["privs"] = $user->fields["adm_privs"];
         require("footer2.inc.php"); ?>
         <script language="JavaScript">
            window.location="index.php";
         </script> <?php
      }
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Username.</td></tr></table>";
      user_form();
      break;
   default:
      user_form();
      break;
}

require("footer2.inc.php"); ?>
