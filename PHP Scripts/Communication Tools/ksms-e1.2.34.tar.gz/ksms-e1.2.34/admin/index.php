<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

require("admcommon.inc.php"); ?>
<table border="0" cellpadding="10" width="100%"><tr><td>
   <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
         <td align="left">
            <b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="7" color="#D31238">ADMIN AREA</font></b>
            <hr>
         </td>
         <td align="center">
           <img src="../images/base.gif" alt="KSMS BY viabazar.com" width="107" height="149" border="0">
         </td>
      </tr>
   </table>
   <p class="default"><?php echo $cfg["signature"]; ?></p>
   <p class="default">ADMIN-PAGE. Ogni accesso viene controllato!<br> L'accesso a queste pagine � strettamente riservato, per cui vi invitiamo a non proseguire e di abbandonare la visione di questa parte del nostro sito wb se <b>NON SIETE ESPRESSAMENTE AUTORIZZATI</b>! Queste pagine <b>NON</b> contengono dati segreti, ma solo codici pubblici e programmi sperimentali.</p>

   <p class="default">Admin, <a href="admin_sms.php">clicca qui</a>.</p>
   
</td></tr></table>
<?php require("footer.inc.php"); ?>
