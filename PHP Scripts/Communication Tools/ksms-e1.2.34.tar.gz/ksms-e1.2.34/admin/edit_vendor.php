<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

require("admcommon.inc.php"); ?>

<?php
function vendor_form($db) {
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
      echo "DIRECTORY OF IMAGES HERE : ".$imgs_admin_dir."<br><br>";	
   if (!$vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="edit_vendor.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Choose Venditore:</td>
      <td>
         <?php echo $vendors->GetMenu("id", "", FALSE, FALSE, 0,
                                   "onChange='document.form1.submit();'"); ?>&nbsp;&nbsp;<img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" alt="Update" align="middle" border="0" onClick="{ document.form1.submit(); }">
      </td>
    </tr>
   <input type="hidden" name="action" value="edit">
   </form>
   </table> <?php
} ?>

<?php
function delete_vendor($db, $id) {
   if (!$db->Execute("DELETE FROM vendor WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

function edit_form($db, $id) {
   if (!$vendor = $db->Execute("SELECT * FROM vendor WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } 
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   echo "<br>DIRECTORY OF IMAGES HERE : ".$imgs_admin_dir."<br>";
   ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="edit_vendor.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="4"><b>Update Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td colspan="3"> 
        <input type="text" name="name" size="40"
           value="<?php echo $vendor->fields["name"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 1:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="40"
           value="<?php echo $vendor->fields["address1"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 2:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="40"
           value="<?php echo $vendor->fields["address2"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">City:</td>
      <td> 
        <input type="text" name="city" size="20"
           value="<?php echo $vendor->fields["city"]; ?>">
      </td>
      <td align="right">Province/State:</td>
      <td> 
        <input type="text" name="province" size="12"
           value="<?php echo $vendor->fields["province"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Country:</td>
      <td> 
        <input type="text" name="country" size="20"
           value="<?php echo $vendor->fields["country"]; ?>">
      </td>
      <td align="right">Postal Code / ZIP:</td>
      <td> 
        <input type="text" name="p_code" size="12"
           value="<?php echo $vendor->fields["p_code"]; ?>">
      </td>
    </tr>
	
	
	<tr class="row_even"> 
      <td align="right">Part.IVA:</td>
      <td> 
        <input type="text" name="PIVAvendor" size="20"
           value="<?php echo $vendor->fields["PIVAvendor"]; ?>">
      </td>
      <td align="right">Attention:</td>
      <td> 
        <input type="text" name="attn" size="40"
           value="<?php echo $vendor->fields["attn"]; ?>">
      </td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="main_phone" size="20"
           value="<?php echo $vendor->fields["main_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="main_fax" size="20"
           value="<?php echo $vendor->fields["main_fax"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="main_email" size="30"
           value="<?php echo $vendor->fields["main_email"]; ?>">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="main_www" size="30"
           value="<?php echo $vendor->fields["main_www"]; ?>">
      </td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Technical or Support Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="tech_phone" size="20"
           value="<?php echo $vendor->fields["tech_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="tech_fax" size="20"
           value="<?php echo $vendor->fields["tech_fax"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="tech_email" size="30"
           value="<?php echo $vendor->fields["tech_email"]; ?>">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="tech_www" size="30"
           value="<?php echo $vendor->fields["tech_www"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td valign="top" align="right">Comments:</td>
      <td colspan="3"> 
        <textarea name="comments" cols="50" rows="5"
           wrap="VIRTUAL"><?php echo $vendor->fields["comments"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4"> 
         <div align="center"><img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" align="middle" alt="Update" border="0"
            onClick="if (valid_vendor_form(document.form2)) { document.form2.submit(); }">
         <img src="<?PHP echo $imgs_admin_dir ?>delete_elimina.gif" align="middle" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Vendor ?')) { window.location='edit_vendor.php?action=delete&id=<?php echo $id; ?>'; }">
         <a href="edit_vendor.php?action=cancel">
        <img src=".<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
			</a></div>
      </td>
    </tr>
  <input type="hidden" name="action" value="Update">
  <input type="hidden" name="id" value="<?php echo $id; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.name.focus();
  </script> <?php
} ?>

<?php
if ($privs == '69') {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (delete_vendor($db, $id)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary updated OK.<a href=\"edit_vendor.php\"><img src=\"".$imgs_admin_dir."edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Vendor.</td></tr></table>";
         }
         break;
      case "update":
         $query = "UPDATE vendor SET"
                . " name='$name', attn='$attn',"
                . " address1='$address1', address2='$address2',"
                . " city='$city', province='$province',"
                . " country='$country', p_code='$p_code', PIVAvendor='$PIVAvendor',"
                . " main_phone='$main_phone', main_fax='$main_fax',"
                . " main_email='$main_email', main_www='$main_www',"
                . " tech_phone='$tech_phone', tech_fax='$tech_fax',"
                . " tech_email='$tech_email', tech_www='$tech_www',"
   	          . " comments='$comments' WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary updated OK.<a href=\"edit_vendor.php\"><img src=\"".$imgs_admin_dir."edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Vendor.</td></tr></table>";
         break;
      case "edit":
         edit_form($db, $id);
         break;
      default:
         vendor_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See Ksms administrator.</td></tr></table>";
}
require("footer.inc.php");
?>

