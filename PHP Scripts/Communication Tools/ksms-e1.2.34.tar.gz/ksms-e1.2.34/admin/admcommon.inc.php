<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|	admcommon.inc.php */

require("admconfig.inc.php");
$sesspth = $cfg["sespath"];
session_save_path($sesspth);
session_start();
if (!empty($_SESSION) && isset($_SESSION["adm_login"])) {
   $adm_login = $_SESSION["adm_login"];
   $project_name = $_SESSION["project_name"];
   $privs = $_SESSION["privs"];
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
} else {
   header("Status: 302 moved");
   header("Location: admlogin.php");
}

// Tell browsers not to cache this page
header("Expires: Mon, 23 Jul 2000 07:00:07 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");

// Include required files
require("admgrab_globals.inc.php");
require("admconnection.inc.php");
$title = "Administration Area";
require("admheader.inc.php");

// Some functions needed by several pages. Try to move functions required often
// to this file.



/*
ORIGINAL SYSTEM FOR VALIDATE ENGLISH DATE
*/
function valid_date($date) {
// Converts shortcut to valid date, or validates date input format. Returns
// a valid date in ANSI format or FALSE on error.
   if (eregi("^(t{1})([\+\-]?)([0-9]*)$", $date, $shortcut)) {
      if ($shortcut[2] == "-") {
         $date = date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") - $shortcut[3], date("Y")));
      } else {
         $date = date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") + $shortcut[3], date("Y")));
      }
      return $date;
   }
   if (ereg("^[0-9]{4}\-{1}[0-9]{2}\-{1}[0-9]{2}$", $date)) {
      return $date;
   }
   return FALSE;
}



function valid_selct($orgs) {
// Checks for don't use a "select..." value in a form. Returns TRUE or FALSE.
// ^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*$
// (!eregi("^(\-[_a-zA-Z0-9-]+)*$", $selectn))
   if (!$orgs->fields["id"] == "3") {
      return FALSE;
   }
   return TRUE;
}

function addslash_text($valuetxt) {
// Add the necessary slashes in a text that contains a single quote:  (') ---> (\')
// $valuetxt = htmlspecialchars($valuetxt);
$valuetxt = addslashes($valuetxt);
	return $valuetxt;
}

?>