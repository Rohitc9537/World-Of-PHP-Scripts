<?php 
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
require("admcommon.inc.php"); 
?>

<?php
function AddOrder_form($db) {
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	$nextyr  = mktime (0,0,0,date("m"),  date("d")-7,  date("Y")+1);
	$orgs = $db->Execute("SELECT company, id, username, email FROM organization ORDER BY company");
	$gatew = $db->Execute("SELECT name_gwprovider, id, city FROM gwprovider ORDER BY name_gwprovider");
	$vendor = $db->Execute("SELECT name, id, city FROM vendor ORDER BY name");
	//$pricelst = $db->Execute("SELECT descript1, id FROM products ORDER BY descript1");
	$orid = $db->Execute("SELECT id FROM orders_seq");
	$ordercalc = ($orid->fields["id"]+1);
	$ordernr = "ksms".$ordercalc."p";
?>
   <table class="kdefault" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form1addpo" method="post" action="admin_orders.php">
         <tr class="row_head"> 
            <td colspan="4" nowrap><b>NEW CUSTOMER ORDER</b></td>
         </tr>
		 <tr class="row_even">
            <td nowrap align="right">Ord. Number:</td>
            <td>
               <input type="text" name="ord_number" size="11" value="<?php echo $ordernr; ?>" disabled>
            </td>
            <td align="right">Insert Date:</td>
			<td>
	           <input type="text" name="date" value="<?php echo date("Y-m-d"); ?>"
              onChange="return BisDate(this,'R')">AA-MM-GG
          </td>
	  	 </tr>
		 <tr class="row_even">
            <td nowrap align="right">Order start:</td>
           <td>
               <input type="text" name="contract_start" value="<?php echo date("Y-m-d"); ?>"
              onChange="return BisDate(this,'R')">AA-MM-GG
            </td>
            <td align="right">Order end:</td>
			<td>
	           <input type="text" name="contract_end" value="<?php echo date("Y-m-d", $nextyr); ?>"
              onChange="return BisDate(this,'R')">AA-MM-GG
          </td>
	  	 </tr>
		<tr class="row_even"> 
            <td nowrap align="right">Customer:</td>
            <td> 
               <?php // echo $orgs->GetMenu("org", "", false, false, 0,"$jscript"); 
					echo $orgs->GetMenu("org", "", $blank1stItem=true, $multiple_select=false);
				?>
            </td>
         <td align="right">Vendor:</td>
         <td>
            <?php echo $vendor->GetMenu("vendor", "", FALSE); ?>
         </td>
       </tr>
	<tr class="row_even">
	  <td align="right">Cust. Tax Exempt?:</td>
      <td colspan="3"> 
        <table class="kdefault" border="0" cellspacing="2" cellpadding="">
<tr class="row_even">
	<td><input type="checkbox" name="tax_exempt" value="Y">&nbsp;&nbsp;&nbsp;</td>
    <td align="right">Exempt by law #:</td>
    <td><input type="text" name="law_exart" size="15" value="">&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td nowrap align="right">Payed?</td>
    <td><input type="checkbox" name="payed" value="Y">&nbsp;&nbsp;&nbsp;</td>
	<td>(spuntare la casella se il cliente ha gi&agrave; pagato)</td>
</tr>
</table>
      </td>
    </tr>
	   <tr class="row_head"> 
      		<td colspan="4"><b>Technical Data</b></td>
       </tr>
	   <tr class="row_even">
         <td align="right">Gateway Provider:</td>
         <td>
           <?php echo $gatew->GetMenu("gateway", "", FALSE); ?>
         </td>
		 
		 <td align="right">Pyment Type:</td>
         <td>
           <select name="payment_type">PAYPAL</option>
		   <option value='VISA' selected>VISA</option>
		   <option value='AMEXPRES'>AMERICAN EXPRESS</option>
		   <option value='BANK'>BANK</option>
			</select>
         </td>
		 </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">E-Mail:</td>
            <td> 
             <input type="text" name="email_poconf" size="40" value="sms@viabazar.com"><br><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#F7EC2B"><b>mail a cui spedire i dati riepilogo di questo ordine!</b></font>
            </td>
			<td nowrap align="right">Revisioned by:</td>
            <td>
			<select name="created_by">
		   <option value='Eric'>Eric</option>
		   <option value='Jenny'>Jenny</option>
		   <option value='Bob' selected>Bob</option>
		   <option value='Paul'>Paul</option>
			</select>
            </td>
         </tr>
	
         <tr class="row_even"> 
            <td nowrap align="right">Admin comments:</td>
            <td colspan="3"> 
               <textarea name="ord_comments" cols="70" rows="2" wrap="VIRTUAL"></textarea>
            </td>
         </tr>         
         <tr class="row_even"> 
            <td colspan="4" nowrap>
               <div align="center">
			   <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" align="middle" alt="Enter"
                  onClick="document.form1addpo.submit();">
               <img src="<?PHP echo $imgs_admin_dir ?>reset.gif" border="0" alt="Reset"
                  onClick="document.form1addpo.reset();">
               <a href="admin_orders.php?action=cancel">
                  <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" align="middle" alt="Abort" border="0"></a></div>
            </td>
         </tr>
		 <?php
   if (isset($refer)) { ?>
     <?PHP echo "<input type='hidden' name='refer' value='$refer;'>";
   }  // chiusura funzione : /function AddOrder_form
  ?>
  		<input type="hidden" name="ord_number" value="<?php echo $ordernr; ?>">
		<input type="hidden" name="ord_nr" value="<?php echo $ordernr; ?>">
      	<input type="hidden" name="action" value="add_orderdata">
      </form>
   </table>
   <div align="center">
			   <b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#000066">Click on under buttom to insert the order # #</font> <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#ff6600"><?php echo $ordernr; ?></font></b>
			   </div>
   <br>
   <script language="JavaScript">
      document.form1addpo.contract_start.focus();
   </script> 
<?php
} // close the function AddOrder_form
######     EDIT THE ORDER     ################################################################
function edit_order_form($db, $ord_number, $id_of_order) {
	require("admconfig.inc.php");
   	$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   if ($ord_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td><div align='center'>You must enter a valid PO number.</div></td></tr></table>";
      po_form($db);
      return FALSE;
   }
   /////if (!$purchorder = $db->Execute("SELECT * FROM orders WHERE ord_number='$ord_number'")) {
   if (!$purchorder = $db->Execute("SELECT * FROM orders WHERE ord_number='$ord_number'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Database Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($purchorder->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $ord_number not found.</td></tr></table>";
      po_form($db);
      return FALSE;
   }
   if ($purchorder->fields["open"] == "N") {
   		echo "<table class='news'><tr><td>Order closed....not modifiable!</td></tr></table>";
	  view_order($db, $ord_number, $id_of_order);
      return FALSE;
   } else {
   		echo "<table class=\"news\" width=\"100%\"><tr><td><font color='#0450AC'>WARNING : this order is in OPEN status (the summs maybe wrong!)</font></td></tr></table><br>";
   		}
      if (!$kselprod1 = $db->Execute("SELECT descript1, ID, internal_code FROM products ORDER BY ID")){
      echo "<table class=\"notice\" width=\"100%\"><tr><td>prDB Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
	  break;
   }
   //require("admconfig.inc.php");
   $vendor_id = $purchorder->fields["id_vendor"];
   $id_of_order = $purchorder->fields["ordID"];
   $org_id = $purchorder->fields["id_organization"];
   $Kcreatedby = $purchorder->fields["created_by"];
   $vendor = $db->Execute("SELECT name FROM vendor WHERE id='$vendor_id'");
   $org = $db->Execute("SELECT username, company FROM organization WHERE id='$org_id'");
   //$cr_user = $db->Execute("SELECT * FROM users WHERE username='$Kcreatedby'");
   $crrp = $cfg["curr"];
   //if (!$line_items = $db->Execute("SELECT * FROM ord_line_items WHERE order_number='$ord_number' ORDER BY id_row")) {
	if (!$line_items = $db->Execute("SELECT * FROM ord_line_items WHERE orderID_ln='$id_of_order' ORDER BY id_row")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
	  break;
   }
    $llines_nrOrder = $line_items->fields["order_number"];
	$privs = $_SESSION["privs"];
 ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
       <tr class="row_head"> 
         <td nowrap><b>Edit Order Information</b> (ID : <?php echo $id_of_order; ?>)</td>
         <td align="right">Order Number:&nbsp;<b><?php echo $ord_number; ?></b></td>
       </tr>
       <tr class="row_even">
         <td> <?php
         if ($purchorder->fields["open"] == "Y") {
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."open_button.gif' border='0' alt='Order Open!'>";
         } else if ($purchorder->fields["open"] == "N") { 
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."closed_button.gif' border='0' alt='Order Closed!'>";
         } else { 
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."closed_button.gif' border='0' alt='Order Closed'>";
         }
         if ($privs > 68 && $purchorder->fields["open"] == "N") {
             echo "<a href='print_order.php?ord_number=$ord_number&orderid=$id_of_order'><img src='".$imgs_admin_dir."print_button.gif' border='0' alt='Print this order!'></a>";
         	} ?>
         </td>
         <td align="right">InsertDate:&nbsp;<?php echo $purchorder->fields["date"]; ?></td>
       </tr>
       <tr class="row_even"> 
         <td>&nbsp;&nbsp;Customer:&nbsp;<?php echo $org->fields["company"]."&nbsp;&nbsp;&nbsp;(user=<b>".$org->fields["username"]."</b>)"; ?></td>
         <td align="right">Created By:&nbsp;<?php echo $Kcreatedby; ?></td>
       </tr>
       <tr class="row_even">
         <td>&nbsp;&nbsp;Vendor:&nbsp;<?php echo $vendor->fields["name"]; ?></td>
         <td align="right">Start Contract : <b><?php echo $purchorder->fields["contract_start"]; ?></b>&nbsp;End Contract : <b><font color="#FACCA3"><?php echo $purchorder->fields["contract_end"]; ?></font></b></td>
       </tr>
	   <tr class="row_even">
         <td colspan="2">
		 <hr color="#ffffe6">
		 </td>
	   </tr>
       <tr class="row_even">
         <td colspan="2">
		 <?PHP
		 $privs = $_SESSION["privs"];
		 $advtext="Solo ad ordine CHIUSO, vengono conteggiati ed inseriti in tabella SQL i crediti, aggiornati i totali, etc.<br>&nbsp;&nbsp;&nbsp;Ad ordine APERTO il totale_ordine &eacute; pari a ZERO!";
			   if ($privs > 68 || $purchorder->fields["open"] == "Y") {
			   echo "<form name='form3addline' method='post' action='admin_orders.php'>";
				//echo "<font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='1' color='#ccffcc'>seleziona articolo da inserire su ordine</font><br>";
				echo "<img src='".$imgs_admin_dir."seltxt01.gif' border='0' alt='Select below'><br>";
				echo $kselprod1->GetMenu("lnitems", "", FALSE);
				echo " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
				echo "<img src='".$imgs_admin_dir."add_line_arrw.gif' border='0' align='middle' alt='Add Line Item' onClick='document.form3addline.submit();'>";
			   		}
			if (!isset($llines_nrOrder)) {
				echo "&nbsp;&nbsp;Inserire righe sull'ordine!<br>";
				   } else {
             	echo "&nbsp;&nbsp;<a href='admin_orders.php?action=close_po&ordkeyID=$id_of_order&ord_number=$ord_number'>";
        		echo "<img src='".$imgs_admin_dir."close_order.gif' border='0' align='middle' alt='Close Order'></a>&nbsp;&nbsp;";
				echo "<a href='admin_orders.php?'><img src='".$imgs_admin_dir."open_maint.gif' border='0' align='middle' alt='Close Order'></a><br>";
				     }
				echo "&raquo;<b><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#E8FDFF'> ".$advtext."</font></b>&nbsp;&laquo;";
  				echo "<input type='hidden' name='ord_number' value='$ord_number'>";
				echo "<input type='hidden' name='ord_nr' value='$ord_number'>";
				echo "<input type='hidden' name='id_of_order' value='$id_of_order'>";
				echo "<input type='hidden' name='chk' value='lineitemskey'>";
      			echo "<input type='hidden' name='action' value='add_kline'>";
      		    echo "</form>";
					$privs = $_SESSION["privs"];
            	if ($privs > 68 || $purchorder->fields["open"] == "N") {
				echo "<img src='".$imgs_admin_dir."closed_button.gif' border='0' align='middle' alt='Order Closed!'>";
            }
?>
         </td>
       </tr>
	   <tr class="row_even">
         <td colspan="2">
		 <hr color="#ffffe6">
		 </td>
	   </tr>
     </table>
   <table class="small" cellspacing="0" cellpadding="1" width="100%" border="1">
    <tr class="row_head">
      <td align="center"><b>#</b></td>
	  <td align="right"><b>Code</b></td>
      <td align="right"><b>Qty</b></td>
      <td align="center"><b>Unit</b></td>
      <td><b>Description</b></td>
      <td align="right"><b>Prezzo sms</b></td>
      <td align="right"><b>PrezzoPack</b></td>
	  <!-- <td align="right"><b>Add Fee</b></td> -->
      <td align="right"><b>CredsVal</b></td>
      <td align="right"><b>I.V.A.</b></td>
      <td align="right"><b>Tot.Riga</b></td>
      <td align="center"><b>Availb</b></td>
    </tr> 
<?php
	$po_total = 0;
	$i = 1;
      while (!$line_items->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
		 $privs = $_SESSION["privs"];
         if ($privs > 68 || $purchorder->fields["open"] == "Y") {
            echo "<td align=\"center\"><a href=\"admin_orders.php?action=edit_singleline&ord_number=$ord_number&id="
                 . $line_items->fields["id_row"]
                 . "\"><img src='".$imgs_admin_dir."mn_edit.gif' border=\"0\" alt=\"Edit Row\"></a></td>";
         } else {
            echo "<td align=\"center\">$i</td>";
         }
	$totrow = $line_items->fields["prd_total_row"];
	$row_prod_amount_it = number_format($totrow, 2, ',', '.'); // italian format numbers!!!
	$desc1=$line_items->fields["prod_descript1"];
	$desc01=substr($desc1, 0, 35);
         echo "<td align=\"right\">".$line_items->fields["product_code"]."</td>";
         echo "<td align=\"right\"><b>".$line_items->fields["prod_qty"]."</b></td>";
         echo "<td align=\"center\">".$line_items->fields["prod_unit"]."</td>";
         echo "<td>". $desc01." ...</td>";
         echo "<td align=\"right\">".$crrp.$line_items->fields["prod_single_sale"]."</td>";
         echo "<td align=\"right\">".$crrp."<b> ".$line_items->fields["prpack_sale_price"]."</b></td>";
         //echo "<td align=\"right\">".$crrp.$line_items->fields["pr_addprice"]."</td>";
		 echo "<td align=\"right\">".$line_items->fields["prd_credits_value"]."</td>";
         echo "<td align=\"right\">".$line_items->fields["prd_tax"]."</td>";
		 echo "<td align=\"right\">".$crrp.$row_prod_amount_it."</td>";
//               echo "<td align=\"center\"><b>NN</b></td>";
#			N = Not Available
#			P = Package
#			W = On Line (web)
#			L = On Local PC
#			I = Internal Use Only
#			T = Not Specified

         switch ($line_items->fields["available"]) {
            case "":
               echo "<td align=\"center\"><b>NN</b></td>";
               break;
            case "N":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."not_avlb.gif' border=\"0\" alt=\"Products Not Available\"><br>NonDisp.</td>";
               break;
            case "P":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."pack.gif' border=\"0\" alt=\"Product availabe in a package\"><br>Scatola</td>";
               break;
            case "W":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."prweb.gif' border=\"0\" alt=\"Product availabe on-line\"></a><br>OnLine</td>";
               break;
            case "L":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."prPC.gif' border=\"0\" alt=\"Product availabe for use on local PC\"></a><br>Local</td>";  //
               break;
            case "I":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."intern.gif' border=\"0\" alt=\"Product not availabe for public (only internal use)\"></a><br>IntUse</td>"; //
               break;
            case "T":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."notspec.gif' border=\"0\" alt=\"Product availabe in some format!\"></a><br>NotSpec</td>"; //
               break;
         }

         echo "</tr>";
         $po_total += $line_items->fields["prd_total_row"];
         $i++;
         $line_items->MoveNext();
      } ?>
      <tr class="row_head">
         <td align="right" colspan="9"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#F2F7FF"><b>Customer Order Total:</b></font></td>
         <?php
		 // NON FUNZIA !!!
		//  $po_total_it = number_format($Ppo_total, 2, ',', '.'); // italian format numbers!!!
		//  printf("<td align=\"right\"><b>%01.2f</b></td>", $po_total_it);
		//  echo "<td align='right'><b>".$po_total_it."</b></td>";
		printf("<td align='right'><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#000066'><b>".$crrp. "%01.2f</b></font></td>", $po_total); 
		 ?>
		  <td>&nbsp;</td> 
      </tr>
      <tr class="row_even">
         <td colspan="11">&nbsp;</td> 
      </tr>
      <tr class="row_head">
         <td align="right" colspan="11">
            <a href="admin_orders.php"><img src="<?php echo $imgs_admin_dir; ?>edit_btn.gif" align="middle" border="0" alt="Edit"></a> &nbsp;another Customer Order.
         </td>
      </tr>
  </table> 
  <div align="center">  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#D31238">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font></div>
  <?php
}

function po_form() { ?>
   <table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="admin_orders.php" method="post" name="form1">
      <tr class="row_head"> 
         <td align="center" colspan="2" nowrap><b>Update Customer Order Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Order Number:</td>
         <td> 
            <input type="text" name="ord_number" size="12">
            <input type="submit" value="DaSISTEMARE!!!">
         </td>
      </tr>
   <input type="hidden" name="action" value="edit_po">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.ord_number.focus();
   </script> 
<?php
} 	// end function po_form
 ######     ONLY VIEW ORDER     ################################################################
function view_order($db, $ord_number, $id_of_order) {
require("admconfig.inc.php");
   	$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
$privs = $_SESSION["privs"];
   if ($ord_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td><div align='center'>Numero ordine non trovato! You must enter a valid PO number.</div></td></tr></table>";
      po_form($db);
      return FALSE;
   }
   if (!$viewKrder = $db->Execute("SELECT * FROM orders WHERE ordID='$id_of_order'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Database Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($viewKrder->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $ord_number not found.</td></tr></table>";
      po_form($db);
      return FALSE;
   }
   if ($viewKrder->fields["open"] == "N") {
   		echo "<table class=\"notice\"><tr><td>Ordine non modificabile, altrimenti si potrebbero avere problemi sui conteggi dei crediti!!!</td></tr></table>";
   		} else {
   		echo "<table class=\"news\" width=\"100%\"><tr><td><font color='#0450AC'>Attenzione: questo ordine risulta <b>APERTO</b>, pertanto non sono stati conteggiati i crediti eventualmente acquistati con questo ordine!</font></td></tr></table><br>";
   		}
//   require("admconfig.inc.php");
//   $imgs_admin_dir = $_SESSION["imgs_dir"];
   $vendor_id = $viewKrder->fields["id_vendor"];
   $org_id = $viewKrder->fields["id_organization"];
   $Kcreatedby = $viewKrder->fields["created_by"];
   $vendor = $db->Execute("SELECT name FROM vendor WHERE id='$vendor_id'");
   $org = $db->Execute("SELECT username, company FROM organization WHERE id='$org_id'");
   //$cr_user = $db->Execute("SELECT * FROM users WHERE username='$Kcreatedby'");
   $crrp = $cfg["curr"];
   if (!$line_items = $db->Execute("SELECT * FROM ord_line_items WHERE order_number='$ord_number' ORDER BY id_row")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
	  break;
   }
 ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
       <tr class="row_head"> 
         <td nowrap><b>VISUALIZZAZIONE ORDINE</b></td>
         <td align="right">Order Number:&nbsp;<b><?php echo $ord_number; ?></b></td>
       </tr>
       <tr class="row_even">
         <td> <?php
         if ($viewKrder->fields["open"] == "Y") {
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."open_button.gif' border='0' alt='Order Open!' align='middle'>";
         } else if ($viewKrder->fields["open"] == "N") { 
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."closed_button.gif' border='0' alt='Order Closed!' align='middle'>&nbsp;&nbsp;<img src='".$imgs_admin_dir."CreditsUpdatedLarge.gif' border='0' align='middle' alt='Order Closed!'>";
         } else { 
            echo "&nbsp;&nbsp;Status:&nbsp;&nbsp;<img src='".$imgs_admin_dir."ord_appr.gif' border='0' alt='Order Closed' align='middle'>";
         }?>
         </td>
         <td align="right">InsertDate:&nbsp;<?php echo $viewKrder->fields["date"]; ?></td>
       </tr>
       <tr class="row_even"> 
         <td>&nbsp;&nbsp;Cliente:&nbsp;<?php echo $org->fields["company"]."&nbsp;&nbsp;&nbsp;(user=<b>".$org->fields["username"]."</b>)"; ?></td>
         <td align="right">Created By:&nbsp;<?php echo $Kcreatedby; ?></td>
       </tr>
       <tr class="row_even">
         <td>&nbsp;&nbsp;Venditore:&nbsp;<?php echo $vendor->fields["name"]; ?></td>
         <td align="right">Start Contract : <b><?php echo $viewKrder->fields["contract_start"]; ?></b>&nbsp;End Contract : <b><font color="#FACCA3"><?php echo $viewKrder->fields["contract_end"]; ?></font></b></td>
       </tr>
	   </tr>
       <tr class="row_even">
         <td colspan="2">&nbsp;</td>
       </tr>
     </table>
   <table class="small" cellspacing="0" cellpadding="1" width="100%" border="1">
    <tr class="row_head">
      <td align="center"><b>#</b></td>
	  <td align="right"><b>Code</b></td>
	  <td align="right"><b>OrdID</b></td>
      <td align="right"><b>Qty</b></td>
      <td align="center"><b>Unit</b></td>
      <td><b>Description</b></td>
	  <!--  <td>desc2</td> -->
     <!--  <td align="right"><b>Prezzo sms</b></td> -->
      <td align="right"><b>PrezzoSing</b></td>
      <td align="right"><b>ValoreCred</b></td>
      <td align="right"><b>I.V.A.</b></td>
      <td align="right"><b>Tot.Riga</b></td>
      <td align="center"><b>Format</b></td>
    </tr> 
<?php
	$po_total = 0;
	$i = 1;
      while (!$line_items->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
		 $privs = $_SESSION["privs"];
		 $purchorder = $db->Execute("SELECT * FROM orders WHERE ord_number='$ord_number'");
         if ($privs > 68 && $purchorder->fields["open"] == "Y") {
            echo "<td align=\"center\"><a href=\"admin_orders.php?action=edit_singleline&ord_number=$ord_number&id="
                 . $line_items->fields["id_row"]
                 . "\"><img src='".$imgs_admin_dir."mn_edit.gif' border=\"0\" alt=\"Edit Row\"></a></td>";
         } else {
            echo "<td align=\"center\">$i</td>";
         }
	$totrow = $line_items->fields["prd_total_row"];
	$row_prod_amount_it = number_format($totrow, 2, ',', '.'); // italian format numbers!!!
	$desc1=$line_items->fields["prod_descript1"];
	$desc01=substr($desc1, 0, 35);
	$desc2=$line_items->fields["prod_descript2"];
	$desc02=substr($desc2, 0, 45);
         echo "<td align=\"right\">".$line_items->fields["product_code"]."</td>";
         echo "<td align=\"right\">".$line_items->fields["orderID_ln"]."</td>";
         echo "<td align=\"right\"><b>".$line_items->fields["prod_qty"]."</b></td>";
         echo "<td align=\"center\">".$line_items->fields["prod_unit"]."</td>";
         echo "<td>". $desc01." ...</td>";
         //echo "<td>". $desc02." ...</td>";
         //echo "<td align=\"right\">".$crrp.$line_items->fields["prod_single_sale"]."</td>";
         echo "<td align=\"right\">".$crrp."<b> ".$line_items->fields["prpack_sale_price"]."</b></td>";
		 echo "<td align=\"right\">".$line_items->fields["prd_credits_value"]."</td>";
         echo "<td align=\"right\">".$line_items->fields["prd_tax"]."</td>";
		 echo "<td align=\"right\">".$crrp.$row_prod_amount_it."</td>";
//               echo "<td align=\"center\"><b>NN</b></td>";
#			N = Not Available
#			P = Package
#			W = On Line (web)
#			L = On Local PC
#			I = Internal Use Only
#			T = Not Specified
         switch ($line_items->fields["available"]) {
            case "":
               echo "<td align=\"center\"><b>NN</b></td>";
               break;
            case "N":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."not_avlb.gif' border=\"0\" alt=\"Products Not Available\"><br>NonDisp.</td>";
               break;
            case "P":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."pack.gif' border=\"0\" alt=\"Product availabe in a package\"><br>Scatola</td>";
               break;
            case "W":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."prweb.gif' border=\"0\" alt=\"Product availabe on-line\"></a><br>OnLine</td>";
               break;
            case "L":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."prPC.gif' border=\"0\" alt=\"Product availabe for use on local PC\"></a><br>Local</td>";  //
               break;
            case "I":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."intern.gif' border=\"0\" alt=\"Product not availabe for public (only internal use)\"></a><br>IntUse</td>"; //
               break;
            case "T":
               echo "<td align=\"center\"><img src='".$imgs_admin_dir."notspec.gif' border=\"0\" alt=\"Product availabe in some format!\"></a><br>NotSpec</td>"; //
               break;
         }
         echo "</tr>";
         $po_total += $line_items->fields["prd_total_row"];
         $i++;
         $line_items->MoveNext();
      } ?>
      <tr class="row_head">
         <td align="right" colspan="9"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#F2F7FF"><b>Customer Order Total:</b></font></td>
         <?php
		 // NON FUNZIA !!!
		//  $po_total_it = number_format($Ppo_total, 2, ',', '.'); // italian format numbers!!!
		//  printf("<td align=\"right\"><b>%01.2f</b></td>", $po_total_it);
		//  echo "<td align='right'><b>".$po_total_it."</b></td>";
		printf("<td align='right'><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#000066'><b>".$crrp. "%01.2f</b></font></td>", $po_total); 
		 ?>
		  <td>&nbsp;</td> 
      </tr>
      <tr class="row_even">
         <td colspan="11">&nbsp;</td> 
      </tr>
      <tr class="row_head">
	  	<td colspan="3">ordine chiuso</td>
		<td colspan="5" align="center"><?PHP
		$privs = $_SESSION["privs"];
		if ($privs > 68 && $viewKrder->fields["open"] == "N") {
   		echo "<div align='center'>";
		echo "<a href='print_order.php?ord_number=$ord_number&orderid=$id_of_order'>"
		. "<img src='".$imgs_admin_dir."print_button.gif' border='0' alt='Print this order!' align='middle'></a>&nbsp;&nbsp;Stampa l'ordine</div>";
         	} 
			?>
			</td>
		<td colspan="3" align="right">
            <a href="admin_orders.php"><img src="<?php echo $imgs_admin_dir; ?>edit_btn.gif" border="0" alt="Edit" align="middle"></a> &nbsp;another Customer Order.</td>
      </tr>
  </table>
  <div align="center">  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#D31238">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font></div>
  
  <?php
}
	?>
	
<?php
##### ADD_LINE AGGIUNGI RIGHE ALL'ORDINE !!!  ADDLINES TO ORDER !!! ADD LINE ::: ADDLINE ####
function new_line_item($db, $ord_number, $lnitems, $id_of_order) {
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   if ($ord_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td align='center'>You must enter a valid PO number for ad some rows to that order!</td></tr></table>";
      po_form($db);
      return FALSE;
	  break;
   }
   if (!$korder = $db->Execute("SELECT * FROM orders WHERE ord_number='$ord_number'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Database Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if (!$kselprod = $db->Execute("SELECT * FROM products WHERE ID='$lnitems' ORDER BY ID")){
      echo "<table class=\"notice\" width=\"100%\"><tr><td>prDB Error: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
	  break;
   }
	$ins_row = date("Y-m-d");
   	$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	if ($kselprod->fields["internal_code"] == "k00.00")
		{ $fieldability = ""; }
		else { $fieldability = " disabled"; }
/*
  comments text,
		//$kselprod->GetMenu2("prodseld", $dsc1, false);
		$namemnprod = "prodseld";
		echo $kselprod->GetMenu($namemnprod,$defstr='kselprod',$blank1stItem=false,$multiple=false,$size=0, $selectAttr='',$compareFields0=true) 
*/
?>
  <table class="kdefault" border="0" cellspacing="0" cellpadding="1" align="center">
  <form action="admin_orders.php" method="post" name="forminsrow">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>Add Line Item to Order Number: <?php echo $ord_number." - ID : " .$id_of_order; ?></b></td>
         </tr>
		 <tr class="row_even">
		 	<td colspan="4" nowrap><b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#ffff00">La quantit&agrave; va sempre riferita al prezzo totale o al pacchetto (NON AL SINGOLO COSTO)</font></b></td>
		 </tr>
		 <tr class="row_even">
			 <td nowrap align="right">Codice:</td>
            <td colspan="3">
            <input type="text" name="internal_code" size="12" value="<?php echo $kselprod->fields["internal_code"]; ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp;Max 12 char.
            </td>
         </tr>
		 <tr class="row_even">
			 <td nowrap align="right">Quantit&agrave;:</td>
            <td colspan="3">
            <input type="text" name="prod_qty" size="4" value="1">&nbsp;<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#69f8f8"><b>x il Prezzo Totale</b></font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Descrizione 1:</td>
            <td colspan="3">
			   <input type="text" name="descript1" size="50" value="<?php echo $kselprod->fields["descript1"] ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp;Max 50 char.
            </td>
			<tr class="row_even"> 
            <td nowrap align="right">Descrizione 2:</td>
            <td colspan="3">
			   <input type="text" name="descript2" size="50" value="<?php echo $kselprod->fields["descript2"] ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp;Max 50 char.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Unit� di misura:</td>
            <td colspan="3">
			   <select name="unit">
		<option value="Pz" <?php if ($kselprod->fields["unit_m"] == "Pz") echo "selected"; ?>>Pz.</option>			   
		<option value="Kg" <?php if ($kselprod->fields["unit_m"] == "Kg") echo "selected"; ?>>Kg.</option>
		<option value="Nr" <?php if ($kselprod->fields["unit_m"] == "Nr") echo "selected"; ?>>Nr.</option>
		<option value="NN" <?php if ($kselprod->fields["unit_m"] == "NN") echo "selected"; ?>>NN</option
              </select>
		</td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Acquisto:</td>
            <td colspan="3">
			   <input type="text" name="buyed_price" size="14" value="<?php echo $kselprod->fields["buyed_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;(senza I.V.A.) Costo riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo Vendita:</td>
            <td colspan="3">
			   <input type="text" name="sale_price" size="14" value="<?php echo $kselprod->fields["sale_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;(senza I.V.A.) Costo riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">% IVA:</td>
            <td colspan="3">
		<input type="text" name="tax1" size="2" value="<?php echo $kselprod->fields["tax1"]; ?>">
            </td>
		</tr>
		 <tr class="row_even">
			<td nowrap align="right">Pezzi Pacchetto:</td>
            <td colspan="3">
		<input type="text" name="single_packet_qty" size="8" value="<?php echo $kselprod->fields["single_packet_qty"]; ?>" <?php echo $fieldability; ?>>&nbsp; nr. di pezzi che compongono quanto in descrizione!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Descrizione Addizionale (es.:"interconnessione"):</td>
            <td colspan="3">
		<input type="text" name="single_additional_descript" size="50" value="<?php echo $kselprod->fields["single_additional_descript"]; ?>" <?php echo $fieldability; ?>>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Prezzo Unitario Addizionale:</td>
            <td colspan="3">
		<input type="text" name="single_add_price" size="14" value="<?php echo $kselprod->fields["single_add_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp; 3 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Crediti Addebitati x ogni invio:</td>
            <td colspan="3">
		<input type="text" name="credits_sale_value" size="14" value="<?php echo $kselprod->fields["credits_sale_value"]; ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp; 4 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even">
            <td colspan="4">
				<hr width="100%" color="#D31238">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Acquisto:</td>
            <td colspan="3">
			   <input type="text" name="single_purchase_price" size="14" value="<?php echo $kselprod->fields["single_purchase_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Vendita:</td>
            <td colspan="3">
			   <input type="text" name="single_sale_price" size="14" value="<?php echo $kselprod->fields["single_sale_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Produttore:</td>
            <td colspan="3">
		<input type="text" name="manufacturer" size="30" value="<?php echo $kselprod->fields["manufacturer"] ?>" <?php echo $fieldability; ?>>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Marca:</td>
            <td colspan="3">
		<input type="text" name="brand" size="30" value="<?php echo $kselprod->fields["brand"] ?>" <?php echo $fieldability; ?>>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Scheda Inserita Da:</td>
            <td colspan="3">
			<?php echo "&nbsp;<b>" .$kselprod->fields["created_by"]. "</b>"; ?>
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Formato del prodotto:</td>
            <td colspan="3">
			<?php 
				if ($kselprod->fields["available"] == "N") echo "&nbsp;<b>Not Available</b>";
				if ($kselprod->fields["available"] == "P") echo "&nbsp;<b>Package</b>";
				if ($kselprod->fields["available"] == "W") echo "&nbsp;<b>On Line (web)</b>";
				if ($kselprod->fields["available"] == "L") echo "&nbsp;<b>On Local PC</b>";
				if ($kselprod->fields["available"] == "I") echo "&nbsp;<b>Internal Use Only</b>";
				if ($kselprod->fields["available"] == "T") echo "&nbsp;<b>Not Specified</b>";
			?>
            </td>
         </tr>
	<tr class="row_even">
      	<td colspan="4">
		<hr color="#F7EC2B">
		</td>
	</tr>
    <tr class="row_even">
      	<td colspan="4">
<div align="center">
<?PHP
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
         echo "<img src='".$imgs_admin_dir."add_btn.gif' align='middle' border='0' alt='Enter' onClick='document.forminsrow.submit();'>\n";
         echo "<img src='".$imgs_admin_dir."reset_btn_it.gif' align='middle' border='0' alt='Reset' onClick='document.forminsrow.reset();'>\n";
         echo "<a href='admin_orders.php?action=cancel&ord_number=$ord_number&area=add_linetoorder;'><img src='".$imgs_admin_dir."cancel_opr.gif' align='middle' border='0' alt='Cancel'></a>\n"; 
?>
</div>
      </td>
    </tr>
	<tr class="row_even"> 
  <td colspan="8">
  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font>
  </td>
</tr>
	<?PHP
		$kprod_id = $kselprod->fields["ID"];
	if ($kselprod->fields["internal_code"] == "k00.00")
		{
		echo "<input type='hidden' name='prodct' value='modifiable'>";
		}
		else {
//internal_code || prod_qty || descript1 || descript2 || unit || buyed_price || sale_price || tax1 || single_packet_qty || single_additional_descript || single_add_price || credits_sale_value || single_purchase_price || single_sale_price || manufacturer || brand || created_by || available || 
		$iicd = $kselprod->fields['internal_code'];
		// inviato tramite form :
		//	  $prqt = $kselprod->fields['prod_qty'];
		$dds1 = $kselprod->fields["descript1"];
		$dds2 = $kselprod->fields["descript2"];
		// inviato tramite form :
		//	 $prun = $kselprod->fields['unit'];
		//	 $seltax = $kselprod->fields["tax1"];
		$salepri = $kselprod->fields["sale_price"];
		$sinqty = $kselprod->fields["single_packet_qty"];
		// campi non inseriti in questa tabella "ord_line_items" :
		//	$buypri = $kselprod->fields["buyed_price"];
		//	 $sngadddesc = $kselprod->fields["single_additional_descript"];
		//	 $sngaddpri = $kselprod->fields["single_add_price"];
		//	 $adsc = $kselprod->fields["single_purchase_price"];
		$credval = $kselprod->fields["credits_sale_value"];
		$aprc = $kselprod->fields["single_sale_price"];
		// campi non inseriti in questa tabella "ord_line_items" :
		//	 $mmad = $kselprod->fields["manufacturer"];
		//	 $brnd = $kselprod->fields["brand"];
		//	 $crby = $kselprod->fields["created_by"];
		$kavl = $kselprod->fields["available"];
		echo "<input type='hidden' name='product_code' value='$iicd'>\n\r";
		echo "<input type='hidden' name='prod_descript1' value='$dds1'>\n";
		echo "<input type='hidden' name='prod_descript2' value='$dds2'>\n";
		echo "<input type='hidden' name='sale_price' value='$salepri'>\n";
		echo "<input type='hidden' name='single_packet_qty' value='$sinqty'>\n";
		echo "<input type='hidden' name='credits_sale_value' value='$credval'>\n";
		echo "<input type='hidden' name='single_sale_price' value='$aprc'>\n";
		echo "<input type='hidden' name='available' value='$kavl'>\n";
		}
	?>
  <input type="hidden" name="ord_number" value="<?php echo $ord_number; ?>">
  <input type="hidden" name="id_of_order" value="<?php echo $id_of_order; ?>">
  <input type="hidden" name="prod_id" value="<?php echo $kprod_id; ?>">
  <input type="hidden" name="action" value="order_addlines">
  </form>
  </table>
  <script language="JavaScript">
     document.forminsrow.prod_qty.focus();
  </script> <?php
} 

########## EDIT SINGLE ROW OF THE ORDER .... EDIT SINGLE LINE .... ############################
function edit_line($db, $ord_number, $id) {
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	   if (!$edline_item = $db->Execute("SELECT * FROM ord_line_items WHERE id_row='$id' AND order_number='$ord_number'")){
      echo "<table class=\"notice\" width=\"100%\"><tr><td>linesDB Error: " . $db->ErrorMsg() . "</td></tr></table>";
	  break;
   }
   	$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	if ($kselprod->fields["internal_code"] == "k00.00")
		{ $fieldability = ""; }
	  else { $fieldability = " disabled"; }
  $orderID = $edline_item->fields["orderID_ln"];
?>
	<table class="kdefault" border="0" cellspacing="0" cellpadding="1" align="center">
  	<form action="admin_orders.php" method="post" name="edline_f4">
    <tr class="row_head"> 
      <td colspan="4">
	  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="3">
	  <b>Edit Line Item from PO Number:</font>&nbsp;
	  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="4" color="#0000cc">
	  <?php echo $ord_number; ?></b></font>
	   - Modifica linea dell'ordine -
	  </td>
    </tr>
	<tr class="row_even">
		<td colspan="4" nowrap><b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#ffff00">La quantit&agrave; va sempre riferita al prezzo totale o al pacchetto (NON AL SINGOLO COSTO)</font></b></td>
	</tr>
		 <tr class="row_even">
			 <td nowrap align="right">Codice:</td>
            <td colspan="3">
            <input type="text" name="product_code" size="12" value="<?php echo $edline_item->fields["product_code"]; ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp;Max 12 char.
            </td>
         </tr>
		 <tr class="row_even">
			 <td nowrap align="right">Quantit&agrave;:</td>
            <td colspan="3">
            <input type="text" name="prod_qty" size="4" value="<?php echo $edline_item->fields["prod_qty"]; ?>">&nbsp;<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#69f8f8"><b>x il Prezzo Totale</b></font>
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Descrizione 1:</td>
            <td colspan="3">
		<input type="text" name="prod_descript1" size="50" value="<?php echo $edline_item->fields["prod_descript1"] ?>">&nbsp;&nbsp;Max 50 char.
            </td>
			<tr class="row_even"> 
            <td nowrap align="right">Descrizione 2:</td>
            <td colspan="3">
		<input type="text" name="prod_descript2" size="50" value="<?php echo $edline_item->fields["prod_descript2"] ?>">&nbsp;&nbsp;Max 50 char.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Unit� di misura:</td>
            <td colspan="3">
			   <select name="pr_unit">
		<option value="Pz" <?php if ($edline_item->fields["prod_unit"] == "Pz") echo "selected"; ?>>Pz.</option>			   
		<option value="Kg" <?php if ($edline_item->fields["prod_unit"] == "Kg") echo "selected"; ?>>Kg.</option>
		<option value="Nr" <?php if ($edline_item->fields["prod_unit"] == "Nr") echo "selected"; ?>>Nr.</option>
		<option value="NN" <?php if ($edline_item->fields["prod_unit"] == "NN") echo "selected"; ?>>NN</option
             </select>
		</td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Prezzo Vendita:</td>
            <td colspan="3">
					<input type="text" name="prpack_sale_price" size="14" value="<?php echo $edline_item->fields["prpack_sale_price"]; ?>" <?php echo $fieldability; ?>>&nbsp;(senza I.V.A.) Costo riferito al pacchetto.
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">% IVA:</td>
            <td colspan="3">
		<input type="text" name="ptax1" size="2" value="<?php echo $edline_item->fields["prd_tax"]; ?>">
            </td>
		</tr>
		 <tr class="row_even">
			<td nowrap align="right">Pezzi Pacchetto:</td>
            <td colspan="3">
		<input type="text" name="single_packet_qty" size="8" value="<?php echo $edline_item->fields["prd_singlepack_qty"]; ?>" <?php echo $fieldability; ?>>&nbsp; nr. di pezzi che compongono un pacchetto (vedi descriz.1)!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Crediti Addebitati x ogni invio:</td>
            <td colspan="3">
		<input type="text" name="prd_credits_value" size="14" value="<?php echo $edline_item->fields["prd_credits_value"]; ?>" <?php echo $fieldability; ?>>&nbsp;&nbsp; 4 Decimali col punto.
            </td>
         </tr>
		 <tr class="row_even">
            <td colspan="4">
				<hr width="100%" color="#D31238">
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Costo <b>Singolo</b> Vendita:</td>
            <td colspan="3">
			   <input type="text" name="prod_single_sale" size="14" value="<?php echo $edline_item->fields["prod_single_sale"]; ?>" <?php echo $fieldability; ?>>&nbsp;(No Tassa - No IVA)&nbsp;&nbsp;&nbsp;es.: costo per 1 sms
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">IDFornitore:</td>
            <td colspan="3">
		<input type="Text" name="ID_fornit" size="11" value="<?php echo $edline_item->fields["ID_fornit"]; ?>" disabled>&nbsp;non usato!!!
            </td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Formato del prodotto:</td>
            <td colspan="3">
			<?php 
				if ($edline_item->fields["available"] == "N") echo "&nbsp;<b>Not Available</b>";
				if ($edline_item->fields["available"] == "P") echo "&nbsp;<b>Package</b>";
				if ($edline_item->fields["available"] == "W") echo "&nbsp;<b>On Line (web)</b>";
				if ($edline_item->fields["available"] == "L") echo "&nbsp;<b>On Local PC</b>";
				if ($edline_item->fields["available"] == "I") echo "&nbsp;<b>Internal Use Only</b>";
				if ($edline_item->fields["available"] == "T") echo "&nbsp;<b>Not Specified</b>";
			?>
            </td>
         </tr>		 
<tr class="row_even">
      	<td colspan="4">
		<hr color="#F7EC2B">
		</td>
	</tr>
<tr class="row_even"> 
  <td colspan="8"><div align="center">
 <img src="<?php echo $imgs_admin_dir; ?>update.gif" align="middle" alt="Update" border="0"
  onClick="document.edline_f4.submit();">
 <img src="<?php echo $imgs_admin_dir; ?>delete_this.gif" align="middle" alt="Delete" border="0"
  onClick="if (isConfirmed('Are you sure you want to DELETE this Line Item ?')) { window.location='admin_orders.php?action=delete_line&id=<?php echo $id; ?>&ord_number=<?php echo $ord_number; ?>&id_of_order=<?php echo $orderID; ?>'; }">
 <img src="<?php echo $imgs_admin_dir; ?>kform_reset.gif" align="middle" alt="Reset" border="0"
  onClick="document.edline_f4.reset();">
 <a href="admin_orders.php?action=cancel&ord_number=<?php echo $ord_number; ?>&area=editsinglerow">
 <img src="<?php echo $imgs_admin_dir; ?>cancel_opr.gif" alt="Cancel" border="0"></a></div>
  </td>
</tr>
<tr class="row_even"> 
  <td colspan="8">
  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font>
  </td>
</tr>
<?PHP
		if ($edline_item->fields["internal_code"] == "k00.00")
			{
			echo "<input type='hidden' name='prodct' value='modifiable'>";
				} else {
		$kprodtcode = $edline_item->fields["product_code"];
		$ID_prd = $edline_item->fields["prod_id"];
		$saleprice = $edline_item->fields["prpack_sale_price"];
		$qty_in_pack = $edline_item->fields["prd_singlepack_qty"];
		$smscreditsval = $edline_item->fields["prd_credits_value"];
		$single_price = $edline_item->fields["prod_single_sale"];
		$kavlb = $edline_item->fields["available"];
		$KordID = $edline_item->fields["orderID_ln"];
		$totriga = $edline_item->fields["prd_total_row"];
		echo "<input type='hidden' name='product_code' value='$kprodtcode'>\n";
		echo "<input type='hidden' name='prod_id' value='$ID_prd'>\n";
		echo "<input type='hidden' name='prpack_sale_price' value='$saleprice'>\n";
		echo "<input type='hidden' name='single_packet_qty' value='$qty_in_pack'>\n";
		echo "<input type='hidden' name='prd_credits_value' value='$smscreditsval'>\n";
		echo "<input type='hidden' name='id_Korder' value='$KordID'>\n";
		echo "<input type='hidden' name='prod_single_sale' value='$single_price'>\n";
		echo "<input type='hidden' name='totale_riga' value='$totriga'>\n";
		echo "<input type='hidden' name='available' value='$kavlb'>\n";
			}
	?>
  <input type="hidden" name="action" value="update_line">
  <input type="hidden" name="row_id" value="<?php echo $id; ?>">
  <input type="hidden" name="eq_ord_number" value="<?php echo $ord_number; ?>">
  <input type="hidden" name="KorderID" value="<?php echo $orderID; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.edline_f4.prod_qty.focus();
  </script> <?php
} ?>

<?php
function paint_table($db) {
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
//   $ksummary = $db->Execute("SELECT orders.ordID, orders.ord_number, orders.contract_start, orders.contract_end, orders.id_organization, orders.type_payment, orders.payed, orders.tax_exempt, orders.open, organization.company FROM orders LEFT JOIN organization ON orders.id_organization=organization.id  ORDER BY ord_number, contract_end");
// SELECT orders.ordID, orders.ord_number, orders.contract_start, orders.contract_end, orders.id_organization, orders.type_payment, orders.payed, orders.tax_exempt, orders.open, organization.company, ord_line_items.prod_id FROM orders LEFT JOIN organization ON orders.id_organization=organization.id LEFT JOIN ord_line_items ON orders.ordID=ord_line_items.orderID_ln  ORDER BY ord_number, contract_end
  $ksummary = $db->Execute("SELECT orders.ordID, orders.ord_number, orders.contract_start, orders.contract_end, orders.id_organization, orders.type_payment, orders.payed, orders.tax_exempt, orders.open, organization.connext_type, organization.company, SUM(ord_line_items.prd_total_row) AS ordertotal, ord_line_items.prd_singlepack_qty AS tot_credits FROM orders LEFT JOIN organization ON orders.id_organization=organization.id LEFT JOIN ord_line_items ON orders.ordID=ord_line_items.orderID_ln  GROUP BY ord_number ORDER BY ord_number, contract_end");
?>
   <table class="small" width="99%" border="0" cellspacing="1" cellpadding="1" align="center">
   <tr class="row_head">
   	<td colspan="12">..:SELEZIONARE L'ORDINE CHE SI VUOLE MODIFICARE:..
	<hr width="100%" color="#D31238"></td>
      </tr>
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Start</b></td>
         <td><b>Stop</b></td>
		 <td><b>Cliente</b></td>
         <td align="center"><b>Connect</b></td>
		 <td align="right"><b>Tot.Ordine</b></td>
		 <td align="center"><b>Pagamento</b></td>
		 <td align="right"><b>TotCredits</b></td>
         <td align="center"><b>Pay</b></td>
		 <td align="center"><b>Tax</b></td>
		 <td align="center"><b>Status</b></td>
		 <td align="center"><b>Del</b></td>
      </tr> <?php
      $i = 1;
      while (!$ksummary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
	$keyordID = $ksummary->fields["ordID"];
	$keyordnr = $ksummary->fields["ord_number"];
	$abcd = $ksummary->fields["ordertotal"];
	$cotp = $ksummary->fields["connext_type"];
	$ordertotal_it = number_format($abcd, 2, ',', '.');
	$efgh = $ksummary->fields["tot_credits"];
	$totcredits_it = number_format($efgh, 0, ',', '.'); // italian format. Totale crediti x ogni ordine!
	if ($cotp == "fee") {$ksconnect = "<img src='".$imgs_admin_dir."Conn_Credits.gif' border='0' alt='+FEE' align='middle'>fee";}
	if ($cotp == "oto") { $ksconnect = "<img src='".$imgs_admin_dir."Conn_nrSMS.gif' border='0' alt='nrSMS' align='middle'>sms";}
	if ($cotp == "") {$ksconnect = "<img src='".$imgs_admin_dir."Conn_NotSpec.gif' border='0' alt='no' align='middle'>nn";}
	if ($cotp == "nnt") {$ksconnect = "<img src='".$imgs_admin_dir."Conn_NotSpec.gif' border='0' alt='no' align='middle'>nn";}
	?>
            <td><a href="admin_orders.php?action=edit_po&ord_number=<?php echo $ksummary->fields["ord_number"]; ?>&id_of_order=<?php echo $ksummary->fields["ordID"]; ?>" class="wlink"><?php echo $ksummary->fields["ord_number"]; ?></a></td>
            <td><?php echo $ksummary->fields["contract_start"]; ?></td>
			<td><?php echo $ksummary->fields["contract_end"]; ?></td>
			<td><b><?php echo $ksummary->fields["company"]; ?></b></td>
            <td align="center"><?php echo $ksconnect; ?></td>
			<td align="right"><?php
			//printf("<b>".$crrp. "%01.2f</b>", $ksummary->fields["ordertotal"]) 
			echo "<b>".$ordertotal_it."</b>";
					?></td>
			<td align="center"><?php echo $ksummary->fields["type_payment"]; ?></td>
			<td align="right"><b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#F7EC2B"><?php echo $totcredits_it; ?></font></b></td>
            <td align="center"><?php echo $ksummary->fields["payed"]; ?></td>
			<td align="center"><?php echo $ksummary->fields["tax_exempt"]; ?></td>
			<td align="center">
			<?php
			if ($ksummary->fields["open"] == "Y") {
			echo "<a href='admin_orders.php?action=edit_po&ord_number=".$keyordnr."&id_of_order=".$keyordID."'>"
            . "<img src='".$imgs_admin_dir."StatusY_open.gif' border='0' alt='Order Open!'></a>";
         	   	  } else if ($ksummary->fields["open"] == "N") { 
            	echo "<img src='".$imgs_admin_dir."StatusN_closed.gif' border='0' alt='Order Closed!'>";
			}
			?>
			</td>
            <td>
			<img src="<?PHP echo $imgs_admin_dir ?>/del_small.gif" alt="Delete" border="0"
  onClick="if (isConfirmed('Are you sure you want to DELETE this Order Nr. <?php echo $ksummary->fields["ord_number"]; ?> and relative items lines ?')) { window.location='admin_orders.php?action=order_delete&idlord=<?php echo $ksummary->fields["ordID"]; ?>&area=paint&ord_numbdel=<?php echo $ksummary->fields["ord_number"]; ?>'; }">
			
			</td>
         </tr>
		 
<?php
         $i++;
         $ksummary->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="99%" align="center">
	  <tr class="row_head">
	  		<td colspan="9"><hr width="100%" color="#D31238"></td>
      	 </tr>
      <tr class="row_foot">
         <td><div align="center">
		 <a href="admin_orders.php?action=nneworder"><img src="<?PHP echo $imgs_admin_dir ?>new_order.gif" alt="Inserisci un ordine" align="middle" border="0"></a>&nbsp;&nbsp;&nbsp;<a href="admin_sms.php?action=new"><img src="<?PHP echo $imgs_admin_dir ?>/new_custm.gif" alt="Inserisci un nuovo utente-cliente" align="middle" border="0"></a></div></td>
      </tr>
   </table>
<div align="center">  <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#D31238">Il tipo di connessione (<b>diretta o interconnessione</b>) viene specificato al momento di inserimento dell'organizzazione!</font></div>
     <br>
 <?php
} ?>

<?php
$projname = $_SESSION["project_name"];
$privs = $_SESSION["privs"];
if ($privs == '69'AND $projname == 'KeySMS') {
   $action = strtolower($action);
   switch ($action) {
	case "cancel":
		if ($ord_number){
		edit_order_form($db, $ord_number, $id_of_order);
		}
		else {
         paint_table($db);
		 }
         break;
      case "order_delete":
         if (!$db->Execute("DELETE FROM orders WHERE ordID='$idlord'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	}
		 if (!$db->Execute("DELETE FROM ord_line_items WHERE order_number='$ord_numbdel'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB Error: " . $db->ErrorMsg() . "</td></tr></table>";
	  break;
   			}
         echo "<table class=\"notice\" width=\"100%\"><tr><td>This Order (id $idlord) was sucessfuly deleted.</td></tr></table>";
         paint_table($db);
         break;
	case "delete_line":
         if (!$db->Execute("DELETE FROM ord_line_items WHERE id_row='$id'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	} else {
				// &ord_number=<? php echo $ord_number; ? >
		echo "<table class=\"notice\" width=\"100%\"><tr><td>La riga (id $id) che era inserita nell'ordine $ord_number &eacute; stata cancellata !!!.</td></tr></table>";
			}
         edit_order_form($db, $ord_number, $id_of_order);
         break;
	case "add_kline":
         new_line_item($db, $ord_number, $lnitems, $id_of_order);
         break;
	case "edit_singleline":
         edit_line($db, $ord_number, $id);
         break;
    case "update_line":
		$ord_number=$eq_ord_number;
		$id_of_order=$KorderID;
	### su mySQL:
// id_row | order_number | orderID_ln | prod_id | product_code | prod_descript1                | prod_descript2  | prod_unit | prpack_sale_price | prd_tax | prod_qty | prd_singlepack_qty | prd_credits_value | prod_single_sale | prd_total_row | available |
	### VARIABILI PASSATE :
//  product_code || prpack_sale_price || single_packet_qty || prd_credits_value || prod_single_sale || available || row_id || eq_ord_number  || id_Korder
		// ### NON UTILIZZATE :::    ID_fornit / id_forni
			$prz_tot_formattato = sprintf("%01.2f", $totale_riga);
         	$prezzo_tot_riga = sprintf("%01.2f", $prod_qty * $prz_tot_formattato);
        // $unit_price = sprintf("%01.2f", $unit_price);
        // $amount = sprintf("%01.2f", $qty * $unit_price);
	$query = "UPDATE ord_line_items SET"
		. " order_number='$eq_ord_number', orderID_ln='$id_Korder', prod_id='$prod_id',"
		. " product_code='$product_code', prod_descript1='$prod_descript1',"
		. " prod_descript2='$prod_descript2', prod_unit='$pr_unit', prpack_sale_price='$prpack_sale_price',"
		. " prd_tax='$ptax1', prod_qty='$prod_qty', prd_singlepack_qty='$single_packet_qty',"
		. " prd_credits_value='$prd_credits_value', prod_single_sale='$prod_single_sale',"
		. " prd_total_row='$prezzo_tot_riga', available='$available'"
		. " WHERE id_row=$row_id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_order_form($db, $ord_number, $id_of_order);
         break;
	case "edit_po":
         edit_order_form($db, $ord_number, $id_of_order);
         break;
	case "add_orderdata":
		if ($org == "" or $org == "Select" or $org == " ") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The <b><font size='+1'>organizatio</font></b>n field is required.</td></tr></table>";
            AddOrder_form($db);
            break;
         }
         if ($ord_number == "" or $ord_nr == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The order <b><font size='+1'>number</font></b> field is required.</td></tr></table>";
            AddOrder_form($db);
            break;
         }
         if ($contract_start == "" or $contract_end == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The date of contract_start and contract_end are required.</td></tr></table>";
            AddOrder_form($db);
            break;
         }
		$Kdatenow = date("Y-m-d");
         if ($date == "") { $date = $Kdatenow; }
		 if (!isset($tax_exempt)) { $tax_exempt = "N"; }
		 if (!isset($payed)) { $payed = "N"; }
	$id = $db->GenID("orders_seq");
	$opened = "Y";
	$ord_number2 = $ord_nr;
	// ord_number, date, contract_start, contract_end, id_organization, id_vendor, id_gwprovider, sms_credit, sms_debit, payed, type_payment, tax_exempt, amount_tax1, amount_tax2, amount_tax3, percent_tax1, percent_tax2, percent_tax3, tot_amount, tot_order, created_by, mail_address_confirmsend, closed, comments
	// ord_number, date, contract_start, contract_end, id_organization, id_vendor, id_gwprovider, payed, type_payment, tax_exempt, created_by, mail_address_confirmsend, open, comments
		$query = "INSERT INTO orders (ord_number, date, contract_start, contract_end, id_organization, id_vendor, id_gwprovider, payed, type_payment, tax_exempt, law_exart, created_by, mail_address_confirmsend, open, comments)"
		. " VALUES ('$ord_number2','$date', '$contract_start', '$contract_end', '$org', '$vendor', '$gateway', '$payed', '$payment_type','$tax_exempt', '$law_exart', '$created_by', '$email_poconf', '$opened', '$ord_comments')";
         if (!$db->Execute($query)) {
		$dperr = $db->ErrorMsg();
		$duplic_err = substr($dperr, 0, 15);
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB INS ERROR: " . $db->ErrorMsg() . " --- <b>".$duplic_err."</b></td></tr></table>";
			if ($duplic_err == "Duplicate entry") {
			echo "<table class=\"descrinotes\" width=\"100%\"><tr><td>Non &egrave; possibile inserire pi&uacute; ordini con lo stesso numero.L'errore forse &egrave; dovuto dal fatto che hai aggiornato la pagina. Ti consiglio di ritornare in inserimento_ordini, <a href='admin_orders.php?action=nneworder'><b>cliccando qui</b></a></td></tr></table>";
				require("footer.inc.php");
				break;
			}
            AddOrder_form($db);
            break;
		}
	echo "<table class=\"notice\" width=\"100%\"><tr><td>Head Order was inserted in database!<br>Testata dell'ordine inserita nel database!</td></tr></table>";
		//paint_table($db);
		$id_of_order="";
		edit_order_form($db, $ord_number, $id_of_order);
		break;
	case "new_ord":
         new_order_form($db);
         break;
	case "nneworder":
         AddOrder_form($db);
         break;
	case "order_addlines":
 ### VARIABILI PASSATE :
// variabili da forminsrow ::: $product_code || $prod_qty || $prod_descript1 || $prod_descript2 || $unit || $tax1 || $sale_price || $single_packet_qty || $credits_sale_value || $single_sale_price || $available || $ord_number || $id_of_order || $prod_id || $ord_number
 #
// variabili da mySQL ::: id_row || order_number || orderID_ln || prod_id || id_forni || product_code || prod_descript1 || prod_descript2 || prod_unit || prpack_sale_price || prd_tax || prod_qty || prd_singlepack_qty || prd_credits_value || prod_single_sale || prd_total_row || available
		// %01.2f ---> formatta il numero e lo porta a 2 decimali!!!
         $ttotal_pack_price = sprintf("%01.2f", $sale_price);
         $krow_pr_amount = sprintf("%01.2f", $prod_qty * $ttotal_pack_price);
		 $row_total_prod_it = number_format($krow_pr_amount, 2, ',', '.'); // italian format numbers!!!
         //  $id = $db->GenID("line_items_seq");
         $query = "INSERT INTO ord_line_items (order_number, orderID_ln, prod_id, product_code, prod_descript1, prod_descript2, prod_unit, prpack_sale_price, prd_tax, prod_qty, prd_singlepack_qty, prd_credits_value, prod_single_sale, prd_total_row, available)"
                . " VALUES ('$ord_number', '$id_of_order', '$prod_id', '$product_code', '$prod_descript1', '$prod_descript2', '$unit', '$sale_price', '$tax1', '$prod_qty', '$single_packet_qty', '$credits_sale_value', '$single_sale_price', '$krow_pr_amount', '$available')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
//       echo "<font face='Courier,Geneva,sans-serif' size='3' color='#D31238'>";
//       echo "TEST DELLE VARIABILI<br>";
//       echo "<b>order_number &raquo; ".$ord_number."</b> &laquo;<br>";
//       echo "prod_id &raquo; <b>".$prod_id."</b> &laquo;<br>";
//       echo "product_code &raquo; <b>".$product_code."</b> &laquo;<br>";
//       echo "prod_descript1 &raquo; <b>".$prod_descript1."</b> &laquo;<br>";
//       echo "prod_descript2 &raquo; <b>".$prod_descript2."</b> &laquo;<br>";
//       echo "prod_qty &raquo; <b>".$prod_qty."</b> &laquo;<br>";
//       echo "prod_unit &raquo; <b>".$prod_unit."</b> &laquo;<br>";
//       echo "pr_unit_price &raquo; <b>".$pr_unit_price."</b> &laquo;<br>";
//       echo "prod_amount &raquo; <b>".$prod_amount."</b> &laquo;<br>";
//       echo "pr_addprice_descript &raquo; <b>".$pr_addprice_descript."</b> &laquo;<br>";
//       echo "pr_addprice &raquo; <b>".$pr_addprice."</b> &laquo;<br>";
//       echo "credits_val &raquo; <b>".$credits_val."</b> &laquo;<br>";
//       echo "tax1 &raquo; <b>".$tax1."</b> &laquo;<br>";
//       echo "row_prod_amount-Tot. Riga &raquo; <b>".$row_pr_amount."</b> &laquo;<br>";
//       echo "available &raquo; <b>".$available."</b> &laquo;<br>";
//       echo "<br><hr>";
//       echo "Tot. Riga (italian format)<b>".$row_pr_amount_it."</b><br>";
//       echo "Prezzo Prodotto (formattato) <b>".$amount_pack_price."</b><br>";
//       echo "</font><br>";
     edit_order_form($db, $ord_number, $id_of_order);
     break;
//
// CHIUSURA DELL'ORDINE, AGGIORNAMENTO TBL CON IL TOTALE ORDINE E AGGIORNAMENTO DEI CREDITI !!! ///////
//
    case "close_po":
	$id_of_order = $ordkeyID;
	 if (!$po = $db->Execute("SELECT contract_end, id_organization, open FROM orders WHERE ordID='$ordkeyID'")) {
		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	   }
  if ($po->fields["open"] == "Y") {
		# Update the order_table (orders) with "Order Total" :::
		$ord_lines2 = $db->Execute("SELECT * FROM ord_line_items WHERE orderID_ln='$ordkeyID'");
				$i = 1;
			 	while (!$ord_lines2->EOF) {
				$k_total_row = $ord_lines2->fields["prd_total_row"];
				$k_single_qty = $ord_lines2->fields["prd_singlepack_qty"];
				$k_credits_value = $ord_lines2->fields["prd_credits_value"];
				$k_prod_qty = $ord_lines2->fields["prod_qty"];
					$order_tot +=  $k_total_row;
					$credstot += ($k_prod_qty * $k_single_qty);
         			$i++;
         			$ord_lines2->MoveNext();
      					}
echo "<font face='Arial,Helvetica,sans-serif' size='4' color='#F9714F'>Totale Ordine &raquo; <b>".$order_tot."</b> &laquo;</font><br>";
echo "<font face='Arial,Helvetica,sans-serif' size='4' color='#F9714F'>Totale Crediti &raquo; <b>".$credstot."</b> &laquo;</font> (smscredits o nr.sms)<br>";
		$query_creds1 = "UPDATE orders SET"
		. " order_total='$order_tot'"
		. " WHERE ordID='$ordkeyID' AND open='Y'";
         if (!$db->Execute($query_creds1)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: creds1 - " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	}


		// UPDATE THE CUSTOMER'S CREDITS :::
			$id_of_company = $po->fields["id_organization"];
			$insert_now = date("Y-m-d");
			if (!$po_creds = $db->Execute("SELECT company, connext_type FROM organization WHERE id='$id_of_company'")) {
               echo "<table class='notice' width='100%'><tr><td>orderDB ERROR: " . $db->ErrorMsg();
			   echo "</td></tr></table>";
               break;
            	}
		$rem_connect = $po_creds->fields["connext_type"];
		echo "<p class='addnotes'>Tipo Connessione &raquo; <b>".$rem_connect."</b> &laquo;</p><br>";
		if ($rem_connect == "") { $rem_connect == "nnt"; }
		$orgcompany = $po_creds->fields["company"];
		if ($rem_connect == "fee") {
		  $tbl_creds = $db->Execute("SELECT * FROM credits_manager WHERE id_orgz='$id_of_company'");
		  	$mycreds = $tbl_creds->fields["smscredits_totalsum"];
			 if (!$mycreds) {
				# Essendo il primo inserimento, i CREDITI RIMASTI corrispondono al 
				#  totale dei crediti inseriti!
				$cred_remained = $credstot;
			// TESTING ..........................................................
			echo "<p class='linev'>connessione=".$rem_connect." | credTotali Precedenti=".$mycreds."</p><br>";
			echo "<p class='linev'>credstot=".$credstot." | valore crediti=".$k_credits_value."</p><br>";
			// end TESTING.........................................................
				$query_crm = "INSERT INTO credits_manager (id_orgz, orgz_company, connext_type, credits_sale_value, smscredits_totalsum, smscredits_remain, date_ins, last_update, credit_activated)"
                . " VALUES ('$id_of_company', '$orgcompany', '$rem_connect', '$k_credits_value', '$credstot', '$cred_remained', '$insert_now ', NOW(), 'Y')";
         	   			if (!$db->Execute($query_crm)) {
            			echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: 
						crm19 - " . $db->ErrorMsg() . "</td></tr></table>";
						break;
			           	  }
			    } else {
			if ($mycreds == "") { $mycreds = 0; }
			if ($mycreds) {
				$actualcreds = $tbl_creds->fields["smscredits_totalsum"];
				$actualremain = $tbl_creds->fields["smscredits_remain"];
				$newtotcreds = $credstot + $actualcreds;
				$cred_remained = $actualremain + $newtotcreds;
				$newcredt = $actualremain + $credstot;
			// TESTING ...........................................................
			echo "<p class='linev'>CREDITI_INSERITI (Totale della riga dell'ordine)=".$credstot." | NUOVO CREDITO RIMASTO=".$newcredt."</p><br>";
			echo "<p class='linev'>CREDS_ATTUALE=".$actualcreds." | CR_remain=".$actualremain."</p><br>";
			echo "<p class='linev'>newTOTcreds=".$newtotcreds." | 
				valore crediti=".$k_credits_value." | CRED_RIMASTI=".$cred_remained."</p><br>";
			// end TESTING.........................................................
			 $query_creds1 = "UPDATE credits_manager SET"
			 	. " credits_sale_value='$k_credits_value', smscredits_totalsum='$newtotcreds',"
				. " smscredits_remain='$newcredt', last_update=NOW()"
				. " WHERE id_orgz='$id_of_company' AND credit_activated='Y'";
         		if (!$db->Execute($query_creds1)) {
            	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: creds1
				  - " . $db->ErrorMsg() . "</td></tr></table>";
            	break;
         	        }
			  	} // end if ($tbl_creds->fields["smscredits_totalsum"] != 0...
			}
		} // if ($rem_connect == "fee")

### OTHER CONNECTION TYPE (1:1)
   // SE IL TIPO DI CONNESSIONE E' OneToOne (1:1), ovvero "oto" [1 credito per 1 sms spedito]
		if ($rem_connect == "oto") {
	echo "<p class='linev'>ATTENZIONE ::: STAI UTILIZZANDO LA PROCEDURA OTO-1:1 (OneToOne). QUESTA NON E' STATA SUFFICIENTEMENTE TESTATA PER CUI CI POTREBBERO ESSERE DEI PROBLEMI SULL'INSERIMENTO DEI DATI SU DATABASE. SIA SULLE TABELLE DEGLI ORDINI CHE SULLE TABELLE DI GESTIONE CREDITI !!!</p><br>";
		  $tbl_creds = $db->Execute("SELECT * FROM credits_manager WHERE id_orgz='$id_of_company'");
		  $mycreds_oto = $tbl_creds->fields["nrsms_totalsum"];
			 	if (!$mycreds_oto) {
			$query_crm = "INSERT INTO credits_manager (id_orgz, orgz_company, connext_type, credits_sale_value, nrsms_totalsum, last_update, credit_activated)"
			//	$query_crm = "INSERT INTO credits_manager (id_orgz, orgz_company, connext_type, smscredits_totalsum, last_update, credit_activated)"
                . " VALUES ('$id_of_company', '$orgcompany', '$rem_connect', '$k_credits_value', '$credstot', NOW(), 'Y')";
         	   if (!$db->Execute($query_crm)) {
            	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: crm - " . $db->ErrorMsg() . "</td></tr></table>";
			        }
			    } // end if ($tbl_creds->fields["nrsms_totalsum"] == 0)...
				else {
			 if ($mycreds_oto) {
				$actualcreds = $tbl_creds->fields["smscredits_totalsum"];
				$newtotcreds = $credstot + $actualcreds;
				$actualremain = $tbl_creds->fields["smscredits_remain"];
				$newtotremn = $credstot + $actualremain;
				$new_oto_credt = $actualremain + $credstot;
			 $query_creds1 = "UPDATE credits_manager SET"
			 . " credits_sale_value='$k_credits_value', smscredits_totalsum='$newtotcreds',"
			 . " nrsms_remain='$new_oto_credt', last_update=NOW()"
			 . " WHERE id_orgz='$id_of_company' AND credit_activated='Y'";
              if (!$db->Execute($query_creds1)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: creds1 - " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	    }
			  } // end if ($tbl_creds->fields["nrsms_totalsum"] != 0)...
			} // else
	      } // if ($rem_connect == "oto")
	### if $rem_connect <> "oto" or "fee"
	### Add this message when $rem_connect is not like "oto" or "fee" :
		if ($rem_connect == "oto") { $rem_connect2 = 1; }
		if ($rem_connect == "fee") { $rem_connect2 = 2; }
		if ($rem_connect == "nnt") { $rem_connect2 = 3; }
		if ($rem_connect == "") { $rem_connect2 = 4; }
		if ($rem_connect2 > 2) {
		echo "<br><table bgcolor='#000000' align='center' width='80%'><tr><td><b><font color='#F7EC2B'>Questo cliente (organization-".$rem_connect2.") non ha attivo il tipo di connessione.</font></b></td></tr><tr><td><b><font color='#ffffff'>Pertanto non vengono inseriti e/o aggiornati i crediti !!</font></b></td></tr></table>";
				}
// APPUNTI //
			 /*
			 $ord_lines = $db->Execute("SELECT * FROM ord_line_items WHERE orderID_ln='$ordkeyID'");
			 	while (!$ord_lines->EOF) {
					$credits_totalrow = ($prd_singlepack_qty * $prd_credits_value);
					$credstot += $credits_totalrow;
         			$i++;
         			$ord_lines->MoveNext();
      					}
 		. " id_orgz='$id_of_company', orgz_company='$orgcompany', connext_type='$rem_connect',"
		. " smscredits_totalsum='$credstot', smscredits_spend='$smscredits_spend',"
		. " smscredits_remain='$smscredits_remain', nrsms_totalsum='$nrsms_totalsum',"
		. " nrsms_spend='$nrsms_spend', nrsms_remain='$nrsms_remain', last_update='$last_update',"
		. " credit_activated='$credit_activated',"
		. " WHERE id_orgz='$id_of_company'";
*/
if (!$db->Execute("UPDATE orders SET open='N' WHERE ordID='$ordkeyID'")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>orderDB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            	}
			
  } // END  if ($po->fields["open"] == "Y")
         edit_order_form($db, $ord_number, $id_of_order);
         break;
		    default:
      			//	new_order_form($db);
	  			//	AddOrder_form($db);
	  			 paint_table($db);
   }    ### fine   switch ($action)
} ### fine   if ($privs == '69'AND $projname == 'KSMS')
	else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer2.inc.php");
?>
