<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
 */
/* 	2005 05 21		| 	admgrab_globals.inc.php*/

// This file will set the GET and POST variables. This works for PHP >= 4.0
// with register_globals = off OR on (off is recomended for PHP >= 4.1).


if (!empty($_GET)) {
   extract($_GET, EXTR_OVERWRITE);
} else if (!empty($HTTP_GET_VARS)) {
   extract($HTTP_GET_VARS, EXTR_OVERWRITE);
}

if (!empty($_POST)) {
   extract($_POST, EXTR_OVERWRITE);
} else if (!empty($HTTP_POST_VARS)) {
   extract($HTTP_POST_VARS, EXTR_OVERWRITE);
}

if (!empty($_FILES)) {
   while (list($name, $value) = each($_FILES)) {
      $$name = $value["tmp_name"];
   }
} else if (!empty($HTTP_POST_FILES)) {
   while (list($name, $value) = each($HTTP_POST_FILES)) {
      $$name = $value["tmp_name"];
   }
}

// The rest of this file is specific to Ksms. Cut it out if you
// use this file in other applications.

// Initialize the $action variable if it is not already set.
if (!isset($action)) $action = "null";
?>

