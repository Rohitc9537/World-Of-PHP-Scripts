<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
  ?>
<select name="province">
<option selected>-->Seleziona la prov.</option>
<option value="AG"<?PHP if($org->fields["province"]=="AG"){echo("SELECTED");};?>>Agrigento</option>
<option value="AL"<?PHP if($org->fields["province"]=="AL"){echo("SELECTED");};?>>Alessandria</option>
<option value="AN"<?PHP if($org->fields["province"]=="AN"){echo("SELECTED");};?>>Ancona</option>
<option value="AO"<?PHP if($org->fields["province"]=="AO"){echo("SELECTED");};?>>Aosta</option>
<option value="AR"<?PHP if($org->fields["province"]=="AR"){echo("SELECTED");};?>>Arezzo</option>
<option value="AP"<?PHP if($org->fields["province"]=="AP"){echo("SELECTED");};?>>Ascoli Piceno</option>
<option value="AT"<?PHP if($org->fields["province"]=="AT"){echo("SELECTED");};?>>Asti</option>
<option value="AV"<?PHP if($org->fields["province"]=="AV"){echo("SELECTED");};?>>Avellino</option>
<option value="BA"<?PHP if($org->fields["province"]=="BA"){echo("SELECTED");};?>>Bari</option>
<option value="BL"<?PHP if($org->fields["province"]=="BL"){echo("SELECTED");};?>>Belluno</option>
<option value="BN"<?PHP if($org->fields["province"]=="BN"){echo("SELECTED");};?>>Benevento</option>
<option value="BG"<?PHP if($org->fields["province"]=="BG"){echo("SELECTED");};?>>Bergamo</option>
<option value="BI"<?PHP if($org->fields["province"]=="BI"){echo("SELECTED");};?>>Biella</option>
<option value="BO"<?PHP if($org->fields["province"]=="BO"){echo("SELECTED");};?>>Bologna</option>
<option value="BZ"<?PHP if($org->fields["province"]=="BZ"){echo("SELECTED");};?>>Bolzano</option>
<option value="BS"<?PHP if($org->fields["province"]=="BS"){echo("SELECTED");};?>>Brescia</option>
<option value="BR"<?PHP if($org->fields["province"]=="BR"){echo("SELECTED");};?>>Brindisi</option>
<option value="CA"<?PHP if($org->fields["province"]=="CA"){echo("SELECTED");};?>>Cagliari</option>
<option value="CL"<?PHP if($org->fields["province"]=="CL"){echo("SELECTED");};?>>Caltanisetta</option>
<option value="CB"<?PHP if($org->fields["province"]=="CB"){echo("SELECTED");};?>>Campobasso</option>
<option value="CE"<?PHP if($org->fields["province"]=="CE"){echo("SELECTED");};?>>Caserta</option>
<option value="CT"<?PHP if($org->fields["province"]=="CT"){echo("SELECTED");};?>>Catania</option>
<option value="CZ"<?PHP if($org->fields["province"]=="CZ"){echo("SELECTED");};?>>Catanzaro</option>
<option value="CH"<?PHP if($org->fields["province"]=="CH"){echo("SELECTED");};?>>Chieti</option>
<option value="CO"<?PHP if($org->fields["province"]=="CO"){echo("SELECTED");};?>>Como</option>
<option value="CS"<?PHP if($org->fields["province"]=="CS"){echo("SELECTED");};?>>Cosenza</option>
<option value="CR"<?PHP if($org->fields["province"]=="CR"){echo("SELECTED");};?>>Cremona</option>
<option value="KR"<?PHP if($org->fields["province"]=="KR"){echo("SELECTED");};?>>Crotone</option>
<option value="CN"<?PHP if($org->fields["province"]=="CN"){echo("SELECTED");};?>>Cuneo</option>
<option value="EN"<?PHP if($org->fields["province"]=="EN"){echo("SELECTED");};?>>Enna</option>
<option value="FE"<?PHP if($org->fields["province"]=="FE"){echo("SELECTED");};?>>Ferrara</option>
<option value="FI"<?PHP if($org->fields["province"]=="FI"){echo("SELECTED");};?>>Firenze</option>
<option value="FG"<?PHP if($org->fields["province"]=="FG"){echo("SELECTED");};?>>Foggia</option>
<option value="FC"<?PHP if($org->fields["province"]=="FC"){echo("SELECTED");};?>>Forl�-Cesena</option>
<option value="FR"<?PHP if($org->fields["province"]=="FR"){echo("SELECTED");};?>>Frosinone</option>
<option value="GE"<?PHP if($org->fields["province"]=="GE"){echo("SELECTED");};?>>Genova</option>
<option value="GO"<?PHP if($org->fields["province"]=="GO"){echo("SELECTED");};?>>Gorizia</option>
<option value="GR"<?PHP if($org->fields["province"]=="GR"){echo("SELECTED");};?>>Grosseto</option>
<option value="IM"<?PHP if($org->fields["province"]=="IM"){echo("SELECTED");};?>>Imperia</option>
<option value="IS"<?PHP if($org->fields["province"]=="IS"){echo("SELECTED");};?>>Isernia</option>
<option value="AQ"<?PHP if($org->fields["province"]=="AQ"){echo("SELECTED");};?>>L'Aquila</option>
<option value="SP"<?PHP if($org->fields["province"]=="SP"){echo("SELECTED");};?>>La Spezia</option>
<option value="LT"<?PHP if($org->fields["province"]=="LT"){echo("SELECTED");};?>>Latina</option>
<option value="LE"<?PHP if($org->fields["province"]=="LE"){echo("SELECTED");};?>>Lecce</option>
<option value="LC"<?PHP if($org->fields["province"]=="LC"){echo("SELECTED");};?>>Lecco</option>
<option value="LI"<?PHP if($org->fields["province"]=="LI"){echo("SELECTED");};?>>Livorno</option>
<option value="LO"<?PHP if($org->fields["province"]=="LO"){echo("SELECTED");};?>>Lodi</option>
<option value="LU"<?PHP if($org->fields["province"]=="LU"){echo("SELECTED");};?>>Lucca</option>
<option value="MC"<?PHP if($org->fields["province"]=="MC"){echo("SELECTED");};?>>Macerata</option>
<option value="MN"<?PHP if($org->fields["province"]=="MN"){echo("SELECTED");};?>>Mantova</option>
<option value="MS"<?PHP if($org->fields["province"]=="MS"){echo("SELECTED");};?>>Massa</option>
<option value="MT"<?PHP if($org->fields["province"]=="MT"){echo("SELECTED");};?>>Matera</option>
<option value="ME"<?PHP if($org->fields["province"]=="ME"){echo("SELECTED");};?>>Messina</option>
<option value="MI"<?PHP if($org->fields["province"]=="MI"){echo("SELECTED");};?>>Milano</option>
<option value="MO"<?PHP if($org->fields["province"]=="MO"){echo("SELECTED");};?>>Modena</option>
<option value="NA"<?PHP if($org->fields["province"]=="NA"){echo("SELECTED");};?>>Napoli</option>
<option value="NO"<?PHP if($org->fields["province"]=="NO"){echo("SELECTED");};?>>Novara</option>
<option value="NU"<?PHP if($org->fields["province"]=="NU"){echo("SELECTED");};?>>Nuoro</option>
<option value="OR"<?PHP if($org->fields["province"]=="OR"){echo("SELECTED");};?>>Oristano</option>
<option value="PD"<?PHP if($org->fields["province"]=="PD"){echo("SELECTED");};?>>Padova</option>
<option value="PA"<?PHP if($org->fields["province"]=="PA"){echo("SELECTED");};?>>Palermo</option>
<option value="PR"<?PHP if($org->fields["province"]=="PR"){echo("SELECTED");};?>>Parma</option>
<option value="PV"<?PHP if($org->fields["province"]=="PV"){echo("SELECTED");};?>>Pavia</option>
<option value="PE"<?PHP if($org->fields["province"]=="PE"){echo("SELECTED");};?>>Perugia</option>
<option value="PU"<?PHP if($org->fields["province"]=="PU"){echo("SELECTED");};?>>Pesaro-Urbino</option>
<option value="PE"<?PHP if($org->fields["province"]=="PE"){echo("SELECTED");};?>>Pescara</option>
<option value="PC"<?PHP if($org->fields["province"]=="PC"){echo("SELECTED");};?>>Piacenza</option>
<option value="PI"<?PHP if($org->fields["province"]=="PI"){echo("SELECTED");};?>>Pisa</option>
<option value="PT"<?PHP if($org->fields["province"]=="PT"){echo("SELECTED");};?>>Pistoia</option>
<option value="PN"<?PHP if($org->fields["province"]=="PN"){echo("SELECTED");};?>>Pordenone</option>
<option value="PT"<?PHP if($org->fields["province"]=="PT"){echo("SELECTED");};?>>Potenza</option>
<option value="PO"<?PHP if($org->fields["province"]=="PO"){echo("SELECTED");};?>>Prato</option>
<option value="RG"<?PHP if($org->fields["province"]=="RG"){echo("SELECTED");};?>>Ragusa</option>
<option value="RA"<?PHP if($org->fields["province"]=="RA"){echo("SELECTED");};?>>Ravenna</option>
<option value="RC"<?PHP if($org->fields["province"]=="RC"){echo("SELECTED");};?>>Reggio Calabria</option>
<option value="RE"<?PHP if($org->fields["province"]=="RE"){echo("SELECTED");};?>>Reggio Emilia</option>
<option value="RI"<?PHP if($org->fields["province"]=="RI"){echo("SELECTED");};?>>Rieti</option>
<option value="RN"<?PHP if($org->fields["province"]=="RN"){echo("SELECTED");};?>>Rimini</option>
<option value="Roma"<?PHP if($org->fields["province"]=="Roma"){echo("SELECTED");};?>>Roma</option>
<option value="RO"<?PHP if($org->fields["province"]=="RO"){echo("SELECTED");};?>>Rovigo</option>
<option value="SA"<?PHP if($org->fields["province"]=="SA"){echo("SELECTED");};?>>Salerno</option>
<option value="SS"<?PHP if($org->fields["province"]=="SS"){echo("SELECTED");};?>>Sassari</option>
<option value="SV"<?PHP if($org->fields["province"]=="SV"){echo("SELECTED");};?>>Savona</option>
<option value="SI"<?PHP if($org->fields["province"]=="SI"){echo("SELECTED");};?>>Siena</option>
<option value="SR"<?PHP if($org->fields["province"]=="SR"){echo("SELECTED");};?>>Siracusa</option>
<option value="SO"<?PHP if($org->fields["province"]=="SO"){echo("SELECTED");};?>>Sondrio</option>
<option value="TA"<?PHP if($org->fields["province"]=="TA"){echo("SELECTED");};?>>Taranto</option>
<option value="TE"<?PHP if($org->fields["province"]=="TE"){echo("SELECTED");};?>>Teramo</option>
<option value="TR"<?PHP if($org->fields["province"]=="TR"){echo("SELECTED");};?>>Terni</option>
<option value="TO"<?PHP if($org->fields["province"]=="TO"){echo("SELECTED");};?>>Torino</option>
<option value="TP"<?PHP if($org->fields["province"]=="TP"){echo("SELECTED");};?>>Trapani</option>
<option value="TN"<?PHP if($org->fields["province"]=="TN"){echo("SELECTED");};?>>Trento</option>
<option value="TV"<?PHP if($org->fields["province"]=="TV"){echo("SELECTED");};?>>Treviso</option>
<option value="TS"<?PHP if($org->fields["province"]=="TS"){echo("SELECTED");};?>>Trieste</option>
<option value="UD"<?PHP if($org->fields["province"]=="UD"){echo("SELECTED");};?>>Udine</option>
<option value="VA"<?PHP if($org->fields["province"]=="VA"){echo("SELECTED");};?>>Varese</option>
<option value="VE"<?PHP if($org->fields["province"]=="VE"){echo("SELECTED");};?>>Venezia</option>
<option value="VB"<?PHP if($org->fields["province"]=="VB"){echo("SELECTED");};?>>Verbania</option>
<option value="VC"<?PHP if($org->fields["province"]=="VC"){echo("SELECTED");};?>>Vercelli</option>
<option value="VR"<?PHP if($org->fields["province"]=="VR"){echo("SELECTED");};?>>Verona</option>
<option value="VV"<?PHP if($org->fields["province"]=="VV"){echo("SELECTED");};?>>Vibo Valentia</option>
<option value="VI"<?PHP if($org->fields["province"]=="VI"){echo("SELECTED");};?>>Vicenza</option>
<option value="VT"<?PHP if($org->fields["province"]=="VT"){echo("SELECTED");};?>>Viterbo</option>
<option value="EE"<?PHP if($org->fields["province"]=="EE"){echo("SELECTED");};?>>EE (estero)</option>
    </select>
