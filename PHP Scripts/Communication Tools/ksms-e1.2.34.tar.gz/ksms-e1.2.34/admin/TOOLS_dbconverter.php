<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/

// THIS IS ONLY USED FOR AN OLD PROGRAM USED BY OUR CUSTOMERS

// module = TOOLS - CONVERTER from ASSIPLANSMS to KSMS
// gestione classificazione :::
$title = "Tools/Converters/AssiplanSMSDB_to_kSMSDB";
require("admcommon.inc.php");

/*

1.)	Selezionare il file di testo che contiene il DB completo da ASSIPLANSMS   [selezionafile]
2.)	Importare i dati contenuti nel file
3.)	Convertirli e trasformarli (max lunghezza, togli caratteri che non vanno,..etc..)
4.)	Importarli nel nuovo DB

*/
function pretables($db) {
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
$date_now = date("Ymd-is");
$arr = "<img src='".$imgs_admin_dir."rtarrow.gif' alt='-&gt;' width='22' height='18' border='0' align='middle'>";
	echo "<br><hr><br>";
	echo "<p class='tbl_notes'>	AGGIORNAMENTO TABELLE SUL <b>KSMS DATABASE</b> !!!	</p>";
	echo "<p class='addnotes'>Con questa operazione cancelli ed inserisci alcune tabelle.
		In particolare cancelli (se esistono) le vecchie tabelle inserite sul nuovo KSMSDB.
		Poi automaticamente vengono ricreate, in modo da essere pronti ad importare il db
	</p>";
	echo "<p class='descrtxNa'>";
	echo $arr." &nbsp;In pratica queste le tabelle aggiunte sul nuovo <b>ksmsDB</b>:<br>";
	echo "<p class='rawrow'>";
	echo "mysql -u paol -p<br>";
	echo "&gt;&nbsp; use ksmsDB;<br>";
	echo "DROP TABLE IF EXISTS gestori;<br>";
	echo "CREATE TABLE gestori (...<br>";
	echo "DROP TABLE IF EXISTS pubblicita;<br>";
	echo "CREATE TABLE pubblicita (...<br>";
	echo "DROP TABLE IF EXISTS rappresentanti;<br>";
	echo "CREATE TABLE rappresentanti (...<br>";
	echo "DROP TABLE IF EXISTS sms;<br>";
	echo "CREATE TABLE sms (...<br>";
	echo "DROP TABLE IF EXISTS testipub;<br>";
	echo "CREATE TABLE testipub (...<br>";
	echo "DROP TABLE IF EXISTS utenti;<br>";
	echo "CREATE TABLE utenti (...<br>";
	echo "<br>";
	echo "</p><br>";
	echo "<p class='tbl_notes'>SE VUOI CREARE QUESTE TABELLE, <a href='TOOLS_dbconverter.php?action=addtables'>CLICCA QUI</a></p>";
}
function main_page($db) {
$date_now = date("Ymd-is");
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
$arr = "<img src='".$imgs_admin_dir."rtarrow.gif' alt='-&gt;' width='22' height='18' border='0' align='middle'>";
	echo "<br><hr><br>";
	echo "<p class='linev'><b>La prima cosa IMPORTANTE da ricordare &egrave; che, prima di fare queste operazioni di importazione DB, devi avere gi&aacute; settato il programma con almeno 1 CLIENTE e devi aver gi&aacute; configurato le CLASSI, le CATEGORIE e i GRUPPI !!!</b></p> ";
	echo "<br><hr><br>";
	echo "<p class='evdrow'>SERVER-001</p>";
	echo "<p class='descrtxNa'>".$arr."
		La prima cosa da fare � collegarsi al DB in assiplan e creare un file SQL con la seguente riga:
		</p>";
	echo "<p class='descrtxNa'>&nbsp;&nbsp; (copia esattamente la seguente riga in shell del server 1!)</p>";
	echo "<p class='rawrow'>";
	echo "mysqldump -c --opt -e assiplansms -u paolo -p > /home/assiplan/_AssiplanSMS-".$date_now.".sql";
	echo "</p>";
	echo "<p class='descrtxNa'>".$arr."
		Entra nella directory del SERVER001 (<b>/home/assiplan/</b>) e copia il file appena creato (<b>_AssiplanSMS-".$date_now.".sql</b>)";
	echo "</p>";
	echo "<hr width='100%' color='#FFFFFF'>";
	echo "<p class='evdrow'>SERVER-002</p>";
	echo "<p class='descrtxNa'>";
	echo $arr." &nbsp;Assicurati che il database <b>ksmsDB</b> abbia anche le tabelle del vecchio <b>assplansms</b><br>";
	echo $arr." &nbsp;Incolla il file appena creato (server001) e copialo nella cartella 
		<b>/home/viabazar/</b> del server <b>002</b><br>".$arr;
	echo " &nbsp;Esegui quindi l'importazione del file in mysql, con le seguenti righe :</p>";
	echo "<p class='rawrow'>";
	// Importo le righe del vecchioDB su "ksmsDB", senza creare un DB nuovo!
	// echo "CREATE DATABASE assiplansms;<br>";
	//echo "GRANT ALL PRIVILEGES ON assiplansms.* TO paolo@localhost IDENTIFIED BY 'p..9...x';<br>";
	//echo "mysql -u paolo -p assiplansms < /home/viabazar/_AssiplanSMS-".$date_now.".sql";
	echo "mysql -u paolo -p ksmsDB < /home/viabazar/_AssiplanSMS-".$date_now.".sql";
	echo "</p><br>";
	echo "<hr width='100%' color='#FFFFFF'><p class='descrtxNa'>";
	echo "A questo punto ci troviamo il database ASSIPLANSMS anche sul server 002<br>";
	echo "</p><br><br>";
	echo "<p class='descrtxNa'>";
	echo "&nbsp;&nbsp;&nbsp; <a href='TOOLS_dbconverter.php?action=secondstep'>CLICCA QUI PER PROSEGUIRE</a><br>";
echo "<br>&nbsp;&nbsp;&nbsp; <a href='TOOLS_dbconverter.php?action=advisor'>OPPURE QUI PER AZZERARE E INSERIRE SUL DB LE TABELLE MANCANTI</a>";
	echo "</p><br><br>";
 } // end main function

function importdata($db) {
	   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	echo "<br><hr width='100%' color='#FFFFFF'><br><p class='rawrow'>";
	echo ".........selecting data for ksmsDB........................";
	echo "</p><br>";
	   	   if (!$oldorganiz = $db->Execute("SELECT Login_Rappresentante,IDRappresentante FROM rappresentanti ORDER BY Login_Rappresentante")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		//break;
			return FALSE;
		}
	if (!$neworganiz = $db->Execute("SELECT company,id FROM organization ORDER BY company")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		//break;
			return FALSE;
		}
?>
<table class="tbl_converter" cellspacing="4" cellpadding="4" border="0" align="center" width="600">
	<form name="form1" method="post" action="TOOLS_dbconverter.php">
<tr>
    <td colspan="2"><b><font size="+1">RIEPILOGO</font></b></td>
</tr>
<tr>
    <td>nome oldDB (contiene i numeri di cell vecchi)</td>
    <td>assiplansms</td>
</tr>
<tr>
    <td>nome new DB a cui aggiungeremo i clienti</td>
    <td>ksmsDB</td>
</tr>
<tr>
    <td>Seleziona tutti i numeri, contenuti nel vecchio DB, appartenenti a:</td>
    <td><?php echo $oldorganiz->GetMenu("id_cliente", "", FALSE); ?></td>
</tr>
<tr>
    <td>I numeri vanno abbinati a questa nuovo Cliente Assiplan:</td>
    <td><?php echo $neworganiz->GetMenu("neworg", "", FALSE); ?></td>
</tr>
<tr>
    <td>nome di questo file</td>
    <td>TOOLS_dbconverter.</td>
</tr>
<tr><td colspan="2">Selezioniamo ora il gruppo, la classe e la categoria da abbinare ai numeri.</td></tr>
<tr class="row_even"> 
            <td colspan="2" nowrap> 
			<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" alt="Enter" align="middle" onClick="document.form1.submit();">
               <a href="TOOLS_dbconverter.php?action=Abort">
              <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
				  </a>
			</div>
            </td>
         </tr>
	<input type="hidden" name="action" value="selectzone">
      </form>
</table>
<?PHP
 } // end importdata function


function selecta($db,$id_cliente,$neworg) {
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
	   	   if (!$koldorganiz = $db->Execute("SELECT Login_Rappresentante,IDRappresentante FROM rappresentanti WHERE IDRappresentante='$id_cliente'")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		break;
			   }
		$oldbcompany = $koldorganiz->fields["Login_Rappresentante"];

	if (!$kneworganiz = $db->Execute("SELECT company,id FROM organization WHERE id='$neworg'")) {
      		echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      		break;
		       }
		$newdbcompany = $kneworganiz->fields["company"];
		$idORG = $kneworganiz->fields["id"];
	$selectcat = $db->Execute("SELECT descrip,id FROM category ORDER BY descrip");
	$selectcla = $db->Execute("SELECT descript,id FROM classf ORDER BY descript");
	$selectgrp = $db->Execute("SELECT descrip,id FROM groups WHERE id_organization='$idORG'");
			echo "<table class='tbl_converter'><tr>";
			echo "<td><b>OLD</b>_DB : vecchi dati, cliente assiplan = <b> ".$oldbcompany." </b>&nbsp;---&nbsp;</td>";
			echo "<td><b>NEW</b>_DB : nuovi dati,cliente assiplan = <b> ".$newdbcompany." </b>&nbsp;</td></tr>";
			echo "</table><br>";
	echo "<br><hr width='100%' color='#FFFFFF'><br><p class='news'>";
	echo "TUTTI I NUMERI ESTRATTI DA <b>".$oldbcompany."</b>, ANDRANNO INSERITI IN <b>".$newdbcompany."</b><br>";
	echo "QUI SOTTO SCELGO LE ZONE A CUI ABBINARE OGNI NUMERO (uguale per tutti i numeri)<br>";
	echo "</p><br>";
?>
	<table class="tbl_converter" cellspacing="4" cellpadding="4" border="0" align="center" width="600">
	<form name="form2" method="post" action="TOOLS_dbconverter.php">
<tr>
    <td colspan="2"><b><font size="+1">RIEPILOGO 2�</font></b></td>
</tr>
<tr>
    <td>Abbino tutti i numeri alla categoria:</td>
    <td><?php echo $selectcat->GetMenu2("newcat", "", FALSE); ?></td>
</tr>
<tr>
    <td>Abbino tutti i numeri alla classe:</td>
    <td><?php echo $selectcla->GetMenu2("newcla", "", FALSE); ?></td>
</tr>
<tr>
    <td>Abbino tutti i numeri al gruppo:</td>
    <td><?php echo $selectgrp->GetMenu2("newgrp", "", FALSE); ?></td>
</tr>
<tr><td colspan="2">
<p class="adm_menu2">Fai attenzione a selezionare l'esatto sottogruppo in base al gruppo che hai scelto qui sopra!</p>
</td></tr>
<tr>
    <td>Abbino tutti i numeri al Sottogruppo:</td>
    <td><?php 
	$selectsubgrp = $db->Execute("SELECT descript,id,groupdescr FROM subgroup WHERE id_organization='$idORG' ORDER BY groupdescr,descript");
	echo "<select name='selectgroup'>";
			$i = 1;
      		while (!$selectsubgrp->EOF) {
			$ksbdesct = $selectsubgrp->fields["descript"];
			$ksbdegrp = $selectsubgrp->fields["groupdescr"];
			$ksbsubid = $selectsubgrp->fields["id"];
			echo "<option value='".$ksbsubid."'> ".$ksbdesct."  - (".$ksbdegrp.")";
			$i++;
         	$selectsubgrp->MoveNext();
      			}
	echo "</select>";
	?></td>
</tr>
<tr>
    <td>nome di questo file</td>
    <td>TOOLS_dbconverter.</td>
</tr>
<tr class="row_even"> 
            <td colspan="2" nowrap> 
			<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" border="0" alt="Enter" align="middle" onClick="document.form2.submit();">
               <a href="TOOLS_dbconverter.php?action=Abort">
               <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" alt="Abort" border="0" align="middle">
				  </a>
			</div>
            </td>
         </tr>
	<input type="hidden" name="neworg" value="<?PHP echo $neworg; ?>">
	<input type="hidden" name="id_cliente" value="<?PHP echo $id_cliente; ?>">
	<input type="hidden" name="action" value="inserintodb">
      </form>
</table>
<?PHP
 } // end function selecta
function db_updated($db) {
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
$date_now = date("Ymd-is");
$arr = "<img src='".$imgs_admin_dir."rtarrow.gif' alt='-&gt;' width='22' height='18' border='0' align='middle'>";
	echo "<br><hr><br>";
	echo "<p class='tbl_notes'>	IL DATABASE E' STATO AGGIORNATO !!!	</p>";
	echo "<p class='evdrow'>DA FARE:</p>";
	echo "<p class='descrtxNa'>";
	echo $arr." &nbsp;Ora puoi cancellare le tabelle del vecchio DB, dal nuovo <b>ksmsDB</b>:<br>";
	echo "<p class='rawrow'>";
	echo "mysql -u paol -p<br>";
	echo "&gt;&nbsp; use ksmsDB;<br>";
	echo "DROP TABLE IF EXISTS gestori;<br>";
	echo "DROP TABLE IF EXISTS pubblicita;<br>";
	echo "DROP TABLE IF EXISTS rappresentanti;<br>";
	echo "DROP TABLE IF EXISTS sms;<br>";
	echo "DROP TABLE IF EXISTS testipub;<br>";
	echo "DROP TABLE IF EXISTS utenti;<br>";
	echo "exit;<br>";
	echo "</p><br>";
	echo "<p class='tbl_notes'>ORA PUOI CHIUDERE !!!<br>FAI ATTENZIONE A NON RIPETERE L'OPERAZIONE ALTRIMENTI INSERIRAI SOLO NUMERI DOPPIONI!!!</p>";
} // end main function
?>

<?php
if ($privs == '69') {
	//$action = "null";
   switch ($action) {
	case "Abort":
         	echo "<table class='tbl_converter'><tr><td>Operazione annullata.</td></tr></table><br>";
			main_page($db);
         	break;
	case "secondstep":
         	importdata($db);
		 	break;
	case "advisor":
         	pretables($db);
		 	break;
	case "selectzone":
         	echo "<table class='tbl_converter'><tr><td>Selection from OldDB...</td>";
			echo "<td>ID DEL CLIENTE SELEZIONATO =<b> ".$id_cliente."</b>&nbsp;&nbsp;</td>";
			echo "<td>ID NUOVO DEL CLIENTE SELEZIONATO =<b> ".$neworg."</b>&nbsp;&nbsp;</td></tr>";
			echo "</table><br>";
         	selecta($db,$id_cliente,$neworg);
		 	break;
	case "inserintodb2":
		// TESTING....
         	echo "<p class='td_notice'>&nbsp;&nbsp;CATEGORIA SELEZIONATA = ".$newcat."</p>";
			echo "<p class='td_notice'>&nbsp;&nbsp;CLASSE SELEZIONATA = ".$newcla."</p>";
			echo "<p class='td_notice'>&nbsp;&nbsp;GRUPPO SELEZIONATO = ".$newgrp."</p>";
			echo "<table class='tbl_converter'><tr><td>Selection from ...</td></tr>";
			echo "<tr><td>ID DEL CLIENTE SELEZIONATO =<b> ".$id_cliente."</b>&nbsp;&nbsp;</td></tr>";
			echo "</table><br>";
		 	break;
// INSERIMENTO FINALE SU DB CON FILTRO ADDSLASHES
	case "inserintodb":
		    echo "<p class='td_notice'>&nbsp;Hai selezionato : Categoria = ".$newcat." -";
			echo "&nbsp;Classe = ".$newcla." -";
			echo "&nbsp;Gruppo = ".$newgrp."</p>";
         	echo "<table class='tbl_converter'><tr><td>Selection from ...</td></tr>";
			echo "<tr><td>ID DEL CLIENTE SELEZIONATO =<b> ".$id_cliente."</b>&nbsp;&nbsp;</td></tr>";
			echo "</table><br>";
		if (!$utentiselect = $db->Execute("SELECT * FROM utenti WHERE Rappresentanti_IDRappresentante=$id_cliente")) {
      	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
		break;
		}
		if (!$neworgselect = $db->Execute("SELECT * FROM organization WHERE id=$neworg")) {
      	echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
		break;
		}
		$organization = $neworgselect->fields["company"];
		$id_organization = $neworgselect->fields["id"];
		// if ($id_cliente == "20") { $organization = "La Corte Degli Aranci S.r.l."; }
		// if ($id_cliente == "31") { $organization = "Alex Il Cubanissimo"; }
		// if ($id_cliente == "1") { $organization = "Computel S.r.l."; }
		if ($id_cliente == "") { $organization = "-"; }
	$i = 1;
    while (!$utentiselect->EOF) {
		$import_date = $utentiselect->fields["Data_Utente"];
		$internal_code = $utentiselect->fields["IDUtente"];
		$username = $utentiselect->fields["Login_Utente"];
		$password = $utentiselect->fields["Passw_Utente"];
		$nome = $utentiselect->fields["Nome_Utente"];
		$cognome = $utentiselect->fields["Cognome_Utente"];
		$sex = $utentiselect->fields["Sesso_Utente"];
		$age_range = $utentiselect->fields["FasciaEta_Utente"];
		$province = $utentiselect->fields["Provincia_Utente"];
		$city = $utentiselect->fields["Citta_Utente"];
		$address = $utentiselect->fields["Via_Utente"];
		$preffisso = $utentiselect->fields["PrefFisso_Utente"];
		$numfisso = $utentiselect->fields["NumFisso_Utente"];
		$mobile_pref = $utentiselect->fields["PrefCell_Utente"];
		$mobile_phone = $utentiselect->fields["NumCell_Utente"];
		$email = $utentiselect->fields["Email_Utente"];
		$web = $utentiselect->fields["Url_Utente"];
	//	$idcategory = $utentiselect->fields["Categoria_Utente"];
	//	$idclass = $utentiselect->fields["Classificazione_Utente"];
	//	$idgroups = $utentiselect->fields["Gruppo_Utente"];
		$note = $utentiselect->fields["Note_Utente"];
		$idcategory = $newcat;
		$idclass = $newcla;
		$idgroups = $newgrp;
		$idsubgroups = $selectgroup;
		
		// $IDRappresentante = $utentiselect->fields["Rappresentanti_IDRappresentante"];
		// $IP = $utentiselect->fields["IP_Utente"];
		// $Priorita = $utentiselect->fields["Priorita_Utente"];
		// $Pubblica = $utentiselect->fields["Pubblica_Utente"];
		// $Attiva = $utentiselect->fields["Attiva_Utente"];
		// $Codice = $utentiselect->fields["Codice_Utente"];
		if ($idcategory == "") { $idcategory = 1; }
		if ($idclass == "") { $idclass = 1; }
		if ($idgroups == "") { $idgroups = 1; }
		if ($idsubgroups == "") { $idsubgroups = 1; }
		$name = $nome." ".$cognome;
		if ($name == " ") { $name = ""; }
		$country = "Italy";
		$p_code = "";
		$phone = $preffisso." ".$numfisso;
		if ($phone == " ") { $phone = ""; }
		$fax = "";
		$country_code = "39";
		$user_activated = "Y";
		$comments = "automatic_added";
		  // OnlyForTest ==> id user is in autoincrement method in a mySQL table!
		  //  $id_user = rand (2000,125999);
  // FILTRO ADDSLASHES PER TUTTI I CAMPI !
  			$import_date = addslashes($import_date);
			$internal_code = addslashes($internal_code);
			$username = addslashes($username);
			$password = addslashes($password);
//			$id_organization = addslashes($id_organization);
			$organization = addslashes($organization);
			$name = addslashes($name);
			$address = addslashes($address);
			$city = addslashes($city);
			$province = addslashes($province);
			$country = addslashes($country);
			$p_code = addslashes($p_code);
			$phone = addslashes($phone);
			$fax = addslashes($fax);
			$email = addslashes($email);
			$web = addslashes($web);
			$sex = addslashes($sex);
			$age_range = addslashes($age_range);
//			$country_code = addslashes($country_code);
			$mobile_pref = addslashes($mobile_pref);
			$mobile_phone = addslashes($mobile_phone);
//			$idcategory = addslashes($idcategory);
//			$idclass = addslashes($idclass);
//			$idgroups = addslashes($idgroups);
//			$user_activated = addslashes($user_activated);
			$note = addslashes($note);
//			$comments = addslashes($comments);

 // FILTRARE I NUMERI DOPPI !!!!!!!!!!!!
				$query = "INSERT INTO userz (insert_date, old_importdate, internal_code, username, password, id_organization, organization, name, address, city, province, country, p_code, phone, fax, email, web, sex, age_range, country_code, mobile_pref, mobile_phone, idcateg, idclasse, idgroup, idsubgroup, user_activated, note, comments)"
				. " VALUES (NOW(), '$import_date', '$internal_code', '$username', '$password', '$id_organization', '$organization', '$name', '$address', '$city', '$province', '$country', '$p_code', '$phone', '$fax', '$email', '$web', '$sex', '$age_range', '$country_code', '$mobile_pref', '$mobile_phone', '$idcategory', '$idclass', '$idgroups', '$idsubgroups', '$user_activated', '$note', '$comments')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	}
		$i++;
		$utentiselect->MoveNext();
	}  // end while ...
		db_updated($db);
		break;
	case "addtables":
	$query = "DROP TABLE IF EXISTS gestori";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
	$query = "CREATE TABLE gestori (
  IDGestore smallint(5) unsigned NOT NULL auto_increment,
  Login_Gestore text,
  Passw_Gestore text,
  DataRegistrazione_Gestore date NOT NULL default '0000-00-00',
  Pseudonimo_Gestore text,
  Nome_Gestore text,
  Cognome_Gestore text,
  Tel1_Gestore text,
  Tel2_Gestore text,
  Indirizzo_Gestore text,
  Citta_Gestore text,
  Email_Gestore text,
  Url_Gestore text,
  Locale1_Gestore text,
  Locale2_Gestore text,
  Locale3_Gestore text,
  Locale4_Gestore text,
  Locale5_Gestore text,
  DataInizioContratto_Gestore date NOT NULL default '0000-00-00',
  DataFineContratto_Gestore date NOT NULL default '0000-00-00',
  CodiceContratto_Gestore text,
  CreditoSms_Gestore int(6) default '0',
  SmsUtilizzati_Gestore int(6) default '0',
  Attiva_Gestore enum('n','s') NOT NULL default 'n',
  Hapagato_Gestore enum('n','s') NOT NULL default 'n',
  MaxTestoChar_Gestore smallint(6) default NULL,
  MaxPubblicitaChar_Gestore smallint(6) default NULL,
  MaxFirmaChar_Gestore smallint(6) default NULL,
  SenderSms_Gestore text,
  GatewaySms_Gestore text,
  AltreInfo_Gestore text,
  Note_Gestore text,
  PRIMARY KEY  (IDGestore)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "DROP TABLE IF EXISTS pubblicita";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "CREATE TABLE pubblicita (
  IDPub int(11) NOT NULL auto_increment,
  DataPub date NOT NULL default '0000-00-00',
  Gestori_IDGestore int(11) NOT NULL default '0',
  TestiPub_IDTesto int(11) NOT NULL default '0',
  NotePub text,
  PRIMARY KEY  (IDPub)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }

$query = "DROP TABLE IF EXISTS rappresentanti";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "CREATE TABLE rappresentanti (
  IDRappresentante smallint(5) unsigned NOT NULL auto_increment,
  Gestori_IDGestore int(11) NOT NULL default '0',
  Login_Rappresentante text,
  Passw_Rappresentante text,
  DataRegistrazione_Rappresentante date NOT NULL default '0000-00-00',
  Nome_Rappresentante text,
  Cognome_Rappresentante text,
  Tel1_Rappresentante text,
  Tel2_Rappresentante text,
  Indirizzo_Rappresentante text,
  Citta_Rappresentante text,
  Email_Rappresentante text,
  Url_Rappresentante text,
  Firma_Rappresentante text,
  SmsCredits decimal(12,3) NOT NULL default '0.000',
  CreditoSms_Rappresentante int(6) default '0',
  SmsUtilizzati_Rappresentante int(6) default '0',
  Attiva_Rappresentante enum('n','s') NOT NULL default 'n',
  Note_Rappresentante text,
  NoteAdmin_Rappresentante text,
  PRIMARY KEY  (IDRappresentante)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }

$query = "DROP TABLE IF EXISTS sms";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "CREATE TABLE sms (
  IDSms int(11) NOT NULL auto_increment,
  DataSms date NOT NULL default '0000-00-00',
  Rappresentanti_IDRappresentante int(11) NOT NULL default '0',
  IDAlphaSms text,
  TitoloSms text,
  TestoSms text,
  NoteSms text,
  PRIMARY KEY  (IDSms)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }

$query = "DROP TABLE IF EXISTS testipub";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "CREATE TABLE testipub (
  IDTesto int(11) NOT NULL auto_increment,
  DataPub date NOT NULL default '0000-00-00',
  TitoloPub text,
  TestoPub text,
  NotePub text,
  PRIMARY KEY  (IDTesto)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }

$query = "DROP TABLE IF EXISTS utenti";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
$query = "CREATE TABLE utenti (
  IDUtente smallint(5) unsigned NOT NULL auto_increment,
  Rappresentanti_IDRappresentante int(11) NOT NULL default '0',
  Login_Utente text,
  Passw_Utente text,
  Data_Utente date NOT NULL default '0000-00-00',
  Nome_Utente text,
  Cognome_Utente text,
  Sesso_Utente enum('m','f') default NULL,
  FasciaEta_Utente text,
  Provincia_Utente text,
  Citta_Utente text,
  Via_Utente text,
  PrefFisso_Utente text,
  NumFisso_Utente text,
  PrefCell_Utente text,
  NumCell_Utente text,
  Email_Utente text,
  Url_Utente text,
  Categoria_Utente text,
  Priorita_Utente text,
  Classificazione_Utente text,
  Gruppo_Utente text,
  Note_Utente text,
  IP_Utente text,
  Pubblica_Utente enum('n','s') NOT NULL default 'n',
  Attiva_Utente enum('n','s') NOT NULL default 'n',
  Codice_Utente varchar(5) default NULL,
  PRIMARY KEY  (IDUtente)
) TYPE=MyISAM";
	if (!$db->Execute($query)) { 
	echo "&nbsp;-&nbsp;&nbsp;<b>DB ERROR: " . $db->ErrorMsg() . "</b>";
     break;
	  }
	echo "<p class='row_head_title'>................OK.......FATTO!!!!!!!!!!!!!</p>";
	echo "<p class='descrtxNa'>Ora puoi importare il vecchio DB, aggiornando il nuovo dal file locale, con la seguente stringa (da fare su shell, in Db come utente e non come root!):</p>";
	echo "<p class='small'>&nbsp;&nbsp;&nbsp;mysql -u user -p ksmsDB < /home/viabazar/_AssiplanSMS-.....</p>";
	main_page($db);
     break;
      default:
         main_page($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
