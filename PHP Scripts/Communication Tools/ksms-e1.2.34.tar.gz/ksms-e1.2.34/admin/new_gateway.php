<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/

// gestione gateway ::: solo per ADMIN 
$title = "Gestione Gateway Provider";
require("admcommon.inc.php");

?>

<?php
function display_form($db) {
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
  ?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
       <tr class="row_head_title"> 
         <td colspan="3"><b>New Gateway Used</b></td>
         <td align="right">SMS GATEWAY</td>
       </tr>

   <form action="new_gateway.php" method="post" name="form1">
   		 <tr class="row_head">
      <td colspan="4"><b>Dati Fornitore Gateway</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Rag. Sociale:</td>
      <td> 
        <input type="text" name="name_gwprovider" size="50">
 	</td>
	<td>&nbsp;</td>
   <td align="right" colspan="2">
	  <table cellspacing="2" cellpadding="2" border="0">
		<tr>
    		<td><font size="-2">Sigla Fornitore Gateway:</font></td>
    		<td><input type="text" name="nick_gwprovider" size="10"></td>
    		<td><div align="center"><font size="-2">Solo Uso Interno, non importante!</font></div></td>
		</tr>
	</table>
  </td>

    </tr>
    <tr class="row_even"> 
      <td align="right">Sede principale:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="50">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede secondaria:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="50">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Citt�:</td>
      <td><input type="text" name="city" size="30"></td>
      <td align="right">Provincia:</td>
      <td>
	  <?php require("ItProv.inc.php"); ?>
	  </td>
    </tr>
	 <tr class="row_even">
      	<td align="right">CAP/ZIP:</td>
      	<td><input type="text" name="p_code" size="6">
		&nbsp;Country:&nbsp;<input type="text" name="country" size="15" value="Italy"></td>	
    	<td align="right">Part.IVA:</td>
      	<td><input type="text" name="PIVAgatew" size="20"></td>		
    </tr>	
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Responsabile Commerciale:</td>
      <td> 
        <input type="text" name="gway_contact" size="30">
      </td>
	  <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="main_email" size="30">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="main_phone" size="20">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="main_fax" size="20">
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Indirizzo Internet:</td>
      <td colspan="3"> 
        <input type="text" name="main_www" size="50">
      </td>
    </tr>
	<tr class="row_head"> 
      <td colspan="4"><b>Technical Contact Information</b></td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Resp. Tecnico:</td>
      <td> 
        <input type="text" name="tech_gway_contact" size="30">
      </td>
	  <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="tech_email" size="30">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="tech_phone" size="20">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="tech_fax" size="20">
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Indirizzo Internet:</td>
      <td colspan="3"> 
        <input type="text" name="tech_www" size="50">
      </td>
	<tr class="row_head"> 
      <td colspan="4"><b>Technical Data</b></td>
    </tr>
<?PHP
   // con KANNEL non serve piu' !!!! ############################
// include ("techdata01.inc");
?>
		<tr class="row_even">
			<td>&nbsp;</td>
      		<td colspan="2" bgcolor="#E8FDFF"><div align="center"><font color="#000099"><b>EMI/UCP connection</b></font></div></td>
			<td>&nbsp;</td>
		</tr>	
		<tr class="row_even">
	  <td align="right">Incoming Path:</td>
      <td> 
        <input type="text" name="UCP_path" size="30" value="/usr/local/kannel/gateway-1.xx"> <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#ffcc00">no trailing slash</font>
      </td>
      <td align="right">Interfaccia EMI/UCP</td>
      <td> 
        <select name="UCP_interface">
		<option value="">--seleziona
		<option value="kannel">Kannel
		</select>
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">EMI Username:</td>
      <td> 
        <input type="text" name="E_user" size="20" value="">
      </td>
      <td align="right">EMI password:</td>
      <td> 
        <input type="text" name="E_pwd" size="20" value="">
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Barebox IP:</td>
      <td> 
        <input type="text" name="B_IP" size="20" value="127.0.0.1">
      </td>
      <td align="right">send SMS port:</td>
      <td> 
        <input type="text" name="KPort" size="20" value="13013"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#ffcc00"> (Kannel's specific)</font>
      </td>
    </tr>
		<tr class="row_even"> 
      <td colspan="4"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#d5f3ff">Specificare l'interfaccia utilizzata per la connessione EMI/UCP con il gateway provider esterno.Con questo sistema si diventa gateway che si collega direttamente ad un terminale (tipo cellulare) oppure ad un altro gateway esterno.</font></td>
      </td>
    </tr>
	<tr class="row_head"> 
      		<td colspan="4"><b>Commenti e Note</b></td>
	</tr>
	<tr class="row_even">
            <td nowrap align="right">Commenti da Admin:</td>
            <td colspan="3">
               <textarea name="master_comments" cols="60" rows="2" wrap="VIRTUAL"></textarea>
            </td>
	 <tr class="row_even">
      <td align="right">Gate Quest:</td>
      <td colspan="3">
        <input type="text" name="gate_quest" size="80">
      </td>
         </tr>
		 <tr class="row_foot">
         <td colspan="4">
            <div align="center">
			<img src="<?PHP echo $imgs_admin_dir ?>invia_enter.gif" align="middle" border="0" alt="Enter"
               onClick="document.form1.submit();">&nbsp;&nbsp;
            <a href="new_gateway.php?action=cancel">
               <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" align="middle" border="0" alt="Annulla-Cancel"></a>
			 </div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">  
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#000080"><b>(**) NOTA BENE:</b> Gate File &egrave; il file di testo utilizzato da certi gateway per l'invio di sms.
<br>
Questo file contiene al suo interno i dati tipo lo user di chi invia, i nr. di cellulare,etc.<br> Generalmente viene utilizzato in casi dove si richiede una connessione al gateway di tipo <i>http</i>.
<br>
Ora questo sistema &egrave; stato sostituito da una connessione diretta per la trasmissione dei dati attraverso l'interfaccia <b>EMI/UCP (kannel)</b>.
<br>
<?PHP echo //"In ogni caso il file in questione si trova sotto la directory:<b> ".$dirgw1." </b>.<br>"; ?>Si fa presente che in caso di connessione EMI/UCP attraverso un qualsiasi programma specifico (tipo kannel) il file selezionato nel capo &quot;Gate File&quot; non ha importanza: pertanto qui selezioneremo un file a caso.</font>
<br><br><br>
   <script language="JavaScript">
      document.form1.name.focus();
   </script> <?php
} ?>

<?php
if ($privs == '69') {
// Modifiche per KANNEL (campi non piu' necessari)
$original_gwfile_name = "-";
$connect_gway_host1 = "";
$connect_gway_port1 = "";
$fsock1 = "";
$connect_gway_lang = "";
$connect_gway_test = "N";
// end mods
   $action = strtolower($action);
   switch ($action) {
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The category number $id was successfully added!.</td></tr></table>";
		  display_form($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  display_form($db);
         break;
      case "create":
		 if ($name_gwprovider == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid name for that filed! (Rag.Sociale)</td></tr></table>";
            display_form($db);
            break;
         }
		 if ($original_gwfile_name == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a filename in Gate File field!</td></tr></table>";
            display_form($db);
            break;
         }
		 	// dati kannel ===> UCPpath  UCPinterface  bareboxIP  KanlSmsPort
         $id = $db->GenID("gwprovider_seq");
         $query = "INSERT INTO gwprovider (intid, name_gwprovider, nick_gwprovider, address1, address2, city, province, country, p_code, PIVAgatew, gway_contact, main_phone, main_fax, main_email, main_www, tech_gway_contact, tech_phone, tech_fax, tech_email, tech_www, original_gwfile_name, connect_gway_host1, connect_gway_port1, connect_gway_host2, connect_gway_port2, connect_gway_lang, connect_gway_test, fsock_link, UCPpath, UCPinterface, EMIuser, EMIpass, bareboxIP, KanlSmsPort, gate_quest, comments)"
                . " VALUES ('$id', '$name_gwprovider', '$nick_gwprovider', '$address1', '$address2', '$city', '$province', '$country', '$p_code', '$PIVAgatew', '$gway_contact', '$main_phone', '$main_fax', '$main_email', '$main_www', '$tech_gway_contact', '$tech_phone', '$tech_fax', '$tech_email', '$tech_www', '$original_gwfile_name', '$connect_gway_host1', '$connect_gway_port1', '$connect_gway_host2', '$connect_gway_port2', '$connect_gway_lang', '$connect_gway_test', '$fsock1', '$UCP_path', '$UCP_interface', '$E_user', '$E_pwd', '$B_IP', '$KPort', '$gate_quest', '$comments')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ed_gateway.php?action=gateinserted&idgate=<?php echo $id; ?>";
         </script> <?php
         break;
      default:
         display_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
