<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.
*/

// print_order.php
require("admcommon_print.inc.php");
$privs = $_SESSION["privs"];
$projname = $_SESSION["project_name"];
if ($privs == '69'AND $projname == 'KeySMS') {
?>

<?php
   if (!$pork = $db->Execute("SELECT * FROM orders WHERE ordID='$orderid'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($pork->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO IDnumber $orderid not found.</td></tr></table>";
   die();
   }

   $orderdata = $pork->fields["date"];
   $ordernumb = $pork->fields["ord_number"];
   //$orderk_id = $pork->fields["ordID"];
   $vendor_id = $pork->fields["id_vendor"];
   $cliorg_id = $pork->fields["id_organization"];
   $kgatew_id = $pork->fields["id_gwprovider"];
   $creat_usr = $pork->fields["created_by"];
$kp_org = $db->Execute("SELECT * FROM organization WHERE id='$cliorg_id'");
$kp_vendor = $db->Execute("SELECT * FROM vendor WHERE id='$vendor_id'");
$kp_gate = $db->Execute("SELECT name_gwprovider, nick_gwprovider FROM gwprovider WHERE id='$kgatew_id'");
$line_items = $db->Execute("SELECT * FROM ord_line_items WHERE orderID_ln='$orderid' ORDER BY id_row");
$kprov = $kp_org->fields["province"];
//   echo "Generating print job. Please be patient...";
//   flush();

echo "<html>";
echo "<head>";
echo "	<title>Print KSMS Master Order for ".$kp_org->fields["company"]."</title>";
echo "   	<link rel='stylesheet' type='text/css' href='admstyle.css'>";
echo "</head>";
//echo "<body class='admbody'>";
echo "<body bgcolor='#ffffff' text='#000000' link='#000000' vlink='#000000'>";
require("print_head_order.inc"); 
?>
<hr>
<table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <tr> 
      <td><b>Date of Order: </b><?php echo $orderdata; ?></td>
      <td align="right"><b>Order No. </b><?php echo $orderid."/<b>".$ordernumb."</b>"; ?></td>
   </tr>
</table>
<hr>

<table class="default" width="98%" border="0" cellspacing="0" cellpadding="1">
   <tr> 
      <td><b>Venditore:</b></td>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
      <td><b>Spettabile:</b></td>
   </tr>
   <tr>
      <td nowrap>
         <?php echo $kp_vendor->fields["name"]; ?><br>
         <?php echo $kp_vendor->fields["address1"]; ?><br>
         <?php echo $kp_vendor->fields["city"] . ", " . $kp_vendor->fields["province"] . ", " . $kp_vendor->fields["p_code"]; ?><br>
         <?php echo "Attn: " . $kp_vendor->fields["attn"]; ?>
         </td>
      <td>&nbsp;</td>
	  <td><img src="<?PHP echo $imgs_admin_dir ?>whiteblank.png" alt="w" width="200" height="5" border="0"></td>
	  <td>&nbsp;</td>
      <td nowrap>
         <?php echo $kp_org->fields["company"]; ?><br>
         <?php echo $kp_org->fields["address1"]; ?><br>
         <?php
		 if ($kprov == "-->Seleziona la prov.") { $kapprov = ""; }
		 if ($kprov == "") { $kapprov = ""; }
		// if ($kprov LIKE "Sele") { $kapprov = ""; }
		 if ($kapprov != "") {
		 echo $kp_org->fields["zip_code"] ."&nbsp;". $kp_org->fields["city"] ."(". $kprov .")";
			} else {
		 echo "<hr>";
			}
?><br>
         <?php echo "Attn: &nbsp;" . $kp_org->fields["contact"]; ?>
      </td>
   </tr>
</table>
<br>
<table class="default" width="100%" border="1"><tr><td>
<table class="small" width="100%" border="0" cellspacing="1" cellpadding="1">
   <tr> 
      <td colspan="7" align="center">WE ARE PLEASURE TO RECEIVE ORDER FOR THE MATERIALS SPECIFIED BELOW:</td>
   </tr>
   <tr><td colspan="9"><hr width="100%"></td></tr>
   <tr> 
      <td align="center"><b>#</b></td>
	  <td align="center"><b>Code</b></td>
      <td align="center"><b>Qty</b></td>
      <td align="center"><b>Un.</b></td>
      <td><b>Description</b></td>
      <td align="right"><b>Unit Price</b></td>
      <td align="right"><b>Amount</b></td>
	  <td align="right"><b>%IVA</b></td>
	  <td align="right"><b>Ivato</b></td>
   </tr> 
   <tr><td colspan="9"><hr width="100%"></td></tr>
   <?php
   $i = 1;
   $po_total = 0;
   while (!$line_items->EOF) {
      echo "<tr>";
      echo "<td align=\"center\">$i</td>";
      echo "<td align=\"center\">" . $line_items->fields["product_code"] . "</td>";
	  echo "<td align=\"center\"><b>" . $line_items->fields["prod_qty"] . "</b></td>";
	  echo "<td align=\"center\">" . $line_items->fields["prod_unit"] . "</td>";
      echo "<td>" . $line_items->fields["prod_descript1"] . "</td>";
      if ($line_items->fields["prod_qty"] != 0) {
         echo "<td align=\"right\">" . $line_items->fields["prpack_sale_price"] . "</td>";
         echo "<td align=\"right\">" . $line_items->fields["prd_total_row"] . "</td>";
      } else {
         echo "<td>&nbsp;</td>";
         echo "<td>&nbsp;</td>";
      }
	  echo "<td align=\"right\">" . $line_items->fields["prd_tax"] . "</td>";
	  $prtot_riga = $line_items->fields["prd_total_row"];
	  $rowtax = $line_items->fields["prd_tax"];
	  $row_ivat = ($prtot_riga+(($prtot_riga * $rowtax)/100));
	  if ($line_items->fields["prd_total_row"] != 0) {
         //echo "<td align=\"right\">" . $row_ivat . "</td>";
		 echo "<td align=\"right\">";"</td>";
		 printf("<b>%s%01.2f</b>", $cfg["curr"], $row_ivat);
		 echo "</td>";
      } else {
         echo "<td>&nbsp;</td>";
      }
      echo "</tr>";
	  echo "<tr><td colspan='9'>&nbsp;</td></tr>";
      $po_total += $line_items->fields["prd_total_row"];
	  $po_total_ivt += $row_ivat;
      $i++;
      $line_items->MoveNext();
   } ?>
   <tr>
   <tr><td colspan='9'>&nbsp;</td></tr>
   <tr><td colspan='9'>&nbsp;</td></tr>
   <tr><td colspan="9"><hr width="100%"></td></tr>
      <td colspan="8" align="right"><b>TOTALE:</b></td>
      <td align="right"> <?php
         if ($po_total != 0) {
		 	//$ktot_it = number_format($po_total, 2, ',', '.'); // italian format numbers!!!
            printf("<b>%s%01.2f</b>", $cfg["curr"], $po_total);
         } else {
            echo "&nbsp;";
         } ?>
      </td>
   </tr>
   <tr> 
      <td colspan="8" align="right"><b>TOTALE IVATO:</b></td>
      <td align="right"><b><?php echo $po_total_ivt; ?></b></td>
</table>
</td></tr></table>
<table class="default" width="100%" border="0"><tr><td>&nbsp;</td></tr></table>
<table class="default" width="100%" border="1" cellspacing="1" cellpadding="1">
   <tr> 
      <td width="33%">Server Gw:</td>
      <td width="33%">Dept. Manager:</td>
      <td width="33%">Manager of Finance:</td>
   </tr>
   <tr>
      <td width="33%"><?php echo $kp_gate->fields["nick_gwprovider"]; ?></td>
      <td width="33%"><div align="center"><?php echo $creat_usr; ?></div></td>
      <td width="33%">&nbsp;</td>
   </tr>
</table>
<?PHP
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer_print.inc");
?>
