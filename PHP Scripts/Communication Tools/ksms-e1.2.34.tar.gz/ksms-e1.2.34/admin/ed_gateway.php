<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// gestione modifica gate ::: solo per Admin
$title = "Gestione Modifica Gateway Provider";
require("admcommon.inc.php"); 
?>

<?php
function edit_gate_form($db, $id) {
   global $gway, $ins_date;
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
   $imgs_admin_dir = $_SESSION["imgs_admin_dir"];
   $gway = $db->Execute("SELECT * FROM gwprovider WHERE id='$id'");
   $org = $db->Execute("SELECT id,province FROM gwprovider WHERE id='$id'");
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Number or Gateway Provider.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$gway = $db->Execute("SELECT * FROM gwprovider WHERE id='$id'")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($gway->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Gateway  not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
  ?>
  
<table class="default" align="center" border="0" cellspacing="0" cellpadding="0">
      <form name="form2" method="post" action="ed_gateway.php">
	  <tr class="row_head"> 
      <td colspan="4"><b>Dati Fornitore Gateway</b></td>
    </tr>
		 <tr class="row_even"> 
      <td align="right">Rag. Sociale:</td>
      <td> 
        <input type="text" name="name_gwprovider" size="50" value="<?php echo $gway->fields["name_gwprovider"]; ?>">
      </td>
	  <td align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sigla Fornitore Gateway:</td>
      <td> 
        <input type="text" name="nick_gwprovider" size="10" value="<?php echo $gway->fields["nick_gwprovider"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede principale:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="50" value="<?php echo $gway->fields["address1"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Sede secondaria:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="50" value="<?php echo $gway->fields["address2"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Citt�:</td>
      <td><input type="text" name="city" size="30" value="<?php echo $gway->fields["city"]; ?>"></td>
      <td align="right">Provincia:</td>
      <td>
	  <?php require("ItProvSelect.inc.php"); ?>
	  </td>
    </tr>
	 <tr class="row_even">
      	<td align="right">CAP/ZIP:</td>
      	<td><input type="text" name="p_code" size="6" value="<?php echo $gway->fields["p_code"]; ?>">
		&nbsp;Country:&nbsp;<input type="text" name="country" size="15" value="<?php echo $gway->fields["country"]; ?>"></td>	
    	<td align="right">Part.IVA:</td>
      	<td><input type="text" name="PIVAgatew" size="20" value="<?php echo $gway->fields["PIVAgatew"]; ?>"></td>		
    </tr>	
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Responsabile Commerciale:</td>
      <td> 
        <input type="text" name="gway_contact" size="30" value="<?php echo $gway->fields["gway_contact"]; ?>">
      </td>
	  <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="main_email" size="30" value="<?php echo $gway->fields["main_email"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="main_phone" size="20" value="<?php echo $gway->fields["main_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="main_fax" size="20" value="<?php echo $gway->fields["main_fax"]; ?>">
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Indirizzo Internet:</td>
      <td colspan="3"> 
        <input type="text" name="main_www" size="50" value="<?php echo $gway->fields["main_www"]; ?>">
      </td>
    </tr>
	<tr class="row_head"> 
      <td colspan="4"><b>Technical Contact Information</b></td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Resp. Tecnico:</td>
      <td> 
        <input type="text" name="tech_gway_contact" size="30" value="<?php echo $gway->fields["tech_gway_contact"]; ?>">
      </td>
	  <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="tech_email" size="30" value="<?php echo $gway->fields["tech_email"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Telefono:</td>
      <td> 
        <input type="text" name="tech_phone" size="20" value="<?php echo $gway->fields["tech_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="tech_fax" size="20" value="<?php echo $gway->fields["tech_fax"]; ?>">
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">Indirizzo Internet:</td>
      <td colspan="3"> 
        <input type="text" name="tech_www" size="50" value="<?php echo $gway->fields["tech_www"]; ?>">
      </td>
	  <tr class="row_head"> 
      <td colspan="4"><b>Technical Data</b></td>
    </tr>
<?PHP 
	// con KANNEL questa parte non serve piu' !!!
 #  include ("techdata02.inc"); 
?>
<tr class="row_even">
			<td>&nbsp;</td>
      		<td colspan="2" bgcolor="#E8FDFF"><div align="center"><font color="#000099"><b>EMI/UCP connection</b></font></div></td>
			<td>&nbsp;</td>
		</tr>	
		<tr class="row_even">
	  <td align="right">Incoming Path:</td>
      <td>
        <input type="text" name="UCP_path" size="30" value="<?php echo $gway->fields["UCPpath"]; ?>"> <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#ffcc00">no trailing slash</font>
      </td>
      <td align="right">Interfaccia EMI/UCP</td>
      <td>
	  <?PHP $EMIorg = $gway->fields["UCPinterface"]; 
	  $EMIsel = "kannel";
	  ?>
        <select name="UCP_interface">
		<option value=""<?PHP if($gway->fields["UCPinterface"]==""){echo(" SELECTED");};?>>--Seleziona</option>
		<option value="demo"<?PHP if($gway->fields["UCPinterface"]=="demo"){echo(" SELECTED");};?>>Demo</option>
	<option value="<?php echo $EMIorg; ?>"<?PHP if($gway->fields["UCPinterface"]=="kannel"){echo(" SELECTED");};?>>kannel</option>
		</select>&nbsp;&raquo;&nbsp;<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1">selezionato:</font>&nbsp;<b><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="3" color="#80FFFF"><?php echo $EMIorg; ?></font></b>
      </td>
    </tr>
	<tr class="row_even"> 
      <td align="right">EMI Username:</td>
      <td> 
        <input type="text" name="E_user" size="20" value="<?php echo $gway->fields["EMIuser"]; ?>">
      </td>
      <td align="right">EMI password:</td>
      <td> 
        <input type="text" name="E_pwd" size="20" value="<?php echo $gway->fields["EMIpass"]; ?>">
      </td>
    </tr>
	<tr class="row_even">
      <td align="right">Barebox IP:</td>
      <td> 
        <input type="text" name="B_IP" size="20" value="<?php echo $gway->fields["bareboxIP"]; ?>">
      </td>
      <td align="right">send SMS port:</td>
      <td> 
        <input type="text" name="KPort" size="20" value="<?php echo $gway->fields["KanlSmsPort"]; ?>"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#ffcc00"> (Kannel's specific)</font>
      </td>
    </tr>
		<tr class="row_even"> 
      <td colspan="4"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#d5f3ff">Specificare l'interfaccia utilizzata per la connessione EMI/UCP con il gateway provider esterno.Con questo sistema si diventa gateway che si collega direttamente ad un terminale (tipo cellulare) oppure ad un altro gateway esterno.</font></td>
      </td>
    </tr>
	<tr class="row_head"> 
      		<td colspan="4"><b>Commenti e Note</b></td>
	</tr>
	<tr class="row_even">
            <td nowrap align="right">Commenti da Admin:</td>
            <td colspan="3">
               <textarea name="master_comments" cols="60" rows="2" wrap="VIRTUAL"><?php echo $gway->fields["comments"]; ?></textarea>
            </td>
	 <tr class="row_even">
      <td align="right">Gate Quest:</td>
      <td colspan="3">
        <input type="text" name="gate_quest" size="80"<?php echo $gway->fields["gate_quest"]; ?>">
      </td>
         </tr>
		 <tr class="row_foot"> 
            <td colspan="4" nowrap>
					<div align="center">
               <img src="<?PHP echo $imgs_admin_dir ?>Mod_GatewayProvider.gif" align="middle" border="0" alt="Modifica"
                  onClick="document.form2.submit();">
               <a href="ed_gateway.php?action=Abort">
			   	  <img src="<?PHP echo $imgs_admin_dir ?>abort.gif" align="middle" border="0" alt="Annulla">
			   </a>
                  <img src="<?PHP echo $imgs_admin_dir ?>delete_elimina.gif" alt="Elimina - Delete <?php echo $id; ?>" border="0" align="middle" 
			onClick="if (isConfirmed('Are you sure you want to DELETE this Gateway Provider Nr.<?php echo $id; ?> - [ <?php echo $gway->fields["name_gwprovider"]; ?> ] ?')) { window.location='ed_gateway.php?action=delete&auid=<?php echo $id; ?>&name=<?php echo $gway->fields["name_gwprovider"]; ?>'; }">
				</div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#000080"><b>(**) NOTA BENE:</b> Gate File &egrave; il file di testo utilizzato da certi gateway per l'invio di sms.
<br>
Questo file contiene al suo interno i dati tipo lo user di chi invia, i nr. di cellulare,etc.<br> Generalmente viene utilizzato in casi dove si richiede una connessione al gateway di tipo <i>http</i>.
<br>
Ora questo sistema &egrave; stato sostituito da una connessione diretta per la trasmissione dei dati attraverso l'interfaccia <b>EMI/UCP (kannel)</b>.
<br>
<?PHP // echo "In ogni caso il file in questione si trova sotto la directory:<b> ".$dirgw1." </b>.<br>" ?>Si fa presente che in caso di connessione EMI/UCP attraverso un qualsiasi programma specifico (tipo kannel) il file selezionato nel capo &quot;Gate File&quot; non ha importanza: pertanto qui selezioneremo un file a caso.</font>
<br><br><br>
   <script language="JavaScript">
      document.form2.name.focus();
   </script> 
 <?php
} 
 ?>  



<?php
function paint_table($db) { 
   $summgate = $db->Execute("SELECT * FROM gwprovider ORDER BY name_gwprovider");
?>

   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Sigla Provider</b></td>
		 <td><b>Rag.Sociale</b></td>
		 <td><b>Citt�</b></td>
		 <td><b>Telefono</b></td>
		 <td><b>FILE GATEWAY</b></td>
      </tr> <?php
      $i = 1;
      while (!$summgate->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
            <td>

               <a href="ed_gateway.php?action=edit&id=<?php echo $summgate->fields["id"]; ?>&description=<?php echo $summgate->fields["name_gwprovider"]; ?>">
                  <?php echo $summgate->fields["id"]; ?></a>
            </td>
            <td> <a href="ed_gateway.php?action=edit&id=<?php echo $summgate->fields["id"]; ?>&description=<?php echo $summgate->fields["name_gwprovider"]; ?>"><b><?php echo $summgate->fields["nick_gwprovider"]; ?></b></a>
			</td>
			<td><?php echo $summgate->fields["name_gwprovider"]; ?></td>
			<td><?php echo $summgate->fields["city"]; ?></td>
			<td><?php echo $summgate->fields["main_phone"]; ?></td>
			<td><b><?php echo $summgate->fields["original_gwfile_name"]; ?></b></td>
         </tr> <?php
         $i++;
         $summgate->MoveNext();
      } ?>
	  <tr class="row_head"> 
         <td>&nbsp;</td>
         <td>&nbsp;</td>
		 <td>&nbsp;</td>
		 <td>&nbsp;</td>
		 <td>&nbsp;</td>
		 <td>&nbsp;</td>
      </tr>
   </table>

 <?php
} ?>

<?php
if ($privs == '69') {
	// NON SERVE CON KANNEL --> $gwydir = $cfg["gatewdir"];
	//$gwfile = $db->Execute("SELECT gwprovider.original_gwfile_name AS gatex FROM gwprovider LEFT JOIN organization ON gwprovider.name=organization.gway_provider WHERE gwprovider.id = '$id';");
##	$gwfile = $db->Execute("SELECT gwprovider.original_gwfile_name AS gatex FROM gwprovider LEFT JOIN organization ON gwprovider.id=organization.id_gwprovider WHERE gwprovider.id='$id';");
##	$gatefl = $gwfile->fields["gatex"];
    $action = strtolower($action);
   switch ($action) {
      case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operazione annullata.</td></tr></table><br>";
			paint_table($db);
         break;
	  case "gateinserted":
            echo "<table width=\"600\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\"><tr bgcolor=\"#E8FDFF\"><td colspan=\"2\"><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"3\" color=\"#D31238\"><b>NEW GATEWAY PROVIDER IS INSERTED!</b></font></td></tr><tr bgcolor=\"#D31238\">";
   // con KANNEL non serve piu' !!!! ############################
			//echo "<td><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"2\" color=\"#F8FB82\"><b>NOTE FOR ADMIN:</b></font></td><td><b><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"2\" color=\"#FFFFFF\"><b>RICORDATI DI INSERIRE IL FILE FORNITO DAL GATEWAY COME ::: $gwydir/xxx</b></font><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"4\" color=\"#FFFFFF\"><b>$gatefl</b></font></td>";
			echo "</tr></table>";

		paint_table($db);
            break;
	  case "delete":
          if (!$db->Execute("DELETE FROM gwprovider WHERE id='$auid'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Gateway Provider <b>$name</b> was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
	  case "edit":
         edit_gate_form($db, $id);
		 	break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the gateway provider.</td></tr></table>";
            paint_table($db);
            break;
         }
		 	$original_gwfile_name = "not_with_kannel";
		 	$connect_gway_host1 = "not_in_knl";
			$connect_gway_port1 = "not_in_knl";
			$connect_gway_host2 = "not_in_knl";
			$connect_gway_port2 = "not_in_knl";
			$connect_gway_lang = "ita";
			$connect_gway_test = "not_in_knl";
			$fsock1 = "not_in_knl";
         $query = "UPDATE gwprovider SET"
		. " name_gwprovider='$name_gwprovider', nick_gwprovider='$nick_gwprovider', address1='$address1', address2='$address2',"
		. " city='$city', province='$province', country='$country', p_code='$p_code',"
		. " PIVAgatew='$PIVAgatew', gway_contact='$gway_contact', main_phone='$main_phone',"
		. " main_fax='$main_fax', main_email='$main_email', main_www='$main_www',"
		. " tech_gway_contact='$tech_gway_contact', tech_phone='$tech_phone', tech_fax='$tech_fax',"
		. " tech_email='$tech_email', tech_www='$tech_www',original_gwfile_name='$original_gwfile_name', connect_gway_host1='$connect_gway_host1',"
		. " connect_gway_port1='$connect_gway_port1',connect_gway_host2='$connect_gway_host2',"
		. " connect_gway_port2='$connect_gway_port2', connect_gway_lang='$connect_gway_lang',"
		. " connect_gway_test='$connect_gway_test', fsock_link='$fsock1', UCPpath='$UCP_path', UCPinterface='$UCP_interface',"
		. " EMIuser='$E_user', EMIpass='$E_pwd', bareboxIP='$B_IP', KanlSmsPort='$KPort', gate_quest='$gate_quest', comments='$master_comments'"
		. " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
?>
 <script language="JavaScript">
            window.location="ed_gateway.php";
 </script> <?php
         break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
