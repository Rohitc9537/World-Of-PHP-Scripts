<html>
<head>
<!--
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.

-->
<?PHP
/* 	2005 05 21		| 	admheader.inc.php*/
?>
	<script language="JavaScript1.2" src="KsmsAdminValid.js"></script>
<link rel="stylesheet" type="text/css" href="admstyle.css">
<title>Ksms Admin Area - The sms services by viabazar.com</title>
<meta name="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="Mon, 28 Aug 2000 16:20:18 GMT">
</head>
<body class="admbody">

<?PHP 
$imgs_admin_dir = $_SESSION["imgs_admin_dir"];
echo "DIRECTORY OF IMAGES HERE : ".$imgs_admin_dir
// ../images/admin_img/admin_area.gif
?>
<br>
<table cellspacing="3" cellpadding="3" border="0">
<tr>
    <td><img src="<?PHP echo $imgs_admin_dir ?>admin_area.gif" alt="Area Reserved!" width="120" height="31" border="0"></td>
    <td>&nbsp;&nbsp;</td>
    <td>menu A :&nbsp;</td>
    <td><a href="admin_sms.php?action=newconfi" class="adm_menu">config</a> 
	<a href="admin_sms.php?action=newconfi" class="adm_menu">edit config</a> 
	<a href="admin_sms.php?action=new" class="adm_menu">new organization</a> 
	<a href="admin_sms.php" class="adm_menu">edit organization</a>
	<a href="new_vendor.php" class="adm_menu">new vendor</a>
	<a href="edit_vendor.php" class="adm_menu">edit vendor</a>
	</td>
	
</tr>
<tr>
    <td>&nbsp;</td>
    <td>&nbsp;&nbsp;</td>
    <td>menu B :&nbsp;</td>
    <td><a href="new_gateway.php" class="adm_menu">new gateway</a>
	<a href="ed_gateway.php" class="adm_menu">edit gateway</a>
	<a href="admin_orders.php?action=nneworder" class="adm_menu">add order</a>
	<a href="admin_orders.php" class="adm_menu">edit order</a>
	<a href="ne_products.php" class="adm_menu">Products</a>
	<a href="TOOLS_dbconverter.php" class="adm_menu2">DBconverter</a>
	<a href="adm_logout.php" class="adm_menu2">logout</a></td>
</tr>
</table>
<table cellspacing="2" cellpadding="2" border="0">
<tr>
    <td><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000099"><b>KSMS [admin area reserved]</b> - <?php echo $title; ?></b></font></td>
</tr>
</table>
<?PHP
	$tot_orgz = $db->Execute("SELECT COUNT(*) AS totorg FROM organization");
	$tot_cat = $db->Execute("SELECT COUNT(*) AS totcat FROM category");
	$tot_clasf = $db->Execute("SELECT COUNT(*) AS totcla FROM classf");
	$tot_grp = $db->Execute("SELECT COUNT(*) AS totgrp FROM groups");
	$tot_gwp = $db->Execute("SELECT COUNT(*) AS totgwp FROM gwprovider");
	$tot_ord = $db->Execute("SELECT COUNT(*) AS totord FROM orders;");
	$nrorgz = $tot_orgz->fields["totorg"];
	$nrcat = $tot_cat->fields["totcat"];
	$nrcla = $tot_clasf->fields["totcla"];
	$nrgrp = $tot_grp->fields["totgrp"];
	$nrgwp = $tot_gwp->fields["totgwp"];
	$nrord = $tot_ord->fields["totord"];
	if (!$nrorgz) { $nrorgz = 0; }
	if (!$nrcat) { $nrcat = 0; }
	if (!$nrcla) { $nrcla = 0; }
	if (!$nrgrp) { $nrgrp = 0; }
	if (!$nrord) { $nrord = 0; $ordtxt = "Order not found!!!";
		} else { $ordtxt = "There are ".$nrord." orders in database!!!"; }
	echo "<p class='addnotes'>";
	echo "In database there are : <b>".$nrorgz." </b>customers, ";
	echo "in <b>".$nrcat." </b>categories,";
	echo " <b>".$nrcla." </b>classes,";
	echo " <b>".$nrgrp." </b>groups,<b> ".$nrgwp."</b> GatewayProvider";
	echo "<br><b>".$ordtxt."</b>";
	echo "</p><br>";
?>
