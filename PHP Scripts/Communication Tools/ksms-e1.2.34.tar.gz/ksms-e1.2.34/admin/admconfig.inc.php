<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// Ksms version string.
// Ksms version string.
/// look at file: vers.inc.php
///  $cfg["version"] = "xxxxx";
require("../vers.inc.php");
$cfg["signature"] = "KSMS admin - the bulk sms system manager " . $cfg["version"];
$cfg["sysver"] = "KSMS " . $cfg["version"];

### -> Database connection parameters.
$cfg["db_type"] = "mysql";      // DB server type eg: mysql, postgres, sqlite, odbc. See ADODB docs.
$cfg["db_host"] = "localhost";  // DB server hostname. DSN if odbc OR /path/filename if sqlite.
$cfg["db"] = "ksmsDB";          // Ksms database. Not used if odbc or sqlite.
$cfg["auid"] = "test";       		// DB server user id.
$cfg["apasswd"] = "userpass";     // DB server password.
$cfg["db_persist"] = FALSE;     	// Use persistent database connection. TRUE or FALSE.
### -> Miscellaneous configuration parameters.
$cfg["curr"] = "�  ";				// Local currency symbol. eg: $, �, � etc.
$cfg["sespath"] = "/tmp/sessioniTempPHP/ksms_adm_sess/";	// Path of the sessions (777)


// For debuggin (view) in "connection.inc.php". TRUE or FALSE.
//$cfg["admview_debug"] = TRUE;
$cfg["admview_debug"] = FALSE;


?>
