<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
// 					 ne_SMS.php												//


### THE SEQUENCE :
#					functions.php
#						areasmsSV.inc.php  - areasms.inc
#							my_notAutomaticSelect.inc  -  my_AutomaticSelect.inc
#								ne_SMS.php ~ DBsend.php ~ newpart.php ~ KsmsNsend.php  /functions.php/
### internal use

//
$title = "Messages Center";
require("common.inc.php");
include("functions.php");
$smsdir = $cfg["sendeddir"];
$gwydir = $cfg["gatewdir"];
$mastgwdir = $cfg["mastergwd"];
$priv = $_SESSION["priv"];
global $gnbline, $list_numbers, $strsm3, $mex_status, $linestest, $smsnmb, $global, $referer_uri_parts, $strsm3, $mex_status;
?>
<br>

<?PHP 
function edit_sms_form($db, $id) {
   //global $ksms, $id, $DataSms, $title;
   $company = $_SESSION["company"];
   $idORG = $_SESSION["id_company"];
   //$ksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'"); 
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid number or valid sms ID.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$ksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($ksms->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Sms not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
//       ************* EDIT ********************
  ?>

<table class="default" align="center" border="0" cellspacing="0" cellpadding="0" width="400">
      <form name="form1" method="post" action="ne_SMS.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>SMS MODIFY</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Num.:</td>
            <td colspan="3"> <?php echo $ksms->fields["id"]; ?> </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Date:</td>
            <td colspan="3"><?php echo $ksms->fields["sms_ins_date"]; ?> </td>
		 </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Customer:</td>
            <td colspan="3"><?php echo $ksms->fields["organization"]; ?> </td>
		 </tr>
		          <tr class="row_even"> 
            <td colspan="4"><hr></td>
		 </tr>	 
		<tr class="row_even">
            <td nowrap align="right">Title:</td>
            <td colspan="3"><input type="text" name="sms_title" size="40" value="<?php echo $ksms->fields["sms_title"]; ?>"> </td>
         </tr>
		 <tr class="row_even">
            <td nowrap align="right">SMS (MESSAGE):</td>
            <td colspan="3">
			<?PHP 
			$Ktext = $ksms->fields["sms_text"];
			include("areasmsSV.inc.php"); ?>
			</td>
         </tr>
		 <tr class="row_even">
            <td nowrap align="right">Note:</td>
            <td colspan="3"><input type="text" name="sms_note" size="40" value="<?php echo $ksms->fields["sms_note"]; ?>"> </td>
         </tr>
		 <tr class="row_even">
            <td colspan="4">&nbsp;<br></td>
         </tr>
		 <tr class="row_even"> 
            <td nowrap align="right">Others note</td>
			<?php
         if ($ksms->fields["sms_sended"] == "N") { ?>
		 	<td colspan="3">&nbsp;
			<img src="images/pub/bta_neversended.gif" alt="Questo messaggio e' ancora da inviare" border="0">
			</td> <?php
         } else { ?>
		 	<td colspan="3">&nbsp;
			<img src="images/pub/bta_justsended.gif" alt="Messaggio gi� inviato" border="0">
			</td> <?php
         } ?>
		 </tr>
		 <tr class="row_even">
            <td colspan="4">&nbsp;<br></td>
         </tr>
		 <tr class="row_foot"> 
            <td colspan="4" nowrap>
				<div align="center">
               <img src="images/pub/bt_save_message.gif" border="0" alt="Modifica"
                  onClick="document.form1.submit();">
               <a href="ne_SMS.php?action=abortsect">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Delete <?php echo $id; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this ksms Nr.<?php echo $id; ?> - [ <?php echo $ksms->fields["sms_title"]; ?> ] ?')) { window.location='ne_SMS.php?action=delete&uid=<?php echo $id; ?>'; }">
	<?php if ($ksms->fields["sms_sended"] == "N") { ?>
					<img src="images/pub/bt_send_message.gif" border="0" alt="Modifica"
                  onClick="document.form1.submit();">
				  <?PHP
			 } else { ?>
			   	  <img src="images/pub/bt_NOsend_message.gif" border="0" alt="Messaggio gia' inviato!">
	 <?php } ?>
	 			</div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
	  <input type="hidden" name="organization" value="<?php echo $ksms->fields["organization"]; ?>">
	  <input type="hidden" name="sms_ins_date" value="<?php echo $ksms->fields["sms_ins_date"]; ?>">
	  <input type="hidden" name="sms_saved" value="<?php echo $ksms->fields["sms_saved"]; ?>">
	  <input type="hidden" name="sms_sended" value="<?php echo $ksms->fields["sms_sended"]; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   	<?php if ($ksms->fields["sms_sended"] == "Y") { ?>
	<table align="center" width="400" cellspacing="2" cellpadding="2" border="0">
<tr>
    <td><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#919DA2">hi-from-ksms</font></td>
</tr>
</table>
		<?PHP } ?>
   <br>
  
   <script language="JavaScript">
      document.form1.sms_title.focus();
   </script> 
 <?php
} 
 ?>
 <script language="javascript">
 	function setTemplate()
		{
			sellength = ksmsform.mtemplate.length;
		    	for ( i=0; i<sellength; i++)
		    	{
				if (ksmsform.mtemplate.options[i].selected == true)
				{
			    	ksmsform.sms_text.value = ksmsform.mtemplate.options[i].value;
					countChars(event);
				}
		    }
		}
	</script>
<?php
//       ************* NEW ********************
function display_form($db) {
	$company = $_SESSION["company"];
	$rndnb = rand(0,999);
	$rndnb2 = mt_rand(100,999);
	$datnb = date("Ymd");
	$idsms = $db->Execute("SELECT MAX(id) as lst_id FROM ksms");
	$rp = $idsms->FetchRow();
	$smsnb = $rp['lst_id'] + 1;
	$idORG = $_SESSION["id_company"];
	$vitemplate = $db->Execute("SELECT * FROM SmsTemplate WHERE uid='$idORG' ORDER BY t_title");
	$i = 1;
	$option_values = "<option value=\"\" default>--Please Select--</option>";
	while (!$vitemplate->EOF) {
	    $option_values .= "<option value=\"".$vitemplate->fields["t_text"]."\">".$vitemplate->fields["t_title"]."</option>";
	  //  $input_values .= "<input type=\"hidden\" name=\"content_$i\" value=\"".$vitemplate->fields["t_text"]."\">";
         $i++;
         $vitemplate->MoveNext();
	}
?>
  <br>
  <table class="foottbl"><tr><td>If you want to use one message template, click on button &quot;<b>Use Template</b>&quot;</td></tr></table>
<br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="600">
       <tr class="row_head"> 
         <td><b>Area insert</b></td>
         <td align="right">NEW SMS</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="600">
   <form action="ne_SMS.php" method="post" name="ksmsform" id="ksmsform"> 
   	  <tr class="row_even"> 
         <td align="right">Use Template:</td>
         <td>
           <?php 
		   //echo $vitemplate->GetMenu("mtemplate", "", FALSE, FALSE, 0);
		   echo "<select name=\"mtemplate\">". $option_values . "</select>";
		   ?>
		   <input type="button" onClick="javascript: setTemplate();" name="nb" value="Use Template" class="button">
         </td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Date:</td>
         <td>
           <?php echo date("Y-m-d"); ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Title:</td>
         <td>
		<input type="text" name="sms_title" size="40" value="<?php echo $datnb, "0", $smsnb, "@pr", $rndnb, ".", $rndnb2; ?>">
         </td>
       </tr>
	   <tr class="row_even">
         <td align="right">Message:</td>
         <td>
		 <?PHP include("areasms.inc"); ?>
         </td>
       </tr>
	   <tr class="row_even">
         <td align="right">Internal note:</td>
         <td>
			<input type="text" name="sms_note" size="40" value="">
         </td>
       </tr>
    <tr class="row_foot"> 
         <td colspan="2"> 
            <div align="center">
			<img src="images/pub/bt_save_message.gif" border="0" alt="Salva il messaggio sms"
               onClick="document.ksmsform.submit();">
            <a href="ne_SMS.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a>
          <!--  <a href="ne_SMS.php?action=sendsms">
			   	  <img src="images/pub/bt_send_message.gif" border="0" alt="Invia l'SMS!"></a>	 -->
			</div>
     	</td> 
	</tr>
	 <input type="hidden" name="sms_ins_date" value="<?php echo date("Y-m-d"); ?>">
	 <input type="hidden" name="organization" value="<?php echo $company; ?>">
	 <?PHP// echo $input_values; ?>
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.ksmsform.sms_text.focus();
   </script> <?php
} ?>


<?php
function select_options($db, $id) {
 	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
	//$selksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'"); 
	if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Incorrect Selection: you must 
	    select a valid number or valid sms.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$selksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($selksms->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Sms --> not found...</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
	if ($selksms->fields["sms_sended"] == "Y") {
	//echo "<table class=\"notice\" width=\"100%\"><tr><td><br><div align=\"center\"><b><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"4\" color=\"ffff00\">ATTENZIONE::: QUESTO MESSAGGIO E' GIA' STATO INVIATO!!!</font></b></div><br></td></tr></table>";
      //return FALSE;
	 echo "<br><table class='noticeadvance' align='center'><tr><td>";
	 echo "WARNING::: THIS MESSAGE IS ALREADY SENDED!!!";
	 echo "</td></tr></table><br>";

   }
?>

<table class="default" align="center" border="0" cellspacing="1" cellpadding="2">
      <form name="ksmsform3" method="post" action="ne_SMS.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>MESSAGE SAVED AND READY TO SEND!</b></td>
         </tr>
         <tr class="row_smsa"> 
            <td nowrap align="right" colspan="4"><div align="center">SMS Num.:
			&nbsp;&nbsp;
			<b><?php echo $selksms->fields["id"]; ?></b>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			SMS salvato il : 
			&nbsp;&nbsp;&nbsp;
			<b><?php echo $selksms->fields["sms_ins_date"]; ?></b> </div></td>
		 </tr>
         <tr class="row_smsa"> 
            <td nowrap align="right">Organization:</td>
            <td colspan="3"><b><?php echo $selksms->fields["organization"]; ?> </b></td>
		<tr class="row_smsa">
            <td nowrap align="right">Title:</td>
            <td colspan="3"><b><?php echo $selksms->fields["sms_title"]; ?> </b></td>
         </tr>
	<tr class="row_smsa">
         <td nowrap align="right">The Message:</td>
         <td colspan="3">
<?php
// MS INTERNET EXPLORER BUGS (table/images)
include ("detector_fll.php");
if ( ( browser_detection( 'browser' ) == 'ie' ) 
&& 
( browser_detection( 'number' ) >= 4 ) )
{ $wdt="78"; }
	else { $wdt="79"; }
//
echo"<table align='center' cellspacing='0' cellpadding='0'>";
echo"<tr>";
echo"<td colspan='2' background='images/pub/mobs/mobileUP001.jpg' width='".$wdt."' height='62'></td>";
echo"<td colspan='3' background='images/pub/mobs/mobileUP002.jpg' width='216' height='62'></td>";
echo"<td colspan='2' background='images/pub/mobs/mobileUP003.jpg' width='85' height='62'></td>";
echo"</tr>";
echo"<tr>";
echo"<td colspan='2' background='images/pub/mobs/mobileMID001.jpg' width='".$wdt."' height='194'></td>";
echo"<td colspan='3' background='images/pub/mobs/mobileMID002txt.jpg' width='216' height='194' border='0' class='cell_of_evidence' valign='top'>";
echo"<div id='pod'>";
					$txsms=$selksms->fields["sms_text"];
					$nwSMStext = wordwrap($txsms, 28, "<br />\n");
					echo "<p class='body_of_text'>".$nwSMStext."</p>";
echo"</div>";
echo"<br>";
echo"</td>";
echo"<td colspan='2' background='images/pub/mobs/mobileMID003.jpg' width='85' height='194'></td>";
echo"</tr>";
echo"<tr>";
echo"<td colspan='2' background='images/pub/mobs/mobileDW001.jpg' width='".$wdt."' height='49'></td>";
echo"<td colspan='3' background='images/pub/mobs/mobileDW002.jpg' width='216' height='49'></td>";
echo"<td colspan='2' background='images/pub/mobs/mobileDW003.jpg' width='85' height='49'></td>";
echo"</tr>";
echo"</table>";
?>
<table align="center" cellspacing="0" cellpadding="0">
<tr>
   <td background="images/pub/mobs/mbDwnUp001.jpg" width="67" height="53"></td>
    <td colspan="2" background="images/pub/mobs/mbDwnUp002.jpg" width="67" height="53"></td>
    <td background="images/pub/mobs/mbDwnUp003.jpg" width="122" height="53"><a href="index.php"><img src="images/pub/mobs/mbDwnUp003.jpg" alt="HomePage" border="0"></a></td>
    <td colspan="2" background="images/pub/mobs/mbDwnUp004.jpg" width="64" height="53"></td>

    <td background="images/pub/mobs/mbDwnUp005.jpg" width="60" height="53"></td>
</tr>
<tr>
    <td background="images/pub/mobs/mbDwnDW001.jpg" width="67" height="54"></td>
    <td colspan="2" background="images/pub/mobs/mbDwnDW002.jpg" width="67" height="54">
	<img src="images/pub/mobs/mbDwnDW002.jpg" border="0" alt="Invia" onClick="document.ksmsform3.submit();">
	</td>
    <td background="images/pub/mobs/mbDwnDW003.jpg" width="122" height="54"><a href="index.php"><img src="images/pub/mobs/mbDwnDW003.jpg" alt="homepage" border="0"></a></td>
    <td colspan="2" background="images/pub/mobs/mbDwnDW004.jpg" width="64" height="54">
		<a href="ne_SMS.php?action=abortsect">
		<img src="images/pub/mobs/mbDwnDW004.jpg" border="0" alt="Annulla">
		</a>
	</td>
    <td background="images/pub/mobs/mbDwnDW005.jpg" width="60" height="54"></td>
</tr>
</table>

		</td>
       </tr>
		 <tr class="row_smsa">
            <td nowrap align="right">Note:</td>
            <td colspan="3"><b><?php echo $selksms->fields["sms_note"]; ?> </b></td>
         </tr>
		<tr class="row_smsa">
			<td align="right">HOWTO:</td>
        	<td colspan="3">
			<table align="center" bgcolor="#EEEEEE" width="450" cellspacing="2" cellpadding="2" border="0">
		<tr class="row_even_mini">
    		<td>
			<?PHP if ($selksms->fields["sms_sended"] == "Y") { ?>
			<div align="center">
				<b>This message was sended!!!</b>
				<br>
				If you wanna resend for another time, please click on &laquo;<b>SEND</b>&raquo; or &laquo;<b>ANNULLA</b>&raquo; to abort this operation.
			</div>
			<?PHP } else { ?>		
			<div align="center">
				OK... now you can send this message to some phone numbers, or 
				you can abort this operation and sedn thi message later!
				<br><br>
				.......
			</div>
		<?PHP 
		}?>
	</td>
</tr>
</table>
			</td>
		</tr>
		
   	<input type="hidden" name="id" value="<?php echo $id; ?>">
	<input type="hidden" name="sms_text" value="<?php echo $selksms->fields["sms_text"]; ?>">
	<input type="hidden" name="sms_ins_date" value="<?php echo $selksms->fields["sms_ins_date"]; ?>">
	<input type="hidden" name="sms_saved" value="<?php echo $selksms->fields["sms_saved"]; ?>">
	<input type="hidden" name="sms_sended" value="<?php echo $selksms->fields["sms_sended"]; ?>">
    <input type="hidden" name="action" value="send_ksms">
  </form>
   </table>
   <br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#919DA2"><b>SMS TEXT:</b> <?PHP echo $selksms->fields["sms_text"]; ?></font>
<br>
 <?php
} 
 ?>

<?php
function paint_select($db) {
 	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
   	$summsms = $db->Execute("SELECT * FROM ksms WHERE id_organization='$idORG' ORDER BY sms_ins_date");
?>
<br>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head_tbl"> 
         <td><b># </b></td>
         <td><b>Date</b></td>
		 <td><b>Title</b></td>
		 <td><b>Message</b></td>
		 <td><b>DataBase</b></td>
		 <td><b>Status</b></td>
      </tr> <?php
      $i = 1;
      while (!$summsms->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } 
		if ($summsms->fields["sms_saved"] == "Y")
			 { $imgsavd = "<img src='images/pub/salvato.gif' alt='message saved!' border='0'>"; }
		if ($summsms->fields["sms_saved"] == "N")
			 { $imgsavd = "<img src='images/pub/dasalvare.gif' alt='message NOT saved!' border='0'>"; }
		if ($summsms->fields["sms_sended"] == "Y")
			 { $imgsdd = "<img src='images/pub/inviato.gif' alt='message sended!' border='0'>"; 
			 	$kssend = "second_sendafter"; }
		if ($summsms->fields["sms_sended"] == "N")
			 { $imgsdd = "<img src='images/pub/dainviare.gif' alt='message NOT sended!' border='0'>"; 
			 	$kssend = "sendafter"; }
		$txtsms=$summsms->fields["sms_text"];
		if (strlen($txtsms) > 49) { $dotx = " ..."; }
		$summid = $summsms->fields["id"];
		$sumtitle = urlencode($summsms->fields["sms_title"]);
		 ?>

            <td align="right">
            <a href="ne_SMS.php?action=<?php echo $kssend; ?>&id=<?php echo $summid; ?>&title=<?php echo $sumtitle; ?>"><?php echo $summid; ?>&nbsp;</a>
			</td>
			 <td align="center"><?php echo $summsms->fields["sms_ins_date"]; ?></td>
            <td> 
			<a href="ne_SMS.php?action=<?php echo $kssend; ?>&id=<?php echo $summsms->fields["id"]; ?>&title=<?php echo $sumtitle; ?>"><b><?php echo $summsms->fields["sms_title"]; ?></b></a>
			</td>
 		 	 <td><b><?php echo substr($txtsms, 0, 49).$dotx; ?></b></td>
			 <td> <b><?php //echo $summsms->fields["sms_saved"]; 
			 			echo $imgsavd;
					?></b></td>
			 <td> <b><?php //echo $summsms->fields["sms_sended"]; 
			 			echo $imgsdd;
					?></b></td>
         </tr> <?php
         $i++;
         $summsms->MoveNext();
      } 
	  echo "<tr class='row_head_tbl'><td colspan='6'><div align='center'>";
	  echo "If the list is empty you can insert a new message following this <a href='ne_SMS.php?action=addksms'>LINK (send new message)!!</a>";
	  echo "</div></td></tr>";
	  echo "</table>";
} //    chiudi paint_select($db)


// FUNZIONE SELEZIONE NUMERI A CUI INVIARE L'SMS...
//    per CATEGORIA / per GRUPPO / per CLASSE / per SINGOLO NUMERO SELEZIONATO

function paint_table_numbers_select($db, $smsid, $smopt) {
   	$company = $_SESSION["company"];
   	$idORG = $_SESSION["id_company"];
   	$smcats = $db->Execute("SELECT * FROM category ORDER BY descrip");
	  $smcatsGR=$smcats->RecordCount();
   	$smgroups = $db->Execute("SELECT * FROM groups WHERE id_organization='$idORG' ORDER BY descrip");
	  $smgroupsGR=$smgroups->RecordCount();
   	$smsubgroups = $db->Execute("SELECT * FROM subgroup WHERE id_organization='$idORG' ORDER BY descript");
	  $smsubgroupsGR=$smsubgroups->RecordCount();
   	$smclasses = $db->Execute("SELECT * FROM classf ORDER BY descript");
	  $smclassesGR=$smclasses->RecordCount();
	$smphones = $db->Execute("SELECT mobile_pref,mobile_phone,id_user FROM userz WHERE country_code='39' AND id_organization='$idORG' ORDER BY mobile_pref");
	$smidusr = $smphones->fields["id_user"];
	// necessary for javascript "enableDisable()"
	// $totvoices = ($smcatsGR + $smgroupsGR + $smclassesGR + $smsubgroupsGR);
	$totvoices = ($smcatsGR + $smclassesGR + $smsubgroupsGR);
	$sel_creds = $db->Execute("SELECT * FROM credits_manager WHERE id_orgz='$idORG'");
	//$sendksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'");
	$rp_connect = $sel_creds->fields["connext_type"];
	$rp_crdtots = $sel_creds->fields["smscredits_totalsum"];
	$rp_crdspen = $sel_creds->fields["smscredits_spend"];
	$rp_crdremn = $sel_creds->fields["smscredits_remain"];
	$rp_nsmstot = $sel_creds->fields["nrsms_totalsum"];
	$rp_nsmsspe = $sel_creds->fields["nrsms_spend"];
	$rp_nsmsrem = $sel_creds->fields["nrsms_remain"];
	$rp_cractiv = $sel_creds->fields["credit_activated"];
	// $row_prod_amount_it = number_format($totrow, 2, ',', '.'); // italian format numbers!!!
	if ($rp_connect == "fee") {
		$creds_avail = number_format($rp_crdremn, 2, ',', '.');
		$ksmssend = number_format($rp_crdspen, 2, ',', '.');
		if ($rp_crdtots == 0) { $credact = "noSMCRED"; }
	}
	if ($rp_connect == "oto") {
		$creds_avail = number_format($rp_nsmsrem, 2, ',', '.');
		$ksmssend = number_format($rp_nsmsspe, 2, ',', '.');
		if ($rp_nsmstot == 0) { $credact = "noCREDS"; }
	}
	if ($rp_connect == "nnt") {
		$creds_avail = 0;
		$ksmssend = 0;
	}
	if ($rp_connect == "") {
		$creds_avail = 0; 
		$ksmssend = 0;
	}
		$notes = "nessuna nota!";
// CHECKIN........
	if ($credact == "noSMCRED") {
		echo "<p class='errtbl'>
		<br>
		WARNING : <br>
		There isn't any credits to send this message!
		</p>";
		include ("footer2.inc.php");
		break;
		  }
	if ($credact == "noCREDS") {
		echo "<p class='errtbl'>
		<br>
		WARNING : <br>
		There isn't any credits to send this message!
		</p>";
		include ("footer2.inc.php");
		break;
		  }
	if (!$smidusr) {
		echo "<p class='errtbl'>
		<br>
		WARNING : <br>
		There isn't any credits to send this message!
		</p>";
		include ("footer2.inc.php");
		break;
		  }
?>
<br>
<table class="tblsm" align="center" width="801" cellspacing="2" cellpadding="2" border="0">
       <tr class="row_head">
    <td class="row_credits" width="200">&nbsp;<img src="images/pub/buttons/cred_disponibili.gif" alt="crediti disponibili" width="25" height="27" border="0" align="middle">&nbsp;CREDITS AVAILABLE</td>
    <td class="row_credits_notice"><?PHP echo $creds_avail ?></div></td>
</tr>
<tr>
    <td class="row_credits" width="200">&nbsp;<img src="images/pub/buttons/cred_consumati.gif" alt="crediti consumati" width="25" height="27" border="0" align="middle">&nbsp;CREDITS SENDED</td>
    <td class="row_credits_notice"><?PHP echo $ksmssend ?></td>
</tr>
<tr>
    <td class="row_credits" width="200">&nbsp;<img src="images/pub/buttons/note.gif" alt="note e appunti" width="25" height="27" border="0" align="middle">&nbsp;NOTE</td>
    <td class="row_credits"><?PHP echo $notes ?></div></td>
</tr>
</table>
<?PHP 
$snmbelm= $totvoices + 1;
//echo "<script> var snel = '$snmbelm'; </script>"; # Assign it to a javascript variable
?>
<SCRIPT LANGUAGE="JAVASCRIPT" TYPE="TEXT/JAVASCRIPT">
<!-- Hide script from older browsers	
	function enableDisable()
{
<?PHP 
	echo "var smsgrsel = '$totvoices';";
	echo "\n";
	echo "var kelem = '$snmbelm';";
	echo "\n";
?>
    // document.formsend1.smsgroupsel[0].checked  checks if the first radio button is selected.
    if(document.formsend1.smsgroupsel[smsgrsel].checked == false)
    {
        document.formsend1.elements[kelem].disabled = true;
    }
    else if(document.formsend1.smsgroupsel[smsgrsel].checked == true)
    {
        document.formsend1.elements[kelem].disabled = false;
    }
    else
    {
        alert("Error on java! Please contact Paolo");
    }
}
// End hiding script -->
</SCRIPT>
<!-- <script> var jstest = '$test'; </script>   // Assign it to a javascript variable -->
<br>
<table class="tblsm" align="center" width="801" cellspacing="1" cellpadding="1" border="0">
<form name="formsend1" method="post" action="ne_SMS.php">
<tr class="row_head">
    <td colspan="2"><div align="center">Please select the numbers&nbsp;&nbsp;&nbsp;&nbsp;<font size="1" color="#ff9900">(<?PHP echo $totvoices; ?>)</font></div></td>
</tr>
<tr>
    <td>
	<!-- Area ksms SubGroup selection     -->
  
	<table class="tbl_p01b" width="400" border="0" cellspacing="2" cellpadding="2">
      <tr class="row_head"><td colspan="2"><b><font size="4">SUBGROUPS</font></b> <font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#e5e5e5">()</font></td></tr>
		<tr class="row_under_head">
			<td><font size="-1"><b>GROUP</b></font></td>
			<td><b>SubGroup description</b> <font size="-1">(numbers)</font></td>
	   	</tr>
		
<?php
      				$i = 1;
      				while (!$smsubgroups->EOF) {
         			if ($i % 2 == 0) {
            			echo "<tr class=\"row_scd\">";
         			} else {
            			echo "<tr class=\"row_fst\">";
         			}
	$idsubgroup=$smsubgroups->fields["id"];
	$selsubgr = $db->Execute("SELECT COUNT(idgroup) AS totsubgroup FROM userz WHERE idsubgroup='$idsubgroup' AND id_organization='$idORG'");
	$getsubgr = $selsubgr->fields["totsubgroup"];
	//$subgrSID = $smsubgroups->fields["id"];
	$subgrDSC = $smsubgroups->fields["descript"];
	$groupDESC = $smsubgroups->fields["groupdescr"];
 ?>
			<td>
				<?php echo $groupDESC; ?>
			</td>
			<td>
<input type="Radio" name="smsgroupsel" value="XG<?php echo $idsubgroup; ?>" onClick="enableDisable()"> 
	<?php echo $subgrDSC."</input>&nbsp;&nbsp;&nbsp;($getsubgr)	"; ?>	
			</td>
		</tr><?php
         $i++;
         $smsubgroups->MoveNext();
      } ?>
	</table>
	<!-- end Area SubGroup Selection -->
	</td>
    <td>
	<!-- Area Category selection     -->
	<table class="tbl_p02" width="400" border="0" cellspacing="2" cellpadding="2">
      	<tr class="row_head"><td><b><font size="4">CATEGORY</font></b></td></tr>
		<tr class="row_under_head">
			<td><b>Category description</b> (summ)</td>
	   	</tr>
<?php
      				$i = 1;
      				while (!$smcats->EOF) {
         			if ($i % 2 == 0) {
            			echo "<tr class=\"row_scd\">";
         			} else {
            			echo "<tr class=\"row_fst\">";
         			}
	$idcat=$smcats->fields["id"];
// $getcat = $db->GetAll("SELECT category FROM userz WHERE category='$idcat' AND id_organization='$idORG'");
$selct = $db->Execute("SELECT COUNT(idcateg) AS pipcatg FROM userz WHERE idcateg='$idcat' AND id_organization='$idORG'");
$getct = $selct->fields["pipcatg"];
$caSID = $smcats->fields["id"];
$caDES = $smcats->fields["descrip"];
?>
		<td>
<input type="Radio" name="smsgroupsel" value="CA<?php echo $caSID; ?>" onClick="enableDisable()"> <?php echo $caDES."</input>&nbsp;&nbsp;&nbsp;($getct)"; ?>
		</td>
	</tr><?php
         $i++;
         $smcats->MoveNext();
      } ?>
	</table>
	<!-- end Area Category Selection -->
	</td>
</tr>
<tr>
    <td>
	<!-- Area Class selection     -->
	<table class="tbl_p02b" width="400" border="0" cellspacing="2" cellpadding="2">
      	<tr class="row_head"><td><b><font size="4">CLASS</font></b></td></tr>
		<tr class="row_under_head">
			<td><b>Class description</b> (summ)</td>
	   	</tr>
<?php
      				$i = 1;
      				while (!$smclasses->EOF) {
         			if ($i % 2 == 0) {
            			echo "<tr class=\"row_scd\">";
         			} else {
            			echo "<tr class=\"row_fst\">";
         			}
	$idclass=$smclasses->fields["id"];

// $getcl = $db->GetAll("SELECT class FROM userz WHERE class='$idclass' AND id_organization='$idORG'");
// $totalcl = count($getcl);
$selcla = $db->Execute("SELECT COUNT(idclasse) AS pipcla FROM userz WHERE idclasse='$idclass' AND id_organization='$idORG'");
$getcl = $selcla->fields["pipcla"];
$clSID = $smclasses->fields["id"];
$clDES = $smclasses->fields["descript"];
?>
			<td>
<input type="Radio" name="smsgroupsel" value="CL<?php echo $clSID;  ?>" onClick="enableDisable()"> <?php echo $clDES."</input>&nbsp;&nbsp;&nbsp;($getcl)"; ?>
			</td>
		</tr><?php
         $i++;
         $smclasses->MoveNext();
      } ?>
	</table>
	
	<!-- end Area Class Selection -->
	</td>
    <td>
	<!-- Area Numbers w/manual single selection     -->
	<table class="tblsm2" align="center" width="400" cellspacing="2" cellpadding="2" border="0">
	   <tr class="row_head">
	   <td colspan="2"><b><font size="4">SINGLE NUMBER</font></b></td></tr>
	   <tr class="row_under_head">
		<td colspan="2">
		<input type="Radio" name="smsgroupsel" value="ksms_SingleSelector"onClick="enableDisable()"><b>Multiple selection</b>
		</td>
	   </tr>
	<tr>
    <td class="row_fstx"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#008040">
	<b>Only one international prefix, at the moment!</b><br>
For multiple select:<br>
1.) Check the bottom box &quot;<i>Multiple selection</i>&quot;<br>
2.) Select the first number, hit on your keyboard the button<b>CTRL</b> and select some others ...<br>
3.) For select more sequential numbers, select the first and the lat with <b>SHIFT</b> hitting in your keyboard</font></td>
    	<td>
			<label><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#0450AC">SMS da spedire a:</font><br>
				<select name="sms_numbers[]" size="10" multiple="yes" disabled><?php
      				$i = 1;
      				while (!$smphones->EOF) {
			$smnumbers = ($smphones->fields["mobile_pref"]."-".$smphones->fields["mobile_phone"]);
			//$smphones = $db->Execute("SELECT mobile_pref,mobile_phone,id_user FROM userz WHERE country_code='39' AND id_organization='$idORG' ORDER BY mobile_pref");
			$ksmsiduser = $smphones->fields["id_user"];
			// old :    <option value="< ?php echo $smnumbers; ? >"> < ?php echo $smnumbers; ? >
         			?>					
			<option value="<?php echo $ksmsiduser; ?>"> <?php echo $smnumbers; ?>
		<?php
         	$i++;
         	$smphones->MoveNext();
      		} 
		?>
					</select>
				</label>
		</td>
		</tr>
	</table>
	<!-- end Numbers w/manual single Selection -->
	</td>
	
</tr>
<tr>
    <td colspan="2">
	<!-- Area Single Number Input Selection     -->
	<table class="tblsm2" align="center" width="400" cellspacing="2" cellpadding="2" border="0">
		<tr class="row_head">
	   		<td colspan="2"><b><font size="4">MANUAL SELECT SINGLE NUMBER</font></b></td></tr>
	   	<tr class="row_under_head">
			<td colspan="2"><input type="radio" name="nn" value="not activated">Send to:</td>
	   	</tr>
		<tr>
    		<td class="row_fstx">
			<select name="ksingle_number" multiple="no" disabled>
			<?php
			//	$smphones = $db->Execute("SELECT mobile_pref,mobile_phone,id_user FROM userz WHERE country_code='39' AND id_organization='$idORG' ORDER BY mobile_pref");
			$i = 1;
      		while (!$smphones->EOF) {
			$kspren = $smphones->fields["mobile_pref"];
			echo "<option value='".$kspren."'> ".$kspren;
			$i++;
         	$smphones->MoveNext();
      			}
			?>
			</select>
			</td>
    		<td>not active</td>
		</tr>
	</table>
	<!-- end Single Number Input Selection -->
	</td>
</tr>
<tr>
    <td colspan="2">onetwothreefour</td>
</tr>
</table>

 </td>  
</tr>
<tr><td colspan="2"><br></td></tr>
<tr><td colspan="2"><hr width="100%" color="#FFFFFF"></td></tr>
      <tr class="row_foot">
         <td colspan="2">
		 <div align="center"> 
		 <a href="ne_SMS.php?action=abortsect">
			   	  	<img src="images/pub/bt_cancel.gif" border="0" alt="Annulla l'operazione">
						</a>&nbsp;&nbsp;
					<img src="images/pub/bt_send_message.gif" border="0" alt="Invio Finale di SMS"
                  onClick="document.formsend1.submit();">
			</div>
			</td>
      </tr>
	  <input type="hidden" name="smsid" value="<?php echo $smsid ?>">
	  <input type="hidden" name="action" value="finalsend">
	 	</form>
</table>


 <?php
} // end function

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// CHECKED !!!////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// test
function sendsms_confirmed_test($db,$smsel,$sms_numbers,$smsgroupsel,$smsid,$stream)
{
$strsm = substr($smsgroupsel, 0, 2);
$strsm2 = substr($smsgroupsel, 2, 10);  // id
echo "&nbsp;Special function only for test!  ~ row-868-ne_SMS.php<br>";
echo "&nbsp;&nbsp;<li type='square'>SMSEL =".$smsel."</li><br>";
echo "&nbsp;&nbsp;<li type='square'>STRSM =".$strsm."</li><br>";
echo "&nbsp;&nbsp;<li type='square'>SMSGRPSEL =".$smsgroupsel."</li><br>";
echo "&nbsp;&nbsp;<li type='square'>strsm =".$strsm."</li><br>";
echo "&nbsp;&nbsp;<li type='square'>strsm2 =".$strsm2."</li><br>";

}
function sendsms_confirmed($db,$smsel,$sms_numbers,$smsgroupsel,$smsid,$stream)
{
//global $strsm3, $mex_status, $sms_msg;
$privz = $_SESSION["priv"];
$idORG = $_SESSION["id_company"];
	if ($privz == 1)  // USER LOCKED !!!
			{
	echo "<br>";
	echo "<table align='center' bgcolor='#4A3FD8' cellspacing='2' cellpadding='2' border='0'><tr>";
    echo "<td><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#F7EC2B'><b>LOCKED (ACSB$privz)::: You are not allowed to send SMS, please contact the administrator!</b></font></td>";
	echo "</tr></table>";
	echo "<br>";
		break;
		}
// TESTING -----------------------------------------------
// echo "&nbsp;&nbsp;<li type='square'>SMSEL =".$smsel."</li><br>";
// echo "&nbsp;&nbsp;<li type='square'>STRSM =".$strsm."</li><br>";
//--------------------------------------------------------------

	if (!$gwfile = $db->Execute("SELECT gwprovider.id, gwprovider.UCPpath, gwprovider.UCPinterface, gwprovider.EMIuser, gwprovider.EMIpass, gwprovider.bareboxIP, gwprovider.KanlSmsPort FROM gwprovider LEFT JOIN organization ON gwprovider.id=organization.id_gwprovider WHERE organization.id='$idORG'"))
	{
	echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
	return FALSE;
		}
	   // sms data extract! ---> 
	if (!$smsk = $db->Execute("SELECT * FROM ksms WHERE id_organization='$idORG' AND id='$smsid'")) {
	echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
	return FALSE;
		}
   if ($smsel == "SingleMessagesSelected") {
   		if ($sms_numbers == "") {
			echo ("<table class=\"notice\" width=\"100%\"><tr><td><div align=\"center\"><b><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"4\" color=\"#F8FB82\">Errore ::: Non hai selezionato nessun NUMERO TELEFONICO a cui spedire il tuo SMS!</font></b></div></td></tr></table>");
				$thereisnr = "No";
     			}
            echo "<table class=\"news\" width=\"100%\"><tr><td>NUMERI SINGOLI SELEZIONATI!</td></tr>";
			### DISPLAY ALL SINGLE NUMBER SELECTED FUNCTION:
			// display_single_sel($db, $sms_numbers):
			echo "</table>";
			$thereisnr = "Yes";
			//echo "<br><br>&nbsp;&nbsp;&nbsp;<b>Tra poco riceverai una email con il report di consegna!</b><br><br>";
		}
			// end  if ($smsel == SingleMessagesSelected
	if ($smsel == "automaticselecta") { $smsgroupsel = $stream; }
	$totcountnrs = count($sms_numbers);
// TESTING -----------------------------------------------
// echo "&nbsp;&nbsp;<li type='square'>TotNR =".$totcountnrs."</li><br>";
//--------------------------------------------------------------
	if ($totcountnrs == " ") { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
	if ($totcountnrs == "") { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
	if (empty($totcountnrs)) { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
$strsm = substr($smsgroupsel, 0, 2);
$strsm2 = substr($smsgroupsel, 2, 10);  // id
if ($strsm == "ks") {($strsm = "single");}
if ($strsm2 == "ms_SingleS") {($strsm = "single");}
##
######### CHECK THE NUMBERS ###############################################################
//  "XG"   ----- >>>  "GR" (match-case) ... 
	if ($strsm == "XG") {
//	   if (!$strsm3G = $db->Execute("SELECT id,descript FROM subgroup WHERE id='$strsm2' AND id_organization='$idORG'")) {
//      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
//      return FALSE;
//   		}
//		$strsm3=$strsm3G->fields["id"];
		$strsm3=$strsm2;
		if (!$strsm3) { echo "<b>NUMBER NOT SELECTED. Error DEC7127</b>"; return FALSE;}
		$slclause = "idsubgroup";  // group ... WHERE CLAUSE IN DBsend.php
		$phselected = $db->Execute("SELECT COUNT(id_user) AS KphSel FROM userz WHERE idsubgroup='$strsm3' AND id_organization='$idORG'");
		$phselectedFLD = $phselected->fields["KphSel"];
		 if (empty($phselectedFLD)) { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
		 $totcountnrs = $phselectedFLD;
     	}
		if ($strsm == "GR") {
	   if (!$strsm3D = $db->Execute("SELECT id,descrip FROM groups WHERE id='$strsm2' AND id_organization='$idORG'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   		}
		$strsm3=$strsm3D->fields["id"];
		if (!$strsm3) { echo "<b>NUMBER NOT SELECTED. Error DEC7121</b>"; return FALSE;}
		$slclause = "idgroup";  // group ... WHERE CLAUSE IN DBsend.php
		$phselected = $db->Execute("SELECT COUNT(id_user) AS KphSel FROM userz WHERE idgroup='$strsm3' AND id_organization='$idORG'");
		$phselectedFLD = $phselected->fields["KphSel"];
		 if (empty($phselectedFLD)) { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
		 $totcountnrs = $phselectedFLD;
     	}
	if ($strsm == "CA") {
		if (!$strsm3E = $db->Execute("SELECT id,descrip FROM category WHERE id='$strsm2'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   		}
		$strsm3=$strsm3E->fields["id"];
		if (!$strsm3) { echo "<b>NUMBER NOT SELECTED. Error DEC7122</b>"; return FALSE;}
		$slclause = "idcateg";//  category ... WHERE CLAUSE IN DBsend.php
		$phselected = $db->Execute("SELECT COUNT(id_user) AS KphSel FROM userz WHERE idcateg='$strsm3' AND id_organization='$idORG'");
		$phselectedFLD = $phselected->fields["KphSel"];
		 if (empty($phselectedFLD)) { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
		 $totcountnrs = $phselectedFLD;
     	}
	if ($strsm == "CL") {
	  if (!$strsm3F = $db->Execute("SELECT id,descript FROM classf WHERE id='$strsm2'")) {
     	echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   		}
		$strsm3=$strsm3F->fields["id"];
		if (!$strsm3) { echo "<b>NUMBER NOT SELECTED. Error DEC7123</b>"; return FALSE;}
		$slclause = "idclasse";  // class ... WHERE CLAUSE IN DBsend.php
		$phselected = $db->Execute("SELECT COUNT(id_user) AS KphSel FROM userz WHERE idclasse='$strsm3' AND id_organization='$idORG'");
		$phselectedFLD = $phselected->fields["KphSel"];
		 if (empty($phselectedFLD)) { $thereisnr = "No"; } else { $thereisnr = "Yes"; }
		 $totcountnrs = $phselectedFLD;
     	}
		
// FOR TEST ONLY -----------------------------------------------
//echo "&nbsp;<li type='square'> || SMSELxx =".$smsel."</li><br>";
//echo "&nbsp;<li type='square'> || STRSMxx =".$strsm."</li><br>";
//echo "&nbsp;<li type='square'> || Totale Numerixx =".$totcountnrs."</li><br>";
//--------------------------------------------------------------
	if ($strsm == "") {
	echo ("<table class=\"notice\" width=\"100%\"><tr><td><div align=\"center\"><b><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"4\" color=\"#F8FB82\">Error: You must select a number! (D3F.150)</font></b></div></td></tr></table>");
     	}
	## Controllo che sia presente una lista di numeri, con la variabile '$thereisnr'...
	if ($thereisnr == "No") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td><div align='center'><b><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#ffffff'>YOU MUST SELECT A NUMBER FROM THE LIST !!!</font></b></div></td></tr></table>";
	  echo "<br><div align='center'><b><a href='ne_SMS.php?action=second_sendafter&id=".$smsid."'>BACK</a></b></div>";
      return FALSE;
	  break;
   		}
// FOR DATA-TEST ONLY !!! --------------------------------------------------------
//echo "<br><hr>";
//echo "<li type='square'>smselyyy = ".$smsel."</li>";
//echo "<li type='square'>strsm = ".$strsm."</li>";
//echo "<li type='square'>sms_numbers = ".$sms_numbers."</li>";
//echo "<li type='square'>smsgroupsel = ".$smsgroupsel."</li>";
//echo "<li type='square'>smsid = ".$smsid."</li>";
//echo "<li type='square'>stream = ".$stream."</li>";
//echo "<hr><br>";
// -----------------------------------------------------------------------------
if ($thereisnr == "Yes") {

if ($smsel != "automaticselecta") {
		include ("my_notAutomaticSelect.inc");
   			}
elseif ($smsel == "automaticselecta") {
		$remcheck = "7ikpd0kk100OOYLKWW++--778O9O9O8O7O6O5O4O3O2O1";
		include ("my_AutomaticSelect.inc");
   			}
	else {
		echo "<p class='body_of_evidence'>SINTAX PROGRAM ERROR (AB597):</p>";
		require("footer.inc.php");
		break;
   			}

include ("DBsend.php");



//					    ex (!checkcredits_numbers --------> or end if ($paolorem == "figo")
  } // end if ($thereisnr == "Yes..
  $totcountnrs2 = count($sms_numbers);
  if ($sms_numbers == "") { $totcountnrs2 = " <b>no-numbers!</b> "; }
  echo "<br><br><br><br>";
  echo "<p class='desc'>KSMS BULK SMS MANAGER";

  echo "&nbsp;&nbsp;&nbsp; <i>sending..ok...assiplan,PR</i></p>";
//  paint_select($db);
}    // end  function sendsms_confirmed
function paint_table($db) {
 	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
   	$summsms = $db->Execute("SELECT * FROM ksms WHERE id_organization='$idORG' ORDER BY sms_ins_date");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td>&nbsp;</td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Date</b></td>
		 <td><b>Title</b></td>
		 <td><b>Sms</b></td>
		 <td><b>Saved?</b></td>
		 <td><b>Sended?</b></td>
      </tr> <?php
      $i = 1;
      while (!$summsms->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } 
		$summid = $summsms->fields["id"];
		$sumtitle = urlencode($summsms->fields["sms_title"]);
	?> 
            <td>
            <a href="ne_SMS.php?action=edit&id=<?php echo $summid; ?>&title=<?php echo $sumtitle; ?>"><?php echo $summid; ?></a>
			</td>
			 <td><?php echo $summsms->fields["sms_ins_date"]; ?></td>
            <td> 
			<a href="ne_SMS.php?action=edit&id=<?php echo $summid; ?>&title=<?php echo $sumtitle; ?>"><b><?php echo $summsms->fields["sms_title"]; ?></b></a>
			</td>
 		 	 <td><b>
			 <?php 
 // ############# str_pad($Sms_text, 10) ###################
	$txtsms=$summsms->fields["sms_text"];
 	if (strlen($txtsms) > 49) { $dotx = "..."; }
			 echo substr($txtsms, 0, 49).$dotx; ?></b>
			 </td>
			 <td> <b><?php echo $summsms->fields["sms_saved"]; ?></b></td>
			 <td> <b><?php echo $summsms->fields["sms_sended"]; ?></b></td>
         </tr> <?php
         $i++;
         $summsms->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_SMS.php?action=addksms">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Aggiungi Messaggio">
			   </a></div></td>
      </tr>
   </table>

 <?php
} //    chiudi function paint_table($db)
		$cfgg = $db->Execute("SELECT id_config, project_name FROM config");
		$projname = $cfgg->fields["project_name"];
		$projectnm = strtolower ($projname);
		if ($projectnm == "ksms") { $proj = "APPROVED"; }
		if ($projectnm == "keysms") { $proj = "APPROVED"; }
		if ($proj != "APPROVED") { 
					echo "<p class='cell_of_evidence'><font color='#F2F7FF'>";
					echo "...ERROR 7295 (error use project) </font></p>";
					include("footer2.inc.php");
					break; 
							}
	// user : only  4 - 5 - 6 -7
if ($priv > 2) {
	$company = $_SESSION["company"];
   	$action = strtolower($action);
   switch ($action) {
   	  case "abortsect":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operazione aborted.</td></tr></table><br>";
			//paint_table($db);
			$id="";
			$sms_text="";
			$sms_ins_date="";
			paint_select($db);
         break;
	   case "addksms":
            display_form($db);
            break;
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The ksms number $id was successfully added!.</td></tr></table>";
		  select_options($db, $id);
         break;
      case "sendafter":
         echo "<table class=\"news\" width=\"100%\"><tr><td><div align='center'><b>Message sending...-".$id."</b></div></td></tr></table><br>";
		  select_options($db, $id);
         break;
	  case "second_sendafter":
         echo "<table class=\"news\" width=\"100%\"><tr><td><div align='center'><b>Message sending... (another time).</b></div></td></tr></table><br>";
		  select_options($db, $id);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  paint_table($db);
         break;
	  case "delete":
	  	$idORGAN = $_SESSION["id_company"];
          if (!$db->Execute("DELETE FROM ksms WHERE id='$uid' AND id_organization='$idORGAN'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>ksms $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
      case "create":
		 if ($sms_text == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a message!</td></tr></table>";
            display_form($db);
            break;
         }
         $sms_number = $db->GenID("ksms_seq");
		 $sms_title = addslash_text($sms_title);
		 $sms_text = addslash_text($sms_text);
		 $sms_note = addslash_text($sms_note);
		 $idORG = $_SESSION["id_company"];
		 // id | sms_ins_date | organization | id_organization | sms_title            | sms_text                                                         | sms_note | sms_saved |

         $query = "INSERT INTO ksms (intid, sms_ins_date, organization, id_organization, sms_title, sms_text, sms_note, sms_saved)"
                . " VALUES ('$sms_number', '$sms_ins_date', '$organization', '$idORG', '$sms_title', '$sms_text', '$sms_note', 'Y')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_SMS.php?action=inkey&id=<?php echo $sms_number; ?>";
         </script> <?php
         break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the ksms.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $sms_title = addslash_text($sms_title);
		 $sms_text = addslash_text($sms_text);
		 $sms_note = addslash_text($sms_note);
         $query = "UPDATE ksms SET"
                . " sms_ins_date='$sms_ins_date', sms_title='$sms_title', sms_text='$sms_text', sms_note='$sms_note'"
                 . " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php");?>
         <script language="JavaScript">
            window.location="ne_SMS.php?action=sendafter&id=<?php echo $id; ?>";
         </script> <?php
         break;
	  case "edit":
	  	$idORG = $_SESSION["id_company"];
	  	$ed_ksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'");
		$Ksms_sended = $ed_ksms->fields["sms_sended"];
	  	if ($Ksms_sended == "Y") { select_options($db, $id); }
		else { edit_sms_form($db, $id); }
		 	break;
	  case "send_ksms":
	  	$company = $_SESSION["company"];
		$idORG = $_SESSION["id_company"];
		//  $sendksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'");
		if ($id == "") {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Error:ID not found!</td></tr></table>";
            paint_table($db);
            break;
         	}
   		if (!$sendksms = $db->Execute("SELECT * FROM ksms WHERE id='$id' AND id_organization='$idORG'")) {
      	 echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
			paint_table($db);
      		break;
   			}
		if ($sendksms->fields["sms_text"] == "") {
    	 echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            paint_table($db);
            break;
         		}
			$smopt = "";
			$smsid = $sendksms->fields["id"];
			paint_table_numbers_select($db, $smsid, $smopt);
		break;
	case "manualselect":
		$smopt = "manual";
			//paint_table_numbers_select($db, $smsid, $smopt);
			paint_table_manual_select($db, $smsid, $smopt);
		break;
		case "automaticselect":
		$smopt = "auto";
			################### ATTIVA CHECK SMSC ###############################
			//	  	check_smsc($db);
			if ($okk == "N") {
         	echo "<table class=\"notice\" width=\"100%\"><tr><td><div align=\"center\"><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"3\" color=\"#ffffff\"><b>Error</b>: sending...impossible....</font></div></td></tr></table>";
            //paint_table($db);
            break;
         		}
			$smsel = "automaticselecta";
			# $stream  ===>  GROUP - CLASS or CATEGORY WITH "id" (CL5)
			sendsms_confirmed($db,$smsel,$sms_numbers,$smsgroupsel,$smsid,$stream);
			//paint_table_autom_select($db, $smsid, $smopt);
		break;
		
		
		
		
		
	case "finalsend":
	   # Check the radio buttons.
		if ($smsgroupsel == "") {
		echo "<p class='tbl_error'>";
		echo "Error</b>:&nbsp;&nbsp;&nbsp;Please select a message ina :<br>";
		echo "GROUP, CATEGORY, CLASS OR SINGLE SELECTION";
		echo "</p>";
            paint_table($db);
            break;
         		}
  if ($smsgroupsel == "ksms_SingleSelector") { 
		if ($sms_numbers == "") {
		echo ("<p class='tbl_error'>");
		echo ("Error::: please select the numbers</p>");
            break;
     			}
	$smsel = "SingleMessagesSelected";
	     }
$idORG = $_SESSION["id_company"];
	  	check_smsc($db);
	if ($okk == "N") {
         echo "<table class=\"notice\" width=\"100%\"><tr><td><div align=\"center\"><font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"3\" color=\"#ffffff\"><b>Errore</b>:il sistema � temporanemanete in manutenzione. Ti preghiamo di avvisare un tecnico!</font></div></td></tr></table>";
            //paint_table($db);
            break;
         		}
	$smsel = "";
	$stream = "";
	sendsms_confirmed($db,$smsel,$sms_numbers,$smsgroupsel,$smsid,$stream);
		break;
	  case "sendgsmmex":
	  	echo "<table class=\"news\" width=\"100%\"><tr><td>Seleziona un messaggio da spedire</td></tr></table>";
         paint_select($db);
		 	break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
