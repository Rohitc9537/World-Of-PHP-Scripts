<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/


$title = "Category Management";
require("common.inc.php"); 
?>

<?php
function edit_cat_form($db, $id) {
	$priv = $_SESSION["priv"];
   	$cats = $db->Execute("SELECT id, descrip, ins_date FROM category WHERE id='$id'"); 
   global $id, $descrip, $ins_date;
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Number or category.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$cats = $db->Execute("SELECT id, descrip, ins_date FROM category WHERE id='$id'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($cats->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Category not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   	if ($priv > 5) {
  ?>
  
<table class="default" align="center" border="1" cellspacing="0" cellpadding="0">
      <form name="form2" method="post" action="ed_cat.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>CATEGORY MOD</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Num.:</td>
            <td colspan="3"> <?php echo $cats->fields["id"]; ?> </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Insert Date:</td>
            <td colspan="3"><?php echo $cats->fields["ins_date"]; ?> </td>
		 </tr>
			<tr class="row_even">
            <td nowrap align="right">Description:</td>
            <td colspan="3"><input type="text" name="descrip" size="40" value="<?php echo $cats->fields["descrip"]; ?>"> </td>
         </tr>		
		 <tr class="row_foot"> 
            <td colspan="4" nowrap><div align="center">
               <img src="images/pub/bt_update.gif" border="0" alt="Modifica"
                  onClick="document.form2.submit();">
               <a href="ed_cat.php?action=Abort">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Elimina - Delete <?php echo $id; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this category Nr.<?php echo $id; ?> - [ <?php echo $cats->fields["descrip"]; ?> ] ?')) { window.location='ed_cat.php?action=delete&uid=<?php echo $id; ?>'; }"></div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.form2.descrip.focus();
   </script> 
 <?php
 	} // end if priv >5
	   echo "<table class=\"notice\" width=\"100%\"><tr><td><b>Operation not allowed!.</b></td></tr><tr><td>You can only add and not modify the categories!</td></tr></table>";
} // end function
 ?>  



<?php
function paint_table($db) { 
   $summcat = $db->Execute("SELECT * FROM category ORDER BY descrip");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td>&nbsp;</td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Description</b></td>
      </tr> <?php
      $i = 1;
      while (!$summcat->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
            <td>

               <a href="ed_cat.php?action=edit&description=<?php echo $summcat->fields["descrip"]; ?>&id=<?php echo $summcat->fields["id"]; ?>">
                  <?php echo $i //$summcat->fields["id"]; ?></a>
            </td>
            <td> <a href="ed_cat.php?action=edit&description=<?php echo $summcat->fields["descrip"]; ?>&id=<?php echo $summcat->fields["id"]; ?>"><b><?php echo $summcat->fields["descrip"]; ?></b></a>
			</td>
         </tr> <?php
         $i++;
         $summcat->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="new_cat.php">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Add Category">
					</div>
		 </td>
      </tr>
   </table>

 <?php
} ?>

<?php
if ($priv > 5) {
   $action = strtolower($action);
   switch ($action) {
      case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation Aborted!</td></tr></table><br>";
			paint_table($db);
         break;
	  case "delete":
          if (!$db->Execute("DELETE FROM category WHERE id='$uid'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Category $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
	  case "edit":
         edit_cat_form($db, $id);
		 	break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the category.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $descrip = addslash_text($descrip);
         $query = "UPDATE category SET"
                . " descrip='$descrip'"
                 . " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ed_cat.php";
         </script> <?php
         break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
