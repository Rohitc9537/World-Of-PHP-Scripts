<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// gestione gruppi :::
$title = "Gestione Gruppi";
require("common.inc.php"); 
?>

<?php
function edit_group_form($db, $id) {
   global $groups, $id, $descrip, $ins_date;
   $groups = $db->Execute("SELECT id, descrip, ins_date FROM groups WHERE id='$id'");
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Number or groups.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$groups = $db->Execute("SELECT id, descrip, ins_date FROM groups WHERE id='$id'")) {
     echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($groups->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>groups not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
 }
 	$description = $groups->fields["descrip"];
	$description = view_text_specialchars($description);
  ?>
  
<table class="default" align="center" border="0" cellspacing="0" cellpadding="0">
      <form name="form1a" method="post" action="ne_groups.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>GROUPS MODIFY AREA</b>&nbsp; 
			<font size="-1">(cod. <?php echo $groups->fields["id"]; ?>)</font>
			</td>
         </tr>
	  <tr class="row_even"> 
            <td colspan="2" nowrap><b>Data not shared!</b></td>
         </tr>		 
         <tr class="row_even"> 
            <td nowrap align="right">Date : &nbsp;</td>
            <td><?php echo $groups->fields["ins_date"]; ?>&nbsp;</td>
		</tr>
		<tr class="row_even">
            <td nowrap align="right">
			Descrizione : &nbsp;
			</td>
      		<td>
			<input type="text" name="descrip" size="40" value="<?php echo ("$description"); ?>"> &nbsp;
			</td>
         </tr>		
		 <tr class="row_foot"> 
            <td colspan="2" nowrap><div align="center">
               <img src="images/pub/bt_update.gif" border="0" alt="Modifica"
                  onClick="document.form1a.submit();">
               <a href="ne_groups.php?action=Abort">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Elimina - Delete <?php echo $id; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this groups Nr.<?php echo $id; ?> - <?php echo $groups->fields["descrip"]; ?>  ?')) { window.location='ne_groups.php?action=delete&uid=<?php echo $id; ?>'; }"></div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.form1a.descrip.focus();
   </script> 
 <?php
} 
 ?>

<?php
// ADD _ INSERT
function display_form($db) {
$company = $_SESSION["company"];
$idORG = $_SESSION["id_company"];
?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
       <tr class="row_head"> 
         <td><b></b></td>
         <td align="right">Data not shared!</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
   <form action="ne_groups.php" method="post" name="form2">	   
       <tr class="row_even"> 
         <td align="right">Insert Date:</td>
         <td>
           <?php echo date("Y-m-d"); ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Group Description:</td>
         <td>
			<input type="text" name="descrip" size="40" value="">
         </td>
       </tr>
       <tr class="row_foot"> 
         <td colspan="2"> <div align="center">
            <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
               onClick="document.form2.submit();">
            <a href="ne_groups.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
	 <input type="hidden" name="idORG" value="<?php echo ("$idORG"); ?>">
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.form2.descrip.focus();
   </script> <?php
} ?>

<?php
function paint_table($db) {
	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
   	$summgrp = $db->Execute("SELECT * FROM groups WHERE id_organization='$idORG' ORDER BY descrip");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td><?php echo ("$company"); ?> -  data:<?php echo date("Y-m-d"); ?></td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Description</b></td>
      </tr> <?php
      $i = 1;
      while (!$summgrp->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
            <td>

               <a href="ne_groups.php?action=edit&id=<?php echo $summgrp->fields["id"]; ?>&description=<?php echo $summgrp->fields["descrip"]; ?>">
                  <?php echo $i //$summgrp->fields["id"]; ?></a>
            </td>
            <td> <a href="ne_groups.php?action=edit&id=<?php echo $summgrp->fields["id"]; ?>&description=<?php echo $summgrp->fields["descrip"]; ?>"><b><?php echo $summgrp->fields["descrip"]; ?></b></a>
			</td>
         </tr> <?php
         $i++;
         $summgrp->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_groups.php?action=addgrp">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Aggiungi Gruppo">
			   </a></div></td>
      </tr>
   </table>

 <?php
} ?>


<?php
if ($priv > 3) {
   $action = strtolower($action);
   switch ($action) {
   	  case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted.</td></tr></table><br>";
			paint_table($db);
         break;
	   case "addgrp":
            display_form($db);
            break;
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The groups number $id was successfully added!.</td></tr></table>";
		  paint_table($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  display_form($db);
         break;
	  case "delete":
          if (!$db->Execute("DELETE FROM groups WHERE id='$uid'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>groups $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
      case "create":
		 if ($descrip == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description for this groups!</td></tr></table>";
            display_form($db);
            break;
         }
         $cat_number = $db->GenID("groups_seq");
		 $descrip = addslash_text($descrip);
         $query = "INSERT INTO groups (intid, ins_date, descrip, organization, id_organization)"
                . " VALUES ('$cat_number', '$date', '$descrip', '$company', '$idORG')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_groups.php?action=inkey&id=<?php echo $cat_number; ?>";
         </script> <?php
         break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the groups.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $descrip = addslash_text($descrip);
         $query = "UPDATE groups SET"
                . " descrip='$descrip'"
                 . " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_groups.php";
         </script> <?php
         break;
	  case "edit":
         edit_group_form($db, $id);
		 	break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
