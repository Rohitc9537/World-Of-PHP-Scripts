<?PHP
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
// newpart.php


// 
// ----- START HERE  ----
### $aokk == "OK_CRsupNR" --> credits > of selected numbers

$numbersselected = $db->Execute("SELECT COUNT(*) AS totnumbselect FROM sendgatenumbs WHERE id_organization='$idORG' AND sms_id='$smsID' AND ref='$refer'");
$totnri = $numbersselected->fields["totnumbselect"];
// testing --------------------------------------------------------------------
//	echo "<p class='body_of_evidence'>&mdash;&mdash;&raquo; 
//		<font size='+1'>".$totnri."</font> NUMBER(S) SELECTED!</p>";
// /testing --------------------------------------------------------------------
 if ($totcountnrs != $totnri) {
 	echo "<br><p class='texto_of_evidence'>There is some errors in credits checker (ERROR 69584E)</p>";
	include("footer2.inc.php");
	exit; }
////////// CHECK THE CREDITS FOR ANOTHER TIME !!! ///////////////////////////////////////////////
		$idORG = $_SESSION["id_company"];
		$credstok = "NOTdef";
// testing...
		//echo "<b>Totale numeri che hai da spedire : ".$totcountnrs."</b><br>";
		//echo "<b>Id dell'organizzazione che spedisce : ".$idORG."</b><br>";
		 if (!$orgsel3E = $db->Execute("SELECT * FROM credits_manager WHERE id_orgz='$idORG'")) {
			echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
			$credstok = "NO";
	      		include("footer2.inc.php");
				exit();
   				}
		$conxx = $orgsel3E->fields["connext_type"];
		$cred_val = $orgsel3E->fields["credits_sale_value"];
		$kstot = $orgsel3E->fields["smscredits_totalsum"];
		$ksrem = $orgsel3E->fields["smscredits_remain"];
		$kntot = $orgsel3E->fields["nrsms_totalsum"];
		$knrem = $orgsel3E->fields["nrsms_remain"];
		$cr_ac = $orgsel3E->fields["credit_activated"];
	if ($cr_ac == "Y") {
		$credstok = "YnotY";
		if ($conxx == "fee") { 
			$cust_credsrem = $ksrem; 
			$custcred_value = $cred_val;
			  }
		 else if ($conxx == "oto") {
		 	$cust_credsrem = $knrem;
		 	$custcred_value = 1;
		 	   }
		 else $cust_credsrem = 0;
		$totcountnrs=$totnri;
		$totcountnrs_it = number_format($totcountnrs, 0, ',', '.'); // italian format numbers!!!
		$cust_credsrem_it = number_format($cust_credsrem, 0, ',', '.'); // Formato italiano (0 decim.)
		// testing --------------------------------------------------------------------
//	echo "<p class='body_of_evidence_Red'>&mdash;&mdash;&raquo; 
//		<font size='+1'>".$totcountnrs_it."</font> NUMBER(S) SELECTED!</p>";
//	echo "<p class='body_of_evidence_Red'>&mdash;&mdash;&raquo; 
//		<font size='+1'>".$cust_credsrem_it."</font> ACTUAL CREDIT(S)!</p><br>";
// /testing --------------------------------------------------------------------
	  if ($cust_credsrem <= 0) {
			$credstok = "NO";
			echo "<table class=\"notice\" width=\"100%\"><tr><td><div align='center'><b><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#ffffff'>YOU DON'T HAVE ENOUGH CREDITS!</font></b></div></td></tr></table>";
			$credstok = "NO";
	      		include("footer2.inc.php");
				exit();
			     }
	  if(!empty($cust_credsrem)) {
	   $credstok = "NOTempty";
	  	if ($cust_credsrem < $totcountnrs) {        ### credito inferiore ai numeri selezionati
		$credstok = "NO";
		  echo "<br>";
		  echo "<table class='foottbl'><tr><td>
			Attenzione :  You do not have enough credits in order to send all the messages !!!
			</td></tr></table>";
			$credstok = "NO";
	      		include("footer2.inc.php");
				exit();
			     }
	// credito superiore (OK) ai numeri selezionati
		 if ($cust_credsrem >= $totcountnrs) {
		echo "<table class='foottbl'><tr><td><b>".$totcountnrs_it." </b>
			Your message is on the queue and waiting to be send @  <b>".$totnri."</b> numbers....
			</td></tr></table>";
			$credstok = "YESOK";
			}
	  }  //	  end  if(!empty($cust_credsrem))
 } // end if ($cr_ac == "Y"...
  else { echo "<br><b>".$klang_err['sendsms_user_notactivated']."</b><br>"; 
			$credstok = "NO";
	      		include("footer2.inc.php");
				exit();
		}
///////end CHECK THE CREDITS FOR ANOTHER TIME !!! ///////////////////////////////////////////////
if ($credstok == "YESOK") {
$credstok2 = "ok_to_send";
// TESTING
 echo "<p class='texto_of_evidence'><b>".$totcountnrs_it." </b> credits Are ".$credstok2."&copy;</p>";
	$aokk = "OK_CRsupNR";
	} else {
	echo "<table class='foottbl'><tr><td><div align='center'>";
	echo "You do not have enough credits in order to send this message !!!(".$credstok.")";
	echo "</b></div></td></tr></table>";
	      		include("footer2.inc.php");
				exit();
	}
if ($aokk == "OK_CRsupNR") {
$priv = $_SESSION["priv"];
// testing
//echo("<br><table bgcolor='#F7EC2B'><tr><td>PRIVILEGES: ".$priv."</td></tr></table><br>");

	// if ($priv > 40) {
   if ($priv > 4) {
	$idORG = $_SESSION["id_company"];
	$smorg2 = $db->Execute("SELECT id, username, priv, txt_head_sender, auth_adm FROM organization WHERE id='$idORG'");
	$tx_head = $smorg2->fields["txt_head_sender"];
	$mobile_sender = $tx_head; // text alternative to display a sender's number
	$KuidOrg = $smorg2->fields["id"]; 		// id organization
	$Kauth = $smorg2->fields["auth_adm"]; 	// There is auth to send message?
	$gwconnects = $db->Execute("SELECT gwprovider.UCPPath, gwprovider.UCPinterface, gwprovider.EMIuser, gwprovider.EMIpass, gwprovider.bareboxIP, gwprovider.KanlSmsPort FROM gwprovider LEFT JOIN organization ON gwprovider.id=organization.id_gwprovider WHERE organization.id='$idORG';");
	$UCP_Path = $gwconnects->fields["UCPPath"]; // e.g.: "/usr/sbin/local"
	$UCP_Intf = $gwconnects->fields["UCPinterface"];
	$sms_sender = "";			// the stamp ... if you wanna, in every sended message
	$grp_code = $strsm;			// group or clas or category selected
	if ($Kauth == "Y")
	{
 //	$msg_flash = $_POST[msg_flash];
	// FLASH MESSAGE IS NOT IMPLEMENTED AT THIS MOMENT
		$msg_flash = "off";
	// echo "<br><br>----->IS IT A KANNEL ROUTINE ???".$UCP_Intf." <<<<<---------<br><br>";
	if ($Kmessage AND $UCP_Intf=="kannel")
  {
	    $sms_type = "text";
	    if ($msg_flash == "on")
	    {
		$sms_type = "flash";
	    }
  // echo("<table bgcolor='#F7EC2B' border='0'><tr><td>send_data REF. = ".$refer."</td></tr></table>");
	// Send a message in unicode format (http://www.unicode.org) ---> future implementation!!!
		$unicode = "0";
	      // if ($msg_unicode == "on")
	      // {
		  // $unicode = "1";
	      // }
			// $sms_msg = utf8_to_unicode($sms_msg);
		$cfgg = $db->Execute("SELECT id_config, project_name, prgmURL FROM config");
			$www_source = "http://".$_SERVER['SERVER_ADDR'];
			$cfgid = $cfgg->fields["id_config"];
			$rel_URL = $cfgg->fields["prgmURL"];
			$KsmsURL = $www_source."/".$rel_URL;
			$idORG = $_SESSION["id_company"];
			$projname = $cfgg->fields["project_name"];
		// Seleziono tutti i nr. di un cliente (organization)  che non sono ancora stati inviati!!!
		$sendsmsk2 = $db->Execute("SELECT * FROM sendgatenumbs WHERE sended='N' AND mailed='N'  AND ref='$refer' AND id_organization='$idORG' LIMIT $totcountnrs");
		$sendsmsk2b = $db->Execute("SELECT id_sendgate_data,id_gateway_provider,id_sms,sms_text,internal_id_mex,txt_head_sender FROM sendgate_data WHERE tpl_sended='N' AND id_organization='$idORG' AND ref='$refer'");
			$sms_id = $sendsmsk2b->fields["id_sms"]; // ID sms 
			$sms_message = $sendsmsk2b->fields["sms_text"]; // the message
			//$intl_sms_id = $sendsmsk2->fields["id_sms"]; // ID ... internal id
			$sms_head = $sendsmsk2->fields["txt_head_sender"]; // sender
			$sms_myID = $sendsmsk2->fields["id_sendgatenumbs"];
		//	$senddataS = $db->Execute("SELECT * FROM sendgatenumbs WHERE sended='NO' AND id_organization='$idORG'");
	if ($sms_myID == "") {
			echo "<p class='cell_of_evidence'><font color='#F2F7FF'>...ERROR 7245 = NUMBERS NOT FOUND...</font></p>";
			include("footer2.inc.php");
			break;
		}
		$projectnm = strtolower ($projname);
		if ($projectnm == "ksms") { $proj = "APPROVED"; }
		if ($projectnm == "keysms") { $proj = "APPROVED"; }
	if ($proj != "APPROVED") {
			echo "<p class='cell_of_evidence'><font color='#F2F7FF'>ERROR 7296 (error in using this project) </font></p>";
			include("footer2.inc.php");
			break;
		}

## Richiesta la pagina dedicata all'invio a KANNELL
	include("KsmsNsend.php");
echo <<<END
<br>
<table cellspacing="0" cellpadding="0" border="0" align="center">
<tr>
    <td align="left"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1">Testo:</font></td>
</tr>
<tr class="row_mex">
    <td>$Kmessage</td>
</tr>
</table>
<br>
END;
// TESTING .................................................
// echo "<p class='testing'>Type of the connection : ".$conxx."</p>";
// echo "<p class='testing'>Credits removal : ".$custcred_value."</p>";
// end TESTING .............................................
echo "<br><br>";
## WHILE... 
	$i = 1;
	while (!$sendsmsk2->EOF)
			{
		//$EMI_User = $gwconnects->fields["EMIuser"];
		//$EMI_Pass = $gwconnects->fields["EMIpass"];
			$id_sendgtnr_logs = $sendsmsk2->fields["id_sendgatenumbs"]; // ID in "sendgatenumbs" table!
			$smslog_id = $id_sendgtnr_logs;
			$Kprenr = $sendsmsk2->fields["mobile_prenumber"];
			$Kphnr = $sendsmsk2->fields["mobile_phone_number"];
			//   $Kucountry = $smsuser->fields["country_code"];
			$Kucountry = $sendsmsk2->fields["mob_countrycode"];
			$ksmsuid = $sendsmsk2->fields["id_user"]; // User ID from "sendgatenumbs" table
			$userid = $ksmsuid;
			$sms_to = $Kucountry.$Kprenr.$Kphnr;

### Add a "+" sign before every phone_numbers!
	$sms_to = '+'.$sms_to;
# Call to a gw_send_sms function (in KsmsNsend.php).
			// LIMIT = $totcountnrs
			// ref='$refer'
list($okj,$errsmess,$sendtomyserver)=gw_send_sms($db,$gwconnects,$sms_message,$mobile_sender,$sms_to,$smslog_id,$KuidOrg,$sms_type,$KsmsURL,$userid,$sms_id,$refer,$Kmessage);
    			$i++;
         		$sendsmsk2->MoveNext();
      		} // end while (!$sendsmsk2->EOF)
// ##################### end WHILE Numeri Tel in sendgatenumbs ###############################
	if (!$okj) 
	  {
	  	echo "<table class='errtbl' align='center'><tr><td>";
		echo "ERROR NA71545 (gate-non autorizzato) !!!";
		echo "</b></td></tr></table>";
		}
			
	  } // end if if ($Kmessage AND
	
	if (!$okj)
 			{
	  	echo "<table class='errtbl' align='center'><tr><td>";
		echo "ERROR NE69377 (".$errsmess.") !!!";
		echo "</b></td></tr></table>";
		}
//echo "<p class='body_of_evidence_Red'>OKj= ".$okj."-- StoMyS= ".$sendtomyserver."</p>";

		if ($okj AND $sendtomyserver)
			{

echo "<br>";
echo "<p class='noticeadvance'>";
echo "<br><b>MESSAGE SENDED!!!</b>";
echo "<br>";
echo "Every message are send to mobile!";
echo "</p>";

	### TESTING...
//	echo "<br><p class='testing'>TEST DELIVERED VARIABLES IN newpart</p>";
//	echo "<p class='testing'>[DB ] ".$db."</p>";
//	echo "<p class='testing'>[USERID] ".$userid."</p>";
//	echo "<p class='testing'>[ID_ORG] ".$KuidOrg."</p>";
//	echo "<p class='testing'>[CONN.TYPE] ".$conxx."</p>";
//	echo "<p class='testing'>[CREDS_VALUE] ".$custcred_value."</p>";
//	echo "<p class='testing'>[TOT_MESSAGES] ".$totcountnrs."</p>";
//	echo "<p class='testing'>......Now I'm Updating the Credits Database.........</p>";
	### end TESTING ...
// UPDATE CREDITS MANAGER THROUGH THE FUNCTION @  "functions.php"
 creditsupdt($db,$conxx,$custcred_value,$KuidOrg,$totcountnrs);
echo "<div align='center'>";
echo "Page loaded in";
$load = microtime();
print (number_format($load,2));
echo "seconds.";
echo "</div>";
### invio di una email di conferma
$mailsendtest = "N";
$mailsel = "SMSsended";
	sendmailtoServer($db,$refer,$smsid,$mailsendtest,$mailsel);
			} //   end ($okj AND $sendtomyserver)
		else {
		$mailsendtest="ERR01";
		$mailsel = "kerror";
		sendmailtoServer($db,$refer,$smsid,$mailsendtest,$mailsel);
			}
  } // end if ($Kauth ==....
		else
			{
	echo "<br>";
	echo "<table align='center' bgcolor='#4A3FD8' cellspacing='2' cellpadding='2' border='0'><tr>";
    echo "<td><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#F7EC2B'><b>(eng) You are not allowed to send SMS, please contact the administrator!</b></font></td>";
	echo "</tr></table>";
	echo "<br>";
			}

 	} // 	END	if ($priv > 4)
	elseif ($priv == 2)
			{
	echo "<br>";
	echo "<table align='center' bgcolor='#4A3FD8' cellspacing='2' cellpadding='2' border='0'><tr>";
    echo "<td><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#F7EC2B'><b>This is only an example. For sending a message you must buy our special packets!</b></font></td>";
	echo "</td></tr><tr>";
  	echo "<td><font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#F7EC2B'><b>THIS IS ONLY AN EXAMPLE_TEST! (KSMS=V$priv6)</b></font></td>";
	echo "</tr></table>";
	echo "<br>";
			} // end priv=2
	// else
	 elseif ($priv < 5)
	 // elseif ($priv < 6)
	{
		echo "<br>";
		echo "<table align='center' bgcolor='#D8E2DA' width='600' cellspacing='2' cellpadding='2' border='0'>";
		echo "<tr><td>";
		echo "<font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#D31238'><b>The selected message is not send. +".$priv."6</b></font>";
		echo "</td></tr>";
		echo "<tr><td>";
		echo "<font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"1\" color=\"#400000\">You can only send a message in email because your account is a test.</font>";
		echo "</td></tr>";
		echo "<tr><td>";
		echo "<font face=\"Verdana,Geneva,Arial,Helvetica,sans-serif\" size=\"1\" color=\"#400000\"><b>If you want to buy our sms-packets, please send us an email with your data!</b></font>";
		echo "</td></tr>";
		echo "</table>";
		echo "<br>";
		$mailsendtest = "Y";
		$mailsel = "onlymailtest";
	sendmailtoServer($db,$refer,$smsid,$mailsendtest,$mailsel);
		echo "<br>";
		echo "<table align='center' bgcolor='#ff9900' width='600' cellspacing='2' cellpadding='2' border='0'>";
		echo "<tr><td>";
		echo "<font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='2' color='#ffffcc'><b>CONFIRM: the message are send to an email address. You can close this page</b></font>";
		echo "</td></tr>";
		echo "</table>";
		
		}
 }   // end if ($aokk == "OK_CRsupNR2")
 	else {
			echo "<br><table align='center' bgcolor='#ff6600' width='800' cellspacing='2' cellpadding='2' border='0'>";
			echo "<tr><td>";
			echo "<font face='Verdana,Geneva,Arial,Helvetica,sans-serif' size='3' color='#ffffff'><b>You do not have enough credits in order to send this message!!!</b></font>";
			echo "</td></tr></table>";
	}


?>