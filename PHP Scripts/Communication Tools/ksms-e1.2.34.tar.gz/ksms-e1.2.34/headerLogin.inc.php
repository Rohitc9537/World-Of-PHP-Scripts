<?PHP
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

?>
<html>
<head>

	<script language="JavaScript1.2" src="kSmsvalidation.js"></script>
	<link href="kSms-style.css" rel="stylesheet" type="text/css">
<title>Ksms - The sms services by Computel Group Italia</title>
<meta name="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" content="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="Mon, 28 Aug 2000 16:20:18 GMT">
</head>
<body class="Ksmsman">

<?php
// echo ($urlB);
// $priv = $_SESSION["priv"];
if (isset($username)) { ?>
   <table class="default" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_even">
         <td>&nbsp;&nbsp;Welcome <?php echo $company; ?></td>
         <td align="right"> <?php
            if ($priv == 69) { ?>
               <a href="admin.php"><img src="images/admin_btn.gif" alt="Administration" border="0"></a> <?php
            } ?>
            <a href="logout.php"><img src="images/logout_btn.gif" alt="Logout" border="0"></a>
         </td>
      </tr>
   </table> <?php
} ?>

