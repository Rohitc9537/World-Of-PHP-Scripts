<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

$title = "Gestione SMS home";
require("common.inc.php");
include("functions.php")
?>
<STYLE TYPE="text/css">
p, .p-rem, .p-list {
	margin-top: 0px; 
	margin-bottom:0px; 
	font-size:12px;
}
</STYLE>
<table align="center" height="182" width="780" cellspacing="2" cellpadding="2" border="0">
<tr>
    <td>
	<a href="http://www.viabazar.com/">
			<img src="images/logoKS.gif" alt="KSMS the sms system from Computel Group CGI" width="199" height="84" border="0">
    </a>
	</td>
    <td>&nbsp;</td>
    <td>
	<div align="right"><img src="images/base.gif" alt="programma by computel group italia" width="107" height="149" border="0"></div>
	</td>
</tr>
<tr>
    <td colspan="3">
	<hr>
	<p class="default"><?php echo $cfg["signature"]; ?></p>
	</td>
</tr>
<tr>
    <td height="182"><?php include("detector.php"); ?></td>
    <td>&nbsp;</td>
    <td>
	<table align="center" width="254" height="182" cellspacing="2" cellpadding="2" border="1" bordercolor="#000080">
<tr>
    <td>

		<table align="center" cellspacing="0" cellpadding="0" border="0" width="158" height="181">
<tr>
    <td rowspan="2"><img src="images/pub/intro2a.gif" alt="assiplan" width="38" height="158" border="0"></td>
    <td><img src="images/pub/intro2b.gif" alt="ksms sms gsm" width="143" height="54" border="0"></td>
</tr>
<tr>
    <td background="images/pub/intro2backg.gif" height="104" class="main_base">Click on the <b>MENU</b> button!</td>
</tr>
</table>
</td>
</tr>
</table>

	</td>
</tr>
<tr>
    <td colspan="3"><br></td>
</tr>
<tr>
    <td colspan="3"><hr></td>
</tr>
<tr>
    <td colspan="3">
	<p class="default">Welcome on the .... blah blah blah.</p>
	</td>
</tr>
</table>

<?php require("footer.inc.php"); ?>
