<script type="text/javascript">
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|	detector.php */


// this function gets the cookie, if it exists
function Get_Cookie( name ) {
	
	var start = document.cookie.indexOf( name + "=" );
	var len = start + name.length + 1;
	if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) )
	{
		return null;
	}
	if ( start == -1 ) return null;
	var end = document.cookie.indexOf( ";", len );
	if ( end == -1 ) end = document.cookie.length;
	return unescape( document.cookie.substring( len, end ) );
}

/*
only the first 2 parameters are required, the cookie name, the cookie
value. Cookie time is in milliseconds, so the below expires will make the 
number you pass in the Set_Cookie function call the number of days the cookie
lasts, if you want it to be hours or minutes, just get rid of 24 and 60.

Generally you don't need to worry about domain, path or secure for most applications
so unless you need that, leave those parameters blank in the function call.
*/
function Set_Cookie( name, value, expires, path, domain, secure ) {
	// set time, it's in milliseconds
	var today = new Date();
	today.setTime( today.getTime() );
	// if the expires variable is set, make the correct expires time, the
	// current script below will set it for x number of days, to make it
	// for hours, delete * 24, for minutes, delete * 60 * 24
	if ( expires )
	{
		expires = expires * 1000 * 60 * 60 * 24;
	}
	//alert( 'today ' + today.toGMTString() );// this is for testing purpose only
	var expires_date = new Date( today.getTime() + (expires) );
	//alert('expires ' + expires_date.toGMTString());// this is for testing purposes only

	document.cookie = name + "=" +escape( value ) +
		( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) + //expires.toGMTString()
		( ( path ) ? ";path=" + path : "" ) + 
		( ( domain ) ? ";domain=" + domain : "" ) +
		( ( secure ) ? ";secure" : "" );
}

// this deletes the cookie when called
function Delete_Cookie( name, path, domain ) {
	if ( Get_Cookie( name ) ) document.cookie = name + "=" +
			( ( path ) ? ";path=" + path : "") +
			( ( domain ) ? ";domain=" + domain : "" ) +
			";expires=Thu, 01-Jan-1970 00:00:01 GMT";
}

/*
If your page is XHMTL 1 strict, you have to
put this code into a js library file or your
page will not validate
*/

function client_data(info)
{
	if (info == 'width')
	{
		width_height_html = '<p class="dect_bar2">Current Screen Resolution</p>';
		width = (screen.width) ? screen.width:'';
		height = (screen.height) ? screen.height:'';
		width_height_html += '<p class="dect_bar">' + width + " x " +
			height + " pixels</p>";
		(width && height) ? document.write(width_height_html):'';
	}
	else if (info == 'js' )
	{
		document.write('<p class="dect_bar">JavaScript is enabled (<b><font color="#339933">OK</font></b>).</p>');
	}
	else if ( info == 'cookies' )
	{
		expires ='';
		Set_Cookie( 'cookie_test', 'it_worked' , expires, '', '', '' );
		string = '<p class="dect_bar2">Cookies</p><p class="dect_bar">';
		if ( Get_Cookie( 'cookie_test' ) )
		{
			string += 'Cookies are enabled (<b><font color="#339933">OK</font></b>)</p>';
		}
		else {
			string += 'Cookies are disabled (<b><font color=#D31238>devi abilitare i cookie!</font></b>)</p>';
		}
		document.write( string );
	}
}
</script>
<div class="float-left-01">
<p class="box_title">Your are connected with :</p>
			<?php
			$os = '<p class="dect_bar2">Operating System:</p><p class="dect_bar">';
			$full = '';
			// change these two to match your include path/and file name you give the script
			include('detector_fll.php');
			$browser_info = browser_detection('full');
			
			$browser_info[] = browser_detection('moz_version');

			switch ($browser_info[5])
			{
				case 'win':
					$os .= 'Windows ';
					break;
				case 'nt':
					$os .= 'Windows<br />NT ';
					break;
				case 'lin':
					$os .= 'Linux<br /> ';
					break;
				case 'mac':
					$os .= 'Mac ';
					break;
				case 'unix':
					$os .= 'Unix<br />Version: ';
					break;
				default:
					$os .= $browser_info[5];
			}

			if ( $browser_info[5] == 'nt' )
			{
				if ($browser_info[6] == 5)
				{
					$os .= '5.0 (Windows 2000)';
				}
				elseif ($browser_info[6] == 5.1)
				{
					$os .= '5.1 (Windows XP)';
				}
			}
			elseif ( ( $browser_info[5] == 'mac' ) &&  ( $browser_info[6] >= 10 ) )
			{
				$os .=  'OS X';
			}
			elseif ( $browser_info[5] == 'lin' )
			{
				$os .= ( $browser_info[6] != '' ) ? 'Distro: ' . ucfirst ($browser_info[6] ) : 'Smart Move!!!';
			}
			elseif ( $browser_info[6] == '' )
			{
				$os .=  ' (version unknown)';
			}
			else
			{
				$os .=  strtoupper( $browser_info[6] );
			}

			$full .= $os . '</p><p class="dect_bar2">Current Browser:</p><p class="dect_bar">';
			if ($browser_info[0] == 'moz' )
			{
				$a_temp = $browser_info[count( $browser_info ) - 1];// the moz array is last item
				$full .= ($a_temp[0] != 'mozilla') ? 'Mozilla/ ' . ucfirst($a_temp[0]) . ' ' : ucfirst($a_temp[0]) . ' ';
				$full .= $a_temp[1] . '<br />';
				$full .= 'ProductSub: ';
				$full .= ( $a_temp[4] != '' ) ? $a_temp[4] . '<br />' : 'Not Available<br />';
				$full .= ($a_temp[0] != 'galeon')?'RV version: ' . $a_temp[3] : '';
			}
			elseif  ( $browser_info[0] == 'ns' )
			{
				$full .= 'Netscape ';
				$full .= $browser_info[1] . '<br />';
			}
			else
			{
				$full .= ($browser_info[0] == 'ie') ? strtoupper($browser_info[7]) : ucwords($browser_info[7]);
				$full .= ' ' . $browser_info[1];
			}
			echo $full . '</p>';
			?>
			<script type="text/javascript">
				client_data('width');
			</script>
			<p class="dect_bar2">JavaScript</p>
			<script type="text/javascript">
				client_data('js');
			</script>
			<noscript>
			<p class="dect_bar">JavaScript is disabled (<b><font color="#D31238">devi abilitare i JavaScript!</font></b>)</p>
			</noscript>
			<script type="text/javascript">
				client_data('cookies');
			</script>
	</div>