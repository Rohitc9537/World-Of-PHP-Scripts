<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

//  :::
$title = "Manager Prefix Mobile numbers";
require("common.inc.php"); 
?>

<?php
function edit_mobpre_form($db, $id) {
   global $mobilpre, $id, $prenumber;
   $priv = $_SESSION["priv"];
   $mobilpre = $db->Execute("SELECT * FROM mobile_pref WHERE id='$id'"); 
   if ($id == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Number or Mobile Pre Number.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$mobilpre = $db->Execute("SELECT * FROM mobile_pref WHERE id='$id'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($mobilpre->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Mobile Pre Number not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if ($priv > 5) {
  ?>
  
<table class="default" align="center" border="1" cellspacing="0" cellpadding="0" width="500">
      <form name="form1pre" method="post" action="ne_mob_pref.php">
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b><?PHP echo $title ?></b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">ID:</td>
            <td colspan="3"> <?php echo $mobilpre->fields["id"]; ?> </td>
         </tr>
         <tr class="row_even">
            <td nowrap align="right">Prefix:</td>
            <td colspan="3"><input type="text" name="prenumber" size="7" value="<?php echo $mobilpre->fields["prenumber"]; ?>"> </td>
         </tr> <!--
		 <tr class="row_even">
            <td nowrap align="right">Cost/sms (*):</td>
            <td colspan="3"><input type="text" name="gsm_provider_cost" size="7" value="<?php //echo $mobilpre->fields["gsm_provider_cost"]; ?>"> &nbsp;(3 decimal)</td>
         </tr> -->
		 <tr class="row_even">
            <td nowrap align="right">GSM Provider:</td>
            <td colspan="3"><input type="text" name="gsm_provider_name" size="7" value="<?php echo $mobilpre->fields["gsm_provider_name"]; ?>"> </td>
         </tr>
		 <tr class="td_warn">
		 <td colspan="4" nowrap><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#f3f3f3"><b>(*) ... in the future....cost per sms....</b></font></td>
			</tr>
		 <tr class="row_foot">
            <td colspan="4" nowrap><div align="center">
               <img src="images/pub/bt_update.gif" border="0" alt="Modifica"
                  onClick="document.form1pre.submit();">
               <a href="ne_mob_pref.php?action=Abort">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Elimina - Delete <?php echo $id; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this Pre Number<?php echo $id; ?> - [ <?php echo $mobilpre->fields["prenumber"]; ?> ] ?')) { window.location='ne_mob_pref.php?action=delete&uid=<?php echo $id; ?>'; }"></div>
            </td>
         </tr>
   	  <input type="hidden" name="id" value="<?php echo $id; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.form1pre.prenumber.focus();
   </script> 
 <?php
 	} // end if priv >5
	   echo "<table class=\"notice\" width=\"100%\"><tr><td><b>Operation not allowed.</b></td></tr><tr><td>You can't modify the prefix!</td></tr></table>";
} // end function
 ?>

<?php
function display_form($db) {
?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="500">
       <tr class="row_head"> 
         <td><b>New Pre Number for Mobile Telephones</b></td>
         <td align="right">PRE-NUMBER</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="500">
   <form action="ne_mob_pref.php" method="post" name="form2pre">	   
       <tr class="row_even"> 
         <td align="right">Insert Date:</td>
         <td>
           <?php echo date("Y-m-d"); ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Prefix:</td>
         <td>
			<input type="text" name="prenumber" size="5" value="">
         </td>
       </tr> <!--
	    <tr class="row_even">
            <td nowrap align="right">Cost/sms (*):</td>
            <td colspan="3"><input type="text" name="gsm_provider_cost" size="7" value="0.0940"> &nbsp;(3 decimal)</td>
         </tr> -->
		 <tr class="row_even">
            <td nowrap align="right">GSM Provider:</td>
            <td colspan="3"><input type="text" name="gsm_provider_name" size="7" value="<?php echo $mobilpre->fields["gsm_provider_name"]; ?>"> </td>
         </tr>
		 <tr class="td_warn">
		 <td colspan="2" nowrap><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#ffff00"><b>(*)...cost.....!</b></font></td>
			</tr>
       <tr class="row_foot">
         <td colspan="2"> <div align="center">
            <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
               onClick="document.form2pre.submit();">
            <a href="ne_mob_pref.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">  
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.form2pre.prenumber.focus();
   </script> <?php
} ?>

<?php
function paint_table($db) { 
   $summtelpre = $db->Execute("SELECT * FROM mobile_pref ORDER BY prenumber");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="500" align="center">
      <tr>
         <td>&nbsp;</td>
      </tr>
   </table>   
   <table class="small" border="0" cellspacing="0" cellpadding="1" width="500" align="center">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Pre Number</b></td>
		 <td><b>Provider (*)</b></td>
      </tr>
	  <?php
      $i = 1;
      while (!$summtelpre->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
            <td>

               <a href="ne_mob_pref.php?action=edit&prenumber=<?php echo $summtelpre->fields["prenumber"]; ?>&id=<?php echo $summtelpre->fields["id"]; ?>">
                  <?php echo $summtelpre->fields["id"]; ?></a>
            </td>
            <td> <a href="ne_mob_pref.php?action=edit&prenumber=<?php echo $summtelpre->fields["prenumber"]; ?>&id=<?php echo $summtelpre->fields["id"]; ?>"><b><?php echo $summtelpre->fields["prenumber"]; ?></b></a>
			</td>
			<td>
			    <b>  <?php echo $summtelpre->fields["gsm_provider_name"]; ?></b>
            </td>
         </tr> <?php
         $i++;
         $summtelpre->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="500" align="center">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_mob_pref.php?action=addptel">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Aggiungi Prefisso">
			   </a></div></td>
      </tr>
	  <tr class="row_grey"> 
         <td colspan="3"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#fbfeff">(*) not "Number Portability"!</font></td>
      </tr>
   </table>

 <?php
} ?>


<?php
if ($priv > 5) {
   $action = strtolower($action);
   switch ($action) {
   	  case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted.</td></tr></table><br>";
			paint_table($db);
         break;
	   case "addptel":
            display_form($db);
            break;
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The Mobile Pre Number id $id was successfully added!.</td></tr></table>";
		  paint_table($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  paint_table($db);
         break;
	  case "delete":
          if (!$db->Execute("DELETE FROM mobile_pref WHERE id='$uid'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Mobile PreNumber id $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
      case "create":
		 if ($prenumber == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description for this filed about PreNumber!</td></tr></table>";
            display_form($db);
            break;
         }
		 // security
		 if ($gsm_provider_cost == "") {($gsm_provider_cost = "0.1071");}
         $pre_number = $db->GenID("mobile_pref_seq");
		 $gsm_provider_name = addslash_text($gsm_provider_name);
         $query = "INSERT INTO mobile_pref (intid, prenumber, gsm_provider_cost, gsm_provider_name)"
                . " VALUES ('$pre_number', '$prenumber', '$gsm_provider_cost', '$gsm_provider_name')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
		 paint_table($db);
         break;
      case "update":
         if ($id == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for that field.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $gsm_provider_name = addslash_text($gsm_provider_name);
         $query = "UPDATE mobile_pref SET"
                . " prenumber='$prenumber',"
				. " gsm_provider_cost='$gsm_provider_cost',"
				. " gsm_provider_name='$gsm_provider_name'"
                 . " WHERE id='$id'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_mob_pref.php";
         </script> <?php
         break;
	  case "edit":
         edit_mobpre_form($db, $id);
		 	break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>This operation on numbers isn't allowed!</td></tr></table>";
}
require("footer.inc.php");
?>
