<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|	menu.php	*/

// module = main menu
// 
//$title = "MENU";
//require("common.inc.php");
global $apps_path;
//include "html_header.php";
$apps_path='';
$linkm = $_GET['incm'];

if (!$linkm) { ($linkm == "index"); }

switch ($linkm)
{
/* EXAMPLE
    case "dir_create":
	include $apps_path."/user/dir_create.php";
	break;
*/
    case "":
	include $apps_path."index.php";
	break;
    case "index":
	include $apps_path."index.php";
	break;
    case "newcat":
	include $apps_path."new_cat.php";
	break;
    case "edcat":
	include $apps_path."ed_cat.php";
	break;
    case "add_group":
	header ("Location: ne_groups.php?action=addgrp");
	//include $apps_path."ne_groups.php?action=addgrp";
	break;
    case "edit_group":
	include $apps_path."ne_groups.php";
	break;
    case "add_class":
		$action="addptel";
	include $apps_path."ne_classf.php";
	//include $apps_path."ne_classf.php?action=addptel";
	break;
    case "edit_class":
	include $apps_path."ne_classf.php";
	break;
    case "add_prx-number":
		$action="addptel";
	include $apps_path."ne_mob_pref.php";
	//include $apps_path."ne_mob_pref.php?action=addptel";
	break;
    case "edit_prx-number":
	include $apps_path."ne_mob_pref.php";
	break;
    case "add_gsmmex":
		$action="addksms";
	include $apps_path."ne_SMS.php";
	//include $apps_path."ne_SMS.php?action=addksms";
	break;
    case "edit_gsmmex":
	include $apps_path."ne_SMS.php";
	break;
    case "send_gsmmex":
			$action="sendgsmmex";
	include $apps_path."ne_SMS.php";
	break;
    case "search_gsmmex":
	include $apps_path."index.php";
	break;
    case "new_gsmuser":
	include $apps_path."new_user.php";
	break;
    case "edit_gsmuser":
	include $apps_path."edit_user.php";
	break;
    case "phonebook":
	include $apps_path."index.php";
	break;
    case "sms_template":
	include $apps_path."Ksms_template.php";
	break;
	case "add_templates":
	include $apps_path."Ksms_template.php";
	break;
    case "edit_template":
	include $apps_path."Ksms_template.php";
	break;
    case "reports":
	include $apps_path."report_index.php";
	break;
    case "add_subgroup":
		$action="addsubgrp";
	include $apps_path."ne_subgroup.php";
	break;
    case "edit_subgroup":
		$action="";
	include $apps_path."ne_subgroup.php";
	break;
		default:
		include $apps_path."index.php";
}

?>