<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// module = users
// only for .....(priv > 4)
$title = "User Manager";
require("common.inc.php");
# double combo boxes by ---->   http://wsabstract.com/script/cut183.shtml 
// http://www.javascriptkit.com/script/cut183.shtml
?>

<?php
function user_form($db, $uid, $focusjs) {
 $company = $_SESSION["company"];
 $idORG = $_SESSION["id_company"];
 global $erra;
   if (!$users = $db->Execute("SELECT * FROM userz WHERE id_user='$uid' AND id_organization='$idORG' ORDER BY name")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
	  }
	if (!$prenumbers = $db->Execute("SELECT prenumber FROM mobile_pref ORDER BY prenumber")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
	  }
	$cats = $db->Execute("SELECT descrip,id FROM category ORDER BY descrip");
	$classf = $db->Execute("SELECT descript,id FROM classf ORDER BY descript");
	$selgroups = $db->Execute("SELECT descrip,id FROM groups WHERE id_organization='$idORG'");
  		$selectcats = $users->fields["idcateg"];
  		$selectcls = $users->fields["idclass"];
  		$selectgrps = $users->fields["idgroup"];
		$selectmpref = $users->fields["mobile_pref"];
	if ($erra=="1") { $tra="row_odd"; } else { $tra="row_even"; }
?>

<br>
  <table class="default" align="center" width="799" cellspacing="0" cellpadding="0" border="0">
  	   <form action="edit_user.php" method="post" name="form1">
<tr class="row_head">
    <td colspan="4" class="small"><br><b>New User Modification</b></td>
</tr>
<tr class="row_user_even2">
    <td class="small" width="50">InternalCode:<br>
        <input type="text" name="internal_code" size="16" value="<?php echo $users->fields["internal_code"]; ?>">
	</td>
    <td class="small">Username:<br>
        <input type="text" name="username" size="16" value="<?php echo $users->fields["username"]; ?>">&nbsp;&nbsp;<font size="-22">(max 16)</font>
	</td>
    <td class="small">Password:<br>
        <input type="password" name="pwd1" size="15" value="<?php //echo $users->fields["password"]; ?>">&nbsp;&nbsp;<font size="-2">(min. 4)</font>
	</td>
    <td class="small">Retype Password:<br>
        <input type="password" name="pwd2" size="15" value="<?php //echo $users->fields["password"]; ?>">&nbsp;&nbsp;<font size="-2">(min. 4)</font>
	</td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">Name LastName:<br>
        <input type="text" name="comname" size="50" value="<?php echo $users->fields["name"]; ?>">&nbsp;&nbsp;<font size="-22">(max 50)</font>
	</td>
    <td colspan="2" class="small">Address:<br>
        <input type="text" name="address" size="45" value="<?php echo $users->fields["address"]; ?>">&nbsp;&nbsp;<font size="-22">(max 50)</font>
	</td>
</tr>
<tr class="row_user_even2">
    <td class="small">ZIP:<br>
		<input type="text" name="p_code" size="8" value="<?php echo $users->fields["p_code"]; ?>">
	</td>
    <td class="small">City:<br>
        <input type="text" name="city" size="30" value="<?php echo $users->fields["city"]; ?>">&nbsp;&nbsp;<font size="-22">(max 30)</font>
	</td>
    <td class="small">Area:<br>
		<?php $org = $users;
			require("ItProvSelect.inc.php"); ?>
	</td>
    <td class="small">Country:<br>
		<input type="text" name="country" size="10"  value="<?php echo $users->fields["country"]; ?>">
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><br><b>Main Contact Information</b></td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">Phone:<br>
        <input type="text" name="phone" size="20" value="<?php echo $users->fields["phone"]; ?>">
	</td>
    <td colspan="2" class="small">FAX:<br>
        <input type="text" name="fax" size="20" value="<?php echo $users->fields["fax"]; ?>">
	</td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">E-Mail:<br>
       <input type="text" name="email" size="50" value="<?php echo $users->fields["email"]; ?>">
	</td>
    <td colspan="2" class="small">Web:<br>
       <input type="text" name="web" size="50" value="<?php echo $users->fields["web"]; ?>">
	</td>
</tr>
<tr class="row_user_even2">
    <td class="small">Sex:<br>
        <select name="sex">
	<option value="m" <?PHP if($users->fields["sex"]=="m"){echo("SELECTED");};?>>Uomo</option>
	<option value="f" <?PHP if($users->fields["sex"]=="f"){echo("SELECTED");};?>>Donna</option>
    	</select>
	</td>
    <td class="small">Age Range<br>
	
	<select name="age_range">
	   		<option value="" <?PHP if($users->fields["age_range"]==""){echo("SELECTED");};?>>non dichiarato</option>
			<option value="0-15" <?PHP if($users->fields["age_range"]=="0-15"){echo("SELECTED");};?>>0-15</option>
			<option value="16-18" <?PHP if($users->fields["age_range"]=="16-18"){echo("SELECTED");};?>>16-18</option>
			<option value="19-25" <?PHP if($users->fields["age_range"]=="19-25"){echo("SELECTED");};?>>19-25</option>
			<option value="26-35" <?PHP if($users->fields["age_range"]=="26-35"){echo("SELECTED");};?>>26-35</option>
			<option value="36-45" <?PHP if($users->fields["age_range"]=="36-45"){echo("SELECTED");};?>>36-45</option>
			<option value="46-55" <?PHP if($users->fields["age_range"]=="46-55"){echo("SELECTED");};?>>46-55</option>
			<option value="56-65" <?PHP if($users->fields["age_range"]=="56-65"){echo("SELECTED");};?>>56-65</option>
			<option value="oltre 65" <?PHP if($users->fields["age_range"]=="over 65"){echo("SELECTED");};?>>Over 65 old years</option>
    </select>
	</td>
    <td class="small">Category<br>
		<?php echo $cats->GetMenu2("category", $selectcats , FALSE, FALSE, 0); ?>
	</td>
    <td class="small">Class:<br>
		<?php echo $classf->GetMenu2("class", $selectcls, FALSE, FALSE, 0); ?>
	</td>
</tr>
<tr class="row_user_even2">
	<td class="small" colspan="2"><p class="texto_of_evidence">Subgroups are not share</p></td>
    <td class="small">Group<br>
		<?php echo $selgroups->GetMenu2("groupz", $selectgrps, FALSE, FALSE, 0); ?>
	</td>
    <td class="small">SubGroup:<br>
		<font size="-1">(in selection in other page)</font>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><br><b>GSM Data</b></td>
</tr>
<tr class="row_user_even2">
	<td colspan="4" class="small">
		<table cellspacing="2" cellpadding="2" border="0" width="100%">
		<tr>
    		<td class="small">International Prefix:</td>
 			<td class="small" align="center">GSM Prefix:</td>
    		<td class="small" align="center">GSM Number:</td>
    		<td class="small">User Activated ?</td>
		</tr>
		<tr>
        	<td>
		<select name="country_code">
	   		<option value="39" <?PHP if($users->fields["country_code"]=="39"){echo("SELECTED");};?>>+39</option>
			<option value="39" <?PHP if($users->fields["country_code"]=="39"){echo("SELECTED");};?>>+39 (Italia)</option>
    	</select>
			</td>
    		<td align="center"><?php echo $prenumbers->GetMenu("mobile_pref", $selectmpref, FALSE, FALSE, 0); ?></td>
    		<td align="center"><input type="text" name="mobile_phone" size="10" value="<?php echo $users->fields["mobile_phone"]; ?>"></td>
    		<td><input type="radio" name="user_activated" value="Y" <?PHP if($users->fields["user_activated"]=="Y"){echo("checked");};?>> SI
		<input type="radio" name="user_activated" value="N" <?PHP if($users->fields["user_activated"]!="Y"){echo("checked");};?>> NO</td>
		</tr>
	</table>

	</td>
</tr>
<tr>
	<td colspan="4" class="small">
		<table class="default" align="center" width="799" cellspacing="0" cellpadding="0" border="0">
		<tr class="row_user_even2">
    		<td class="small">Note:<br>
        <textarea name="note" cols="30" rows="3" wrap="VIRTUAL"><?php echo $users->fields["note"]; ?></textarea>
			</td>
			<td>&nbsp;</td>
    		<td colspan="2" class="small">Comments:<br>
		<textarea name="comments" cols="50" rows="3" wrap="VIRTUAL"><?php echo $users->fields["comments"]; ?></textarea>
			</td>
		</tr>
		</table>
	</td>
</tr>
    <tr class="row_foot"> 
      <td colspan="4" class="small">
	  <div align="center">
	  <img src="images/pub/bt_update.gif" alt="aggiorna" width="80" height="35" border="0"
            onClick="if (valid_edituser_form(document.form1)) { document.form1.submit(); }">
         <img src="images/pub/bt_delete.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure to delete thi user ?')) { window.location='edit_user.php?action=delete&uid=<?php echo $uid; ?>&scrtp=@pkms'; }">
         <a href="edit_user.php?action=cancel">
            <img src="images/pub/bt_cancel.gif" alt="Cancel" border="0"></a>
	  </div>
      </td>
    </tr>
  <input type="hidden" name="organization" value="<?php echo $company; ?>">
  <input type="hidden" name="uid" value="<?php echo $uid; ?>">	
  <input type="hidden" name="action" value="updateit">
  </form>
  </table>
  <?php 
	$focusname = "<script language=\"JavaScript\"> document.form1.comname.focus(); </script>";
	if ($focusjs == "") {
			$focusjs="$focusname";
            echo "$focusjs";
         } else {
		 echo "$focusjs";
		 }
 ?>
 
 <br>
<div align="center"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#919DA2"> my - ksms ::: sms bulk manager</font></div>
 <br>
  <!--
  <script language="JavaScript">
     document.form1.name.focus();
  </script> 
  -->
  <?php
} ?>


<?php
function checks_form($db, $internal_code, $susername, $pwd1, $pwd2, $comname, $address, $p_code, $city, $province, $country, $phone, $fax, $email, $web, $sex, $age_range, $category, $class, $groupz, $country_code, $mobile_pref, $mobile_phone, $user_activated, $note, $comments, $uid) {
	// All variables passed trough this function. In future set a cookie!!!
 		$idORG = $_SESSION["id_company"];
	if ((strlen($pwd1) > 0) AND (strlen($pwd1)) < 4) {
		echo "<p class='news'>The passwords must be of at least 3 characters in length!</p>";
		echo "<br><br><br><br><br><br><br><br><br>";
		include("footer.inc.php");
		break;
		  }
	if ((strlen($pwd1) >= 4) AND ($pwd1 != $pwd2)){
		echo "<p class='news'>Passwords do not match!</p>";
		echo "<br><br><br><br><br><br><br><br><br>";
		include("footer.inc.php");
		break;
		  }
  ?>
  <br>
  <table class="default" align="center" width="700" cellspacing="1" cellpadding="2" border="0">
  	<form action="edit_user.php" method="post" name="formcheck">
<tr class="row_head">
    <td colspan="4" class="small"><b>Check new user insert</b></td>
</tr>
<tr class="row_user_even2">
    <td class="small">Int.Code:<br>
      <?PHP echo $internal_code ?>
	</td>
    <td class="small">Username:<br>
		<?PHP echo $susername ?>
	</td>
    <td class="small">Password:<br>
		<?PHP echo $pwd1 ?>
	</td>
    <td class="small">Retype Password:<br>
        <?PHP echo $pwd2 ?>
	</td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">Name and Lastname:<br>
		<?PHP echo $comname ?>
	</td>
    <td colspan="2" class="small">Address:<br>
		<?PHP echo $address ?>
	</td>
</tr>
<tr class="row_user_even2">
    <td class="small">ZIP:<br>
		<?PHP echo $p_code ?>
	</td>
    <td class="small">City:<br>
		<?PHP echo $city ?>
		</td>
    <td class="small">Area:<br>
		<?PHP echo $province ?>
	</td>
    <td class="small">Country:<br>
		<?PHP echo $country ?>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b>Main Contact Information</b></td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">Phone:<br>
		<?PHP echo $phone ?>
	</td>
    <td colspan="2" class="small">FAX:<br>
		<?PHP echo $fax ?>
	</td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">E-Mail:<br>
		<?PHP echo $email ?>
	</td>
    <td colspan="2" class="small">Web:<br>
		<?PHP echo $web ?>
	</td>
</tr>
<tr class="row_user_even2">
    <td class="small">Sex:<br>
		<?PHP echo $sex ?>
	</td>
    <td class="small">Age-Range<br>
		<?PHP echo $age_range ?>
	</td>
    <td class="small">Category<br>
		<?PHP echo $category ?>
	</td>
    <td class="small">Class:<br>
		<?PHP echo $class ?>
	</td>
</tr>
<tr class="row_user_even2">
	<td class="small" colspan="2">&nbsp;</td>
    <td class="small">Group<br>
		<?PHP echo $groupz ?>
	</td>
    <td class="small">SubGroup:<br>
		<?php 
	$selsubgrps = $db->Execute("SELECT descript,id FROM subgroup WHERE idgroup='$groupz' AND id_organization='$idORG' ORDER BY id");
	echo $selsubgrps->GetMenu2("subgrps", "", FALSE, FALSE, 0); ?>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b></b>GSM area data</b></td>
</tr>
<tr class="row_user_even2">
    <td colspan="2" class="small">Country Code:<br>
		<?PHP echo $country_code ?>
	</td>
    <td class="small">Mobile Prefixe:<br>
		<?PHP echo $mobile_pref ?>
	</td>
    <td class="small">Mobile Number:<br>
		<?PHP echo $mobile_phone ?>
	</td>
</tr>
<tr class="row_user_even2">
    <td class="small">USER ACTIVATED ?<br>
		<?PHP echo $user_activated ?>
	</td>
    <td class="small">Note:<br>
		<?PHP echo $note ?>
	</td>
    <td colspan="2" class="small">Comments:<br>
		<?PHP echo $comments ?>
	</td>
</tr>
<tr class="row_user_even2">
	<td colspan="4" class="small">
	If there is some errors, please hit return and insert new data!
	</td>
</tr>
    <tr class="row_foot"> 
      <td colspan="4" class="small">
	  	<div align="center">
         <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
            onClick="document.formcheck.submit();">
         <a href="edit_user.php?action=cancel">
            <img src="images/pub/bt_cancel.gif" border="0" alt="Cancel"></a>
		</div>
      </td>
    </tr> <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
	<input type="hidden" name="internal_code" value="<?php echo $internal_code; ?>">
	<input type="hidden" name="uid" value="<?php echo $uid; ?>">
	<input type="hidden" name="susername" value="<?php echo $susername; ?>">
	<input type="hidden" name="pwd1" value="<?php echo $pwd1; ?>">
	<input type="hidden" name="pwd2" value="<?php echo $pwd2; ?>">
	<input type="hidden" name="comname" value="<?php echo $comname; ?>">
	<input type="hidden" name="address" value="<?php echo $address; ?>">
	<input type="hidden" name="p_code" value="<?php echo $p_code; ?>">
	<input type="hidden" name="city" value="<?php echo $city; ?>">
	<input type="hidden" name="province" value="<?php echo $province; ?>">
	<input type="hidden" name="country" value="<?php echo $country; ?>">
	<input type="hidden" name="phone" value="<?php echo $phone; ?>">
	<input type="hidden" name="fax" value="<?php echo $fax; ?>">
	<input type="hidden" name="email" value="<?php echo $email; ?>">
	<input type="hidden" name="web" value="<?php echo $web; ?>">
	<input type="hidden" name="sex" value="<?php echo $sex; ?>">
	<input type="hidden" name="age_range" value="<?php echo $age_range; ?>">
	<input type="hidden" name="category" value="<?php echo $category; ?>">
	<input type="hidden" name="class" value="<?php echo $class; ?>">
	<input type="hidden" name="groupz" value="<?php echo $groupz; ?>">
	<input type="hidden" name="country_code" value="<?php echo $country_code; ?>">
	<input type="hidden" name="mobile_pref" value="<?php echo $mobile_pref; ?>">
	<input type="hidden" name="mobile_phone" value="<?php echo $mobile_phone; ?>">
	<input type="hidden" name="user_activated" value="<?php echo $user_activated; ?>">
	<input type="hidden" name="note" value="<?php echo $note; ?>">
	<input type="hidden" name="comments" value="<?php echo $comments; ?>">
   <input type="hidden" name="organization" value="<?php echo $company; ?>">
   <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
   <input type="hidden" name="action" value="update_aftercheck">
   </form>
   </table>
   <script language="JavaScript">
      document.formcheck.subgrps.focus();
   </script> <?php
} ?>


<?php
function paint_table($db, $ksort,$pageview) {
	// PAGER - (previous / next page)
   $totpg = 40;    ################## the max number of user in one page
	if(!$pageview || $pageview == 1){
	  $start = 0;
		}else{
	   $offset = $pageview-1;
	   $start = ($offset * $totpg);
		   }
	 $company = $_SESSION["company"];
	 $idORG = $_SESSION["id_company"];
 	 	if ($ksort == "") { $ksort = "id_user"; $mysort = "ID"; }
		if ($ksort == "id_user") { $ksort = "id_user"; $mysort = "ID"; }
	  	if ($ksort == "name") { $ksort = "name"; $mysort = "name"; }
	  	if ($ksort == "cat") { $ksort = "idcateg"; $mysort = "category"; }
	  	if ($ksort == "grp") { $ksort = "idgroup"; $mysort = "group"; }
	  	if ($ksort == "cls") { $ksort = "idclass"; $mysort = "class"; }
		if ($ksort == "pref") { $ksort = "mobile_pref,mobile_phone"; $mysort = "Prefix Nr."; }
		if ($ksort == "telf") { $ksort = "mobile_phone,mobile_pref"; $mysort = "GSM number"; }
		if ($ksort == "active") { $ksort = "user_activated"; $mysort = "attivazione"; }
     //$summusers = $db->Execute("SELECT * FROM userz WHERE id_organization='$idORG' ORDER BY $ksort");
   $summusers = $db->Execute("SELECT * FROM userz WHERE id_organization='$idORG' ORDER BY $ksort LIMIT $start,$totpg");
	$sucountusers = $db->Execute("SELECT COUNT(id_user) AS tousr FROM userz WHERE id_organization='$idORG'");
	$totmaxusr = $sucountusers->fields["tousr"];

	// pager part 2
	if($pageview > 1){
		$prevpage = $pageview - 1;
		  }
		$currentend = $start + 25;
		if($totmaxusr > $currentend) {
			if(!$pageview){
			$nextpage = 2;
			  }else{
			$nextpage = $pageview + 1;
				}
			}
// testing ...
//	echo "2-page === ".$pageview."<br>";
//	echo "2-currentend === ".$currentend."<br>";
//	echo "2-totmaxusr === ".$totmaxusr."<br>";
		echo "<br><p class='news'>";
		echo "Visualization : <b>".$totpg."</b> users in every page";
		echo " orders by <b>".$mysort."</b></p>";
?>

      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td>&nbsp;</td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head_view"> 
         <td><b>#</b></td>
         <td><a href="edit_user.php?ksort=name"><b>Name</b></a></td>
		 <td><b><a href="edit_user.php?ksort=pref">Prefix</a>.<a href="edit_user.php?ksort=telf">MobilePhone</a></b></td>
		 <td><a href="edit_user.php?ksort=cat"><b>Category</b></a></td>
		 <td><a href="edit_user.php?ksort=grp"><b>Group</b></a></td>
		 <td><a href="edit_user.php?ksort=grp"><b>SubGroup</b></a></td>
		 <td><a href="edit_user.php?ksort=cls"><b>class</b></a></td>
		 <td><a href="edit_user.php?ksort=active"><b>Activ.?</b></a></td>
      </tr>
	  <?php
      $i = 1;
      while (!$summusers->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd_view2\">";
         } else {
            echo "<tr class=\"row_scd_view1\">";
         } 
	$usercat = $summusers->fields["idcateg"];
	$userclas = $summusers->fields["idclass"];
	$usegroup = $summusers->fields["idgroup"];
	$ussubgroup = $summusers->fields["idsubgroup"];
	$selectcat = $db->Execute("SELECT descrip FROM category WHERE id='$usercat'");
	$selectcla = $db->Execute("SELECT descript FROM classf WHERE id='$userclas'");
	$selectgrp = $db->Execute("SELECT descrip FROM groups WHERE id='$usegroup' AND id_organization='$idORG'");
	$selectsubgrp = $db->Execute("SELECT descript FROM subgroup WHERE id='$ussubgroup' AND id_organization='$idORG'");
	$userselcat = $selectcat->fields["descrip"];
	$userselcla = $selectcla->fields["descript"];
	$userselgrp = $selectgrp->fields["descrip"];
	$usrslsubgrp = $selectsubgrp->fields["descript"];
		 ?> 
            <td>
        <a href="edit_user.php?action=edit&phone=<?php echo $summusers->fields["mobile_phone"]; ?>&uid=<?php echo $summusers->fields["id_user"]; ?>"> 
		<?php echo $summusers->fields["id_user"]; ?>
		</a>
            </td>
            <td>
		<a href="edit_user.php?action=edit&phone=<?php echo $summusers->fields["mobile_phone"]; ?>&uid=<?php echo $summusers->fields["id_user"]; ?>">
		<b><?php echo $summusers->fields["name"]; ?></b>
		</a>
			</td>
			<td>
		<a href="edit_user.php?action=edit&phone=<?php echo $summusers->fields["mobile_phone"]; ?>&uid=<?php echo $summusers->fields["id_user"]; ?>">
		<?php echo $summusers->fields["mobile_pref"]; ?><b>.</b><?php echo $summusers->fields["mobile_phone"]; ?>
		</a>
			</td>
			<td><?php echo $userselcat; ?></td>
			<td><?php echo $userselgrp; ?></td>
			<td><?php echo $usrslsubgrp; ?></td>
			<td><?php echo $userselcla; ?></td>
			<td><?php echo $summusers->fields["user_activated"]; ?></td>
         </tr> <?php
         $i++;
         $summusers->MoveNext();
      } ?>
   </table>
<?php
 // pager 3 ---> select the pages!
 	if($pageview < 2){
		$pageview = 1;
		  }
 	$keytotpages = ceil($totmaxusr/$totpg);
//	echo "previous=== ".$prevpage."<br>"; // testing
//	echo "next=== ".$nextpage."<br>";   // testing
  echo "<table class='small' cellpadding='1' cellspacing='0' border='0' width='100%'>";
  echo "<tr class='row_head'>";
  echo "<td>";
  
  	echo "<table width='100%' cellspacing='2' cellpadding='2' border='0'><tr>";
    	echo "<td class='zen' align='left'><a href=\"menu.php?incm=edit_gsmuser&ksort=".$ksort."&pageview=1\">vai alla prima pagina</a></td>";
    	echo "<td>";
			echo "<div align='center'>";
  			$kpnext = "<img src='images/pub/nextpage.gif' alt='pagina seguente ' border='0'>";
  			$kpprev = "<img src='images/pub/previouspage.gif' alt='pagina precedente ' border='0'>";
			if ($prevpage || $nextpage) {
				if($prevpage){
					echo ("<a href=\"menu.php?incm=edit_gsmuser&ksort=".$ksort."&pageview=".$prevpage."\">$kpprev</a>");
			  			}else{
						echo ("");
							}
				if($nextpage){
					echo ("<a href=\"menu.php?incm=edit_gsmuser&ksort=".$ksort."&pageview=".$nextpage."\">$kpnext</a>");
			 		 }else{
					echo ("");
						}
			 		}
		echo "</div></td>";
    	echo "<td class='zen' align='right'><a href=\"menu.php?incm=edit_gsmuser&ksort=".$ksort."&pageview=".$keytotpages."\">vai all'ultima pagina</a></td>";
	echo "</tr></table>";
  
  

  echo "</td></tr>";
  echo "<tr><td><div align='center'>Page # <b>".$pageview."</b> of ".$keytotpages." page(s) found!</div></td></tr>";
  echo "</tr></table>";
} // end function paint_table...

function delete_user($db, $uid) {
   if (!$db->Execute("DELETE FROM userz WHERE id_user=$uid")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

?>

<?php

$priv = $_SESSION["priv"];
if ($priv > 3) {
   $action = strtolower($action);
   switch ($action) {
   	  case "edit":
	  global $focusjs;
         user_form($db, $uid, $focusjs);
         break;
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Operation Aborted!</td></tr></table>";
         break;
      case "delete":
         if (delete_user($db, $uid)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>User Deleted!<a href=\"edit_user.php\"><img src='images/pub/aggiornaBsr.gif' alt='aggiorna' border='0' align='middle'></a>another user!</td></tr></table>";
         }
         break;
      case "updateit":
         echo "<table class=\"news\" width=\"100%\"><tr><td>CHECK AN EXISTENT USER!</td></tr></table><br>";
	$idORG = $_SESSION["id_company"];
	$userz = $db->Execute("SELECT * FROM userz WHERE id_user<>'$uid' AND mobile_pref='$mobile_pref' AND mobile_phone='$mobile_phone' AND id_organization='$idORG'");
		$idusr = $userz->fields["id_user"];
		$nmusr = $userz->fields["name"];
		// echo "<br>------".$idusr."<br>";
   if ($idusr!="") {
		if ($nmusr=="") { $nmusr="nn"; }
      echo "<p class='news'><font color='#D31238'><b>Error: this number ".$mobile_pref."-".$mobile_phone." is in database, please select another name!</b></font> <br><font size='-1'>(".$idusr." - name: ".$nmusr.")</font></p>";
      user_form($db, $uid, $focusjs);
         break;
	  }
		 checks_form($db, $internal_code, $susername, $pwd1, $pwd2, $comname, $address, $p_code, $city, $province, $country, $phone, $fax, $email, $web, $sex, $age_range, $category, $class, $groupz, $country_code, $mobile_pref, $mobile_phone, $user_activated, $note, $comments, $uid);
         break;
      case "update_aftercheck":
	  	$company = $_SESSION["company"];
 		$idORG = $_SESSION["id_company"];
	    $usercomp = $db->Execute("SELECT id_organization, organization FROM userz WHERE id_user='$uid' AND id_organization='$idORG'");
	  	$company_regID = ($usercomp->fields["id_organization"]);
		if ($company_regID != $idORG) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td><div align=center><b>DB ERROR: You are not allowed to modify the data of this user!</b></div></td></tr></table>";
            break;
         }
         if ($pwd1 == "") {
		 $address = addslash_text($address);
		 $city = addslash_text($city);
		 $country = addslash_text($country);
		 $note = addslash_text($note);
		 $comments = addslash_text($comments);
		 if ($province == "-->Seleziona la prov.") { $province = ""; }
         $query = "UPDATE userz SET"
			. " internal_code='$internal_code', username='$username', name='$comname',"
			. " id_organization='$idORG', organization='$company', address='$address', city='$city',"
			. " province='$province', country='$country', p_code='$p_code', phone='$phone',"
			. " fax='$fax', email='$email', web='$web', sex='$sex', age_range='$age_range',"
			. " country_code='$country_code', mobile_pref='$mobile_pref',"
			. " mobile_phone='$mobile_phone', idcateg='$category', idclass='$class', "
			. " idgroup='$groupz', idsubgroup='$subgrps', user_activated='$user_activated',"
			. " note='$note', comments='$comments'"
			  . " WHERE id_user='$uid' AND id_organization='$idORG'";
         } else if ((strlen($pwd1) >= 4) && ($pwd1 == $pwd2)) {
		 $address = addslash_text($address);
		 $city = addslash_text($city);
		 $country = addslash_text($country);
		 $note = addslash_text($note);
		 $comments = addslash_text($comments);
		 if ($province == "-->Seleziona la prov.") { $province = ""; }
		$query = "UPDATE userz SET"
			. " internal_code='$internal_code', username='$username', password='$pwd1',"
			. " name='$comname', id_organization='$idORG', organization='$company', address='$address',"
			. " city='$city', province='$province', country='$country', p_code='$p_code',"
			. " phone='$phone', fax='$fax', email='$email', web='$web', sex='$sex',"
			. " age_range='$age_range', country_code='$country_code', mobile_pref='$mobile_pref',"
			. " mobile_phone='$mobile_phone', idcateg='$category', idclass='$class',"
			. " idgroup='$groupz', idsubgroup='$subgrps',"
			. " user_activated='$user_activated', note='$note', comments='$comments'"
			  . " WHERE id_user='$uid' AND id_organization='$idORG'";
         } else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Le password inserite hanno meno di 4 caratteri o non coincidono</td></tr></table>";
	$focuspwd = "<script language=\"JavaScript\"> document.form1.pwd1.focus(); </script>";
			$focusjs="$focuspwd";
			$erra="1";
            //user_form($db, $uid, $focusjs);
			paint_table($db, $ksort,$pageview);
            break;
         }
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td><b>User Data Updated!.</b> Click on this image and <a href=\"edit_user.php\"><img src='images/pub/aggiornaBsr.gif' alt='aggiorna' border='0' align='middle'></a> another user, or select another option, from the menu!</td></tr></table>";
         break;
      default:
         paint_table($db, $ksort,$pageview);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See Ksms administrator.</td></tr></table>";
}
require("footer.inc.php");
?>

