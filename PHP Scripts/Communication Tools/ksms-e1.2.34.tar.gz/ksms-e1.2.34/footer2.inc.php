<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

?>
<br><br><br><br><br><br>

<b><div align="center"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#919DA2">my&nbsp;<?php echo $cfg["sysver"]; ?></font></div></b>
<div align="center"><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="1" color="#808080">&copy; 2004-<?php echo date ("Y"); ?> by <a href="http://www.viabazar.com/">Viabazar Group</a>. All information on this server is protected under the copyright laws of United States and in other countries.<br>Unless otherwise specified, no one has permission to copy or republish, in any form, any information or any software found on this site.</font></div>
<br>
</body>
</html>
