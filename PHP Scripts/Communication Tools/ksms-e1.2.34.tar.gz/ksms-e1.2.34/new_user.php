<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// module = users

$title = "Add User";
require("common.inc.php");
////// 	if ($user_activated = "") { $user_activated = "N"; }
# double combo boxes by ---->   http://wsabstract.com/script/cut183.shtml
?>

<?php
function display_form($db) {
//  global $refer, $prenumber; 
   $company = $_SESSION["company"];
   $idORG = $_SESSION["id_company"];
	$prenumbers = $db->Execute("SELECT prenumber FROM mobile_pref ORDER BY prenumber");
	$cats = $db->Execute("SELECT descrip, id FROM category ORDER BY descrip");
	$classf = $db->Execute("SELECT descript, id FROM classf ORDER BY descript");
	$groups = $db->Execute("SELECT descrip, id FROM groups WHERE id_organization='$idORG' ORDER BY descrip");
// random number
		srand((double)microtime()*1000000);
		//echo rand(0,100);
		$filrand = rand(0,100);
		$filrand2 = rand(100,1000);
		$filname = rand(0,100000);

function makeRandomPassword() {
  $salt = "abcdefghijklmnopqrstuvwxyz0123456789";
  //srand((double)microtime()*1000000);
      $i = 0;
      while ($i <= 7) {
            $num = rand() % 33;
            $tmp = substr($salt, $num, 1);
            $pass = $pass . $tmp;
            $i++;
      }
      return $pass;
}
$random_password = makeRandomPassword();
//echo "Random Password is $random_password";

  ?>
  <br>
  <table class="default" align="center" width="700" cellspacing="1" cellpadding="2" border="0">
  	<form action="new_user.php" method="post" name="form1">
<tr class="row_head">
    <td colspan="4" class="small"><b>NEW USER</b></td>
</tr>
<tr class="row_user_even">
    <td class="small">Internal Code:<br>
        <input type="text" name="internal_code" size="10" value="<?PHP echo $filrand.".".$filrand2 ?>">
	</td>
    <td class="small">Username:<br>
        <input type="text" name="susername" size="16" value="nm<?PHP echo $filname ?>">&nbsp;&nbsp;<font size="-2">(max.16)</font>
	</td>
    <td class="small">Password:<br>
        <input type="Password" name="pwd1" size="20" value="<?PHP echo $random_password ?>">&nbsp;&nbsp;<font size="-2">(min.4)</font>
	</td>
    <td class="small">Retype Password:<br>
        <input type="Password" name="pwd2" size="20" value="<?PHP echo $random_password ?>">&nbsp;&nbsp;<font size="-2">(min.4)</font>
	</td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Name:<br>
        <input type="text" name="sname" size="40">&nbsp;&nbsp;<font size="-2">(max.50)</font>
	</td>
    <td colspan="2" class="small">Address:<br>
        <input type="text" name="address" size="50">&nbsp;&nbsp;<font size="-2">(max.50)</font>
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">ZIP:<br>
		<input type="text" name="p_code" size="8">
	</td>
    <td class="small">Citty:<br>
        <input type="text" name="city" size="30">&nbsp;<font size="-2">(max.30)</font></td>
    <td class="small">Provincia:<br>
		<?php require("ItProv.inc.php"); ?>
	</td>
    <td class="small">Country:<br>
		<input type="text" name="country" size="10" value="Italia">
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b>Main Contact Information</b></td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Phone:<br>
        <input type="text" name="phone" size="20">
	</td>
    <td colspan="2" class="small">FAX:<br>
        <input type="text" name="fax" size="20">
	</td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">E-Mail:<br>
        <input type="text" name="email" size="50">
	</td>
    <td colspan="2" class="small">Web:<br>
        <input type="text" name="web" size="50" value="http://">
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">Sex:<br>
        <select name="sex">
			<option value="m" selected>Man</option>
			<option value="f">Woman</option>
    	</select>
	</td>
    <td class="small">Age-Range<br>
	<select name="age_range">
	   		<option value="" selected>nothing</option>
			<option value="0-15">0-15</option>
			<option value="16-18">16-18</option>
			<option value="19-25">19-25</option>
			<option value="26-35">26-35</option>
			<option value="36-45">36-45</option>
			<option value="46-55">46-55</option>
			<option value="56-65">56-65</option>
			<option value="oltre 65">over 65</option>
    </select>
	</td>
    <td class="small">Category<br>
		<?php echo $cats->GetMenu("category", "", FALSE, FALSE, 0); ?>
	</td>
    <td class="small">Class:<br>
		<?php echo $classf->GetMenu("class", "", FALSE, FALSE, 0); ?>
	</td>
</tr>
<tr class="row_user_even">
	<td class="small" colspan="2">&nbsp;</td>
    <td class="small">Group<br>
		<?php 
	$selgroups = $db->Execute("SELECT descrip,id FROM groups WHERE id_organization='$idORG' ORDER BY id");
	echo $selgroups->GetMenu2("groupz", "", FALSE, FALSE, 0); ?>
	</td>
    <td class="small">SubGroup:<br>
		<font size="-1">(select in next page)</font>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b>SMS-AREA</b></td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Country Code:<br>
	<select name="country_code">
	   		<option value="41" selected>+41</option>
			<option value="44">+44 ()</option>
    	</select>
	</td>
    <td class="small">GSM Prefix:<br>
		<?php echo $prenumbers->GetMenu("mobile_pref", "", FALSE, FALSE, 0); ?>
	</td>
    <td class="small">GSM Number:<br>
		<input type="text" name="mobile_phone" size="10">
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">USER ACTIVE ?<br>
		<input type="radio" name="user_activated" value="Y" checked> SI
		<input type="radio" name="user_activated" value="N"> NO
	</td>
    <td class="small">Note:<br>
		<textarea name="note" cols="30" rows="3" wrap="VIRTUAL"></textarea>
	</td>
    <td colspan="2" class="small">Comments:<br>
        <textarea name="comments" cols="50" rows="3" wrap="VIRTUAL"></textarea>
	</td>
</tr>
    <tr class="row_foot"> 
      <td colspan="4" class="small">
	  	<div align="center">
         <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
            onClick="if (valid_smsuser_form(document.form1)) { document.form1.submit(); }">
         <img src="images/pub/bt_reset.gif" border="0" alt="Reset"
            onClick="document.form1.reset();">
         <a href="new_user.php?action=cancel">
            <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a>
		</div>
      </td>
    </tr> <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
   <input type="hidden" name="organization" value="<?php echo $company; ?>">
   <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
   <input type="hidden" name="action" value="insert">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.internal_code.focus();
   </script> <?php
} ?>

<?php
function checks_form($db, $internal_code, $susername, $pwd1, $pwd2, $sname, $address, $p_code, $city, $province, $country, $phone, $fax, $email, $web, $sex, $age_range, $category, $class, $groupz, $country_code, $mobile_pref, $mobile_phone, $user_activated, $note, $comments) {
	// All variables passed trough this function. In future set a cookie!!!
 		$idORG = $_SESSION["id_company"];
  ?>
  <br>
  <table class="default" align="center" width="700" cellspacing="1" cellpadding="2" border="0">
  	<form action="new_user.php" method="post" name="formcheck">
<tr class="row_head">
    <td colspan="4" class="small"><b>Check the inserted data</b></td>
</tr>
<tr class="row_user_even">
    <td class="small">internal code:<br>
      <?PHP echo $internal_code ?>
	</td>
    <td class="small">Username:<br>
		<?PHP echo $susername ?>
	</td>
    <td class="small">Password:<br>
		<?PHP echo $pwd1 ?>
	</td>
    <td class="small">Password (2'):<br>
        <?PHP echo $pwd2 ?>
	</td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Name:<br>
		<?PHP echo $sname ?>
	</td>
    <td colspan="2" class="small">Address:<br>
		<?PHP echo $address ?>
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">ZIP:<br>
		<?PHP echo $p_code ?>
	</td>
    <td class="small">Citty:<br>
		<?PHP echo $city ?>
		</td>
    <td class="small">Provincia:<br>
		<?PHP echo $province ?>
	</td>
    <td class="small">Country:<br>
		<?PHP echo $country ?>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b>Main Contact Information</b></td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Phone:<br>
		<?PHP echo $phone ?>
	</td>
    <td colspan="2" class="small">FAX:<br>
		<?PHP echo $fax ?>
	</td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">E-Mail:<br>
		<?PHP echo $email ?>
	</td>
    <td colspan="2" class="small">Web:<br>
		<?PHP echo $web ?>
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">Sesx:<br>
		<?PHP echo $sex ?>
	</td>
    <td class="small">Age-Range<br>
		<?PHP echo $age_range ?>
	</td>
    <td class="small">Category<br>
		<?PHP echo $category ?>
	</td>
    <td class="small">Class:<br>
		<?PHP echo $class ?>
	</td>
</tr>
<tr class="row_user_even">
	<td class="small" colspan="2">&nbsp;</td>
    <td class="small">Group<br>
		<?PHP echo $groupz ?>
	</td>
    <td class="small">SubGroup:<br>
		<?php 
	$selsubgrps = $db->Execute("SELECT descript,id FROM subgroup WHERE idgroup='$groupz' AND id_organization='$idORG' ORDER BY id");
	echo $selsubgrps->GetMenu2("subgrps", "", FALSE, FALSE, 0); ?>
	</td>
</tr>
<tr class="row_head">
    <td colspan="4" class="small"><b>SMS AREA</b></td>
</tr>
<tr class="row_user_even">
    <td colspan="2" class="small">Country Code:<br>
		<?PHP echo $country_code ?>
	</td>
    <td class="small">SMS Prefix:<br>
		<?PHP echo $mobile_pref ?>
	</td>
    <td class="small">GSM Number:<br>
		<?PHP echo $mobile_phone ?>
	</td>
</tr>
<tr class="row_user_even">
    <td class="small">User Activated ?<br>
		<?PHP echo $user_activated ?>
	</td>
    <td class="small">Note:<br>
		<?PHP echo $note ?>
	</td>
    <td colspan="2" class="small">Comments:<br>
		<?PHP echo $comments ?>
	</td>
</tr>
<tr class="row_user_even">
	<td colspan="4" class="small">
ksms
	</td>
</tr>
    <tr class="row_foot"> 
      <td colspan="4" class="small">
	  	<div align="center">
         <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
            onClick="document.formcheck.submit();">
         <a href="new_user.php?action=cancel">
            <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a>
		</div>
      </td>
    </tr> <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
	<input type="hidden" name="internal_code" value="<?php echo $internal_code; ?>">
	<input type="hidden" name="susername" value="<?php echo $susername; ?>">
	<input type="hidden" name="pwd1" value="<?php echo $pwd1; ?>">
	<input type="hidden" name="pwd2" value="<?php echo $pwd2; ?>">
	<input type="hidden" name="sname" value="<?php echo $sname; ?>">
	<input type="hidden" name="address" value="<?php echo $address; ?>">
	<input type="hidden" name="p_code" value="<?php echo $p_code; ?>">
	<input type="hidden" name="city" value="<?php echo $city; ?>">
	<input type="hidden" name="province" value="<?php echo $province; ?>">
	<input type="hidden" name="country" value="<?php echo $country; ?>">
	<input type="hidden" name="phone" value="<?php echo $phone; ?>">
	<input type="hidden" name="fax" value="<?php echo $fax; ?>">
	<input type="hidden" name="email" value="<?php echo $email; ?>">
	<input type="hidden" name="web" value="<?php echo $web; ?>">
	<input type="hidden" name="sex" value="<?php echo $sex; ?>">
	<input type="hidden" name="age_range" value="<?php echo $age_range; ?>">
	<input type="hidden" name="category" value="<?php echo $category; ?>">
	<input type="hidden" name="class" value="<?php echo $class; ?>">
	<input type="hidden" name="groupz" value="<?php echo $groupz; ?>">
	<input type="hidden" name="country_code" value="<?php echo $country_code; ?>">
	<input type="hidden" name="mobile_pref" value="<?php echo $mobile_pref; ?>">
	<input type="hidden" name="mobile_phone" value="<?php echo $mobile_phone; ?>">
	<input type="hidden" name="user_activated" value="<?php echo $user_activated; ?>">
	<input type="hidden" name="note" value="<?php echo $note; ?>">
	<input type="hidden" name="comments" value="<?php echo $comments; ?>">
   <input type="hidden" name="organization" value="<?php echo $company; ?>">
   <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
   <input type="hidden" name="action" value="insert_aftercheck">
   </form>
   </table>
   <script language="JavaScript">
      document.formcheck.subgrps.focus();
   </script> <?php
} ?>

<?php
if ($priv > 3) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operazione aborted.</td></tr></table><br>";
         break;
      case "insert":
         echo "<table class=\"news\" width=\"100%\"><tr><td>CHECK THE DATA !</td></tr></table><br>";
	$idORG = $_SESSION["id_company"];
   if ($users = $db->Execute("SELECT * FROM userz WHERE mobile_pref='$mobile_pref' AND mobile_phone='$mobile_phone' AND id_organization='$idORG'")) {
		$idusr = $users->fields["id_user"];
		$nmusr = $users->fields["name"];
		if ($nmusr=="") { $nmusr="nn"; }
      echo "<p class='news'><font color='#D31238'><b>Error: GSM-number ".$mobile_pref."-".$mobile_phone." is already in database </b></font> <br><font size='-1'>(".$idusr." - nome: ".$nmusr.")</font></p>";
      display_form($db);
         break;
	  }
		 checks_form($db, $internal_code, $susername, $pwd1, $pwd2, $sname, $address, $p_code, $city, $province, $country, $phone, $fax, $email, $web, $sex, $age_range, $category, $class, $groupz, $country_code, $mobile_pref, $mobile_phone, $user_activated, $note, $comments);
         break;

      case "insert_aftercheck":
         if ($mobile_phone == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Please insert a GSM-number</td></tr></table>";
            display_form($db);
            break;
         		}
		 if ((strlen($pwd1) < 4) || ($pwd1 != $pwd2)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Two password mismatch</td></tr></table>";
            display_form($db);
            break;
				}
		if (!isset($user_activated)) {
            $user_activated = "N";
         }
		 if ($internal_code == "") {
            $internal_code = date("YmdHis");
         }
		 if ($susername == "") {
            $susername = date("BHis");
         }
		 if ($province == "-->Seleziona la prov.") {
            $province = "";
         }
		 $password = $pwd1;
		 $idORG = $_SESSION["id_company"];
		 $company = $_SESSION["company"];
		 $insertDate = $date;
         $id = $db->GenID("userz_seq");
		 $sname = addslash_text($sname);
		 $address = addslash_text($address);
		 $city = addslash_text($city);
		 if ($province == "-->Seleziona la prov.") { $province = ""; }
         $query = "INSERT INTO userz (insert_date, internal_code, username, password, id_organization, organization, name, address, city, province, country, p_code, phone, fax, email, web, sex, age_range, country_code, mobile_pref, mobile_phone, idcateg, idclasse, idgroup, idsubgroup, user_activated, note, comments)"
                . " VALUES ('$insertDate', '$internal_code', '$susername', '$password', '$idORG', '$company', '$sname', '$address', '$city', '$province', '$country', '$p_code', '$phone', '$fax', '$email', '$web', '$sex', '$age_range', '$country_code', '$mobile_pref', '$mobile_phone', '$category', '$class', '$groupz', '$subgrps', '$user_activated', '$note', '$comments')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         if (isset($refer)) {
            require("footer.inc.php"); ?>
            <script language="JavaScript">
               window.location="<?php echo $refer; ?>";
            </script> <?php
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>User inserted! If you wanna insert another user, click on this image: <a href=\"new_user.php\"><img src=\"images/pub/bta_Add.gif\" border=\"0\" alt=\"Add\" align=\"middle\"></a> </td></tr></table>";
         break;

      default:
         display_form($db);
   }
} // if priv
else 
{ echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS administrator.</td></tr></table>"; }
require("footer.inc.php");

?>
