<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

session_start();
unset($username, $priv, $company, $id_company, $imgs_pub_dir);

require("grab_globals.inc.php");
require("config.inc.php");
require("connection.inc.php");
require("headerLogin.inc.php");

function user_form() { 

?>
   <table class="default" border="0" cellpadding="10" width="100%"><tr><td>
      <table class="default" border="0" cellpadding="0" cellspacing="0" width="100%">
         <tr>
            <td align="left">
               <a href="http://www.viabazar.com">
					<img src="images/logoKS.gif" alt="Ksms bulk manager" width="199" height="84" border="0">
				  </a>
               <hr>
            </td>
            <td align="center">
               <img src="images/base.gif" alt="happy hour" width="107" height="149" border="0">
            </td>
         </tr>
      </table>
      <table class="default" align="center" border="0" cellpadding="1" cellspacing="0">
         <form action="login.php" method="post" name="form1">
         <tr class="row_head">
            <td align="center" colspan="2"><b>Please type you username and password</b></td>
         </tr>
         <tr class="row_even">
            <td align="center" colspan="2">&nbsp;</td>
         </tr>
         <tr class="row_even">
            <td align="right">Username:</td>
            <td><input type="text" name="uid" size="16"></td>
         </tr>
         <tr class="row_even">
            <td align="right">Password:</td>
            <td><input type="password" name="pwd" size="16"></td>
         </tr>
         <tr class="row_even">
            <td colspan="2">
               <input type="submit" value="Login"
            </td>
         </tr>
         <input type="hidden" name="action" value="check_user">
         </form>
      </table>
   </td></tr></table>
   <script language="JavaScript">
      document.form1.uid.focus();
   </script> 
   
  <?php
}

$action = strtolower($action);
switch ($action) {
   case "check_user":
      if (!$user = $db->Execute("SELECT * FROM organization WHERE username='$uid'")) {
         echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
         break;
      }
      if ($user->RecordCount() > 0) {
         if (md5($pwd) != $user->fields["password"]) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Password.</td></tr></table>";
            user_form();
            break;
         }
	   if (!$imgconf = $db->Execute("SELECT * FROM config")) {
         echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
         break;
      }
         $_SESSION["username"] = $user->fields["username"];
         $_SESSION["priv"] = $user->fields["priv"];
         $_SESSION["company"] = $user->fields["company"];
		 $_SESSION["id_company"] = $user->fields["id"];
		 $_SESSION["imgs_pub_dir"] = $imgconf->fields["imgs_pub_dir"];
         require("footer2.inc.php"); ?>
         <script language="JavaScript">
            window.location="index.php";
         </script> <?php
      }
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Username.</td></tr></table>";
      user_form();
      break;
   default:
      user_form();
      break;
}

require("footer2.inc.php"); ?>
