<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/
//		KsmsNsend.php


// $strsm = substr($smsgroupsel, 0, 2);
// echo("<table bgcolor='#3399cc' border='0'><tr><td>USER kannel = ".$EMI_User."</td></tr></table>");

function setsmsnotdeliveredstatus($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer)
//       setsmsnotdeliveredstatus($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status);
{
			$query = "UPDATE sendgatenumbs SET"
                . " mex_status='$p_status', myserv_queue ='MTCS'"
				. " WHERE id_sendgatenumbs='$smslog_id' AND id_user='$userid' AND id_organization='$KuidOrg' AND sended ='N' AND ref='$refer'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
    return;
}

function setsmsdeliverystatus($db,$userid,$KuidOrg,$p_status,$sms_to,$refer) {
	//global $okj;
	//global $datetime_now;
	//$idORG = $_SESSION["id_company"];
    $okj = false;
			 // echo "<br>id SMS = ".$smslog_id."<br>";
			 // echo "id ORGAN. = ".$KuidOrg."<br>";
			 // echo "AKK_sTaTus = ".$p_status."<br>";
			 // echo "<br>idUSERZ = ".$userid."<br>";
			$query = "UPDATE sendgatenumbs SET"
                . " sended ='Y', mex_status='$p_status', myserv_queue ='MIKV'"
				. " WHERE id_organization='$KuidOrg' AND id_user='$userid' AND sended ='N' AND ref='$refer'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
			$errsmess = "upd 2s10/25";
			$okj = false;
            break;
         }
	echo("Sms sended to the server... <b>[".$sms_to."]</b><br>");
	$okj = true;
    return $okj;
}

function setsmsonqueue($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer)
{
			$queryt = "UPDATE sendgatenumbs SET"
                . " myserv_queue ='MMER'"
				. " WHERE id_sendgatenumbs='$smslog_id' AND id_user='$userid' AND id_organization='$KuidOrg' AND sended ='N' AND ref='$refer'";
         if (!$db->Execute($queryt)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
    return;
}

function setsmsonqueue_errorkanl($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer)
{
			$queryt = "UPDATE sendgatenumbs SET"
                . " myserv_queue ='MMCT'"
				. " WHERE id_sendgatenumbs='$smslog_id' AND id_user='$userid' AND id_organization='$KuidOrg' AND sended ='N' AND ref='$refer'";
         if (!$db->Execute($queryt)) {
           echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
    return;
}

function //gw_send_sms($db,$mobile_sender,$sms_sender,$sms_to,$Kmessage,$grp_code,$KuidOrg="",$smslog_id="",$sms_id,$sms_type,$KsmsURL,$gwconnects,$flash=false)
// $db,$gwconnects,$sms_message,$mobile_sender,$sms_to,$KuidOrg,$sms_type,$KsmsURL,$userid,$sms_id
gw_send_sms($db,$gwconnects,$sms_message,$mobile_sender,$sms_to,$smslog_id,$KuidOrg,$sms_type,$KsmsURL,$userid,$sms_id,$refer,$Kmessage,$flash=false)
 {
	global $gateway_number;
//			$gatefile = $gwfile->fields["original_gwfile_name"];
			$EMI_User = $gwconnects->fields["EMIuser"];
			$EMI_Pass = $gwconnects->fields["EMIpass"];
			$UCP_BxIP = $gwconnects->fields["bareboxIP"];
			$UCP_KPrt = $gwconnects->fields["KanlSmsPort"];
			$www_source = "http://".$_SERVER['SERVER_ADDR'];
			// PUT THIS VARIABLE OLN THE CONFIG FILE
			$K192URL = "http://192.168.2.90";
			$KwwwURL=$KsmsURL;
	//echo("<table bgcolor='#F7EC2B' border='0'><tr><td>SERVER IP = ".$www_source ."</td></tr></table>");
	//echo("<table bgcolor='#F7EC2B' border='0'><tr><td>COMPLETE URL = ".$KsmsURL."</td></tr></table>");
	//echo("<table bgcolor='#F7EC2B' border='0'><tr><td>USER kannel = ".$EMI_User."</td></tr></table>");
	//echo("<table bgcolor='#F7EC2B'><tr><td>001.INVIO AL NUMERO: ".$sms_to."</td></tr></table>");
	//echo "<br>||| <b>IDsms|numero selezionato:::::::</b> = ".$smslog_id."|" .$sms_to." ---------<br>";
	
    $okj = false;
    if ($gateway_number)
    {
	$sms_from = $gateway_number;
   }
    else
    {
	$sms_from = $mobile_sender;
    }
//    if ($sms_sender)
//    {
//	$sms_msg = $sms_msg.$sms_sender;
//    }
    // set failed first --- errorcode 2 = messagge not delivered to SMSC (non delivered to SMSC)
    $p_status = 2;
    setsmsnotdeliveredstatus($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer);
    $sms_type = 2; // text
	if ($flash)
		{
			$sms_type = 1; //flash
		}
		
	//  If you want multiple report types, you simply add the values together.
	//	For example, if you want to get delivery success and/or failure you
	//	set the dlr-mask value of 3 (1+2). If you specify dlr-mask on the URL
	//	you pass on to Kannel, you also need to specify dlr-url. dlr-url should
	//	contain the URL to which Kannel should place an HTTP_GET requests once
	//	the delivery report is ready to be delivered back to your system.
	// 		Use dlr-mask=31 to get all possible values of delivery status!
	// The URL is where KANNEL contact the script    (local, in this case!!!)
	//	(e.g.: if KANNEL is on 190.10.10.0, URL= http://190.10.10.0/... )
	
// $URL = $K192URL."/cgi-bin/sendsms?username=".urlencode($EMI_User)."&password=".urlencode($EMI_Pass);
    $URL = "/cgi-bin/sendsms?username=".urlencode($EMI_User)."&password=".urlencode($EMI_Pass);
    $URL .= "&from=".urlencode($sms_from)."&to=".urlencode($sms_to)."&text=".urlencode($Kmessage);
    $URL .= "&dlr-mask=31&dlr-url=".urlencode($KwwwURL."/plugin/gateway/kanl_dlr.php?type=%d&datez=%t&slid=$sms_id&uid=$userid&orgz=$idORG");
    $URL .= "&mclass=$sms_type";

//191.148.0.0/KSMS/cgi-bin/sendsms?username=&password=&from=Miosender&to=393482680840&text=prova+SMS+numero+2+%21%21%21%21%21%21%21%21%21%21%21%21&dlr-mask=31&dlr-url=%2Fplugin%2Fgateway%2Fkanl_dlr.php%3Ftype%3D%25d%26slid%3D%26uid%3D&mclass=2

// Delivered reports from KANNEL:
//			1: delivery success
//			2: delivery failure
//			4: message buffered
//			8: smsc submit
//			16: smsc reject


// #############Test variables###############################
//
// echo "<br>";
// echo "<br>Variable URL = ".$KsmsURL."<br>";
// echo "<hr>";
// echo "<br>EMI_USER = ".$EMI_User."";
// echo "<br>EMI_PWD = ".$EMI_Pass."";
// echo "<br>mobilesender:smsFROM = ".$sms_from."";
// echo "<br>smsTO = ".$sms_to."";
// echo "<br>smsMESSAGGGE! = ".$Kmessage."";
// echo "<br>smsID = ".$sms_id."";
// echo "<br>ID_ORGANIZ = ".$KuidOrg."";
// echo "BareBox_IP: ".$UCP_BxIP."<br>";
// echo "BareBox_Port: ".$UCP_KPrt."<br>";
// echo "ProgramUrl: ".$PrgmURL."<br>";		 //   http://191.148.0.0/KSMS
// echo("<table bgcolor='#F7EC2B' border='0'><tr><td>___URL encoded PRGM = ".$URL."</td></tr></table>");
// echo "<hr>";

	// ini_set("max_execution_time", "99");
	$connection = fsockopen($UCP_BxIP, $UCP_KPrt, $errno, $errstr, 60);
	$errsmess = "";
/* **************************************************************************************** */
    	if($connection) 
    	{
	//socket_set_blocking($connection, false);
	stream_set_blocking($connection, false);
		fputs($connection, "GET $URL HTTP/1.0\r\n\r\n");
		//fputs($connection, "GET $URL HTTP/1.1\r\n\r\n");
			while (!feof($connection)) 
				{
	    			$myline = fgets($connection, 128);
						//echo "error: connection to internal gatewa failed! ... <b> ".$myline."</b><br>";
	    			if ($myline == "Sent.")
	    			  {
						$okj = true;
						$p_status = 0;   // queue to kannel (set pending-queued on SMSC)
		setsmsdeliverystatus($db,$userid,$KuidOrg,$p_status,$sms_to,$refer);
							// setsmsdeliverystatus($db,$sms_id,$userid,$KuidOrg,$p_status,$sms_to);
	    			          }
					 elseif ($myline != "Sent.") {
						setsmsonqueue($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer);
					// TESTING /////////////////////////////////////////////////////////
						// echo "<p class='testing'>".$myline."</p>";
						       }
					}
     fclose ($connection);
    		}
	else {
			$okj = false;
			setsmsonqueue_errorkanl($db,$smslog_id,$KuidOrg,$userid,$sms_id,$p_status,$refer);
		if ($errstr=="Connection refused")
			{ $errstr="BBOX ERROR ::: PLEASE CONTACT SYS_ADMIN!"; }
		$errsmess = "SUB725AS-".$errno." )<br>Internal Gateway Connection!!!<br>(".$errstr." ";
		}
   // \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\  fclose ($connection);
	 $sendtomyserver = true;
 // ********************************************************************************** //
    return array($okj,$errsmess,$sendtomyserver);
 }


?>





