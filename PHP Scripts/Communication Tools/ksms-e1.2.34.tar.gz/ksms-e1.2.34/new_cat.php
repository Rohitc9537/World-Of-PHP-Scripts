<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// gestione categorie :::
$title = "Add Categories";
require("common.inc.php"); 
?>

<?php
function display_form($db) {
  // $cats = $db->Execute("SELECT descrip, id FROM category ORDER BY descrip"); ?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
       <tr class="row_head"> 
         <td><b>New Category for Users</b></td>
         <td align="right">CATEGORY</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="400">
   <form action="new_cat.php" method="post" name="form1">	   
       <tr class="row_even"> 
         <td align="right">Insert Date:</td>
         <td>
           <?php echo date("Y-m-d"); ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Category:</td>
         <td>
			<input type="text" name="descrip" size="40" value="">
         </td>
       </tr>
       <tr class="row_foot"> 
         <td colspan="2"> <div align="center">
            <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
               onClick="document.form1.submit();">
            <a href="new_cat.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">  
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.descrip.focus();
   </script> <?php
} ?>

<?php
if ($priv > 5) {
   $action = strtolower($action);
   switch ($action) {
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The category number $id was successfully added!.</td></tr></table>";
		  display_form($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  display_form($db);
         break;
      case "create":
		 if ($descrip == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description for this category!</td></tr></table>";
            display_form($db);
            break;
         }
         $cat_number = $db->GenID("category_seq");
		 $descrip = addslash_text($descrip);
         $query = "INSERT INTO category (intid, ins_date, descrip)"
                . " VALUES ('$cat_number', '$date', '$descrip')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ed_cat.php?action=inkey&id=<?php echo $cat_number; ?>";
         </script> <?php
         break;
      default:
         display_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See KSMS  administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
