<?

include "config.inc";

$t = $_GET['t'];
$q = $_GET['q'];
$a = $_GET['a'];

if ($t && $q && $a)
{
    $sms_datetime = trim($t);
    $sms_sender = trim($q);
    $message = trim($a);
    $array_target_code = explode(" ",$message);
    $target_code = strtoupper(trim($array_target_code[0]));
    $message = $array_target_code[1];
    for ($i=2;$i<count($array_target_code);$i++)
    {
	$message .= " ".$array_target_code[$i];
    }
    // collected:
    // $sms_datetime, $sms_sender, $target_code, $message
    setsmsincomingaction($sms_datetime,$sms_sender,$target_code,$message);
}


// check incoming SMS for available codes
// and sets the action


function setsmsincomingaction($sms_datetime,$sms_sender,$target_code,$message)
{
    $ok = false;
	
		$getquery = "INSERT INTO gwkannel_geturl (smslog_id,sms_datetime,sms_sender,target_code,ksmsmessage,kannel_dlr_type)"
					. " VALUES ('$smslog_id','$sms_datetime','$sms_sender','$target_code','$ksmsmessage','$kannel_dlr_type')";
		if (!$db->Execute($getquery)) 
			{
			echo "<table bgcolor='#ffff00' width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         	}
	
	
	
	
	
	
	
	
/*
    switch ($target_code)
    {
	case "BC":
	    $array_target_group = explode(" ",$message);
	    $target_group = strtoupper(trim($array_target_group[0]));
	    $message = $array_target_group[1];
	    for ($i=2;$i<count($array_target_group);$i++)
	    {
		$message .= " ".$array_target_group[$i];
	    }
	    if (send2group($sms_sender,$target_group,$message))
	    {
		$ok = true;
	    }
	    break;
	case "PV":
	    $array_target_user = explode(" ",$message);
	    $target_user = strtoupper(trim($array_target_user[0]));
	    $message = $array_target_user[1];
	    for ($i=2;$i<count($array_target_user);$i++)
	    {
		$message .= " ".$array_target_user[$i];
	    }
	    if (insertsmstoinbox($sms_datetime,$sms_sender,$target_user,$message))
	    {
		$ok = true;
	    }
	    break;
	default:
	    // maybe its for sms autoreply
	    $db_query = "SELECT autoreply_id FROM playsms_featAutoreply WHERE autoreply_code='$target_code'";
	    if ($db_result = dba_num_rows($db_query))
	    {
		if (processautoreply($sms_datetime,$sms_sender,$target_code,$message))
		{
		    $ok = true;
		}
	    }
	    // maybe its for sms poll
	    $db_query = "SELECT poll_id FROM playsms_featPoll WHERE poll_code='$target_code'";
	    if ($db_result = dba_num_rows($db_query))
	    {
		if (savepoll($sms_sender,$target_code,$message))
		{
		    $ok = true;
		}
	    }
	    // or maybe its for sms command
	    $db_query = "SELECT command_id FROM playsms_featCommand WHERE command_code='$target_code'";
	    if ($db_result = dba_num_rows($db_query))
	    {
		if (execcommand($sms_datetime,$sms_sender,$target_code,$message))
		{
		    $ok = true;
		}
	    }
	    // or maybe its for sms custom
	    $db_query = "SELECT custom_id FROM playsms_featCustom WHERE custom_code='$target_code'";
	    if ($db_result = dba_num_rows($db_query))
	    {
		if (processcustom($sms_datetime,$sms_sender,$target_code,$message))
		{
		    $ok = true;
		}
	    }
	    // its for sms board
	    $db_query = "SELECT board_id FROM playsms_featBoard WHERE board_code='$target_code'";
	    if ($db_result = dba_num_rows($db_query))
	    {
		if (insertsmstodb($sms_datetime,$sms_sender,$target_code,$message))
		{
		    $ok = true;
		}
	    }
    }
*/
    return $ok;
}


?>