<?
/* http://192.168.0.9/KSMS/plugin/gateway/kanl_dlr.php?type=%d&datez=%t&slid=$sms_id&uid=$userid&orgz=$idORG
http://192.168.0.9/KSMS/plugin/gateway/kanl_dlr.php?type=1&datez=20050402&slid=9&uid=$userid&orgz=$idORG

*/
include "config.inc";

function setkanldeliverystatus($db,$slid,$uid,$p_status,$orgz)
{
			$query = "UPDATE sendgatenumbs SET"
                . " mex_status='$p_status', myserv_queue='MKKN'"
				. " WHERE id_organization='$uid' AND id_sendtogate='$sms_id' AND myserv_queue='MIKV'";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
    return;
}

// $...kanl_dlr.php?type=%d&datez=%t&slid=$smslog_id&uid=$Kuid&orgz=$idORG&mclass=$sms_type
$type = $_GET['type'];
$slid = $_GET['slid'];
$uid = $_GET['uid'];
$orgz = $_GET['orgz'];
$out_datetime = $_GET['datez'];

// if ($slid && $uid)
if ($type && $slid && $uid && $orgz)
{
    $stat = 0;
    switch ($type)
    {
	case 1: $stat = 6; break;	// delivered to phone
	case 2: $stat = 5; break;	// non delivered to phone
	case 4: $stat = 3; break;	// queued on SMSC
	case 8: $stat = 4; break;	// delivered to SMSC
	case 16: $stat = 5; break;	// non delivered to SMSC
	case 9: $stat = 4; break;
	case 12: $stat = 4; break;
	case 18: $stat = 5; break;
    }
    $p_status = $stat;
    if ($stat)
    {
	$p_status = $stat - 3;
    }
    setkanldeliverystatus($db,$slid,$uid,$p_status,$orgz);
    // log dlr
	$skaid = $db->Execute("SELECT kannel_dlr_id FROM gwkannel_dlr WHERE smslog_id='$slid'");
	if ($skaid->RecordCount() > 0)
			{
			$kaquery = "UPDATE gwkannel_dlr SET kannel_dlr_type='$type',out_datetime='$out_datetime' WHERE smslog_id='$slid'";
         		if (!$db->Execute($kaquery)) 
					{
				echo "<table bgcolor='#ffff00' width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            	break;
         			}
			} // end ($skaid->RecordCount() > 0)
	    else
    {
				$kaNquery = "INSERT INTO gwkannel_dlr (smslog_id,kannel_dlr_type,out_datetime)"
                . " VALUES ('$slid','$type','$out_datetime')";
         		if (!$db->Execute($kaNquery)) 
					{
				echo "<table bgcolor='#ffff00' width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            	break;
         			}
	}
 }    // end   if ($type && $slid && $uid && $orgz)


/*
 // log dlr
    $db_query = "SELECT kannel_dlr_id FROM playsms_gwmodKannel_dlr WHERE smslog_id='$slid'";
    $db_result = dba_num_rows($db_query);
    if ($db_result > 0)
    {
	$db_query = "UPDATE playsms_gwmodKannel_dlr SET kannel_dlr_type='$type' WHERE smslog_id='$slid'";
	$db_result = dba_query($db_query);
    }
    else
    {
	$db_query = "INSERT INTO playsms_gwmodKannel_dlr (smslog_id,kannel_dlr_type) VALUES ('$slid','$type')";
	$db_result = dba_query($db_query);
    }
}
*/

?>