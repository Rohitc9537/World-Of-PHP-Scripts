<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

// emplate sms messages::: 
$title = "SMS Template";
require("common.inc.php"); 
?>

<?php
function edit_templ_form($db, $tid) {
   global $uid, $tid, $t_title, $t_text;
   $edtmpl = $db->Execute("SELECT * FROM SmsTemplate WHERE tid='$tid'");
   if ($tid == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a valid Message!</td></tr></table>";
      paint_table($db);
      return FALSE;
   }
   if (!$edtmpl = $db->Execute("SELECT * FROM SmsTemplate WHERE tid='$tid'")) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($edtmpl->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Message not found.</td></tr></table>";
      paint_table($db);
      return FALSE;
 }
 	$mt_text = $edtmpl->fields["t_text"];
	$mt_text = view_text_specialchars($mt_text);
	$idORG = $_SESSION["id_company"];
	$company = $_SESSION["company"];
  ?>
  
  
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="450">
       <tr class="row_head"> 
         <td><b>Modify Template</b></td>
         <td align="right">data</td>
       </tr>
	   </table>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="450">
   <form action="menu.php?incm=sms_template&opron=update" method="post" name="tmplform">   
       <tr class="row_foot"> 
         <td align="right" class="box_text">Operator</td>
         <td>
           <?php echo $company; ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right" class="box_text">Template-name:</td>
         <td class="box_text">
			<input type="text" name="t_title" size="40" maxlength="100" value="<?php echo $edtmpl->fields["t_title"]; ?>">
         </td>
       </tr>
	   <tr class="row_even">
         <td align="right" class="box_text">Message:</td>
         <td class="box_text">
		 <?PHP 
			$Ktext = $edtmpl->fields["t_text"];
			include("areatemplateSV.inc.php"); ?>
         </td>
       </tr>
	   <tr>
              <td class="row_foot" colspan="2" nowrap>
           <img src="images/pub/bt_update.gif" border="0" alt="Modifica" onClick="document.tmplform.submit();">
           <a href="Ksms_template.php?opron=Abort"><img src="images/pub/bt_cancel.gif" border="0" alt="Annulla"></a>
            </td>
         </tr>
   	  <input type="hidden" name="tid" value="<?php echo $tid; ?>">
      <input type="hidden" name="opron" value="update">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.tmplform.t_title.focus();
   </script> 
 <?php
} 
 ?>

<?php
// ADD _ INSERT
function add_form($db) {
$company = $_SESSION["company"];
$idORG = $_SESSION["id_company"];
?>
  <br><br>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="600">
       <tr class="row_head"> 
         <td colspan="2"><b>Add Template</b>&nbsp;&nbsp;&nbsp;
		 <font size="-2">(data-add)</font></td>
       </tr>
   <form action="menu.php?incm=sms_template&opron=add_yes" method="post" name="tmplform">   
       <tr class="row_even"> 
         <td class="box_text">Operator</td>
         <td>
           <?php echo $company; ?>
         </td>
       </tr>
       <tr class="row_even">
         <td class="box_text">Template-name:</td>
         <td>
			<input type="text" name="t_title" size="40" maxlength="100">
         </td>
       </tr>
	   <tr class="row_even">
         <td class="box_text">Message:</td>
         <td>
			<?PHP 
			$Ktext = "";
			include("areatemplateSV.inc.php"); ?>
         </td>
       </tr>
	   <tr class="row_even">
         <td colspan="2" class="desc_mini">
			Every filed is required!
         </td>
       </tr>
       <tr class="row_foot"> 
         <td colspan="2"> <div align="center">
            <img src="images/pub/bt_save.gif" border="0" alt="Save Template"
               onClick="document.tmplform.submit();">
            <a href="Ksms_template.php?opron=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
	 <input type="hidden" name="idORG" value="<?php echo ("$idORG"); ?>">
     <input type="hidden" name="opron" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.tmplform.t_title.focus();
   </script> <?php
} ?>

<?php
// Show the template's list
function paint_table($db) {
	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
   	// $opron = $_GET[opron];
	// $gpid = $_GET[gpid];
	// $pid = $_GET[pid];
	$tid = $_GET[tid];
    $tmplt = $db->Execute("SELECT * FROM SmsTemplate WHERE uid='$idORG' ORDER BY 't_title'");
   if ($idORG == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Operation Not Allowed (User failed).</td></tr></table>";
      return FALSE;
   }
	$fm_name = "fm_smstemp";
    	$contents1 .= "
		<br>
	    <p class='news_title'>templates list <font size='-1'>(dati non condivisi)</font></p>
		";
		$contents2 .= "
	    <h4 class='dect_bar'>
		<a href=\"menu.php?incm=sms_template&opron=add_template\">[ Add message template ]</a>
		</h4>
	    <br>
		";
		$contents3 .= "
	    <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
	    <form name=\"$fm_name\" action=\"menu.php?incm=sms_template&opron=delete\" method=post>
	    <tr class='row_head'>
		<td width='4%'>&nbsp;&nbsp;</td>
		<td width='22%'>Titolo</td>
		<td width='70%'>Testo Template</td>
		<td align='center'><input type=checkbox onclick=CheckUncheckAll(document.".$fm_name.")></td>
	    </tr>
	";
	
echo $contents1;
// echo $contents2;
echo $contents3;

      $i = 1;
      while (!$tmplt->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } ?> 
		 <td class="mini_Wtext" width='4%'>&nbsp;<?php echo $i; ?>&nbsp;</td>
            <td class="mini_Wtext" width='22%'>
               <a href="menu.php?incm=sms_template&opron=edit_template&tid=<?php echo $tmplt->fields["tid"]; ?>&title=<?php echo $tmplt->fields["t_title"]; ?>">
                  <?php echo $tmplt->fields["t_title"]; ?>&nbsp;</a>
            </td>
            <td class="mini_Wtext" width='70%'><a href="menu.php?incm=sms_template&opron=edit_template&tid=<?php echo $tmplt->fields["tid"]; ?>&title=<?php echo $tmplt->fields["t_title"]; ?>"><?php echo $tmplt->fields["t_text"]; ?></a>
			</td>
   <td class="mini_Wtext" align="center">
	<input type="hidden" name="tid<?php echo $i; ?>" value="<?php echo $tmplt->fields["tid"]; ?>">
	<input type="checkbox" name="chkid<?php echo $i; ?>">
   </td>
  </tr> <?php
         $i++;
         $tmplt->MoveNext();
      } ?>
  <tr class="row_foot"> 
   <td colspan="4">
   <table width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
    <td width="70%">
		<div align="right"><a href="menu.php?incm=sms_template&opron=add_template">
		<img src="images/pub/bt_AddTemplate.gif" alt="Aggiungi una template" border="0">
		</a></div>
	</td>
    <td width="30%"><div align="right">
		<select name="action"><option value="delete">Delete templates selected</option></select>
		<input type="submit" value="Go" class="button">
		</div></td>
</tr>
</table>

	    

   </td></tr>
  </table>
	<input type="hidden" name="item_count" value="<?php echo $i; ?>">
	</form>
		<br>
 <?php
} ?>


<?php
$priv = $_SESSION["priv"];
if ($priv > 3) {
   $opron = strtolower($opron);
   switch ($opron) {
      	  case "list":
         echo "<table class=\"news\" width=\"100%\"><tr><td>$err</td></tr></table><br>";
			paint_table($db);
         break;
   	  case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation Aborted!</td></tr></table><br>";
			paint_table($db);
         break;
	   case "add_template":
            add_form($db);
            break;
      case "inkey":
         echo "<table class=\"news\" width=\"100%\"><tr><td>The message <b>&quot;$title&quot;</b> was inserted!.</td></tr></table>";
		  paint_table($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation Aborted!</td></tr></table>";
		  paint_table($db);
         break;
	  case "delete":
	  $idORG = $_SESSION["id_company"];
	  $item_count = $_POST[item_count];

		for ($i=1;$i<=$item_count;$i++)
			{
	    ${"tid".$i} = $_POST["tid".$i];
	    ${"chkid".$i} = $_POST["chkid".$i];
			}

			//echo (${"chkid".$i}."<br>");
		$delcontent1 = "
	    <p class='news_title'>Delete one or more templates</p>
		<br>
	    <form action=\"menu.php?incm=sms_template&opron=delete_yes\" method=\"post\">
	    <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
	    <tr class='row_head'>
		<td width='4%'>&nbsp;&nbsp;</td>
		<td width='22%'>Name</td>
		<td width='70%'>Template</td>
	    </tr>
	";
	//$delTMP = $db->Execute("SELECT * FROM SmsTemplate WHERE tid='".${"tid".$i}."'");
	$templdel = $db->Execute("SELECT * FROM SmsTemplate WHERE uid='$idORG'");
	$j = 0;
	//for ($i=1;$i<=$item_count;$i++)
	
	$i = 1;
      while (!$templdel->EOF) {
         if ($i % 2 == 0) {
            $delcontent2 .=  "<tr class=\"row_scd\">";
         		} else {
            $delcontent2 .=  "<tr class=\"row_fst\">";
         		}
				
	    if (${"chkid".$i} == "on")
		//if ($delTMP->fields["chkid"] == "on")
	    {
		$j++;
		$delcontent2 .= "
	    		<td class=\"mini_Wtext\">&nbsp;$j&nbsp;</td>
	    		<td class=\"mini_Wtext\">&nbsp;".$templdel->fields["t_title"]."</td>
	    		<td class=\"mini_Wtext\">&nbsp;".$templdel->fields["t_text"]."</td>
	    		<input type='hidden' name='tid".$j."' value='".${"tid".$i}."'>
		    </tr>
		";
	    }
	     $i++;
         $templdel->MoveNext();
	}
	$delcontent2 .= "
	    </table>
	    <input type=\"hidden\" name=\"item_count\" value=\"$j\">
	    <p class=\"tblfdata\"> Are you sure to delete this template ? </p> &nbsp;&nbsp;
	    <div align='center'><input type=\"submit\" value=\"CANCELLA\" class=\"button\"></div>
	    </form>
	    <a href=\"menu.php?incm=sms_template&opron=list\">
		<img src='images/pub/bta_back.gif' alt='back' border='0' align='middle'>
		</a>
	";
	echo $delcontent1;
	echo $delcontent2;
	break;

	  /*
          if (!$db->Execute("DELETE FROM groups WHERE id='$uid'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>groups $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
	*/
      case "create":
		 if ($t_title == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must insert a valid title-name !</td></tr></table>";
            add_form($db);
            break;
         }
		 if ($t_text == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must insert a valid text for that template</td></tr></table>";
            add_form($db);
            break;
         }
		 $t_text = addslash_text($t_text);
		 $t_title = addslash_text($t_title);
         $query = "INSERT INTO SmsTemplate (uid,t_title,t_text)"
                . " VALUES ('$idORG', '$t_title', '$t_text')";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="Ksms_template.php?opron=inkey&title=<?php echo ("$t_title"); ?>";
         </script> <?php
         break;
      case "update":
         if ($tid == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the groups.</td></tr></table>";
            paint_table($db);
            break;
         }
		 $t_title = addslash_text($t_title);
		 $t_text = addslash_text($t_text);
         $query = "UPDATE SmsTemplate SET"
                . " t_title='$t_title', "
				. " t_text='$t_text'"
                . " WHERE tid='$tid'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="Ksms_template.php";
         </script> <?php
         break;
	  case "edit_template":
         edit_templ_form($db, $tid);
		 	break;
      default:
         paint_table($db);
	  case "delete_yes":
	  
	  //////////////////// TO DO : WATCH AND MODIFY .... /////////////////////////
	  
	$item_count = $_POST[item_count];
	for ($i=1;$i<=$item_count;$i++)
	{
	    ${"tid".$i} = $_POST["tid".$i];
	}
	for ($i=1;$i<=$item_count;$i++)
	{
	    //$db_query = "DELETE FROM SmsTemplate WHERE tid='".${"tid".$i}."'";
	    //$db_result = dba_affected_rows($db_query);
		$templdel = $db->Execute("DELETE FROM SmsTemplate WHERE tid='".${"tid".$i}."'");
	}
	$error_string = "All selected templates are deleted!";
	//header ("Location: menu.php?incm=sms_template&opron=list&err=".urlencode($error_string));
	echo "<br><br><div align='center'><b><a href='menu.php?incm=sms_template&opron=list&err='.urlencode($error_string)'>BACK</a></b></div>";
	break;
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See Ksms administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
