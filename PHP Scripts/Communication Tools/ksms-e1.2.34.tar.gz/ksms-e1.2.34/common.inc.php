<?php

// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/


session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $company = $_SESSION["company"];
   $id_company = $_SESSION["id_company"];
   $imgs_pub_dir = $_SESSION["imgs_pub_dir"];
} else {
   header("Status: 302 moved");
   header("Location: login.php");
}

// Tell browsers not to cache this page
header("Expires: Mon, 23 Jul 2000 07:00:07 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");

// Include required files
require("grab_globals.inc.php");
require("config.inc.php");
require("connection.inc.php");
require("header.inc.php");

// Some functions needed by several pages. Try to move functions required often
// to this file.


function paged_query($db, $page = 1) {
// Used by search_*.php to generate paged recordsets.
   global $cfg;
   // First, check for an empty result.
   if (!$rstest = $db->SelectLimit($_SESSION["search_query"], 1)) {
      echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($rstest->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Your search returned 0 results.</td></tr></table>";
      return FALSE;
   }
   $rstest->Close();
   // Recordset is not empty so go ahead and page it.
   if (!$summary = $db->PageExecute($_SESSION["search_query"], $cfg["lpp"], $page)) {
     echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   return $summary;
}

/*
ORIGINAL SYSTEM FOR VALIDATE ENGLISH DATE
*/
function valid_date($date) {
// Converts shortcut to valid date, or validates date input format. Returns
// a valid date in ANSI format or FALSE on error.
   if (eregi("^(t{1})([\+\-]?)([0-9]*)$", $date, $shortcut)) {
      if ($shortcut[2] == "-") {
         $date = date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") - $shortcut[3], date("Y")));
      } else {
         $date = date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") + $shortcut[3], date("Y")));
      }
      return $date;
   }
   if (ereg("^[0-9]{4}\-{1}[0-9]{2}\-{1}[0-9]{2}$", $date)) {
      return $date;
   }
   return FALSE;
}

function addslash_text($valuetxt) {
// Add the necessary slashes in a text that contains a single quote:  (') ---> (\')
// $valuetxt = htmlspecialchars($valuetxt);
$valuetxt = addslashes($valuetxt);
	return $valuetxt;
}

function view_text_specialchars($specialtxt) {
// for viewing a text with a special characters (html)
$specialtxt = htmlspecialchars($specialtxt);
	return $specialtxt;
}

?>

