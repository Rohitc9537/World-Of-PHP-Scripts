<?php

// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		| 	config.inc.php*/





/*
// *** USE IT ONLY FOR TESTING THESE SCRIPTS *** //
// Inser the authorized domain
	$domauth = 'xxxyyy.xx';
// Insert the host-name
	$authorizedhost = 'www.xxxyyy.xx';
// Insert the IP
	$authorizedIP = '192.168.0.9';

############################################################
# CHECK IF HOST IS OK 
############################################################
// TESTING -----------------------------------------------
// echo("<BR>Server Name = ".$SERVER_NAME."<BR>");
// echo("<BR>Authorized Host = ".$authorizedhost."<BR>");
// echo("<BR>SERVER IP = ".$SERVER_ADDR."<BR>");
// echo("<BR>Authorized IP = ".$authorizedIP."<BR>");

// if ($SERVER_NAME != $HostAutorizzato)
if ($SERVER_ADDR != $IPautorizzato)
	{
		// unauthorized!
		echo("<b>Page not found.Please Try Again.</b> <br><b></b>");
		include("err_foot.inc.php");
		exit;
	};

*/

// Ksms version string.
/// look at file: vers.inc.php
///  $cfg["version"] = "xxxxx";
require("vers.inc.php");
$cfg["signature"] = "Ksms - Assiplan sms system " . $cfg["version"];
$cfg["sysver"] = "KSMS " . $cfg["version"];

// Database connection parameters.
$cfg["db_type"] = "mysql";      // DB server type eg: mysql, postgres, sqlite, odbc. See ADODB docs.
$cfg["db_host"] = "localhost";  // DB server hostname. DSN if odbc OR /path/filename if sqlite.
$cfg["db"] = "ksmsDB";           // Ksms database. Not used if odbc or sqlite.
$cfg["uid"] = "user";       // DB server user id.
$cfg["pwd"] = "password";       // DB server password.
$cfg["db_persist"] = FALSE;     // Use persistent database connection. TRUE or FALSE.
// For debuggin (view) in "connection.inc.php". TRUE or FALSE.
//$cfg["view_debug"] = TRUE;
$cfg["view_debug"] = FALSE;

// Miscellaneous configuration parameters.
$cfg["curr"] = "�  ";        // Local currency symbol. eg: $, �, � etc.

/////////////////////////////////////////////////////////////////////////
// the paths and other configuration in local (not in database!)       //
/////////////////////////////////////////////////////////////////////////

// "unix" or "win"
$cfg["os"] = "unix";

// Full path to ksms directory.
$cfg["basedir"] = "/home//public/KSMS";

// Full path to files with data of sended messages...NO TRAILING SLASH!... chmod666.........
$cfg["sendeddir"] = "/home/sms_sended";

// Full path to where is the gateway's file ...NO TRAILING SLASH!... chmod666 or 777.........
$cfg["gatewdir"] = "/home/sms_sended/gateways";

// Full path to where is the MASTER or ORIGINAL gateway's file ...NO TRAILING SLASH!... chmod666
// This is for old version.
$cfg["mastergwd"] = "/home/....gateways/MasterGatewayFiles";

// This method is in implementation...
// TODO : put the language variable in a separte function and in session....
include('lang/english.php');

?>
