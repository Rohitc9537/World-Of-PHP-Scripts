<?php
// -------------------------------------------------------------------------//
// KSMS ^ Short Message System Manager										//
// -------------------------------------------------------------------------//
// Based on "DBSMS" (C) 2002 Paolo Remonato									//
// Copyright (C) 2002-2005 Paolo Remonato									//
// KSMS-PROJECT HOME  :  http://ksms.sourceforge.net/						//
// -------------------------------------------------------------------------//
//   Please,do not delete these lines	^^^									//
// -------------------------------------------------------------------------//
/*
  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation.
  The software is provided "as is" without any express or implied warranty of any kind,
  Including warranties of noninfringement, merchantability, or fitness for a particular purpose.  
*/
/* 	2005 05 21		|*/

//    subgroup manager     //
$title = "Sub Group Manager";
require("common.inc.php"); 

function edit_group_form($db, $idsubgroup) {
   //global $subgroup, $idsubgroup, $descript, $ins_date;
   	$idORG = $_SESSION["id_company"];
   if ($idsubgroup == "") {
      echo "<p class='news'>You must select a valid Subgroup ID.</p>";
      paint_table($db);
      return FALSE;
   }
	if (!$selsubgrp = $db->Execute("SELECT * FROM subgroup WHERE id='$idsubgroup' AND id_organization='$idORG'")) {
     echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
      return FALSE;
   }
   if ($selsubgrp->RecordCount() == 0) {
      echo "<p class='news'>Subgroup not found.</p>";
      paint_table($db);
      return FALSE;
 }
 		$description = $selsubgrp->fields["descript"];
		$description = view_text_specialchars($description);
 		$id_relative_group = $selsubgrp->fields["idgroup"];
		$id_subgrp = $selsubgrp->fields["id"];
		$insert_date = $selsubgrp->fields["ins_date"];
		$id_organz = $selsubgrp->fields["id_organization"];
		$company_name = $selsubgrp->fields["organization"];
	$selcgroup = $db->Execute("SELECT descrip, id FROM groups WHERE id='$id_relative_group' AND id_organization='$idORG'");
		$group_name = $selcgroup->fields["descrip"];
		$group_id = $selcgroup->fields["id"];
  ?>
  <br>
<table class="default" align="center" border="0" cellspacing="0" cellpadding="0">
      <form name="form1a" method="post" action="ne_subgroup.php">
	  	  <tr class="row_head"> 
            <td colspan="4" nowrap><font color="#FFFF00"><b>YOU CAN NOT MODIFY SOME DATA IN SUBGROUP AREA!!!</b></font>
			</td>
         </tr>
		 <tr class="row_head"> 
            <td colspan="4"><hr></td>
         </tr>
	  <tr class="row_head"> 
            <td colspan="4" nowrap><b>Modify Subgroup</b>&nbsp; 
			<font size="-1">(cod. <?php echo "20122".$idsubgroup ?>)</font>
			</td>
         </tr>
	  <tr class="row_even"> 
            <td colspan="2" nowrap><b>ksms bulk manager!</b></td>
         </tr>		 
         <tr class="row_even"> 
            <td nowrap align="right">Insert Date : &nbsp;</td>
            <td><?php echo $selsubgrp->fields["ins_date"]; ?>&nbsp;</td>
		</tr>
		<tr class="row_even">
            <td nowrap align="right">
			Description : &nbsp;
			</td>
      		<td>
			<input type="text" name="descript" size="40" value="<?php echo ("$description"); ?>"> &nbsp;
			</td>
         </tr>
		 <tr class="row_even">
            <td nowrap align="right">
			Group : &nbsp;
			</td>
      		<td class="woman_in_white">
			<?php 
			//echo $selcgroup->GetMenu2("subgroups", $id_relative_group, FALSE, FALSE, 0); 
			echo $group_name;
			?>
			</td>
         </tr>	
		 <tr class="row_foot"> 
            <td colspan="2" nowrap><div align="center">
               <img src="images/pub/bt_update.gif" border="0" alt="Modifica"
                  onClick="document.form1a.submit();">
               <a href="ne_subgroup.php?action=Abort">
			   	  <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla">
			   </a>
                  <img src="images/pub/bt_delete.gif" alt="Elimina - Delete <?php echo $idsubgroup; ?>" border="0"onClick="if (isConfirmed('Are you sure you want to DELETE this subgroup Nr.<?php echo $idsubgroup; ?> - <?php echo $description; ?>  ?')) { window.location='ne_subgroup.php?action=delete&uid=<?php echo $idsubgroup; ?>'; }"></div>
            </td>
         </tr>
   	  <input type="hidden" name="idsubgroup" value="<?php echo $idsubgroup; ?>">
	  <input type="hidden" name="idgroup" value="<?php echo $group_id; ?>">
      <input type="hidden" name="action" value="updatesubgr">
      </form>
   </table>
   <br>
  
   <script language="JavaScript">
      document.form1a.descript.focus();
   </script> 
 <?php
} 
 ?>

<?php
// ADD _ INSERT
function display_form_sg($db) {
$company = $_SESSION["company"];
$idORG = $_SESSION["id_company"];
$groups = $db->Execute("SELECT descrip,id FROM groups WHERE id_organization='$idORG' ORDER BY descrip");
// $groupaddname = $groups->fields["descrip"];
?>
  <br><br>

   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="580">
   <form action="ne_subgroup.php" method="post" name="form2">
       <tr class="row_head"> 
         <td align="left"><b>SUBGROUP MANAGER</b></td>
         <td align="right">ksms</td>
       </tr>   
       <tr class="row_even"> 
         <td align="right">Insert Date:</td>
         <td>
           <?php echo date("Y-m-d"); ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">SubGroup Description:</td>
         <td>
			<input type="text" name="descript" size="40" value="">
         </td>
       </tr>
	   <tr class="row_even">
         <td align="right">group:</td>
         <td>
			<?php echo $groups->GetMenu("groups", "", FALSE, FALSE, 0); ?>
         </td>
       </tr>
       <tr class="row_foot"> 
         <td colspan="2"> <div align="center">
            <img src="images/pub/bt_enter.gif" border="0" alt="Enter"
               onClick="document.form2.submit();">
            <a href="ne_subgroup.php?action=cancel">
               <img src="images/pub/bt_cancel.gif" border="0" alt="Annulla-Cancel"></a></div>
         </td>
       </tr>
	 <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
	 <input type="hidden" name="idORG" value="<?php echo ($idORG); ?>">
     <input type="hidden" name="action" value="createsubgroup">
   </form>
   </table>
   <script language="JavaScript">
      document.form2.descript.focus();
   </script> <?php
} ?>

<?php
function paint_table($db) {
	$company = $_SESSION["company"];
	$idORG = $_SESSION["id_company"];
   	$summgrp = $db->Execute("SELECT * FROM subgroup WHERE id_organization='$idORG' ORDER BY descript");
?>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr>
         <td>New insert @ <b><?php echo date("Y-m-d"); ?></b>, by <font color="#808080"><?php echo ("$company"); ?></font></td>
      </tr>
   </table>   
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>#</b></td>
         <td><b>Description</b></td>
		 <td><b>Group</b></td>
      </tr> <?php
      $i = 1;
      while (!$summgrp->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_scd\">";
         } else {
            echo "<tr class=\"row_fst\">";
         } 
	$idsub = $summgrp->fields["id"];
	$idgrp = $summgrp->fields["idgroup"];
	$selmygrp = $db->Execute("SELECT * FROM groups WHERE id_organization='$idORG' AND id='$idgrp'");
	$displaygrp = $selmygrp->fields["descrip"];
	?> 
            <td>

               <a href="ne_subgroup.php?action=edit&idsubgroup=<?php echo $idsub; ?>&description=<?php echo $summgrp->fields["descript"]; ?>">
                  <?php echo $i ?></a>
            </td>
            <td> <a href="ne_subgroup.php?action=edit&idsubgroup=<?php echo $idsub; ?>&description=<?php echo $summgrp->fields["descript"]; ?>"><b><?php echo $summgrp->fields["descript"]; ?></b></a>
			</td>
			<td><?php echo $displaygrp; ?></a>
			</td>
         </tr> <?php
         $i++;
         $summgrp->MoveNext();
      } ?>
   </table>
      <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_foot">
         <td><div align="center"> <a href="ne_subgroup.php?action=addsubgrp">
			   	  <img src="images/pub/bta_Add.gif" border="0" alt="Aggiungi sottogruppo">
			   </a></div></td>
      </tr>
   </table>

 <?php
} ?>


<?php
if ($priv > 3) {
   $action = strtolower($action);
   switch ($action) {
   	  case "Abort":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted.</td></tr></table><br>";
			paint_table($db);
         break;
	   case "addsubgrp":
            display_form_sg($db);
            break;
      case "inkey":
	  	$mydescription = html_entity_decode($desc);
         echo "<table class=\"news\" width=\"100%\"><tr><td>The subgroup <b>".$mydescription."</b> was successfully added!.</td></tr></table>";
		  paint_table($db);
         break;
      case "cancel":
         echo "<table class=\"news\" width=\"100%\"><tr><td>Operation aborted!.</td></tr></table>";
		  display_form_sg($db);
         break;
	  case "delete":
          if (!$db->Execute("DELETE FROM subgroup WHERE id='$uid'")) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>subgroup $uid was deleted without errors!</td></tr></table>";
         paint_table($db);
         break;
      case "createsubgroup":
	   $idORG = $_SESSION["id_company"];
		 if ($descript == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description for this subgroup!</td></tr></table>";
            display_form_sg($db);
            break;
         }
		$kkgroups = $db->Execute("SELECT descrip FROM groups WHERE id='$groups' AND id_organization='$idORG'");
		$groupaddname = $kkgroups->fields["descrip"];
		// $selmx = $db->Execute("SELECT MAX(idgroup) FROM subgroup WHERE idgroup='$groups' AND id_organization='$idORG'");
		$selmx = $db->Execute("SELECT COUNT(*) AS posrow FROM subgroup WHERE idgroup='$groups' AND id_organization='$idORG'");
		$position = $selmx->fields["posrow"];
		if ($position == "") { $ppos = '0'; }
		else { $ppos = $position; }
		 $descript = addslash_text($descript);
		 // groupaddname   |   groups
        $querysg = "INSERT INTO subgroup (idgroup, pos, descript, groupdescr, ins_date, id_organization, organization)"
                . " VALUES ('$groups', '$ppos', '$descript', '$groupaddname', '$date', '$idORG', '$company')";
         if (!$db->Execute($querysg)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_subgroup.php?action=inkey&desc=<?php echo $descript; ?>";
         </script> <?php
         break;
      case "updatesubgr":
	   $idORG = $_SESSION["id_company"];
         if ($idsubgroup == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must provide a valid number for the subgroup.</td></tr></table>";
            paint_table($db);
            break;
         }
//		 $selupdmx = $db->Execute("SELECT COUNT(*) AS posrw FROM subgroup WHERE idgroup='$subgroups' AND id_organization='$idORG'");
//			$position = $selupdmx->fields["posrw"];
//			if ($position == "") { $ppos = '0'; }
//			else { $ppos = $position-1; }

		 $descript = addslash_text($descript);
         $query = "UPDATE subgroup SET"
			. " descript='$descript'"
			. " WHERE id='$idsubgroup'";
         if (!$db->Execute($query)) {
            echo "<p class='tbl_error'>Database Error: " . $db->ErrorMsg() . "</p>";
            break;
         }
         require("footer.inc.php"); ?>
         <script language="JavaScript">
            window.location="ne_subgroup.php";
         </script> <?php
         break;
	  case "edit":
         edit_group_form($db, $idsubgroup);
		 	break;
      default:
         paint_table($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Non hai i permessi necessari per accedere a questa area!</td></tr></table>";
}
require("footer.inc.php");
?>
