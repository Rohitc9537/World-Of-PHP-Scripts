<?php
/* ########################################################################

Copyright (C) 2003 FORTUNE DESIGN
Amazon feed Version 1.0
sales@fortunedesign.co.uk
http://www.fortunedesign.co.uk

######################################################################## */
// Amazon Config
define('ASSOCIATES_ID', 				'barelyreadboo-21');

?>
