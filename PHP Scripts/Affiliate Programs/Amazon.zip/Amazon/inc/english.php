<?php
/* ########################################################################

Copyright (C) 2003 FORTUNE DESIGN
Amazon feed Version 1.0
sales@fortunedesign.co.uk
http://www.fortunedesign.co.uk

######################################################################## */
define('TITLE', 						'Amazon Search');

define('BOX_HEADING_AMAZON_SEARCH', 	'Amazon Search');
define('AMAZON_ALLPRODUCTS', 			'All Products');
define('AMAZON_APPAREL', 				'Apparel');
define('AMAZON_BOOKS', 					'Books');
define('AMAZON_CLASSICAL', 				'Classical');
define('AMAZON_DVD', 					'DVD');
define('AMAZON_ELECTRONICS', 			'Electronics');
define('AMAZON_KITCHEN', 				'Kitchen');
define('AMAZON_MUSIC', 					'Music');
define('AMAZON_MUSIC_TRACKS', 			'MusicTracks');
define('AMAZON_OUTDOOR_LIVING', 		'OutdoorLiving');
define('AMAZON_PCHARDWARE', 			'PCHardware');
define('AMAZON_SOFTWARE', 				'Software');
define('AMAZON_VHS', 					'VHS');
define('AMAZON_VIDEO', 					'Video');
define('AMAZON_VIDEO_GAMES', 			'VideoGames');
define('AMAZON_US', 					'United States');
define('AMAZON_UK', 					'United Kingdom');
define('AMAZON_DE', 					'Germany');
define('AMAZON_JP', 					'Japan');
define('NODATA', 						'No results found');
define('MISSING_QUANTITY', 				'Unknown');
define('QUANTITY_FOUND', 				'Results Found:');
define('UNKNOWN', 						'Unknown');
define('LISTPRICE', 					'List Price');
define('OURPRICE', 						'Our Price');
define('USEDANDNEW', 					'Used & New');
define('FROM', 							'from');
define('AVAILABILITY', 					'Availability:');
define('SPACE', 						'&nbsp;');
define('IMAGE_BUTTON_ADD_TO_BASKET', 	'Add To Basket');
define('IMAGE_BUTTON_AMAZON', 			'In Association with Amazon.co.uk');
define('NEXTPAGE', 						'Next Page >>');
define('PREVIOUSPAGE', 					'<< Previous page');

?>
