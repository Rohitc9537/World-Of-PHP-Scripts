<HTML>
<HEAD>
<TITLE>Site Administration</TITLE>
</HEAD>

<FRAMESET  COLS="25%, *">
     <FRAME SRC="man.php" >
     <FRAME SRC="usedcats.php" name='principal'>

</FRAMESET>

</HTML>

