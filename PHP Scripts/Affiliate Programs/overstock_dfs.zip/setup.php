<html>
<head>
<style type="text/css">
body {font-family: arial}
</style></head>

<body bgcolor='#CCCCFF'>

<form action=dbsettings.php method='post'><center>
<table>
<tr><td ><b>Database </b></td><td><input type='text' name='database'></td></tr>
<tr><td ><b>Database Username</b></td><td><input type='text' name='username'></td></tr>
<tr><td ><b>Database Password</b></td><td><input type='password' name='password'></td></tr>
<tr><td ><b>Administration Username</b></td><td><input type='text' name='adusername'></td></tr>
<tr><td ><b>Administration Password</b></td><td><input type='password' name='adpassword'></td></tr>

<tr><td colspan=2><input type='submit' name='Submit'></td></tr>
</table>
</form>
