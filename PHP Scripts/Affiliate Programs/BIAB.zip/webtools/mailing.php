<?php
#####################################################################################
##										                       ##
##    Bravenet-In-A-Box                                                            ##
##    (a.k.a. BIAB) by www.AffiliateBuilder.net                                    ##
##    This pack is freeware                                                        ##
##    You are allowed to use it free of charge for personal,                       ##
##    educational or commercial purposes                                           ##
##    but it cannot be distribute from other website, CDs, download file,          ##
##    email or any other way unless having written authorization from us.          ## 
##    If you want to promote BIAB, feel free link to us: www.affiliatebuilder.net  ##
## 										                       ##
#####################################################################################
include("config.php");
include("header.html");
?>
    <table border="1" cellspacing="0" bordercolordark="white" bordercolorlight="black" width="100%">
      <tr>
        <td width="100%">
            <table cellpadding="1" cellspacing="1" width="100%">
                <tr>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="index.php">Home</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="tell.php">Tell-Friend</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="calendar.php">Calendars</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="chat.php">Live-Chat</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="classifieds.php">Classifieds</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="counter.php">Counters</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="forms.php">Forms</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="faq.php">FAQs</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="forums.php">Forums</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="guestbook.php">Guestbooks</a></span></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="webjournal.php">Web-Blogs</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="news.php">Add-News</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="password.php">Passwords</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="albums.php">Albums</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="ecards.php">E-Cards</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="url.php">Fast 
                        URL</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="search.php">Site-Search</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="sitering.php">Site-Rings</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="mailing.php">Mailing-Lists</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="traffic.php">Traffic</a></span></font></p>
                    </td>
                </tr>
            </table>
            <hr align="left" size="1" color="#009933">            <table cellpadding="2" cellspacing="2" width="100%" height="90">
                <tr>
                    <td width="73" height="66" align="center" valign="middle">
                        <p><img src="images/icon/elist.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="288" height="66" align="left" valign="middle"><DIV><span style="font-size:20pt;"><font face="Arial"><b>Mailing 
                            Lists<br></b></font></span><font face="Arial"><span style="font-size:9pt;">Build your  email lists to send newsletters</span></font></DIV>
                    </td>
                    <td width="372" height="66" align="left" valign="middle"><span style="font-size:10pt;"><font face="Arial">Keep your visitors up to date with your latest site changes or product news! 
Send HTML or Plain text messages and manage your list subscribers in our easy to 
use Mailing List control panel</font></span></td>
                </tr>
            </table>
            <hr size="1" align="left" color="#009933">          <table cellpadding="0" cellspacing="0" width="100%" bordercolordark="white" bordercolorlight="black" align="center">
            <tr>
              <td width="57%" valign="top">
                            
                        <table cellpadding="2" cellspacing="2" width="100%">
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Double Opt-In</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Confirmed 
subscriber lists are safer from spam complaints. 
                                    </font></span></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Email Notifications</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Get 
notified by email when new members subscribe. 
                                    </font></span></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">HTML Newsletters</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Use our 
HTML Builder to build and send HTML email. 
                                    </font></span></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Subscriber Search</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Find 
subscribers by name or date easily.</font></span></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Display Statistics</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Track the 
performance of your list. 
                                    </font></span><font face="Arial"><span style="font-size:10pt;">.</span></font></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Multiple Templates</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Use one 
of many pre-built HTML email templates. </font></span><font face="Arial"><span style="font-size:10pt;">.</span></font></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
<p><STRONG><span style="font-size:10pt;"><font face="Arial">Full Site Integration</font></span></STRONG><span style="font-size:10pt;"><font face="Arial"><BR>Our 
subscribe box can be completely customized.</font></span></p>
                                </td>
                            </tr>
                            <tr>
                                <td width="48" height="43">
                                    <p align="center"><img src="images/icon/check32.jpg" width="32" height="32" border="0"></p>
                                </td>
                                <td width="369" height="43">
                                    <p><STRONG><font face="Arial"><span style="font-size:10pt;">Easy
                    installation</span></font></STRONG><span style="font-size:10pt;"><font face="Arial">
                    </font></span><font face="Arial"><span style="font-size:10pt;"><br>
                     Just copy and paste our code onto your
                    webpage</span></font></p>
                                </td>
                            </tr>
                        </table>
                        <p><br></p>
              </td>
              <td width="50%" valign="top" align="center">
                <div align="center">
                            
                            
                                <font face="Arial" color="#333333"><span style="font-size:16pt;"><b>Get 
                            your Free Mailing List 
                                 <br></b></span></font><font face="Arial" color="black"><span style="font-size:12pt;">And 
                            start using it right now !!!</span></font>
                </div>
                        <form action="http://www.affiliatebuilder.net/brav/signup.php" method="GET">
                                            <div align="left">
                            <table border="0" cellpadding="3" cellspacing="3" width="100%">
                              <tr>
                                <td colspan="2" width="100%" bgcolor="#009933" valign="TOP">
                                  <p align="center">
                                    
                                    <font face="Arial" color="white"><span style="font-size:12pt;"><b>Get it Free !!</b></span></font>
                                  </p>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <B><FONT FACE="Verdana"><span style="font-size:8pt;">Username</span></FONT></B>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="center">
                                  <p align="left">
                                    <input type="TEXT" name="userid" size="20">
                                  </p>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <FONT FACE="Verdana"><B><span style="font-size:8pt;">Email</span></B></FONT>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="center">
                                  <p align="left">
                                    <input type="TEXT" name="email" size="20">
                                  </p>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <FONT FACE="Verdana"><B><span style="font-size:8pt;">First Name</span></B></FONT>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="center">
                                  <p align="left">
                                    <input type="TEXT" name="firstname" size="20">
                                  </p>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <FONT FACE="Verdana"><B><span style="font-size:8pt;">Last Name</span></B></FONT>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="center">
                                  <p align="left">
                                    <input type="TEXT" name="lastname" size="20">
                                  </p>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <FONT FACE="Verdana"><B><span style="font-size:8pt;">Date of Birth</span></B></FONT>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="left">
                                  <div class="signup_input">
                                    <select name="dobmonth" style="width: 140px;width: 80px;">
                                      <option value="0">
                                        Month
                                      </option>
                                      <option value="1">
                                        January
                                      </option>
                                      <option value="2">
                                        February
                                      </option>
                                      <option value="3">
                                        March
                                      </option>
                                      <option value="4">
                                        April
                                      </option>
                                      <option value="5">
                                        May
                                      </option>
                                      <option value="6">
                                        June
                                      </option>
                                      <option value="7">
                                        July
                                      </option>
                                      <option value="8">
                                        August
                                      </option>
                                      <option value="9">
                                        September
                                      </option>
                                      <option value="10">
                                        October
                                      </option>
                                      <option value="11">
                                        November
                                      </option>
                                      <option value="12">
                                        December
                                      </option>
                                    </select><select name="dobday" style="width: 50px;width: 55px;">
                                      <option value="0">
                                        Day
                                      </option>
                                      <option value="1">
                                        1
                                      </option>
                                      <option value="2">
                                        2
                                      </option>
                                      <option value="3">
                                        3
                                      </option>
                                      <option value="4">
                                        4
                                      </option>
                                      <option value="5">
                                        5
                                      </option>
                                      <option value="6">
                                        6
                                      </option>
                                      <option value="7">
                                        7
                                      </option>
                                      <option value="8">
                                        8
                                      </option>
                                      <option value="9">
                                        9
                                      </option>
                                      <option value="10">
                                        10
                                      </option>
                                      <option value="11">
                                        11
                                      </option>
                                      <option value="12">
                                        12
                                      </option>
                                      <option value="13">
                                        13
                                      </option>
                                      <option value="14">
                                        14
                                      </option>
                                      <option value="15">
                                        15
                                      </option>
                                      <option value="16">
                                        16
                                      </option>
                                      <option value="17">
                                        17
                                      </option>
                                      <option value="18">
                                        18
                                      </option>
                                      <option value="19">
                                        19
                                      </option>
                                      <option value="20">
                                        20
                                      </option>
                                      <option value="21">
                                        21
                                      </option>
                                      <option value="22">
                                        22
                                      </option>
                                      <option value="23">
                                        23
                                      </option>
                                      <option value="24">
                                        24
                                      </option>
                                      <option value="25">
                                        25
                                      </option>
                                      <option value="26">
                                        26
                                      </option>
                                      <option value="27">
                                        27
                                      </option>
                                      <option value="28">
                                        28
                                      </option>
                                      <option value="29">
                                        29
                                      </option>
                                      <option value="30">
                                        30
                                      </option>
                                      <option value="31">
                                        31
                                      </option>
                                    </select><select name="dobyear" style="width: 60px;width: 58px; ">
                                      <option value="0">
                                        Year
                                      </option>
                                      <option value="2004">
                                        2004
                                      </option>
                                      <option value="2003">
                                        2003
                                      </option>
                                      <option value="2002">
                                        2002
                                      </option>
                                      <option value="2001">
                                        2001
                                      </option>
                                      <option value="2000">
                                        2000
                                      </option>
                                      <option value="1999">
                                        1999
                                      </option>
                                      <option value="1998">
                                        1998
                                      </option>
                                      <option value="1997">
                                        1997
                                      </option>
                                      <option value="1996">
                                        1996
                                      </option>
                                      <option value="1995">
                                        1995
                                      </option>
                                      <option value="1994">
                                        1994
                                      </option>
                                      <option value="1993">
                                        1993
                                      </option>
                                      <option value="1992">
                                        1992
                                      </option>
                                      <option value="1991">
                                        1991
                                      </option>
                                      <option value="1990">
                                        1990
                                      </option>
                                      <option value="1989">
                                        1989
                                      </option>
                                      <option value="1988">
                                        1988
                                      </option>
                                      <option value="1987">
                                        1987
                                      </option>
                                      <option value="1986">
                                        1986
                                      </option>
                                      <option value="1985">
                                        1985
                                      </option>
                                      <option value="1984">
                                        1984
                                      </option>
                                      <option value="1983">
                                        1983
                                      </option>
                                      <option value="1982">
                                        1982
                                      </option>
                                      <option value="1981">
                                        1981
                                      </option>
                                      <option value="1980">
                                        1980
                                      </option>
                                      <option value="1979">
                                        1979
                                      </option>
                                      <option value="1978">
                                        1978
                                      </option>
                                      <option value="1977">
                                        1977
                                      </option>
                                      <option value="1976">
                                        1976
                                      </option>
                                      <option value="1975">
                                        1975
                                      </option>
                                      <option value="1974">
                                        1974
                                      </option>
                                      <option value="1973">
                                        1973
                                      </option>
                                      <option value="1972">
                                        1972
                                      </option>
                                      <option value="1971">
                                        1971
                                      </option>
                                      <option value="1970">
                                        1970
                                      </option>
                                      <option value="1969">
                                        1969
                                      </option>
                                      <option value="1968">
                                        1968
                                      </option>
                                      <option value="1967">
                                        1967
                                      </option>
                                      <option value="1966">
                                        1966
                                      </option>
                                      <option value="1965">
                                        1965
                                      </option>
                                      <option value="1964">
                                        1964
                                      </option>
                                      <option value="1963">
                                        1963
                                      </option>
                                      <option value="1962">
                                        1962
                                      </option>
                                      <option value="1961">
                                        1961
                                      </option>
                                      <option value="1960">
                                        1960
                                      </option>
                                      <option value="1959">
                                        1959
                                      </option>
                                      <option value="1958">
                                        1958
                                      </option>
                                      <option value="1957">
                                        1957
                                      </option>
                                      <option value="1956">
                                        1956
                                      </option>
                                      <option value="1955">
                                        1955
                                      </option>
                                      <option value="1954">
                                        1954
                                      </option>
                                      <option value="1953">
                                        1953
                                      </option>
                                      <option value="1952">
                                        1952
                                      </option>
                                      <option value="1951">
                                        1951
                                      </option>
                                      <option value="1950">
                                        1950
                                      </option>
                                      <option value="1949">
                                        1949
                                      </option>
                                      <option value="1948">
                                        1948
                                      </option>
                                      <option value="1947">
                                        1947
                                      </option>
                                      <option value="1946">
                                        1946
                                      </option>
                                      <option value="1945">
                                        1945
                                      </option>
                                      <option value="1944">
                                        1944
                                      </option>
                                      <option value="1943">
                                        1943
                                      </option>
                                      <option value="1942">
                                        1942
                                      </option>
                                      <option value="1941">
                                        1941
                                      </option>
                                      <option value="1940">
                                        1940
                                      </option>
                                      <option value="1939">
                                        1939
                                      </option>
                                      <option value="1938">
                                        1938
                                      </option>
                                      <option value="1937">
                                        1937
                                      </option>
                                      <option value="1936">
                                        1936
                                      </option>
                                      <option value="1935">
                                        1935
                                      </option>
                                      <option value="1934">
                                        1934
                                      </option>
                                      <option value="1933">
                                        1933
                                      </option>
                                      <option value="1932">
                                        1932
                                      </option>
                                      <option value="1931">
                                        1931
                                      </option>
                                      <option value="1930">
                                        1930
                                      </option>
                                      <option value="1929">
                                        1929
                                      </option>
                                      <option value="1928">
                                        1928
                                      </option>
                                      <option value="1927">
                                        1927
                                      </option>
                                      <option value="1926">
                                        1926
                                      </option>
                                      <option value="1925">
                                        1925
                                      </option>
                                      <option value="1924">
                                        1924
                                      </option>
                                      <option value="1923">
                                        1923
                                      </option>
                                      <option value="1922">
                                        1922
                                      </option>
                                      <option value="1921">
                                        1921
                                      </option>
                                      <option value="1920">
                                        1920
                                      </option>
                                      <option value="1919">
                                        1919
                                      </option>
                                      <option value="1918">
                                        1918
                                      </option>
                                      <option value="1917">
                                        1917
                                      </option>
                                      <option value="1916">
                                        1916
                                      </option>
                                      <option value="1915">
                                        1915
                                      </option>
                                      <option value="1914">
                                        1914
                                      </option>
                                      <option value="1913">
                                        1913
                                      </option>
                                      <option value="1912">
                                        1912
                                      </option>
                                      <option value="1911">
                                        1911
                                      </option>
                                      <option value="1910">
                                        1910
                                      </option>
                                      <option value="1909">
                                        1909
                                      </option>
                                      <option value="1908">
                                        1908
                                      </option>
                                      <option value="1907">
                                        1907
                                      </option>
                                      <option value="1906">
                                        1906
                                      </option>
                                      <option value="1905">
                                        1905
                                      </option>
                                      <option value="1904">
                                        1904
                                      </option>
                                      <option value="1903">
                                        1903
                                      </option>
                                      <option value="1902">
                                        1902
                                      </option>
                                      <option value="1901">
                                        1901
                                      </option>
                                      <option value="1900">
                                        1900
                                      </option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td width="88" bgcolor="#d7d7d7" align="RIGHT" valign="middle">
                                  <p align="left">
                                    
                                    <FONT FACE="Verdana"><B><span style="font-size:8pt;">Zip Code</span></B></FONT>
                                  </p>
                                </td>
                                <td width="66%" bgcolor="#f0f0f0" valign="TOP" align="center">
                                  <p align="left">
                                    <input type="TEXT" name="zipcode" size="20">
                                     <input type="hidden" name="afilid" value="<?php echo $aff; ?>">
                                  </p>
                                </td>
                              </tr>
                              <tr valign="TOP">
                                <td colspan="2" width="100%" bgcolor="#f0f0f0" valign="TOP" align="CENTER">
                                  <p align="center">
                                    <input type="SUBMIT" name="send" value="Sign Up">
                                  </p>
                                </td>
                              </tr>
                                    <tr>
                                <td colspan="2" width="100%" bgcolor="white" valign="baseline" align="CENTER" height="27">
                                            <p><span style="font-size:7pt;"><font face="Verdana">By registering you agree with our <a href="terms.php" target="_blank">Terms of Service</a></font></span></p>
                                </td>
                                    </tr>
                            </table>
                                            </div>
                        </form>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
<p align="center"><?php include("footer.html"); ?>

<br><font face="Arial"><span style="font-size:8pt;"><a href="http://affiliatebuilder.net" target="_blank">Powered 
by BIAB</a></span></font>&nbsp;