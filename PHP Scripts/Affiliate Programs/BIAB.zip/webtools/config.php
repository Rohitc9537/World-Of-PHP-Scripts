<?php
#####################################################################################
##										                       ##
##    Bravenet-In-A-Box                                                            ##
##    (a.k.a. BIAB) by www.AffiliateBuilder.net                                    ##
##    This pack is freeware                                                        ##
##    You are allowed to use it free of charge for personal,                       ##
##    educational or commercial purposes                                           ##
##    but it cannot be distribute from other website, CDs, download file,          ##
##    email or any other way unless having written authorization from us.          ## 
##    If you want to promote BIAB, feel free link to us: www.affiliatebuilder.net  ##
## 										                       ##
#####################################################################################

## In order to configure BIAB to track your bravenet affiliate account, 
## you must change the value below with your affiliate ID.
## I.E. if your bravenet affiliate links include something like 
## http://www.bravenet.com/?afilid=123456789 , then your ID is: 123456789
## and the line below should look like $aff = "123456789"; 
##(dont remove the quotes and the semicolon, or it will not work)

$aff = "555555555";

?>
