<?php
#####################################################################################
##										                       ##
##    Bravenet-In-A-Box                                                            ##
##    (a.k.a. BIAB) by www.AffiliateBuilder.net                                    ##
##    This pack is freeware                                                        ##
##    You are allowed to use it free of charge for personal,                       ##
##    educational or commercial purposes                                           ##
##    but it cannot be distribute from other website, CDs, download file,          ##
##    email or any other way unless having written authorization from us.          ## 
##    If you want to promote BIAB, feel free link to us: www.affiliatebuilder.net  ##
## 										                       ##
#####################################################################################
include("config.php");
include("header.html");
?>

<p align="center"><span style="font-size:18pt;"><font face="Arial" color="#333333"><b>100% 
Free Web Services to Improve your Website !!!</b></font></span></p>
<table align="center" border="1" cellspacing="0" width="100%" bordercolor="white" bordercolordark="white" bordercolorlight="#666666">
    <tr>
        <td>
            <table width="100%" cellspacing="3" bordercolordark="white" bordercolorlight="black" cellpadding="3" align="center">
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/announce.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="tell.php"><b><font face="Arial" >Tell A Friend</font></b></a><font face="Arial" color="#666666"><b><br></b></font></span><span style="font-size:9pt;"><font face="Arial" color="#666666">Let visitors recommend your site to friends. 
                            &nbsp;</font></span></DIV>
                    </td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/journal.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="webjournal.php">Web Journal / Blog</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Create an online diary or blog. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/calendar.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="calendar.php"><b><font face="Arial">Calendar</font></b></a></span><span style="font-size:9pt;"><font face="Arial" color="#666666"><br>Life just got a little bit easier to manage. 
                            </font></span></DIV>
                    </td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/news.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="news.php">Headline News</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Dynamic self-updating content for your Website. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/elist.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="mailing.php"><b><font face="Arial">Mailing 
                            Lists</font></b></a></span></DIV>
<DIV class=text11b><font face="Arial" color="#666666"><span style="font-size:9pt;">Build your own email lists and send newsletters</span></font><span style="font-size:9pt;"><font face="Arial" color="#666666">.</font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/passwd.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="password.php">Password Gate</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Restrict access to important web pages. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/chat.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="chat.php"><b><font face="Arial">Live Chat</font></b></a></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Chat live with your website visitors. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/photocenter.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="albums.php">Photo Center</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Store and display your favorite images online. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/classified.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="classifieds.php"><b><font face="Arial">Classifieds</font></b></a></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Allow visitors to buy/sell/trade on your site. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial"><img src="images/icon/postcard.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="ecards.php">E-Cards</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Add custom greeting cards to your website. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/counter.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><a href="counter.php"><b><font face="Arial">Counter Stats</font></b></a></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Track visitors coming to your website. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/redirect.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="url.php">Fast URL Redirect</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Turn your long URL into a short URL. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/emailform.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="forms.php">Email Forms</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Get information from your visitors with a click. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/search.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="search.php">Site Search</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Search web pages on your own site. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/faq.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="faq.php">FAQ Service</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Online help system for your visitors or clients. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/sitering.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="sitering.php">Site Ring</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Build a directory of websites like yours. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/forum.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="forums.php">Message Forum</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Discussion boards for you and your visitors. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/template.gif" width="42" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="templates.php">Template Gallery</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Hundreds of fantastic homepage  designs. 
                            </font></span></DIV></td>
                </tr>
                <tr>
                    <td width="58">
                        <p align="center"><img src="images/icon/guestbook.gif" width="42" height="52" border="0"></p>
                    </td>
                    <td width="303" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="guestbook.php">Guestbook</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Let visitors leave comments for you. 
                            </font></span></DIV></td>
                    <td width="71">
                        <p align="center"><span style="font-size:9pt;"><font face="Arial" color="#666666"><img src="images/icon/traffic.gif" width="52" height="52" border="0"></font></span></p>
                    </td>
                    <td width="321" bgcolor="#EEEEEE"><DIV class=text16b style="PADDING-TOP: 10px"><span style="font-size:14pt;"><font face="Arial"><b><a href="traffic.php">Traffic Exchange</a></b></font></span></DIV>
<DIV class=text11b><span style="font-size:9pt;"><font face="Arial" color="#666666">Generate free hits to your site in minutes. 
                            </font></span></DIV></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<?php include("footer.html"); ?>