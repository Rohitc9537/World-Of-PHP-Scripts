<?php
#####################################################################################
##										                       ##
##    Bravenet-In-A-Box                                                            ##
##    (a.k.a. BIAB) by www.AffiliateBuilder.net                                    ##
##    This pack is freeware                                                        ##
##    You are allowed to use it free of charge for personal,                       ##
##    educational or commercial purposes                                           ##
##    but it cannot be distribute from other website, CDs, download file,          ##
##    email or any other way unless having written authorization from us.          ## 
##    If you want to promote BIAB, feel free link to us: www.affiliatebuilder.net  ##
## 										                       ##
#####################################################################################
include("config.php");
include("header.html");
?>

    <table border="1" cellspacing="0" bordercolordark="white" bordercolorlight="black" width="100%">
      <tr>
        <td width="100%">
            <table cellpadding="1" cellspacing="1" width="100%">
                <tr>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="index.php">Home</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="tell.php">Tell-Friend</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="calendar.php">Calendars</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="chat.php">Live-Chat</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="classifieds.php">Classifieds</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="counter.php">Counters</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="forms.php">Forms</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="faq.php">FAQs</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="forums.php">Forums</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="guestbook.php">Guestbooks</a></span></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="webjournal.php">Web-Blogs</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="news.php">Add-News</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="password.php">Passwords</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="albums.php">Albums</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="ecards.php">E-Cards</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="url.php">Fast 
                        URL</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="search.php">Site-Search</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="sitering.php">Site-Rings</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="mailing.php">Mailing-Lists</a></span></font></p>
                    </td>
                    <td width="10%" bgcolor="#EEEEEE">
                        <p align="left"><font face="Verdana"><span style="font-size:8pt;"><a href="traffic.php">Traffic</a></span></font></p>
                    </td>
                </tr>
            </table>
            <hr align="left" size="1" color="#009933">
            <table cellpadding="2" cellspacing="2" width="100%" height="90">
                <tr>
                    <td width="73" height="66" align="center" valign="middle">
                        <p>&nbsp;</p>
                    </td>
                    <td width="585" height="66" align="left" valign="middle">
                        <p align="center"><span style="font-size:20pt;"><font face="Arial"><b>Thanks 
                        for Registering with us<br></b></font></span>                    </td>
                    <td width="75" height="66" align="left" valign="middle">&nbsp;</td>
                </tr>
            </table>
            <hr size="1" align="left" color="#009933">                      <table cellpadding="2" cellspacing="2" width="100%" height="90">
                <tr>
                    <td width="73" height="66" align="center" valign="middle">
                        <p><span style="font-size:11pt;"><font face="Arial">&nbsp;</font></span></p>
                    </td>
                    <td width="585" height="66" align="left" valign="middle">
                        <p align="left"><span style="font-size:11pt;"><font face="Arial">Please 
                        check your email to find instructions needed to activate 
                        &amp; setup your new web tools.<br>We have partnered 
                        with Bravenet Web Services to provide you with the best 
                        &nbsp;tools to improve your web presence.</font></span></p>
                        <p align="left"><span style="font-size:11pt;"><font face="Arial">You 
                        will find your username and temporary password to access 
                        all our&nbsp;services listed from just one place in 
                        the welcome email already sent to you.</font></span></p>
                        <p align="left"><span style="font-size:11pt;"><font face="Arial">Feel 
                        free to change your login info as you want, including 
                        username and password, from the profile section.</font></span></p>
                        <p align="left"><span style="font-size:11pt;"><font face="Arial">Enjoy 
                        !!!</font></span><span style="font-size:20pt;"><font face="Arial"><b><br></b></font></span></p>
                    </td>
                    <td width="75" height="66" align="left" valign="middle"></td>
                </tr>
            </table>
            <p align="center">&nbsp;</p>
        </td>
      </tr>
    </table><br>
<?php include("footer.html"); ?>

