<?php
#####################################################################################
##										                       ##
##    Bravenet-In-A-Box                                                            ##
##    (a.k.a. BIAB) by www.AffiliateBuilder.net                                    ##
##    This pack is freeware                                                        ##
##    You are allowed to use it free of charge for personal,                       ##
##    educational or commercial purposes                                           ##
##    but it cannot be distribute from other website, CDs, download file,          ##
##    email or any other way unless having written authorization from us.          ## 
##    If you want to promote BIAB, feel free link to us: www.affiliatebuilder.net  ##
## 										                       ##
#####################################################################################
include("header.html");

?>

&nbsp;
<p><STRONG><font face="Verdana"><span style="font-size:8pt;">Terms of Service, &quot;TOS&quot;</span></font></STRONG><font face="Verdana"><span style="font-size:8pt;"> 
</span></font></p>
<P><font face="Verdana"><span style="font-size:8pt;">By registering to be a member of Bravenet and to use any Bravenet Service, 
you are agreeing to the following Terms of Service. Failure to comply will 
result in account termination. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">1. Disclaimer of Warranty. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet Web Services Inc. disclaims all warranties or representations, 
express or implied, oral or written, including, without limitation, warranties 
of merchantability, fitness for a particular purpose, title or non-infringement. 
Bravenet Web Services Inc. does not warrant that its services are error-free or 
that they will operate without interruption nor does Bravenet Web Services Inc. 
make any warranty with respect to the quality, reliability, timeliness or 
security of its services. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet makes no guarantee as to the availability of Service and are not 
responsible for any loss of information resulting from deletion of Services, 
network or system outages, file corruption, or any other reasons. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">2. Disclaimer of Service Content. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet does not verify, endorse, or otherwise vouch for the contents of any 
Web Site using a Bravenet Web Service. Web Service owners are responsible for 
everything contained on their own Web Site and in their Web Services. Web 
Service owners can be held legally accountable for the contents of any web 
service; including for example; material protected by copyright, trademark, 
patent, or trade secret law. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">3. Service Limitations. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">You are not allowed to associate any Bravenet Services or Web Tools with any 
adult material of any sort. This includes, but is not limited to, such things as 
nudity, any site, page, image or service requiring any adult verification 
service, anything that says you must be 18 or older to view or join or access, 
and any text, image or likeness suggesting sexual and/or inappropriate and/or 
illegal acts of any sort. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">We do not allow any Bravenet Member Account to store, use, contain or display 
pornography, adult novelties, adult toys, XXX material, Gorean, bondage, BDSM, 
anything illegal, bigotry, racism, hatred, profanity, mail fraud, pyramid 
schemes, or any material which may be insulting to another person(s) or company, 
or depicts the exploitation of minors (children under 18 years of age). No 
spamming allowed, no harassing, threatening or illegal activities. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">In addition we do not allow: 
</span></font><OL>
<LI><font face="Verdana"><span style="font-size:8pt;">File storage - Bravenet Member Accounts found to be storing files for use on 
other websites will be terminated without notice, at Bravenet's sole discretion. 
Bravenet Member Accounts found to be storing files renamed, or modified in any 
way, to bypass Bravenets file restrictions will be terminated without notice, at 
Bravenet's sole discretion. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">Copyrighted or Trademarked materials - NO copyrighted or trademarked 
materials may be stored in Bravenet Member Accounts, unless the Bravenet Member 
is the sole legal owner of the Copyright or Trademark and can reasonably 
demonstrate Ownership or legal permission for use, on demand. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">Adult services - Bravenet Member Accounts may not be used to promote, store, 
or display information or data pertaining to or about Escort services or Paid 
Companionship services of any sort. </span></font></LI></OL>
<P><font face="Verdana"><span style="font-size:8pt;">&nbsp;</span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Material in Bravenet Member Accounts must be appropriately and legally viewed 
and used by all ages. Bravenet Member Accounts found to be in violation of any 
portion of this section can and will be terminated without notice at Bravenet's 
sole discretion. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">4. Bravenet Code Usage Limitations. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet services and service code provided for use by Members is, and 
remains, copyrighted material/property of Bravenet Web Services, Inc. Bravenet 
grants you a limited license to modify our service codes in 5 specific ways: 
</span></font></P>
<P>
<font face="Verdana"><span style="font-size:8pt;">&nbsp;</span></font><OL>
<LI><font face="Verdana"><span style="font-size:8pt;">You may modify the text and color displayed in the service to match those of 
your webpages. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">You may modify images appearing in the service, where applicable. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">You may modify the dimensions (height and width) that services are displayed 
in, as long as the service remains visible. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">You may modify the buttons provided by Bravenet that link to the services, 
in order to match your site. 
</span></font><LI><font face="Verdana"><span style="font-size:8pt;">You may replace the buttons provided by Bravenet that link to the services, 
in order to match your site, as long as each button conforms to the usage 
guidelines outlined in the Terms of Service. </span></font></LI></OL>
<P><font face="Verdana"><span style="font-size:8pt;">&nbsp;</span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">You may not modify any other portion of our codes, including but not limited 
to advertising script, service copy/paste codes or any other Bravenet code, in 
any manner,for any reason whatsoever. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Accounts found to be in violation of this section will be Terminated 
immediately along with all services registered and associated with the Account, 
without warning, at Bravenet's sole discretion. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">5. Account Termination. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet can remove any Web Service from the database, without prior notice, 
if we find the contents unsuitable for the public. We can remove a Member's 
Services if there is no evident activity for 90 days. And we can deny membership 
if we see the need. If the Membership is a paid member account or service, and 
Bravenet terminates the account or service for a TOS violation, the payment is 
not refundable. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">All mailings sent to you by Bravenet.com are opt-in emails activated and 
authorized by you either through subscription or as a mandatory component of 
your membership in Bravenet. All subscribed mailing lists have a link at the 
bottom to allow you to unsubscribe from that mailing list if you wish. Other 
mailings are mandatory and are conditional of your membership with Bravenet.com. 
If you report any of these mailings or service notification emails (which you 
have the control to turn off yourself), as spam we reserve the right to 
terminate your Bravenet account. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">6. Service and Member Account Upkeep. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">As the Registered Owners of our services, Bravenet members are required to 
maintain their Registered Services and keep them within the guidelines set forth 
here in the Terms of Service. Failure to do so will result in Account 
Termination, at Bravenet's sole discretion. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">All Members must ensure that their member account information is accurate and 
complete at all times. It is particularly important to keep the email address 
stored in your member account current and valid at all times. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">7. Member Email lists. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">By registering a Bravenet account, you agree to subscribe to our Members 
Update, Tips and Tricks, Freebies and Special Offers mailing lists. These lists 
may contain third-party sponsorships. You may unsubscribe from the Special 
Offers, Freebies and Tips and Tricks list by removing your email address here: 
</span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Special Offers<BR></span></font><A 
href="http://www.bravenet.com/unsub.php?listname=offers"><font face="Verdana"><span style="font-size:8pt;">Remove me from this 
list</span></font></A></P>
<P><font face="Verdana"><span style="font-size:8pt;">Tips and Tricks<BR></span></font><A 
href="http://www.bravenet.com/unsub.php?listname=tipsandtricks"><font face="Verdana"><span style="font-size:8pt;">Remove me from 
this list</span></font></A></P>
<P><font face="Verdana"><span style="font-size:8pt;">Freebies<BR></span></font><A 
href="http://www.bravenet.com/unsub.php?listname=freebies"><font face="Verdana"><span style="font-size:8pt;">Remove me from this 
list</span></font></A></P>
<P><font face="Verdana"><span style="font-size:8pt;">Maintaining a working subscription to our regularly sent Members Update 
Newsletter is Mandatory for all Bravenet Members. If you wish to no longer 
receive the Members Update Newsletter, delete your Member account and services. 
</span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Other lists subscriptions are completely optional and may contain third-party 
endorsements. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">8. Exclusive Remedy. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Issues of exclusive remedy are adequately dealt with under limitation of 
liability and governing law. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">9. Limitation of Warranty. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Each party hereby acknowledges that it has not relied upon any warranty, 
condition, guarantee or representation made by the other except as specifically 
set forth in this agreement. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">10. Limitation of Liability. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">In no event shall either party be liable to the other for indirect, 
incidental, consequential, special, exemplary or punitive damages in any action 
arising from or related to this agreement whether based in contract, tort 
(including negligence), intended conduct or otherwise including, without 
limitation, damages relating to the loss of profits, income or goodwill, 
regardless of whether such party has been advised of the possibility of such 
damages. In no event will Bravenet Web Services Inc. be liable for amounts 
greater than actually received under this agreement in the six (6) months 
preceding the date that any cause of action arises. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">11. Indemnification. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet services are completely free. They may be used for Business 
(Commercial) Sites or Personal Sites. All you have to do is abide by the rules. 
By registering, you become a Web Service owner. You then agree to indemnify and 
hold harmless Bravenet for any loss, liability, and damage arising from or in 
connection with the contents or service of any Bravenet Web Service. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Each party will defend, indemnify and hold harmless the other party and its 
officers, directors, employees, agents and affiliated entities from and against 
any and all liabilities, losses, damages, claims and expenses, including 
reasonable legal fees arising out of or related to the indemnifying parties' 
conduct under this agreement or such parties' breach of this agreement or the 
untruth of any such parties' representations or warranties herein. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">12. Force Majeure. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Neither party shall be deemed in default or otherwise liable under this 
agreement, except with regards to payments due herein, due to its inability to 
perform its obligations hereunder by reason of any fire, earthquake, flood, 
substantial snow storm, epidemic, accident, explosion, casualty, strike, 
lock-out, labour controversy, riot, civil disturbance, act of public enemy, 
embargo, war, act of God or any municipal, county, state, provincial, 
territorial or national ordinance or law, or any executive, administrative or 
judicial order (which order is not the result of any act or omission which would 
constitute a default hereunder) or any failure or delay of any transportation, 
power or communication system or any other similar cause beyond that parties' 
control. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">13. Governing Law. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">This agreement shall be deemed to have been made in the Province of British 
Columbia, Canada and the validity, construction, interpretation and enforcement 
hereof and the rights of the parties hereto shall be determined under, governed 
by, and construed in accordance with the internal laws of the Province of 
British Columbia without regard to the principles of conflicts of laws. Each 
party is specifically prohibited from bringing any action arising from or 
related to this agreement other than in the Province of British Columbia unless 
the said action is for the purpose of enforcing a Judgment already obtained in 
the Province of British Columbia. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">14. Usage of Bravenet Servers. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet servers may be used for lawful purposes only. Transmission, storage, 
or distribution of any information, data, or material in violation of any 
applicable law or regulation is prohibited. This includes, but is not limited 
to: copyrighted material; trademarks; trade secrets or other intellectual 
property rights used without proper authorization; material that is obscene, 
defamatory, constitutes an illegal threat, or violates export control laws </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">15. Bravenet Network Security. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Violations of system or network security are prohibited and may result in 
criminal and civil liability. Examples include but are not limited to the 
following: unauthorized access, use, probing, or scanning of systems security or 
authentication measures, data, or traffic; interference with service to any 
user, host, or network including, without limitation, mail bombing, flooding, 
deliberate attempts to overload a system, broadcast attacks; forging of any 
TCP-IP packet header or any part of the header information in an email or a 
newsgroup posting. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">16. CPU Usage. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet Members shall not use excessive amounts of CPU processing on any of 
Bravenet's servers. Any violation of this policy may result in corrective action 
by Bravenet, including assessment of additional charges, disconnection or 
discontinuance of any and all Services, or termination of this Agreement, which 
actions may be taken in Bravenet's sole and absolute discretion. If Bravenet 
takes any corrective action under this section, the Member shall not be entitled 
to a refund of any fees paid in advance prior to such action. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">17. Bandwidth and Disk Usage. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">With Bravenet.com Web Tools, bandwidth limits are calculated on a recurring 
30 days basis. Bandwidth cannot be combined with multiple packages. Bandwidth 
and disk usage shall not exceed the number of megabytes per day for the Services 
ordered and purchased by the Member. Bravenet will monitor each Member's 
bandwidth and disk usage. Bravenet shall have the right to take corrective 
action if any Member's bandwidth or disk usage exceeds the Agreed Usage. Such 
corrective action may include the assessment of additional charges, 
disconnection or discontinuance of any and all Services, or termination of this 
Agreement, which actions may be taken in Bravenet's sole and absolute 
discretion. If Bravenet takes any corrective action under this section, the 
Member shall not be entitled to a refund of any fees paid in advance prior to 
such action. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bandwidth limits for Basic Hosting accounts are structured around a monthly 
total, but metered on a daily basis to ensure that server resources are equally 
available to all accounts. Accounts using all of, or more than, their alotted 
daily bandwidth will be temporarily suspended until 12:01am PST the following 
day. Daily bandwidth metering begins at 12:01am PST and ends at 11:59pm PST. 
Bandwidth limits are a combination of both HTTP and FTP traffic. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">18. Purchase Policy. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Web Tools Service Payments:<BR>If you are purchasing one of our various Web 
Tools we will accept VISA and Mastercard payments and payments made through the 
PayPal service. Your service(s) will be automatically activated within your 
account when purchasing using these methods. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">We also accept International Money Orders and Checks made out to Bravenet Web 
Services, in US Dollars only. Services purchased through these 2 methods will be 
activated in your member account once payment has been received and successfully 
processed. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Please Note: The category above does NOT include Web Hosting payments. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Hosting and Domains Payments:<BR>If you are purchasing one of our Web Site 
Hosting or Domain services, we will accept VISA and Mastercard payments and 
payments made through the PayPal service. Your service(s) will be automatically 
activated within your account when purchasing using these methods. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">IMPORTANT NOTE: All prices quoted on the Bravenet Web Services web site are 
in US dollars. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">19. Refund Policies. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Domain Registration Payments:<BR>We do not provide refunds for Domain 
Registrations, since Domains cannot be unregistered. Domain transfer fees are 
non-refundable. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Template Gallery:<BR>The Templates contained in the Template Gallery service 
are deemed to be commercial software, thus no refunds can be made to those 
purchasing this service, since the product is digital in nature and cannot be 
physically returned to Bravenet. All purchases of this service are final and 
non-refundable. <BR><BR>Website Hosting:<BR>Monthly Hosting package payments are 
fully refundable up to 7 days from the date of purchase. Notify us in writing, 
and include a copy of your purchase receipt, within 7 days of the date of 
purchase and we will provide a full refund of your payment, if applicable. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Yearly Hosting package payments are fully refundable up to 30 days from the 
date of purchase. Notify us in writing, and include a copy of your purchase 
receipt, within 30 days of the date of purchase and we will provide a full 
refund of your payment, if applicable. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Hosting packages purchased with the free domain name and/or template gallery 
option will receive a partial refund, as the normal purchase price of the domain 
name, template usage and/or domain name transfer requests, will be applied 
against any outstanding amount(s). </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Professional Tools and Services:<BR>Professional Tools package payments are 
fully refundable up to 30 days from the date of purchase. Notify us in writing, 
and include a copy of your purchase receipt, within 30 days of the date of 
purchase and we will provide a full refund of your payment, if applicable. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Partial refunds may result in an administration fee. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Bravenet reserves the right to amend or change these Rules and Regulations at 
any time and without prior notice. </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">If you notice a Bravenet Member breaking any of the rules, please notify us 
via the Support Center: <BR></span></font><A href="http://support.bravenet.com/" 
target=_new><font face="Verdana"><span style="font-size:8pt;">http://support.bravenet.com</span></font></A><font face="Verdana"><span style="font-size:8pt;"> </span></font></P>
<P><font face="Verdana"><span style="font-size:8pt;">Please follow the rules... and enjoy Bravenet's Web Services! </span></font></P>

<?php 
include("footer.html");
?>
