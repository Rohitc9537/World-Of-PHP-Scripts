Script by RAZORE.co.uk


Install Instructions:

1) Upload all files to your php server
2) Run index.php and use the script!

Linking to us:
If you want, you may link to our site. There is already a link on the script but you can remove it by either changing $showlink to 0 or commenting out the link block of code.
