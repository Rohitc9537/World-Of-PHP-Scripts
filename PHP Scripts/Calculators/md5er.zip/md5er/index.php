<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>MD5 Hasher</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p align="center">
<h1 align="center">MD5 Hasher</h1>
<p>What would you like MD5 hashed? </p>
<form name="form1" method="post" action="md5er.php">
  <p>
    <input type="text" name="unencrypted">
  </p>
  <p>
    <input type="submit" name="Submit" value="Submit">
  </p>
</form>
<p>
<!--Please do not remove this-->
<a href="http://www.razore.co.uk">Powered by MD5 Hasher</a>
</body>
</html>