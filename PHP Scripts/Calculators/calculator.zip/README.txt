**********	     **********			    *	   * *    *
*		     *				    *	   * *   *
*		     *				    *	   * *  *
*		     *****			    *	   * ***
*     ****	     *				    *	   * ***
*	** ****	***  *	   **** ***** *  * *** ***  *	   * *  *
*	** *  *	*  * *	   *  *   *   **** **  *  * *	   * *   *
*	** *  *	*  * *	   ****   *   **** **  ***  *	   * *    * 
********** ****	***  *	   *  *   *   *  * *** *  * ******** *     *

This Calculator script is very simple to use, and easy to edit.

It relies on just the two files,
calculator.php
calculator.css

Just simply upload them onto your domain and you are ready to go!

If you would like to intergrate the style of the calculator to match your site, you may link it to your own stylesheet
and remove the calcultaor.css file.

All you need to do is open calculator.php
Find:
<link rel="stylesheet" type="text/css" href="calculator.css">
and edit it to link to your own .css file

If you do not have one, but wish to edit the colurs in the Calculator, open calculator.css
You then simply edit the colour codes, and font formats to suit your needs!


Wel li think that is all you will need to know to host your own calculator!

Just one request, that you please leave the 'Powered By GodfatherUK' beneath the script as i have put time and effort
into making this free script.
Thankyou!

If youy have any questions or Queries, dont hesitate to contact me at http://godfatheruk.com following the 'Contact' link!

ENJOY!