<< READ ME >>

Release Version: 1.2
Release Date   : 30/05/2005

TABLE OF CONTENTS

1. Package contents
2. Requirements
3. How to install
4. Copyrighted



1.1 PACKAGE CONTENTS

* prime.php
* README.php



2.1 REQUIREMENTS

This scripts requires the use of php. Before you use the script, check that your web space supports php.



3.1 EXTRACT

Extract the archive to you local hardisk. You should get a folder named 'prime'.
Upload this folder this to you web space.


3.2 INSTALL

The script requires no installation. If you have uploaded all the files then just add the 
following line to include the script:
<? include("./prime/prime.php"); ?>
Or link to the file


3.3 STYLE

This script uses no css style sheet so it's not possible to change the style.


3.4 NOTE

Do not aks the prime numbers for numbers above 1.000.000.000. The script will need a lot of time 
to find all those numbers and it may cause in an exertion of the execution time of your web server.



4.1 COPYRIGHT

This software is developed and copyrighted by Xantus WEBdevelopment (http://www.xantus-webdevelopment.com).


4.2 TERMS OF USE

This script may be used free for personal use. The copyright MUST remain intact.
Please contact us if you want to have the copyright removed.



5.1 UPDATES & CHANGES

1: The code in prime.php is realigned for a better view of the code
2: Codes is optimized for faster calculation of the prime numbers
3: Copyright notice updated