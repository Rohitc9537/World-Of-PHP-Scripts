<?php /* Smarty version 2.6.5-dev, created on 2005-02-12 13:58:05
         compiled from footer.tpl */ ?>
</body></html>