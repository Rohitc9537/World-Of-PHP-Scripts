<?php /* Smarty version 2.6.5-dev, created on 2005-05-12 11:22:18
         compiled from main.tpl */ ?>
<html>
<head>
	<title><?php echo $this->_tpl_vars['title']; ?>
</title>
	<meta name="keywords" content="mortgage calculators, online mortgage calculators">
	<meta name="description" content="<?php echo $this->_tpl_vars['description']; ?>
">
	<meta http-equiv="author" content="http://www.mortgagecalculatorsplus.com/">
	<link href="calculators.css" type="text/css" rel="stylesheet">
	<script type="text/javascript" src="calculators.js"></script>
</head>
<body><div id="tiplayer"></div>

<?php echo $this->_tpl_vars['contents']; ?>


</body></html>