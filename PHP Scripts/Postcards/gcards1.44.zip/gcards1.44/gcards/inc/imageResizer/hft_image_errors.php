<?
$ERR["FILE_DOESNOT_EXSIT"]		= $upload19;
$ERR["FUNCTION_DOESNOT_EXIST"]	= $upload10;
$ERR["GD2_NOT_CREATED"]			= $upload11;
$ERR["IMG_NOT_CREATED"]			= $upload12;
$ERR["GD2_UNAVALABLE"]			= $upload13;
$ERR["GD2_NOT_RESIZED"]			= $upload14;
$ERR["IMG_NOT_RESIZED"]			= $upload15;
$ERR["UNKNOWN_OUTPUT_FORMAT"]	= $upload16;
$ERR["NO_IMAGE_FOR_OUTPUT"]		= $upload17;
$ERR["IMG_NOT_SUPPORTED"]		= $upload18;
?>