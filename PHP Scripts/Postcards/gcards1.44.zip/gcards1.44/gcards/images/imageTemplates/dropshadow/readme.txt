Note:  Template file was created in Photoshop 7 - I don't know whether it (or these instructions) will work with other versions

Steps to create new dropshadow images:
1. Open dropshadowtemplate.psd in Adobe Photoshop
2. Choose the 'Background Color' layer
3. Select the entire image and fill with the same color you use as your gCards background color
4. Choose File -> Save For the Web
5. Choose an optimised version and click 'Save'
6. In dialog choose to save 'Images only' and click save
7. A folder called 'Images' will be created that will contain 6 gif files
8. Copy all of the files to your gcards images/siteImages/dropshadow folder
9. Done!