<?php
$lang['bad_user_pass'] = "Your username and password combination were not found.";
$lang['login_success'] = "Login Successful";
$lang['click_proceed_acp'] = "Click here to proceed to the admin centre.";
$lang['logged_out'] = "You have been logged out.";
$lang['back_to_acp'] = "Back to the admin centre";
?>