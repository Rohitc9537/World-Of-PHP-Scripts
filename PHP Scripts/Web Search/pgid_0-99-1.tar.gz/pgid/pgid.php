#!/usr/bin/php
<?php
$PROGRAMNAME="PGID";
$VERSION="0.99.1";
$DEBUG=0;
$DIR_BASE=getcwd();
$FILE_HTML="temp.html";
$NPERPAG=20;
$MAXDOWNLOAD=60;

$SURL="http://images.google.com/images?q=";
function WRITE_DEBUG($str) {
  global $DEBUG;
  if ($DEBUG==1) {
    echo "DEBUG :$str\n";
  }
}

function ScriviFile($NomeFile, $str) {
  WRITE_DEBUG("--$NomeFile--");
  $file = fopen($NomeFile, 'w');
  fwrite($file, $str); 
  fclose($file);
}


function WgetFile($URL, $dir, $radice) {
  $nomefile=$dir."/".$radice.basename($URL);
  if (@copy($URL, $nomefile)) {
          echo " DONE\n";
  } else {
          echo " FAILED\n";
  }
}

// BEGIN ______________________________
WRITE_DEBUG($DIR_BASE);
if ($argc == 1) {
  echo $PROGRAMNAME." v. ".$VERSION."\n";
	echo "Usage : ".$argv[0]." <keyword>\n";
	die();
}
WRITE_DEBUG("ok : processing : ".$argv[1]);
$keyword=$argv[1];
// IMPOSTO LA DIRECTORY DI SALVATAGGIO
$dir_save=$DIR_BASE."/".$keyword."/";
if (file_exists($dir_save)) {
        WRITE_DEBUG("DIR ALREADY EXIST : $dir_save");
} else {
        WRITE_DEBUG("Creating dir $dir_save");
        mkdir($dir_save);
}
$finito=false;
$start=0;
$quante=0;
while (!$finito) { //SCARICA PIUI? PAGINE DI RISULTATI
  $scontent = file_get_contents($SURL.$keyword."&start=".$start);
  $start=$start+$NPERPAG;
  ScriviFile($DIR_BASE."/".$FILE_HTML, $scontent);
  if ($scontent) {
    WRITE_DEBUG($scontent."\n");
  } else {
    echo "ERRORE\n";
  }
  $PATTERN ="((imgurl=[^\&]*)+)"; 
  $pos=0;
  $i=0;
  while ($len=ereg($PATTERN, $scontent, $ritorno)) {
    $i++;
    $quante++;
    if ($i>$NPERPAG) {
      die();
    }
    $pos=strpos($scontent, "imgurl=");
    //echo $pos."\n";
    echo $ritorno[1]."";
    $pos=$pos+$len;
    //echo $pos."\n";
    $scontent=substr($scontent,$pos);
    $url = substr($ritorno[1], 7);
    WgetFile($url,$dir_save, substr("000".$quante, strlen($quante))."_" );
    //ScriviFile($DIR_BASE."/".$i.$FILE_HTML, $scontenta);
    //$scontent=$scontenta;
  }
  if ($i<$NPERPAG) {
    $finito=true;
  }
  if ($start==$MAXDOWNLOAD) {
    $finito=true;
  }
}
echo "DONE\n";

?>
