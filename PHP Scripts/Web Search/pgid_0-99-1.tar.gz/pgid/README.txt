-----> PGID <-----
VERSION  : 0.99.1
AUTHOR   : Roberto B.
WEB SITE : http://www.errebit.com/opensource/

What "PGID" is ?
PGID searches, downloads and saves on your hard disk the images from web for a specified keyword.



INSTALLATION
$ tar zxvf pgid_0-99-1.tar.gz

CHECK YOUR INSTALLATION:
$ cd pgid/
$ ls -1

You must have :
LICENSE.txt
README.txt
pgid.php


USAGE
$ /usr/bin/php pgid.php <keyword>

After that, you should have a new directory <keyword> with your new images.


