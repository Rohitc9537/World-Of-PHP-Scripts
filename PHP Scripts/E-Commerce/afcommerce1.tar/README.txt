  File Name: README.txt, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License

-----------------------------------------------------------------------

								Outline
1. Before you begin
2. Installation
3. Copyright Information
4. Additional Documentation
5. Why Should I Use Amazing Flash ?

-----------------------------------------------------------------------

1. Before you begin -
	AFCommerce was created as a simple ecommerce solution that can add power to your website. When I first started designing websites and php applications, I used the OSCommerce Shopping Cart for my clients. While using oscommerce, I noticed many aspects that I did not agree with. Oscommerce is a well written application, and is one of the most popular shopping carts in the world, however it is extremely difficult to customize. Oscommerce can be modified only with many man hours and only with an advanced understanding of php. I have designed many unique php applications including the Amazing Flash website builder and content management system, and it even takes me a while to add to Oscommerce. By now, I can modify their cart very fast but when I see new programmers try to figure it out, it generally seems to be fairly difficult for them. 

	So with that being said, my cart is set up differently. The majority of files are in the main website directory. Some programmers may believe this is sloppy programming without having each type of module being in its own directory, however I feel that since the cart is written to have most of the features of expensive shopping carts, but still uses less disk space, has a lower load on the server, and is easier to customize. This cart is used with our website builder, and most of the time our system is reading our file structure, not a person, so structure is generally not an issue. In later versions I may add more of a structure to this cart, but am afraid of becoming like other carts with too many files, thus making my cart harder to customize than it is now. I welcome comments on afcommerce.com, and I will try to add any changes that I get a lot of requests for. I will not respond to complaints (hopefully there will not be any). I want to help as many people as I can and do my part to add to the open source community. I have used many open source programs myself, and learned a lot from them, so if my application can help others the same way, I am happy to be of service.

-----------------------------------------------------------------------

2. Installation / Requirements -

You should have php 4.0 or higher, and mysql 3.0 or higher already installed

a) unzip the software and upload all files to your web server. I recommend uploading all files in your domain's root directory.

b) Chmod the "web" and "images" directories to 777. If you are adding products that need to be downloaded after purchase, also Chmod the "downloads" directory to 777. Chmod (Change Mode) means setting the permissions for user, group and other to read, write and execute. Most ftp programs have functions that will do this for you.

c) Create a new empty mysql database with a mysql user that has "Select, Insert, Create, Update, Delete" privileges. You must use a password for your mysql user, this measure is taken for security. Also for security, you should password protect the "admin" directory so that only you can access the administration area for the cart.

d) Run the install file. If you set the cart up the way I suggest, the install file can be found at : http://yourname.com/install/install.php. You should be able to go to the home page of your shopping cart (or any other page) and be redirected to the install file. Make sure you delete the "install" directory after the installation is complete.

That should be it. If you have trouble doing this, check out our support forums at: http://amazingflash.com/forum/. I highly recommend that you use our Amazing Flash system if you can set up a remote database connection to our servers. Read the section labeled "Why Should I use Amazing Flash ?" below.

----------------------------------------------------------------------- 

3. Copyright Information -

Like most free software on the internet, I require a link on the website in order to use the software. I have seen other companies take this WAY too far. Some people ask for a huge link and some even try to get an image and a text link. I do not do this, and I believe I have been very reasonable with what I require. 

If you are using this shopping cart software, you must keep the link that says, "Powered By AFCommerce.com" on the bottom of your pages. Please do not modify this link in any way. It is not uncommon for a link to be on a site from the designer, so by saying it looks unprofessional is simply not true. That link supports our community and also brings more developers to the community to develop new features.

I do not ask for donations to be made either. What I have done is add a small footer, ONLY in the admin area, which only you will see (not your customers), that has advertisements. These ads do not generate much money, but it will generate enough to allow me to spend more time adding new features and more documentation. Everyone should try to do their part to support this project, and I felt this was the best way to accomplish this. Think about it, the ads are only on the bottom of the pages in the admin area, and if you take them off that space will just be empty. This ad space is only valuable to us, no advertiser would allow you to put your own ads in your own admin area. 

These ads are completely optional, and may be taken off by selecting the option on the "Configure My Store" page, that says "Show Ad Block In Administration Area Footer ?". There is no personal information collected in any way from these ads, and any programmer who understands how an iframe works should understand this. You can see the code that calls the iframe and tell that nothing unethical is going on. I didn't want to give any reason to not show these ads, so I made it as safe and secure as possible. A few months after the release of this software, I will let people who allow these ads to be shown to have a link to their new store be put on www.afcommerce.com as a thank you. More instructions will be given at a later date.

Thank you for your support of AFCommerce !

----------------------------------------------------------------------- 

4. Additional Documentation -
	Please go to www.afcommerce.com for more documentation. This is the first release of this cart so our forums and documentation will not have every possible situation covered yet. More information will be added as questions arise, and I hope that other developers will try to answer some questions on the forums as well as me. The AFCommerce project is very important to me and will NOT be dropped for lack of time. As this cart becomes more popular, I will look for help from other developers from around the world. 

There will be a forum on afcommerce.com, which will be the same forum that is used for AmazingFlash.com. I am focusing all support in the same forums. 

Please be helpful on the forums. Also, and this is very important, please be as positive as you can while in the forums. Nothing in this world is perfect, and I have noticed that when dealing with a high number of people, you can never make everyone happy. If you ask for my help, or help from any member of the community, you MUST ask nicely with the understanding that no one owes you anything. Its a free community for a free shopping cart, and any help that is given is a bonus. Even if your not asking me for my help, if I see that someone else is trying to help you and you are rude to them, I will immediately remove all of your privileges from using the forums.

And finally, my company AmazingFlash is a development company. Any help I give will be on my own time and NEVER over the phone. So if you do not plan on buying support time or paying for customization, PLEASE DO NOT CALL US.

----------------------------------------------------------------------- 

5. Why Should I Use Amazing Flash ?
	AmazingFlash.com has the most powerful online flash website builder in the world. Some people have trouble understanding the full capabilities of the system, generally because they try to compare it to other systems they find on the internet. I could not possibly explain it all here, but I will explain some of the more important reasons in this section. 

a) First, the concept of using a template scares people away. I am actually thinking of using different terminology instead of the word template. Generally a template is a pre-built website where you can change the pictures, colors and text. Amazing Flash does not build pre-designed websites. We have pre-designed flash banners that can be used for free, however the rest of the website is created automatically by the system. As of this moment, there are more customizable options with Amazing Flash than any other system I have seen. Instead of building a system to edit pre-designed websites, my system actually builds the website the same way a person would. There are some general similarities to all websites created with the system, it still is a program creating the website, however I made every feature interchangeable with each other. Each template has the same abilities as the next, you can switch between any template and still have all of the same features available. You also do not have to redesign your website anytime you make a major change, when you switch your banner template, all of your old information is automatically transferred to the new one. 

Also, you do not have to use any of the banner templates at all. We allow you to upload your own banner to make a unique template. Your banner can be either flash or a graphic, the only draw back is that you must make your banner yourself with the exact proportions that you want it displayed. The system does not alter your banner in any way, and does not resize it to make it fit. This must be done before its upload, but you can upload it as many times as you want while your making your own adjustments. You can also hire someone from my development team to create the banner for you, or have your own web designer create one for you. 

b) The administration area for our shopping cart is inside of the website builder's control panel. Not only it nice to have everything in one place, but there are also more features for you to use. If you set up an account with Amazing Flash, which is free if your not hosting your website with us, you can easily add web pages to your online store that have the same look and feel as the shopping cart that you create. 

We also have more advanced features like automatic image optimization and resizing. Any time you take a picture with a digital camera, the image is generally around 2000 pixels in height and around 1 megabyte in file size. Our system will optimize the picture while it is being uploaded, and make that image 400 pixels in height and also resize the width to be proportional. Our system also tries to increase the picture quality of the image and makes the file size around 40 kilobytes. 

Your files are also automatically uploaded to your server as they are being created. I have seen other builders out there that let you download your files, and some others that require you to download software to your computer that will create your files for you. Most people reading this file are web developers and should not have any trouble putting a website on to a web server, however this feature still saves you time, and eliminates most errors. Other people who are new the web LOVE this feature because they have no idea on how to upload their files, and probably become frustrated with other companies that say how easy it is to do. These other companies think if they say its easy, the person will magically learn how to do it. We all know its not hard, but even I would rather use my system to make it even easier.

c) Changing parts of your site is easier, but you also have just about everything you would ever need. There is a button maker, which is new and does not have a ton of button templates yet, but still makes buttons really fast and lets you push a button to have it automatically uploaded and placed on your site. I also keep adding new free features like mouse trails, various code creators, and soon I will be adding free games, maps, news headlines and more.

d) Automatic upgrades - Now whenever I add new features to the cart's admin area, you will have instant access to them. You will not have to download and reinstall the new changes to your website. Now to be clear, any changes to the software that is installed on your website, you would need to upgrade the cart, but the admin area is automatically updated and I intend on adding new features that will not affect your software regularly, and will schedule any major changes only after a new version of the cart is released.    

Thank You For Using Amazing Flash Commerce !
