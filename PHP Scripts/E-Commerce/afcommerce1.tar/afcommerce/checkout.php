<?php
/*
  File Name: checkout.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");

if ($id == "")   {
header("location:viewcart.php");
exit;    }
include("tax.php");
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid]; 
if (($memberid == "") || ($memberid == "0"))   {
header("location:account.php");
exit;    }
$totalprice = $newarray[totalprice];
$promocode = $newarray[promocode];
$comments = $newarray[comments];
$newshipaddress = $newarray[newshipaddress];

$select = "select * from promos where promocode = '$promocode' && status = '1'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$discount = $newarray[discount];

if (($newshipaddress == "") || ($newshipaddress == "0"))   {
$select = "select * from members where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$address = $newarray[address];
$city = $newarray[city];
$state = $newarray[state];

$select2 = "select * from zones where zone_id = '$state'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$formatstate = $newarray2[zone_name]; 

$zipcode = $newarray[zipcode];
$country = $newarray[country];
$newshipaddress = "$address<BR> $city, $formatstate $zipcode";
$newshipaddress = ucwords ($newshipaddress);
}
else    {
$shiparray = explode (",", $newshipaddress);
$address = $shiparray[0];
$city = $shiparray[1];
$state = $shiparray[2];
$zipcode = $shiparray[3];
$country = $shiparray[4];

$newshipaddress = "$address<BR> $city, $state $zipcode";
$newshipaddress = ucwords ($newshipaddress);
}
$shipcode = "$address,$city,$formatstate,$zipcode,$country";

$select = "select * from config where varname = 'taxshipping'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$taxshipping = $newarray['varvalue'];

$select = "select * from config where varname = 'shipmethod'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$shipmethod = $newarray['varvalue'];
require ("shipping.php");
$shipcost = calculateshipping ($shipmethod, $id);

$select = "select * from config where varname = 'pickupshipping'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$pickupshipping = $newarray['varvalue'];

$select = "select * from config where varname = 'handling'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$handling = $newarray['varvalue'];
$handlingformatted = number_format ($handling, 2); 

$shipandhandling = $handling + $shipcost;
$shipandhandlingformatted = number_format ($shipandhandling, 2); 

$subtotal = 0;
$numb = 0;
$select = "select * from basket_products where basketid = '$id'";
$answer = mysql_query($select, $conn);
while ($newarray = @mysql_fetch_array($answer))   {
$quantity = $newarray[quantity];
$price = $newarray[price];
$producttotal = $quantity * $price;
$subtotal = $subtotal + $producttotal;
$numb = numb + 1;
}
if ($numb == "0")   {
header("location:viewcart.php");
exit;    }
$taxrate = gettaxrate($state, $country);
$taxratedec = $taxrate / 100;
if ($taxrate != "0")  {
$tax = $subtotal * $taxratedec;
$taxpickup = $tax;

if ($taxshipping == "1")  {
$shiptaxcost = ($shipandhandling * $taxratedec) + $tax;
$shiptaxcostpickup = ($handling * $taxratedec) + $tax;
$shiptaxcostformatted = number_format ($shiptaxcost, 2);
$shiptaxcostpickupformatted = number_format ($shiptaxcostpickup, 2);
$shiptaxcostdifference = $shiptaxcost - $shiptaxcostpickup;
$shiptaxcostdifferenceformatted = number_format ($shiptaxcostdifference, 2);

$tax = $shiptaxcost;
$taxpickup = $shiptaxcostpickup;
} // ends tax shipping

else  {
// not taxing shipping, so its pretty straight forward
$tax = $subtotal * $taxratedec;
$taxformatted = number_format ($tax, 2);   }

$taxformatted = number_format ($tax, 2);     }
$subtotalformatted = number_format ($subtotal, 2);

$afterdiscount = (100 - $discount) / 100;
$newsubtotal = ($subtotal * $afterdiscount); 
$newsubtotalformatted = number_format ($newsubtotal, 2);
$promodiscount = $subtotal - $newsubtotal; 
$promodiscountformatted = number_format ($promodiscount, 2); 
if ($discount != "")   {
$ordertotal = $newsubtotal + $shipandhandling + $tax;
$ordertotalpickup = $newsubtotal + $handling + $taxpickup; } 
else   {
$ordertotal = $subtotal + $shipandhandling + $tax;
$ordertotalpickup = $subtotal + $handling + $taxpickup; } 

$ordertotalformatted = number_format ($ordertotal, 2); 
$ordertotalformattedpickup = number_format ($ordertotalpickup, 2); 

include("carttop.php"); 
?>
<script language="JavaScript">
/* Please note: This javascript will not work if you change the default pickup shipping radio buttons. If you change those radio buttons, you will need to update this function too. All the radio buttons create an array automatically by javascript, so the only way to see which one is checked is to check if each element of the array is checked. The first radio button will be shipmethod[0], the second shipmethod[1]. If you add more options, just follow my pattern below and make sure they are in the correct order. --- Paul Crinigan, AmazingFlash.com     */ 

function updateordertotal()  {

// -------------------------------------------------------------------
/* these values are set by php and should not be changed, they are here so the script will know the values of both shipping options if you are using pickup shipping. If your not using that module, this code does nothing.   */
// -------------------------------------------------------------------

normalshippingordertotal = "<?php echo $ordertotal; ?>";
normalshippingordertotalformatted = "<?php echo $ordertotalformatted; ?>";
pickupshippingordertotal = "<?php echo $ordertotalpickup; ?>";
pickupshippingordertotalformatted = "<?php echo $ordertotalformattedpickup; ?>";
<?php
if ($taxshipping == "1")  { echo "
taxcost = '$shiptaxcostformatted';
taxcostpickup = '$shiptaxcostpickupformatted';
taxcostdifference = '$shiptaxcostdifferenceformatted';
";
} // ends tax shipping
?>

if (document.checkoutform.shippingmodule[0].checked == true) {
// this means they selected normal shipping
document.checkoutform.ordertotaldisplay.value = normalshippingordertotalformatted;
document.checkoutform.totalprice.value = normalshippingordertotal;
document.checkoutform.totalpriceformatted.value = normalshippingordertotalformatted;
<?php
if ($taxshipping == "1")  { echo "
document.checkoutform.taxdisplay.value = taxcost;
document.checkoutform.tax.value = taxcost;
";
} // ends tax shipping
?>
}
else if (document.checkoutform.shippingmodule[1].checked == true) {
// this means they selected pickup shipping
document.checkoutform.ordertotaldisplay.value = pickupshippingordertotalformatted;
document.checkoutform.totalprice.value = pickupshippingordertotal;
document.checkoutform.totalpriceformatted.value = pickupshippingordertotalformatted;
<?php
if ($taxshipping == "1")  { echo "
document.checkoutform.taxdisplay.value = taxcostpickup;
document.checkoutform.tax.value = taxcostpickup;
";
} // ends tax shipping
?>
}
else {
// nothing is selected, so default to normal shipping
document.checkoutform.ordertotaldisplay.value = normalshippingordertotalformatted;
document.checkoutform.totalprice.value = normalshippingordertotal;
document.checkoutform.totalpriceformatted.value = normalshippingordertotalformatted;
<?php
if ($taxshipping == "1")  { echo "
document.checkoutform.taxdisplay.value = taxcost;
document.checkoutform.tax.value = taxcost;
";
} // ends tax shipping
?>
}
} // ends function
</script>
<CENTER>
<table class='contentheader' width='100%'><tr>
<?php if ($cartimages == "1")  {
echo "<td width='20%' align='center'><IMG SRC='boy_pushing_shopping_cart_sm_clr.gif'></td>"; } ?>

<td width='80%' align='center'><?php echo CHECKOUT_HEADER; ?></td></tr></table>
<?php if ($promocodefeature == "1") { ?>
<table width='100%'><tr><td width='50' align='right'></td><td align='right'><font size='2'><B><?php echo CHECKOUT_ENTERPROMOCODE; ?>:</B></font></td><td align='right'><form action='updatepromo.php' method='post'><input size='12' name='promocode'></td><td align='right'><input type='image' src='lang/<?php echo $langid; ?>/1/button_updatecart.gif'></td></tr></table></form><?php } ?>
<form action='processcheckout.php' method='post' name='checkoutform'><table class='maincart' width='100%' border='1'><tr><td width='40%' align='left' valign='top'><CENTER><BR><?php if ($displayshipaddress == "1") {
echo CHECKOUT_SHIPADDRESS; ?>:<BR><BR><input type='hidden' name='shipcode' value='<?php echo $shipcode; ?>'>
<A HREF='changeshipaddress.php' class='maincart'><?php echo CHECKOUT_EDITADDRESS; ?></A><HR><?php echo $newshipaddress; ?><BR><BR><BR><BR><BR><?php } ?>
<?php echo CHECKOUT_PAYMETHOD; ?>:<HR></CENTER><?php 
$select = "select * from paymethod where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$description = $newarray[description];
$type = $newarray[type];    
echo "<input type='radio' name='paymethod' value='$type' checked> $description<BR><BR>";
}   ?>
<BR><BR><BR>

</td><td width='60%' align='center' valign='top'><?php echo CHECKOUT_SUBTOTAL; ?>:<BR><BR>$ <?php if (($discount != "") && ($promocode != ""))   {
echo "<s>$subtotalformatted</s><BR><BR>" . CHECKOUT_AFTERPROMO . ":<BR><BR>$ $newsubtotalformatted";
}
else {
echo $subtotalformatted;    }  ?><BR><BR><A HREF='viewcart.php' class='maincart'><?php echo CHECKOUT_EDITCART; ?></A><HR><BR>

<?php if ($displayshipping == "1") {

if ($pickupshipping == "1") {

echo "<CENTER>" . CHECKOUT_SHIPMETHOD . "<table width='300' border='0' cellspacing='0' cellpadding='6'><tr><td width='20' align='center'><input type='radio' name='shippingmodule' value='normal' onclick='updateordertotal();' checked></td><td width='*' align='left'>" . CHECKOUT_SHIPPINGHANDLING . ": &nbsp;&nbsp;$ $shipandhandlingformatted </td></tr><tr><td width='20' align='center'><input type='radio' name='shippingmodule' value='pickup' onclick='updateordertotal();'></td><td width='*' align='left'>" . CHECKOUT_PICKUPSHIPPING . ": &nbsp;&nbsp;$ $handlingformatted <input type='hidden' name='pickupshippingcost' value='<?php echo $handling; ?>'></td></tr></table></CENTER>";
} // ends pick up shipping

else {
// normal shipping - one option only - choose which one in the admin area
echo CHECKOUT_SHIPPINGHANDLING . ": &nbsp;&nbsp;$ $shipandhandlingformatted ";
} // ends normal shipping
?>
<BR><HR>
<?php } // ends display shipping ?>
<?php if ($displaytax == "1") { ?>
<BR><?php echo CHECKOUT_TAX; ?>: &nbsp;&nbsp;&nbsp;&nbsp;<B>$</B> <input size='7' type='text' name='taxdisplay' value='<?php echo $taxformatted; ?>' style='font-size: 16px; 
border: 0px solid #000000;' readonly><?php echo "&nbsp;($taxrate %)"; ?><BR><HR><?php } ?>

<input type='hidden' name='shipcost' value='<?php echo $shipandhandling; ?>'><input type='hidden' name='tax' value='<?php echo $taxformatted; ?>'><input type='hidden' name='promodiscount' value='<?php echo $promodiscountformatted; ?>'><BR><?php echo CHECKOUT_ORDERTOTAL; ?>: &nbsp;&nbsp;&nbsp;&nbsp;<B>$</B> <input size='10' type='text' name='ordertotaldisplay' value='<?php echo $ordertotalformatted; ?>' style='font-size: 17px; 
border: 0px solid #000000;' readonly><input type='hidden' name='totalprice' value='<?php echo $ordertotal; ?>'><input type='hidden' name='totalpriceformatted' value='<?php echo $ordertotalformatted; ?>'><BR><BR></td></tr></table><BR><BR>

<BR><BR><font size='4' class='viewcart'><?php echo CHECKOUT_ADDCOMMENTS; ?> </font><BR>
<textarea cols='40' rows='6' name='comments'></textarea><BR><BR><BR><input type='image' src='lang/<?php echo $langid; ?>/1/button_gotosecurepage.gif'><BR><BR><BR><BR></form>
</td></tr></table><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
