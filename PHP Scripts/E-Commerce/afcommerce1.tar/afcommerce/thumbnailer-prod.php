<?php
/*
  File Name: thumbnailer-prod.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$maxheight = 200;
$maxwidth = 200;
$imagepath = "images/$prodimage";
$imagearray = @getimagesize ($imagepath);
$width = $imagearray[0];
$height = $imagearray[1];

$newwidth = $width;
$newheight = $height;

if ($height > $maxheight) { 
$newheight = $maxheight;
// make the width proportional
$difference = $width / $height;
$newwidth = $difference * $newheight;   }

if ($newwidth > $maxwidth) { 
$newwidth = $maxwidth;
// make the height proportional
if ($difference > 0) {
$newheight = $newwidth / $difference;   }   }

$width = floor($newwidth);
$height = floor($newheight);

?>
