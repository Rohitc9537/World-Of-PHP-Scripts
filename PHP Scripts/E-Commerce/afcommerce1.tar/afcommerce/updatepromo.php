<?php
/*
  File Name: updatepromo.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$promocode = $_POST[promocode];
if ($promocode != "")   {
$update = "update basket set promocode = '$promocode' where id = '$id'";
mysql_query($update, $conn);   }
header("location:checkout.php");
?>
