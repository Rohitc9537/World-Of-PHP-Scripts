<?php
/*
  File Name: shipping.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

function calculateshipping ($shipmethod, $bid)   {
include("dbinfo.php");
switch ($shipmethod)   {
case "flatrate":
$select = "select * from config where varname = 'flatrate'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$totalshipping = $newarray[varvalue];
break;

case "percentagerate":
$select = "select * from config where varname = 'percentagerate'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$percentagerate = $newarray[varvalue];
$percentagerate = $percentagerate / 100;
$select2 = "select * from basket_products where basketid = '$bid'";
$answer2 = mysql_query($select2, $conn);
$totalprice = 0;
while ($newarray2 = mysql_fetch_array($answer2))   {
$price = $newarray2[price];
$totalprice = $totalprice + $price;    }
$totalshipping = $totalprice * $percentagerate;
break;

case "byweight":
$select = "select * from config where varname = 'byweight'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$byweight = $newarray[varvalue];
$select2 = "select * from basket_products where basketid = '$bid'";
$answer2 = mysql_query($select2, $conn);
$totalweight = 0;
while ($newarray = mysql_fetch_array($answer2))   {
$tempprodid = $newarray[prodid]; 
$tempquantity = $newarray[quantity]; 

$select3 = "select * from products where prodid = '$tempprodid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$weight = $newarray3[weight]; 
$temptotalweight = $tempquantity * $weight;
$totalweight = $totalweight + $temptotalweight;    }

$totalshipping = $byweight * $totalweight;
break;

case "peritem":
$select = "select * from config where varname = 'peritem'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$peritem = $newarray[varvalue];
$select2 = "select * from basket_products where basketid = '$bid'";
$answer2 = mysql_query($select2, $conn);
$numitems = 0;
while ($newarray = mysql_fetch_array($answer2))   {
$quantity = $newarray[quantity];
$numitems = $numitems + $quantity;   }
$totalshipping = $peritem * $numitems;
break;

}
return $totalshipping;
}
?>
