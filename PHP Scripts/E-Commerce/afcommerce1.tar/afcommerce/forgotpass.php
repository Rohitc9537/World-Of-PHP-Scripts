<?php 
/*
  File Name: forgotpass.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$email = $_POST[email];
if ($email == "")   {
echo "<HTML><HEAD><TITLE> Forgot Password </TITLE></HEAD><BODY BGCOLOR='#FFFFFF' TEXT='#000000'><CENTER><form action='forgotpass.php' method='post'><H3>Your Email Address:</H2><input size='20' name='email'><BR><BR><input type='submit' value='Email Me My Password'></form></BODY></HTML>";      }

else   {
include("dbinfo.php");
$select = "select * from config where varname = 'domainname'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$domainname = $newarray[varvalue];

$select = "select * from members where email = '$email'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) < 1)   {
echo "<HTML><HEAD><TITLE> Forgot Password </TITLE></HEAD><BODY BGCOLOR='#FFFFFF' TEXT='#000000'><CENTER><form action='forgotpass.php' method='post'><font size='5' color='#ff0000'>Email Can Not Be Found</font><BR><H3>Your Email Address:</H2><input size='20' name='email'><BR><BR><input type='submit' value='Email Me My Password'></form></BODY></HTML>";
exit;
    }
$newarray = mysql_fetch_array($answer);
$pass = $newarray[pass];

$msg = "Hello, 

This message is being sent because someone, hopefully you, has requested your password. This password is only being emailed to this email address. Please save your password in a safe place.

Password: $pass

";
$subject = "Forgotten Password";
$mailheaders = "From: noreply@$domainname";
mail($email, $subject, $msg, $mailheaders);

echo "<HTML><HEAD><TITLE> Forgot Password </TITLE></HEAD><BODY BGCOLOR='#FFFFFF' TEXT='#000000'><CENTER><font size='5' color='#ff0000'>Password Sent</font><BR><BR><a href='javascript:window.parent.close();'><h4>Close Window</h4></a>";
}

?>
