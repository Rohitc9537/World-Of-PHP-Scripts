<?php
/*
  File Name: getcategory.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$cat = $_GET['cat'];
include("carttop.php");
include("dbinfo.php");
$select = "select * from categories where catid = '$cat'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$catimage = $newarray[catimage];
  
$select3 = "select * from categories_descript where catid = '$cat' && langid = '$langid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$categoryname = $newarray3[catname];
$catdescript = $newarray3[catdescript];

echo "<CENTER><A class='login' HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A><BR><table width='95%'><tr><td width='65%' align='center' valign='middle'><font size='5'>$categoryname</font></td>";
if (strlen($catimage) > 4)   {
echo "<td width='35%' align='center' valign='middle'><IMG SRC='images/$catimage' border='0' height='120'></td>";    }

echo "</tr></table>";

if ($catdescript != "") {
echo "<BR><BR><font size='4'>$catdescript</font>";    }


echo "<BR><HR>";  

$select = "select * from categories where level = '$cat'";
$answer = mysql_query($select, $conn);
$numsubcats = mysql_num_rows($answer);
if ($numsubcats > 0) {

$i = 0;
$catidarray = array();
$catnamearray = array();

while ($newarray = mysql_fetch_array($answer))   {
$i = $i + 1;
$catidarray[$i] = $newarray['catid'];
$select3 = "select * from categories_descript where catid = '$catidarray[$i]' && langid = '$langid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$catnamearray[$i] = $newarray3['catname'];    }

@array_multisort($catnamearray, SORT_ASC, SORT_STRING, $catidarray);

echo "<table width='90%'><tr>";

for ($i = 0; $i < $numsubcats; $i++) {

$catid = $catidarray[$i];
$categoryname = $catnamearray[$i];

$select2 = "select * from categories where catid = '$catid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$catimage = $newarray2[catimage];

echo "<td width='33%' align='center' valign='bottom'><a href='getcategory.php?cat=$catid' class='login'>";
if ($catimage != "")   {
echo "<IMG SRC='images/$catimage' border='0' height='100'><BR><BR>";   }

echo "<font size='3'><B>$categoryname</B></font></a></td>";

if (($i % $productsperrow) == 0)   {
echo "</tr><tr>";    }     }


echo "</tr></table><BR>";
if (($i != "0") && ($level != "0"))    { 
echo "<HR><BR>";    }

} // ends if numsubcats is greater than 0 

if ($page == "") { $page = 1; }
$startnum = ($page - 1) * $numperpage;

// first find out how many products we have in total.
if (($displayoutofstock != "1") && ($quantityfeature == "1"))  {
$select = "select * from products where catid = '$cat' && prodquantity > 0 && status = '1'";   }
else {
$select = "select * from products where catid = '$cat' && status = '1'";   }

$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$count = $count + 1; }
if ($count > ($page * $numperpage)) { $shownextpagelink = 1; }

if (($displayoutofstock != "1") && ($quantityfeature == "1"))  {
$select = "select * from products where catid = '$cat' && prodquantity > 0 && status = '1' LIMIT $startnum , $numperpage";   }
else {
$select = "select * from products where catid = '$cat' && status = '1' LIMIT $startnum , $numperpage";   }

$answer = mysql_query($select, $conn); 
$numsubprods = mysql_num_rows($answer);

$i = 0;
$prodidarray = array();
$prodnamearray = array();

while ($newarray = mysql_fetch_array($answer))   {
$prodidarray[$i] = $newarray['prodid'];
$select2 = "select * from product_descript where prodid = '$prodidarray[$i]' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodnamearray[$i] = $newarray2['prodname']; 
$i = $i + 1;   }

@array_multisort($prodnamearray, SORT_ASC, SORT_STRING, $prodidarray);

echo "<BR><CENTER><table align='left' width='97%'><tr>";

for ($i = 0; $i < $numsubprods; $i++) {

$prodid = $prodidarray[$i];
$prodname = $prodnamearray[$i];

$select2 = "select * from products where prodid = '$prodid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodimage = $newarray2['prodimage'];

echo "<td width='33%' align='center' valign='middle'>";
if ($prodimage != "")   {
include("thumbnailer-cat.php");
echo "<a href='getproduct.php?pid=$prodid' class='login'><IMG SRC='images/$prodimage' border='0' height='$height'></a><BR><BR>";   }

echo "<a href='getproduct.php?pid=$prodid' class='login'><font size='3'><B>$prodname</B></font></a></td>";

if (($i % $productsperrow) == 0)   {
echo "</tr><tr><td><BR><BR></td></tr><tr>";    } 

}

if ($i == "0")   {   echo "</tr></table><BR><font size='4'>There are no products to display</font><BR><BR><BR>";  }
else { echo "</tr></table>"; }
$nextpage = $page + 1;
$previouspage = $page - 1;
if ($page > 1) { echo "<a href='getcategory.php?cat=$cat&page=$previouspage' class='login'><font size='3'>Previous Page</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
if ($shownextpagelink == "1") { echo "<a href='getcategory.php?cat=$cat&page=$nextpage' class='login'><font size='3'>Next Page</font></a>"; }

?><?php echo "<BR><BR><BR></td></tr></table></td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
