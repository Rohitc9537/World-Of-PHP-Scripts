<?php
/*
  File Name: payform.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

// The first thing you need to do in this file is set the path to the payflow pro // software. The Pro must be set up correctly for this to work at all, and this 
// script will run the pro command as a Unix binary with the "exec" function
// You can even set the pro up by uploading the pfpro and libpfpro.so files
// in to the local domain directory and just use the file name as the full path

$host = "test-payflow.verisign.com";
$port = "443";
$binary = "/usr/local/bin/pfpro";
$library = "/usr/local/lib/libpfpro.so";
$newld = "/usr/local/lib";
// set the cert path, you can just upload the cert directory in the dir we are in
putenv("PFPRO_CERT_PATH=certs/");


include("dbinfo.php");
$select = "select * from config where varname = 'defaultlang'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$langid = $newarray[varvalue];
$langfilename = "lang" . $langid . ".php";
require ("lang/$langfilename");
$errorflag = 0;
$currentdate = time();
$select = "select * from config where varname = 'domainname'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$domainname = $newarray[varvalue];
$amount = $_POST[AMOUNT];
if ($amount == "")   {
$errorflag = 1;    }
$amountformatted = number_format ($amount, 2);
$amount = str_replace(",", "", $amountformatted);
$cardnum = $_POST[cardnum];
if ($cardnum == "")   {
$errorflag = 1;   }
$cardnum = str_replace("-", "", $cardnum);
$cardnum = str_replace(" ", "", $cardnum);
$cardnum = str_replace("/", "", $cardnum);
if (strlen ($cardnum) < 15)   {
$errorflag = 1;   
$invalidcard = 1; }
$zipcode = $_POST[ZIP];
$id = $_POST[id];
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid]; 
if (($memberid == "") || ($memberid == "0"))   {
header("location:account.php");
exit;    }
$select = "select * from members where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$firstname = $newarray[firstname];
$lastname = $newarray[lastname];
$email = $newarray[email];
$phone = $newarray[phone];
$customername = "$firstname $lastname";

if ($zipcode == "")   {
$errorflag = 1;    }
$expmonth = $_POST[expmonth];
if ($expmonth == "")   {
$errorflag = 1;      }
$expyear = $_POST[expyear];
if ($expyear == "")   {
$errorflag = 1;      }
$expdate = "$expmonth$expyear";
$streetaddress = $_POST[ADDRESS];
if ($streetaddress == "")   {
$errorflag = 1;   }
$securitycode = $_POST[securitycode];
if ($securitycode == "")   {
$errorflag = 1;   }

if ($errorflag == 0)   {    
$select = "select * from paymethod where type = 'Verisign-Payflow Pro'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$info1 = $newarray[info1];
$info2 = $newarray[info2];
$info3 = $newarray[info3];
$info4 = $newarray[info4];

// form info is validated, lets try to charge the credit card
$user = $info1;
$vendor = $info4;
$partner = $info2;
$pwd = $info3;

$original_ld_path = getenv("LD_LIBRARY_PATH");  // save old value
if ($original_ld_path) {
  $newld .= ":$original_path";        }     // append old paths if any
putenv("LD_LIBRARY_PATH=$newld");               // set new value
$current_ld_path = getenv("LD_LIBRARY_PATH");   // save current value

		$result = exec("$binary $host $port \"TRXTYPE=S&TENDER=C&PWD=$pwd&USER=$user&VENDOR=$vendor&PARTNER=$partner&ACCT=$cardnum&EXPDATE=$expdate&AMT=$amount&COMMENT1=AFCommerce Shopping Cart&STREET=$billaddress&ZIP=$zipcode\" 30", $string, $exit_value);  

        $valArray = explode('&', $result);
         foreach($valArray as $val) {
		        $valArray2 = explode('=', $val);
				if ($valArray2[0] == "PNREF")   {    $confirmcode = $valArray2[1]; }    }

if ($exit_value == "0")    {
echo "Going to checkout
<script>
self.location.replace('processpayment.php?confirmcode=$confirmcode&paymethod=vpro');
</script>";     }	
		
else   {
  $error = 1;		
		}

        // now that we're done, restore the old linker path:
        putenv("LD_LIBRARY_PATH=$original_ld_path");    


		  }


echo "<HTML><HEAD><meta http-equiv=Content-Type content='text/html;  charset=ISO-8859-1'><TITLE>Make A Credit Card Payment</TITLE></HEAD><style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #0099CC; text-decoration: none}
a:visited { color: #0099CC; text-decoration: none}
a:active { color: #ff0000; text-decoration: underline}
a:hover { color: #ff0000; text-decoration: underline}
-->
</style>
<BODY bgcolor='#ffffff'><CENTER>
<CENTER><TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD BGCOLOR='#330099' WIDTH='150' ALIGN='CENTER' VALIGN='TOP'>";
 
echo "<BR><BR></TD><TD WIDTH='*' ALIGN='CENTER' VALIGN='TOP'><BR>";	 ?>

<form action="https://<?php echo $domainname; ?>/payform.php" method="post"><H2><?php echo PFP_HEADER; ?></H2><A HREF='javascript:history.go(-2)'><font size='4'><?php echo BACKBUTTON; ?></font></A><HR>
<?php if ($_POST[validate] == "1")    {
echo "<font color='#ff0000' size='4'>" . PFP_ERROR . "</font><BR><BR>";   } 
if ($error == "1")    {
echo "<font color='#ff0000' size='4'>" . PFP_CARDDECLINE . "</font><BR><BR>";   }  ?>

<TABLE WIDTH="500" BORDER="1" CELLSPACING="4" CELLPADDING="7">
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_AMOUNT; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4">$ <?php echo $amountformatted; ?></font>
<input type="hidden" name="AMOUNT" value="<?php echo $amount; ?>">
<input type="hidden" name="id" value="<?php echo $id; ?>">

   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_CARDNUMBER; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="cardnum" value="<?php echo $cardnum; ?>">
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_EXPIREDATE; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<table width='100%'><tr><td width='50%' align='center' valign='middle'><select name='expmonth'><option value=''><?php echo PFP_MONTH; ?></option>
<?php
echo "<option value='01'";
if (($_POST[validate] == "1") && ($expmonth == "1"))    {
echo " selected";    }
echo ">01</option><option value='02'";
if (($_POST[validate] == "1") && ($expmonth == "2"))    {
echo " selected";    }
echo ">02</option><option value='03'";
if (($_POST[validate] == "1") && ($expmonth == "3"))    {
echo " selected";    }
echo ">03</option><option value='04'";
if (($_POST[validate] == "1") && ($expmonth == "4"))    {
echo " selected";    }
echo ">04</option><option value='05'";
if (($_POST[validate] == "1") && ($expmonth == "5"))    {
echo " selected";    }
echo ">05</option><option value='06'";
if (($_POST[validate] == "1") && ($expmonth == "6"))    {
echo " selected";    }
echo ">06</option><option value='07'";
if (($_POST[validate] == "1") && ($expmonth == "7"))    {
echo " selected";    }
echo ">07</option><option value='08'";
if (($_POST[validate] == "1") && ($expmonth == "8"))    {
echo " selected";    }
echo ">08</option><option value='09'";
if (($_POST[validate] == "1") && ($expmonth == "9"))    {
echo " selected";    }
echo ">09</option><option value='10'";
if (($_POST[validate] == "1") && ($expmonth == "10"))    {
echo " selected";    }
echo ">10</option><option value='11'";
if (($_POST[validate] == "1") && ($expmonth == "11"))    {
echo " selected";    }
echo ">11</option><option value='12'";
if (($_POST[validate] == "1") && ($expmonth == "12"))    {
echo " selected";    }
echo ">12</option>";  ?>

</select></td><td width='50%' align='center' valign='middle'><select name='expyear'><option value=''><?php echo PFP_YEAR; ?></option><option value='04'
<?php
if (($_POST[validate] == "1") && ($expyear == "04"))    {
echo " selected";    }
echo ">2004</option><option value='05'";
if (($_POST[validate] == "1") && ($expyear == "05"))    {
echo " selected";    }
echo ">2005</option><option value='06'";
if (($_POST[validate] == "1") && ($expyear == "06"))    {
echo " selected";    }
echo ">2006</option><option value='07'";
if (($_POST[validate] == "1") && ($expyear == "07"))    {
echo " selected";    }
echo ">2007</option><option value='08'";
if (($_POST[validate] == "1") && ($expyear == "08"))    {
echo " selected";    }
echo ">2008</option><option value='09'";
if (($_POST[validate] == "1") && ($expyear == "09"))    {
echo " selected";    }
echo ">2009</option><option value='10'";
if (($_POST[validate] == "1") && ($expyear == "10"))    {
echo " selected";    }
echo ">2010</option><option value='11'"; 
if (($_POST[validate] == "1") && ($expyear == "11"))    {
echo " selected";    }
echo ">2011</option><option value='12'"; 
if (($_POST[validate] == "1") && ($expyear == "12"))    {
echo " selected";    }
echo ">2012</option>";  ?>
</select></td></tr></table>
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_CSC; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="securitycode" value="<?php echo $securitycode; ?>">
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_ADDRESS; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="ADDRESS" value="<?php echo $streetaddress; ?>">
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_ZIP; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="ZIP" value="<?php echo $zipcode; ?>">
   </TD>
  </TR><TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_NAME; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="NAME" value="<?php echo $customername; ?>">
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_EMAIL; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="EMAIL" value="<?php echo $email; ?>">
   </TD>
  </TR>
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<font size="4"><?php echo PFP_PHONE; ?>:</font>
   </TD>
   <TD WIDTH="50%" ALIGN="CENTER" VALIGN="MIDDLE">
<input size="20" name="PHONE" value="<?php echo $phone; ?>">
   </TD>
  </TR>
</TABLE><BR><BR>
<input type="submit" value="<?php echo PFP_BUTTON; ?>"><input type="hidden" name="validate" value="1"><BR><BR><BR>
</form></td></tr></table>

<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
