<?php
$imagecount = 1000;
if ($conn == "") { include("dbinfo.php");  }
$select = "select * from buttons where langid = '$l' && internalname = '$bn'";
$answer = mysql_query($select, $conn);
if (!$answer) { include("dbinfo.php");
$select = "select * from buttons where langid = '$l' && internalname = '$bn'";
$answer = mysql_query($select, $conn);   }
$newarray = mysql_fetch_array($answer);
$buttontype = $newarray[type];
$buttonid = $newarray[id] + $imagecount;
$buttonfilename = $newarray[filename];
$buttonrollfilename = $newarray[rollfilename];
$buttonobjecttag = $newarray[objecttag];
$buttonpagename = $newarray[pagename];
$buttonodescription = $newarray[description];
$checkforswf = substr_count($buttonfilename, ".swf");
if ($buttonrollfilename == "") { $buttonrollfilename = $buttonfilename; }

if (($checkforswf == "1") && ($buttontype == "2")) { 
echo $buttonobjecttag;    } 

else if (($buttonfilename != "") && ($buttontype == "2")) { 
echo "<A onMouseOver=\"changeimage('a$buttonid','lang/$l/2/$buttonrollfilename');\"
onMouseOut=\"changeimage('a$buttonid','lang/$l/2/$buttonfilename');\" HREF='$buttonpagename'><IMG name='a$buttonid' SRC='lang/$l/2/$buttonfilename' border='0' alt=\"$buttonodescription\"></A>";   }

else if ($buttontype > 0) { 
echo "<A onMouseOver=\"changeimage('a$buttonid','lang/$l/1/$bn" . "-roll.gif');\"
onMouseOut=\"changeimage('a$buttonid','lang/$l/1/$bn" . ".gif');\" HREF='$buttonpagename'><IMG name='a$buttonid' SRC='lang/$l/1/$bn" . ".gif' border='0' alt=\"$buttonodescription\"></A>";   }

else {
echo "<A HREF='$buttonpagename'>$fontstring" . "$buttonodescription</B></u></i></font></A>"; } 

?>
