<?php

define("MENU_ACCOUNT", "My Account");
define("MENU_VIEWCART", "View Cart");
define("MENU_CHECKOUT", "Checkout");
define("MENU_CATEGORIES", "Categories");
define("MENU_ORDERS", "View Orders");
define("MENU_LEGALNOTICES", "Legal Notices");
define("MENU_CONTACTUS", "Contact Us");
define("MENU_PRIVACY", "Privacy Policy");
define("MENU_SHIPPING", "Shipping and Refunds");
define("MENU_SEARCH", "Search");
define("MENU_TRANSLATE", "Translate Website<br>into ");
define("MENU_BESTSELLERS", "Best Sellers");
define("MENU_NEWESTPRODUCTS", "Newest Products");
define("MENU_REVIEWS", "Reviews");
define("ACCOUNTS_HEADER", "You Must Log In To Continue");
define("ACCOUNTS_RETURNINGCUSTOMER", "I am a returning customer");
define("ACCOUNTS_EMAIL", "E-Mail Address");
define("ACCOUNTS_PASSWORD", "Password");
define("ACCOUNTS_FORGOTPASS", "Forgot Password");
define("ACCOUNTS_NEWACCOUNTHEADER", "I am a new customer");
define("ACCOUNTS_NEWACCOUNTLINK", "Create a new account");
define("ACCOUNTS_LOGIN", "Log In");
define("ACCOUNTS_LOGOUT", "Log Out");
define("ACCOUNTS_UPDATEBUTTON", "Update Account");
define("ACCOUNTS_UPDATEHEADER", "Update Your Account");
define("NEWACCOUNT_FIRSTNAME", "First Name");
define("NEWACCOUNT_LASTNAME", "Last Name");
define("NEWACCOUNT_EMAIL", "E-Mail Address");
define("NEWACCOUNT_STREET", "Street Address");
define("NEWACCOUNT_ZIP", "Postal Code");
define("NEWACCOUNT_CITY", "City");

define("NEWACCOUNT_STATE", "State / Province");
define("NEWACCOUNT_COUNTRY", "Country");
define("NEWACCOUNT_PHONE", "Phone Number");
define("NEWACCOUNT_FAX", "Fax Number");
define("NEWACCOUNT_NEWSLETTER", "Newsletter");
define("NEWACCOUNT_PASSWORD", "Password");
define("NEWACCOUNT_PASSWORDCONFIRM", "Password Confirmation");
define("NEWACCOUNT_BUTTON", "Create New Account");
define("NEWACCOUNT_HEADER", "Create A Free Account");
define("NEWACCOUNT_EMAILINUSE", "Email Address Is Already In Use");
define("NEWACCOUNT_PASSNOMATCH", "Passwords Do Not Match");
define("NEWACCOUNT_ERROR", "All Fields Required");
define("CONTACT_HEADER", "Contact Us");
define("CONTACT_FORMHEADER", "Send Us Email");
define("CONTACT_NAME", "Name");
define("CONTACT_EMAIL", "Email Address");
define("CONTACT_PHONE", "Phone Number");
define("CONTACT_MESSAGE", "Your Message");
define("CONTACT_BUTTON", "Contact Us");
define("NEWSLETTER_SUBSCRIBED", "Subscribed");
define("NEWSLETTER_UNSUBSCRIBED", "Unsubscribed");
define("REQUIRED", "required");
define("MAXDOWNLOADS_OVERLIMIT", "Product Has Been Downloaded The Maximum Number Of Times");
define("OUTOFSTOCK_MESSAGE", "This product is currently out of stock. Please contact us to find out when it will become available again.");
define("OUTOFSTOCK_OVERLIMIT", "You have added a higher quantity for at least one product below. Quantities have been set to the maximum amount we have in stock.");
define("VIEWCART_EMPTY", "Your Cart Is Empty");
define("VIEWCART_PRODUCTNAME", "Product Name");
define("VIEWCART_QUANTITY", "Quantity");
define("VIEWCART_PRICE", "Price");
define("VIEWCART_REMOVE", "Remove");
define("VIEWCART_SUBTOTAL", "Sub Total");
define("VIEWCART_UPDATEBUTTON", "Update Your Cart");
define("VIEWCART_VIEWCART", "Your Shopping Cart");
define("CHECKOUT_HEADER", "Please Confirm Your Order");
define("CHECKOUT_ENTERPROMOCODE", "Enter Promotion Code");
define("CHECKOUT_SHIPADDRESS", "Shipping Address");
define("CHECKOUT_EDITADDRESS", "Change Address");
define("CHECKOUT_PAYMETHOD", "Payment Method");
define("CHECKOUT_SHIPMETHOD", "Shipping Method");
define("CHECKOUT_SUBTOTAL", "Order Sub Total");
define("CHECKOUT_EDITCART", "Edit Shopping Cart");
define("CHECKOUT_SHIPPINGHANDLING", "Shipping & Handling");
define("CHECKOUT_PICKUPSHIPPING", "Pick Up Shipping Option");
define("CHECKOUT_TAX", "Tax");
define("CHECKOUT_ORDERTOTAL", "Order Total");
define("CHECKOUT_ADDCOMMENTS", "Add Comments About Your Order");
define("CHECKOUT_GOTOPAYMENTBUTTON", "Go To Secure Payment Page");
define("CHECKOUT_UPDATECARTBUTTON", "Update Cart");
define("CHECKOUT_AFTERPROMO", "After Promotion Discount");
define("REVIEWS_HEADER", "Please select a product to see it's reviews");
define("REVIEWS_PRODNAME", "Product Name");
define("REVIEWS_SELECTPROD", "Select A Product");
define("REVIEWS_READBUTTON", "Read Reviews");
define("REVIEWS_NOREVIEWS", "There are currently no reviews on this product.");
define("REVIEWS_WRITE", "Write A Review");
define("REVIEWS_WRITECAPTION", "Write a review for");
define("REVIEWS_WRITEHEADER", "Product Reviews");
define("REVIEWS_PRODRATING", "Product Rating");
define("REVIEWS_WRITEBUTTON", "Submit Review");
define("REVIEWS_READLINK", "See Product Reviews");
define("BACKBUTTON", "Go Back");
define("REVIEWS_STARRATING", "Star(s)");
define("REVIEWS_OUTOFSTARS", "( Out Of 5 Stars )");
define("REVIEWS_READREVIEWCUSTNAME", "Customer Name");
define("REVIEWS_READREVIEWDATE", "Date Created");
define("REVIEWS_READREVIEWRATING", "Rating");
define("REVIEWS_READREVIEWCAPTION", "Review");
define("BESTSELLERS_HEADER", "Best Selling Products");
define("NEWPRODUCTS_HEADER", "Newest Products");
define("SEARCH_RESULTS", "Search Results");
define("SEARCH_MATCHINGRESULTS", "Number of matching results");
define("SEARCH_HEADER", "Search Our Website");
define("SEARCH_KEYWORDS", "Search Keywords");
define("SEARCH_CATEGORIES", "Search In");
define("SEARCH_MANUFACTURES", "Manufactures");
define("SEARCH_PRICERANGE", "Price Range");
define("SEARCH_BUTTON", "Search");
define("SEARCH_ALLCATEGORIES", "All Categories");
define("SEARCH_ALLMANUFACTURES", "Show All");
define("SEARCH_NOMAX", "No Maximum");
define("SEARCH_NOMIN", "No Minimum");



define("CHANGESHIPADDRESS_ERROR", "Warning, All Fields Required");
define("CHANGESHIPADDRESS_HEADER", "Change Your Shipping Address");
define("CHANGESHIPADDRESS_ADDRESS", "Street Address");
define("CHANGESHIPADDRESS_CITY", "City");
define("CHANGESHIPADDRESS_STATE", "State/Province");
define("CHANGESHIPADDRESS_ZIP", "Zip Code");
define("CHANGESHIPADDRESS_COUNTRY", "Country");
define("CHANGESHIPADDRESS_BUTTON", "Update New Shipping Address");

// Verisign's Payflow Pro form
define("PFP_HEADER", "Make A Credit Card Payment");
define("PFP_AMOUNT", "Amount Of Payment");
define("PFP_CARDNUMBER", "Card Number");
define("PFP_EXPIREDATE", "Expiration Date");
define("PFP_MONTH", "Month");
define("PFP_YEAR", "Year");
define("PFP_CSC", "Security Code");
define("PFP_ADDRESS", "Street Address");
define("PFP_ZIP", "Zip Code");
define("PFP_NAME", "Customer Name");
define("PFP_EMAIL", "Email Address");
define("PFP_PHONE", "Phone Number");
define("PFP_BUTTON", "Make Payment");
define("PFP_ERROR", "Error, Please Correct Your Information");
define("PFP_CARDDECLINE", "Credit Card Denied, Please Check Your Information");


// getproduct.php
define("PROD_SPECIALS", "Special Price");
define("PROD_ADDTOCARTBUTTON", "Add To Cart");
define("PROD_CATEGORY", "Category");
define("PROD_MANU", "Manufacture");
define("PROD_MODEL", "Model Number");
define("PROD_WEBPAGE", "View Product's Webpage");



?>
