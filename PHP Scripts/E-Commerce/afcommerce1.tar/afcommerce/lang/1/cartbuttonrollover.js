/*
  File Name: cartbuttonrollover.js, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

function changeimage(imagenum,newfilename)  {
document.images[imagenum].src=newfilename;    }

// main link images here

Image3001 = new Image();
Image3001.src = "/lang/1/1/home.gif";
Image4001 = new Image();
Image4001.src = "/lang/1/1/home-roll.gif";

Image3002 = new Image();
Image3002.src = "/lang/1/1/aboutus.gif";
Image4002 = new Image();
Image4002.src = "/lang/1/1/aboutus-roll.gif";

Image3003 = new Image();
Image3003.src = "/lang/1/1/resources.gif";
Image4003 = new Image();
Image4003.src = "/lang/1/1/resources-roll.gif";

Image3004 = new Image();
Image3004.src = "/lang/1/1/contactus.gif";
Image4004 = new Image();
Image4004.src = "/lang/1/1/contactus-roll.gif";

// shopping cart images below

Image1001 = new Image();
Image1001.src = "/lang/1/1/button_viewcart.gif";
Image2001 = new Image();
Image2001.src = "/lang/1/1/button_viewcart-roll.gif";

Image1002 = new Image();
Image1002.src = "/lang/1/1/button_checkout.gif";
Image2002 = new Image();
Image2002.src = "/lang/1/1/button_checkout-roll.gif";

Image1003 = new Image();
Image1003.src = "/lang/1/1/button_myaccount.gif";
Image2003 = new Image();
Image2003.src = "/lang/1/1/button_myaccount-roll.gif";

Image1004 = new Image();
Image1004.src = "/lang/1/1/button_vieworders.gif";
Image2004 = new Image();
Image2004.src = "/lang/1/1/button_vieworders-roll.gif";

Image1005 = new Image();
Image1005.src = "/lang/1/1/button_search.gif";
Image2005 = new Image();
Image2005.src = "/lang/1/1/button_search-roll.gif";

Image1006 = new Image();
Image1006.src = "/lang/1/1/button_bestsellers.gif";
Image2006 = new Image();
Image2006.src = "/lang/1/1/button_bestsellers-roll.gif";

Image1007 = new Image();
Image1007.src = "/lang/1/1/button_whatsnew.gif";
Image2007 = new Image();
Image2007.src = "/lang/1/1/button_whatsnew-roll.gif";

Image1008 = new Image();
Image1008.src = "/lang/1/1/button_reviews.gif";
Image2008 = new Image();
Image2008.src = "/lang/1/1/button_reviews-roll.gif";

Image1009 = new Image();
Image1009.src = "/lang/1/1/button_privacy.gif";
Image2009 = new Image();
Image2009.src = "/lang/1/1/button_privacy-roll.gif";

Image1010 = new Image();
Image1010.src = "/lang/1/1/button_shipandrefund.gif";
Image2010 = new Image();
Image2010.src = "/lang/1/1/button_shipandrefund-roll.gif";