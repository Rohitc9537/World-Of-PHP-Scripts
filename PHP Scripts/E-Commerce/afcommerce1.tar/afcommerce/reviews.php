<?php
/*
  File Name: reviews.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$langid = $_GET['langid'];
$pid = $_GET['pid'];
$mode = $_GET['mode'];
include("dbinfo.php");
if (($pid == "") && ($_POST[pid] == ""))  {
// show all reviews as links to read
include("carttop.php");
echo "<CENTER><table class='maintext' width='90%'><tr><td width='100%' align='center' valign='top'><BR><form action='reviews.php?mode=r' method='post'><font size='4'>" . REVIEWS_HEADER . "<BR><BR>" . REVIEWS_PRODNAME . ":</font><BR><BR><BR><select name='pid'><option value=''>" . REVIEWS_SELECTPROD . "</option>";
$select = "select * from products where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$prodid = $newarray[prodid];
$select2 = "select * from product_descript where prodid = '$prodid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];
echo "<option value='$prodid'>$prodname</option>";    }

echo "</select></td></tr></table><BR><BR><BR><input type='image' src='lang/$langid/1/button_readreview.gif'><BR><BR><BR></td></tr></table></td></tr></table>";

require ('footer.php');

exit;     }
if ($pid == "")   {   $pid = $_POST[pid];   }
if ($mode == "w")   {
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];
if (($memberid == "") || ($memberid == "0") || ($id == ""))  {
header("location:account.php");
exit;   }
include("carttop.php");

$select = "select * from products where prodid = '$pid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$prodimage = $newarray[prodimage];

$select2 = "select * from product_descript where prodid = '$pid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];
 
echo "<CENTER><H2>" . REVIEWS_WRITEHEADER . "<HR></H2><table class='maintext' width='90%'><tr><td width='100%' align='center' valign='top'><form action='writereview.php' method='post'><input type='hidden' name='memberid' value='$memberid'><input type='hidden' name='langid' value='$langid'><input type='hidden' name='prodid' value='$pid'><A class='login' HREF='javascript:history.go(-1)'><font size='4'>" . BACKBUTTON . "</font></A><BR><BR><font size='5'>" . REVIEWS_WRITECAPTION . ":</font><BR><BR><font size='5'>$prodname</font><BR><BR><BR><font size='4'>" . REVIEWS_PRODRATING . ": </font><select name='rating'><option value='5'> 5 </option><option value='4'> 4 </option><option value='3'> 3 </option><option value='2'> 2 </option><option value='1'> 1 </option></select> " . REVIEWS_STARRATING . "<BR><BR><BR><textarea cols='40' rows='7' name='review'></textarea><BR><BR><BR><input type='image' src='lang/$langid/1/button_writereview.gif'><BR><BR><BR></form></td></tr></table></td></tr></table>";
}
else if ($mode == "r")    {
include("carttop.php");
$select = "select * from products where prodid = '$pid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$prodimage = $newarray[prodimage];
$select2 = "select * from product_descript where prodid = '$pid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];

echo "<CENTER><A class='login' HREF='javascript:history.go(-1)'><font size='4'>" . BACKBUTTON . "</font></A><BR><BR><table width='90%' class='maintext'><tr><td width='70%' align='center' valign='middle'><font size='5'>$prodname</font></td>";
if ($prodimage != "")   {
include("thumbnailer-prod.php");
echo "<td width='30%' align='center' valign='middle'><img src='images/$prodimage' height='$height'></td>";   }

echo "</tr></table><BR><BR>";
$select = "select * from reviews where prodid = '$pid' && langid = '$langid' order by dateadded desc limit 0,8";
$answer = mysql_query($select, $conn);
$count = 0;
while ($newarray = mysql_fetch_array($answer))   {
$count = $count + 1;
$review = $newarray[review];
$review = str_replace("
", "<br>", $review);
$memberid = $newarray[memberid];  
$rating = $newarray[rating];
$temp = "";
for ($i = 0; $i < $rating; $i++)   {   $temp .= "* ";    }
$rating = $temp;
$dateadded = $newarray[dateadded];
$datearray = getdate ($dateadded);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$dateadded = "$month / $day / $year";
$select2 = "select * from members where memberid = '$memberid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$firstname = $newarray2[firstname];
$lastname = $newarray2[lastname];

echo "<CENTER><table class='maintext' width='90%' cellpadding='7'><tr><td width='50%' align='left' valign='top'>" . REVIEWS_READREVIEWCUSTNAME . ":</td><td width='50%' align='left' valign='top'>$firstname $lastname</td></tr><tr><td width='50%' align='left' valign='top'>" . REVIEWS_READREVIEWDATE . ":</td><td width='50%' align='left' valign='top'>$dateadded</td></tr><tr><td width='50%' align='left' valign='top'>" . REVIEWS_READREVIEWRATING . ":</td><td width='50%' align='left' valign='top'><B>$rating</B> " . REVIEWS_OUTOFSTARS . "</td></tr></table><H3>" . REVIEWS_READREVIEWCAPTION . ":<HR></H3><div class='maintext'>$review</div><BR><BR><BR><BR>";             }

if ($count == "0")   {
echo "<font size='4'>" . REVIEWS_NOREVIEWS . "</font><BR><BR><BR>";    }   
echo "<a class='login' href='reviews.php?mode=w&pid=$pid'><img src='lang/$langid/1/button_writereview.gif' border='0'></a><BR><BR><BR><BR></td></tr></table>";    } 
 
else   {
// if no mode selected
include("carttop.php");
echo "<CENTER><BR><BR><H2>Error, script mode not selected</H2>";
}

?><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>