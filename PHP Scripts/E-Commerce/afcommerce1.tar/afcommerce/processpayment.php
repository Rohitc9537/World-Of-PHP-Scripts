<?php
/*
  File Name: processpayment.php, v 1.1     
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$success = 0;
include("dbinfo.php");
$currentdate = time();
$paymethod = $_GET['paymethod'];

switch($paymethod)    {
case "vlink":
include("mods/payment/verisignpfl_payment.php");
$status = "Pending";
break;
case "vpro":
include("mods/payment/verisignpfp_payment.php");
$status = "Pending";
break;
case "paypal":
include("mods/payment/paypal_payment.php");
$status = "Pending";
break;
case "checkmoneyorder":
include("mods/payment/checkmoneyorder_payment.php");
$status = "Waiting For Payment";
break;
}

if ($success == "1")   {
$select = "select * from config where varname = 'quantityfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$quantityfeature = $newarray['varvalue'];

$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$totalprice = $newarray['totalprice'];
$totalprice = number_format ($totalprice, 2);
$memberid = $newarray['memberid'];
$promocode = $newarray['promocode'];
$select5 = "select * from promos where promocode = '$promocode'";
$answer5 = mysql_query($select5, $conn);
$newarray5 = mysql_fetch_array($answer5);
$promodiscount = $newarray5['discount'];

$taxcost = $newarray['taxcost'];
$comments = $newarray['comments'];
$shipcost = $newarray['shipcost'];
$newshipaddress = $newarray['newshipaddress'];
$select3 = "select * from members where memberid = '$memberid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$email = $newarray3['email'];
if (($newshipaddress == "") || ($newshipaddress == "0"))   {
$address = $newarray3['address'];
$city = $newarray3['city'];
$state = $newarray3['state'];
$select5 = "select * from zones where zone_id = '$state'";
$answer5 = mysql_query($select5, $conn);
$newarray5 = mysql_fetch_array($answer5);
$formatstate = $newarray5['zone_name']; 

$zipcode = $newarray3['zipcode'];
$country = $newarray3['country'];
$newshipaddress = "$address<BR> $city, $formatstate $zipcode";
$newshipaddress = ucwords ($newshipaddress);
}

$receipt = "";
$select2 = "select * from basket_products where basketid = '$id'";
$answer2 = mysql_query($select2, $conn);
$productcount = 0;
while ($newarray2 = mysql_fetch_array($answer2))    {
$quantity = $newarray2['quantity'];
$price = $newarray2['price'];
$prodname = $newarray2['prodname'];
$tempprodid = $newarray2['prodid'];
$receipt .= "<li>$quantity $prodname $ $price each</li><BR><BR>"; 
$prodidarray[$productcount] = $tempprodid;
$select4 = "select * from products where prodid = '$tempprodid'";
$answer4 = mysql_query($select4, $conn);
$newarray4 = mysql_fetch_array($answer4);
$totalsold = $newarray4['totalsold'];  
$totalsold = $totalsold + 1;

if ($quantityfeature == "1")   {
$prodquantity = $newarray4['prodquantity'];   
$prodquantity = $prodquantity - $quantity;
$update = "update products set prodquantity = '$prodquantity' where prodid = '$tempprodid'";
mysql_query($update, $conn);      }

$update = "update products set totalsold = '$totalsold' where prodid = '$tempprodid'";
mysql_query($update, $conn);   
$productcount = $productcount + 1;    }

$paymethod = ucwords ($paymethod);

$update = "update promos set status = '0' where promocode = \"$promocode\"";
mysql_query($update, $conn); 

$select = "select * from config where varname = 'storename'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storename = $newarray['varvalue'];
$select = "select * from config where varname = 'storeemail'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeemail = $newarray['varvalue'];
$select = "select * from config where varname = 'storephone'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storephone = $newarray['varvalue'];
$select = "select * from config where varname = 'domainname'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$domainname = $newarray['varvalue'];

// insert into orders table
$insertrow = "insert into orders values ('', '$memberid', '$totalprice', \"$receipt\", '$status', \"$newshipaddress\", \"$description\", \"$confirmcode\", '$taxcost', '', '$shipcost', \"$promocode\", '$currentdate', \"$comments\", '0', '0', '0')";
if (mysql_query($insertrow, $conn)) {

// get orderid
$highnum = 0;
$select = "select * from orders";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$tempid = $newarray['id'];      
if ($highnum < $tempid)  {
$highnum = $tempid;    }  }
$orderid = $highnum;

// if there are products to download, add rows into downloads table
$select = "select * from config where varname = 'maxdownloads'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$maxdownloads = $newarray['varvalue'];
reset ($prodidarray);
while (list($key, $val) = each($prodidarray))   {  
$select4 = "select * from products where prodid = '$val'";
$answer4 = mysql_query($select4, $conn);
$newarray4 = mysql_fetch_array($answer4);
$download = $newarray4['download']; 
if (($download != "") && ($download != "0"))  {
$insertrow = "insert into order_downloads values ('', '$orderid', '$maxdownloads', '', '$val', '$download')";
mysql_query($insertrow, $conn);   }   }    }

else  {
// this section is used for handling errors with inserting a new row in the 
// orders table. There must be a big problem if we get inside this else statement
// In my expirence with other carts, when an error like this occurs, the store
// owner has no way of knowing what the customer just paid for. So we'll email 
// the receipt to the store owner so they can handle it.

$msg = "Hello, there has been an error attempting to create a new row in your orders database table inside your shopping cart. This may have been caused by many different reasons. Here is a copy of the receipt from the order so you can still be able to process the order. The receipt is shown as html.

" . $receipt;
$subject = "Error creating order in your shopping cart database";
$mailheaders = "From: $storeemail";
mail($storeemail, $subject, $msg, $mailheaders);	} // ends database error

// send confirmation emails
$msg = "
This email is an Order Confirmation From $storename on $domainname. Below is an html receipt of the order :

" . $receipt;
$subject = "Order Confirmation From $storename";
$mailheaders = "From: $storeemail";
mail($storeemail, $subject, $msg, $mailheaders);

$msg = "Thank you for your order. 

We have received your payment for $ $totalprice.

You can see updated information, or a receipt of your purchase(s) at:

http://$domainname/orderstatus.php

You can contact us through our website if you have any questions.
";
$subject = "Receipt of Payment from $storename";
$mailheaders = "From: $storeemail";
mail($email, $subject, $msg, $mailheaders);	

// empty basket
$delete = "delete from basket_products where basketid = '$id'";
mysql_query($delete, $conn);

// the below line is for the Amazing Flash Tracking System
// if you don't have our tracking system installed, this line does nothing
if (file_exists("addtrack.php")) { include("addtrack.php");
addtrack ("sale", $memberid, $totalprice, $orderid); }

// redirect to confirmation page
header("location:orderstatus.php?orderid=$orderid");
}
else   {
// redirect to error page
include("carttop.php"); 
echo "<BR><BR><H2>Payment Error</H2><BR><BR><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A><BR><BR><BR>";
}

?>
