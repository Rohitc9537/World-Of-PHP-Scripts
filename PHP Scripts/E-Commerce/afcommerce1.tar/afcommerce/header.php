<?php
/*
  File Name: header.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
if ($id == "")    {
$select3 = "select * from config where varname = 'defaultlang'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[varvalue];    }
else   {
$select3 = "select * from basket where id = '$id'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[defaultlang];    }
if ($langid == "") { $langid = 1;   }

?>
<HTML><HEAD><TITLE>AFCommerce Default Installation</TITLE><META NAME="description" content=""><META NAME="keywords" content=""><link rel='stylesheet' type='text/css' href='style.css'><script src='lang/<?php echo $langid; ?>/cartbuttonrollover.js'></script></HEAD><style type='text/css'><!--
body {  margin: 0px  0px; padding: 0px  0px} 
a:link { color: #000044; text-decoration: none}
a:visited { color: #000044; text-decoration: none}
a:active { color: #000044; text-decoration: underline}
a:hover { color: #FF0000; text-decoration: underline} 
--></style><BODY bgcolor='#ffffff' TEXT='#000000'><CENTER><TABLE WIDTH='100%'><TR ALIGN='center' VALIGN='TOP'><TD WIDTH='100%' ALIGN='center' VALIGN='TOP'>