<?php
/*
  File Name: toplayout.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

?>
</TD></TR></TABLE>

<!-- The following links are optional. You may delete them or change them any way you like. The menu appears under the banner by default unless you move them. -->
<BR><TABLE bgcolor='#ffffff' WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'><TR><TD WIDTH='25%' ALIGN='CENTER' VALIGN='MIDDLE'><A onMouseOver="changeimage('a3001','lang/<?php echo $langid; ?>/1/home-roll.gif');"
onMouseOut="changeimage('a3001','lang/<?php echo $langid; ?>/1/home.gif');" HREF='index.php'><IMG name='a3001' SRC='lang/<?php echo $langid; ?>/1/home.gif' border='0' alt='Home'></A></TD><TD WIDTH='25%' ALIGN='CENTER' VALIGN='MIDDLE'><A onMouseOver="changeimage('a3002','lang/<?php echo $langid; ?>/1/aboutus-roll.gif');"
onMouseOut="changeimage('a3002','lang/<?php echo $langid; ?>/1/aboutus.gif');" HREF='about.php'><IMG name='a3002' SRC='lang/<?php echo $langid; ?>/1/aboutus.gif' border='0' alt='About Us'></A></TD><TD WIDTH='25%' ALIGN='CENTER' VALIGN='MIDDLE'><A onMouseOver="changeimage('a3003','lang/<?php echo $langid; ?>/1/resources-roll.gif');"
onMouseOut="changeimage('a3003','lang/<?php echo $langid; ?>/1/resources.gif');" HREF='resources.php'><IMG name='a3003' SRC='lang/<?php echo $langid; ?>/1/resources.gif' border='0' alt='Resources'></A></TD><TD WIDTH='25%' ALIGN='CENTER' VALIGN='MIDDLE'><A onMouseOver="changeimage('a3004','lang/<?php echo $langid; ?>/1/contactus-roll.gif');"
onMouseOut="changeimage('a3004','lang/<?php echo $langid; ?>/1/contactus.gif');" HREF='contact.php'><IMG name='a3004' SRC='lang/<?php echo $langid; ?>/1/contactus.gif' border='0' alt='Contact Us'></A></TD></tr></TABLE>

<!-- Left hand column to your website begins here, this is where your categories and shopping links begin. Also, the free Live Support Solution provided by AmazingFlash.com and AFLiveSupport.com is listed below. Follow the instructions below to setup the Live Support Software with your website. All you need to do is register a free account on AFLiveSupport.com and add your account number below. As soon as you create and activate your account with the Live Support software, you will need to add your account number below, and you will instantly have Live Support on your website. Another great feature of using AFCommerce ! -->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='*' ALIGN='left' VALIGN='TOP'><TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><?php $fontstring = "<font size='3' face='Arial'><b>";
$l = "$langid";
 ?><TD class='categories' WIDTH='20%' ALIGN='left' VALIGN='TOP'><CENTER><BR>
<!-- Live Support Code Begins Here -->
<?php 
// replace the zero below this line with your Live Support account number
$livesupportaccountid = 0;
?>

<style type="text/css">.mylswhosonline {font: color: black;}</style><script language="JavaScript" src="http://myfreelivesupport.com/livesupport.php?accid=<?php echo $livesupportaccountid; ?>"></script>

<?php
// shopping cart links begin here
$bn = 'button_viewcart';
include('lang/printcartlink.php'); ?><BR><BR><?php
$bn = 'button_checkout';
include('lang/printcartlink.php'); ?><BR><BR><?php
$bn = 'button_myaccount';
include('lang/printcartlink.php'); ?><BR><BR><?php
$bn = 'button_vieworders';
include('lang/printcartlink.php'); ?><BR><BR><font size='4'><HR><?php echo MENU_CATEGORIES; ?><HR></B></u></i></font></CENTER><?php require ('categories.php');
require ('translatelist.php'); ?><BR><HR><CENTER><?php
$bn = 'button_search';
include('lang/printcartlink.php'); ?><BR><HR>
<?php if ($bestsellers == '1') { ?>
<?php
$bn = 'button_bestsellers';
include('lang/printcartlink.php'); ?><BR><HR>
<?php } ?>
<?php if ($whatsnew == '1') { ?>
<?php
$bn = 'button_whatsnew';
include('lang/printcartlink.php'); ?><BR><HR>
<?php } ?>
<?php if ($productreviews == '1') { ?>
<?php
$bn = 'button_reviews';
include('lang/printcartlink.php'); ?><HR>
<?php } ?><?php if ($displaylegalnotices == '1') { ?>
<font size='4'><BR><?php echo MENU_LEGALNOTICES; ?><HR></font>
<?php } ?><?php if ($displayprivacypolicy == '1') { ?>
<?php 
$bn = 'button_privacy';
include('lang/printcartlink.php'); ?><BR><BR>
<?php } ?><?php if ($displayshipandrefunds == '1') { ?>
<?php 
$bn = 'button_shipandrefund';
include('lang/printcartlink.php'); ?><BR>
<?php } ?></CENTER><BR>

</TD><TD WIDTH='*' ALIGN='left' VALIGN='TOP'><BR>