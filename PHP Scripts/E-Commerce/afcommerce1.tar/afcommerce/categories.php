<?php
/*
  File Name: categories.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from categories where level = '0'";
$answer = mysql_query($select, $conn);
$numsubcats = mysql_num_rows($answer);
while ($newarray = mysql_fetch_array($answer))    {
$i = $i + 1;
$catidarray[$i] = $newarray['catid'];
$select3 = "select * from categories_descript where catid = '$catidarray[$i]' && langid = '$langid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$catnamearray[$i] = $newarray3['catname'];    }

@array_multisort($catnamearray, SORT_ASC, SORT_STRING, $catidarray);

for ($i = 0; $i < $numsubcats; $i++) {

$catid = $catidarray[$i];
$catname = $catnamearray[$i];

echo "<BR><a href='getcategory.php?cat=$catid'><font size='3' face='arial'><b>$catname</b></font></a><BR>";

}

?>