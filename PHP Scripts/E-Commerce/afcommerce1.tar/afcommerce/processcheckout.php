<?php
/*
  File Name: processcheckout.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$taxcost = $_POST['tax'];
$shipcost = $_POST['shipcost'];

$shippingmodule = $_POST['shippingmodule'];
if ($shippingmodule == "pickup") {
$shipcost = $_POST['pickupshippingcost'];  }

$paymethod = $_POST['paymethod'];
$comments = $_POST['comments'];
$totalprice = $_POST['totalprice'];
$totalpriceformatted = $_POST['totalpriceformatted'];
$totalpriceformatted = str_replace(",", "", $totalpriceformatted);
$shipcode = $_POST['shipcode'];
$shiparray = explode (",", $shipcode);
$address = $shiparray[0];
$city = $shiparray[1];
$state = $shiparray[2];
$zipcode = $shiparray[3];
$country = $shiparray[4];

include("dbinfo.php");
$update = "update basket set paymethod = \"$paymethod\", comments = \"$comments\", totalprice = '$totalprice', taxcost = '$taxcost', shipcost = '$shipcost' where id = '$id'";
mysql_query($update, $conn);
$select = "select * from config where varname = 'domainname'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$domainname = $newarray['varvalue'];

$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$memberid = $newarray['memberid'];

$select = "select * from members where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$firstname = $newarray['firstname'];
$lastname = $newarray['lastname'];
$fullname = "$firstname $lastname";
$email = $newarray['email'];
$phone = $newarray['phone'];

$select = "select * from paymethod where type = \"$paymethod\"";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$info1 = $newarray['info1'];
$info2 = $newarray['info2'];
$info3 = $newarray['info3'];
$info4 = $newarray['info4'];

switch ($paymethod)  {

case "Verisign-Payflow Pro":
include("mods/payment/verisignpfp_checkout.php");
break;
case "Paypal":
include("mods/payment/paypal_checkout.php");
break;
case "Verisign-Payflow Link":
include("mods/payment/verisignpfl_checkout.php");
break;
case "Check-Money-Order":
include("mods/payment/checkmoneyorder_checkout.php");
break;
case "":
include("carttop.php");
echo "<BR><BR><H2>You Forgot To Select A Payment Method !</H2><BR><BR><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A>";
break;     }
?>