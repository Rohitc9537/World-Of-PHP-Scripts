<?php
/*
  File Name: logout.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$update = "update basket set memberid = '' where id = '$id'";
mysql_query($update, $conn);
header("location:account.php");
?>
