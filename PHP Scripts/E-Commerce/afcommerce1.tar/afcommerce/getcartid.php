<?php
/*
  File Name: getcartid.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$currenttime = time();
$olddate = $currenttime - (86400 * 1);
// clean up database
$delete = "delete from ipid where date < '$olddate'";
mysql_query($delete, $conn);

$select = "select * from basket where date < '$olddate'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) != 0) {
while ($newarray = @mysql_fetch_array($answer)) {
$tempid = $newarray[id];
$delete = "delete from basket_products where basketid = '$tempid'";
mysql_query($delete, $conn);   } // end while

$delete = "delete from basket where date < '$olddate'";
mysql_query($delete, $conn);
} // ends mysql_num_rows != 0

$ip = $REMOTE_ADDR;
$select = "select * from ipid where ip = '$ip'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) < 1) {
$insert = "insert into ipid values ('', '$ip', '', '$currenttime')";
mysql_query($insert, $conn);

} // ends insert

else { $newarray = @mysql_fetch_array($answer);
$id = $newarray[basketid];   }
if ($id == "0") { $id = ""; }   ?>