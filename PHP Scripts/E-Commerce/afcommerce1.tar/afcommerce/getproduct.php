<?php
/*
  File Name: getproduct.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$pid = $_GET['pid'];
$langid = $_GET['langid'];
include("carttop.php");
include("dbinfo.php");

$select = "select * from products where prodid = '$pid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$prodimage = $newarray[prodimage];
$prodquantity = $newarray[prodquantity];
$modelnum = $newarray[modelnum];
$price = $newarray[price];
$price = number_format ($price, 2);
$catid = $newarray[catid];
$manid = $newarray[manid];
$select = "select * from product_descript where prodid = '$pid' && langid = '$langid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$webpage = $newarray[webpage];
$prodcaption = $newarray[prodcaption];
$proddescript = $newarray[proddescript];  
$prodname = $newarray[prodname];

$select = "select * from categories_descript where catid = '$catid' && langid = '$langid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$maincatname = $newarray[catname];
$select = "select * from manufactures where manid = '$manid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$manname = $newarray[manname];

$select = "select * from specials where prodid = '$pid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$newprice = $newarray[newprice];

echo "<CENTER><script language='javascript'>

function enlarge () {  window.open('images/$prodimage','','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no,top=20,left=20');
}
</script><CENTER><A class='login' HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A><BR><BR><table class='maintext' width='90%'><tr><td width='65%' align='center' valign='top'><BR><font size='5'>$prodname</font>";

if ($prodcaption != "")   {
echo "<BR><HR><BR><font size='4'>$prodcaption</font>";    }

if ($newprice != "")    {
echo "<BR><HR><BR><font size='5'><s>$ $price</s></font><BR><BR><font size='4'>" . PROD_SPECIALS . ":</font><BR><font size='5'>$ $newprice</font></td>";   }

else   {
echo "<BR><HR><BR><font size='5'>$ $price</font>";   }

if (($prodquantity < 1) && ($quantityfeature == "1"))  {
echo "<BR><BR><font size='4' face='arial'>" . OUTOFSTOCK_MESSAGE . "</font><BR><BR>";   }

echo "</td><td width='35%' align='center' valign='top'><BR><form action='addtocart.php' method='post'><input type='hidden' name='prodid' value='$pid'><input type='hidden' name='newprice' value='$newprice'><input type='image' src='lang/$langid/1/button_addtocart.gif'></form><BR><BR>";

if ($prodimage != "")   {
include("thumbnailer-prod.php");
echo "<a href='javascript:enlarge ();'><IMG SRC='images/$prodimage' border='0' height='$height'></a>";  }

echo "</td></tr></table><BR><BR><table class='maintext' width='75%'><tr><td width='100%' align='left' valign='middle'><font size='3' face='arial'><B>$proddescript</B></font></td></tr></table><BR><BR><HR><BR><table class='maintext' width='90%'><tr>";

if ($catname != "")   {
echo "<td width='50%' align='center' valign='middle'><font size='3'><B>" . PROD_CATEGORY . ":</B></font><BR><BR><BR></td><td width='50%' align='center' valign='middle'><font size='3'><B>$maincatname</B></font><BR><BR><BR></td></tr><tr>";   }

if (($manname != "") && ($displaymanufactures == "1"))   {
echo "<td width='50%' align='center' valign='middle'><font size='3'><B>" . PROD_MANU . ":</B></font><BR><BR><BR></td><td width='50%' align='center' valign='middle'><font size='3'><B>$manname</B></font><BR><BR><BR></td></tr></table>";   }

echo "<table class='maintext' width='90%'><tr>";

if ($modelnum != "")   {
echo "<td width='50%' align='center' valign='middle'><font size='2'><B>" . PROD_MODEL . ":<BR>$modelnum</B></font></td>";   }
if ($webpage != "")   {
echo "<td width='50%' align='center' valign='middle'><a class='login' href='$webpage' target='_blank'><font size='2'><div class='login'><B>" . PROD_WEBPAGE . "</B></font></div></a></td>";   }
echo "</tr></table><BR><BR>";
if ($productreviews == "1")  {
echo "<table width='90%'><tr><td width='50%' align='center' valign='middle'><a class='login' href='reviews.php?mode=r&pid=$pid'><img border='0' src='lang/$langid/1/button_readreview.gif'></a></td><td width='50%' align='center' valign='middle'><a class='login' href='reviews.php?mode=w&pid=$pid'><img border='0' src='lang/$langid/1/button_writereview.gif'></a></td></tr></table><BR><BR><BR>"; }

?><?php echo "</td></tr></table></td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
