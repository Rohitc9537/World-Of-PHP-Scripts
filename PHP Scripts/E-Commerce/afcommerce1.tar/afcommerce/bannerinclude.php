<?php
/*
  File Name: bannerinclude.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/
?>
<IMG SRC="/images/mainsite/mainlogo.gif" ALT="Amazing Flash Commerce Solutions - AFCommerce.com">