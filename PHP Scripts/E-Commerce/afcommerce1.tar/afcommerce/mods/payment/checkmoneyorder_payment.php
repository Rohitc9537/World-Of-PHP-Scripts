<?php

$select = "select * from paymethod where id = '4'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$description = $newarray['description'];
if (($id != "0") && ($id != ""))    {
$success = 1;    
$confirmcode = "Manual Payment Method";    }

?>
