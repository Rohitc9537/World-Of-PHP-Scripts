<?php

$select = "select * from paymethod where id = '1'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$description = $newarray[description];
if (($id != "0") && ($id != ""))    {
$success = 1;    
$confirmcode = "Successful Paypal Transaction";    }

?>
