<?php

$select = "select * from paymethod where id = '2'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$description = $newarray[description];
if ($confirmcode != "")   {
$success = 1;     }

?>
