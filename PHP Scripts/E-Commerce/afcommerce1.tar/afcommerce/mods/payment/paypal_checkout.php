<?php

echo "<body><form name='form1' action='https://www.paypal.com/cgi-bin/webscr' method='post'><input type='hidden' name='cmd' value='_xclick'><input type='hidden' name='business' value='$info1'><input type='hidden' name='item_name' value='Shopping Cart Checkout'><input type='hidden' name='amount' value='$totalpriceformatted'><input type='hidden' name='no_shipping' value='1'><input type='hidden' name='return' value='http://$domainname/processpayment.php?paymethod=Paypal'><input type='hidden' name='cancel_return' value='http://$domainname/checkout.php'><input type='hidden' name='no_note' value='1'><input type='hidden' name='bn' value='AmazingFlash.AFCommerce'><input type='hidden' name='currency_code' value='USD'><script language='javascript'>document.form1.submit();</script></form>";

?>
