<?php

$select = "select * from paymethod where id = '3'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$description = $newarray[description];
// get silent post data, see if transaction was successful 
$id = $_POST[CUSTID];
$confirmcode = $_POST[PNREF];
$result = $_POST[RESULT];
if ($result == "0")   {
$success = 1;      }

?>
