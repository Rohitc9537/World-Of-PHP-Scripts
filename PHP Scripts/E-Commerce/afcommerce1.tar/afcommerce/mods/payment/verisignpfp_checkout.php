<?php

echo "<body><form name='form1' action='payform.php' method='post'><input type='hidden' name='AMOUNT' value='$totalprice'><input type='hidden' name='ZIP' value='$zipcode'><input type='hidden' name='ADDRESS' value=\"$address\"><input type='hidden' name='id' value='$id'><script>document.form1.submit();</script></form>";

?>
