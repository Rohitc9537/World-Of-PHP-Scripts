<?php

echo "<body><form name='form1' action='processpayment.php?paymethod=checkmoneyorder' method='post'><script language='javascript'>document.form1.submit();</script></form>";

?>
