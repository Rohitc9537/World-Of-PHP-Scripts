<?php
/*
  File Name: writereview.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$currenttime = time();
$memberid = $_POST['memberid'];
if ($memberid == "")   {
$error = 1;   }
$prodid = $_POST['prodid'];
if ($prodid == "")   {
$error = 1;   }
$review = $_POST['review'];
if ($review == "")   {
$error = 1;   }
$rating = $_POST['rating'];
$langid = $_POST['langid'];
if ($langid == "")   {
$langid = 1;   }

if ($error != "1")   {
include("dbinfo.php");
$insert = "insert into reviews values('', '$memberid', '$prodid', \"$review\", '$rating', '$currenttime', '$langid')";
mysql_query($insert, $conn);   }
header("location:reviews.php");
?>
