<?php
/*
  File Name: carttop.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

require_once("urlescape.php"); 
include("dbinfo.php");
$select = "select * from config where varname = 'quantityfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$quantityfeature = $newarray[varvalue];
$select = "select * from config where varname = 'displayoutofstock'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayoutofstock = $newarray[varvalue];
$select = "select * from config where varname = 'tellafriendfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$tellafriendfeature = $newarray[varvalue];
$select = "select * from config where varname = 'displayprivacypolicy'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayprivacypolicy = $newarray[varvalue];
$select = "select * from config where varname = 'numperpage'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$numperpage = $newarray[varvalue];
$select = "select * from config where varname = 'displayshipandrefunds'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipandrefunds = $newarray[varvalue];
if (($displayshipandrefunds == "1") || ($displayprivacypolicy == "1")) {
$displaylegalnotices = 1;  }
$select = "select * from config where varname = 'displayshipaddress'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipaddress = $newarray[varvalue];
$select = "select * from config where varname = 'displayshipping'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipping = $newarray[varvalue];
$select = "select * from config where varname = 'displaytax'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displaytax = $newarray[varvalue];
$select = "select * from config where varname = 'promocodefeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$promocodefeature = $newarray[varvalue];
$select = "select * from config where varname = 'bestsellers'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$bestsellers = $newarray[varvalue];
$select = "select * from config where varname = 'whatsnew'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$whatsnew = $newarray[varvalue];
$select = "select * from config where varname = 'displaymanufactures'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displaymanufactures = $newarray[varvalue];
$select = "select * from config where varname = 'productsperrow'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$productsperrow = $newarray[varvalue];
$select = "select * from config where varname = 'productreviews'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$productreviews = $newarray[varvalue];
$select = "select * from config where varname = 'cartimages'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$cartimages = $newarray[varvalue];
$select = "select * from config where varname = 'domainname'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$domainname = $newarray[varvalue];

if ($id == "")    {
$select3 = "select * from config where varname = 'defaultlang'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[varvalue];    }
else   {
$select3 = "select * from basket where id = '$id'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[defaultlang];    }

if ($langid == "") { $langid = 1; }
$langfilename = "lang" . $langid . ".php";
require_once ("lang/$langfilename");
require_once ('header.php');
require_once ('bannerinclude.php');
require_once ('toplayout.php');
?>