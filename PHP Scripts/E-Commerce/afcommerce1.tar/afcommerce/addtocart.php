<?php
/*
  File Name: addtocart.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$pid = $_POST[prodid];
$newprice = $_POST[newprice];
include("dbinfo.php");
$select = "select * from config where varname = 'quantityfeature'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$quantityfeature = $newarray[varvalue];

$select = "select * from products where prodid = '$pid'";
$answer = mysql_query($select, $conn);
$newarray = @mysql_fetch_array($answer);
$prodquantity = $newarray[prodquantity];
if (($prodquantity < 1) && ($quantityfeature == "1"))  {
header("location:getproduct.php?pid=$pid");
exit;   }

$prodprice = $newarray[price];
if ($newprice != "")   {
$prodprice = $newprice;   }
$quantity = 1;

if ($id == "")    {
$select3 = "select * from config where varname = 'defaultlang'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[varvalue];    }
else   {
$select3 = "select * from basket where id = '$id'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[defaultlang];    }

$select2 = "select * from product_descript where prodid = '$pid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];

if ($id == "")    {
// create new session
$currentdate = time();

$insertrow = "insert into basket values ('', '$memberid', '$currentdate', '', '', '', '0', '0', '0', '0', '$langid', '0')";
mysql_query($insertrow, $conn);
// get id
$highnum = 0;
$select = "select * from basket";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$id = $newarray[id];      
if ($highnum < $id)  {
$highnum = $id;    }  }
$id = $highnum;

$ip = $REMOTE_ADDR;
$update = "update ipid set basketid = '$id' where ip = '$ip'";
mysql_query($update, $conn); 

$insert = "insert into basket_products values ('', '$id', '$quantity', '$prodprice', '$pid', '$prodname', '0', '0')";
mysql_query($insert, $conn);
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);

$totalprice = $newarray[totalprice];
$totalprice = $totalprice + $price;
$update = "update basket set totalprice = '$totalprice' where id = '$id'";
mysql_query($update, $conn);

}
// check if cart has been created
else    {
$select = "select * from basket_products where basketid = '$id'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) < 1)    {
//create new row
$insert = "insert into basket_products values ('', '$id', '$quantity', '$prodprice', '$pid', '$prodname', '0', '0')";
mysql_query($insert, $conn);
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);

$totalprice = $newarray[totalprice];
$totalprice = $totalprice + $price;
$update = "update basket set totalprice = '$totalprice' where id = '$id'";
mysql_query($update, $conn);
}

else    {
// cart exists, add new row to cart table if not already there
$select = "select * from basket_products where basketid = '$id'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))    {
if ($newarray[prodid] == $pid)   {
$rownum = $newarray[id];
$quantity = $newarray[quantity];
$quantity = $quantity + 1;
$isthere = 1;   }
}
if ($isthere == "1")   {
$update = "update basket_products set quantity = '$quantity' where id = '$rownum'";
mysql_query($update, $conn);  


}
else   {
$insert = "insert into basket_products values ('', '$id', '$quantity', '$prodprice', '$pid', '$prodname', '0', '0')";
mysql_query($insert, $conn);    }
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);

$totalprice = $newarray[totalprice];
$totalprice = $totalprice + $price;
$update = "update basket set totalprice = '$totalprice' where id = '$id'";
mysql_query($update, $conn);          }            }

header("location:viewcart.php?oq=$oq");
?>
