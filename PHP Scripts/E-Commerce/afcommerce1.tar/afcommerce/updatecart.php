<?php
/*
  File Name: updatecart.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$oq = 0;
include("dbinfo.php");
$select = "select * from config where varname = 'quantityfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$quantityfeature = $newarray[varvalue];

$select = "select * from basket_products where basketid = '$id'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$dbquantity = $newarray[quantity];
$dbprodid = $newarray[prodid];

$subid = $newarray[id];
$temp = "quantity$subid";
$newquantity = $_POST[$temp];
$checkboxname = "c$subid";
$checkboxval = $_POST[$checkboxname];

if (($newquantity > $dbquantity) && ($quantityfeature == "1"))  {
$select218 = "select * from products where prodid = '$dbprodid'";
$answer218 = mysql_query($select218, $conn);
$newarray218 = mysql_fetch_array($answer218);
$dbprodquantity = $newarray218[prodquantity];

if ($newquantity > $dbprodquantity)  {
$newquantity = $dbprodquantity;
$oq = 1;  }    }

$update = "update basket_products set quantity = '$newquantity' where id = '$subid'";
mysql_query($update, $conn);    

if ($checkboxval == "on")   {
$delete = "DELETE FROM basket_products where id = '$subid'";
mysql_query($delete, $conn); 

}     }

header("location:viewcart.php?oq=$oq");
?>
