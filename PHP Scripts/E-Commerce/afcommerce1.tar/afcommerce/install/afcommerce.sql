CREATE TABLE basket (
  id int(11) NOT NULL auto_increment,
  memberid int(11) default NULL,
  date varchar(25) default NULL,
  promocode varchar(20) default NULL,
  comments text,
  totalprice varchar(25) default NULL,
  taxcost float default NULL,
  newshipaddress varchar(254) default NULL,
  shipcost float default NULL,
  paymethod varchar(25) default NULL,
  defaultlang tinyint(4) default NULL,
  extra1 tinyint(4) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE basket_products (
  id int(11) NOT NULL auto_increment,
  basketid int(11) default NULL,
  quantity int(11) default NULL,
  price varchar(25) default NULL,
  prodid int(11) default NULL,
  prodname varchar(50) default NULL,
  extra1 tinyint(4) default NULL,
  extra2 tinyint(4) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE ipid (
  id int(11) NOT NULL auto_increment,
  ip varchar(20),
  basketid varchar(20),
  date varchar(20),
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=11 ;
CREATE TABLE buttons (
  id int(11) NOT NULL auto_increment,
  langid tinyint(4) NOT NULL default '1',
  description varchar(255) NOT NULL default '',
  internalname varchar(100) NOT NULL default '',
  type tinyint(4) NOT NULL default '1', filename varchar(150) NOT NULL, rollfilename varchar(150) NOT NULL, objecttag text, pagename varchar(250), PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=11 ;
INSERT INTO buttons VALUES (1, 1, 'View Cart', 'button_viewcart', '1', '', '', '', 'viewcart.php');
INSERT INTO buttons VALUES (2, 1, 'Checkout', 'button_checkout', '1', '', '', '', 'checkout.php');
INSERT INTO buttons VALUES (3, 1, 'My Account', 'button_myaccount', '1', '', '', '', 'account.php');
INSERT INTO buttons VALUES (4, 1, 'View Orders', 'button_vieworders', '1', '', '', '', 'orderstatus.php');
INSERT INTO buttons VALUES (5, 1, 'Search', 'button_search', '1', '', '', '', 'search.php');
INSERT INTO buttons VALUES (6, 1, 'Best Sellers', 'button_bestsellers', '1', '', '', '', 'bestsellers.php');
INSERT INTO buttons VALUES (7, 1, 'Whats New', 'button_whatsnew', '1', '', '', '', 'whatsnew.php');
INSERT INTO buttons VALUES (8, 1, 'Reviews', 'button_reviews', '1', '', '', '', 'reviews.php');
INSERT INTO buttons VALUES (9, 1, 'Privacy Policy', 'button_privacy', '1', '', '', '', 'privacy.php');
INSERT INTO buttons VALUES (10, 1, 'Shipping and Refunds', 'button_shipandrefund', '1', '', '', '', 'shipandrefund.php');
CREATE TABLE categories (
  catid int(11) NOT NULL auto_increment,
  catimage varchar(40) default NULL,
  level tinyint(4) default NULL,
  num int(11) default NULL,
  dateadded varchar(20) default NULL,
  extra1 tinyint(4) default NULL,
  PRIMARY KEY  (catid)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE categories_descript (
  id int(11) NOT NULL auto_increment,
  catid int(11) default NULL,
  langid int(11) default NULL,
  catname varchar(75) default NULL,
  catdescript text,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE config (
  id int(11) NOT NULL auto_increment,
  varname varchar(40) default NULL,
  varvalue varchar(254) default NULL,
  extra1 tinyint(4) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
INSERT into config values ('' , 'handling', '0', ''), ('' , 'buttons', '0', ''), ('' , 'shipmethod' , 'flatrate', ''), ('' , 'flatrate' , '', ''), ('' , 'byweight', '', ''), ('' , 'peritem' , '', ''), ('' , 'percentagerate' , '', ''), ('' , 'storename' , '', ''), ('' , 'storeemail' , '', ''), ('' , 'storeaddress' , '', ''), ('' , 'storephone' , '', ''), ('' , 'storefax' , '', ''), ('' , 'taxrate' , '', ''), ('' , 'domainname' , '', ''), ('' , 'productreviews' , '1', ''), ('' , 'bestsellers' , '1', ''), ('' , 'displaytax' , '1', ''), ('' , 'displayshipping' , '1', ''), ('' , 'displayshipaddress' , '1', ''), ('' , 'displayshipandrefunds' , '1', ''), ('' , 'displayprivacypolicy' , '1', ''), ('' , 'whatsnew' , '1', ''), ('' , 'promocodefeature' , '1', ''), ('' , 'cartimages' , '1', ''), ('' , 'displaymanufactures' , '1', ''), ('' , 'productsperrow' , '3', ''), ('' , 'numperpage' , '15', ''), ('' , 'defaultlang' , '1', ''), ('' , 'maxdownloads' , '3', ''), ('' , 'tellafriendfeature' , '1', ''), ('' , 'quantityfeature' , '0', ''), ('' , 'displayoutofstock' , '0', ''), ('' , 'pickupshipping' , '0', ''), ('' , 'taxshipping' , '0', '');
CREATE TABLE countries (
  countries_id int(11) NOT NULL auto_increment,
  countries_name varchar(64) NOT NULL default '',
  countries_iso_code_2 char(2) NOT NULL default '',
  countries_iso_code_3 char(3) NOT NULL default '',
  address_format_id int(11) NOT NULL default '0',
  PRIMARY KEY  (countries_id)
) TYPE=MyISAM AUTO_INCREMENT=240 ;
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (1, 'Afghanistan', 'AF', 'AFG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (2, 'Albania', 'AL', 'ALB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (3, 'Algeria', 'DZ', 'DZA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (4, 'American Samoa', 'AS', 'ASM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (5, 'Andorra', 'AD', 'AND', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (6, 'Angola', 'AO', 'AGO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (7, 'Anguilla', 'AI', 'AIA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (8, 'Antarctica', 'AQ', 'ATA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (9, 'Antigua and Barbuda', 'AG', 'ATG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (10, 'Argentina', 'AR', 'ARG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (11, 'Armenia', 'AM', 'ARM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (12, 'Aruba', 'AW', 'ABW', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (13, 'Australia', 'AU', 'AUS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (14, 'Austria', 'AT', 'AUT', 5);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (15, 'Azerbaijan', 'AZ', 'AZE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (16, 'Bahamas', 'BS', 'BHS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (17, 'Bahrain', 'BH', 'BHR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (18, 'Bangladesh', 'BD', 'BGD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (19, 'Barbados', 'BB', 'BRB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (20, 'Belarus', 'BY', 'BLR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (21, 'Belgium', 'BE', 'BEL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (22, 'Belize', 'BZ', 'BLZ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (23, 'Benin', 'BJ', 'BEN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (24, 'Bermuda', 'BM', 'BMU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (25, 'Bhutan', 'BT', 'BTN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (26, 'Bolivia', 'BO', 'BOL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (27, 'Bosnia and Herzegowina', 'BA', 'BIH', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (28, 'Botswana', 'BW', 'BWA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (29, 'Bouvet Island', 'BV', 'BVT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (30, 'Brazil', 'BR', 'BRA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (31, 'British Indian Ocean Territory', 'IO', 'IOT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (32, 'Brunei Darussalam', 'BN', 'BRN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (33, 'Bulgaria', 'BG', 'BGR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (34, 'Burkina Faso', 'BF', 'BFA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (35, 'Burundi', 'BI', 'BDI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (36, 'Cambodia', 'KH', 'KHM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (37, 'Cameroon', 'CM', 'CMR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (38, 'Canada', 'CA', 'CAN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (39, 'Cape Verde', 'CV', 'CPV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (40, 'Cayman Islands', 'KY', 'CYM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (41, 'Central African Republic', 'CF', 'CAF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (42, 'Chad', 'TD', 'TCD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (43, 'Chile', 'CL', 'CHL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (44, 'China', 'CN', 'CHN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (45, 'Christmas Island', 'CX', 'CXR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (46, 'Cocos (Keeling) Islands', 'CC', 'CCK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (47, 'Colombia', 'CO', 'COL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (48, 'Comoros', 'KM', 'COM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (49, 'Congo', 'CG', 'COG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (50, 'Cook Islands', 'CK', 'COK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (51, 'Costa Rica', 'CR', 'CRI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (52, 'Cote D''Ivoire', 'CI', 'CIV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (53, 'Croatia', 'HR', 'HRV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (54, 'Cuba', 'CU', 'CUB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (55, 'Cyprus', 'CY', 'CYP', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (56, 'Czech Republic', 'CZ', 'CZE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (57, 'Denmark', 'DK', 'DNK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (58, 'Djibouti', 'DJ', 'DJI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (59, 'Dominica', 'DM', 'DMA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (60, 'Dominican Republic', 'DO', 'DOM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (61, 'East Timor', 'TP', 'TMP', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (62, 'Ecuador', 'EC', 'ECU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (63, 'Egypt', 'EG', 'EGY', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (64, 'El Salvador', 'SV', 'SLV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (65, 'Equatorial Guinea', 'GQ', 'GNQ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (66, 'Eritrea', 'ER', 'ERI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (67, 'Estonia', 'EE', 'EST', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (68, 'Ethiopia', 'ET', 'ETH', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (69, 'Falkland Islands (Malvinas)', 'FK', 'FLK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (70, 'Faroe Islands', 'FO', 'FRO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (71, 'Fiji', 'FJ', 'FJI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (72, 'Finland', 'FI', 'FIN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (73, 'France', 'FR', 'FRA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (74, 'France, Metropolitan', 'FX', 'FXX', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (75, 'French Guiana', 'GF', 'GUF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (76, 'French Polynesia', 'PF', 'PYF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (77, 'French Southern Territories', 'TF', 'ATF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (78, 'Gabon', 'GA', 'GAB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (79, 'Gambia', 'GM', 'GMB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (80, 'Georgia', 'GE', 'GEO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (81, 'Germany', 'DE', 'DEU', 5);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (82, 'Ghana', 'GH', 'GHA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (83, 'Gibraltar', 'GI', 'GIB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (84, 'Greece', 'GR', 'GRC', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (85, 'Greenland', 'GL', 'GRL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (86, 'Grenada', 'GD', 'GRD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (87, 'Guadeloupe', 'GP', 'GLP', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (88, 'Guam', 'GU', 'GUM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (89, 'Guatemala', 'GT', 'GTM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (90, 'Guinea', 'GN', 'GIN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (91, 'Guinea-bissau', 'GW', 'GNB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (92, 'Guyana', 'GY', 'GUY', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (93, 'Haiti', 'HT', 'HTI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (94, 'Heard and Mc Donald Islands', 'HM', 'HMD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (95, 'Honduras', 'HN', 'HND', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (96, 'Hong Kong', 'HK', 'HKG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (97, 'Hungary', 'HU', 'HUN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (98, 'Iceland', 'IS', 'ISL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (99, 'India', 'IN', 'IND', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (100, 'Indonesia', 'ID', 'IDN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (101, 'Iran (Islamic Republic of)', 'IR', 'IRN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (102, 'Iraq', 'IQ', 'IRQ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (103, 'Ireland', 'IE', 'IRL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (104, 'Israel', 'IL', 'ISR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (105, 'Italy', 'IT', 'ITA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (106, 'Jamaica', 'JM', 'JAM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (107, 'Japan', 'JP', 'JPN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (108, 'Jordan', 'JO', 'JOR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (109, 'Kazakhstan', 'KZ', 'KAZ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (110, 'Kenya', 'KE', 'KEN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (111, 'Kiribati', 'KI', 'KIR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (112, 'Korea, Democratic People''s Republic of', 'KP', 'PRK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (113, 'Korea, Republic of', 'KR', 'KOR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (114, 'Kuwait', 'KW', 'KWT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (115, 'Kyrgyzstan', 'KG', 'KGZ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (116, 'Lao People''s Democratic Republic', 'LA', 'LAO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (117, 'Latvia', 'LV', 'LVA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (118, 'Lebanon', 'LB', 'LBN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (119, 'Lesotho', 'LS', 'LSO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (120, 'Liberia', 'LR', 'LBR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (122, 'Liechtenstein', 'LI', 'LIE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (123, 'Lithuania', 'LT', 'LTU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (124, 'Luxembourg', 'LU', 'LUX', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (125, 'Macau', 'MO', 'MAC', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (126, 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (127, 'Madagascar', 'MG', 'MDG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (128, 'Malawi', 'MW', 'MWI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (129, 'Malaysia', 'MY', 'MYS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (130, 'Maldives', 'MV', 'MDV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (131, 'Mali', 'ML', 'MLI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (132, 'Malta', 'MT', 'MLT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (133, 'Marshall Islands', 'MH', 'MHL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (134, 'Martinique', 'MQ', 'MTQ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (135, 'Mauritania', 'MR', 'MRT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (136, 'Mauritius', 'MU', 'MUS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (137, 'Mayotte', 'YT', 'MYT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (138, 'Mexico', 'MX', 'MEX', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (139, 'Micronesia, Federated States of', 'FM', 'FSM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (140, 'Moldova, Republic of', 'MD', 'MDA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (141, 'Monaco', 'MC', 'MCO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (142, 'Mongolia', 'MN', 'MNG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (143, 'Montserrat', 'MS', 'MSR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (144, 'Morocco', 'MA', 'MAR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (145, 'Mozambique', 'MZ', 'MOZ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (146, 'Myanmar', 'MM', 'MMR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (147, 'Namibia', 'NA', 'NAM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (148, 'Nauru', 'NR', 'NRU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (149, 'Nepal', 'NP', 'NPL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (150, 'Netherlands', 'NL', 'NLD', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (151, 'Netherlands Antilles', 'AN', 'ANT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (152, 'New Caledonia', 'NC', 'NCL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (153, 'New Zealand', 'NZ', 'NZL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (154, 'Nicaragua', 'NI', 'NIC', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (155, 'Niger', 'NE', 'NER', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (156, 'Nigeria', 'NG', 'NGA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (157, 'Niue', 'NU', 'NIU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (158, 'Norfolk Island', 'NF', 'NFK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (159, 'Northern Mariana Islands', 'MP', 'MNP', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (160, 'Norway', 'NO', 'NOR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (161, 'Oman', 'OM', 'OMN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (162, 'Pakistan', 'PK', 'PAK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (163, 'Palau', 'PW', 'PLW', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (164, 'Panama', 'PA', 'PAN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (165, 'Papua New Guinea', 'PG', 'PNG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (166, 'Paraguay', 'PY', 'PRY', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (167, 'Peru', 'PE', 'PER', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (168, 'Philippines', 'PH', 'PHL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (169, 'Pitcairn', 'PN', 'PCN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (170, 'Poland', 'PL', 'POL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (171, 'Portugal', 'PT', 'PRT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (172, 'Puerto Rico', 'PR', 'PRI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (173, 'Qatar', 'QA', 'QAT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (174, 'Reunion', 'RE', 'REU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (175, 'Romania', 'RO', 'ROM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (176, 'Russian Federation', 'RU', 'RUS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (177, 'Rwanda', 'RW', 'RWA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (178, 'Saint Kitts and Nevis', 'KN', 'KNA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (179, 'Saint Lucia', 'LC', 'LCA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (180, 'Saint Vincent and the Grenadines', 'VC', 'VCT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (181, 'Samoa', 'WS', 'WSM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (182, 'San Marino', 'SM', 'SMR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (183, 'Sao Tome and Principe', 'ST', 'STP', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (184, 'Saudi Arabia', 'SA', 'SAU', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (185, 'Senegal', 'SN', 'SEN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (186, 'Seychelles', 'SC', 'SYC', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (187, 'Sierra Leone', 'SL', 'SLE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (188, 'Singapore', 'SG', 'SGP', 4);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (189, 'Slovakia (Slovak Republic)', 'SK', 'SVK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (190, 'Slovenia', 'SI', 'SVN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (191, 'Solomon Islands', 'SB', 'SLB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (192, 'Somalia', 'SO', 'SOM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (193, 'South Africa', 'ZA', 'ZAF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (194, 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (195, 'Spain', 'ES', 'ESP', 3);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (196, 'Sri Lanka', 'LK', 'LKA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (197, 'St. Helena', 'SH', 'SHN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (198, 'St. Pierre and Miquelon', 'PM', 'SPM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (199, 'Sudan', 'SD', 'SDN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (200, 'Suriname', 'SR', 'SUR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (202, 'Swaziland', 'SZ', 'SWZ', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (203, 'Sweden', 'SE', 'SWE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (204, 'Switzerland', 'CH', 'CHE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (205, 'Syrian Arab Republic', 'SY', 'SYR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (206, 'Taiwan', 'TW', 'TWN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (207, 'Tajikistan', 'TJ', 'TJK', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (208, 'Tanzania, United Republic of', 'TZ', 'TZA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (209, 'Thailand', 'TH', 'THA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (210, 'Togo', 'TG', 'TGO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (211, 'Tokelau', 'TK', 'TKL', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (212, 'Tonga', 'TO', 'TON', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (213, 'Trinidad and Tobago', 'TT', 'TTO', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (214, 'Tunisia', 'TN', 'TUN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (215, 'Turkey', 'TR', 'TUR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (216, 'Turkmenistan', 'TM', 'TKM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (217, 'Turks and Caicos Islands', 'TC', 'TCA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (218, 'Tuvalu', 'TV', 'TUV', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (219, 'Uganda', 'UG', 'UGA', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (220, 'Ukraine', 'UA', 'UKR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (221, 'United Arab Emirates', 'AE', 'ARE', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (222, 'United Kingdom', 'GB', 'GBR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (223, 'United States', 'US', 'USA', 2);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (224, 'United States Minor Outlying Islands', 'UM', 'UMI', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (225, 'Uruguay', 'UY', 'URY', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (226, 'Uzbekistan', 'UZ', 'UZB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (227, 'Vanuatu', 'VU', 'VUT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (228, 'Vatican City State (Holy See)', 'VA', 'VAT', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (229, 'Venezuela', 'VE', 'VEN', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (230, 'Viet Nam', 'VN', 'VNM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (231, 'Virgin Islands (British)', 'VG', 'VGB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (232, 'Virgin Islands (U.S.)', 'VI', 'VIR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (233, 'Wallis and Futuna Islands', 'WF', 'WLF', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (234, 'Western Sahara', 'EH', 'ESH', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (235, 'Yemen', 'YE', 'YEM', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (236, 'Yugoslavia', 'YU', 'YUG', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (237, 'Zaire', 'ZR', 'ZAR', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (238, 'Zambia', 'ZM', 'ZMB', 1);
INSERT INTO countries (countries_id, countries_name, countries_iso_code_2, countries_iso_code_3, address_format_id) VALUES (239, 'Zimbabwe', 'ZW', 'ZWE', 1);
CREATE TABLE languages (
  langid int(11) NOT NULL auto_increment,
  langname varchar(50) default NULL,
  status tinyint(4) default NULL,
  langimage varchar(100) default NULL,
  extra1 tinyint(4) default NULL,
  PRIMARY KEY  (langid)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

INSERT INTO languages (langid, langname, status, langimage, extra1) VALUES (1, 'English', 1, '', 0);
INSERT INTO languages (langid, langname, status, langimage, extra1) VALUES (2, 'Spanish', 0, '', 0);
CREATE TABLE legal (
  legalid int(11) NOT NULL auto_increment,
  content text,
  identifier varchar(50) default NULL,
  langid tinyint(4) default NULL,
  PRIMARY KEY  (legalid)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

INSERT INTO legal (legalid, content, identifier, langid) VALUES (1, '', 'privacy', 1);
INSERT INTO legal (legalid, content, identifier, langid) VALUES (2, '', 'shipping', 1);
INSERT INTO legal (legalid, content, identifier, langid) VALUES (3, '', 'home', 1);
INSERT INTO legal (legalid, content, identifier, langid) VALUES (4, '', 'privacy', 2);
INSERT INTO legal (legalid, content, identifier, langid) VALUES (5, '', 'shipping', 2);
CREATE TABLE manufactures (
  manid int(11) NOT NULL auto_increment,
  manname varchar(150) default NULL,
  extra1 tinyint(4) default NULL,
  langid tinyint(4) default NULL,
  PRIMARY KEY  (manid)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE members (
  memberid int(11) NOT NULL auto_increment,
  firstname varchar(100) default NULL,
  lastname varchar(150) default NULL,
  email varchar(254) default NULL,
  pass varchar(50) default NULL,
  address varchar(150) default NULL,
  city varchar(100) default NULL,
  state varchar(100) default NULL,
  zipcode varchar(15) default NULL,
  phone varchar(25) default NULL,
  fax varchar(25) default NULL,
  newsletter tinyint(4) default NULL,
  datecreated varchar(25) default NULL,
  country varchar(254) default NULL,
  extra1 tinyint(4) default NULL,
  extra2 tinyint(4) default NULL,
  extra3 tinyint(4) default NULL,
  PRIMARY KEY  (memberid)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

INSERT INTO members (memberid, firstname, lastname, email, pass, address, city, state, zipcode, phone, fax, newsletter, datecreated, country, extra1, extra2, extra3) VALUES (1, 'Test', 'Member', 'test@domain.com', 'password', 'none', 'none', '18', '1', '1', '', 1, '1098859936', '223', 0, 0, 0);
CREATE TABLE order_downloads (
  id int(11) NOT NULL auto_increment,
  orderid int(11) default NULL,
  maxdownloads tinyint(4) default NULL,
  maxdays tinyint(4) default NULL,
  prodid int(11) default NULL,
  filename varchar(150) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE orders (
  id int(11) NOT NULL auto_increment,
  memberid int(11) default NULL,
  total varchar(25) default NULL,
  receipt text,
  status varchar(25) default NULL,
  shipaddress varchar(254) default NULL,
  paymethod varchar(25) default NULL,
  confirmcode varchar(30) default NULL,
  taxcost float default NULL,
  shipmethod varchar(40) default NULL,
  shipcost varchar(20) default NULL,
  promodiscount varchar(30) default NULL,
  orderdate varchar(25) default NULL,
  comments text,
  extra1 tinyint(4) default NULL,
  extra2 tinyint(4) default NULL,
  extra3 tinyint(4) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE paymethod (
  id int(11) NOT NULL auto_increment,
  type varchar(30) default NULL,
  description varchar(200) default NULL,
  info1 varchar(254) default NULL,
  info2 varchar(254) default NULL,
  info3 varchar(254) default NULL,
  info4 varchar(254) default NULL,
  status tinyint(4) default NULL,
  info1name varchar(25) default NULL,
  info2name varchar(25) default NULL,
  info3name varchar(25) default NULL,
  info4name varchar(25) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

INSERT INTO paymethod (id, type, description, info1, info2, info3, info4, status, info1name, info2name, info3name, info4name) VALUES (1, 'Paypal', 'Paypal', '', '', '', '', 0, 'Paypal Email Address', '', '', '');
INSERT INTO paymethod (id, type, description, info1, info2, info3, info4, status, info1name, info2name, info3name, info4name) VALUES (2, 'Verisign-Payflow Pro', 'Credit Card', '', '', '', '', 0, 'Login ID', 'Partner', 'Password', 'Vendor');
INSERT INTO paymethod (id, type, description, info1, info2, info3, info4, status, info1name, info2name, info3name, info4name) VALUES (3, 'Verisign-Payflow Link', 'Credit Card', '', '', '', '', 0, 'Login ID', 'Partner', '', '');
INSERT INTO paymethod (id, type, description, info1, info2, info3, info4, status, info1name, info2name, info3name, info4name) VALUES (4, 'Check-Money-Order', 'Check or Money Order', '', '', '', '', 0, '', '', '', '');
CREATE TABLE product_descript (
  id int(11) NOT NULL auto_increment,
  langid int(11) default NULL,
  prodid int(11) default NULL,
  prodname varchar(50) default NULL,
  proddescript text,
  prodcaption varchar(254) default NULL,
  webpage varchar(100) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE products (
  prodid int(11) NOT NULL auto_increment,
  prodimage varchar(50) default NULL,
  price float default NULL,
  catid int(11) default NULL,
  modelnum varchar(25) default NULL,
  download varchar(50) default NULL,
  weight int(11) default NULL,
  specialid int(11) default NULL,
  totalsold int(11) default NULL,
  manid int(11) default NULL,
  datecreated varchar(25) default NULL,
  status tinyint(4) default NULL,
  prodquantity varchar(25) default NULL,
  extra1 tinyint(4) default NULL,
  extra2 tinyint(4) default NULL,
  PRIMARY KEY  (prodid)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE promos (
  id int(11) NOT NULL auto_increment,
  promocode varchar(50) default NULL,
  discount float default NULL,
  status tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE reviews (
  id int(11) NOT NULL auto_increment,
  memberid int(11) default NULL,
  prodid int(11) default NULL,
  review text,
  rating tinyint(4) default NULL,
  dateadded varchar(25) default NULL,
  langid int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE specials (
  id int(11) NOT NULL auto_increment,
  prodid int(11) default NULL,
  newprice varchar(25) default NULL,
  expdate varchar(25) default NULL,
  extra1 tinyint(4) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE taxzones (
  id int(11) NOT NULL auto_increment,
  state int(11) default NULL,
  taxrate float default NULL,
  description varchar(250) default NULL,
  countryid int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE zones (
  zone_id int(11) NOT NULL auto_increment,
  zone_country_id int(11) NOT NULL default '0',
  zone_code varchar(32) NOT NULL default '',
  zone_name varchar(32) NOT NULL default '',
  PRIMARY KEY  (zone_id)
) TYPE=MyISAM AUTO_INCREMENT=182 ;

INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (1, 223, 'AL', 'Alabama');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (2, 223, 'AK', 'Alaska');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (3, 223, 'AS', 'American Samoa');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (4, 223, 'AZ', 'Arizona');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (5, 223, 'AR', 'Arkansas');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (6, 223, 'AF', 'Armed Forces Africa');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (7, 223, 'AA', 'Armed Forces Americas');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (8, 223, 'AC', 'Armed Forces Canada');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (9, 223, 'AE', 'Armed Forces Europe');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (10, 223, 'AM', 'Armed Forces Middle East');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (11, 223, 'AP', 'Armed Forces Pacific');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (12, 223, 'CA', 'California');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (13, 223, 'CO', 'Colorado');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (14, 223, 'CT', 'Connecticut');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (15, 223, 'DE', 'Delaware');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (16, 223, 'DC', 'District of Columbia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (17, 223, 'FM', 'Federated States Of Micronesia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (18, 223, 'FL', 'Florida');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (19, 223, 'GA', 'Georgia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (20, 223, 'GU', 'Guam');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (21, 223, 'HI', 'Hawaii');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (22, 223, 'ID', 'Idaho');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (23, 223, 'IL', 'Illinois');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (24, 223, 'IN', 'Indiana');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (25, 223, 'IA', 'Iowa');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (26, 223, 'KS', 'Kansas');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (27, 223, 'KY', 'Kentucky');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (28, 223, 'LA', 'Louisiana');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (29, 223, 'ME', 'Maine');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (30, 223, 'MH', 'Marshall Islands');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (31, 223, 'MD', 'Maryland');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (32, 223, 'MA', 'Massachusetts');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (33, 223, 'MI', 'Michigan');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (34, 223, 'MN', 'Minnesota');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (35, 223, 'MS', 'Mississippi');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (36, 223, 'MO', 'Missouri');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (37, 223, 'MT', 'Montana');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (38, 223, 'NE', 'Nebraska');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (39, 223, 'NV', 'Nevada');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (40, 223, 'NH', 'New Hampshire');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (41, 223, 'NJ', 'New Jersey');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (42, 223, 'NM', 'New Mexico');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (43, 223, 'NY', 'New York');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (44, 223, 'NC', 'North Carolina');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (45, 223, 'ND', 'North Dakota');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (46, 223, 'MP', 'Northern Mariana Islands');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (47, 223, 'OH', 'Ohio');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (48, 223, 'OK', 'Oklahoma');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (49, 223, 'OR', 'Oregon');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (50, 223, 'PW', 'Palau');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (51, 223, 'PA', 'Pennsylvania');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (52, 223, 'PR', 'Puerto Rico');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (53, 223, 'RI', 'Rhode Island');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (54, 223, 'SC', 'South Carolina');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (55, 223, 'SD', 'South Dakota');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (56, 223, 'TN', 'Tennessee');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (57, 223, 'TX', 'Texas');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (58, 223, 'UT', 'Utah');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (59, 223, 'VT', 'Vermont');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (60, 223, 'VI', 'Virgin Islands');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (61, 223, 'VA', 'Virginia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (62, 223, 'WA', 'Washington');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (63, 223, 'WV', 'West Virginia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (64, 223, 'WI', 'Wisconsin');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (65, 223, 'WY', 'Wyoming');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (66, 38, 'AB', 'Alberta');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (67, 38, 'BC', 'British Columbia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (68, 38, 'MB', 'Manitoba');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (69, 38, 'NF', 'Newfoundland');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (70, 38, 'NB', 'New Brunswick');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (71, 38, 'NS', 'Nova Scotia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (72, 38, 'NT', 'Northwest Territories');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (73, 38, 'NU', 'Nunavut');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (74, 38, 'ON', 'Ontario');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (75, 38, 'PE', 'Prince Edward Island');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (76, 38, 'QC', 'Quebec');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (77, 38, 'SK', 'Saskatchewan');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (78, 38, 'YT', 'Yukon Territory');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (79, 81, 'NDS', 'Niedersachsen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (80, 81, 'BAW', 'Baden-W�rttemberg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (81, 81, 'BAY', 'Bayern');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (82, 81, 'BER', 'Berlin');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (83, 81, 'BRG', 'Brandenburg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (84, 81, 'BRE', 'Bremen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (85, 81, 'HAM', 'Hamburg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (86, 81, 'HES', 'Hessen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (87, 81, 'MEC', 'Mecklenburg-Vorpommern');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (88, 81, 'NRW', 'Nordrhein-Westfalen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (89, 81, 'RHE', 'Rheinland-Pfalz');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (90, 81, 'SAR', 'Saarland');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (91, 81, 'SAS', 'Sachsen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (92, 81, 'SAC', 'Sachsen-Anhalt');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (93, 81, 'SCN', 'Schleswig-Holstein');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (94, 81, 'THE', 'Th�ringen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (95, 14, 'WI', 'Wien');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (96, 14, 'NO', 'Nieder�sterreich');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (97, 14, 'OO', 'Ober�sterreich');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (98, 14, 'SB', 'Salzburg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (99, 14, 'KN', 'K�rnten');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (100, 14, 'ST', 'Steiermark');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (101, 14, 'TI', 'Tirol');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (102, 14, 'BL', 'Burgenland');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (103, 14, 'VB', 'Voralberg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (104, 204, 'AG', 'Aargau');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (105, 204, 'AI', 'Appenzell Innerrhoden');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (106, 204, 'AR', 'Appenzell Ausserrhoden');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (107, 204, 'BE', 'Bern');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (108, 204, 'BL', 'Basel-Landschaft');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (109, 204, 'BS', 'Basel-Stadt');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (110, 204, 'FR', 'Freiburg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (111, 204, 'GE', 'Genf');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (112, 204, 'GL', 'Glarus');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (113, 204, 'JU', 'Graub�nden');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (114, 204, 'JU', 'Jura');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (115, 204, 'LU', 'Luzern');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (116, 204, 'NE', 'Neuenburg');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (117, 204, 'NW', 'Nidwalden');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (118, 204, 'OW', 'Obwalden');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (119, 204, 'SG', 'St. Gallen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (120, 204, 'SH', 'Schaffhausen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (121, 204, 'SO', 'Solothurn');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (122, 204, 'SZ', 'Schwyz');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (123, 204, 'TG', 'Thurgau');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (124, 204, 'TI', 'Tessin');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (125, 204, 'UR', 'Uri');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (126, 204, 'VD', 'Waadt');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (127, 204, 'VS', 'Wallis');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (128, 204, 'ZG', 'Zug');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (129, 204, 'ZH', 'Z�rich');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (130, 195, 'A Coru�a', 'A Coru�a');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (131, 195, 'Alava', 'Alava');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (132, 195, 'Albacete', 'Albacete');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (133, 195, 'Alicante', 'Alicante');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (134, 195, 'Almeria', 'Almeria');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (135, 195, 'Asturias', 'Asturias');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (136, 195, 'Avila', 'Avila');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (137, 195, 'Badajoz', 'Badajoz');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (138, 195, 'Baleares', 'Baleares');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (139, 195, 'Barcelona', 'Barcelona');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (140, 195, 'Burgos', 'Burgos');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (141, 195, 'Caceres', 'Caceres');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (142, 195, 'Cadiz', 'Cadiz');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (143, 195, 'Cantabria', 'Cantabria');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (144, 195, 'Castellon', 'Castellon');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (145, 195, 'Ceuta', 'Ceuta');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (146, 195, 'Ciudad Real', 'Ciudad Real');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (147, 195, 'Cordoba', 'Cordoba');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (148, 195, 'Cuenca', 'Cuenca');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (149, 195, 'Girona', 'Girona');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (150, 195, 'Granada', 'Granada');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (151, 195, 'Guadalajara', 'Guadalajara');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (152, 195, 'Guipuzcoa', 'Guipuzcoa');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (153, 195, 'Huelva', 'Huelva');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (154, 195, 'Huesca', 'Huesca');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (155, 195, 'Jaen', 'Jaen');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (156, 195, 'La Rioja', 'La Rioja');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (157, 195, 'Las Palmas', 'Las Palmas');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (158, 195, 'Leon', 'Leon');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (159, 195, 'Lleida', 'Lleida');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (160, 195, 'Lugo', 'Lugo');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (161, 195, 'Madrid', 'Madrid');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (162, 195, 'Malaga', 'Malaga');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (163, 195, 'Melilla', 'Melilla');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (164, 195, 'Murcia', 'Murcia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (165, 195, 'Navarra', 'Navarra');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (166, 195, 'Ourense', 'Ourense');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (167, 195, 'Palencia', 'Palencia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (168, 195, 'Pontevedra', 'Pontevedra');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (169, 195, 'Salamanca', 'Salamanca');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (170, 195, 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (171, 195, 'Segovia', 'Segovia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (172, 195, 'Sevilla', 'Sevilla');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (173, 195, 'Soria', 'Soria');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (174, 195, 'Tarragona', 'Tarragona');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (175, 195, 'Teruel', 'Teruel');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (176, 195, 'Toledo', 'Toledo');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (177, 195, 'Valencia', 'Valencia');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (178, 195, 'Valladolid', 'Valladolid');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (179, 195, 'Vizcaya', 'Vizcaya');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (180, 195, 'Zamora', 'Zamora');
INSERT INTO zones (zone_id, zone_country_id, zone_code, zone_name) VALUES (181, 195, 'Zaragoza', 'Zaragoza');
