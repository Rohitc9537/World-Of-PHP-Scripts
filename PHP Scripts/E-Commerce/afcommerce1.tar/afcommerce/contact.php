<?php
/*
  File Name: contact.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("carttop.php"); 
include("dbinfo.php");
$select = "select * from config where varname = 'storefax'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storefax = $newarray[varvalue];

$select = "select * from config where varname = 'storephone'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storephone = $newarray[varvalue];

$select = "select * from config where varname = 'storeaddress'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeaddress = $newarray[varvalue];

$select = "select * from config where varname = 'storeemail'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeemail = $newarray[varvalue];

$select = "select * from config where varname = 'storename'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storename = $newarray[varvalue];
$error = 0;
$name = $_POST[name];
if ($name == "")   {
$error = 1;  }
$email = $_POST[email];
$phone = $_POST[phone];
$comments = $_POST[message];
if ($comments == "")   {
$error = 1;  }

if ($error == "0")    {
$msg = "Message From: $name

Email: $email

Phone Number: $phone

Message: $comments";
$recipient = $storeemail;
$subject = "Message From $storename";
$mailheaders = "From: $storeemail";
mail($recipient, $subject, $msg, $mailheaders);

echo "<h2>Thank you for your request, we will be contacting you shortly.</h2>";
exit;    }

echo "<CENTER><form action='contact.php' method='post'><CENTER><H2>" . CONTACT_HEADER . "<HR></H2>";

if ($storename != "")  {
echo "<font size='4' face='arial'>$storename</font><BR><BR>";   }

if (($storefax != "") || ($storephone != "")) {
echo "<TABLE WIDTH='600' BORDER='0' CELLSPACING='2' CELLPADDING='2'><TR ALIGN='CENTER' VALIGN='MIDDLE'>";   }

if ($storephone != "")  {  
echo "<TD ALIGN='CENTER' VALIGN='MIDDLE'><font size='3' face='arial'><B>$storephone - Phone</B></font></td>"; }

if ($storefax != "")  {  
echo "<TD ALIGN='CENTER' VALIGN='MIDDLE'><font size='3' face='arial'><B>$storefax - Fax</B></font></td>"; }

if (($storefax != "") || ($storephone != "")) {
echo "</tr></table><BR>";  }

if (($storeaddress != "") || ($storeemail != "")) {
echo "<TABLE WIDTH='600' BORDER='0' CELLSPACING='2' CELLPADDING='2'><TR ALIGN='CENTER' VALIGN='MIDDLE'>";    }

if ($storeaddress != "")  { 
echo "<TD ALIGN='CENTER' VALIGN='MIDDLE'><font size='3' face='arial'><B>$storeaddress</B></font></td>";   }

if ($storeemail != "")  { 
echo "<TD ALIGN='CENTER' VALIGN='MIDDLE'><a href='mailto:$storeemail'><font size='3' face='arial'><B>$storeemail</B></font></a></td>";  }

if (($storeaddress != "") || ($storeemail != "")) {
echo "</tr></table><BR>";   }

if (($error == "1") && ($_POST[posted] == "1"))   {
echo "<font size='4' color='#ff0000'>Name and Comments Required</font><BR>";   }
echo "<BR><font size='4' face='arial'>" . CONTACT_FORMHEADER . "</font><TABLE WIDTH='85%' BORDER='1' CELLSPACING='2' CELLPADDING='2'>
  <TR ALIGN='CENTER' VALIGN='MIDDLE'><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><font size='4' face='arial'>" . CONTACT_NAME . " :</font></TD><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><input size='17' name='name'></TD></TR><TR ALIGN='CENTER' VALIGN='MIDDLE'><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><font size='4' face='arial'>" . CONTACT_EMAIL . " :</font></TD><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><input size='17' name='email'></TD></TR><TR ALIGN='CENTER' VALIGN='MIDDLE'><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><font size='4' face='arial'>" .  CONTACT_PHONE . " :</font></TD><TD WIDTH='50%' ALIGN='CENTER' VALIGN='MIDDLE'><input size='17' name='phone'></TD></TR></TABLE><BR><BR><font size='4' face='arial'>" . CONTACT_MESSAGE . " :</font><BR><BR><TEXTAREA name='message' cols='45' rows='5'></TEXTAREA><BR><BR><BR><input type='image' src='lang/$langid/1/contactus.gif'><BR><BR><input type='hidden' name='posted' value='1'></form>";

echo "<BR><BR></td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>