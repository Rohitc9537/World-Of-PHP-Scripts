<?php 
/*
  File Name: translatelist.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$select = "select * from languages where langid != '$langid' && status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$langname = $newarray[langname];
$templangid = $newarray[langid];
echo "<CENTER><HR><a href='changelang.php?id=$id&lang=$templangid'><font size='2'>" . MENU_TRANSLATE . " $langname</font></a>";    }
?>
