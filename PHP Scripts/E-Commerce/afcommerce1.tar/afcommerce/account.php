<?php 
/*
  File Name: account.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("carttop.php");
include("dbinfo.php");
if ($id == "")    {
// start a new session and log in
$currentdate = time();
$insertrow = "insert into basket values ('', '', '$currentdate', '', '', '', '0', '0', '0', '0', '$langid', '0')";
mysql_query($insertrow, $conn);
// get id
$highnum = 0;
$select = "select * from basket";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$id = $newarray[id];      
if ($highnum < $id)  {
$highnum = $id;    }  }
$id = $highnum;
$ip = $REMOTE_ADDR;
$update = "update ipid set basketid = '$id' where ip = '$ip'";
mysql_query($update, $conn); 
}
if ($id != "")    {
// session already started, check if logged in
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];

if (($memberid == "") || ($memberid == "0"))   {
// not logged in, log in or create account

echo "<CENTER><script>
function forgot()    {  window.open('forgotpass.php','','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=350,height=250,top=50,left=20');
}
</script><form action='login.php' method='post'><H2>" . ACCOUNTS_HEADER . "</H2><table width='400' class='viewcart' border='1'><tr><td align='center'>" . ACCOUNTS_RETURNINGCUSTOMER . " :</div><BR>
                   <table width='400' class='viewcart'><tr>
                    <td class='main'><b>" . ACCOUNTS_EMAIL . ":</b></td>
                    <td class='main'><input type='text' name='email'></td>
                  </tr>
                  <tr>
                    <td class='main'><b>" . ACCOUNTS_PASSWORD . ":</b></td>
                    <td class='main'><input type='password' name='password' maxlength='40'></td>
                  </tr></table><table width='400' class='viewcart'>
                  <tr>
                    <td align='left'><a href='javascript:forgot()' class='login'>" . ACCOUNTS_FORGOTPASS . " ?</a><BR><BR></td> <td align='center'><BR><input type='image' src='lang/$langid/1/button_login.gif'><BR><BR></form></td>
                  </tr>
				  <tr></table><table width='400' class='viewcart'>
				  <td align='center'><HR>" . ACCOUNTS_NEWACCOUNTHEADER . " : <BR>
						<a href='newaccount.php' class='login'>" . ACCOUNTS_NEWACCOUNTLINK . "</a><BR><BR></td> 		  
                 </tr></table></td> 		  
                 </tr></table><BR><BR>";

}    else   {
// logged in, show cart

$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];

$select = "select * from members where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);

$firstname = $newarray[firstname];
$lastname = $newarray[lastname];
$email = $newarray[email];
$address = $newarray[address];
$city = $newarray[city];
$state = $newarray[state];
$newsletter = $newarray[newsletter];
$country = $newarray[country];
$phone = $newarray[phone];
$fax = $newarray[fax];
$zipcode = $newarray[zipcode];

$select = "select * from countries where countries_id = '$country'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$country = $newarray[countries_name];

$select = "select * from zones where zone_id = '$state'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$state = $newarray[zone_name];

echo "<CENTER><H2>" . ACCOUNTS_UPDATEHEADER . "<HR></H2><form action='updateaccount.php' method='post'>
<table width='450' border='0' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='450' border='0' cellspacing='0' cellpadding='2'>
          <tr>
          <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_FIRSTNAME . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='firstname' value='$firstname'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_LASTNAME . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='lastname' value='$lastname'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_EMAIL . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='email' value='$email'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
        </table></td>
  </tr>
  <tr>
    
        <td class='main'><table width='450' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_STREET . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='address' value='$address'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
           <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_ZIP . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='zipcode' value='$zipcode'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_CITY . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='city'  value='$city'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_STATE . ":</B></td>
            <td class='main' width='50%'>&nbsp; <input type='text' name='state' value=\"$state\"></td>
          </tr>
          <tr></table></td>
  </tr>
  <tr>
    <td class='main'><table border='0' width='450' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='450' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_PHONE . ":</B></td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='phone' value='$phone'>&nbsp;&nbsp;<small><font color='#330099'>" . REQUIRED . "</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_FAX . ":</B></td>
            <td class='main' width='50%'>&nbsp; <input type='text' name='fax' value='$fax'>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class='main'><table border='0' width='450' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='450' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;<B>" . NEWACCOUNT_NEWSLETTER . ":</B></td>
            <td class='main' width='50%'>&nbsp; 
<select name='newsletter'><option value='1'";
if ($newsletter == "1")   {   echo " selected";    }
echo ">" . NEWSLETTER_SUBSCRIBED . "</option><option value='0'";
if ($newsletter == "0")   {   echo " selected";    }
echo ">" . NEWSLETTER_UNSUBSCRIBED . "</option></select>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr></table><BR><BR><BR><CENTER><input type='image' src='lang/$langid/1/button_updateaccount.gif'><BR><BR><BR></form><HR><BR><BR><a href='logout.php' class='login'><B>" . ACCOUNTS_LOGOUT . "</B></a><BR><BR>";

}
} // ends else for if id is blank

 ?><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
