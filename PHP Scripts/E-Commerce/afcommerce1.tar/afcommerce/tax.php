<?php
/*
  File Name: tax.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

function gettaxrate ($state, $country)   {
include("dbinfo.php");

if (!is_numeric($state)) {

// this is to find the rate for a new shipping address
$select = "select * from zones where zone_name = '$state' || zone_code = '$state'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$zone_country_id = $newarray[zone_country_id];
$zone_id = $newarray[zone_id];

if ($zone_id < 1) {
// error finding state, so return 0. You may want to do something when this happens
// If so, add your code here. - Paul
return 0;    }

$state = $zone_id;
} // ends zone is not a number

$select = "select * from taxzones where state = '$state'";
$answer = mysql_query($select, $conn);
if (@mysql_num_rows($answer) < 1)  { return 0;  }

$select = "select * from taxzones where state = '$state'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$taxrate = $newarray[taxrate]; 
if (($taxrate == "") || ($taxrate == "0"))   {  return 0;  }
return $taxrate;  
} // ends function

?>
