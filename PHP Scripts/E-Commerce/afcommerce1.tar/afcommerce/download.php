<?php
/*
  File Name: download.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from order_downloads where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$filename = $newarray[filename];
$maxdownloads = $newarray[maxdownloads];
if ($maxdownloads < 1)   {   
$select = "select * from config where varname = 'defaultlang'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$langid = $newarray[varvalue];
$langfilename = "lang" . $langid . ".php";
require ("lang/$langfilename");
echo "<BR><BR><BR><CENTER><H2>" . MAXDOWNLOADS_OVERLIMIT . "</H2>";
exit;    }
$maxdownloads = $maxdownloads - 1;
$update = "update order_downloads set maxdownloads = '$maxdownloads' where id = '$id'";
mysql_query($update, $conn);
header ("location:downloads/$filename");

?>
