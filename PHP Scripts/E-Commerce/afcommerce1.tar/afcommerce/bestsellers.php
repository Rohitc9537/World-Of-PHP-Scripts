<?php
/*
  File Name: bestsellers.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("carttop.php");
echo "<CENTER><H2>" . BESTSELLERS_HEADER . "<HR></H2><table width='90%' border='0' cellpadding='7'>";
include("dbinfo.php");
// first get all products by datecreated
$select = "select * from products where status = '1' order by totalsold desc limit 0,12";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$prodid = $newarray[prodid];  
$prodimage = $newarray[prodimage];
$select2 = "select * from product_descript where prodid = '$prodid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];
$prodcaption = $newarray2[prodcaption];

if ($prodname != "")   {
echo "<tr><td width='65%' align='center' valign='middle'><a href='getproduct.php?pid=$prodid' class='login'><font size='4'>$prodname</font></a><BR><BR><font size='3'>$prodcaption</font><BR><HR></td>";   }

if ($prodimage != "")   {
echo "<td width='35%' align='center' valign='middle'><img src='images/$prodimage' width='70'><BR><BR></td>";   }
else   {
echo "<td width='35%' align='center' valign='middle'><BR><BR><BR></td>";   }

echo "</tr>"; 

} // ends outer while loop

echo "</table></td></tr></table>";

?><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
