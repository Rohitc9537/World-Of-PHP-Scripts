<?php
/*
  File Name: updatetaxrule.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$ruleid = $_GET['ruleid'];
include("dbinfo.php");
$taxrate = $_POST[taxrate];
$description = $_POST[description];

$update = "update taxzones set description = \"$description\", taxrate = '$taxrate' where id = '$ruleid'";
mysql_query($update, $conn);
header("location:addtaxrules.php?ruleid=$ruleid");

?>
