<?php
/*
  File Name: dbinfo.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

if (@file_exists("../web/dbinfo.php")) {
include ("../web/dbinfo.php");   }
else {
// Database Error
echo "<BR><BR><CENTER><H4>A Database Connection Could Not Be Established <BR><BR></H4></CENTER>";
exit;   }

?>