<?php
/*
  File Name: uploadimage.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$imageid = $_GET['imageid'];
$identifier = $imageid[0];
$imageid = str_replace($identifier, "", $imageid);
$filename= $_FILES['userfile']['name'];
$filesize = $_FILES['userfile']['size'];
$filetype = $_FILES['userfile']['type'];
$tempname = $_FILES['userfile']['tmp_name'];

if ($identifier == "p")  {
$location = "uploadform.php?idenid=$imageid&type=p";
$tablename = "products";
$imagevar = "prodimage";
$idname = "prodid";
$picvar = "prodimage";
}
if ($identifier == "c")  {
$location = "uploadform.php?idenid=$imageid&type=c";
$tablename = "categories";
$imagevar = "catimage";
$idname = "catid";
$picvar = "catimage";
}
include("dbinfo.php");

if ($filename == "")   {
$select = "select * from $tablename where $idname = '$imageid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$oldpic = $newarray[$picvar];
if ($oldpic != "")  {
if (file_exists("../images/$oldpic")) {
unlink ("../images/$oldpic"); }  }

$update = "update $tablename set $imagevar = '' where $idname = '$imageid'";
mysql_query($update, $conn);
header("location:$location" . "&imgup=2");      
exit;       }

// first see if there is an old file to delete
$select = "select * from $tablename where $idname = '$imageid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$oldpic = $newarray[$picvar];
if ($oldpic != "")  {
if (file_exists("../images/$oldpic")) {
unlink ("../images/$oldpic"); }  }

$update = "update $tablename set $imagevar = '$filename' where $idname = '$imageid'";
mysql_query($update, $conn);
if (move_uploaded_file ($tempname, "../images/$filename"))  {
// success
header("location:$location" . "&imgup=1");
}
else   {   header("location:$location" . "&imgup=0");    }

?>
