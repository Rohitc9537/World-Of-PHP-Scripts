<?php
/*
  File Name: orders.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$orderid = $_GET['orderid'];
$controlnum = 1; 
include("controlheader.php");
if ($orderid == "")   {

$todaydate = time();
$todaydatearray = getdate ($todaydate);
$todaymonth = $todaydatearray['mon'];
$todayday = $todaydatearray['mday'];
$todayyear = $todaydatearray['year'];
$todayformat = $todayyear . "-" . $todaymonth . "-" . $todayday;
$todaydate = strtotime($todayformat);
$tomorrow = $todaydate + 86400;
$fromrangemonth = $_POST[fromrangemonth]; 
$fromrangeday = $_POST[fromrangeday]; 
$fromrangeyear = $_POST[fromrangeyear]; 
$fromrangeformat = $fromrangeyear . "-" . $fromrangemonth . "-" . $fromrangeday;
$fromrangedisplay = $fromrangemonth . " / " . $fromrangeday . " / " . $fromrangeyear;
$fromrangetimestamp = strtotime($fromrangeformat);
if ($fromrangeformat == "--") { $fromrangetimestamp = $todaydate;  }
if ($fromrangetimestamp > $todaydate) { 
$fromrangedisplay = $todaymonth . " / " . $todayday . " / " . $todayyear;
$fromrangemonth = $todaymonth; 
$fromrangeday = $todayday; 
$fromrangeyear = $todayyear; 
$fromrangetimestamp = $todaydate;  }
$torangemonth = $_POST[torangemonth]; 
$torangeday = $_POST[torangeday]; 
$torangeyear = $_POST[torangeyear]; 
$torangeformat = $torangeyear . "-" . $torangemonth . "-" . $torangeday;
$torangedisplay = $torangemonth . " / " . $torangeday . " / " . $torangeyear;
$torangetimestamp = strtotime($torangeformat);
$torangetimestamp = $torangetimestamp + 86400;
if ($torangetimestamp > $tomorrow) { 
$torangedisplay = $todaymonth . " / " . $todayday . " / " . $todayyear;
$torangemonth = $todaymonth; 
$torangeday = $todayday; 
$torangeyear = $todayyear; 
$torangetimestamp = $tomorrow;  }

if ($torangeformat == "--") { 
$torangetimestamp = $tomorrow;  }

if ($fromrangeformat == "--") {
$rangetext = "Showing Orders From Today";   }
else {
$rangetext = "Showing Orders From $fromrangedisplay to $torangedisplay";   }
if ($fromrangeday == "") { $fromrangeselectday = $todayday;  }
else { $fromrangeselectday = $fromrangeday;  }
if ($fromrangemonth == "") { $fromrangeselectmonth = $todaymonth;  }
else { $fromrangeselectmonth = $fromrangemonth;  }
if ($fromrangeyear == "") { $fromrangeselectyear = $todayyear;  }
else { $fromrangeselectyear = $fromrangeyear;  }

if ($torangeday == "") { $torangeselectday = $todayday;  }
else { $torangeselectday = $torangeday;  }
if ($torangemonth == "") { $torangeselectmonth = $todaymonth;  }
else { $torangeselectmonth = $torangemonth;  }
if ($torangeyear == "") { $torangeselectyear = $todayyear;  }
else { $torangeselectyear = $torangeyear;  }


echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Check Orders<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><form action='orders.php' method='post'><table width='100%' border='0' cellspacing='2' cellpadding='2'><tr><td width='40%' align='center'><font size='3'><B>Select Date Range For Statistics</B></font><BR><BR><input type='submit' value='Get Stats From Selected Period'></td><td width='60%' align='center'>
<font size='3' face='arial'><B>Month -- Day -- Year</B></font><BR><select name='fromrangemonth'>";
for ($tempi = 1; $tempi < 13; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $fromrangeselectmonth) { echo " selected"; }
echo ">$tempi</option>";   }
echo "</select> &nbsp; <select name='fromrangeday'>";
for ($tempi = 1; $tempi < 32; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $fromrangeselectday) { echo " selected"; }
echo ">$tempi</option>";   }
echo "</select> &nbsp; <select name='fromrangeyear'>";
for ($tempi = 2005; $tempi < $todayyear + 1; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $fromrangeselectyear) { echo " selected"; }

echo ">$tempi</option>";   }
echo "</select><BR><font size='4' face='arial'>To</font><BR>
<select name='torangemonth'>";
for ($tempi = 1; $tempi < 13; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $torangeselectmonth) { echo " selected"; }
echo ">$tempi</option>";   }
echo "</select> &nbsp; <select name='torangeday'>";
for ($tempi = 1; $tempi < 32; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $torangeselectday) { echo " selected"; }
echo ">$tempi</option>";   }
echo "</select> &nbsp; <select name='torangeyear'>";
for ($tempi = 2005; $tempi < $todayyear + 1; $tempi++) {
echo "<option value='$tempi'";
if ($tempi == $torangeselectyear) { echo " selected"; }

echo ">$tempi</option>";   }
echo "</select></td></tr></table></form><HR><font size='4' face='arial'><B>$rangetext</B></font><BR><BR>";

include("dbinfo.php");
$select = "select * from orders where orderdate >= '$fromrangetimestamp' && orderdate <= '$torangetimestamp'";
$answer = mysql_query($select, $conn);

if (mysql_num_rows($answer) < 1) {
echo "<BR><BR><font size='3' face='arial'><b>There were no orders in the selected time period.</b></font><BR><BR>";   }
else  {
echo "<table width='100%' cellpadding='7' border='1'><tr><td width='40%' align='center' valign='middle'>Customer</td><td width='20%' align='center' valign='middle'>Status</td><td width='20%' align='center' valign='middle'>Date</td><td width='20%' align='center' valign='middle'>Total Price</td></tr>";   }

while ($newarray = mysql_fetch_array($answer))   {
$memberid[$controlnum] = $newarray[memberid];
$select2 = "select * from members where memberid = '$memberid[$controlnum]'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$firstname[$controlnum] = $newarray2[firstname];
$lastname[$controlnum] = $newarray2[lastname];

$orderid[$controlnum] = $newarray[id];
$orderstatus[$controlnum] = $newarray[status];
$ordertotal[$controlnum] = $newarray[total];
$tax = $newarray[taxcost];
$shipping = $newarray[shipcost];
$subtotal[$controlnum] = $ordertotal[$controlnum] + $tax + $shipping;
$ordertotal[$controlnum] = number_format ($ordertotal[$controlnum], 2);
$subtotal[$controlnum] = number_format ($subtotal[$controlnum], 2);
$tax = number_format ($tax, 2);
$shipping = number_format ($shipping, 2);
$orderdate[$controlnum] = $newarray[orderdate];
$datearray = getdate ($orderdate[$controlnum]);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$orderdate[$controlnum] = "$month / $day / $year";
$controlnum = $controlnum + 1;   }

for ($i = 1; $i < $controlnum; $i++)   {
echo "<tr><td width='40%' align='center' valign='middle'><a href='orders.php?orderid=$orderid[$i]'>$firstname[$i] $lastname[$i]</a></td><td width='20%' align='center' valign='middle'><a href='orders.php?orderid=$orderid[$i]'>$orderstatus[$i]</a></td><td width='20%' align='center' valign='middle'><a href='orders.php?orderid=$orderid[$i]'>$orderdate[$i]</a></td><td width='20%' align='center' valign='middle'><a href='orders.php?orderid=$orderid[$i]'>$ordertotal[$i]</a></td></tr>";   }

echo "</table><BR><BR><BR><BR>";

} // ends if orderid is blank
else   {
include("dbinfo.php");
$select = "select * from orders where id = '$orderid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];
$ordertotal = $newarray[total];
$status = $newarray[status];
$shipaddress = $newarray[shipaddress];
$paymethod = $newarray[paymethod];
$orderdate = $newarray[orderdate];
$datearray = getdate ($orderdate);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$orderdate = "$month / $day / $year";
$confirmcode = $newarray[confirmcode];
$taxcost = $newarray[taxcost];
$receipt = $newarray[receipt];
$comments = $newarray[comments];
$comments = str_replace("
", "<br>", $comments);
$shipcost = $newarray[shipcost];
$promodiscount = $newarray[promodiscount];
$subtotal = $ordertotal - $shipcost - $taxcost;
$subtotal = number_format ($subtotal, 2);
$shipcost = number_format ($shipcost, 2);
$taxcost = number_format ($taxcost, 2);
$ordertotal = number_format ($ordertotal, 2);
$select2 = "select * from members where memberid = '$memberid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$firstname = $newarray2[firstname];
$lastname = $newarray2[lastname];

echo "<style>.viewcart { font-family : Verdana, Arial, sans-serif; font-size : 15px; color : #000000; font-weight: bold; }</style><TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Check Orders<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><form action='updateorders.php?orderid=$orderid' method='post'><table width='100%' cellpadding='7' border='1'><tr><td width='33%' align='center' valign='middle'><font size='4'>Update Status</font></td><td width='33%' align='center' valign='middle'><select name='status'><option value='Pending'";
if ($status == "Pending")   {   echo " selected";     }
echo ">Pending</option><option value='Processed'";
if ($status == "Processed")   {   echo " selected";     }
echo ">Processed</option><option value='Delivered'";
if ($status == "Delivered")   {   echo " selected";     }

echo ">Delivered</option><option value='Waiting For Payment'";
if ($status == "Waiting For Payment")   {   echo " selected";     }
echo ">Waiting For Payment</option>

</select></td><td width='33%' align='center' valign='middle'><input type='submit' value='Update Status'></td></tr></table><BR><table border='1' cellpadding='7' class='viewcart' width='97%'><tr><td width='45%' align='left' valign='top'>Customer Name:<BR>$firstname $lastname<BR><BR><BR>Shipping Address:<BR><BR>$shipaddress</td><td width='55%' align='left' valign='top'>Subtotal : $ $subtotal<BR><BR>Shipping And Handling: $ $shipcost<BR><BR>Tax: $ $taxcost<BR><BR><HR><BR>Order Total: $ $ordertotal</td></tr></table><BR><hr><BR><table border='1' cellpadding='7' class='viewcart' width='97%'><tr><td width='45%' align='left' valign='top'>Order Date: <hR>$orderdate<BR><BR><BR>Payment Method: <hR>$paymethod<BR><BR><BR>Confirmation Code: <hR>$confirmcode<BR><BR><BR>Additional Comments:<hR>$comments<BR><BR><BR><BR></td><td width='55%' align='left' valign='top'><CENTER>Products Ordered</CENTER><HR>$receipt</td></tr></table>";

}
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>