<?php
/*
  File Name: countid.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/
/*

The purpose of this file is to allow you to register your website for a free account at AFCommerce.com. By becoming a registered user you become eligible to have a link to your website put on www.afcommerce.com as a live online store. We do not link to every site, only ones that we feel really show the power of the cart or a unique look. Please do not be insulted if we do not select your site to be displayed in a prime location, I do not choose who is linked to solely on the look of the store. There are many other factors in determining who will be chosen, such as whether you properly keep the copyrights in place, how much you participate in the community, new features that you add, and whether you keep the advertisements inside the administration tool. If you keep the ads inside the admin tool, I will give you a link somewhere on the AFCommerce website, on a page with (hopefully) a decent page rank as a thank you. This cart was released on August 10, 2005, so if you are viewing this within the first few months after the release, there may not be a high rank on the support site yet. However time and experience have proven that free open source communities have very high search engine rankings, so a link from the support site will help you in one way or another. How this works will be explained in more detail on the support site in the next few months.

All you need to understand at this point is that if you register your store, and keep the copyrights and advertisements in place, you will be assigned an id number to put in to this file below. The id number will only be used by an automated system to prove to us that you are in fact keeping the ads inside your admin tool which will qualify your site for a link.

The advertisements are not generated from your website, therefore they do not use your bandwidth or disk space. They are remotely called from a file that is hosted on the afcommerce.com website and are displayed in a framed window.

Finally, a note about the advertisements. I want it to be very clear to everyone using this software that I would NEVER do anything to violate any person's privacy in any way whatsoever. I am very ethical in all of my internet practices, and I believe that everyone else should be as well. It does not make sense for me to cause problems for other people since my main objective in all of my projects is to help other developers, and make a name for myself. I certainly would never want to be known as unethical or unprofessional, I am 27 years old and intend on releasing many other development tools in the future. Any money I make on these advertisements will go towards making new features for this software and making new software in the future. Also, please understand that this advertising space is only valuable to me since no advertiser would allow you to insert ads in to a page that only you (or your employees) have access to. So if you remove the ads the footer will probably be left blank anyway. I will also try to put advertisements in there that you would be interested in, so that the advertisers get their money's worth, and you could possibly find products and services that would help you. I also do not encourage you to visit the advertisers unless you are actually interested in them. I want to be fair to everyone, and the advertisers should be treated as fairly as I treat the community. Thank you for using AFCommerce.

Paul Crinigan

*/

// replace the zero with the id number given to you 
// after you register on the support site

$countid = 0;

?>
