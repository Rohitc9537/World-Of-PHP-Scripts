<?php
/*
  File Name: controlheader.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/
include ("countid.php");
?>
<HTML><HEAD><TITLE>Administration Area</TITLE></HEAD><style type='text/css'><!-- body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #330099; text-decoration: none}
a:visited { color: #330099; text-decoration: none}
a:active { color: #330099; text-decoration: underline}
a:hover { color: #ff0000; text-decoration: underline}
--></style><BODY TEXT="#000000"><TABLE WIDTH="100%" bgcolor='#ffffff'><TR ALIGN="CENTER" VALIGN="MIDDLE"><TD WIDTH="100%" ALIGN="CENTER" VALIGN="MIDDLE"><iframe width='770' height='115' frameborder='0' scrolling='no' src='http://afcommerce.com/ab.php?countid=$countid'></iframe></TD></TR></TABLE><TABLE WIDTH="100%"><TR ALIGN="CENTER" VALIGN="MIDDLE"><TD WIDTH="20%" ALIGN="CENTER" VALIGN="top">
<BR><BR><BR><A HREF="index.php"><font size='1' face='arial'><b>Admin Home Page</b></font></A><BR><BR><BR><A HREF="/" target="_blank"><font size='1' face='arial'><b>Preview Your Store</b></font></A><BR><BR><BR><A HREF="http://www.afcommerce.com/carttutorial.php" target='_blank'><font size='1' face='arial'><b>Shopping Cart Tutorial</b></font></A><BR><BR><BR><A HREF="http://www.afcommerce.com/customizationguide.php" target='_blank'><font size='1' face='arial'><b>Customization Guide</b></font></A><BR><BR><BR>

<A HREF="http://amazingflash.com/forum/" target='_blank'><font size='1' face='arial'><b>Support Forums</b></font></A><BR><BR><BR>

<A HREF="http://amazingflash.com/signup.html" target='_blank'><font size='1' face='arial'><b>Free Enhanced Admin Area</b></font></A><BR><BR><BR>

<A HREF="http://amazingflash.com/cms.html" target='_blank'><font size='1' face='arial'><b>Free Content Management System</b></font></A><BR><BR><BR>

<!-- This is the copyright announcement for AFCommerce. You must keep this link in place to comply with our user agreement. It is a small link that gives credit to the hard work that went in to developing this software. Thank you. -->
<BR><BR><a href='http://www.afcommerce.com/' target='_blank'><font size='1' face='arial'><b>Powered by AFCommerce.com</b></font></a>
<BR><BR><BR>
</TD>

<?php
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
