<?php 
/*
  File Name: updateshipping.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$taxshipping = $_POST['taxshipping'];
$update = "update config set varvalue = '$taxshipping' where varname = 'taxshipping'";
mysql_query($update, $conn); 
$pickupshipping = $_POST['pickupshipping'];
$update = "update config set varvalue = '$pickupshipping' where varname = 'pickupshipping'";
mysql_query($update, $conn); 
$flatrate = $_POST['flatrate'];
$update = "update config set varvalue = '$flatrate' where varname = 'flatrate'";
mysql_query($update, $conn); 
$peritem = $_POST['peritem'];
$update = "update config set varvalue = '$peritem' where varname = 'peritem'";
mysql_query($update, $conn);
$byweight = $_POST['byweight'];
$update = "update config set varvalue = '$byweight' where varname = 'byweight'";
mysql_query($update, $conn); 
$percentagerate = $_POST['percentagerate'];
$update = "update config set varvalue = '$percentagerate' where varname = 'percentagerate'";
mysql_query($update, $conn); 
$shipmethod = $_POST['shipmethod'];
$update = "update config set varvalue = \"$shipmethod\" where varname = 'shipmethod'";
mysql_query($update, $conn); 
$handling = $_POST['handling'];
$update = "update config set varvalue = '$handling' where varname = 'handling'";
mysql_query($update, $conn); 
header("location:editshipping.php");
?>
