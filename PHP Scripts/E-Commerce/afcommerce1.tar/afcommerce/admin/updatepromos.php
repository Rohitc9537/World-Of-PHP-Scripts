<?php
/*
  File Name: updatepromos.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from promos";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {

$promoid = $newarray[id];
$temp1 = "promocode" . $promoid;
$promocode = $_POST[$temp1];
$temp2 = "discount" . $promoid;
$discount = $_POST[$temp2];

$update = "update promos set promocode = \"$promocode\", discount = '$discount' where id = '$promoid'";
mysql_query($update, $conn);       }

$select = "select * from promos";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$promoid = $newarray[id];
$temp3 = "remove" . $promoid;
$remove = $_POST[$temp3];

if ($remove == "on")   {
$delete = "DELETE FROM promos where id = '$promoid'";
mysql_query($delete, $conn); 
      }    }
header("location:editpromos.php");
?>
