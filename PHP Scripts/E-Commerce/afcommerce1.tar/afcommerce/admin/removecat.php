<?php
/*
  File Name: removecat.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$maincat = $_POST[maincat];
include("dbinfo.php");
$select = "select * from categories";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$catid = $newarray[catid];
$temp3 = "remove" . $catid;
$remove = $_POST[$temp3];

if ($remove == "on")   {
$select2 = "select * from categories where catid = '$catid'";
$answer2 = mysql_query($select, $conn);
$newarray2 = mysql_fetch_array($answer2);
$oldpic = $newarray2[catimage];
if ($oldpic != "")  {
if (file_exists("../images/$oldpic")) {
unlink ("../images/$oldpic");     }  }

$delete = "DELETE FROM categories where catid = '$catid'";
mysql_query($delete, $conn); 
$delete = "DELETE FROM categories_descript where catid = '$catid'";
mysql_query($delete, $conn); 
}    }	  
	  
if ($maincat == "")   {
header("location:editcat.php");  }
else   {
header("location:editcat.php?catid=$maincat");  }

?>
