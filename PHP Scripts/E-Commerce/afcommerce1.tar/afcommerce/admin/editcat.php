<?php
/*
  File Name: editcat.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$catid = $_GET['catid'];
include("dbinfo.php");
$select3 = "select * from config where varname = 'defaultlang'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$langid = $newarray3[varvalue];
include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><script>
function uploadpic(id, typeid)   {
  url = 'uploadform.php?type=' + typeid + '&idenid=' + id;
 newwindow=window.open(url,'','location=no,toolbar=no,scrollbars=yes,height=450,width=650,left=50,top=50') 
}</script>
<BR><H2>Edit Main Categories<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR>";

if ($catid == "")   {
$controlnum = 0;
include("dbinfo.php");
// adds new main category
if ($_POST[add] == "1")   {
$dateadded = time();
$insertrow = "insert into categories values ('', '', '0', '', '$dateadded', '')";
mysql_query($insertrow, $conn);

// get id
$highnum = 0;
$select = "select * from categories";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$tempid = $newarray[catid];      
if ($highnum < $tempid)  {
$highnum = $tempid;    }  }
$tempid = $highnum;
$catid = $tempid;
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$templangid = $newarray[langid];
$insertrow = "insert into categories_descript values ('', '$catid', '$templangid', '', '')";
mysql_query($insertrow, $conn);   }
$_POST[add] = 0;
}   }  // ends add new main category

if ($catid == "")   {
$select = "select * from categories where level = '0' order by dateadded ASC";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$controlnum = $controlnum + 1;
$mnum = $newarray[num];
$mcatid[$controlnum] = $newarray[catid];
$select2 = "select * from categories_descript where catid = '$mcatid[$controlnum]' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$mcatname[$controlnum] = $newarray2[catname];   }

@array_multisort($mcatname, SORT_ASC, SORT_STRING, $mcatid);

echo "<form action='removecat.php' method='post'><table width='100%' border='1' cellpadding='7'><tr><td width='70%' align='center' valign='middle'><font size='4'>Select A Category</font></td><td width='30%' align='center' valign='middle'><font size='3'>( Remove ) </font></td></tr>";
for ($i = 0; $i < $controlnum; $i++)   {
echo "<tr><td width='70%' align='center' valign='middle'><a href='editcat.php?catid=$mcatid[$i]'><font size='4'>$mcatname[$i]</font></a></td><td width='30%' align='center' valign='middle'><input type='checkbox' name='remove$mcatid[$i]'></td></tr>";   }

echo "</table><BR><BR><BR><table width='95%'><tr><td width='50%' align='center'><input type='submit' value='Remove Selected'></form></td><td width='50%' align='center'><form action='editcat.php' method='post'><input type='hidden' name='add' value='1'><input type='submit' value='Add New Main Category'></form></td></tr></table>";
}    // ends if catid is blank

else    {
// catid has a value
include("dbinfo.php");
// adds new sub category
if ($_POST[add] == "1")   {
$dateadded = time();
$insertrow = "insert into categories values ('', '', '$catid', '', '$dateadded', '')";
mysql_query($insertrow, $conn);

// get id
$highnum = 0;
$select = "select * from categories";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$tempid = $newarray[catid];      
if ($highnum < $tempid)  {
$highnum = $tempid;    }  }
$tempid = $highnum;
$catid = $tempid;
$select2 = "select * from languages where status = '1'";
$answer2 = mysql_query($select2, $conn);
while ($newarray2 = mysql_fetch_array($answer2))  {
$templangid = $newarray2[langid];
$insertrow = "insert into categories_descript values ('', '$catid', '$templangid', '', '')";  }
mysql_query($insertrow, $conn);
} // ends add new sub category

$select = "select * from categories where catid = '$catid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$catimage = $newarray[catimage];
$level = $newarray[level];

if ($level != "0")   {
$maincat = $level;  }

echo "<A HREF='javascript:uploadpic(\"$catid\", \"c\")'><font size='5'>Upload Image</font></A><BR><BR><table width='100%' cellpadding='7' border='0'><form action='updatecat.php?catid=$catid' method='post'><input type='hidden' name='maincat' value='$maincat'>";

$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$mlangid = $newarray[langid];
$langname = $newarray[langname];
$select2 = "select * from categories_descript where catid = '$catid' && langid = '$mlangid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$catname = $newarray2[catname];
$catdescript = $newarray2[catdescript];

echo "<tr><td width='50%' align='center' valign='middle'><BR></td><td width='50%' align='center' valign='middle'><BR></td></tr><tr><td width='50%' align='center' valign='middle'><font size='4'>Category Name:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname )</B></font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"catname$mlangid\" value=\"$catname\"></td></tr><tr><td width='50%' align='center' valign='middle'><font size='4'>Category Description:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname )</B></font></td><td width='50%' align='center' valign='middle'><textarea rows='5' cols='35' name='catdescript$mlangid'>$catdescript</textarea></td></tr>";     }


echo "</table><BR><BR><BR><input type='submit' value='Update Category'><BR><BR><BR><HR></form><BR>";

$controlnum = 0;
$select = "select * from categories where level = '$catid'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$controlnum = $controlnum + 1;
$snum = $newarray[num];
$scatid[$controlnum] = $newarray[catid];
$select2 = "select * from categories_descript where catid = '$scatid[$controlnum]' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$scatname[$controlnum] = $newarray2[catname];   }
if ($controlnum != "0")   {
echo "<form action='removecat.php' method='post'><input type='hidden' name='maincat' value='$catid'><table width='100%' border='1' cellpadding='7'><tr><td width='70%' align='center' valign='middle'><font size='4'>Select A Sub Category</font></td><td width='30%' align='center' valign='middle'><font size='3'>( Remove ) </font></td></tr>";
for ($i = 1; $i < $controlnum + 1; $i++)   {
echo "<tr><td width='70%' align='center' valign='middle'><a href='editcat.php?catid=$scatid[$i]'><font size='4'>$scatname[$i]</font></a></td><td width='30%' align='center' valign='middle'><input type='checkbox' name='remove$scatid[$i]'></td></tr>";   }
echo "</table><BR><BR>";  }


echo "<BR><table width='95%'><tr>";
if ($controlnum != "0")   {
echo "<td width='50%' align='center'><input type='submit' value='Remove Selected'></form></td>";  }

echo "<td width='50%' align='center'><form action='editcat.php?catid=$catid' method='post'><input type='hidden' name='add' value='1'><input type='submit' value='Add New Sub Category'></form></td></tr></table><BR><BR><BR>";   

}
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
