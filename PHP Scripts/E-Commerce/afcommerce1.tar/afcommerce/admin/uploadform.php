<?php
/*
  File Name: uploadform.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$idenid = $_GET['idenid'];
echo "<CENTER><BR><H2>Upload New Image</H2>";

if ($imgup == "0") { 
echo "<font size='4' face='arial' color='#ff0000'><b>Upload Failure !</b></font><BR><BR>";  }

if ($imgup == "1") { 
echo "<font size='4' face='arial' color='#ff0000'><b>Upload Successful</b></font><BR><BR>";  }

if ($imgup == "2") { 
echo "<font size='4' face='arial' color='#ff0000'><b>Picture Deleted</b></font><BR><BR>";  }

echo "<font size='3' face='arial'><b>To delete an existing image, simply push the<BR> upload button without selecting an image.</b></font><BR><BR><table width='100%' cellpadding='7' border='0'>";

if ($_GET['type'] == "p") {

$select = "select * from products where prodid = '$idenid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayimage = $newarray[prodimage];

echo "<tr><td width='50%' align='center' valign='middle'><font size='4'><form enctype='multipart/form-data' action='uploadimage.php?imageid=p$idenid' method='post'>File Name:</font><BR><BR><font size='2' color='#ff0000'><B>(Click Browse To Find Pictures On Your Computer)</B><BR><BR></td><td width='50%' align='center' valign='middle'><BR><input size='15' name='userfile' type='file' value=''><BR><BR><input type='submit' value='Upload Image'></font><BR><BR></td></tr></table><BR><BR>";     }

else {

$select = "select * from categories where catid = '$idenid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayimage = $newarray[catimage];

echo "<tr><td width='50%' align='center' valign='middle'><font size='4'>Category Image:</font><BR><BR><font size='2' color='#ff0000'><B>(Click Browse To Find Pictures On Your Computer)</B></font><BR><BR></td><td width='50%' align='center' valign='middle'><form enctype='multipart/form-data' action='uploadimage.php?imageid=c$idenid' method='post'><input size='12' name='userfile' type='file' value=''><BR><BR><input type='submit' value='Upload Image'><BR><BR></form></td></tr></table><BR><BR>";  }

$maxheight = 200;
$maxwidth = 500;
$imagepath = "../images/$displayimage";
$imagearray = @getimagesize ($imagepath);
$width = $imagearray[0];
$height = $imagearray[1];

$newwidth = $width;
$newheight = $height;

if ($height > $maxheight) { 
$newheight = $maxheight;
// make the width proportional
$difference = $width / $height;
$newwidth = $difference * $newheight;   }

if ($newwidth > $maxwidth) { 
$newwidth = $maxwidth;
// make the height proportional
$newheight = $newwidth / $difference;   }

$width = floor($newwidth);
$height = floor($newheight);

if ($displayimage != "")   {
echo "<IMG SRC='../images/$displayimage' border='0' height='$height'><BR><BR>";  }

echo "<BR><BR>";
?>

<!-- This is the copyright announcement for AFCommerce. You must keep this link in place to comply with our user agreement. It is a small link that gives credit to the hard work that went in to developing this software. Thank you. -->
<BR><BR><a href='http://www.afcommerce.com/' target='_blank'><font size='1' face='arial'><b>Powered by AFCommerce.com</b></font></a><BR><BR>

