<?php
/*
  File Name: editpayment.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$paymethod = $_GET['paymethod'];
include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Edit Payment Configuration<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR>"; 
include("dbinfo.php");
$select = "select * from paymethod";
$answer = mysql_query($select, $conn);
echo "<table width='80%' cellpadding='7' border='1'>";

if ($paymethod == "")   {
while ($newarray = mysql_fetch_array($answer))   {
$type = $newarray['type'];
$payid = $newarray['id'];

echo "<tr><td width='50%' align='center' valign='middle'><font size='4'>$type</font></td><td width='50%' align='center' valign='middle'><form action='editpayment.php?paymethod=$type' method='post'><BR><input type='submit' value='Edit Configuration'></form></td></tr>";


}   }// ends if blank
else   {
$select = "select * from paymethod where type = '$paymethod'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))    {
$description = $newarray['description'];
$info1 = $newarray['info1'];
$info2 = $newarray['info2'];
$info3 = $newarray['info3'];
$info4 = $newarray['info4'];
$info1name = $newarray['info1name'];
$info2name = $newarray['info2name'];
$info3name = $newarray['info3name'];
$info4name = $newarray['info4name'];
$status = $newarray['status'];
$type = $newarray['type'];

echo "<tr><td width='50%' align='center' valign='middle'><form action='updatepayment.php?paymethod=$type' method='post'><font size='4'>Status:</font></td><td width='50%' align='center' valign='middle'><table width='100%'><tr><td align='center'><input type='radio' name='status' value='1'";
if ($status == "1")   {   echo " checked";   }
echo "> Enabled </td><td align='center'><input type='radio' name='status' value='0'";
if ($status == "0")   {   echo " checked";   }
echo "> Disabled</td></tr></table></td></tr>";



echo "<tr><td width='50%' align='center' valign='middle'><font size='4'>Description:</font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"description\" value=\"$description\"></td></tr>";
if ($info1name != "")   {
echo "<tr><td width='50%' align='center' valign='middle'><form action='updatepayment.php?paymethod=$type' method='post'><font size='4'>$info1name:</font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"info1\" value=\"$info1\"></td></tr>";   }
if ($info2name != "")   {
echo "<tr><td width='50%' align='center' valign='middle'><form action='updatepayment.php?paymethod=$type' method='post'><font size='4'>$info2name:</font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"info2\" value=\"$info2\"></td></tr>";   }
if ($info3name != "")   {
echo "<tr><td width='50%' align='center' valign='middle'><form action='updatepayment.php?paymethod=$type' method='post'><font size='4'>$info3name:</font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"info3\" value=\"$info3\"></td></tr>";   }
if ($info4name != "")   {
echo "<tr><td width='50%' align='center' valign='middle'><form action='updatepayment.php?paymethod=$type' method='post'><font size='4'>$info4name:</font></td><td width='50%' align='center' valign='middle'><input size=\"25\" name=\"info4\" value=\"$info4\"></td></tr>";   }

echo "</table><BR><BR><BR><input type='submit' value='Update Payment Module'></form><BR><BR>";
}
}

echo "</table>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>