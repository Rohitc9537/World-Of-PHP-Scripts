<?php 
/*
  File Name: updatemystore.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$quantityfeature = $_POST['quantityfeature'];
$update = "update config set varvalue = '$quantityfeature' where varname = 'quantityfeature'";
mysql_query($update, $conn);
$displayoutofstock = $_POST['displayoutofstock'];
$update = "update config set varvalue = \"$displayoutofstock\" where varname = 'displayoutofstock'";
mysql_query($update, $conn);
$defaultlang = $_POST['defaultlang'];
$update = "update config set varvalue = '$defaultlang' where varname = 'defaultlang'";
mysql_query($update, $conn);
$storename = $_POST['storename'];
$update = "update config set varvalue = \"$storename\" where varname = 'storename'";
mysql_query($update, $conn);
$storeaddress = $_POST['storeaddress'];
$update = "update config set varvalue = \"$storeaddress\" where varname = 'storeaddress'";
mysql_query($update, $conn);
$storeemail = $_POST['storeemail'];
$update = "update config set varvalue = \"$storeemail\" where varname = 'storeemail'";
mysql_query($update, $conn);
$storephone = $_POST['storephone'];
$update = "update config set varvalue = \"$storephone\" where varname = 'storephone'";
mysql_query($update, $conn);
$storefax = $_POST['storefax'];
$update = "update config set varvalue = \"$storefax\" where varname = 'storefax'";
mysql_query($update, $conn);
$displaymanufactures = $_POST['displaymanufactures'];
$update = "update config set varvalue = '$displaymanufactures' where varname = 'displaymanufactures'";
mysql_query($update, $conn);
$productsperrow = $_POST['productsperrow'];
$update = "update config set varvalue = '$productsperrow' where varname = 'productsperrow'";
mysql_query($update, $conn);
$productreviews = $_POST['productreviews'];
$update = "update config set varvalue = '$productreviews' where varname = 'productreviews'";
mysql_query($update, $conn);
$bestsellers = $_POST['bestsellers'];
$update = "update config set varvalue = '$bestsellers' where varname = 'bestsellers'";
mysql_query($update, $conn);

$whatsnew = $_POST['whatsnew'];
$update = "update config set varvalue = '$whatsnew' where varname = 'whatsnew'";
mysql_query($update, $conn);
$cartimages = $_POST['cartimages'];
$update = "update config set varvalue = '$cartimages' where varname = 'cartimages'";
mysql_query($update, $conn);
$numperpage = $_POST['numperpage'];
$update = "update config set varvalue = '$numperpage' where varname = 'numperpage'";
mysql_query($update, $conn);
$displayshipping = $_POST['displayshipping'];
$update = "update config set varvalue = '$displayshipping' where varname = 'displayshipping'";
mysql_query($update, $conn);
$displaytax = $_POST['displaytax'];
$update = "update config set varvalue = '$displaytax' where varname = 'displaytax'";
mysql_query($update, $conn);
$displayshipaddress = $_POST['displayshipaddress'];
$update = "update config set varvalue = '$displayshipaddress' where varname = 'displayshipaddress'";
mysql_query($update, $conn);
$displayshipandrefunds = $_POST['displayshipandrefunds'];
$update = "update config set varvalue = '$displayshipandrefunds' where varname = 'displayshipandrefunds'";
mysql_query($update, $conn);
$displayprivacypolicy = $_POST['displayprivacypolicy'];
$update = "update config set varvalue = '$displayprivacypolicy' where varname = 'displayprivacypolicy'";
mysql_query($update, $conn);
$promocodefeature = $_POST['promocodefeature'];
$update = "update config set varvalue = '$promocodefeature' where varname = 'promocodefeature'";
mysql_query($update, $conn);
$tellafriendfeature = $_POST['tellafriendfeature'];
$update = "update config set varvalue = '$tellafriendfeature' where varname = 'tellafriendfeature'";
mysql_query($update, $conn);
header("location:mystore.php");
?>
