<?php
/*
  File Name: mystore.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from config where varname = 'promocodefeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$promocodefeature = $newarray['varvalue'];

$select = "select * from config where varname = 'displayprivacypolicy'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayprivacypolicy = $newarray['varvalue'];

$select = "select * from config where varname = 'displayshipandrefunds'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipandrefunds = $newarray['varvalue'];

$select = "select * from config where varname = 'displayshipaddress'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipaddress = $newarray['varvalue'];

$select = "select * from config where varname = 'displaytax'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displaytax = $newarray['varvalue'];

$select = "select * from config where varname = 'quantityfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$quantityfeature = $newarray['varvalue'];

$select = "select * from config where varname = 'displayoutofstock'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayoutofstock = $newarray['varvalue'];

$select = "select * from config where varname = 'displayshipping'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displayshipping = $newarray['varvalue'];

$select = "select * from config where varname = 'displaymanufactures'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$displaymanufactures = $newarray['varvalue'];

$select = "select * from config where varname = 'numperpage'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$numperpage = $newarray['varvalue'];

$select = "select * from config where varname = 'productsperrow'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$productsperrow = $newarray['varvalue'];

$select = "select * from config where varname = 'productreviews'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$productreviews = $newarray['varvalue'];

$select = "select * from config where varname = 'bestsellers'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$bestsellers = $newarray['varvalue'];

$select = "select * from config where varname = 'whatsnew'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$whatsnew = $newarray['varvalue'];

$select = "select * from config where varname = 'cartimages'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$cartimages = $newarray['varvalue'];

$select = "select * from config where varname = 'storename'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storename = $newarray['varvalue'];

$select = "select * from config where varname = 'defaultlang'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$langid = $newarray['varvalue'];

$select = "select * from config where varname = 'storephone'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storephone = $newarray['varvalue'];

$select = "select * from config where varname = 'storeaddress'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeaddress = $newarray['varvalue'];

$select = "select * from config where varname = 'storefax'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storefax = $newarray['varvalue'];

$select = "select * from config where varname = 'storeemail'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeemail = $newarray['varvalue'];

$select = "select * from config where varname = 'tellafriendfeature'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$tellafriendfeature = $newarray['varvalue'];

include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><form action='updatemystore.php' method='post'><BR><H2>Edit My Store<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><table width='80%' cellspacing='7' cellpadding='7' border='1'><tr><td width='60%' align='left' valign='middle'><font size='4'>Store Name:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='storename' value='$storename'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Store Email Address:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='storeemail' value='$storeemail'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Store Mailing Address:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='storeaddress' value='$storeaddress'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Store Phone Number:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='storephone' value='$storephone'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Store Fax Number:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='storefax' value='$storefax'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Number of Products Per Page:</font></td><td width='40%' align='left' valign='middle'><input size='25' name='numperpage' value='$numperpage'></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Default Language:</font></td><td width='40%' align='left' valign='middle'><select name='defaultlang'>";
include("dbinfo.php");
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$templangid = $newarray[langid];
$templangname = $newarray[langname];
echo "<option value='$templangid'";
if ($langid == $templangid)  {  echo " selected";   }
echo ">$templangname</option>";    }

echo "</select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Product Manufactures:</font></td><td width='40%' align='left' valign='middle'><select name='displaymanufactures'><option value='0'>No</option><option value='1'";
if ($displaymanufactures == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Number of Products Per Row:</font></td><td width='40%' align='left' valign='middle'><select name='productsperrow'>";

for ($tempcount = 1; $tempcount < 6; $tempcount++) {
echo "<option value='$tempcount'";
if ($productsperrow == $tempcount) { echo " selected"; } 
echo ">$tempcount</option>"; }

echo "</select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Enable Quantity Feature:</font><BR><font size='2' color='#ff0000'><b>(Cart Will Keep Track Of Your Inventory)</b></font></td><td width='40%' align='left' valign='middle'><select name='quantityfeature'><option value='0'>No</option><option value='1'";
if ($quantityfeature == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Out Of Stock Products:</font></td><td width='40%' align='left' valign='middle'><select name='displayoutofstock'><option value='0'>No</option><option value='1'";
if ($displayoutofstock == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Enable Product Reviews:</font></td><td width='40%' align='left' valign='middle'><select name='productreviews'><option value='0'>No</option><option value='1'";
if ($productreviews == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Enable Best Sellers:</font></td><td width='40%' align='left' valign='middle'><select name='bestsellers'><option value='0'>No</option><option value='1'";
if ($bestsellers == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Newest Products:</font></td><td width='40%' align='left' valign='middle'><select name='whatsnew'><option value='0'>No</option><option value='1'";
if ($whatsnew == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Cart Images:</font></td><td width='40%' align='left' valign='middle'><select name='cartimages'><option value='0'>No</option><option value='1'";
if ($cartimages == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Enable Promotional Coupons:</font></td><td width='40%' align='left' valign='middle'><select name='promocodefeature'><option value='0'>No</option><option value='1'";
if ($promocodefeature == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Shipping Address:</font></td><td width='40%' align='left' valign='middle'><select name='displayshipaddress'><option value='0'>No</option><option value='1'";
if ($displayshipaddress == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Shipping Cost:</font></td><td width='40%' align='left' valign='middle'><select name='displayshipping'><option value='0'>No</option><option value='1'";
if ($displayshipping == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Shipping and<BR>Refunds Policy:</font></td><td width='40%' align='left' valign='middle'><select name='displayshipandrefunds'><option value='0'>No</option><option value='1'";
if ($displayshipandrefunds == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Privacy Policy:</font></td><td width='40%' align='left' valign='middle'><select name='displayprivacypolicy'><option value='0'>No</option><option value='1'";
if ($displayprivacypolicy == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Display Tax Cost:</font></td><td width='40%' align='left' valign='middle'><select name='displaytax'><option value='0'>No</option><option value='1'";
if ($displaytax == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr><tr><td width='60%' align='left' valign='middle'><font size='4'>Enable Tell A Friend Feature:</font></td><td width='40%' align='left' valign='middle'><select name='tellafriendfeature'><option value='0'>No</option><option value='1'";
if ($tellafriendfeature == "1") { echo " selected"; }

echo ">Yes</option></select></td></tr></table><BR><BR><BR><input type='submit' value='Update My Store'><BR><BR><BR></form>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
