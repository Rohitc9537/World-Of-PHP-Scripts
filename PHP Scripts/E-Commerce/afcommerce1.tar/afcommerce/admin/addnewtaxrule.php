<?php
/*
  File Name: addnewtaxrule.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$state = $_POST[state];
if ($state == "")   {
header("location:addtaxrules.php?action=add&fail=1");
exit;    }
$countryid = $_POST[zone_country_id];
if ($countryid == "")   {
header("location:addtaxrules.php?action=add&fail=1");
exit;    }
$taxrate = $_POST[taxrate];
$description = $_POST[description];
if ($description == "")   {
header("location:addtaxrules.php?action=add&fail=1");
exit;    }

$select = "select * from zones where zone_name = '$state' || zone_code = '$state'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$zone_country_id = $newarray[zone_country_id];
$zone_id = $newarray[zone_id];

if ($zone_id > 0) {       
$insert = "insert into taxzones values('', '$zone_id', '$taxrate', \"$description\", '$countryid')";
mysql_query($insert,$conn);
header("location:addtaxrules.php");   }

else {
header("location:addtaxrules.php?action=add&fail=1");
exit;    }
?>
