<?php
/*
  File Name: removetaxrule.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from taxzones";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$ruleid = $newarray[id];
$temp3 = "remove" . $ruleid;
$remove = $_POST[$temp3];

if ($remove == "on")   {
$delete = "DELETE FROM taxzones where id = '$ruleid'";
mysql_query($delete, $conn); 
      }    }
header("location:addtaxrules.php");

?>
