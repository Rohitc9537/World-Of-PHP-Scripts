<?php
/*
  File Name: updatepayment.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$paymethod = $_GET['paymethod'];
include("dbinfo.php");
$description = $_POST['description'];
$status = $_POST['status'];
$info1 = $_POST['info1'];
$info2 = $_POST['info2'];
$info3 = $_POST['info3'];
$info4 = $_POST['info4'];

$update = "update paymethod set info1 = \"$info1\", info2 = \"$info2\", info3 = \"$info3\", info4 = \"$info4\", status = '$status', description = \"$description\" where type = \"$paymethod\"";
mysql_query($update, $conn);
header("location:editpayment.php?paymethod=$paymethod");
?>
