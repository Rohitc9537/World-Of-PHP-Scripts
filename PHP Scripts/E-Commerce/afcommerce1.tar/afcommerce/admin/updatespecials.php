<?php
/*
  File Name: updatespecials.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from specials";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {

$specialid = $newarray[id];
$temp1 = "prodid" . $specialid;
$prodid = $_POST[$temp1];
$temp2 = "newprice" . $specialid;
$newprice = $_POST[$temp2];

$update = "update specials set prodid = '$prodid', newprice = '$newprice' where id = '$specialid'";
mysql_query($update, $conn);       }

$select = "select * from specials";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$specialid = $newarray[id];
$temp3 = "remove" . $specialid;
$remove = $_POST[$temp3];

if ($remove == "on")   {
$delete = "DELETE FROM specials where id = '$specialid'";
mysql_query($delete, $conn); 
      }    }
header("location:editspecials.php");
?>
