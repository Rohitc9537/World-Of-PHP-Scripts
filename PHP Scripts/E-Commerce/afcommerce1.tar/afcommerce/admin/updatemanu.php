<?php 
/*
  File Name: updatemanu.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from manufactures";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$manid = $newarray[manid];
$temp = "manname" . $manid;
$manname = $_POST[$temp];

$update = "update manufactures set manname = \"$manname\" where manid = '$manid'";
mysql_query($update, $conn);     }

$select = "select * from manufactures";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$manid = $newarray[manid];
$temp = "remove" . $manid;
$remove = $_POST[$temp];

if ($remove == "on")   {
$delete = "DELETE FROM manufactures where manid = '$manid'";
mysql_query($delete, $conn); 
      }    }
header("location:editmanu.php"); 
?>