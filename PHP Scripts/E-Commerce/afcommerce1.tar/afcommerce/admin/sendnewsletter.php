<?php
/*
  File Name: sendnewsletter.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR>";
include("dbinfo.php");
$select = "select * from config where varname = 'storeemail'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$storeemail = $newarray[varvalue];
$mailheaders = "From: $storeemail";

$wholist = $_POST[wholist];
$content = $_POST[content];
$content = stripslashes ($content);
$subject = $_POST[subject];
$subject = stripslashes ($subject);

if ($content == "")    {
echo "<BR><FONT FACE='VERDANA' SIZE='4' COLOR='#000000'><CENTER><BR><BR><BR>You Didn't Have Any Content To Your Newsletter!<BR><BR><A HREF='javascript:history.go(-1)'><FONT FACE='VERDANA' SIZE='3' COLOR='#000000'><B>Go Back</B></font></A><BR><BR>";
exit;     }

if ($wholist == "")    {
echo "<BR><FONT FACE='VERDANA' SIZE='4' COLOR='#000000'><CENTER><BR><BR><BR>You Didn't Choose Any Recipients To Your Newsletter!<BR><BR><A HREF='javascript:history.go(-1)'><FONT FACE='VERDANA' SIZE='3' COLOR='#000000'><B>Go Back</B></font></A><BR><BR>";
exit;     }

if ($wholist == "some")    {
$totaladdresses = $_POST[totaladdresses];
for ($i = 0; $i < $totaladdresses + 1; $i++) {
$temp = "dname$i";
$recipient = $_POST[$temp];
$temp = "num$i";
$num = $_POST[$temp];
$temp = "name$i";
$name = $_POST[$temp];
if ($num == "on") {
$msg = $content;
mail($recipient, $subject, $msg, $mailheaders);    }
} // ends for
} // ends wholist = some

if ($wholist == "all")    {
$select = "select * from members where newsletter = '1'";
$answer = mysql_query($select, $remoteconn);
while ($newarray = mysql_fetch_array($answer))  { 
$firstname = $newarray[firstname]; 
$lastname = $newarray[lastname]; 
$name = "$firstname $lastname"; 
$recipient = $newarray[email];   
$msg = $content; 
mail($recipient, $subject, $msg, $mailheaders);    }   } 
   
echo "<BR><BR><FONT FACE='VERDANA' SIZE='4' COLOR='#000000'><CENTER><BR><BR><BR>Newsletter Sent!<BR><BR><A HREF='javascript:history.go(-1)'><FONT FACE='VERDANA' SIZE='3' COLOR='#000000'><B>Go Back</B></font></A><BR><BR>";
?>
