<?php
/*
  File Name: newsletter.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php");
include("dbinfo.php");   ?>
<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR>
<H2>Email / Newsletter List</H2><CENTER>
<form action="sendnewsletter.php" method="post">
<H3>Who Are We Emailing ?<HR></H6><TABLE WIDTH="100%"><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='50%' ALIGN='CENTER' VALIGN='middle'><H3><input type='radio' name='wholist' value='all'> All Names On List</H6></TD><TD WIDTH='50%' ALIGN='CENTER' VALIGN='middle'><H3><input type='radio' name='wholist' value='some' checked> Only Selected Names</H6></TD></TR></TABLE><BR>

<TABLE WIDTH="100%" border='1' cellpadding='4' cellspacing='4'>
<?php

$i = 0;
// get shopping cart list

echo "<TABLE WIDTH='100%' BORDER='1'>";

$select = "select * from members where newsletter = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = @mysql_fetch_array($answer))  { 
$i = $i + 1;
$firstname = $newarray[firstname]; 
$lastname = $newarray[lastname]; 
$name = "$firstname $lastname"; 
$newsletterid = $newarray[memberid]; 
$recipient = $newarray[email]; 
echo "<TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='7%' ALIGN='CENTER' VALIGN='middle'><input type='checkbox' name='num$i'><input type='hidden' name='dname$i' value='$recipient'><input type='hidden' name='name$i' value='$name'></TD><TD WIDTH='5%' ALIGN='CENTER' VALIGN='middle'><font size='2'>$i</font></TD><TD WIDTH='27%' ALIGN='CENTER' VALIGN='middle'><font size='2'>$name</font></TD><TD WIDTH='57%' ALIGN='CENTER' VALIGN='middle'><font size='2'>$recipient</font></TD></TR>";    } 

if ($i < 1)  {
echo "<TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='CENTER' VALIGN='middle'><BR><H4>Your Newsletter List Is Empty!</H4></TD></TR>";    }

echo "<input type='hidden' name='totaladdresses' value='$i'>";

?></TABLE><BR><BR><HR><BR>
<H2>Newsletter Content</H3><font size='3'><b>Type your email message below</b></font><br><br>
  <textarea name="content" cols="60" rows="12"></textarea><BR><BR><BR>
<input type="submit" value="Send New Message">


</form></TD>
  </TR>
</TABLE><BR><BR><?php include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>