<?php
include("dbinfo.php");
$select = "select * from config where varname = 'showads'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$showads = $newarray[varvalue];

if ($showads == "1") {
echo "<BR><iframe src='http://afcommerce.com/adblock.php' scrolling='no' height='120' width='100%' frameborder='0'></iframe>";   }

?>
