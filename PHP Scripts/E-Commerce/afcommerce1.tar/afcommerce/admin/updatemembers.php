<?php 
/*
  File Name: updatemembers.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$memberid = $_GET['memberid'];
$firstname = $_POST[firstname];
$lastname = $_POST[lastname];
$email = $_POST[email];
$address = $_POST[address];
$city = $_POST[city];
$state = $_POST[state];
$newsletter = $_POST[newsletter];
$country = $_POST[country];
$phone = $_POST[phone];
$fax = $_POST[fax];
$zipcode = $_POST[zipcode];

$update = "update members set firstname = \"$firstname\", lastname = \"$lastname\", email = \"$email\", address = \"$address\", city = \"$city\", state = \"$state\", newsletter = '$newsletter', country = \"$country\", phone = \"$phone\", fax = \"$fax\", zipcode = \"$zipcode\" where memberid = '$memberid'";
mysql_query($update, $conn);
header("location:members.php");

?>