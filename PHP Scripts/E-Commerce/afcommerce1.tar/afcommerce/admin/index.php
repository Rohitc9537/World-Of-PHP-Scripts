<?php 
/*
  File Name: index.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php"); ?>

<td width='80%'>
<BR><script src='http://afcommerce.com/gs.js'></script><BR><H2>Shopping Cart Administration Home<HR></H2><TABLE WIDTH="100%">
  <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='mystore.php'><font size='4'>Configure My Store</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editproducts.php'><font size='4'>Edit Products</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='orders.php'><font size='4'>Orders</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
  </TR> <TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editcat.php'><font size='4'>Edit Categories</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
<a href='members.php'><font size='4'>Members</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editmanu.php'><font size='4'>Edit Manufactures</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
  </TR><TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editpayment.php'><font size='4'>Payment Config</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='addtaxrules.php'><font size='4'>Sales Tax</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editshipping.php'><font size='4'>Shipping Config</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
  </TR><TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editlegal.php'><font size='4'>Legal Notices</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='editspecials.php'><font size='4'>Specials</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
  <a href='editpromos.php'><font size='4'>Promotions</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a> <BR><BR><BR>
   </TD>
  </TR><TR ALIGN="CENTER" VALIGN="MIDDLE">
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE">
   <a href='newsletter.php'><font size='4'>Send Email</font><BR><BR><IMG SRC='select.gif' WIDTH='60' border=0 HEIGHT='60'></a><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE"><BR><BR><BR>
   </TD>
   <TD WIDTH="33%" ALIGN="CENTER" VALIGN="MIDDLE"><BR><BR><BR>
   </TD>
  </TR>
</TABLE></td></tr></table>
   
<?php 
echo "</td></tr></table>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
