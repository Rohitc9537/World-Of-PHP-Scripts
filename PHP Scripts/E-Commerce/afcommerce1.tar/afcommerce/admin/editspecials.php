<?php
/*
  File Name: editspecials.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php");
include("dbinfo.php");
$select = "select * from config where varname = 'defaultlang'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$langid = $newarray[varvalue];
if ($_POST[add] == "1")   {   

$insertrow = "insert into specials values ('', '', '', '', '')";
mysql_query($insertrow, $conn);        }

$controlnum = 0;  
$select = "select * from specials";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$controlnum = $controlnum + 1;
$specialid[$controlnum] = $newarray[id];
$prodid[$controlnum] = $newarray[prodid];
$newprice[$controlnum] = $newarray[newprice];    }
   
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><form action='updatespecials.php' method='post'><BR><H2>Edit Specials<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><table width='100%' border='1' cellpadding='7'>";
if ($controlnum != "0")   {
echo "<tr><td width='20%' align='center' valign='middle'><font size='3'>( Remove ) </font><BR><BR></td><td width='40%' align='center' valign='middle'><font size='4'>Product Name</font><BR><BR></td><td width='40%' align='center' valign='middle'><font size='4'>Special Price</font><BR><BR></td></tr>";    }
for ($i = 1; $i < $controlnum + 1; $i++)   {
echo "<tr><td width='10%' align='center' valign='middle'><input type='checkbox' name='remove$specialid[$i]'></td><td width='60%' align='center' valign='middle'><select name='prodid$specialid[$i]'><option value=''>Select A Product</option>";

$select2 = "select * from products";
$answer2 = mysql_query($select2, $conn);
while ($newarray2 = mysql_fetch_array($answer2))   {
$productid = $newarray2[prodid];

$select3 = "select * from product_descript where prodid = '$productid' && langid = '$langid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$productname = $newarray3[prodname];

echo "<option value='$productid'";
if ($productid == $prodid[$i])   {  echo " selected";    }
echo ">$productname</option>";     }

echo "</select></td><td width='30%' align='center' valign='middle'><B>$</B><input size='8' name='newprice$specialid[$i]' value='$newprice[$i]'></td></tr>";   }
if ($controlnum == "0")   {
echo "<tr><td width='100%' align='center' valign='middle'><BR><font size='4'>There are currently no specials</font></td></tr>";     }

echo "</table><BR><BR><input type='submit' value='Update Specials'><BR><BR>";

echo "<HR></form><BR><form action='editspecials.php' method='post'><input type='hidden' name='add' value='1'><input type='submit' value='Add New Special'></form></A><BR><BR>";
echo "<BR>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
