<?php
/*
  File Name: memberorders.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Orders By Customer<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR>";

if ($memberid == "")  {
echo "<BR><font size='4'>No Customer Selected !</font>";   
exit;      }
if ($memberid != "")  {
echo "<table width='100%' border='1' cellpadding='7'>";     }

include("dbinfo.php");
$controlnum = 0;
$select = "select * from orders where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$controlnum = $controlnum + 1;
$orderid = $newarray[id];
$orderdate = $newarray[orderdate];
$datearray = getdate ($orderdate);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$orderdate = "$month / $day / $year";

echo "<tr><td width='60%' align='center' valign='middle'><a href='orders.php?orderid=$orderid'><font size='3'><b>View Order</b></font></a></td><td width='40%' align='center' valign='middle'><font size='3'><b>$orderdate</b></font></td></tr>";    }

if ($controlnum == "0")   {
echo "<tr><td width='60%' align='center' valign='middle'><font size='4'>There are currently no orders</font></td><td width='40%' align='center' valign='middle'><font size='4'>by this customer</font></td></tr>";    }

echo "</table><BR><BR><BR><BR>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
