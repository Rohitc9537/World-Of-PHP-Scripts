<?php
/*
  File Name: removeprod.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from products";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$prodid = $newarray[prodid];
$temp3 = "remove" . $prodid;
$remove = $_POST[$temp3];

if ($remove == "on")   {
$select2 = "select * from products where prodid = '$prodid'";
$answer2 = mysql_query($select, $conn);
$newarray2 = mysql_fetch_array($answer2);
$oldpic = $newarray2[prodimage];
if ($oldpic != "")  {
if (file_exists("../images/$oldpic")) {
unlink ("../images/$oldpic");     }  }

$delete = "DELETE FROM products where prodid = '$prodid'";
mysql_query($delete, $conn); 
$delete = "DELETE FROM product_descript where prodid = '$prodid'";
mysql_query($delete, $conn);
}    }
header("location:editproducts.php");

?>
