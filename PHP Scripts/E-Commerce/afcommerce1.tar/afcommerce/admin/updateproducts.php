<?php 
/*
  File Name: updateproducts.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$prodid = $_GET['prodid'];
include("dbinfo.php");
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$langid = $newarray['langid'];
$temp = "prodname$langid";
$prodname = $_POST[$temp];
$temp = "proddescript$langid";
$proddescript = $_POST[$temp];
$proddescript = str_replace("
", "<br>", $proddescript);
$temp = "webpage$langid";
$webpage = $_POST[$temp];
$temp = "prodcaption$langid";
$prodcaption = $_POST[$temp];

$update = "update product_descript set prodname = \"$prodname\", proddescript = \"$proddescript\", webpage = \"$webpage\", prodcaption = \"$prodcaption\" where prodid = '$prodid' && langid = '$langid'";
mysql_query($update, $conn);     }

$price = $_POST['price'];
$catid = $_POST['catid'];
$modelnum = $_POST['modelnum'];
$weight = $_POST['weight'];
$manid = $_POST['manid'];
$status = $_POST['status'];
$prodquantity = $_POST['prodquantity'];

$update = "update products set price = '$price', catid = '$catid', modelnum = \"$modelnum\", weight = '$weight', manid = '$manid', status = '$status', prodquantity = \"$prodquantity\" where prodid = '$prodid'";
mysql_query($update, $conn);

header("location:editproducts.php?prodid=$prodid&update=1");
?>
