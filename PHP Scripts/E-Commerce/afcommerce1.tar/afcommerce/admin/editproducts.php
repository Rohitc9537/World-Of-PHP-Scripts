<?php
/*
  File Name: editproducts.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$prodid = $_GET['prodid'];
include("dbinfo.php");

include("controlheader.php");
if ($_POST[add] == "1")   {

$currentdate = time();
$insertrow = "insert into products values ('', '', '0', '', '', '', '0', '', '0', '', '$currentdate', '1', '0', '0', '0')";
mysql_query($insertrow, $conn);

// get id
$highnum = 0;
$select = "select * from products";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$tempid = $newarray[prodid];      
if ($highnum < $tempid)  {
$highnum = $tempid;    }  }
$tempid = $highnum;
$prodid = $tempid;
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$templangid = $newarray[langid];
$insertrow = "insert into product_descript values ('', '$templangid', '$prodid', 'NEW Product', '', '', '')";
mysql_query($insertrow, $conn);
}  }

echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'>
<BR><H2>Edit Products<HR></H2>";
if ($imgup == "1") { echo "<font size='4' color='#ff0000'>Your Image Was Successfully Uploaded</font><BR><BR><HR>"; }
else if ($imgup == "0") { echo "<font size='4' color='#ff0000'>Upload Error, please make sure your image is less than 150 kilobytes in size, and the file extension is either a .gif or .jpg</font><BR><BR><HR>"; }
echo "<script>
function uploadpic(id, typeid)   {
  url = 'uploadform.php?type=' + typeid + '&idenid=' + id;
 newwindow=window.open(url,'','location=no,toolbar=no,scrollbars=yes,height=450,width=650,left=50,top=50') 
}</script><table width='100%'><tr><td width='20%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='60%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR>";

include("dbinfo.php");
$select = "select * from config where varname = 'defaultlang'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$langid = $newarray[varvalue];
if ($prodid == "")     {
// display list to choose which product
echo "<table width='100%' cellpadding='7' border='1'><tr><td width='35%' align='center' valign='middle'><form action='removeprod.php' method='post'><font size='4'>Product Name</font></td><td width='35%' align='center' valign='middle'><font size='4'>Category Name</font></td><td width='30%' align='center' valign='middle'> ( Remove ) </td></tr>";

$i = 0;
$prodidarray = array();
$prodnamearray = array();

$select = "select * from products";
$answer = mysql_query($select, $conn);
$numsubprods = mysql_num_rows($answer);

while ($newarray = mysql_fetch_array($answer))  {
$prodidarray[$i] = $newarray['prodid'];

$select2 = "select * from product_descript where prodid = '$prodidarray[$i]' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodnamearray[$i] = $newarray2['prodname']; 
$i = $i + 1;    }

@array_multisort($prodnamearray, SORT_ASC, SORT_STRING, $prodidarray);

for ($i = 0; $i < $numsubprods; $i++) {

$prodid = $prodidarray[$i];
$prodname = $prodnamearray[$i];

$select2 = "select * from products where prodid = '$prodid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$catid = $newarray2['catid'];

$select3 = "select * from categories_descript where catid = '$catid' && langid = '$langid'";
$answer3 = mysql_query($select3, $conn);
$newarray3 = mysql_fetch_array($answer3);
$catname = $newarray3['catname'];

echo "<tr><td width='35%' align='center' valign='middle'><a href='editproducts.php?prodid=$prodid'><font size='4'>$prodname</font></a></td><td width='35%' align='center' valign='middle'><a href='editproducts.php?prodid=$prodid'><font size='4'>$catname</font></a></td><td width='30%' align='center' valign='middle'><input type='checkbox' name='remove$prodid'></td></tr>";


} // ends while loop
echo "</table><BR><BR><BR><table width='95%'><tr><td width='50%' align='center'><input type='submit' value='Remove Selected'></form></td><td width='50%' align='center'><form action='editproducts.php' method='post'><input type='hidden' name='add' value='1'><input type='submit' value='Add New Product'></form></td></tr><table></td></tr></table><BR><HR><BR><BR><BR><BR><BR><BR>";

}
else    {
include("dbinfo.php");
// display product with id number
$select = "select * from products where prodid = '$prodid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$price = $newarray['price'];
$catid = $newarray['catid'];
$modelnum = $newarray['modelnum'];
$weight = $newarray['weight'];
$manid = $newarray['manid'];
$status = $newarray['status'];
$prodquantity = $newarray['prodquantity'];

if ($_GET['update'] == "1") { echo "<font size='4' face='arial' color='#ff0000'><B>Update Successful</B></font><BR><BR>";  }

echo "<A HREF='javascript:uploadpic(\"$prodid\", \"p\")'><font size='5' face='arial'>Upload Product Image</font></A><BR><BR><table width='90%' cellpadding='7' border='0'><tr><td width='50%' align='left' valign='middle'><form action='updateproducts.php?prodid=$prodid' method='post'><font size='4'>Product Status:</font></td><td width='50%' align='center' valign='middle'><table width='100%'><tr><td align='center'><input type='radio' name='status' value='1'";
if ($status == "1")   {   echo " checked";   }
echo "> In Stock </td><td align='center'><input type='radio' name='status' value='0'";
if ($status == "0")   {   echo " checked";   }
echo "> Out Of Stock</td></tr></table></td></tr>";

$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$templangid = $newarray[langid];
$langname = $newarray[langname];
$select2 = "select * from product_descript where prodid = '$prodid' && langid = '$templangid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];
$proddescript = $newarray2[proddescript];
$proddescript = str_replace("<br>", "
", $proddescript);
$webpage = $newarray2[webpage];
$prodcaption = $newarray2[prodcaption];

echo "<tr><td width='50%' align='left' valign='middle'><font size='4'>Product Name:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname ) </B></font></td><td width='50%' align='center' valign='middle'><input size=\"35\" name=\"prodname$templangid\" value=\"$prodname\"></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Product Description:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname )</B></font></td><td width='50%' align='center' valign='middle'><textarea rows='7' cols='35' name='proddescript$templangid'>$proddescript</textarea></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Product Caption:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname )</B></font></td><td width='50%' align='center' valign='middle'><input size=\"35\" name=\"prodcaption$templangid\" value=\"$prodcaption\"></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Product Webpage:</font><BR><BR><font size='2' color='#ff0000'><B>( $langname )</B></font></td><td width='50%' align='center' valign='middle'><input size='35' name='webpage$templangid' value='$webpage'></td></tr><tr><td width='50%' align='left' valign='middle'><BR></td><td width='50%' align='center' valign='middle'><BR></td></tr>";    }  

echo "<tr><td width='50%' align='left' valign='middle'><font size='4'>Price:</font></td><td width='50%' align='center' valign='middle'><font size='5'>$</font> &nbsp; &nbsp;<input size='12' name='price' value='$price'></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>In Stock Quantity:</font></td><td width='50%' align='center' valign='middle'><input size=\"15\" name=\"prodquantity\" value=\"$prodquantity\"></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Category:</font></td><td width='50%' align='center' valign='middle'><select name='catid'><option value=''>None</option>";
$select2 = "select * from categories";
$answer2 = mysql_query($select2, $conn);
while ($newarray2 = mysql_fetch_array($answer2))  {

$tempcatid = $newarray2[catid];
$select4 = "select * from categories_descript where catid = '$tempcatid' && langid = '$langid'";
$answer4 = mysql_query($select4, $conn);
$newarray4 = mysql_fetch_array($answer4);
$tempcatname = $newarray4[catname];
echo "<option value='$tempcatid'";
if ($catid == $tempcatid)  {  echo " selected";   }
echo ">$tempcatname</option>";   }

echo "</select></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Manufacture:</font></td><td width='50%' align='center' valign='middle'><select name='manid'><option value=''>None</option>";
$select3 = "select * from manufactures";
$answer3 = mysql_query($select3, $conn);
while ($newarray3 = mysql_fetch_array($answer3))  {
$tempmanname = $newarray3[manname];
$tempmanid = $newarray3[manid];
echo "<option value='$tempmanid'";
if ($manid == $tempmanid)  {  echo " selected";   }
echo ">$tempmanname</option>";     }

echo "</select></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Product Model Number:</font></td><td width='50%' align='center' valign='middle'><input size='30' name='modelnum' value=\"$modelnum\"></td></tr><tr><td width='50%' align='left' valign='middle'><font size='4'>Product Weight:</font></td><td width='50%' align='center' valign='middle'><input size='12' name='weight' value='$weight'> &nbsp; &nbsp;<font size='4'>Lbs</font></td></tr></table><BR><BR><BR><input type='submit' value='Update Product'><BR><BR></form><BR><BR>
<table width='100%' cellpadding='7' border='1'><tr><td width='50%' align='center' valign='middle'><font size='4'><form enctype='multipart/form-data' action='uploadzip.php?prodid=$prodid' method='post'>Downloadable File:</font><BR><BR><font size='2' color='#ff0000'><B>(Click Browse To Find Files On Your Computer)</B><BR><BR></td><td width='50%' align='center' valign='middle'><input size='15' name='userfile' type='file' value='$download'><BR><BR><input type='submit' value='Upload Zip File'></font><BR><BR></td></tr></table></form>";

}

include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
