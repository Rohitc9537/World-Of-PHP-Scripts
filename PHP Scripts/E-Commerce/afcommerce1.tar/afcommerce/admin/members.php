<?php
/*
  File Name: members.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$memberid = $_GET['memberid'];
$controlnum = 1; 
include("controlheader.php");
if ($memberid == "")   {
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Members<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><table width='100%' cellpadding='7' border='1'><tr><td width='70%' align='center' valign='middle'><font size='4'>Customer Name</font></td><td width='30%' align='center' valign='middle'><font size='4'>Current Orders</font></td></tr>";
include("dbinfo.php");
$select = "select * from members";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$memberid[$controlnum] = $newarray[memberid];
$firstname[$controlnum] = $newarray[firstname];
$lastname[$controlnum] = $newarray[lastname];
$datecreated[$controlnum] = $newarray[datecreated];
$controlnum = $controlnum + 1;   }

for ($i = 1; $i < $controlnum; $i++)   {
echo "<tr><td width='70%' align='center' valign='middle'><a href='members.php?memberid=$memberid[$i]'>$firstname[$i] $lastname[$i]</a></td><td width='30%' align='center' valign='middle'><a href='memberorders.php?memberid=$memberid[$i]'>Show All</a></td></tr>";   }

echo "</table><BR><BR>";
} // ends if orderid is blank
else   {
include("dbinfo.php");
$select = "select * from members where memberid = '$memberid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);

$firstname = $newarray[firstname];
$lastname = $newarray[lastname];
$datecreated = $newarray[datecreated];
$datecreated = "6 / 24 / 2004";
$email = $newarray[email];
$address = $newarray[address];
$city = $newarray[city];
$state = $newarray[state];
$newsletter = $newarray[newsletter];
$country = $newarray[country];
$phone = $newarray[phone];
$fax = $newarray[fax];
$zipcode = $newarray[zipcode];

echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Members<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><CENTER><H2>Update Account</H2><form action='updatemembers.php?memberid=$memberid' method='post'>
<table width='550' border='0' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='550' border='0' cellspacing='0' cellpadding='2'>
          <tr>
          <td class='main' width='50%'>&nbsp;First Name:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='firstname' value='$firstname'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;Last Name:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='lastname' value='$lastname'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;E-Mail Address:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='email' value='$email'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
        </table></td>
  </tr>
  <tr>
    
        <td class='main'><table width='550' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;Street Address:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='address' value='$address'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
           <tr>
            <td class='main' width='50%'>&nbsp;Post Code:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='zipcode' value='$zipcode'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;City:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='city'  value='$city'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;State/Province:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='state' value='$state'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr></table><table width='550' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;Country:</td>
            <td class='main' width='50%'>&nbsp;
			<input type='text' name='country' value='$country'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small>  </td>
          </tr>
        </table></td>
  </tr>
  <tr>
    <td class='main'><table border='0' width='550' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='550' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;Phone Number:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='phone' value='$phone'>&nbsp;&nbsp;<small><font color='#330099'>required</font></small></td>
          </tr>
          <tr>
            <td class='main' width='50%'>&nbsp;Fax Number:</td>
            <td class='main' width='50%'>&nbsp;
<input type='text' name='fax' value='$fax'>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class='main'><table border='0' width='550' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='550' border='0' cellspacing='0' cellpadding='2'>
          <tr>
            <td class='main' width='50%'>&nbsp;Newsletter:</td>
            <td class='main' width='50%'>&nbsp;
<select name='newsletter'><option value='1'";
if ($newsletter == "1")   {   echo " selected";    }
echo ">Subscribed</option><option value='0'";
if ($newsletter == "0")   {   echo " selected";    }
echo ">Unsubscribed</option></select>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td class='main'><table border='0' width='550' cellspacing='0' cellpadding='2' class='formArea'>
      <tr>
        <td class='main'><table width='550' border='0' cellspacing='0' cellpadding='2'>
         </table></td></tr></table><BR><BR><BR><CENTER><input type='submit' value='Update Account'><BR><BR><BR>		
		</form>
</table><BR><BR>";
}
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
