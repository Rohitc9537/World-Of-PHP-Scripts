<?php
/*
  File Name: editshipping.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("controlheader.php");
include("dbinfo.php");

$select = "select * from config where varname = 'handling'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$handling = $newarray['varvalue'];
$select = "select * from config where varname = 'flatrate'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$flatrate = $newarray['varvalue'];
$select = "select * from config where varname = 'byweight'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$byweight = $newarray['varvalue'];
$select = "select * from config where varname = 'peritem'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$peritem = $newarray['varvalue'];
$select = "select * from config where varname = 'percentagerate'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$percentagerate = $newarray['varvalue'];
$select = "select * from config where varname = 'shipmethod'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$shipmethod = $newarray['varvalue'];
$select = "select * from config where varname = 'pickupshipping'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$pickupshipping = $newarray['varvalue'];
$select = "select * from config where varname = 'taxshipping'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$taxshipping = $newarray['varvalue'];

echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><BR><H2>Edit Shipping Configuration<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR><font size='4'>You can choose to add an optional Handling Fee:</font><BR><BR><table width='100%' cellpadding='7' border='1'><tr><td width='40%' align='center' valign='middle'><form action='updateshipping.php' method='post'><font size='4'>Handling Fee:</font><BR></td><td width='40%' align='center' valign='middle'><input size='15' name='handling' value='$handling'><BR></td></tr></table><BR><font size='4'>You can choose one of the following Shipping Methods:</font><BR><BR><table width='100%' cellpadding='7' border='1'><tr><td width='40%' align='center' valign='middle'><input type='radio' value='flatrate' name='shipmethod'";
if ($shipmethod == "flatrate")  {
echo " checked";   }
echo "> <font size='4'>Flat Rate</font></td><td width='40%' align='center' valign='middle'><input type='radio' value='byweight' name='shipmethod'";
if ($shipmethod == "byweight")  {
echo " checked";   }
echo "> <font size='4'>Calculate By Weight</font></td></tr><tr><td width='40%' align='center' valign='middle'><BR>Flat Rate Amount: <input size='12' name='flatrate' value='$flatrate'><BR><BR><BR><BR></td><td width='40%' align='center' valign='middle'><BR>Cost Per Pound: <input size='12' name='byweight' value='$byweight'><BR><BR><BR><BR></td></tr><tr><td width='40%' align='center' valign='middle'><input type='radio' value='peritem' name='shipmethod'";
if ($shipmethod == "peritem")  {
echo " checked";   }
echo "> <font size='4'>Per Item Rate</font></td><td width='40%' align='center' valign='middle'><input type='radio' value='percentagerate' name='shipmethod'";
if ($shipmethod == "percentagerate")  {
echo " checked";   }
echo "> <font size='4'>Percentage Rate</font></td></tr><tr><td width='40%' align='center' valign='middle'><BR>Per Item Rate Amount: <input size='12' name='peritem' value='$peritem'><BR><BR><BR><BR></td><td width='40%' align='center' valign='middle'><BR>Percentage: <input size='12' name='percentagerate' value='$percentagerate'> %<BR><BR><BR><BR></td></tr></table><BR><BR><CENTER><font size='4'>The following additional items are also optional</font><BR><BR>

<table width='100%' border='1' cellspacing='0' cellpadding='0'><tr><td width='40%' align='center' valign='top'><table width='100%' border='0' cellspacing='2' cellpadding='2'><tr><td width='40%' align='center' valign='top'><font size='4'>Pick Up Shipping Option</font><HR><font size='2'><B>This option will only charge the customer the handling fee, and requires them to pick their order up at your store's location.</font></B>
</td><td width='60%' align='center' valign='top'><font size='4'>Tax Shipping Fees</font><HR><font size='2'><B>This option will charge tax on the shipping and handling fees. The same tax rate for the rest of the order will be charged at checkout with the tax rules you set up in this administration area.</font></B>
</td></tr><tr><td width='40%' align='center' valign='top'><font size='4'>
<select name='pickupshipping'><option value='0'>No</option><option value='1'";
if ($pickupshipping == "1") { echo " selected"; }
echo ">Yes</option></select>
</td><td width='60%' align='center' valign='top'><font size='4'>
<select name='taxshipping'><option value='0'>No</option><option value='1'";
if ($taxshipping == "1") { echo " selected"; }
echo ">Yes</option></select>
</td></tr></table></td></tr></table>

<BR><BR><BR><input type='submit' value='Update Shipping Configuration'>";

echo "<BR><BR></form>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>
