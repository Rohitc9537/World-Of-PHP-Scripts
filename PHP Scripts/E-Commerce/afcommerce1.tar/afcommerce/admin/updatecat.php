<?php 
/*
  File Name: updatecat.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$catid = $_GET['catid'];
include("dbinfo.php");
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$langid = $newarray[langid];
$temp = "catname$langid";
$catname = $_POST[$temp];
$temp = "catdescript$langid";
$catdescript = $_POST[$temp];   

$update = "update categories_descript set catname = \"$catname\", catdescript = \"$catdescript\" where catid = '$catid' && langid = '$langid'";
mysql_query($update, $conn);     }

$maincat = $_POST[maincat];
if ($maincat == "")  {
header("location:editcat.php");   }
else   {
header("location:editcat.php?catid=$maincat");   }

?>
