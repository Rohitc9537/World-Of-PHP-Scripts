<?php
/*
  File Name: updatelegal.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from languages where status = '1'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$langid = $newarray[langid];
$temp = "privacy$langid";
$privacy = $_POST[$temp];
$temp = "shipping$langid";
$shipping = $_POST[$temp];  

$privacy = str_replace("
", "<br>", $privacy);
$shipping = str_replace("
", "<br>", $shipping);

$update = "update legal set content = \"$privacy\" where identifier = 'privacy' && langid = '$langid'";
mysql_query($update, $conn);
$update = "update legal set content = \"$shipping\" where identifier = 'shipping' && langid = '$langid'";
mysql_query($update, $conn);    }

header("location:editlegal.php");

?>
