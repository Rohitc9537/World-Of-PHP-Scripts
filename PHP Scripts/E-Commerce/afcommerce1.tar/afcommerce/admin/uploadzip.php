<?php
/*
  File Name: uploadzip.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$prodid = $_GET['prodid'];
$filename = $_FILES['userfile']['name'];
$filesize = $_FILES['userfile']['size'];
$filetype = $_FILES['userfile']['type'];
$tempname = $_FILES['userfile']['tmp_name'];

if ($filename == "")   {
header("location:editproducts.php?imgup=0&prodid=$prodid");      
exit;       }
include("dbinfo.php");
$update = "update products set download = '$filename' where prodid = '$prodid'";
mysql_query($update, $conn);
if (move_uploaded_file ($tempname, "../downloads/$filename"))  {
// success
header("location:editproducts.php?imgup=1&prodid=$prodid");
}
else   {   header("location:editproducts.php?imgup=0&prodid=$prodid");    }

?>
