<?php
/*
  File Name: editlegal.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/


include("controlheader.php");
echo "<TD WIDTH='75%' ALIGN='CENTER' VALIGN='top'><form action='updatelegal.php' method='post'><BR><H2>Edit Legal Notices<HR></H2><table width='100%'><tr><td width='30%' align='center' valign='middle'><A HREF='javascript:history.go(-1)'><font size='4'>Go Back</font></A></td><td width='70%' align='center' valign='middle'><A HREF='index.php'><font size='4'>Shopping Cart Admin Home</font></A></td></tr></table><HR><BR>";
include("dbinfo.php");
$select2 = "select * from languages where status = '1'";
$answer2 = mysql_query($select2, $conn);
while ($newarray2 = mysql_fetch_array($answer2))  {
$langid = $newarray2[langid];
$langname = $newarray2[langname];
$select = "select * from legal where identifier = 'privacy' && langid = '$langid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$privacy = $newarray[content];
$privacy = str_replace("<br>", "
", $privacy);
$select = "select * from legal where identifier = 'shipping' && langid = '$langid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$shipping = $newarray[content];
$shipping = str_replace("<br>", "
", $shipping);
echo "<table width='80%'><tr><td width='100%' align='center' valign='top'><H2>Privacy Policy</H2><font size='2' color='#ff0000'><B>( $langname ) </B></font><BR><BR><textarea cols='50' rows='8' name='privacy$langid'>$privacy</textarea><BR><BR><BR></td></tr><tr><td width='100%' align='center' valign='top'><H2>Shipping and Refunds</H2><font size='2' color='#ff0000'><B>( $langname ) </B></font><BR><BR><textarea cols='50' rows='8' name='shipping$langid'>$shipping</textarea><BR><BR><BR><input type='submit' value='Update Legal Notices'><BR><BR></td></tr></table><BR><BR><HR><BR>";    }

echo "</form>";   
include ("countid.php");
echo "</td></tr></table><CENTER><BR><script src='http://afcommerce.com/gs.js'></script><BR><BR>";
/*
				Thank You For Using The AFCommerce Shopping Cart 
The advertisements that are displayed inside this administration tool are optional and may be removed. However before you do so, please consider that there was a lot of hard work that went in to developing this software and that by keeping the ads inside this tool, you are eligible for a link to your website on the AFCommerce support site. I created this shopping cart by myself without the help of any other programmers, so it obviously took longer than if I had a team working on it. I am also continuing to work on new features and documentation that takes up much of my time, so to be able to spend more time on this I do need to try to make a little money some how to be able to justify working on this instead of getting paid jobs. Most of the people installing this cart are getting paid for it, which is fine by me, I hope you all do well with it. There is absolutely no personal information collected, and absolutely no unethical actions taken inside this tool. There is more information in the files named COPYING and countid.php that are both included in this software package.
*/ ?>