<?php 
/*
  File Name: updateorders.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$orderid = $_GET['orderid'];
include("dbinfo.php");
$status = $_POST[status];

$update = "update orders set status = '$status' where id = '$orderid'";
mysql_query($update, $conn);
header("location:orders.php");
?>