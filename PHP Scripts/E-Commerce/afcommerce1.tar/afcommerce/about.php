<?php
/*
  File Name: about.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("carttop.php"); 
include("lang/$langid/content2.php"); 
echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
