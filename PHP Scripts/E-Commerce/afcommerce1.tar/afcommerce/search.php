<?php 
/*
  File Name: search.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$errorflag = 0;
$numoccurances = array();
$numrelmatches = 0;
$keys = $_POST['keywords'];
if ($keys == "")   {
$errorflag = 1;    }
$keys = strtolower ($keys);
$keywords = explode(" ", $keys);

// get number of keywords
$numkeywords = 0;
while (list($key, $val) = each($keywords))   {
$numkeywords = $numkeywords + 1;  }
reset ($keywords);

$searchcat = $_POST['searchcat'];
if ($searchcat == "")   {
$errorflag = 1;    }
$searchmakes = $_POST['searchmakes'];
if ($searchmakes == "")   {
$errorflag = 1;    }
$lowrange = $_POST['lowrange'];
if ($lowrange == "")   {
$errorflag = 1;    }
$highrange = $_POST['highrange'];
if ($highrange == "")   {
$errorflag = 1;    }
$page = $_POST['page'];

include("carttop.php");
if ($errorflag == "0")    {
echo "<CENTER><H2>" . SEARCH_RESULTS . "<HR></H2>";
include("dbinfo.php");

$select = "select * from product_descript where langid = '$langid'";  
$answer = mysql_query($select, $conn);

$controlproductloop = 0;
while ($newarray = mysql_fetch_array($answer))   {
$controlproductloop = $controlproductloop + 1;
$prodname = $newarray[prodname];
$searchprodname = strtolower ($prodname);
$proddescript = $newarray[proddescript];
$searchproddescript = strtolower ($proddescript);
$prodcaption = $newarray[prodcaption];
$searchprodcaption = strtolower ($prodcaption);
$prodid = $newarray[prodid];

$select2 = "select * from products where prodid = '$prodid'";  
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$price = $newarray2[price];
$manid = $newarray2[manid];
$catid = $newarray2[catid];

// check if category matches
if ($searchcat != "all")   {
if ($catid != $searchcat)   {
continue;   }     }

// check if manufacture matches
if ($searchmakes != "all")   {
if ($manid != $searchmakes)   {
continue;   }     }

// check if price is within range
if (($price < $lowrange) || ($highrange < $price))    {
continue;   }  

// check for keyword matches, loop through each word
$controlkeywordloop = 0;
reset ($keywords);
while (list($key, $onekeyword) = each($keywords)) {
if (($onekeyword == "") || ($onekeyword == " "))   {  continue;   }
// exclude common words. Currently only works in English
if (($onekeyword == "and") || ($onekeyword == "to") || ($onekeyword == "for") || ($onekeyword == "the") || ($onekeyword == "a") || ($onekeyword == "or") || ($onekeyword == "it"))   {  continue;   }

$controlkeywordloop = $controlkeywordloop + 1;
// temptotal will equal number of occurances for each keyword
$temptotal = 0;
$tempnum = substr_count($searchprodname, $onekeyword);
$temptotal = $temptotal + $tempnum;
$tempnum = substr_count($searchproddescript, $onekeyword);
$temptotal = $temptotal + $tempnum;
$tempnum = substr_count($searchprodcaption, $onekeyword);
$temptotal = $temptotal + $tempnum;
if (($temptotal > 0) && ($temptotal < 9))  {  $temptotal = 1;    }
if (($temptotal > 8) && ($temptotal < 40))  {  $temptotal = 2;    }
if ($temptotal > 40)  {  $temptotal = 3;    }

$numoccurances[$controlkeywordloop] = $temptotal;

} // ends while for keywords

// now add numoccurances all together
reset ($numoccurances);
$totalnumoccurances = 0;
while (list($key, $val) = each($numoccurances)) {
$totalnumoccurances = $totalnumoccurances + $val;    }

// get percentage of number of keywords that match
$nummatches = 0;
reset ($numoccurances);
while (list($key, $val) = each($numoccurances)) {
if ($val > 0)  {
$nummatches = $nummatches + 1;    }   }

$relevancypercent = $nummatches / $numkeywords;

$relevancy[$controlproductloop] = ($relevancypercent * $totalnumoccurances) * 100;
$prodidarray[$controlproductloop] = $prodid;

if ($totalnumoccurances > 0)  { $numrelmatches = $numrelmatches + 1;   }

} // ends products while loop

// reorder array by highest relevancy
array_multisort($relevancy, SORT_DESC, $prodidarray);

// print products
if (($page == "") || ($page == "1"))  { 
$page = 1;
$startnum = 0;   }
else   {
$startnum = (($page - 1) * $numperpage);   }

if ($numrelmatches > ($numperpage - 1))  {
$endnum = $startnum + $numperpage;    }
else  { $endnum = $startnum + $numrelmatches;   }

$nextpage = $page + 1;
$previouspage = $page - 1;
if ($numrelmatches > ($page * $numperpage)) { $shownextpagelink = 1; }

$lastpage = $numrelmatches / $numperpage;
$lastpage = ceil($lastpage);
$tablewidth = ($lastpage * 25) + 40;

for ($i = $startnum; $i < $endnum; $i++)   {
$select = "select * from products where prodid = '$prodidarray[$i]'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$price = $newarray[price];
$price = number_format ($price, 2);

$select2 = "select * from product_descript where prodid = '$prodidarray[$i]' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];
$proddescript = $newarray2[proddescript];

echo "<CENTER><table width='90%'><tr><td width='100%' align='center' valign='middle'><table width='100%'><tr><td width='70%' align='center' valign='middle'><a href='getproduct.php?pid=$prodidarray[$i]'><font size='4' color='#000000'>$prodname</font></a></td><td width='30%' align='center' valign='middle'><font size='4' color='#000000'>$price</font></td></tr></table></td></tr></table><HR>";

} // ends for loop to print products

echo "<BR><BR>" . SEARCH_MATCHINGRESULTS . ": $numrelmatches<BR><BR><table width='300'><tr>";

if ($page > 1)  { echo "<td width='50%' align='left'><form name='forma$previouspage' action='search.php' method='post'><input type='hidden' name='keywords' value=\"$keys\"><input type='hidden' name='searchcat' value=\"$searchcat\"><input type='hidden' name='searchmakes' value=\"$searchmakes\"><input type='hidden' name='lowrange' value=\"$lowrange\"><input type='hidden' name='highrange' value=\"$highrange\"><input type='hidden' name='page' value='$previouspage'><a href='javascript:document.forma" . $previouspage . ".submit();' class='login'><font size='3' face='arial'>Previous Page</B></font></a></td></form>";    }
if ($shownextpagelink == "1") { echo "<td width='50%' align='right'><form name='forma$nextpage' action='search.php' method='post'><input type='hidden' name='keywords' value=\"$keys\"><input type='hidden' name='searchcat' value=\"$searchcat\"><input type='hidden' name='searchmakes' value=\"$searchmakes\"><input type='hidden' name='lowrange' value=\"$lowrange\"><input type='hidden' name='highrange' value=\"$highrange\"><input type='hidden' name='page' value='$nextpage'><a href='javascript:document.forma" . $nextpage . ".submit();' class='login'><font size='3' face='arial'>Next Page</B></font></a></td></form>";    }

echo "</tr></table><BR><table width='$tablewidth'><tr><td width='40'><font size='3' face='arial'><B>Page:</B></font></td>";

for ($pagecount = 1; $pagecount < $lastpage + 1; $pagecount++)  {
if ($pagecount == $page) {
echo "<td width='20'><font size='3' face='arial' color='#ff0000'>" . $pagecount . "</B></font></td>";
}
else {
echo "<td width='20'><form name='form$pagecount' action='search.php' method='post'><input type='hidden' name='keywords' value=\"$keys\"><input type='hidden' name='searchcat' value=\"$searchcat\"><input type='hidden' name='searchmakes' value=\"$searchmakes\"><input type='hidden' name='lowrange' value=\"$lowrange\"><input type='hidden' name='highrange' value=\"$highrange\"><input type='hidden' name='page' value='$pagecount'><a href='javascript:document.form" . $pagecount . ".submit();' class='login'><font size='3' face='arial'>" . $pagecount . "</B></font></a></td></form>";   }   }

echo "</tr></table><BR><BR></td></tr></table>";

}
else   {
echo "<CENTER><form action='search.php' method='post'>";
 ?>

<H2><?php echo SEARCH_HEADER; ?><HR></H2><table width='65%' class='viewcart'><tr><td width='40%' align='center' valign='top'><?php echo SEARCH_KEYWORDS; ?>:</td><td width='60%' align='center' valign='top'><input size='25' name='keywords'><BR><BR></td></tr>
<tr><td width='40%' align='center' valign='top'><?php echo SEARCH_CATEGORIES; ?>:</td><td width='60%' align='center' valign='top'><select name='searchcat'><option value='all'><?php echo SEARCH_ALLCATEGORIES; ?></option><?php
include("dbinfo.php");
$select = "select * from categories";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$catid = $newarray[catid];
$select2 = "select * from categories_descript where catid = '$catid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$catname = $newarray2[catname];
echo "<option value='$catid'>$catname</option>";  }  ?></select><BR><BR></td></tr>

<?php if ($displaymanufactures == "1") { ?>
<tr><td width='40%' align='center' valign='top'><?php echo SEARCH_MANUFACTURES; ?>:</td><td width='60%' align='center' valign='top'><select name='searchmakes'><option value='all'><?php echo SEARCH_ALLMANUFACTURES; ?></option><?php
include("dbinfo.php");
$select = "select * from manufactures where langid = '$langid'";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$manid = $newarray[manid];
$manname = $newarray[manname];
echo "<option value='$manid'>$manname</option>";  }  ?></select><BR><BR></td></tr>
<?php } 
else { echo "<input type='hidden' name='searchmakes' value='all'>"; } ?>
<tr><td width='40%' align='center' valign='middle'><?php echo SEARCH_PRICERANGE; ?>:</td><td width='60%' align='center' valign='top'><select name='lowrange'><option value='0'><?php echo SEARCH_NOMIN; ?></option><option value='25'>25</option><option value='50'>50</option><option value='75'>75</option><option value='100'>100</option><option value='150'>150</option><option value='200'>200</option><option value='300'>300</option><option value='400'>400</option><option value='500'>500</option><option value='600'>600</option><option value='700'>700</option><option value='800'>800</option><option value='900'>900</option><option value='1000'>1000</option></select><BR> <B>To:</B> <BR><select name='highrange'><option value='5000000'><?php echo SEARCH_NOMAX; ?></option><option value='25'>25</option><option value='50'>50</option><option value='75'>75</option><option value='100'>100</option><option value='200'>200</option><option value='400'>400</option><option value='600'>600</option><option value='800'>800</option><option value='1000'>1000</option><option value='1200'>1200</option><option value='1400'>1400</option><option value='1600'>1600</option><option value='1800'>1800</option><option value='2000'>2000</option></select></td></tr>

</table>

<BR><BR><BR><input type='image' src='lang/<?php echo $langid; ?>/1/button_search.gif'><BR><BR><BR>
</form>
</td></tr></table>
<?php  }   
echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
