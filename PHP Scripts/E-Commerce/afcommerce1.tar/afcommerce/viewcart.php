<?php
/*
  File Name: viewcart.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$total = 0;
include("dbinfo.php");
if ($id == "")   {
// can not find id number, so cart is empty
include("carttop.php"); 
echo "<CENTER><div class='contentheader'><p align='center'><BR>";
if ($cartimages == "1")  {
 echo "<IMG SRC='pullcart.gif'></p>"; }
 echo "" . VIEWCART_EMPTY . "<BR></div><BR><BR><BR><BR><BR>";

}
// after checks, look for cart table and main basket row
else    {
$select2 = "select * from basket_products where basketid = '$id'";
$answer2 = mysql_query($select2, $conn);
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) < 1)    {
// can not find id number, so cart is empty
include("carttop.php"); 
echo "<CENTER><div class='contentheader'><p align='center'><BR>";
if ($cartimages == "1")  {
 echo "<IMG SRC='pullcart.gif'></p>"; }
 echo "" . VIEWCART_EMPTY . "<BR></div><BR><BR><BR><BR><BR></TD></TR></TABLE>";
}
else if (mysql_num_rows($answer2) < 1)   {
// cart is empty
include("carttop.php"); 
echo "<CENTER><div class='contentheader'><p align='center'><BR>";
if ($cartimages == "1")  {
 echo "<IMG SRC='pullcart.gif'></p>"; }
 echo "" . VIEWCART_EMPTY . "<BR></div><BR><BR><BR><BR><BR>";
}
else    {
$i = 1;
// there is a cart, so display contents
include("carttop.php"); 

if ($_GET[oq] == "1")  {
echo "<CENTER><BR><font size='4' face='arial'>" . OUTOFSTOCK_OVERLIMIT . "</font><BR><BR></CENTER>";   }

echo "<CENTER><form action='updatecart.php' method='post'><table class='contentheader' width='100%'><tr>";
if ($cartimages == "1")  {
 echo "<td width='20%' align='center'><IMG SRC='pullcart.gif'></td>"; }
 echo "<td width='80%' align='center'>" . VIEWCART_VIEWCART . "<BR><BR></td></tr></table><table border='1' CELLSPACING='0' CELLPADDING='7' class='viewcart' width='100%'><tr><td width='10%' align='center' valign='middle'><font size='1'>" . VIEWCART_REMOVE . "</font></td><td width='15%' align='center' valign='middle'>" . VIEWCART_QUANTITY . "</td><td width='50%' align='center' valign='middle'>" . VIEWCART_PRODUCTNAME . "</td><td width='25%' align='center' valign='middle'>" . VIEWCART_PRICE . "</td></tr>";

while ($newarray = mysql_fetch_array($answer2))   {
$prodname = $newarray[prodname]; 
$price = $newarray[price];
$priceformatted = number_format ($price, 2);
$quantity = $newarray[quantity];
$subid = $newarray[id];
$totalproductprice = $price * $quantity; 
$total = $total + $totalproductprice;   
$totalformatted = number_format ($total, 2); 

echo "<tr><td width='10%' align='center' valign='middle'><input type='checkbox' name='c$subid'></td><td width='20%' align='center' valign='middle'><input size='4' name='quantity$subid' value='$quantity'></td><td width='45%' align='center' valign='middle'>$prodname</td><td width='25%' align='center' valign='middle'>$ $priceformatted</td></tr>";

}  // ends while loop
echo "</table><BR><table class='viewcart' width='100%' border='0'><tr><td width='25%' align='center' valign='middle'></td><td width='55%' align='center' valign='middle'>" . VIEWCART_SUBTOTAL . ":</td><td width='20%' align='center' valign='middle'>$ $totalformatted</td></tr></table><HR><BR><table width='100%'><tr><td width='50%' align='center' valign='middle'><input type='image' src='lang/$langid/1/button_updatecart.gif'></td></form><td width='50%' align='center' valign='middle'><form action='checkout.php' method='get'><input type='image' src='lang/1/1/button_checkout.gif'></td></tr></table><BR><BR></form>";

}     }
echo "</td></tr></table></TD></TR></TABLE>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
