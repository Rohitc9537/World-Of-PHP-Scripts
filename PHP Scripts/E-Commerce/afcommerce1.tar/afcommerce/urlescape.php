<?php
/*
  File Name: urlescape.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

function urlescape ($string)    {
$string = stripslashes($string);
// $string = str_replace("%", "%25", $string);
$string = str_replace(" ", "%20", $string);
$string = str_replace("?", "%3f", $string);
$string = str_replace("/", "%2f", $string);
$string = str_replace("$", "%24", $string);
$string = str_replace("&", "%26", $string);
$string = str_replace("'", "%27", $string);
$string = str_replace("=", "%3D", $string);
$string = str_replace("^", "%5E", $string);
// $string = str_replace("(", "%28", $string);
// $string = str_replace(")", "%29", $string);
$string = str_replace(";", "%3B", $string);
$string = str_replace(":", "%3A", $string);
$string = str_replace("<", "%3C", $string);
$string = str_replace(">", "%3E", $string);
$string = str_replace("[", "%5B", $string);
$string = str_replace("]", "%5D", $string);
$string = str_replace("|", "%7C", $string);
$string = str_replace("{", "%7B", $string);
$string = str_replace("}", "%7D", $string);
$string = str_replace("\"", "%22", $string);
return $string;
}

function urlunescape ($string)    {
// $string = str_replace("%25", "%", $string);
$string = str_replace("%20", " ", $string);
$string = str_replace("%3f", "?", $string);
$string = str_replace("%2f", "/", $string);
$string = str_replace("%24", "$", $string);
$string = str_replace("%26", "&", $string);
$string = str_replace("%27", "'", $string);
$string = str_replace("%3D", "=", $string);
$string = str_replace("%5E", "^", $string);
// $string = str_replace("%28", "(", $string);
// $string = str_replace("%29", ")", $string);
$string = str_replace("%3B", ";", $string);
$string = str_replace("%3A", ":", $string);
$string = str_replace("%3C", "<", $string);
$string = str_replace("%3E", ">", $string);
$string = str_replace("%5B", "[", $string);
$string = str_replace("%5D", "]", $string);
$string = str_replace("%7C", "|", $string);
$string = str_replace("%7B", "{", $string);
$string = str_replace("%7D", "}", $string);
$string = str_replace("%22", "\"", $string);
return $string;
}






?>
