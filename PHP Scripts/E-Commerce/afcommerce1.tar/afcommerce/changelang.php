<?php
/*
  File Name: changelang.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
if ($id == "")    {
// create new session
$currentdate = time();

$insertrow = "insert into basket values ('', '', '$currentdate', '', '', '', '1', '0', '0', '0', '$lang', '0')";
mysql_query($insertrow, $conn);
// get id
$highnum = 0;
$select = "select * from basket";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))   {
$id = $newarray[id];      
if ($highnum < $id)  {
$highnum = $id;    }  }
$id = $highnum;    }

$update = "update basket set defaultlang = '$lang' where id = '$id'";
mysql_query($update, $conn);
header("location:index.html");
?>
