<?php
/*
  File Name: bottomlayout.php, v 1.1
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

// By default this file is blank, however this file is attached to the footer 
// include for websites that want to add any universal html to be added after
// each cart file's html. For example, if you want to display any links on the 
// bottom or right hand side of your pages. When using the Amazing Flash website
// building system, this file is automatically created for each layout option.

?>