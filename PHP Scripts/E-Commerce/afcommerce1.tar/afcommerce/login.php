<?php
/*
  File Name: login.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

$pass = $_POST[password];
if ((strlen($pass)) < 3)   {
header("location:account.php");   }
$email = $_POST[email];
if ((strlen($email)) < 5)   {
header("location:account.php");   }

include("dbinfo.php");
// clean up basket and basket products tables
$currentdate = time();
$select = "select * from basket";
$answer = mysql_query($select, $conn);
while ($newarray = mysql_fetch_array($answer))  {
$date = $newarray[date];
$cleanid = $newarray[id];
$checkdate = ($currentdate - $date) - 86400;
if ($checkdate > 0)  {
// delete row and all rows with same basketid

$delete = "DELETE FROM basket where id = '$cleanid'";
mysql_query($delete, $conn); 

$delete = "DELETE FROM basket_products where basketid = '$cleanid'";
mysql_query($delete, $conn); 
} // ends if checkdate is larger than 0
} // ends while for cleanup

// now finish the login

$select = "select * from members where email = '$email'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];
$dbpass = $newarray[pass];
if ($dbpass == $pass)   {
$update = "update basket set memberid = '$memberid' where id = '$id'";
mysql_query($update, $conn);
header("location:viewcart.php");    }
else  {
header("location:account.php");     }
?>
