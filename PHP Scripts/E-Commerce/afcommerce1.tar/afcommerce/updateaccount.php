<?php 
/*
  File Name: updateaccount.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$firstname = $_POST[firstname];
$lastname = $_POST[lastname];
$email = $_POST[email];
$address = $_POST[address];
$city = $_POST[city];
$state = $_POST[state];
$newsletter = $_POST[newsletter];
$country = $_POST[country];
$phone = $_POST[phone];
$fax = $_POST[fax];
$zipcode = $_POST[zipcode];

$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];

$select = "select * from zones where zone_name = '$state' || zone_code = '$state'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$state_zone_country_id = $newarray[zone_country_id];
$zone_id = $newarray[zone_id];

if ($zone_id == "") {
include("carttop.php");
echo "<CENTER><BR><H2>There was an error updating your account. The state that you entered does not match a valid state name. Please go back and fix any errors.</H2>";
echo "</td></tr></table></td></tr></table>";
require ('footer.php');
exit;  }

$update = "update members set firstname = \"$firstname\", lastname = \"$lastname\", email = \"$email\", address = \"$address\", city = \"$city\", state = \"$zone_id\", newsletter = \"$newsletter\", phone = \"$phone\", fax = \"$fax\", zipcode = \"$zipcode\" where memberid = '$memberid'";
mysql_query($update, $conn);
header("location:account.php");

?>