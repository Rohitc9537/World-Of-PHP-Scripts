<?php 
/*
  File Name: orderstatus.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("dbinfo.php");
$select = "select * from basket where id = '$id'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$logmemberid = $newarray[memberid]; 
if (($logmemberid == "") || ($logmemberid == "0"))   {
header("location:account.php");
exit;    }
$orderid = $_GET['orderid'];
if (($orderid == "") || ($orderid == "0"))   {
include("carttop.php");
$count = 0;
$select = "select * from orders where memberid = '$logmemberid'";
$answer = mysql_query($select, $conn);

echo "<CENTER><table width='100%' border='1' cellpadding='7'>";
while ($newarray = mysql_fetch_array($answer))   {
$count = $count + 1;
$orderid = $newarray[id];
$orderdate = $newarray[orderdate];
$datearray = getdate ($orderdate);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$orderdate = "$month / $day / $year";

echo "<tr><td width='60%' align='center' valign='middle'><a href='orderstatus.php?orderid=$orderid' class='login'><font size='3'><b>View Order</b></font></a></td><td width='40%' align='center' valign='middle'><font size='3'><b>$orderdate</b></font></td></tr>";   
  }
if ($count == "0")   {
echo "<tr><td width='90%' align='center' valign='middle'><font size='4' face='verdana'>There are currently no orders for you to view</font></td></tr>";    }

echo "</table></td></tr></table>";
require ('footer.php');

exit;     }

$select = "select * from orders where id = '$orderid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$memberid = $newarray[memberid];
if ($logmemberid != $memberid)  {
include("carttop.php");
echo "<BR><H2>You are not authorized to view this order.<BR><BR>If this is your order, please make sure you are logged in as the proper recipient of this order.<BR><BR>If you are still having trouble, please contact us.</H2>";
exit;    }
$ordertotal = $newarray[total];
$status = $newarray[status]; 
$shipaddress = $newarray[shipaddress]; 
$paymethod = $newarray[paymethod]; 
$confirmcode = $newarray[confirmcode]; 
$orderdate = $newarray[orderdate];
$datearray = getdate ($orderdate);
$month = $datearray['mon'];
$day = $datearray['mday'];
$year = $datearray['year'];
$orderdate = "$month / $day / $year";
$taxcost = $newarray[taxcost]; 
$receipt = $newarray[receipt];
$comments = $newarray[comments];
$comments = str_replace("
", "<br>", $comments);
$shipmethod = $newarray[shipmethod]; 
$shipcost = $newarray[shipcost]; 
$promodiscount = $newarray[promodiscount];
$subtotal = $ordertotal - $shipcost - $taxcost;
$ordertotal = number_format ($ordertotal, 2); 
$subtotal = number_format ($subtotal, 2); 
$shipcost = number_format ($shipcost, 2); 
$taxcost = number_format ($taxcost, 2); 
$select2 = "select * from members where memberid = '$memberid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$firstname = $newarray2[firstname];
$lastname = $newarray2[lastname];
include("carttop.php");
echo "<H2>Thank You For You Order !<HR></H2><table class='viewcart' width='380'><tr><td width='50%' align='center' valign='middle'>Order Status:</td><td width='50%' align='center' valign='middle'>$status</td></tr></table><hr><BR><table border='1' cellpadding='7' class='viewcart' width='97%'><tr><td width='45%' align='left' valign='top'>Customer Name:<BR>$firstname $lastname<BR><BR><BR>Shipping Address:<BR><BR>$shipaddress</td><td width='55%' align='left' valign='top'>Subtotal : $ $subtotal<BR><BR>Shipping And Handling: $ $shipcost<BR><BR>Tax: $ $taxcost<BR><BR><HR><BR>Order Total: $ $ordertotal</td></tr></table><BR><hr><BR><table border='1' cellpadding='7' class='viewcart' width='97%'><tr><td width='45%' align='left' valign='top'>Order Date: <hR>$orderdate<BR><BR><BR>Payment Method: <hR>$paymethod<BR><BR><BR>Confirmation Code: <hR>$confirmcode<BR><BR><BR>Additional Comments:<hR>$comments<BR><BR><BR><BR></td><td width='55%' align='left' valign='top'><CENTER>Products Ordered</CENTER><HR>$receipt</td></tr></table>";

$select = "select * from order_downloads where orderid = '$orderid'";
$answer = mysql_query($select, $conn);
if (mysql_num_rows($answer) > 0)  {
echo "<H2>Download Products</H2><table width='100%' border='1' cellpadding='7'>";
while ($newarray = mysql_fetch_array($answer))   {
$downloadid = $newarray[id];
$maxdownloads = $newarray[maxdownloads]; 
$maxdays = $newarray[maxdays]; 
$filename = $newarray[filename]; 
$prodid = $newarray[prodid]; 
$select2 = "select * from product_descript where prodid = '$prodid' && langid = '$langid'";
$answer2 = mysql_query($select2, $conn);
$newarray2 = mysql_fetch_array($answer2);
$prodname = $newarray2[prodname];


echo "<tr><td width='70%' align='center' valign='middle'>";

if ($maxdownloads > 0)  {  echo "<a href='download.php?id=$downloadid' target='_blank' class='login'>";   }
echo "<font size='4'>$prodname</font>";

if ($maxdownloads > 0)  {  echo "</a>";   }
echo "</td><td width='30%' align='center' valign='middle'><BR>Number of downloads remaining: $maxdownloads<BR><BR></td></tr>";       }  

echo "</table><BR>"; }

echo "<BR><BR><BR></td></tr></table>"; 

?><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
