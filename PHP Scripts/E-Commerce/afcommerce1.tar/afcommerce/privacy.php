<?php
/*
  File Name: privacy.php, v 1.1       
  Author: Paul Crinigan, AmazingFlash.com

  AFCommerce, Amazing Flash Commerce Solutions
  http://www.afcommerce.com

  Copyright (c) 2005 AFCommerce

  AFCommerce is Released under the GNU General Public License
*/

include("carttop.php");
include("dbinfo.php");
$select = "select * from legal where identifier = 'privacy' && langid = '$langid'";
$answer = mysql_query($select, $conn);
$newarray = mysql_fetch_array($answer);
$content = $newarray[content]; 

echo "<CENTER><H2>" . MENU_PRIVACY . "<HR></H2><table width='90%'><tr><td width='100%'><font size='3' face='verdana'>$content</font></td></tr></table><BR><BR><BR></td></tr></table>";

?><?php echo "</td></tr></table>";
require ('footer.php'); ?>
<!-- 
The link below is our copyright announcement. This software is completely free, however we do require that this link remain exactly the way it is. We have made it extremely small and out of the way so that it would be a reasonable request. Thank You. 
-->
<TABLE WIDTH='100%'><TR ALIGN='CENTER' VALIGN='TOP'><TD WIDTH='100%' ALIGN='right' VALIGN='middle'><a href='http://www.afcommerce.com/' target='_blank' alt='Shopping Cart Powered by AFCommerce.com'><font size='1' face='times new roman'><i>Powered by AFCommerce.com</i></font></a></TD></TR></TABLE>
