<?php
print_r($_GET);
echo $_GET['where_field'];
?>