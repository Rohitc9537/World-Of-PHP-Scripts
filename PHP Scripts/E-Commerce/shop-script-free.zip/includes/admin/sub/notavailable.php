<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	//payment types list

	if (!strcmp($sub, "payment"))
	{
		//set sub-department template
		$smarty->assign("admin_sub_dpt", "notavailable.tpl.html");
	}

?>