<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// registration form

	if (isset($register)) //customers registration
	{

			$smarty->assign("main_content_template", "notavailable.tpl.html");
	}

?>