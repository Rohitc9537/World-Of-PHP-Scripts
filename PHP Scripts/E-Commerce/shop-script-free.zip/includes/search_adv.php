<?php
/*****************************************************************************
 *                                                                           *
 * Shop-Script FREE                                                          *
 * Copyright (c) 2005 WebAsyst LLC. All rights reserved.                     *
 *                                                                           *
 ****************************************************************************/

	// advanced search

	if (isset($_GET["adv_search"])) //advanced search form
	{
		$smarty->assign("main_content_template", "notavailable.tpl.html");
	}

?>