<?php
	define('CONF_PRODUCTS_PER_PAGE', '8');
	define('CONF_COLUMNS_PER_PAGE', '2');
	define('CONF_SHOW_ADD2CART', '1');
	define('CONF_SHOW_BEST_CHOICE', '1');
	define('CONF_DARK_COLOR', 'CD8181');
	define('CONF_MIDDLE_COLOR', 'F0B5B5');
	define('CONF_LIGHT_COLOR', 'FFEEEE');
?>