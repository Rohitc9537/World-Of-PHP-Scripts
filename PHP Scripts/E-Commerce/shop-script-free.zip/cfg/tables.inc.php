<?php
	//Shop-Script FREE database tables
	define('PRODUCTS_TABLE', 'SS_products');
	define('ORDERS_TABLE', 'SS_orders');
	define('ORDERED_CARTS_TABLE', 'SS_ordered_carts');
	define('CATEGORIES_TABLE', 'SS_categories');
	define('SPECIAL_OFFERS_TABLE', 'SS_special_offers');

?>