<?php
	define('CONF_SHOP_NAME', 'Shop-Script FREE');
	define('CONF_SHOP_URL', 'www.shop-script.com');
	define('CONF_GENERAL_EMAIL', 'your@email.here');
	define('CONF_ORDERS_EMAIL', 'your@email.here');
	define('CONF_PAYPAL_EMAIL', 'paypal@webasyst.net');
	define('CONF_PAYPAL_INTEGRATION', 1);
?>