<?
//////////////////////////////////////////////////////////////
//           DEFINE THE LANGUAGE CHARSET TO USE             //
//                                                          //
// Possible values are;                                     //
// -------------------------------------------------------- //
// CHARSETNAME (use this)             VALUE                 //
// -------------------------------------------------------- //
// arabic                             iso-8859-6            //
// baltic                             iso-8859-4            //
// central european                   iso-8859-2            //
// chinese simplified                 euc-cn                //
// chinese traditional                big5                  //
// cyrillic                           koi8-r                //
// greek                              iso-8859-7            //
// hebrew                             iso-8859-8-i          //
// icelandic                          x-mac-icelandic       //
// japanese                           euc-jp                //
// korean                             euc-kr                //
// maltese                            iso-8859-3            //
// thai                               windows-874           //
// turkish                            iso-8859-9            //
// unicode                            utf-8                 //
// vietnamese                         windows-1258          //
// western                            iso-8859-1            //
//                                                          //
//////////////////////////////////////////////////////////////
define("language_charset", "Turkish");

//////////////////////////////////////////////////////////////
// When translating, beware to NOT use quotes (") within    //
// your texts. If you absolutely need to use quotes, prefix //
// them with a backslach (\")                               //
//////////////////////////////////////////////////////////////

	define("lang_general_yes", "Evet");
	define("lang_general_no", "Hay�r");
	define("lang_general_submit", "G�nder");
	define("lang_general_edit", "D�zenle");
	define("lang_general_delete", "Sil");
	define("lang_general_action", "Eylem");
	define("lang_general_id", "ID");
	define("lang_general_select", "-- Se�iniz --");
	define("lang_general_deleteconfirm", "Se�ili �geyi silmek istedi�inizden emin misiniz?");
	
	define("lang_pages_admin_advertisements_list_advertisements", "Reklamlar");
	define("lang_pages_admin_advertisements_list_name", "Ad�");
	define("lang_pages_admin_advertisements_list_addadvertisement", "Reklam ekle");
	define("lang_pages_admin_advertisements_list_friendlyname", "Reklam Ad�");
	define("lang_pages_admin_advertisements_list_imagefile", "Resim dosyas�");
	define("lang_pages_admin_advertisements_list_url", "URL");

	define("lang_pages_admin_categories_add_addnew", "Kategori ekle");
	define("lang_pages_admin_categories_add_categoryname", "Kategori ad�");
	define("lang_pages_admin_categories_add_parentcategory", "�st kategori");
	define("lang_pages_admin_categories_add_nonemastercat", "Yok (Ana kategori)");
	define("lang_pages_admin_categories_add_description", "A��klama");

	define("lang_pages_admin_categories_edit_editacategory", "Kategori d�zenle");
	define("lang_pages_admin_categories_edit_categoryname", "Kategori ad�");
	define("lang_pages_admin_categories_edit_parentcategory", "�st kategori");
	define("lang_pages_admin_categories_edit_nonemastercat", "Yok (Ana kategori)");
	define("lang_pages_admin_categories_edit_description", "A��klamalar");

	define("lang_pages_admin_categories_list_categories", "Kategoriler");
	define("lang_pages_admin_categories_list_name", "Ad�");
	define("lang_pages_admin_categories_list_parent", "�st kategori");
	define("lang_pages_admin_categories_list_description", "A��klama");
	define("lang_pages_admin_categories_list_addacategory", "Yeni kategori ekle");
	
	define("lang_pages_admin_currencies_edit_editcurrency", "Para birimi d�zenle");
	define("lang_pages_admin_currencies_edit_name", "Ad�");
	define("lang_pages_admin_currencies_edit_itlcc", "Uluslararas� birim kodu");
	define("lang_pages_admin_currencies_edit_default", "Varsay�lan");
	define("lang_pages_admin_currencies_edit_moneysymbol", "Birim sembol�");
	define("lang_pages_admin_currencies_edit_moneysymbollocation", "Sembol yerle�imi");
	define("lang_pages_admin_currencies_edit_onleftwithspace", "Solda bo�luklu");
	define("lang_pages_admin_currencies_edit_onleft", "Solda");
	define("lang_pages_admin_currencies_edit_onrightwithspace", "Sa�da bo�luklu");
	define("lang_pages_admin_currencies_edit_onright", "Sa�da");
	define("lang_pages_admin_currencies_edit_decsepsym", "Ondal�k ayra� sembol�");

	define("lang_pages_admin_currencies_list_currencies", "Para Birimleri");
	define("lang_pages_admin_currencies_list_name", "Ad");
	define("lang_pages_admin_currencies_list_code", "Kod");
	define("lang_pages_admin_currencies_list_default", "Varsay�lan");
	define("lang_pages_admin_currencies_list_addcurrency", "Para birimi ekle");
	define("lang_pages_admin_currencies_list_intlcc", "Uluslararas� birim kodu");
	define("lang_pages_admin_currencies_list_moneysymbol", "Birim sembol�");
	define("lang_pages_admin_currencies_list_moneysymbollocation", "Sembol yerle�imi");
	define("lang_pages_admin_currencies_list_onleftwithspace", "Solda bo�luklu");
	define("lang_pages_admin_currencies_list_onleft", "Solda");
	define("lang_pages_admin_currencies_list_onrightwithspace", "Sa�da bo�luklu");
	define("lang_pages_admin_currencies_list_onright", "Sa�da");
	define("lang_pages_admin_currencies_list_decsepsym", "Ondal�k ayra� sembol�");

	define("lang_pages_admin_manufacturers_add_addaman", "�retici ekle");
	define("lang_pages_admin_manufacturers_add_name", "Ad�");
	define("lang_pages_admin_manufacturers_add_website", "Web sitesi");
	define("lang_pages_admin_manufacturers_add_logofile", "Logo dosyas�");

	define("lang_pages_admin_manufacturers_edit_editman", "�retici d�zenle");
	define("lang_pages_admin_manufacturers_edit_name", "Ad�");
	define("lang_pages_admin_manufacturers_edit_website", "Web sitesi");
	define("lang_pages_admin_manufacturers_edit_actuallogo", "Kullan�lan logo");
	define("lang_pages_admin_manufacturers_edit_newlogofile", "Yeni logo dosyas�");
	define("lang_pages_admin_manufacturers_edit_gotomanlist", "�reticiler listesine d�n");
	
	define("lang_pages_admin_manufacturers_list_name", "Ad�");
	define("lang_pages_admin_manufacturers_list_website", "Web sitesi");
	define("lang_pages_admin_manufacturers_list_creationdate", "Eklenme tarihi");
	define("lang_pages_admin_manufacturers_list_logo", "Logo");
	define("lang_pages_admin_manufacturers_list_nopicture", "Resim yok");
	define("lang_pages_admin_manufacturers_list_createman", "Yeni �retici ekle");
	define("lang_pages_admin_manufacturers_list_totalman", "toplam �retici");

	define("lang_pages_admin_payment_blockconfig_paybkconfig", "�deme Mod�l� Ayarlar�");
	define("lang_pages_admin_payment_blockconfig_block", "Mod�l");
	
	define("lang_pages_admin_products_add_addnewproduct", "Yeni �r�n ekle");
	define("lang_pages_admin_products_add_productname", "�r�n ad�");
	define("lang_pages_admin_products_add_model", "Model");
	define("lang_pages_admin_products_add_intref", "Stok referans no");
	define("lang_pages_admin_products_add_category", "Kategori");
	define("lang_pages_admin_products_add_manufacturer", "�retici");
	define("lang_pages_admin_products_add_provider", "Da��t�c�");
	define("lang_pages_admin_products_add_select", "-- Se� --");
	define("lang_pages_admin_products_add_sellprice", "Sat�� fiyat�");
	define("lang_pages_admin_products_add_specialsellprice", "�ndirimli Fiyat");
	define("lang_pages_admin_products_add_costprice", "Al�� fiyat�");
	define("lang_pages_admin_products_add_qtyinstock", "Miktar");
	define("lang_pages_admin_products_add_reorderqty", "Stok alarm mik.");
	define("lang_pages_admin_products_add_backorder", "Stok d��� sipari�?");
	define("lang_pages_admin_products_add_available", "Sat�� Tarihi");
	define("lang_pages_admin_products_add_from", "Ba�lang��");
	define("lang_pages_admin_products_add_to", "Biti�");
	define("lang_pages_admin_products_add_weight", "A��rl�k");
	define("lang_pages_admin_products_add_featured", "Se�me �r�n");
	define("lang_pages_admin_products_add_visible", "Aktif");
	define("lang_pages_admin_products_add_rating", "Puan");
	define("lang_pages_admin_products_add_producturl", "�r�n URL");
	define("lang_pages_admin_products_add_productdescription", "�r�n a��klamas�");

	define("lang_pages_admin_products_edit_product", "�r�n");
	define("lang_pages_admin_products_edit_productname", "�r�n ad�");
	define("lang_pages_admin_products_edit_model", "Model");
	define("lang_pages_admin_products_edit_intrefnumber", "Stok referans no");
	define("lang_pages_admin_products_edit_category", "Kategori");
	define("lang_pages_admin_products_edit_manufacturer", "�retici");
	define("lang_pages_admin_products_edit_provider", "Da��t�mc�");
	define("lang_pages_admin_products_edit_none", "yok");
	define("lang_pages_admin_products_edit_sellprice", "Sat�� fiyat�");
	define("lang_pages_admin_products_edit_specialsellprice", "�ndirimli sat�� fiyat�");
	define("lang_pages_admin_products_edit_costprice", "Al�� fiyat�");
	define("lang_pages_admin_products_edit_qtyinstock", "Miktar");
	define("lang_pages_admin_products_edit_reorderqty", "Stok alarm mik.");
	define("lang_pages_admin_products_edit_backorder", "Stok d��� sipari�?");
	define("lang_pages_admin_products_edit_available", "Sat�� Tarihi");
	define("lang_pages_admin_products_edit_from", "Ba�lang��");
	define("lang_pages_admin_products_edit_to", "Biti�");
	define("lang_pages_admin_products_edit_weight", "A��rl�k");
	define("lang_pages_admin_products_edit_featured", "Se�me �r�n");
	define("lang_pages_admin_products_edit_visible", "Aktif");
	define("lang_pages_admin_products_edit_rating", "Puan");
	define("lang_pages_admin_products_edit_select", "Se�in");
	define("lang_pages_admin_products_edit_producturl", "�r�n URL");
	define("lang_pages_admin_products_edit_description", "A��klama");
	define("lang_pages_admin_products_edit_productdescription", "�r�n a��klamas�");
	define("lang_pages_admin_products_edit_gallery", "Galeri");
	define("lang_pages_admin_products_edit_file", "Dosya");
	define("lang_pages_admin_products_edit_view", "G�r�nt�le");
	define("lang_pages_admin_products_edit_addpictureforthatproduct", "Bu �r�n i�in bir resim ekle");
	define("lang_pages_admin_products_edit_picture", "Resim");
	define("lang_pages_admin_products_edit_relations", "Ba�lant�lar");
	define("lang_pages_admin_products_edit_relatedproducts", "�lgili �r�nler");
	define("lang_pages_admin_products_edit_relproductname", "�r�n ad�");
	define("lang_pages_admin_products_edit_breakrelationship", "Ba�lant�y� sil");
	define("lang_pages_admin_products_edit_productsthatrelate", "Bu �r�nle ilgili di�er �r�nler");
	define("lang_pages_admin_products_edit_bwproductname", "�r�n ad�");
	define("lang_pages_admin_products_edit_createrelationship", "Ba�lant� olu�tur");
	define("lang_pages_admin_products_edit_selectaproduct", "Bir �r�n se�in");
	define("lang_pages_admin_products_edit_pleaseselect", "-- L�tfen Se�iniz --");
	define("lang_pages_admin_products_edit_createreverserel", "Ters ba�lant� olu�tur");
	define("lang_pages_admin_products_edit_reviews", "Yorumlar");
	define("lang_pages_admin_products_edit_statistics", "�statistikler");
	define("lang_pages_admin_products_edit_gotoproductslist", "�r�n listesine git (y�netici g�r�nt�s�)");
	define("lang_pages_admin_products_edit_gotoproductdetails", "�r�n detaylar�na git (kullan�c� g�r�nt�s�)");
	
	define("lang_pages_admin_products_list_products", "�r�nler");
	define("lang_pages_admin_products_list_showproductsinthiscat", "Bu kategorideki �r�nleri g�ster");
	define("lang_pages_admin_products_list_allcategories", "T�m kategoriler");
	define("lang_pages_admin_products_list_name", "Ad");
	define("lang_pages_admin_products_list_model", "Model");
	define("lang_pages_admin_products_list_manufacturer", "�retici");
	define("lang_pages_admin_products_list_price", "Fiyat");
	define("lang_pages_admin_products_list_addnewproduct", "Yeni �r�n ekle");
	define("lang_pages_admin_products_list_productsindatabase", "- veritaban�ndaki �r�n say�s�");

	define("lang_pages_admin_products_pictures_picturesforproduct", "�r�n resimleri");
	define("lang_pages_admin_products_pictures_picturefile", "Resim dosyas�");
	define("lang_pages_admin_products_pictures_view", "G�r�nt�le");
	define("lang_pages_admin_products_pictures_delete", "Sil");
	define("lang_pages_admin_products_pictures_addapictureforthatproduct", "Bu �r�n i�in resim ekle");
	define("lang_pages_admin_products_pictures_picture", "Resim");
	define("lang_pages_admin_products_pictures_finished", "Tamamland�");

	define("lang_pages_admin_providers_list_providerslist", "Da��t�c�lar listesi");
	define("lang_pages_admin_providers_list_name", "Ad");
	define("lang_pages_admin_providers_list_addaprovider", "Da��t�c� ekle");
	define("lang_pages_admin_providers_list_addname", "Ad");

	define("lang_pages_admin_shipping_config_shippingmethods", "Nakliye Ayarlar�");
	define("lang_pages_admin_shipping_config_name", "Ad");
	define("lang_pages_admin_shipping_config_addnewshippingmethod", "Nakliye �ekli ekle");
	define("lang_pages_admin_shipping_config_addname", "Ad");
	define("lang_pages_admin_shipping_config_description", "A��klamalar");
	define("lang_pages_admin_shipping_config_arithmeticoperation", "Aritmetik hesap");

	define("lang_pages_admin_shipping_edit_editshippingmethod", "Nakliye �ekli d�zenle");
	define("lang_pages_admin_shipping_edit_name", "Ad");
	define("lang_pages_admin_shipping_edit_description", "A��klama");
	define("lang_pages_admin_shipping_edit_arithmeticoperation", "Aritmetik hesap");

	define("lang_pages_admin_shopping_details_invoicedetails", "Fatura detaylar�");
	define("lang_pages_admin_shopping_details_invoiceid", "Fatura No");
	define("lang_pages_admin_shopping_details_shippingmethod", "Nakliye �ekli");
	define("lang_pages_admin_shopping_details_shippingcost", "Nakliye �creti");
	define("lang_pages_admin_shopping_details_paymentmethod", "�deme �ekli");
	define("lang_pages_admin_shopping_details_orderdate", "Sipari� tarihi");
	define("lang_pages_admin_shopping_details_customer", "M��teri");
	define("lang_pages_admin_shopping_details_total", "Toplam: (vergi dahil, kargo hari�)");
	define("lang_pages_admin_shopping_details_grandtotal", "TOPLAM");
	define("lang_pages_admin_shopping_details_status", "Durum");
	define("lang_pages_admin_shopping_details_stadminconf", "Sat�c� onay� bekleniyor");
	define("lang_pages_admin_shopping_details_stpaymentconfirmed", "�deme onayland�");
	define("lang_pages_admin_shopping_details_stpackaginginprocess", "Paket haz�rlan�yor");
	define("lang_pages_admin_shopping_details_stshipped", "Kargoya verildi");
	define("lang_pages_admin_shopping_details_stpaymentretracted", "�deme geri al�nd�");
	define("lang_pages_admin_shopping_details_stdeclaredasfraudulent", "Hileli i�lem bildirimi");
	define("lang_pages_admin_shopping_details_streceivedbycustomer", "M��teri taraf�ndan al�nd�");
	define("lang_pages_admin_shopping_details_streturnedbycustomer", "M��teri taraf�ndan geri g�nderildi");
	define("lang_pages_admin_shopping_details_stother", "Di�er");
	define("lang_pages_admin_shopping_details_stcompleted", "Tamamland�");
	define("lang_pages_admin_shopping_details_productsbought", "Sat�n al�nan �r�nler");
	define("lang_pages_admin_shopping_details_backtoinvoiceslist", "Fatura listesine d�n");
	
	define("lang_pages_admin_shopping_invoices_invoices", "Faturalar");
	define("lang_pages_admin_shopping_invoices_invoicenumber", "Fatura No");
	define("lang_pages_admin_shopping_invoices_date", "Tarih");
	define("lang_pages_admin_shopping_invoices_status", "Durum");
	define("lang_pages_admin_shopping_invoices_stawaitingadminconfirmation", "Sat�c� onay� bekleniyor");
	define("lang_pages_admin_shopping_invoices_stpaymentconfirmed", "�deme onayland�");
	define("lang_pages_admin_shopping_invoices_stpackaginginprocess", "Paket haz�rlan�yor");
	define("lang_pages_admin_shopping_invoices_stshipped", "Kargoya verildi");
	define("lang_pages_admin_shopping_invoices_stpaymentretracted", "�deme geri al�nd�");
	define("lang_pages_admin_shopping_invoices_stdeclaredasfraudulent", "Hileli i�lem bildirimi");
	define("lang_pages_admin_shopping_invoices_streceivedbycustomer", "M��teri taraf�ndan al�nd�");
	define("lang_pages_admin_shopping_invoices_streturnedbycustomer", "M��teri taraf�ndan geri g�nderildi");
	define("lang_pages_admin_shopping_invoices_stothers", "Di�er");
	define("lang_pages_admin_shopping_invoices_stcompleted", "Tamamland�");
	define("lang_pages_admin_shopping_invoices_details", "Detaylar");

	define("lang_pages_admin_system_languages_add_newlanguage", "Yeni dil");
	define("lang_pages_admin_system_languages_add_languagename", "Dil ad�");
	define("lang_pages_admin_system_languages_add_dictionaryfile", "S�zl�k dosyas�");
	define("lang_pages_admin_system_languages_add_defaultlanguage", "Varsay�lan dil");

	define("lang_pages_admin_system_languages_edit_editlanguage", "Dil d�zenle");
	define("lang_pages_admin_system_languages_edit_languagename", "Dil ad�");
	define("lang_pages_admin_system_languages_edit_dictionaryfile", "S�zl�k dosyas�");
	define("lang_pages_admin_system_languages_edit_defaultlanguage", "Varsay�lan dil");

	define("lang_pages_admin_system_languages_list_systemlanguages", "Dil ayarlar�");
	define("lang_pages_admin_system_languages_list_languagename", "Dil ad�");
	define("lang_pages_admin_system_languages_list_addsystemlanguage", "Yeni dil ekle");

	define("lang_pages_admin_system_texts_editor_homepagewelcometext", "Ana Sayfa ho�geldiniz sayfas�");
	define("lang_pages_admin_system_texts_editor_contactusintrotext", "Bize Ula��n giri� yaz�s�");
	define("lang_pages_admin_system_texts_editor_orderconfirmationemail", "Sipari� Onay e-posta");
	define("lang_pages_admin_system_texts_editor_privacynoticepage", "Gizlilik Bildirimi sayfas�");
	define("lang_pages_admin_system_texts_editor_conditionofusepage", "Kullan�m �artlar� sayfas�");
	define("lang_pages_admin_system_texts_editor_shippingandreturnpage", "Nakliye ve �ade sayfas�");
	define("lang_pages_admin_system_texts_editor_text", "Yaz�");

	define("lang_pages_admin_system_texts_selang_youareabout", "Sistem yaz�lar�n� d�zenlemek �zeresiniz");
	define("lang_pages_admin_system_texts_selang_pleaseselect", "L�tfen d�zenlenecek dili se�in");

	define("lang_pages_admin_system_general_generalsystemsettings", "Genel Sistem Ayarlar�");
	define("lang_pages_admin_system_general_companyname", "Firma Ad�");
	define("lang_pages_admin_system_general_adminname", "Y�netici ad�");
	define("lang_pages_admin_system_general_adminemail", "Y�netici e-posta adresi");
	define("lang_pages_admin_system_general_systememail", "Ma�aza e-posta adresi");
	define("lang_pages_admin_system_general_rooturl", "Site i�in k�k Dizin (URL)");
	define("lang_pages_admin_system_general_departurezip", "Ma�aza posta kodu");
	define("lang_pages_admin_system_general_taxarithmeticoper", "Vergi aritmetik hesab�");
	define("lang_pages_admin_system_general_catlistorder", "Kategori a�ac� s�ralama d�zeni");
	define("lang_pages_admin_system_general_insertorderasc", "Eklenme s�ras�na g�re, Artan");
	define("lang_pages_admin_system_general_insertorderdesc", "Eklenme s�rasina g�re, Azalan");
	define("lang_pages_admin_system_general_catnameasc", "Kategori ad�na g�re, Artan");
	define("lang_pages_admin_system_general_catnamedesc", "Kategori ad�na g�re, Azalan");
	define("lang_pages_admin_system_general_weightunit", "A��rl�k birimi");
	define("lang_pages_admin_system_general_kilograms", "Kilogram");
	define("lang_pages_admin_system_general_pounds", "Pound");
	define("lang_pages_admin_system_general_metrictons", "Metrik ton");
	define("lang_pages_admin_system_general_grams", "Gram");
	define("lang_pages_admin_system_general_miligrams", "Miligram");
	define("lang_pages_admin_system_general_tons", "Ton");
	define("lang_pages_admin_system_general_ounces", "Ons");
	define("lang_pages_admin_system_general_showprodbo", "Stok D��� Sat�� olarak i�aretlenmi� �r�nleri g�ster");
	define("lang_pages_admin_system_general_buybo", "M��teriler stok d��� �r�nleri alabilir");
	define("lang_pages_admin_system_general_showbo", "Stok D��� Sat�� durumunu g�ster");
	define("lang_pages_admin_system_general_showoutofdate", "Tarih aral���n� ge�mi� �r�nleri g�ster");
	define("lang_pages_admin_system_general_orderoutofrange", "M��teriler tarih aral��� ge�mi� �r�nleri alabilir");
	define("lang_pages_admin_system_general_defaultthemetouse", "Varsay�lan g�rsel tema");

	define("lang_pages_admin_users_details_customersdetails", "M��teri Detaylar�");
	define("lang_pages_admin_users_details_firstname", "Ad");
	define("lang_pages_admin_users_details_lastname", "Soyad");
	define("lang_pages_admin_users_details_emailaddress", "E-posta  adresi");
	define("lang_pages_admin_users_details_password", "�ifre");
	define("lang_pages_admin_users_details_companyname", "Firma ad�");
	define("lang_pages_admin_users_details_address", "Adres");
	define("lang_pages_admin_users_details_city", "�l");
	define("lang_pages_admin_users_details_state", "�l�e");
	define("lang_pages_admin_users_details_zipcode", "Posta kodu");
	define("lang_pages_admin_users_details_country", "�lke");
	define("lang_pages_admin_users_details_phonenumber", "Telefon");
	define("lang_pages_admin_users_details_faxnumber", "Faks");
	define("lang_pages_admin_users_details_isadmin", "Y�netici");
	define("lang_pages_admin_users_details_backtocustomerslist", "M��teri listesine d�n");
	define("lang_pages_admin_users_details_sendemail", "E-posta  g�nder");

	define("lang_pages_admin_users_list_customersanduserslist", "M��teri & Kullan�c� listesi");
	define("lang_pages_admin_users_list_name", "Ad");
	define("lang_pages_admin_users_list_details", "Detaylar");
	
	define("lang_pages_admin_system_updates_systemupdate", "Sistem g�ncelleme");
	define("lang_pages_admin_system_updates_insertcode", "L�tfen sistem g�ncelleme kodunu giriniz");

	define("lang_pages_admin_menu_adminmenu", "Y�netim Men�s�");
	define("lang_pages_admin_menu_manufacturerprovider", "�reticiler & Da��t�mc�lar");
	define("lang_pages_admin_menu_manufacturerslist", "�reticiler Listesi");
	define("lang_pages_admin_menu_addmanufacturer", "�retici Ekle");
	define("lang_pages_admin_menu_providerslist", "Da��t�mc�lar Listesi");
	define("lang_pages_admin_menu_categoriesandproducts", "Kategoriler & �r�nler");
	define("lang_pages_admin_menu_categorieslist", "Kategori Listesi");
	define("lang_pages_admin_menu_addacategory", "Kategori Ekle");
	define("lang_pages_admin_menu_productslist", "�r�n Listesi");
	define("lang_pages_admin_menu_addaproduct", "�r�n Ekle");
	define("lang_pages_admin_menu_systemsettings", "Sistem Ayarlar�");
	define("lang_pages_admin_menu_generalsystemsettings", "Genel Sistem Ayarlar�");
	define("lang_pages_admin_menu_advertisementsmanagement", "Reklam Y�netimi");
	define("lang_pages_admin_menu_languagesmanagement", "Dil Y�netimi");
	define("lang_pages_admin_menu_currenciesmanagement", "Para Birimleri Y�netimi");
	define("lang_pages_admin_menu_systemtextseditor", "Sistem Yaz�lar� Edit�r�");
	define("lang_pages_admin_menu_paymentblocksconfiguration", "�deme Ayarlar�");
	define("lang_pages_admin_menu_shippingconfigurations", "Nakliye Ayarlar�");
	define("lang_pages_admin_menu_shopping", "Al��veri�");
	define("lang_pages_admin_menu_invoicesandorders", "Fatura & Sipari�ler");
	define("lang_pages_admin_menu_customersandusers", "M��teriler & Kullan�c�lar");
	define("lang_pages_admin_menu_stockmanagement", "Stok Y�netimi");
	define("lang_pages_admin_menu_updates", "Sistem G�ncelleme");

	define("lang_pages_cart_checkout_youarenowregistered", "Kayd�n�z yap�ld�. L�tfen bu formu doldurunuz");
	define("lang_pages_cart_checkout_emailaddress", "E-posta  adresi");
	define("lang_pages_cart_checkout_password", "�ifre");
	define("lang_pages_cart_checkout_login", "Oturum A�");
	define("lang_pages_cart_checkout_ifyouprev", "Daha �nce ma�azam�zdan al��veri� yapt�ysan�z, l�tfen oturum a��n�z");
	define("lang_pages_cart_checkout_ifthisisyourfirstorder", "Ma�azam�zdan ilk defa al��veri� yap�yorsan�z , l�tfen formu doldurunuz");
	define("lang_pages_cart_checkout_firstname", "Ad�n�z");
	define("lang_pages_cart_checkout_lastname", "Soyad�n�z");
	define("lang_pages_cart_checkout_email", "E-posta adresiniz");
	define("lang_pages_cart_checkout_desiredpassword", "�ifreniz");
	define("lang_pages_cart_checkout_companyname", "Firma Ad�");
	define("lang_pages_cart_checkout_address", "Adres");
	define("lang_pages_cart_checkout_city", "�l");
	define("lang_pages_cart_checkout_stateprovince", "�l�e");
	define("lang_pages_cart_checkout_zip", "Posta Kodu");
	define("lang_pages_cart_checkout_country", "�lke");
	define("lang_pages_cart_checkout_phonenumber", "Telefon");
	define("lang_pages_cart_checkout_faxnumber", "Faks");
	define("lang_pages_cart_checkout_shippingaddress", "Kargo adresi");
	define("lang_pages_cart_checkout_name", "Ad");
	define("lang_pages_cart_checkout_order", "Sipari�");
	define("lang_pages_cart_checkout_item", "�r�n");
	define("lang_pages_cart_checkout_qty", "Miktar");
	define("lang_pages_cart_checkout_unitprice", "Birim Fiyat");
	define("lang_pages_cart_checkout_total", "Toplam");
	define("lang_pages_cart_checkout_subtotal", "Ara-Toplam");
	define("lang_pages_cart_checkout_taxes", "KDV");
	define("lang_pages_cart_checkout_shipping", "Kargo");
	define("lang_pages_cart_checkout_paymentmethod", "�deme �ekli");

	define("lang_pages_cart_confirmorder_orderconfirmation", "Sipari� onay�");
	
	define("lang_pages_cart_show_product", "�r�n");
	define("lang_pages_cart_show_qty", "Miktar");
	define("lang_pages_cart_show_unitprice", "Birim Fiyat");
	define("lang_pages_cart_show_subtotal", "Ara-Toplam");
	define("lang_pages_cart_show_checkout", "Sat�n Al");
	define("lang_pages_cart_show_cartempty", "Sepetiniz bo�");
	
	define("lang_pages_information_contact_thankyou", "Te�ekk�rler, en k�sa zamanda size geri d�nece�iz");
	define("lang_pages_information_contact_name", "Ad / Soyad");
	define("lang_pages_information_contact_email", "E-posta adresi");
	define("lang_pages_information_contact_service", "Departman");
	define("lang_pages_information_contact_subject", "Konu");
	define("lang_pages_information_contact_message", "Mesaj");

	define("lang_pages_products_details_addedtoshoppingcart", "�r�n sepetinize eklendi");
	define("lang_pages_products_details_edit", "D�zenle");
	define("lang_pages_products_details_morepictures", "Di�er resimler");
	define("lang_pages_products_details_relatedproducts", "�lgili �r�nler");
	define("lang_pages_products_details_ourrating", "Ma�aza Puan�");
	define("lang_pages_products_details_customersrating", "Kullan�c� Puan�");
	define("lang_pages_products_details_rateit", "Puan Ver");
	define("lang_pages_products_details_tellafriend", "Arkada��ma G�nder");
	define("lang_pages_products_details_special", "�ndirimde");
	define("lang_pages_products_details_addtocart", "Sepete ekle");
	define("lang_pages_products_details_backorder", "Bu �r�n stokta yok");
	define("lang_pages_products_details_availablefrom", "�r�n�n sat��ta olaca�i tarih");
	define("lang_pages_products_details_to", "-");
	define("lang_pages_products_details_availableuntil", "Bu �r�n �u tarihe kadar sat��ta olacakt�r");
	define("lang_pages_products_details_backtolist", "�r�n listesine d�n");

	define("lang_pages_products_list_addedtoshoppingcart", "�r�n sepetinize eklendi");
	define("lang_pages_products_list_productsin", "�r�nler");
	define("lang_pages_products_list_home", "Ana Sayfa");
	define("lang_pages_products_list_buy", "Sat�n Al");
	define("lang_pages_products_list_details", "Detaylar");
	define("lang_pages_products_list_backorder", "Stok d��� sipari�");
	define("lang_pages_products_list_edit", "D�zenle");
	define("lang_pages_products_list_youmaywanttolook", "Bu alt kategorilere de bakmak isteyebilirsiniz.");
	
	define("lang_pages_products_listmanuf_addedtoshoppingcart", "�r�n sepetinize eklendi");
	define("lang_pages_products_listmanuf_productsby", "�r�nler");
	define("lang_pages_products_listmanuf_buy", "Sat�n Al");
	define("lang_pages_products_listmanuf_details", "Detaylar");
	
	define("lang_pages_products_tellafriend_checkthisurl", "Merhaba! �u adrese bak");
	define("lang_pages_products_tellafriend_tellafriend", "Arkada��ma G�nder");
	define("lang_pages_products_tellafriend_friendsemail", "Arkada��n�z�n e-posta adresi");
	define("lang_pages_products_tellafriend_emailsubject", "E-posta konusu");
	define("lang_pages_products_tellafriend_hey", "Merhaba! �una bir bak!");

	define("lang_pages_products_search_searchresults", "Arama sonu�lar� - aranan :");
	define("lang_pages_products_search_matches", "�r�n bulundu");

	define("lang_themes_bykeywords", "Anahtar Kelime");
	define("lang_pages_themes_home", "Ana Sayfa");
	define("lang_pages_themes_shoppingcart", "Sepet");
	define("lang_pages_themes_contactus", "Bize Ula��n");
	define("lang_pages_themes_admin", "Y�netim");
	define("lang_pages_themes_yourcart", "Al��veri� Sepetiniz");
	define("lang_pages_themes_details", "Detaylar");
	define("lang_pages_themes_items", "�r�n");
	define("lang_pages_themes_total", "toplam");
	define("lang_pages_themes_language", "Dil");
	define("lang_pages_themes_currency", "Para Birimi");
	define("lang_pages_themes_usersonline", "Kullan�c� aktif");
	define("lang_pages_themes_products", "�r�n");
	define("lang_pages_themes_uptime", "Uptime");
	define("lang_pages_themes_days", "g�n");

	define("lang_pages_themes_home_welcome", "Ho� Geldiniz");
	define("lang_pages_themes_home_featured", "Bizim Se�tiklerimiz");
	define("lang_pages_themes_home_details", "Detaylar");
	define("lang_pages_themes_home_newproducts", "Yeni �r�nler");
	define("lang_pages_themes_home_email", "E-posta");
	define("lang_pages_themes_home_password", "�ifre");
	define("lang_pages_themes_home_loggedin", "Oturum A��ld�");

	define("lang_pages_themes_blocks_browsemanufacturers_browsebyman", "�reticiler");
	define("lang_pages_themes_blocks_browsemanufacturers_select", "-- Se�iniz --");

	define("lang_pages_themes_blocks_cataloguecats_cataloguecategories", "Kategoriler");

	define("lang_pages_themes_blocks_categoriesdrop_bycategory", "Kategori");
	define("lang_pages_themes_blocks_categoriesdrop_select", "-- Se�iniz --");

	define("lang_pages_themes_blocks_informations_informations", "Bilgi");
	define("lang_pages_themes_blocks_informations_contactus", "Bize Ula��n");
	define("lang_pages_themes_blocks_informations_privacynotice", "Gizlilik Bildirimi");
	define("lang_pages_themes_blocks_informations_conditionsofuse", "Kullan�m �artlar�");
	define("lang_pages_themes_blocks_informations_shippingandreturns", "Nakliye ve �ade");


	//////////////////////////////////////////////////////////////////////////////////////////
	// NEW LANGUAGES FIELDS ADDED AFTER V.905B
	//////////////////////////////////////////////////////////////////////////////////////////
	
	define("lang_pages_admin_products_pictures_whattodo", "�imdi ne yapmak istiyosunuz?");
	define("lang_pages_admin_products_pictures_backtoproductslist", "�r�n listesine d�n");
	define("lang_pages_admin_products_pictures_redirection", "5 saniye i�inde y�nlendiriliyor");
	define("lang_pages_admin_products_pictures_setmore", "Bu �r�nle ilgili ba�ka ayarlar yap");
	define("lang_pages_admin_products_pictures_addanother", "Ba�ka bir �r�n ekle");


	define("lang_pages_admin_system_general_companylogo", "�irket logosu");
	
	define("lang_pages_cart_show_total", "Toplam");
	define("lang_pages_cart_show_addone", "�r�n adedini 1 art�r");
	define("lang_pages_cart_show_remone", "�r�n adedini 1 azalt");
	define("lang_pages_cart_show_donerem", "�r�n adedi 1 azalt�ld�");
	define("lang_pages_cart_show_doneadd", "�r�n adedi 1 art�r�ld�");
	define("lang_pages_cart_show_details", "Detaylar");
	
	define("lang_pages_products_search_addedtoshoppingcart", "�r�n al��veri� sepetinize eklendi");
	
	define("lang_pages_themes_home_logout", "Oturumu Kapat");
	
	define("lang_pages_admin_system_general_tabsystem", "Sistem");
	define("lang_pages_admin_system_general_tabcompany", "�irket");
	define("lang_pages_admin_system_general_tabstyle", "Stil");
	define("lang_pages_admin_system_general_tabproducts", "�r�nler");
	
	define("lang_pages_admin_advertisements_list_list", "Liste");
	define("lang_pages_admin_advertisements_list_add", "Ekle");
	
	define("lang_pages_admin_manufacturers_list_manufacturers", "�reticiler");
	define("lang_pages_admin_manufacturers_list_list", "Liste");
	define("lang_pages_admin_manufacturers_list_create", "Olu�tur");
	
	define("lang_pages_admin_providers_list_list", "Liste");
	define("lang_pages_admin_providers_list_create", "Olu�tur");
	
	define("lang_pages_admin_categories_list_head", "Kategoriler");
	define("lang_pages_admin_categories_list_list", "Liste");
	define("lang_pages_admin_categories_list_create", "Olu�tur");
	
	define("lang_pages_admin_system_languages_list_list", "Liste");
	define("lang_pages_admin_system_languages_list_create", "Olu�tur");
	
	define("lang_pages_admin_currencies_list_list", "Liste");
	define("lang_pages_admin_currencies_list_create", "Olu�tur");
	
	define("lang_pages_admin_shipping_config_shipping", "Nakliye");
	define("lang_pages_admin_shipping_config_list", "Liste");
	define("lang_pages_admin_shipping_config_create", "Olu�tur");
	
	define("lang_pages_admin_system_languages_list_list", "Liste");
	define("lang_pages_admin_system_languages_list_create", "Olu�tur");
	
	define("lang_pages_admin_products_edit_editproduct", "�r�n d�zenle");
	
	define("lang_pages_admin_providers_list_providers", "Da��t�mc�lar");
	
	define("lang_pages_admin_system_general_ratingstyleimage", "Resim kullan");
	define("lang_pages_admin_system_general_ratingstyletext", "Yaz� kullan");
	define("lang_pages_admin_system_general_ratingstyle", "�r�n puanlar� nas�l g�sterilsin?");

	//////////////////////////////// NEW FIELDS ADDED AFTER V0921B /////////////////////////////////////
	define("lang_pages_admin_shopping_details_notesforthisinvoice", "Fatura notlar�");

	define("lang_pages_admin_products_edit_noreviews", "Bu �r�n hakk�nda hen�z bir yorum yok");
	define("lang_pages_admin_products_edit_productsreviews", "�r�n hakk�nda yorumlar");
	
	define("lang_pages_admin_system_general_enablereviews", "�r�n yorumlar� sistemini etkinle�tir");
	
	define("lang_pages_products_details_reviews", "Yorumlar");
	define("lang_pages_products_details_readreviews", "Yorumlar� oku");
	define("lang_pages_products_details_writereview", "Yorum yaz");
	
	define("lang_pages_reviews_read_reviewsfor", "Yorumlar: ");
	define("lang_pages_reviews_read_user", "Kullan�c�");
	define("lang_pages_reviews_read_reviewproduct", "Yorum yaz");
	
	define("lang_pages_reviews_write_thankyou", "Te�ekk�rler");
	define("lang_pages_reviews_write_writefor", "G�r���n�z� bildirin - ");
	define("lang_pages_reviews_write_nickname", "Takma ad�n�z");
	define("lang_pages_reviews_write_yourreview", "Yorumunuz");

	define("lang_pages_admin_mailing_mailing_sending", "E-posta g�nderiliyor... L�tfen bekleyiniz");
	define("lang_pages_admin_mailing_mailing_errorsendingto", "Hata! E-posta �u adrese g�nderilemedi: ");
	define("lang_pages_admin_mailing_mailing_skipping", "Vazge�iliyor");
	define("lang_pages_admin_mailing_mailing_mailsentto", "E-posta g�nderildi - ");
	define("lang_pages_admin_mailing_mailing_finished", "Tamamland�");
	define("lang_pages_admin_mailing_mailing_sent", "G�nderildi");
	define("lang_pages_admin_mailing_mailing_skip", "Vazge�ildi");
	define("lang_pages_admin_mailing_mailing_mailinglist", "E-posta Listesi Y�netimi");
	define("lang_pages_admin_mailing_mailing_from", "G�nderen");
	define("lang_pages_admin_mailing_mailing_to", "Al�c�");
	define("lang_pages_admin_mailing_mailing_subject", "Konu");
	define("lang_pages_admin_mailing_mailing_message", "Mesaj");
	define("lang_pages_admin_mailing_mailing_everymember", "T�m kay�tl� kullan�c�lar");
	
	define("lang_pages_admin_stats_access_accessstatsfor", "Eri�im istatistikleri,");
	
	define("lang_pages_admin_stats_sales_salesstatsfor", "Sat�� istatistikleri,");
	define("lang_pages_admin_stats_sales_soldunitsfor", "Sat�� adedi (t�m �r�nler),");
	define("lang_pages_admin_stats_sales_soldunits", "Sat�� adedi");
	define("lang_pages_admin_stats_sales_salesstatsfor", "Sat�� istatistikleri (t�m �r�nler),");
	define("lang_pages_admin_stats_sales_salesstats", "Sat��lar");

	define("lang_pages_admin_system_general_usesmiles", "�r�n yorumlar�nda \"smiles\" kullan�ls�n");
	define("lang_pages_admin_system_general_cookieprefix", "�erez (cookie) �n ad�");
	
	define("lang_theme_lostpass", "�ifre hat�rlatma");
	define("lang_theme_register", "Yeni kay�t");
		
	define("lang_pages_lostpass_error", "Hata: Belirtti�iniz E-posta adresi kullan�c� veritaban�nda bulunamad�");
	define("lang_pages_lostpass_yourpassword", "�ifreniz");
	define("lang_pages_lostpass_yourpasson", " ");
	define("lang_pages_lostpass_is", "ma�azas�ndaki �ifreniz");
	define("lang_pages_lostpass_passsent", "�ifreniz a�a��daki e-posta adresine g�nderildi");
	define("lang_pages_lostpass_lostpass", "�ifre hat�rlatma");
	define("lang_pages_lostpass_toptext", "L�tfen a�a��daki formu doldurunuz. �ifreniz e-posta ile size g�nderilecektir.");
	define("lang_pages_lostpass_email", "E-posta adresi");

	define("lang_pages_admin_system_texts_editor_registrationtext", "Kay�t sayfas�nda g�sterilecek yaz�"); 
	
	define("lang_pages_register_register_registration", "Kullan�c� kayd�");
	
	define("lang_pages_register_register_firstname", "Ad");
	define("lang_pages_register_register_lastname", "Soyad");
	define("lang_pages_register_register_email", "E-posta adresi");
	define("lang_pages_register_register_desiredpassword", "�ifre");
	define("lang_pages_register_register_companyname", "�irket ad�");
	define("lang_pages_register_register_address", "Adres");
	define("lang_pages_register_register_city", "�l");
	define("lang_pages_register_register_stateprovince", "�l�e");
	define("lang_pages_register_register_zip", "Posta kodu");
	define("lang_pages_register_register_country", "�lke");
	define("lang_pages_register_register_phonenumber", "Telefon");
	define("lang_pages_register_register_faxnumber", "Faks");
	define("lang_pages_register_register_registered", "Te�ek��rler. Kayd�n�z yap�ld�.");
	
	define("lang_pages_admin_system_general_showcount", "Kategori ad� yan�nda �r�n miktar�n� g�ster");
	define("lang_pages_admin_system_general_linktofolder", "Kategori a�ac�ndaki ana klas�rlere link ver");
	define("lang_pages_admin_system_general_highlightselected", "Kategori a�ac�ndaki se�ili �geyi renklendir");
	define("lang_pages_admin_system_general_showlines", "Kategori a�ac�ndaki ba�lant� �izgilerini g�ster");
	define("lang_pages_admin_system_general_useicons", "Kategori a�ac�nda ikon kullan");
	define("lang_pages_admin_system_general_displaydesc", "Kategori a�ac�ndaki �gelerin a��klamalar�n� Status bar'da g�ster");
	define("lang_pages_admin_system_general_closesame", "Ayn� seviyedeki kategorileri kapat");
	define("lang_pages_admin_system_general_expandall", "Varsay�lan olarak a�a�taki t�m kategorileri a�");
	
	define("lang_pages_admin_categories_list_sortorder", "S�ralama");
	
	define("lang_pages_admin_system_general_sortorder", "S�ra numaras�");	