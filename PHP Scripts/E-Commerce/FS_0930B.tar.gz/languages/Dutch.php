<?
//////////////////////////////////////////////////////////////
//           DEFINE THE LANGUAGE CHARSET TO USE             //
//                                                          //
// Possible values are;                                     //
// -------------------------------------------------------- //
// CHARSETNAME (use this)             VALUE                 //
// -------------------------------------------------------- //
// arabic                             iso-8859-6            //
// baltic                             iso-8859-4            //
// central european                   iso-8859-2            //
// chinese simplified                 euc-cn                //
// chinese traditional                big5                  //
// cyrillic                           koi8-r                //
// greek                              iso-8859-7            //
// hebrew                             iso-8859-8-i          //
// icelandic                          x-mac-icelandic       //
// japanese                           euc-jp                //
// korean                             euc-kr                //
// maltese                            iso-8859-3            //
// thai                               windows-874           //
// turkish                            iso-8859-9            //
// unicode                            utf-8                 //
// vietnamese                         windows-1258          //
// western                            iso-8859-1            //
//                                                          //
//////////////////////////////////////////////////////////////
define("language_charset", "Western");

//////////////////////////////////////////////////////////////
// When translating, beware to NOT use quotes (") within    //
// your texts. If you absolutely need to use quotes, prefix //
// them with a backslach (\")                               //
//////////////////////////////////////////////////////////////

	define("lang_general_yes", "JA");
	define("lang_general_no", "Nee");
	define("lang_general_submit", "Verzenden");
	define("lang_general_edit", "Bewerken");
	define("lang_general_delete", "Verwijderen");
	define("lang_general_action", "Actie");
	define("lang_general_id", "ID");
	define("lang_general_select", "-- Selecteer --");
	define("lang_general_deleteconfirm", "Wilt u werkelijk het geselecteerde verwijderen?");
	
	define("lang_pages_admin_advertisements_list_advertisements", "Reclame");
	define("lang_pages_admin_advertisements_list_name", "Naam");
	define("lang_pages_admin_advertisements_list_addadvertisement", "Reclame toevoegen");
	define("lang_pages_admin_advertisements_list_friendlyname", "Naam");
	define("lang_pages_admin_advertisements_list_imagefile", "Image bestand");
	define("lang_pages_admin_advertisements_list_url", "URL");

	define("lang_pages_admin_categories_add_addnew", "Categorie toevoegen");
	define("lang_pages_admin_categories_add_categoryname", "Categorie naam");
	define("lang_pages_admin_categories_add_parentcategory", "Onderdeel van");
	define("lang_pages_admin_categories_add_nonemastercat", "Geen (Hoofd categorie)");
	define("lang_pages_admin_categories_add_description", "Omschrijving");

	define("lang_pages_admin_categories_edit_editacategory", "Bewerk een categorie");
	define("lang_pages_admin_categories_edit_categoryname", "Categorie naam");
	define("lang_pages_admin_categories_edit_parentcategory", "Sub categorie");
	define("lang_pages_admin_categories_edit_nonemastercat", "Geen (Hoofd categorie)");
	define("lang_pages_admin_categories_edit_description", "Omschrijving");

	define("lang_pages_admin_categories_list_categories", "Categorie�n");
	define("lang_pages_admin_categories_list_name", "Naam");
	define("lang_pages_admin_categories_list_parent", "Onderdeel van");
	define("lang_pages_admin_categories_list_description", "Omschrijving");
	define("lang_pages_admin_categories_list_addacategory", "Categorie toevoegen");
	
	define("lang_pages_admin_currencies_edit_editcurrency", "Bewerk valuta");
	define("lang_pages_admin_currencies_edit_name", "Naam");
	define("lang_pages_admin_currencies_edit_itlcc", "Internationale valuta code");
	define("lang_pages_admin_currencies_edit_default", "Standaard");
	define("lang_pages_admin_currencies_edit_moneysymbol", "Valuta symbool");
	define("lang_pages_admin_currencies_edit_moneysymbollocation", "symbool locatie");
	define("lang_pages_admin_currencies_edit_onleftwithspace", "Op de linkerzijde met spatie");
	define("lang_pages_admin_currencies_edit_onleft", "Op de linkerzijde");
	define("lang_pages_admin_currencies_edit_onrightwithspace", "Op de rechterzijde met spatie");
	define("lang_pages_admin_currencies_edit_onright", "Op de rechterzijde");
	define("lang_pages_admin_currencies_edit_decsepsym", "Decimaal afscheiden met");

	define("lang_pages_admin_currencies_list_currencies", "Valuta�s");
	define("lang_pages_admin_currencies_list_name", "Naam");
	define("lang_pages_admin_currencies_list_code", "Code");
	define("lang_pages_admin_currencies_list_default", "Standaard");
	define("lang_pages_admin_currencies_list_addcurrency", "Valuta toevoegen");
	define("lang_pages_admin_currencies_list_intlcc", "Internationale valuta code");
	define("lang_pages_admin_currencies_list_moneysymbol", "Valuta symbool");
	define("lang_pages_admin_currencies_list_moneysymbollocation", "symbool locatie");
	define("lang_pages_admin_currencies_list_onleftwithspace", "Op de linkerzijde met spatie");
	define("lang_pages_admin_currencies_list_onleft", "Op de linkerzijde");
	define("lang_pages_admin_currencies_list_onrightwithspace", "Op de rechterzijde met spatie");
	define("lang_pages_admin_currencies_list_onright", "Op de rechterzijde");
	define("lang_pages_admin_currencies_list_decsepsym", "Decimaal afscheiden met");

	define("lang_pages_admin_manufacturers_add_addaman", "Fabrikant toevoegen");
	define("lang_pages_admin_manufacturers_add_name", "Naam");
	define("lang_pages_admin_manufacturers_add_website", "Website");
	define("lang_pages_admin_manufacturers_add_logofile", "Logo plaatje");

	define("lang_pages_admin_manufacturers_edit_editman", "Fabrikant bewerken");
	define("lang_pages_admin_manufacturers_edit_name", "Naam");
	define("lang_pages_admin_manufacturers_edit_website", "Website");
	define("lang_pages_admin_manufacturers_edit_actuallogo", "Aanwezigen logo");
	define("lang_pages_admin_manufacturers_edit_newlogofile", "Nieuw logo");
	define("lang_pages_admin_manufacturers_edit_gotomanlist", "Ga naar de Fabrikanten lijst");
	
	define("lang_pages_admin_manufacturers_list_name", "Naam");
	define("lang_pages_admin_manufacturers_list_website", "Website");
	define("lang_pages_admin_manufacturers_list_creationdate", "Datum");
	define("lang_pages_admin_manufacturers_list_logo", "Logo");
	define("lang_pages_admin_manufacturers_list_nopicture", "Geen plaatje");
	define("lang_pages_admin_manufacturers_list_createman", "Fabrikant toevoegen");
	define("lang_pages_admin_manufacturers_list_totalman", "fabrikant(en)");

	define("lang_pages_admin_payment_blockconfig_paybkconfig", "Configuratie, Betaling methodes");
	define("lang_pages_admin_payment_blockconfig_block", "Blok");
	
	define("lang_pages_admin_products_add_addnewproduct", "Artikel toevoegen");
	define("lang_pages_admin_products_add_productname", "Artikel naam");
	define("lang_pages_admin_products_add_model", "Model");
	define("lang_pages_admin_products_add_intref", "Intern ref. number");
	define("lang_pages_admin_products_add_category", "Categorie");
	define("lang_pages_admin_products_add_manufacturer", "Fabrikant");
	define("lang_pages_admin_products_add_provider", "Leverancier");
	define("lang_pages_admin_products_add_select", "-- Selecteer --");
	define("lang_pages_admin_products_add_sellprice", "Verkoop prijs");
	define("lang_pages_admin_products_add_specialsellprice", "Speciale verkoop prijs");
	define("lang_pages_admin_products_add_costprice", "Kost prijs");
	define("lang_pages_admin_products_add_qtyinstock", "Aantal op voorraad");
	define("lang_pages_admin_products_add_reorderqty", "Te bestellen.");
	define("lang_pages_admin_products_add_backorder", "Niet op voorraad");
	define("lang_pages_admin_products_add_available", "Op voorraad");
	define("lang_pages_admin_products_add_from", "Van");
	define("lang_pages_admin_products_add_to", "Tot");
	define("lang_pages_admin_products_add_weight", "Gewicht");
	define("lang_pages_admin_products_add_featured", "Weergeven als Best verkochte artikel");
	define("lang_pages_admin_products_add_visible", "Zichtbaar");
	define("lang_pages_admin_products_add_rating", "Waardering");
	define("lang_pages_admin_products_add_producturl", "Artikel URL");
	define("lang_pages_admin_products_add_productdescription", "Artikel omschrijving");

	define("lang_pages_admin_products_edit_product", "Artikel");
	define("lang_pages_admin_products_edit_productname", "Artikel naam");
	define("lang_pages_admin_products_edit_model", "Model");
	define("lang_pages_admin_products_edit_intrefnumber", "Intern ref. number");
	define("lang_pages_admin_products_edit_category", "Categorie");
	define("lang_pages_admin_products_edit_manufacturer", "Fabrikant");
	define("lang_pages_admin_products_edit_provider", "Leverancier");
	define("lang_pages_admin_products_edit_none", "geen");
	define("lang_pages_admin_products_edit_sellprice", "Verkoop prijs");
	define("lang_pages_admin_products_edit_specialsellprice", "Speciale verkoop prijs");
	define("lang_pages_admin_products_edit_costprice", "Kost prijs");
	define("lang_pages_admin_products_edit_qtyinstock", "Aantal op voorraad");
	define("lang_pages_admin_products_edit_reorderqty", "Te bestellen.");
	define("lang_pages_admin_products_edit_backorder", "Niet op voorraad");
	define("lang_pages_admin_products_edit_available", "Op voorraad");
	define("lang_pages_admin_products_edit_from", "Van");
	define("lang_pages_admin_products_edit_to", "Tot");
	define("lang_pages_admin_products_edit_weight", "Gewicht");
	define("lang_pages_admin_products_edit_featured", "Weergeven als Best verkochte artikel");
	define("lang_pages_admin_products_edit_visible", "Zichtbaar");
	define("lang_pages_admin_products_edit_rating", "Waardering");
	define("lang_pages_admin_products_edit_select", "Selecteer");
	define("lang_pages_admin_products_edit_producturl", "Artikel URL");
	define("lang_pages_admin_products_edit_description", "Omschrijving");
	define("lang_pages_admin_products_edit_productdescription", "Artikel omschrijving");
	define("lang_pages_admin_products_edit_gallery", "Galerij");
	define("lang_pages_admin_products_edit_file", "Bestand");
	define("lang_pages_admin_products_edit_view", "Bekijken");
	define("lang_pages_admin_products_edit_addpictureforthatproduct", "Plaatje toevoegen voor dit product toe");
	define("lang_pages_admin_products_edit_picture", "Plaatje");
	define("lang_pages_admin_products_edit_relations", "Relaties");
	define("lang_pages_admin_products_edit_relatedproducts", "Artikel Relaties");
	define("lang_pages_admin_products_edit_relproductname", "Artikel naam");
	define("lang_pages_admin_products_edit_breakrelationship", "Verbreek de Relatie");
	define("lang_pages_admin_products_edit_productsthatrelate", "Artikelen die betrekking hebben op deze relatie");
	define("lang_pages_admin_products_edit_bwproductname", "Artikel naam");
	define("lang_pages_admin_products_edit_createrelationship", "Cre�er een relatie op dit product");
	define("lang_pages_admin_products_edit_selectaproduct", "Selecteer een product");
	define("lang_pages_admin_products_edit_pleaseselect", "-- selecteer a.u.b. --");
	define("lang_pages_admin_products_edit_createreverserel", "Cre�er een soortgelijke relatie op dit product");
	define("lang_pages_admin_products_edit_reviews", "Overzichten");
	define("lang_pages_admin_products_edit_statistics", "Statistieken");
	define("lang_pages_admin_products_edit_gotoproductslist", "Ga naar artikelenlijst (admin zijde)");
	define("lang_pages_admin_products_edit_gotoproductdetails", "Ga naar product details (klant zijde)");
	
	define("lang_pages_admin_products_list_products", "Artikelen");
	define("lang_pages_admin_products_list_showproductsinthiscat", "Toon artikelen in deze categorie");
	define("lang_pages_admin_products_list_allcategories", "Alle categorie�n");
	define("lang_pages_admin_products_list_name", "Naam");
	define("lang_pages_admin_products_list_model", "Model");
	define("lang_pages_admin_products_list_manufacturer", "Merk");
	define("lang_pages_admin_products_list_price", "Prijs");
	define("lang_pages_admin_products_list_addnewproduct", "Artikel toevoegen");
	define("lang_pages_admin_products_list_productsindatabase", "Artikelen in gegevensbestand");

	define("lang_pages_admin_products_pictures_picturesforproduct", "Plaatje voor product");
	define("lang_pages_admin_products_pictures_picturefile", "Plaatje");
	define("lang_pages_admin_products_pictures_view", "Bekijken");
	define("lang_pages_admin_products_pictures_delete", "Verwijderen");
	define("lang_pages_admin_products_pictures_addapictureforthatproduct", "Plaatje toevoegen voor dit product");
	define("lang_pages_admin_products_pictures_picture", "Plaatje");
	define("lang_pages_admin_products_pictures_finished", "Gereed");

	define("lang_pages_admin_providers_list_providerslist", "Leveranciers lijst");
	define("lang_pages_admin_providers_list_name", "Naam");
	define("lang_pages_admin_providers_list_addaprovider", "Leverancier toevoegen");
	define("lang_pages_admin_providers_list_addname", "Naam");

	define("lang_pages_admin_shipping_config_shippingmethods", "Manier van verzending");
	define("lang_pages_admin_shipping_config_name", "Naam");
	define("lang_pages_admin_shipping_config_addnewshippingmethod", "Nieuwe betalings module toevoegen");
	define("lang_pages_admin_shipping_config_addname", "Naam");
	define("lang_pages_admin_shipping_config_description", "Omschrijvingen");
	define("lang_pages_admin_shipping_config_arithmeticoperation", "Rekenkundige uitwerking");

	define("lang_pages_admin_shipping_edit_editshippingmethod", "Bewerk levering methode");
	define("lang_pages_admin_shipping_edit_name", "Naam");
	define("lang_pages_admin_shipping_edit_description", "Omschrijving");
	define("lang_pages_admin_shipping_edit_arithmeticoperation", "Module naam (.php)");

	define("lang_pages_admin_shopping_details_invoicedetails", "Rekening details");
	define("lang_pages_admin_shopping_details_invoiceid", "Rekening ID");
	define("lang_pages_admin_shopping_details_shippingmethod", "Verzend methode");
	define("lang_pages_admin_shopping_details_shippingcost", "Verzend kosten");
	define("lang_pages_admin_shopping_details_paymentmethod", "Betalings methode");
	define("lang_pages_admin_shopping_details_orderdate", "Bestellings datum");
	define("lang_pages_admin_shopping_details_customer", "Klant");
	define("lang_pages_admin_shopping_details_total", "Totaal: (Plus BTW)");
	define("lang_pages_admin_shopping_details_grandtotal", "TOTAAL");
	define("lang_pages_admin_shopping_details_status", "Status");
	define("lang_pages_admin_shopping_details_stadminconf", "Wacht op bevestiging");
	define("lang_pages_admin_shopping_details_stpaymentconfirmed", "Betaling bevestigd");
	define("lang_pages_admin_shopping_details_stpackaginginprocess", "Bestelling in behandeling");
	define("lang_pages_admin_shopping_details_stshipped", "Verzonden");
	define("lang_pages_admin_shopping_details_stpaymentretracted", "Betaling ingetrokken");
	define("lang_pages_admin_shopping_details_stdeclaredasfraudulent", "Frauduleuze klant");
	define("lang_pages_admin_shopping_details_streceivedbycustomer", "Ontvangst bevestigd");
	define("lang_pages_admin_shopping_details_streturnedbycustomer", "Retour zending");
	define("lang_pages_admin_shopping_details_stother", "Anderen / miscs");
	define("lang_pages_admin_shopping_details_stcompleted", "Voltooid");
	define("lang_pages_admin_shopping_details_productsbought", "Gekochte artikelen");
	define("lang_pages_admin_shopping_details_backtoinvoiceslist", "Terug naar rekeningenlijst");
	
	define("lang_pages_admin_shopping_invoices_invoices", "Rekeningen");
	define("lang_pages_admin_shopping_invoices_invoicenumber", "Rekening number");
	define("lang_pages_admin_shopping_invoices_date", "Datum");
	define("lang_pages_admin_shopping_invoices_status", "Status");
	define("lang_pages_admin_shopping_invoices_stawaitingadminconfirmation", "Wacht op bevestiging");
	define("lang_pages_admin_shopping_invoices_stpaymentconfirmed", "Betaling bevestigd");
	define("lang_pages_admin_shopping_invoices_stpackaginginprocess", "Bestelling in behandeling");
	define("lang_pages_admin_shopping_invoices_stshipped", "Verzonden");
	define("lang_pages_admin_shopping_invoices_stpaymentretracted", "Ingetrokken betaling");
	define("lang_pages_admin_shopping_invoices_stdeclaredasfraudulent", "Verklaard als frauduleus");
	define("lang_pages_admin_shopping_invoices_streceivedbycustomer", "Ontvangen door klant");
	define("lang_pages_admin_shopping_invoices_streturnedbycustomer", "Teruggekeerd door klant");
	define("lang_pages_admin_shopping_invoices_stothers", "Anderen / miscs");
	define("lang_pages_admin_shopping_invoices_stcompleted", "Voltooid");
	define("lang_pages_admin_shopping_invoices_details", "Meer info");

	define("lang_pages_admin_system_languages_add_newlanguage", "Nieuwe taal");
	define("lang_pages_admin_system_languages_add_languagename", "Taal naam");
	define("lang_pages_admin_system_languages_add_dictionaryfile", "Taal code");
	define("lang_pages_admin_system_languages_add_defaultlanguage", "Standaard taal");

	define("lang_pages_admin_system_languages_edit_editlanguage", "Taal bewerken");
	define("lang_pages_admin_system_languages_edit_languagename", "Taal naam");
	define("lang_pages_admin_system_languages_edit_dictionaryfile", "Taal code");
	define("lang_pages_admin_system_languages_edit_defaultlanguage", "Standaard taal");

	define("lang_pages_admin_system_languages_list_systemlanguages", "Systeem talen");
	define("lang_pages_admin_system_languages_list_languagename", "Taal naam");
	define("lang_pages_admin_system_languages_list_addsystemlanguage", "Systeem taal toevoegen");

	define("lang_pages_admin_system_texts_editor_homepagewelcometext", "Welkome tekst hoofd pagina");
	define("lang_pages_admin_system_texts_editor_contactusintrotext", "Contactinformatie text");
	define("lang_pages_admin_system_texts_editor_orderconfirmationemail", "Bestelling bevestigings email text");
	define("lang_pages_admin_system_texts_editor_privacynoticepage", "Privacyverklaring text");
	define("lang_pages_admin_system_texts_editor_conditionofusepage", "Algemene Voorwaarden text");
	define("lang_pages_admin_system_texts_editor_shippingandreturnpage", "Verzendinformatie text");
	define("lang_pages_admin_system_texts_editor_text", "Text");

	define("lang_pages_admin_system_texts_selang_youareabout", "U staat nu op het punt de text van het systeem te bewerken");
	define("lang_pages_admin_system_texts_selang_pleaseselect", "Selecteer de taal module die u wilt veranderen");

	define("lang_pages_admin_system_general_generalsystemsettings", "Algemene systeem instellingen");
	define("lang_pages_admin_system_general_companyname", "Bedrijfs naam");
	define("lang_pages_admin_system_general_adminname", "Beheerder naam");
	define("lang_pages_admin_system_general_adminemail", "Beheerder email adres");
	define("lang_pages_admin_system_general_systememail", "Systeem email adres");
	define("lang_pages_admin_system_general_rooturl", "Root URL van deze site");
	define("lang_pages_admin_system_general_departurezip", "Uw bedrijfs postcode");
	define("lang_pages_admin_system_general_taxarithmeticoper", "BTW berekening");
	define("lang_pages_admin_system_general_catlistorder", "Volgorde van de categorie�n lijst");
	define("lang_pages_admin_system_general_insertorderasc", "Orde van de toevoeging, Stijgen");
	define("lang_pages_admin_system_general_insertorderdesc", "Orde van de toevoeging, Dalen");
	define("lang_pages_admin_system_general_catnameasc", "Categorie naam, Stijgen");
	define("lang_pages_admin_system_general_catnamedesc", "Categorie naam, Dalen");
	define("lang_pages_admin_system_general_weightunit", "Eenheid v/h gewicht");
	define("lang_pages_admin_system_general_kilograms", "Kilogram");
	define("lang_pages_admin_system_general_pounds", "Ponden");
	define("lang_pages_admin_system_general_metrictons", "Metrische ton");
	define("lang_pages_admin_system_general_grams", "Gram");
	define("lang_pages_admin_system_general_miligrams", "Miligram");
	define("lang_pages_admin_system_general_tons", "Ton");
	define("lang_pages_admin_system_general_ounces", "Ons");
	define("lang_pages_admin_system_general_showprodbo", "Toon alle artikelen die als nabestelling staan");
	define("lang_pages_admin_system_general_buybo", "De klanten kunnen de artikelen die niet op voorraad zijn kopen");
	define("lang_pages_admin_system_general_showbo", "Toon de status van de Nabestelling");
	define("lang_pages_admin_system_general_showoutofdate", "Toon de artikelen die buiten datum zijn");
	define("lang_pages_admin_system_general_orderoutofrange", "Klant. kan de artikelen aankopen die buiten de datum zijn");
	define("lang_pages_admin_system_general_defaultthemetouse", "Standaard thema keuze");

	define("lang_pages_admin_users_details_customersdetails", "Klant gegevens");
	define("lang_pages_admin_users_details_firstname", "Naam");
	define("lang_pages_admin_users_details_lastname", "Achternaam");
	define("lang_pages_admin_users_details_emailaddress", "Email adres");
	define("lang_pages_admin_users_details_password", "Password");
	define("lang_pages_admin_users_details_companyname", "Bedrijfs naam");
	define("lang_pages_admin_users_details_address", "Adres");
	define("lang_pages_admin_users_details_city", "Stad");
	define("lang_pages_admin_users_details_state", "Provincie");
	define("lang_pages_admin_users_details_zipcode", "Postcode");
	define("lang_pages_admin_users_details_country", "Land");
	define("lang_pages_admin_users_details_phonenumber", "Telefoon nummer");
	define("lang_pages_admin_users_details_faxnumber", "Fax nummer");
	define("lang_pages_admin_users_details_isadmin", "Is Beheerder");
	define("lang_pages_admin_users_details_backtocustomerslist", "Terug naar de klanten lijst");
	define("lang_pages_admin_users_details_sendemail", "Verzend email");

	define("lang_pages_admin_users_list_customersanduserslist", "Klanten & Beheerders lijst");
	define("lang_pages_admin_users_list_name", "Naam");
	define("lang_pages_admin_users_list_details", "Meer info");
	
	define("lang_pages_admin_system_updates_systemupdate", "System update");
	define("lang_pages_admin_system_updates_insertcode", "Plaats uw (verkregen) update code hieronder in");

	define("lang_pages_admin_menu_adminmenu", "Beheerder menu");
	define("lang_pages_admin_menu_manufacturerprovider", "Fabrikanten & Leveranciers");
	define("lang_pages_admin_menu_manufacturerslist", "Fabrikanten lijst");
	define("lang_pages_admin_menu_addmanufacturer", "Fabrikant toevoegen");
	define("lang_pages_admin_menu_providerslist", "Leveranciers lijst");
	define("lang_pages_admin_menu_categoriesandproducts", "Categories & artikelen");
	define("lang_pages_admin_menu_categorieslist", "Categorie�n lijst");
	define("lang_pages_admin_menu_addacategory", "Categorie�n toevoegen");
	define("lang_pages_admin_menu_productslist", "Artikelen lijst");
	define("lang_pages_admin_menu_addaproduct", "Artikelen toevoegen");
	define("lang_pages_admin_menu_systemsettings", "Systeem instellingen");
	define("lang_pages_admin_menu_generalsystemsettings", "Algemene systeem instellingen");
	define("lang_pages_admin_menu_advertisementsmanagement", "Reclame beheer");
	define("lang_pages_admin_menu_languagesmanagement", "Talen beheer");
	define("lang_pages_admin_menu_currenciesmanagement", "Valuta�s beheer");
	define("lang_pages_admin_menu_systemtextseditor", "Systeem texts bewerken");
	define("lang_pages_admin_menu_paymentblocksconfiguration", "Betaling configuratie");
	define("lang_pages_admin_menu_shippingconfigurations", "Betaling modules");
	define("lang_pages_admin_menu_shopping", "Winkel beheer");
	define("lang_pages_admin_menu_invoicesandorders", "Rekeningen & Bestellingen");
	define("lang_pages_admin_menu_customersandusers", "Klanten & Beheerders");
	define("lang_pages_admin_menu_stockmanagement", "Voorraad beheer");
	define("lang_pages_admin_menu_updates", "Systeem update");

	define("lang_pages_cart_checkout_youarenowregistered", "U wordt nu geregistreerd. Gelieve deze vorm in te vullen");
	define("lang_pages_cart_checkout_emailaddress", "Email adres");
	define("lang_pages_cart_checkout_password", "Password");
	define("lang_pages_cart_checkout_login", "Login");
	define("lang_pages_cart_checkout_ifyouprev", "Als u eerder al is een bestelling heeft geplaatst, Gelieve eerst in te loggen");
	define("lang_pages_cart_checkout_ifthisisyourfirstorder", "Is dit uw eerste bestelling, vul dan eerst uw gegevens in in deze form");
	define("lang_pages_cart_checkout_firstname", "Naam");
	define("lang_pages_cart_checkout_lastname", "Achternaam");
	define("lang_pages_cart_checkout_email", "Email adres");
	define("lang_pages_cart_checkout_desiredpassword", "Gewenste password");
	define("lang_pages_cart_checkout_companyname", "Bedrijfs naam");
	define("lang_pages_cart_checkout_address", "Adres");
	define("lang_pages_cart_checkout_city", "Stad");
	define("lang_pages_cart_checkout_stateprovince", "Provincie");
	define("lang_pages_cart_checkout_zip", "Postcode");
	define("lang_pages_cart_checkout_country", "Land");
	define("lang_pages_cart_checkout_phonenumber", "Telefoon nummer");
	define("lang_pages_cart_checkout_faxnumber", "Fax nummer");
	define("lang_pages_cart_checkout_shippingaddress", "Adres van ontvangst");
	define("lang_pages_cart_checkout_name", "Naam");
	define("lang_pages_cart_checkout_order", "Bestelling");
	define("lang_pages_cart_checkout_item", "Artikel");
	define("lang_pages_cart_checkout_qty", "Aantal");
	define("lang_pages_cart_checkout_unitprice", "Prijs");
	define("lang_pages_cart_checkout_total", "Totaal");
	define("lang_pages_cart_checkout_subtotal", "Sub-Totaal");
	define("lang_pages_cart_checkout_taxes", "BTW");
	define("lang_pages_cart_checkout_shipping", "Verzending");
	define("lang_pages_cart_checkout_paymentmethod", "Betaal methode");

	define("lang_pages_cart_confirmorder_orderconfirmation", "Bevestiging van uw bestelling");
	
	define("lang_pages_cart_show_product", "Artikel");
	define("lang_pages_cart_show_qty", "Aantal");
	define("lang_pages_cart_show_unitprice", "Prijs");
	define("lang_pages_cart_show_subtotal", "Sub-Totaal");
	define("lang_pages_cart_show_checkout", "Uw bestelling(en) doorgeven");
	define("lang_pages_cart_show_cartempty", "Uw winkelwagen is leeg");
	
	define("lang_pages_information_contact_thankyou", "Dank u, wij zullen uw bericht zo spoedig mogelijk in behandeling nemen");
	define("lang_pages_information_contact_name", "Naam / Achternaam");
	define("lang_pages_information_contact_email", "Email adres");
	define("lang_pages_information_contact_service", "Service");
	define("lang_pages_information_contact_subject", "Onderwerp");
	define("lang_pages_information_contact_message", "Bericht");

	define("lang_pages_products_details_addedtoshoppingcart", "Artikel toegevoegd in de winkelwagen");
	define("lang_pages_products_details_edit", "Bewerken");
	define("lang_pages_products_details_morepictures", "Meer beelden");
	define("lang_pages_products_details_relatedproducts", "Verwante artikelen");
	define("lang_pages_products_details_ourrating", "Onze waardering");
	define("lang_pages_products_details_customersrating", "Waardering van klanten");
	define("lang_pages_products_details_rateit", "Waardering");
	define("lang_pages_products_details_tellafriend", "Vertel een vriend");
	define("lang_pages_products_details_special", "Actie prijs");
	define("lang_pages_products_details_addtocart", "Voeg toe in winkelwagen");
	define("lang_pages_products_details_backorder", "Dit artikel is tot onze spijt nu niet leverbaar");
	define("lang_pages_products_details_availablefrom", "Leverbaar vanaf");
	define("lang_pages_products_details_to", "tot en met");
	define("lang_pages_products_details_availableuntil", "Dit artikel zal leverbaar zijn op");
	define("lang_pages_products_details_backtolist", "Terug");

	define("lang_pages_products_list_addedtoshoppingcart", "Artikel is toegevoegd in uw winkelwagen");
	define("lang_pages_products_list_productsin", "Artikelen in");
	define("lang_pages_products_list_home", "Hoofdpagina");
	define("lang_pages_products_list_buy", "Toevoegen in uw winkelwagen");
	define("lang_pages_products_list_details", "Meer info");
	define("lang_pages_products_list_backorder", "Niet op voorraad");
	define("lang_pages_products_list_edit", "Bewerken");
	define("lang_pages_products_list_youmaywanttolook", "U heeft de keuze uit de volgende subcategorie�n");
	
	define("lang_pages_products_listmanuf_addedtoshoppingcart", "Artikelen die toegevoegd zijn in uw winkelwagen");
	define("lang_pages_products_listmanuf_productsby", "Artikelen van");
	define("lang_pages_products_listmanuf_buy", "Kopen");
	define("lang_pages_products_listmanuf_details", "Meer info");
	
	define("lang_pages_products_tellafriend_checkthisurl", "Hey! kijk is op deze URL");
	define("lang_pages_products_tellafriend_tellafriend", "Vertel een vriend");
	define("lang_pages_products_tellafriend_friendsemail", "Vriend's email adres");
	define("lang_pages_products_tellafriend_emailsubject", "Email onderwerp");
	define("lang_pages_products_tellafriend_hey", "Hey! Controleer dit!");

	define("lang_pages_products_search_searchresults", "Zoek resultaten van");
	define("lang_pages_products_search_matches", "Gevonden artikelen die uw zoek opdracht benaderen");

	define("lang_themes_bykeywords", "Zoek Opdracht");
	define("lang_pages_themes_home", "Hoofdpagina");
	define("lang_pages_themes_shoppingcart", "Winkelwagen");
	define("lang_pages_themes_contactus", "Contact");
	define("lang_pages_themes_admin", "Beheerder");
	define("lang_pages_themes_yourcart", "Uw winkelwagen");
	define("lang_pages_themes_details", "Meer info");
	define("lang_pages_themes_items", "Artikelen");
	define("lang_pages_themes_total", "totaal");
	define("lang_pages_themes_language", "Taal");
	define("lang_pages_themes_currency", "Valuta");
	define("lang_pages_themes_usersonline", "Klanten aanwezig");
	define("lang_pages_themes_products", "Artikelen");
	define("lang_pages_themes_uptime", "Uptime");
	define("lang_pages_themes_days", "dagen");

	define("lang_pages_themes_home_welcome", "WELKOM");
	define("lang_pages_themes_home_featured", "BEST VERKOCHTE ARTIKEL!!");
	define("lang_pages_themes_home_details", "<b>Meer info</b>");
	define("lang_pages_themes_home_newproducts", "NIEUWE ARTIKELEN");
	define("lang_pages_themes_home_email", "E-Mail");
	define("lang_pages_themes_home_password", "Passwoord");
	define("lang_pages_themes_home_loggedin", "U bent ingelogd");

	define("lang_pages_themes_blocks_browsemanufacturers_browsebyman", "Snelkeuze menu");
	define("lang_pages_themes_blocks_browsemanufacturers_select", "-- Fabrikanten --");

	define("lang_pages_themes_blocks_cataloguecats_cataloguecategories", "Categorie�n");

	define("lang_pages_themes_blocks_categoriesdrop_bycategory", "Zoeken in:");
	define("lang_pages_themes_blocks_categoriesdrop_select", "-- Categorie�n --");

	define("lang_pages_themes_blocks_informations_informations", "Informatie");
	define("lang_pages_themes_blocks_informations_contactus", "Contactinformatie");
	define("lang_pages_themes_blocks_informations_privacynotice", "Privacyverklaring");
	define("lang_pages_themes_blocks_informations_conditionsofuse", "Algemene voorwaarden");
	define("lang_pages_themes_blocks_informations_shippingandreturns", "Verzendinformatie");
	

	//////////////////////////////////////////////////////////////////////////////////////////
	// NEW LANGUAGES FIELDS ADDED AFTER V.905B
	//////////////////////////////////////////////////////////////////////////////////////////
	
	define("lang_pages_admin_products_pictures_whattodo", "Wat wilt u nu doen");
	define("lang_pages_admin_products_pictures_backtoproductslist", "Ga terug naar de artikeleb lijst");
	define("lang_pages_admin_products_pictures_redirection", "redirection in 5 seconden");
	define("lang_pages_admin_products_pictures_setmore", "Plaats meer opties voor dat artikel");
	define("lang_pages_admin_products_pictures_addanother", "Voeg een ander product toe");


	define("lang_pages_admin_system_general_companylogo", "Bedrijfs logo");
	
	define("lang_pages_cart_show_total", "Totaal");
	define("lang_pages_cart_show_addone", "Aantal verhogen");
	define("lang_pages_cart_show_remone", "Aantal verlagen en of artikel verwijderen");
	define("lang_pages_cart_show_donerem", "Aantal verlaagd en of artikel verwijderd");
	define("lang_pages_cart_show_doneadd", "Aantal verhoogd");
	define("lang_pages_cart_show_details", "Details");
	
	define("lang_pages_products_search_addedtoshoppingcart", "Artikel is toegevoegd in de winkelwagen");
	
	define("lang_pages_themes_home_logout", "Uitloggen");
	
	define("lang_pages_admin_system_general_tabsystem", "Systeem");
	define("lang_pages_admin_system_general_tabcompany", "Bedrijf");
	define("lang_pages_admin_system_general_tabstyle", "Stijl");
	define("lang_pages_admin_system_general_tabproducts", "Artikelen");
	
	define("lang_pages_admin_advertisements_list_list", "Lijst");
	define("lang_pages_admin_advertisements_list_add", "Toevoegen");
	
	define("lang_pages_admin_manufacturers_list_manufacturers", "Fabrikanten");
	define("lang_pages_admin_manufacturers_list_list", "Lijst");
	define("lang_pages_admin_manufacturers_list_create", "Cre�er");
	
	define("lang_pages_admin_providers_list_list", "Lijst");
	define("lang_pages_admin_providers_list_create", "Cre�er");
	
	define("lang_pages_admin_categories_list_head", "Categorie�ns");
	define("lang_pages_admin_categories_list_list", "Lijst");
	define("lang_pages_admin_categories_list_create", "Cre�er");
	
	define("lang_pages_admin_system_languages_list_list", "Lijst");
	define("lang_pages_admin_system_languages_list_create", "Cre�er");
	
	define("lang_pages_admin_currencies_list_list", "Lijst");
	define("lang_pages_admin_currencies_list_create", "Cre�er");
	
	define("lang_pages_admin_shipping_config_shipping", "Verzending");
	define("lang_pages_admin_shipping_config_list", "Lijst");
	define("lang_pages_admin_shipping_config_create", "Cre�er");
	
	define("lang_pages_admin_system_languages_list_list", "Lijst");
	define("lang_pages_admin_system_languages_list_create", "Cre�er");
	
	define("lang_pages_admin_products_edit_editproduct", "Artikel bewerken");
	
	define("lang_pages_admin_providers_list_providers", "Leveranciers");
	
	define("lang_pages_admin_system_general_ratingstyleimage", "Plaatje gebruiken");
	define("lang_pages_admin_system_general_ratingstyletext", "Text gebruiken");
	define("lang_pages_admin_system_general_ratingstyle", "Waardering weergave");
	
	//////////////////////////////// NEW FIELDS ADDED AFTER V0921B /////////////////////////////////////
	define("lang_pages_admin_shopping_details_notesforthisinvoice", "Nota's voor deze rekening");

	define("lang_pages_admin_products_edit_noreviews", "Er zijn nog geen recensies over dit artikel");
	define("lang_pages_admin_products_edit_productsreviews", "Recensies over dit artikel");
	
	define("lang_pages_admin_system_general_enablereviews", "Recensies op artikelen toelaten");
	
	define("lang_pages_products_details_reviews", "Recensies");
	define("lang_pages_products_details_readreviews", "Lees de recensies");
	define("lang_pages_products_details_writereview", "Plaats een recensie voor dit artikel");
	
	define("lang_pages_reviews_read_reviewsfor", "Recensies voor");
	define("lang_pages_reviews_read_user", "Klant");
	define("lang_pages_reviews_read_reviewproduct", "Plaats een recensie voor dit artikel");
	
	define("lang_pages_reviews_write_thankyou", "Dank U");
	define("lang_pages_reviews_write_writefor", "Plaats een recensie voor");
	define("lang_pages_reviews_write_nickname", "Uw naam");
	define("lang_pages_reviews_write_yourreview", "Uw recensie");

	define("lang_pages_admin_mailing_mailing_sending", "Bezig met verzenden... Even geduld alstublieft");
	define("lang_pages_admin_mailing_mailing_errorsendingto", "Er is een fout opgetreden met de verzending naar");
	define("lang_pages_admin_mailing_mailing_skipping", "Overslaan");
	define("lang_pages_admin_mailing_mailing_mailsentto", "Mail verzonden naar");
	define("lang_pages_admin_mailing_mailing_finished", "Gereed");
	define("lang_pages_admin_mailing_mailing_sent", "Verzonden");
	define("lang_pages_admin_mailing_mailing_skip", "Overgeslagen");
	define("lang_pages_admin_mailing_mailing_mailinglist", "Adressenlijstbeheer");
	define("lang_pages_admin_mailing_mailing_from", "Van");
	define("lang_pages_admin_mailing_mailing_to", "Naar");
	define("lang_pages_admin_mailing_mailing_subject", "Onderwerp");
	define("lang_pages_admin_mailing_mailing_message", "Bericht");
	define("lang_pages_admin_mailing_mailing_everymember", "Alle geregistreerde leden");
	
	define("lang_pages_admin_stats_access_accessstatsfor", "Bezoekers statistieken");
	
	define("lang_pages_admin_stats_sales_soldunitsfor", "Verkochte artikelen (totaal) van");
	define("lang_pages_admin_stats_sales_soldunits", "Verkochte artikelen");
	define("lang_pages_admin_stats_sales_salesstatsfor", "Verkoop statistieken (totaal) van");
	define("lang_pages_admin_stats_sales_salesstats", "Verkoop statistieken");

	define("lang_pages_admin_system_general_usesmiles", "Smileys in recensies toelaten");
	define("lang_pages_admin_system_general_cookieprefix", "Koekje (Cookie) naam prefix");
	
	define("lang_theme_lostpass", "Wachtwoord vergeten");
	define("lang_theme_register", "Registreren");
		
	define("lang_pages_lostpass_error", "Fout: Uw E-mail adres die u invoerde is bij ons niet bekend");
	define("lang_pages_lostpass_yourpassword", "uw wachtwoord");
	define("lang_pages_lostpass_yourpasson", "Uw wachtwoord op");
	define("lang_pages_lostpass_is", "is");
	define("lang_pages_lostpass_passsent", "Uw wachtwoord is verzonden naar het volgende e-mailadres");
	define("lang_pages_lostpass_lostpass", "Verloren wachtwoord");
	define("lang_pages_lostpass_toptext", "Voer hier uw gegevens in die bij ons bekend zijn. Mits de gegevens bij ons bekend zijn zal uw wachtwoord naar u verzonden worden.");
	define("lang_pages_lostpass_email", "E-mail adres");

	define("lang_pages_admin_system_texts_editor_registrationtext", "Tekst van de registratie pagina"); 
	
	define("lang_pages_register_register_registration", "Klant registratie");
	
	define("lang_pages_register_register_firstname", "Naam");
	define("lang_pages_register_register_lastname", "Achternaam");
	define("lang_pages_register_register_email", "Email adres");
	define("lang_pages_register_register_desiredpassword", "Gewenste password");
	define("lang_pages_register_register_companyname", "Bedrijfs naam");
	define("lang_pages_register_register_address", "Adres");
	define("lang_pages_register_register_city", "Stad");
	define("lang_pages_register_register_stateprovince", "Provincie");
	define("lang_pages_register_register_zip", "Postcode");
	define("lang_pages_register_register_country", "Land");
	define("lang_pages_register_register_phonenumber", "Telefoon nummer");
	define("lang_pages_register_register_faxnumber", "Fax nummer");
	define("lang_pages_register_register_registered", "Dank u. U bent nu bij ons geregistreerd.");
	
	define("lang_pages_admin_system_general_showcount", "Aantal weergeven naast de categorie");
	define("lang_pages_admin_system_general_linktofolder", "Link weergeven in de categorie lijst");
	define("lang_pages_admin_system_general_highlightselected", "Bezochte links weergeven");
	define("lang_pages_admin_system_general_showlines", "Toon verbindingslijnen");
	define("lang_pages_admin_system_general_useicons", "Toon pictogrammen");
	define("lang_pages_admin_system_general_displaydesc", "Toon het artikel omschrijving in de status balk");
	define("lang_pages_admin_system_general_closesame", "Zelfde niveau afsluiten");
	define("lang_pages_admin_system_general_expandall", "Alles weergeven");
	
	define("lang_pages_admin_categories_list_sortorder", "Volgorde categorie�nlijst");
	
	define("lang_pages_admin_system_general_sortorder", "Algemene volgorde");		