<?
//////////////////////////////////////////////////////////////
//           DEFINE THE LANGUAGE CHARSET TO USE             //
//                                                          //
// Possible values are;                                     //
// -------------------------------------------------------- //
// CHARSETNAME (use this)             VALUE                 //
// -------------------------------------------------------- //
// arabic                             iso-8859-6            //
// baltic                             iso-8859-4            //
// central european                   iso-8859-2            //
// chinese simplified                 euc-cn                //
// chinese traditional                big5                  //
// cyrillic                           koi8-r                //
// greek                              iso-8859-7            //
// hebrew                             iso-8859-8-i          //
// icelandic                          x-mac-icelandic       //
// japanese                           euc-jp                //
// korean                             euc-kr                //
// maltese                            iso-8859-3            //
// thai                               windows-874           //
// turkish                            iso-8859-9            //
// unicode                            utf-8                 //
// vietnamese                         windows-1258          //
// western                            iso-8859-1            //
//                                                          //
//////////////////////////////////////////////////////////////
define("language_charset", "Western");

//////////////////////////////////////////////////////////////
// When translating, beware to NOT use quotes (") within    //
// your texts. If you absolutely need to use quotes, prefix //
// them with a backslach (\")                               //
//////////////////////////////////////////////////////////////

	define("lang_general_yes", "Yes");
	define("lang_general_no", "No");
	define("lang_general_submit", "Submit");
	define("lang_general_edit", "Edit");
	define("lang_general_delete", "Delete");
	define("lang_general_action", "Action");
	define("lang_general_id", "ID");
	define("lang_general_select", "-- Select --");
	define("lang_general_deleteconfirm", "Do you really want to delete the selected item?");

	define("lang_pages_admin_advertisements_list_advertisements", "Advertisements");
	define("lang_pages_admin_advertisements_list_name", "Name");
	define("lang_pages_admin_advertisements_list_addadvertisement", "Add an advertisement");
	define("lang_pages_admin_advertisements_list_friendlyname", "Friendly name");
	define("lang_pages_admin_advertisements_list_imagefile", "Image file");
	define("lang_pages_admin_advertisements_list_url", "URL");
	define("lang_pages_admin_advertisements_list_list", "List");
	define("lang_pages_admin_advertisements_list_add", "Add");

	define("lang_pages_admin_categories_add_addnew", "Add a new category");
	define("lang_pages_admin_categories_add_categoryname", "Category name");
	define("lang_pages_admin_categories_add_parentcategory", "Parent category");
	define("lang_pages_admin_categories_add_nonemastercat", "None (Master category)");
	define("lang_pages_admin_categories_add_description", "Description");

	define("lang_pages_admin_categories_edit_editacategory", "Edit a category");
	define("lang_pages_admin_categories_edit_categoryname", "Category name");
	define("lang_pages_admin_categories_edit_parentcategory", "Parent category");
	define("lang_pages_admin_categories_edit_nonemastercat", "None (Master category)");
	define("lang_pages_admin_categories_edit_description", "Descriptions");

	define("lang_pages_admin_categories_list_categories", "Categories");
	define("lang_pages_admin_categories_list_name", "Name");
	define("lang_pages_admin_categories_list_parent", "Parent");
	define("lang_pages_admin_categories_list_description", "Description");
	define("lang_pages_admin_categories_list_addacategory", "Add a new category");
	define("lang_pages_admin_categories_list_head", "Categories");
	define("lang_pages_admin_categories_list_list", "List");
	define("lang_pages_admin_categories_list_create", "Create");
	
	define("lang_pages_admin_currencies_edit_editcurrency", "Edit currency");
	define("lang_pages_admin_currencies_edit_name", "Name");
	define("lang_pages_admin_currencies_edit_itlcc", "International currency code");
	define("lang_pages_admin_currencies_edit_default", "Default");
	define("lang_pages_admin_currencies_edit_moneysymbol", "Money symbol");
	define("lang_pages_admin_currencies_edit_moneysymbollocation", "Money symbol location");
	define("lang_pages_admin_currencies_edit_onleftwithspace", "On the left with space");
	define("lang_pages_admin_currencies_edit_onleft", "On the left");
	define("lang_pages_admin_currencies_edit_onrightwithspace", "On the right with space");
	define("lang_pages_admin_currencies_edit_onright", "On the right");
	define("lang_pages_admin_currencies_edit_decsepsym", "Decimal separator symbol");

	define("lang_pages_admin_currencies_list_currencies", "Currencies");
	define("lang_pages_admin_currencies_list_name", "Name");
	define("lang_pages_admin_currencies_list_code", "Code");
	define("lang_pages_admin_currencies_list_default", "Default");
	define("lang_pages_admin_currencies_list_addcurrency", "Add currency");
	define("lang_pages_admin_currencies_list_intlcc", "International currency code");
	define("lang_pages_admin_currencies_list_moneysymbol", "Money symbol");
	define("lang_pages_admin_currencies_list_moneysymbollocation", "Money symbol location");
	define("lang_pages_admin_currencies_list_onleftwithspace", "On the left with space");
	define("lang_pages_admin_currencies_list_onleft", "On the left");
	define("lang_pages_admin_currencies_list_onrightwithspace", "On the right with space");
	define("lang_pages_admin_currencies_list_onright", "On the right");
	define("lang_pages_admin_currencies_list_decsepsym", "Decimal separator symbol");
	define("lang_pages_admin_currencies_list_list", "List");
	define("lang_pages_admin_currencies_list_create", "Create");

	define("lang_pages_admin_manufacturers_add_addaman", "Add a manufacturer");
	define("lang_pages_admin_manufacturers_add_name", "Name");
	define("lang_pages_admin_manufacturers_add_website", "Web site");
	define("lang_pages_admin_manufacturers_add_logofile", "Logo file");

	define("lang_pages_admin_manufacturers_edit_editman", "Edit a manufacturer");
	define("lang_pages_admin_manufacturers_edit_name", "Name");
	define("lang_pages_admin_manufacturers_edit_website", "Web site");
	define("lang_pages_admin_manufacturers_edit_actuallogo", "Actual logo");
	define("lang_pages_admin_manufacturers_edit_newlogofile", "New logo file");
	define("lang_pages_admin_manufacturers_edit_gotomanlist", "Go to manufacturers list");
	
	define("lang_pages_admin_manufacturers_list_name", "Name");
	define("lang_pages_admin_manufacturers_list_website", "Web site");
	define("lang_pages_admin_manufacturers_list_creationdate", "Creation date");
	define("lang_pages_admin_manufacturers_list_logo", "Logo");
	define("lang_pages_admin_manufacturers_list_nopicture", "No picture");
	define("lang_pages_admin_manufacturers_list_createman", "Create a new manufacturer");
	define("lang_pages_admin_manufacturers_list_totalman", "total manufacturers");
	define("lang_pages_admin_manufacturers_list_manufacturers", "Manufacturers");
	define("lang_pages_admin_manufacturers_list_list", "List");
	define("lang_pages_admin_manufacturers_list_create", "Create");

	define("lang_pages_admin_payment_blockconfig_paybkconfig", "Payment blocks configurations");
	define("lang_pages_admin_payment_blockconfig_block", "Block");
	
	define("lang_pages_admin_products_add_addnewproduct", "Add new product");
	define("lang_pages_admin_products_add_productname", "Product name");
	define("lang_pages_admin_products_add_model", "Model");
	define("lang_pages_admin_products_add_intref", "Internal ref. number");
	define("lang_pages_admin_products_add_category", "Category");
	define("lang_pages_admin_products_add_manufacturer", "Manufacturer");
	define("lang_pages_admin_products_add_provider", "Provider");
	define("lang_pages_admin_products_add_select", "-- Select --");
	define("lang_pages_admin_products_add_sellprice", "Sell price");
	define("lang_pages_admin_products_add_specialsellprice", "Special sell price");
	define("lang_pages_admin_products_add_costprice", "Cost price");
	define("lang_pages_admin_products_add_qtyinstock", "Qty. in stock");
	define("lang_pages_admin_products_add_reorderqty", "Reorder qty.");
	define("lang_pages_admin_products_add_backorder", "Back order");
	define("lang_pages_admin_products_add_available", "Available");
	define("lang_pages_admin_products_add_from", "From");
	define("lang_pages_admin_products_add_to", "To");
	define("lang_pages_admin_products_add_weight", "Weight");
	define("lang_pages_admin_products_add_featured", "Featured");
	define("lang_pages_admin_products_add_visible", "Visible");
	define("lang_pages_admin_products_add_rating", "Rating");
	define("lang_pages_admin_products_add_producturl", "Product URL");
	define("lang_pages_admin_products_add_productdescription", "Product description");

	define("lang_pages_admin_products_edit_product", "Product");
	define("lang_pages_admin_products_edit_productname", "Product name");
	define("lang_pages_admin_products_edit_model", "Model");
	define("lang_pages_admin_products_edit_intrefnumber", "Internal ref. number");
	define("lang_pages_admin_products_edit_category", "Category");
	define("lang_pages_admin_products_edit_manufacturer", "Manufacturer");
	define("lang_pages_admin_products_edit_provider", "Provider");
	define("lang_pages_admin_products_edit_none", "none");
	define("lang_pages_admin_products_edit_sellprice", "Sell price");
	define("lang_pages_admin_products_edit_specialsellprice", "Special sell price");
	define("lang_pages_admin_products_edit_costprice", "Cost price");
	define("lang_pages_admin_products_edit_qtyinstock", "Qty. in stock");
	define("lang_pages_admin_products_edit_reorderqty", "Reorder qty.");
	define("lang_pages_admin_products_edit_backorder", "Back order");
	define("lang_pages_admin_products_edit_available", "Available");
	define("lang_pages_admin_products_edit_from", "From");
	define("lang_pages_admin_products_edit_to", "To");
	define("lang_pages_admin_products_edit_weight", "Weight");
	define("lang_pages_admin_products_edit_featured", "Featured");
	define("lang_pages_admin_products_edit_visible", "Visible");
	define("lang_pages_admin_products_edit_rating", "Rating");
	define("lang_pages_admin_products_edit_select", "Select");
	define("lang_pages_admin_products_edit_producturl", "Product URL");
	define("lang_pages_admin_products_edit_description", "Description");
	define("lang_pages_admin_products_edit_productdescription", "Product description");
	define("lang_pages_admin_products_edit_gallery", "Gallery");
	define("lang_pages_admin_products_edit_file", "File");
	define("lang_pages_admin_products_edit_view", "View");
	define("lang_pages_admin_products_edit_addpictureforthatproduct", "Add a picture for that product");
	define("lang_pages_admin_products_edit_picture", "Picture");
	define("lang_pages_admin_products_edit_relations", "Relations");
	define("lang_pages_admin_products_edit_relatedproducts", "Related products");
	define("lang_pages_admin_products_edit_relproductname", "Product name");
	define("lang_pages_admin_products_edit_breakrelationship", "Break relationship");
	define("lang_pages_admin_products_edit_productsthatrelate", "Products that relate to this item");
	define("lang_pages_admin_products_edit_bwproductname", "Product name");
	define("lang_pages_admin_products_edit_createrelationship", "Create relationship");
	define("lang_pages_admin_products_edit_selectaproduct", "Select a product");
	define("lang_pages_admin_products_edit_pleaseselect", "-- Please select --");
	define("lang_pages_admin_products_edit_createreverserel", "Create reverse relationship");
	define("lang_pages_admin_products_edit_reviews", "Reviews");
	define("lang_pages_admin_products_edit_statistics", "Statistics");
	define("lang_pages_admin_products_edit_gotoproductslist", "Go to products list (admin side)");
	define("lang_pages_admin_products_edit_gotoproductdetails", "Go to product details (user side)");
	define("lang_pages_admin_products_edit_editproduct", "Edit product");
	
	define("lang_pages_admin_products_list_products", "Products");
	define("lang_pages_admin_products_list_showproductsinthiscat", "Show products in this category");
	define("lang_pages_admin_products_list_allcategories", "All categories");
	define("lang_pages_admin_products_list_name", "Name");
	define("lang_pages_admin_products_list_model", "Model");
	define("lang_pages_admin_products_list_manufacturer", "Manufacturer");
	define("lang_pages_admin_products_list_price", "Price");
	define("lang_pages_admin_products_list_addnewproduct", "Add new product");
	define("lang_pages_admin_products_list_productsindatabase", "Products in database");

	define("lang_pages_admin_products_pictures_picturesforproduct", "Pictures for product");
	define("lang_pages_admin_products_pictures_picturefile", "Picture file");
	define("lang_pages_admin_products_pictures_view", "View");
	define("lang_pages_admin_products_pictures_delete", "Delete");
	define("lang_pages_admin_products_pictures_addapictureforthatproduct", "Add a picture for that product");
	define("lang_pages_admin_products_pictures_picture", "Picture");
	define("lang_pages_admin_products_pictures_finished", "Finished");
	define("lang_pages_admin_products_pictures_whattodo", "What do you want to do now");
	define("lang_pages_admin_products_pictures_backtoproductslist", "Go back to products list");
	define("lang_pages_admin_products_pictures_redirection", "redirection in 5 seconds");
	define("lang_pages_admin_products_pictures_setmore", "Set more options for that product");
	define("lang_pages_admin_products_pictures_addanother", "Add another product");	

	define("lang_pages_admin_providers_list_providerslist", "Providers list");
	define("lang_pages_admin_providers_list_name", "Name");
	define("lang_pages_admin_providers_list_addaprovider", "Add a provider");
	define("lang_pages_admin_providers_list_addname", "Name");
	define("lang_pages_admin_providers_list_list", "List");
	define("lang_pages_admin_providers_list_create", "Create");
	define("lang_pages_admin_providers_list_providers", "Providers");

	define("lang_pages_admin_shipping_config_shippingmethods", "Shipping methods");
	define("lang_pages_admin_shipping_config_name", "Name");
	define("lang_pages_admin_shipping_config_addnewshippingmethod", "Add a new shipping method");
	define("lang_pages_admin_shipping_config_addname", "Name");
	define("lang_pages_admin_shipping_config_description", "Descriptions");
	define("lang_pages_admin_shipping_config_arithmeticoperation", "Arithmetic operation");
	define("lang_pages_admin_shipping_config_shipping", "Shipping");
	define("lang_pages_admin_shipping_config_list", "List");
	define("lang_pages_admin_shipping_config_create", "Create");

	define("lang_pages_admin_shipping_edit_editshippingmethod", "Edit shipping method");
	define("lang_pages_admin_shipping_edit_name", "Name");
	define("lang_pages_admin_shipping_edit_description", "Description");
	define("lang_pages_admin_shipping_edit_arithmeticoperation", "Arithmetic operation");

	define("lang_pages_admin_shopping_details_invoicedetails", "Invoice details");
	define("lang_pages_admin_shopping_details_invoiceid", "Invoice ID");
	define("lang_pages_admin_shopping_details_shippingmethod", "Shipping method");
	define("lang_pages_admin_shopping_details_shippingcost", "Shipping cost");
	define("lang_pages_admin_shopping_details_paymentmethod", "Payment method");
	define("lang_pages_admin_shopping_details_orderdate", "Order date");
	define("lang_pages_admin_shopping_details_customer", "Customer");
	define("lang_pages_admin_shopping_details_total", "Total: (w/taxes, wo/shipping)");
	define("lang_pages_admin_shopping_details_grandtotal", "TOTAL");
	define("lang_pages_admin_shopping_details_status", "Status");
	define("lang_pages_admin_shopping_details_stadminconf", "Awaiting admin confirmation");
	define("lang_pages_admin_shopping_details_stpaymentconfirmed", "Payment confirmed");
	define("lang_pages_admin_shopping_details_stpackaginginprocess", "Packaging in process");
	define("lang_pages_admin_shopping_details_stshipped", "Shipped");
	define("lang_pages_admin_shopping_details_stpaymentretracted", "Payment retracted");
	define("lang_pages_admin_shopping_details_stdeclaredasfraudulent", "Declared as fraudulent");
	define("lang_pages_admin_shopping_details_streceivedbycustomer", "Received by customer");
	define("lang_pages_admin_shopping_details_streturnedbycustomer", "Returned by customer");
	define("lang_pages_admin_shopping_details_stother", "Others / miscs");
	define("lang_pages_admin_shopping_details_stcompleted", "Completed");
	define("lang_pages_admin_shopping_details_productsbought", "Products bought");
	define("lang_pages_admin_shopping_details_backtoinvoiceslist", "Back to invoices list");
	
	define("lang_pages_admin_shopping_invoices_invoices", "Invoices");
	define("lang_pages_admin_shopping_invoices_invoicenumber", "Invoice number");
	define("lang_pages_admin_shopping_invoices_date", "Date");
	define("lang_pages_admin_shopping_invoices_status", "Status");
	define("lang_pages_admin_shopping_invoices_stawaitingadminconfirmation", "Awaiting admin confirmation");
	define("lang_pages_admin_shopping_invoices_stpaymentconfirmed", "Payment confirmed");
	define("lang_pages_admin_shopping_invoices_stpackaginginprocess", "Packaging in process");
	define("lang_pages_admin_shopping_invoices_stshipped", "Shipped");
	define("lang_pages_admin_shopping_invoices_stpaymentretracted", "Payment retracted");
	define("lang_pages_admin_shopping_invoices_stdeclaredasfraudulent", "Declared as fraudulent");
	define("lang_pages_admin_shopping_invoices_streceivedbycustomer", "Received by customer");
	define("lang_pages_admin_shopping_invoices_streturnedbycustomer", "Returned by customer");
	define("lang_pages_admin_shopping_invoices_stothers", "Others / Miscs");
	define("lang_pages_admin_shopping_invoices_stcompleted", "Completed");
	define("lang_pages_admin_shopping_invoices_details", "Details");

	define("lang_pages_admin_system_languages_add_newlanguage", "New language");
	define("lang_pages_admin_system_languages_add_languagename", "Language name");
	define("lang_pages_admin_system_languages_add_dictionaryfile", "Dictionary file");
	define("lang_pages_admin_system_languages_add_defaultlanguage", "Default language");

	define("lang_pages_admin_system_languages_edit_editlanguage", "Edit language");
	define("lang_pages_admin_system_languages_edit_languagename", "Language name");
	define("lang_pages_admin_system_languages_edit_dictionaryfile", "Dictionary file");
	define("lang_pages_admin_system_languages_edit_defaultlanguage", "Default language");

	define("lang_pages_admin_system_languages_list_systemlanguages", "System languages");
	define("lang_pages_admin_system_languages_list_languagename", "Language name");
	define("lang_pages_admin_system_languages_list_addsystemlanguage", "Add a system language");
	define("lang_pages_admin_system_languages_list_list", "List");
	define("lang_pages_admin_system_languages_list_create", "Create");
	define("lang_pages_admin_system_languages_list_list", "List");
	define("lang_pages_admin_system_languages_list_create", "Create");

	define("lang_pages_admin_system_texts_editor_homepagewelcometext", "Home page welcome text");
	define("lang_pages_admin_system_texts_editor_contactusintrotext", "Contact us intro text");
	define("lang_pages_admin_system_texts_editor_orderconfirmationemail", "Order confirmation email");
	define("lang_pages_admin_system_texts_editor_privacynoticepage", "Privacy notice page");
	define("lang_pages_admin_system_texts_editor_conditionofusepage", "Conditions of use page");
	define("lang_pages_admin_system_texts_editor_shippingandreturnpage", "Shipping and return page");
	define("lang_pages_admin_system_texts_editor_text", "Text");

	define("lang_pages_admin_system_texts_selang_youareabout", "You are about to edit system texts");
	define("lang_pages_admin_system_texts_selang_pleaseselect", "Please select a language to edit");

	define("lang_pages_admin_system_general_generalsystemsettings", "General system settings");
	define("lang_pages_admin_system_general_companyname", "Company name");
	define("lang_pages_admin_system_general_adminname", "Administrator's name");
	define("lang_pages_admin_system_general_adminemail", "Administrtor's email address");
	define("lang_pages_admin_system_general_systememail", "System email address");
	define("lang_pages_admin_system_general_rooturl", "Root URL for this site");
	define("lang_pages_admin_system_general_departurezip", "Items departure Zip or Postal code");
	define("lang_pages_admin_system_general_taxarithmeticoper", "Taxes arithmetic operation");
	define("lang_pages_admin_system_general_catlistorder", "Categories tree list order");
	define("lang_pages_admin_system_general_insertorderasc", "Insertion order, Ascending");
	define("lang_pages_admin_system_general_insertorderdesc", "Insertion order, Descending");
	define("lang_pages_admin_system_general_catnameasc", "Category name, Ascensing");
	define("lang_pages_admin_system_general_catnamedesc", "Category name, Descending");
	define("lang_pages_admin_system_general_weightunit", "Weight unit");
	define("lang_pages_admin_system_general_kilograms", "Kilograms");
	define("lang_pages_admin_system_general_pounds", "Pounds");
	define("lang_pages_admin_system_general_metrictons", "Metric tons");
	define("lang_pages_admin_system_general_grams", "Grams");
	define("lang_pages_admin_system_general_miligrams", "Miligrams");
	define("lang_pages_admin_system_general_tons", "Tons");
	define("lang_pages_admin_system_general_ounces", "Ounces");
	define("lang_pages_admin_system_general_showprodbo", "Show products marked as Back Order");
	define("lang_pages_admin_system_general_buybo", "Customers can buy BO items");
	define("lang_pages_admin_system_general_showbo", "Show Back Order status");
	define("lang_pages_admin_system_general_showoutofdate", "Show products that are out of date range");
	define("lang_pages_admin_system_general_orderoutofrange", "Cust. can buy products that are out of date range");
	define("lang_pages_admin_system_general_defaultthemetouse", "Default theme to use");
	define("lang_pages_admin_system_general_companylogo", "Company logo");
	define("lang_pages_admin_system_general_tabsystem", "System");
	define("lang_pages_admin_system_general_tabcompany", "Company");
	define("lang_pages_admin_system_general_tabstyle", "Style");
	define("lang_pages_admin_system_general_tabproducts", "Products");
	define("lang_pages_admin_system_general_ratingstyleimage", "Use images");
	define("lang_pages_admin_system_general_ratingstyletext", "Use texts");
	define("lang_pages_admin_system_general_ratingstyle", "How to display rating results");

	define("lang_pages_admin_users_details_customersdetails", "Customers details");
	define("lang_pages_admin_users_details_firstname", "First name");
	define("lang_pages_admin_users_details_lastname", "Last name");
	define("lang_pages_admin_users_details_emailaddress", "Email address");
	define("lang_pages_admin_users_details_password", "Password");
	define("lang_pages_admin_users_details_companyname", "Company name");
	define("lang_pages_admin_users_details_address", "Address");
	define("lang_pages_admin_users_details_city", "City");
	define("lang_pages_admin_users_details_state", "State");
	define("lang_pages_admin_users_details_zipcode", "Zip code");
	define("lang_pages_admin_users_details_country", "Country");
	define("lang_pages_admin_users_details_phonenumber", "Phone number");
	define("lang_pages_admin_users_details_faxnumber", "Fax number");
	define("lang_pages_admin_users_details_isadmin", "Is admin");
	define("lang_pages_admin_users_details_backtocustomerslist", "Back to customers list");
	define("lang_pages_admin_users_details_sendemail", "Send email");

	define("lang_pages_admin_users_list_customersanduserslist", "Customers & Users list");
	define("lang_pages_admin_users_list_name", "Name");
	define("lang_pages_admin_users_list_details", "Details");
	
	define("lang_pages_admin_system_updates_systemupdate", "System update");
	define("lang_pages_admin_system_updates_insertcode", "Please insert your update code below");
	
	define("lang_pages_admin_menu_adminmenu", "Administrative menu");
	define("lang_pages_admin_menu_manufacturerprovider", "Manufacturers & Providers");
	define("lang_pages_admin_menu_manufacturerslist", "Manufacturers list");
	define("lang_pages_admin_menu_addmanufacturer", "Add a manufacturer");
	define("lang_pages_admin_menu_providerslist", "Providers list");
	define("lang_pages_admin_menu_categoriesandproducts", "Categories & Products");
	define("lang_pages_admin_menu_categorieslist", "Categories list");
	define("lang_pages_admin_menu_addacategory", "Add a category");
	define("lang_pages_admin_menu_productslist", "Products list");
	define("lang_pages_admin_menu_addaproduct", "Add a product");
	define("lang_pages_admin_menu_systemsettings", "System settings");
	define("lang_pages_admin_menu_generalsystemsettings", "General system settings");
	define("lang_pages_admin_menu_advertisementsmanagement", "Advertisements management");
	define("lang_pages_admin_menu_languagesmanagement", "Languages management");
	define("lang_pages_admin_menu_currenciesmanagement", "Currencies management");
	define("lang_pages_admin_menu_systemtextseditor", "System texts editor");
	define("lang_pages_admin_menu_paymentblocksconfiguration", "Payment blocks configuration");
	define("lang_pages_admin_menu_shippingconfigurations", "Shipping configurations");
	define("lang_pages_admin_menu_shopping", "Shopping");
	define("lang_pages_admin_menu_invoicesandorders", "Invoices & Orders");
	define("lang_pages_admin_menu_customersandusers", "Customers & Users");
	define("lang_pages_admin_menu_stockmanagement", "Stock management");
	define("lang_pages_admin_menu_updates", "System update");

	define("lang_pages_cart_checkout_youarenowregistered", "You are now registered. Please fill in this form");
	define("lang_pages_cart_checkout_emailaddress", "Email address");
	define("lang_pages_cart_checkout_password", "Password");
	define("lang_pages_cart_checkout_login", "Login");
	define("lang_pages_cart_checkout_ifyouprev", "If you previously ordered on this system, please login");
	define("lang_pages_cart_checkout_ifthisisyourfirstorder", "If this is your first order here, please fill in this form");
	define("lang_pages_cart_checkout_firstname", "First name");
	define("lang_pages_cart_checkout_lastname", "Last name");
	define("lang_pages_cart_checkout_email", "Email address");
	define("lang_pages_cart_checkout_desiredpassword", "Desired password");
	define("lang_pages_cart_checkout_companyname", "Company name");
	define("lang_pages_cart_checkout_address", "Address");
	define("lang_pages_cart_checkout_city", "City");
	define("lang_pages_cart_checkout_stateprovince", "State / Province");
	define("lang_pages_cart_checkout_zip", "Zip / Postal code");
	define("lang_pages_cart_checkout_country", "Country");
	define("lang_pages_cart_checkout_phonenumber", "Phone number");
	define("lang_pages_cart_checkout_faxnumber", "Fax number");
	define("lang_pages_cart_checkout_shippingaddress", "Shipping address");
	define("lang_pages_cart_checkout_name", "Name");
	define("lang_pages_cart_checkout_order", "Order");
	define("lang_pages_cart_checkout_item", "Item");
	define("lang_pages_cart_checkout_qty", "Qty");
	define("lang_pages_cart_checkout_unitprice", "Unit price");
	define("lang_pages_cart_checkout_total", "Total");
	define("lang_pages_cart_checkout_subtotal", "Sub-Total");
	define("lang_pages_cart_checkout_taxes", "Taxes");
	define("lang_pages_cart_checkout_shipping", "Shipping");
	define("lang_pages_cart_checkout_paymentmethod", "Payment method");

	define("lang_pages_cart_confirmorder_orderconfirmation", "Order confirmation");
	
	define("lang_pages_cart_show_product", "Product");
	define("lang_pages_cart_show_qty", "Qty");
	define("lang_pages_cart_show_unitprice", "Unit price");
	define("lang_pages_cart_show_subtotal", "Sub-Total");
	define("lang_pages_cart_show_checkout", "Checkout");
	define("lang_pages_cart_show_cartempty", "Your shopping cart is empty");
	define("lang_pages_cart_show_total", "Total");
	define("lang_pages_cart_show_addone", "Add one");
	define("lang_pages_cart_show_remone", "Remove one");
	define("lang_pages_cart_show_donerem", "Removed one item");
	define("lang_pages_cart_show_doneadd", "Added one item");
	define("lang_pages_cart_show_details", "Details");
	
	define("lang_pages_information_contact_thankyou", "Thank you, we will come back to you shortly");
	define("lang_pages_information_contact_name", "First name / Last name");
	define("lang_pages_information_contact_email", "Email address");
	define("lang_pages_information_contact_service", "Service");
	define("lang_pages_information_contact_subject", "Subject");
	define("lang_pages_information_contact_message", "Message");

	define("lang_pages_products_details_addedtoshoppingcart", "Product added to shopping cart");
	define("lang_pages_products_details_edit", "Edit");
	define("lang_pages_products_details_morepictures", "More pictures");
	define("lang_pages_products_details_relatedproducts", "Related products");
	define("lang_pages_products_details_ourrating", "Our rating");
	define("lang_pages_products_details_customersrating", "Customers rating");
	define("lang_pages_products_details_rateit", "Rate it");
	define("lang_pages_products_details_tellafriend", "Tell a friend");
	define("lang_pages_products_details_special", "Special");
	define("lang_pages_products_details_addtocart", "Add to shopping cart");
	define("lang_pages_products_details_backorder", "This product is back order");
	define("lang_pages_products_details_availablefrom", "Available from");
	define("lang_pages_products_details_to", "to");
	define("lang_pages_products_details_availableuntil", "This product will be available until");
	define("lang_pages_products_details_backtolist", "Back to products list");

	define("lang_pages_products_list_addedtoshoppingcart", "Product added to shopping cart");
	define("lang_pages_products_list_productsin", "Products in");
	define("lang_pages_products_list_home", "Home");
	define("lang_pages_products_list_buy", "Buy");
	define("lang_pages_products_list_details", "Details");
	define("lang_pages_products_list_backorder", "Back order");
	define("lang_pages_products_list_edit", "Edit");
	define("lang_pages_products_list_youmaywanttolook", "You may want to look at these subcategories");
	
	define("lang_pages_products_listmanuf_addedtoshoppingcart", "Product added to shopping cart");
	define("lang_pages_products_listmanuf_productsby", "Products by");
	define("lang_pages_products_listmanuf_buy", "Buy");
	define("lang_pages_products_listmanuf_details", "Details");
	
	define("lang_pages_products_tellafriend_checkthisurl", "Hey! Check this URL");
	define("lang_pages_products_tellafriend_tellafriend", "Tell a friend");
	define("lang_pages_products_tellafriend_friendsemail", "Friend's email address");
	define("lang_pages_products_tellafriend_emailsubject", "Email subject");
	define("lang_pages_products_tellafriend_hey", "Hey! Check this out!");

	define("lang_pages_products_search_searchresults", "Search results for");
	define("lang_pages_products_search_matches", "products matching your query where found in database");
	define("lang_pages_products_search_addedtoshoppingcart", "Product added to shopping cart");

	define("lang_themes_bykeywords", "By keywords");
	define("lang_pages_themes_home", "Home");
	define("lang_pages_themes_shoppingcart", "Shopping cart");
	define("lang_pages_themes_contactus", "Contact us");
	define("lang_pages_themes_admin", "Admin");
	define("lang_pages_themes_yourcart", "Your shopping cart");
	define("lang_pages_themes_details", "Details");
	define("lang_pages_themes_items", "items");
	define("lang_pages_themes_total", "total");
	define("lang_pages_themes_language", "Language");
	define("lang_pages_themes_currency", "Currency");
	define("lang_pages_themes_usersonline", "Users online");
	define("lang_pages_themes_products", "products");
	define("lang_pages_themes_uptime", "Uptime");
	define("lang_pages_themes_days", "days");

	define("lang_pages_themes_home_welcome", "WELCOME");
	define("lang_pages_themes_home_featured", "FEATURED PRODUCT");
	define("lang_pages_themes_home_details", "Details");
	define("lang_pages_themes_home_newproducts", "NEW PRODUCTS");
	define("lang_pages_themes_home_email", "E-Mail");
	define("lang_pages_themes_home_password", "Password");
	define("lang_pages_themes_home_loggedin", "Logged in");
	define("lang_pages_themes_home_logout", "Logout");

	define("lang_pages_themes_blocks_browsemanufacturers_browsebyman", "Browse by manufacturer");
	define("lang_pages_themes_blocks_browsemanufacturers_select", "-- Select --");

	define("lang_pages_themes_blocks_cataloguecats_cataloguecategories", "Catalogue categories");

	define("lang_pages_themes_blocks_categoriesdrop_bycategory", "By category");
	define("lang_pages_themes_blocks_categoriesdrop_select", "-- Select --");

	define("lang_pages_themes_blocks_informations_informations", "Information");
	define("lang_pages_themes_blocks_informations_contactus", "Contact us");
	define("lang_pages_themes_blocks_informations_privacynotice", "Privacy notice");
	define("lang_pages_themes_blocks_informations_conditionsofuse", "Conditions of use");
	define("lang_pages_themes_blocks_informations_shippingandreturns", "Shipping & returns");
	
	
	//////////////////////////////////////////////////////////////////////////////////////////
	// NEW LANGUAGES FIELDS ADDED AFTER V0921B
	//////////////////////////////////////////////////////////////////////////////////////////

	define("lang_pages_admin_shopping_details_notesforthisinvoice", "Notes for this invoice");

	define("lang_pages_admin_products_edit_noreviews", "No reviews for this product yet");
	define("lang_pages_admin_products_edit_productsreviews", "Products reviews");
	
	define("lang_pages_admin_system_general_enablereviews", "Enable the products reviews system");
	
	define("lang_pages_products_details_reviews", "Reviews");
	define("lang_pages_products_details_readreviews", "Read reviews");
	define("lang_pages_products_details_writereview", "Review this product");
	
	define("lang_pages_reviews_read_reviewsfor", "Reviews for");
	define("lang_pages_reviews_read_user", "User");
	define("lang_pages_reviews_read_reviewproduct", "Review this product");
	
	define("lang_pages_reviews_write_thankyou", "Thank you");
	define("lang_pages_reviews_write_writefor", "Write a review for");
	define("lang_pages_reviews_write_nickname", "Your nick name");
	define("lang_pages_reviews_write_yourreview", "Your review");

	define("lang_pages_admin_mailing_mailing_sending", "Sending mails... Please wait");
	define("lang_pages_admin_mailing_mailing_errorsendingto", "Error sending mail to");
	define("lang_pages_admin_mailing_mailing_skipping", "Skipping");
	define("lang_pages_admin_mailing_mailing_mailsentto", "Mail sent to");
	define("lang_pages_admin_mailing_mailing_finished", "Finished");
	define("lang_pages_admin_mailing_mailing_sent", "Sent");
	define("lang_pages_admin_mailing_mailing_skip", "Skipped");
	define("lang_pages_admin_mailing_mailing_mailinglist", "Mailing list management");
	define("lang_pages_admin_mailing_mailing_from", "From");
	define("lang_pages_admin_mailing_mailing_to", "To");
	define("lang_pages_admin_mailing_mailing_subject", "Subject");
	define("lang_pages_admin_mailing_mailing_message", "Message");
	define("lang_pages_admin_mailing_mailing_everymember", "Every registered members");
	
	define("lang_pages_admin_stats_access_accessstatsfor", "Access statistics for");
	
	define("lang_pages_admin_stats_sales_salesstatsfor", "Sales statistics for");
	define("lang_pages_admin_stats_sales_soldunitsfor", "Sold units (all products) for");
	define("lang_pages_admin_stats_sales_soldunits", "Sold units");
	define("lang_pages_admin_stats_sales_salesstatsfor", "Sales statistics (all products) for");
	define("lang_pages_admin_stats_sales_salesstats", "Sales statistics");

	define("lang_pages_admin_system_general_usesmiles", "Enable smiles in products reviews");
	define("lang_pages_admin_system_general_cookieprefix", "Cookie name prefix");
	
	define("lang_theme_lostpass", "Lost password");
	define("lang_theme_register", "Register");
		
	define("lang_pages_lostpass_error", "Error: The E-Mail address you specified can not be found in our users database");
	define("lang_pages_lostpass_yourpassword", "your password");
	define("lang_pages_lostpass_yourpasson", "Your password on");
	define("lang_pages_lostpass_is", "is");
	define("lang_pages_lostpass_passsent", "Your password has been sent to the following email address");
	define("lang_pages_lostpass_lostpass", "Lost password");
	define("lang_pages_lostpass_toptext", "Please fill the form below in order to retrive your password. It will be sent to you by email.");
	define("lang_pages_lostpass_email", "E-mail address");

	define("lang_pages_admin_system_texts_editor_registrationtext", "Registration text shown on the register page"); 
	
	define("lang_pages_register_register_registration", "User registration");
	
	define("lang_pages_register_register_firstname", "First name");
	define("lang_pages_register_register_lastname", "Last name");
	define("lang_pages_register_register_email", "E-Mail address");
	define("lang_pages_register_register_desiredpassword", "Desired password");
	define("lang_pages_register_register_companyname", "Company name");
	define("lang_pages_register_register_address", "Address");
	define("lang_pages_register_register_city", "City");
	define("lang_pages_register_register_stateprovince", "State / Province");
	define("lang_pages_register_register_zip", "Zip / Postal code");
	define("lang_pages_register_register_country", "Country");
	define("lang_pages_register_register_phonenumber", "Phone number");
	define("lang_pages_register_register_faxnumber", "Fax number");
	define("lang_pages_register_register_registered", "Thank you. You are now registered.");
	
	define("lang_pages_admin_system_general_showcount", "Show count next to category name");
	define("lang_pages_admin_system_general_linktofolder", "Apply link to folders in tree");
	define("lang_pages_admin_system_general_highlightselected", "Hilight selected item in tree");
	define("lang_pages_admin_system_general_showlines", "Show connection lines in tree");
	define("lang_pages_admin_system_general_useicons", "Use icons in tree");
	define("lang_pages_admin_system_general_displaydesc", "Display tree item description in status bar");
	define("lang_pages_admin_system_general_closesame", "Close same level in tree");
	define("lang_pages_admin_system_general_expandall", "Expand all categories by default");
	
	define("lang_pages_admin_categories_list_sortorder", "Sort");
	
	define("lang_pages_admin_system_general_sortorder", "Sort order number");