<?
//////////////////////////////////////////////////////////////
//           DEFINE THE LANGUAGE CHARSET TO USE             //
//                                                          //
// Possible values are;                                     //
// -------------------------------------------------------- //
// CHARSETNAME (use this)             VALUE                 //
// -------------------------------------------------------- //
// arabic                             iso-8859-6            //
// baltic                             iso-8859-4            //
// central european                   iso-8859-2            //
// chinese simplified                 euc-cn                //
// chinese traditional                big5                  //
// cyrillic                           koi8-r                //
// greek                              iso-8859-7            //
// hebrew                             iso-8859-8-i          //
// icelandic                          x-mac-icelandic       //
// japanese                           euc-jp                //
// korean                             euc-kr                //
// maltese                            iso-8859-3            //
// thai                               windows-874           //
// turkish                            iso-8859-9            //
// unicode                            utf-8                 //
// vietnamese                         windows-1258          //
// western                            iso-8859-1            //
//                                                          //
//////////////////////////////////////////////////////////////
define("language_charset", "Western");

//////////////////////////////////////////////////////////////
// When translating, beware to NOT use quotes (") within    //
// your texts. If you absolutely need to use quotes, prefix //
// them with a backslach (\")                               //
//////////////////////////////////////////////////////////////

	define("lang_general_yes", "Oui");
	define("lang_general_no", "Non");
	define("lang_general_submit", "Soumettre");
	define("lang_general_edit", "�diter");
	define("lang_general_delete", "Effacer");
	define("lang_general_action", "Action");
	define("lang_general_id", "ID");
	define("lang_general_select", "-- S�lection --");
	define("lang_general_deleteconfirm", "Voulez-vous vraiment supprimer l'article s�lectionn�?");

	define("lang_pages_admin_advertisements_list_advertisements", "Annonces");
	define("lang_pages_admin_advertisements_list_name", "Nom");
	define("lang_pages_admin_advertisements_list_addadvertisement", "Ajoutez une publicit�");
	define("lang_pages_admin_advertisements_list_friendlyname", "Nom");
	define("lang_pages_admin_advertisements_list_imagefile", "Fichier image");
	define("lang_pages_admin_advertisements_list_url", "URL");
	define("lang_pages_admin_advertisements_list_list", "Liste");
	define("lang_pages_admin_advertisements_list_add", "Ajout");

	define("lang_pages_admin_categories_add_addnew", "Ajouter une nouvelle cat�gorie");
	define("lang_pages_admin_categories_add_categoryname", "Nom de la cat�gorie");
	define("lang_pages_admin_categories_add_parentcategory", "Cat�gorie supp�rieure");
	define("lang_pages_admin_categories_add_nonemastercat", "Aucune (cat�gorie principale)");
	define("lang_pages_admin_categories_add_description", "Description");

	define("lang_pages_admin_categories_edit_editacategory", "�diter une cat�gorie");
	define("lang_pages_admin_categories_edit_categoryname", "Nom de la cat�gorie");
	define("lang_pages_admin_categories_edit_parentcategory", "Cat�gorie supp�rieure");
	define("lang_pages_admin_categories_edit_nonemastercat", "Aucune (cat�gorie principale)");
	define("lang_pages_admin_categories_edit_description", "Description");

	define("lang_pages_admin_categories_list_categories", "Cat�gories");
	define("lang_pages_admin_categories_list_name", "Nom");
	define("lang_pages_admin_categories_list_parent", "Parent");
	define("lang_pages_admin_categories_list_description", "Description");
	define("lang_pages_admin_categories_list_addacategory", "Ajouter une nouvelle cat�gorie");
	define("lang_pages_admin_categories_list_head", "Cat�gories");
	define("lang_pages_admin_categories_list_list", "Liste");
	define("lang_pages_admin_categories_list_create", "Cr�er");

	define("lang_pages_admin_currencies_edit_editcurrency", "�ditez la devise");
	define("lang_pages_admin_currencies_edit_name", "Nom");
	define("lang_pages_admin_currencies_edit_itlcc", "Code international de devise");
	define("lang_pages_admin_currencies_edit_default", "D�faut");
	define("lang_pages_admin_currencies_edit_moneysymbol", "Symbole d'argent");
	define("lang_pages_admin_currencies_edit_moneysymbollocation", "Emplacement du symbole d'argent");
	define("lang_pages_admin_currencies_edit_onleftwithspace", "Du c�t� gauche avec espace");
	define("lang_pages_admin_currencies_edit_onleft", "Du c�t� gauche");
	define("lang_pages_admin_currencies_edit_onrightwithspace", "Du c�t� droit avec espace");
	define("lang_pages_admin_currencies_edit_onright", "Du c�t� droit");
	define("lang_pages_admin_currencies_edit_decsepsym", "Symbole s�parateur des d�cimales");

	define("lang_pages_admin_currencies_list_currencies", "Devises");
	define("lang_pages_admin_currencies_list_name", "Nom");
	define("lang_pages_admin_currencies_list_code", "Code");
	define("lang_pages_admin_currencies_list_default", "D�faut");
	define("lang_pages_admin_currencies_list_addcurrency", "Ajouter une devise");
	define("lang_pages_admin_currencies_list_intlcc", "Code international de devise");
	define("lang_pages_admin_currencies_list_moneysymbol", "Symbole d'argent");
	define("lang_pages_admin_currencies_list_moneysymbollocation", "Emplacement du symbole d'argent");
	define("lang_pages_admin_currencies_list_onleftwithspace", "Du c�t� gauche avec espace");
	define("lang_pages_admin_currencies_list_onleft", "Du c�t� gauche");
	define("lang_pages_admin_currencies_list_onrightwithspace", "Du c�t� droit avec espace");
	define("lang_pages_admin_currencies_list_onright", "Du c�t� droit");
	define("lang_pages_admin_currencies_list_decsepsym", "Symbole s�parateur des d�cimales");
	define("lang_pages_admin_currencies_list_list", "Liste");
	define("lang_pages_admin_currencies_list_create", "Cr�er");

	define("lang_pages_admin_manufacturers_add_addaman", "Ajouter un fabricant");
	define("lang_pages_admin_manufacturers_add_name", "Nom");
	define("lang_pages_admin_manufacturers_add_website", "Site Web");
	define("lang_pages_admin_manufacturers_add_logofile", "Logo");

	define("lang_pages_admin_manufacturers_edit_editman", "�diter un fabricant");
	define("lang_pages_admin_manufacturers_edit_name", "Nom");
	define("lang_pages_admin_manufacturers_edit_website", "Site Web");
	define("lang_pages_admin_manufacturers_edit_actuallogo", "Logo actuel");
	define("lang_pages_admin_manufacturers_edit_newlogofile", "Nouveau logo");
	define("lang_pages_admin_manufacturers_edit_gotomanlist", "Aller � la liste des fabricants");

	define("lang_pages_admin_manufacturers_list_name", "Nom");
	define("lang_pages_admin_manufacturers_list_website", "Site Web");
	define("lang_pages_admin_manufacturers_list_creationdate", "Date de cr�ation");
	define("lang_pages_admin_manufacturers_list_logo", "Logo");
	define("lang_pages_admin_manufacturers_list_nopicture", "Aucune image");
	define("lang_pages_admin_manufacturers_list_createman", "Cr�er un nouveau fabricant");
	define("lang_pages_admin_manufacturers_list_totalman", "fabricants au total");
	define("lang_pages_admin_manufacturers_list_manufacturers", "Manufacturiers");
	define("lang_pages_admin_manufacturers_list_list", "Liste");
	define("lang_pages_admin_manufacturers_list_create", "Cr�er");

	define("lang_pages_admin_payment_blockconfig_paybkconfig", "Configuration des blocs de paiement");
	define("lang_pages_admin_payment_blockconfig_block", "Bloc");

	define("lang_pages_admin_products_add_addnewproduct", "Ajouter un nouveau produit");
	define("lang_pages_admin_products_add_productname", "Nom du produit");
	define("lang_pages_admin_products_add_model", "Mod�le");
	define("lang_pages_admin_products_add_intref", "No. de r�f. interne");
	define("lang_pages_admin_products_add_category", "Cat�gorie");
	define("lang_pages_admin_products_add_manufacturer", "Fabricant");
	define("lang_pages_admin_products_add_provider", "Fournisseur");
	define("lang_pages_admin_products_add_select", "-- S�lection --");
	define("lang_pages_admin_products_add_sellprice", "Prix de vente");
	define("lang_pages_admin_products_add_specialsellprice", "Prix sp�cial de vente");
	define("lang_pages_admin_products_add_costprice", "Prix d'achat");
	define("lang_pages_admin_products_add_qtyinstock", "Qt�e. en stock");
	define("lang_pages_admin_products_add_reorderqty", "Qt�e. limite");
	define("lang_pages_admin_products_add_backorder", "Commande en attente (BO)");
	define("lang_pages_admin_products_add_available", "Disponible");
	define("lang_pages_admin_products_add_from", "De");
	define("lang_pages_admin_products_add_to", "�");
	define("lang_pages_admin_products_add_weight", "Poids");
	define("lang_pages_admin_products_add_featured", "Produit vedette");
	define("lang_pages_admin_products_add_visible", "Visible");
	define("lang_pages_admin_products_add_rating", "�valuation");
	define("lang_pages_admin_products_add_producturl", "URL du produit");
	define("lang_pages_admin_products_add_productdescription", "Description du produit");

	define("lang_pages_admin_products_edit_product", "Produit");
	define("lang_pages_admin_products_edit_productname", "Nom du produit");
	define("lang_pages_admin_products_edit_model", "Mod�le");
	define("lang_pages_admin_products_edit_intrefnumber", "No. de r�f. interne");
	define("lang_pages_admin_products_edit_category", "Cat�gorie");
	define("lang_pages_admin_products_edit_manufacturer", "Fabricant");
	define("lang_pages_admin_products_edit_provider", "Fournisseur");
	define("lang_pages_admin_products_edit_none", "aucun");
	define("lang_pages_admin_products_edit_sellprice", "Prix de vente");
	define("lang_pages_admin_products_edit_specialsellprice", "Prix sp�cial de vente");
	define("lang_pages_admin_products_edit_costprice", "Prix d'achat");
	define("lang_pages_admin_products_edit_qtyinstock", "Quantit�.  en stock");
	define("lang_pages_admin_products_edit_reorderqty", "Qt�e. limite");
	define("lang_pages_admin_products_edit_backorder", "Commande en attente (BO)");
	define("lang_pages_admin_products_edit_available", "Disponible");
	define("lang_pages_admin_products_edit_from", "De");
	define("lang_pages_admin_products_edit_to", "�");
	define("lang_pages_admin_products_edit_weight", "Poids");
	define("lang_pages_admin_products_edit_featured", "Produit vedette");
	define("lang_pages_admin_products_edit_visible", "Visible");
	define("lang_pages_admin_products_edit_rating", "�valuation");
	define("lang_pages_admin_products_edit_select", "S�lectionnez");
	define("lang_pages_admin_products_edit_producturl", "URL du produit");
	define("lang_pages_admin_products_edit_description", "Description");
	define("lang_pages_admin_products_edit_productdescription", "Description du produit");
	define("lang_pages_admin_products_edit_gallery", "Galerie");
	define("lang_pages_admin_products_edit_file", "Fichier");
	define("lang_pages_admin_products_edit_view", "Voir");
	define("lang_pages_admin_products_edit_addpictureforthatproduct", "Ajouter une image pour ce produit");
	define("lang_pages_admin_products_edit_picture", "Image");
	define("lang_pages_admin_products_edit_relations", "Relations");
	define("lang_pages_admin_products_edit_relatedproducts", "Produits connexes");
	define("lang_pages_admin_products_edit_relproductname", "Nom du produit");
	define("lang_pages_admin_products_edit_breakrelationship", "Rompre ce rapport");
	define("lang_pages_admin_products_edit_productsthatrelate", "Produits reli�s � cet article");
	define("lang_pages_admin_products_edit_bwproductname", "Nom du produit");
	define("lang_pages_admin_products_edit_createrelationship", "Cr�er un rapport");
	define("lang_pages_admin_products_edit_selectaproduct", "Choisissez un produit");
	define("lang_pages_admin_products_edit_pleaseselect", "-- S�lectionnez --");
	define("lang_pages_admin_products_edit_createreverserel", "Cr�er le rapport inverse");
	define("lang_pages_admin_products_edit_reviews", "Revues");
	define("lang_pages_admin_products_edit_statistics", "Statistiques");
	define("lang_pages_admin_products_edit_gotoproductslist", "Aller � la liste de produits (c�t� administrateur)");
	define("lang_pages_admin_products_edit_gotoproductdetails", "Aller aux d�tails du produit (c�t� utilisateur)");
	define("lang_pages_admin_products_edit_editproduct", "�dition de produit");

	define("lang_pages_admin_products_list_products", "Produits");
	define("lang_pages_admin_products_list_showproductsinthiscat", "Montrer les produits dans cette cat�gorie");
	define("lang_pages_admin_products_list_allcategories", "Toutes les cat�gories");
	define("lang_pages_admin_products_list_name", "Nom");
	define("lang_pages_admin_products_list_model", "Mod�le");
	define("lang_pages_admin_products_list_manufacturer", "Fabricant");
	define("lang_pages_admin_products_list_price", "Prix");
	define("lang_pages_admin_products_list_addnewproduct", "Ajouter un nouveau produit");
	define("lang_pages_admin_products_list_productsindatabase", "produits dans la base de donn�es");

	define("lang_pages_admin_products_pictures_picturesforproduct", "Images pour le produit");
	define("lang_pages_admin_products_pictures_picturefile", "Fichier image");
	define("lang_pages_admin_products_pictures_view", "Voir");
	define("lang_pages_admin_products_pictures_delete", "Effacer");
	define("lang_pages_admin_products_pictures_addapictureforthatproduct", "Ajouter une image pour ce produit");
	define("lang_pages_admin_products_pictures_picture", "Image");
	define("lang_pages_admin_products_pictures_finished", "Termin�");
	define("lang_pages_admin_products_pictures_whattodo", "Que d�sirez-vous faire?");
	define("lang_pages_admin_products_pictures_backtoproductslist", "Retour � la liste des produits");
	define("lang_pages_admin_products_pictures_redirection", "redirection dans 5 secondes");
	define("lang_pages_admin_products_pictures_setmore", "Plus de param�tres pour ce produit");
	define("lang_pages_admin_products_pictures_addanother", "Ajouter un autre produit");

	define("lang_pages_admin_providers_list_providerslist", "Liste des fournisseurs");
	define("lang_pages_admin_providers_list_name", "Nom");
	define("lang_pages_admin_providers_list_addaprovider", "Ajouter un fournisseur");
	define("lang_pages_admin_providers_list_addname", "Nom");
	define("lang_pages_admin_providers_list_list", "Liste");
	define("lang_pages_admin_providers_list_create", "Cr�er");
	define("lang_pages_admin_providers_list_providers", "Fournisseurs");

	define("lang_pages_admin_shipping_config_shippingmethods", "M�thodes d'exp�dition");
	define("lang_pages_admin_shipping_config_name", "Nom");
	define("lang_pages_admin_shipping_config_addnewshippingmethod", "Ajouter une nouvelle m�thode d'exp�dition");
	define("lang_pages_admin_shipping_config_addname", "Nom");
	define("lang_pages_admin_shipping_config_description", "Descriptions");
	define("lang_pages_admin_shipping_config_arithmeticoperation", "Op�ration arithm�tique");
	define("lang_pages_admin_shipping_config_shipping", "Exp�dition");
	define("lang_pages_admin_shipping_config_list", "Liste");
	define("lang_pages_admin_shipping_config_create", "Cr�er");

	define("lang_pages_admin_shipping_edit_editshippingmethod", "�diter la m�thode d'exp�dition");
	define("lang_pages_admin_shipping_edit_name", "Nom");
	define("lang_pages_admin_shipping_edit_description", "Description");
	define("lang_pages_admin_shipping_edit_arithmeticoperation", "Op�ration arithm�tique");

	define("lang_pages_admin_shopping_details_invoicedetails", "D�tails d'une facture");
	define("lang_pages_admin_shopping_details_invoiceid", "ID de facture");
	define("lang_pages_admin_shopping_details_shippingmethod", "M�thode d'exp�dition");
	define("lang_pages_admin_shopping_details_shippingcost", "Co�t d'exp�dition");
	define("lang_pages_admin_shopping_details_paymentmethod", "M�thode de paiement");
	define("lang_pages_admin_shopping_details_orderdate", "Date de commande");
	define("lang_pages_admin_shopping_details_customer", "Client");
	define("lang_pages_admin_shopping_details_total", "Total:  (TTC, sans exp�d.)");
	define("lang_pages_admin_shopping_details_grandtotal", "TOTAL");
	define("lang_pages_admin_shopping_details_status", "Statut");
	define("lang_pages_admin_shopping_details_stadminconf", "En attente de confirmation");
	define("lang_pages_admin_shopping_details_stpaymentconfirmed", "Le paiement a �t� confirm�");
	define("lang_pages_admin_shopping_details_stpackaginginprocess", "Empaquetage en cours");
	define("lang_pages_admin_shopping_details_stshipped", "Envoy�");
	define("lang_pages_admin_shopping_details_stpaymentretracted", "Le paiement a �t� retir�");
	define("lang_pages_admin_shopping_details_stdeclaredasfraudulent", "D�clar� comme frauduleux");
	define("lang_pages_admin_shopping_details_streceivedbycustomer", "Re�u par le client");
	define("lang_pages_admin_shopping_details_streturnedbycustomer", "Retourn� par le client");
	define("lang_pages_admin_shopping_details_stother", "Autres");
	define("lang_pages_admin_shopping_details_stcompleted", "Accompli");
	define("lang_pages_admin_shopping_details_productsbought", "Produits achet�s");
	define("lang_pages_admin_shopping_details_backtoinvoiceslist", "Retour � la liste des factures");

	define("lang_pages_admin_shopping_invoices_invoices", "Factures");
	define("lang_pages_admin_shopping_invoices_invoicenumber", "Num�ro de facture");
	define("lang_pages_admin_shopping_invoices_date", "Date");
	define("lang_pages_admin_shopping_invoices_status", "Statut");
	define("lang_pages_admin_shopping_invoices_stawaitingadminconfirmation", "En attente de confirmation");
	define("lang_pages_admin_shopping_invoices_stpaymentconfirmed", "Le paiement a �t� confirm�");
	define("lang_pages_admin_shopping_invoices_stpackaginginprocess", "Empaquetage en cours");
	define("lang_pages_admin_shopping_invoices_stshipped", "Envoy�");
	define("lang_pages_admin_shopping_invoices_stpaymentretracted", "Le paiement a �t� retir�");
	define("lang_pages_admin_shopping_invoices_stdeclaredasfraudulent", "D�clar� comme frauduleux");
	define("lang_pages_admin_shopping_invoices_streceivedbycustomer", "Re�u par le client");
	define("lang_pages_admin_shopping_invoices_streturnedbycustomer", "Retourn� par le client");
	define("lang_pages_admin_shopping_invoices_stothers", "Autres");
	define("lang_pages_admin_shopping_invoices_stcompleted", "Accompli");
	define("lang_pages_admin_shopping_invoices_details", "D�tails");

	define("lang_pages_admin_system_languages_add_newlanguage", "Nouvelle langue");
	define("lang_pages_admin_system_languages_add_languagename", "Nom de la langue");
	define("lang_pages_admin_system_languages_add_dictionaryfile", "Fichier dictionnaire");
	define("lang_pages_admin_system_languages_add_defaultlanguage", "Langue par d�faut");

	define("lang_pages_admin_system_languages_edit_editlanguage", "�diter la langue");
	define("lang_pages_admin_system_languages_edit_languagename", "Nom de la langue");
	define("lang_pages_admin_system_languages_edit_dictionaryfile", "Fichier dictionnaire");
	define("lang_pages_admin_system_languages_edit_defaultlanguage", "Langue par d�faut");

	define("lang_pages_admin_system_languages_list_systemlanguages", "Langues syst�me");
	define("lang_pages_admin_system_languages_list_languagename", "Nom de la langue");
	define("lang_pages_admin_system_languages_list_addsystemlanguage", "Ajouter une langue syst�me");
	define("lang_pages_admin_system_languages_list_list", "Liste");
	define("lang_pages_admin_system_languages_list_create", "Cr�er");
	define("lang_pages_admin_system_languages_list_list", "Liste");
	define("lang_pages_admin_system_languages_list_create", "Cr�er");

	define("lang_pages_admin_system_texts_editor_homepagewelcometext", "Texte de bienvenue, page d'accueil");
	define("lang_pages_admin_system_texts_editor_contactusintrotext", "Texte d'intro, Contactez-nous");
	define("lang_pages_admin_system_texts_editor_orderconfirmationemail", "Courriel de confirmation de commande");
	define("lang_pages_admin_system_texts_editor_privacynoticepage", "Page de notification d'intimit�");
	define("lang_pages_admin_system_texts_editor_conditionofusepage", "Page des conditions d'usage");
	define("lang_pages_admin_system_texts_editor_shippingandreturnpage", "Exp�ditions et retours");
	define("lang_pages_admin_system_texts_editor_text", "Texte");

	define("lang_pages_admin_system_texts_selang_youareabout", "Vous �tes sur le point d'�diter les textes syst�me");
	define("lang_pages_admin_system_texts_selang_pleaseselect", "Veuillez choisir une langue � �diter");

	define("lang_pages_admin_system_general_generalsystemsettings", "Param�tres g�n�raux du syst�me");
	define("lang_pages_admin_system_general_companyname", "Nom de compagnie");
	define("lang_pages_admin_system_general_adminname", "Nom de l'Administrateur");
	define("lang_pages_admin_system_general_adminemail", "Courriel de l'Administrateur");
	define("lang_pages_admin_system_general_systememail", "Courriel syst�me");
	define("lang_pages_admin_system_general_rooturl", "URL racine pour ce site");
	define("lang_pages_admin_system_general_departurezip", "Code postal de d�part des articles");
	define("lang_pages_admin_system_general_taxarithmeticoper", "Op�ration arithm�tique de la taxe");
	define("lang_pages_admin_system_general_catlistorder", "Ordre d'affichage des cat�gories");
	define("lang_pages_admin_system_general_insertorderasc", "Ordre d'insertion, montant");
	define("lang_pages_admin_system_general_insertorderdesc", "Ordre d'insertion, descendant");
	define("lang_pages_admin_system_general_catnameasc", "Nom de cat�gorie, montant");
	define("lang_pages_admin_system_general_catnamedesc", "Nom de cat�gorie, descendant");
	define("lang_pages_admin_system_general_weightunit", "Unit� de poids");
	define("lang_pages_admin_system_general_kilograms", "Kilogrammes");
	define("lang_pages_admin_system_general_pounds", "Livres");
	define("lang_pages_admin_system_general_metrictons", "Tonnes m�triques");
	define("lang_pages_admin_system_general_grams", "Grammes");
	define("lang_pages_admin_system_general_miligrams", "Miligrames");
	define("lang_pages_admin_system_general_tons", "Tonnes");
	define("lang_pages_admin_system_general_ounces", "Onces");
	define("lang_pages_admin_system_general_showprodbo", "Montrer les produits marqu�s comme BO");
	define("lang_pages_admin_system_general_buybo", "Les clients peuvent acheter des articles BO");
	define("lang_pages_admin_system_general_showbo", "Montrer le statut BO");
	define("lang_pages_admin_system_general_showoutofdate", "Montrer les items hors des dates de disponibilit�");
	define("lang_pages_admin_system_general_orderoutofrange", "Permetre l'achat hors des dates de dispo.");
	define("lang_pages_admin_system_general_defaultthemetouse", "Th�me visuel � employer");
	define("lang_pages_admin_system_general_companylogo", "Logo de la compagnie");
	define("lang_pages_admin_system_general_tabsystem", "Syst�me");
	define("lang_pages_admin_system_general_tabcompany", "Compagnie");
	define("lang_pages_admin_system_general_tabstyle", "Style");
	define("lang_pages_admin_system_general_tabproducts", "Produits");
	define("lang_pages_admin_system_general_ratingstyleimage", "Utiliser les images");
	define("lang_pages_admin_system_general_ratingstyletext", "Utiliser le texte");
	define("lang_pages_admin_system_general_ratingstyle", "Mode d'affichage des �valuations");

	define("lang_pages_admin_users_details_customersdetails", "D�tails du client");
	define("lang_pages_admin_users_details_firstname", "Pr�nom");
	define("lang_pages_admin_users_details_lastname", "Nom");
	define("lang_pages_admin_users_details_emailaddress", "Adresse de courriel");
	define("lang_pages_admin_users_details_password", "Mot de passe");
	define("lang_pages_admin_users_details_companyname", "Nom de compagnie");
	define("lang_pages_admin_users_details_address", "Adresse");
	define("lang_pages_admin_users_details_city", "Ville");
	define("lang_pages_admin_users_details_state", "�tat / Province");
	define("lang_pages_admin_users_details_zipcode", "Code postal");
	define("lang_pages_admin_users_details_country", "Pays");
	define("lang_pages_admin_users_details_phonenumber", "Num�ro de t�l�phone");
	define("lang_pages_admin_users_details_faxnumber", "Num�ro de fax");
	define("lang_pages_admin_users_details_isadmin", "Privil�ges d'administrateur");
	define("lang_pages_admin_users_details_backtocustomerslist", "Retour � la liste des clients");
	define("lang_pages_admin_users_details_sendemail", "Envoyer un courriel");

	define("lang_pages_admin_users_list_customersanduserslist", "Liste des clients et des utilisateurs");
	define("lang_pages_admin_users_list_name", "Nom");
	define("lang_pages_admin_users_list_details", "D�tails");

	define("lang_pages_admin_system_updates_systemupdate", "Mise � jour du syst�me");
	define("lang_pages_admin_system_updates_insertcode", "Veuillez ins�rer votre code de mise � jour ci-dessous");

	define("lang_pages_admin_menu_adminmenu", "Menu administratif");
	define("lang_pages_admin_menu_manufacturerprovider", "Fabricants et Fournisseurs");
	define("lang_pages_admin_menu_manufacturerslist", "Liste des fabricants");
	define("lang_pages_admin_menu_addmanufacturer", "Ajouter un fabricant");
	define("lang_pages_admin_menu_providerslist", "Liste des fournisseurs");
	define("lang_pages_admin_menu_categoriesandproducts", "Cat�gories et Produits");
	define("lang_pages_admin_menu_categorieslist", "Liste des cat�gories");
	define("lang_pages_admin_menu_addacategory", "Ajouter une cat�gorie");
	define("lang_pages_admin_menu_productslist", "Liste des produits");
	define("lang_pages_admin_menu_addaproduct", "Ajouter un produit");
	define("lang_pages_admin_menu_systemsettings", "Param�tres syst�me");
	define("lang_pages_admin_menu_generalsystemsettings", "Param�tres g�n�raux du syst�me");
	define("lang_pages_admin_menu_advertisementsmanagement", "Gestion des annonces");
	define("lang_pages_admin_menu_languagesmanagement", "Gestion des langues");
	define("lang_pages_admin_menu_currenciesmanagement", "Gestion des devises");
	define("lang_pages_admin_menu_systemtextseditor", "�diteur de textes syst�me");
	define("lang_pages_admin_menu_paymentblocksconfiguration", "Configuration des blocs de paiement");
	define("lang_pages_admin_menu_shippingconfigurations", "Configurations des exp�ditions");
	define("lang_pages_admin_menu_shopping", "Achats, Commandes et Factures");
	define("lang_pages_admin_menu_invoicesandorders", "Factures et Commandes");
	define("lang_pages_admin_menu_customersandusers", "Clients et Utilisateurs");
	define("lang_pages_admin_menu_stockmanagement", "Gestion des stocks");
	define("lang_pages_admin_menu_updates", "Mise � jour du syst�me");

	define("lang_pages_cart_checkout_youarenowregistered", "Vous �tes maintenant enregistr�s.  Veuillez compl�ter ce formulaire");
	define("lang_pages_cart_checkout_emailaddress", "Adresse de courriel");
	define("lang_pages_cart_checkout_password", "Mot de passe");
	define("lang_pages_cart_checkout_login", "Connexion");
	define("lang_pages_cart_checkout_ifyouprev", "Si vous avez pr�c�demment pass� une commande sur ce syst�me, veuillez vous connecter");
	define("lang_pages_cart_checkout_ifthisisyourfirstorder", "Si il s'agit de votre premi�re commande ici, veuillez compl�ter ce formulaire");
	define("lang_pages_cart_checkout_firstname", "Pr�nom");
	define("lang_pages_cart_checkout_lastname", "Nom");
	define("lang_pages_cart_checkout_email", "Courriel");
	define("lang_pages_cart_checkout_desiredpassword", "Mot de passe d�sir�");
	define("lang_pages_cart_checkout_companyname", "Nom de compagnie");
	define("lang_pages_cart_checkout_address", "Adresse");
	define("lang_pages_cart_checkout_city", "Ville");
	define("lang_pages_cart_checkout_stateprovince", "�tat / Province");
	define("lang_pages_cart_checkout_zip", "Code postal");
	define("lang_pages_cart_checkout_country", "Pays");
	define("lang_pages_cart_checkout_phonenumber", "Num�ro de t�l�phone");
	define("lang_pages_cart_checkout_faxnumber", "Num�ro de fax");
	define("lang_pages_cart_checkout_shippingaddress", "Adresse d'exp�dition");
	define("lang_pages_cart_checkout_name", "Nom");
	define("lang_pages_cart_checkout_order", "Commande");
	define("lang_pages_cart_checkout_item", "Article");
	define("lang_pages_cart_checkout_qty", "Quantit�");
	define("lang_pages_cart_checkout_unitprice", "Prix unitaire");
	define("lang_pages_cart_checkout_total", "Total");
	define("lang_pages_cart_checkout_subtotal", "Total partiel");
	define("lang_pages_cart_checkout_taxes", "Taxes");
	define("lang_pages_cart_checkout_shipping", "Exp�dition");
	define("lang_pages_cart_checkout_paymentmethod", "M�thode de paiement");

	define("lang_pages_cart_confirmorder_orderconfirmation", "Confirmation de la commande");

	define("lang_pages_cart_show_product", "Produit");
	define("lang_pages_cart_show_qty", "Quantit�");
	define("lang_pages_cart_show_unitprice", "Prix unitaire");
	define("lang_pages_cart_show_subtotal", "Total partiel");
	define("lang_pages_cart_show_checkout", "Confirmer");
	define("lang_pages_cart_show_cartempty", "Votre panier est vide");
	define("lang_pages_cart_show_total", "Total");
	define("lang_pages_cart_show_addone", "Additionner une unit�");
	define("lang_pages_cart_show_remone", "Supprimer une unit�");
	define("lang_pages_cart_show_donerem", "Une unit�e retir�e");
	define("lang_pages_cart_show_doneadd", "Une unit�e ajout�e");
	define("lang_pages_cart_show_details", "D�tails");

	define("lang_pages_information_contact_thankyou", "Merci, nous vous contacterons sous peu");
	define("lang_pages_information_contact_name", "Pr�nom / Nom");
	define("lang_pages_information_contact_email", "Courriel");
	define("lang_pages_information_contact_service", "Service");
	define("lang_pages_information_contact_subject", "Sujet");
	define("lang_pages_information_contact_message", "Message");

	define("lang_pages_products_details_addedtoshoppingcart", "Produit ajout� au panier");
	define("lang_pages_products_details_edit", "�diter");
	define("lang_pages_products_details_morepictures", "Plus d'images");
	define("lang_pages_products_details_relatedproducts", "Produits connexes");
	define("lang_pages_products_details_ourrating", "Notre �valuation");
	define("lang_pages_products_details_customersrating", "�valuation des clients");
	define("lang_pages_products_details_rateit", "�valuez-le");
	define("lang_pages_products_details_tellafriend", "Envoyer � un ami");
	define("lang_pages_products_details_special", "Sp�cial");
	define("lang_pages_products_details_addtocart", "Ajouter au panier");
	define("lang_pages_products_details_backorder", "Commande en attente (BO)");
	define("lang_pages_products_details_availablefrom", "Disponible du");
	define("lang_pages_products_details_to", "au");
	define("lang_pages_products_details_availableuntil", "Ce produit sera disponible jusqu'au");
	define("lang_pages_products_details_backtolist", "Retour � la liste des produits");

	define("lang_pages_products_list_addedtoshoppingcart", "Produit ajout� au panier");
	define("lang_pages_products_list_productsin", "Produits dans");
	define("lang_pages_products_list_home", "Accueil");
	define("lang_pages_products_list_buy", "Acheter");
	define("lang_pages_products_list_details", "D�tails");
	define("lang_pages_products_list_backorder", "Commande en attente");
	define("lang_pages_products_list_edit", "�diter");
	define("lang_pages_products_list_youmaywanttolook", "Vous pourriez porter int�r�t � ces sous-cat�gories");

	define("lang_pages_products_listmanuf_addedtoshoppingcart", "Produit ajout� au panier");
	define("lang_pages_products_listmanuf_productsby", "Produits par");
	define("lang_pages_products_listmanuf_buy", "Acheter");
	define("lang_pages_products_listmanuf_details", "D�tails");

	define("lang_pages_products_tellafriend_checkthisurl", "H�!  V�rifiez cette adresse");
	define("lang_pages_products_tellafriend_tellafriend", "Parlez-en � un ami");
	define("lang_pages_products_tellafriend_friendsemail", "Adresse courriel de votre ami");
	define("lang_pages_products_tellafriend_emailsubject", "Sujet du courriel");
	define("lang_pages_products_tellafriend_hey", "H�! V�rifie ceci");

	define("lang_pages_products_search_searchresults", "R�sultats de la recherche pour");
	define("lang_pages_products_search_matches", "produits correspondant � votre requ�te");
	define("lang_pages_products_search_addedtoshoppingcart", "Produit ajout� au panier");

	define("lang_themes_bykeywords", "Par mots-cl�s");
	define("lang_pages_themes_home", "Accueil");
	define("lang_pages_themes_shoppingcart", "Votre panier");
	define("lang_pages_themes_contactus", "Contactez-nous");
	define("lang_pages_themes_admin", "Admin");
	define("lang_pages_themes_yourcart", "Votre panier");
	define("lang_pages_themes_details", "D�tails");
	define("lang_pages_themes_items", "articles");
	define("lang_pages_themes_total", "total");
	define("lang_pages_themes_language", "Langue");
	define("lang_pages_themes_currency", "Devise");
	define("lang_pages_themes_usersonline", "Utilisateurs en ligne");
	define("lang_pages_themes_products", "produits");
	define("lang_pages_themes_uptime", "En ligne depuis");
	define("lang_pages_themes_days", "jours");

	define("lang_pages_themes_home_welcome", "BIENVENUE");
	define("lang_pages_themes_home_featured", "PRODUIT VEDETTE");
	define("lang_pages_themes_home_details", "D�tails");
	define("lang_pages_themes_home_newproducts", "NOUVEAUX PRODUITS");
	define("lang_pages_themes_home_email", "Courriel");
	define("lang_pages_themes_home_password", "Mot de passe");
	define("lang_pages_themes_home_loggedin", "Connect�");
	define("lang_pages_themes_home_logout", "D�connexion");

	define("lang_pages_themes_blocks_browsemanufacturers_browsebyman", "Liste par fabricants");
	define("lang_pages_themes_blocks_browsemanufacturers_select", "-- S�lectionnez --");

	define("lang_pages_themes_blocks_cataloguecats_cataloguecategories", "Cat�gories des produits");

	define("lang_pages_themes_blocks_categoriesdrop_bycategory", "Par cat�gorie");
	define("lang_pages_themes_blocks_categoriesdrop_select", "-- S�lectionnez --");

	define("lang_pages_themes_blocks_informations_informations", "Informations");
	define("lang_pages_themes_blocks_informations_contactus", "Contactez-nous");
	define("lang_pages_themes_blocks_informations_privacynotice", "Note sur l'intimit�");
	define("lang_pages_themes_blocks_informations_conditionsofuse", "Conditions d'utilisation");
	define("lang_pages_themes_blocks_informations_shippingandreturns", "Exp�ditions et Retours");
	
	//////////////////////////////////////////////////////////////////////////////////////////
	// NEW LANGUAGES FIELDS ADDED AFTER V0921B
	//////////////////////////////////////////////////////////////////////////////////////////

	define("lang_pages_admin_shopping_details_notesforthisinvoice", "Notes pour cette facture");

	define("lang_pages_admin_products_edit_noreviews", "Aucune �valuation pour ce produit");
	define("lang_pages_admin_products_edit_productsreviews", "�valuations du produit");
	
	define("lang_pages_admin_system_general_enablereviews", "Activer le syst�me d'�valuation des produits");
	
	define("lang_pages_products_details_reviews", "�valuations");
	define("lang_pages_products_details_readreviews", "Lire les �valuations");
	define("lang_pages_products_details_writereview", "�valuer");
	
	define("lang_pages_reviews_read_reviewsfor", "�valuations pour");
	define("lang_pages_reviews_read_user", "Utilisateur");
	define("lang_pages_reviews_read_reviewproduct", "�valuez ce produit");
	
	define("lang_pages_reviews_write_thankyou", "Merci");
	define("lang_pages_reviews_write_writefor", "�valuation de");
	define("lang_pages_reviews_write_nickname", "Votre surnom");
	define("lang_pages_reviews_write_yourreview", "Votre �valuation");

	define("lang_pages_admin_mailing_mailing_sending", "Envoie des courriels en cours... Veuillez patienter");
	define("lang_pages_admin_mailing_mailing_errorsendingto", "Erreure lors de l'envoi �");
	define("lang_pages_admin_mailing_mailing_skipping", "Saut�");
	define("lang_pages_admin_mailing_mailing_mailsentto", "Courriel envoy� �");
	define("lang_pages_admin_mailing_mailing_finished", "Termin�");
	define("lang_pages_admin_mailing_mailing_sent", "Envoy�s");
	define("lang_pages_admin_mailing_mailing_skip", "Saut�s");
	define("lang_pages_admin_mailing_mailing_mailinglist", "Gestion de liste d'envois");
	define("lang_pages_admin_mailing_mailing_from", "De");
	define("lang_pages_admin_mailing_mailing_to", "A");
	define("lang_pages_admin_mailing_mailing_subject", "Suject");
	define("lang_pages_admin_mailing_mailing_message", "Message");
	define("lang_pages_admin_mailing_mailing_everymember", "Tous les membres enregistr�s");
	
	define("lang_pages_admin_stats_access_accessstatsfor", "Access statistics for");
	
	define("lang_pages_admin_stats_sales_salesstatsfor", "Statistiques de ventes pour");
	define("lang_pages_admin_stats_sales_soldunitsfor", "Unit�s vendues (tous les produits) pour");
	define("lang_pages_admin_stats_sales_soldunits", "Unit�s vendues");
	define("lang_pages_admin_stats_sales_salesstatsfor", "Statistiques de ventes (tous les produits) pour");
	define("lang_pages_admin_stats_sales_salesstats", "Statistiques de ventes");

	define("lang_pages_admin_system_general_usesmiles", "Permettre les �moticons dans les �valuations");
	define("lang_pages_admin_system_general_cookieprefix", "Pr�fixe du cookie");
	
	define("lang_theme_lostpass", "Mot de passe perdu");
	define("lang_theme_register", "Devenez membre");
		
	define("lang_pages_lostpass_error", "Erreur: L'adresse courriel que vous avez fournis ne peut �tre rep�r�e dans notre base de donn�es");
	define("lang_pages_lostpass_yourpassword", "votre mot de passe");
	define("lang_pages_lostpass_yourpasson", "Votre mot de passe sur");
	define("lang_pages_lostpass_is", "est");
	define("lang_pages_lostpass_passsent", "Votre mot de passe a �t� envoy� � cette adresse:");
	define("lang_pages_lostpass_lostpass", "Mot de passer perdu");
	define("lang_pages_lostpass_toptext", "Veuillez compl�ter le formulaire suivant. Votre mot de passe vous sera envoy� par courriel.");
	define("lang_pages_lostpass_email", "Adresse courriel");

	define("lang_pages_admin_system_texts_editor_registrationtext", "Texte d'introduction affich� sur la page d'enregistrement"); 
	
	define("lang_pages_register_register_registration", "Enregistrement");
	
	define("lang_pages_register_register_firstname", "Pr�nom");
	define("lang_pages_register_register_lastname", "Nom");
	define("lang_pages_register_register_email", "Adresse courriel");
	define("lang_pages_register_register_desiredpassword", "Mot de passe d�sir�");
	define("lang_pages_register_register_companyname", "Nom de compagnie");
	define("lang_pages_register_register_address", "Adresse");
	define("lang_pages_register_register_city", "Ville");
	define("lang_pages_register_register_stateprovince", "�tat / Province");
	define("lang_pages_register_register_zip", "Zip / Code postal");
	define("lang_pages_register_register_country", "Pays");
	define("lang_pages_register_register_phonenumber", "Num�ro de t�l�phone");
	define("lang_pages_register_register_faxnumber", "Num�ro de t�l�copieur");
	define("lang_pages_register_register_registered", "Merci. Vous �tes maintenant enregistr�.");
	
	define("lang_pages_admin_system_general_showcount", "Afficher le total � cot� des cat�gories");
	define("lang_pages_admin_system_general_linktofolder", "Appliquer le lien � l'image du dossier");
	define("lang_pages_admin_system_general_highlightselected", "Surligner les items dans l'arbre");
	define("lang_pages_admin_system_general_showlines", "Afficher les lignes de connection dans l'arbre");
	define("lang_pages_admin_system_general_useicons", "Afficher les icones dans l'arbre");
	define("lang_pages_admin_system_general_displaydesc", "Afficher la description des cat�gories dans la barre de status");
	define("lang_pages_admin_system_general_closesame", "Fermer les niveaux �gaux dans l'arbre");
	define("lang_pages_admin_system_general_expandall", "D�velopper toutes les cat�gories");
	
	define("lang_pages_admin_categories_list_sortorder", "Ordre");
	
	define("lang_pages_admin_system_general_sortorder", "Num�ro d'ordre");

	
