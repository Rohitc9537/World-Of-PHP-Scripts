<?
	// FIELDS CORRESPONDANCES //
	$field[0] = "Pay to (name)";
	$field[8] = "Send check to (name)";
	$field[1] = "Send check to (address line 1)";
	$field[2] = "Send check to (address line 2)";
	$field[3] = "Send check to (city)";
	$field[4] = "Send check to (state)";
	$field[5] = "Send check to (zip / postal code)";
	$field[6] = "Send check to (country)";
	$field[7] = "Special instructions";
	
	// END OF FIELDS CORRESPONDANCES //

	if (!function_exists(gatestart)) {
		function gatestart($id, $total, $ship, $transactionid) {
			$bk = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_paymentbk` WHERE `blockname`='Cheque'"));
			echo "<CENTER><B>Thank you.</B><BR><BR>Please make your check to the attention of {$bk["field_0"]} and mail to:<BR><BR>
			<table align=center cellspacing=0 cellpadding=0>
			<tr><td><B>{$bk["field_8"]}</td></tr>
			<tr><td><B>{$bk["field_1"]}</td></tr>
			<tr><td><B>{$bk["field_2"]}</td></tr>
			<tr><td><B>{$bk["field_3"]}, {$bk["field_4"]}</td></tr>
			<tr><td><B>{$bk["field_5"]}</td></tr>
			<tr><td><B>{$bk["field_6"]}</td></tr>
			</table><BR>
		   Don't forget to write your transaction id ({$transactionid})<BR>in the 'notes' field of your check.<BR>
		   <BR><BR>";
		   echo $bk["field_7"];
		}
	}
?>