<?
	// FIELDS CORRESPONDANCES //
	$field[0] = "'Details' text to display";
	// END OF FIELDS CORRESPONDANCES //

	if (!function_exists(gatestart)) {
		function gatestart($id, $total, $ship, $transactionid) {
			$bk = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_paymentbk` WHERE `blockname`='COD'"));
			echo "<CENTER><B>Thank you.</B><BR><BR>Your order (with transaction id {$transactionid})<BR>Has been recorded.<BR><BR>";
			echo $bk["field_0"];
		}
	}
?>