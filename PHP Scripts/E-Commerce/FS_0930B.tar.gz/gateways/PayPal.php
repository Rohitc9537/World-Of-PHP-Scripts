<?php
	// FIELDS CORRESPONDANCES //
	$field[0] = "PayPal account";
	$field[1] = "Currency code";
	// END OF FIELDS CORRESPONDANCES //

	if (!function_exists(gatestart)) {
		function gatestart($id, $total, $ship, $transactionid) {
	
			$row = mysql_fetch_array(mysql_query("SELECT * FROM `cart_invoices` WHERE `id`='{$id}'"));
			$cst = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_users` WHERE `id`='{$row["user"]}'"));
			$bk = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_paymentbk` WHERE `blockname`='PayPal'"));
		
			echo "<CENTER>Thank you. Please click the button below to proceed to payment.<BR><BR>";
			echo "<FORM ACTION=\"https://www.paypal.com/cgi-bin/webscr\" METHOD=\"POST\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"cmd\" VALUE=\"_ext-enter\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"redirect_cmd\" VALUE=\"_xclick\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"business\" VALUE=\"{$bk["field_0"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"undefined_quantity\" VALUE=\"0\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"item_name\" VALUE=\"Invoice #{$transactionid}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"item_number\" VALUE=\"#{$transactionid}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"amount\" VALUE=\"{$row["total"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"shipping\" VALUE=\"{$ship}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"currency_code\" VALUE=\"{$bk["field_1"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"first_name\" VALUE=\"{$cst["fname"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"last_name\" VALUE=\"{$cst["lname"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"address1\" VALUE=\"{$cst["address"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"city\" VALUE=\"{$cst["city"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"state\" VALUE=\"{$cst["state"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"zip\" VALUE=\"{$cst["zip"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"lc\" VALUE=\"{$cst["country"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"email\" VALUE=\"{$cst["email"]}\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"night_phone_a\" VALUE=\"".substr($row["phone"], 0,2)."\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"night_phone_b\" VALUE=\"".substr($row["phone"], 3,5)."\">";
			echo "<INPUT TYPE=\"hidden\" NAME=\"night_phone_c\" VALUE=\"".substr($row["phone"], 6,20)."\">";
			echo "<INPUT TYPE=\"image\" SRC=\"http://www.paypal.com/en_US/i/btn/x-click-but01.gif\" BORDER=\"0\" NAME=\"submit\" ALT=\"Make payment\">";
			echo "</FORM>";
		
		}
	}
?>