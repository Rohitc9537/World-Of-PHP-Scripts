<?
	// FIELDS CORRESPONDANCES //
	$field[0] = "Transfer to account";
	$field[1] = "Special instructions";
	$field[2] = "Bank name";
	
	// END OF FIELDS CORRESPONDANCES //

	if (!function_exists(gatestart)) {
		function gatestart($id, $total, $ship, $transactionid) {
			$bk = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_paymentbk` WHERE `blockname`='Bank transfer'"));
			echo "<CENTER><B>Thank you.</B><BR><BR>Please transfer {$total} to<BR> the following bank account: {$bk["field_2"]}, {$bk["field_0"]}<BR><BR>
		   Don't forget to refer to your transaction id ({$transactionid})<BR>when transfering.<BR>
		   <BR><BR>";
		   echo $bk["field_1"];
		}
	}
?>