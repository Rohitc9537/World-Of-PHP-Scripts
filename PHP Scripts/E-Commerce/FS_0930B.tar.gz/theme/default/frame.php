<html>
<head>
<title><? echo gen(company_name); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<? echo charset(); ?>">
<link href="theme/default/images/interface.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<script language="javascript" src="includes/javascript/cal.js"></script>
<script language="javascript" src="includes/javascript/cal_conf.js"></script>
<br>
<table width="780" height="174" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top">
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="49%"><img src="files/local/<? echo gen(logo); ?>" height="68" alt=""></td>
          <td width="51%" align="center" valign="bottom"><div class="whitelink">| <a class="whitelink" href="?">##lang_pages_themes_home##</a> | <a class="whitelink" href="?L=cart.show">##lang_pages_themes_shoppingcart##</a> | <a class="whitelink" href="?L=information.contact">##lang_pages_themes_contactus##</a> | <? if (admin()) { echo "<a class=\"whitelink\" href=?L=admin.menu>##lang_pages_themes_admin##</a>"; } ?>
		  </div>
		  </td>
        </tr>
      </table>      
      <br>      
      <table width="100%" height="97"  border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="26" rowspan="2" valign="top" background="theme/default/images/shoop_23.gif"><table width="26" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="50%" valign="top"><img src="theme/default/images/shoop_07.gif" width="26" height="18" alt=""></td>
              </tr>
              <tr>
                <td height="50%" valign="bottom"><img src="theme/default/images/shoop_17.gif" width="26" height="15" alt=""></td>
              </tr>
          </table>          <p>&nbsp;          </p></td>
        <td height="3" bgcolor="#FFFFFF">&nbsp;</td>
        <td height="3" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="235" height="1"></td>
        <td height="3" bgcolor="#FFFFFF">&nbsp;</td>
        <td height="3" bgcolor="#FFFFFF">&nbsp;</td>
        <td height="3" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF">&nbsp;</td>
        <td width="235" height="143" background="theme/default/images/shoop_11.gif" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="13%" height="54">&nbsp;</td>
              <td width="87%">&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td><TD>
              <? TH_categories_drop(); ?>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <form method=post action=?L=search.search>
                <td>##lang_themes_bykeywords##<br>                
                  <input name="query" type="text" id="query"></td></form>
            </tr>
          </table>          <br>          </td>
        <td width="3" bgcolor="#FFFFFF">&nbsp;</td>
        <td bgcolor="#FFFFFF">          <img src="theme/default/images/shoop_13.gif" width="509" height="143" alt=""></td>
        <td bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td width="26" background="theme/default/images/shoop_23.gif"><table width="26" height="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="50%" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="50%" valign="bottom"><img src="theme/default/images/shoop_17.gif" width="26" height="15" alt=""></td>
          </tr>
        </table></td>
        <td bgcolor="#FFFFFF">&nbsp;</td>
        <td valign="top" bgcolor="#FFFFFF"><p><br>
		<? TH_catalogue_cats(); ?>
		<BR><BR>
		<? TH_manufacturers_browsing(); ?>
		<BR><BR>
		<? TH_infos(); ?>
          <br>
          <br>
          <br>
          <br>
              <p>&nbsp;</p></td>
        <td width="3" bgcolor="#FFFFFF">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><br>          <? Jump(); ?></td>
        <td bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td width="26" valign="bottom" background="theme/default/images/shoop_23.gif"><img src="theme/default/images/shoop_24.gif" width="26" height="10" alt=""></td>
        <td bgcolor="#FFFFFF">&nbsp;</td>
        <td colspan="3" align="right" valign="bottom" bgcolor="#FFFFFF"> <table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr bgcolor="#9B9EA7">
            <td width="4">&nbsp;</td>
            <td width="282" valign="middle"><? include("theme/default/blocks/shoppingcart.php"); ?></td>
            <td width="219">              
			<table width="108" border="0" cellpadding="0" cellspacing="0">
                
				
                  <? 
				  $defaultlang = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_sessioninfo` WHERE `session`='{$_COOKIE[gen(cookie_prefix)."fishsession"]}'")); $current = $defaultlang["language"]; 
				  if ($current == "") { $defaultlang = mysql_fetch_array(mysql_query("SELECT * FROM `sys_languages` WHERE `default`='1'")); $current = $defaultlang["id"]; }
				  $selection = mysql_query("SELECT * FROM `sys_languages`");
				  if (mysql_num_rows($selection) > 1) {
					  echo "<tr><form method=post><td>##lang_pages_themes_language##:</td><td>";
					  echo "<input type=hidden name=setlanguage value=true>";
					  echo "<select name=\"language\" onchange=\"submit();\">";
					  while ($lang = mysql_fetch_array($selection)) {
						echo "<option value=\"{$lang["id"]}\" "; if ($current == $lang["id"]) { echo "SELECTED"; } echo ">{$lang["name"]}</option>";
					  }
				  echo "</select></td></tr>";
				  }
				  ?>

				<?
                $ss = mysql_query("SELECT * FROM `dyn_currencies`");
				if (mysql_num_rows($ss) > 1) { 
					echo "<tr><form method=post><td>##lang_pages_themes_currency##: </td>";
					echo "<td><select name=\"swapcurrency\" onchange=\"submit();\">";
					$mycur = mysql_fetch_array(mysql_query("SELECT * FROM `dyn_sessioninfo` WHERE `session`='{$_COOKIE[gen(cookie_prefix)."fishsession"]}'"));
					while ($cur = mysql_fetch_array($ss)) { 
						echo "<option value=\"{$cur["id"]}\" "; if ($mycur["currency"] == $cur["id"]) { echo "SELECTED"; } echo ">{$cur["name"]}</option>";
					}
					echo "</select></td></form></tr>";
				}
				?>
            </table></td>
            <td width="219"><? echo date("F jS Y"); ?><br>
              <? echo mysql_num_rows(mysql_query("SELECT * FROM `cart_products`")); ?> ##lang_pages_themes_products##<br>
              </td>
            <td width="24" align="right"><img src="theme/default/images/shoop_20.gif" width="20" height="50" alt=""></td>
          </tr>
        </table>
          <img src="theme/default/images/shoop_25.gif" width="20" height="8" alt=""></td>
        <td align="right" valign="bottom" bgcolor="#FFFFFF"><img src="theme/default/images/shoop_21.gif" width="7" height="58" alt=""></td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="785" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
<BR>
<script language="JavaScript" type="text/javascript" src="includes/javascript/alttxt.js"></script>