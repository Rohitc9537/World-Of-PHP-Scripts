<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {font-size: 12}
.loginbox {
	border: 1px solid #58759F;
	padding: 0px;
	margin: 0px;
}
-->
</style>
<table width="100%" height="409"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="70%" align="left" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="6"><img src="theme/default/images/head_l.gif" width="6" height="25"></td>
            <td bgcolor="#424955"><span class="style1">##lang_pages_themes_home_welcome##</span></td>
            <td width="6"><img src="theme/default/images/head_r.gif" width="6" height="25"></td>
          </tr>
        </table>          
          <? echo t("001"); ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="6"><img src="theme/default/images/head_l.gif" width="6" height="25"></td>
            <td bgcolor="#424955"><span class="style1">##lang_pages_themes_home_featured##</span></td>
            <td width="6"><img src="theme/default/images/head_r.gif" width="6" height="25"></td>
          </tr>
        </table>
		<? include("theme/default/blocks/home_featured.php"); ?>
		  
          <p>&nbsp;</p></td>
      </tr>
      <tr>
        <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="6"><img src="theme/default/images/head_l.gif" width="6" height="25"></td>
            <td bgcolor="#424955"><span class="style1">##lang_pages_themes_home_newproducts##</span></td>
            <td width="6"><img src="theme/default/images/head_r.gif" width="6" height="25"></td>
          </tr>
        </table> 
          <? include("theme/default/blocks/home_newproducts.php"); ?>          </td>
      </tr>
    </table></td>
    <td width="5" align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="173" height="97" border="0" cellpadding="0" cellspacing="0" class="loginbox">
          <tr>
            <td valign="top" bgcolor="#D7DEE4" style="padding: 3px;">
			
			
			<? if(!isset($_COOKIE[gen(cookie_prefix)."fishuser"])) { ?>
			<img src="theme/default/images/cstlogin.gif" width="112" height="29" hspace="2" vspace="2"><br>
              <table width="100%"  border="0" cellspacing="0" cellpadding="0"><form method=post><input type=hidden name=userlogin value=true>
                <tr>
                  <td colspan="2">##lang_pages_themes_home_email##</td>
                </tr>
                <tr>
                  <td colspan="2"><input name="email" type="text" size="15"></td>
                </tr>
                <tr>
                  <td colspan="2">##lang_pages_themes_home_password##</td>
                </tr>
                <tr>
                  <td width=10%><input name="password" type="password" size="15"></td>
                  <td>&nbsp;<input type=image src="theme/default/images/okbtn.gif" border=0 width="20" height="13"></td>
                </tr>
				<tr>
				  <td colspan=2><a href=?L=register.lostpass>##lang_theme_lostpass##</a> | <a href=?L=register.register>##lang_theme_register##</a></td>
				</tr>
                <tr>
                  <td colspan="2">&nbsp;</td>
                </tr>
              </form></table>
			  <? } else { echo "<CENTER>##lang_pages_themes_home_loggedin##<BR><BR><img src=theme/default/images/logged.png>
			  						<BR><a href=?logout=true>##lang_pages_themes_home_logout##</a></CENTER>"; } ?>
			  
			  
			  
			  
			  
			  
			  </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><? 
		$selection = mysql_query("SELECT * FROM `sys_advertisements` ORDER BY RAND() LIMIT 2");
		$i=0;
		while ($row = mysql_fetch_array($selection)) {
			$ad[$i] = "<a href=\"{$row["url"]}\"><img src=files/advertisements/{$row["picture"]} vspace=3 border=0></a>";
			$i++;
		}
		
		echo $ad[0];
		echo "<BR>";
		echo $ad[1];
		?>
		
		
		</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
