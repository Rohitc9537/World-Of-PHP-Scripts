<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><strong>##lang_pages_themes_blocks_informations_informations##:</strong></td>
  </tr>
  <tr>
    <td width="12%">&nbsp;</td>
    <td width="88%"><a href="?L=information.contact">##lang_pages_themes_blocks_informations_contactus##</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="?L=information.privacy">##lang_pages_themes_blocks_informations_privacynotice##</a> </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="?L=information.conditions">##lang_pages_themes_blocks_informations_conditionsofuse##</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="?L=information.ship">##lang_pages_themes_blocks_informations_shippingandreturns##</a></td>
  </tr>
</table>

