<? 				echo "<table><form method=get><tr><td>##lang_pages_themes_blocks_categoriesdrop_bycategory##</TD></TR>";
				echo "<TR><TD><input type=hidden name=L value=products.list>";
				echo "<select name=cat onchange=\"submit();\">";
				echo "<option value=0>##lang_pages_themes_blocks_categoriesdrop_select##</option>";
				$selection = mysql_query("SELECT * FROM `cart_categories`");
				while ($row = mysql_fetch_array($selection)) {
				
					echo "<option value=\"{$row["id"]}\">{$row["name"]}</option>";
				}
				echo "</select></TD></TR>";
				echo "</td></form></table>";
?>