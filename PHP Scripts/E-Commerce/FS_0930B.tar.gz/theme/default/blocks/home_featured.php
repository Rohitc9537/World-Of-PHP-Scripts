          <?
		  $row = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products` WHERE `featured`='1' ORDER BY RAND() LIMIT 1"));
		  $name = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products_names` WHERE `product`='{$row["id"]}' AND `language`='".defaultlang()."'"));
		  $img = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products_pictures` WHERE `product`='{$row["id"]}' ORDER BY RAND() LIMIT 1"));
		  $desc = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products_descriptions` WHERE `product`='{$row["id"]}' AND `language`='".defaultlang()."'"));
		  echo "<TABLE WIDTH=100%><TR height=10><TD ROWSPAN=2 width=100><a href=?L=products.details&id={$row["id"]}><IMG SRC=\"files/products/{$img["picture"]}\" width=100 border=0></a></TD>";
		  echo "<TD bgcolor=#F5F5F5><B>{$name["name"]} {$row["model"]}<B></TD></TR><TR><TD valign=top>".substr($desc["description"], 0,150)."</TD></TR>";
		  echo "<TR><TD><a href=?L=products.details&id={$row["id"]}>##lang_pages_themes_home_details##</a></TD><TD>";
		  if ($row["special"] != "") { echo "<S><B>".fp($row["sell_price"])."</S> <font color=red>".fp($row["special"])."</font></b>"; }
		  else { echo "<b>".fp($row["sell_price"])."</b></TD></TR>"; }
		  echo "</TABLE>";

		  
		  ?>