<?
		  $selection = mysql_query("SELECT * FROM `cart_products` ORDER BY RAND() LIMIT 4");
		  echo "<TABLE WIDTH=100%><TR>";
		  while ($row = mysql_fetch_array($selection)) {
		  	$name = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products_names` WHERE `product`='{$row["id"]}' and `language`='".defaultlang()."'"));
			$picture = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products_pictures` WHERE `product`='{$row["id"]}' ORDER BY RAND() LIMIT 1"));
			
			echo "<TD valign=top align=center><a href=?L=products.details&id={$row["id"]}><span class=microtext>".substr($name["name"], 0,20)."</span></a><BR><a href=?L=products.details&id={$row["id"]}><img src=\"files/products/{$picture["picture"]}\" width=50 border=0></a></TD>";
			
		  }
		  echo "</TR></TABLE>";
		  ?>