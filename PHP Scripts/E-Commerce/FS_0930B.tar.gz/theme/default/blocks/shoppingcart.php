<table width="239" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="41" rowspan="2"><img src="theme/default/images/book.gif" width="32" height="32"></td>
                <td width="198"><strong>##lang_pages_themes_yourcart##</strong> | <a href=?L=cart.show>##lang_pages_themes_details##</a></td>
              </tr>
              <tr>
                <td><? $selection = mysql_query("SELECT * FROM `dyn_carts` WHERE `client` = '{$_COOKIE[gen(cookie_prefix)."fishsession"]}'");
				echo mysql_num_rows($selection); ?>
				 ##lang_pages_themes_items## - 
				 <? 
				 $total = 0;
				 while ($row = mysql_fetch_array($selection)) {
				 	$item = mysql_fetch_array(mysql_query("SELECT * FROM `cart_products` WHERE `id`='{$row["product"]}'"));
				 	if ($item["special"] != "") { $total = $total + $item["special"]; } else { $total = $total + $item["sell_price"]; }
				 }
				 echo fp($total);
				 ?> ##lang_pages_themes_total## </td>
              </tr>
            </table>