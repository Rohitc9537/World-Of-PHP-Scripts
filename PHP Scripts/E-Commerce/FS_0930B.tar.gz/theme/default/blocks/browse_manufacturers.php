<table><form method=get><input type=hidden name=L value=products.listmanuf>
<TR><TD><strong>##lang_pages_themes_blocks_browsemanufacturers_browsebyman##:</strong></TD></TR>
<TR><TD><select name=id onchange=submit();>
<option>##lang_pages_themes_blocks_browsemanufacturers_select##</option>
<? 
$selection = mysql_query("SELECT * FROM `cart_manufacturers`");
while ($row = mysql_fetch_array($selection)) {
	echo "<option value={$row["id"]}>{$row["name"]}</option>";
}
?>
</select></td></tr></form></table>
