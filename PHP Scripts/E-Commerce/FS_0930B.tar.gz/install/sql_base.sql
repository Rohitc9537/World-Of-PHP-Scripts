CREATE TABLE `cart_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `parent` varchar(100) NOT NULL default '',
  `description` longtext NOT NULL,
  `sortorder` varchar(100) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_invoices` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL default '',
  `transactionid` varchar(100) NOT NULL default '',
  `shippingmethod` varchar(100) NOT NULL default '',
  `shippingcost` varchar(100) NOT NULL default '',
  `paymentmethod` varchar(100) NOT NULL default '',
  `status` varchar(100) NOT NULL default '',
  `date` varchar(100) NOT NULL default '',
  `notes` longtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_invoices_products` (
  `id` int(11) NOT NULL auto_increment,
  `invoiceid` varchar(100) NOT NULL default '',
  `productid` varchar(100) NOT NULL default '',
  `paid` varchar(100) NOT NULL default '',
  `cost` varchar(100) NOT NULL default '',
  `date` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_manufacturers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `picture` varchar(100) NOT NULL default '',
  `creation_date` varchar(100) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_products` (
  `id` int(11) NOT NULL auto_increment,
  `category` varchar(100) NOT NULL default '',
  `model` varchar(100) NOT NULL default '',
  `manufacturer` varchar(100) NOT NULL default '',
  `provider` varchar(100) NOT NULL default '',
  `tax_class` varchar(100) NOT NULL default '',
  `sell_price` varchar(100) NOT NULL default '',
  `cost_price` varchar(100) NOT NULL default '',
  `stock_qty` varchar(100) NOT NULL default '',
  `reorder_qty` varchar(100) NOT NULL default '',
  `weight` varchar(100) NOT NULL default '',
  `special` varchar(100) NOT NULL default '',
  `featured` varchar(100) NOT NULL default '',
  `rating` varchar(100) NOT NULL default '',
  `bo` varchar(100) NOT NULL default '',
  `innerdate` varchar(100) NOT NULL default '',
  `outerdate` varchar(100) NOT NULL default '',
  `visible` varchar(100) NOT NULL default '1',
  `intref` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_products_descriptions` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(100) NOT NULL default '',
  `language` varchar(100) NOT NULL default '',
  `description` longtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_products_names` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(100) NOT NULL default '',
  `language` varchar(100) NOT NULL default '',
  `name` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_products_pictures` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(100) NOT NULL default '',
  `picture` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_products_url` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(100) NOT NULL default '',
  `language` varchar(100) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_providers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_related` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(100) NOT NULL default '',
  `related` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_resellers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `cart_reviews` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL default '',
  `ip` varchar(100) NOT NULL default '',
  `udate` varchar(100) NOT NULL default '',
  `product` varchar(100) NOT NULL default '',
  `text` longtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_accesslog` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(100) NOT NULL default '',
  `page` varchar(100) NOT NULL default '',
  `udate` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_carts` (
  `id` int(11) NOT NULL auto_increment,
  `client` varchar(100) NOT NULL default '',
  `product` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_currencies` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `code` varchar(100) NOT NULL default '',
  `default` varchar(100) NOT NULL default '',
  `value` varchar(100) NOT NULL default '',
  `symbol` varchar(100) NOT NULL default '',
  `placement` varchar(100) NOT NULL default '',
  `decimal` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_paymentbk` (
  `id` int(11) NOT NULL auto_increment,
  `blockname` varchar(100) NOT NULL default '',
  `field_0` varchar(250) NOT NULL default '',
  `field_1` varchar(250) NOT NULL default '',
  `field_2` varchar(250) NOT NULL default '',
  `field_3` varchar(250) NOT NULL default '',
  `field_4` varchar(250) NOT NULL default '',
  `field_5` varchar(250) NOT NULL default '',
  `field_6` varchar(250) NOT NULL default '',
  `field_7` varchar(250) NOT NULL default '',
  `field_8` varchar(250) NOT NULL default '',
  `field_9` varchar(250) NOT NULL default '',
  `field_10` varchar(250) NOT NULL default '',
  `field_11` varchar(250) NOT NULL default '',
  `field_12` varchar(250) NOT NULL default '',
  `field_13` varchar(250) NOT NULL default '',
  `field_14` varchar(250) NOT NULL default '',
  `field_15` varchar(250) NOT NULL default '',
  `field_16` varchar(250) NOT NULL default '',
  `field_17` varchar(250) NOT NULL default '',
  `field_18` varchar(250) NOT NULL default '',
  `field_19` varchar(250) NOT NULL default '',
  `field_20` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_ratings` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL default '',
  `product` varchar(100) NOT NULL default '',
  `vote` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_reviews` (
  `id` int(11) NOT NULL auto_increment,
  `nickname` varchar(100) NOT NULL default '',
  `product` varchar(100) NOT NULL default '',
  `review` longtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_sessioninfo` (
  `id` int(11) NOT NULL auto_increment,
  `session` varchar(100) NOT NULL default '',
  `language` varchar(100) NOT NULL default '',
  `currency` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_shipping` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `desc` varchar(250) NOT NULL default '',
  `calc` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
CREATE TABLE `dyn_users` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(100) NOT NULL default '',
  `lname` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `company` varchar(100) NOT NULL default '',
  `address` varchar(100) NOT NULL default '',
  `city` varchar(100) NOT NULL default '',
  `state` varchar(100) NOT NULL default '',
  `zip` varchar(100) NOT NULL default '',
  `country` varchar(100) NOT NULL default '',
  `phone` varchar(100) NOT NULL default '',
  `fax` varchar(100) NOT NULL default '',
  `is_admin` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
INSERT INTO `dyn_users` (`id`, `fname`, `lname`, `email`, `password`, `company`, `address`, `city`, `state`, `zip`, `country`, `phone`, `fax`, `is_admin`) VALUES (1, 'Administrator', '', 'admin', 'admin', '', '', '', '', '', '', '', '', '1');
CREATE TABLE `sys_advertisements` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `picture` varchar(250) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
INSERT INTO `sys_advertisements` (`id`, `name`, `picture`, `url`) VALUES (1, 'laptops', 'b9c2e7721259a85057cb3159ef91ff17AD_Z2.gif', 'http://');
INSERT INTO `sys_advertisements` (`id`, `name`, `picture`, `url`) VALUES (2, 'cameras', '25b6d085929b7cfe4950adb861774bfaAD_Z1.gif', 'http://');
CREATE TABLE `sys_languages` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `dictionary` varchar(100) NOT NULL default '',
  `default` varchar(100) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
INSERT INTO `sys_languages` (`id`, `name`, `dictionary`, `default`) VALUES (1, 'English', 'English', '1');
CREATE TABLE `sys_settings` (
  `company_name` varchar(250) NOT NULL default '',
  `admin_name` varchar(250) NOT NULL default '',
  `admin_email` varchar(250) NOT NULL default '',
  `system_email` varchar(250) NOT NULL default '',
  `url_to_root` varchar(250) NOT NULL default '',
  `zipcode` varchar(100) NOT NULL default '',
  `tax` varchar(100) NOT NULL default '',
  `tree_list_order` varchar(100) NOT NULL default '',
  `update` varchar(100) NOT NULL default '',
  `bo_visible` varchar(100) NOT NULL default '',
  `show_bo` varchar(100) NOT NULL default '',
  `show_inner` varchar(100) NOT NULL default '',
  `buy_inner` varchar(100) NOT NULL default '',
  `buy_bo` varchar(100) NOT NULL default '',
  `weight_unit` varchar(100) NOT NULL default '',
  `theme` varchar(100) NOT NULL default '',
  `logo` varchar(100) NOT NULL default '',
  `show_count` varchar(100) NOT NULL default '',
  `rating_style` varchar(100) NOT NULL default '',
  `enable_reviews` varchar(100) NOT NULL default '',
  `review_use_smiles` varchar(100) NOT NULL default '',
  `cookie_prefix` varchar(100) NOT NULL default '',
  `tree_folderlinks` varchar(100) NOT NULL default '',
  `tree_useselection` varchar(100) NOT NULL default '',
  `tree_uselines` varchar(100) NOT NULL default '',
  `tree_useicons` varchar(100) NOT NULL default '',
  `tree_usestatustext` varchar(100) NOT NULL default '',
  `tree_closesamelevel` varchar(100) NOT NULL default '',
  `tree_expanded` varchar(100) NOT NULL default ''
) TYPE=MyISAM;
INSERT INTO `sys_settings` (`company_name`, `admin_name`, `admin_email`, `system_email`, `url_to_root`, `zipcode`, `tax`, `tree_list_order`, `update`, `bo_visible`, `show_bo`, `show_inner`, `buy_inner`, `buy_bo`, `weight_unit`, `theme`, `logo`, `show_count`, `rating_style`, `enable_reviews`, `review_use_smiles`, `cookie_prefix`, `tree_folderlinks`, `tree_useselection`, `tree_uselines`, `tree_useicons`, `tree_usestatustext`, `tree_closesamelevel`, `tree_expanded`) VALUES ('FishyShoop', 'John Doe', 'admin@somedomain.com', 'system_noreply@somedomain.com', 'http://www.somedomain.com', '00965', 'T * 1.15025', 'nameasc', '', '0', '1', '1', '0', '1', 'KG', 'default', 'e737305db200c2a516600dc019eced7ashoop_03.gif', '1', '0', '1', '1', 'mysite', '1', '1', '1', '1', '1', '1', '0');
CREATE TABLE `sys_texts` (
  `id` int(11) NOT NULL auto_increment,
  `language` varchar(100) NOT NULL default '',
  `textid` varchar(100) NOT NULL default '',
  `text` longtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM;
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (16, 'English', '003', 'Your order at FishyShoop has been confirmed. Thank you.');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (17, 'English', '004', 'privacy notice text');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (15, 'English', '002', 'Thank you for your interrest in FishyShoop. Please complete the form below. Expect 24 to 48 hours for an answer.');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (14, 'English', '001', 'Welcome on FishyShoop. Hope you like your visit and find great products out there.');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (18, 'English', '005', 'conditions text');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (19, 'English', '006', 'shipping text');
INSERT INTO `sys_texts` (`id`, `language`, `textid`, `text`) VALUES (20, 'English', '007', 'Please register');