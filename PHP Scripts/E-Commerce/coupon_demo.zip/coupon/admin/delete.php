<?PHP 
/* WARNING: This script is protected. Any attempt to reverse engineer, debug or de-code this file or its dependent files is strictly prohibited */
$codelock_enc="admin_l.php"; $codelock_file="delete.php"; $codelock_filed=dirname(__FILE__); include("admin_l.php"); return; ?>
nZBNb4IwAIb/TA/tDSkkethh7bYCVWZgUnrsxxSk0WSmdvDr52XHGeb9zfM+ebYvS66EPHAGkGbNHrQdMriaOC2QhpurXKwGja3XtDqarEoN23nDupD3A6KnxmvmvBoPvRLpcR2Xe8BWWMMwSEyiz5a49YmcDc3Rezjf/QHsLZL1nI+qs+z1Ab6bClYGm7kA6jSo7Lnn9cCtSC837tfd3ceFU+hgTjuoxLdr4yZRbRmZXydM/By2Ycm/vU1WXOU4owsmo443D3RpJiXsLP8/t7c+2yl5+gE=