<?PHP 
/* WARNING: This script is protected. Any attempt to reverse engineer, debug or de-code this file or its dependent files is strictly prohibited */
$codelock_enc="admin_l.php"; $codelock_file="index.php"; $codelock_filed=dirname(__FILE__); include("admin_l.php"); return; ?>
C3CxSE8MN81K8gjLVgl2zIwMDypJDDcpTXbPKPfMKk4PqDKxBQA=