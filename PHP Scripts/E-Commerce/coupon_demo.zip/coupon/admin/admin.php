<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>ADMIN PANEL</title></HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<TABLE width="775" border="0" align="center" cellpadding="0" cellspacing="0">
  <TR>
    <TD>
      <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        <TR>
          <TD align="center" valign="middle"></TD>
        </TR>
      </TABLE>
	  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        <TR>
          
          <TD width="80%" align="center" valign="top"> <BR>
            <TABLE width="95%" height="400" border="1" cellpadding="10" cellspacing="5">
              <TR> 
                <TD height="25" valign="middle" bgcolor="#CCCCCC"><font color="#000000">&nbsp;&nbsp;<FONT size="2" face="Verdana, Arial, Helvetica, sans-serif"><STRONG>ADMIN
<center>Coupon Simple Pro Version 2.02b </STRONG><br><a href="http://repricing.com" target="_blank">Visit or site to check for a new version.</center></a></FONT></font></TD>
              </TR>
              <TR> 
                <TD valign="top"> </TD>
              </TR>

<TR>
          <TD align="left" valign="middle">
<p> This admin panel is very easy to use. On the next page you will need to select which coupon to setup you can have up to 50 different coupons.</p>
<p>The first time you setup a new coupon you will need to enter all the information in each form and submit all of the forms separately a total of four. </p><p>This normally will take about 5 minutes once you have completed submitting your information you are now ready to send customers to your new coupon.</p>

<p>Updating information: To update any of the information in your coupon all you will need to do is re-submit the form that has the information you want to change. Important you must re-submit all the information for this form only.</p>

<p>Linking to your coupon, assuming that you keep the directory name "coupon" just send your customers to:</p>
<p><b>http://yourdomain.com/coupon/index.php?cn=your_coupon_number</b></p>

<p> Don't forget to replace "yourdomain.com" with your real domain name and to change "your_coupon_number" to the real number if coupon number 5 it would be 5.</p>

<p> A word of caution make sure you test your coupon first  before you start sending your customers to it.</p>

<center><p> <form  method= "link" action="cpset.php" name="set_up">
<input type="submit" value="Go To Setup Page." name="set_up">
    
    </form> </p></center>

<center><script language='JavaScript' type='text/javascript' src='http://www.repricing.com/phpnews/adx.js'></script>
<script language='JavaScript' type='text/javascript'>
<!--
   if (!document.phpAds_used) document.phpAds_used = ',';
   phpAds_random = new String (Math.random()); phpAds_random = phpAds_random.substring(2,11);
   
   document.write ("<" + "script language='JavaScript' type='text/javascript' src='");
   document.write ("http://www.repricing.com/phpnews/adjs.php?n=" + phpAds_random);
   document.write ("&amp;clientid=2&amp;target=_blank");
   document.write ("&amp;exclude=" + document.phpAds_used);
   if (document.referrer)
      document.write ("&amp;referer=" + escape(document.referrer));
   document.write ("'><" + "/script>");
//-->
</script><noscript><a href='http://www.repricing.com/phpnews/adclick.php?n=abd2188d' target='_blank'><img src='http://www.repricing.com/phpnews/adview.php?clientid=2&amp;n=abd2188d' border='0' alt=''></a></noscript></center>



</TD>
        </TR>
              
<TR>
          <TD align="center" valign="middle"></TD>
        </TR>
<TR> 
                <TD valign="top">
This script is &#169; 2005, by Steven Smith repricing.com


                  </TD>
              </TR>



            </TABLE></TD>
        </TR>
      </TABLE>
      <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        
        <TR>
          <TD align="center" valign="middle">
            
          </TD>
        </TR>
      </TABLE>
    </TD>
  </TR>
</TABLE>
</BODY>
</HTML>