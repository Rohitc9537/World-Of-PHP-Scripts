<html>
<head></head>

<body>
<center><table width = 50%>
<tr><td>
<p><font color="#FF0000">There was an error!</font> We have detected an older version of Netscape web browser.</p>

<p>While we try to make our site compatible to many browser types there are some that we just can not accommodate due to the scripts we run like our coupon script.</p>

<p>You may want to consider upgrading your browser to a newer version.</p>



<p>Thank you for your understanding.</p>
</td></tr></table></center>
</body></html>