<?
/* this is the csv-parse config file */




//Your directory root for fishcartsql
$droot="/path/to/your/catalog/directory";




//Your custID as supplied in your db.cust you created during the setup of
// your catalog.
$custID="fish";




/* end of csvconfig */
?>