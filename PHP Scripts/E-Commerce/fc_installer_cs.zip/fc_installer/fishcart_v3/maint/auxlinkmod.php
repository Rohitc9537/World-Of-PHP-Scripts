<?php /*
FishCart: an online catalog management / shopping system
Copyright (C) 1997-2002  FishNet, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
USA.

   N. Michael Brennen
   FishNet(R), Inc.
   850 S. Greenville, Suite 102
   Richardson,  TX  75081
   http://www.fni.com/
   mbrennen@fni.com
   voice: 972.669.0041
   fax:   972.669.8972
*/

header("Expires: ".GMDate("D, d M Y H:i:s")." GMT");
header("Pragma: no-cache");

require('../functions.php');
// ========== start of variable loading ==========
// load passed variables and cookie variables
// int or double cast the numbers, no exceptions

$zoneid = (int)getparam('zoneid');
$langid = (int)getparam('langid');
$act    = getparam('act');

$link = (int)getparam('link');

// ==========  end of variable loading  ==========

require('./admin.php');
require('./header.php');
?>

<h2 align="center">Modify A Dynamic Link</h2>
<hr />
<p></p>

<?php 
$fcc = new FC_SQL;

$fcc->query("select * from AUXLINKTABLE where rid=$link"); 
if( !$fcc->next_record() ){?>
  The selected link could not be found.  This may reflect an
  inconsistent database; please check with your system
  administrator.
  <?php $fcc->free_result();
  exit;
}?>

<center>
<table border="0" cellpadding="4" cellspacing="1" bgcolor="#666666" width="650" class="text">
<tr><td align="center" colspan="2" bgcolor="#FFFFFF">

<a href="auxlinkndx.php?zoneid=<?php echo $zoneid?>&langid=<?php echo $langid?>"
 onClick="closehelp();">
Return to Link Maintenance Page</a><br />

<a href="index.php?zoneid=<?php echo $zoneid?>&langid=<?php echo $langid?>"
 onClick="closehelp();">
Return to Central Maintenance Page</a><br />

</td></tr>
<tr><td align="center" colspan="2" bgcolor="#FFFFFF">

<b>
Modify A Link<br />
</b>

</td></tr>

<form method="post" action="auxlinkupd.php">
<input type="hidden" name="act" value="mod" />
<input type="hidden" name="link" value="<?php echo $link?>" />

<tr><td align="right" bgcolor="#FFFFFF">
Title or Image Link
</td><td align="left" bgcolor="#FFFFFF">
<input name="title" size="40"
value="<?php echo stripslashes($fcc->f("title"))?>" />
</td></tr>
<tr><td align="right" bgcolor="#FFFFFF">
URL for Link
</td><td align="left" bgcolor="#FFFFFF">
<input name="url" size="60"
value="<?php echo stripslashes($fcc->f("url"))?>" />
</td></tr>
<tr><td align="right" bgcolor="#FFFFFF">
Location for Link
</td><td align="left" bgcolor="#FFFFFF">
<select name="loc">
<?php if ($fcc->f("loc")==1){?>
<option value="1" selected>Home Page</option>
<?php }else{ ?>
<option value="1">Home Page</option>
<?php } ?>
<?php if ($fcc->f("loc")==2){?>
<option value="2" selected>Cart</option>
<?php }else{ ?>
<option value="2">Cart
<?php } ?>
</select>
</td></tr>
<tr><td colspan="2" bgcolor="#ffffff" align="center">


<input type="hidden" name="zoneid" value="<?php echo $zoneid?>" />
<input type="hidden" name="langid" value="<?php echo $langid?>" />
<input type="submit" value="Modify Link"
 onSubmit="closehelp();">
<input type="reset" value="Clear Field" />

</form>

</td></tr>
<tr><td align="center" colspan="2" bgcolor="#FFFFFF">

<a href="auxlinkndx.php?zoneid=<?php echo $zoneid?>&langid=<?php echo $langid?>"
 onClick="closehelp();">
Return to Link Maintenance Page</a><br />

<a href="index.php?zoneid=<?php echo $zoneid?>&langid=<?php echo $langid?>"
 onClick="closehelp();">
Return to Central Maintenance Page</a><br />

</td></tr>

</table>
</center>

<?php require('./footer.php');?>
