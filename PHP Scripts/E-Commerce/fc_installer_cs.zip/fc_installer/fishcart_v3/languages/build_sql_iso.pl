#!/usr/bin/perl

# FishCart: an online catalog management / shopping system
# Copyright (C) 1997-2003  FishNet, Inc.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
# USA.
# 
# N. Michael Brennen
# FishNet(R), Inc.
# 850 S. Greenville, Suite 102
# Richardson,  TX  75081
# http://www.fni.com/
# mbrennen@fni.com
# voice: 972.669.0041
# fax:   972.669.8972

# Generate the initial SQL insert statements for each language,
# for each country listed in iso_country_list_eng.csv.  Prints the
# results to stdout to be saved as desired.

# Parse the php file for the 3 letter language codes and the 
# name of the language.  Not particularly sophisticated but it works.
# 
open(IF,"../languages/languages.php")
	|| die "could not open languages.php: $!";
while( <IF> ){
	if( /'([a-z]{3})'\s+=>\s+'([A-Za-z ]+)'/ ){
		$langiso{$1} = $2;
	}
}
close(IF);

# Now generate a country code list for each language.
#
foreach $liso (keys(%langiso)){
  $langfile = open(IF,"../languages/iso_country_list_${liso}.csv");
  if( !$langfile ){
    open(IF,"../languages/iso_country_list_eng.csv")
	  || die "could not open iso_country_list_eng.csv: $!";
  }

  print "\n\n--\n-- Country table for ".$langiso{$liso}."\n--\n\n";

  $i = 1;	# sequence number
  while( <IF> ){
	chomp;
	($twoiso,$threeiso,$ccname) = split(/,/);
	$ccname =~ s/'/''/;
	$ccname =~ s/\r//;
	print
		"insert into COUNTRYLANG ".
		"(ctrylangliso,ctrylangciso,ctrylangciso2,ctrylangname)\n".
		"   values ".
		"('$liso','$threeiso','$twoiso','$ccname');\n";
	if( $liso eq 'eng' ){
	  # only do English as the initial default defined language
	  print
		"insert into COUNTRYTABLE ".
		"(ctryzid,ctrylid,ctryiso,ctryseq,ctryactive)\n".
		"   values ".
		"(1,1,'$threeiso',$i,0);\n";
	}
	$i++;
  }
  close(IF);
}
