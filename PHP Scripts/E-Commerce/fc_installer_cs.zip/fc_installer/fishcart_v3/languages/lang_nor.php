<?php
//Norwegian
//ISO 639/2 code: nor
//Translated by Frode Vasstein at frode@go-there.com

$salutearray[] = 'Herr';
$salutearray[] = 'Fru';
$salutearray[] = 'Frue';
$salutearray[] = 'Dr.';
$salutearray[] = 'Rev.';

$fc_prompt = array(
'welcome' =>
	'Velkommen til FishCart, premieren open source multi-nasjonal e-commerce system. Du kan laste ned FishCart fra <a href="http://fishcart.org">fishcart.org</a>.',
'outofservice' =>
	'Butikk programmet er for �yeblikket ute av service. V�r vennlig � pr�v ogjen om noen f� minutter; Vi beklager dette.',
'choosegeo' =>
	'<h2 align=center>Geografi Valg</h2><i>Velg omr�det du bor i<br>salgs moms og utsendings gebyr blir kalkulert.</i>',
'invalidfield' =>
	'</center><p><b>Et n�dvendig felt er ikke skrevet.<br> V�r vennlig � klikk p� "tilbake" knappen p� din browser<br>og pass p� at alle felt er skrevet. Tusen takk.</b><br>',

'tcnotapproved' =>
        '<p><b>The Terms and Conditions were not approved; your order cannot be '.
        'completed without this approval.  Please click the &quot;Back&quot; button '.
        'on your browser to approve them, or click on the link below to abandon your '.
        'order and return to the front page.  Thank you</b></p>',

'contribblank'  =>
        '<p><b>The contribution amount was left blank.  Please click '.
        'the &quot;Back&quot; button on your browser and enter an amount. '.
        'Thank you!</b></p>',

'payamblank'  =>
        '<p><b>The payment amount was left blank.  Please click '.
        'the &quot;Back&quot; button on your browser and enter an amount. '.
        'Thank you!</b></p>',

'invalidemail' =>
	'</center><p><b>Det ser ut til at din epost adresse er skrevet feil.<br> V�r vennlig � klikk p� "Tilbake" knappen p� din browser<br> og sjekk om det er riktig. Tusen takk.<b><br>',
'invalidoffon' =>
	'</center><p><b>Verken Online eller Offline ordre metode er valgt.<br>V�r vennlig � klikk p� "Tilbake" knappen p� din browser og velg en. Tusen takk.</b><br>',
'invalidccfld' =>
	'</center><p><b>Et n�dvendig kreditt kort felt er blank. V�r vennlig � klikk p� "Tolbake" knappen p� din browser og v�r sikker p� at det er riktig utfylt. Tusen takk.</b>',
'invalidccard' =>
	'</center><br><b>Kreditt kort nummeret som vart nedskrevet, ser ut til ikke � v�re riktig<br> skrevet. V�r vennlig � klikk p� "Tilbake" knappen p� din browser<br>og sjekk om det er riktig skrevet. For � hjelpe deg � gj�re nummerene<br> bedre leslig, kan du sepparere kreditt kort nummerene i grupper<br>med blanke eller mellomrom som viser i eksempelet nedenfor. Tusen Takk.</b><br><pre>1111 2222 3333 4444 /Visa / Mastercard) 1111 22222 333333 (American Express)</pre>',
'invalidcctype' =>
	'</center><p><b>V�r vennlig � klikk p� "Tilbake" knappen p� din browser og velg typen av kreditt kort. Tusen takk.</b>',
'invalidccyr' =>
	'</center><p><b>V�r vennlig � klikk p� "Tilbake" knappen p� din browser og<br> skriv inn riktig kreditt kort utg�r �r. Tusen takk.</b>',
'invalidccmo' =>
	'</center><p><b>V�r vennlig � klikk p� "Tilbake" knappen p� din browser og<br> skriv inn riktig kreditt kort utg�r m�ned. Tusen takk.</b>',
'invalidorder' =>
	'<h2 align=center>Feil eller ferdig ordre</h2>
Denne ordren ser ut til enten � v�re feil eller er blitt helt ferdig. Du vil motta denne beskjeden om du klikker p� "Tilbake" knappen p� din browser etter at du er fullstendig ferdig med din ordre. Om du har plassert en ordre online, vil du vite med sikkerhet at det vart fullstendig gjennomf�rt n�r du har mottatt en epost som bekrefter ordren. Ingen e-post blir sendt til offline ordrer.<p>For � fortsette � se FIRMAETS Webside, v�r vennlig � klikk p� <a href="/">tilbake til hjemmesiden.</a> Tusen takk!',
'pwexp' =>
	'Denne elektroniske utsalgs konto er utg�tt. V�r vennlig � kontakte v�r Kunde Service for mer assistanse. Tusen takk.',
'orderfinal' =>
	'Din ordre er plassert! En detaljert bekreftelse har blitt sendt til din e-post adresse som du skrev inn i butikkprogrammet.<p>V�r vennlig � IKKE klikk p� "Tilbake" knappen p� din browser. For � fortsette, klikk p� linken nedenfor for � g� tilbake til FIRMAETS hjemmeside. Tusen takk igjen for ordren!',
'emptysearch' =>
	'Enten vart ingen produkter og/eller s�ke ord vart spesifisert, eller ditt s�k vart returnert uten resultater. V�r vennlig � g� tilbake til produkt valg siden og velg en kategori eller skriv et s�ke ord. Tusen takk.',
'back2select' =>
	'Klikk her for � g� tilbake til produkt valg siden.',

'click2select'	=>
	'<i>Click on the picture for more product detail</i>',

'click2prodname'=>
	'<i>Click on product name for more detail</i>',

'click2select2' =>
        '<i>Click here for more product detail</i>',

'back2cat'=>
	'&#171Back',

'shipinfo' =>
	'Utsendings Informasjon<br><i>(om det er forskjellig fra Betalings Informasjonen)</i>',
'onlinetext' =>
	'Online ordren vart plassert ved � bruke ditt kreditt kort. Ordren er h�yt kryptert for � sikre dine finansielle informasjoner.',
'offlinetext' =>
	'Du kan skrive ut ordren og sende det til telefonen, faksen eller epost. Du kan betale med kreditt kort eller postordre.',
'noshipcalc' =>
	'Utsendings kalkulatoren vart ikke funnet.',
'cartcontents' =>
	'Butikk Innhold',
'cartempty' =>
	'Din kurv er tom!',
'cartmodify' =>
	'<i>For � modifisere en vare, skriv inn antallet og klikk "Oppdater Din Ordre".</i><br><i>For � slette en vare, skriv in 0 antall og klikk p� "Oppdater Din Ordre".</i><br>',
'cartsubmit' =>
	'Oppdater din Ordre',
'cartinvmax' =>
	'<i>*** antallet har overstiget tilgjengelig inventar</i>',
'esdnotrans' =>
	'Ingen produkt vart gitt for nedlasting.<br>',
'esdnodl' =>
	'Enten er nedlasting informasjonen feil eller s� er passer ikke varen denne beskrivelsen.<br>',
'esddlmax' =>
	'Den nedlastbare telleren i denne filen har overskredet.<br>',
'esdnofile' =>
	'Filen som skal lastes ned vart ikke funnet.',
'custsvc' =>
	'V�r vennlig � kontakte FIRMAETS kunde Service for mer hjelp.<br>',
'donatetext' =>
	'Om du vil gi litt penger til forskjellige FIRMAER, skriv inn bel�pet nedenfor og det vil bli lagt til i total bel�pet til din kort. Tusen takk.',
'optviolation' =>
	'<b><i>Et n�dvendig felt for dette produktet vart ikke valgt. V�r vennlig � skriv inn igjen ditt produkt valg; n�dvendige valg er merket med en <font color="#ff0000"<b>*</b></font>. Tusen takk.</i></b>',
'optreqtext' =>
	'<font color="#ff0000"><b>*</b> <i>= n�dvendig valg</i></font>',
'reqtext' =>
	'<font color="#ff0000"><b>*</b> <i>= n�dvendig</i></font>',
'reqflag' =>
	'<font color="#ff0000"><b>*</b></font>',
'choosezone' =>
	'Velg en Katalog',
'chooselang' =>
	'Velg et Spr�k',
'choosecat' =>
	'Se Kategorien',
'selectcat' =>
	'[velg en kategori]',
'choosekey' =>
	'N�kkelord S�k',
'newitems' =>
	'Nye Innlegg!',
'vieworder' =>
	'Se din gjeldene Ordre',
'contactinfo' =>
	'Kontakt Informasjon',
'supportinfo' =>
	'Kunde Behandling',
'titletag' =>
	'Online Butikk',
'submitgeo' =>
	'Velg Ditt Betalings Omr�de',
'prodinfo' =>
	'Produkt Kj�p',
'orderinfo' =>
	'Kunde Ordre Informasjon',
'billinfo' =>
	'Betalings Informasjon',
'creditinfo' =>
	'Kreditt kort Informasjon',
'proddesc' =>
	'Produkt Beskrivelse',
'couponid' =>
	'Kupong ID:',
'coupondisc' =>
	'Kupong Rabatt:',
'unitprice' =>
	'Pris enhet:',
'baseprice' =>
	'Pris Base:',
'option' =>
	'Valg:',
'setup' =>
	'Setup:',
'setupfee' =>
	'Setup kostnad:',
'setupfees' =>
	'Setup kostnader:',
'shipfee' =>
	'Utsendings kostnad:',
'salestax' =>
	'Salgs Moms:',
'thankyou' =>
	'Tusen Takk!',
'voluntary' =>
	'Frivillig Tilleggs Donasjon:',
'subtotal' =>
	'Sum totalt:',
'psubtotal' => 'psubtotal: to be translated',
'product'=>
	'product: to be translated',
'total' =>
	'Totlat:',
'longadd' =>
	'Legg til din Ordre',
'shortadd' =>
	'Legg til',
'quantity' =>
	'Antall',
'qty' =>
	'Ant.',
'home' =>
	'Hjem',
'subcats' =>
	'Subkategori',
'previous' =>
	'Forrige',
'next' =>
	'Neste',
'searchresult' =>
	'S�ke Resultater:',
'sku' =>
	'Antall #:',
'download' =>
	'Last ned',
'downloadrem' =>
	'nedlastbart igjen',
'downloadmax' =>
	'maksimum nedlastbart er n�dd',
'onsale' =>
	'Spesial!',
'price' =>
	'Pris:',
'retailprice'	=> 'retailprice: to be translated',
'nocharge' =>
	'IKKE TILGJENGELIG',
'audiosample' =>
	'Audio klipp',
'videosample' =>
	'Video klipp',
'homepage' =>
	'Hjemmeside',
'zonehome' =>
	'Katalog Forside',
'returnpage' =>
	'Returner til forrige side',
'returnprod' =>
	'Returner til Produkt Siden',
'selectctry' => 'To be translated: Select Country',
'selectgeo' =>
	'Velg Geografi Omr�de',
'checkout' =>
	'Sjekk ut',
'contribution' =>
	'Online Donasjon',
'contribamount' =>
	'Donasjons mengde',
'emailaddr' =>
	'E-Post Adresse',
'salutation' =>
	'Tittel<br><i>valgfritt</i>',
'saluteopt' =>
	'[valfri tittel]',
'firstname' =>
	'For namn',
'miname' =>
	'M.I.',
'lastname' =>
	'Etter namn',
'address' =>
	'Adresse',
'city' =>
	'Sted',
'state' =>
	'Fylke',
'zip' =>
	'Postnr.',
'country' =>
	'Land',
'dayphone' =>
	'Dagtid telefon # (nummer)',
'ccname' =>
	'Kunde namn p� Kreditt kortet',
'ccnumber' =>
	'Kreditt kort Nummer',
'cctype' =>
	'Kreditt kort Type',
'ccexpire' =>
	'Kreditt kortet Utg�r',
'cvvnumber' =>
	'CVV2',
'month' =>
	'M�ned',
'year' =>
	'�r',
'ordermethod' =>
	'Ordre Metode',
'ordersubmit' =>
	'Submitt Din Ordre',
'contribsubmit' =>
	'Submitt Din Donasjon',
'clearform' =>
	'Reset',
'online' =>
	'Online',
'offline' =>
	'Offline',
'ordersubj' =>
	'Ordre Bekreftelse',
'contribsubj' =>
	'Donasjons Bekreftelse',
'orderconf' =>
	'Dette er din Bekreftelses kopi av din ordre p� FIRMA',
'contribconf' =>
	'Dette er din Bekreftelses kopi av din donasjon til FIRMA.',
'contribconf'	=> 
	"This is the confirmation copy of your contribution to\nCOMPANY.",
'paymentconf'	=> 
	"This is the confirmation copy of your payment to\nCOMPANY.",
'promoemail'	=> 
	'Yes, please send me product announcements and promotions.',
'retain_addr'	=> 
	'Remember the above address information on this computer.',
'approvetc'	=> 
	'Yes, I have read the Terms and Conditions, and I accept them.',
'orderorigin'	=> 
	"\nThis order was processed by FishCart(r), FishNet(r)'s Open Source\n".
	"e-commerce software.  For information regarding support, upgrade and\n".
	"feature development services, please visit http://www.fishcart.org/\n".
	"or http://www.fishnetinc.com/.\n",

'jsapprovetc'	=>
	'Please indicate that you accept the Terms and Conditions.  Thank you!',
'jsonoff' =>
	'V�r vennlig � velg Online eller Offline. Tusen takk!',
'jscontrib' =>
	'V�r vennlig � skriv inn donasjons bel�pet. Tusen takk!',
'jscountry' =>
	'V�r vennlig � velg land. Tusen takk!',
'jsbcountry' =>
	'V�r vennlig � velg betalings land. Tusen takk!',
'jsscountry' =>
	'V�r vennlig � velg utsendings landet. Tusen takk!',
'jsccname' =>
	'V�r vennlig � skriv inn namnet p� kreditt kortet- Tusen takk!',
'jsccnum' =>
	'V�r vennlig � skriv inn et kreditt kort nummer. Tusen tak!',
'jscctype' =>
	'V�r vennlig  � skriv inn et krditt ort type. Tusen takk!',
'jsccexp' =>
	'V�r vennlig � skriv inn riktig kreditt kort utg�tt dato. Tusen takk!',
'jsbemail' =>
	'V�r vennlig � skriv inn betalings e-post adresse. Tusen takk!',
'jsbfname' =>
	'V�r vennlig � skriv inn betalings fornamn. Tusen takk!',
'jsblname' =>
	'V�r vennlig � skriv inn betalings etternamn. Tusen takk!',
'jsbaddr' =>
	'V�r vennlig � skriv inn betalings adresse. Tusen takk!',
'jsbcity' =>
	'V�r vennlig � skriv inn betalings sted. Tusen takk!',
'jsbstate' =>
	'V�r vennlig � skriv inn betalings fylke. Tusen takk!',
'jsbzip' =>
	'V�r vennlig � skriv inn betalings postnr. Tusen takk!',
'jspickone' =>
	'V�r vennlig � velg enten en kategori eller skriv inn et s�ke n�kkelord. Tusen takk!',
'jsplaced' =>
	'Tusen takk! Din ordre er plassert; V�r tolmodig, denne prosessen vil ta noen f� sekunder. Tusen takk igjen for din ordre!',
'itemcapfix' =>
	'VARE',
'qtycapfix' =>
	'ANT',
'pricecapfix' =>
	'PRIS',
'productcapfix' =>
	'BESKRIVELSE',
'basepricefix' =>
	'Pris Base:',
'optionfix' =>
	'Valg:',
'qtyfix' =>
	'Ant:',
'totalfix' =>
	'Totalt:',
'setupfix' =>
	'Setup:',
'setuptotalfix' =>
	'Setup Totalt:',
'discountfix' =>
	'Rabatt:',
'subtotalfix' =>
	'Subtotalt:',
'psubtotalfix' => 'psubtotalfix: to be translated',
'shippingfix' =>
	'Utsending:',
'salestaxfix' =>
	'MVA:',
'contributefix' =>
	'Gitt av:',
'ordertotalfix' =>
	'Ordre Totalt:',
'billinfofix' =>
	'Betalings Informasjon:',
'emailaddrfix' =>
	'E-Post Adresse:',
'shipaddrfix' =>
	'Utsendings Adresse:',
'dlusernamefix' =>
	'Nedlastbar bRukernamn:',
'dlpasswordfix' =>
	'Nedlastbar Passord:',
'coupon' =>
	'Kupong:',
'orderid' =>
	'Ordre ID:',
'phone' =>
	'Telefon:',
'fax' =>
	'FAKS:'
);
?>
