#!/usr/bin/perl
#
# FishCart: an online catalog management / shopping system
# Copyright (C) 1997-2002  FishNet, Inc.
#
# install a FishCart into a virtual web space
#
$version = $];
if ($version < 5.001) {
 print "Your version of perl is: $version\n";
 print "perl 5 is required to run this install script.\n";
 exit(0);
}

require "getopts.pl";
&Getopts('d:l:n:');

###
### CUSTOMIZE ANYTHING IN HERE FOR YOUR INSTALLATION
###

$editor = 'vi';

# flat order file root directory
# $flatfile_loc="/usr/local/etc/httpd/fishcartsql";
$flatfile_loc="";

# Solid database installation directory (empty if not using Solid)
# $solid_loc = "/usr/local/solid";
$solid_loc = "";

###
### END OF INSTALLATION CUSTOMIZATION
###

if ( length($opt_d) ) {
 # set up the proper include files
 `cp ./maint/admin_$opt_d.php  ./maint/admin.php`;
 `cp ./common/public_$opt_d.php ./common/public.php`;
 open (DB,">>database.pl" );
 print DB "\$databaseeng = '$opt_d';\n";
 close DB;
}

if ( length($opt_l) ) {
 # set up the proper include files
 open (DB,">>database.pl" );
 print DB "\$dialect = '$opt_l';\n";
 close DB;
}

$fil=$ARGV[0];
$opt=$ARGV[1];

if ( !(-e "../fishcartsql.db") ) {
	`mkdir ../fishcartsql.db`;
	print "\nThe \"../fishcartsql.db\" directory is set up.\n\n";
	`cp db/db.cust ../fishcartsql.db`;
	exit;
}else{
	`cp db/db.cust ../fishcartsql.db`;
}

if ( $opt_n ) {
  if ( -e "../fishcartsql.db/$opt_n" ) {
    print "$opt_n file already exists -- not overwritten\n\n";
  } else {
	"cp  db/db.cust ../fishcartsql.db/$opt_n";
    print "$opt_n file created\n\n";
	# `$editor $opt_n`;
  }
}

if ( !(-e "database.pl") ) {
 print "
The install script has not been run with the -d option yet.
";
 $croak = 1;
}

if ( $#ARGV != 1 || $croak == 1 || ( $#ARGV == 3 && !$opt_n ) ) {
	print "
Usage:  install.pl [-n db.???] [-d database] [-l odbc_dialect] db.??? which

 -n db.???: copies the db.cust template to a new client file 
            (will not overwrite an existing file)

where \"database\" is one of:

 odbc | mysql | pgsql | oracle | mssql

where \"odbc_dialect\" is the ODBC dialect used
(only needed if using ODBC):

 solid

and \"which\" is one of:

 all  | maint   | cart    | secure  | sql | cron | function |
 lang | seclang | onetime | instsql

 ('instsql' will attempt to create the FishCart SQL tables. This
  option must be specified separately; for it to work the defined
  database username must have table create privileges.)

 NB: 'lang', 'seclang' and 'onetime' options force the overwrite of 
 the files being installed; if run with the 'all' option, if the
 files exist they are installed as 'filename.recommended'.

";
	exit 1;
}

# get this client's installation parameter file
if ( length($solid_loc) && -e $solid_loc ) {
 require DBI;
}

require "database.pl";
if ( -e "../fishcartsql.db/$fil" ) {
 require "../fishcartsql.db/$fil";
}else{
 print "The specified file $fil does not exist.\n";
 exit;
}

print "\nInstalling for the '$databaseeng' database...\n";

$docpath = $inst{'docroot'}.$inst{'directory'};
$secpath = $inst{'secroot'}.$inst{'secdir'};

sub chown_by_name {
#	local ( $user, $pattern ) = @_;
#	chown ((getpwnam($user))[2,3], <${pattern}>);
}

sub copy_file {
local ( $fname, $destpath, $destfile, $onetime ) = @_;

  $destfile =~ /([\w\.\/_]+)\/([a-z0-9\._]+)/;
  if(length($1)>0){
    $destfile = $2;
  }
  if( $onetime ){
    if ( -e $destpath.'/'.$destfile ) {
      $destfile .= '.recommended';
    }
  }
  print "copy $fname to $destfile....\n";
  #return;

  open ( IN, "$fname" )
	|| die "OOPS: copy_file can't open $fname: $!\n";
  open ( OUT, ">$destpath/$destfile" )
	|| die "OOPS: copy_file can't create $destpath/$destfile: $!\n";

  while (<IN>) {
		s/DEFAULT_AID/$default_aid/g;
		s/FLATFILE_LOC/$flatfile_loc/g;
		s/DATABASEENG/$inst{'databaseeng'}/g;
		s/DATABASEHOST/$inst{'databasehost'}/g;
		s/DATABASENAME/$inst{'databasename'}/g;
		s/DIALECT/$inst{'dialect'}/g;
		s/PORTNUM/$inst{'portnum'}/g;
		s/TPLDBASE/$inst{'tpldbase'}/g;
		s/HOMEURL/$inst{'homeurl'}/g;
		s/CATALOGURL/$inst{'catalogurl'}/g;
		s/SECUREURL/$inst{'secureurl'}/g;
		# DocumentRoot now extracted at run time from PHP superglobal
		# s/DOCROOT/$inst{'docroot'}/g;
		s/SECROOT/$inst{'secroot'}/g;
		s/DIRECTORY/$inst{'directory'}/g;
		s/SECDIR/$inst{'secdir'}/g;
		s/MAINTDIR/$inst{'maintdir'}/g;
		s/LANGDIR/$inst{'langdir'}/g;
		s/ACCOUNT/$inst{'account'}/g;
		s/SECACCOUNT/$inst{'secaccount'}/g;
		s/ORDACCT/$inst{'ordacct'}/g;
		s/ORDGRP/$inst{'ordgrp'}/g;
		s/COMPANY/$inst{'company'}/g;
		s/DOMAINTLD/$inst{'domaintld'}/g;
		s/DOMAIN/$inst{'domain'}/g;
		s/TLD/$inst{'tld'}/g;
		s/KEYID/$inst{'keyid'}/g;
		s/ORDEREMAIL/$inst{'orderemail'}/g;
		s/ORDERCONF/$inst{'orderconf'}/g;
		s/CONFFILE/$inst{'conffile'}/g;
		s/USERID/$inst{'userid'}/g;
		s/USERPW/$inst{'userpw'}/g;
		s/ADMID/$inst{'admid'}/g;
		s/ADMPW/$inst{'admpw'}/g;
		s/ORDERHEAD/$inst{'orderhead'}/g;
		s/ORDERLINEOPT/$inst{'orderlineopt'}/g;
		s/ORDERLINE/$inst{'orderline'}/g;
		s/OHEADFILE/$inst{'oheadfile'}/g;
		s/OLINEFILE/$inst{'olinefile'}/g;
		s/MASTERTABLE/$inst{'mastertable'}/g;
		s/WEBTABLE/$inst{'webtable'}/g;
		s/VENDORTABLE/$inst{'vendortable'}/g;
		s/PRODCATTABLE/$inst{'prodcattable'}/g;
		s/NPRODTABLE/$inst{'nprodtable'}/g;
		s/OPRODTABLE/$inst{'oprodtable'}/g;
		s/PRODTABLE/$inst{'prodtable'}/g;
		s/PRODLANG/$inst{'prodlang'}/g;
		s/PRODOPTGRPNAME/$inst{'prodoptgrpname'}/g;
		s/PRODOPT/$inst{'prodopt'}/g;
		s/PRODREL/$inst{'prodrel'}/g;
		s/SUBCATTABLE/$inst{'subcattable'}/g;
		s/CATTABLE/$inst{'cattable'}/g;
		s/ACCTABLE/$inst{'acctable'}/g;
		s/KEYTABLE/$inst{'keytable'}/g;
		s/SUBZSHIPTABLE/$inst{'subzshiptable'}/g;
		s/SHIPTABLE/$inst{'shiptable'}/g;
		s/SHIPTHRESH/$inst{'shipthresh'}/g;
		s/WEIGHTTHRESH/$inst{'weightthresh'}/g;
		s/SUBZONETABLE/$inst{'subzonetable'}/g;
		s/ZONETABLE/$inst{'zonetable'}/g;
		s/LANGTABLE/$inst{'langtable'}/g;
		s/CUSTTABLE/$inst{'custtable'}/g;
		s/ASSOCIATETABLE/$inst{'associatetable'}/g;
		s/COUPONTABLE/$inst{'coupontable'}/g;
		s/ADMPASSWORDTABLE/$inst{'admpasswordtable'}/g;
		s/PASSWORDTABLE/$inst{'passwordtable'}/g;
		s/COUNTRYTABLE/$inst{'countrytable'}/g;
		s/COUNTRYLANG/$inst{'countrylang'}/g;
		s/ESDTABLE/$inst{'esdtable'}/g;
		s/SEQTABLE/$inst{'seqtable'}/g;
		s/AUXLINKTABLE/$inst{'auxlinktable'}/g;
		s/AUXTXTTABLE/$inst{'auxtexttable'}/g;
		s/TEMPLATES/$inst{'templates'}/g;
		s/TEMPLATEID/$inst{'templateid'}/g;
		s/SEQID/$inst{'seqid'}/g;
		s/INSID/$inst{'insid'}/g;
		s/INDEXID/$inst{'indexid'}/g;
		s/INSTALLID/$inst{'installid'}/g;
		s/DBDNAME/$inst{'dbdname'}/g;
		s/DBDPASS/$inst{'dbdpass'}/g;
		s/DBDUID/$dbduid/g;
		s/SYSDSN/$inst{'sysdsn'}/g;
		s/DSN_UID/$inst{'dsn_uid'}/g;
		s/DSN_PW/$inst{'dsn_pw'}/g;
		s/LANGISO/$inst{'langiso'}/g;
		s/LANGNAME/$inst{'langname'}/g;
		s/BACKGRAPHIC/$inst{'backgraphic'}/g;
		s/MASTGRAPHIC/$inst{'mastgraphic'}/g;
		s/CYBERCASH_ID/$inst{'cybercash_id'}/g;
		s/MERCHANT_KEY/$inst{'merchant_key'}/g;
		print OUT;
  }
  close ( IN );
  close ( OUT );
#  ($ownr,$grp)=(getpwnam($inst{'account'}))[2,3];
# print "chowning $destpath/$destfile to $inst{'account'}:$ownr.$grp\n";
#  &chown_by_name ("$inst{'account'}", "$destpath/$destfile");
}

#
# see if we need to set up the split CC database
#

if ( $inst{'dbdname'} eq "" || $inst{'dbdpass'} eq "" ) {

	print "\nThe split CC delivery system will not be set up.\n\n";
	$dbduid = 0;

} else {

###
### set up the Solid database for split CC delivery
###

if ( length($solid_loc) && -e $solid_loc ) {

$dbdname = $inst{'dbdname'};
$dbdpass = $inst{'dbdpass'};
$fcord_view=$dbdname.'_ccnum';
$fcusr_view=$dbdname.'_user';

print "\nsplit CC database user dbdname $dbdname, password $dbdpass\n\n";

my $dbh = DBI->connect('upipe solid', 'fishcart', 'fishcart', 'Solid');
unless($dbh)
    {
    warn($DBI::errstr);
    exit(0);
    }

if ( $sth=$dbh->prepare(
	"select count(*) from fc_users where username='$dbdname'")) {
	$res=$sth->execute();
	@row=$sth->fetchrow_array;
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
if( $row[0] > 0 ){

	print "This user already exists in the database...\n\n";

} else {

 ##
 ## use the sequence incrementing procedure call to add the user record
 ##

 # single quotes have to be escaped with two for Solid
 $company = $inst{'company'};
 $company =~ s/'/''/g;

 if ( $sth=$dbh->prepare("call fcuser_ins('$dbdname','$company')")) {
	$res=$sth->execute();
	$sth->finish();
 } else {
	print $DBI::errstr, "\n";
 }

}

##
## now fetch the sequence
##

if ( $sth=$dbh->prepare(
	"select userid from fc_users where username='$dbdname'")) {
	$res=$sth->execute();
	@row=$sth->fetchrow_array;
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}

## dbduid will be used in installation/substitution
$dbduid = $row[0];
print "$dbdname has user id $dbduid\n";

## reinstall the privs and views
##
## revoke privs, create the user name

$dbh->do("revoke all privileges on $fcord_view from $dbdname");
$dbh->do("revoke all privileges on $fcusr_view from $dbdname");
$dbh->do("drop view $fcord_view");
$dbh->do("drop view $fcusr_view");
$dbh->do("drop user $dbdname");
$dbh->do("commit work");

if ( $sth=$dbh->prepare("create user $dbdname identified by $dbdpass")) {
	$res=$sth->execute();
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
print "created user $dbdname\n";

$dbh->do("commit work");

##
## create the fc_ccnums view
##

if ( $sth=$dbh->prepare(
"create view $fcord_view as select * from fc_ccnums where userid=$dbduid") ) {
	$res=$sth->execute();
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
print "created view $fcord_view\n";

##
## create the fc_users view
##

if ( $sth=$dbh->prepare(
"create view $fcusr_view as select * from fc_users where username='$dbdname'") ) {
	$res=$sth->execute();
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
print "created view $fcusr_view\n";

##
## grant the user privileges to the fc_ccnums view
##

if ( $sth=$dbh->prepare("grant all privileges on $fcord_view to $dbdname") ) {
	$res=$sth->execute();
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
print "granted all privileges on $fcord_view to $dbdname\n";

##
## grant the user privileges to the fc_users view
##

if ( $sth=$dbh->prepare("grant select on $fcusr_view to $dbdname") ) {
	$res=$sth->execute();
	$sth->finish();
} else {
	print $DBI::errstr, "\n";
}
print "granted select on $fcusr_view to $dbdname\n";

##
## and commit what is left
##

if ( $sth=$dbh->do("commit work") ) {
} else {
	print $DBI::errstr, "\n";
}
print "committed work\n";

$dbh->disconnect();

}

}

###
### end of split CC database setup
###

###
### create the directories for the cart files
###

if ( !(-e "$inst{'docroot'}$inst{'directory'}") ) {
	print "\nmaking $inst{'docroot'}$inst{'directory'} for $inst{'company'}\n";
	mkdir ("$inst{'docroot'}$inst{'directory'}", 0755) || 
		die "OOPS: can't create directory: $inst{'docroot'}$inst{'directory'}\n";
}
# &chown_by_name ("$inst{'account'}", "$inst{'docroot'}$inst{'directory'}");

if ( !(-e "$inst{'docroot'}$inst{'maintdir'}") ) {
	mkdir ("$inst{'docroot'}$inst{'maintdir'}", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'maintdir'}\n";
	mkdir ("$inst{'docroot'}$inst{'maintdir'}/maintupl", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'maintdir'}/maintupl\n";
}
# &chown_by_name ("$inst{'account'}", "$inst{'docroot'}$inst{'maintdir'}");

$created_langdir = 0;
if ( !(-e "$inst{'docroot'}$inst{'langdir'}") ) {
	mkdir ("$inst{'docroot'}$inst{'langdir'}", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'langdir'}\n";
	$created_langdir = 1; 
}
# &chown_by_name ("$inst{'account'}", "$inst{'docroot'}$inst{'langdir'}");
if ( !(-e "$inst{'docroot'}$inst{'funcdir'}") ) {
	mkdir ("$inst{'docroot'}$inst{'funcdir'}", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'funcdir'}\n";
}
# &chown_by_name ("$inst{'account'}", "$inst{'docroot'}$inst{'funcdir'}");

if ( !(-e "$inst{'docroot'}$inst{'directory'}/ra") ) {
	mkdir ("$inst{'docroot'}$inst{'directory'}/ra", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'directory'}/ra\n";
}
# chown ((getpwnam($inst{'account'}))[2], (getpwnam("nobody"))[3], "$inst{'docroot'}$inst{'directory'}/ra");
# chmod 0770, "$inst{'docroot'}$inst{'directory'}/ra";

if ( !(-e "$inst{'docroot'}$inst{'directory'}/files") ) {
	mkdir ("$inst{'docroot'}$inst{'directory'}/files", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'directory'}/files\n";
}
# chown ((getpwnam($inst{'account'}))[2], (getpwnam("nobody"))[3],"$inst{'docroot'}$inst{'directory'}/files");
# chmod 0770, "$inst{'docroot'}$inst{'directory'}/files";

if ( !(-e "$inst{'docroot'}$inst{'imgdir'}") ) {
	mkdir ("$inst{'docroot'}$inst{'directory'}/images", 0755) || 
	 die "OOPS: can't create directory: $inst{'docroot'}$inst{'directory'}/images\n";
}
# chown ((getpwnam($inst{'account'}))[2], (getpwnam("nobody"))[3],"$inst{'docroot'}$inst{'directory'}/images");
# chmod 0770, "$inst{'docroot'}$inst{'directory'}/images";

if ( length($flatfile_loc) ) {
 if ( !(-e $flatfile_loc) ) {
	mkdir ("$flatfile_loc", 0730) || 
		die "OOPS: can't create directory: $flatfile_loc\n";
 }
#  chown ((getpwnam($inst{'ordacct'}))[2],(getpwnam("nobody"))[3],$flatfile_loc);
#  chmod 0730, $flatfile_loc;
}

##
## create the secure areas if needed
##
if ( !(-e "$inst{'secroot'}$inst{'secdir'}") ) {
	print "\nmaking $inst{'secroot'}$inst{'secdir'} for $inst{'company'}\n";
	mkdir ("$inst{'secroot'}$inst{'secdir'}", 0755) || 
		die "OOPS: can't create directory: $inst{'secroot'}$inst{'secdir'}\n";
}
# &chown_by_name ("$inst{'secaccount'}", "$inst{'secroot'}$inst{'secdir'}");

$created_seclangdir = 0;
if ( !(-e "$inst{'secroot'}$inst{'langdir'}") ) {
	mkdir ("$inst{'secroot'}$inst{'langdir'}", 0755) || 
	 die "OOPS: can't create directory: $inst{'secroot'}$inst{'langdir'}\n";
	$created_seclangdir = 1; 
}
# &chown_by_name ("$inst{'account'}", "$inst{'secroot'}$inst{'langdir'}");

##
## now install the needed files
##

if($opt eq "all" || $opt eq "maint") {
	print "\nInstalling the maintenance scripts....\n";
	foreach $fname (@maintarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'maintdir'}","$fname",0);
	}
}

if($opt eq "all" || $opt eq "function") {
	print "\nInstalling the function scripts....\n";
	foreach $fname (@funcarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'funcdir'}","$fname",0);
	}
}

if($opt eq "all" || $opt eq "cart") {
	print "\nInstalling the cart scripts....\n";
	foreach $fname (@cartarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'directory'}","$fname",0);
	}
	if($opt eq "cart") {
		print "\nThe secure cart scripts must be installed separately.\n";
	}
}

if( ($opt eq "all" || $opt eq "secure") ){
	#($docpath ne $secpath) ) {
	print "\nInstalling the secure cart scripts....\n";
	foreach $fname (@secarray) {
		&copy_file ("$fname","$inst{'secroot'}$inst{'secdir'}","$fname",0);
	}
	if($opt eq "secure") {
		print "\nThe normal cart scripts must be installed separately.\n";
	}
}

if( $opt eq "all" || $opt eq "cron" ) {
	print "\nInstalling the cron scripts....\n";
	foreach $fname (@orderarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'maintdir'}","$fname",0);
		# chown 0,0,"$inst{'docroot'}$inst{'maintdir'}/$fname";
		chmod 0700,"$inst{'docroot'}$inst{'maintdir'}/$fname";
	}
}

if($opt eq "all" || $opt eq "sql") {
	print "\nInstalling the SQL templates....\n";
	foreach $fname (@sqlarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'maintdir'}","$fname",0);
	}
}

if($opt eq "all" || $opt eq "onetime") {
	if( $opt eq "all" ) {
		$keep=1;
	}else{
		$keep=0;
	}
	print "\nInstalling the onetime files....\n";
	foreach $fname (@onetimearray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'directory'}","$fname",$keep);
	}
}

if( $opt eq "all" || $opt eq "lang" ) {
	if( $opt eq "all" ) {
		$keep=1;
	}else{
		$keep=0;
	}
	print "\nInstalling the language templates....\n";
	foreach $fname (@langarray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'langdir'}","$fname",$keep);
	}
}

if( ($opt eq "all" || $opt eq "seclang") &&
	($docpath ne $secpath) ){
	if( $opt eq "all" ) {
		$keep=1;
	}else{
		$keep=0;
	}
	print "\nInstalling the secure site language templates....\n";
	foreach $fname (@langarray) {
		&copy_file ("$fname","$inst{'secroot'}$inst{'langdir'}","$fname",$keep);
	}
}

if($opt eq "all") {
	print "\nInstalling the images....\n";
	foreach $fname (@imagearray) {
		&copy_file ("$fname","$inst{'docroot'}$inst{'imgdir'}","$fname",0);
	}
}

### call the installed sql_setup.php script
if(opt eq "instsql") {
  &sql_setup(
	"$machine.$domain.$tld", 
	"/".$inst{'maintdir'}."/sql_setup.php",
	"80"
  );
  if( $inst{'directory'} ne $inst{'secdir'} ||
    $inst{'docroot'}   ne $inst{'secroot'} ){
	&sql_setup(
		"$secmachine.$domain.$tld", 
		"/".$inst{'maintdir'}."/sql_setup.php",
		"443"
	);
  }
}

print "\n\n";
print "1. Create the database with the proper sql file (~/maint directory).";
print "\n\n";
print	"2. Set a Web server password on the $inst{'maintdir'} directory.";
print "\n\n";

### access the sql_setup.php file installed in the /maint directory
### to set up the sql database
###
sub sql_setup {  # arguments: host address, relative path, server port
	local($url, $path, $port) = @_;

	open(LOG,">sql_setup.log") || warn "unable to open sql_setup.log\n";
	$proto = getprotobyname('tcp');
	$saddr = pack_sockaddr_in ( $port, inet_aton("$url") );
	if ( !socket(S, PF_INET, SOCK_STREAM, $proto) ) {
		print "*** sql_setup socket failure\n";
	} elsif ( connect(S, $saddr) ) {
		select(S); $| = 1; select(STDOUT);
		if ( $child=fork() ) {
			print S "GET $path HTTP/1.0\r\n";
			print S "Host: $url:$port\r\n\r\n";
			waitpid ($child,0);  # collect the child process
		} else {
			# child process
			# get first line of HTTP header
			$rslt=<S>;
			if ( !($rslt =~ /200 OK\r$/) ) {
				print "*** sql_setup HTTP error: $rslt\n".
					  "see errors in sql_setup.log\n";
			}
			print LOG "$rslt\r\n";
			# log the sql_setup results
			while( $rslt=<S> ){
				print LOG "$rslt\r\n";
			}
		}
		close(S);
	} else {
		print "*** sql_setup connect failure\n";
	}
	close(LOG);
	return;
}
