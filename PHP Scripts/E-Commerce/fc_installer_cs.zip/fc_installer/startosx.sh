#!/bin/sh
umask 022
/usr/bin/java -jar ./jar/FCInstall.jar
