#!/bin/sh
umask 022
java -jar ./jar/FCInstall.jar
