<?
$logit = true; 
$logfile = "searchbot_log.txt";
$emailit = true;
$youremail = "email@site.com";
$perpage = 10;
$password = "password";
?>