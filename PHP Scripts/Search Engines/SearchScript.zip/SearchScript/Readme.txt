GlobalPPC.com Search Script

REQUIREMENTS:

Web Hosting Account/Server
PHP 4.3.0 or above (with fopen enabled)

GETTING STARTED:

1. 	Insert HTML for everything that you want to come before your search results
   	into header.html.

2. 	Insert HTML for everything that you want to come after your search results
   	into footer.html.

3. 	Open search.php with notepad, or similar text editor. Edit they variables at 
   	the top of the file. These unclude your affiliate website ID, number of results
	per page (the maximum is 10), weather to filter adult sites, any advertisers you
	would like to filter, and whether or not to only show paid results.

4. 	Upload all files in ASCII mode to your server.
