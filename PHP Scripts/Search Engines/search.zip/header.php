<?php

	error_reporting(E_ALL & ~E_NOTICE);

	echo '<html><head><meta HTTP-EQUIV="content-type" CONTENT="text/html; charset=UTF-8"><title>Results for:  ' . stripslashes ($HTTP_GET_VARS['q']) . '</title></head>';
	echo '<body><BR>';

?>
