// -----------------------------------------------------------------------------
//
// phpFaber CMS v.1.0
// Copyright(C), phpFaber LLC, 2004-2005, All Rights Reserved.
// E-mail: products@phpfaber.com
//
// All forms of reproduction, including, but not limited to, internet posting,
// printing, e-mailing, faxing and recording are strictly prohibited.
// One license required per site running phpFaber CMS.
// To obtain a license for using phpFaber CMS, please register at
// http://www.phpfaber.com/i/products/cms/
//
// 09:03 PM 08/21/2005
//
// -----------------------------------------------------------------------------

Module: GoogleSitemap
Version: 1.0

----------------------------------
Module integration instructions
----------------------------------

1/ Create empty file google_sitemap.xml in the root folder of the phpFaber CMS. (Where cron.php file is placed.)

2/ CHMOD google_sitemap.xml file to 666.

3/ Open Admin Area -> Modules Management -> GoogleSitemap page.

4/ Press Generate Google Sitemap button.

5/ Open https://www.google.com/webmasters/sitemaps/ page. Login or create Google account there.

6/ Using instructions submit your sitemap google_sitemap.xml file.
   Use http://your_web_site_url/google_sitemap.xml
