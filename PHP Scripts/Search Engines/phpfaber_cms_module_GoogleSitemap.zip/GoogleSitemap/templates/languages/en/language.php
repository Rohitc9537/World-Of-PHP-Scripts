<?php

// -----------------------------------------------------------------------------
//
// phpFaber CMS v.1.0
// Copyright(C), phpFaber LLC, 2004-2005, All Rights Reserved.
// E-mail: products@phpfaber.com
//
// All forms of reproduction, including, but not limited to, internet posting,
// printing, e-mailing, faxing and recording are strictly prohibited.
// One license required per site running phpFaber CMS.
// To obtain a license for using phpFaber CMS, please register at
// http://www.phpfaber.com/i/products/cms/
//
// 02:12 AM 08/16/2005
//
// -----------------------------------------------------------------------------

if (!defined('INDEX_INCLUDED')) die('<code>You cannot access this file directly..</code>');

$_LNG['_PAGE_TITLE'] = 'Google Sitemap';
$_LNG['_BTN_GENERATE'] = 'Generate Google Sitemap file';
$_LNG['_MSG_SITEMAP_GENERATED'] = 'Google Sitemap file \'%s\' generated successfully';
$_LNG['_MSG_ER_SITEMAP_GENERATE'] = 'Can not generate Google Sitemap file \'%s\'';
$_LNG['_MSG_SITEMAP_POSTED'] = 'Google Sitemap file \'%s\' processed successfully';
$_LNG['_MSG_ER_SITEMAP_POST'] = 'Can not process Google Sitemap file \'%s\'';

$_LNG['_MSG_SITEMAP_NOTCREATED'] = 'Google Sitemap file \'%s\' generated successfully';

?>