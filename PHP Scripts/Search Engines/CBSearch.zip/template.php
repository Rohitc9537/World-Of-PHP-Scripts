<?php
  include "header.php";
  include "results.php";
  include "pages.php";
  include "categories.php";
  include "footer.php";
?>