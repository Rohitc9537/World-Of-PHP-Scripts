<?
#Please refer to config_variables.html for an explanation of each variable. :)
$sqlhost = "";
$sqllogin = "";
$sqlpass = "";
$sqldb = "";
$table = "mos_sites";
$adstable = "mos_ads";
$enginestable = "mos_engines";
$searchfeedid = "6410";
$revenuepilotid = "2751";
$webgerusername = "nukedweb";
$numsearchfeed = "10";
$numrevenuepilot = "10";
$numwebger = "10";
$rpfamfilt = "off";
$purgedays = "60";
$mainmod = "index.php";
$engtitle = "MyOwnSearch";
$header = "";
$footer = "";
$fontface = "Verdana";
$fontsize = "-1";
$color1 = "#DDDDDD";
$color2 = "#EEEEEE";
$textcolor = "#000000";
$tablewidth = "90%";
$maxresults = 30;
$newwin = "1";
$showmeta = 1;
$adminpass = "thepass";
$showadvert = 1;

?>