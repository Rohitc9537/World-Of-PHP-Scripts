#-------------------------------------------------#
# podDetector - search bot detector script 	  #
# Copyright (C) 2005 http://phpPod.com		  #
#-------------------------------------------------#

Need a simple way of finding out when and where search engine spiders are crawling your site? The answer is podDetector! 

What is podDetector?

podDetector is a simple PHP script that will email you with accurate results the second that a spider crawls your site and will give you information like what page got spidered and what time it got spidered.

Requirements

- A webhost that supports PHP

Licence

Freeware, you may use this script freely on your website and freely distribute it. We only require you to leave the copyright notices intact.
If you would like to remove the copyright notices please contact us 

Installation

All you need to do is edit the "detector.php" file and replace "you@yourwebsite.com" with your own email address.
Then use a phpinclude to include the "detector.php" file into your own website eg)...

<?php include('detector.php'); ?>

We hope you enjoy this script! For support please visit our forums at http://phppod.com/forums/

#-------------------------------------------------#
# END of document			 	  #
#-------------------------------------------------#