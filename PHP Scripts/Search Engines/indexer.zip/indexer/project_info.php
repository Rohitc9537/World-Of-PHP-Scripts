project_name;Indexer
version;0.9
release_date;2004-11-01

author_name;Oliver K�hrig
author_email;oliver@bitesser.de

homepage_text;bitesser.de
homepage_link;http://www.bitesser.de

install_protection;disabled