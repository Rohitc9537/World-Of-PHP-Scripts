-- following will be filled automatically by SubVersion!
-- Do not change by hand!
-- $LastChangedDate: 2005-08-16 08:35:07 +0200 (Di, 16 Aug 2005) $
-- @lastedited $LastChangedBy: lu $
-- $LastChangedRevision: 288 $

DROP TABLE IF EXISTS %tablePrefix%stopwords;

DROP TABLE IF EXISTS %tablePrefix%search;

DROP TABLE IF EXISTS %tablePrefix%log;

DROP TABLE IF EXISTS %tablePrefix%loghits;

DROP TABLE IF EXISTS %tablePrefix%internal;

DROP TABLE IF EXISTS %tablePrefix%iprofile;

DROP TABLE IF EXISTS %tablePrefix%iprofile_search;

DROP TABLE IF EXISTS %tablePrefix%ranksymbols;

DROP TABLE IF EXISTS %tablePrefix%users;

DROP TABLE IF EXISTS %tablePrefix%user_levels;
