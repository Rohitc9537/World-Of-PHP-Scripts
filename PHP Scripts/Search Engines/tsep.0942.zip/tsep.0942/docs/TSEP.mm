<map version="0.8.0 RC5">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1120736094225" ID="Freemind_Link_755319190" MODIFIED="1120987533792" TEXT="TSEP">
<edge STYLE="bezier"/>
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1120736338516" ID="_" LINK="note.htm" MODIFIED="1120909971022" POSITION="left" TEXT="Notes">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="ksmiletris"/>
<node COLOR="#00b439" CREATED="1120739298482" ID="Freemind_Link_579763922" LINK="note.htm#begin" MODIFIED="1120916740536" TEXT="To begin with">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1120736812538" ID="Freemind_Link_267225223" LINK="note.htm#timeline" MODIFIED="1120916744943" TEXT="Timeline">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="idea"/>
<node COLOR="#990000" CREATED="1120736841099" ID="Freemind_Link_729777091" MODIFIED="1120745937378" TEXT="Past">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737464175" ID="Freemind_Link_1167769739" LINK="history.txt" MODIFIED="1120951254359" TEXT="History (txt)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1120736841099" ID="Freemind_Link_850852839" MODIFIED="1120745937388" TEXT="Future">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737442133" ID="Freemind_Link_1288824767" LINK="todo.txt" MODIFIED="1125600046994" TEXT="ToDo (txt)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736812538" ID="Freemind_Link_1723362522" LINK="note.htm#license" MODIFIED="1120916749850" TEXT="License">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1120736841099" ID="Freemind_Link_1260186973" LINK="gpl.txt" MODIFIED="1120951248921" TEXT="GPL (txt)">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736812538" ID="Freemind_Link_593578027" LINK="note.htm#credit" MODIFIED="1120916754156" TEXT="Credits">
<arrowlink DESTINATION="Freemind_Link_1278322566" ENDARROW="Default" ENDINCLINATION="444;0;" ID="Freemind_Arrow_Link_951993200" STARTARROW="Default" STARTINCLINATION="444;0;"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1120738669668" ID="Freemind_Link_1970034856" MODIFIED="1120746181690" TEXT="Translators">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120738676348" ID="Freemind_Link_1780980593" MODIFIED="1120746181690" TEXT="Donators">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120895060953" ID="Freemind_Link_310531627" LINK="note.htm#contact" MODIFIED="1120916759223" TEXT="Contact">
<arrowlink DESTINATION="Freemind_Link_1278322566" ENDARROW="Default" ENDINCLINATION="542;0;" ID="Freemind_Arrow_Link_168090464" STARTARROW="Default" STARTINCLINATION="542;0;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="Mail"/>
<node COLOR="#990000" CREATED="1120738662157" ID="Freemind_Link_92685787" MODIFIED="1120894793668" TEXT="Developer Team">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120736367187" ID="Freemind_Link_1470369214" LINK="install.htm" MODIFIED="1120909965955" POSITION="left" TEXT="Install &amp; Upgrade">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="full-1"/>
<node COLOR="#00b439" CREATED="1120742298155" ID="Freemind_Link_185697971" LINK="install.htm#setup" MODIFIED="1120916793463" TEXT="Setup">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1125413096872" ID="Freemind_Link_1762741397" LINK="install.htm#setupdebug" MODIFIED="1125413144341" TEXT="Debugging">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1125836211251" ID="Freemind_Link_1320763360" LINK="install.htm#feedback" MODIFIED="1125836226674" TEXT="Feedback">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736383280" ID="Freemind_Link_1805321512" LINK="install.htm#config" MODIFIED="1120916799031" TEXT="Configuration">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1120736390671" ID="Freemind_Link_497888918" LINK="install.htm#security" MODIFIED="1120916807973" TEXT="Security">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="password"/>
</node>
<node COLOR="#00b439" CREATED="1120736396579" ID="Freemind_Link_1344230774" LINK="install.htm#index" MODIFIED="1120916812690" TEXT="Indexing">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="pencil"/>
<node COLOR="#990000" CREATED="1120736422767" ID="Freemind_Link_25180832" LINK="install.htm#profiles" MODIFIED="1120950966796" TEXT="Profiles">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1125413444362" ID="Freemind_Link_1720847549" LINK="advanced.htm#contentimages" MODIFIED="1125415586102" TEXT="ContentImages">
<arrowlink DESTINATION="Freemind_Link_1650666261" ENDARROW="Default" ENDINCLINATION="377;0;" ID="Freemind_Arrow_Link_1325111258" STARTARROW="None" STARTINCLINATION="377;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736429967" ID="Freemind_Link_1901646134" LINK="install.htm#prepare" MODIFIED="1120916817567" TEXT="Preparing the search page">
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120736542579" ID="Freemind_Link_481375399" LINK="usage.htm" MODIFIED="1120909980095" POSITION="left" TEXT="Usage">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="full-2"/>
<node COLOR="#00b439" CREATED="1120736547837" ID="Freemind_Link_887567237" LINK="usage.htm#search" MODIFIED="1120916677706" TEXT="Searching">
<arrowlink COLOR="#cc0000" DESTINATION="Freemind_Link_1515638473" ENDARROW="Default" ENDINCLINATION="414;0;" ID="Freemind_Arrow_Link_1067104797" STARTARROW="Default" STARTINCLINATION="414;0;"/>
<arrowlink COLOR="#cc0000" DESTINATION="Freemind_Link_330223001" ENDARROW="Default" ENDINCLINATION="265;-100;" ID="Freemind_Arrow_Link_1820207072" STARTARROW="Default" STARTINCLINATION="394;-54;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="xmag"/>
<node COLOR="#990000" CREATED="1120736547837" ID="Freemind_Link_1904587335" LINK="usage.htm#suggestsearch" MODIFIED="1120950565038" TEXT="Suggest Search">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120736547837" ID="Freemind_Link_202508893" LINK="usage.htm#suggestsearchintegrate" MODIFIED="1120950578768" TEXT="Integrating search suggest into your own page design"/>
</node>
<node COLOR="#990000" CREATED="1125413444362" ID="Freemind_Link_169235598" LINK="advanced.htm#contentimages" MODIFIED="1125415591770" TEXT="ContentImages">
<arrowlink DESTINATION="Freemind_Link_1650666261" ENDARROW="Default" ENDINCLINATION="296;0;" ID="Freemind_Arrow_Link_36065303" STARTARROW="None" STARTINCLINATION="296;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736547837" ID="Freemind_Link_49142073" LINK="usage.htm#stopwords" MODIFIED="1120916684165" TEXT="Stopwords">
<edge WIDTH="thin"/>
<arrowlink DESTINATION="Freemind_Link_1991296769" ENDARROW="Default" ENDINCLINATION="667;0;" ID="Freemind_Arrow_Link_1723885657" STARTARROW="Default" STARTINCLINATION="667;0;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="clanbomber"/>
<node COLOR="#990000" CREATED="1120737621691" ID="Freemind_Link_366864184" LINK="usage.htm#stopwordsmanual" MODIFIED="1120950594831" TEXT="Manual creation">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737615001" ID="Freemind_Link_1236511090" LINK="usage.htm#stopwordsauto" MODIFIED="1120950631934" TEXT="Automatic creation">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737634029" ID="Freemind_Link_394480766" LINK="usage.htm#stopnew" MODIFIED="1120950643070" TEXT="Add N new"/>
<node COLOR="#111111" CREATED="1120737641670" ID="Freemind_Link_1257315064" LINK="usage.htm#stoptop" MODIFIED="1120950654837" TEXT="Add top N"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736547837" ID="Freemind_Link_1697208839" LINK="usage.htm#log" MODIFIED="1120916649996" TEXT="Logging">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="attach"/>
<node COLOR="#990000" CREATED="1120736547837" ID="Freemind_Link_1699637443" LINK="usage.htm#logview" MODIFIED="1120950699551" TEXT="Log view">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120736547837" ID="Freemind_Link_743224187" LINK="usage.htm#logfilter" MODIFIED="1120950703277" TEXT="Log Filter"/>
</node>
<node COLOR="#990000" CREATED="1120736547837" ID="Freemind_Link_1117421346" LINK="usage.htm#logstatistics" MODIFIED="1120950708274" TEXT="Log statistics">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120737001089" ID="Freemind_Link_1715315373" LINK="usage.htm#edit" MODIFIED="1120985762224" TEXT="Edit and delete an index">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="pencil"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120736457998" ID="Freemind_Link_1074457221" LINK="advanced.htm" MODIFIED="1120910018400" POSITION="left" TEXT="Advanced Configuration">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="full-3"/>
<node COLOR="#00b439" CREATED="1120736503914" ID="Freemind_Link_1955658569" LINK="advanced.htm#external" MODIFIED="1120916632341" TEXT="Using external data supply&#xa;(like a web spider/crawler)">
<arrowlink DESTINATION="Freemind_Link_461318281" ENDARROW="Default" ENDINCLINATION="351;0;" ID="Freemind_Arrow_Link_1475693498" STARTARROW="Default" STARTINCLINATION="351;0;"/>
<arrowlink DESTINATION="Freemind_Link_1085496277" ENDARROW="Default" ENDINCLINATION="820;-81;" ID="Freemind_Arrow_Link_1337407737" STARTARROW="None" STARTINCLINATION="772;0;"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1120736503914" ID="Freemind_Link_1184102798" LINK="advanced.htm#definitionsfromtsep" MODIFIED="1120949014258" TEXT="Definitions made available from TSEP">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736503924" ID="Freemind_Link_1801041546" LINK="advanced.htm#tseptags" MODIFIED="1120916622246" TEXT="TSEP Tags for your code">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1120736901295" ID="Freemind_Link_1381225571" LINK="advanced.htm#cron" MODIFIED="1120949058792" TEXT="Scheduling: cron / at">
<arrowlink DESTINATION="Freemind_Link_66696603" ENDARROW="Default" ENDINCLINATION="659;-88;" ID="Freemind_Arrow_Link_1156892479" STARTARROW="Default" STARTINCLINATION="689;-88;"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1125413504078" ID="Freemind_Link_1650666261" LINK="advanced.htm#contentimages" MODIFIED="1125415586112" TEXT="ContentImages">
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120736812538" ID="Freemind_Link_461318281" LINK="extensions.htm" MODIFIED="1120910041464" POSITION="left" TEXT="Extensions &amp; Plug-ins">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="full-4"/>
</node>
<node COLOR="#0033ff" CREATED="1120736896618" ID="Freemind_Link_1385076548" LINK="faq.htm" MODIFIED="1120910192291" POSITION="right" TEXT="FAQ" VSHIFT="12">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="help"/>
<node COLOR="#00b439" CREATED="1120742921562" ID="Freemind_Link_1370249495" LINK="faq.htm#index" MODIFIED="1120916905023" TEXT="Indexing">
<arrowlink COLOR="#00cc66" DESTINATION="Freemind_Link_1577101583" ENDARROW="Default" ENDINCLINATION="174;0;" ID="Freemind_Arrow_Link_457201344" STARTARROW="Default" STARTINCLINATION="174;0;"/>
<arrowlink COLOR="#00cc66" DESTINATION="Freemind_Link_1344230774" ENDARROW="Default" ENDINCLINATION="347;-168;" ID="Freemind_Arrow_Link_1568741970" STARTARROW="Default" STARTINCLINATION="383;-191;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="pencil"/>
<node COLOR="#990000" CREATED="1120736901295" ID="Freemind_Link_1257970119" LINK="faq.htm#utfcheckapache" MODIFIED="1120948624067" TEXT="Some characters (&#xe4;,&#xf6;,&#xfc;,&#xe0;,&#xe2;) aren&apos;t displayed properly">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736901295" ID="Freemind_Link_1818955280" LINK="faq.htm#dynamicsites" MODIFIED="1120948647931" TEXT="How to index dynamic sites">
<arrowlink DESTINATION="Freemind_Link_1236880771" ENDARROW="Default" ENDINCLINATION="345;0;" ID="Freemind_Arrow_Link_450297693" STARTARROW="Default" STARTINCLINATION="345;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736901295" ID="Freemind_Link_1236880771" LINK="faq.htm#contentnotresult" MODIFIED="1120948666598" TEXT="When trying to index a (php) script the contents, not the result of the script is indexed - why?">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736416789" ID="Freemind_Link_66696603" LINK="faq.htm#cron" MODIFIED="1120949654118" TEXT="Scheduling: cron / at">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737001089" ID="Freemind_Link_1888583747" LINK="faq.htm#otherfiletypes" MODIFIED="1120948684374" TEXT="How can I change the filetypes TSEP indexes?">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120742957604" ID="Freemind_Link_330223001" LINK="faq.htm#search" MODIFIED="1120916910060" TEXT="Searching">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="xmag"/>
<node COLOR="#990000" CREATED="1120737001089" ID="Freemind_Link_1281697239" LINK="faq.htm#rank" MODIFIED="1120948714837" TEXT="What Does the &quot;rank&quot; of the pages mean">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120744754237" ID="Freemind_Link_421410845" LINK="faq.htm#other" MODIFIED="1120916914677" TEXT="Other">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1120737001089" ID="Freemind_Link_359253387" LINK="faq.htm#howlook" MODIFIED="1120948733745" TEXT="How can I change the look of TSEP to fit it best in my own layout?">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737001089" ID="Freemind_Link_1271246009" LINK="faq.htm#language" MODIFIED="1120948742637" TEXT="Creating a new language">
<arrowlink DESTINATION="Freemind_Link_1194151554" ENDARROW="Default" ENDINCLINATION="639;0;" ID="Freemind_Arrow_Link_1672667871" STARTARROW="None" STARTINCLINATION="639;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736901295" ID="Freemind_Link_1388078902" LINK="faq.htm#indexhtmfor" MODIFIED="1120948775194" TEXT="What are the index.htm (size 0k) for anyways?">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120744605033" ID="Freemind_Link_523286867" LINK="faq.htm#info" MODIFIED="1120916919023" TEXT="Information">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="idea"/>
<node COLOR="#990000" CREATED="1120736901295" ID="Freemind_Link_1110976661" LINK="faq.htm#codedocs" MODIFIED="1125836122504" TEXT="TSEP code documentation">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120744630109" ID="Freemind_Link_1242676227" MODIFIED="1120745937819" TEXT="Versions">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737001089" ID="Freemind_Link_1137558786" LINK="faq.htm#whatversion" MODIFIED="1120948801212" TEXT="&apos;What version am I running ?&apos;"/>
<node COLOR="#111111" CREATED="1120736901295" ID="Freemind_Link_1954927956" LINK="faq.htm#phpinfo" MODIFIED="1120948807751" TEXT="How do I get information about my server environment? (PHP Info)">
<arrowlink DESTINATION="Freemind_Link_1137558786" ENDARROW="Default" ENDINCLINATION="214;0;" ID="Freemind_Arrow_Link_1009757000" STARTARROW="Default" STARTINCLINATION="214;0;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736901295" ID="Freemind_Link_348689408" LINK="faq.htm#rest" MODIFIED="1120916926674" TEXT="Restrictions">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="stop"/>
<node COLOR="#990000" CREATED="1120736949505" ID="Freemind_Link_892392481" LINK="faq.htm#whatfilescanbeindexed" MODIFIED="1120948834610" TEXT="What files can TSEP index">
<arrowlink DESTINATION="Freemind_Link_1888583747" ENDARROW="Default" ENDINCLINATION="71;0;" ID="Freemind_Arrow_Link_1936574795" STARTARROW="Default" STARTINCLINATION="71;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736949505" ID="Freemind_Link_1308459396" LINK="faq.htm#restrictions" MODIFIED="1120948843613" STYLE="fork" TEXT="MySQL">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#111111" CREATED="1120736958487" ID="Freemind_Link_706327502" LINK="faq.htm#mysqlrestsortip" MODIFIED="1120948861188" TEXT="sorting log by IP"/>
<node COLOR="#111111" CREATED="1120736958487" ID="Freemind_Link_811602384" LINK="faq.htm#mysqlrestutf8" MODIFIED="1120948890150" TEXT="UTF-8 handling">
<arrowlink DESTINATION="Freemind_Link_1257970119" ENDARROW="Default" ENDINCLINATION="345;0;" ID="Freemind_Arrow_Link_1714112378" STARTARROW="Default" STARTINCLINATION="345;0;"/>
</node>
<node COLOR="#111111" CREATED="1120736958487" ID="Freemind_Link_1948300347" LINK="faq.htm#mysqlfulltextrestrictions" MODIFIED="1120948908716" TEXT="Fulltextsearch">
<node COLOR="#111111" CREATED="1120736977545" ID="Freemind_Link_1991296769" LINK="faq.htm#mysqlreststopwords" MODIFIED="1120948932981" TEXT="Stopwords">
<icon BUILTIN="clanbomber"/>
</node>
<node COLOR="#111111" CREATED="1120736983563" ID="Freemind_Link_121242268" LINK="faq.htm#minlength" MODIFIED="1120948944968" TEXT="minimum searchword length">
<icon BUILTIN="xmag"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120737001089" HGAP="30" ID="Freemind_Link_1150412520" LINK="error.htm" MODIFIED="1120910188585" POSITION="right" TEXT="Problems &amp; Errors" VSHIFT="10">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#00b439" CREATED="1120743172483" ID="Freemind_Link_1577101583" LINK="error.htm#index" MODIFIED="1120916942517" TEXT="Indexing">
<arrowlink COLOR="#00cc66" DESTINATION="Freemind_Link_1344230774" ENDARROW="Default" ENDINCLINATION="553;0;" ID="Freemind_Arrow_Link_606522880" STARTARROW="Default" STARTINCLINATION="7;169;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="pencil"/>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_166944324" LINK="error.htm#contentnotresulterror" MODIFIED="1120987121909" TEXT="Content of a script is indexed, not result">
<arrowlink DESTINATION="Freemind_Link_1818955280" ENDARROW="Default" ENDINCLINATION="398;0;" ID="Freemind_Arrow_Link_1133954158" STARTARROW="None" STARTINCLINATION="398;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_615469784" LINK="error.htm#memorylimit" MODIFIED="1120987147436" TEXT="Memory Limit Error">
<arrowlink DESTINATION="Freemind_Link_25180832" ENDARROW="Default" ENDINCLINATION="583;0;" ID="Freemind_Arrow_Link_437794627" STARTARROW="None" STARTINCLINATION="583;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_525350510" LINK="error.htm#maxexecprohibit" MODIFIED="1120987162327" TEXT="I can not index!">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_932788425" LINK="error.htm#maxexecution" MODIFIED="1120987177079" TEXT="Maximum Execution Time eceeded">
<arrowlink DESTINATION="Freemind_Link_25180832" ENDARROW="Default" ENDINCLINATION="670;0;" ID="Freemind_Arrow_Link_479090747" STARTARROW="None" STARTINCLINATION="670;0;"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120743183509" ID="Freemind_Link_1515638473" LINK="error.htm#search" MODIFIED="1120916951360" TEXT="Searching">
<arrowlink COLOR="#cc0000" DESTINATION="Freemind_Link_330223001" ENDARROW="Default" ENDINCLINATION="184;0;" ID="Freemind_Arrow_Link_1948229546" STARTARROW="Default" STARTINCLINATION="184;0;"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="xmag"/>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_858849651" LINK="error.htm#phpfileexists" MODIFIED="1120987277373" TEXT="PHP safety denies: Check if file exists">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_716383314" LINK="error.htm#jserror" MODIFIED="1120987271014" TEXT="JavaScript shows up in pages">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_856564026" LINK="error.htm#noresults" MODIFIED="1120987263172" TEXT="no results on search but indexing ok">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120744685018" ID="Freemind_Link_1045411240" LINK="error.htm#other" MODIFIED="1120916956146" TEXT="Other">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_1399666939" LINK="error.htm#timelimit" MODIFIED="1120987236023" TEXT="I get an error with &quot;set_time_limit()&quot;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120737009571" ID="Freemind_Link_243311356" LINK="error.htm#newpath" MODIFIED="1120987247019" TEXT="TSEP does not work correctly after I moved it to another path / domain" VSHIFT="-2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1120736812538" ID="Freemind_Link_1552281623" LINK="error.htm#problemsmysql" MODIFIED="1120987215364" STYLE="fork" TEXT="MySQL">
<arrowlink DESTINATION="Freemind_Link_1308459396" ENDARROW="Default" ENDINCLINATION="584;0;" ID="Freemind_Arrow_Link_1269152324" STARTARROW="Default" STARTINCLINATION="584;0;"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120737209328" ID="Freemind_Link_1914831164" LINK="links.htm" MODIFIED="1120910184009" POSITION="right" TEXT="Links">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="gohome"/>
<node COLOR="#00b439" CREATED="1120737254573" ID="Freemind_Link_1278322566" LINK="links.htm#tsep" MODIFIED="1120916969926" TEXT="TSEP">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="bookmark"/>
<node COLOR="#990000" CREATED="1120736850122" ID="Freemind_Link_266662130" MODIFIED="1120745937979" TEXT="Download TSEP">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
<node COLOR="#111111" CREATED="1120737680035" ID="Freemind_Link_615718191" LINK="http://www.tsep.info/include/latest_version.php" MODIFIED="1120917770387" TEXT="latest version direct">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1120737701566" ID="Freemind_Link_604728848" LINK="http://sourceforge.net/project/showfiles.php?group_id=107420" MODIFIED="1120917782144" TEXT="from Sourceforge">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1120736850122" ID="Freemind_Link_1877191792" LINK="http://www.tsep.info" MODIFIED="1120949463284" TEXT="Homepage">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="forward"/>
</node>
<node COLOR="#990000" CREATED="1120736850122" ID="Freemind_Link_604484823" LINK="http://sourceforge.net/projects/tsep/" MODIFIED="1120949450115" TEXT="Sourceforge Summary">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="forward"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1120736841089" ID="Freemind_Link_1010917780" LINK="links.htm#used" MODIFIED="1120985694637" TEXT="Software TSEP uses">
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="flag"/>
<node COLOR="#990000" CREATED="1120737289133" FOLDED="true" ID="Freemind_Link_1085496277" MODIFIED="1120745938019" TEXT="PHPCrawl">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737320318" ID="Freemind_Link_229931392" MODIFIED="1120745938019" TEXT="Author: Uwe Hunfeld"/>
<node COLOR="#111111" CREATED="1120738478283" ID="Freemind_Link_1642524472" LINK="http://phpcrawl.sourceforge.net/" MODIFIED="1120949469983" TEXT="WWW: http://phpcrawl.sourceforge.net/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743018101" ID="Freemind_Link_300057006" MODIFIED="1120745938029" TEXT="Purpose: Crawling / spidering along URLs"/>
</node>
<node COLOR="#990000" CREATED="1120738116573" FOLDED="true" ID="Freemind_Link_925607392" MODIFIED="1120745938039" TEXT="PHPXref">
<arrowlink DESTINATION="Freemind_Link_1110976661" ENDARROW="None" ENDINCLINATION="649;0;" ID="Freemind_Arrow_Link_1078764186" STARTARROW="Default" STARTINCLINATION="649;0;"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120738370728" ID="Freemind_Link_330781671" MODIFIED="1120745938039" TEXT="Author: Gareth Watts"/>
<node COLOR="#111111" CREATED="1120738379140" ID="Freemind_Link_905255075" LINK="http://sourceforge.net/projects/phpxref/" MODIFIED="1120949479527" TEXT="WWW: http://sourceforge.net/projects/phpxref/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743037429" ID="Freemind_Link_401621163" MODIFIED="1120745938049" TEXT="Purpose: Documentation"/>
</node>
<node COLOR="#990000" CREATED="1120737289133" FOLDED="true" ID="Freemind_Link_518506304" MODIFIED="1120745938049" TEXT="The DHTML / JavaScript Calendar">
<arrowlink DESTINATION="Freemind_Link_743224187" ENDARROW="Default" ENDINCLINATION="911;0;" ID="Freemind_Arrow_Link_1508421384" STARTARROW="None" STARTINCLINATION="911;0;"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737329030" ID="Freemind_Link_615267290" MODIFIED="1120745938059" TEXT="Author: Mihai Bazon"/>
<node COLOR="#111111" CREATED="1120738519272" ID="Freemind_Link_244122403" LINK="http://www.dynarch.com/projects/calendar/" MODIFIED="1120949484494" TEXT="WWW: http://www.dynarch.com/projects/calendar/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743045640" ID="Freemind_Link_281685686" MODIFIED="1120745938059" TEXT="Purpose: Make entering dates and times easy"/>
</node>
<node COLOR="#990000" CREATED="1120737289133" FOLDED="true" ID="Freemind_Link_1996549782" MODIFIED="1120745938069" TEXT="Sitebar Bookmark Server">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737343040" ID="Freemind_Link_1978466427" MODIFIED="1120745938079" TEXT="Author: Ondrej Brablc "/>
<node COLOR="#111111" CREATED="1120738446187" ID="Freemind_Link_300485135" LINK="http://www.sitebar.org/" MODIFIED="1120949487228" TEXT="WWW: http://www.sitebar.org/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743057047" ID="Freemind_Link_1329182423" MODIFIED="1120745938079" TEXT="Purpose: Used for translation"/>
</node>
<node COLOR="#990000" CREATED="1120737289133" FOLDED="true" ID="Freemind_Link_1986194648" MODIFIED="1120745938089" TEXT="SmartTemplate">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737350912" ID="Freemind_Link_1616756549" MODIFIED="1120745938089" TEXT="Author: Philipp von Criegern"/>
<node COLOR="#111111" CREATED="1120738424926" ID="Freemind_Link_241567614" LINK="http://www.smarttemplate.net/" MODIFIED="1120949491795" TEXT="WWW: http://www.smarttemplate.net/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743070446" ID="Freemind_Link_1037948921" MODIFIED="1120745938099" TEXT="Purpose: Template system"/>
</node>
<node COLOR="#990000" CREATED="1120737289133" FOLDED="true" ID="Freemind_Link_1523685462" MODIFIED="1120745938099" TEXT="WebSwoon - The web photographer">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120737364942" ID="Freemind_Link_456269377" MODIFIED="1120745938109" TEXT="Author: Igor Kouzmine"/>
<node COLOR="#111111" CREATED="1120738500995" ID="Freemind_Link_107864302" LINK="http://www.intellitamper.com/webswoon/" MODIFIED="1120949494218" TEXT="WWW: http://www.intellitamper.com/webswoon/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120743117684" ID="Freemind_Link_381740897" MODIFIED="1120745938109" TEXT="Purpose: Generate screenshots of URLs"/>
</node>
<node COLOR="#990000" CREATED="1120985251420" FOLDED="true" ID="Freemind_Link_976278369" MODIFIED="1120985257248" TEXT="Freemind">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1120985260523" ID="Freemind_Link_27750432" MODIFIED="1120985266722" TEXT="Author: Freemind Team"/>
<node COLOR="#111111" CREATED="1120985267733" ID="Freemind_Link_1479982674" LINK="http://freemind.sourceforge.net/" MODIFIED="1120985331595" TEXT="WWW: http://freemind.sourceforge.net/">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120985275524" ID="Freemind_Link_942785073" MODIFIED="1120985305688" TEXT="Purpose: Creating an overview of the documentation. "/>
</node>
<node COLOR="#990000" CREATED="1125764150305" FOLDED="true" ID="Freemind_Link_970404944" MODIFIED="1125764154752" TEXT="Comment">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1125764162873" ID="Freemind_Link_187570784" MODIFIED="1125764792979" TEXT="Author: Alex"/>
<node COLOR="#111111" CREATED="1120985267733" ID="Freemind_Link_1184410812" LINK="http://www.mylittlehomepage.net/comment_script.html" MODIFIED="1125764311327" TEXT="WWW: http://www.mylittlehomepage.net/comment_script.html">
<icon BUILTIN="forward"/>
</node>
<node COLOR="#111111" CREATED="1120985275524" ID="Freemind_Link_1037243025" MODIFIED="1125764278410" TEXT="Purpose: Possibility to add comments our online documentation"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1120738623171" ID="Freemind_Link_329283205" LINK="help.htm" MODIFIED="1120910198670" POSITION="left" TEXT="Help TSEP">
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="idea"/>
<node COLOR="#00b439" CREATED="1120736856280" ID="Freemind_Link_1639399297" LINK="help.htm#donate" MODIFIED="1120916873608" TEXT="Donate">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1120738631253" ID="Freemind_Link_1194151554" LINK="help.htm#translate" MODIFIED="1120916879186" TEXT="Translate">
<arrowlink DESTINATION="Freemind_Link_1996549782" ENDARROW="Default" ENDINCLINATION="591;0;" ID="Freemind_Arrow_Link_1485780433" STARTARROW="None" STARTINCLINATION="591;0;"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1120738634307" ID="Freemind_Link_319193468" LINK="help.htm#code" MODIFIED="1120916884313" TEXT="Develop / Code">
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
</node>
</map>
