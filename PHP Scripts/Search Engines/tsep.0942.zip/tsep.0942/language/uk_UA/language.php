<?php

/* following will be filled automatically by SubVersion!

Do not change by hand!

$LastChangedDate: 2005-06-25 17:39:06 +0200 (Sa, 25 Jun 2005) $

@lastedited $LastChangedBy: olaf $

$LastChangedRevision: 198 $
*/
$tsep_lng['above_values'] = <<<_P
значення вище
_P;

$tsep_lng['add'] = <<<_P
додати
_P;

$tsep_lng['all'] = <<<_P
все
_P;

$tsep_lng['assigned_indexingprofiles'] = <<<_P
назначені профілі індексування
_P;

$tsep_lng['button_search'] = <<<_P
Пошук
_P;

$tsep_lng['click_here_to_open'] = <<<_P
Перейдіть на посилання для того щоб відкрити сторінку
_P;

$tsep_lng['close_this_window'] = <<<_P
Закриває це вікно
_P;

$tsep_lng['config_absPath'] = <<<_P
Визначіть абсолютний шлях до прикладів TSEP: якщо файл search.php розміщено у /home/www/php/tsepsearch/search.php він буде виглядати як '/home/www/php/tsepsearch'
_P;

$tsep_lng['config_Color_1'] = <<<_P
Перший з двох кольорів (сторк) для довгих списків
_P;

$tsep_lng['config_Color_2'] = <<<_P
Другий з двох кольорів (сторк) для довгих списків
_P;

$tsep_lng['config_Date_Style'] = <<<_P
Як відображати дату(у стилі PHP ви можете використовувати D, l, M & F). Вивод буде на мові вказаній нижче. Наприклад: Англійський стиль: 'l, F d Y h:i a' Німецький стиль: 'l, d. F Y, G:i'
_P;

$tsep_lng['config_dir_exclude'] = <<<_P
Введіть каталоги для виключення
_P;

$tsep_lng['config_ext_include'] = <<<_P
Розщирення файлів для включення
_P;

$tsep_lng['config_file_exclude'] = <<<_P
Введіть файли для виключення:
_P;

$tsep_lng['config_group_general'] = <<<_P
Загальне
_P;

$tsep_lng['config_group_lists'] = <<<_P
Списки
_P;

$tsep_lng['config_group_lists_colors'] = <<<_P
Кольори списків
_P;

$tsep_lng['config_group_lists_limits'] = <<<_P
Кордони списків
_P;

$tsep_lng['config_group_logging'] = <<<_P
журналювання
_P;

$tsep_lng['config_group_visible2enduser'] = <<<_P
Інтерфейс користувача
_P;

$tsep_lng['config_group_visible2enduser_range'] = <<<_P
Кордони
_P;

$tsep_lng['config_group_visible2enduser_results'] = <<<_P
Результати
_P;

$tsep_lng['config_group_visible2enduser_searchsuggest'] = <<<_P
Допомога у пошуку
_P;

$tsep_lng['config_group_visible2enduser_search'] = <<<_P
Пошук
_P;

$tsep_lng['config_Hour_Difference'] = <<<_P
різниця у часі між часом сервера та міцевим. Змініть відповідно
_P;

$tsep_lng['config_calc_hits_method'] = <<<_P
Який спосіб обчислень для номерів сторінок потрібно повертати?
_P;

$tsep_lng['config_How_Many_CharsAfter_Hit'] = <<<_P
Скільки симолів показувати після першого натискання?
_P;

$tsep_lng['config_How_Many_CharsBefore_Hit'] = <<<_P
Скільки симолів показувати перед першим натисканням?
_P;

$tsep_lng['config_Logging_result_links'] = <<<_P
Журнал кліків на результатах пошуку?
_P;

$tsep_lng['config_Logging_search_term'] = <<<_P
Журнал термінів для пошуку?
_P;

$tsep_lng['page_additional_info'] = <<<_P
Додаткова інформація
_P;

$tsep_lng['ss_search_term'] = <<<_P
Запит
_P;

$tsep_lng['ss_search_term_hover'] = <<<_P
Попередні запити пошуку
_P;

$tsep_lng['ss_popular'] = <<<_P
Поп.
_P;

$tsep_lng['ss_popular_hover'] = <<<_P
Кількість разів яку використовували запит(популярність)
_P;

$tsep_lng['ss_returned_pages'] = <<<_P
ВС
_P;

$tsep_lng['ss_returned_pages_hover'] = <<<_P
Кількість сторінок, яка повертається запитом
_P;

$tsep_lng['error_index_nothing'] = <<<_P
Порожньо(тобто немає що індексувати): �
_P;

$tsep_lng['error_empty_files'] = <<<_P
файли порожні(тобто немає що індексувати)
_P;

?>
