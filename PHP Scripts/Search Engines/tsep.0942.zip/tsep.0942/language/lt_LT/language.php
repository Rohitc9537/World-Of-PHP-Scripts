<?php

/* following will be filled automatically by SubVersion!

Do not change by hand!

$LastChangedDate: 2005-08-20 16:05:25 +0200 (Sa, 20 Aug 2005) $

@lastedited $LastChangedBy: olaf $

$LastChangedRevision: 291 $
*/
$tsep_lng['all'] = <<<_P
visi
_P;

$tsep_lng['button_search'] = <<<_P
Ieškoti
_P;

$tsep_lng['click_here_to_open'] = <<<_P
Spragtelkite ant šios nuorodos ir atsidarys puslapis
_P;

$tsep_lng['close_this_window'] = <<<_P
Uždarys šį langą
_P;

$tsep_lng['config_check_file_exists'] = <<<_P
Ar tikrinti bylų, esančių rezultate, egzistavimą? Jei taip, paieška vyks truputį lėčiau, tačiau rezultate bus tik egzistuojančios bylos. Turėkite omenyje, kad tai veikia tiktai kai php.ini byloje yra įjungtas allow_url_open! Galbūt jums vertėtų nenaudoti šios savybės?
_P;

$tsep_lng['config_Color_1'] = <<<_P
Pirma kaitaliojama eilutės spalva, naudojama ilguose sąrašuose
_P;

$tsep_lng['config_Color_2'] = <<<_P
Antra kaitaliojama eilutės spalva, naudojama ilguose sąrašuose

_P;

$tsep_lng['config_Date_Style'] = <<<_P
Datos formatas (PHP stiliumi, galima naudoti D, l, M ir F). Rezultato kalba bus tokia, kokia nurodyta viršuje. Pavyzdžiai: Angliškas stilius: 'l, F d Y h:i a', Vokiškas stilius 'l, d. F Y, G:i'
_P;

$tsep_lng['config_dir_exclude'] = <<<_P
Išbrauktini katalogai:
_P;

$tsep_lng['config_ext_include'] = <<<_P
Įtrauktini bylų prievardžiai:
_P;

$tsep_lng['config_file_exclude'] = <<<_P
Išbrauktinos bylos:
_P;

$tsep_lng['config_group_general'] = <<<_P
Bendri
_P;

$tsep_lng['config_group_lists'] = <<<_P
Sąrašai
_P;

$tsep_lng['config_group_lists_colors'] = <<<_P
Spalvos
_P;

$tsep_lng['config_group_lists_limits'] = <<<_P
Ribos
_P;

$tsep_lng['config_group_logging'] = <<<_P
Įrašai
_P;

$tsep_lng['config_group_visible2enduser'] = <<<_P
Naudotojo sąsaja
_P;

$tsep_lng['config_group_visible2enduser_range'] = <<<_P
Ribos
_P;

$tsep_lng['config_group_visible2enduser_results'] = <<<_P
Rezultatai
_P;

$tsep_lng['config_group_visible2enduser_search'] = <<<_P
Paieškos procesas
_P;

$tsep_lng['config_Hour_Difference'] = <<<_P
Laiko skirtumas valandomis tarp serverio laiko ir vietos laiko. Atitinkamai nustatyti.
_P;

$tsep_lng['config_Logging'] = <<<_P
Ar norite įrašinėti viską?
_P;

$tsep_lng['config_Logging_IP'] = <<<_P
Įrašinėti IP adresus?
_P;

$tsep_lng['config_Logging_result_links'] = <<<_P
Įrašinėti spragtelėjimus pele ant paieškos rezultatų?
_P;

$tsep_lng['config_Logging_search_term'] = <<<_P
Įrašinėti paieškos užklausas?
_P;

$tsep_lng['config_maxRows_logview'] = <<<_P
Kiek žurnalo įrašų norite matyti viename puslapyje?
_P;

$tsep_lng['config_Use_Debug_Print'] = <<<_P
Tik programuotojams: ar norite naudoti debugprint() funkciją?<br />(rekomenduojame išjungti, jeigu TSEP yra normaliai naudojamas)
_P;

$tsep_lng['configuration'] = <<<_P
Nustatymai
_P;

$tsep_lng['copyright'] = <<<_P
Autorinės teisės saugomos įstatymų.
_P;

$tsep_lng['create_new_index'] = <<<_P
Sukurti naują indeksą
_P;

$tsep_lng['day_friday'] = <<<_P
Penktadienis
_P;

$tsep_lng['day_friday_short'] = <<<_P
p
_P;

$tsep_lng['day_monday'] = <<<_P
Pirmadienis
_P;

$tsep_lng['day_monday_short'] = <<<_P
pr
_P;

$tsep_lng['day_saturday'] = <<<_P
Šeštadienis
_P;

$tsep_lng['day_saturday_short'] = <<<_P
š
_P;

$tsep_lng['day_sunday'] = <<<_P
Sekmadienis
_P;

$tsep_lng['day_sunday_short'] = <<<_P
s
_P;

$tsep_lng['day_thursday'] = <<<_P
Ketvirtadienis
_P;

$tsep_lng['day_thursday_short'] = <<<_P
k
_P;

$tsep_lng['day_tuesday'] = <<<_P
Antradienis
_P;

$tsep_lng['day_tuesday_short'] = <<<_P
a
_P;

$tsep_lng['day_wednesday'] = <<<_P
Trečiadienis
_P;

$tsep_lng['day_wednesday_short'] = <<<_P
T
_P;

$tsep_lng['delete'] = <<<_P
pašalinti
_P;

$tsep_lng['filename'] = <<<_P
bylos pavadinimas
_P;

$tsep_lng['filter'] = <<<_P
filtras
_P;

$tsep_lng['found_no_pages'] = <<<_P
Puslapių nerasta.
_P;

$tsep_lng['help'] = <<<_P
Pagalba
_P;

$tsep_lng['help_first_page'] = <<<_P
į pirmą puslapį
_P;

$tsep_lng['help_last_page'] = <<<_P
į paskutinį puslapį
_P;

$tsep_lng['help_next_page'] = <<<_P
į kitą puslapį
_P;

$tsep_lng['help_previous_page'] = <<<_P
į ankstesnį puslapį
_P;

$tsep_lng['index_edit_date'] = <<<_P
Paskutinė indekso redakcija:
_P;

$tsep_lng['index_edit_head'] = <<<_P
Keisti duomenis, įrašytus į indeksą
_P;

$tsep_lng['index_edit_title'] = <<<_P
Indekso keitimas (detalus)
_P;

$tsep_lng['index_overview_click_title'] = <<<_P
Redaguoti puslapio nupasakojimą.
_P;

$tsep_lng['index_overview_click_url'] = <<<_P
Rodyti puslapį naršyklės lange.
_P;

$tsep_lng['index_overview_title'] = <<<_P
Indekso apžvalga (trumpa)
_P;

$tsep_lng['indexed_words'] = <<<_P
Peržiūrėti visus šiuo metu esančius indeksus (gali būti labai daug!)
_P;

$tsep_lng['indexer_title'] = <<<_P
Indeksatorius
_P;

$tsep_lng['logview_contents'] = <<<_P
Įrašas
_P;

$tsep_lng['logview_time_of_entry'] = <<<_P
Įrašo laikas
_P;

$tsep_lng['logview_type_1'] = <<<_P
Užklausa paieškai
_P;

$tsep_lng['mandatory'] = <<<_P
* Šį lauką užpildyti yra privaloma.
_P;

$tsep_lng['month_april'] = <<<_P
Balandis
_P;

$tsep_lng['month_april_short'] = <<<_P
Bal
_P;

$tsep_lng['month_august'] = <<<_P
Rugpjūtis
_P;

$tsep_lng['month_august_short'] = <<<_P
Rugp
_P;

$tsep_lng['month_december'] = <<<_P
Gruodis
_P;

$tsep_lng['month_december_short'] = <<<_P
Gr
_P;

$tsep_lng['month_february'] = <<<_P
Vasaris
_P;

$tsep_lng['month_february_short'] = <<<_P
Vas
_P;

$tsep_lng['month_january'] = <<<_P
Sausis
_P;

$tsep_lng['month_january_short'] = <<<_P
Sau
_P;

$tsep_lng['month_july'] = <<<_P
Liepa
_P;

$tsep_lng['month_july_short'] = <<<_P
Lie
_P;

$tsep_lng['month_june'] = <<<_P
Birželis
_P;

$tsep_lng['month_june_short'] = <<<_P
Bir
_P;

$tsep_lng['month_march'] = <<<_P
Kovas
_P;

$tsep_lng['month_march_short'] = <<<_P
Kov
_P;

$tsep_lng['month_may'] = <<<_P
Gegužė
_P;

$tsep_lng['month_may_short'] = <<<_P
Geg
_P;

$tsep_lng['month_november'] = <<<_P
Lapkritis
_P;

$tsep_lng['month_november_short'] = <<<_P
Lap
_P;

$tsep_lng['month_october'] = <<<_P
Spalis
_P;

$tsep_lng['month_october_short'] = <<<_P
Spa
_P;

$tsep_lng['month_september'] = <<<_P
Rugsėjis
_P;

$tsep_lng['month_september_short'] = <<<_P
Rugs
_P;

$tsep_lng['more_than_four'] = <<<_P
Įveskite 4 ar daugiau simbolių eilutę.
_P;

$tsep_lng['page_title'] = <<<_P
Puslapio pavadinimas:
_P;

$tsep_lng['page_url'] = <<<_P
Puslapio adresas:
_P;

$tsep_lng['results'] = <<<_P
Rezultatai
_P;

$tsep_lng['search_tips'] = <<<_P
Patarimai kaip ieškoti
_P;

$tsep_lng['search_tips_head'] = <<<_P
Patarimai, kaip naudoti TSEP efektyviai
_P;

$tsep_lng['search_tips_help'] = <<<_P
atidarys pagalbos puslapį naujame lange
_P;

$tsep_lng['search_tips_se1'] = <<<_P
apple banana
_P;

$tsep_lng['search_tips_se2'] = <<<_P
+apple +banana
_P;

$tsep_lng['search_tips_se3'] = <<<_P
+apple macintosh
_P;

$tsep_lng['search_tips_se4'] = <<<_P
+apple -macintosh
_P;

$tsep_lng['search_tips_se5'] = <<<_P
+apple +(>pie <strudel)
_P;

$tsep_lng['search_tips_se6'] = <<<_P
apple*
_P;

$tsep_lng['search_tips_se7'] = <<<_P
"keli žodžai"
_P;

$tsep_lng['search_tips_title'] = <<<_P
Patarimai kaip ieškoti
_P;

$tsep_lng['search_took'] = <<<_P
Paieška tesėsi 
_P;

$tsep_lng['searched_site_for'] = <<<_P
Ieškota
_P;

$tsep_lng['seconds'] = <<<_P
sek.
_P;

$tsep_lng['show_x_results_per_page'] = <<<_P
/ puslapiui
_P;

$tsep_lng['sort_asc'] = <<<_P
išrūšiuoja A -> Z, seniausias -> naujausias
_P;

$tsep_lng['sort_desc'] = <<<_P
išrūšiuoja Z -> A, naujausias -> seniausias
_P;

$tsep_lng['tsep'] = <<<_P
TSEP - Paieškos Sistemos Projektas
_P;

$tsep_lng['type'] = <<<_P
tipas
_P;

$tsep_lng['update'] = <<<_P
pakeisti
_P;

$tsep_lng['value_already_exists'] = <<<_P
Tokia reikšmė jau yra
_P;

$tsep_lng['version'] = <<<_P
Tai yra versija
_P;

$tsep_lng['config_group_indexer_miscellaneous'] = <<<_P
Įvairūs
_P;

$tsep_lng['filter_filterbutton'] = <<<_P
Naudoti filtrą
_P;

$tsep_lng['filter_filterbutton_Remove_Filter'] = <<<_P
Pašalinti filtrą
_P;

$tsep_lng['filter_logviewtype_all'] = <<<_P
Visi
_P;

$tsep_lng['filter_from'] = <<<_P
Nuo:
_P;

$tsep_lng['filter_to'] = <<<_P
Kam:
_P;

$tsep_lng['setup_step1'] = <<<_P
1. Įvadas
_P;

$tsep_lng['setup_step2'] = <<<_P
2. Duomenų bazės parametrai
_P;

$tsep_lng['setup_step3'] = <<<_P
3. Sistemos patikrinimas
_P;

$tsep_lng['setup_step5'] = <<<_P
5. Diegimas
_P;

$tsep_lng['setup_step6'] = <<<_P
6. Apibendrinimas
_P;

$tsep_lng['setup_Quit'] = <<<_P
Išeiti
_P;

$tsep_lng['setup_ContinueSetup'] = <<<_P
Tęsti įdiegimą
_P;

$tsep_lng['setup_IwantToContinue'] = <<<_P
Apsigalvojau, norėčiau tęsti...
_P;

$tsep_lng['setup_ToPreviousStep'] = <<<_P
Grįžk prie ankstesnio žingsnio...
_P;

$tsep_lng['setup_Previous'] = <<<_P
Ankstesnis
_P;

$tsep_lng['setup_Next'] = <<<_P
Kitas
_P;

$tsep_lng['setup_ToNextStep'] = <<<_P
Einam prie kito žingsnio.
_P;

$tsep_lng['setup_IWantToQuitInstalling'] = <<<_P
Noriu nutraukti TSEP diegimą.
_P;

$tsep_lng['setup_Cancel'] = <<<_P
Atšaukti
_P;

$tsep_lng['upload_complete'] = <<<_P
Siuntimas sėkmingai baigtas.
_P;

$tsep_lng['delete_complete'] = <<<_P
Byla pašalinta!
_P;

$tsep_lng['back'] = <<<_P
atgal
_P;

$tsep_lng['close'] = <<<_P
uždaryto
_P;

?>
