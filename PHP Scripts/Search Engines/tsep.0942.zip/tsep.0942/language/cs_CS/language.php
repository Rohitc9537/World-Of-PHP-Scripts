<?php
$tsep_lng['SubVersion_Automated_Information'] = <<<_TSEP
following will be filled automatically by SubVersion - our version control system.
Do NOT change by hand! Do NOT translate - just leave as you find it!
$LastChangedDate: 2005-05-19 17:44:30 +0200 (Do, 19 Mai 2005) $
@lastedited $LastChangedBy: olaf $
$LastChangedRevision: 56 $
_TSEP;



?>