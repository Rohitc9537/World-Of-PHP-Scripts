<?php
// this file contains the translation between language-abbr and language
//
// created by
// Manfred Jedlicka
//
// following will be filled automatically by SubVersion!
// Do not change by hand!
//  $LastChangedDate: 2005-07-26 23:56:58 +0200 (Tue, 26 Jul 2005) $
//  @lastedited $LastChangedBy: manfred $
//  $LastChangedRevision: 282 $
//
//
// created for
// tsep version 0941 and website
//
//-----------------------------------------------

$tsep_language['cn_CN'] = '';
$tsep_language['cs_CS'] = '';
$tsep_language['de_DE'] = 'Deutsch';
$tsep_language['dk_DK'] = '';
$tsep_language['en_US'] = 'English';
$tsep_language['es_ES'] = 'Español';
$tsep_language['es_MX'] = '';
$tsep_language['fi_FI'] = '';
$tsep_language['fr_FR'] = 'Français';
$tsep_language['gr_GR'] = '';
$tsep_language['he_HE'] = '';
$tsep_language['hu_HU'] = '';
$tsep_language['id_ID'] = '';
$tsep_language['il_IL'] = '';
$tsep_language['it_IT'] = 'Italiano';
$tsep_language['lt_LT'] = '';
$tsep_language['nl_NL'] = 'Nederlands';
$tsep_language['no_NO'] = 'Norsk';
$tsep_language['pl_PL'] = '';
$tsep_language['pt_BR'] = 'Português (Brasil)';
$tsep_language['pt_PT'] = '';
$tsep_language['ro_RO'] = '';
$tsep_language['ru_RU'] = '';
$tsep_language['sv_SE'] = '';
$tsep_language['tr_TR'] = '';
$tsep_language['uk_UA'] = '';

?>
