<?php
/**
* Show how long it took to to whatever was done (built page, query database). Code recycling
*
* @author Olaf Noehring
*
* following will be filled automatically by SubVersion!
* Do not change by hand!
*  $LastChangedDate: 2005-05-17 17:18:57 +0200 (Di, 17 Mai 2005) $
*  @lastedited $LastChangedBy: olaf $
*  $LastChangedRevision: 41 $
*
*/
?>
<div class="SearchForWhatTimeNeeded">
	<?php echo $tsep_lng['search_took']; ?> <div class="SearchPage"><?php print $time_taken ?></div> <?php echo $tsep_lng['seconds'];?>.
</div>	
