<?php
/**
* display how much time was needed for indexing
*
* @author Olaf Noehring
*
* following will be filled automatically by SubVersion!
* Do not change by hand!
*  $LastChangedDate: 2005-05-17 17:18:57 +0200 (Di, 17 Mai 2005) $
*  @lastedited $LastChangedBy: olaf $
*  $LastChangedRevision: 41 $
*
*/

?>
<span class="TimeTaken"><?php echo $time_taken;?></span> <?php echo $tsep_lng['seconds'];?>
