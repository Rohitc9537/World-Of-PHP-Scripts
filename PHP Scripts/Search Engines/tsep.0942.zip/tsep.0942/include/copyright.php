<?php
/**
* output copyright / powered by notice. Code recycling
*
* @author Olaf Noehring
*
* following will be filled automatically by SubVersion!
* Do not change by hand!
*  $LastChangedDate: 2005-06-11 18:55:44 +0200 (Sa, 11 Jun 2005) $
*  @lastedited $LastChangedBy: toon $
*  $LastChangedRevision: 134 $
*
*/

?>
<div class="tsepCopyright">
	<a href="http://tsep.sourceforge.net/" title="<?php echo $tsep_lng['version'];?> <?php require ( $tsep_config["absPath"]."/include/tsepversion.txt" ); ?>. <?php echo $tsep_lng['help_copyright']; ?>." target="_blank" class="tsepCopyright">
	<?php echo $tsep_lng['powered_by']; ?> <?php echo $tsep_lng['tsep'];?></a><!-- //Please do not change the this text and the link to the TSEP site -->
</div>
