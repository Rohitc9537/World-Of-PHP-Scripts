<?php
/**
* actually write the color to a div tag
*
* @author Olaf Noehring
*
* following will be filled automatically by SubVersion!
* Do not change by hand!
*  $LastChangedDate: 2005-07-11 18:56:06 +0200 (Mo, 11 Jul 2005) $
*  @lastedited $LastChangedBy: olaf $
*  $LastChangedRevision: 254 $
*
*/

?>
 style="background-color:<?php  //set changing background color for this div tag
        echo $tsep_config['config_Color'];
        require( $tsep_config["absPath"]."/include/colorcycle.php" ); 
?>"