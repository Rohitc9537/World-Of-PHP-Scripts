-----------------------------------------------------------------------------------------
---    AZBANNER v1.0 by zoerb.net - Internetdienste - (c) - Alle Rechte vorbehalten   ---
---		  eMail: mail@zoerb.net - Phone/Fax: 0700 ZOERBNET (96372638) 	        ---
-----------------------------------------------------------------------------------------
--- Dieses Script wurde zu �bungszwecken programmiert, es wird keinerlei Haftung f�r  ---
---     evtl. Sch�den, durch den Betrieb dieses Scriptes �bernommen. Keine Gew�hr     ---
---               f�r Bedienkomfort, Funktionalit�t und Systemintegrit�t.             ---
-----------------------------------------------------------------------------------------
---                             http://www.zoerb.net 			     		        ---
-----------------------------------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------------------------------
- Anpassen der Variabeln in config.php
- Upload der Dateien auf den Server
- Aufrufen von admin/install.php -> Datenbankstruktur wird erstellt
- L�schen von admin/install.php
-----------------------------------------------------------------------------------------
FERTIG !
-----------------------------------------------------------------------------------------
Zur Anzeige der Banner showbanner.php aufrufen oder in eine beliebige php-Datei einbinden.  
Es ist ratsam den Zugriff auf das Unterverzeichnis admin zu sch�tzen (z. Bsp. mit htaccess). 

Das Entfernen von Copyrighthinweisen aus dem Script ist untersagt, weiterhin sind �nderungen
am Layout (Bilder) der Administrationsoberfl�che nur mit Zustimmung von zoerb.netzul�ssig. 

Die Weitergabe dieses Scripts ist erw�nscht und uneingeschr�nkt gestattet.

Viel Spass
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
English-Manual:

INSTALLATION
-----------------------------------------------------------------------------------------
- change the variables in config.php to fit your needs
- upload all files to your webserver
- load admin/install.php -> database is created
- delete admin/install.php
-----------------------------------------------------------------------------------------
DONE !

To show the banners, simply load showbanner.php or include it to any php-file. 
Due to security reasons, it is recommended, to protect the subdirectorie admin
(for example with htaccess).

You are not allowed to remove Copyright-Remarks or change the layout auf the admin pages 
but to redistribute this package.

Have Fun
-----------------------------------------------------------------------------------------
