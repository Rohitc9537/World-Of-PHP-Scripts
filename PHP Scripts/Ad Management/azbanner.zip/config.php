<?php
// DATENBANK VERBINDUNG ---------------------------------------
$dbserver="localhost";
$db="test";
$dbuser="root";
$dbpass="";
$ad_table="az_banner";

?>