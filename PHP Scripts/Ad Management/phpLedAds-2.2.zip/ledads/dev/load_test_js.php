<?php
	for($i = 0; $i < 500; $i++) {
		?>
			<script src="/dev/ledads/ledad_js.php?<?=$i++?>"></script>
			<script src="/dev/ledads/ledad_js.php?<?=$i++?>"></script><br>
		<?
	}
?>