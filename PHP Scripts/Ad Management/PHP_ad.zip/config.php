<?php
/*
          //////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
         //////////////// Simple php banner ad rotator. \\\\\\\\\\\\\\\\
        ////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
       /// Copyright (c) 2005 Sam Clarke                              \\\\
      //// All Rights Reserved.                                       \\\\\
     /////                                                            \\\\\\
    ////// if you need help email at admin@free-php.org.uk            \\\\\\\
   ///////                                                            \\\\\\\\
  //////// Make sure you change                                       \\\\\\\\\
 /////////                                                            \\\\\\\\\\
////////// $password = 'admin';                                       //////////
\\\\\\\\\\ $username = 'username';                                    /////////
 \\\\\\\\\                                                            ////////
  \\\\\\\\ to your username and password eg. if your password is pass ///////
   \\\\\\\ and your username is user change it to this                //////
    \\\\\\                                                            /////
     \\\\\ $password = 'pass';                                        ////
      \\\\ $username = 'user';                                        ///
       \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////
        \\\ as you can see i had a little to much time on my hands. ///
         \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////////////////
*/

$password = 'admin';
$username = 'admin';

/*
          /////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
         ///////////////////////// Part 2 of config \\\\\\\\\\\\\\\\\\\\\\\\\
        ///////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
       /// make sure you change this to your default ad                    \\\\
      //// $default_ad_url = 'http://your-site.com/advitise-with-us.html'; \\\\\
     ///// $default_ad_banner = 'http://your-site.com/banner.png';         \\\\\\
    //////                                                                 \\\\\\\
   ///////                                                                 \\\\\\\\
  //////// and change this to where the file ad.php is                     \\\\\\\\\
 ///////// $adphpfile = 'http://yoursite/dir/ad.php                        \\\\\\\\\\
//////////                                                                 //////////
\\\\\\\\\\                                                                 /////////
 \\\\\\\\\                                                                 ////////
  \\\\\\\\ ############################################################### ///////
   \\\\\\\ I hope you like and use this script :) good luck with your site //////
    \\\\\\ and if your ever bored have a look at my site free-php.org.uk   /////
     \\\\\ and make sure to have lots of fun with your site :)             ////
      \\\\                                                                 ///
       \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////////////////////
        \\\                                                              ///
         \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////
*/

$default_ad_url         = 'http://your-site.com/advitise-with-us.html';
$default_ad_banner      = 'http://your-site.com/banner.png';
$phpclickfile           = 'http://localhost/php_n_banner_rotator/click.php';
$adphpfile              = 'http://localhost/php_n_banner_rotator/ad.php';
?>