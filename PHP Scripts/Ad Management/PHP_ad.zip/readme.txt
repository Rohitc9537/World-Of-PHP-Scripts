Copyright (c) 2005 free-php.org.uk.
All rights reserved.

#############################################################################
#             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            #
#           ~ THANK YOU FOR DOWNLOADING THIS PHP BANNER AD SCRIPT ~         #
#             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            #
#                                                                           #
# 1. HOW TO USE                                                             #
# 2. WARRANTY                                                               #
# 3. HELP                                                                   #
# 4. DISTRIBUTE                                                             #
#                                                                           #
#############################################################################

1. HOW TO USE
Just upload all the files in the zip file to your cgi-bin and edit the file 
called config.php thats it but if you need any help please email me at
admin@free-php.org.uk.

2. WARRANTY
For my protection, I want to make certain that everyone understands that 
there is no warranty for this free script. If the script is modified by 
someone else and passed on, I want its recipients to know that what they 
have is not the original, so that any problems introduced by others will not
reflect on my reputations.

3. HELP
If you need help you can search on google for some or you can email me at
admin@free-php.org.uk and i will try to get back to you as soon as possible,
i hope you like this script.

4. DISTRIBUTE
You can distribute this script freely but you cannot charge for it or
claim it as your own. You do not have the copyright for this script but
you do have the right to distribute it. You cannot change for it and you 
can only distribute it as you got it. 
