function phpads_deliverActiveX(content)
{
	document.write(content);	
}