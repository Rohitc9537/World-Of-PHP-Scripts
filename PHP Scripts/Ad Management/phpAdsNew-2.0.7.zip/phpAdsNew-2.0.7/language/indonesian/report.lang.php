<?php // $Revision: 1.1.2.4 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2005 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Menghasilkan pandangan umum tentang sejarah dari Penerbit yang dipilih. Laporan ini akan diekspor dalam format CSV untuk digunakan dalam Spreadsheet.";
$GLOBALS['strPluginCampaign'] 		= "Menghasilkan pandangan umum tentang sejarah dari kampanye yang dipilih. Laporan ini akan diekspor dalam format CSV untuk digunakan dalam Spreadsheet.";
$GLOBALS['strPluginClient'] 		= "Menghasilkan pandangan umum tentang sejarah dari Pemasang Iklan yang dipilih. Laporan ini akan diekspor dalam format CSV untuk digunakan dalam Spreadsheet.";
$GLOBALS['strPluginGlobal'] 		= "Menghasilkan pandangan umum tentang sejarah global. Laporan ini akan diekspor dalam format CSV untuk digunakan dalam Spreadsheet.";
$GLOBALS['strPluginZone'] 		= "Menghasilkan pandangan umum tentang sejarah dari zona yang dipilih. Laporan ini akan diekspor dalam format CSV untuk digunakan dalam Spreadsheet.";

?>
