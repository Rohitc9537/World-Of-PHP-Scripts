<?php // $Revision: 2.0.2.2 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2005 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Genereer een overzicht van de geselecteerde uitgever. Het rapport wordt geexporteerd als CSV voor gebruik in een spreadsheet.";
$GLOBALS['strPluginCampaign'] 		= "Genereer een overzicht van de geselecteerde campagne. Het rapport wordt geexporteerd als CSV voor gebruik in een spreadsheet.";
$GLOBALS['strPluginClient'] 		= "Genereer een overzicht van de geselecteerde adverteerder. Het rapport wordt geexporteerd als CSV voor gebruik in een spreadsheet.";
$GLOBALS['strPluginGlobal'] 		= "Genereer een globaal overzicht. Het rapport wordt geexporteerd als CSV voor gebruik in een spreadsheet.";
$GLOBALS['strPluginZone'] 		= "Genereer een overzicht van de geselecteerde zone. Het rapport wordt geexporteerd als CSV voor gebruik in een spreadsheet.";

?>