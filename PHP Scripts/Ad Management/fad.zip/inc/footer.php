<?php
/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/
@mysql_close();
?>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td><div align="center"></div></td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#999933">
  <tr> 
    <td><div align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><a href="http://www.free-php-scripts.net" target="_blank" >Support Site</a> - <a href="terms.php"> TOS </a></strong></font></div>      <div align="center"></div></td>
  </tr>
</table>
</body>
</html>