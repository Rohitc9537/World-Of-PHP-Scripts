<?php
/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/


//Include header
require_once ("inc/header.php"); 


?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="25%" valign="top">
      <?php // Get the side menu
	  require_once('inc/side.php');?>
    </td>
    <td width="90%" valign="top"> 
      <table width="100%" border="0" cellspacing="5" cellpadding="5">
        <tr>
          <td>
		<p align="justify"><strong>These are some links that FAD&reg; would like to introduce you. All of them are 100% free without catches. </strong></p>
            <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#00CCFF">
              <tr> 
                <td bgcolor="#99CC99"><strong>Complete 
                  Shopping Cart System, OSCommerce:</strong></td>
              </tr>
              <tr> 
                <td><div align="center"><strong><a href="http://www.oscommerce.com/"  target="_blank">Oscommerce</a></strong></div></td>
              </tr>
              <tr> 
                <td bgcolor="#99CC99"><strong>Complete 
                  Web Forums:</strong></td>
              </tr>
              <tr>
                <td><div align="center"><strong><a href="http://www.PHPBB.com"  target="_blank">PhpBB</a> - <a href="http://www.YourPHPBB.com" target="_blank">PHPBB Directory</a> </strong></div></td>
              </tr>
              <tr> 
                <td bgcolor="#99CC99"><strong>Free 
                  Image Hosting:</strong></td>
              </tr>
              <tr> 
                <td><div align="center"><strong><a href="http://www.sonimager.com"  target="_blank">Sonimager</a> - <a href="http://www.MyImage.us" target="_blank">MyImage.us [Free Mirosoft Publishing Wizrd]</a> </strong></div></td>
              </tr>
              <tr> 
                <td bgcolor="#99CC99"><strong>Free 
                  PHP Support Forum (Fad&reg; and other scripts):</strong></td>
              </tr>
              <tr>  
                <td><div align="center"><strong><a href="http://www.HelpPHP.net"  target="_blank">Free 
                    PHP Scripts</a> - <a href="http://www.phpskills.com" target="_blank">PHP Tutorials</a> </strong></div></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#00CCFF">
              <tr> 
                <td bgcolor="#99CC99"><div align="center"><strong>Some 
                    PHP Script Search Sites:</strong></div></td>
              </tr>
              <tr> 
                <td><strong><a href="http://www.myPHPFiles.com"  target="_blank">MyPHPFiles.com</a> - Free Scripts Directory </strong></td>
              </tr>
              <tr> 
                <td><strong><a href="http://www.tryphp.com/?view_page=Important%20PHP%20and%20MYSQL%20links&id=14"  target="_blank">Complete Paid/Free Scripts Directory Directory </a></strong></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#00CCFF">
              <tr> 
                <td bgcolor="#99CC99"><div align="center"><strong>Please 
                This Script:</strong></div></td>
              </tr>
              <tr> 
                <td><form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST" target="_blank" style="display:inline;">
                    <div align="center">
                      <input type="hidden" name="ID" value="34864">
                      <input type="hidden" name="external" value="1">
                      <select name="rate" class="listmenu" size="1">
                        <option value="5" selected>Excellent!</option>
                        <option value="4">Very Good</option>
                        <option value="3">Good</option>
                        <option value="2">Fair</option>
                        <option value="1">Poor</option>
                      </select>
                      <input name="submit" type="submit"  title="Please Vote For Me" value="Vote 4 Me!">
                    </div>
                  </form>
                </td>
              </tr>
            </table>
            <p align="justify">&nbsp;</p>
	
  
          </td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr align="center"> 
    <td height="28" colspan="2">
      
    </td>
  </tr>
</table>
<?php // get the footer
	  require_once('inc/footer.php');?>