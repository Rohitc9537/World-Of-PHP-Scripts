<?
//***********************************************************************************//
//** Please leave this message alone, no one will be able to see it, except coders.**//
// This script is copyrighted by PHP scripts, a Marsal Design Company.***************//
// To get your own verison of this system, please do download it from our site*******//
// located at http://www.free-php-scripts.net****************************************//
// Script is free, no advertisement, no nothing....**********************************//
//***********************************************************************************//

//This is used as a security measure, no one will be able to access the image folder directly
header("Location: ../../index.php");
exit();
?>