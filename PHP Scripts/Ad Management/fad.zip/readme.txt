/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/

FAD Complete Site Manager V 4.0
--------------------------------

-------------->>>>>>>>>>INSTRUCTIONS:<<<<<<<<<<<<------------------
Step #1:
--------
-->Edit the inc/cofigure.php with all information (correct information)

Step #2:
--------
-->Run inc/installdatabase.php or install it yourself from inc/database.sql
(will take around 3 minutes to process so you will need command line access)

Step #3:
--------
-->Remove the database.sql file

and you are done, access the control panel from index.php (any page will redirect you to login.php)


-------------->>>>>>>>>>ABOUT:<<<<<<<<<<<<------------------
This script is a complete site manager which has many features and usage options.

Banner Management:
------------------
-->Add, Edit modify banners.
-->View complete stats for banner
-->Options such as new window, same window, resize banner images, 
-->Ability to stop banner on a certain date, after certain views/clicks.
-->Banners can be images, such as JPG, BMP, GIF, ect.. or Flash type
** If placing flash type banners you must insert the link: fad/catchbanner.php?id=XXX (Where XXX represents banner ID)

Counter Management:
------------------
-->Counters can be made visible or Hidden
-->Counters can be Image type, or Text based
-->Counters count both Unique and all views, whichever you choose to view they wont be mixed.
-->Counters also track user information including: Country, System and Browser used to access system

Referral Management:
------------------
-->You can give unlimited amount of Referrals to your site
-->Specify redirect link or choose main site
-->Records clicks on the link and how many actual credits (purchases, signups, ect..) happened
-->Stores the cookie for 30 days on system.

Security Management:
------------------
-->Produce code to protect files and directories (unlimited)
-->User list can be single, or can be read from a database
-->Absolutely no PHP experience necessary, everything is produced for you

Very Uselful Links:
------------------
-->Some important links of which might save you hundreads of dollars, all free scripts and services

Whats been updated from V3.0:
-----------------------------
1) Code now uses full php implementation, no more javascript
2) Works on all browsers and systems
3) Code is much eaiser to read, understand or change
4) Faster generation
5) More accuracy in viewing and managing banners
6) Better Randomizing affect
7) No more errors, easy to login
8) Login now uses database to record sessions.

We hope that you like our script, please remember to visit us at: www.helpphp.net or free-php-scripts.net
we are ready for your questions, not only relating to this script but to coding in general.

FPS Inc.,