<? 
//***********************************************************************************//
//** Please leave this message alone, no one will be able to see it, except coders.**//
// This script is copyrighted by PHP scripts, a Marsal Design Company.***************//
// To get your own verison of this system, please do download it from our site*******//
// located at http://www.free-php-scripts.net****************************************//
// Script is free, no advertisement, no nothing....**********************************//
//***********************************************************************************//


//Include header (which inturn include, page titles ands connect file)
require_once ('inc/header.php'); 







?> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="25%" valign="top"> 
      <? // Get the side menu
	  require_once('inc/side.php');?>
    </td>
    <td width="90%" valign="top"><table width="100%" border="0" cellspacing="5" cellpadding="5">
        <tr>
          <td><p align="center">
            <div align="center"><strong><font color="#00FF00" face="Courier New, Courier, mono"> 
              </font></strong>
              <table width="100%" border="0" cellspacing="5" cellpadding="5">
                <tr> 
                  <td><div align="center"><strong><font color="#00FF00" face="Courier New, Courier, mono">FAD 
                      System Terms Of Use and Agreement </font> </strong></div>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">1. 
                      ACCEPTABLE USE. The following represent unlawful usage of 
                      any PH</font> <font color="#FFFFFF">P Script website: Wrongfull 
                      advertisements or links, Spamming, Advertising us on sites 
                      containing/promoting illegal activities, Violation of intellectual 
                      property rights. </font></strong></font> 
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">2. 
                      LINKS TO THIRD PARTY WEB SITES Some links within the PHP 
                      Scripts may let users leave the PHP Scripts. You understand 
                      that the linked sites are not under the control of PHP Scripts, 
                      Inc. and that PHP Scripts, Inc. is not responsible for the 
                      contents or operation of such linked sites or any link contained 
                      in such linked site, or any changes or updates to such sites. 
                      PHP Scripts, Inc. is providing these links to you only as 
                      a convenience, and the inclusion of any link does not imply 
                      endorsement by PHP Scripts, Inc. of the linked site or any 
                      association with their operators. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">3. 
                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY Your 
                      access to and use of the PHP Scripts, and products and services 
                      of PHP Scripts, is at your own risk. PHP Scripts, Inc., 
                      and its affiliates, will not be liable for any damage, loss 
                      or disclosure of information, data, revenue, accounts or 
                      business that occurs in connection with your use of the 
                      PHP Scripts, or such products or services. PHP Scripts, 
                      Inc. makes no guarantees of any kind regarding the dependability, 
                      accuracy, security, timeliness or availability of the PHP 
                      Scripts, or such products or services. Without limiting 
                      the foregoing, PHP Scripts, INC. AND/OR ITS RESPECTIVE PARNERS 
                      MAKE NO REPRESENTATIONS OR WARRANTIES ABOUT THE CONDITION, 
                      SUITABILITY, RELIABILITY, AVAILABILITY, COMPLETENESS, SECURITY, 
                      TIMELINESS, OR ACCURACY OF THE INFORMATION, SOFTWARE, PRODUCTS, 
                      SERVICES AND MATERIALS CONTAINED IN PHP Scripts FOR ANY 
                      PURPOSE. ALL SUCH INFORMATION, SOFTWARE, PRODUCTS, SERVICES 
                      AND MATERIALS ARE PROVIDED &quot;AS IS&quot; WITHOUT WARRANTY 
                      OF ANY KIND. PHP Scripts, INC. AND/OR ITS RESPECTIVE AFFILIATES 
                      HEREBY DISCLAIM ALL REPRESENTATIONS, WARRANTIES AND CONDITIONS, 
                      EXPRESS OR IMPLIED, WITH REGARD TO THIS INFORMATION, SOFTWARE, 
                      PRODUCTS, SERVICES OR MATERIALS, INCLUDING ALL IMPLIED WARRANTIES 
                      AND CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
                      PURPOSE, TITLE AND NON-INFRINGEMENT. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">IN 
                      NO EVENT SHALL PHP Scripts, INC. AND/OR ITS AFFILIATES BE 
                      LIABLE FOR ANY DIRECT, INDIRECT, PUNITIVE, INCIDENTAL, SPECIAL, 
                      CONSEQUENTIAL OR EXEMPLARY DAMAGES OR ANY DAMAGES WHATSOEVER 
                      INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF USE, 
                      DATA OR PROFITS, ARISING OUT OF OR IN ANY WAY CONNECTED 
                      WITH THE USE OR PERFORMANCE OF PHP Scripts OR RELATED SERVICES, 
                      WITH THE DELAY OR INABILITY TO USE PHP Scripts OR RELATED 
                      SERVICES, THE PROVISION OF OR FAILURE TO PROVIDE SERVICES, 
                      OR FOR ANY INFORMATION, SOFTWARE, PRODUCTS, SERVICES AND 
                      RELATED GRAPHICS OBTAINED THROUGH PHP Scripts, OR OTHERWISE 
                      ARISING OUT OF THE USE OF PHP Scripts, WHETHER BASED ON 
                      CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE, 
                      EVEN IF PHP Scripts, INC. OR ANY OF ITS AFFILIATES HAS BEEN 
                      ADVISED OF THE POSSIBILITY OF DAMAGES. BECAUSE SOME STATES/JURISDICTIONS 
                      DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR 
                      CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE LIMITATION 
                      MAY NOT APPLY TO YOU. THE MAXIMUM LIABILITY OF PHP Scripts 
                      INC. TO YOU FOR ANY LOSS, CLAIM, DAMAGE, OR LIABILITY OF 
                      ANY KIND, INCLUDING DUE TO PHP Scripts INC.'S NEGLIGENCE, 
                      SHALL BE LIMITED TO THE AMOUNT PAID BY YOU TO PHP Scripts 
                      INC. FOR THE PARTICULAR MONTH THAT GAVE RISE TO SUCH CLAIM. 
                      IF YOU ARE DISSATISFIED WITH ANY PORTION OF PHP Scripts, 
                      OR WITH ANY OF THESE TERMS OF USE AND NOTICES, YOUR SOLE 
                      AND EXCLUSIVE REMEDY IS TO DISCONTINUE USING PHP Scripts 
                      AND ITS RELATED SERVICES. WITHOUT LIMITING THE FOREGOING, 
                      PHP Scripts, INC. IS NOT RESPONSIBLE FOR ANY OF YOUR DATA 
                      RESIDING ON PHP Scripts, INC. AND PHP Scripts HARDWARE. 
                      IT IS YOUR RESPONSIBILITY TO TAKE THE NECESSARY STEPS TO 
                      ENSURE YOUR PRIMARY MEANS OF BUSINESS IS MAINTAINED. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">EXCEPT 
                      AS OTHERWISE EXPRESSLY STATED IN THIS AGREEMENT, PHP Scripts 
                      INC. MAKES NO REPRESENTATIONS OR WARRANTIES (I) THAT THE 
                      SERVICES WILL BE SECURE, UNINTERRUPTED, TIMELY, ERROR FREE 
                      OR ALWAYS AVAILABLE; (II) REGARDING THE RELIABILITY OR ACCURACY 
                      OF THE SERVICES OR OF THE INFORMATION DISTRIBUTED, OBTAINED 
                      OR PRESENTED VIA THE SERVICES AND YOUR USE OF SUCH INFORMATION 
                      IS AT YOUR DISCRETION AND RISK; (III) THAT THE SERVICES 
                      WILL MEET ANY OF YOUR REQUIREMENT; OR (IV) THAT PHP Scripts 
                      INC. WILL CONTINUE TO OPERATE ITS SERVICE IN ITS CURRENT 
                      FORM. USE OF THE SERVICES BY YOU IS AT YOUR SOLE RISK.</font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF"><br>
                      4. GENERAL This Agreement is governed by the laws of the 
                      State of New York, U.S.A. You hereby consent to the jurisdiction 
                      of and venue in courts located in Kings County, New York, 
                      U.S.A. in all disputes arising out of or relating to the 
                      use of the PHP Scripts . In addition, you hereby consent 
                      to the exclusive jurisdiction of and venue in such courts 
                      for any action commenced by you against PHP Scripts, Inc., 
                      (or its affiliates). You agree that no joint venture, partnership, 
                      employment, or agency relationship exists between you and 
                      PHP Scripts, Inc. as a result of this Agreement or use of 
                      PHP Scripts . PHP Scripts, Inc.'s performance of this agreement 
                      is subject to existing laws and legal process, and nothing 
                      contained in this agreement is in derogation of PHP Scripts, 
                      Inc.'s right to comply with governmental, court and law 
                      enforcement requests or requirements relating to your use 
                      of the PHP Scripts or information provided to or gathered 
                      by PHP Scripts, Inc. with respect to such use. If any part 
                      of this Agreement is determined to be invalid or unenforceable 
                      pursuant to applicable law including, but not limited to, 
                      the warranty disclaimers and liability limitations set forth 
                      above, then the invalid or unenforceable provision will 
                      be deemed superseded by a valid, enforceable provision that 
                      most closely matches the intent of the original provision 
                      and the remainder of the Agreement shall continue in effect. 
                      Unless otherwise specified herein, this Agreement constitutes 
                      the entire agreement between the user and PHP Scripts, Inc. 
                      with respect to the PHP Scripts and it supersedes all prior 
                      or contemporaneous communications and proposals, whether 
                      electronic, oral or written, between the user and PHP Scripts, 
                      Inc. with respect to the PHP Scripts . A printed version 
                      of this Agreement and of any notice given in electronic 
                      form shall be admissible in judicial or administrative proceedings 
                      based upon or relating to this Agreement to the same extent 
                      and subject to the same conditions as other business documents 
                      and records originally generated and maintained in printed 
                      form. You may not rent, lease, license, grant a security 
                      interest in, or otherwise transfer or sublicense your rights 
                      hereunder to any third party. Use of the PHP Scripts is 
                      unauthorized in any jurisdiction that does not give effect 
                      to all provisions of these terms and conditions, including 
                      without limitation this paragraph. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">PHP 
                      Scripts Inc.'s failure to insist upon strict performance 
                      of any of the provisions of this Agreement shall in no way 
                      constitute a waiver of future violations of the same or 
                      any other provision. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">If 
                      either you or PHP Scripts Inc. commences any action or proceeding 
                      against the other to enforce or interpret this Agreement, 
                      the prevailing party in such action or proceeding shall 
                      be entitled to recover from the other party the actual costs, 
                      expenses and attorneys' fees (including all related costs 
                      and expenses), incurred by such prevailing party in connection 
                      with such action or proceeding and in connection with obtaining 
                      and enforcing any judgment or order thereby obtained. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">5. 
                      TERMS OF THE AGREEMENT. These terms will begin upon your 
                      usage of this website. The terms of this agreement may be 
                      modified at any time by us without warning. Your continued 
                      participation with the website will constitute your acceptance 
                      of any changes. By using this website you agree to all terms 
                      and are bound by them. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">6.TRADEMARKS 
                      PHP Scripts is either a trademark or registered trademark 
                      or service mark (collectively Trademark) of Sonimager, Incorporated. 
                      The names of actual companies and products mentioned herein 
                      may be the trademarks of their respective owners. The right 
                      to access and use the PHP Scripts does not include any right 
                      to use such Trademarks of PHP Scripts Inc. </font></strong></font></p>
                    <p align="justify"><font face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">7. 
                      ILLEGAL USE OF THIS PROGRAM This program can be used in 
                      any way, except for profit making. This program must stay 
                      free, no charge for anything including but not limited to 
                      Downloading charge, set-up charge, or referral charge. Whoever 
                      is found breaking such agreement will be referred to the 
                      D.C. C. (Department of Cyber Control) for further legal 
                      matters.</font></strong></font></p>
                    <p><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif"></font><font color="#FFFFFF"></font></p>
            </td>
                </tr>
              </table>
              <font color="#FFFFFF"><br>
              </font></div>
            </td>
        </tr>
      </table>
      <p align="center">&nbsp;
      </td>
  </tr>
  <tr align="center"> 
    <td height="28" colspan="2">
      <? // get the footer
	  require_once('inc/footer.php');?>
    </td>
  </tr>
</table>
