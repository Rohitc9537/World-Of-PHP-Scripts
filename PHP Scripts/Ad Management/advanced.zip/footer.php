<?php
/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/
@mysql_close();
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="17"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Please 
        Read and Agree To Our <a href="http://www.free-php-scripts.net/fps_terms_of_use.php" target="_blank" >Terms 
        Of Use</a> before using our site and it's scripts </strong></font></div></td>
  </tr>
  <tr> 
    <td height="19"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>All 
        Rights Reserved For PHP Scipts (c) 2003-2004, A Registered Trademark Of 
        Sonimager Inc.</strong></font></div></td>
  </tr>
</table>
</body>
</html>
