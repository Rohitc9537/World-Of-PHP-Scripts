/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/

Marsal Advanced Banner Manager V 3.0

---------------Please insure you install the sql file + edit connect.php file------

This script will allow you to:

1) Add, Remove, Edit banners
2) Change banner options
3) Stop on certain date, hits, unique hits, views or unique views
4) Live stat showing you all information
5) Password protected administation area (default: username: aziz, pass: 2598 - changable on login.php)


To use this script, place this code andwhere where you want the form to appear:
<?php @include_once("viewbanner.php");?>

Whats been updated from V 1.0:
1) Code now uses full php implementation, no more javascript
2) Works on all browsers and systems
3) Code is much eaiser to read, understand or change
4) Faster generation
5) More accuracy in viewing and managing banners
6) Better Randomizing affect

We hope that you like our script, please remember to visit us at: www.helpphp.net or free-php-scripts.net
we are ready for your questions, not only relating to this script but to coding in general.

FPS Inc.,