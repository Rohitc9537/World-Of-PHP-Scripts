<?php // $Revision: 1.1.2.2 $

/****************************************************************************/
/* phpAdsNew 2                                                              */
/* ===========                                                              */
/*                                                                          */
/* Copyright (c) 2000-2005 by the phpAdsNew developers                      */
/* For more information visit: http://www.phpadsnew.com                     */
/*                                                                          */
/*Translated to Brazilian_portuguese by: Luiz Alberto de Moraes - purasorte */
/*For any comments/suggestions: purasorte@yahoo.com.br                      */
/*http://wwww.ojogodobicho.com                                              */
/*                                                                          */
/* This program is free software. You can redistribute it and/or modify     */
/* it under the terms of the GNU General Public License as published by     */
/* the Free Software Foundation; either version 2 of the License.           */
/****************************************************************************/


$GLOBALS['strPluginAffiliate'] 	= "Gera um hist&oacute;rico descritivo do editor selecionado. O relat&oacute;rio &eacute; exportado como CSV para f&aacute;cil importa&ccedil;&atilde;o.";
$GLOBALS['strPluginCampaign'] 	= "Gera um hist&oacute;rico descritivo da campanha selecionada. O relat&oacute;rio &eacute; exportado como CSV para f&aacute;cil importa&ccedil;&atilde;o.";
$GLOBALS['strPluginClient'] 	= "Gera um hist&oacute;rico descritivo do anunciante selecionado. O relat&oacute;rio &eacute; exportado como CSV para f&aacute;cil importa&ccedil;&atilde;o.";
$GLOBALS['strPluginGlobal'] 	= "Gera um hist&oacute;rico descritivo global. O relat&oacute;rio &eacute; exportado como CSV para f&aacute;cil importa&ccedil;&atilde;o.";
$GLOBALS['strPluginZone'] 		= "Gera um hist&oacute;rico descritivo do zona selecionado. O relat&oacute;rio &eacute; exportado como CSV para f&aacute;cil importa&ccedil;&atilde;o.";

?>