<?php
// Yoursite.nu Plugboard 1.0
// Created by Linda - Please see http://www.yoursite.nu/mbforum.php?id=8 if you need help
// Do not redistribute this code


// Edit the lines below to match your mysql information

$conf['mysql_host'] = "localhost"; // host - usually localhost
$conf['mysql_user'] = "fdlinda_yoursite"; // mysql username
$conf['mysql_pass'] = "huh"; // mysql password
$conf['mysql_db'] = "fdlinda_yoursite"; // database name

$admin_username = "admin"; // Username to access administration area
$admin_password = "password"; // Password to access administration area

$limit = 9;  // Number of buttons to be displayed

$button_width = "88";  // width of buttons in pixels
$button_height = "31"; // height of buttons in pixels

$ipcheck = "false"; // Disallow same ip posting twice in a row, change to true if you want to allow it.
?>