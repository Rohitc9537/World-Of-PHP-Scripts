<?php
// config variables for the db
$dbtype = "mysql";
$dbhost = "localhost";
$dbuser = "";
$dbpass = "";
$dbname = "";
$dbprefix = "pl_";
?>