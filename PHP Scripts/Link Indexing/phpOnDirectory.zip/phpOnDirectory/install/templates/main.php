<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Directory Software Install</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META HTTP-EQUIV="Content-Language" CONTENT="EN">
<META NAME="ROBOTS" content="INDEX, FOLLOW">
<META NAME="CLASSIFICATION" CONTENT="personals, dating, singles, matchmaking, love, relationships">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>

<table cellspacing="0" cellpadding="0" width="100%" border="0" bordercolor="black" align="center">
  <tr>
    <td width="5%" valign="top">&nbsp;</td>
    <td width="85%" valign="top"><?php require('pages/' . $page_contents); ?></td>
    <td width="5%" valign="top">&nbsp;</td>
  </tr>
</table>

</body>
</html>