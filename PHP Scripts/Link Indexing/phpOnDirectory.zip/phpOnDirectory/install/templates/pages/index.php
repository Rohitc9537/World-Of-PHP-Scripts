<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META HTTP-EQUIV="Content-Language" CONTENT="EN">
</head>
<body>
<table cellspacing="0" cellpadding="10" border="0" width="100%">
<tr>
	<td align="center">
		<a href="install.php">Click here to begin installation of the phpDirectory</a>
	</td>
</tr>
</table>
</body>
</html>