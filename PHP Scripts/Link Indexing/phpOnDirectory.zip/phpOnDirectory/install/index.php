<?php
$page_contents = 'index.php';
require('templates/main.php');

?>