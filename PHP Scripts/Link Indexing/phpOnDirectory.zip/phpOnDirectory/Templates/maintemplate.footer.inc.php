    </td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td align="center"  class="foot">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"  class="small">Copyright &copy; 1999 - 2005 Interactive Arts Ltd</td>
  </tr>
</table>
</body>
</html>
