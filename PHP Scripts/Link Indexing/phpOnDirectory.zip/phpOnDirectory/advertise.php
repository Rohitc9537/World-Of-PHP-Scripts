<?php
include_once('includes/db_connect.php');
include_once('banner.inc.php');
include('Templates/maintemplate.header.inc.php');
?>

        <table border="0" cellpadding="0" cellspacing="0" width="95%">
          <tr>
            <td width="100%" height="30" colspan="3">
              <h1>Advertise</h1></td>
          </tr>
          <tr>
            <td width="100%" valign="top" align="left" colspan="3">
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="3">
        <p>
  <?php echo $CONST_LINK_SITE ?> offers a variety of advertising options to help you
  increase the visibility of your service on this website and to drive highly
  targeted traffic to your site. Our current rates are as follows:</p>
  <p><b>Home Page &amp; continuation</b></p>
  <p>    Banner (top of page 468x60 pixels) - $120 per month<br>
      Banner (continuation
  page)           - $60 per
  month</p>
  <p><b>Boxed Ads</b> </p>
        <p> <i>Increase the visibility of your advert by having it boxed at the top of your chosen sub-category.
        Only one boxed add per sub-category allowed.</i> <b><br>
  </b><br>
      Sub-categories - $35  - $45 per month</p>
        <b>
  Example:</b>
<div align="right">
  <table border="1" cellpadding="3" cellspacing="0" width="100%">
    <tr>
      <td width="100%" bordercolorlight="#FFFFFF" bordercolordark="#000000"><a class="menu" href="<?php echo $CONST_LINK_ROOT ?>" target="_blank"><b><?php echo $CONST_LINK_SITE ?></b></a>
        - Would you like to advertise on the worlds #1 dating directory and give
        your site a boost with targeted traffic. <?php echo $CONST_LINK_SITE ?> offers
        free and paid advertising opportunities and will help you to achieve the
        best return on your advertising budget. Mail now for further
        information!  <br>
        <font color="#FF0000"><i>(<?php echo $CONST_LINK_ROOT ?>)</i></font></td>
    </tr>
  </table>
</div>
  <p><b>Categories</b>  </p>
        <p>    <i>Categories &amp; Sub-Categories:</i><br>
      <br>
      Banner (top of page 468x60 pixels) - $35 - $45 per month</p>
        <div align="center">
          <center>
          <table border="1" cellpadding="0" cellspacing="0" width="80%" bordercolordark="#C0C0C0">
            <tr>
              <td width="100%" bgcolor="#FFFFE6">
                <p align="center">We offer a 25% discount for all pre-paid
                bookings over 3 months. Please e-mail if you are interested in
                multiple slot bookings.</p></td>
            </tr>
          </table>
          </center>
        </div>
        <p>All prices are fixed costs for a 30 day period. We cannot guarantee
        the click-thru ratio, this is partly dependant upon the quality of your
        banner.
        Nor do we track click-thru's or impressions. Adult sites may only
        display banners within the adult categories.</p>
        <p>If you are interested in any of these options then please drop us a
        line using the contact button above.</p>
        <p></p>
            </td>
          </tr>
        </table>

<?include('Templates/maintemplate.footer.inc.php');?>