<html>
<head>
<title>Plugbox 1.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body style="background-color: transparent;">

<?php include('plug.php'); ?>

</body>
</html>