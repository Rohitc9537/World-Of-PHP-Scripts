<?php

// Caution: Auto-Generated File. Do Not Edit!
// Edit these variable through the admin panel.

$pb_cfg['version'] = "1.0";
$pb_cfg['admin_uname'] = "zavion";
$pb_cfg['admin_upass'] = "9ebdf82b65a8170952d31db7d84a148c";
$pb_cfg['base_url'] = 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/';
$pb_cfg['site_url'] = $pb_cfg['base_url'].'index.php';
$pb_cfg['date_format'] = "m/d/y";
$pb_cfg['timeout'] = "15";
$pb_cfg['max_plugs'] = "16";
$pb_cfg['button_width'] = "88";
$pb_cfg['button_height'] = "31";
$pb_cfg['display_order'] = "DESC";
$pb_cfg['allow_milti_post'] = "1";
$pb_cfg['error_tpl'] = "<html>\n<head><title>PHP Plugbox - Error</title></head>\n<body>\n<p>{ERROR_MESSAGE}</p>\n<p><a href=\"{WEBSITE_URL}\">Back</a></p>\n</body>\n</html>";

?>