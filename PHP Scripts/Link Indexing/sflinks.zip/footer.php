<p align="center"><h1><a href="addlink.php">Add a Link</a> || <a href="deletelink.php">Delete a Link</a> || <a href="#" onClick="list=window.open('showids.php','list','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=650,height=500'); return false;">Show Links</a></h1></p>

<p align="center"><font size="1">This script brought to you by the letters <a href="http://spoken-for.org" target="_blank">S and F and O</a>.</font></p>

</body>
</html>