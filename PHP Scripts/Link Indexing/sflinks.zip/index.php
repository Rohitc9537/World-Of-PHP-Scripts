<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>nope.</title>
</head>

<body>
<style type="text/css">
body, html {background-color: #fff; color: #000; scrollbar-base-color: #fff; font-family: verdana, arial, sans-serif; font-size: 9px;</style>

you're not supposed to be here.

</body>
</html>