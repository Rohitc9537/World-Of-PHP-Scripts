<?php
$logs = "logs"; // Used for advanced installation. Read the readme for details.
$sof = "0"; // Your time offset in hours from your server's time.
?>