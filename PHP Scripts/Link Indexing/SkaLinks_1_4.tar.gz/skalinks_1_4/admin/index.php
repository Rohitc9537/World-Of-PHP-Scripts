<?php
/*
 *	SkaLinks, Links Exchange Script
 * (c) Skalfa eCommerce, 2005
 *
 * TERMS OF USE
 * You are free to use, modify and distribute the original code of SkaLinks software
 * with the following restrictions:
 * 1) You may not remove Skalfa eCommerce copyright notices from any parts of Skalinks software
 * code.
 * 2) You may not remove or modify "powered by" links to vendor's site from any web-pages of
 * SkaLinks script.
 * 3) You may use but may not distribute original or modified version of SkaLinks software
 * for commercial purposes.
 * Complete License Agreement text: http://www.skalinks.com/license.php
 *
 * Technical support: http://www.skalinks.com/support/
 */

require_once( '../headers.php' );

// Process input data

$admin_attribute = ( ctype_space( $_POST['admin_name'] ) || ctype_space( $_POST['admin_password'] ) ) ? 0 : 1 ;
$_output['menu'] = 0;

// TODO: Statements here:

$SkaLinks	= new SkaLinks( $_skalinks_mysql );
$smarty		= new DirSmarty();
$SkaLinks->SetRootURL( $_skalinks_url['dir'] );
$SkaLinks->SetRootDir( $_skalinks_dir['dir'] );
$SkaLinks->SetPrefix( $_skalinks_mysql['tbl_prefix'] );
$_output['title'] = $SkaLinks->GetTitleChain( -1, $_skalinks_page['title'], $_skalinks_page['title_admin'] );
$ADMIN = $SkaLinks->IsAdmin();

if ( $ADMIN['Type'] == 2 )
{
	$editor_id = 0;
}
else
{
	$editor_id = $ADMIN['ID'];
}
$_output['count_appr_cat']	= count( $SkaLinks->GetVerifyCats( 1, $editor_id ) ); 
$_output['count_appr_link']	= count( $SkaLinks->GetVerifyLinks( array( 'type' => 1, 'editor' => $editor_id ) ) );
$_output['count_broken_link']	= $SkaLinks->GetVerifyLinks( array( 'type' => 2, 'count' => 1, 'editor' => $editor_id ) ) ;
$_output['count_invalid_email'] = count( $SkaLinks->GetVerifyLinks( array( 'type' =>3, 'editor' => $editor_id ) ) );
$_output['count_recip_link']	= count( $SkaLinks->GetVerifyLinks( array( 'type' => 4, 'editor' => $editor_id ) ) );
$_output['settings']		= $SkaLinks->GetParam( 0 );

if ( $ADMIN && ( !$_POST['Logout'] ) )
{
	require_once( '../SkaLinks_include/rss.class.php' );
	$reader = new RSSReader( $_skalinks_url['rm_news'] );
	foreach( $reader->data['item']['title'] as $key => $value )
	{
		$reader->data['item']['description'][$key] = str_replace( "&gt;", ">", $reader->data['item']['description'][$key] );
		$reader->data['item']['description'][$key] = str_replace( "&lt;", "<", $reader->data['item']['description'][$key] );
		$reader->data['item']['title'][$key] = str_replace( "&gt;", ">", $reader->data['item']['title'][$key] );
		$reader->data['item']['title'][$key] = str_replace( "&lt;", "<", $reader->data['item']['title'][$key] );
		
		$_output['news'][$key]['title']	= $reader->data['item']['title'][$key];
		$_output['news'][$key]['link']	= $reader->data['item']['link'][$key];
		$_output['news'][$key]['description']	= $reader->data['item']['description'][$key];
		$_output['news'][$key]['pubdate']	= $reader->data['item']['pubdate'][$key];
	}
}

if ( !$ADMIN )
{
	$_output['menu'] = 0;
}
if ( $_POST['Login'] )
{
	$_output['logout'] = $SkaLinks->Login( $_POST['admin_name'], md5( $_POST['admin_password'] ) );
}

if ( $_POST['Logout'] )
{
	$SkaLinks->Logout();
	$_output['logout'] = 1;
}


if ( ( $_POST['Build_cat'] || $_GET['Build_cat'] ) && $ADMIN )
{
      $msg = ( $SkaLinks->BuildCategory( 0, 1 ) ) ? $_skalinks_lang['msg']['cats_built'] : $_skalinks_lang['msg']['cats_not_built'] ;
}
if ( $ADMIN['Type'] == 2 && $_POST['Get_pagerank'] )
{
	$query = "SELECT * FROM `".$SkaLinks->m_LinksTable."`";
	$all_links = $SkaLinks->db_Fetch( $query );
	foreach( $all_links as $key => $value )
	{
		$page_rank	= getPR( $all_links[$key]['URL'] );
		$query		= "UPDATE `".$SkaLinks->m_LinksTable."` SET `Pagerank`='$page_rank' WHERE `ID`='{$all_links[$key]['ID']}'";
		$SkaLinks->db_Query( $query );
	}
	$msg = $_skalinks_lang['msg']['pagerank_set'];
}


display( 'admin_index' );

?>
