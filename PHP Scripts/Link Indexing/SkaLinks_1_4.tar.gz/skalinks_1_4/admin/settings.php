<?php
/*
 *	SkaLinks, Links Exchange Script
 * (c) Skalfa eCommerce, 2005
 *
 * TERMS OF USE
 * You are free to use, modify and distribute the original code of SkaLinks software
 * with the following restrictions:
 * 1) You may not remove Skalfa eCommerce copyright notices from any parts of Skalinks software
 * code.
 * 2) You may not remove or modify "powered by" links to vendor's site from any web-pages of
 * SkaLinks script.
 * 3) You may use but may not distribute original or modified version of SkaLinks software
 * for commercial purposes.
 * Complete License Agreement text: http://www.skalinks.com/license.php
 *
 * Technical support: http://www.skalinks.com/support/
 */
 
require_once( '../headers.php' );

   
   
// Process input data
if ( $_POST['settings'] )
{
	foreach( $_POST['settings'] as $value)
	{
		if ( ctype_space( $value ) )
		{
			$settings_attribute = 1;
			break;
		}
	}
}

// TODO: Statements here..
$SkaLinks	= new SkaLinks( $_skalinks_mysql );
$smarty		= new DirSmarty();
$SkaLinks->SetRootURL( $_skalinks_url['dir'] );
$SkaLinks->SetPrefix( $_skalinks_mysql['tbl_prefix'] );
$ADMIN			= $SkaLinks->IsAdmin();
$_output['title']	= $SkaLinks->GetTitleChain( -1, $_skalinks_page['title'], "Settings" );
if ( $ADMIN['Type'] != 2 )
{
   	$msg = $_skalinks_lang['msg']['not_admin'];
	require_once( '../index.php' );
      
}
else
{
	if ( $_POST['Change_settings'] )
	{
		if ( !$settings_attribute )
		{ 
			foreach( $_POST['settings'] as $key => $value )
			{
				$SkaLinks->SetParam( $key, $value );
			}	   
			$msg = $_skalinks_lang['msg']['changes_done'];
		}
		else
		{
			$msg = $_skalinks_lang['msg']['inf_incomplete'];
		}
	}
	$_output['settings'] = $SkaLinks->GetParam( 0 );
	foreach( $_output['settings'] as $key => $value )
	{	      
		$temp = $_output['settings'][$key]['Name'];
		$_output['settings'][$key]['mean'] = $_skalinks_lang['settings'][$temp];
		if ( $_output['settings'][$key]['type'] == 'select' && $_output['settings'][$key]['Range'] )
		{
			$_output['settings'][$key]['Range'] = explode( ";", $_output['settings'][$key]['Range'] );
			foreach( $_output['settings'][$key]['Range'] as $key1 => $value1 )
			{
				$_output['settings'][$key]['Range'][$key1] = explode( '=', $_output['settings'][$key]['Range'][$key1] );
			}
		}
	}
	      
	// Show HTML

	display( 'settings' );
}
?>
