
			<?php 
			require_once( '../headers.php' );
			// Input Data
			$SkaLinks = new SkaLinks( $_skalinks_mysql );
			$smarty = new DirSmarty();
			$SkaLinks->SetRootUrl( $_skalinks_url['root'] );
			$SkaLinks->SetPrefix( $_skalinks_mysql['tbl_prefix'] );
			$url	     = $_GET['link_id'];
			$table_name  = $SkaLinks->m_LinksTable;
			$ADMIN	     = $SkaLinks->IsAdmin();
			$_output['mod_rewrite']		= $SkaLinks->GetParam( 'mod_rewrite' );
			$_output['show_admin_ads']	= $SkaLinks->GetParam('show_admin_ads' );
			$number_search_results_display	= $SkaLinks->GetParam( 'number_search_display' );
			$_output['show_dirtree']	= $SkaLinks->GetParam('show_dirtree' );
			$_output['links_info']		= $SkaLinks->db_Row( "SELECT * FROM `$table_name` WHERE ID='$url'" );

			$link_arr['id']		        = $url;
		        $link_arr['cat_id']	        = $_output['links_info']['Category'];
		        $link_arr['link']	        = $_output['links_info']['URL'];
		        $link_arr['LinkBackURLValid']	= $_output['links_info']['LinkBackURLValid'];
		        $link_arr['EmailValid']	        = $_output['links_info']['EmailValid'];
		        $link_arr['title']	        = mysql_escape_string( $_output['links_info']['Title'] );
		        $link_arr['description']	= mysql_escape_string( $_output['links_info']['Description'] );
		        $link_arr['rank']	        = $_output['links_info']['Rank'];
		        $link_arr['linkback']	        = $_output['links_info']['LinkBackURL']; 
		        $link_arr['email']	        = $_output['links_info']['Email'];
		        $link_arr['alt_domain']		= $_output['links_info']['Alt_domain'];
		        $link_arr['admin_name']		= $_output['links_info']['Admin_id'];
		        $SkaLinks->EditLink( $link_arr );	
		       
			$_output['title']		= $SkaLinks->GetTitleChain( -1, $_skalinks_page['title'], $_output['links_info']['Title'] );
			$_output['meta_description']	= $_output['links_info']['Description'];
			$_output['cat_navigation']	= $SkaLinks->GetCatNavigationLine( $_output['links_info']['Category'] );
			$_output['cat_info']		= $SkaLinks->GetCatInfo( $_output['links_info']['Category'] );
			$_output['searches']		= $SkaLinks->GetSearches( $_output['links_info']['Title'], $number_search_results_display ); 
			if ( $_output['mod_rewrite'] )
   			{
				foreach( $_output['searches'] as $key => $value )
				{
					$_output['searches'][$key]['URL'] = $_skalinks_url['dir']."search_url={$_output['searches'][$key]['Pattern']}".urlencode( "&search_type[]=URL&search_type[]=Title&search_type[]=Description").".html" ;
				}
			}
	                display('listing');
			?>
