<?php
/*
 *	SkaLinks, Links Exchange Script
 * (c) Skalfa eCommerce, 2005
 *
 * TERMS OF USE
 * You are free to use, modify and distribute the original code of SkaLinks software
 * with the following restrictions:
 * 1) You may not remove Skalfa eCommerce copyright notices from any parts of Skalinks software
 * code.
 * 2) You may not remove or modify "powered by" links to vendor's site from any web-pages of
 * SkaLinks script.
 * 3) You may use but may not distribute original or modified version of SkaLinks software
 * for commercial purposes.
 * Complete License Agreement text: http://www.skalinks.com/license.php
 *
 * Technical support: http://www.skalinks.com/support/
 */

require_once( 'headers.php' );

// Process input data
$SkaLinks = new SkaLinks( $_skalinks_mysql );
$smarty	  = new DirSmarty();
$SkaLinks->SetRootURL( $_skalinks_url['root'] );
$SkaLinks->SetPrefix( $_skalinks_mysql['tbl_prefix'] );
$ADMIN = $SkaLinks->IsAdmin();
//
//
$_output['menu'] = 0;
$_output['title'] = $SkaLinks->GetTitleChain( -1, $_skalinks_page['title'], $_skalinks_page['title_add_cat'] );
$_output['show_dirtree'] = $SkaLinks->GetParam( 'show_dirtree' );
$_output['show_admin_ads'] = $SkaLinks->GetParam( 'show_admin_ads' );

$cat_id = ( $_GET['cat'] ) ? ( int )$_GET['cat'] : ( int )$_POST['cat'];

if ( $_POST['Form_submitted'] )
{
	// get incorrect filed
	if ( ctype_space( $_POST['title'] ) )
	{
		$inf_item = $_skalinks_lang['add_cat']['cat_dir'];
	}
	elseif( ctype_space( $_POST['dir'] ) )
	{
		$inf_item = $_skalinks_lang['add_cat']['cat_title'];
	}

	if ( !$inf_item )
	{
		$cat_attribute = 1 ;
	}
}

if ( $cat_attribute )
{
	$_POST['title'] = convert_quote( $_POST['title'] );
	$_POST['dir'] = ltrim( $_POST['dir'] );
	$_POST['dir'] = rtrim( $_POST['dir'] );
	$_POST['dir'] = str_replace( ' ', '_', $_POST['dir'] );
	$_POST['dir'] = str_replace( '/', '_', $_POST['dir'] );
	}
// TO DO: Statements here

$_output['cat_info']	   = $SkaLinks->GetCatInfo( $cat_id );
$_output['cat_url']	   = $SkaLinks->GetCategoryURL( $cat_id );
$_output['cat_navigation'] = $SkaLinks->GetCatNavigationLine( $cat_id );
if ( $ADMIN['Type'] == 2 )
{
	$_output['editors']	   = $SkaLinks->GetAdmins( 1 );
}
if ( $_POST['Form_submitted'] )
{
if ( !$cat_attribute )
{
	$msg = $_skalinks_lang['msg']['inf_incomplete']."<br/>".$inf_item;
}
else
{
	if ( ( $ADMIN['Type'] == 2 ) || ( ( $ADMIN['Type'] == 1 ) && ( $ADMIN['ID'] == $_output['cat_info']['Editor_id'] ) ) )
	{
		$dir_arr	= explode( ',', $_POST['dir'] );
		$title_arr	= explode( ',', $_POST['title'] );
	        if ( ( count( $dir_arr ) != count( $title_arr ) ) || ( array_search( "", $dir_arr ) != false ) || ( array_search( "", $title_arr ) != false ) )
		{
			$msg = $_skalinks_lang['msg']['inf_incomplete']."<br/>".$_skalinks_lang['msg']['incor_count_cat_item'];
		}
		else
		{
			$status = 0;
			foreach( $title_arr as $key => $value )
			{
				$dir_arr[$key] = preg_replace( '/\W/i','_',$dir_arr[$key]);
				if ( $SkaLinks->AddCategory( $title_arr[$key], $dir_arr[$key], $cat_id, $_POST['editor'], $status ) )
				{
					$new_cat_info = $SkaLinks->db_Row( "SELECT ID FROM ".$SkaLinks->m_CategoriesTable." WHERE `Parent`='$cat_id' AND `title`='".$title_arr[$key]."'" );
					$SkaLinks->BuildCategory( $new_cat_info['ID'] );
					$msg .= text( array( 'c' => 'txt_cat_added', 'cat_title' => $title_arr[$key], 'cat_dir' => $dir_arr[$key] ));
				}
				else
				{
					$msg .= text( array( 'c' => 'txt_cat_exists', 'cat_title' => $title_arr[$key], 'cat_dir' => $dir_arr[$key] ) );
				}
			}
			$_POST['title']	= "";
			$_POST['dir']	= "";  
		}
	}
	else
	{
		$status = 1;
		$editor_id = 0;
		if ( $SkaLinks->AddCategory( $_POST['title'], $_POST['dir'], $cat_id, $editor_id, $status ) )
		{
			$msg = $_skalinks_lang['msg']['cat_added'];
		}
		else
		{
			$msg = $_skalinks_lang['msg']['cat_exists'];
		}
	}
}      
}//if ( $_POST['Form_submitted'] )
if ( !$ADMIN && !$cat_id )
{
	$msg = $_skalinks_lang['msg']['add_cat_root'];
	require_once( 'index.php' );
}
else
{
	$_output['js'] = 'form.js';
	display( 'add_cat' );
}
 
?> 
