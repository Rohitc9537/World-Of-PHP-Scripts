<?php
// MySQL host -- "localhost" is right 99% of the time
$db['host'] = "localhost";

// MySQL username -- enter your mysql username between the double quotes
$db['user'] = "username";

// MySQL database -- enter your mysql database name between the double quotes
$db['database'] = "database";

// MySQL password -- enter your mysql password between the double quotes
$db['password'] = "password";


// DS Plugger admin username -- this is the username to access the admin panel
$admin['user'] = "admin";  // CHANGE THIS!!

// DS Plugger admin password -- this is the password to access the admin panel
$admin['password'] = "password";  // CHANGE THIS!!
?>