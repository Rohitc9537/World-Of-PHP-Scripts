<?php

print"<center><h1><a href=\"$GAME_SELF?p=enter\">Enter</a>&nbsp;-&nbsp;<a href=\"$GAME_SELF?p=vote\">Vote</a></h1></center>"; 

?>
