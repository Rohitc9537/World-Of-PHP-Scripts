
<html>
<head>
<title>{title}</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<TABLE width=100% Border=0 valign=top><TR valign=top><TD valign=top>{menu}<br>{event}</TD></TR><TR><TD>
<TABLE Border=1 valign=top><TR valign=top><TD valign=top>
<TABLE Border=0 WIDTH=100% valign=top><TR valign=top><TD valign=top>{right}</TD></TR><TR><TD valign=top>{left}</TD></TR></TABLE>
</TD><TD WIDTH=100% valign=top><TABLE Border=0 WIDTH=100% valign=top><TR valign=top><TD valign=top>{content}</TD></TR><TR><TD valign=top>{lowregion}<BR>{lowchat}</TD></TR></TABLE></TD></TR>
</TABLE>
</TD></TR></TABLE>
</body>
</html>