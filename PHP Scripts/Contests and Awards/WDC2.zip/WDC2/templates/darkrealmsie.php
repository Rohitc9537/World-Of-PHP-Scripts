{junk}

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<title>{title}</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">


<style type="text/css">

body {
        background: #000;
        margin: 0;
        padding: 0;
        border: 0;
        font-family: "Verdana", sans-serif;
        font-size: 11px;
        color: #6A55A1;
        }



p {
        padding: 3px 0px;
        margin: 8px 0px 0px 0px;
        }

a:link {
        color: #6A55A1;
        text-decoration: underline;
                font-weight: bold;
        }

a:visited {
        color: #9A3581;
        text-decoration: underline;
                font-weight: bold;
        }

a:hover {
        text-decoration: none;
                font-weight: bold;
        }

a:active {
        color: #9A85F1;
        text-decoration: none;
        font-weight: bold;
        }

h1, h2, h3 {
        font-weight: bold;
        }

h1 {
        font-size: 30px;
        }

h2 {
        font-size: 16px;
        }

h3 {
        font-size: 11px;
        }

.topborder1 {
position: absolute;        background: transparent url(img/logo.png) no-repeat top right;
        width: 100%;
        min-width: 700px;
        height: 184px;
        z-index: 90;
        }



.background {
position: absolute;        background: transparent url(img/dbg.gif) repeat-x scroll 0% 0%;
        top: 0px;
        left: 0px;
        padding: 0px;
        height: 200px;
        width: 100%;
        min-width: 750px;
        z-index: 35;
        }





.menu {
position: absolute;        top: 0px;
        left: 0px;
        padding: 10px;
        height: 200px;
        width: 60%;
        z-index: 100;
        }


.ontop {
background: #202020;
       }

.hpbarfull {
background: #773322;
         }

.barfull {
background: #332244;
}

.barempty {
background: #000000;
         }



.topborder2 {
position: absolute;        top: 126px;
        left: 0px;
        background: #000 url(img/dbordtop.gif) repeat-x;
        width: 100%;
        min-width: 700px;
        height: 44px;
        z-index: 60;
        }

.maincontent {
        position: absolute;
        background: #000;
        top: 200px;
        left: 210px;
                padding-left: 12px;
        padding-top: 12px;
        padding-right: 12px;
        padding-bottom: 12px;
        margin: 10px;
        border: solid 1px #E4EDF0;
        z-index: 33;
        }


.popcontent {
        position: absolute;
        top: 10px;
        left: 10px;
        right: 10px;
        margin-bottom: 10px;
        padding-bottom: 25px;
        border: solid 1px #E4EDF0;
        z-index: 33;
        }



.rightbar {
position: absolute;        top: 450px;
        left: 10px;
        width: 190px;
        padding: 5px 5px 5px 5px;
        border: solid 1px #E4EDF0;
        voice-family:inherit;
        z-index: 34;
        }


.leftbar {
position: absolute;        top: 200px;
        left: 10px;
        width: 190px;
        padding: 5px 5px 5px 5px;
        border: solid 1px #E4EDF0;
        voice-family:inherit;
        z-index: 34;
        }

.admin {
color: #FF2222;
}

.mod {
color: #22FF22;
}


</style>





<SCRIPT LANGUAGE="JavaScript" type="text/javascript">
<!--

if (window != top) top.location.href = location.href;

// -->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript" type="text/javascript">
<!--

if (window != parent) top.location.href = location.href;

// -->

</SCRIPT>
<SCRIPT LANGUAGE="JavaScript" type="text/javascript">
<!--

if (self != top) top.location.href = location.href;

// -->
</SCRIPT>

</head><body>


<div class="topborder1"></div>
<div class="topborder2"><center>{event}</center><center>{pages}</center></div>
<div class="background"></div>


<div class="menu">{menu}</div>


<div class="leftbar">{left} <BR> {right} <br>

<script type="text/javascript"><!--
google_ad_client = "pub-6088426709750512";
google_alternate_color = "000000";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al_s";
google_ad_type = "text_image";
google_ad_channel ="8498960370";
google_page_url = document.location;
google_color_border = "220033";
google_color_bg = "000000";
google_color_link = "6A55A1";
google_color_url = "6A55A1";
google_color_text = "ffffff";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>




<div class="maincontent">
<table border=0 align=center style="width: 70%; min-width: 500px; max-width: 1000px;"><tr><td>
{logged}


{content}


{lowregion}


{lowchat}


<script type="text/javascript"><!--
google_ad_client = "pub-6088426709750512";
google_alternate_color = "000000";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel ="8498960370";
google_page_url = document.location;
google_color_border = "220033";
google_color_bg = "000000";
google_color_link = "6A55A1";
google_color_url = "6A55A1";
google_color_text = "ffffff";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>


<SCRIPT LANGUAGE="JavaScript" type="text/javascript">
<!--

c=0;
h = screen.height;
w = screen.width;
r="?h="+h+"&w="+w+"&id={userid}";
document.write('<img src="getres.php'+r+'">');

// -->
</SCRIPT>

</td></tr></table></div>









<script language="JavaScript" type="text/javascript" src="wz_tooltip.php"></script>
</body></html>