<P><h1>Rules</h1></P>

<P>most of the rules are very loose, but a few must be followed  </P>

<P>users must report any bugs to a member of the staff, using a bug to your advantage will result in Character downgrading or deletion depending on the size.</P>

<P>100% originality, do not trace, steal or otherwise infringe on others work. also unless stated only your original characters may be used as the main picture. </P>

<P>it has to clearly fit with the subject matter, just drawing a random picture and adding text is not enough </P>

<P>critique is welcome on all pictures, do not post if you do not want someone to say its bad, but be polite, do not throw personal insults<br>
example:<br>
"this picture sucks, whoever drew it is a complete loser" <-- that is not allowed<br>
"This picture is pretty bad, i don't like it at all" <-- that is allowed but not smiled apon<br>
"This picture is pretty bad, i don't like it at all, perhaps if you were to make it fit with the subject matter more, and worked on more realistic poses and perspective it would be better" <-- thats ok<br>
 <br>
(my examples arent the best, but they should be enough) </P>

<P>no bigger than 800x800</P>

<P>jpgs, gifs and pngs only. no bitmaps... for now the gif thumbnail maker seems broken, until i or another developer fix it please use jpeg or png  </P>

<P>PG13+ this is "internet" PG ... non sexual nudity is okay but don't overdo it </P>

<P>Any attemp to hack or otherwise infringe on another users account will result in being banned from the server</P>

<P>Abusing language/behaviour is unwelcome</P>

<P>if rule breaking behaviour keeps up, the punishments will get worse.</P>

<P>Rule breakers might find themselves in the prison, nothing can be achieved in the prison until the sentence time is up.</P>