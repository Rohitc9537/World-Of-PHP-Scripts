<?php

//edit below, change localhost to your mysql hostname (usually localhost), change username to your mysql username, change password to your mysql password and change databasename to the name o fthe database that you executed the sql file into


mysql_connect("localhost","contest_user","contest_pass");
mysql_select_db("contest_db");