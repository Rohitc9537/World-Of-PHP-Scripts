<?php


session_cache_limiter('private');
/* set the cache expire to 30 minutes */
session_cache_expire(60*24);


 
 session_start();
 
 include("includes/config_mysql.php");
 include("includes/functions.php");
 include_once("Class/MySql.Class.php");
 include_once("CLIENT/LOGINClient.php");
 	
	$key=$_GET['key'];
	


		
		

				
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();
	
	$sql="select user from ".TABLE_LOGIN." where user_key='$key'";
	$result=$db->Query($sql);
	$r=@mysql_fetch_array($result);
		
	if(!empty($r['user'])){


		$_SESSION['user_ax']=$r['user'];									
		$perm=trim(Return_Permission($r['user']));
		$p=explode(" ",$perm);
		
		$j=0;
		$i=0;
		while($i<count($p)){							
			$url[$j]=$p[$i];
			$permissions[$j++]=$p[$i+1];							
			$i=$i+2;							
		}
 
		
		setPermissions($url,$permissions);
	
	}

		

 

  function Return_Permission($user){

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
 	$db->Connect(); 
 	
	
	$sql="select IDUser from ".TABLE_USERS." where nick='$user'";	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);	
	$IDUser=$r["IDUser"];
	
	
	$sql="select S.url as url,R.text  from ".TABLE_RESOURCES." S,".TABLE_PERMISIONS." P,".TABLE_ROLES." R where P.IDUser='$IDUser' and P.IDRole=R.IDRole and S.IDResource=P.IDResource";

	
	$result=$db->Query($sql);
	$permisions="";
	
	while($r=mysql_fetch_array($result)){
		$permisions.=$r["url"]." ".$r["text"]." ";
	}
	
   
   
	$db->Close();
	return $permisions;
	}
			
?>
<html>
	<head>
	<meta http-equiv="Pragma" content="no-cache">
 </head> 

<body>
am apelat.user=<? echo $_SESSION['user_ax'];?>
</body>
</html>
