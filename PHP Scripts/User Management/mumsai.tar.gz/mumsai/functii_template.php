<?php


function doHead()
{
global $message;
echo '
<html>
<head>
<link rel="stylesheet" href="stil.css" type="text/css" >
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
<script type="text/javascript" language="JavaScript1.2" src="'.HTTTP.'js/functions.js"></script>
<title>'.$message['Page title'].'</title>
</head>

';
}

function doPageHeader()
{
	
	echo"
	<h1><span>Authentification</span></h1>
	<h2><span></span></h2>
	";
}


function doQuickSummary()
{
global $currentTip;
echo "<p class='p1'>$currentTip</p>";

}

function doGoogle()
{
	
}


			
function doPreamble()
{
	global $currentFile;
	global $message;
	
	echo '<h3><span>'.$message['Welcome'].'</span></h3>';
	
	
	include("pages/pg_welcome.php");
	
	if(strcmp($currentFile,"new_user_terms")!=0 && strcmp($currentFile,"new_user")!=0)
		include("modules/form_login.php");
	


}

function doExplanation()
{
	
    global $currentMessage;
    global $currentFile;
    
    echo "	<h3><span>$currentMessage</span></h3>";
	
	if(file_exists("pages/pg_".$currentFile.".php"))
		include("pages/pg_".$currentFile.".php");
	else
		echo "Page not found";
    
    
    
 
    
}



function doParticipation()
{	

}


function doBenefits()
{

}


function doRequirements()
{
 
}

function doFooter()
{

}


function doLSelect()
{
	global $message;
	echo "<h3 class='select'><span>".$message['Menu']."</span></h3>";
	include("modules/menu_left.php");
}
	
	
function doLArchives(){
	
}


function doLResources()
{
Global $message;
echo "
<h3 class='resources'><span>".$message['Links']."</span></h3><ul>";
include("modules/links.php");
echo "</ul>";

}

?>
