<?

session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">


<?php
require_once("functii_template.php");
require_once("includes/functions.php");
require_once("CLIENT/config.php");
require_once("includes/settings.php");
require_once("includes/config_mysql.php");
require_once("Class/MySql.Class.php");
include(LANG."/messages.php");



$currentFile = $_GET["page"];
if(empty($currentFile))
	$currentFile = $_POST["page"];
	
	
if($currentFile==NULL){ 
	$currentFile="main";
	$currentTip="<b>".$message['Today is']." ".date("Y-m-d")."</b>";
	$currentMessage=$message['About'];
	}else
		setMessages($currentFile,$currentMessage,$currentTip);
			

include("template.php");

?>



