<?
//IMPORTANT:with ending slash
define (PATH,"/home/../"); 
//IMPORTANT:with ending slash
define (HTTTP,"http://www.your-mumsai-address.com/"); 

/*
 *  directory with language files
 */

define (LANG,"en"); 


define (FROM_EMAIL,"your@email-address.net"); 

define (USER_PAG,20); //how many users are displayed in "list users" option, from admin section


//This email is displayed on main page.Also is displayed on confirmation email sent to users.
define (ADMIN_EMAIL,"admin@email.com");



?>