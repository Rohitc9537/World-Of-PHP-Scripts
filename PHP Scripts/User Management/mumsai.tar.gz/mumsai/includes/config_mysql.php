<?
define (DB_NAME,"");         
define (DB_USER,"");         
define (DB_PASSWORD,"");                    

#
#Server tables
#
define(TABLE_USERS,"mumsai_users_test");                 /* keepind users information       */
define(TABLE_NEWS,"mumsai_news_test");                   /* users who want to receive news  */
define(TABLE_ADITIONAL_USER_INFO,"mumsai_ainfo_test");   /* aditional informations about users */  
define(TABLE_RESOURCES,"mumsai_sites_Test");                     /* list of sites that belongs to you */
define(TABLE_ROLES,"mumsai_roles_test");                          

define(TABLE_PERMISIONS,"mumsai_permisions_test");
define(TABLE_AUTOINCIDS,"mumsai_autoinc_Test");
define(TABLE_LOGIN,"mumsai_login_Test");



# tables for links managmenet

define(TABLE_LINKS,"mumsai_links_Test");
define(TABLE_LINKS_LABELS,"mumsai_links_labels_test");
define(TABLE_LABELS,"mumsai_labels_test");

?>