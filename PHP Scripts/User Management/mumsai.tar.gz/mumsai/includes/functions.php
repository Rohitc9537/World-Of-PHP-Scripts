<?


function SetUserKey($user,$key){
	
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();
	

	$sql="delete from ".TABLE_LOGIN." where user='$user'";
	@$db->Query($sql);


	$sql="insert into ".TABLE_LOGIN." values('$user','$key','".date("Y-m-d H:i:s")."')";
	@$db->Query($sql);
	$db->Close();
	
}			
	

#
#return permissions for an user
#
function getPermissions($url){
	$i=0;
	$perm='';
	while(true){
	
		$u=$_SESSION['Urls['.$i.']'];
				
		if(!empty($u)){
			
			if(strcmp($url,"http://".$u."/")==0 || strcmp($url,$u)==0 || strcmp($url,$u."/")==0 )
				return 
					$_SESSION['Permissions['.$i.']'];
			
			if(strcmp($u,"all")==0)
				$perm=$_SESSION['Permissions['.$i.']'];
						
					
		}else
			break;
		
		$i++;
	}
	
	
	
	return $perm;
}
function setPermissions($url,$perm){
	for($i=0;$i<count($url);$i++){
		$_SESSION['Urls['.$i.']']=$url[$i];
		$_SESSION['Permissions['.$i.']']=$perm[$i];
	}
}


#type=3, normal user, type=0 admin
function session_check($type="3") {

	$redirect=false;
		
	
	if(empty($_SESSION['user_ax']))
			$redirect=true;
			
	if(strcmp($type,"0")==0)//admin
		if(strcmp(getPermissions(HTTP),"Admin")!=0)
			$redirect=true;
			
	if(strcmp($type,"1")==0)//moderator
		if(strcmp(getPermissions(HTTP),"Moderator")!=0)
			$redirect=true;
			
	if(strcmp($type,"2")==0)//User
		if(strcmp(getPermissions(HTTP),"User")!=0)
			$redirect=true;
			
	if(strcmp($type,"01")==0)//ADmin si moderator
		if(strcmp(getPermissions(HTTP),"Moderator")!=0 && strcmp(getPermissions(HTTP),"Admin")!=0)			
			$redirect=true;
	
	
		
	if($redirect){
				echo "
				<script language='javascript'>
				location.href='index.php?page=error_login';
				</script>
				";
				exit();
	}
          
}
function setMessages($currentFile,&$currentMessage,&$currentTip){
	
	GLOBAL $message;
	switch($currentFile){
	
	case "new_user":{
			$currentTip="<h4>".$message['Registration Information']."</h4>";
			$currentMessage=$message['New user'];
			}break;		
	case "new_user_finish":{
			$currentTip=$message['Registered'];
			$currentMessage=$message['Company name or logo'];
			}break;
	
	case "choose_user":{	
			$currentTip="For <font color='red'><b>searching</b></font>, <a href='#help'>read the help</a> section on the <font color='red'>bottom</font> of the page ";
			$currentMessage="Select user wich you wish to operate";
			}break;	
			
	case "change_pass":{
			$currentTip="<h4>".$message['Change password']."</h4>";
			$currentMessage=$message['Company name or logo'];
			}break;		
	case "msg_profile_updated":{
			$currentTip="<h4>".$message['Finish']."</h4>";
			$currentMessage=$message['Company name or logo'];
		    }break;
		
	case "list_urls":{
			$currentTip="<h4>Listing url's</h4>";
			$currentMessage="TCS=authentification token key";
		}break;		
	case "new_user_terms":{
			$currentTip="<h4><font color='red'>".$message['Privacy']."</font></h4>";
			$currentMessage=$message['Company name or logo'];
			}break;
	case "list_users":{
			$currentTip="<h4>Listing users</h4>";
			$currentMessage="Axiologic registered users";
		}break;
		
	case "edit_profile":{
			$currentTip="<h4>Edit profile</h4>";
			$currentMessage="Axiologic registered users";
		}break;
	case "new_url":{
			$currentTip="<h4>New url</h4>";
			$currentMessage=$message['Company name or logo'];
		}break;
	default:{
			$currentMessage=$message['Company name or logo'];
			$currentTip="Today:".date("y-m-d");
			}
	}
	
}
?>