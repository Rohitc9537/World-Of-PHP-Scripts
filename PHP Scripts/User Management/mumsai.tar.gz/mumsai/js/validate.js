function is_email(val)
{
	var at = val.indexOf("@")
	if(at == -1){
	 return false
	 }
	else
	{
		var at_parts = val.split("@")
		if(at_parts[0].length < 1){
			return false
			}
		else{
			point = at_parts[1].indexOf(".")
			if(point == -1) return false
			else{
			  point_parts = at_parts[1].split(".")
			  if((point_parts[1].length < 2) || (point_parts[1].length > 3)) return false
			  else  return true
			}
		}
	}
}
function accept(str){
acc="~_`.!,:_#@$^&*+|{}/?=-0123456789abcdefghijklmnoprstuvxzqywABCDEFGHIJKLMNOPRSTUVXZYQW "

var ch
var found = true

if (str.length == 0) 
{
   return true
}
for (i = 0; i < str.length ;i++){
		ch = str.charAt(i)
		if(acc.indexOf(ch)==-1){
			found=false
			}
}
return found
		
}



