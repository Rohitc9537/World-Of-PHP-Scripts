<?php

 session_start();
 include("includes/config_mysql.php");
 include("includes/functions.php");
 include_once("Class/MySql.Class.php");
 include_once("CLIENT/LOGINClient.php");
 
 	
	
	//keya primita cu care se face asocierea
	$key=$_GET['key'];

	//e deja logat pe axiologic
	if(!empty($_SESSION['user_ax'])){
		
	//il salvez in tabela cu logati cu noua cheie
			
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();
	

	$sql="delete from ".TABLE_LOGIN." where user='".$_SESSION['user_ax']."'";
	$db->Query($sql);


	$sql="insert into ".TABLE_LOGIN." values('".$_SESSION['user_ax']."','$key','".date("Y-m-d H:i:s")."')";
	$db->Query($sql);
	$db->Close();
			

}	
?>
<html>
<head>
<head>
 <meta http-equiv="Pragma" content="no-cache">
 </head> 
</head>
<body>
</body>
</html>