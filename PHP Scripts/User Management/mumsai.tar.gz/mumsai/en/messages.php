<?
$message['Page title']="Your page title";
$message['Welcome']="Welcome";
$message['Menu']="Menu";
$message['Links']="Links";
$message['About']="About";
$message['Today is']="Today is";
$message['Profile']="Profile";
$message['Home']="Home";
$message['Log out']="Log out";

$message['MAIN_PAGE']="
(c) Your main page message here.. 
";

#START-messages for acivate user account
$message['Hello']="Hello";
$message['Thanks']="Thank for your registration";
$message["Go to main page"]="Go to main page";
$message["Error activating code"]="There was an error activating you code.Try later!";
$message["Access forbidden"]="Access forbidden";
#END -activate messages

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#START EDIT PROFILE
$message['Accepted chars']="Accepted chars:";
$message['letters and numbers']="letters and numbers";
$message['Web page']="Web page";
$message['Services']="Services"; //from wich sites want to receive emails with news, from example.
$message['Profile update']="Your profile has been updated.You can go to home page";
//description table header (of sites)
$message['Description']="Description";
$message['Select sites']="Select sites from wich you want to receive e-mail alertss.";
$message['Receive news']="Receive news";

#END

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#START NEW USER

$message['Registered']="You have registered! Thank you for visiting our pages";
$message['Company name or logo']="Put here your company name, for example..";
$message['Finish']="Finish";
$message['Accepted chars']="Accepted chars";
$message['I agree']="I Agree to these terms and am over or exactly 13 years of age";
$message['I do not agree']="I do not agree to these terms";
$message['Required']="Items marked with a * are required unless stated otherwise.";
$message['Password']="Password";
$message['Confirm Password']="Confirm password";
$message['Receive news']="Receive news";
$message['Registration completed']="Registration completed succes";
$message['Confirmation code sent']="A confirmation code has been sent to your email.";
$message['Registration Information']="Registration Information";
$message['Change password']="Change password";
$message['Privacy']="Privacy";
#END

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#CHANGE PASS
$message['Old password']="Old password:";
$message['New password']="New password:";
$message['Activation resend']="Enter email where to send activation code:";
#END



#other
$message['Recover password']="To recover your password, please enter your email and press <b>Send</b>";
$message['I forgot my pass']="I forgot my pass";
$message['Log out']="Log out";
$message['Resend activation code']="Resend activation code";
$message['New user']="New user";
$message['Welcome note']="For any <B>trubbles</b>, please contact using e-mail address <a href='mailto:".ADMIN_EMAIL."'>".ADMIN_EMAIL."</a><br>";














?> 

