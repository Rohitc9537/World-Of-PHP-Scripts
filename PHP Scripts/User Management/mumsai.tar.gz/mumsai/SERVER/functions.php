<?
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");


function Login($user,$key){

/*-----send logout command-----*/
	
		
		
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	
	$db->Connect(); 

	$sql="delete from ".TABLE_LOGIN." where user='$user'";
	$db->Query($sql);
		
	$sql="insert into ".TABLE_LOGIN." values('".$user."','".$key."','".date("Y-m-d H:i:s")."')";
	$db->Query($sql);
		
	
	$db->Close();
	
	
	return true;
}



function Logout($user){

/*-----send logout command-----*/

	@require_once("../CLIENT/LOGOUTClient.Class.php");
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	
	
	$sql="delete from ".TABLE_LOGIN." where user='$usr'";	
	$db->Query($sql);
	
	
	$sql="select url  from ".TABLE_RESOURCES."";	
	$result=$db->Query($sql);
	

	
	
	while(($r=mysql_fetch_array($result))){		
	   
		@$c=@new CLOGOUTClient();
		@$c->Connect("http://".$r['url']."/SERVER/server.php");
		@$c->SendLogout($user);
		
	}
	return true;
}


function GetUserByKey($key){


	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	
 	$db->Connect();	
 	
 	
	$sql="select * from ".TABLE_LOGIN." where user_key='$key'";
		@$db->Query($sql);		
		$result=@$db->Query($sql);		
		
		$r=@mysql_fetch_array($result);		
	
	$db->Close();
	

	
	return $r["user"];
		
}


function ReturnField($id,$field,$type){

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	
 	$db->Connect();	
 	
 	$f=NULL;
 	
 	if($type==true){
		$sql="select $field as result from ".TABLE_USERS." where nick='$id'";	
		$result=$db->Query($sql);		
		$r=mysql_fetch_array($result);
		$f=$r['result'];
							
								
	}else{
	
		$sql="select IDUser  from ".TABLE_USERS." where nick='$id'";	
		$result=$db->Query($sql);		
		$r=mysql_fetch_array($result);
		$iduser=$r['IDUser'];

		$sql="select $field as result from ".TABLE_ADITIONAL_USER_INFO." where IDUser='$iduser'";	
		$result=$db->Query($sql);
		
		$r=mysql_fetch_array($result);
		$f=$r['result'];
	}
	$db->Close();
	
	return $f;	
		
}


function Return_TCS($http){
	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
 	$db->Connect(); 
 	
 	#
	# search tcs for an url
	#
	$sql="select TCS from ".TABLE_RESOURCES." where url='$http'";	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);	
	$db->Close();
	
	return $r["TCS"];	
}

function Return_password($nick){
	
	
	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);

 	$db->Connect(); 
 	
 	
	$sql="select password,time_register,code from ".TABLE_USERS." where nick='$nick'";	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);	
	$db->Close();
	
	
	$timediff = time() - strtotime($r['time_register']);
	$d = floor(($timediff/86400));

	$pass='';
	
	//a user can login 7 days without confirm his code..
	if(!empty($code)){
		if($d<7)
			$pass=$r["password"];
	}else
		$pass=$r["password"];
	
	return $pass;
	
	
	
}

function Return_Permission($user){

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
 	$db->Connect(); 
 	
	$sql="select IDUser from ".TABLE_USERS." where nick='$user'";	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);	
	$IDUser=$r["IDUser"];
		
	
	$sql="select S.url as url,R.text  from ".TABLE_RESOURCES." S,".TABLE_PERMISIONS." P,".TABLE_ROLES." R where P.IDUser='$IDUser' and P.IDRole=R.IDRole and S.IDResource=P.IDResource";

	
	$result=$db->Query($sql);
	$permisions="";
	
	while($r=mysql_fetch_array($result)){
		$permisions.=$r["url"]." ".$r["text"]." ";
	}
	

	
	
	$db->Close();
	return $permisions;
}

#
#is token valid
#

function Is_ok($RO,$http,$autoincID,$validity_day,$md5){


	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
 	$db->Connect(); 	 
 	
 	$http=base64_decode($http); 
 	
	$sql="select IDResource,TCS from ".TABLE_RESOURCES." where url='$http'";	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);
	$IDResource=$r["IDResource"];
	$TCS=$r["TCS"];	

	$sql="select maxNumber,Date from ".TABLE_AUTOINCIDS." where IDResource='$IDResource'";	
	$result=$db->Query($sql);	
	$r=mysql_fetch_array($result);
		
	$maxNumber=$r['maxNumber'];
	
	$curr_date=date("Y-m-d H:i");

	//first time..
	if($r["maxNumber"]==''){	
		$sql="INSERT into ".TABLE_AUTOINCIDS." values(0,'$IDResource','0','$curr_date')";	
		$db->Query($sql);	
		$maxNumber=0;	
	
	}else{
	
		$date=$r["Date"];
		$date=substr($date,0,strpos($date," "));
		
		list($year,$month,$day)=split('[:-]',$date);
		
		
		#
		#a new day has began
		#
		if(date("Y-m-d")>date("Y-m-d",mktime(0,0,0,$month,$day,$year))){
			$maxNumber=-1;
		}
		
		
		if($autoincID>=$maxNumber){
				$maxNumber++;
				}
				else
					return NULL;                                 //We received a smaller id, than the server id
		
		
		#
		# update id's
		#		
		$sql="update ".TABLE_AUTOINCIDS." set maxNumber='$maxNumber' where IDResource='$IDResource'";	
		$db->Query($sql);
		
		$sql="update ".TABLE_AUTOINCIDS." set Date='$curr_date' where IDResource='$IDResource'";	
		$db->Query($sql);
		
		
			
	}
	
	$curr_date=date("Y-m-d");
	
	
	$TC=md5($RO.base64_encode($http).$autoincID.$validity_day.$TCS);
	
 	
	
	if(strcmp($md5,$TC)==0){
		$is_ok=Generate_TS($http,$maxNumber,$validity_day,$TCS);
	
		}
			else
				$is_ok=NULL;
	
	
	$db->Close();	
	
	
	return $is_ok;
	
}

function Generate_TS($http,$id,$day,$TCS){
	$RO=randomstring(32);

	$md5=md5($RO.base64_encode($http).$id.$day.$TCS);
	
	$result=array("RO"=>$RO,"http"=>base64_encode($http),"id"=>$id,"day"=>$day,"md5"=>$md5);
	
	return $result;

	
}


function randomstring($length) {

   $random = rand(1,20000);
   
   $string = md5($random);
   
   $output = substr($string,0,$length);

   return $output;
}
	


?>
