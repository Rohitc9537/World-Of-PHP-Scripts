<?php
session_start();
/*********************************************
  Axiologic
  ********************************************
  Copyright  2004 - 2005 by Axiologic Team
  http://www.axiologic.com

  SOAP SERVER
  
  
  
  $Version: 1.0
  $Date: 2005/07/1 
**********************************************/

require_once("functions.php");
// Clasele SOAP
require_once('./nusoap.php');



function SendLogin($user,$key){
	
    Login($user,$key);
    return array("result"=>true);

}


function SendLogout($user){
	
	    Logout($user);
	    return array("result"=>true);

}


//return the nick with the key $key
function WhoIsUser($key){
	
		$user=GetUserByKey($key);
		if(!empty($user))
			$perm=Return_Permission($user);
			
		return array("user"=>$user,"permissions"=>$perm);	
}

#
#Receive from client name,password and a token client .The server checks if TCS is valid
#Parametri:
#           $N=nick,$P=parola ( $N.$P.TCS), $C_RO=random from client,$C_HTTP=from where the reques came
#           $C_id=id client (automated incremented),$C_day-valibility day
#           $C_md5=md5(RO.base64_encode(HTTP).id.day.TCS-from client-)
#
function Validate_Passwd($N,$P,$C_RO,$C_http,$C_id,$C_day,$C_md5){
	
	#
	#password for $N
	#	
	
		
	$user_p=Return_password($N);

	
	#
	#Find TCS(unique key) for $C_http 
	#
	$tcs=Return_TCS(base64_decode($C_http));				
	
	if( strcmp(md5($N.$user_p.$tcs),$P)==0)
		$valid=1;
			else 
				$valid=0;
				
	#
	# TC coming from client isn;t valid
	#
	if(strcmp(md5($C_RO.$C_http.$C_id.$C_day.$tcs),$C_md5)!=0)
			$valid=0;
	
	if($valid){
		#
		#Server send md5(TC.TCS) , permissions and md5(permisions.TC.TCS)
		#
		$TC=md5($C_RO.$C_http.$C_id.$C_day.$C_md5.$tcs);
				
		$perm=Return_Permission($N);
		
		
		$pmd5=md5($perm.$C_RO.$C_http.$C_id.$C_day.$C_md5.$tcs);
		
		
		
		
		return array("TC"=>$TC,"permissions"=>$perm,"pmd5"=>$pmd5);
		
	}else
		#
		# Combination $N/$P not valid, keys don't match
		#
		return array("TC"=>NULL);
				
}


function Verify($RO,$http,$id,$day,$md5) {
	

	$r=Is_ok($RO,$http,$id,$day,$md5);	
		
	
	return array( "RO"  =>$r["RO"], "http"  =>$r["http"],"id"  =>$r["id"],"day"  =>$r["day"],"md5"  =>$r["md5"]);
    
    }

function getField($id,$field_name,$type){

	return array("field"=>ReturnField($id,$field_name,$type));
	     
}


$server = new soap_server;


$server->register('Verify');
$server->register('SendLogout');
$server->register('SendLogin');
$server->register('Validate_Passwd');
$server->register('getField');
$server->register('WhoIsUser');


$fault = $server->fault('soap:Server','',$error);



$server->service($HTTP_RAW_POST_DATA);
?>
