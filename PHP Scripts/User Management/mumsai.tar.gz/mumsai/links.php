<?
require_once("functii_template.php");
require_once("includes/functions.php");
require_once("includes/settings.php");
require_once("includes/config_mysql.php");
require_once("Class/MySql.Class.php");


$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$sql="select * from labels";
$result=$db->Query($sql);

while($r=mysql_fetch_array($result))
$items=$r['name'];


foreach($items as $label){

	
	$sql="select a.link,a.description,a.id from links a,labels b,links_labels c where c.id_label=b.id and c.id_link=a.id and b.name='$label'";
	$result=$db->Query($sql);
	
	if(mysql_num_rows($result)>0){
	$content='
	<rss version="2.0">
	<channel>
    <title>axiologic.net</title>
    <link>
    http://www.axiologic.net
    </link>
    <description>
	Axiologic links
    </description>
    <language>ro-ro</language>
    <copyright> Axiologic Research SRL 2005, Iasi, Romania </copyright>
    <pubDate>'.date("D, d M Y H:i:s").' +0200</pubDate>
	';
    
	
	while($r=mysql_fetch_array($result)){
			
			$content.='
			<item>
			<title>'.$r['link'].'</title>
			<link>'.$r['link'].'</link>
			<description>
			'.$r['description'].'
			</description>
			</item>';

	}
	
	


	$content.="
	</channel>
	</rss>
	";

	echo "<br>".$label." generated..<br>";
	
	$label=preg_replace("'\s+'","_",$label);

	$h=fopen("/home/axnet/public_html/links/$label.rss","w");
	fwrite($h,$content);
	fclose($h);

	
}
}


$db->Close();
?>