<?
//how to use..
//include("this file")..then use links[] array

define('MAGPIE_DIR', '');
require_once('links_parser/magpierss/rss_fetch.inc');
define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');

	
	
	$rss = @fetch_rss(HTTTP."links/categories.xml");
	$links=array();
		
		if(count($rss->items)>0 ){	
		
		
		foreach ($rss->items as $item) {

			$href = trim($item['link']);
			
			$title = $item['title'];	
				
			$rss_links = @fetch_rss($href);
			
			foreach ($rss_links->items as $item_links) {

				$href_link = trim($item_links['link']);				
				$description_link = trim($item_links['description']);	
				$name = trim($item_links['title']);	
				if($href_link!="http://".$_SERVER['HTTP_HOST'])				
				$links[$name]="<a $class href='$href_link' title='$title: $description_link'>$name</a>";
			}

		}
		
		
		}
					
			
?>
