<?
require ("../includes/config_mysql.php");
require ("../Class/MySql.Class.php");

$no_fields=$_POST["no_fields"];
$step=$_POST["step"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-color: #33CCFF;
}
-->
</style>
<script>
	
</script>
</head>

<body>
<center><img src="setup.jpg"/></center>
<table width="80%"  border="1" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF" bordercolor="#FF0000">
  <tr>
    <td height="111" valign="top" bordercolor="#FFFFFF" bgcolor="#FFFFFF"  align="center">
		<br>		
		<form name="frm" action="<?php echo $PHP_SELF; ?>" method="post" enctype="application/x-www-form-urlencoded">
		<?
		if(empty($step)){
		?>
		<h3>Step 1</h3>
		Enter number of fields:
		<select name="no_fields">
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
			<option>7</option>
			<option>8</option>
			<option>9</option>
			<option>10</option>
			<option>11</option>
			<option>12</option>
			<option>13</option>
			<option>14</option>
			<option>15</option>
			<option>16</option>
			<option>17</option>
		</select>
		<input type="hidden" value="2" name="step"/>	
		<br>
		Help:Users informations are kept in two database tables, one with principal fields, and another with wich fields do you want. (Eg: Name,Country...)
		<?
		}
		if($step==2){
			echo "<h3>Step 2-Specifying fields</h3>";
			for($i=0;$i<$no_fields;$i++){
				?>
				<!-- --------------------------PASUL 2--------------------------- -->
				<br>
				Display name
				<input name="name<? echo $i; ?>" type="text" size="15" maxlength="15"/>
				Field Name
				<input name="field<? echo $i; ?>" type="text" size="15" maxlength="15"/> type 
				<select name="field_type<? echo $i; ?>">
					<option>VARCHAR</option>
					<option>Text</option>
					<option>Int</option>
					<option>Date</option>
					<option>Date-time</option>
				</select>	
				length
				<input type="text" name="length<? echo $i; ?>" size="10" maxlength="3"/>
									
				
				<?			
			}#for
			
			echo "<input type='hidden' value='3' name='step'/>";
			echo "<input type='hidden' value='".$no_fields."' name='no_fields'/>";
			echo "<br><br><font color='red'>Note:</font> int(1) means Yes/No.Also install dir must have write permissions.";
			
		}#step 2	
		if($step==3){
			
			/*			 			 
			 *  Crearea tabelelor
			 *********************
						         */ 
						         
			$no=$_POST['no_fields'];
			$sql="CREATE TABLE ".(TABLE_ADITIONAL_USER_INFO)." (IDUser int(8),WebPage varchar(255), ";
			
			#
			#In fisier se vor pastra configuratia campurilor custom
			#Format - camp tip lungime
			#
			$handle=fopen("../modules/server_fields.cfg","w");
			
			for($i=0;$i<$no;$i++){
					$display[$i]=$_POST['name'.$i.''];
					$name[$i]=$_POST['field'.$i.''];
					$type[$i]=$_POST['field_type'.$i.''];
					$length[$i]=$_POST['length'.$i.''];
					
					if(strcmp($type[$i],"Date")!=0 && strcmp($type[$i],"Date-time")!=0 && strcmp($type[$i],"Text")!=0)
						$sql.=$name[$i]." ".$type[$i]."(".$length[$i].")";											
						else
						$sql.=$name[$i]." ".$type[$i];
						
						
					if($i!=$no-1)
						$sql.=",";
						
					fwrite($handle,$display[$i]."-".$name[$i]."-".$type[$i]."-".$length[$i]."\n");
					
			}
			
			$sql.=")";
			
			
			$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
			$db->Connect();
			if($db->Query($sql))
				echo "Table ".(TABLE_ADITIONAL_USER_INFO)." created";
					else						
						echo "Table ".(TABLE_ADITIONAL_USER_INFO)." failed";
			
			$db->Close();
			fclose($handle);
			
		}#step 3
		?>
	<br>
	<br>	
	<? 
	if($step!=3 ){ 
	?>		
		<input type="submit" value="Next step"/>
	<? 
	} 
	?>
	</form>
	</td>
  </tr>
</table>
</body>
</html>
