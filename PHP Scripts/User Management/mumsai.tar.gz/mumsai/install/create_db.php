<?
require_once("../includes/config_mysql.php"); 
require_once("../CLIENT/config.php"); 
require_once("../Class/MySql.Class.php"); 
$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();



echo "Creating tables...<br>";




$sql="
CREATE TABLE ".TABLE_LABELS." (
  `id` int(8) NOT NULL auto_increment,
  `name` text,
  `description` text,
  PRIMARY KEY  (`id`)
)";

if ($db->Query($sql))
 echo "Table ".TABLE_LABELS." created<br>";
	else 
	echo "Table ".TABLE_LABELS." failed<br>";



$sql="
CREATE TABLE ".TABLE_LINKS." (
  `id` int(8) NOT NULL auto_increment,
  `link` text,
  `description` text,
  `name` text,
  PRIMARY KEY  (`id`)
)";


if ($db->Query($sql))
 echo "Table ".TABLE_LINKS." created<br>";
	else 
	echo "Table ".TABLE_LINKS." failed<br>";



$sql="
CREATE TABLE ".TABLE_LINKS_LABELS." (
  `id` int(8) NOT NULL auto_increment,
  `id_link` int(8) default NULL,
  `id_label` int(8) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=34 ;
";


if ($db->Query($sql))
 echo "Table ".TABLE_LINKS_LABELS." created<br>";
	else 
	echo "Table ".TABLE_LINKS_LABELS." failed<br>";

$sql="CREATE TABLE ".TABLE_LOGIN." (user varchar(255),user_key varchar(255),login_time DATETIME)";
if ($db->Query($sql))
 echo "Table ".TABLE_LOGIN." created<br>";
	else 
	echo "Table ".TABLE_LOGIN." failed<br>";




echo "Creating tables...<br>";
$sql="CREATE TABLE ".TABLE_NEWS." (IDUser int(8),IDResource int(8),domain varchar(255))";
if ($db->Query($sql))
 echo "Table ".TABLE_NEWS." created<br>";
	else 
	echo "Table ".TABLE_NEWS." failed<br>";


		
#
#Tabelele pentru server 
#





$sql="CREATE TABLE ".TABLE_USERS." (IDUser INT NOT NULL AUTO_INCREMENT PRIMARY KEY,nick VARCHAR(20),email VARCHAR(50),password VARCHAR(255),code varchar(255),time_register datetime)";
if ($db->Query($sql))
 echo "Table users created<br>";
	else 
	echo "Table users failed<br>";

$sql="CREATE TABLE ".TABLE_RESOURCES." (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,IDResource  int (8),url varchar(255),TCS VARCHAR(255),description varchar(255))";
if ($db->Query($sql))
 echo "Table ".TABLE_RESOURCES." created<br>";
	else 
		echo "Table ".TABLE_RESOURCES." failed<br>";

$sql="CREATE TABLE ".TABLE_ROLES." (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,IDRole int(1),text VARCHAR(255))";
if ($db->Query($sql))
 echo "Table ".TABLE_ROLES." created<br>";
	else 
		echo "Table ".TABLE_ROLES." failed<br>";


$sql="CREATE TABLE ".TABLE_PERMISIONS." (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,IDUser int(8),IDRole int(1),IDResource int(8))";
if ($db->Query($sql))
 echo "Table ".TABLE_PERMISIONS." created<br>";
	else 
		echo "Table ".TABLE_PERMISIONS." failed<br>";

$sql="CREATE TABLE ".TABLE_AUTOINCIDS." (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,IDResource int(8),maxNumber int(8),Date datetime)";
if ($db->Query($sql))
 echo "Table ".TABLE_AUTOINCIDS." created<br>";
	else 
		echo "Table ".TABLE_AUTOINCIDS." failed<br>";

$sql="CREATE TABLE ".TABLE_AUTOINC_CLIENT." (id int(8),valid_date datetime)";
if ($db->Query($sql))
 echo "Table ".TABLE_AUTOINC_CLIENT." created<br>";
	else 
	echo "Table ".TABLE_AUTOINC_CLIENT." failed<br>";


echo "<br>Inserting data...<br>";


#
#Inserare de date prestabilite
#

$sql="insert into ".TABLE_USERS." values(0,'admin','','21232f297a57a5a743894a0e4a801fc3','','".date("Y-m-d H:i:s")."')";
if ($db->Query($sql))
 echo "insert to ".TABLE_USERS." succes";
	else 
		echo "insert to ".TABLE_USERS." failed<br>";
	


$sql="insert into ".TABLE_RESOURCES." values(0,0,'all','','')";
if ($db->Query($sql))
 echo "insert to ".TABLE_RESOURCES." succes";
	else 
		echo "insert to ".TABLE_RESOURCES." failed<br>";


$sql="insert into ".TABLE_RESOURCES." values(0,1,'".HTTP."','b6a970f76sdbc5f88fh4ae153d54a903','')";
if ($db->Query($sql))
 echo "insert to ".TABLE_RESOURCES." succes";
	else 
		echo "insert to ".TABLE_RESOURCES." failed<br>";



	


echo "Inserting Roles...<br>";
#
#Reguli
#
$sql="insert into ".TABLE_ROLES." values(0,0,'Admin')";
if ($db->Query($sql))
 echo "insert to ".TABLE_ROLES." succes";
	else 
		echo "insert to ".TABLE_ROLES." failed<br>";
		
$sql="insert into ".TABLE_ROLES." values(0,1,'Moderator')";
if ($db->Query($sql))
 echo "insert to ".TABLE_ROLES." succes";
	else 
		echo "insert to ".TABLE_ROLES." failed<br>";
		
$sql="insert into ".TABLE_ROLES." values(0,2,'User')";
if ($db->Query($sql))
 echo "insert to ".TABLE_ROLES." succes";
	else 
		echo "insert to ".TABLE_ROLES." failed<br>";

$sql="insert into ".TABLE_ROLES." values(0,3,'InternetUser')";
if ($db->Query($sql))
 echo "insert to ".TABLE_ROLES." succes";
	else 
		echo "insert to ".TABLE_ROLES." failed<br>";

#
#Permisiuni pt admin
#

$sql="insert into ".TABLE_PERMISIONS." values(0,1,0,0)";
if ($db->Query($sql))
 echo "insert to ".TABLE_PERMISIONS." succes";
	else 
		echo "insert to ".TABLE_PERMISIONS." failed<br>";

		
$db->Close();
?>