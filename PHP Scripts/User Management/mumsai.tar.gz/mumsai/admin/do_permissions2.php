<?
/****************************************

	Script de prelucrare date formular.
Insereaza noi permisiuni in baza de date

****************************************/
session_start();
require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$iduser=$_POST['iduser'];
$idres=$_POST['idres'];
$permission=$_POST['permission'];



$sql="update ".TABLE_PERMISIONS." set IDRole='$permission' where IDUser='$iduser' and IDResource='$idres'";
$result=$db->Query($sql);
if(!$result)
	die("Error updating permission");
else
	header("Location:".HTTTP."index.php?page=permissions_step2&nick=".$_SESSION['choosen_nick']);
?>