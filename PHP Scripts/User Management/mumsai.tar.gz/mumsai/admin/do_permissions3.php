<?
session_start();
require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$iduser=$_POST['iduser'];
$url=$_POST['url'];
$permission=$_POST['permission'];



$sql="select IDResource from ".TABLE_RESOURCES." where url='$url'";
$result=$db->Query($sql);
$r=mysql_fetch_array($result);
$idres=$r["IDResource"];


$sql="insert into ".TABLE_PERMISIONS." values (0,'$iduser','$permission','$idres')";
$result=$db->Query($sql);
if(!$result)
	die("Error inserting permission");
	else
		header("Location:".HTTTP."index.php?page=permissions_step2&nick=".$_SESSION['choosen_nick']);
?>