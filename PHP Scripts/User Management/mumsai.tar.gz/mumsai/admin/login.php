<form action="admin/do_login.php" method="post">
<table width="229" height="90" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="27" colspan="2" headers="25" align="center"><font color='red'><b>Login area</b></font></td>
  </tr>
  <tr>
    <td width="86"><div align="center">Password</div></td>
    <td width="146"><input type="text" name="passwd"></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" name="Login" value="Submit"></td>
  </tr>
</table>
</form>
