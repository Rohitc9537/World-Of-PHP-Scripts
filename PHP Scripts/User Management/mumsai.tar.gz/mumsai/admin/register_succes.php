<?
$request_site=base64_decode($_GET['site']);
?>
<table width="80%"  border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF" bordercolor="#FF0000">
		<tr>
			<td height="111" valign="top" bordercolor="#FFFFFF" bgcolor="#FFFFFF"  align="center">
			<h2>Registration completed succes</h2>		
			
			A confirmation code has been sent to your email. <font color='red'>Login </font>  <a href="http://<? echo $request_site; ?>">here</a> for site <? echo $request_site; ?><br>
				
			</td>
		</tr>
</table>
<br>
	