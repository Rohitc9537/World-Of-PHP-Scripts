<?

if(!empty($_SESSION["admin_ax"])){

	$id=$_GET['idres'];   //idresource
	$nick=$_GET['nick'];  //nick
	$iduser=$_GET['iduser'];  //nick

	#
	#Modificare permisiuni
	#
	if(!empty($id)){
	   echo "Select new permission for user <b>$nick</b>";
   	   ?>
   <table border="0">
   <tr>
   <td align="left">
   <form action="admin/do_permissions2.php" method="post">
   <select name="permission">
	   <option>1</option> 
  	   <option>2</option>   
   	   <option>3</option> 
   </select>
   <input type="submit" value="Modify"/>
   <input type="hidden" name="iduser" value="<? echo $iduser; ?>"/>
   <input type="hidden" name="idres" value="<? echo $id; ?>"/>
   <br>
   <br>
   <br>
   <ul>
   <font color="#000099">Legend:</font><br>
   
   <li>1=Moderator</li>
   <li>2=User</li>
   <li>3=InternetUser</li>
   </ul>
   </form>
   </td>
   </tr>
   </table>
   <?	
   }else{ //adaugare permisiune
	
	echo "Select site and permision for user  <b>'$nick'</b><br>";
	
	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 
	
	$sql="select url,IDResource  from ".TABLE_RESOURCES; 
	
	$result=$db->Query($sql);

	echo "<form action='admin/do_permissions3.php' method='post'>
	<select name='url'>";
	while($r=mysql_fetch_array($result))
		echo "<option>".$r["url"]."</option>";
	echo "</select>
	<select name='permission'>
		<option>1</option>
		<option>2</option>
		<option>3</option>
	</select>		
	<input type='submit' value='Add'/>
	<input type='hidden' name='iduser' value='$iduser'/>
	
	</form>";
	
   }
	
}

?>