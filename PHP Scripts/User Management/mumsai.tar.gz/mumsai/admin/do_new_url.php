<?
require_once("../includes/config_mysql.php");
require_once("../includes/settings.php");
require_once("../Class/MySql.Class.php");

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$url=$_POST['url'];
$description=$_POST['description'];
$update=$_POST['update'];//este si idu resource-ului de updatat

$sql="select count(IDResource) as result from ".TABLE_RESOURCES." where url='$url'";
$result=$db->Query($sql);
$r=mysql_fetch_array($result);
$result=$r["result"];
if($result==0){

	$sql="select max(IDResource) as  max from ".TABLE_RESOURCES;
	$result=$db->Query($sql);
	$r=mysql_fetch_array($result);
	$max=$r["max"]+1;

	$TCS=md5(base64_encode($url).date("U"));
	
	
		

	if(empty($update)){
		$message = '
		<html>
		<head><title>New url</title></head>
		<body>			
			<p>TCS for '.$url.'<br/>
			'.$TCS.'<br/>			
			</p>
			Link for new user: '.HTTTP.'index.php?page=new_user_terms&site='.base64_encode($url).'<br>
			Link for -I forgot password- :'.HTTTP.'index.php?page=forgot_pass
		</body>
		</html>';
		$headers = "MIME-Version: 1.0\r\n";
		$headers.= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers.= "From:".FROM_EMAIL."\r\n";
		
		if(@mail(ADMIN_EMAIL,"TCS for ".$url."",$message,$headers)){
			#
			#Date ce trebuiesc afisate adminului
			#	
			$message=base64_encode("
			<br>
			<font color='red'>TCS sent at ".ADMIN_EMAIL."</font>:<br>
			"); 
			}
			else
				$message=base64_encode("Failed to send email");
		}else
			$message="Url updated succes";
	
}else
	$message="Already exist";
	
	
	
if(!empty($update)){
		$sql="update ".TABLE_RESOURCES." set url='$url' where IDResource='$update'";
		@$db->Query($sql);
		$sql="update ".TABLE_RESOURCES." set description='$description' where IDResource='$update'";
		@$db->Query($sql);
		}
		else{
			$sql="insert into ".TABLE_RESOURCES." values(0,'$max','$url','$TCS','$description')";	
			@$db->Query($sql);
			}	


if(empty($update))
	echo "<script>
		location='".HTTTP."index.php?page=new_url_finish&content=".$message."'
	</script>";
	
	else	
		echo "<script>
				location='".HTTTP."/index.php?page=list_urls'
			</script>";
	
	
	
?>
