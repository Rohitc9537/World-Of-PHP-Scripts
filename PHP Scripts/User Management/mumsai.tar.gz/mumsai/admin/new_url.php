<form action="admin/do_new_url.php" method="post">
<table border='0'>
<tr>
	<td>
	Enter URL:
	</td>	
	<td>
	http://<input type="text" name="url" maxlength="255" size="25"/><br>
	</td>
</tr>
<tr>
	<td>
	Description:
	</td>
	<td>
	<input type="text" name="description" maxlength="255" size="25"/><br>
	</td>
</tr>
</table>

<input type="submit" value="Add"/>

</form>