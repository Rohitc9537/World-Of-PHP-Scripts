<?php

 session_start();
 include("includes/config_mysql.php");
 include("includes/functions.php");
 include_once("Class/MySql.Class.php");
 include_once("CLIENT/LOGINClient.php");
 	
	$key=$_GET['key'];
	
				
	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();
	
	//invalidez cheia..pastez inrgistrarea ca sa imi ramana last login
	$sql="update ".TABLE_LOGIN." set user_key='-'";
	$db->Query($sql);
	
	$_SESSION['user_ax']='';
			
?>
<html>
<head>
<head>
 <meta http-equiv="Pragma" content="no-cache">
 </head> 
</head>
<body>
</body>
</html>