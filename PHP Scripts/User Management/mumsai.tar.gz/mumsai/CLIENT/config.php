
<?
/*
 * Config file for SOAP CLIENT
 */

//server address
define(SERVER,"http://www.your-mumsai server here/SERVER/server.php");

//leave this value unchanged until you install application, then you can change it from admin section
define(TCS,"b6a970f76sdbc5f88fh4ae153d54a903");

//server address without http://, and ending slash
//eg: www.yahoo.com
define(HTTP,"www.your-mumsai-server.com");


define(TABLE_AUTOINC_CLIENT,"mumsai_autoinc_client_test");

?>