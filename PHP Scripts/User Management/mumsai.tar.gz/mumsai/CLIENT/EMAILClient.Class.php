<?

  

require_once('nusoap.php');
require_once('config.php');



class CEMAILClient{

	var $client;        //obiect soap-client
	
	
	#
	# Constructor-initializari
	#
	function Connect($address){
	
	
	
		$this->client = new soapclient($address);
		
	}
	
	
	#
	# Inchiderea conexiunii cu serverul
	#
	function Close(){
		unset($this->client);		
	}

	
	
	function Send_Update($email,$action){
	
	    // trimitere n,p,ts si TC generat mai sus
		$param = array("email" => $email,"action"=>$action);
		               			
		//namespace-ul functiei
		$namespace="urn:xmethods-BNUpdate";
	
		$result = $this->client->call('Update',$param,$namespace);
		
						
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else							
				return $result["result"];
	
		
	}
}

?>			