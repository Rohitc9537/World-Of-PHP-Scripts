<?
require_once('nusoap.php');
require_once('config.php');

class CLOGOUTClient{

	var $client;        //obiect soap-client
	
	
	#
	# Constructor-initializari
	#
	function Connect($address){
	
	
	
		$this->client = new soapclient($address);
		
	}
	
	
	#
	# Inchiderea conexiunii cu serverul
	#
	function Close(){
		unset($this->client);		
	}

	
	
	function SendLogout($user){
	
	    // trimitere n,p,ts si TC generat mai sus
		$param = array("user" => $user);
		               			
		//namespace-ul functiei
		$namespace="urn:xmethods-BNUser";
	
		$result = $this->client->call('SendLogout',$param,$namespace);
		
						
		if (isset($fault)) {			
			return false;
			} 
			else							
				return $result["result"];
			
	}
}

?>			