<?
require_once('nusoap.php');
require_once('config.php');

class CLoginClient{

	var $client;        //obiect soap-client
	
	
	#
	# Constructor-initializari
	#
	function Connect($address){
	
	
	
		$this->client = new soapclient($address);
		
	}
	
	
	#
	# Inchiderea conexiunii cu serverul
	#
	function Close(){
		unset($this->client);		
	}

	
	
	function Who_Is_Key($key){
	
	    // trimitere n,p,ts si TC generat mai sus
		$param = array("key" => $key);
		               			
		//namespace-ul functiei
		$namespace="urn:xmethods-BNWhoIsKey";
	
		$result = $this->client->call('WhoIsKey',$param,$namespace);
		
						
		if (isset($fault)) {			
			return false;
			} 
			else							
				return $result["result"];
			
	}
}

?>			