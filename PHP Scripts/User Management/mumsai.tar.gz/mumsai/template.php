<?php
   doHead();
?>

<body> 

<div id="container">
	<div id="intro">
		<div id="pageHeader">
    		<?php
               		doPageHeader();
	        ?>
		</div>

		<div id="quickSummary">
       		<?php
			doQuickSummary();
		?>
		</div>

		<div id="preamble">
    	     	<?php
                	doPreamble();
             	?>
		</div>
	</div>

	<div id="supportingText">
			
		<div id="explanation">
				
       		<?php
                	doExplanation();
            	?>
		</div>
		


	  	<div id="requirements">
       		<?php
                	doRequirements();
            	?>
		</div>
		
	</div>


	<div id="linkList">
		<div id="linkList2">
			<div id="lselect">
           		<?php
                	      doLSelect();
		        ?>
			</div>

			<div id="larchives">
       		   	<?php
			      doLArchives();
                	?>
			</div>

			<div id="lresources">
       	    		<?php
                    		doLResources();
                	?>
			</div>
		</div>
	</div>

</div>


<div id="extraDiv1"><span></span></div><div id="extraDiv2"><span></span></div><div id="extraDiv3"><span></span></div>
<div id="extraDiv4"><span></span></div><div id="extraDiv5"><span></span></div><div id="extraDiv6"><span></span></div>

</body>

</html>
