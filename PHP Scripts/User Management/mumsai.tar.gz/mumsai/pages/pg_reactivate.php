<?
global $message;
?>

<form method='post' action='modules/do_reactivate.php'>
<? echo $message['Activation resend'];?><br>
<input type='text' name='email'/><br>
<input type='submit' value='Resend'/>
</form>