<?
//la pag asta are acces numai admin si moderatoru
session_check("01");
require_once("includes/settings.php");
?>
<a href='javascript:history.go(-1)'>Go back</a>
<br>

<?

    $start=$_GET['start'];
    if(empty($start) || $start<0)$start=0;    

	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();

	$sql="select u.IDuser,u.nick,u.email,u.code from ".TABLE_USERS." u, ".TABLE_ADITIONAL_USER_INFO." a where u.IDUser=a.IDUser";
	$result=$db->Query($sql);
		
	
	$afected_rows=mysql_affected_rows();
	if(USER_PAG+$start> $afected_rows)
		$to=$afected_rows;
		else
			$to=USER_PAG+$start;
	
	$total=0;
	$i=0;
	
	if($result){



		echo "
		<font color='orange' size='+1'>Displaying users</font> [".($start+1)." to ".$to."]
		<table border='0'>

			
			<tr>
			<th align='left' width='80px'>User</th>
			<th>Email</th>					
			<th>&nbsp;</th>			
			</tr>
			";
	  
			while($r=@mysql_fetch_array($result)){
	
				if(empty($r['code']))
						$nick="<b>".$r['nick']."</b>";
								else $nick=$r['nick'];
				
				if($i<USER_PAG && $total>=$start){	
					echo "
					<tr>	
						<td>".$nick."</td>
						<td>".$r['email']."</td>												
						<td><a href='index.php?page=delete_user&user=".$r['IDuser']."'><img border='0' src='images/delete.gif'/></a></td>						
					</tr>";
				$i++;
				}
				$total++;
		
			}
	
	
			
			if($start+$i<$total)
				$next="<a href='index.php?page=list_users&start=".($i+$start)."'>Next</a>";
			else
				$next="&nbsp";
			
			
			if($start-USER_PAG>=0)
				$prev="<a href='index.php?page=list_users&start=".($start-USER_PAG)."'>Prev</a>";
			else
				$prev="&nbsp";
			
				
			
			echo "<tr>
					<td>$prev<td>
					<td>$next</td>
				</tr>
			";
			echo "</table>";
		
	}

?>
<hr>

		<form method='get' action='index.php'>
			<input type='hidden' name='page' value='list_users'/>
			Display from user no.<input type='text' name='start' size='4'/>
			<input type='submit' value='Go'/>
		</form>
<br>

<?
	echo "<br>Found: $total result<br><Br>";
			
?>

<br>
<a href='javascript:history.go(-1)'>Go back</a>		
