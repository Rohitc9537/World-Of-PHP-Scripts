<?

GLOBAL $message;

include(LANG."/long_messages.php");





echo $message['Privacy'];

?>

<font size='2'>
<center>

	<a href='index.php?page=new_user&amp;site=<? echo $_GET['site'];?>'><? echo $message['I agree']; ?></a><br>
	<a href=''><? echo $message['I do not agree']; ?></a><Br>

</center>
</font>