<?
session_start();

session_check();

GLOBAL $message;

include_once("includes/settings.php");
include_once("includes/functions.php");
include_once("includes/config_mysql.php");
include_once("Class/MySql.Class.php");


$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

$sql="Select IDUser,email from ".TABLE_USERS." where nick='".$_SESSION['user_ax']."'";
$result=@$db->Query($sql);
$r=@mysql_fetch_array($result);

$iduser=$r['IDUser'];
$email=$r['email'];


$sql="Select webpage from ".TABLE_ADITIONAL_USER_INFO." where IDUser='".$iduser."'";
$result=@$db->Query($sql);
$r=@mysql_fetch_array($result);

$webpage=$r['webpage'];




$err=$_GET["err"];


?>
<script>
function validate()
{
	f = document.frm
	
	isOK = true
	usr_account = f.id.value
	usr_pass = f.password.value
	usr_pass_conf = f.password_.value
	usr_em = f.email.value
	usr_web=f.webpage.value
	
	
	
	if (!accept(usr_account))
	{
		alert("Invalid Id")
		isOK = false
	}

	
	if (!accept(usr_web))
	{
		alert("Invalid Web page")
		isOK = false
	}
		
	if (!accept(usr_pass))
	{
		alert("Wrong password")
		isOK = false
	}
	
	if (!accept(usr_em))
	{
		alert("Invalid Email")
		isOK = false
	}
		
	
	if(usr_account.length < 4)
	{
		alert("Id minimum 4 chars")
		isOK = false
	}
	if(usr_pass.length < 1)
	{
		alert("Type a password")
		isOK = false
	}
	if(usr_web.length < 6)
	{
		alert("Type a web page")
		isOK = false
	}
	if(!is_email(usr_em))
	{
		alert("Email invalid")
		isOK = false
	}
	
	if(usr_pass_conf!=usr_pass){
		alert("Password don't match") 
		isOK = false
	} 
	
	//custom fields must containts accepted chars
	for (j = 5; j < f.length-1 ;j++){
		field=f[j].value
		if(field!='T' && field!='F')				
			if(!accept(field))
				{
					alert("Field "+f[j].name+" ("+field+") invalid")
					isOK = false
				}		
	}
	
	
	return isOK
}	
</script>
<?
#
#File with custom fields
#
if( ($handle=fopen("modules/server_fields.cfg","r"))==NULL){
	echo "Erorr opening server_fields.cfg";
	die();
}else
	{
	$name=array();
	$fields=array();
	$type=array();
	$length=array();
		
	$i=0;
	while (!feof($handle)) {
		list($name[$i],$fields[$i],$type[$i],$length[$i])=explode("-",fgets($handle));				
		$i++;
		}
	
	$i--;
	fclose($handle);
	}

?>

<table  border="0" align="center" cellpadding="0" cellspacing="1">
  <tr>
    <td height="111" valign="top" align="left">
		<br>
		<b><? echo $message['Accepted chars']; ?><B>
		_`.!,:_#@$^&*+|{}/?=- <? echo $message['letters and numbers']; ?>
		<br>
		<br>
		
			
				<form name="frm" action="modules/do_edit_profile.php" method="post">
				<? if($err==1) echo "<br><font color='red'> Email already exists</font><br>"; ?>
				<input type='hidden' name='id_user' value='<? echo $iduser; ?>'/>
								
				<br>
				
				<? if($err==2) echo "<br><font color='red'>Web page already exists</font><br>"; ?>
				
				<? echo $message['Web page'];?><br>
				<input type="text" size="30" maxlength="255" name="webpage" value='<? echo $webpage; ?>'/><br>
								
				<br>
				<?
				for($j=0;$j<$i;$j++){
				
				
					$sql="Select ".$fields[$j]." from ".TABLE_ADITIONAL_USER_INFO." where IDUser='".$iduser."'";
					$result=@$db->Query($sql);
					$r=@mysql_fetch_array($result);

					$info=$r[$fields[$j]];
				
					#
					#int(1) means bool
					#
					
					if(strcmp($type[$j],"int")!=0 && $length[$j]!=1)
						echo "".$name[$j].":<Br>
						<input type='text' name='".$fields[$j]."' value='".$info."'/><br>";
						
					else{
						
						if($info==1){
							$check_yes="checked";
							$check_no="";							
						}else{
							$check_yes="";
							$check_no="checked";													
						}
						
							
						echo "
						".$name[$j].": 
						<input type='radio' name='".$fields[$j]."' value='_BOOL_T_' ".$check_yes."/>Yes 
						<input type='radio' name='".$fields[$j]."' value='_BOOL_F_' ".$check_no."/>No
						<br>
						";	
					}
						
				}
				?>
				<br>
				<a  href="index.php?page=show_services">Services</a><br>
				<br>
				<center><input type='submit' value="Save" onClick="return validate()"/></center>
				
				
				</form>
			
	</td>
  </tr>
</table>

