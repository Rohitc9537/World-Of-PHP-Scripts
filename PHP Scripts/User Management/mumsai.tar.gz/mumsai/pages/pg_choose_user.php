<?
//la pag asta are acces numai admin si moderatoru
session_check("01");
require_once("includes/settings.php");
?>
<a href='javascript:history.go(-1)'>Go back</a>
<br>
<form method="get" action="index.php" >
	<input type='hidden' name='page' value='choose_user_step2'/>
	
	User mask: <input type='text' size='10' name='user'/>
	Role:
	<select	name='type'>	
		<option>Admin</option>
		<option>Moderator</option>
		<option>User</option>		
		<option>InternetUser</option>
		<option>All</option>
	</select>
	<input type='submit' value='Ok'>
</form>
<br>
<br>

<?

    $start=$_GET['start'];
    if(empty($start) || $start<0)$start=0;    

	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();

	$sql="select nick from ".TABLE_USERS."";
	$result=$db->Query($sql);
		
	
	$afected_rows=mysql_affected_rows();
	if(USER_PAG+$start> $afected_rows)
		$to=$afected_rows;
		else
			$to=USER_PAG+$start;
	
	$total=0;
	$i=0;
	
	if($result){
		echo "
		<font color='orange' size='+1'>Displaying users</font> [".($start+1)." to ".$to."]
		<table border='0'>
			<tr>
			<th align='left' width='80px'>User</th>
			<th>Options</th>
			</tr>
			";
	  
			while($r=@mysql_fetch_array($result)){
	
				
				
				if($i<USER_PAG && $total>=$start){	
					echo "
					<tr>
						<td>".$r['nick']."</td>
						<td><a href='index.php?page=do_choose&nick=".$r['nick']."'>Choose</a></td>
					</tr>";
				$i++;
				}
				$total++;
		
			}
	
	
			
			if($start+$i<$total)
				$next="<a href='index.php?page=choose_user&start=".($i+$start)."'>Next</a>";
			else
				$next="&nbsp";
			
			
			if($start-USER_PAG>=0)
				$prev="<a href='index.php?page=choose_user&start=".($start-USER_PAG)."'>Prev</a>";
			else
				$prev="&nbsp";
				
			
			echo "<tr>
					<td>$prev<td>
					<td>$next</td>
				</tr>
			";
			echo "</table>";
		
	}

?>
<hr>

		<form method='get' action='index.php'>
			<input type='hidden' name='page' value='choose_user'/>
			Display from user no.<input type='text' name='start' size='4'/>
			<input type='submit' value='Go'/>
		</form>
<br>

<?
	echo "<br>Found: $total result<br><Br>";
			
?>

<br>
<a name='help'>
	<font color='orange' size='+1'>Help</font>
</a>
<br>

		To find names beginning with 'b': <b>b%</b> <br>
		To find names ending with 'fy': <b>%fy</b> <br>
		To find names containing a 'w': <b>%w%</b> <br>
		To find names containing exactly five characters, use five instances of the '_' pattern character <br>
		<br>
		Some characteristics of extended regular expressions are:
		<ul>
		<li>
		'.' matches any single character.
		</li>
		<li>
		A character class '[...]' matches any character within the brackets. For example, '[abc]' matches 'a', 'b', or 'c'. To name a range of characters, use a dash. '[a-z]' matches any letter, whereas '[0-9]' matches any digit.
		</li>
		<li>
		'*' matches zero or more instances of the thing preceding it. For example, 'x*' matches any number of 'x' characters, '[0-9]*' matches any number of digits, and '.*' matches any number of anything. 
		</li>
		</ul>
<a href='javascript:history.go(-1)'>Go back</a>		