<p class='p1' align='left'>
	<?
	Global $message;
	echo $message['Welcome note'];
	?>
</p>
<Br>
    