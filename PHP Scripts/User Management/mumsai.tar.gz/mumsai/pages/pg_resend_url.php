<?
require_once("includes/config_mysql.php");
require_once("includes/settings.php");
require_once("Class/MySql.Class.php");

session_check("0");

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$url=$_GET['url'];

$sql="select url  from ".TABLE_RESOURCES." where IDResource='$url'";
$result=$db->Query($sql);
$r=mysql_fetch_array($result);
$address=$r["url"];

#
#Generare alt tcs
#
$TCS=md5(base64_encode($address).date("U"));
$sql="update ".TABLE_RESOURCES." set TCS='$TCS' where IDResource='$url'";
@$db->Query($sql);



if(!empty($address)){

		$message = '
		<html>
		<head><title>Axiologic- new url</title></head>
		<body>			
			<p>TCS for '.$address.'<br/>
			'.$TCS.'<br/>			
			</p>
			<p>
			Link for new user:<br>
			'.HTTTP.'index.php?page=new_user&site='.base64_encode($address).'
			</p>
		</body>
		</html>';
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From:root@axiologic.net\r\n";
		
		if(@mail(ADMIN_EMAIL,"TCS for ".$address."",$message,$headers)){
			#
			#Date ce trebuiesc afisate adminului
			#	
			$message="<font color='red'>TCS sent at ".ADMIN_EMAIL."</font>:<br>"; 
		}
		else
			$message="Failed to send email";
	
}else
	$message="Error:Url not found";

	
	echo $message;
	
	$db->Close();
?>