<?
session_check("01");

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$user=$_GET["nick"];

if(empty($user) || empty($_SESSION["user_ax"]))
	echo "Ilegal acces";
	else{

$sql="select IDUser from ".TABLE_USERS." where nick='$user'";	
$result=$db->Query($sql);

	
$r=mysql_fetch_array($result);	
$IDUser=$r["IDUser"];


if(empty($IDUser)){
	echo "<font color='red'>No such nick</font>. Try <a href='javascript:history.go(-1)'>again</a>";
	}else{
	#
	# Cautare permisiuni
	#
	
	$sql="select S.IDResource,S.url as url,R.text,P.ID as pid  from ".TABLE_RESOURCES." S,".TABLE_PERMISIONS." P,".TABLE_ROLES." R where P.IDUser='$IDUser' and P.IDRole=R.IDRole and S.IDResource=P.IDResource";	
	$result=$db->Query($sql);

	
	echo "<font color='red'>Permissions for $user</font><br>";
	?>	

	<table border="0" cellpadding="3" cellpadding="3">	
	<tr>
		<th align="center">IDResource</th>
		<th align="center" width="140">Url</th>
		<th align="center">Permission</th>
		<th align="center">Options</th>			
	</tr>
	<?	
	while(($r=mysql_fetch_array($result))){
	
		echo "<tr>
		<td align='center'> ".$r["IDResource"]." </td>
		<td align='center'> 
		".$r["url"]." 
		</td>
		<td align='center'> ".$r["text"]." </td>
		<td align='center'>
		<a href='index.php?page=do_permissions&idres=".$r["IDResource"]."&nick=".$user."&iduser=".$IDUser."'>Modify</a>
		<a href='index.php?page=delete_permision&id=".$r["pid"]."'>&nbsp;<img align='middle' border='0' src='images/delete.gif'/></a>
		</td>
		</tr>";
	}
?>	
	<tr>
	<td colspan="4"><br>	<a href="index.php?page=do_permissions&nick=<? echo $user;?>&iduser=<? echo $IDUser;?>">Add permission</a></td>
	</tr>
	</table>

<?
	}
}
?>