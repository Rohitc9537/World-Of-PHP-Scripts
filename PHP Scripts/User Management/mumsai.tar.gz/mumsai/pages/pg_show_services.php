<?
	session_check();
	GLOBAL $message;

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	
	
	$sql="select IDUser,email  from ".TABLE_USERS." where nick='".$_SESSION['user_ax']."'";	
	$result=$db->Query($sql);
	$r=@mysql_fetch_array($result);
	$IDUser=$r["IDUser"];
	$email=$r["email"];
	
	
	
	$sql="select IDResource,url,description  from ".TABLE_RESOURCES."";	
	$result=$db->Query($sql);

	echo $message['Select sites'];
	?>	
	
	<form action='modules/do_services.php' method='post'>
	
	<!-- Hidden fields-->
	
	<input type='hidden' value='<? echo $IDUser;?>' name='id'/>
	<input type='hidden' value='<? echo $email;?>' name='email'/>
	
	<table border="0" cellpadding="3" cellpadding="3">	
	<tr>
		<th align="left">URL</th>
		<th align="left"><? echo $message['Description'];?></th>				
		<th align="left"><? echo $message['Receive news'];?></th>
					
	</tr>
	<?	
	
	while(($r=mysql_fetch_array($result))){
	
		
		$sql="select count(*) as no from ".TABLE_NEWS." where IDUser='$IDUser' and IDResource='".$r['IDResource']."'";
		$result_temp=@$db->Query($sql);
		$r_temp=@mysql_fetch_array($result_temp);
		$count=$r_temp['no'];
		
		if($count==1){
			$check_no="";
			$check_yes="checked";
		}else{
			$check_no="checked";
			$check_yes="";
			}
			
		
		if(strcmp($r['url'],"all")!=0)
		echo "<tr>
		<td align='left'><a name='-' title='".$r['description']."'><font color='blue'> ".$r["url"]." <font></a></td>		
		<td align='left' width='120px'>".$r['description']."</td>		
		<td align='center'>
			<input type='radio' name='".$r['IDResource']."' value='1' ".$check_yes."/>Yes
			<input type='radio' name='".$r['IDResource']."' value='0' ".$check_no."/>No			
		</td>		
		</tr>";
	}
	$db->Close();
	?>	
	</table>
	<input type='submit' value='Save'/>
	</form>
		
