<?
//la pag asta are acces numai admin si moder
session_check("01");


$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$sql="select * from ".TABLE_LABELS."";
$result=$db->Query($sql);

while($r=mysql_fetch_array($result))
$items[]=$r['name'];

@mkdir("links");

$hh=fopen("links/index.php","w");
fwrite($hh,"<html><head><title>".HTTP."</tite><body>All categories links are listed <a href='categories.xml'>here</a><br>");


$hrdf=fopen("links/categories.xml","w");

	$content_rdf='
	<rss version="2.0">
	<channel>
    <title>'.HTTTP.'</title>
    <link>
   '.HTTTP.'
    </link>
    <description>
	rdf links
    </description>
    <language>en-en</language>    
    <pubDate>'.date("D, d M Y H:i:s").' +0200</pubDate>
	';



foreach($items as $label){

	$label_file=preg_replace("'\s+'","_",$label);
	
	$content_rdf.='
			<item>
			<title>'.$label.'</title>
			<link>'.HTTTP.'links/'.$label_file.'.xml</link>
			<description>
			'.$r['description'].'
			</description>
			</item>';

	
	
	$sql="select a.link,a.name,a.description,a.id from ".TABLE_LINKS." a,".TABLE_LABELS." b,".TABLE_LINKS_LABELS." c where c.id_label=b.id and c.id_link=a.id and b.name='$label'";
	$result=$db->Query($sql);
	
	if(mysql_num_rows($result)>0){
	


	fwrite($hh,"<h1>$label</h1>");
	fwrite($hh,"<a href='".HTTTP."links/$label_file.xml'><img border='0' src='".HTTTP."/images/rss.jpg'/></a><br><Br>");
	
	
	$content='
	<rss version="2.0">
	<channel>
    <title>'.HTTP.'</title>
    <link>
    '.HTTTP.'
    </link>
    <description>
	links
    </description>
    <language>en-en</language>    
    <pubDate>'.date("D, d M Y H:i:s").' +0200</pubDate>
	';
    
	$i=0;
	while($r=mysql_fetch_array($result)){
			
			$content.='
			<item>
			<title>'.$r['name'].'</title>
			<link>'.$r['link'].'</link>
			<description>
			'.$r['description'].'
			</description>			
			</item>';
			$i++;
			fwrite($hh,"$i.<a href='".$r['link']."'>".$r['name']."</a>-&nbsp<font color='green'>".$r['description']."<br>");
			

	}
	
	


	$content.="
	</channel>
	</rss>
	";
	

	echo "<br>".$label." generated..<br>";
	
	

	$h=fopen(PATH."links/$label_file.xml","w");
	fwrite($h,$content);
	fclose($h);
	
	

	
}
}
	fwrite($hh,"</body></html>");
	fclose($hh);



	$content_rdf.="
	</channel>
	</rss>
	";

	fwrite($hrdf,$content_rdf);
	fclose($hrdf);
	
	echo "<b>View <a href='links'>output</a></b>";
$db->Close();
?>