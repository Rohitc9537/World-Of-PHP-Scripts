<?
session_check("01");

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	#
	# Cautare permisiuni
	#
	
	$sql="select IDResource,url,TCS,description  from ".TABLE_RESOURCES."";	
	$result=$db->Query($sql);
	
	?>	

	<table border="0" cellpadding="3" cellpadding="3">	
	<tr>
		<th align="left">URL</th>
		<th align="center">Delete</th>				
		<th align="center">Resend TCS</th>
		<th align="center">Edit</th>
					
	</tr>
	<?	
	while(($r=mysql_fetch_array($result))){
		if(strcmp($r['url'],"all")!=0)
		echo "<tr>
		<td align='left'><font color='blue'> ".$r["url"]." </font><br>".$r['description']."</a></td>		
		<td align='center'><a href='index.php?page=delete_url&url=".$r["IDResource"]."'><img border='0' src='images/delete.gif'/></a></td>		
		<td align='center'><a href='index.php?page=resend_url&url=".$r["IDResource"]."'><img border='0' src='images/resend_tcs.png'/></a></td>		
		<td align='center'><a href='index.php?page=edit_url_description&url=".$r["IDResource"]."'><img border='0' src='images/edit_url.png'/></a></td>		
		</tr>";
	}
	$db->Close();
	?>	
	</table>
	<br>
	<font color='red'><b>Note</b>:If you resend TCS, it will be sent to admin email</font><br>
	

