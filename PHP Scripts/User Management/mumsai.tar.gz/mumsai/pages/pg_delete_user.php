<?
session_check("01");

	$user=$_GET['user'];

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	#
	# Cautare permisiuni
	#
	
	$sql="delete from ".TABLE_USERS." where IDUser='$user'";	
	$result=@$db->Query($sql);
	
	$sql="delete from ".TABLE_ADITIONAL_USER_INFO." where IDUser='$user'";	
	$result1=@$db->Query($sql);
	
		
	if($result && $result1){
		echo "User deleted";
	}else
		echo "<font color='red'>Error</font> deleting url";

	$db->Close();
	?>	

	
	

