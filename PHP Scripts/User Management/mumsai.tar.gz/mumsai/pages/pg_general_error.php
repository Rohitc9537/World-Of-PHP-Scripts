<?
require_once("includes/functions.php");
session_check();
?>
Database error.Please try again later!
