
<script>
function is_email(val)
{
	var at = val.indexOf("@")
	if(at == -1){
	 return false
	 }
	else
	{
		var at_parts = val.split("@")
		if(at_parts[0].length < 1){
			return false
			}
		else{
			point = at_parts[1].indexOf(".")
			if(point == -1) return false
			else{
			  point_parts = at_parts[1].split(".")
			  if((point_parts[1].length < 2) || (point_parts[1].length > 3)) return false
			  else  return true
			}
		}
	}
}
function accept(str){
acc="_`.!,:_'#@$^&*+|{}/?-0123456789abcdefghijklmnoprstuvxzqywABCDEFGHIJKLMNOPRSTUVXZYQW"

var ch
var found = true

if (str.length == 0) 
{
   return false
}
for (i = 0; i < str.length ;i++){
		ch = str.charAt(i)
		if(acc.indexOf(ch)==-1){
			found=false
			}
}
return found
		
}


function validate()
{
	f = document.frm
	isOK = true
	usr_em = f.email.value
	
	
	
	if (!accept(usr_em))
	{
		alert("Invalid Email")
		isOK = false
	}
		
	if(!is_email(usr_em))
	{
		alert("Email invalid")
		isOK = false
	}
	return isOK
}
</script>
<body>
<br>

<?
GLOBAl $message;
echo $message['Recover password'];
?>
<br>
<br>
<form action="modules/do_forgot_pass.php" method="post" name="frm">
Email:<input type="text" size='20' name="email"/>
<input type="submit" value="Send" onClick="return validate()" />
</form>
</body>
</html>
