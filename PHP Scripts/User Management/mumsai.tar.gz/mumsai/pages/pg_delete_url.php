<?
session_check("01");

	$id=$_GET['url'];

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	#
	# Cautare permisiuni
	#
	
	$sql="delete from ".TABLE_RESOURCES." where IDResource='$id'";	
	$result=@$db->Query($sql);
		
	if($result){
		echo "Url deleted";
	}else
		echo "<font color='red'>Error</font> deleting url";

	$db->Close();
	?>	

	
	

