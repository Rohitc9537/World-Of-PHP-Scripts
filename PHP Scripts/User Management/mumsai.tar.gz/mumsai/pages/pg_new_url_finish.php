<?
$message=$_GET['content'];

?>

<font color='blue'>URL added succes</font> <br>
<?
echo base64_decode($message);
?>