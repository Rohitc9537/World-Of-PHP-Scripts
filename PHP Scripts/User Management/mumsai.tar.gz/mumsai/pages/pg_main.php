<?
GLOBAL $message;
echo $message['MAIN_PAGE'];
?>

