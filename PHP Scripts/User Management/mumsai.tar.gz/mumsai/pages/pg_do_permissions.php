<?

//la pag asta are acces numai admin si moder
session_check("01");


if(!empty($_SESSION["user_ax"])){

	$id=$_GET['idres'];   //idresource
	$nick=$_GET['nick'];  //nick
	$iduser=$_GET['iduser'];  //nick

	#
	#Modificare permisiuni
	#
	if(!empty($id)){
	   echo "Select new permission for user <b>$nick</b>";
   	   ?>
   <table border="0">
   <tr>
   <td align="left">
   <form action="admin/do_permissions2.php" method="post">
   <select name="permission">
	   <option id='0' value='0'>Admin</option> 
	   <option id='1' value='1'>Moderator</option> 
	   <option id='2' value='2'>User</option> 
	   <option id='3' value='3'>InternetUser</option> 
  	   
   </select>
   <input type="submit" value="Modify"/>
   <input type="hidden" name="iduser" value="<? echo $iduser; ?>"/>
   <input type="hidden" name="idres" value="<? echo $id; ?>"/>
   <br>
   <br>
   <br>
   </form>
   </td>
   </tr>
   </table>
   <?	
   }else{ //adaugare permisiune
	
	echo "Select site and permision for user  <b>'$nick'</b><br>";
	
	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 
	
	$sql="select url,IDResource  from ".TABLE_RESOURCES; 
	
	$result=$db->Query($sql);

	echo "<form action='admin/do_permissions3.php' method='post'>
	<select name='url'>";
	while($r=mysql_fetch_array($result))
		echo "<option>".$r["url"]."</option>";		
	echo "</select>
	<select name='permission'>
		<option id='0' value='0'>Admin</option>
		<option id='1' value='1'>Moderator</option>
		<option id='2' value='2'>User</option>
		<option id='3' value='3'>InternetUser</option>
	</select>		
	<input type='submit' value='Add'/>
	<input type='hidden' name='iduser' value='$iduser'/>
	
	</form>";
	
   }
	
}

?>