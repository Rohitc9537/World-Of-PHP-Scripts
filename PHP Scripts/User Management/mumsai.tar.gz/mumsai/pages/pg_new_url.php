<?
//la pag asta are acces numai admin si moder
session_check("01");
		
?>

<form action="admin/do_new_url.php" method="post">

	<b>Enter URL:</b><br><br>
	http://<input type="text" name="url" maxlength="255" size="25"/><br>
	<br>
	Description:<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="text" name="description" maxlength="255" size="25"/><br><br>
	<input type="submit" value="Add"/>

</form>