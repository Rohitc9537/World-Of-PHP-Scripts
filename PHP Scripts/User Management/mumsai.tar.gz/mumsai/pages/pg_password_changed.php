<?
require_once("includes/functions.php");
session_check();
?>
<font color='orange' size='+1'>Password has been changed</font>
