<?
session_check("01");
echo "
  <Script>
	location='index.php?page=permissions_step2&nick=".$_SESSION['choosen_nick']."'
  </script>
";
?>
