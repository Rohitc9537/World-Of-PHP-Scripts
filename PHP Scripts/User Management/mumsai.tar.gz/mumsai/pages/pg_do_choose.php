<?
//la pag asta are acces numai admin si moder
session_check("01");

$_SESSION['choosen_nick']=$_GET['nick'];
$_SESSION['choosen_id']=$user=$_GET['id'];

?>

<font color='orange' size='+1'>User <? echo $_GET['nick']; ?> choosen</font><br>
User is selected until you log off, or you choose another.