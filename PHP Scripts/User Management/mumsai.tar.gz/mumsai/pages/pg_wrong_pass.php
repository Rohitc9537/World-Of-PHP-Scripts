<?

require_once("includes/functions.php");
session_check();
?>
Your old password doesn't match.Please try again <a href='javascript:history.go(-1)'>here</a>