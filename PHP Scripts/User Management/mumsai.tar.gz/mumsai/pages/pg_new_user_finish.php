<?
$r=$_GET['r'];
GLOBAL $message;
?>
<font color='green' size='+1'><? echo $message['Registration completed'];?></font><br><Br>		
<? echo $message['Confirmation code sent'];?><br> 
Site: <a href="http://<? echo base64_decode($r); ?>"> <? echo base64_decode($r); ?></a>