<?
###############################################
# 											  #
# Prelucrare formular user nou pentru server  #
#    Pas1->Verificare unicitatii datelor      #
#    pas2->Inserarea datelor                  #
#    Pentru resource se genereaza TCS         #
#                                             #
#    Iunie 2005								  #
###############################################



$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

$sql="select * from cms_users";
$result=$db->Query($sql);
$content="";
while($r=mysql_fetch_array($result)){
	
	echo "name=".$r['name']."<br>";
	echo "user_name=".$r['username']."<br>";
	echo "mail=".$r['user_email']."<br>";
	echo "p=".$r['user_password']."<br>";
	echo "web=".$r['user_website']."<br>";
	echo "news=".$r['newsletter']."<br>";

	
 

	$id=$r['username'];
	$password=$r["user_password"];
	$email=$r["user_email"]; 
	$webpage=$r["user_website"];
	$request_site="www.intrebare.today-news.info";
	$name=$r['name'];
 
	if($r['newsletter']==1)
		$news="yes";
		
	else
		$news="no";

	
	$response=0;
	$nick=0;
	$em=0;
	
	$sql1="Select count(IDUser) as result from ".TABLE_USERS." where nick='$id' ";
	$result1=$db->Query($sql1);
	$r1=@mysql_fetch_array($result1);
	if($r1["result"]!=0){
		$nick=1;
	}
	
	
	
	$sql1="Select count(IDUser) as result from ".TABLE_USERS." where email='$email'";
	$result1=$db->Query($sql1);
	$r1=@mysql_fetch_array($result1);
	if($r1["result"]!=0){
	    $em=1;
	} 
	
	if($nick==1 && $em==0){
			$id=$email;
			$nick=0;
			
			}
	
	
	
	if($em==0 && $nick==0){
		echo "inserez cu $id <Br><br>";
		
		
		
		
	$sql1="SELECT IDResource  from ".TABLE_RESOURCES." where url='".$request_site."'";
	$result1=$db->Query($sql1);
	$r1=@mysql_fetch_array($result1);	
	$IDResource=$r1["IDResource"];
	
	if(empty($IDResource))
		die("The ".$request_site." does not exist in our database");
	


	#
	#Informatii standard
	#
	$sql1="Insert into ".TABLE_USERS." values(0,'$id','$email','".$password."','','".date("Y-m-d H:i:s")."')";
	if(!$db->Query($sql1)){
		$db->Close();
		die("Error saving data!");
	}
	
	
	
	$sql1="SELECT IDUser from ".TABLE_USERS." where nick='$id'";
	$result1=$db->Query($sql1);
	$r1=@mysql_fetch_array($result1);
	$IDUser=$r1["IDUser"];

	
	#
	#Informatii custom
	#
	$sql1="Insert into ".TABLE_ADITIONAL_USER_INFO." values('$IDUser','$webpage','RO','','$name','')";
	

	if(!$db->Query($sql1)){
		$db->Close();
		die("Error saving data!");
	}
	
	
	
	
	#
	#Vrea sa primeasca stiri-inserare in tabela cu stiri
	#
	if(strcmp($news,"yes")==0){
		
		$sql1="Insert into ".TABLE_NEWS." values('$IDUser','$IDResource','-')";
		if(!$db->Query($sql1)){
			$db->Close();
			die("Error saving data");	
		}
	}
	
	#
	#Setare permisiuni InternetUser
	#	
	$sql1="Insert into ".TABLE_PERMISIONS." values(0,'$IDUser','3','0')"; 
	if(!$db->Query($sql1)){
		$db->Close();
		die("Error saving data");	
	}
	 
		
		
		
		
		$content.=$email."\n";
		
	}	
	else{
		echo "este $em-$nick,<br> ";
		//update name
		if(!empty($name)){
		
		
		$sql1="SELECT IDUser from ".TABLE_USERS." where email='$email'";
		$result1=$db->Query($sql1);
		$r1=@mysql_fetch_array($result1);
		$IDUser=$r1["IDUser"];
		
		$sql1="UPDATE AInfo set first_name='$name' where IDUser=$IDUser";
		$db->Query($sql1);
		
		
			
		} 
		
		
		
		//update web
		if(!empty($webpage)){
		
		
		$sql1="SELECT IDUser from ".TABLE_USERS." where email='$email'";
		$result1=$db->Query($sql1);
		$r1=@mysql_fetch_array($result1);
		$IDUser=$r1["IDUser"];
		
		$sql1="UPDATE AInfo set WebPage='$webpage' where IDUser=$IDUser";
		$db->Query($sql1);
		
		
			
		}
		
		
		
		
		
		
		
		
		
			
		}
		
		
	}
	 
	

$db->Close();

$h=fopen("save/emails.txt","w");
fwrite($h,$content);
fclose($h);



function Send_Verification_Email($id,$password,$email,$request_site,$news){

	GLOBAL $db;
	$no=date("U");
$message = '
		<html>
		<head><title>Registration</title></head>
		<body>
			<p>You have register to site '.$request_site.'</p>
			<p>Your information<br/>
			Id: '.$id.'<br/>
			Password: '.$password.'<br/>				
			</p>
			<p>To activate you account follow this link: <a href="'.HTTTP.'/index.php?page=activate&q='.md5($id.$email.$no).'&site='.base64_encode($request_site).'&news='.$news.'">Activate</a></p>
		</body>
		</html>';
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From:root@axiologic.net\r\n";
		
		if(@mail($email,"User account activation for ".$request_site."",$message,$headers)){
		
			$query_post = "update ".TABLE_USERS." set code='".md5($id.$email.$no)."' where nick='".$id."'";
			if($result = $db->Query($query_post))
				return true;
					else
						return false;
				
		}
		else
			return false;
}


?>
