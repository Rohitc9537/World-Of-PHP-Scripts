<?

GLOBAL $message;


$_GET['key'];

if(!empty($_SESSION['user_ax'])){
			echo "<center>".$message['Hello']." ".$i_SESSION["user_ax"]."! ".$message['Thanks'].". <br><a href='http://".base64_decode($_GET['site'])."'>".$message["Go to main page"]." </a><br><br>";			
						
}else 
	echo "<font color='red'>".$message['Access forbidden']."</font>";


?>