<?
//la pag asta are acces numai admin si moder
session_check("01");

//save


$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$label=$_GET['label'];
$name=$_GET['name'];
$description=$_GET['description'];

$action=$_GET['action'];

$submit="Add";

//delete
if($action=='delete'){
	
	$id=$_GET['id'];
	
	$sql="delete from ".TABLE_LINKS." where id='$id'";
	if($db->Query($sql))
		echo "<font color='red'>Deleted</font>.";
		else
			echo "Failed";
	

}
//edit
if($action=='edit'){

	$id=$_GET['id'];
	
	$sql="select *  from ".TABLE_LINKS." where id='$id'";
	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);
	
	$label=$r['link'];
	
	$description=$r['description'];
	
	$name=$r['name'];
		
	$submit="Modify";	
	
}


if(!empty($label) && empty($action)){
	
	$mode_edit=$_GET['mode_edit'];
	if(empty($mode_edit)){
	$sql="select count(*) as result from ".TABLE_LINKS." where link='$label'";
	$result=$db->Query($sql);
	$r=mysql_fetch_array($result);
	$result=$r["result"];
	if($result==0){
	
			$sql="insert into ".TABLE_LINKS." values(0,'$label','$description','$name')";
			@$db->Query($sql);
			echo "<font color='green'>Link inserted.<a href='index.php?page=new_link'>Back</a></font>";
			
	}else
	
	
	echo "<font color='red'>This link already exists</font>";
	}
	else
	{
	
		$sql="update ".TABLE_LINKS." set link='$label' where id='$mode_edit'";
		$db->Query($sql);
	
		$sql="update ".TABLE_LINKS." set description='$description' where id='$mode_edit'";
		$db->Query($sql);
		
		$sql="update ".TABLE_LINKS." set name='$name' where id='$mode_edit'";
		$db->Query($sql);
		
		echo "<font color='green'>Link updated.<a href='index.php?page=new_link'>Back</a></font>"; 
	
	
	}
	
	
	
}else{
		
?>



<h1>New Link</h1>
<h3>Links management on axiologic.net</h3>
<br>

<form action="index.php" method="get">
	<input type='hidden' value='new_link' name='page'/>

	<b>Enter link:</b><br><br>
	<input type="text" name="label" value="<? echo $label; ?>"maxlength="255" size="25"/><br>
	<br>
	
	<b>Enter name:</b><br><br>
	<input type="text" name="name" value="<? echo $name; ?>"maxlength="255" size="25"/><br>
	<br>
	
	Description:<br>	
	<input type="text" name="description" value="<? echo $description; ?>" maxlength="255" size="25"/><br><br>
	<input type="submit" value="<? echo $submit; ?>"/>
	<?
	if($submit=="Modify"){
		$id=$_GET['id'];
		echo "<input type='hidden' name='mode_edit' value='$id'/>";
		}
	?>

</form> 
<?
	
	$sql="select * from ".TABLE_LINKS."";
	
	$result=$db->Query($sql);
	echo "<table border='0' width='100%' cellpadding='0'><tr>
	<th >Name<br></th><th align='center' style='border-left:1px dotted black;'>Edit<br></th><th style='border-left:1px dotted black;' align='center'>Delete<Br></th><th style='border-left:1px dotted black;' align='center'>Associate<br></th></tr>";
	while($r=mysql_fetch_array($result)){
		echo "<tr >
					<td style='border-bottom:1px dotted black;'>					
					<br>
					<i>".$r['name']."</i><br>
					<b>".$r['link']."</b><br>
					".$r['description']."
					</td>					
					<td align='center' style='border-bottom:1px dotted black;border-left:1px dotted black;'>
					<a href='index.php?page=new_link&action=edit&id=".$r['id']."'><font size='3'>+</font></a>
					</td>
					<td align='center' style='border-bottom:1px dotted black;border-left:1px dotted black;'>
					<a href='index.php?page=new_link&action=delete&id=".$r['id']."'><font color='red' size='3'>x</font></a>
					</td>
					<td align='center' style='border-bottom:1px dotted black;border-left:1px dotted black;'>
					<a href='index.php?page=asociate&id=".$r['id']."'><font color='green' size='4'><b>*</b></font></a>
					</td>
			  </tr>";
	}
	echo "</table>";
	
	
	
}
	$db->Close();
?>