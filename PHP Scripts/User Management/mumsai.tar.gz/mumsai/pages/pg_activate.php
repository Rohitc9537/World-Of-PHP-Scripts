<?
   include("CLIENT/EMAILClient.Class.php");
   

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 
	

	if(isset($_GET["q"]))
	{
		$result_infos = $db->Query("SELECT * FROM ".TABLE_USERS." WHERE code='".$_GET["q"]."'");
		$result = $db->Query("UPDATE ".TABLE_USERS." SET code='' WHERE code='".$_GET["q"]."'");
		
		
		if($result)
			{
			$info=@mysql_fetch_array($result_infos);
			$_SESSION['user_ax']=$info["nick"];
			if(strcmp($_GET['news'],"yes")==0){
				/*connect to each server from the client sites, and register services */
				@$client=new CEMAILClient();
				@$client->Connect("http://".base64_decode($_GET['site'])."/SERVER/server.php");
				@$client->Send_Update($info['email'],1);//1=adaugare
				@$client->Close();
			}			
			
			$_SESSION["choosen_nick"]=$info["nick"];
			SetUserKey($info["nick"],'-');
				
			#safe erase permissions
			$i=0;
			while(!empty($_SESSION['Url['.$i.']'])){
				$_SESSION['Url['.$i.']']='';
				$_SESSION['Permissions['.$i.']']='';
				$i++;
			}
				
			
			echo "<script>
			location='index.php?page=activate_finish&site=".$_GET['site']."'
			</script>";
			}
		else 
			echo $message["Error activating code"];
	}
?>
