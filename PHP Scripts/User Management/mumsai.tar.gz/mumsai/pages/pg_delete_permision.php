<?
session_check("01");

	$id=$_GET['id'];

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	#
	# Cautare permisiuni
	#
	
	$sql="delete from ".TABLE_PERMISIONS." where ID='$id'";	
	$result=@$db->Query($sql);
		
	if($result){
		echo "Url deleted";
	}else
		echo "<font color='red'>Error</font> deleting permissions";

	$db->Close();
	?>	
	<br>
	<a href='javascript:history.go(-1)'>Go back</a>

	
	

