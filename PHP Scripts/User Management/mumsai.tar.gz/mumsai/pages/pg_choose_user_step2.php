<?
//la pag asta are acces numai admin si moder
session_check("01");

$user=$_GET['user'];
$type=$_GET['type'];


require_once("includes/settings.php");
require_once("includes/config_mysql.php");
require_once("Class/MySql.Class.php");


$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

	$start=$_GET['start'];
		if(empty($start) || $start<0)
			$start=0;    

	
	$sql="select IDUser,nick from ".TABLE_USERS." where nick like '".$user."'";
	$result=@$db->Query($sql);

	$total=0;
	if($result){
		echo "<table border='0'>
			<tr>
			<th align='left' width='50px'>User</th>
			<th>Options</th>
			</tr>
			";
	  
			while($r=@mysql_fetch_array($result)){
	
						
			$sql="select P.IDUser,R.text  from ".TABLE_RESOURCES." S,".TABLE_PERMISIONS." P,".TABLE_ROLES." R where P.IDUser='".$r['IDUser']."' and P.IDRole=R.IDRole and S.IDResource=P.IDResource";	
			$result_temp=$db->Query($sql);
			
			if(strcmp($type,"All")!=0){
				#daca are cel putin un drept din cel dorit, este afisat
				$valid=false;
				while($rr=@mysql_fetch_array($result_temp))	
						if(strcmp($type,$rr["text"])==0){
							$valid=true;
							break;
						}
						
				if($valid){
					if($i<USER_PAG && $total>=$start){	
						echo "<tr><td>".$r['nick']."</td>				
						<td><a href='index.php?page=do_choose&id=".$r['IDUser']."&nick=".$r['nick']."'>Choose</a></td></tr>";
					$i++;
					}
				$total++;
				}
				
			}
			else{ #doar afisez
				if($i<USER_PAG && $total>=$start){	
					echo "<tr><td>".$r['nick']."</td>
					<td><a href='index.php?page=do_choose&id=".$r['IDUser']."&nick=".$r['nick']."'>Choose</a></td></tr>";
					$i++;
				}
				$total++;
			}
	
		

	}
	
	
	
			if($start+$i<$total)
				$next="<a href='index.php?page=choose_user_step2&start=".($i+$start)."&user=$user&type=$type'>Next</a>";
			else
				$next="&nbsp";
			
			
			if($start-USER_PAG>=0)
				$prev="<a href='index.php?page=choose_user_step2&start=".($start-USER_PAG)."&user=$user&type=$type'>Prev</a>";
			else
				$prev="&nbsp";
				
			
			echo "<tr>
					<td>$prev<td>
					<td>$next</td>
				</tr>
			";
			echo "</table>";
			
	echo "<br>Found: $total result<br><br>
	<a href='javascript:history.go(-1)'>Go back</a>
	";

}


?>

<hr>

		<form method='get' action='index.php'>
			<input type='hidden' name='page' value='choose_user_step2'/>
			<input type='hidden' name='user' value='<? echo $user;?>'/>			
			<input type='hidden' name='type' value='<? echo $type;?>'/>						
			Display from user no.<input type='text' name='start' size='4'/>
			<input type='submit' value='Go'/>
		</form>
<br>