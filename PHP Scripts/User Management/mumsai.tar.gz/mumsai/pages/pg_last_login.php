<?
//la pag asta are acces numai admin si moderatoru
session_check("01");
require_once("includes/settings.php");
?>
<a href='javascript:history.go(-1)'>Go back</a>
<br>

<?




	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();

	$sql="select login_time from ".TABLE_LOGIN." where user='".$_SESSION['choosen_nick']."'";
	$result=$db->Query($sql);
		
	
	$r=@mysql_fetch_array($result);
	
				
	echo "Last login for <i>".$_SESSION['choosen_nick']."</i>:<B>".$r['login_time']."</b>";
	$db->Close();
?>		
