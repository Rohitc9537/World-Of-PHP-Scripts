<?
//la pag asta are acces numai admin si moderatoru
session_check("01");
require_once("includes/settings.php");
?>
<a href='javascript:history.go(-1)'>Go back</a>
<br>
<br>
<center><h4>Last 30 logins</h4></center>
<br>
<table border='0' width='80%'>
<tr>
	<th>
	Name	
	</th>
	<th>
	Last login
	</th>
	
</tr>
<?




	$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect();

	$sql="select user,login_time from ".TABLE_LOGIN." order by login_time desc limit 30";
	$result=$db->Query($sql);
		
	$i=1;

	while($r=@mysql_fetch_array($result)){
	if(!empty($r['user']))
	echo "<tr>
	      <td>
                <b>$i.".$r['user']."</b>
	      </td>	

	      <td>
                ".$r['login_time']."
	      </td>	
   	      </tr>
	";
	$i++;
	}
	
				

	$db->Close();
?>		
</table>
<br>
