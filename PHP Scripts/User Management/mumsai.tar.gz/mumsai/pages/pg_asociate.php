<SCRIPT LANGUAGE="JavaScript">
function moveOverCanBe()  
{
	var boxLengthcanbe = document.myfrm.elements['selectcanbe[]'].length;
	var selectedItem;
	var selectedText;
	var selectedValue;
	var boxLength = document.myfrm.selectall.length;


	for (i = 0; i < boxLength; i++) 
		if (document.myfrm.selectall.options[i].selected) {
			selectedText = document.myfrm.selectall.options[i].text;
			selectedValue = document.myfrm.selectall.options[i].value;
	
			newoption = new Option(selectedText, selectedValue, false, false);
			document.myfrm.elements['selectcanbe[]'].options[boxLengthcanbe] = newoption;
			boxLengthcanbe++;
		}

removeMe();
}


function moveOverCantBe()  
{
	var boxLengthcanbe = document.myfrm.elements['selectcannotbe[]'].length;
	var selectedItem;
	var selectedText;
	var selectedValue;
	var boxLength = document.myfrm.selectall.length;


	for (i = 0; i < boxLength; i++) 
		if (document.myfrm.selectall.options[i].selected) {
			selectedText = document.myfrm.selectall.options[i].text;
			selectedValue = document.myfrm.selectall.options[i].value;
	
			newoption = new Option(selectedText, selectedValue, false, false);
			document.myfrm.elements['selectcannotbe[]'].options[boxLengthcanbe] = newoption;
			boxLengthcanbe++;
		}

removeMe();
}


function dojob(){
	var boxLength1 = document.myfrm.elements['selectcanbe[]'].length;
	
	
	for (i = 0; i < boxLength1; i++) 
		document.myfrm.elements['selectcanbe[]'].options[i].selected=true;
		
	
}

function removeMe() {

	
	var finish=false;
	while(!finish){
			finish=true;

			if(document.myfrm.selectall.selectedIndex>=0){
				document.myfrm.selectall.remove(document.myfrm.selectall.selectedIndex);
				finish=false;
			}
	}
}

function  removeOverCantBe() {

	var boxLength = document.myfrm.selectall.length;

	var finish=false;
	while(!finish){
			finish=true;

			if(document.myfrm.elements['selectcannotbe[]'].selectedIndex>=0){

				selectedText = document.myfrm.elements['selectcannotbe[]'].options[document.myfrm.elements['selectcannotbe[]'].selectedIndex].text;
				selectedValue = document.myfrm.elements['selectcannotbe[]'].options[document.myfrm.elements['selectcannotbe[]'].selectedIndex].value;

				newoption = new Option(selectedText, selectedValue, false, false);
				document.myfrm.selectall.options[boxLength] = newoption;
				boxLength++;

				document.myfrm.elements['selectcannotbe[]'].remove(document.myfrm.elements['selectcannotbe[]'].selectedIndex);
				finish=false;
			}
	}
}
function  removeOverCanBe() {

	var boxLength = document.myfrm.selectall.length;

	var finish=false;
	while(!finish){
			finish=true;

			if(document.myfrm.elements['selectcanbe[]'].selectedIndex>=0){

				selectedText = document.myfrm.elements['selectcanbe[]'].options[document.myfrm.elements['selectcanbe[]'].selectedIndex].text;
				selectedValue = document.myfrm.elements['selectcanbe[]'].options[document.myfrm.elements['selectcanbe[]'].selectedIndex].value;

				newoption = new Option(selectedText, selectedValue, false, false);
				document.myfrm.selectall.options[boxLength] = newoption;
				boxLength++;

				document.myfrm.elements['selectcanbe[]'].remove(document.myfrm.elements['selectcanbe[]'].selectedIndex);
				finish=false;
			}
	}
}

//  End -->
</script>

<?

session_check("01");


$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 


$select=$_POST['selectcanbe'];
$save=$_POST['save'];


if($save==1){

	$id=$_POST['id'];

	$sql="delete from ".TABLE_LINKS_LABELS." where id_link=$id";	
	$db->Query($sql);
	
	
	foreach($select as $id_label){
	
		$sql="insert into ".TABLE_LINKS_LABELS." values(0,'$id','$id_label')";
		$db->Query($sql);
		
	}
	echo "Updated";
	
	
}


$id=$_GET['id'];
if(empty($id))$id=$_POST['id'];

	$sql="select a.name,b.id_label,a.id  from ".TABLE_LABELS." a,".TABLE_LINKS_LABELS." b where b.id_link='$id' and b.id_label=a.id";
	
	$result=$db->Query($sql);
	
	$content1="<select name='selectcanbe[]' multiple size='10' style='width:150px'>";
	while($r=mysql_fetch_array($result)){
	
		$content1.="<option value='".$r['id']."'>".$r['name']."</option>";
		$items[]=$r['id'];
	
	}

	$content1.="</select>";

	
	$sql="select *  from ".TABLE_LABELS."";
	
	$result=$db->Query($sql);
	
	$content="<select name='selectall' size='10' style='width:150px'>";
	while($r=mysql_fetch_array($result)){
		if(!@in_array($r['id'],$items))
			$content.="<option value='".$r['id']."'>".$r['name']."</option>";
	
	
	
	
	
	}
	
	$content.="</select>";
	
				
				
	
	
	
	echo "
	<h1><font color='green'>Associate label to link</font></h1><br>
	<form name='myfrm' action='index.php' method='post'>
	<input type='hidden' name='page' value='asociate'/>
	<input type='hidden' name='save' value='1'/>
	<input type='hidden' name='id' value='".$id."'/>
	<table border='0'>
	<tr>
		<td valign='top'>
		Labels:<br>
		$content<br>
		<input type='button' value='Move>>' name='bt2'  onClick='moveOverCanBe();'/>
		</td>		
		<td valign='top'>
		Link belong to:<br>
		$content1.<br>
		<input type='button' value='Remove' name='bt4' onClick='removeOverCanBe();'/>
		&nbsp;
		<input type='submit' value='Save' onClick='dojob();'/>
		</td>
	</tr>
	</table>
	</form>";
	

	$db->Close();
?>