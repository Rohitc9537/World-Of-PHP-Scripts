<font color='red' size='+1'>Forbidden</font><br>
You are not logged in, or you don't have the permissions to acces this page. If you think this is an 
error please use the <a href='mailto:<? echo ADMIN_EMAIL;?>'>admin</a> mail to announce us.

