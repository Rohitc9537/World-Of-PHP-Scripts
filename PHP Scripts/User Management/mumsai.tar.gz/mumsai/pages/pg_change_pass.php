<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">


<?php
GLOBAL $message;
require_once("includes/functions.php");
session_check();

?>
	<script>

	function validate(){
	f=document.frm;
	new_p=f.new_pass.value
	confirm_p=f.confirm.value
	if(new_p!=confirm_p){
		alert("Password doesn't match");
		return false;
	}
	return true;
	}
	</script>
	<br>
	<form name='frm' method='post' action='modules/do_change_pass.php'>
		<? echo $message['Old password'];?><br>
		<input type='password' name='old'/><br>
		<? echo $message['New password'];?><br>
		<input type='password' name='new_pass'/><br>
		<? echo $message['Confirm Password'];?><br>
		<input type='password' name='confirm'/><br>
		<input onClick='return validate()' type='submit' value='Change'/>
	
	</form>


