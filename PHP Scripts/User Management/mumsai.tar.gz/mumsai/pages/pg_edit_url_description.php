<?
session_check("0");

$id=$_GET['url'];

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

	#
	# Cautare permisiuni
	#
	
$sql="select url,description from ".TABLE_RESOURCES." where IDResource='$id'";	
$result=@$db->Query($sql);
$r=mysql_fetch_array($result);
$name=$r["url"];
$description=$r["description"];

$db->Close();
?>	

<form action="admin/do_new_url.php" method="post">
	
	<input type='hidden' name='update' value='<? echo $id;?>'/>

	<b>Enter URL:</b><br><br>
	http://<input type="text" name="url" maxlength="255" size="25" value='<? echo $name; ?>'><br>
	<br>
	Description:<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="text" name="description" maxlength="255" size="25" value='<? echo $description; ?>' /><br><br>
	<input type="submit" value="Update"/>

</form>


	
	

