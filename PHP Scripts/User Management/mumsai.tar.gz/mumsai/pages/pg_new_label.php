<?
//la pag asta are acces numai admin si moder
session_check("01");

//save

$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect(); 

$label=$_GET['label'];
$description=$_GET['description'];
$action=$_GET['action'];

$submit="Add";

//delete
if($action=='delete'){
	
	$id=$_GET['id'];
	
	$sql="delete from ".TABLE_LABELS." where id='$id'";
	if($db->Query($sql))
		echo "<font color='red'>Deleted</font>.";
		else
			echo "Failed";
	

}
//edit
if($action=='edit'){

	$id=$_GET['id'];
	
	$sql="select *  from ".TABLE_LABELS." where id='$id'";
	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);
	$label=$r['name'];
	$description=$r['description'];
		
	$submit="Modify";	
	
}


if(!empty($label) && empty($action)){
	
	$mode_edit=$_GET['mode_edit'];
	if(empty($mode_edit)){
	$sql="select count(*) as result from ".TABLE_LABELS." where name='$label'";
	$result=$db->Query($sql);
	$r=mysql_fetch_array($result);
	$result=$r["result"];
	if($result==0){
	
			$sql="insert into ".TABLE_LABELS." values(0,'$label','$description')";
			@$db->Query($sql);
			echo "<font color='green'>Label inserted.<a href='index.php?page=new_label'>Back</a></font>";
			
	}else
	
	
	echo "<font color='red'>This label already exists</font>";
	}
	else
	{
	
		$sql="update ".TABLE_LABELS." set name='$label' where id='$mode_edit'";
		$db->Query($sql);
	
		$sql="update ".TABLE_LABELS." set description='$description' where id='$mode_edit'";
		$db->Query($sql);
		
		echo "<font color='green'>Label updated.<a href='index.php?page=new_label'>Back</a></font>"; 
	
	
	}
	
	
	
}else{
		
?>



<h1>New Label</h1>
<h3>Links management</h3>
<br>

<form action="index.php" method="get">
	<input type='hidden' value='new_label' name='page'/>

	<b>Enter label:</b><br><br>
	<input type="text" name="label" value="<? echo $label; ?>" maxlength="255" size="25"/><br>
	<br>
	Description:<br>	
	<input type="text" name="description" value="<? echo $description; ?>" maxlength="255" size="25"/><br><br>
	<input type="submit" value="<? echo $submit; ?>"/>
	<?
	if($submit=="Modify"){
		$id=$_GET['id'];
		echo "<input type='hidden' name='mode_edit' value='$id'/>";
		}
	?>

</form>
<?
	
	$sql="select * from ".TABLE_LABELS."";
	
	$result=$db->Query($sql);
	echo "<table border='0' width='100%' cellpadding='0'><tr><th>Name</th><th align='left'>Description</th><th align='center'>Edit</th><th align='center'>Delete</th></tr>";
	while($r=mysql_fetch_array($result)){
		echo "<tr>
					<td>
					".$r['name']."
					</td>
					<td>
					".$r['description']."
					</td>
					<td align='center'>
					<a href='index.php?page=new_label&action=edit&id=".$r['id']."'>+</a>
					</td>
					<td align='center'>
					<a href='index.php?page=new_label&action=delete&id=".$r['id']."'><font color='red'>x</font></a>
					</td>
			  </tr>";
	}
	echo "</table>";
	
	
	
}
	$db->Close();
?>