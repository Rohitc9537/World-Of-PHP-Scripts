<?
GLOBAL $message;
require_once("includes/settings.php");
require_once("includes/functions.php");
session_check();
?>

<? echo $message['Profile update'];?> <a href='<? echo HTTTP; ?>'>here</a>