<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">


<?php
require_once("includes/functions.php");
session_check("01");

if(!empty($_SESSION['choosen_nick']))
		echo "Changing password for <b>".$_SESSION['choosen_nick']."</b>";
	else
		echo "First choose an user from CHOOSE USER link";
	
if(!empty($_SESSION['choosen_nick'])){
?>
	<script>

	function validate(){
	f=document.frm;
	new_p=f.new_pass.value
	confirm_p=f.confirm.value
	if(new_p!=confirm_p){
		alert("Password doesn't match");
		return false;
	}
	return true;
	}
	</script>
	<br>
	<form name='frm' method='post' action='modules/do_change_user_pass.php'>
		New password:<br>
		<input type='password' name='new_pass'/><br>
		Confirm password:<br>
		<input type='password' name='confirm'/><br>
		<input onClick='return validate()' type='submit' value='Change'/>
	
	</form>
<?
}
?>


