<?
session_start();
$new=$_POST['new_pass'];

require_once("../includes/settings.php");
require_once("../includes/functions.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

session_check();

$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

		
	$sql="update ".TABLE_USERS." set password='".md5($new)."' where nick='".$_SESSION['choosen_nick']."'";
	$result=@$db->Query($sql);
	if($result){
	$db->Close();
		header("Location:".HTTTP."index.php?page=password_changed");
		}
		else
			header("Location:".HTTTP."index.php?page=general_error");
			

?>