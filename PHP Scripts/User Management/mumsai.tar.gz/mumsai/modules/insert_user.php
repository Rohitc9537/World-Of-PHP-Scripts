<?


require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");


$VARS=$HTTP_POST_VARS;

$id=$_POST["id"];
$password=$_POST["password"];
$email=$_POST["email"];
$webpage=$_POST["webpage"];
$request_site=base64_decode($_POST["site"]);

$news=trim($_POST["news"]);

$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();


Verify_Unique($id,$email,$webpage,$request_site);
InsertData($id,$email,$password,$webpage,$request_site,$news);
Send_Verification_Email($id,$password,$email,$request_site,$news);
header("Location:".HTTTP."index.php?page=new_user_finish&r=".$_POST["site"]);
#
#Verifica unicitatea datelor
#
function Verify_Unique($id,$email,$webpage,$site){

	GLOBAL $db;

	$sql="Select count(IDUser) as result from ".TABLE_USERS." where nick='$id' or email='$email'";
	$result=$db->Query($sql);
	$r=@mysql_fetch_array($result);
	if($r["result"]!=0){
		header("Location:".HTTTP."index.php?page=new_user&err=1&site=".base64_encode($site)."");
		die();
	}
	
	if(!empty($webpage)){
		$sql="Select count(*) as result from ".TABLE_ADITIONAL_USER_INFO." where webpage='$webpage'";
		$result=$db->Query($sql);
		$r=@mysql_fetch_array($result);
		if($r["result"]!=0){
			header("Location:".HTTTP."index.php?page=new_user&err=2&site=".base64_encode($site)."");
			die();
		}
	}
		
}

#
# Inserarea in tabele
#
function InsertData($id,$email,$password,$webpage,$request_site,$news){

	GLOBAL $db;
	GLOBAL $VARS;
	
	$sql="SELECT IDResource  from ".TABLE_RESOURCES." where url='".$request_site."'";
	$result=$db->Query($sql);
	$r=@mysql_fetch_array($result);	
	
	$IDResource=$r["IDResource"];
	
	if(empty($IDResource))
		die("The ".$request_site." does not exist in our database");
	


	#
	#Informatii standard
	#
	$sql="Insert into ".TABLE_USERS." values(0,'$id','$email','".md5($password)."','".md5($id.$email)."','".date("Y-m-d H:i:s")."')";
	if(!$db->Query($sql)){
		$db->Close();
		die("Error saving data!");
	}
	
	
	
	$sql="SELECT IDUser from ".TABLE_USERS." where nick='$id'";
	$result=$db->Query($sql);
	$r=@mysql_fetch_array($result);
	$IDUser=$r["IDUser"];

	
	#
	#Informatii custom
	#
	$sql="Insert into ".TABLE_ADITIONAL_USER_INFO." values('$IDUser','$webpage'";
	$i=0;
	while(list($key, $value) = each($VARS)){
		if($i>=7)
			$sql.=",'$value'";
			$i++;
	}
	$sql.=")"; 
	

	if(!$db->Query($sql)){
		$db->Close();
		die("Error saving data!");
	}
	
	
	
	
	#
	#Vrea sa primeasca stiri-inserare in tabela cu stiri
	#
	if(strcmp($news,"yes")==0){
		
		$sql="Insert into ".TABLE_NEWS." values('$IDUser','$IDResource','-')";
		if(!$db->Query($sql)){
			$db->Close();
			die("Error saving data");	
		}
	}
	
	#
	#Setare permisiuni InternetUser
	#	
	$sql="Insert into ".TABLE_PERMISIONS." values(0,'$IDUser','3','0')"; 
	if(!$db->Query($sql)){
		$db->Close();
		die("Error saving data");	
	}
	 
	
	
}	

function Send_Verification_Email($id,$password,$email,$request_site,$news){

	GLOBAL $db;
	$no=date("U");
$message = '
		<html>
		<head><title>Registration</title></head>
		<body>
			<p>You have register to site '.$request_site.'</p>
			<p>Your information<br/>
			Id: '.$id.'<br/>
			Password: '.$password.'<br/>				
			</p>
			<p>To activate you account follow this link: <a href="'.HTTTP.'/index.php?page=activate&q='.md5($id.$email.$no).'&site='.base64_encode($request_site).'&news='.$news.'">Activate</a></p>
		</body>
		</html>';
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From:".ADMIN_EMAIL."\r\n";
		
		if(@mail($email,"User account activation for ".$request_site."",$message,$headers)){
		
			$query_post = "update ".TABLE_USERS." set code='".md5($id.$email.$no)."' where nick='".$id."'";
			if($result = $db->Query($query_post))
				return true;
					else
						return false;
				
		}
		else
			return false;
}


?>
