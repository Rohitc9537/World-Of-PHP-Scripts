<?
session_start();
$old=$_POST['old'];
$new=$_POST['new_pass'];

require_once("../includes/settings.php");
require_once("../includes/functions.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

session_check();

$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

$sql="select password from ".TABLE_USERS." where nick='".$_SESSION['user_ax']."'";
$result=@$db->Query($sql);
$r=@mysql_fetch_array($result);
//se potriveste parola veche
if( strcmp($r['password'],md5($old))==0){
		
	$sql="update ".TABLE_USERS." set password='".md5($new)."' where nick='".$_SESSION['user_ax']."'";
	$result=@$db->Query($sql);
	if($result){
	$db->Close();
		header("Location:".HTTTP."index.php?page=password_changed");
		}
		else
			header("Location:".HTTTP."index.php?page=general_error");
			

}else{
	$db->Close();
	
	header("Location:".HTTTP."index.php?page=wrong_pass");
	}
	
	



?>