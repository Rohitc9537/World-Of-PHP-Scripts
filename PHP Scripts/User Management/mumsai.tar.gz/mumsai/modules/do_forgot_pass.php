<?
require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();

$email=$_POST["email"];

$query_check = "SELECT nick FROM ".TABLE_USERS." WHERE email='$email'";
$result = $db->Query($query_check);
$n= @mysql_fetch_array($result);
	#trimit mail cu o parola random
	if(!empty($n["nick"])){
				$passwd=base64_encode(substr($email,0,5));
				$query_check = "Update ".TABLE_USERS." set password='".md5($passwd)."' WHERE email='$email'";
				$db->Query($query_check);
				
				$message = '
						<html>
						<head><title>Your password for Axiologic</title></head>
						<body>
						Id: '.$n["nick"].'<br>
						New password is '.$passwd.'<br>
						Change it <a href="'.HTTTP.'">here</a>
						</body>
						</html>';
				$headers = "MIME-Version: 1.0\r\n";
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				$headers .= "From:root@axiologic.net\r\n";
				if(@mail($email,"Axiologic new password",$message,$headers))
					echo "
					<Script>
					alert('Your password has been sent');
					location='".HTTTP."index.php'
					</script>
					";
						else
							echo "
							<Script>
							alert('Send mail failed.Please try again later');
							location='".HTTTP."index.php'
							</script>
					
							";
				
	}else
	echo "
	<Script>
	alert('You are not registered');
	location=document.history.go(-1);
	</script>
	";
	
				
?>