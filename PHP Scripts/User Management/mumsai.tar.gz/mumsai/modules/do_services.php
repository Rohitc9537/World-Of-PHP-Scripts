<?
session_start();
include_once("../includes/settings.php");
include_once("../includes/functions.php");
include_once("../includes/config_mysql.php");
include_once("../Class/MySql.Class.php");
include_once("../CLIENT/EMAILClient.Class.php");

//session_check("0");

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	$id_user=$_POST['id'];
	$email=$_POST['email'];
	
	
	
	foreach($_POST as $key=>$value){
	
	if(strcmp($key,"id")!=0 && strcmp($key,"email")!=0){
		#
		#Cauta sa vad daca e schimbare
		#
		$sql="select count(*) as no from ".TABLE_NEWS." where  IDUser='$id_user' and IDResource='$key'";
		$result=@$db->Query($sql);
		$r=@mysql_fetch_array($result);
		
		$no=$r['no'];//1=apare in tabela cu spam pt un url
		
		//a bifat sa primeasca stiri pt un url, era deja bifat
		if($value==1 && $no==1){		
			//do nothing...			
			}
			
		//a bifat sa primeasca stiri pt un url, nu era deja bifat
		if($value==1 && $no==0){
			//pt url $key acu a bifat, va trebui sa trimit sitului instiintare si sa adaug inreg in baza de date
			
			$sql="insert into  ".TABLE_NEWS." values('$id_user','$key','')";
			@$db->Query($sql);	
			
			//aflare adresa unui idres
			$sql="select url from ".TABLE_RESOURCES." where IDResource='$key'";
			$result=@$db->Query($sql);
			$r=@mysql_fetch_array($result);
			$url=$r['url'];
			
			
			/*conectare la serveru pt urlu curent si transmiterea mesajului*/
			$client=new CEMAILClient();
			$client->Connect("http://".$url."/SERVER/server.php");
			$client->Send_Update($email,1);//1=adaugare
			$client->Close();
						
			}
		
		//nu a bifat pt situl curent si nici nu era bifat
		if($value==0 && $no==0){
			//pt url $key nu era bifat, si a ramas nebifat- nu fac nimic
			//do nothing...
		}
			
			//nu a bifat pt situl curent si nici nu era bifat
			if($value==0 && $no==1){
			echo "pt url $key era bifat in tabele , dar a bifat acuma sa nu mai primeasca=sterg din news si trimit instiint";
			$sql="delete from ".TABLE_NEWS." where IDUser='$id_user' and IDResource='$key'";
			@$db->Query($sql);			
			
			
			$sql="select url from ".TABLE_RESOURCES." where IDResource='$key'";
			$result=@$db->Query($sql);
			$r=@mysql_fetch_array($result);
			$url=$r['url'];
			
			/*conectare la serveru pt urlu curent si transmiterea mesajului*/
			$client=new CEMAILClient();
			$client->Connect("http://".$url."/SERVER/server.php");
			$client->Send_Update($email,0);//0=stergere
			$client->Close();
			
			
			
		}
			
			
		
	}
		

	}
	$db->Close();
	echo "
     <script>
		location='".HTTTP."index.php?page=show_services'
	</script>
	";
	
	


?>
