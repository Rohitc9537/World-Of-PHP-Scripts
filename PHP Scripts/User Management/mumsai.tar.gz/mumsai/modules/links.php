<?

$class="";

include("links_parser/rss.php");

foreach($links as $link)
	echo "<li>$link</li>";
?>
