<?
Global $message;
?>
<ul>
<li><a  href="index.php"><? echo $message['Home'];?></a></li>
<li><a href='index.php?page=edit_profile'><? echo $message['Profile'];?></a></li>
<li><a  href="index.php?page=show_services" ><? echo $message['Services'];?></a></li>
<?
if(empty($_SESSION['user_ax'])){

?>
<li><a href='index.php?page=reactivate'><? echo $message['Resend activation code'];?></a></li>

<?
}
include_once("includes/functions.php");

if(!empty($_SESSION['user_ax']) && (strcmp(getPermissions(HTTTP),"Admin")==0 ||strcmp(getPermissions(HTTTP),"Moderator")==0)){


?>
<li><a href="index.php?page=last_login">Last login</a></li>
<li><a href="index.php?page=last_logins">Last logins</a></li>
<h3 class='select'><span>Admin area</span></h3>
<li><a href="index.php?page=choose_user">Choose user</a></li>
<li><a href="index.php?page=permissions_step1">Permissions</a></li>
<li><a href="index.php?page=change_user_pass">Change users pass.</a></li>
<li><a href="index.php?page=new_url">New url </a></li>
<li><a href="index.php?page=list_users">List users</a></li>
<li><a href="index.php?page=list_urls">List urls</a></li>
<li><div align='left'><font color='yellow'><b>&nbsp;Links management</b></font></div></li>
<li><a href="index.php?page=new_label">New/Edit label</a></li>
<li><a href="index.php?page=new_link">New/Edit link</a></li>
<li><a href="index.php?page=generate">Generate rss links</a></li>
<?
}
?>
</ul>
<br>
<?
if(file_exists("blocs/google.html"))
	include("blocs/google.html");
?>