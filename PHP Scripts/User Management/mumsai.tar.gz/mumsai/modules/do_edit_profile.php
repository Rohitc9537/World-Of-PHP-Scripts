<?
###############################################
# 											  #
# Prelucrare formular user nou pentru server  #
#    Pas1->Verificare unicitatii datelor      #
#    pas2->Inserarea datelor                  #
#    Pentru resource se genereaza TCS         #
#                                             #
#    Iunie 2005								  #
###############################################

session_start();

require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");

$VARS=$HTTP_POST_VARS;


$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();


$id=$_SESSION['user_ax'];
$iduser=$_POST["id_user"];
$webpage=$_POST["webpage"];



InsertData($id,$id_user,$email,$webpage);
header("Location:".HTTTP."index.php?page=msg_profile_updated");

#
# Inserarea in tabele
#
function InsertData($id,$iduser,$email,$webpage){

	GLOBAL $db;
	GLOBAL $VARS;
	
	
	
	
	
	#
	#Informatii custom
	#
	$sql="update ".TABLE_ADITIONAL_USER_INFO." set webpage='$webpage' where IDUser='$iduser'";
	$db->Query($sql);
	$i=0;
	while(list($key, $value) = each($VARS)){
		if($i>=3)
			$sql="update ".TABLE_ADITIONAL_USER_INFO." set $key='$value' where IDUser='$iduser'";
			$db->Query($sql);
			$i++;
	}
	
		
	
		
}	



?>
