<?
session_start();
$usr=$_SESSION["user_ax"];
$_SESSION["user_ax"]='';
$_SESSION["choosen_id"]='';
unset($_SESSION["user_ax"]);
unset($_SESSION["choosen_nick"]);


require("../includes/settings.php");
require("../includes/config_mysql.php");
require("../Class/MySql.Class.php");
include_once("../CLIENT/LOGOUTClient.Class.php");

/*-----send logout command-----*/

	$db=new Mysql(DB_NAME,DB_USER,DB_PASSWORD);
	$db->Connect(); 

	#
	#Iau pe rand fiecare url
	#
	
	$sql="delete from ".TABLE_LOGIN." where user='$usr'";	
	$db->Query($sql);
	
	
	$sql="select url  from ".TABLE_RESOURCES."";	
	$result=$db->Query($sql);
	
	while(($r=mysql_fetch_array($result))){		
		$c=new CLOGOUTClient();
		
			if(strcmp($r['url'],"www.free-test.info")==0 ||
			strcmp($r['url'],"www.today-news.info")==0 ){
			$c->Connect("http://".$r['url']."/SERVER/server.php");
			$user=$c->SendLogout($usr);
			}
		
		$c->Close();
		
		}
		
	
	
		
/*-----end of send logout------*/

$i=0;
while(!empty($_SESSION['Urls['.$i.']'])){
	$_SESSION['Urls['.$i.']']='';
	$i++;
	}

?>

<script>
function redirect(where){
location=where
}
</script>

<html>
<body onload='redirect("<? echo HTTTP."index.php";?>")'>
</html>
