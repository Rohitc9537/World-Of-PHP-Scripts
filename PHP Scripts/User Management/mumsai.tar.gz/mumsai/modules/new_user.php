<?
GLOBAL $message;

$err=$_GET["err"];
$site=$_GET["site"];

if(empty($site))
	echo "<Center>No url specified!</center>";
else{
?>
<script>

function is_email(val)
{
	var at = val.indexOf("@")
	if(at == -1){
	 return false
	 }
	else
	{
		var at_parts = val.split("@")
		if(at_parts[0].length < 1){
			return false
			}
		else{
			point = at_parts[1].indexOf(".")
			if(point == -1) return false
			else{
			  point_parts = at_parts[1].split(".")
			  if((point_parts[1].length < 2) || (point_parts[1].length > 3)) return false
			  else  return true
			}
		}
	}
}


function accept(str){
acc="~_`.!,:_#@$^&*+|{}/?=-0123456789abcdefghijklmnoprstuvxzqywABCDEFGHIJKLMNOPRSTUVXZYQW "

var ch
var found = true

if (str.length == 0) 
{
   return true
}
for (i = 0; i < str.length ;i++){
		ch = str.charAt(i)
		if(acc.indexOf(ch)==-1){
			found=false
			}
}
return found
		
}


function validate()
{
	f = document.frm
	
	isOK = true
	usr_account = f.id.value
	usr_pass = f.password.value
	usr_pass_conf = f.password_.value
	usr_em = f.email.value
	usr_web=f.webpage.value
	
	
	
	if (!accept(usr_account))
	{
		alert("Invalid Id")
		isOK = false
	}

	
	if (!accept(usr_web))
	{
		alert("Invalid Web page")
		isOK = false
	}
		
	if (!accept(usr_pass))
	{
		alert("Wrong password")
		isOK = false
	}
	
	if (!accept(usr_em))
	{
		alert("Invalid Email")
		isOK = false
	}
		
	
	if(usr_account.length < 4)
	{
		alert("Id minimum 4 chars")
		isOK = false
	}
	if(usr_pass.length < 1)
	{
		alert("Type a password")
		isOK = false
	}
	
	if(!is_email(usr_em))
	{
		alert("Email invalid")
		isOK = false
	}
	
	if(usr_pass_conf!=usr_pass){
		alert("Password don't match") 
		isOK = false
	} 
	
	//validare pentru campurile custom-sa contina caractere acceptate
	for (j = 5; j < f.length-1 ;j++){
		field=f[j].value
		if(field!='T' && field!='F')				
			if(!accept(field))
				{
					alert("Field "+f[j].name+" ("+field+") invalid")
					isOK = false
				}		
	}
	
	
	return isOK
}	
</script>
<?

if( ($handle=fopen("modules/server_fields.cfg","r"))==NULL){
	echo "Erorr opening server_fields.cfg";
	die();
}else
	{
	$name=array();
	$fields=array();
	$type=array();
	$length=array();
		
	$i=0;
	while (!feof($handle)) {
		list($name[$i],$fields[$i],$type[$i],$length[$i])=explode("-",fgets($handle));				
		$i++;
		}
	
	$i--;
	fclose($handle);
	}

?>

<table  border="0" align="center" cellpadding="0" cellspacing="1">
  <tr>
    <td height="111" valign="top" align="left">
		<br>
		<b><? echo $message['Accepted chars']; ?><B>
		<font size='+1'>_`.!,:_#@$^&*+|{}/?=-</font> <? echo $message['letters and numbers'];?>
		<br>
		<br>
				<b><font color='red'><? echo $message['Required'];?></font><b>
			
				<form name="frm" action="modules/insert_user.php" method="post">
				<? if($err==1) echo "<br><font color='red'>Id or Email already exists</font><br>"; ?>
				Id:*<br>
				<input type="text" size="20" maxlength="20" name="id" /><br>
				
				<? echo $message['Password'];?>:*<br>
				<input type="password" size="20" maxlength="20" name="password" /><br>
				
				
				<? echo $message['Confirm Password'];?>:*<br>
				<input type="password" size="20" maxlength="20" name="password_" /><br>
				
				
				Email:*<br>
				<input type="text" size="20" maxlength="60" name="email" /><br>
				
				<? if($err==2) echo "<br><font color='red'>Web page already exists</font><br>"; ?>
				
				<? echo $message['Web page'];?>:<br>
				<input type="text" size="30" maxlength="255" name="webpage" /><br>
				<? echo $message['Receive news'];?>
				<input type='radio' name='news' value='yes'/>Yes 
				<input type='radio' name='news' value='no' checked />No
				<input type="hidden" value="<? echo $site; ?>" name="site"/>
				<br>
				<?
				for($j=0;$j<$i;$j++){
				
					#
					#int(1) means bool.
					#
					if(strcmp($type[$j],"int")!=0 && $length[$j]!=1)
						echo "
						".$name[$j].":<Br>
						<input type='text' name='".$fields[$j]."' /><br>
						";
					else
						echo "
						".$name[$j].": 
						<input type='radio' name='".$fields[$j]."' value='_BOOL_T_' />Yes 
						<input type='radio' name='".$fields[$j]."' value='_BOOL_F_' checked />No
						<br>
					";	
						
				}
				?>
				<br>
				<center><input type='submit' value="Register" onClick="return validate()"/></center>
				<!-- transmit situl mai departe pt prelucrare -->
				
				</form>
			
	</td>
  </tr>
</table>
<?
}
?>
