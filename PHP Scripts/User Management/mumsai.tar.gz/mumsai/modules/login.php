<?
session_cache_limiter('private');
/* set the cache expire to 30 minutes */
session_cache_expire(60*24);

session_start();

session_register("user_ax");
require("../includes/config_mysql.php");
require("../includes/settings.php");
require("../Class/MySql.Class.php");

require("../CLIENT/AUTHClient.Class.php");

require("../includes/functions.php");



$id=$_POST['id'];
$password=$_POST['pass'];



$where=HTTTP;

$c=new CAUTHClient();

	if($c->Verify()){
	
			 
		if($c->Validate_passwd($id,$password,$url,$perm)){		
			
			setPermissions($url,$perm);			
			$_SESSION["user_ax"]=$id;	
			$_SESSION["choosen_nick"]=$id;	
			SetUserKey($id,'-');
			

			}else
				$where=HTTTP."index.php?r=err_log";				
	}
	
		
echo "<script>
	location='".$where."';			
      </script>";
				    
	    	    

?>

