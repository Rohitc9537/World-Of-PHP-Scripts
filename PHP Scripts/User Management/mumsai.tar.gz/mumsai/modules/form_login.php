<?

global $message;
if(empty($_SESSION['user_ax'])){
if(strcmp($_GET['r'],"err_log")==0)
	echo "<font color='red'>User/Password doesn't match</font>";
?>


<form action="modules/login.php" method="post">
			Id:<br>
			<input type="text" name="id" size="18"/><br>
			<? echo $message['Password']; ?><br>
			<input type="password" name="pass" size="18"/><br>
			<input type="submit" value="Login"/><br>
		</form>
<?
}else{
?>
 	<ul>
	    <li>User <font color='orange'> <? echo $_SESSION['user_ax']; ?></font> logged in </li>
	    <li><a href='modules/logout.php'><? echo $message['Log out'];?></a></li>
	    <li><a href='index.php?page=change_pass'><? echo $message['Change password'];?></a></li>	    
       </ul>
		<?
		}
		?>


<?
if(empty($_SESSION['user_ax'])){
?>
<ul>
<li><a href='index.php?page=new_user_terms&amp;site=<? echo base64_encode(HTTP);?>'><? echo $message['New user'];?></a></li>
<li><a href='index.php?page=forgot_pass'><? echo $message['I forgot my pass'];?></a></li>

</ul>
<?
}
?>

