<?
###############################################
# 											  #
# Prelucrare formular user nou pentru server  #
#    Pas1->Verificare unicitatii datelor      #
#    pas2->Inserarea datelor                  #
#    Pentru resource se genereaza TCS         #
#                                             #
#    Iunie 2005								  #
###############################################


require_once("../includes/settings.php");
require_once("../includes/config_mysql.php");
require_once("../Class/MySql.Class.php");


$email=$_POST["email"];


$db=new MySql(DB_NAME,DB_USER,DB_PASSWORD);
$db->Connect();


Send_Verification_Email($email);
echo "
	<script>
	location='".HTTTP."'
	</script>
";
#
#Verifica unicitatea datelor
#

function Send_Verification_Email($email){

GLOBAL $db;

$sql="select nick from ".TABLE_USERS." where email='$email'";
$result=@$db->Query($sql);
$r=@mysql_fetch_array($result);
$nick=$r['nick'];

$no=date("U");

$message = '
		<html>
		<head><title>Registration</title></head>
		<body>
			<p>Reactivation</p>
			<p>Your information<br/>
			Id: '.$nick.'<br/>
			</p>
			<p>To activate you account follow this link: <a href="'.HTTTP.'/index.php?page=activate&q='.md5($nick.$email.$no).'&site='.base64_encode("www.axiologic.net").'">Activate</a></p>
		</body>
		</html>';
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From:root@axiologic.net\r\n";
		
		if(@mail($email,"User account activation ",$message,$headers)){
			$query_post = "update ".TABLE_USERS." set code='".md5($nick.$email.$no)."' where nick='".$nick."'";
			if(@$db->Query($query_post))
				echo "
				<script>
				alert('Reactivation code sent');
				</script>
				";
		}
				
		
			
}


?>