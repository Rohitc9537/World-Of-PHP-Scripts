<?php
$hostname = "localhost";	/* Hostname (usually localhost) */
$user = "username";		/* Username for database */
$pass = "password";		/* Password for database */
$database = "dbname";		/* Database name */
$domain = "yourdomain.com";	/* Do NOT enter www. or http:// */
$directory = "/login/";		/* this is the directory location of the script ie.. /login/ be sure to add a slash at the beginning and end */
?>