Network-13 Login System!

Requirements:

1 MySQL database is required

Installation:

(1) Extract all files
(2) Edit config.php change the relative information. Save the file
(3) Create a MySQL database on your server
(4) Upload all files to the server
(5) Once uploaded goto install.php this will create the nessecary tables in the database. Once created remove this file from the server.
(6) YOUR DONE! goto register.php to create an account


http://network-13.com