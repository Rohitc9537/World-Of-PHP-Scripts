// *************************************************************************************************
// Title: 		PHP AGTC-IP ban v1.0a
// Developed by: Andy Greenhalgh
// Email:		andy@agtc.co.uk
// Website:		agtc.co.uk
// Copyright:	2005(C)Andy Greenhalgh - (AGTC)
// Licence:		GPL, You may use this software under the terms of this General Public License
// *************************************************************************************************
//
## Intro:


Admin Password:	admin

## Requirements:
PHP no MySql required, flat file only.


## Features:
1. Admin Page with secure login
2. Add banned IP address through admin page
3. List all banned IP's through admin page

## File Check: (You should have this list of files uploaded to your server)
admin.php
check.php
inc.php
ip.txt
readme.txt
IPstyle.css
testpage.php (For demo purposes)

## Instructions:
1. Upload all files to your server
2. Run admin.php from your browser
3. Enter 'admin' for password
4. Your done....

You can change the admin password from inc.php

