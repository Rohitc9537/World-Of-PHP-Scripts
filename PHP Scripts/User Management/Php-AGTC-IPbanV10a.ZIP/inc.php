<?php
// *************************************************************************************************
// Title: 		PHP AGTC-IP Ban v1.0a
// Developed by: Andy Greenhalgh
// Email:		andy@agtc.co.uk
// Website:		agtc.co.uk
// Copyright:	2005(C)Andy Greenhalgh - (AGTC)
// Licence:		GPL, You may distribute this software under the terms of this General Public License
// *************************************************************************************************
//
// YOU CAN CHANGE THE ADMIN PASSWORD BELOW
$password = "admin";
// PLEASE DO NOT REMOVE OR CHANGE THE COPYRIGHT BELOW
$copyright = "Copyright &copy;2005 <a href='http://www.agtc.co.uk'> PHP AGTC-IP Ban v1.0a</a>";
?>