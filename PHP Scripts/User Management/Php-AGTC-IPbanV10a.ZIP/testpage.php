<?php
// *************************************************************************************************
// Title: 		PHP AGTC-IP Ban v1.0a
// Developed by: Andy Greenhalgh
// Email:		andy@agtc.co.uk
// Website:		agtc.co.uk
// Copyright:	2005(C)Andy Greenhalgh - (AGTC)
// Licence:		GPL, You may distribute this software under the terms of this General Public License
// *************************************************************************************************
//
// THIS IS THE TEST PAGE, SO YOU CAN SEE HOW IT WORKS, TRY ADDING YOUR OWN IP ADDRESS
// AND THEN RELOAD THIS PAGE, IT WILL IMFORM YOU THAT YOU ARE BANNED.
// TO UN-BAN AN IP REMOVE IT FROM THE ip.txt FILE, BUT DONT LEAVE ANY BLANK SPACES.
// VERSION 1.1a WILL HAVE AN EDITABLE AREA, SO YOU CAN UN-BAN IP'S FROM ADMIN, COMING SOON.
include "check.php"; // JUST INCLUDE THIS LINE AT THE TOP OF THE PAGES YOU WISH TO PROTECT

?>
Hello, welcome to my site