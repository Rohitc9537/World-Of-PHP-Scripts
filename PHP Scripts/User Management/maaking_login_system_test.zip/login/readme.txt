###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.0                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:   August 22 2005             \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
MSN        :   m@maaking.com              \\
AOL-IM     :   maa2pal                    \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/

Install:

- upload files to your site.
- create a new databse and insert mysql_database.sql Using PHPMyAdmin.
- edit config file and change the requested.

note: this is the test version.
i am working on the official version with much more enhancements and modifications.

I welcome any suggestion/modification at m@maaking.com or contact page: http://www.maaking.com/index.php?loadpage=contact


Regards :)
Mohammed Ahmed