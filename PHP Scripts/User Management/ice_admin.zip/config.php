<?php $username2 = "test"; // Your Username
$password2 = "test"; // Your Password ?>