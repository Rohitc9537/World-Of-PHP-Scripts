Thank you for downloading Ice-Admin. 

// Installation Guide
To install Ice-Admin, just open config.php edit the 2 variables with
your wanted password and username and upload the script, your now avai-
lable to login to a protected area on your site.