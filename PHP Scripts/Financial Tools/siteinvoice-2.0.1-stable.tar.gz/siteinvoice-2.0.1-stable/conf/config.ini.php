; <?php /* DO NOT ALTER THIS LINE, IT IS HERE FOR SECURITY REASONS

default_handler = index
default_handler_type = box

app_name = "SiteInvoice"
description = "Simple invoice manager"

admin_handler = index
admin_handler_type = box

; DO NOT ALTER THIS LINE, IT IS HERE FOR SECURITY REASONS */ ?>
