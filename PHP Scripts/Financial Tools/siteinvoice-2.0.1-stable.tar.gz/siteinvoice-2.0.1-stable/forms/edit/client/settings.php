[Form]

[id]

type = hidden

[code]

type = text

[name]

type = text

[contact_name]

type = text

[contact_email]

type = text

[contact_phone]

type = text

[address]

type = textarea

[submit_button]

type = submit
setValues = Save

