Authors: Bernd R�mer <berndr@bonn.edu>
         Sebastian Bergmann <sb@sebastian-bergmann.de>
         Tomas V.V.Cox <cox@idecnet.com>
         Michele Manzato <michele.manzato@verona.miz.it>

Package Home: http://pear.php.net/package/XML_Tree

Documentation:

You can find a good introduction tutorial for this class at:

http://www.devshed.com/Server_Side/PHP/XMLTrees/page1.html

Feel free to contribute your own documentation :-)

Bug Reporting:

Please report bugs at the package home page

--
 Tomas V.V.Cox