<?php
/*----------------------------------------------------------------------------*/
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// Read the README file for more information
/*----------------------------------------------------------------------------*/

// define variables
$sys_dbhost = 'localhost';
$sys_dbuser = 'citrus';
$sys_dbpasswd = 'citrus';
$sys_dbname = 'citrus';
$sys_dbtype = 'mysql';
$path_to_citrus = '/users/pyasi/sites/citrusdb';
$hidden_hash_var='youmustchangethis';

?>
