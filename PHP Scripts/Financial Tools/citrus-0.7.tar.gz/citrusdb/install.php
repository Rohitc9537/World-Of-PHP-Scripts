<html>
<head>
<title>CitrusDB Installer</title>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
<script language="JavaScript">
function h(oR) {
	oR.style.background-color='ffdd77';
}	
function deh(oR) {
	oR.style.background-color='ddddee';
}
function dehnew(oR) {
	oR.style.background-color='ddeeff';
}
</script>
</head>
<body bgcolor="#ffffff">
<?php
/*----------------------------------------------------------------------------*/
// CitrusDB - The Open Source Customer Database
// Copyright (C) 2002-2005 Paul Yasi
//
// This program is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT 
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with 
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple 
// Place, Suite 330, Boston, MA 02111-1307 USA
//
// http://www.citrusdb.org
// Read the README file for more details
/*----------------------------------------------------------------------------*/


// Get our base include class and functions
require 'include/citrus_base.php';
$base = new citrus_base();

session_start();

//GET Variables (sorta like the old way for now)
$cmd = $base->input['cmd'];
$sqlhost = $base->input['sqlhost'];
$sqlusername = $base->input['sqlusername'];
$sqlpassword = $base->input['sqlpassword'];
$dbname = $base->input['dbname'];
	
switch ($cmd) {
		
	default:
	// prompt for the mysql host, username, password and database name
	echo '
	<h3>This does nothing yet, please read the install instructions</h3>
	<script language="JavaScript" src="include/md5.js"></script>
	<div id=horizon>
		<div style="margin-left: -125px; position: absolute; top: -145px; left: 50%; border: 1px solid black; padding: 5px; background: #ffe;">
		<center><table><td valign=top>
		<h3>Welcome to the CitrusDB Installer</h3>
		<P>
		Enter your mysql server information.
		<P>
		<FORM ACTION="index.php" METHOD="POST">
		<table>
		<td><b>Hostname:</b></td>
		<td><input type="text" name="sqlhost"></td>
		<tr>
		<td><B>Username:</B></td>
		<td><INPUT TYPE="TEXT" NAME="sqlusername"></td>
		<tr>
		<td><B>Password:</B></td>
		<td><INPUT TYPE="password" NAME="sqlpassword"></td>
		<tr>
		<td><b>Database Name:</b></td>
		<td><input type="text" name="dbname"></td>
		<tr>
		<td></td>
		<td>
		<input type=hidden name="cmd" value="testsql">
		<INPUT TYPE="submit" NAME="Begin" VALUE="Begin" class=smallbutton></td>
		</table>
		</FORM>
		<P></td></table>
		</div>
	</div>';
	break;
	
	case 'testsql':
	// try logging into the empty database to see if it works
	//	if it fails show an error, otherwise continue
	
	break;
	
	case 'makedatabase':
	// dump the sql from citrus.sql into the database inside mysql

	break;
	
	case 'makevariables':
	// determine the file system path to put inside the path_to_citrus variable
	// prompt or autocreate the hiddenhashvar to insert into the config file
	// create the config file - ask the user to copy and paste the text shown 
	// into a new empty config.inc.php file to put in the include folder
	
	break;

	case 'finish':
	// tell the user they must delete the install.php file
	// provide a link to the login page of their database
	
	break;
}


?>
</body>
</html>
