<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information -->

<table cellpadding=0 cellspacing=0 border=0 width=720 height=48>
<td width="20%" align=center><a href="index.php?load=customer&type=module&create=on"><img src="images/new-icon.png" alt="New Customer" border=0><br>New</a></td>
<td width="20%" align=center><a href="index.php?load=search&type=base"><img src="images/search-icon.png" alt="Search" border=0><br>Search</a></td>
<td width="20%" align=center><a href="index.php?load=print&type=base"><img src="images/print-icon.png" alt="Print Record" border=0><br>Print</a></td>
<td width="20%" align=center><a href="index.php?load=version&type=tools"><img src="images/admin-icon.png" alt="Tools" border=0><br>Tools</a></td>
<td width="20%" align=center>
<?php
print "<a href=\"logout.php\"><img src=\"images/logout-icon.png\" alt=\"Logout $user\" border=0><br>Logout $user</a>";
?>
</td></table>
