<?php   
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//Includes
require_once('include/permissions.inc.php');

// GET Variables
$notify = $base->input['notify'];
$status = $base->input['status'];
$description = $base->input['description'];

if ($edit)
{
    if ($pallow_modify)
    {
       include('edit.php');
    }  else permission_error();
}
else if ($create) // add the message to customer history
{
	if ($pallow_create)
    	{
	$query = "INSERT into customer_history (creation_date,created_by,notify,account_number,status,description) VALUES (CURRENT_TIMESTAMP,'$user','$notify','$account_number','$status','$description')";
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=customer&type=module\";</script>";
	} else permission_error();
}

else if ($delete)
{
    if ($pallow_remove)
    {
       include('delete.php');
    } else permission_error();
}

else if ($pallow_view)
{
print <<<END
<a href="index.php?load=customer&type=module">[ Undo Changes ]</a> &nbsp; 
<a href="index.php?load=support&type=module&edit=on">[ Check Notes ]</a>
<table cellpadding=5 border=0 cellspacing=1 width=720>
<td bgcolor="#ccccdd"><b>Created By</b></td><td bgcolor="#ddddee">$user</td><tr>
<td bgcolor="#ccccdd"><b>Notify</b></td><td bgcolor="#ddddee">
<form style="margin-bottom:0;" action="index.php">
END;

        print "<select name=\"notify\">\n";
	print "<option></option>\n";
	print "<option>nobody</option>\n";
	print "<optgroup label=\"groups\">\n";
	// print the list of groups
        $query = "SELECT DISTINCT groupname FROM groups ";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

	while ($myresult = $result->FetchRow())
        {
                $groupname = $myresult['groupname'];          
                print "<option>$groupname</option>\n";
        }

	// print a seperator
	print "</optgroup><optgroup label=\"users\">\n"; 


	// print the list of users
        $query = "SELECT username FROM user ORDER BY username";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	while ($myresult = $result->FetchRow())
        {
                $username = $myresult['username'];
                print "<option>$username</option>\n";
        }

        print "</optgroup></select>\n";


print <<<END
<input type=hidden name="status" value="not done">\n
</td><tr>
<td bgcolor="#ccccdd"><b>Description</b></td><td bgcolor="#ddddee"><textarea name="description" rows=8 cols=50></textarea></td><tr>
<tr>
<td colspan=2 align=center>
<input type=hidden name=load value=support>
<input type=hidden name=type value=module>
<input type=hidden name=create value=on>
<input name=addnow type=submit value="Add Note" class=smallbutton>
</td>
</table>
</form>
END;

} else permission_error();

?>
