<p>
<fieldset>
<legend><b>Support</b></legend>
<table>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Description: </td><td><input type=text name=s1 size=32>
<input type=hidden name=id value=8> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td></table>
</fieldset>



