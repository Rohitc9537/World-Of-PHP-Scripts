<?php   
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$id = $base->input['id'];
$pending = $base->input['pending'];
$completed = $base->input['completed'];

if ($pending)
{
        // mark the customer_history id as pending
	$query = "UPDATE customer_history SET status = \"pending\" WHERE id = $id";
	$result = $DB->Execute($query) or die ("Query Failed");
	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=support&type=module&edit=on\";</script>";			
}
else if ($completed)
{
        // make the customer_history id as completed
        $query = "UPDATE customer_history SET status = \"completed\" WHERE id = $id";
	$result = $DB->Execute($query) or die ("Query Failed");
        print "<script language=\"JavaScript\">window.location.href = \"index.php?load=support&type=module&edit=on\";</script>";	
}
else
{
	echo '<table cellspacing=1 cellpadding=5 border=0 width=720>';

	// find notes for groups that this user belongs to

	print "<tr><td bgcolor=\"#ffffff\" width=100% colspan=6>
		<b>Notes For Groups $user Belongs To</b></td>";
	echo '<tr><td bgcolor="#ccccdd" width=100><b>Date Time</b></td>
                <td bgcolor="#ccccdd" width=80><b>From</b></td>
                <td bgcolor="#ccccdd" width=80><b>Account</b></td>
                <td bgcolor="#ccccdd" width=70><b>Status</b></td>
                <td bgcolor="#ccccdd" width=320><b>Description</b></td>
		<td bgcolor="#ccccdd">Pending</td>
		<td bgcolor="#ccccdd">Finished</td>';

	$query = "SELECT * FROM groups WHERE groupmember = '$user' ";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	while ($myresult = $result->FetchRow())
	{
		$groupname = $myresult['groupname'];
		$query = "SELECT * FROM customer_history WHERE notify = '$groupname' AND status IN ('not done','pending') ORDER BY creation_date DESC";
	        $gpresult = $DB->Execute($query) or die ("Query Failed");


	        while ($groupresult = $result->FetchRow())
        	{
			$id = $groupresult['id'];
			$creation_date = $groupresult['creation_date'];
                	$created_by = $groupresult['created_by'];
			$accountnum = $groupresult['account_number'];
                	$status = $groupresult['status'];
                	$description = $groupresult['description'];
        	
        		if ($status == "not done"){ print "<tr onmouseover='h(this);' onmouseout='dehnew(this);' bgcolor=\"#ddeeff\">"; }
		        else { print "<tr  onmouseover='h(this);' onmouseout='deh(this);' bgcolor=\"#ddddee\">"; }
        	        print "<td>$creation_date</td>";
       		        print "<td>$created_by</td>";
			print "<td><a href=\"viewaccount.php?acnum=$accountnum\">$accountnum</a></td>";
        	        print "<td>$status</td>";
        	        print "<td>$description</td>";
        	        print "<td><a href=\"index.php?load=support&type=module&edit=on&pending=on&id=$id\">
				Pending</a></td>"; 
			print "<td><a href=\"index.php?load=support&type=module&edit=on&completed=on&id=$id\">
				Finished</a></td>";
		}
	}


	// find notes for that user

	print "<tr><td bgcolor=\"#ffffff\" width=100% colspan=6><b>Notes For User $user</td>";
	echo '<tr><td bgcolor="#ccccdd" width=120><b>Date Time</b></td>
                <td bgcolor="#ccccdd" width=80><b>From</b></td>
                <td bgcolor="#ccccdd" width=80><b>Account</b></td>
                <td bgcolor="#ccccdd" width=70><b>Status</b></td>
                <td bgcolor="#ccccdd" width=320><b>Description</b></td>
		<td bgcolor="#ccccdd">Pending</td>
		<td bgcolor="#ccccdd">Finished</td>';

        $query = "SELECT * FROM customer_history WHERE notify = '$user' AND status IN ('not done','pending') ORDER BY creation_date DESC";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	while ($myresult = $result->FetchRow())
        {
		$id = $myresult['id'];
                $creation_date = $myresult['creation_date'];
                $created_by = $myresult['created_by'];
                $notify = $myresult['notify'];
                $status = $myresult['status'];
                $description = $myresult['description'];

                if ($status == "not done"){ print "<tr onmouseover='h(this);' onmouseout='dehnew(this);' bgcolor=\"#ddddff\">"; }
                else { print "<tr onmouseover='h(this);' onmouseout='deh(this);' bgcolor=\"#ddddee\">"; }
                print "<td>$creation_date</td>";
                print "<td>$created_by</td>";
		print "<td><a href=\"viewaccount.php?acnum=$accountnum\">$accountnum</a></td>";
                print "<td>$status</td>";
                print "<td>$description</td>";
                print "<td><a href=\"index.php?load=support&type=module&edit=on&pending=on&id=$id\">
			Pending</a></td>"; 
		print "<td><a href=\"index.php?load=support&type=module&edit=on&completed=on&id=$id\">
			Finished</a></td>";
	}

        echo '</table>';	

}
?>
