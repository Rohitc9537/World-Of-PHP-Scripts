<p>
<fieldset>
<legend><b>Billing</b></legend>
<table>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Billing ID: </td><td><input type=text name=s1>
<input type=hidden name=id value=5> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr><td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Billing Company: </td><td><input type=text name=s1>
<input type=hidden name=id value=6> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr><td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Payment Due Date: </td><td><input type=text name=s1>
<input type=hidden name=id value=7> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td></table>
</fieldset>
