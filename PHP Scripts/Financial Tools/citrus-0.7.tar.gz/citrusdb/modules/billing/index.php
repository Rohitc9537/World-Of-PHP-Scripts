<?php   
// Copyright (C) 2003-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//Includes
require_once('include/permissions.inc.php');

// GET Variables
$save = $base->input['save'];
$resetaddr = $base->input['resetaddr'];

if ($edit)
{
    if ($pallow_modify)
    {
       include('edit.php');
    }  else permission_error();
}
else if ($create)
{
    if ($pallow_create)
    {
       include('create.php');
    } else permission_error();
}
else if ($delete)
{
    if ($pallow_remove)
    {
       include('delete.php');
    } else permission_error();
}
else if ($resetaddr)
{
    if ($pallow_modify)
    {
       include('resetaddr.php');
    } else permission_error();
}


else if ($pallow_view)
{
// get the billing id
$query = "SELECT * FROM customer WHERE account_number = $account_number";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Billing ID Query Failed");
$myresult = $result->fields;	
$default_billing_id = $myresult['default_billing_id'];

// get the billing record for that default_billing_id
$query = "SELECT b.id b_id, b.name b_name, b.company b_company, b.street b_street, 
b.city b_city, b.state b_state, b.zip b_zip, b.phone b_phone, b.fax b_fax, 
b.contact_email b_email, b.creditcard_number b_ccnum, b.creditcard_expire b_ccexp, 
b.billing_status b_status, b.billing_type b_type, b.next_billing_date b_next_billing_date, 
b.prev_billing_date b_prev_billing_date, b.from_date b_from_date,
b.to_date b_to_date, b.payment_due_date b_payment_due_date, b.notes b_notes, 
t.id t_id, t.name t_name FROM billing b LEFT JOIN billing_types t 
ON b.billing_type = t.id WHERE b.id = '$default_billing_id'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Billing Record Query Failed");
while ($myresult = $result->FetchRow())
{
	$billing_id = $myresult['b_id'];
	$name = $myresult['b_name'];
	$company = $myresult['b_company'];
	$street = $myresult['b_street'];
	$city = $myresult['b_city'];
	$state = $myresult['b_state'];
	$zip = $myresult['b_zip'];
	$phone = $myresult['b_phone'];
	$fax = $myresult['b_fax'];
	$contact_email = $myresult['b_email'];
	$billing_type = $myresult['t_name'];
	$creditcard_number = $myresult['b_ccnum'];
	$creditcard_expire = $myresult['b_ccexp'];
	$billing_status = $myresult['b_status'];
	$next_billing_date = $myresult['b_next_billing_date'];
	$prev_billing_date = $myresult['b_prev_billing_date'];
	$from_date = $myresult['b_from_date'];
	$to_date = $myresult['b_to_date'];
	$payment_due_date = $myresult['b_payment_due_date'];
	$notes = $myresult['b_notes'];
}

// print the default billing information
print <<<END
<a href=index.php?load=billing&type=module&edit=on&billing_id=$billing_id>[ Edit Default Billing ]</a>
<a href=index.php?load=billing&type=module&resetaddr=on&account_number=$account_number>[ Reset Address To Customer ]</a>

<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=360>		
	<table cellpadding=5 border=0 cellspacing=1 width=360>
	<td bgcolor="#ccccdd" width=180><b>ID</b></td><td bgcolor="#ddddee" width=180>$billing_id</td><tr>
	<td bgcolor="#ccccdd"><b>Name</b></td><td bgcolor="#ddddee">$name</td><tr>
	<td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee">$company</td><tr>
	<td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee">$street</td><tr>
	<td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee">$city</td><tr>
	<td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee">$state</td><tr>
	<td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee">$zip</td><tr>
	<td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee">$phone</td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee">$fax</td><tr>
	</table>
</td>
<td valign=top width=360>		
	<table cellpadding=5 border=0 cellspacing=1 width=360>
	<td bgcolor="#ccccdd" width=180><b>Billing Type</b></td><td bgcolor="#ddddee" width=180>$billing_type</td><tr>
	<td bgcolor="#ccccdd"><b>Credit Card Number</b></td><td bgcolor="#ddddee">$creditcard_number</td><tr>
	<td bgcolor="#ccccdd"><b>Credit Card Expire</b></td><td bgcolor="#ddddee">$creditcard_expire</td><tr>
	<td bgcolor="#ccccdd"><b>Billing Status</b></td><td bgcolor="#ddddee">$billing_status</td><tr>
	<td bgcolor="#ccccdd"><b>Next Billing Date</b></td><td bgcolor="#ddddee">$next_billing_date</td><tr>
	<td bgcolor="#ccccdd"><b>From Date</b></td><td bgcolor="#ddddee">$from_date</td><tr>
	<td bgcolor="#ccccdd"><b>To Date</b></td><td bgcolor="#ddddee">$to_date</td><tr>
	<td bgcolor="#ccccdd"><b>Payment Due Date</b></td><td bgcolor="#ddddee">$payment_due_date</td><tr>
	<td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee">$contact_email</td><tr>
	<td bgcolor="#ccccdd"><b>Notes</b></td><td bgcolor="#ddddee">$notes</td>
	</table>
</td>
</table>
<p>
<b>Alternate Billing Types:</b> [ <a href="index.php?load=billing&type=module&create=on">Add Alternate Billing</a> ]<br>
END;

// print a list of alternate billing id's if any
$query = "SELECT b.id b_id, t.name t_name FROM billing b LEFT JOIN billing_types t ON b.billing_type = t.id WHERE b.id != $default_billing_id AND b.account_number = $account_number";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Alternate BIlling Types Query Failed");

echo '<table width=720><tr bgcolor="#ddddee">';
while ($myresult = $result->FetchRow())
{
        $billing_id = $myresult['b_id'];
        $billing_type = $myresult['t_name'];

	print "<td><a href=\"index.php?load=billing&type=module&edit=on&billing_id=$billing_id\">$billing_id</a></td><td>$billing_type</td><tr bgcolor=\"#ddddee\">";

}

echo '</table>';

} else permission_error();
?>
