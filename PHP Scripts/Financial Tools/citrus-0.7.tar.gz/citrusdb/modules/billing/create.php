<SCRIPT LANGUAGE="JavaScript" SRC="include/CalendarPopup.js"></SCRIPT>
	<SCRIPT LANGUAGE="JavaScript">
	var cal = new CalendarPopup();
	</SCRIPT>
<?php   
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$billing_id = $base->input['billing_id'];
$name = $base->input['name'];
$company = $base->input['company'];
$street = $base->input['street'];
$city = $base->input['city'];
$state = $base->input['state'];
$zip = $base->input['zip'];
$phone = $base->input['phone'];
$fax = $base->input['fax'];
$billing_type = $base->input['billing_type'];
$creditcard_number = $base->input['creditcard_number'];
$creditcard_expire = $base->input['creditcard_expire'];
$billing_status = $base->input['billing_status'];
$next_billing_date = $base->input['next_billing_date'];
$from_date = $base->input['from_date'];
$payment_due_date = $base->input['payment_due_date'];
$contact_email = $base->input['contact_email'];
$addnow = $base->input['addnow'];

if ($addnow) // add the services to the billing table
{
	// save billing information
        $query = "INSERT into billing
        SET name = '$name',
        company = '$company',
        street = '$street',
        city = '$city',
        state = '$state',
        zip = '$zip',
        phone = '$phone',
        fax = '$fax',
	account_number = '$account_number',
	billing_type = '$billing_type',
        creditcard_number = '$creditcard_number',
        creditcard_expire = '$creditcard_expire',
        billing_status = '$billing_status',
        next_billing_date = '$next_billing_date',
        prev_billing_date = '$prev_billing_date',
        from_date = '$from_date',
        to_date = '$to_date',
	payment_due_date = '$payment_due_date',
	contact_email = '$contact_email'";
	$result = $DB->Execute($query) or die ("Billing Insert Failed");
        print "<h3>Changes Saved<h3>";
        //print "<script language=\"JavaScript\">window.location.href = \"index.php?load=billing&type=module\";</script>";
}
else // list the service options after they clicked on the add button.
{
print <<<END
<a href="index.php?load=billing&type=module">[ Undo Changes ]</a>

<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=360>		
<form style="margin-bottom:0;" action="index.php" name="form1">
	<table cellpadding=5 border=0 cellspacing=1 width=360>
	<td bgcolor="#ccccdd" width=180><b>Name</b></td><td bgcolor="#ddddee" width=180><input name="name" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee"><input name="company" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee"><input name="street" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee"><input name="city" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee"><input name="state" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee"><input name="zip" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee"><input name="phone" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee"><input name="fax" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee"><input name="contact_email" type=text></td><tr>
	</table>
</td>
<td valign=top width=360>
	<table cellpadding=5 border=0 cellspacing=1 width=360>
        <td width=180 bgcolor="#ccccdd"><b>Billing Type</b></td><td width=180 bgcolor="#ffbbbb">

END;

        print "<select name=\"billing_type\">\n";
        $query = "SELECT * FROM billing_types ORDER BY sortorder";
	$result = $DB->Execute($query) or die ("Billing Types Query Failed");
	while ($myresult = $result->FetchRow())
        {
		$bt_id = $myresult['id'];
                $bt_name = $myresult['name'];
                if ($billing_type == $bt_id)
                {
                        print "<option selected value=$bt_id>$bt_name</option>\n";
                }
                else
                {
                        print "<option value=$bt_id>$bt_name</option>\n";
                }
        }
        
        print "</select>\n";

print <<<END
	</td><tr>
	<td bgcolor="#ccccdd" width=180><b>Credit Card Number</b></td><td bgcolor="#ddddee" width=180><input name="creditcard_number" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Credit Card Expire</b></td><td bgcolor="#ddddee"><input name="creditcard_expire" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Billing Status</b></td><td bgcolor="#ddddee"><input name="billing_status" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Disable Billing</b></td><td bgcolor="#ddddee"><input name="disable_billing" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Next Billing Date</b></td>
	<td bgcolor="#ddddee"><input name="next_billing_date" type=text size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].next_billing_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	<td bgcolor="#ccccdd"><b>From Date</b></td>
	<td bgcolor="#ddddee"><input name="from_date" type=text size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].from_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	<td bgcolor="#ccccdd"><b>Prev Billing Date</b></td>
	<td bgcolor="#ddddee"><input name="prev_billing_date" type=text size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].prev_billing_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	
	</table>
</td>
<tr>
<td colspan=2 align=center>
<input type=hidden name=load value=billing>
<input type=hidden name=type value=module>
<input type=hidden name=create value=on>
<input type=hidden name=addnow value=on>
<input name=addnow type=submit value="Add Billing" class=smallbutton>
</td>
</table>
</form>
END;

}

?>
