<SCRIPT LANGUAGE="JavaScript" SRC="include/CalendarPopup.js"></SCRIPT>
	<SCRIPT LANGUAGE="JavaScript">
	var cal = new CalendarPopup();
	</SCRIPT>
<?php   
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$billing_id = $base->input['billing_id'];
$name = $base->input['name'];
$company = $base->input['company'];
$street = $base->input['street'];
$city = $base->input['city'];
$state = $base->input['state'];
$zip = $base->input['zip'];
$phone = $base->input['phone'];
$fax = $base->input['fax'];
$billing_type = $base->input['billing_type'];
$creditcard_number = $base->input['creditcard_number'];
$creditcard_expire = $base->input['creditcard_expire'];
$billing_status = $base->input['billing_status'];
$next_billing_date = $base->input['next_billing_date'];
$from_date = $base->input['from_date'];
$payment_due_date = $base->input['payment_due_date'];
$contact_email = $base->input['contact_email'];
$notes = $base->input['notes'];

if ($save) {
	// save billing information
      $query = "UPDATE billing 
	SET name = '$name',
	company = '$company',
	street = '$street',
	city = '$city',
	state = '$state',
	zip = '$zip',
	phone = '$phone',
	fax = '$fax',
	billing_type = '$billing_type',
	creditcard_number = '$creditcard_number',
	creditcard_expire = '$creditcard_expire',
	billing_status = '$billing_status',
	next_billing_date = '$next_billing_date',
	from_date = '$from_date',
	payment_due_date = '$payment_due_date',
	notes = '$notes',
	contact_email = '$contact_email' WHERE id = $billing_id";
	$result = $DB->Execute($query) or die ("Billing Edit Query Failed");
	
	// set the to_date automatically based on the from_date and the length of time indicated by the billing_type
	// figure out the billing frequency
	$query = "SELECT * FROM billing_types WHERE id = $billing_type";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing Types Query Failed");
	$myresult = $result->fields;
	$frequency = $myresult['frequency'];
	// add the number of frequency months to the from date to get what the to_date should be set to
	$query = "UPDATE billing
                          SET to_date = DATE_ADD('$from_date', INTERVAL '$frequency' MONTH)
                          WHERE id = '$billing_id'";
        $updateresult = $DB->Execute($query) or die ("Update From Date Query Failed");


	print "<h3>Changes Saved<h3>";
        print "<script language=\"JavaScript\">window.location.href = \"index.php?load=billing&type=module\";</script>";
}
else
{	
	$query = "SELECT * FROM billing WHERE id = $billing_id";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing Query Failed");
	$myresult = $result->fields;	

        // Put values into variablies and Print HTML results

	$id = $myresult['id'];
	$name = $myresult['name'];
	$company = $myresult['company'];        
	$street = $myresult['street'];
	$city = $myresult['city'];
	$state = $myresult['state'];
	$zip = $myresult['zip'];
	$country = $myresult['country'];
        $phone = $myresult['phone'];
        $fax = $myresult['fax'];
	$billing_type = $myresult['billing_type'];
	$creditcard_number = $myresult['creditcard_number'];
	$creditcard_expire = $myresult['creditcard_expire'];
        $billing_status = $myresult['billing_status'];
        $next_billing_date = $myresult['next_billing_date'];
        $from_date = $myresult['from_date'];
        $to_date = $myresult['to_date'];
	$payment_due_date = $myresult['payment_due_date'];
        $contact_email = $myresult['contact_email'];
        $notes = $myresult['notes'];

print <<<END
<a href="index.php?load=billing&type=module">[ Undo Changes ]</a>
<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=360>
<form action="index.php?load=billing&type=module&edit=on&save=on" name="form1">
	<table cellpadding=5 cellspacing=1 border=0 width=360>
	<td bgcolor="#ccccdd" width=180><b>ID</b></td><td width=180 bgcolor="#ddddee">$id</td><tr>
	<td bgcolor="#ccccdd"><b>Name</b></td><td bgcolor="#ddddee"><input name="name" type=text value="$name"></td><tr>
	<td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee"><input name="company" type=text value="$company"></td><tr>
	<td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee"><input name="street" type=text value="$street"></td><tr>
	<td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee"><input name="city" type=text value="$city"></td><tr>
	<td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee"><input name="state" type=text value="$state" size=2></td><tr>
	<td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee"><input name="zip" size=5 type=text value="$zip"></td><tr>
	<td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee"><input name="phone" type=text value="$phone"></td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee"><input name="fax" type=text value="$fax"></td><tr>
	</table>
</td>
<td valign=top width=360>
	<table cellpadding=5 cellspacing=1 width=360>
	<td width=180 bgcolor="#ccccdd"><b>Billing Type</b></td><td width=180 bgcolor="#ffbbbb">

END;

	print "<select name=\"billing_type\">\n";
        $query = "SELECT * FROM billing_types ORDER BY sortorder";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing Types Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$bt_id = $myresult['id'];
		$bt_name = $myresult['name'];
		if ($billing_type == $bt_id)
		{
			print "<option selected value=$bt_id>$bt_name</option>\n";
		}
		else 
		{ 
			print "<option value=$bt_id>$bt_name</option>\n"; 
		}
	}

	print "</select>\n";

print <<<END
	</td><tr>
	<td bgcolor="#ccccdd"><b>Credit Card Number</b></td><td bgcolor="#ddddee"><input name="creditcard_number" type=text value="$creditcard_number"></td><tr>
	<td bgcolor="#ccccdd"><b>Credit Card Expire</b></td><td bgcolor="#ddddee"><input name="creditcard_expire" type=text value="$creditcard_expire"></td><tr>
	<td bgcolor="#ccccdd"><b>Billing Status</b></td><td bgcolor="#ddddee">$billing_status</td><tr>
	<td bgcolor="#ccccdd"><b>Next Billing Date</b></td><td bgcolor="#ddddee">
	<input name="next_billing_date" type=text value="$next_billing_date" size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].next_billing_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	<td bgcolor="#ccccdd"><b>From Date</b></td><td bgcolor="#ddddee">
	<input name="from_date" type=text value="$from_date" size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].from_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	<td bgcolor="#ccccdd"><b>To Date</b></td><td bgcolor="#ddddee">$to_date</td><tr>
	<td bgcolor="#ccccdd"><b>Payment Due Date</b></td><td bgcolor="#ddddee">
	<input name="payment_due_date" type=text value="$payment_due_date" size=12>
	<A HREF="#"
	onClick="cal.select(document.forms['form1'].payment_due_date,'anchor1','yyyy-MM-dd'); 
	return false;"
	NAME="anchor1" ID="anchor1" style="color:blue">[select]</A>
	</td><tr>
	<td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee"><input name="contact_email" type=text value="$contact_email"></td><tr>
	<td bgcolor="#ccccdd"><b>Notes</b></td><td bgcolor="#ddddee"><input name="notes" type=text value="$notes"></td><tr>
	</table>
</td>
<tr>
<td colspan=2>
<center>
<input name=save type=submit class=smallbutton value="Save Changes">
<input type=hidden name=load value=billing>
<input type=hidden name=type value=module>
<input type=hidden name=edit value=on>
<input type=hidden name=billing_id value=$billing_id>
</center>
</td>
</table>
</form>

END;

}
?>
