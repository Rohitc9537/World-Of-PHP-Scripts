<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

if ($base->input['save']) {

	//
	// GET Variables
	//
	$name = $base->input['name'];
    $company = $base->input['company'];
    $street = $base->input['street'];
    $city = $base->input['city'];
    $state = $base->input['state'];
	$country = $base->input['country'];
    $zip = $base->input['zip'];
    $phone = $base->input['phone'];
	$fax = $base->input['fax'];
	$contact_email = $base->input['contact_email'];
	$source = $base->input['source'];
	
	//
    // make a new customer record
    //
	$query = "INSERT into customer (signup_date, name, company, street, city, state, country, zip, phone, fax, contact_email, source) VALUES (CURRENT_DATE, '$name', '$company', '$street', '$city', '$state', '$country', '$zip', '$phone', '$fax', '$contact_email', '$source')";
	$result = $DB->Execute($query) or die ("Customer Insert Query Failed");
	
	$myinsertid = $DB->Insert_ID();  // is this the upcoming insert, not the previous one?
	$account_number=$myinsertid;
	
	//
	// start the session variables to hold the account number
	//
	session_start();
	$_SESSION['account_number'] = $account_number;
	
	//
	// get the current date and time in the SQL query format
	//
	$mydate = date("Y-m-d");
	$mytime = date("H:i:s");
	
	//
	// check if it's after the dayrollover time and get tomorrow's date if it is
	//
	$query = "SELECT billingdate_rollover_time from general WHERE id = 1";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing date rollover Query Failed");
	$myresult = $result->fields;	
	$rollover_time = $myresult['billingdate_rollover_time'];
	if ($mytime > $rollover_time) {
		$mydate = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));
	}
	
	//
	// check if the date is in the holiday table, move up one day until not matched
	//
	$holiday = true;
	while ($holiday == true)
	{
		$query = "SELECT holiday_date from holiday WHERE holiday_date = '$mydate'";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Holiday date Query Failed");
		$myresult = $result->fields;	
		$myholiday = $myresult['holiday_date'];
		
		if($myholiday == $mydate) {
			// holiday is still true move up one day and test that one
			$mydate = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));
		} else {
		$holiday = false;
		}
		
		echo "holiday $mydate<br>";
	}
	
	//
	// set the next billing date and from date to the date determined from above for the first billing
	//
	$query = "INSERT into billing (account_number,next_billing_date,from_date) VALUES ('$account_number','$mydate','$mydate')";
	$result = $DB->Execute($query) or die ("Customer Billing Date Insert Query Failed");	
	
	//
	// set the default billing ID for the customer record
	//
	$billingid = $DB->Insert_ID();
	$query = "UPDATE customer SET default_billing_id = '$billingid' WHERE account_number = $account_number";
	$result = $DB->Execute($query) or die ("Billing ID Insert Query Failed");
	
	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=customer&type=module\";</script>";
}
else
{
//
// prompt for some standard information to put in the new customer record
//
echo '
<a href="index.php?load=customer&type=module">[ Undo Changes ]</a>
<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=720>
<form action="index.php">
        <table cellpadding=5 cellspacing=1 border=0 width=720>
        <td bgcolor="#ccccdd"><b>Name</b></td><td bgcolor="#ddddee"><input name="name" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee"><input name="company" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee"><input name="street" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee"><input name="city" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee"><input name="state" type=text size=2></td><tr>
	<td bgcolor="#ccccdd"><b>Country</b></td><td bgcolor="#ddddee"><input name="country" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee"><input name="zip" size=5 type=text></td><tr>
        <td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee"><input name="phone" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee"><input name="fax" type=text></td><tr>
        <td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee"><input name="contact_email" type=text></td><tr>
	<td bgcolor="#ccccdd"><b>Source</b></td><td bgcolor="#ddddee"><input name="source" type=text></td><tr>
        </table>
<br />
<center>
<input name=save type=submit class=smallbutton value="Add New Customer">
<input type=hidden name=load value=customer>
<input type=hidden name=type value=module>
<input type=hidden name=create value=on>
<input type=hidden name=save value=on>

</center>
</td>
</table>
</form>
';


}
?>
