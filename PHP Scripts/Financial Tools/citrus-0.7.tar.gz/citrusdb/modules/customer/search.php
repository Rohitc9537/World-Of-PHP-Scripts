<p>
<fieldset>
<legend><b>Customer</b></legend>
<table>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Company Name: </td><td><input type=text name=s1>
<input type=hidden name=id value=2> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr><td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Customer Name: </td><td><input type=text name=s1>
<input type=hidden name=id value=3> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr><td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Phone Number: </td><td><input type=text name=s1>
<input type=hidden name=id value=4> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td></table>
</fieldset>




