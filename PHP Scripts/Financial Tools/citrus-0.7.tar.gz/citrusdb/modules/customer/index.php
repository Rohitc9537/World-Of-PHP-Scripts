<?php
// Copyright (C) 2003-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//Includes
require_once('include/permissions.inc.php');

if ($edit)
{
    if ($pallow_modify)
    {
       include('edit.php');
    }  else permission_error();
}
else if ($create)
{
    if ($pallow_create)
    {
       include('create.php');
    } else permission_error();
}
else if ($delete)
{
    if ($pallow_remove)
    {
       include('delete.php');
    } else permission_error();
}

else if ($pallow_view)
{	
	// get the customer information
        $query = "SELECT * FROM customer WHERE account_number = $account_number";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Customer Query Failed");
	$myresult = $result->fields;	
        // Put values into variablies and Print HTML results

	$signup_date = $myresult['signup_date'];
	$name = $myresult['name'];
	$company = $myresult['company'];        
	$street = $myresult['street'];
	$city = $myresult['city'];
	$state = $myresult['state'];
	$zip = $myresult['zip'];
	$country = $myresult['country'];
        $phone = $myresult['phone'];
        $fax = $myresult['fax'];
        $source = $myresult['source'];
        $contactemail = $myresult['contact_email'];
        $maidenname = $myresult['maiden_name'];
	$tax_exempt_id = $myresult['tax_exempt_id'];
	$default_billing_id = $myresult['default_billing_id'];
	$cancel_date = $myresult['cancel_date'];
	$removal_date = $myresult['removal_date'];
	$account_manager_password = $myresult['account_manager_password'];

	// get their billing status from billing_details, select all accounts for this user that have 
	// a billed amount greater than the paid amount
	$query="SELECT c.account_number c_acctnum, u.account_number u_acctnum, 
	u.billing_id u_bid, d.billing_id d_bid, d.creation_date d_cdate, 
	d.billed_amount d_billed, d.paid_amount d_paid 
	FROM customer c    
        LEFT JOIN user_services u ON c.account_number = u.account_number   
        LEFT JOIN billing_details d ON u.billing_id = d.billing_id   
        WHERE c.account_number = $account_number AND d.billed_amount > d.paid_amount 
	AND CURRENT_DATE > DATE_ADD(creation_date,INTERVAL 30 DAY)";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing Status Query Failed");

        // loop through results and add to total pastdue
	$totalpastdue = 0;
	while ($myresult = $result->FetchRow())
        {	
		$totalpastdue = $totalpastdue + $myresult['d_billed'] - $myresult['d_paid'];
	}

// print the HTML

print <<<END

<a href="index.php?load=customer&type=module&edit=on">[ Edit Customer ]</a>
<a href="index.php?load=customer&type=module&delete=on">[ Cancel Customer ]</a>

<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=360>		
	<table cellpadding=5 cellspacing=1 border=0 width=360>
	<td bgcolor="#ccccdd" width=180><b>Signup Date</b></td><td bgcolor="#ddddee" width=180>$signup_date</td><tr>
	<td bgcolor="#ccccdd"><b>Name</b></td><td bgcolor="#ddddee">$name</td><tr>
	<td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee">$company</td><tr>
	<td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee">$street</td><tr>
	<td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee">$city</td><tr>
	<td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee">$state</td><tr>
	<td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee">$zip</td><tr>
	<td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee">$phone</td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee">$fax</td><tr>
	</table>
</td>
<td valign=top width=360>
	<table cellpadding=5 cellspacing=1 border=0 width=360>

END;

	// show the correct billing status based on $totalpastdue

	if ($totalpastdue > 0)
	{ 
	print "<td bgcolor=\"#ccccdd\" width=180><b>Billing Status</b></td>
	<td bgcolor=\"#ffbbbb\" width=180>Overdue $totalpastdue</td><tr>"; 
	}
	else
	{ 
	print "<td bgcolor=\"#ccccdd\" width=180><b>Billing Status</b></td>
	<td bgcolor=\"#bbffbb\" width=180>OK</td><tr>"; 
	}

print <<<ENDTWO

	<td bgcolor="#ccccdd"><b>Cancel Date</b></td><td bgcolor="#ddddee" class=redbold>$cancel_date</td><tr>
	<td bgcolor="#ccccdd"><b>Removal Date</b></td><td bgcolor="#ddddee" class=redbold>$removal_date</td><tr>
	<td bgcolor="#ccccdd"><b>Source</b></td><td bgcolor="#ddddee">$source</td><tr>
	<td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee">$contactemail</td><tr>
	<td bgcolor="#ccccdd"><b>Secret Word</b></td><td bgcolor="#ddddee">$maidenname</td><tr>
	<td bgcolor="#ccccdd"><b>Tax Exempt ID</b></td><td bgcolor="#ddddee">$tax_exempt_id</td><tr>
	<td bgcolor="#ccccdd"><b>Default Billing ID</b></td><td bgcolor="#ddddee">$default_billing_id</td><tr>
	<td bgcolor="#ccccdd"><b>Country</b></td><td bgcolor="#ddddee">$country</td><tr>
	<td bgcolor="#ccccdd"><b>Acct Mngr Passwd</b></td><td bgcolor="#ddddee">$account_manager_password</td><tr>
	</table>
</td>
</table>
</form>

ENDTWO;

} else permission_error();
?>
