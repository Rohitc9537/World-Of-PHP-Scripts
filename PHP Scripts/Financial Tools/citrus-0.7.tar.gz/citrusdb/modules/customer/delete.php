<?php   
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}


// GET Variables
$userserviceid = $base->input['userserviceid'];
$deletenow = $base->input['deletenow'];

if ($deletenow) {

	// figure out all the services that the customer has and put the removed flag to Y on each one.

	$query = "UPDATE user_services SET removed = 'y' WHERE account_number = '$account_number'";
	$result = $DB->Execute($query) or die ("User Services Update Query Failed");

	
	// set cancel date and removal date of customer record

	$query = "UPDATE customer SET cancel_date = CURRENT_DATE, removal_date = CURRENT_DATE WHERE account_number = '$account_number'";
	$result = $DB->Execute($query) or die ("Customer Update Query Failed");

	

	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=customer&type=module\";</script>";
}
else
{
	print "<br><br>";
	print "<h4>Are you sure you want to cancel customer: $account_number</h4>";
	print "<table cellpadding=15 cellspacing=0 border=0 width=720><td align=right width=360>";

	// if they hit yes, this will sent them into the delete.php file and remove the service

	print "<form style=\"margin-bottom:0;\" action=\"index.php\">";
	print "<input type=hidden name=load value=customer>";
        print "<input type=hidden name=type value=module>";
        print "<input type=hidden name=delete value=on>";
	print "<input name=deletenow type=submit value=\"  Yes  \" class=smallbutton></form></td>";

	// if they hit no, send them back to the service edit screen

	print "<td align=left width=360><form style=\"margin-bottom:0;\" action=\"index.php\">";
	print "<input name=done type=submit value=\"  No  \" class=smallbutton>";
        print "<input type=hidden name=load value=customer>";        
        print "<input type=hidden name=type value=module>";
	print "</form></td></table>";
	print "</blockquote>";
}
?>
