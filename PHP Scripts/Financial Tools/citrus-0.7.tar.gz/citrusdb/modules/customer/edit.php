<?php   
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

if ($base->input['save']) {
	// save customer information

	// GET Variables
	$name = $base->input['name'];
	$company = $base->input['company'];
	$street = $base->input['street'];
	$city = $base->input['city'];
	$state = $base->input['state'];
	$country = $base->input['country'];
	$zip = $base->input['zip'];
	$phone = $base->input['phone'];
	$fax = $base->input['fax'];
	$source = $base->input['source'];
	$contact_email = $base->input['contact_email'];
	$maiden_name = $base->input['maiden_name'];
	$tax_exempt_id = $base->input['tax_exempt_id'];
	$account_manager_password = $base->input['account_manager_password'];

	$account_number = $_SESSION['account_number'];	

	// submit update query
      $query = "UPDATE customer 
	SET name = '$name',
	company = '$company',
	street = '$street',
	city = '$city',
	state = '$state',
	country = '$country',
	zip = '$zip',
	phone = '$phone',
	fax = '$fax',
	source = '$source',
	contact_email = '$contact_email',
	maiden_name = '$maiden_name',
	tax_exempt_id = '$tax_exempt_id', 
	account_manager_password = '$account_manager_password' 
	WHERE account_number = '$account_number'";
	$result = $DB->Execute($query) or die ("Customer Update Query Failed");
	
	print "<h3>Changes Saved<h3>";
	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=customer&type=module\";</script>";
}
else
{

        $query = "SELECT * FROM customer WHERE account_number = $account_number";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Customer Query Failed");
	$myresult = $result->fields;	
        // Put values into variablies and Print HTML results

	$signup_date = $myresult['signup_date'];
	$name = $myresult['name'];
	$company = $myresult['company'];        
	$street = $myresult['street'];
	$city = $myresult['city'];
	$state = $myresult['state'];
	$zip = $myresult['zip'];
	$country = $myresult['country'];
        $phone = $myresult['phone'];
        $fax = $myresult['fax'];
        $source = $myresult['source'];
        $contact_email = $myresult['contact_email'];
        $maiden_name = $myresult['maiden_name'];
	$tax_exempt_id = $myresult['tax_exempt_id'];
	$default_billing_id = $myresult['default_billing_id'];
	$account_manager_password = $myresult['account_manager_password'];

print <<<END
<a href="index.php?load=customer&type=module">[ Undo Changes ]</a>
<table cellpadding=0 border=0 cellspacing=0 width=720>
<td valign=top width=360>
<form action="index.php">
	<table cellpadding=5 cellspacing=1 border=0 width=360>
	<td bgcolor="#ccccdd" width=180><b>Signup Date</b></td><td width=180 bgcolor="#ddddee">$signup_date</td><tr>
	<td bgcolor="#ccccdd"><b>Name</b></td><td bgcolor="#ddddee"><input name="name" type=text value="$name"></td><tr>
	<td bgcolor="#ccccdd"><b>Company</b></td><td bgcolor="#ddddee"><input name="company" type=text value="$company"></td><tr>
	<td bgcolor="#ccccdd"><b>Street</b></td><td bgcolor="#ddddee"><input name="street" type=text value="$street"></td><tr>
	<td bgcolor="#ccccdd"><b>City</b></td><td bgcolor="#ddddee"><input name="city" type=text value="$city"></td><tr>
	<td bgcolor="#ccccdd"><b>State</b></td><td bgcolor="#ddddee"><input name="state" type=text value="$state" size=2></td><tr>
	<td bgcolor="#ccccdd"><b>Zip</b></td><td bgcolor="#ddddee"><input name="zip" size=5 type=text value="$zip"></td><tr>
	<td bgcolor="#ccccdd"><b>Phone</b></td><td bgcolor="#ddddee"><input name="phone" type=text value="$phone"></td><tr>
	<td bgcolor="#ccccdd"><b>Fax</b></td><td bgcolor="#ddddee"><input name="fax" type=text value="$fax"></td><tr>
	</table>
</td>
<td valign=top width=360>
	<table cellpadding=5 cellspacing=1 width=360>
	<td width=180 bgcolor="#ccccdd"><b>Billing Status</b></td><td width=180 bgcolor="#ffbbbb"></td><tr>
	<td width=180 bgcolor="#ccccdd"><b>Cancel Date</b></td><td width=180 bgcolor="#ddddee"></td><tr>
	<td width=180 bgcolor="#ccccdd"><b>Removal Date</b></td><td width=180 bgcolor="#ddddee"></td><tr>
	<td bgcolor="#ccccdd"><b>Source</b></td><td bgcolor="#ddddee"><input name="source" type=text value="$source"></td><tr>
	<td bgcolor="#ccccdd"><b>Contact Email</b></td><td bgcolor="#ddddee"><input name="contact_email" type=text value="$contact_email"></td><tr>
	<td bgcolor="#ccccdd"><b>Secret Word</b></td><td bgcolor="#ddddee"><input name="maiden_name" type=text value="$maiden_name"></td><tr>
	<td bgcolor="#ccccdd"><b>Tax Exempt ID</b></td><td bgcolor="#ddddee"><input name="tax_exempt_id" type=text value="$tax_exempt_id"></td><tr>
	<td bgcolor="#ccccdd"><b>Default Billing ID</b></td><td bgcolor="#ddddee"><input type=hidden name=default_billing_id value="$default_billing_id">$default_billing_id</td><tr>
	<td bgcolor="#ccccdd"><b>Country</b></td><td bgcolor="#ddddee"><input name="country" type=text value="$country"></td><tr>
	<td bgcolor="#ccccdd"><b>Acct Mngr Passwd</b></td><td bgcolor="#ddddee"><input name="account_manager_password" type=text value="$account_manager_password"></td><tr>
	</table>
</td>
<tr>
<td colspan=2>
<center>
<input name=save type=submit class=smallbutton value="Save Changes">
<input type=hidden name=load value=customer>
<input type=hidden name=type value=module>
<input type=hidden name=edit value=on>

</center>
</td>
</table>
</form>

END;

}
?>
