<?php   
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}


print <<<END
<h3>Service History</h3>
<a href="index.php?load=services&type=module">[ Back ]</a>
<table cellpadding=0 border=0 cellspacing=0 width=720><td valign=top>		
	<table cellpadding=5 cellspacing=1 border=0 width=720>
	<td bgcolor="#ccccdd"><b>Service Name</b></td>
	<td bgcolor="#ccccdd"><b>Details</b></td>
	<td bgcolor="#ccccdd"><b>Creation</b></td>
	<td bgcolor="#ccccdd"><b>Price</b></td>
	<td bgcolor="#ccccdd"><b>Freq</b></td>
	<td bgcolor="#ccccdd"><b>BillingID</b></td>
	<td bgcolor="#ccccdd"><b>Removed</b></td><td></td>
END;

// select all the user information in user_services and connect it with the 
// master_services description and cost

$query = "SELECT user.*, master.service_description, master.options_table, 
	master.pricerate, master.frequency 
	FROM user_services AS user, master_services AS master 
	WHERE user.master_service_id = master.id 
	AND user.account_number = '$account_number' 
	ORDER BY master.service_description, user.id";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

// Print HTML table of user_services
while ($myresult = $result->FetchRow())
{
	// select the options_table to get data for the details column
	
	$options_table = $myresult['options_table'];
	$id = $myresult['id'];
	if ($options_table <> '') {
		// get the data from the options table and put into variables
		$query = "SELECT * FROM $options_table WHERE user_services = '$id'";
		$DB->SetFetchMode(ADODB_FETCH_NUM);
		$optionsresult = $DB->Execute($query) or die ("Options table Query Failed");
		$myoptions = $optionsresult->fields;
		$optiondetails = $myoptions[2];
	} else {
		$optiondetails = '';	
	}
	$master_service_id = $myresult['master_service_id'];
	$start_datetime = $myresult['start_datetime'];
	$billing_id = $myresult['billing_id'];
	$pricerate = $myresult['pricerate'];
	$usage_multiple = $myresult['usage_multiple'];
	$frequency = $myresult['frequency'];
	$removed = $myresult['removed'];
	$service_description = $myresult['service_description']; // from the LEFT JOINED master_services table

	// get the data from the billing tables to compare service and billing frequency
	$query = "SELECT * FROM billing b LEFT JOIN billing_types t ON b.billing_type = t.id WHERE b.id = '$billing_id'";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$freqoutput = $DB->Execute($query) or die ("Billing Type Query Failed");
	$freqresult = $freqoutput->fields;
	$billing_freq = $freqresult['frequency'];

	// multiply the pricerate and the usage_multiple to get the price to show
	$totalprice = $pricerate * $usage_multiple;

	print "\n<tr onMouseOver='h(this);' onmouseout='deh(this);' onmousedown='window.location.href=\"index.php?load=services&type=module&edit=on&userserviceid=$id&servicedescription=$service_description&optionstable=$options_table&editbutton=Edit\";' bgcolor=\"#ddddee\">";
	print "\n<td>$service_description</td>
	<td>$optiondetails</td>
	<td>$start_datetime</td>
	<td>$totalprice</td>
	<td>$frequency</td>
	<td>$billing_id</td>
	<td>$removed</td><td>
	</td></tr>";
} 
print <<<END

	</table>

END;

?>

