<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information   

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$userserviceid = $base->input['userserviceid'];
$servicedescription = $base->input['servicedescription'];
$optionstable = $base->input['optionstable'];
$editbutton = $base->input['editbutton'];
$save = $base->input['save'];
$fieldlist = $base->input['fieldlist'];
$usage = $base->input['usage'];
$usage_multiple = $base->input['usage_multiple'];
$billing = $base->input['billing'];
$billing_id = $base->input['billing_id'];

if ($save) 
{
	$fieldlist = substr($fieldlist, 1); 
	// loop through post_vars associative/hash to get field values
	$array_fieldlist = explode(",",$fieldlist);
	foreach ($base->input as $mykey => $myvalue) {
		foreach ($array_fieldlist as $myfield) {
			if ($myfield == $mykey) {
				$fieldvalues .= ', ' . $myfield . ' = \'' . $myvalue . '\'';
			}
		}
	}
	$fieldvalues = substr($fieldvalues, 1);
	$query = "UPDATE $optionstable SET $fieldvalues WHERE user_services = $userserviceid";
	$result = $DB->Execute($query) or die ("Query Failed");
	
	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=services&type=module\";</script>";
}
else if ($usage) // update the database if they changed the usage_multiple
{
        $query = "UPDATE user_services SET usage_multiple = $usage_multiple WHERE id = $userserviceid";
	$result = $DB->Execute($query) or die ("Query Failed");
        print "<script language=\"JavaScript\">window.location.href = \"index.php?load=services&type=module\";</script>";
}
else if ($billing) // update the database if they changed the billing ID
{
	$query = "UPDATE user_services SET billing_id = $billing_id WHERE id = $userserviceid";
	$result = $DB->Execute($query) or die ("Query Failed");
        print "<script language=\"JavaScript\">window.location.href = \"index.php?load=services&type=module\";</script>";
}
else if ($delete) // prompt them to ask if they are sure they want to delete the service
{
	print "<br><br>";
	print "<h4>Are you sure you want to delete: $servicedescription</h4>";
	print "<table cellpadding=15 cellspacing=0 border=0 width=720><td align=right width=360>";

	// if they hit yes, this will sent them into the delete.php file and remove the service

	print "<form style=\"margin-bottom:0;\" action=\"index.php\"><input type=hidden name=optionstable value=$optionstable>";
	print "<input type=hidden name=userserviceid value=$userserviceid>";
	print "<input type=hidden name=load value=services>";
        print "<input type=hidden name=type value=module>";
        print "<input type=hidden name=delete value=on>";
	print "<input name=deletenow type=submit value=\"  Yes  \" class=smallbutton></form></td>";

	// if they hit no, send them back to the service edit screen

	print "<td align=left width=360><form style=\"margin-bottom:0;\" action=\"index.php\">";
	print "<input name=done type=submit value=\"  No  \" class=smallbutton>";
        print "<input type=hidden name=load value=services>";        
        print "<input type=hidden name=type value=module>";
	print "</form></td></table>";
	print "</blockquote>";

}
else if ($editbutton) // list the service options after they clicked on the add button.
{
print "<a href=\"index.php?load=services&type=module\">[ Undo Changes ]</a>";

	// check for optionstable, skip this step if there isn't one
	if ($optionstable <> '')
        {
	$query = "SELECT * FROM $optionstable WHERE user_services = '$userserviceid'";
        $DB->SetFetchMode(ADODB_FETCH_NUM);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
	}
	
	// edit the things in the options table
	print "<h4>Edit: $servicedescription </h4><form action=\"index.php\"><table width=720 cellpadding=5 cellspacing=1 border=0>";
	print "<input type=hidden name=load value=services>";
        print "<input type=hidden name=type value=module>";
        print "<input type=hidden name=edit value=on>";
	print "<input type=hidden name=servicedescription value=\"$servicedescription\"><input type=hidden name=optionstable value=$optionstable><input type=hidden name=userserviceid value=$userserviceid>";

	// check for optionstable, skip this step if there isn't one	
        if ($optionstable <> '') {
	// list out the fields in the options table for that service
	$fields = $DB->MetaColumns($optionstable);
	$i = 0;
	foreach($fields as $v) {
		//echo "Name: $v->name ";
		//echo "Type: $v->type <br>";
        
                $fieldname = $v->name;
                $fieldflags = $v->type;
		if ($fieldname <> "id" AND $fieldname <> "user_services") {
			if ($fieldflags == "enum") {
                        echo "<td bgcolor=\"ccccdd\"width=180><b>$fieldname</b></td>
			<td bgcolor=\"#ddddee\">";

                        # print all the items listed in the enum
                        enum_select($optionstable, $fieldname, $myresult[$i]);

                        echo "</td><tr>\n";

                	} else {
                        echo "<td bgcolor=\"ccccdd\"width=180><b>$fieldname</b></td>
			<td bgcolor=\"#ddddee\"><input type=text name=\"$fieldname\" 
			value=\"$myresult[$i]\"></td><tr>\n";
                	}
                	$fieldlist .= ',' . $fieldname;
		}
		$i++;
        }
	print "<input type=hidden name=fieldlist value=$fieldlist>";
	print "<td></td><td><input name=save type=submit value=\"Save Changes\" class=smallbutton>&nbsp;&nbsp;&nbsp;<input name=delete type=submit value=\"Delete Service\" class=smallbutton></td></table></form></blockquote>";
	}
	else {
	print "<td></td><td><input name=delete type=submit value=\"Delete Service\" class=smallbutton></td></table></form></blockquote>";
	}

        // change the usage_multiple for services charged by usage like refunds, disk space, bandwidth, etc.

        print "<h4>Usage</h4><form action=\"index.php\"><table width=720 cellpadding=5 cellspacing=1 border=0>";
        print "<input type=hidden name=load value=services>";
        print "<input type=hidden name=type value=module>";
        print "<input type=hidden name=edit value=on>";
        print "<input type=hidden name=servicedescription value=\"$servicedescription\">";
        print "<input type=hidden name=optionstable value=$optionstable>";
        print "<input type=hidden name=userserviceid value=$userserviceid>";
        echo "<td bgcolor=\"ccccdd\"width=180><b>Usage Multiple</b></td><td bgcolor=\"#ddddee\">";

        $query = "SELECT * FROM user_services WHERE id = '$userserviceid'";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $usage_multiple = $myresult['usage_multiple'];
        $account_number = $myresult['account_number'];

        // print the usage multiple for this service
	// all services will start with the number one in the usage_multiple

        print "<input type=text name=usage_multiple value=$usage_multiple>";

	echo "</td><tr>\n";

        print "<td></td><td><input name=usage type=submit value=\"Change Usage\" class=smallbutton></td></table></form>";


	// change the billing ID
	
	print "<h4>Billing</h4><form action=\"index.php\"><table width=720 cellpadding=5 cellspacing=1 border=0>";
        print "<input type=hidden name=load value=services>";
        print "<input type=hidden name=type value=module>";
        print "<input type=hidden name=edit value=on>";
        print "<input type=hidden name=servicedescription value=\"$servicedescription\">";
	print "<input type=hidden name=optionstable value=$optionstable>";
	print "<input type=hidden name=userserviceid value=$userserviceid>";
	echo "<td bgcolor=\"ccccdd\"width=180><b>Billing ID</b></td><td bgcolor=\"#ddddee\">";

	$query = "SELECT * FROM user_services WHERE id = '$userserviceid'";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
	$billing_id = $myresult['billing_id'];
	$account_number = $myresult['account_number'];

	// print a list of billing id's that have the account number associated with them
        
	print "<select name=billing_id><option selected value=$billing_id>$billing_id</option>";
	
	$query = "SELECT * FROM billing WHERE account_number = '$account_number'";
        $DB->SetFetchMode(ADODB_FETCH_NUM);
	$result = $DB->Execute($query) or die ("Query Failed");
	while ($myresult = $result->FetchRow())	
        {
		$billing_id = $myresult['id'];
		print "<option value=$billing_id>$billing_id</option>";
        }

	echo "</select></td><tr>\n";
	
	print "<td></td><td><input name=billing type=submit value=\"Change Billing\" class=smallbutton></td></table></form>";

}
?>
