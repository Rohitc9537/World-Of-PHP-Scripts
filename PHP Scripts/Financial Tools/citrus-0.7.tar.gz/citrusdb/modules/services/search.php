<p>
<fieldset>
<legend><b>Services</b></legend>
<table>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Example Username: </td><td><input type=text name=s1 size=32>
<input type=hidden name=id value=9> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Example Password: </td><td><input type=text name=s1 size=32>
<input type=hidden name=id value=10> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td><tr>
<td valign=top>
<form ACTION="index.php?load=dosearch&type=fs" METHOD="POST">
Example Equipment: </td><td><input type=text name=s1 size=32>
<input type=hidden name=id value=11> <!-- the id of this search in the searches table -->
<input type=submit name=submit value="Search" class=smallbutton>
</form>
</td></table>
</fieldset>


