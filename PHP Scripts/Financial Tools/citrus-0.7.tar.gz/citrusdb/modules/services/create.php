<?php   
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$addnow = $base->input['addnow'];
$addbutton = $base->input['addbutton'];
$serviceid = $base->input['serviceid'];
$options_table_name = $base->input['options_table_name'];
$fieldlist = $base->input['fieldlist'];

if ($addnow) // add the services to the user_services table and the options table
{
	$fieldlist = substr($fieldlist, 1); 

	// loop through post_vars associative/hash to get field values
	$array_fieldlist = explode(",",$fieldlist);
	
	foreach ($base->input as $mykey => $myvalue)
	{
		foreach ($array_fieldlist as $myfield)
		{
			// print "$mykey<br>";
			if ($myfield == $mykey)
			{
				$fieldvalues .= ',\'' . $myvalue . '\'';
				print "$fieldvalues<br>";
			}
		}
	}

	$fieldvalues = substr($fieldvalues, 1);

	// make the creation date YYYY-MM-DD HOUR:MIN:SEC
	$mydate = date("Y-m-d H:i:s");

	// get the default billing id
	$query = "SELECT * FROM customer WHERE account_number = $account_number";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;	
        $default_billing_id = $myresult['default_billing_id'];

	// insert the new service into the user_services table
	$query = "INSERT into user_services (account_number, master_service_id, billing_id, start_datetime, salesperson) VALUES ('$account_number', '$serviceid', '$default_billing_id', '$mydate', '$user')";
	$result = $DB->Execute($query) or die ("Query Failed");

	// use the mysql_insert_id command to get the ID of the row the insert was to for the options table query
	$myinsertid = $DB->Insert_ID();

	// insert values into the options table
	// skip this if there is no options_table_name for this service
	if ($options_table_name <> '')
	{
	$query = "INSERT into $options_table_name (user_services,$fieldlist) VALUES ($myinsertid,$fieldvalues)";
	$result = $DB->Execute($query) or die ("Query Failed");
	}

	// insert any linked_services into the user_services table
	$query = "SELECT * FROM linked_services WHERE linkfrom = $serviceid";
	$result = $DB->Execute($query) or die ("Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$linkto = $myresult['linkto'];
		// insert the linked service now
		$query = "INSERT into user_services (account_number, master_service_id, billing_id, start_datetime, salesperson) VALUES ('$account_number', '$linkto', '$default_billing_id', '$mydate', '$user')";
		$result = $DB->Execute($query) or die ("Query Failed");
	}	
	
	// add an entry to the customer_history and the activate_notify support user/group that this service was added
	
	// get the name of the service
	$query = "SELECT * FROM master_services WHERE id = $serviceid";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;	
	$servicename = $myresult['service_description'];
	$activate_notify = $myresult['activate_notify'];
	$optionstable = $myresult['options_table'];

	// if there is an activate_notify user/group make the history say not done instead of automatic
	if ($activate_notify <> '') {$status = "not done";} else {$status = "automatic";}

	// add to customer_history
	$desc = "Added $servicename [ <a target=\"_parent\"href=\"index.php?load=services&type=module&edit=on&userserviceid=$myinsertid&servicedescription=ADDED%20$servicename&optionstable=$optionstable&editbutton=Edit\">view</a> ]";
	$query = "INSERT into customer_history (creation_date,created_by,notify,account_number,status,description) VALUES (CURRENT_TIMESTAMP,'$user','$activate_notify','$account_number','$status','$desc')";
	$result = $DB->Execute($query) or die ("History Insert Query Failed");

	print "<blockquote>&nbsp; Added Service<p>";
	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=services&type=module\";</script>";
}
else if ($addbutton) // list the service options after they clicked on the add button.
{
print <<<END
<a href="index.php?load=services&type=module">[ Undo Changes ]</a>
END;
	$query = "SELECT * FROM master_services WHERE id = $serviceid";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;	
	$servicename = $myresult['service_description'];
	$options_table_name = $myresult['options_table'];
	
	print "<h4>Adding service: $servicename </h4><form action=\"index.php\"><table width=720 cellpadding=5 cellspacing=1 border=0>";
	print "<input type=hidden name=load value=services>";
	print "<input type=hidden name=type value=module>";
	print "<input type=hidden name=create value=on>";
	print "<input type=hidden name=options_table_name value=$options_table_name><input type=hidden name=serviceid value=$serviceid>";
	
	// check that there is an options_table_name, if so, show the options choices

	if ($options_table_name <> '')
	{
	
	/// ADODB version
	/// Maybe SELECT * FROM $options_table_name and run through that for field names?
	$fields = $DB->MetaColumns($options_table_name);
	$i = 0;
	foreach($fields as $v) {
		//echo "Name: $v->name ";
		//echo "Type: $v->type <br>";
        
                $fieldname = $v->name;
                $fieldflags = $v->type;
		if ($fieldname <> "id" AND $fieldname <> "user_services") {
			if ($fieldflags == "enum") {
                        echo "<td bgcolor=\"ccccdd\"width=180><b>$fieldname</b></td>
			<td bgcolor=\"#ddddee\">";

                        # print all the items listed in the enum
                        enum_select($options_table_name, $fieldname, '');

                        echo "</select></td><tr>\n";

                	} else {
                        echo "<td bgcolor=\"ccccdd\"width=180><b>$fieldname</b></td>
			<td bgcolor=\"#ddddee\"><input type=text name=$fieldname 
			value=$myresult[$i]></td><tr>\n";
                	}
                	$fieldlist .= ',' . $fieldname;
		}
		$i++;
        }
	
	print "<input type=hidden name=fieldlist value=$fieldlist>";
	}

	print "<td></td><td><input name=addnow type=submit value=\"Add\" class=smallbutton></td></table></form>";
}
else // print the list of services that may be added to the account
{
	echo '<a href="index.php?load=services&type=module">[ Undo Changes ]</a>';

	$query = "SELECT * FROM master_services WHERE selling_active = 'y' 
		ORDER BY service_description";
	$DB->SetFetchMode(ADODB_FETCH_NUM);
	$result = $DB->Execute($query) or die ("Query Failed");
	// Print HTML table of servicesresults

	echo '<table border=0 cellspacing=1 cellpadding=5 width=720>';
	echo '<tr><td bgcolor="#ccccdd"><b>ID</b></td>
	<td bgcolor="#ccccdd"><b>Description</b></td>
	<td bgcolor="#ccccdd"><b>Rate</b></td>
	<td bgcolor="#ccccdd"><b>Frequency</b></td>
	<td>&nbsp;</td></tr>';
	
	while ($myrow = $result->FetchRow()) 
	{
		printf("<tr onmouseover='h(this);' onmouseout='deh(this);'
		onmousedown='window.location.href=\"index.php?load=services&type=module&create=on&serviceid=$myrow[0]&addbutton=Add\";' bgcolor=\"#ddddee\"><td>%s</td><td>%s</td><td>$%s</td><td>%s</td><td align=center><form  style=\"margin-bottom:0;\" action=\"index.php\"><input type=hidden name=load value=services><input type=hidden name=type value=module><input type=hidden name=create value=on><input type=hidden name=serviceid value=$myrow[0]><input name=addbutton type=submit value=\"Add\" class=smallbutton></form></td></tr>\n", $myrow[0], $myrow[1], $myrow[2], $myrow[3]); 
	} 
	echo "</table>\n";

}

?>
