<?php   
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

session_start();
$account_number = $_SESSION['account_number'];

// GET Variables
$userserviceid = $base->input['userserviceid'];
$deletenow = $base->input['deletenow'];

if ($deletenow) {
	// don't actually delete anything - just set the removed flag to y in the user_services table

	$query = "UPDATE user_services SET removed = 'y' WHERE id = $userserviceid";
	$result = $DB->Execute($query) or die ("Query Failed");
	
	// put a note in the customer_history that this service was removed
        // get the name of the service
        // TODO: get this to work, to post to customer_history and shutoff_notify correctly
	$query = "SELECT user.*, master.service_description, master.shutoff_notify, master.options_table FROM user_services 
		AS user, master_services AS master WHERE user.master_service_id = master.id AND user.id = '$userserviceid'";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $servicename = $myresult['service_description'];
        $shutoff_notify = $myresult['shutoff_notify'];
	$optionstable = $myresult['options_table'];

        // if there is an shutoff_notify user/group make the history say not done instead of automatic
        if ($shutoff_notify <> '') {$status = "not done";} else {$status = "automatic";}

        // add to customer_history
        $desc = "Shutoff $servicename [ <a target=\"_parent\" href=\"index.php?load=services&type=module&edit=on&userserviceid=$userserviceid&servicedescription=SHUTOFF%20$servicename&optionstable=$optionstable&editbutton=Edit\">view</a> ]";
        $query = "INSERT into customer_history (creation_date,created_by,notify,account_number,status,description)
 		VALUES (CURRENT_TIMESTAMP,'$user','$shutoff_notify','$account_number','$status','$desc')";
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<script language=\"JavaScript\">window.location.href = \"index.php?load=services&type=module\";</script>";
}
?>
