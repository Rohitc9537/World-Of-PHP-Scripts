<?php   
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET Variables
$history = $base->input['history'];

session_start();
$account_number = $_SESSION['account_number'];
require_once('include/permissions.inc.php');
if ($edit)
{
    if ($pallow_modify)
    {
       include('edit.php');
    }  else permission_error();
}
else if ($create)
{
    if ($pallow_create)
    {
       include('create.php');
    } else permission_error();
}
else if ($delete)
{
    if ($pallow_remove)
    {
       include('delete.php');
    } else permission_error();
}
else if ($history)
{
	if ($pallow_view) {
		include('history.php');
	}
}

else if ($pallow_view)
{

print <<<END
<a href="index.php?load=services&type=module&create=on">[ Add Service ]</a>
&nbsp;&nbsp;
<a href="index.php?load=services&type=module&history=on">[ History ]</a>
<table cellpadding=0 border=0 cellspacing=0 width=720><td valign=top>		
	<table cellpadding=5 cellspacing=1 border=0 width=720>
	<td bgcolor="#ccccdd"><b>Service Name</b></td>
	<td bgcolor="#ccccdd"><b>Details</b></td>
	<td bgcolor="#ccccdd"><b>Creation</b></td>
	<td bgcolor="#ccccdd"><b>Price</b></td>
	<td bgcolor="#ccccdd"><b>Freq</b></td>
	<td bgcolor="#ccccdd"><b>BillingID</b></td>
	<td bgcolor="#ccccdd"><b>Salesperson</b></td><td></td>
END;

// select all the user information in user_services and connect it with the 
// master_services description and cost

$query = "SELECT user.*, master.service_description, master.options_table, 
	master.pricerate, master.frequency 
	FROM user_services AS user, master_services AS master 
	WHERE user.master_service_id = master.id 
	AND user.account_number = '$account_number' AND removed <> 'y' 
	ORDER BY master.service_description, user.id";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

// Print HTML table of user_services
while ($myresult = $result->FetchRow())
{
	// select the options_table to get data for the details column
	
	$options_table = $myresult['options_table'];
	$id = $myresult['id'];
	if ($options_table <> '') {
		// get the data from the options table and put into variables
		$query = "SELECT * FROM $options_table WHERE user_services = '$id'";
		$DB->SetFetchMode(ADODB_FETCH_NUM);
		$optionsresult = $DB->Execute($query) or die ("Options table Query Failed");
		$myoptions = $optionsresult->fields;
		$optiondetails = $myoptions[2];
	} else {
		$optiondetails = '';	
	}
	$master_service_id = $myresult['master_service_id'];
	$start_datetime = $myresult['start_datetime'];
	$billing_id = $myresult['billing_id'];
	$pricerate = $myresult['pricerate'];
	$usage_multiple = $myresult['usage_multiple'];
	$frequency = $myresult['frequency'];
	$salesperson = $myresult['salesperson'];
	$service_description = $myresult['service_description']; // from the LEFT JOINED master_services table

	// get the data from the billing tables to compare service and billing frequency
	$query = "SELECT * FROM billing b LEFT JOIN billing_types t ON b.billing_type = t.id WHERE b.id = '$billing_id'";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$freqoutput = $DB->Execute($query) or die ("Billing Type Query Failed");
	$freqresult = $freqoutput->fields;
	$billing_freq = $freqresult['frequency'];

	// multiply the pricerate and the usage_multiple to get the price to show
	$totalprice = $pricerate * $usage_multiple;

	print "\n<tr onMouseOver='h(this);' onmouseout='deh(this);' onmousedown='window.location.href=\"index.php?load=services&type=module&edit=on&userserviceid=$id&servicedescription=$service_description&optionstable=$options_table&editbutton=Edit\";' bgcolor=\"#ddddee\">";
	print "\n<td>$service_description</td>
	<td>$optiondetails</td>
	<td>$start_datetime</td>
	<td>$totalprice</td>
	<td>$frequency</td>
	<td>$billing_id</td>
	<td>$salesperson</td><td>";
	if ($frequency > $billing_freq) { 
	print "<b>FIX BILLING FREQUENCY ERROR</b>";
	};
	print "<form style=\"margin-bottom:0;\" action=\"index.php\">";
	print "<input type=hidden name=load value=services>";
	print "<input type=hidden name=type value=module><input type=hidden name=edit value=on>";
	print "<input type=hidden name=userserviceid value=\"$id\">";
	print "<input type=hidden name=servicedescription value=\"$service_description\">";
	print "<input type=hidden name=optionstable value=\"$options_table\">";
	print "<input name=editbutton type=submit value=\"Edit\" class=smallbutton></form></td></tr>";
} 
print <<<END

	</table>
	
	
</td>
</table>
</form>

END;

// query the taxes and fees that this customer has

$query = "SELECT ts.id ts_id, ts.master_services_id ts_serviceid, ts.tax_rate_id ts_rateid, 
ms.id ms_id, ms.service_description ms_description, ms.pricerate ms_pricerate, ms.frequency ms_freq, 
tr.id tr_id, tr.description tr_description, tr.rate tr_rate, tr.if_field tr_if_field, tr.if_value tr_if_value, 
us.master_service_id us_msid, us.billing_id us_bid, us.removed us_removed, us.account_number us_account_number 
FROM taxed_services ts
LEFT JOIN user_services us ON us.master_service_id = ts.master_services_id
LEFT JOIN master_services ms ON ms.id = ts.master_services_id
LEFT JOIN tax_rates tr ON tr.id = ts.tax_rate_id 
WHERE us.removed = 'n' AND us.account_number = '$account_number'";

$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Tax Query Failed");

// Print the taxes and fees that this customer's services have

print <<<END
<h4>Taxes & Fees</h4>
<table cellpadding=0 border=0 cellspacing=0 width=720><td valign=top>		
	<table cellpadding=2 cellspacing=1 border=0 width=720>
	<td bgcolor="#ccccdd"><b>Service</b></td>
	<td bgcolor="#ccccdd"><b>Tax Description</b></td>
	<td bgcolor="#ccccdd"><b>Tax Amount</b></td>
	
END;

while ($taxresult = $result->FetchRow())
{
	$service_description = $taxresult['ms_description'];
	$tax_description = $taxresult['tr_description'];
	$freqmultiplier = $taxresult['ms_freq'];	
	$if_field = $taxresult['tr_if_field'];
	$if_value = $taxresult['tr_if_value'];

	// check the if_field before printing to see if the tax applies to this customer
	if ($if_field <> '') {
	$ifquery = "SELECT $if_field FROM customer WHERE account_number = '$account_number'";
	$DB->SetFetchMode(ADODB_FETCH_NUM);
	$ifresult = $DB->Execute($ifquery) or die ("Tax Result Query Failed");	
	$myifresult = $ifresult->fields;
        $checkvalue = $myifresult[0];
	} else {
		$checkvalue = TRUE;
		$if_value = TRUE;	
	}
	
	if ($checkvalue == $if_value) {
		if ($freqmultiplier > 0) {
			$tax_amount = $taxresult['tr_rate'] * $taxresult['ms_pricerate'] * $freqmultiplier;
		} else {
			$tax_amount = $taxresult['tr_rate'] * $taxresult['ms_pricerate'];
		}
		
		// round the tax to two decimal places
                $tax_amount = sprintf("%.2f", $tax_amount);
		
		print "<tr>
		<td bgcolor=\"#ccccdd\">$service_description</td>
	        <td bgcolor=\"#ccccdd\">$tax_description</td>
	        <td bgcolor=\"#ccccdd\">$tax_amount</td>";
	}
}

print <<<END
	</table>
END;

} else permission_error();
?>

