<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org> -->
<!-- read the README file for more information -->

<html>
<head>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
</head>
<body bgcolor="#ddeeee" marginheight=0 marginwidth=1 leftmargin=1 rightmargin=0>
	<?php
	/*--------------------------------------------------------------------*/
	// Check for authorized accesss
	/*--------------------------------------------------------------------*/
	
	if(constant("INDEX_CITRUS") <> 1){
		echo "You must be logged in to run this.  Goodbye.";
		exit;	
	}
	
	if (!defined("INDEX_CITRUS")) {
		echo "You must be logged in to run this.  Goodbye.";
	        exit;
	}

	// GET Variables
        $account_number = $base->input['account_number'];
	
	echo '<table cellspacing=0 cellpadding=4 border=0>
		<td bgcolor="#ccdddd" width=100><b>Invoice Num</b></td>
		<td bgcolor="#ccdddd" width=130><b>Date</b></td>
		<td bgcolor="#ccdddd" width=200><b>Type</b></td>
		<td bgcolor="#ccdddd" width=100><b>From</b></td>
		<td bgcolor="#ccdddd" width=100><b>To</b></td>
		<td bgcolor="#ccdddd" width=100><b>New Charges</b></td>
		<td bgcolor="#ccdddd" width=150><b>Total</b></td>';

	// get the billing_history for this account, the account number is 
	// stored in the corresponding billing record

	$query = "SELECT h.id h_id, h.billing_id h_bid, h.billing_date h_bdate, 
	h.billing_type h_btype, h.from_date h_from, h.to_date h_to, h.total_due 
	h_total, h.new_charges h_new_charges, c.account_number c_acctnum, 
	b.account_number b_acctnum, b.id b_id 
	FROM billing_history h 
	LEFT JOIN billing b ON h.billing_id = b.id  
	LEFT JOIN customer c ON b.account_number = c.account_number
	WHERE b.account_number = '$account_number' ORDER BY h.id DESC";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Billing History Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$id = $myresult['h_id'];
		$billing_date = $myresult['h_bdate'];
		$billing_type = $myresult['h_btype'];
		$from_date = $myresult['h_from'];
		$to_date = $myresult['h_to'];
		$new_charges = $myresult['h_new_charges'];
		$total_due = $myresult['h_total'];

		print "<tr bgcolor=\"#eeffff\">";
		print "<td style=\"border-top: 1px solid grey;\">$id &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$billing_date &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$billing_type &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$from_date &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$to_date &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$new_charges &nbsp;</td>";
                print "<td style=\"border-top: 1px solid grey;\">$total_due &nbsp;</td>";
	}

	echo '</table>';

	?>
</body>
</html>
