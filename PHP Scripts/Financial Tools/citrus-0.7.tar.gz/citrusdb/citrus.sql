-- phpMyAdmin SQL Dump
-- version 2.6.1-pl3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 28, 2005 at 09:11 AM
-- Server version: 4.0.21
-- PHP Version: 5.0.4
-- 
-- Database: `citrus`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `batch`
-- 

CREATE TABLE `batch` (
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `batch`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `billing`
-- 

CREATE TABLE `billing` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `company` varchar(100) default NULL,
  `street` varchar(100) NOT NULL default '',
  `city` varchar(100) NOT NULL default '',
  `state` char(2) NOT NULL default '',
  `country` varchar(100) NOT NULL default 'USA',
  `zip` varchar(20) NOT NULL default '',
  `phone` varchar(20) NOT NULL default '',
  `fax` varchar(20) default NULL,
  `contact_email` varchar(100) default NULL,
  `account_number` int(11) NOT NULL default '0',
  `billing_type` int(11) NOT NULL default '0',
  `creditcard_number` bigint(16) default NULL,
  `creditcard_expire` smallint(4) unsigned zerofill default NULL,
  `billing_status` int(11) NOT NULL default '0',
  `disable_billing` enum('y','n') default NULL,
  `next_billing_date` date NOT NULL default '0000-00-00',
  `prev_billing_date` date default NULL,
  `from_date` date default NULL,
  `to_date` date default NULL,
  `payment_due_date` date default NULL,
  `notes` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `billing`
-- 

INSERT INTO `billing` VALUES (1, 'Example Customer', 'Example Company', 'Example St.', 'ExampleCity', 'CA', 'USA', '12345', '555-555-5555', '555-555-5556', 'example@example.com', 1, 1, 0, 0000, 0, NULL, '2005-10-26', NULL, '2005-10-26', '2005-11-26', '2005-10-26', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `billing_details`
-- 

CREATE TABLE `billing_details` (
  `id` int(11) NOT NULL auto_increment,
  `billing_id` int(11) NOT NULL default '0',
  `creation_date` date NOT NULL default '0000-00-00',
  `user_services_id` int(11) default NULL,
  `taxed_services_id` int(11) default NULL,
  `invoice_number` int(11) default NULL,
  `billed_amount` float NOT NULL default '0',
  `paid_amount` float NOT NULL default '0',
  `batch` int(11) NOT NULL default '0',
  KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `billing_details`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `billing_history`
-- 

CREATE TABLE `billing_history` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `billing_date` date NOT NULL default '0000-00-00',
  `created_by` varchar(32) NOT NULL default 'citrus',
  `record_type` set('bill','payment') default NULL,
  `billing_type` set('creditcard','invoice','prepaid','free') NOT NULL default '',
  `billing_id` int(11) NOT NULL default '0',
  `from_date` date default '0000-00-00',
  `to_date` date default '0000-00-00',
  `payment_due_date` date default NULL,
  `details` varchar(32) default NULL,
  `new_charges` float NOT NULL default '0',
  `past_due` float default '0',
  `late_fee` float NOT NULL default '0',
  `tax_due` float NOT NULL default '0',
  `total_due` float NOT NULL default '0',
  `notes` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `billing_history`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `billing_status_codes`
-- 

CREATE TABLE `billing_status_codes` (
  `id` int(11) NOT NULL auto_increment,
  `description` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `billing_status_codes`
-- 

INSERT INTO `billing_status_codes` VALUES (1, 'New');
INSERT INTO `billing_status_codes` VALUES (2, 'Authorized');
INSERT INTO `billing_status_codes` VALUES (3, 'Declined');
INSERT INTO `billing_status_codes` VALUES (4, 'Declined 2X');
INSERT INTO `billing_status_codes` VALUES (5, 'Pending');
INSERT INTO `billing_status_codes` VALUES (6, 'Canceled');

-- --------------------------------------------------------

-- 
-- Table structure for table `billing_types`
-- 

CREATE TABLE `billing_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(32) NOT NULL default '',
  `sortorder` int(11) NOT NULL default '0',
  `frequency` int(11) NOT NULL default '1',
  `method` enum('creditcard','invoice','prepay','free') NOT NULL default 'creditcard',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=25 ;

-- 
-- Dumping data for table `billing_types`
-- 

INSERT INTO `billing_types` VALUES (1, 'CreditCard Monthly', 0, 1, 'creditcard');
INSERT INTO `billing_types` VALUES (7, 'Invoice Monthly', 0, 1, 'invoice');
INSERT INTO `billing_types` VALUES (4, 'CreditCard 6 Months', 0, 6, 'creditcard');
INSERT INTO `billing_types` VALUES (6, 'CreditCard 1 Year', 0, 12, 'creditcard');
INSERT INTO `billing_types` VALUES (8, 'Invoice Quarterly', 0, 3, 'invoice');
INSERT INTO `billing_types` VALUES (9, 'Invoice 6 Months', 0, 6, 'invoice');
INSERT INTO `billing_types` VALUES (10, 'Invoice Yearly', 0, 12, 'invoice');
INSERT INTO `billing_types` VALUES (11, 'Final Bill', 15, 0, 'invoice');
INSERT INTO `billing_types` VALUES (12, 'Single Purchase', 14, 0, 'prepay');
INSERT INTO `billing_types` VALUES (13, 'Prepay 6 Months', 0, 6, 'prepay');
INSERT INTO `billing_types` VALUES (15, 'Prepay 1 Year', 0, 12, 'prepay');
INSERT INTO `billing_types` VALUES (16, 'Free', 13, 0, 'free');
INSERT INTO `billing_types` VALUES (18, 'Prepay 2 Years', 0, 24, 'prepay');

-- --------------------------------------------------------

-- 
-- Table structure for table `credit_options`
-- 

CREATE TABLE `credit_options` (
  `id` int(11) NOT NULL auto_increment,
  `user_services` int(11) NOT NULL default '0',
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `credit_options`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `customer`
-- 

CREATE TABLE `customer` (
  `source` varchar(100) default NULL,
  `signup_date` date NOT NULL default '0000-00-00',
  `name` varchar(255) NOT NULL default '',
  `company` varchar(255) default NULL,
  `street` varchar(255) NOT NULL default '',
  `city` varchar(255) NOT NULL default '',
  `state` char(2) NOT NULL default '',
  `country` varchar(255) NOT NULL default 'USA',
  `zip` varchar(20) NOT NULL default '',
  `phone` varchar(20) NOT NULL default '',
  `fax` varchar(20) default NULL,
  `contact_email` varchar(255) default NULL,
  `tax_exempt_id` varchar(100) default NULL,
  `account_number` int(11) NOT NULL auto_increment,
  `maiden_name` varchar(100) default NULL,
  `cancel_date` date default NULL,
  `removal_date` date default NULL,
  `default_billing_id` int(10) unsigned NOT NULL default '0',
  `account_manager_password` varchar(32) default NULL,
  PRIMARY KEY  (`account_number`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `customer`
-- 

INSERT INTO `customer` VALUES ('example', '2005-09-25', 'Example Customer', 'Example Company', 'Example St.', 'ExampleCity', 'CA', 'USA', '12345', '555-555-5555', '555-555-5556', 'example@example.com', '', 1, 'secret', NULL, NULL, 1, 'test');

-- --------------------------------------------------------

-- 
-- Table structure for table `customer_history`
-- 

CREATE TABLE `customer_history` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `creation_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` varchar(20) NOT NULL default 'citrus',
  `notify` varchar(32) NOT NULL default '',
  `account_number` int(11) NOT NULL default '0',
  `status` enum('automatic','not done','pending','completed') NOT NULL default 'automatic',
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `customer_history`
-- 

INSERT INTO `customer_history` VALUES (1, '2005-09-28 09:09:11', 'admin', '', 1, 'automatic', 'Added Example Service [ <a target="_parent"href="index.php?load=services&type=module&edit=on&userserviceid=1&servicedescription=ADDED%20Example Service&optionstable=example_options&editbutton=Edit">view</a> ]');

-- --------------------------------------------------------

-- 
-- Table structure for table `example_options`
-- 

CREATE TABLE `example_options` (
  `id` int(11) NOT NULL auto_increment,
  `user_services` int(11) NOT NULL default '0',
  `username` varchar(12) default NULL,
  `password` varchar(12) default NULL,
  `operating_system` enum('Windows 9x','WindowsNT/2K/XP','Mac OS 9','Mac OS X','Linux') default NULL,
  `service_address` varchar(128) default NULL,
  `equipment` varchar(128) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `example_options`
-- 

INSERT INTO `example_options` VALUES (1, 1, 'myuser', 'mypass', 'Windows 9x', '123 Main St.', 'Model 345');

-- --------------------------------------------------------

-- 
-- Table structure for table `general`
-- 

CREATE TABLE `general` (
  `id` int(11) NOT NULL auto_increment,
  `org_name` varchar(32) NOT NULL default '',
  `org_street` varchar(32) NOT NULL default '',
  `org_city` varchar(32) NOT NULL default '',
  `org_state` varchar(32) NOT NULL default '',
  `org_zip` varchar(32) NOT NULL default '',
  `org_country` varchar(32) NOT NULL default 'USA',
  `phone_sales` varchar(32) default NULL,
  `email_sales` varchar(32) default NULL,
  `phone_billing` varchar(32) default NULL,
  `email_billing` varchar(32) default NULL,
  `phone_custsvc` varchar(32) default NULL,
  `email_custsvc` varchar(32) default NULL,
  `billingdate_rollover_time` time default NULL,
  `default_group` varchar(30) default NULL,
  `ccexportvarorder` varchar(255) NOT NULL default '$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street',
  `path_to_ccfile` varchar(255) default NULL,
  `pastdue_days1` int(11) NOT NULL default '0',
  `pastdue_days2` int(11) NOT NULL default '0',
  `pastdue_days3` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `general`
-- 

INSERT INTO `general` VALUES (1, 'Citrus DB', '1 Citrus St.', 'Citrus City', 'Orange', '12345', 'USA', '123-456-7890', 'test@citrusdb.org', '617-555-5554', 'billing@citrusdb.org', '555-123456', 'customer@citrusdb.org', '16:00:00', 'users', '$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street', '/users/pyasi/sites/io', 30, 60, 90);

-- --------------------------------------------------------

-- 
-- Table structure for table `groups`
-- 

CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `groupname` varchar(50) NOT NULL default '',
  `groupmember` varchar(32) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=31 ;

-- 
-- Dumping data for table `groups`
-- 

INSERT INTO `groups` VALUES (9, 'users', 'admin');
INSERT INTO `groups` VALUES (30, 'users', 'test');
INSERT INTO `groups` VALUES (26, 'users', 'online');

-- --------------------------------------------------------

-- 
-- Table structure for table `holiday`
-- 

CREATE TABLE `holiday` (
  `holiday_date` date NOT NULL default '0000-00-00'
) TYPE=MyISAM;

-- 
-- Dumping data for table `holiday`
-- 

INSERT INTO `holiday` VALUES ('2004-12-25');
INSERT INTO `holiday` VALUES ('2005-01-01');

-- --------------------------------------------------------

-- 
-- Table structure for table `linked_services`
-- 

CREATE TABLE `linked_services` (
  `id` int(11) NOT NULL auto_increment,
  `linkfrom` int(11) NOT NULL default '0',
  `linkto` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `linked_services`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `master_services`
-- 

CREATE TABLE `master_services` (
  `id` int(11) NOT NULL auto_increment,
  `service_description` varchar(100) NOT NULL default '',
  `pricerate` float default NULL,
  `frequency` varchar(20) NOT NULL default '1',
  `options_table` varchar(50) default NULL,
  `category` varchar(25) default NULL,
  `selling_active` enum('y','n') default 'y',
  `hide_online` enum('y','n') NOT NULL default 'n',
  `postbilled` enum('y','n') NOT NULL default 'n',
  `activate_notify` varchar(32) default NULL,
  `shutoff_notify` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=15 ;

-- 
-- Dumping data for table `master_services`
-- 

INSERT INTO `master_services` VALUES (3, 'Example Service', 19.95, '1', 'example_options', 'example', 'y', 'n', 'n', '', '');
INSERT INTO `master_services` VALUES (2, 'Prorate', 1, '0', 'prorate_options', 'prorate', 'y', 'n', 'n', '', '');
INSERT INTO `master_services` VALUES (1, 'Credit', -1, '0', 'credit_options', 'credit', 'y', 'n', 'n', '', '');
INSERT INTO `master_services` VALUES (4, 'One Time Example', 12.95, '0', '', 'example', 'y', 'n', 'n', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `module_permissions`
-- 

CREATE TABLE `module_permissions` (
  `id` int(4) NOT NULL auto_increment,
  `modulename` varchar(30) NOT NULL default '',
  `permission` char(1) NOT NULL default '',
  `user` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=20 ;

-- 
-- Dumping data for table `module_permissions`
-- 

INSERT INTO `module_permissions` VALUES (5, 'customer', 'f', 'users');
INSERT INTO `module_permissions` VALUES (12, 'services', 'f', 'users');
INSERT INTO `module_permissions` VALUES (14, 'billing', 'f', 'users');
INSERT INTO `module_permissions` VALUES (8, 'support', 'f', 'users');

-- --------------------------------------------------------

-- 
-- Table structure for table `modules`
-- 

CREATE TABLE `modules` (
  `id` int(11) NOT NULL auto_increment,
  `commonname` varchar(50) NOT NULL default '',
  `modulename` varchar(50) NOT NULL default '',
  `sortorder` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `sortorder` (`sortorder`)
) TYPE=MyISAM AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `modules`
-- 

INSERT INTO `modules` VALUES (1, 'Customer', 'customer', 0);
INSERT INTO `modules` VALUES (2, 'Services', 'services', 1);
INSERT INTO `modules` VALUES (3, 'Billing', 'billing', 2);
INSERT INTO `modules` VALUES (4, 'Support', 'support', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `payment_history`
-- 

CREATE TABLE `payment_history` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `creation_date` date NOT NULL default '0000-00-00',
  `transaction_code` varchar(4) default NULL,
  `billing_id` int(11) NOT NULL default '0',
  `creditcard_number` varchar(16) default NULL,
  `creditcard_expire` int(4) unsigned zerofill default NULL,
  `billing_amount` float default NULL,
  `response_code` varchar(100) default NULL,
  `paid_from` date NOT NULL default '0000-00-00',
  `paid_to` date NOT NULL default '0000-00-00',
  `invoice_number` int(128) default NULL,
  `status` set('authorized','declined','paid','unknown') default NULL,
  `payment_type` set('creditcard','check','cash','eft') default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `payment_history`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `prorate_options`
-- 

CREATE TABLE `prorate_options` (
  `id` int(11) NOT NULL auto_increment,
  `user_services` int(11) NOT NULL default '0',
  `service_description` varchar(255) default NULL,
  `service_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `prorate_options`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `searches`
-- 

CREATE TABLE `searches` (
  `id` int(11) NOT NULL auto_increment,
  `query` text NOT NULL,
  `owner` varchar(32) default NULL,
  `outputform` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `searches`
-- 

INSERT INTO `searches` VALUES (1, 'SELECT * FROM customer WHERE account_number = %s1%', NULL, '');
INSERT INTO `searches` VALUES (2, 'SELECT * FROM customer WHERE company LIKE ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (3, 'SELECT * FROM customer WHERE name LIKE ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (4, 'SELECT * FROM customer WHERE phone LIKE ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (5, 'SELECT * FROM billing WHERE id = %s1%', NULL, NULL);
INSERT INTO `searches` VALUES (6, 'SELECT * FROM billing WHERE company LIKE ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (7, 'SELECT * FROM billing WHERE payment_due_date = ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (8, 'SELECT * FROM customer_history WHERE description LIKE ''%%s1%%''', NULL, NULL);
INSERT INTO `searches` VALUES (9, 'SELECT * FROM example_options do LEFT JOIN user_services us ON us.id = do.user_services WHERE username LIKE ''%%s1%%'' ', NULL, NULL);
INSERT INTO `searches` VALUES (10, 'SELECT * FROM example_options wo LEFT JOIN user_services us ON us.id = wo.user_services WHERE password LIKE ''%%s1%%'' ', NULL, NULL);
INSERT INTO `searches` VALUES (11, 'SELECT * FROM example_options wo LEFT JOIN user_services us ON us.id = wo.user_services WHERE equipment LIKE ''%%s1%%'' ', NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `tax_rates`
-- 

CREATE TABLE `tax_rates` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `description` varchar(50) NOT NULL default '',
  `rate` float NOT NULL default '0',
  `if_field` varchar(30) default NULL,
  `if_value` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=53 ;

-- 
-- Dumping data for table `tax_rates`
-- 

INSERT INTO `tax_rates` VALUES (1, 'Federal Telephone Excise Tax', 0.03, '', '');
INSERT INTO `tax_rates` VALUES (3, 'Alabama Sales Tax', 0.04, 'state', 'AL');
INSERT INTO `tax_rates` VALUES (4, 'Arizona Sales Tax', 0.056, 'state', 'AZ');
INSERT INTO `tax_rates` VALUES (5, 'Arkansas Sales Tax', 0.05125, 'state', 'AR');
INSERT INTO `tax_rates` VALUES (6, 'California Sales Tax', 0.0725, 'state', 'CA');
INSERT INTO `tax_rates` VALUES (7, 'Colorado Sales Tax', 0.029, 'state', 'CO');
INSERT INTO `tax_rates` VALUES (8, 'Connecticut Sales Tax', 0.06, 'state', 'CT');
INSERT INTO `tax_rates` VALUES (9, 'Florida Sales Tax', 0.06, 'state', 'FL');
INSERT INTO `tax_rates` VALUES (10, 'Georgia Sales Tax', 0.04, 'state', 'GA');
INSERT INTO `tax_rates` VALUES (11, 'Hawaii Sales Tax', 0.04, 'state', 'HI');
INSERT INTO `tax_rates` VALUES (12, 'Idaho Sales Tax', 0.06, 'state', 'ID');
INSERT INTO `tax_rates` VALUES (13, 'Illinois Sales Tax', 0.0625, 'state', 'IL');
INSERT INTO `tax_rates` VALUES (14, 'Indiana Sales Tax', 0.06, 'state', 'IN');
INSERT INTO `tax_rates` VALUES (15, 'Iowa Sales Tax', 0.05, 'state', 'IA');
INSERT INTO `tax_rates` VALUES (16, 'Kansas Sales Tax', 0.053, 'state', 'KS');
INSERT INTO `tax_rates` VALUES (17, 'Kentucky Sales Tax', 0.06, 'state', 'KY');
INSERT INTO `tax_rates` VALUES (18, 'Louisiana Sales Tax', 0.04, 'state', 'LA');
INSERT INTO `tax_rates` VALUES (19, 'Maine Sales Tax', 0.05, 'state', 'ME');
INSERT INTO `tax_rates` VALUES (20, 'Massachusetts Sales Tax', 0.05, 'state', 'MA');
INSERT INTO `tax_rates` VALUES (21, 'Michigan Sales Tax', 0.06, 'state', 'MI');
INSERT INTO `tax_rates` VALUES (22, 'Minnesota Sales Tax', 0.065, 'state', 'MN');
INSERT INTO `tax_rates` VALUES (23, 'Mississippi Sales Tax', 0.07, 'state', 'MS');
INSERT INTO `tax_rates` VALUES (24, 'Missouri Sales Tax', 0.04225, 'state', 'MO');
INSERT INTO `tax_rates` VALUES (25, 'Nebraska Sales Tax', 0.055, 'state', 'NE');
INSERT INTO `tax_rates` VALUES (26, 'Nevada Sales Tax', 0.065, 'state', 'NV');
INSERT INTO `tax_rates` VALUES (27, 'New Jersey Sales Tax', 0.06, 'state', 'NJ');
INSERT INTO `tax_rates` VALUES (28, 'New Mexico Sales Tax', 0.05, 'state', 'NM');
INSERT INTO `tax_rates` VALUES (29, 'New York Sales Tax', 0.0425, 'state', 'NY');
INSERT INTO `tax_rates` VALUES (30, 'North Carolina Sales Tax', 0.045, 'state', 'NC');
INSERT INTO `tax_rates` VALUES (31, 'North Dakota Sales Tax', 0.05, 'state', 'ND');
INSERT INTO `tax_rates` VALUES (32, 'Ohio Sales Tax', 0.06, 'state', 'OH');
INSERT INTO `tax_rates` VALUES (33, 'Oklahoma Sales Tax', 0.045, 'state', 'OK');
INSERT INTO `tax_rates` VALUES (34, 'Pennsylvania Sales Tax', 0.06, 'state', 'PA');
INSERT INTO `tax_rates` VALUES (35, 'Rhode Island Sales Tax', 0.07, 'state', 'RI');
INSERT INTO `tax_rates` VALUES (36, 'South Carolina Sales Tax', 0.05, 'state', 'SC');
INSERT INTO `tax_rates` VALUES (37, 'South Dakota Sales Tax', 0.04, 'state', 'SD');
INSERT INTO `tax_rates` VALUES (38, 'Tennessee Sales Tax', 0.07, 'state', 'TN');
INSERT INTO `tax_rates` VALUES (39, 'Texas Sales Tax', 0.0625, 'state', 'TX');
INSERT INTO `tax_rates` VALUES (40, 'Utah Sales Tax', 0.0475, 'state', 'UT');
INSERT INTO `tax_rates` VALUES (41, 'Vermont Sales Tax', 0.06, 'state', 'VT');
INSERT INTO `tax_rates` VALUES (42, 'Virginia Sales Tax', 0.045, 'state', 'VA');
INSERT INTO `tax_rates` VALUES (43, 'Washington Sales Tax', 0.065, 'state', 'WA');
INSERT INTO `tax_rates` VALUES (44, 'West Virginia Sales Tax', 0.06, 'state', 'WV');
INSERT INTO `tax_rates` VALUES (45, 'Wisconsin Sales Tax', 0.05, 'state', 'WI');
INSERT INTO `tax_rates` VALUES (46, 'Wyoming Sales Tax', 0.04, 'state', 'WY');
INSERT INTO `tax_rates` VALUES (47, 'District of Columbia Sales Tax', 0.0575, 'state', 'DC');

-- --------------------------------------------------------

-- 
-- Table structure for table `taxed_services`
-- 

CREATE TABLE `taxed_services` (
  `id` int(10) NOT NULL auto_increment,
  `master_services_id` int(10) NOT NULL default '0',
  `tax_rate_id` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `taxed_services`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(50) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `real_name` varchar(50) NOT NULL default '',
  `admin` enum('y','n') NOT NULL default 'n',
  `manager` enum('y','n') NOT NULL default 'n',
  `email` varchar(100) default NULL,
  `remote_addr` varchar(15) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (5, 'admin', '098f6bcd4621d373cade4e832627b4f6', 'Admin User', 'y', 'y', NULL, '');
INSERT INTO `user` VALUES (20, 'online', '098f6bcd4621d373cade4e832627b4f6', 'Online Requests', 'n', 'n', NULL, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `user_services`
-- 

CREATE TABLE `user_services` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `account_number` int(11) NOT NULL default '0',
  `master_service_id` int(11) NOT NULL default '0',
  `billing_id` int(11) NOT NULL default '0',
  `start_datetime` datetime NOT NULL default '0000-00-00 00:00:00',
  `end_datetime` datetime default NULL,
  `removal_date` date default NULL,
  `salesperson` varchar(40) default NULL,
  `usage_multiple` float NOT NULL default '1',
  `removed` set('y','n') NOT NULL default 'n',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `user_services`
-- 

INSERT INTO `user_services` VALUES (1, 1, 3, 1, '2005-09-28 09:09:11', NULL, NULL, 'admin', 1, 'n');
