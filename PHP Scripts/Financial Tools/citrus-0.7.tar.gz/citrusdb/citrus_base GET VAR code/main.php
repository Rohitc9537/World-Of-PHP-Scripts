<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information

// Includes
include('include/database.inc');
include('include/user.inc');

// Get our base class
require 'include/citrus_base.php';
$base = new citrus_base();

$user =  user_getname();

//SESSION Variables
session_start();
$account_number = $_SESSION['account_number'];

if (user_isloggedin()) 
{
$time_start = getmicrotime();

print <<<EOF
<html>
<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information -->
<head>
<title>CITRUSDB</title>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
<script language="JavaScript">
   function h(oR) {
      oR.style.background='ffdd77';
   }
   function deh(oR) {
      oR.style.background='ddddee';
   }
   function dehnew(oR) {
      oR.style.background='ddeeff';
   }
</script>
</head>
<body marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 bgcolor="#ffffff">
<table height=100% width=100% cellpadding=10 cellspacing=0 border=0>
<td valign=top bgcolor="#eeeeee">
<img src="images/citrus-logo.png">
<p align=right>
<b>Account Num:</b>&nbsp; $account_number &nbsp; 
<p align=right>
EOF;

include('modules.php');

print "</p></td><td width=100% valign=top><table cellpadding=0 cellspacing=0 border=0 width=100%><td>";

	include('header.php');  

print "</td><tr><td>";

	if ($base->input['type'] == "base")
	{
        	include($base->input['load'].'.php');        
        }
	        
	if ($base->input['type'] == "module") 
        {
                include('modules/'.$base->input['load'].'/index.php');
        }

print "</td><tr><td><br>";

        if ($base->input['type'] == "module") 
	{ 
		include('footer.php'); 
	}        
	print "<br>";
	$time_end = getmicrotime();
	$time = $time_end - $time_start;
                
	echo "&nbsp; &nbsp; Completed in $time seconds";

print "</td></table></td></table></body></html>";
}
else
{
	print "You are not logged in.";
}

?>
