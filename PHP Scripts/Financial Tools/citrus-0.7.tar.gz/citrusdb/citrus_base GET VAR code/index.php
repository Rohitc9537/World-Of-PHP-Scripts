<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information

// Includes
include('include/database.inc');
include('include/user.inc');

// Get our base class
require 'include/citrus_base.php';
$base = new citrus_base();

if (user_isloggedin()) {
        user_logout();
        // $base->input['user_name']='';
}
if ($base->input['submit']) {
	user_login($base->input['user_name'],$base->input['password']);
}
if ($feedback) {
	if ($feedback == ' SUCCESS - You Are Now Logged In ') {

// start the session variables to hold the account number
session_start();
$_SESSION['account_number'] = 1;

header ("Location: main.php?load=search&type=base");

	} else {
		echo $feedback;
	}
}
else
{
echo '<html><head>
	<title>CitrusDB Login</title>
	<LINK href="citrus.css" type=text/css rel=STYLESHEET><script language="JavaScript" src="include/md5.js"></script></head>
	<body bgcolor="#ffffff">
	<center><table><td valign=top><img src="images/citrus-logo.png">
	<P>
	Enter your user name and password.
	<P>
	<FORM ACTION="'. $_SERVER['PHP_SELF'] .'" METHOD="POST">
	<B>User Name:</B><BR>
	<INPUT TYPE="TEXT" NAME="user_name" VALUE="" SIZE="15" MAXLENGTH="15">
	<P>
	<B>Password:</B><BR>
	<INPUT TYPE="password" NAME="password" VALUE="" SIZE="15" MAXLENGTH="32">
	<P>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Login"  onclick="password.value = calcMD5(password.value)" class=smallbutton>
	</FORM>
	<P></td></table></body></html>';

}
?>
