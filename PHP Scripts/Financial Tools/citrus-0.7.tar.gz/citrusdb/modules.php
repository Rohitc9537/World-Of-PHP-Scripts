<?php
// Copyright (C) 2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// Check for permissions to view module
    $groupname = array();
    $modulelist = array();
	$query = "SELECT * FROM groups WHERE groupmember = '$user'";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Group Query Failed");
	while ($myresult = $result->FetchRow())
	{
		array_push($groupname,$myresult['groupname']);
	}
    $groups = array_unique($groupname);
    array_push($groups,$user);

    while (list($key,$value) = each($groups))
    {
        $query = "SELECT * FROM module_permissions WHERE user = '$value' ";
    	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Permission Query Failed");
	while ($myresult = $result->FetchRow())
	{
        	array_push($modulelist,$myresult['modulename']);
    	}
    }
    $viewable = array_unique($modulelist);

// Print Modules Menu

echo "<ul id=\"tabnav\">";

$query = "SELECT * FROM modules ORDER BY sortorder";
$result = $DB->Execute($query) or die ("Permission Query Failed");

while ($myresult = $result->FetchRow())
{
	$commonname = $myresult['commonname'];
	$modulename = $myresult['modulename'];

	//echo "$commonname\n";

    if (in_array ($modulename, $viewable))
    {
		if ($load == $modulename) {
			print "<li><a class=\"active\" href=\"index.php?load=$modulename&type=module\">$commonname</a></li>";
		} else {
			print "<li><a href=\"index.php?load=$modulename&type=module\">$commonname</a></li>";
		}
    }
    	
	if ($modulename == "support")
	{
		// query the customer_history for the number of waiting messages sent to that user
		$supportquery = "SELECT * FROM customer_history WHERE notify = '$user' AND status = \"not done\" ";
		$supportresult = $DB->Execute($supportquery) or die ("Support Query Failed");
		$num_rows = $supportresult->RowCount();

		// query the customer_history for messages sent to groups the user belongs to
	        $query = "SELECT * FROM groups WHERE groupmember = '$user' ";
	        $supportresult = $DB->Execute($supportquery) or die ("Group Query Failed");

	        while ($myresult = $supportresult->FetchRow())
	        {
	                $groupname = $myresult['groupname'];
	                $query = "SELECT * FROM customer_history WHERE notify = '$groupname' AND status = \"not done\" ";
	                $gpresult = $DB->Execute($query) or die ("Groupname Query Failed");
			$num_rows = $gpresult->RowCount() + $num_rows;
		}

		print "<p><a href=\"index.php?load=support&type=module&edit=on\" class=smalltext>$num_rows new messages</a>";
	}
	
}

echo "</ul>";

?>
