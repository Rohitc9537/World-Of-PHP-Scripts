<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information

//
// TEST: test the date functions
//

//
// get the current date and time in the SQL query format
//

$today = date("Y-m-d");
print "today = $today<p>";

$tomorrow  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));
print "tomorrow = $tomorrow<p>";

$thenextday = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")+2, date("Y")));
print "the next day = $thenextday<p>";

$thedayafterthat = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")+3, date("Y")));
print "the day after that = $thedayafterthat<p>";


//
// check if it's after the dayrollover time and get tomorrow's date
//


//
// check if the date is in the holiday table, move up one day until not matched
//


?>
