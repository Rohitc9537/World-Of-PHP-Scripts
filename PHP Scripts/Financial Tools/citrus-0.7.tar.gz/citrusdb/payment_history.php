<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information -->
<html>
<head>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
</head>
<body bgcolor="#eedddd" marginheight=0 marginwidth=1 leftmargin=1 rightmargin=0>
	<?php
	/*--------------------------------------------------------------------*/
	// Check for authorized accesss
	/*--------------------------------------------------------------------*/
	if(constant("INDEX_CITRUS") <> 1){
		echo "You must be logged in to run this.  Goodbye.";
		exit;	
	}
	
	if (!defined("INDEX_CITRUS")) {
		echo "You must be logged in to run this.  Goodbye.";
	        exit;
	}
	
	// GET Variables
        $account_number = $base->input['account_number'];
	
	echo '<table cellspacing=0 cellpadding=4 border=0>
		<td bgcolor="#ddcccc" width=100><b>ID</b></td>
		<td bgcolor="#ddcccc" width=130><b>Date</b></td>
		<td bgcolor="#ddcccc" width=200><b>Type</b></td>
		<td bgcolor="#ddcccc" width=100><b>Status</b></td>
		<td bgcolor="#ddcccc" width=100><b>Response</b></td>
		<td bgcolor="#ddcccc" width=150><b>Amount</b></td>';

	// get the billing_history for this account, the account number is stored in the corresponding billing record

	$query = "SELECT p.id p_id, p.creation_date p_cdate, p.payment_type p_payment_type, p.status p_status, 
		p.billing_amount p_billing_amount, p.response_code p_response_code, c.account_number c_acctnum,
		b.account_number b_acctnum, b.id b_id
	FROM payment_history p 
	LEFT JOIN billing b ON p.billing_id = b.id
	LEFT JOIN customer c ON b.account_number = c.account_number
	WHERE b.account_number = '$account_number' ORDER BY p.id DESC";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
        $result = $DB->Execute($query) or die ("Payment History Query Failed");

	while ($myresult = $result->FetchRow())
	{
		$id = $myresult['p_id'];
		$date = $myresult['p_cdate'];
		$type = $myresult['p_payment_type'];
		$status = $myresult['p_status'];
		$response = $myresult['p_response_code'];
		$amount = $myresult['p_billing_amount'];

		print "<tr bgcolor=\"#ffeeee\">";
		print "<td style=\"border-top: 1px solid grey;\">$id &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$date &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$type &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$status &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$response &nbsp;</td>";
                print "<td style=\"border-top: 1px solid grey;\">$amount &nbsp;</td>";
	}

	echo '</table>';

	?>
</body>
</html>
