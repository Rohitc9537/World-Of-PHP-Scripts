<?php
/*----------------------------------------------------------------------------*/
// CitrusDB - The Open Source Customer Database
// Copyright (C) 2002-2005 Paul Yasi
//
// This program is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software 
// Foundation; either version 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT 
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along with 
// this program; if not, write to the Free Software Foundation, Inc., 59 Temple 
// Place, Suite 330, Boston, MA 02111-1307 USA
//
// http://www.citrusdb.org
// Read the README file for more details
/*----------------------------------------------------------------------------*/

// Includes
include('include/config.inc.php');
include('include/database.inc.php');

// Get our user class
include('include/user.class.php');
$u = new user();

// Get our base functions and class
require 'include/citrus_base.php';
$base = new citrus_base();

if ($base->input['submit'] == 'Login') {
	// check the user login information
	$u->user_login($base->input['user_name'],$base->input['password']);
	
	// redirect back to this page to set any cookies properly
	header("Location: index.php?load=search&type=base");
}

//echo '<pre>';
//var_dump($_SERVER);
//die;

if ($u->user_isloggedin()) {
	session_start();

	// print the html for the top of pages
	echo "<html>
	<head>
	<title>CITRUSDB</title>
	<LINK href=\"citrus.css\" type=text/css rel=STYLESHEET>
	<script language=\"JavaScript\">
	function h(oR) {
		oR.style.backgroundColor='ffdd77';
	}	
	function deh(oR) {
		oR.style.backgroundColor='ddddee';
	}
	function dehnew(oR) {
		oR.style.backgroundColor='ddeeff';
	}
	</script>
	<script language=\"JavaScript\" src=\"include/md5.js\"></script>
	</head>
	<body marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 bgcolor=\"#ffffff\">";
	
	
	// define this constant
	define('INDEX_CITRUS',1);

	$user =  $u->user_getname();

	//GET Variables (sorta like the old way for now)
	$load = $base->input['load'];
	$type = $base->input['type'];
	$edit = $base->input['edit'];
	$create = $base->input['create'];
	$delete = $base->input['delete'];
	
	if (!$type) { 
		$load = "search"; 
		$type="base";	
	}
	
	switch ($type)
	{
	case 'fs':  // full screen
		// Check if the file is inside the path_to_citrus
		$filepath = "$path_to_citrus/$load.php";
		if (file_exists($filepath)) {
			include($load.'.php');
		}
	break; // end full screen
	
	case 'module':	// show a module
		//SESSION Variables
		if (!$_SESSION['account_number']) {
			$_SESSION['account_number'] = 1;	
		}
		
		$account_number = $_SESSION['account_number'];
		
		$time_start = getmicrotime();
		
		// select name and company from the customer table
		$query = "SELECT name,company FROM customer WHERE account_number = $account_number";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Name Query Failed");
		$myresult = $result->fields;
		$acct_name = $myresult['name'];
		$acct_company = $myresult['company'];
	
		// print the left side bar 
		
		echo '<table height=100% width=100% cellpadding=10 cellspacing=0 border=0>
		<td valign=top bgcolor="#eeeeee">
		<img src="images/citrus-logo.png">
		<p align=center class="smalltext">';
		echo "<b>Account Num:&nbsp; $account_number &nbsp; </b><br>";
		echo "$acct_name<br>";
		echo "$acct_company<br></p><p align=right>";
		
		include('modules.php');
		
		print "</p></td><td width=100% valign=top><table cellpadding=0 cellspacing=0 border=0 width=100%><td>";
		
		include('header.php');  
		
		print "</td><tr><td>";
		
		// show the module
		// Check if the file is inside the path_to_citrus
		$filepath = "$path_to_citrus/modules/$load/index.php";
		if (file_exists($filepath)) {
			include('modules/'.$load.'/index.php');
		}					

		print "</td><tr><td><br>";

        	include('footer.php'); 
		
		print "<br>";
		$time_end = getmicrotime();
		$time = $time_end - $time_start;
                
		echo "&nbsp; &nbsp; Completed in $time seconds";
	
		print "</td></table></td></table></body></html>";
	break; // end module
	
	case 'base': // base functions
	
		//SESSION Variables
		if (!$_SESSION['account_number']) {
			$_SESSION['account_number'] = 1;	
		}
		
		$account_number = $_SESSION['account_number'];
		
		$time_start = getmicrotime();
		
		// select name and company from the customer table
		$query = "SELECT name,company FROM customer WHERE account_number = $account_number";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Name Query Failed");
		$myresult = $result->fields;	
		$acct_name = $myresult['name'];
		$acct_company = $myresult['company'];
	
		// print the left side bar 
		
		echo '<table height=100% width=100% cellpadding=10 cellspacing=0 border=0>
		<td valign=top bgcolor="#eeeeee">
		<img src="images/citrus-logo.png">
		<p align=center class="smalltext">';
		echo "<b>Account Num:&nbsp; $account_number &nbsp; </b><br>";
		echo "$acct_name<br>";
		echo "$acct_company<br></p><p align=right>";
		
		include('modules.php');
		
		print "</p></td><td width=100% valign=top><table cellpadding=0 cellspacing=0 border=0 width=100%><td>";
		
		include('header.php');  
		
		print "</td><tr><td>";
		
		// show base function
		// Load the files wrapped by buttons
		// Check if the file is inside the path_to_citrus
		$filepath = "$path_to_citrus/$load.php";
		if (file_exists($filepath)) {
			include($load.'.php');
		}	

		print "</td><tr><td><br>";

		print "<br>";
		$time_end = getmicrotime();
		$time = $time_end - $time_start;
                
		echo "&nbsp; &nbsp; Completed in $time seconds";
	
		print "</td></table></td></table></body></html>";
	break; // end base
	
	case 'tools': // show in tools function
		// Check if the file is inside the path_to_citrus
		$filepath = "$path_to_citrus/tools/index.php";
		if (file_exists($filepath)) {
			include('tools/index.php');
		}
	break; // end tools
	
	}
}
else // show the login screen
{
echo '<html>
<head>
<title>CITRUSDB</title>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
<script language=\"JavaScript\">
function h(oR) {
	oR.style.backgroundColor=\'ffdd77\';
}	
function deh(oR) {
	oR.style.backgroundColor=\'ddddee\';
}
function dehnew(oR) {
	oR.style.backgroundColor=\'ddeeff\';
}
</script>
<script language="JavaScript" src="include/md5.js"></script>
</head>
<body marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 bgcolor="#ffffff">
	<div id=horizon>
		<div id=loginbox>
	<center><table><td valign=top><img src="images/citrus-logo.png">
	<P>
	Enter your user name and password.
	<P>
	<FORM ACTION="index.php" METHOD="POST">
	<B>User Name:</B><BR>
	<INPUT TYPE="TEXT" NAME="user_name" VALUE="" SIZE="15" MAXLENGTH="15">
	<P>
	<B>Password:</B><BR>
	<INPUT TYPE="password" NAME="password" VALUE="" SIZE="15" MAXLENGTH="32">
	<P>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Login"  onclick="password.value = calcMD5(password.value)" class=smallbutton>
	</FORM>
	<P></td></table></div></div></body></html>';
}

?>
