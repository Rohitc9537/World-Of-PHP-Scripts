<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information -->
<table cellpadding=0 cellspacing=0 border=0 width=720 height=100%>
<td>
        <table cellpadding=5 cellspacing=0 border=0>
	<?php
        print "<td bgcolor=\"#eeeedd\" width=100 align=center><b><a href=\"index.php?load=customer_history&type=fs&account_number=$account_number\" target=\"historyframe\">Customer</a></b></td>";
	echo '<td>&nbsp;</td>';
        print "<td bgcolor=\"#ddeeee\" width=100 align=center><b><a href=\"index.php?load=billing_history&type=fs&account_number=$account_number\" target=\"historyframe\">Billing</a></b></td>";
	echo '<td>&nbsp;</td>';
	print "<td bgcolor=\"#eedddd\" width=100 align=center><b><a href=\"index.php?load=payment_history&type=fs&account_number=$account_number\" target=\"historyframe\">Payments</a></b></td>";
	?>
        <td>&nbsp;</td>
        </table>
</td><tr>
<td width="720" height="160" bgcolor="#eeeedd" valign=top>
	<table border=0 cellpadding=0 cellspacing=0><td>
	<?php
	print "<iframe name=\"historyframe\" src=\"index.php?load=customer_history&type=fs&account_number=$account_number\" width=720 height=160 frameborder=0 marginwidth=0 marginheight=1 scrolling=yes></iframe>";
	?>
	</td></table>
</td>
</table>
