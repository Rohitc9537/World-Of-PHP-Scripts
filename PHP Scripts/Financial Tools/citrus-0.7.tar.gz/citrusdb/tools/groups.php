<html>
<body bgcolor="#ffffff">
<h3>Update Database Groups</h3>
<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}


// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

echo '[ <a href="index.php?load=newgroup&type=tools">Add New Group/Member</a> ]';

print "<p><table cellpadding=5 cellspacing=1><tr bgcolor=\"#eeeeee\"><td><b>Group Name</b></td><td><b>Member Name</b></td><td></td><tr bgcolor=\"#eeeeee\">";

        // get the list of users from the table
        $query = "SELECT * FROM groups ORDER BY groupname";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$myid = $myresult['id'];
		$mygroupname = $myresult['groupname'];
		$mymembername = $myresult['groupmember'];

		print "<td>$mygroupname</td><td>$mymembername</td><td><a href=\"index.php?load=deletegroup&type=tools&gid=$myid\">Delete</a></td><tr bgcolor=\"#eeeeee\">\n";
	}
?>
</table>
</body>
</html>
