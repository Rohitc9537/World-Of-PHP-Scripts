<html>
<body bgcolor="#ffffff">
<LINK href="../citrus.css" type=text/css rel=STYLESHEET>

<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$batchid = $base->input['batchid'];
$mydate = $base->input['mydate']; // maybe just make this date equal to today?


if ($submit) {

	//
	// go through a list of billing_id's that are to be billed today
	//

	$query = "SELECT DISTINCT billing_id FROM billing_details 
		WHERE creation_date = CURRENT_DATE AND batch = '$batchid'";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$distinctresult = $DB->Execute($query) or die ("Query Failed");
	
	//
	// make a new billing_history record for each billing id group 
	// use the billing_history_id as the invoice number
	//

	while ($myresult = $distinctresult->FetchRow())
        {
        	$mybilling_id = $myresult['billing_id'];
		$query = "INSERT INTO billing_history (billing_date, created_by, record_type, billing_type, billing_id) 
			VALUES (CURRENT_DATE,'$user','bill','invoice','$mybilling_id')";
		$historyresult = $DB->Execute($query) or die ("Query Failed");
		
		//
		// set the invoice number for billing_details that have the 
		// corresponding billing_id and haven't been assigned an invoice
		// number yet
		//

		$myinsertid = $DB->Insert_ID();
		$invoice_number=$myinsertid;
		$query = "UPDATE billing_details SET invoice_number = '$invoice_number' 
			WHERE billing_id = '$mybilling_id' AND invoice_number IS NULL";
		$invnumresult = $DB->Execute($query) or die ("Query Failed");
			
		//
		// get the data for the service charges from billing_details and 
		// what services they have
		//

		$query = "SELECT d.billing_id d_billing_id, d.creation_date d_creation_date, d.user_services_id d_user_services_id,
	        d.invoice_number d_invoice_number, d.paid_amount d_paid_amount, d.billed_amount d_billed_amount, 
		d.taxed_services_id d_taxed_services_id, 
		u.id u_id, u.account_number u_account_number, 
		m.id m_id, m.service_description m_description, m.options_table m_options_table, 
		ts.id ts_id, ts.master_services_id ts_master_services_id, ts.tax_rate_id ts_tax_rate_id, 
		tr.id tr_id, tr.description tr_description  
	        FROM billing_details d
	        LEFT JOIN user_services u ON d.user_services_id = u.id
	        LEFT JOIN master_services m ON u.master_service_id = m.id 
		LEFT JOIN taxed_services ts ON d.taxed_services_id = ts.id 
		LEFT JOIN tax_rates tr ON ts.tax_rate_id = tr.id 
	        WHERE d.billing_id = $mybilling_id AND d.paid_amount < d.billed_amount 
		ORDER BY d.taxed_services_id"; 
		// this billing id and not already paid and put taxes on bottom of list
        
	        $invoiceresult = $DB->Execute($query) or die ("Query Failed"); // used to show the invoice
		$totalresult = $DB->Execute($query) or die ("Query Failed");  // used to add up the total charges
		
		//
		// get the data for the billing name and address and stuff from 
		// the billing table
		//

		$query = "SELECT b.name b_name, b.company b_company, b.street b_street, 
			b.city b_city, b.state b_state, b.zip b_zip, b.notes b_notes, 
			b.account_number b_account_number, b.from_date b_from_date, 
			b.to_date b_to_date, b.payment_due_date b_payment_due_date, 
			b.billing_type b_billing_type, bt.id bt_id, bt.name bt_name 
			FROM billing b  
			LEFT JOIN billing_types bt 
			ON b.billing_type = bt.id 
			WHERE b.id = $mybilling_id";
		$billingresult = $DB->Execute($query) or die ("Query Failed");

		$myresult = $billingresult->fields;
		$billing_name = $myresult['b_name'];
		$billing_company = $myresult['b_company'];
		$billing_street = $myresult['b_street'];
		$billing_city = $myresult['b_city'];
		$billing_state = $myresult['b_state'];
		$billing_zip = $myresult['b_zip'];
		$billing_acctnum = $myresult['b_account_number'];
		$billing_fromdate = $myresult['b_from_date'];
		$billing_todate = $myresult['b_to_date'];
		$billing_payment_due_date = $myresult['b_payment_due_date'];
		$billing_type = $myresult['bt_name']; // use to join with billing_types table
		$billing_notes = $myresult['b_notes'];

		//
		// get the data for our company to be printed on the bill
		//

                $query = "SELECT * FROM general";
                $generalresult = $DB->Execute($query) or die ("Query Failed");

		$myresult = $generalresult->fields;
                $org_name = $myresult['org_name'];
                $org_street = $myresult['org_street'];
                $org_city = $myresult['org_city'];
                $org_state = $myresult['org_state'];
                $org_zip = $myresult['org_zip'];
                $phone_billing = $myresult['phone_billing'];
                $email_billing = $myresult['email_billing'];

		$invoicetotal = 0;
		$mydate = date("Y-m-d");

		//
		// get the invoicetotal
		//

		while ($myresult = $totalresult->FetchRow())	
                {
                        $billed_amount = $myresult['d_billed_amount'];
                        $invoicetotal = $billed_amount + $invoicetotal;
                }
		$precisetotal = sprintf("%.2f", $invoicetotal);

		//
		// start printing the page now
		//

		print "<div style=\"page: auto\">";

		print "<div style=\"position: relative; border: solid 0px; left: 0px; top: 0px; width: 50%;\">
			<img src=\"images/companylogo.png\"></div>
			<div style=\"position: relative; border: solid 0px; left: 75%; top: -45px; width: 20%;\">
			<h3>Invoice</h3></div>";

		print "<div  style=\"position: relative; left: 0px; top: -10px; width: 30%; border: solid 0px;\">Invoice For:
                        <p>$billing_name
                        <br>$billing_company
                        <br>$billing_street
                        <br>$billing_city &nbsp; $billing_state &nbsp; $billing_zip</div>";
                print "<div style=\"position: relative; left: 50%; top: -116px; width: 40%; border: solid 1px; padding: 10px;\">";
                print "<div>Invoice Number: $invoice_number<br>";
		print "$billing_type<br>";
                print "Date: $mydate<br>";
                print "Account Number: $billing_acctnum<br>";
                print "From: $billing_fromdate  &nbsp;&nbsp; To: $billing_todate  <br>";
                print "Payment Due By: $billing_payment_due_date<br>";
		print "<br>";
		print "</div><div style=\"position: relative; border: solid 1px; padding: 5px;\">Amount Enclosed:</div>";
                print "</div>";

		print "<div  style=\"position: relative; left: 0px; top: -40px; width: 50%; border: solid 0px;\">";
		print "Invoice Number: $invoice_number<br>";
		print "$billing_type<br>";
                print "Date: $mydate<br>Billing ID: $mybilling_id<br>";
                print "Account Number: $billing_acctnum<br>";
                print "From: $billing_fromdate  To: $billing_todate  <br>";
                print "Payment Due By: $billing_payment_due_date<br>";
                print "</div>";
		print "<div style=\"position: relative; left: 65%; top: -116px; width: 200px; border: solid 0px;\">
		$org_name<br>
		$org_street<br>
		$org_city, $org_state $org_zip<br>
		$phone_billing<br>
		$email_billing<br>
		</div>";
                print "<div style=\"position: relative; left: 0px; top: -100px; width=100%; border: solid 1px;\">";
		print "<br><table width=100%>";
                print "<td><b>Description</b></td><td><b>Details</b></td><td><b>Amount</b></td><tr>";

		//
		// Print out the line items on the invoice
		//
		
		// initialize past amounts 
		$pastdue = 0;
		$new_charges = 0;
		$tax_due = 0;
		
		while ($myresult = $invoiceresult->FetchRow())	
        	{
		$options_table = $myresult['m_options_table'];
		$user_services_id = $myresult['d_user_services_id'];
		$currinvoicenumber = $myresult['d_invoice_number'];

		if ($options_table <> '') {
			$query = "SELECT * FROM $options_table WHERE user_services = '$user_services_id'";
			$DB->SetFetchMode(ADODB_FETCH_NUM);
			$optionsresult = $DB->Execute($query) or die ("Options Result Query Failed");
                	$myoptions = $optionsresult->fields;
                	$optiondetails = $myoptions[2];
		} else {
			// it's a tax or service without options
			$optiondetails = "";
		}
                
                $billing_id = $myresult['d_billing_id'];
                $creation_date = $myresult['d_creation_date'];
                $service = $myresult['m_description'];
		$taxdescription = $myresult['tr_description'];
                $billed_amount = $myresult['d_billed_amount'];  

				if ($currinvoicenumber == $invoice_number) {
					// New Charges
					$billed_amount = sprintf("%.2f", $billed_amount);
					print "<td>$service $taxdescription</td><td>$optiondetails</td><td>$billed_amount</td><tr>";
					$new_charges = $new_charges + $billed_amount;
					// Total New Taxes
					if ($taxdescription <> NULL) { 
						$tax_due = $tax_due + $billed_amount;
					}
				} else {
					// Past Due Charges
					//print "<td><i>$service $taxdescription (past due)</i></td>";
					$pastdue = $pastdue + $billed_amount;
				}
        	}
        	
      // figure out total due and give all numbers 2 decimal places
      $total_due = $precisetotal;
      $new_charges = sprintf("%.2f", $new_charges);
      $pastdue = sprintf("%.2f", $pastdue);
      $tax_due = sprintf("%.2f", $tax_due);
      $total_due = sprintf("%.2f", $total_due);
	
		print "</table></div>";
		print "<div style=\"position: relative; bottom: 10%; left: 0px; width: 30%;\">";
		print "<b>Notes:<b><br> $billing_notes </div>";
		print "<div style=\"position: relative; bottom: 10%; left: 80%; width: 40%;\">
			New Charges: $new_charges<br>
			Past Due: $pastdue<br>
			Total Tax: $tax_due<br>
			Total Due: $total_due</b></div>";

		//
		// put a record in the billing_history to note the invoice total, tax, and details
		//

		$query = "UPDATE billing_history 
			  SET from_date = '$billing_fromdate',
			  to_date = '$billing_todate',
			  payment_due_date = '$billing_payment_to_date',
			  new_charges = '$new_charges',
			  past_due = '$pastdue',
			  late_fee = '0',
			  tax_due = '$tax_due',
			  total_due = '$total_due',
			  notes = '$billing_notes' 
			  WHERE id = '$invoice_number'";
                $historyresult = $DB->Execute($query) or die ("History Result Query Failed");

		//
		// update the Next Billing Date to whatever the billing type dictates +1 +2 +6 etc.
                // get the current billing type
		//

                $query = "SELECT b.billing_type b_billing_type, b.next_billing_date b_next_billing_date, 
                        b.from_date b_from_date, b.to_date b_to_date, t.id t_id, t.frequency t_frequency
                        FROM billing b
                        LEFT JOIN billing_types t ON b.billing_type = t.id
                        WHERE b.id = $mybilling_id";
                $DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Billing Result Query Failed");
		$billingresult = $result->fields;

                $mybillingdate = $billingresult['b_next_billing_date'];
		$myfromdate = $billingresult['b_from_date'];
		$mytodate = $billingresult['b_to_date'];
                $mybillingfreq = $billingresult['t_frequency'];

		// to get the to_date, need to double the frequency added
		$doublefreq = $mybillingfreq * 2;	

		//
                // insert the new next_billing_date
		// and a new from_date and to_date and payment_due_date based on from_date
		//

                $query = "UPDATE billing
                          SET next_billing_date = DATE_ADD('$mybillingdate', INTERVAL '$mybillingfreq' MONTH),
				from_date = DATE_ADD('$myfromdate', INTERVAL '$mybillingfreq' MONTH),
				to_date = DATE_ADD('$myfromdate', INTERVAL '$doublefreq' MONTH),
				payment_due_date = DATE_ADD('$myfromdate', INTERVAL '$mybillingfreq' MONTH)
                          WHERE id = '$mybilling_id'";
                $updateresult = $DB->Execute($query) or die ("Update Billing Query Failed");

		print "</div>";
		print "<DIV style=\"page-break-after:always\"></DIV>"; // puts in a page-break

        } // end while

}

?>
</body>
</html>







