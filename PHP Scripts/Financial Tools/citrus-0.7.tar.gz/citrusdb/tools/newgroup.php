<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET & POST Variables
$feedback = $_POST['feedback'];
$submit = $base->input['submit'];
$membername = $base->input['membername'];
$groupname = $base->input['groupname'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
	// insert groupname and username into the groups table
	$query = "INSERT INTO groups (groupname,groupmember) VALUES ('$groupname','$membername')";
	$result = $DB->Execute($query) or die ("Query Failed");
	print "<h3>Groups Updated</h3>";
}

echo '<H3>Add New Database Group/Member</H3>
	<P>
	<FORM ACTION="index.php" METHOD="GET">
	<B>Add Member:</B><BR>
	<SELECT NAME="membername">';
	
	$query = "SELECT * FROM user";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$myusername = $myresult['username'];
		print "<option>$myusername</option>";
	}	

echo '</SELECT><P>
	<B>To Group Named:</B><BR>
        <INPUT TYPE="TEXT" NAME="groupname" VALUE="" SIZE="20" MAXLENGTH="32">
        <P>
	<input type=hidden name=load value=newgroup>
	<input type=hidden name=type value=tools>	
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Add">
	</FORM>';


?>



