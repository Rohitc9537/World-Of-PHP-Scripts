<html>
<body bgcolor="#ffffff">
<h3>Invoice Maintenance</h3>
<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// make sure the user is in a group that is allowed to run this

//
//GET Variables
//
$submit = $base->input['submit'];
$billingid = $base->input['billingid'];
$remove = $base->input['remove'];
$delete = $base->input['delete'];
$details = $base->input['details'];
$invoicenum = $base->input['invoicenum'];

if ($delete) {

	//
	// Delete the invoice, delete from billing history where id = $invoicenum
	//
	$query = "DELETE FROM billing_history WHERE id = $invoicenum";
        $result = $DB->Execute($query) or die ("Query Failed");
	
	//
	// delete from billing_details where invoice_number = $invoicenum
	//
	$query = "DELETE FROM billing_details WHERE invoice_number = $invoicenum";                                          
        $result = $DB->Execute($query) or die ("Query Failed");

	print "Deleted invoice number $invoicenum";
}
else if ($remove) {

	//
	// Ask if they want to remove the invoice, print the yes/no form
	//
	print "<b>Are you sure you want to remove invoice number $invoicenum?</b>";

	print "<table cellpadding=15 cellspacing=0 border=0 width=720><td align=right width=360>";
	print "<form style=\"margin-bottom:0;\" action=\"index.php\">";
	print "<input type=hidden name=load value=invmaint>";
	print "<input type=hidden name=type value=tools>";
	print "<input type=hidden name=invoicenum value=$invoicenum>";
    print "<input type=hidden name=delete value=on>";
    print "<input name=deletenow type=submit value=\"  Yes  \" class=smallbutton></form></td>";
    print "<td align=left width=360><form style=\"margin-bottom:0;\" action=\"index.php\">";
    print "<input type=hidden name=type value=tools>";
    print "<input name=done type=submit value=\"  No  \" class=smallbutton>";
    print "<input type=hidden name=load value=invmaint>";
    print "</form></td></table>";

}

else if ($submit) {

	//
	// Show the invoices that belong to that billing id:
	//
	$query = "SELECT h.id h_id, h.billing_date h_billing_date, h.from_date 
	h_from_date, h.to_date h_to_date, h.payment_due_date h_due_date, 
	h.new_charges h_new_charges, h.total_due h_total_due, h.billing_type h_billing_type, 
	b.name b_name, b.company b_company
	FROM billing_history h
        LEFT JOIN billing b ON h.billing_id = b.id
        WHERE h.billing_id  = '$billingid'";

	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<table cellpadding=5 cellspacing=1><tr bgcolor=\"#dddddd\">";
	print "<td>Invoice Number</td>
	<td>Billing Date</td>
	<td>Name</td>
	<td>Company</td>
	<td>From</td>
	<td>To</td>
	<td>Due Date</td>
	<td>New Charges</td>
	<td>Total Due</td>
	<td>Billing Type</td>
	<td></td><td></td>";

	while ($myresult = $result->FetchRow())
	{
		$invoice_number = $myresult['h_id'];
		$billing_date = $myresult['h_billing_date'];
		$name = $myresult['b_name'];
		$company = $myresult['b_company'];
		$from_date = $myresult['h_from_date'];
		$to_date = $myresult['h_to_date'];
		$due_date = $myresult['h_due_date'];
		$new_charges = $myresult['h_new_charges'];		
		$total_due = $myresult['h_total_due'];
		$billing_type = $myresult['h_billing_type'];


		print "<tr bgcolor=\"#eeeeee\">
		<td>$invoice_number</td>
		<td>$billing_date</td>
		<td>$name</td>
		<td>$company</td>
		<td>$from_date</td>
		<td>$to_date</td>
		<td>$due_date</td>
		<td>$new_charges</td>
		<td>$total_due</td>
		<td>$billing_type</td>
		<td>[<a href=\"index.php?load=printpreviousinvoice&billingid=$billingid&invoiceid=$invoice_number&details=on&type=tools&submit=on\">Details</a>]</td>
		<td>[<a href=\"index.php?load=invmaint&invoicenum=$invoice_number&remove=on&type=tools&submit=on\">Remove</a>]</td><tr>";
		
		if (($details) and ($invoicenum == $invoice_number)) {
        	
        	//
        	// show the details for a specified invoice ID
			//
        	$query = "SELECT d.id d_id, d.billed_amount d_billed_amount, d.paid_amount d_paid_amount, d.batch d_batch,
                	u.master_service_id, m.id m_id, m.service_description m_service
        	FROM billing_details d
        	LEFT JOIN user_services u ON d.user_services_id = u.id
        	LEFT JOIN master_services m ON u.master_service_id = m.id
        	WHERE d.invoice_number  = '$invoicenum'";

		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
        	$dresult = $DB->Execute($query) or die ("Query Failed");

        	print "<tr bgcolor=\"#eeeeee\"><td colspan=10><center><b>New Charges on invoice number $invoicenum</b></center></td><tr>";

        	while ($detailsresult = $dresult->FetchRow())
        	{
                	$service = $detailsresult['m_service'];
                	$billed_amount = $detailsresult['d_billed_amount'];

                	print "<tr bgcolor=\"#eeeeee\"><td colspan=10><center>$service &nbsp; $billed_amount</center></td><tr>";
        	}

	}


	}

	print "</table>";
	
	print "Should I also show any past due services here independant of invoice";

}
else {
//
// ask for the billing date that they want to invoice
//
echo '<FORM ACTION="index.php" METHOD="GET">
	<input type=hidden name=load value=invmaint>
	<input type=hidden name=type value=tools>
	<table>
	<td>Enter Billing ID:</td><td><input type=text name=billingid></td><tr>
	<td></td><td><INPUT TYPE="SUBMIT" NAME="submit" value="submit"></td>
	</form>';
}

?>
</body>
</html>
