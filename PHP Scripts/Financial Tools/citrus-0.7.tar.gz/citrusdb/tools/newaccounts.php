<html>
<body bgcolor="#ffffff">
<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}


// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['manager'] == 'n') {
	echo 'You must have manager privileges to use this feature<br>';
        exit; 
}

        // get the list of customers that signed up for new services today

        $query = "SELECT u.id u_id, u.account_number u_ac, u.master_service_id u_master_service_id, u.billing_id u_bid, 
	u.start_datetime u_start, u.removed u_rem, u.usage_multiple u_usage, m.service_description m_service_description, 
        m.id m_id, m.pricerate m_pricerate, m.frequency m_freq, m.tax_pricerate m_taxpricerate
        FROM user_services u 
	LEFT JOIN master_services m ON m.id = u.master_service_id WHERE to_days(now()) = to_days(u.start_datetime)";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

	// print heading	
	print "<h3>Today's New Accounts</h3><table cellpadding=10>";
	print "<td><b>Account ID</b></td><td><b>User Service ID</b></td><td><b>Description</b></td><tr bgcolor=\"#eeeeee\">";

	// loop through results and print out each
	while ($myresult = $result->FetchRow())
        {
        $user_services_id = $myresult['u_id'];
	$service_description = $myresult['m_service_description'];
	$account_number = $myresult['u_ac'];
	
	
        print "<td>$account_number</td><td>$user_services_id</td><td>$service_description</td><tr bgcolor=\"#eeeeee\">\n";
        }

	// end table listing
        print "</table><p>";


?>
</body>
</html>







