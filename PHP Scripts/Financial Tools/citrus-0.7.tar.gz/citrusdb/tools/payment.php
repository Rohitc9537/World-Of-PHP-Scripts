<h3>Enter Payments (check, eft, or cash)</h3>
<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>
// read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$account_num = $base->input['account_num'];
$billing_id = $base->input['billing_id'];
$amount = $base->input['amount'];
$payment_type = $base->input['payment_type'];
$invoice_number = $base->input['invoice_number'];

if ($submit) {

	// update the billing_details for things that still need to be paid up
	// if the invoice number is empty do the query for all upaid items, if the
	// invoice number isn't empty do it based on invoice number items not 
	// all of the things for that account
	
	//$DB->debug = true;

	/*--------------------------------------------------------------------*/
	// enter payments by invoice number	
	/*--------------------------------------------------------------------*/
	if ($invoice_number > 0) {
		$query = "SELECT * FROM billing_details 
		WHERE paid_amount < billed_amount AND invoice_number = $invoice_number";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Query Failed");
		$invoiceresult = $DB->Execute($query) or die ("Query Failed");

		// update values with missing information
		$myresult = $invoiceresult->fields;
		$billing_id = $myresult['billing_id'];
		
		// insert info into the payment history
		$query = "INSERT INTO payment_history (creation_date, billing_id, 
			billing_amount, status, payment_type, invoice_number) 
			VALUES (CURRENT_DATE,'$billing_id','$amount','paid',
			'$payment_type','$invoice_number')";
		$paymentresult = $DB->Execute($query) or die ("Query Failed");
	/*--------------------------------------------------------------------*/
	// enter payments by account number
	/*--------------------------------------------------------------------*/
	} elseif ($account_num > 0) {
		$query = "SELECT * FROM billing_details bd
		LEFT JOIN billing bi ON bd.billing_id = bi.id
		LEFT JOIN customer cu ON bi.id = cu.default_billing_id
		WHERE bd.paid_amount < bd.billed_amount AND cu.account_number = $account_num";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Query Failed");
		$accountresult = $DB->Execute($query) or die ("Query Failed");
		
		// update values with missing information
		$myresult = $accountresult->fields;
		$billing_id = $myresult['billing_id'];
		
		// insert info into the payment history
		$query = "INSERT INTO payment_history (creation_date, billing_id, 
			billing_amount, status, payment_type, invoice_number) 
			VALUES (CURRENT_DATE,'$billing_id','$amount','paid',
			'$payment_type','$invoice_number')";
		$paymentresult = $DB->Execute($query) or die ("Query Failed");

	/*--------------------------------------------------------------------*/
	// enter payments by billing id
	/*--------------------------------------------------------------------*/
	} else {
		$query = "SELECT * FROM billing_details 
		WHERE paid_amount < billed_amount AND billing_id = $billing_id";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$result = $DB->Execute($query) or die ("Query Failed");
		
		// insert info into the payment history
		$query = "INSERT INTO payment_history (creation_date, billing_id, 
			billing_amount, status, payment_type, invoice_number) 
			VALUES (CURRENT_DATE,'$billing_id','$amount','paid',
			'$payment_type','$invoice_number')";
		$paymentresult = $DB->Execute($query) or die ("Query Failed");

	}

	while (($myresult = $result->FetchRow()) and ($amount > 0)) 
	{
		$id = $myresult['id'];
		$paid_amount = $myresult['paid_amount'];
		$billed_amount = $myresult['billed_amount'];
		
		// calculate amount owed
		$owed = $billed_amount - $paid_amount;
		
		if ($amount >= $owed) {
			$amount = $amount - $owed;
			$fillamount = $owed + $paid_amount;
			$query = "UPDATE billing_details 
				SET paid_amount = '$fillamount' 
				WHERE id = $id";
			$greaterthanresult = $DB->Execute($query) or die ("Query Failed");
		} else { 
		// amount is  less than owed
			$available = $amount;
			$amount = 0;
			$fillamount = $available + $paid_amount;
			$query = "UPDATE billing_details 
				SET paid_amount = '$fillamount' 
				WHERE id = $id";
			$lessthenresult = $DB->Execute($query) or die ("Query Failed");
		}
	}	

        print "<h3>Payments Saved, $amount left over</h3>";

}

/*----------------------------------------------------------------------------*/
// print the by billing id form
/*----------------------------------------------------------------------------*/
echo '<FORM ACTION="index.php" METHOD="GET">
        <input type=hidden name=load value=payment>
	<input type=hidden name=type value=tools>
	Enter one of these three values:
	<table><td>
	<b>Account Number:</b></td><td>
	<input type="text" name="account_num" size="20" maxlength="32">
	(apply to default billing id)
	</td><tr><td>
	<B>Billing ID:</B></td><td>
	<INPUT TYPE="TEXT" NAME="billing_id" SIZE="20" MAXLENGTH="32">
	(apply to specific billing id)
	</td><tr><td>
	<B>Invoice Number:</B></td><td>
	<INPUT TYPE="TEXT" NAME="invoice_number" SIZE="20" MAXLENGTH="32">
	(apply to specific invoice)
	</td><tr><td>
	&nbsp;
	</td><tr><td>
	<B>Payment Amount:</B></td><td>
        <INPUT TYPE="TEXT" NAME="amount" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Payment Type</B></td><td>
	<select name="payment_type">
	<option>check</option>
	<option>cash</option>
	<option>eft</option>
	</select>
        </td><tr><td>
	</td><td>
	<INPUT TYPE="SUBMIT" NAME="submit" value="Submit">
	</td></table>
	</FORM>';
?>







