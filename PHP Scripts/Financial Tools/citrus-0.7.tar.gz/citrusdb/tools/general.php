<html>
<body bgcolor="#ffffff">
<h3>General Configuration</h3>
<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$org_name = $base->input['org_name'];
$org_street = $base->input['org_street'];
$org_city = $base->input['org_city'];
$org_state = $base->input['org_state'];
$org_country = $base->input['org_country'];
$org_zip = $base->input['org_zip'];
$phone_sales = $base->input['phone_sales'];
$email_sales = $base->input['email_sales'];
$phone_billing = $base->input['phone_billing'];
$email_billing = $base->input['email_billing'];
$phone_custsvc = $base->input['phone_custsvc'];
$email_custsvc = $base->input['email_custsvc'];
$billingdate_rollover_time = $base->input['billingdate_rollover_time'];
$path_to_ccfile = $base->input['path_to_ccfile'];
$default_group = $base->input['default_group'];
$ccexportvarorder = $base->input['ccexportvarorder'];
$pastdue_days1 = $base->input['pastdue_days1'];
$pastdue_days2 = $base->input['pastdue_days2'];
$pastdue_days3 = $base->input['pastdue_days3'];

// convert the $ccexportvarorder &#036; dollar signs back to actual dollar signs
$ccexportvarorder = str_replace( "&#036;"           , "$"        , $ccexportvarorder );


/*
ccexportvarorder is a list of available variables that can be included in the export from billing

WILL ALWAYS START WITH CREDIT, or CHARGE automatically, to mark type of charge

$user (the database user)
$batchid
$mybilling_id (the billing id being run)
$invoice_number
$billing_name
$billing_company
$billing_street
$billing_city
$billing_state
$billing_zip
$billing_acctnum
$billing_ccnum
$billing_ccexp
$billing_fromdate
$billing_todate
$billing_payment_due_date
$mydate (Y-m-d date format)
$abstotal (absolute value of total, if precise total is negative it with export with CREDIT marked)

These will become part of the newline variable in the exportccsave.php file
*/


// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
	echo 'You must have admin privileges to use this feature<br>';
        exit; 
}

if ($submit) {
// save general information
      $query = "UPDATE general
      SET org_name = '$org_name',
      org_street = '$org_street',
      org_city = '$org_city',
      org_state = '$org_state',
      org_country = '$org_country',
      org_zip = '$org_zip',
      phone_sales = '$phone_sales',
      email_sales = '$email_sales',
      phone_billing = '$phone_billing',
      email_billing = '$email_billing',
      phone_custsvc = '$phone_custsvc',
      email_custsvc = '$email_custsvc',
      billingdate_rollover_time = '$billingdate_rollover_time',
      path_to_ccfile = '$path_to_ccfile',
      default_group = '$default_group',
      ccexportvarorder = '$ccexportvarorder',
      pastdue_days1 = '$pastdue_days1',
      pastdue_days2 = '$pastdue_days2',
      pastdue_days3 = '$pastdue_days3' 
      WHERE id = 1";
      $result = $DB->Execute($query) or die ("Query Failed");

        print "<h3>Changes Saved<h3>";
        //print "<script language=\"JavaScript\">window.location.href = \"tools/general.php\";</script>";

}

        // get the variables out of the id 1 general configuration table
        $query = "SELECT * FROM general WHERE id = 1";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	$myresult = $result->fields;
        $org_name = $myresult['org_name'];
        $org_street = $myresult['org_street'];
        $org_city = $myresult['org_city'];
        $org_state = $myresult['org_state'];
        $org_zip = $myresult['org_zip'];
        $org_country = $myresult['org_country'];
        $phone_sales = $myresult['phone_sales'];
        $email_sales = $myresult['email_sales'];
        $phone_billing = $myresult['phone_billing'];
        $email_billing = $myresult['email_billing'];
        $phone_custsvc = $myresult['phone_custsvc'];
        $email_custsvc = $myresult['email_custsvc'];
	$billingdate_rollover_time = $myresult['billingdate_rollover_time'];
	$path_to_ccfile = $myresult['path_to_ccfile'];
	$default_group = $myresult['default_group'];
	$ccexportvarorder = $myresult['ccexportvarorder'];
	$pastdue_days1 = $myresult['pastdue_days1'];
	$pastdue_days2 = $myresult['pastdue_days2'];
	$pastdue_days3 = $myresult['pastdue_days3'];

	// print the general variables in a form
	
echo '<FORM ACTION="index.php" METHOD="GET">
	<input type=hidden name=load value=general>
	<input type=hidden name=type value=tools>
	<table><td>
	<B>Organization Name:</B></td><td>
	<INPUT TYPE="TEXT" NAME="org_name" VALUE="'.$org_name.'" SIZE="20" MAXLENGTH="32">
	</td><tr><td>
	<B>Street Address:</B></td><td>
        <INPUT TYPE="TEXT" NAME="org_street" VALUE="'.$org_street.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>City:</B></td><td>
        <INPUT TYPE="TEXT" NAME="org_city" VALUE="'.$org_city.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>State:</B></td><td>
        <INPUT TYPE="TEXT" NAME="org_state" VALUE="'.$org_state.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Zip:</B></td><td>
        <INPUT TYPE="TEXT" NAME="org_zip" VALUE="'.$org_zip.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Country:</B></td><td>
        <INPUT TYPE="TEXT" NAME="org_country" VALUE="'.$org_country.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Sales Phone:</B></td><td>
        <INPUT TYPE="TEXT" NAME="phone_sales" VALUE="'.$phone_sales.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Sales Email:</B></td><td>
        <INPUT TYPE="TEXT" NAME="email_sales" VALUE="'.$email_sales.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Billing Phone:</B></td><td>
        <INPUT TYPE="TEXT" NAME="phone_billing" VALUE="'.$phone_billing.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Billing Email:</B></td><td>
        <INPUT TYPE="TEXT" NAME="email_billing" VALUE="'.$email_billing.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Customer Service Phone:</B></td><td>
        <INPUT TYPE="TEXT" NAME="phone_custsvc" VALUE="'.$phone_custsvc.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Customer Service Email:</B></td><td>
        <INPUT TYPE="TEXT" NAME="email_custsvc" VALUE="'.$email_custsvc.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Billing Date Rollover Time:</B></td><td>
        <INPUT TYPE="TEXT" NAME="billingdate_rollover_time" VALUE="'.$billingdate_rollover_time.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td>
        <B>Path To Credit Card File</B></td><td>
        <INPUT TYPE="TEXT" NAME="path_to_ccfile" VALUE="'.$path_to_ccfile.'" SIZE="50" MAXLENGTH="128">
        </td><tr><td>
	<B>Default Group</B></td><td>
        <INPUT TYPE="TEXT" NAME="default_group" VALUE="'.$default_group.'" SIZE="20" MAXLENGTH="32">
        </td><tr><td valign=top>	
        <B>Credit Card Export Variable Order</B></td><td>
        <INPUT TYPE="TEXT" NAME="ccexportvarorder" VALUE="'.$ccexportvarorder.'" SIZE="50" MAXLENGTH="255">
        </td><tr><td>
	<B>Pastdue Days</B></td><td>
        <INPUT TYPE="TEXT" NAME="pastdue_days1" VALUE="'.$pastdue_days1.'" SIZE="3" MAXLENGTH="3"> &nbsp; 
        <INPUT TYPE="TEXT" NAME="pastdue_days2" VALUE="'.$pastdue_days2.'" SIZE="3" MAXLENGTH="3"> &nbsp; 
        <INPUT TYPE="TEXT" NAME="pastdue_days3" VALUE="'.$pastdue_days3.'" SIZE="3" MAXLENGTH="3"> &nbsp; 
        </td><tr><td>
	</td><td>
	<INPUT TYPE="SUBMIT" NAME="submit" value="submit">
	<p>
	You can use any combination of the following variables in the Credit Card Export Variable Order:<br>
        $user (the database user)<br>
        $batchid<br>
        $mybilling_id (the billing id being run)<br>
        $invoice_number<br>
        $billing_name<br>
        $billing_company<br>
        $billing_street<br>
        $billing_city<br>
        $billing_state<br>
        $billing_zip<br>
        $billing_acctnum<br>
        $billing_ccnum<br>
        $billing_ccexp<br>
        $billing_fromdate<br>
        $billing_todate<br>
        $billing_payment_due_date<br>
        $mydate (Y-m-d date format)<br>
        $abstotal (absolute value of total, if precise total is negative it with export with CREDIT marked)<br>
	</td></table>
	</FORM>';

?>
</body>
</html>







