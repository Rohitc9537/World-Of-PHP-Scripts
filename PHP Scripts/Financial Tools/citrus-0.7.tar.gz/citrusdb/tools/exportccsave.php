<html>
<body bgcolor="#ffffff">
<LINK href="../citrus.css" type=text/css rel=STYLESHEET>

<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$batchid = $base->input['batchid'];
$mydate = $base->input['mydate'];


if ($submit) {

	// go through a list of billing_id's that are to be billed today
	$query = "SELECT DISTINCT billing_id FROM billing_details WHERE creation_date = CURRENT_DATE AND batch = '$batchid'";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$distinctresult = $DB->Execute($query) or die ("Query Failed");

	// make a new billing_history record for each billing id group - use the billing_history_id as the invoice number
	while ($myresult = $distinctresult->FetchRow())
        {
        	$mybilling_id = $myresult['billing_id'];
		$query = "INSERT INTO billing_history (billing_date, created_by, record_type, billing_type, billing_id) 
			VALUES (CURRENT_DATE,'$user','bill','creditcard','$mybilling_id')";
		$historyresult = $DB->Execute($query) or die ("Query Failed");
		
		// set the invoice number for billing_details that have the corresponding billing_id 
		// and haven't been assigned an invoice number yet
		$myinsertid = $DB->Insert_ID();
		$invoice_number=$myinsertid;
		$query = "UPDATE billing_details SET invoice_number = '$invoice_number' 
			WHERE billing_id = '$mybilling_id' AND invoice_number IS NULL";
		$invnumresult = $DB->Execute($query) or die ("Query Failed");
			
		// get the billing name and address for the export

		// get the data for the service charges still pending and what services they have
		$query = "SELECT d.billing_id d_billing_id, d.creation_date d_creation_date, d.user_services_id d_user_services_id,
	        d.invoice_number d_invoice_number, d.billed_amount d_billed_amount, d.paid_amount d_paid_amount, 
		u.id u_id, u.account_number u_account_number, 
		m.id m_id, m.service_description m_description, m.options_table m_options_table
	        FROM billing_details d
	        LEFT JOIN user_services u ON d.user_services_id = u.id
	        LEFT JOIN master_services m ON u.master_service_id = m.id
	        WHERE d.billing_id = $mybilling_id";
        
	        $invoiceresult = $DB->Execute($query) or die ("Query Failed"); // used to show the invoice
		$totalresult = $DB->Execute($query) or die ("Query Failed"); // used to add up the total charges

		// get the data for the billing name and address and stuff from the billing table
		$query = "SELECT * FROM billing WHERE id = $mybilling_id";
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$billingresult = $DB->Execute($query) or die ("Query Failed");

		$myresult = $billingresult->fields;
		$billing_name = $myresult['name'];
		$billing_company = $myresult['company'];
		$billing_street = $myresult['street'];
		$billing_city = $myresult['city'];
		$billing_state = $myresult['state'];
		$billing_zip = $myresult['zip'];
		$billing_acctnum = $myresult['account_number'];
		$billing_ccnum = $myresult['creditcard_number'];
		$billing_ccexp = $myresult['creditcard_expire'];
		$billing_fromdate = $myresult['from_date'];
		$billing_todate = $myresult['to_date'];
		$billing_payment_due_date = $myresult['payment_due_date'];

		// get the data for the general company/organization info printed on the bill
                $query = "SELECT * FROM general";
                $generalresult = $DB->Execute($query) or die ("Query Failed");

		$myresult = $generalresult->fields;
                $org_name = $myresult['org_name'];
                $org_street = $myresult['org_street'];
                $org_city = $myresult['org_city'];
                $org_state = $myresult['org_state'];
                $org_zip = $myresult['org_zip'];
                $phone_billing = $myresult['phone_billing'];
                $email_billing = $myresult['email_billing'];
        	$ccexportvarorder = $myresult['ccexportvarorder'];
		$path_to_ccfile = $myresult['path_to_ccfile'];

		$invoicetotal = 0;
		$mydate = date("Y-m-d");

		// get the invoicetotal
		while ($myresult = $totalresult->FetchRow())
                {
                        $billed_amount = $myresult['d_billed_amount'] - $myresult['d_paid_amount'];
                        $invoicetotal = $billed_amount + $invoicetotal;
                }
	
		// check the total, if it is zero don't do anything else, since this billing id has no services assigned to it
		if ($invoicetotal != 0)
		{

			$precisetotal = sprintf("%.2f", $invoicetotal);

			// print out the information to be exported (save this to a file once we know it's right)
			$filename = "$path_to_ccfile/export$batchid.csv";
			$handle = fopen($filename, 'a'); // open the file

			// get the absolute value of the total
			$abstotal = abs($precisetotal);

			// use the $ccexportvarorder that has the list of variables into real variables
			eval ("\$exportstring = \"$ccexportvarorder\";");

			// print the line in the exported data file
			if ($precisetotal < 0)	// print CREDIT if the precise_total is negative
			{
				//$newline = "CREDIT,$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street\n";
				$newline = "CREDIT,$exportstring\n";
			} else {
				//$newline = "CHARGE,$mybilling_id,$invoice_number,$billing_ccnum,$billing_ccexp,$abstotal,$billing_zip,$billing_street\n";
				$newline = "CHARGE,$exportstring\n";
			}
			fwrite($handle, $newline); // write to the file


			// put a record in the billing_history to note the invoice total, tax, and details
			$query = "UPDATE billing_history 
				  SET from_date = '$billing_fromdate',
				  to_date = '$billing_todate',
				  payment_due_date = '$billing_payment_to_date',
				  total_due = '$precisetotal'
				  WHERE id = '$invoice_number'";
	                $historyresult = $DB->Execute($query) or die ("Query Failed");
	
			//// update the Next Billing Date to whatever the billing type dictates +1 +2 +6 etc.			
			// get the current billing type
			$query = "SELECT b.billing_type b_billing_type, b.next_billing_date b_next_billing_date, 
				b.from_date b_from_date, b.to_date b_to_date, t.id t_id, t.frequency t_frequency 
				FROM billing b
				LEFT JOIN billing_types t ON b.billing_type = t.id
				WHERE b.id = $mybilling_id";		
			$DB->SetFetchMode(ADODB_FETCH_ASSOC);
			$billingqueryresult = $DB->Execute($query) or die ("Query Failed");
			$billingresult = $billingresult->fields;

			$mybillingdate = $billingresult['b_next_billing_date'];
			$myfromdate = $billingresult['b_from_date'];
			$mytodate = $billingresult['b_to_date'];
			$mybillingfreq = $billingresult['t_frequency'];
				
			// double frequency to add to the to_date
			$doublefreq = $mybillingfreq * 2;
	
			// insert the new next_billing_date, from_date, to_date, and payment_due_date to next from_date
			$query = "UPDATE billing
				  SET next_billing_date = DATE_ADD('$mybillingdate', INTERVAL '$mybillingfreq' MONTH),
					from_date = DATE_ADD('$myfromdate', INTERVAL '$mybillingfreq' MONTH),
	                                to_date = DATE_ADD('$myfromdate', INTERVAL '$doublefreq' MONTH),
					payment_due_date = DATE_ADD('$myfromdate', INTERVAL '$mybillingfreq' MONTH)
				  WHERE id = '$mybilling_id'";		
			$updateresult = $DB->Execute($query) or die ("Query Failed");				
	
			// TODO: update the from_date and to_date here automatically according to the billing type interval

		} // endif

        } // endwhile

	fclose($handle); // close the file
	print "<b>Wrote file to $filename</b><p>export order: $ccexportvarorder<p><a href=\"index.php\">[ Done ]</a>";

}

?>
</body>
</html>







