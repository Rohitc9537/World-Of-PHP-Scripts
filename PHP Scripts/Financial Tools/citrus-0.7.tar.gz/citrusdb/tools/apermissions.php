<html>
<body bgcolor="#ffffff">
<h3>Module Permissions</h3>
<p>
<?php
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$module = $base->input['module'];
$save = $base->input['save'];
$padd = $base->input['padd'];
$permission = $base->input['permission'];
$usergroup = $base->input['usergroup'];


// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($save)
{
    $query = "INSERT INTO module_permissions (modulename,permission,user) values('$module','$permission','$usergroup')";
    $result = $DB->Execute($query) or die ("Query Failed");
    print "Saved Changes";

} else {

$usergroup = "<option value=\"\">-- Groups --</option>";
$group = array();
$query = "SELECT groupname FROM groups ORDER BY groupname";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
while ($myresult = $result->FetchRow())
{
    array_push($group,$myresult['groupname']);
}
$group = array_unique($group);
while (list($key,$value) = each($group))
{
    $usergroup .= "<option value=\"".$value."\">".$value."</option>";

}
$usergroup .= "<option value=\"\">-- Users --</option>";
$query = "SELECT username,real_name FROM user ORDER BY real_name";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
while ($myresult = $result->FetchRow())
{
    $usergroup .= "<option value=\"".$myresult['username']."\">".$myresult['real_name']."</option>";
}

print <<<END
<form name="form1" method="get" action="index.php">
    <input type="hidden" name="load" value="apermissions">
    <input type=hidden name=type value=tools>
    <input name="module" type="hidden" id="module" value="$module">
  <p>User/Group:
    <select name="usergroup">
    $usergroup
    </select>
  </p>
  <p>Permission:
    <select name="permission">
      <option value="r">View</option>
      <option value="c">Create</option>
      <option value="m">Modify</option>
      <option value="d">Remove</option>
      <option value="f">Full Control</option>
    </select>
  </p>
  <p>
    <input name="padd" type="submit" id="padd" value="Add">
    <input name="save" type="hidden" id="save" value="yes">
  </p>
</form>
END;
}

?>
</table>
</body>
</html>
