<html>
<body bgcolor="#ffffff">
<h3>Remove Permissions</h3>
[ <a href="index.php?load=addpermissions">Add Permission</a> ]
<p>
<?php
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}
//GET Variables
$module = $base->input['module'];
$pid = $base->input['pid'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

$query = "DELETE FROM module_permissions WHERE id=$pid";
$result = $DB->Execute($query) or die ("Query Failed");


print "Saved Changes";

?>
</table>
</body>
</html>

