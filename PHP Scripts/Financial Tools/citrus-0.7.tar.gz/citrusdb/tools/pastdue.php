<html>
<body bgcolor="#ffffff">
<?php
// Copyright (C) 2003-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['manager'] == 'n') {
	echo 'You must have manager privileges to use this feature<br>';
        exit; 
}
	/*--------------------------------------------------------------------*/
	// Get the pastdue_days from the general table
	/*--------------------------------------------------------------------*/
	$query = "SELECT * from general";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
	$pastdue_days1 = $myresult['pastdue_days1'];
	$pastdue_days2 = $myresult['pastdue_days2'];
	$pastdue_days3 = $myresult['pastdue_days3'];

	/*--------------------------------------------------------------------*/
        // customers with past due amounts pastdue_days1 (30-60) days
	/*--------------------------------------------------------------------*/

        $query = "SELECT 
	bd.creation_date bd_creation_date, bd.user_services_id bd_user_services_id, 
	bd.invoice_number bd_invoice_number, bd.billed_amount bd_billed_amount, 
	bd.paid_amount bd_paid_amound, bd.billing_id bd_billing_id, 
	us.id us_id, us.master_service_id us_master_service_id, 
	ms.id ms_id, ms.service_description ms_service_description, 
	bi.id bi_id, bi.account_number bi_account_number 
	FROM billing_details bd 
	LEFT JOIN user_services us ON bd.user_services_id = us.id 
	LEFT JOIN master_services ms ON us.master_service_id = ms.id
	LEFT JOIN billing bi ON bd.billing_id = bi.id
	WHERE bd.billed_amount > bd.paid_amount 
	AND CURRENT_DATE > DATE_ADD(bd.creation_date, INTERVAL $pastdue_days1 DAY) 
	AND CURRENT_DATE <= DATE_ADD(bd.creation_date, INTERVAL $pastdue_days2 DAY)";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	// print heading	
	print "<h3>$pastdue_days1 Days Past Due</h3><table cellpadding=10>";
	print "<td><b>Creation Date</b></td>
	<td><b>User Service</b></td>
	<td><b>Invoice Number</b></td>
	<td><b>Amount Owed</b></td>
	<td><b>Service</b></td>
	<td><b>Account Number<b></td>
	<tr bgcolor=\"#eeeeee\">";

	// loop through results and print out each
	while ($myresult = $result->FetchRow())
        {
        $creation_date = $myresult['bd_creation_date'];
        $user_services_id = $myresult['bd_user_services_id'];
	$invoice_number = $myresult['bd_invoice_number'];
	$amount_owed = $myresult['bd_billed_amount'] - $myresult['bd_paid_amount'];
	$service_description = $myresult['ms_service_description'];
	$account_num = $myresult['bi_account_number'];
	
        print "<td>$creation_date</td>
	<td>$user_services_id</td>
	<td>$invoice_number</td>
	<td>$amount_owed</td>
	<td>$service_description</td>
	<td><a href=\"index.php?load=viewaccount&type=fs&acnum=$account_num\">$account_num</a></td>
	<tr bgcolor=\"#eeeeee\">\n";
        }

	// end table listing
        print "</table><p>";

	/*--------------------------------------------------------------------*/
	// customers with past due amounts pastdue_days2 (60-90) days
	/*--------------------------------------------------------------------*/
        
        $query = "SELECT 
	bd.creation_date bd_creation_date, bd.user_services_id bd_user_services_id, 
	bd.invoice_number bd_invoice_number, bd.billed_amount bd_billed_amount, 
	bd.paid_amount bd_paid_amound, bd.billing_id bd_billing_id, 
	us.id us_id, us.master_service_id us_master_service_id, 
	ms.id ms_id, ms.service_description ms_service_description, 
	bi.id bi_id, bi.account_number bi_account_number 
	FROM billing_details bd 
	LEFT JOIN user_services us ON bd.user_services_id = us.id 
	LEFT JOIN master_services ms ON us.master_service_id = ms.id
	LEFT JOIN billing bi ON bd.billing_id = bi.id
	WHERE bd.billed_amount > bd.paid_amount 
	AND CURRENT_DATE > DATE_ADD(creation_date, INTERVAL $pastdue_days2 DAY)
        AND CURRENT_DATE <= DATE_ADD(creation_date, INTERVAL $pastdue_days3 DAY)";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
        
	// print heading
        print "<h3>$pastdue_days2 Days Past Due</h3><table cellpadding=10>";
	print "<td><b>Creation Date</b></td>
	<td><b>User Service</b></td>
	<td><b>Invoice Number</b></td>
	<td><b>Amount Owed</b></td>
	<td><b>Service</b></td>
	<td><b>Account Number<b></td>
	<tr bgcolor=\"#eeeeee\">";
	
        // loop through results and print out each
	while ($myresult = $result->FetchRow())
        {
        $creation_date = $myresult['bd_creation_date'];
        $user_services_id = $myresult['bd_user_services_id'];
	$invoice_number = $myresult['bd_invoice_number'];
	$amount_owed = $myresult['bd_billed_amount'] - $myresult['bd_paid_amount'];
	$service_description = $myresult['ms_service_description'];
	$account_num = $myresult['bi_account_number'];
	
        print "<td>$creation_date</td>
	<td>$user_services_id</td>
	<td>$invoice_number</td>
	<td>$amount_owed</td>
	<td>$service_description</td>
	<td><a href=\"index.php?load=viewaccount&type=fs&acnum=$account_num\">$account_num</a></td>
	<tr bgcolor=\"#eeeeee\">\n";
	}
	
	// end table listing
	print "</table><p>";

	/*--------------------------------------------------------------------*/
	// customers with past due amounts over pastdue_days3 (90) days
	/*--------------------------------------------------------------------*/

	$query = "SELECT 
	bd.creation_date bd_creation_date, bd.user_services_id bd_user_services_id, 
	bd.invoice_number bd_invoice_number, bd.billed_amount bd_billed_amount, 
	bd.paid_amount bd_paid_amound, bd.billing_id bd_billing_id, 
	us.id us_id, us.master_service_id us_master_service_id, 
	ms.id ms_id, ms.service_description ms_service_description, 
	bi.id bi_id, bi.account_number bi_account_number 
	FROM billing_details bd 
	LEFT JOIN user_services us ON bd.user_services_id = us.id 
	LEFT JOIN master_services ms ON us.master_service_id = ms.id
	LEFT JOIN billing bi ON bd.billing_id = bi.id
	WHERE bd.billed_amount > bd.paid_amount 
	AND CURRENT_DATE > DATE_ADD(creation_date, INTERVAL $pastdue_days3 DAY)";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
        
        // print heading
        print "<h3>Over $pastdue_days3 Days Past Due</h3><table cellpadding=10>";
	print "<td><b>Creation Date</b></td>
	<td><b>User Service</b></td>
	<td><b>Invoice Number</b></td>
	<td><b>Amount Owed</b></td>
	<td><b>Service</b></td>
	<td><b>Account Number<b></td>
	<tr bgcolor=\"#eeeeee\">";
	
        // loop through results and print out each
	while ($myresult = $result->FetchRow())
        {
        $creation_date = $myresult['bd_creation_date'];
        $user_services_id = $myresult['bd_user_services_id'];
	$invoice_number = $myresult['bd_invoice_number'];
	$amount_owed = $myresult['bd_billed_amount'] - $myresult['bd_paid_amount'];
	$service_description = $myresult['ms_service_description'];
	$account_num = $myresult['bi_account_number'];
	
        print "<td>$creation_date</td>
	<td>$user_services_id</td>
	<td>$invoice_number</td>
	<td>$amount_owed</td>
	<td>$service_description</td>
	<td><a href=\"index.php?load=viewaccount&type=fs&acnum=$account_num\">$account_num</a></td>
	<tr bgcolor=\"#eeeeee\">\n";
        }

        // end table listing
        print "</table><p>";

	

?>
</body>
</html>







