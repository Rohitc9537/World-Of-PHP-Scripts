<html>
<body bgcolor="#ffffff">
<h3>Revenue Report</h3>
<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['manager'] == 'n') {
	echo 'You must have manager privileges to use this feature<br>';
        exit; 
}

        // get the paid amount for lifetime
        $query = "SELECT SUM(paid_amount) FROM billing_details";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $sumpaid = $myresult['SUM(paid_amount)'];

	// get the paid amount for the current month - (need to put the payment date into the billing_history?)
        //$query = "SELECT SUM(paid_amount) FROM billing_details WHERE ";
        //$result = db_query($query) or die ("Query Failed".db_error());
        //$myresult = db_fetch_assoc($result);
        //$sumpaid = $myresult['SUM(paid_amount)'];

	$sumpaid = round($sumpaid,2);

print "Lifetime Revenue: $sumpaid<p>";
//print "Current Month: $currentpaid<p>";
//print "Previous Month: $monthpaid<p>";
//print "Past 6 Months: $past6paid<p>";
//print "Past Year: $past12paid<p>";

?>
</body>
</html>







