<html>
<body bgcolor="#ffffff">
<LINK href="../citrus.css" type=text/css rel=STYLESHEET>

<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>
// Read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$invoiceid = $base->input['invoiceid'];
		
//
// get the data for the billing name and address and stuff from the billing table
//


/*
$query = "SELECT b.name b_name, b.company b_company, b.street b_street, 
			b.city b_city, b.state b_state, b.zip b_zip, 
			b.account_number b_account_number, b.from_date b_from_date, 
			b.to_date b_to_date, b.payment_due_date b_payment_due_date, 
			b.billing_type b_billing_type, bt.id bt_id, bt.name bt_name 
			FROM billing b  
			LEFT JOIN billing_types bt 
			ON b.billing_type = bt.id 
			WHERE b.id = $mybilling_id";
			*/

		$query = "SELECT * FROM billing_history h
		LEFT JOIN billing b ON h.billing_id = b.id 
		WHERE h.id = '$invoiceid'";
		
		$DB->SetFetchMode(ADODB_FETCH_ASSOC);
		$billingresult = $DB->Execute($query) or die ("Query Failed");
		
		$myresult = $billingresult->fields;
		$billing_id = $myresult['billing_id'];
		$billing_name = $myresult['name'];
		$billing_company = $myresult['company'];
		$billing_street = $myresult['street'];
		$billing_city = $myresult['city'];
		$billing_state = $myresult['state'];
		$billing_zip = $myresult['zip'];
		$billing_acctnum = $myresult['account_number'];
		$billing_fromdate = $myresult['from_date'];
		$billing_todate = $myresult['to_date'];
		$billing_payment_due_date = $myresult['payment_due_date'];
		$billing_new_charges = $myresult['new_charges'];
		$billing_past_due = $myresult['past_due'];
		$billing_late_fee = $myresult['late_fee'];
		$billing_tax_due = $myresult['tax_due'];
		$billing_total_due = $myresult['total_due'];
		$billing_notes = $myresult['notes'];

		//
		// get the data for our company to be printed on the bill
		//

		$query = "SELECT * FROM general";
		$generalresult = $DB->Execute($query) or die ("Query Failed");

		$myresult = $generalresult->fields;
		$org_name = $myresult['org_name'];
		$org_street = $myresult['org_street'];
		$org_city = $myresult['org_city'];
		$org_state = $myresult['org_state'];
		$org_zip = $myresult['org_zip'];
		$phone_billing = $myresult['phone_billing'];
		$email_billing = $myresult['email_billing'];
		
		$mydate = date("Y-m-d");


		//
		// start printing the page now
		//

		print "<div style=\"page: auto\">";

		print "<div style=\"position: relative; border: solid 0px; left: 0px; top: 0px; width: 50%;\">
		<img src=\"images/companylogo.png\"></div>
		<div style=\"position: relative; border: solid 0px; left: 75%; top: -45px; width: 20%;\">
		<h3>Invoice</h3></div>";

		print "<div  style=\"position: relative; left: 0px; top: -10px; width: 30%; border: solid 0px;\">Invoice For:
		<p>$billing_name
		<br>$billing_company
		<br>$billing_street
		<br>$billing_city &nbsp; $billing_state &nbsp; $billing_zip</div>";
		print "<div style=\"position: relative; left: 50%; top: -116px; width: 40%; border: solid 1px; padding: 10px;\">";
		print "<div>Invoice Number: $invoiceid<p>";
		print "Date: $mydate<br>";
		print "Account Number: $billing_acctnum<br>";
		print "From: $billing_fromdate  &nbsp;&nbsp; To: $billing_todate  <br>";
		print "Payment Due By: $billing_payment_due_date<br>";
		print "<b>Total: $billing_total_due</b><p>";
		print "</div><div style=\"position: relative; border: solid 1px; padding: 5px;\">Amount Enclosed:</div>";
		print "</div>";

		print "<div  style=\"position: relative; left: 0px; top: -40px; width: 50%; border: solid 0px;\">";
		print "Invoice Number: $invoice_number<p>";
		print "Date: $mydate<br>Billing ID: $billing_id<br>";
		print "Account Number: $billing_acctnum<br>";
		print "From: $billing_fromdate  To: $billing_todate  <br>";
		print "Payment Due By: $billing_payment_due_date<br>";
		print "</div>";
		
		print "<div style=\"position: relative; left: 65%; top: -116px; width: 200px; border: solid 0px;\">
		$org_name<br>
		$org_street<br>
		$org_city, $org_state $org_zip<br>
		$phone_billing<br>
		$email_billing<br>
		</div>";



	print "<div style=\"position: relative; left: 0px; top: -100px; width=100%; border: solid 1px;\"><table width=100%>";
	print "<td><b>Description</b></td><td><b>Details</b></td><td><b>Amount</b></td><tr>";
		

	//
	// Select the new charge details for a specific invoice number
	//
	$query = "SELECT d.user_services_id d_user_services_id, 
	d.invoice_number d_invoice_number, d.billed_amount d_billed_amount, 
	d.billing_id d_billing_id, d.taxed_services_id d_taxed_services_id, 
	u.id u_id, u.master_service_id u_master_service_id, u.usage_multiple u_usage_multiple, 
	m.id m_id, m.service_description m_service_description, ts.id ts_id, 
	ts.master_services_id ts_master_services_id, 
	ts.tax_rate_id ts_tax_rate_id, tr.id tr_id, tr.description tr_description
	FROM billing_details d
	LEFT JOIN user_services u ON d.user_services_id = u.id
	LEFT JOIN master_services m ON u.master_service_id = m.id
	LEFT JOIN taxed_services ts ON d.taxed_services_id = ts.id 
	LEFT JOIN tax_rates tr ON ts.tax_rate_id = tr.id 
	WHERE d.invoice_number = '$invoiceid'";
	
	$result = $DB->Execute($query) or die ("Query Failed");
	
	//
	// Print the invoice details
	//
	
	while ($myresult = $result->FetchRow())
	{
	
		$service_description = $myresult['m_service_description'];
		$tax_description = $myresult['tr_description'];
		$billed_amount = $myresult['d_billed_amount'];
		print "<td>$service_description $tax_description</td><td></td><td>$billed_amount</td><tr>";
	}
	
	
		print "</table></div>";
		print "<div style=\"position: relative; bottom: 10%; left: 0px; width: 30%;\">";
		print "<b>Notes:<b><br> $billing_notes </div>";
		print "<div style=\"position: relative; bottom: 10%; left: 80%;\">
			New Charges: $billing_new_charges<br>
			Past Due: $billing_past_due<br>
			Late Fee: $billing_late_fee<br>
			Tax Due: $billing_tax_due<br>
			Total Due: $billing_total_due</div>";

	print "</div>";
        

?>
</body>
</html>







