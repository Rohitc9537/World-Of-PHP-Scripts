<html>
<body bgcolor="#ffffff">
<h3>Customer Summary</h3>
<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['manager'] == 'n') {
	echo 'You must have manager privileges to use this feature<br>';
        exit; 
}

        // get the number of customers
        $query = "SELECT COUNT(*) FROM customer WHERE cancel_date is NULL";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $numofcustomers = $myresult['COUNT(*)'];

        // get the number of services
        $query = "SELECT COUNT(*) FROM user_services";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $numofservices = $myresult['COUNT(*)'];

	

print "Number of customers: $numofcustomers<p>Number of services: $numofservices";



?>
</body>
</html>







