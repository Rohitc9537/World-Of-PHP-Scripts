<html>
<body bgcolor="#ffffff">
<h3>Edit Billing Types</h3>
<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}


//GET Variables
$submit = $base->input['submit'];
$method = $base->input['method'];
$frequency = $base->input['frequency'];
$sortorder = $base->input['sortorder'];
$name = $base->input['name'];
$submit = $base->input['submit'];
$remove = $base->input['remove'];
$typeid = $base->input['typeid'];


// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit == "AddBillingType") 
{
// add a billing type
	$query = "INSERT INTO billing_types (name,sortorder,frequency,method) VALUES ('$name','$sortorder','$frequency','$method')";
        $result = $DB->Execute($query) or die ("Query Failed");
        print "<h3>Billing Types Updated</h3> [<a href=\"index.php?load=billing&tooltype=module&type=tools\">done</a>]";
}

if ($remove == 'on')
{
	// remove the billing type
	$query = "DELETE FROM billing_types WHERE id = $typeid";
	$result = $DB->Execute($query) or die ("Query Failed");
	print "<h3>Billing Type Removed</h3> [<a href=\"index.php?load=billing&tooltype=module&type=tools\">done</a>]";
}


echo '<p><b>Current Types</b><br>';

$query = "SELECT * FROM billing_types ORDER BY sortorder";

$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");

echo '<table cellpadding=5 cellspacing=1><tr bgcolor="#eeeeee">
<td><b>ID</b></td>
<td><b>Name</b></td>
<td><b>Sortorder</b></td>
<td><b>Frequency</b></td>
<td><b>Method</b></td>
<td></td>
</tr>';
while ($myresult = $result->FetchRow())
{
	$id = $myresult['id'];
        $name = $myresult['name'];
	$sortorder = $myresult['sortorder'];
        $frequency = $myresult['frequency'];
	$method = $myresult['method'];
	print "<tr bgcolor=\"#eeeeee\"><td>$id</td><td>$name</td><td>$sortorder</td><td>$frequency</td><td>$method</td><td><a href=\"index.php?load=billing&tooltype=module&type=tools&billingtypes=on&remove=on&typeid=$id&submit=Link\">Remove</a></td></tr>\n";
}

echo '</table><p>
<b>New Billing Type</b><br>
<FORM ACTION="index.php" METHOD="GET">
<table>
<td>Name:</td><td><input name="name" type=text></td><tr>
<td>Sortorder:</td><td><input name="sortorder" type=text></td><tr>
<td>Frequency:</td><td><input name="frequency" type=text></td><tr>
<td>Method:</td><td><select name="method">
		<option value="creditcard">creditcard</option>
		<option value="invoice">invoice</option>
		<option value="prepay">prepay</option>
		<option value="free">free</option>
	</select></td><tr>
</table>';
?>
<input type=hidden name=load value=billing>
<input type=hidden name=tooltype value=module>
<input type=hidden name=type value=tools>
<input type=hidden name=billingtypes value=on>
<INPUT TYPE="SUBMIT" NAME="submit" VALUE="AddBillingType">
</FORM>
<p>
A frequency of zero is a one time charge, all other frequency are in number of months between recurring charges, 1 = monthly, 2 = 
bi-monthly, etc.
</body>
</html>
