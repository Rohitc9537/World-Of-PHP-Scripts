<li><b>Billing</b></li>
<ul id="tabnav">
<li><a href="index.php?load=billing&tooltype=module&type=tools&billingtypes=on">Edit Billing Types</a></li>

<!-- TODO: move these functions listed below into the billing module tools folder -->

<li><a href="index.php?load=exportcc&type=tools">Export Credit Cards</a></li>
<li><a href="index.php?load=importcc&type=tools">Import Credit Cards</li>
<li><a href="index.php?load=invoice&type=tools">Print Invoices</a></li>
<li><a href="index.php?load=payment&type=tools">Enter Payments</a></li>
<li><a href="index.php?load=reminder&type=tools">Send Reminders</a></li>
<li><a href="index.php?load=invmaint&type=tools">Invoice Maintenance</a></li>
</ul>
