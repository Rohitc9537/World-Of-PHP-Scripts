<html>
<body bgcolor="#ffffff">
<h3>Billing</h3>
<?php
// Copyright (C) 2003  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$billingtypes = $base->input['billingtypes'];

if ($billingtypes)
{
        include('billingtypes.php');
}
else
{

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
	}

echo '[ <a href="index.php?load=billing&tooltype=module&type=tools&billingtypes=on">Edit Billing Types</a> ]';

}
?>
</table>
</body>
</html>
