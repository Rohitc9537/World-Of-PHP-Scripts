<html>
<body bgcolor="#ffffff">
<h3>Link Services</h3>
<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$linkfrom = $base->input['linkfrom'];
$linkto = $base->input['linkto'];
$unlink = $base->input['unlink'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {

// on submit have it link the linkto and linkfrom id's together by putting them into the linked_services table

if ($unlink == 'on')
{
	// remove the link
	$query = "DELETE FROM linked_services WHERE linkfrom = $linkfrom AND linkto = $linkto LIMIT 1";
	$result = $DB->Execute($query) or die ("Query Failed");
	print "<h3>Links Updated</h3> [<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}
else {
	// add a link
	$query = "INSERT INTO linked_services (linkfrom,linkto) VALUES ($linkfrom,$linkto)";
        $result = $DB->Execute($query) or die ("Query Failed");
        print "<h3>Links Updated</h3> [<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}

}
echo '<p><b>Current Links</b><br>';

$query = "SELECT mfrom.id mfrom_id, mfrom.service_description mfrom_description, mto.id mto_id, mto.service_description mto_description, 
l.linkfrom, l.linkto FROM linked_services l LEFT JOIN master_services mfrom ON mfrom.id = l.linkfrom LEFT JOIN master_services mto ON mto.id = 
l.linkto";

$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");

echo '<table cellpadding=5 cellspacing=1><tr bgcolor="#eeeeee"><td><b>From</b></td><td><b>To</b></td></tr>';
while ($myresult = $result->FetchRow())
{
	$fromid = $myresult['mfrom_id'];
        $fromdesc = $myresult['mfrom_description'];
	$toid = $myresult['mto_id'];
        $todesc = $myresult['mto_description'];
	print "<tr bgcolor=\"#eeeeee\"><td>$fromdesc</td><td>$todesc</td><td><a href=\"index.php?load=services&tooltype=module&type=tools&link=on&unlink=on&linkfrom=$fromid&linkto=$toid&submit=Link\">Unlink</a></td></tr>\n";
}

echo '</table><p>
<b>New Service Link</b><br>
<FORM ACTION="index.php" METHOD="GET">
Link From: <select name=linkfrom>';
        // get the list of services from the table
        $query = "SELECT * FROM master_services ORDER BY service_description";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	while ($myresult = $result->FetchRow())
	{
	$id = $myresult['id'];
        $description = $myresult['service_description'];
	print "<option value=\"$id\">$description</option>\n";
	}

	echo '</select><p> Link To: <select name=linkto>';
	
        $query = "SELECT * FROM master_services ORDER BY service_description";
       $DB->SetFetchMode(ADODB_FETCH_ASSOC);
       $result = $DB->Execute($query) or die ("Query Failed");

	while ($myresult = $result->FetchRow())
        {
        $id = $myresult['id'];
        $description = $myresult['service_description'];
        print "<option value=\"$id\">$description</option>\n";
        }
        echo '</select>&nbsp;';
	

?>
<input type=hidden name=load value=services>
<input type=hidden name=tooltype value=module>
<input type=hidden name=type value=tools>
<input type=hidden name=link value=on>
<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Link">
</FORM>
<p>
Linking a service will cause the linked to service to be added whenever the linked from service is added.
</body>
</html>
