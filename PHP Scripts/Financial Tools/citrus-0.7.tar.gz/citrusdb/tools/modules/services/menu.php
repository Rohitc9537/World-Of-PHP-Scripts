<li><b>Services</b></li>
<ul id="tabnav">

<!-- TODO: move these first two links into the services module tools folder -->

<li><a href="index.php?load=newaccounts&type=tools">Show New Accounts</a></li>
<li><a href="index.php?load=tools/printwelcome&type=fs">Print Welcome Letters</a></li>

<li><a href="index.php?load=services&tooltype=module&type=tools">Edit Services</a></li>
<li><a href="index.php?load=services&tooltype=module&new=on&type=tools">Add New Service</a></li>
<li><a href="index.php?load=services&tooltype=module&link=on&type=tools">Link Services</a></li>
<li><a href="index.php?load=services&tooltype=module&options=on&type=tools">Options Tables</li>
<li><a href="index.php?load=services&tooltype=module&tax=on&type=tools">Taxes</a></li>
</ul>
