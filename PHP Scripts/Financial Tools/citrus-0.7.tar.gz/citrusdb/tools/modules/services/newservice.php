<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$service_description = $base->input['service_description'];
$pricerate = $base->input['pricerate'];
$frequency = $base->input['frequency'];
$options_table = $base->input['options_table'];
$category = $base->input['category'];
$selling_active = $base->input['selling_active'];
$postbilled = $base->input['postbilled'];
$activate_notify = $base->input['activate_notify'];
$shutoff_notify = $base->input['shutoff_notify'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
	// insert groupname and username into the groups table
	$query = "INSERT INTO master_services 
(service_description,pricerate,frequency,options_table,category,selling_active,postbilled,activate_notify,shutoff_notify) 
VALUES ('$service_description','$pricerate','$frequency','$options_table','$category','$selling_active','$postbilled','$activate_notify','$shutoff_notify')";
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<h3>Services Updated</h3> [<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}

echo '<H3>Add New Service</H3>
	<P>
	<FORM ACTION="index.php" METHOD="GET">
	<B>Service Description</B><BR>
        <INPUT TYPE="TEXT" NAME="service_description" VALUE="" SIZE="20" MAXLENGTH="32"><P>
	<B>Price Rate</B><BR>
        <INPUT TYPE="TEXT" NAME="pricerate" VALUE="" SIZE="20" MAXLENGTH="32"><P>
	<B>Frequency</B><BR>
        <INPUT TYPE="TEXT" NAME="frequency" VALUE="" SIZE="20" MAXLENGTH="32"><P>
	<B>Options Table</B><BR>
        <INPUT TYPE="TEXT" NAME="options_table" VALUE="" SIZE="20" MAXLENGTH="32"><P>
	<B>Category</B><BR>
        <INPUT TYPE="TEXT" NAME="category" VALUE="" SIZE="20" MAXLENGTH="32"><P>
	<B>Selling Active</B> 
	<input type="radio" name=selling_active value="y">Yes<input type="radio" name=selling_active value="n" checked>No<p>
	<B>Post Billed</B>         
	<input type="radio" name=postbilled value="y">Yes<input type="radio" name=postbilled value="n" checked>No<p>
        <B>Activate Notify</B>         
        <INPUT TYPE="text" NAME="activate_notify" VALUE=""><P>
	<B>Shutoff Notify</B>         
        <INPUT TYPE="text" NAME="shutoff_notify" VALUE=""><P>                                    

	<input type=hidden name=load value=services>
	<input type=hidden name=tooltype value=module>
	<input type=hidden name=type value=tools>
	<input type=hidden name=new value=on>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Add">
	</FORM>';


?>



