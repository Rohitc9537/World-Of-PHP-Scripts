<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$sid = $base->input['sid'];
$service_description = $base->input['service_description'];
$pricerate = $base->input['pricerate'];
$frequency = $base->input['frequency'];
$options_table = $base->input['options_table'];
$category = $base->input['category'];
$selling_active = $base->input['selling_active'];
$hide_online = $base->input['hide_online'];
$postbilled = $base->input['postbilled'];
$activate_notify = $base->input['activate_notify'];
$shutoff_notify = $base->input['shutoff_notify'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
	// update the table
	$query = "UPDATE master_services 
	SET service_description = '$service_description',
	pricerate = '$pricerate',
	frequency = '$frequency',
	options_table = '$options_table',
	category = '$category',
	selling_active = '$selling_active',
	hide_online = '$hide_online',
	postbilled = '$postbilled',
	activate_notify = '$activate_notify',
	shutoff_notify = '$shutoff_notify'
	WHERE id = '$sid'";
	
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<h3>Services Updated</h3> [<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}

$query = "SELECT * FROM master_services WHERE id = $sid";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");

	$myresult = $result->fields;
	$service_description = $myresult['service_description'];
        $pricerate = $myresult['pricerate'];
        $frequency = $myresult['frequency'];
        $options_table = $myresult['options_table'];
        $category = $myresult['category'];
        $selling_active = $myresult['selling_active'];
	$hide_online = $myresult['hide_online'];
        $postbilled = $myresult['postbilled'];
        $activate_notify = $myresult['activate_notify'];
        $shutoff_notify = $myresult['shutoff_notify'];


echo '<H3>Edit Service</H3>
	<P>
	<FORM ACTION="index.php" METHOD="GET">
	<B>Service Description</B><BR>
        <INPUT TYPE="TEXT" NAME="service_description" VALUE="'.$service_description.'" MAXLENGTH="32"><P>
	<B>Price Rate</B><BR>
        <INPUT TYPE="TEXT" NAME="pricerate" VALUE="'.$pricerate.'" SIZE="20" MAXLENGTH="32"><P>
	<B>Frequency</B><BR>
        <INPUT TYPE="TEXT" NAME="frequency" VALUE="'.$frequency.'" SIZE="20" MAXLENGTH="32"><P>
	<B>Options Table</B><BR>
        <INPUT TYPE="TEXT" NAME="options_table" VALUE="'.$options_table.'" SIZE="20" MAXLENGTH="32"><P>
	<B>Category</B><BR>
        <INPUT TYPE="TEXT" NAME="category" VALUE="'.$category.'" SIZE="20" MAXLENGTH="32"><P>';
	echo '<B>Selling Active</B>';
	if ($selling_active == 'y')
        {
	echo '<input type="radio" name=selling_active value="y" checked>Yes<input type="radio" name=selling_active value="n">No<p>';
	} else {
	echo '<input type="radio" name=selling_active value="y">Yes<input type="radio" name=selling_active value="n" checked>No<p>';
	}
	
	echo '<B>Hide Online</B>';

	if ($hide_online == 'y')
        {
	echo '<input type="radio" name=hide_online value="y" checked>Yes
		<input type="radio" name=hide_online value="n">No<p>';
	} else {
	echo '<input type="radio" name=hide_online value="y">Yes
		<input type="radio" name=hide_online value="n" checked>No<p>';
	}
	
	echo '<B>Post Billed</B>';         
	if ($postbilled == 'y')
	{
	echo '<input type="radio" name=postbilled value="y" checked>Yes<input type="radio" name=postbilled value="n">No<p>';
	} else {
	echo '<input type="radio" name=postbilled value="y">Yes<input type="radio" name=postbilled value="n" checked>No<p>';
	}

	echo '<B>Activate Notify</B>         
        <INPUT TYPE="text" NAME="activate_notify" VALUE="'.$activate_notify.'"><P>
	<B>Shutoff Notify</B>         
        <INPUT TYPE="text" NAME="shutoff_notify" VALUE="'.$shutoff_notify.'"><P>                                    

	<input type=hidden name=sid value="'.$sid.'">
	<input type=hidden name=load value=services>
        <input type=hidden name=tooltype value=module>
	<input type=hidden name=type value=tools>
        <input type=hidden name=edit value=on>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Save">
	</FORM>';


?>



