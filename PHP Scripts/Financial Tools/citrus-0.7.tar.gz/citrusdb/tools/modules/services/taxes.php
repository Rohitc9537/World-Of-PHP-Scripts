<html>
<body bgcolor="#ffffff">
<h3>Taxes</h3>

[ <a href="index.php?load=services&tooltype=module&type=tools&tax=on">Tax Rates</a> ] 
[ <a href="index.php?load=services&tooltype=module&type=tools&tax=on&taxedservices=on">
	Taxed Services</a> ]

<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$description = $base->input['description'];
$rate = $base->input['rate'];
$if_field = $base->input['if_field'];
$if_value = $base->input['if_value'];
$id = $base->input['id'];
$taxedservices = $base->input['taxedservices'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($taxedservices)
{
	// edit links from services to taxes assigned to them
	include('taxedservices.php');
}
else
{
// show all taxes for editing

if ($submit == 'Add') {
	// then we add a new tax
	$query = "INSERT INTO tax_rates (description,rate,if_field,if_value) 
	VALUES ('$description','$rate','$if_field','$if_value')";
	
	$result = $DB->Execute($query) or die ("Query Failed");

	print "<h3>Tax Rates Updated</h3> 
	[<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}

if ($submit == 'Delete') {
	// then we add a new tax
	$query = "DELETE FROM tax_rates WHERE id = '$id'";
	$result = $DB->Execute($query) or die ("Query Failed");	

	print "<h3>Tax Rates Updated</h3> 
	[<a href=\"index.php?load=services&tooltype=module&type=tools\">done</a>]";
}

echo '<p><b>Tax Rates</b><p>';

$query = "SELECT * FROM tax_rates";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");

echo '<table cellpadding=5 cellspacing=1><tr bgcolor="#eeeeee">';
echo '<td><b>id</b></td> <td><b>Description</b></td> <td><b>Rate</b></td> <td><b>If-Field</b></td><td><b>If-Value</b></td> <td></td>
</tr>';

while ($myresult = $result->FetchRow())
{
	$id = $myresult['id'];
        $desc = $myresult['description'];
        $rate = $myresult['rate'];
	$if_field = $myresult['if_field'];
	$if_value = $myresult['if_value'];
	print "<tr bgcolor=\"#eeeeee\"><td>$id</td><td>$desc</td><td>$rate</td><td>$if_field</td><td>$if_value</td>";
	print "<td><a href=\"index.php?load=services&tooltype=module&type=tools&tax=on&delete=on&id=$id&submit=Delete\">Delete</a></td></tr>\n";
}

echo '</table><p>
<b>New Tax Rate</b><br>
<FORM ACTION="index.php" METHOD="GET">
Description: <input type=text name="description"><br>
Rate: <input type="text" name="rate"><br>
If-Field <input type=text name="if_field"><br>
If-Value <input type=text name="if_value"><br>
<input type=hidden name=load value=services>
<input type=hidden name=tooltype value=module>
<input type=hidden name=type value=tools>
<input type=hidden name=tax value=on>
<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Add">
</FORM>
<p>';

}
?>

</body>
</html>
