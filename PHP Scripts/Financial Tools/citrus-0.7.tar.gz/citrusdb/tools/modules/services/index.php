<html>
<body bgcolor="#ffffff">
<h3>Services</h3>
<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$new = $base->input['new'];
$link = $base->input['link'];
$edit = $base->input['edit'];
$tax = $base->input['tax'];
$options = $base->input['options'];
$editoptions = $base->input['editoptions'];

if ($new)
{
        include('newservice.php');
}
else if ($tax)
{
	include('taxes.php');
}
else if ($link)
{
        include('linkservice.php');
}
else if ($edit)
{
        include('editservice.php');
}
else if ($options)
{
        include('options.php');
}
else if ($editoptions)
{
        include('editoptions.php');
}
else
{

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

echo '[ <a href="index.php?load=services&tooltype=module&new=on&type=tools">Add New Service</a> ]';
echo '&nbsp; &nbsp; [ <a href="index.php?load=services&tooltype=module&link=on&type=tools">Link Services</a> ]';
echo '&nbsp; &nbsp; [ <a href="index.php?load=services&tooltype=module&options=on&type=tools">Options Tables</a> ]';
echo '&nbsp; &nbsp; [ <a href="index.php?load=services&tooltype=module&tax=on&type=tools">Taxes</a> ]';

if ($submit) {

}

print "<p><table cellpadding=5 cellspacing=1><tr bgcolor=\"#eeeeee\">
<td><b>ID</b></td>
<td><b>Description</b></td>
<td><b>Pricerate</b></td>
<td><b>Frequency</b></td>
<td></td><tr bgcolor=\"#eeeeee\">";

        // get the list of users from the table
        $query = "SELECT * FROM master_services ORDER BY service_description";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	
	while ($myresult = $result->FetchRow())
	{
	$id = $myresult['id'];
        $description = $myresult['service_description'];
        $pricerate = $myresult['pricerate'];
	$frequency = $myresult['frequency'];

	print "<td>$id</td><td>$description</td><td>$pricerate</td><td>$frequency</td><td><a href=\"index.php?load=services&tooltype=module&edit=on&sid=$id&type=tools\">Edit</a></td><tr bgcolor=\"#eeeeee\">\n";
	}
}
?>
</table>
</body>
</html>
