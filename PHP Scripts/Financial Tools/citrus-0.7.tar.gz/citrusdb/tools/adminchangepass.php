<?php
// Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$new_password1 = $base->input['new_password1'];
$new_password2 = $base->input['new_password2'];
$userid = $base->input['userid'];

// check that the user has admin privileges
$user =  user_getname();
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
	if ($new_password1 == $new_password2) {
	$query = "UPDATE user SET password = '$new_password1' WHERE id = '$userid'";
        $result = $DB->Execute($query) or die ("Query Failed");
	print "<h3>Password Changed</h3>";
	}
	else {
	print "<h3>Error: Passwords do not match</h3>";
	}

}

if ($feedback) {
	echo '<FONT COLOR="RED"><H2>'.$feedback.'</H2></FONT>';
}

echo '<script language="JavaScript" src="../include/md5.js"></script>
	<script language="JavaScript" src="../include/verify.js"></script>
	<H3>Change Password</H3>
	<P>
	<FORM ACTION="index.php" METHOD="GET">
        <input type=hidden name=load value="adminchangepass">
	User ID: '.$userid.'
	<INPUT TYPE=hidden NAME="userid" VALUE="'.$userid.'" SIZE="10" MAXLENGTH="32">
	<P>
	<B>NEW Password:</B><BR>
	<INPUT TYPE="password" NAME="new_password1" VALUE="" SIZE="10" MAXLENGTH="32">
	<P>
	<B>NEW Password (again):</B><BR>
	<INPUT TYPE="password" NAME="new_password2" VALUE="" SIZE="10" MAXLENGTH="32">
	<P>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Change My Password" onclick="new_password1.value = calcMD5(new_password1.value); new_password2.value = calcMD5(new_password2.value);">
	</FORM>';
?>









