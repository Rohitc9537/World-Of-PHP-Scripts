<html>
<body bgcolor="#ffffff">
<h3>Add Modules</h3>
[ <a href="index.php?load=modules&type=tools">Go Back</a> ]
<p>

<?php
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// GET & POST Variables
$feedback = $_POST['feedback'];
$submit = $base->input['submit'];
$commonname = $base->input['commonname'];
$modulename = $base->input['modulename'];
$sortorder = $base->input['sortorder'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
	// insert groupname and username into the groups table
	$query = "INSERT INTO modules (commonname,modulename,sortorder) VALUES ('$commonname','$modulename','$sortorder')";
	$result = $DB->Execute($query) or die ("Query Failed");
	print "<h3>Modules Updated</h3>";
}

echo "Before You can add a new module you must put your new module folder inside the $path_to_citrus/modules folder. ";
	echo '
	<P>
	<FORM ACTION="index.php" METHOD="GET">
	<B>Common Name</B><BR><INPUT TYPE="TEXT" NAME="commonname">
	<P>
	<B>Module Folder Name</B><BR><INPUT TYPE="TEXT" NAME="modulename">
	<P>
	<B>Sort Order</B><BR><INPUT TYPE="TEXT" NAME="sortorder">
	<P>
	<input type=hidden name=load value=addmodule>
	<input type=hidden name=type value=tools>
	<INPUT TYPE="SUBMIT" NAME="submit" VALUE="Add">
	</FORM>';


?>

</body>
</html>
