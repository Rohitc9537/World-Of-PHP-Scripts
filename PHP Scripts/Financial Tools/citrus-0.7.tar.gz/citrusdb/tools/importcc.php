<html>
<body bgcolor="#ffffff">
<h3>Import Credit Card Results</h3>
<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];

if ($submit) {
// save information
	
	// get the path_to_citrus
	$query = "SELECT path_to_ccfile FROM general WHERE id = 1";
        $DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Query Failed");
	$myresult = $result->fields;
        $path_to_ccfile = $myresult['path_to_ccfile'];
	
	$myfile = "$path_to_ccfile/newfile.txt";

	print "File Uploaded: $myfile<p>";

	// OPEN THE FILE AND PROCESS IT
	// line format: "transaction code","card number","card expire","amount","billing id","approved or declined"
	// line example: "CHARGE","4111111111111111","0202","18.95","1","Yes"

	$fp = @fopen($myfile, "r") or die ("Cannot open $myfile");
	
	while ($line = @fgetcsv($fp, 1024)) // open the CSV file 
	{
		list($transaction_code, $cardnumber, $cardexp, $amount, $billing_id, $response_code) = $line;
		
		$response_id = substr ($response_code,0,1);		

		// declined or credit (first letter of response code is an 'N')
		if ($response_id == 'N')
		{
			$query = "INSERT INTO payment_history (creation_date, transaction_code, billing_id, creditcard_number,creditcard_expire, response_code, billing_amount, status, payment_type)
				VALUES(CURRENT_DATE,'$transaction_code','$billing_id','$cardnumber','$cardexp','$response_code','$amount','declined','creditcard')";
                	$result = $DB->Execute($query) or die ("Query Failed");		
		}
		// authorized (first letter of response code is a 'Y')
		else {
			$query = "INSERT INTO payment_history (creation_date, transaction_code, billing_id, creditcard_number, creditcard_expire, response_code, billing_amount, status, payment_type) 
				VALUES(CURRENT_DATE,'$transaction_code','$billing_id','$cardnumber','$cardexp','$response_code','$amount','authorized','creditcard')";
        		$result = $DB->Execute($query) or die ("Query Failed");

			// update the billing_details for things that still need to be paid up
			$query = "SELECT * FROM billing_details WHERE paid_amount < billed_amount AND billing_id = $billing_id";
			$DB->SetFetchMode(ADODB_FETCH_ASSOC);
			$result = $DB->Execute($query) or die ("Query Failed");

			while (($myresult = $result->FetchRow()) and ($amount > 0)) 
			{
				$id = $myresult['id'];
				$paid_amount = $myresult['paid_amount'];
				$billed_amount = $myresult['billed_amount'];
				
				// do stuff 
				$owed = $billed_amount - $paid_amount;
			
				if ($amount >= $owed) {
					$amount = $amount - $owed;
					$fillamount = $owed + $paid_amount;
					$query = "UPDATE billing_details SET paid_amount = '$fillamount' WHERE id = $id";
					$greaterthanresult = $DB->Execute($query) or die ("Query Failed");
				} else { 
				// amount is  less than owed
					$available = $amount;
					$amount = 0;
					$fillamount = $available + $paid_amount;
					$query = "UPDATE billing_details SET paid_amount = '$fillamount' WHERE id = $id";
					$lessthanresult = $DB->Execute($query) or die ("Query Failed");
				} //end if
			} // end while
		} // end if
	} // end while
	
	// close the file
	@fclose($fp) or die ("Cannot close $myfile");
	
}

// use the uploadcc.php file to upload the file to the io directory
// uploadcc will redirect back to this file to perform the submit processing

echo '<FORM ACTION="index.php?load=uploadcc&type=tools" METHOD="POST" enctype="multipart/form-data">
<table>
<td>Import this file:</td><td><input type=file name="userfile"></td><tr> 
<td></td><td><br><input type=submit name="Import"></td>
</table>
</form> 
';

?>
</body>
</html>
