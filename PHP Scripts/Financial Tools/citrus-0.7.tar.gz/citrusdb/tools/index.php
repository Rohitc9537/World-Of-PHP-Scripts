<html>
<head>
<LINK href="../citrus.css" type=text/css rel=STYLESHEET>
<title>CitrusDB Tools</title>
</head>
<body marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 bgcolor="#ffffff">
<table width=100% height=100% cellpadding=10 cellspacing=0 border=0>
<td bgcolor="#eeeeee" width=180 valign=top>
<a href="index.php?load=search&type=base" target="_parent">[ Go Back ]</a><p>
<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>
// read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// query user properties
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;

/*----------------------------------------------------------------------------*/
// Show User Functions - for all users
/*----------------------------------------------------------------------------*/
print "<ul id=\"tabnav\"><li><b>User: $user</b></li>";

echo '
<ul id="tabnav">
<li><a href="index.php?load=changepass&type=tools">Change Your Password</a></li>
</ul>
';

/*----------------------------------------------------------------------------*/
// Load Module Listing
// For any user with manager access or higher
/*----------------------------------------------------------------------------*/
if (($myresult['manager'] == 'y') OR ($myresult['admin'] == 'y'))
{	
	// Print Modules Included Menu File
	$query = "SELECT * FROM modules ORDER BY sortorder";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Modules Query Failed");

	while ($mymoduleresult = $result->FetchRow())
	{
	$commonname = $mymoduleresult['commonname'];
        $modulename = $mymoduleresult['modulename'];
	include('tools/modules/'.$modulename.'/menu.php');
	}
}
/*----------------------------------------------------------------------------*/
// Show Admin Functions
/*----------------------------------------------------------------------------*/
if ($myresult['admin'] == 'y')
{
echo '
<li><b>Admin</b></li>
<ul id="tabnav">
<li><a href="index.php?load=general&type=tools">General Configuration</a></li>
<li><a href="index.php?load=users&type=tools">Users</a></li>
<li><a href="index.php?load=groups&type=tools">Groups</a></li>
<li><a href="index.php?load=modules&type=tools">Edit Modules</a></li>
</ul>
';
}

/*----------------------------------------------------------------------------*/
// Show Reports
// print reports for manager
/*----------------------------------------------------------------------------*/
if (($myresult['manager'] == 'y') OR ($myresult['admin'] == 'y'))
{
echo '
<li><b>Reports</b></li>
<ul id="tabnav">
<li><a href="index.php?load=summary&type=tools">Customer Summary</a></li>
<li><a href="index.php?load=revenue&type=tools">Revenue Report</a></li>
<li><a href="index.php?load=pastdue&type=tools">Past Due Report</a></li>
</ul>
';
}

?>
</td>
<td valign=top>
<?php
/*----------------------------------------------------------------------------*/
// Load tools when link clicked
/*----------------------------------------------------------------------------*/
$loadname = $base->input["load"];
$tooltype = $base->input["tooltype"];

if ($loadname == "") {
	include('version.php');
}
else
{
if ($tooltype == "module")
        {
		$filepath = "$path_to_citrus/tools/modules/$loadname/index.php";
		if (file_exists($filepath)) {
			include('tools/modules/'.$loadname.'/index.php');
		}
        }

else 	{
	$filepath = "$path_to_citrus/tools/$loadname.php";
		if (file_exists($filepath)) {
			include('tools/'.$loadname.'.php');
		}	
	}

}
?>


</td>
</table>
</body>
</html>
