<html>
<body bgcolor="#ffffff">
<h3>Edit User</h3>
<?php
// Copyright (C) 2002-2005  Paul Yasi <paul@citrusdb.org>, read the README file for more information
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$submit = $base->input['submit'];
$userid = $base->input['userid'];
$username = $base->input['username'];
$realname = $base->input['realname'];
$admin = $base->input['admin'];
$manager = $base->input['manager'];

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

if ($submit) {
// save customer information
      $query = "UPDATE user 
        SET username = '$username',
        real_name = '$realname',
        admin = '$admin',
        manager = '$manager' 
	WHERE id = '$userid'";
        $result = $DB->Execute($query) or die ("Save Query Failed");

        print "<h3>Changes Saved</h3>";

}

        // get the variables out of the id 1 general configuration table
        $query = "SELECT * FROM user WHERE id = '$userid'";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
        $result = $DB->Execute($query) or die ("Query Failed");
        
	$myresult = $result->fields;
        $username = $myresult['username'];
        $password = $myresult['password'];
        $realname = $myresult['real_name'];
        $admin = $myresult['admin'];
        $manager = $myresult['manager'];

echo '<script language="JavaScript" src="include/md5.js"></script>
        <script language="JavaScript" src="include/verify.js"></script>
	[<a href="index.php?load=adminchangepass&userid='.$userid.'">Change Password</a>]
	<p>
	<FORM ACTION="index.php" METHOD="GET">
	<input type=hidden name=load value=edituser>
	<input type=hidden name=type value=tools>
        <B>Real Name:</B><BR>
        <INPUT TYPE="TEXT" NAME="realname" VALUE="'.$realname.'" SIZE="20" MAXLENGTH="65">
        <P>
        <B>User Name:</B><BR>
        <INPUT TYPE="TEXT" NAME="username" VALUE="'.$username.'" SIZE="10" MAXLENGTH="32">
        <P>
        <b>Tool Privileges:</b><br>
        <table>';
	
if ($admin == 'y') {
echo '<td>Admin</td><td><input type="radio" name=admin value="y" checked>Yes<input type="radio" name=admin value="n">No<tr>';
} else {
echo '<td>Admin</td><td><input type="radio" name=admin value="y">Yes<input type="radio" name=admin value="n" checked>No<tr>';
}

if ($manager == 'y') {
echo '<td>Manager</td><td><input type="radio" name=manager value="y" checked>Yes<input type="radio" name=manager value="n">No<tr>';
} else {
echo '<td>Manager</td><td><input type="radio" name=manager value="y">Yes<input type="radio" name=manager value="n" checked>No<tr>';
}


echo '</table>
        <p>
	<input type=hidden name="userid" value="'.$userid.'">
        <INPUT TYPE="SUBMIT" NAME="submit" VALUE="Update Account">
	</FORM>';
?>
</body>
</html>







