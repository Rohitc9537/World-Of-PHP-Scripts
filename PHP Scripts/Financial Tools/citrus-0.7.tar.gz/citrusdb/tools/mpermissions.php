<?php
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

//GET Variables
$module = $base->input['module'];

print <<<END
<html>
<body bgcolor="#ffffff">
<h3>Module ( $module ) Permissions</h3>
[ <a href="index.php?load=apermissions&type=tools&module=$module">Add Permission</a> ]
<p>
END;

// check that the user has admin privileges
$query = "SELECT * FROM user WHERE username='$user'";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");
$myresult = $result->fields;
if ($myresult['admin'] == 'n') {
        echo 'You must have admin privileges to use this feature<br>';
        exit;
}

$query = "SELECT * FROM module_permissions WHERE modulename='$module' ORDER BY user";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Query Failed");

print <<<END
<table cellpadding=5 cellspacing=1><tr bgcolor="#eeeeee"><td><b>Module Name</b></td><td><b>Permission</b></td><td><b>User/Group</b></td><td><b>Remove</b></td></tr>
END;
while ($myresult = $result->FetchRow())
{
	$pid = $myresult['id'];
        $permission = $myresult['permission'];
        $user = $myresult['user'];

        $query = "SELECT real_name FROM user WHERE username='$user'";
        $uresult = $DB->Execute($query) or die ("Query Failed");
        $myuresult = $uresult->fields;
        $name = $myuresult['real_name'];
        if ($name == "") { $name=$user; }
        if ($permission == "r") { $permission="View"; }
        if ($permission == "c") { $permission="Create"; }
        if ($permission == "m") { $permission="Modify"; }
        if ($permission == "d") { $permission="Remove"; }
        if ($permission == "f") { $permission="Full Control"; }
	print "<tr bgcolor=\"#eeeeee\"><td>$module</td><td>$permission</td><td>$name</td><td><a href=\"index.php?load=rpermissions&module=$module&type=tools&pid=$pid\">[ Remove ]</a></td></tr>";

}

?>
</table>
</body>
</html>
