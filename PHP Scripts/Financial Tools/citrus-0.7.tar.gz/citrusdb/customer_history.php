<!-- Copyright (C) 2002  Paul Yasi <paul@citrusdb.org>, read the README file for more information -->
<html>
<head>
<LINK href="citrus.css" type=text/css rel=STYLESHEET>
</head>
<body bgcolor="#eeeedd" marginheight=0 marginwidth=1 leftmargin=1 rightmargin=0>
<?php
/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
	if(constant("INDEX_CITRUS") <> 1){
		echo "You must be logged in to run this.  Goodbye.";
		exit;	
	}
	
	if (!defined("INDEX_CITRUS")) {
		echo "You must be logged in to run this.  Goodbye.";
	        exit;
	}
	

	// GET Variables
	$account_number = $base->input['account_number'];
	
	echo '<table cellspacing=0 cellpadding=4 border=0>
		<td bgcolor="#ddddcc" width=130><b>Date Time</b></td>
		<td bgcolor="#ddddcc" width=80><b>Created By</b></td>
		<td bgcolor="#ddddcc" width=110><b>Notify</b></td>
		<td bgcolor="#ddddcc" width=80><b>Status</b></td>
		<td bgcolor="#ddddcc" width=320><b>Description</b></td>';

	$query = "SELECT * FROM customer_history WHERE account_number = '$account_number' ORDER BY creation_date DESC";
	$DB->SetFetchMode(ADODB_FETCH_ASSOC);
	$result = $DB->Execute($query) or die ("Customer History Query Failed");
	while ($myresult = $result->FetchRow())
	{
		$creation_date = $myresult['creation_date'];
		$created_by = $myresult['created_by'];
		$notify = $myresult['notify'];
		$status = $myresult['status'];
		$description = $myresult['description'];

		print "<tr bgcolor=\"#ffffee\">";
		print "<td style=\"border-top: 1px solid grey;\">$creation_date &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$created_by &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$notify &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$status &nbsp;</td>";
		print "<td style=\"border-top: 1px solid grey;\">$description &nbsp;</td>";
	}

	echo '</table>';

	?>
</body>
</html>
