<?php
// Copyright (C) 2002-2004  Paul Yasi <paul@citrusdb.org>
// Read the README file for more information

/*----------------------------------------------------------------------------*/
// Check for authorized accesss
/*----------------------------------------------------------------------------*/
if(constant("INDEX_CITRUS") <> 1){
	echo "You must be logged in to run this.  Goodbye.";
	exit;	
}

if (!defined("INDEX_CITRUS")) {
	echo "You must be logged in to run this.  Goodbye.";
        exit;
}

// Variables
//var_dump($_POST);
$id = $_POST['id'];
$s1 = $_POST['s1'];
$s2 = $_POST['s2'];
$s3 = $_POST['s3'];
$s4 = $_POST['s4'];
$s5 = $_POST['s5'];

$user =  $u->user_getname();

// figure out which type of search it is from the searches table
$query = "SELECT * FROM searches WHERE id = $id";
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$result = $DB->Execute($query) or die ("Search Query Failed");
$myresult = $result->fields;	
	
// assign the query from the search to the query string
// replace the s1 thru s5 etc place holders with the actual variables
$query = str_replace("%s1%", $s1, $myresult['query']);
$query = str_replace("%s2%", $s2, $query);
$query = str_replace("%s3%", $s3, $query);
$query = str_replace("%s4%", $s4, $query);
$query = str_replace("%s5%", $s5, $query);

        $result = $DB->Execute($query) or die ("Search Result Query Failed");
        $keyresult = $DB->Execute($query) or die ("Search Key Result Query Failed");

        echo "$query<p><h3>Found Set</h3>
	<table cellpadding=5 cellspacing=1 border=0>
	<tr bgcolor=#ccccdd><td></td>";
        
	$myresult = $keyresult->fields;	

	// print the the column titles
        $i = 0;

   	// check for the array and print any results
	if (is_array($myresult)) {
   		foreach ($myresult as $key => $value) {          
   			echo "<td>$key</td>\n";
      			$i++;
   		} 
	}


while ($myresult = $result->FetchRow())
{
	
	// get the account_number
        foreach ($myresult as $key => $value) {
                if ($key == "account_number") {
                        $acnum = $value;
                }
                if ($key == "id") {
                        $id = $value;
                }
        
        }

	echo "<tr bgcolor=#ddddee><td><a href=\"index.php?load=viewaccount&type=fs&acnum=$acnum\">View</a></td>";

	foreach ($myresult as $key => $value) {
		echo "<td>$value</td>\n";   
        }
}
	
if (empty($key)) {
	echo "<tr><td><b>Sorry no records found!</b></td></tr>\n";
	echo "<tr><td>Click <a href=\"index.php?load=search&type=base\"> here</a> to try again.";
} 

	echo '</table>';
	
?>
