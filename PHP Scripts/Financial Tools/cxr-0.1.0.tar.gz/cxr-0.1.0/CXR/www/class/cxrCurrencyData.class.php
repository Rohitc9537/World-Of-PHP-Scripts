<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrCurrencyData.class.php                 *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Currency data storage class
class CXRCurrencyData {
  
  var $CountryToCode = array();
  var $CodeToInfo = array();
  
  function CXRCurrencyData() {
    
    $this->CountryToCode = array (
      'Afghanistan' => 
      array (
        0 => 'AFA',
      ),
      'Albania' => 
      array (
        0 => 'ALL',
      ),
      'Algeria' => 
      array (
        0 => 'DZD',
      ),
      'America (United States)' => 
      array (
        0 => 'USD',
      ),
      'American Samoa' => 
      array (
        0 => 'USD',
      ),
      'Andorra' => 
      array (
        0 => 'EUR',
      ),
      'Angola' => 
      array (
        0 => 'AOA',
      ),
      'Anguilla' => 
      array (
        0 => 'XCD',
      ),
      'Antigua and Barbuda' => 
      array (
        0 => 'XCD',
      ),
      'Argentina' => 
      array (
        0 => 'ARS',
      ),
      'Armenia' => 
      array (
        0 => 'AMD',
      ),
      'Aruba' => 
      array (
        0 => 'AWG',
      ),
      'Ashmore and Cartier Islands' => 
      array (
        0 => 'AUD',
      ),
      'Australia' => 
      array (
        0 => 'AUD',
      ),
      'Austria' => 
      array (
        0 => 'EUR',
      ),
      'Azerbaijan' => 
      array (
        0 => 'AZM',
      ),
      'Azores' => 
      array (
        0 => 'EUR',
      ),
      'Bahamas' => 
      array (
        0 => 'BSD',
      ),
      'Bahrain' => 
      array (
        0 => 'BHD',
      ),
      'Bajan (Barbados)' => 
      array (
        0 => 'BBD',
      ),
      'Balearic Islands' => 
      array (
        0 => 'EUR',
      ),
      'Bangladesh' => 
      array (
        0 => 'BDT',
      ),
      'Barbados' => 
      array (
        0 => 'BBD',
      ),
      'Belarus' => 
      array (
        0 => 'BYR',
      ),
      'Belgium' => 
      array (
        0 => 'EUR',
      ),
      'Belize' => 
      array (
        0 => 'BZD',
      ),
      'Benin' => 
      array (
        0 => 'XOF',
      ),
      'Bermuda' => 
      array (
        0 => 'BMD',
      ),
      'Bhutan' => 
      array (
        0 => 'INR',
        1 => 'BTN',
      ),
      'Bolivia' => 
      array (
        0 => 'BOB',
      ),
      'Bonaire' => 
      array (
        0 => 'ANG',
      ),
      'Bosnia and Herzegovina' => 
      array (
        0 => 'BAM',
      ),
      'Botswana' => 
      array (
        0 => 'BWP',
      ),
      'Brazil' => 
      array (
        0 => 'BRL',
      ),
      'Britain (United Kingdom)' => 
      array (
        0 => 'GBP',
      ),
      'British Indian Ocean Territory' => 
      array (
        0 => 'GBP',
        1 => 'USD',
      ),
      'British Virgin Islands' => 
      array (
        0 => 'USD',
      ),
      'Brunei' => 
      array (
        0 => 'BND',
        1 => 'SGD',
      ),
      'Bulgaria' => 
      array (
        0 => 'BGN',
      ),
      'Burkina Faso' => 
      array (
        0 => 'XOF',
      ),
      'Burma (Myanmar)' => 
      array (
        0 => 'MMK',
      ),
      'Burundi' => 
      array (
        0 => 'BIF',
      ),
      'Cambodia' => 
      array (
        0 => 'KHR',
      ),
      'Cameroon' => 
      array (
        0 => 'XAF',
      ),
      'Canada' => 
      array (
        0 => 'CAD',
      ),
      'Canary Islands' => 
      array (
        0 => 'EUR',
      ),
      'Cape Verde' => 
      array (
        0 => 'CVE',
      ),
      'Cayman Islands' => 
      array (
        0 => 'KYD',
      ),
      'Central African Republic, CFA Franc BEAC' => 
      array (
        0 => 'XAF',
      ),
      'CFA Communauté Financière Africaine BEAC Franc' => 
      array (
        0 => 'XAF',
      ),
      'CFA Communauté Financière Africaine BCEAO Franc' => 
      array (
        0 => 'XOF',
      ),
      'Chad' => 
      array (
        0 => 'XAF',
      ),
      'Chile' => 
      array (
        0 => 'CLP',
      ),
      'China' => 
      array (
        0 => 'CNY',
      ),
      'Christmas Island' => 
      array (
        0 => 'AUD',
      ),
      'Cocos (Keeling Islands)' => 
      array (
        0 => 'AUD',
      ),
      'Colombia' => 
      array (
        0 => 'COP',
      ),
      'Communauté Financière Africaine BEAC Franc' => 
      array (
        0 => 'XAF',
      ),
      'Communauté Financière Africaine BCEAO Franc' => 
      array (
        0 => 'XOF',
      ),
      'Comoros' => 
      array (
        0 => 'KMF',
      ),
      'Comptoirs Français du Pacifique Franc' => 
      array (
        0 => 'XPF',
      ),
      'Congo/Brazzaville' => 
      array (
        0 => 'XAF',
      ),
      'Congo/Kinshasa' => 
      array (
        0 => 'CDF',
      ),
      'Cook Islands' => 
      array (
        0 => 'NZD',
      ),
      'Coral Sea Islands' => 
      array (
        0 => 'AUD',
      ),
      'Costa Rica' => 
      array (
        0 => 'CRC',
      ),
      'Côte d\'Ivoire' => 
      array (
        0 => 'XOF',
      ),
      'Croatia' => 
      array (
        0 => 'HRK',
      ),
      'Cuba' => 
      array (
        0 => 'CUC',
        1 => 'CUP',
      ),
      'Curaço' => 
      array (
        0 => 'ANG',
      ),
      'Cyprus' => 
      array (
        0 => 'CYP',
      ),
      'Czech Republic' => 
      array (
        0 => 'CZK',
      ),
      'Denmark' => 
      array (
        0 => 'DKK',
      ),
      'Djibouti' => 
      array (
        0 => 'DJF',
      ),
      'Dominica' => 
      array (
        0 => 'XCD',
      ),
      'Dominican Republic' => 
      array (
        0 => 'DOP',
      ),
      'Dutch (Netherlands)' => 
      array (
        0 => 'EUR',
      ),
      'East Caribbean Dollar' => 
      array (
        0 => 'XCD',
      ),
      'East Timor' => 
      array (
        0 => 'USD',
      ),
      'Ecuador' => 
      array (
        0 => 'USD',
      ),
      'Egypt' => 
      array (
        0 => 'EGP',
      ),
      'El Salvador' => 
      array (
        0 => 'SVC',
      ),
      'England (United Kingdom)' => 
      array (
        0 => 'GBP',
      ),
      'Equatorial Guinea' => 
      array (
        0 => 'XAF',
      ),
      'Eritrea' => 
      array (
        0 => 'ERN',
      ),
      'Estonia' => 
      array (
        0 => 'EEK',
      ),
      'Ethiopia' => 
      array (
        0 => 'ETB',
      ),
      'Euro' => 
      array (
        0 => 'EUR',
      ),
      'Europa Island' => 
      array (
        0 => 'EUR',
      ),
      'Falkland Islands' => 
      array (
        0 => 'FKP',
      ),
      'Faroe Islands' => 
      array (
        0 => 'DKK',
      ),
      'Fiji' => 
      array (
        0 => 'FJD',
      ),
      'Finland' => 
      array (
        0 => 'EUR',
      ),
      'France' => 
      array (
        0 => 'EUR',
      ),
      'French Guiana' => 
      array (
        0 => 'EUR',
      ),
      'French Polynesia' => 
      array (
        0 => 'XPF',
        1 => 'EUR',
      ),
      'French Southern and Antarctic Lands' => 
      array (
        0 => 'EUR',
      ),
      'Gabon' => 
      array (
        0 => 'XAF',
      ),
      'Gambia' => 
      array (
        0 => 'GMD',
      ),
      'Gaza Strip' => 
      array (
        0 => 'ILS',
      ),
      'Georgia' => 
      array (
        0 => 'GEL',
      ),
      'Germany' => 
      array (
        0 => 'EUR',
      ),
      'Ghana' => 
      array (
        0 => 'GHC',
      ),
      'Gibraltar' => 
      array (
        0 => 'GIP',
      ),
      'Great Britain (United Kingdom)' => 
      array (
        0 => 'GBP',
      ),
      'Greece' => 
      array (
        0 => 'EUR',
      ),
      'Greenland' => 
      array (
        0 => 'DKK',
      ),
      'Grenada' => 
      array (
        0 => 'XCD',
      ),
      'Guadeloupe' => 
      array (
        0 => 'EUR',
      ),
      'Guam' => 
      array (
        0 => 'USD',
      ),
      'Guatemala' => 
      array (
        0 => 'GTQ',
      ),
      'Guernsey' => 
      array (
        0 => 'GGP',
      ),
      'Guinea' => 
      array (
        0 => 'GNF',
      ),
      'Guinea-Bissau' => 
      array (
        0 => 'XOF',
      ),
      'Guyana' => 
      array (
        0 => 'GYD',
      ),
      'Haiti' => 
      array (
        0 => 'HTG',
      ),
      'Holland' => 
      array (
        0 => 'EUR',
      ),
      'Holy See (Vatican City)' => 
      array (
        0 => 'EUR',
      ),
      'Honduras' => 
      array (
        0 => 'HNL',
      ),
      'Hong Kong' => 
      array (
        0 => 'HKD',
      ),
      'Hungary' => 
      array (
        0 => 'HUF',
      ),
      'Iceland' => 
      array (
        0 => 'ISK',
      ),
      'India' => 
      array (
        0 => 'INR',
      ),
      'Indonesia' => 
      array (
        0 => 'IDR',
      ),
      'International Monetary Fund Special Drawing Right' => 
      array (
        0 => 'XDR',
      ),
      'Iran' => 
      array (
        0 => 'IRR',
      ),
      'Iraq' => 
      array (
        0 => 'IQD',
      ),
      'Ireland' => 
      array (
        0 => 'EUR',
      ),
      'Islas Malvinas (Falkland Islands)' => 
      array (
        0 => 'FKP',
      ),
      'Isle of Man' => 
      array (
        0 => 'IMP',
      ),
      'Israel' => 
      array (
        0 => 'ILS',
      ),
      'Italy' => 
      array (
        0 => 'EUR',
      ),
      'Ivory Coast (Côte d\'Ivoire)' => 
      array (
        0 => 'XOF',
      ),
      'Jamaica' => 
      array (
        0 => 'JMD',
      ),
      'Japan' => 
      array (
        0 => 'JPY',
      ),
      'Jersey' => 
      array (
        0 => 'JEP',
      ),
      'Johnson' => 
      array (
        0 => 'USD',
      ),
      'Jordan' => 
      array (
        0 => 'JOD',
      ),
      'Juan de Nova' => 
      array (
        0 => 'EUR',
      ),
      'Kazakhstan' => 
      array (
        0 => 'KZT',
      ),
      'Kenya' => 
      array (
        0 => 'KES',
      ),
      'Kiribati' => 
      array (
        0 => 'AUD',
      ),
      'Kuwait' => 
      array (
        0 => 'KWD',
      ),
      'Kyrgyzstan' => 
      array (
        0 => 'KGS',
      ),
      'Laos' => 
      array (
        0 => 'LAK',
      ),
      'Latvia' => 
      array (
        0 => 'LVL',
      ),
      'Lebanon' => 
      array (
        0 => 'LBP',
      ),
      'Lesotho' => 
      array (
        0 => 'LSL',
      ),
      'Liberia' => 
      array (
        0 => 'LRD',
      ),
      'Libya' => 
      array (
        0 => 'LYD',
      ),
      'Liechtenstein' => 
      array (
        0 => 'CHF',
      ),
      'Lithuania' => 
      array (
        0 => 'LTL',
      ),
      'Luxembourg' => 
      array (
        0 => 'EUR',
      ),
      'Macau' => 
      array (
        0 => 'MOP',
      ),
      'Macedonia' => 
      array (
        0 => 'MKD',
      ),
      'Madagascar' => 
      array (
        0 => 'MGA',
      ),
      'Madeira Islands' => 
      array (
        0 => 'EUR',
      ),
      'Malawi' => 
      array (
        0 => 'MWK',
      ),
      'Malaysia' => 
      array (
        0 => 'MYR',
      ),
      'Maldives' => 
      array (
        0 => 'MVR',
      ),
      'Mali' => 
      array (
        0 => 'XOF',
      ),
      'Malta' => 
      array (
        0 => 'MTL',
      ),
      'Malvinas (Falkland Islands)' => 
      array (
        0 => 'FKP',
      ),
      'Marshall Islands' => 
      array (
        0 => 'USD',
      ),
      'Martinique' => 
      array (
        0 => 'EUR',
      ),
      'Mauritania' => 
      array (
        0 => 'MRO',
      ),
      'Mauritius' => 
      array (
        0 => 'MUR',
      ),
      'Mayotte' => 
      array (
        0 => 'EUR',
      ),
      'Mexico' => 
      array (
        0 => 'MXN',
      ),
      'Micronesia' => 
      array (
        0 => 'USD',
      ),
      'Midway Islands' => 
      array (
        0 => 'USD',
      ),
      'Moldova' => 
      array (
        0 => 'MDL',
      ),
      'Monaco' => 
      array (
        0 => 'EUR',
      ),
      'Mongolia' => 
      array (
        0 => 'MNT',
      ),
      'Montenegro' => 
      array (
        0 => 'EUR',
      ),
      'Montserrat' => 
      array (
        0 => 'XCD',
      ),
      'Morocco' => 
      array (
        0 => 'MAD',
      ),
      'Mozambique' => 
      array (
        0 => 'MZM',
      ),
      'Myanmar (Burma)' => 
      array (
        0 => 'MMK',
      ),
      'Namibia' => 
      array (
        0 => 'NAD',
      ),
      'Nauru' => 
      array (
        0 => 'AUD',
      ),
      'Navassa' => 
      array (
        0 => 'HTG',
        1 => 'USD',
      ),
      'Nepal' => 
      array (
        0 => 'CNY',
        1 => 'NPR',
      ),
      'Netherlands Antilles' => 
      array (
        0 => 'ANG',
      ),
      'Netherlands' => 
      array (
        0 => 'EUR',
      ),
      'New Caledonia' => 
      array (
        0 => 'XPF',
      ),
      'New Zealand' => 
      array (
        0 => 'NZD',
      ),
      'Nicaragua' => 
      array (
        0 => 'NIO',
      ),
      'Niger' => 
      array (
        0 => 'XOF',
      ),
      'Nigeria' => 
      array (
        0 => 'NGN',
      ),
      'Niue' => 
      array (
        0 => 'NZD',
      ),
      'Norfolk Island' => 
      array (
        0 => 'AUD',
      ),
      'North Korea' => 
      array (
        0 => 'KPW',
      ),
      'Northern Mariana Islands' => 
      array (
        0 => 'USD',
      ),
      'Norway' => 
      array (
        0 => 'NOK',
      ),
      'Oman' => 
      array (
        0 => 'OMR',
      ),
      'Pakistan' => 
      array (
        0 => 'PKR',
      ),
      'Palau' => 
      array (
        0 => 'USD',
      ),
      'Panama' => 
      array (
        0 => 'PAB',
        1 => 'USD',
      ),
      'Papua New Guinea' => 
      array (
        0 => 'PGK',
      ),
      'Paracel Islands' => 
      array (
        0 => 'CNY',
        1 => 'VND',
      ),
      'Paraguay' => 
      array (
        0 => 'PYG',
      ),
      'Peru' => 
      array (
        0 => 'PEN',
      ),
      'Philippines' => 
      array (
        0 => 'PHP',
      ),
      'Pitcairn' => 
      array (
        0 => 'NZD',
      ),
      'Poland' => 
      array (
        0 => 'PLN',
      ),
      'Portugal' => 
      array (
        0 => 'EUR',
      ),
      'Puerto Rico' => 
      array (
        0 => 'USD',
      ),
      'Qatar' => 
      array (
        0 => 'QAR',
      ),
      'Reunion' => 
      array (
        0 => 'EUR',
      ),
      'Romania' => 
      array (
        0 => 'ROL',
      ),
      'Russia' => 
      array (
        0 => 'RUB',
      ),
      'Rwanda' => 
      array (
        0 => 'RWF',
      ),
      'Saba' => 
      array (
        0 => 'ANG',
      ),
      'Saint Helena' => 
      array (
        0 => 'SHP',
      ),
      'Saint Kitts and Nevis' => 
      array (
        0 => 'XCD',
      ),
      'Saint Lucia' => 
      array (
        0 => 'XCD',
      ),
      'Saint Pierre and Miquelon' => 
      array (
        0 => 'EUR',
      ),
      'Saint Vincent and The Grenadines' => 
      array (
        0 => 'XCD',
      ),
      'Saint-Martin' => 
      array (
        0 => 'EUR',
      ),
      'Samoa' => 
      array (
        0 => 'WST',
      ),
      'San Marino' => 
      array (
        0 => 'EUR',
      ),
      'São Tome and Principe' => 
      array (
        0 => 'STD',
      ),
      'Saudi Arabia' => 
      array (
        0 => 'SAR',
      ),
      'Scotland (United Kingdom)' => 
      array (
        0 => 'GBP',
      ),
      'Seborga' => 
      array (
        0 => 'SPL',
      ),
      'Senegal' => 
      array (
        0 => 'XOF',
      ),
      'Serbia' => 
      array (
        0 => 'CSD',
      ),
      'Seychelles' => 
      array (
        0 => 'SCR',
      ),
      'Sierra Leone' => 
      array (
        0 => 'SLL',
      ),
      'Singapore' => 
      array (
        0 => 'SGD',
      ),
      'Sint Eustatius' => 
      array (
        0 => 'ANG',
      ),
      'Sint Maarten' => 
      array (
        0 => 'ANG',
      ),
      'Slovakia' => 
      array (
        0 => 'SKK',
      ),
      'Slovenia' => 
      array (
        0 => 'SIT',
      ),
      'Solomon Islands' => 
      array (
        0 => 'SBD',
      ),
      'Somalia' => 
      array (
        0 => 'SOS',
      ),
      'South Africa' => 
      array (
        0 => 'ZAR',
      ),
      'South Georgia' => 
      array (
        0 => 'GBP',
      ),
      'South Korea' => 
      array (
        0 => 'KRW',
      ),
      'South Sandwich Islands' => 
      array (
        0 => 'GBP',
      ),
      'Spain' => 
      array (
        0 => 'EUR',
      ),
      'Sri Lanka' => 
      array (
        0 => 'LKR',
      ),
      'Sudan' => 
      array (
        0 => 'SDD',
      ),
      'Suriname' => 
      array (
        0 => 'SRD',
      ),
      'Svalbard and Jan Mayen' => 
      array (
        0 => 'NOK',
      ),
      'Swaziland' => 
      array (
        0 => 'SZL',
        1 => 'ZAR',
      ),
      'Sweden' => 
      array (
        0 => 'SEK',
      ),
      'Switzerland' => 
      array (
        0 => 'CHF',
      ),
      'Syria' => 
      array (
        0 => 'SYP',
      ),
      'Taiwan' => 
      array (
        0 => 'TWD',
      ),
      'Tajikistan' => 
      array (
        0 => 'TJS',
        1 => 'RUB',
      ),
      'Tanzania' => 
      array (
        0 => 'TZS',
      ),
      'Thailand' => 
      array (
        0 => 'THB',
      ),
      'Togo' => 
      array (
        0 => 'XOF',
      ),
      'Tokelau' => 
      array (
        0 => 'NZD',
      ),
      'Tonga' => 
      array (
        0 => 'TOP',
      ),
      'Transnistria' => 
      array (
        0 => 'MDL',
      ),
      'Trinidad and Tobago' => 
      array (
        0 => 'TTD',
      ),
      'Tunisia' => 
      array (
        0 => 'TND',
      ),
      'Turkey' => 
      array (
        0 => 'TRY',
        1 => 'out',
      ),
      'Turkmenistan' => 
      array (
        0 => 'TMM',
      ),
      'Turks and Caicos Islands' => 
      array (
        0 => 'USD',
      ),
      'Tuvalu' => 
      array (
        0 => 'AUD',
        1 => 'TVD',
      ),
      'Uganda' => 
      array (
        0 => 'UGX',
      ),
      'Ukraine' => 
      array (
        0 => 'UAH',
      ),
      'United Arab Emirates' => 
      array (
        0 => 'AED',
      ),
      'United Kingdom' => 
      array (
        0 => 'GBP',
      ),
      'United States' => 
      array (
        0 => 'USD',
      ),
      'Uruguay' => 
      array (
        0 => 'UYU',
      ),
      'Uzbekistan' => 
      array (
        0 => 'UZS',
      ),
      'Vanuatu' => 
      array (
        0 => 'VUV',
      ),
      'Vatican City' => 
      array (
        0 => 'EUR',
      ),
      'Venezuela' => 
      array (
        0 => 'VEB',
      ),
      'Vietnam' => 
      array (
        0 => 'VND',
      ),
      'Virgin Islands' => 
      array (
        0 => 'USD',
      ),
      'Wake Island' => 
      array (
        0 => 'USD',
      ),
      'Wallis and Futuna Islands' => 
      array (
        0 => 'XPF',
      ),
      'West Bank' => 
      array (
        0 => 'ILS',
        1 => 'JOD',
      ),
      'Western Sahara' => 
      array (
        0 => 'MAD',
      ),
      'Western Samoa (Samoa)' => 
      array (
        0 => 'WST',
      ),
      'Yemen' => 
      array (
        0 => 'YER',
      ),
      'Zambia' => 
      array (
        0 => 'ZMK',
      ),
      'Zimbabwe' => 
      array (
        0 => 'ZWD',
      ),
    );
    
    
    
    
    $this->CodeToInfo = array (
      'AFA' => 
      array (
        'currency' => 'Afghani',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Afghanistan',
        ),
      ),
      'ALL' => 
      array (
        'currency' => 'Lek',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Albania',
        ),
      ),
      'DZD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Algeria',
        ),
      ),
      'USD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'America (United States)',
          1 => 'American Samoa',
          2 => 'British Indian Ocean Territory',
          3 => 'British Virgin Islands',
          4 => 'East Timor',
          5 => 'Ecuador',
          6 => 'Guam',
          7 => 'Johnson',
          8 => 'Marshall Islands',
          9 => 'Micronesia',
          10 => 'Midway Islands',
          11 => 'Navassa',
          12 => 'Northern Mariana Islands',
          13 => 'Palau',
          14 => 'Panama',
          15 => 'Puerto Rico',
          16 => 'Turks and Caicos Islands',
          17 => 'Virgin Islands',
          18 => 'Wake Island',
        ),
      ),
      'EUR' => 
      array (
        'currency' => 'Euro',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Andorra',
          1 => 'Austria',
          2 => 'Azores',
          3 => 'Balearic Islands',
          4 => 'Belgium',
          5 => 'Canary Islands',
          6 => 'Dutch (Netherlands)',
          7 => 'European Union',
          8 => 'Europa Island',
          9 => 'Finland',
          10 => 'France',
          11 => 'French Guiana',
          12 => 'French Polynesia',
          13 => 'French Southern and Antarctic Lands',
          14 => 'Germany',
          15 => 'Greece',
          16 => 'Guadeloupe',
          17 => 'Holland',
          18 => 'Holy See (Vatican City)',
          19 => 'Ireland',
          20 => 'Italy',
          21 => 'Juan de Nova',
          22 => 'Luxembourg',
          23 => 'Madeira Islands',
          24 => 'Martinique',
          25 => 'Mayotte',
          26 => 'Monaco',
          27 => 'Montenegro',
          28 => 'Netherlands',
          29 => 'Portugal',
          30 => 'Reunion',
          31 => 'Saint Pierre and Miquelon',
          32 => 'Saint-Martin',
          33 => 'San Marino',
          34 => 'Spain',
          35 => 'Vatican City',
        ),
      ),
      'AOA' => 
      array (
        'currency' => 'Kwanza',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Angola',
        ),
      ),
      'XCD' => 
      array (
        'currency' => 'East Caribbean Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Anguilla',
          1 => 'Antigua and Barbuda',
          2 => 'Dominica',
          3 => 'East Caribbean Dollar',
          4 => 'Grenada',
          5 => 'Montserrat',
          6 => 'Saint Kitts and Nevis',
          7 => 'Saint Lucia',
          8 => 'Saint Vincent and The Grenadines',
        ),
      ),
      'ARS' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Argentina',
        ),
      ),
      'AMD' => 
      array (
        'currency' => 'Dram',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Armenia',
        ),
      ),
      'AWG' => 
      array (
        'currency' => 'Guilder',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Aruba',
        ),
      ),
      'AUD' => 
      array (
        'currency' => 'Australia Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Ashmore and Cartier Islands',
          1 => 'Australia',
          2 => 'Christmas Island',
          3 => 'Cocos (Keeling Islands)',
          4 => 'Coral Sea Islands',
          5 => 'Kiribati',
          6 => 'Nauru',
          7 => 'Norfolk Island',
          8 => 'Tuvalu',
        ),
      ),
      'ATS' => 
      array (
        'currency' => 'Schilling',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Austria',
        ),
      ),
      'AZM' => 
      array (
        'currency' => 'Manat',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Azerbaijan',
        ),
      ),
      'BSD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bahamas',
        ),
      ),
      'BHD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bahrain',
        ),
      ),
      'BBD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bajan (Barbados)',
          1 => 'Barbados',
        ),
      ),
      'BDT' => 
      array (
        'currency' => 'Taka',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bangladesh',
        ),
      ),
      'BYR' => 
      array (
        'currency' => 'Ruble',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Belarus',
        ),
      ),
      'BEF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Belgium',
        ),
      ),
      'BZD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Belize',
        ),
      ),
      'XOF' => 
      array (
        'currency' => 'CFA Franc BCEAO',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Benin',
          1 => 'Burkina Faso',
          2 => 'CFA Communauté Financière Africaine BCEAO Franc',
          3 => 'Communauté Financière Africaine BCEAO Franc',
          4 => 'Côte d\'Ivoire',
          5 => 'Guinea-Bissau',
          6 => 'Ivory Coast (Côte d\'Ivoire)',
          7 => 'Mali',
          8 => 'Niger',
          9 => 'Senegal',
          10 => 'Togo',
        ),
      ),
      'BMD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bermuda',
        ),
      ),
      'INR' => 
      array (
        'currency' => 'India Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bhutan',
          1 => 'India',
        ),
      ),
      'BTN' => 
      array (
        'currency' => 'Ngultrum',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bhutan',
        ),
      ),
      'BOB' => 
      array (
        'currency' => 'Boliviano',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bolivia',
        ),
      ),
      'ANG' => 
      array (
        'currency' => 'Netherlands Antilles Guilder',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bonaire',
          1 => 'Curaço',
          2 => 'Netherlands Antilles',
          3 => 'Saba',
          4 => 'Sint Eustatius',
          5 => 'Sint Maarten',
        ),
      ),
      'BAM' => 
      array (
        'currency' => 'Convertible Marka',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bosnia and Herzegovina',
        ),
      ),
      'BWP' => 
      array (
        'currency' => 'Pula',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Botswana',
        ),
      ),
      'BRL' => 
      array (
        'currency' => 'Real',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Brazil',
        ),
      ),
      'GBP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Britain (United Kingdom)',
          1 => 'British Indian Ocean Territory',
          2 => 'England (United Kingdom)',
          3 => 'Great Britain (United Kingdom)',
          4 => 'Scotland (United Kingdom)',
          5 => 'South Georgia',
          6 => 'South Sandwich Islands',
          7 => 'United Kingdom',
        ),
      ),
      'BND' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Brunei',
        ),
      ),
      'SGD' => 
      array (
        'currency' => 'Singapore Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Brunei',
          1 => 'Singapore',
        ),
      ),
      'BGN' => 
      array (
        'currency' => 'Lev',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Bulgaria',
        ),
      ),
      'MMK' => 
      array (
        'currency' => 'Kyat',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Burma (Myanmar)',
          1 => 'Myanmar (Burma)',
        ),
      ),
      'BIF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Burundi',
        ),
      ),
      'KHR' => 
      array (
        'currency' => 'Riel',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cambodia',
        ),
      ),
      'XAF' => 
      array (
        'currency' => 'CFA Franc BEAC',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cameroon',
          1 => 'Central African Republic, CFA Franc BEAC',
          2 => 'CFA Communauté Financière Africaine BEAC Franc',
          3 => 'Chad',
          4 => 'Communauté Financière Africaine BEAC Franc',
          5 => 'Congo/Brazzaville',
          6 => 'Equatorial Guinea',
          7 => 'Gabon',
        ),
      ),
      'CAD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Canada',
        ),
      ),
      'CVE' => 
      array (
        'currency' => 'Escudo',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cape Verde',
        ),
      ),
      'KYD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cayman Islands',
        ),
      ),
      'CLP' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Chile',
        ),
      ),
      'CNY' => 
      array (
        'currency' => 'Yuan Renminbi',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'China',
          1 => 'Nepal',
          2 => 'Paracel Islands',
        ),
      ),
      'COP' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Colombia',
        ),
      ),
      'KMF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Comoros',
        ),
      ),
      'XPF' => 
      array (
        'currency' => '(XPF',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Comptoirs Français du Pacifique Franc',
          1 => 'French Polynesia',
          2 => 'New Caledonia',
          3 => 'Wallis and Futuna Islands',
        ),
      ),
      'CDF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Congo/Kinshasa',
        ),
      ),
      'NZD' => 
      array (
        'currency' => 'New Zealand Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cook Islands',
          1 => 'New Zealand',
          2 => 'Niue',
          3 => 'Pitcairn',
          4 => 'Tokelau',
        ),
      ),
      'CRC' => 
      array (
        'currency' => 'Colon',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Costa Rica',
        ),
      ),
      'HRK' => 
      array (
        'currency' => 'Kuna',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Croatia',
        ),
      ),
      'CUC' => 
      array (
        'currency' => 'Convertible Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cuba',
        ),
      ),
      'CUP' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cuba',
        ),
      ),
      'CYP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Cyprus',
        ),
      ),
      'CZK' => 
      array (
        'currency' => 'Koruna',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Czech Republic',
        ),
      ),
      'DKK' => 
      array (
        'currency' => 'Krone',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Denmark',
          1 => 'Faroe Islands',
          2 => 'Greenland',
        ),
      ),
      'DJF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Djibouti',
        ),
      ),
      'DOP' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Dominican Republic',
        ),
      ),
      'NLG' => 
      array (
        'currency' => 'Guilder',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Dutch (Netherlands)',
          1 => 'Holland (Netherlands)',
          2 => 'Netherlands',
        ),
      ),
      'EGP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Egypt',
        ),
      ),
      'SVC' => 
      array (
        'currency' => 'Colon',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'El Salvador',
        ),
      ),
      'ERN' => 
      array (
        'currency' => 'Nakfa',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Eritrea',
        ),
      ),
      'EEK' => 
      array (
        'currency' => 'Kroon',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Estonia',
        ),
      ),
      'ETB' => 
      array (
        'currency' => 'Birr',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Ethiopia',
        ),
      ),
      'FKP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Falkland Islands',
          1 => 'Islas Malvinas (Falkland Islands)',
          2 => 'Malvinas (Falkland Islands)',
        ),
      ),
      'FJD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Fiji',
        ),
      ),
      'FIM' => 
      array (
        'currency' => 'Markka',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Finland',
        ),
      ),
      'FRF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'France',
        ),
      ),
      'GMD' => 
      array (
        'currency' => 'Dalasi',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Gambia',
        ),
      ),
      'ILS' => 
      array (
        'currency' => 'Israel New Shekel',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Gaza Strip',
          1 => 'Israel',
          2 => 'West Bank',
        ),
      ),
      'GEL' => 
      array (
        'currency' => 'Lari',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Georgia',
        ),
      ),
      'DEM' => 
      array (
        'currency' => 'Deutsche Mark',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Germany',
        ),
      ),
      'GHC' => 
      array (
        'currency' => 'Cedi',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Ghana',
        ),
      ),
      'GIP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Gibraltar',
        ),
      ),
      'GRD' => 
      array (
        'currency' => 'Drachma',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Greece',
        ),
      ),
      'GTQ' => 
      array (
        'currency' => 'Quetzal',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Guatemala',
        ),
      ),
      'GGP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Guernsey',
        ),
      ),
      'GNF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Guinea',
        ),
      ),
      'GYD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Guyana',
        ),
      ),
      'HTG' => 
      array (
        'currency' => 'Gourde',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Haiti',
          1 => 'Navassa',
        ),
      ),
      'VAL' => 
      array (
        'currency' => 'Lira',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Holy See (Vatican City)',
          1 => 'Vatican City',
        ),
      ),
      'HNL' => 
      array (
        'currency' => 'Lempira',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Honduras',
        ),
      ),
      'HKD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Hong Kong',
        ),
      ),
      'HUF' => 
      array (
        'currency' => 'Forint',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Hungary',
        ),
      ),
      'ISK' => 
      array (
        'currency' => 'Krona',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Iceland',
        ),
      ),
      'IDR' => 
      array (
        'currency' => 'Rupiah',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Indonesia',
        ),
      ),
      'XDR' => 
      array (
        'currency' => 'XDR',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'International Monetary Fund Special Drawing Right',
        ),
      ),
      'IRR' => 
      array (
        'currency' => 'Rial',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Iran',
        ),
      ),
      'IQD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Iraq',
        ),
      ),
      'IEP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Ireland',
        ),
      ),
      'IMP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Isle of Man',
        ),
      ),
      'ITL' => 
      array (
        'currency' => 'Lira',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Italy',
        ),
      ),
      'JMD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Jamaica',
        ),
      ),
      'JPY' => 
      array (
        'currency' => 'Yen',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Japan',
        ),
      ),
      'JEP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Jersey',
        ),
      ),
      'JOD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Jordan',
          1 => 'West Bank',
        ),
      ),
      'KZT' => 
      array (
        'currency' => 'Tenge',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Kazakhstan',
        ),
      ),
      'KES' => 
      array (
        'currency' => 'Shilling',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Kenya',
        ),
      ),
      'KWD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Kuwait',
        ),
      ),
      'KGS' => 
      array (
        'currency' => 'Som',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Kyrgyzstan',
        ),
      ),
      'LAK' => 
      array (
        'currency' => 'Kip',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Laos',
        ),
      ),
      'LVL' => 
      array (
        'currency' => 'Lat',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Latvia',
        ),
      ),
      'LBP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Lebanon',
        ),
      ),
      'LSL' => 
      array (
        'currency' => 'Loti',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Lesotho',
        ),
      ),
      'LRD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Liberia',
        ),
      ),
      'LYD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Libya',
        ),
      ),
      'CHF' => 
      array (
        'currency' => 'Switzerland Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Liechtenstein',
          1 => 'Switzerland',
        ),
      ),
      'LTL' => 
      array (
        'currency' => 'Litas',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Lithuania',
        ),
      ),
      'LUF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Luxembourg',
        ),
      ),
      'MOP' => 
      array (
        'currency' => 'Pataca',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Macau',
        ),
      ),
      'MKD' => 
      array (
        'currency' => 'Denar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Macedonia',
        ),
      ),
      'MGA' => 
      array (
        'currency' => 'Ariary',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Madagascar',
        ),
      ),
      'MGF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Madagascar',
        ),
      ),
      'MWK' => 
      array (
        'currency' => 'Kwacha',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Malawi',
        ),
      ),
      'MYR' => 
      array (
        'currency' => 'Ringgit',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Malaysia',
        ),
      ),
      'MVR' => 
      array (
        'currency' => 'Rufiyaa',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Maldives',
        ),
      ),
      'MTL' => 
      array (
        'currency' => 'Lira',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Malta',
        ),
      ),
      'MRO' => 
      array (
        'currency' => 'Ouguiya',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Mauritania',
        ),
      ),
      'MUR' => 
      array (
        'currency' => 'Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Mauritius',
        ),
      ),
      'MXN' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Mexico',
        ),
      ),
      'MDL' => 
      array (
        'currency' => 'Leu',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Moldova',
          1 => 'Transnistria',
        ),
      ),
      'MNT' => 
      array (
        'currency' => 'Tughrik',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Mongolia',
        ),
      ),
      'MAD' => 
      array (
        'currency' => 'Dirham',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Morocco',
          1 => 'Western Sahara',
        ),
      ),
      'MZM' => 
      array (
        'currency' => 'Metical',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Mozambique',
        ),
      ),
      'NAD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Namibia',
        ),
      ),
      'NPR' => 
      array (
        'currency' => 'Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Nepal',
        ),
      ),
      'NIO' => 
      array (
        'currency' => 'Cordoba',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Nicaragua',
        ),
      ),
      'NGN' => 
      array (
        'currency' => 'Naira',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Nigeria',
        ),
      ),
      'KPW' => 
      array (
        'currency' => 'Won',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'North Korea',
        ),
      ),
      'NOK' => 
      array (
        'currency' => 'Krone',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Norway',
          1 => 'Svalbard and Jan Mayen',
        ),
      ),
      'OMR' => 
      array (
        'currency' => 'Rial',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Oman',
        ),
      ),
      'PKR' => 
      array (
        'currency' => 'Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Pakistan',
        ),
      ),
      'PAB' => 
      array (
        'currency' => 'Balboa',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Panama',
        ),
      ),
      'PGK' => 
      array (
        'currency' => 'Kina',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Papua New Guinea',
        ),
      ),
      'VND' => 
      array (
        'currency' => 'Vietnam Dong',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Paracel Islands',
          1 => 'Vietnam',
        ),
      ),
      'PYG' => 
      array (
        'currency' => 'Guarani',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Paraguay',
        ),
      ),
      'PEN' => 
      array (
        'currency' => 'Nuevo Sol',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Peru',
        ),
      ),
      'PHP' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Philippines',
        ),
      ),
      'PLN' => 
      array (
        'currency' => 'Zloty',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Poland',
        ),
      ),
      'PTE' => 
      array (
        'currency' => 'Escudo',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Portugal',
        ),
      ),
      'QAR' => 
      array (
        'currency' => 'Riyal',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Qatar',
        ),
      ),
      'ROL' => 
      array (
        'currency' => 'Leu',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Romania',
        ),
      ),
      'RUB' => 
      array (
        'currency' => 'Ruble',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Russia',
          1 => 'Tajikistan',
        ),
      ),
      'RWF' => 
      array (
        'currency' => 'Franc',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Rwanda',
        ),
      ),
      'SHP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Saint Helena',
        ),
      ),
      'WST' => 
      array (
        'currency' => 'Tala',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Samoa',
          1 => 'Western Samoa (Samoa)',
        ),
      ),
      'STD' => 
      array (
        'currency' => 'Dobra',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'São Tome and Principe',
        ),
      ),
      'SAR' => 
      array (
        'currency' => 'Riyal',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Saudi Arabia',
        ),
      ),
      'SPL' => 
      array (
        'currency' => 'Luigino',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Seborga',
        ),
      ),
      'CSD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Serbia',
        ),
      ),
      'SCR' => 
      array (
        'currency' => 'Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Seychelles',
        ),
      ),
      'SLL' => 
      array (
        'currency' => 'Leone',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Sierra Leone',
        ),
      ),
      'SKK' => 
      array (
        'currency' => 'Koruna',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Slovakia',
        ),
      ),
      'SIT' => 
      array (
        'currency' => 'Tolar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Slovenia',
        ),
      ),
      'SBD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Solomon Islands',
        ),
      ),
      'SOS' => 
      array (
        'currency' => 'Shilling',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Somalia',
        ),
      ),
      'ZAR' => 
      array (
        'currency' => 'Rand',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'South Africa',
          1 => 'Swaziland',
        ),
      ),
      'KRW' => 
      array (
        'currency' => 'Won',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'South Korea',
        ),
      ),
      'ESP' => 
      array (
        'currency' => 'Peseta',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Spain',
        ),
      ),
      'LKR' => 
      array (
        'currency' => 'Rupee',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Sri Lanka',
        ),
      ),
      'SDD' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Sudan',
        ),
      ),
      'SRD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Suriname',
        ),
      ),
      'RG)' => 
      array (
        'currency' => 'Guilder',
        'outdated' => '1',
        'country' => 
        array (
          0 => 'Suriname',
        ),
      ),
      'SZL' => 
      array (
        'currency' => 'Lilangeni',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Swaziland',
        ),
      ),
      'SEK' => 
      array (
        'currency' => 'Krona',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Sweden',
        ),
      ),
      'SYP' => 
      array (
        'currency' => 'Pound',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Syria',
        ),
      ),
      'TWD' => 
      array (
        'currency' => 'New Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Taiwan',
        ),
      ),
      'TJS' => 
      array (
        'currency' => 'Somoni',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Tajikistan',
        ),
      ),
      'TZS' => 
      array (
        'currency' => 'Shilling',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Tanzania',
        ),
      ),
      'THB' => 
      array (
        'currency' => 'Baht',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Thailand',
        ),
      ),
      'TOP' => 
      array (
        'currency' => 'Pa\'anga',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Tonga',
        ),
      ),
      'TTD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Trinidad and Tobago',
        ),
      ),
      'TND' => 
      array (
        'currency' => 'Dinar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Tunisia',
        ),
      ),
      'TRY' => 
      array (
        'currency' => 'New Lira',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Turkey',
        ),
      ),
      'out' => 
      array (
        'currency' => 'Lira',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Turkey',
        ),
      ),
      'TMM' => 
      array (
        'currency' => 'Manat',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Turkmenistan',
        ),
      ),
      'TVD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Tuvalu',
        ),
      ),
      'UGX' => 
      array (
        'currency' => 'Shilling',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Uganda',
        ),
      ),
      'UAH' => 
      array (
        'currency' => 'Hryvna',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Ukraine',
        ),
      ),
      'AED' => 
      array (
        'currency' => 'Dirham',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'United Arab Emirates',
        ),
      ),
      'UYU' => 
      array (
        'currency' => 'Peso',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Uruguay',
        ),
      ),
      'UZS' => 
      array (
        'currency' => 'Som',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Uzbekistan',
        ),
      ),
      'VUV' => 
      array (
        'currency' => 'Vatu',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Vanuatu',
        ),
      ),
      'VEB' => 
      array (
        'currency' => 'Bolivar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Venezuela',
        ),
      ),
      'YER' => 
      array (
        'currency' => 'Rial',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Yemen',
        ),
      ),
      'ZMK' => 
      array (
        'currency' => 'Kwacha',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Zambia',
        ),
      ),
      'ZWD' => 
      array (
        'currency' => 'Dollar',
        'outdated' => '0',
        'country' => 
        array (
          0 => 'Zimbabwe',
        ),
      ),
    );
  }
  
  // Get Currency Code by country name
  function CXRGetCode($country) {
    
    if (array_key_exists($country, $this->CountryToCode)) {
      return $this->CountryToCode[$country];
    }
    else {
      return false;
    }
  }
  
  // Get Currency Info by it code name
  function CXRGetInfo($code) {
    
    if (array_key_exists($code, $this->CodeToInfo)) {
      return $this->CodeToInfo[$code];
    }
    else {
      return false;
    }
  }
}
?>