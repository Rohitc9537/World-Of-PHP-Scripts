<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrGetData.class.php                      *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// CXR get data from files CLASS
class CXRGetData extends CXRMsg {
  // General settings   
  var $PATH = '';
  var $WWW_PATH = '';
  var $FILE_EXTENSION = '.cxr';
  // Array with files with correct extension in data dir
  var $CXR_FILES = array();
  // Array with currency rates
  var $CXR_CONTENT = array();  

  
  
  // Set path to CXR
  function setPath($path) {
    
    if (strpos($path, '/') !== false) {
      // So, should be UNIX path
      if (substr($path, -1) != '/') {
        $path .= '/';
      }
      $this->PATH = $path; 
    }
    elseif (strpos($path, '\\') !== false) {
      // Should be Windows path 
      if (substr($path, -1) != '\\') {
        $path .= '\\';
      }
      $this->PATH = $path; 
    }
    else {
      $this->CXR_ERRNO = 2;
      $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
      return false;
    }
    return true;  
  }
  
  //Set www path
  function setWWWPath($wwwPath) {
    
    if (substr($wwwPath, -1) != '/') {
      $this->WWW_PATH = $wwwPath.'/';
    }
    else {
      $this->WWW_PATH = $wwwPath;
    }
  }
  
  // Get files list from data dir
  function getFilesList() {
    $dh = 0;
    $file = '';
    
    if ($this->PATH) {
      if (is_dir($this->PATH)) {
        if ($dh = opendir($this->PATH)) {
          while (($file = readdir($dh)) !== false) {
            if (substr($file, -4) == $this->FILE_EXTENSION) {
              array_push($this->CXR_FILES, $file); 
            }
          }
          closedir($dh);
          return true;
        }
        else {
          $this->CXR_ERRNO = 3;
          $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
          return false;
        }
      }
      else {
        $this->CXR_ERRNO = 2;
        $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
        return false;
      }
    }
    else {
      $this->CXR_ERRNO = 1;
      $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
      return false;
    }
  }
  
  // Parse files and put data into array
  function parseFiles() {
    
    $counter = count($this->CXR_FILES);
    if ($counter) {
      for ($i = 0; $i < $counter; ++$i) {
        if ($tmp = file($this->PATH.$this->CXR_FILES[$i])) {
          $tmpContent = array();
          $tmpDescription = array();
          $mainKey = '';
          for ($j = 0; $j < count($tmp); ++$j) {
            list($key, $value) = split("=", $tmp[$j]);
            if (strlen($key) > 3) {
              if ($key == 'PRIMARY_CURRENCY') {
                $mainKey = rtrim($value); 
              }
              else {
                $tmpDescription[$key] = rtrim($value); 
              }
            }
            else {
              $tmpContent[$key] = rtrim($value);
            }
          }
          $this->CXR_CONTENT[$mainKey]['description'] = $tmpDescription;
          $this->CXR_CONTENT[$mainKey]['rates'] = $tmpContent;
        }
        else {
          $this->CXR_ERRNO = 5;
          $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
          return false;
        }
      }
      return true;
    }
    else {
      $this->CXR_ERRNO = 4;
      $this->CXR_ERROR = $this->ERRORS_LIST[$this->CXR_ERRNO];
      return false;
    }
  }
  
  // Getting data Init
  function GetDataInit() {
    
    if ($this->getFilesList()) {
      if ($this->parseFiles()) {
        return true;
      }
      else {
        return false;
      }
    }
    else {
      return false; 
    }
  }
}
?>