<?
/***************************************************************\
*                                                               *
*   Filename:         cxrUniversalConverter.class.php           *
*   Version:          v. 0.1.1                                  *
*   Last Modified:    31/05/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Universal converter DATA
class CXRUC extends CXRConverter {
  
  var $UCGeneralCurrency = array('EUR', 'USD', 'GBP');
  var $UCCurrencyList = array();
  var $UCContent = array();
  var $UCToCurrency;
  var $isFirstTime = true;
  

  // Get general currency for all data feeds
  function UCSelectGeneralCurrency(&$CXR_CONTENT) {

    for ($i = 0; $i < count($this->UCGeneralCurrency); ++$i) {
      $inAll = false;
      foreach ($CXR_CONTENT as $key => $value) {
        $inAll = false;
        if ($key != $this->UCGeneralCurrency[$i]) {
          foreach ($CXR_CONTENT[$key]['rates'] as $Curency => $Rate) {
            if ($Curency == $this->UCGeneralCurrency[$i]) {
              $inAll = true;
              break; 
            }
          }
        }
        else { 
          $inAll = true; 
        }
        if (!$inAll) { break; }
      }
      if ($inAll) { 
        $this->UCToCurrency = $this->UCGeneralCurrency[$i];
        return true; 
      }
    }  
     
    return false;
  }
  
  
  // Get list of all currencies and rates
  function UCCreateArray(&$CXR_CONTENT) {
    
    $this->UCCurrencyList[$this->UCToCurrency] = array();
    
    foreach ($CXR_CONTENT as $key => $value) {
      foreach ($CXR_CONTENT[$key]['rates'] as $Curency => $Rate) {
        if (!array_key_exists($Curency, $this->UCCurrencyList[$this->UCToCurrency])) {
          $this->UCCurrencyList[$this->UCToCurrency][$Curency] = array();
        }
        $newRate = floatval($this->convert($key, $this->UCToCurrency, $Curency, 1, null, false));
        array_push($this->UCCurrencyList[$this->UCToCurrency][$Curency], $newRate);
      }
    }
  }
  
  
  // Make list of currencies with median rate
  function UCGetMedianRate() {
   
     foreach ($this->UCCurrencyList[$this->UCToCurrency] as $key => $value) {
       $ratesCount = 0;
       $ratesSum = 0;
       foreach ($value as $rate) {
         $ratesSum += $rate;
         $ratesCount++;
       }
       $medianRate = $ratesSum / $ratesCount;
       $this->UCContent[$key] = $medianRate;
     }
     ksort($this->UCContent);
  }
  
  
  // Init Universal converter DATA
  function UCInit() {
    
    if ($this->isFirstTime) {
      if ($this->UCSelectGeneralCurrency($this->CXR_CONTENT)) {
        $this->UCCreateArray($this->CXR_CONTENT);
        $this->UCGetMedianRate();
        return true;
      }
      else {
        return false; 
      }
      $this->isFirstTime = false;
    }
    return true;
  }
}

?>