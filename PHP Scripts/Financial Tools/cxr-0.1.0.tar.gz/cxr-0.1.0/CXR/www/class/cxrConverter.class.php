<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrConverter.class.php                    *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// CXR Convert functions
class CXRConverter extends CXRGetData {
  
  // Convert currency From into To using Primary currency exchange rate
  function convert($primary = '', $from = '', $to = '', $amount = 0, $round = 2, $is_number_format = true) {
    
    $amount = floatval(str_replace(',', '.', $amount));
    if (!is_numeric($amount)) { return 'N/A'; }
    if ($amount == 0) { return number_format(0, $round, '.', ' '); }
    if (!is_numeric($round) || $round < 0 || $round > 10) { $round = 2; }
    if (!array_key_exists($primary, $this->CXR_CONTENT)) {
      return 'N/A'; 
    }

    if ($from == $primary) {
      $newValueFrom = $amount;
    }
    elseif (array_key_exists($from, $this->CXR_CONTENT[$primary]['rates'])) {
      $newValueFrom = ($amount / $this->CXR_CONTENT[$primary]['rates'][$from]);
    }
    else {
      return 'N/A'; 
    }
    
    if ($to == $primary) {
      $newValueTo = 1;
    }
    elseif (array_key_exists($to, $this->CXR_CONTENT[$primary]['rates'])) {
      $newValueTo = $this->CXR_CONTENT[$primary]['rates'][$to];
    }
    else {
      return 'N/A'; 
    }
    
    if ($is_number_format) {
      return number_format(($newValueFrom * $newValueTo), $round, '.', ' ');
    }
    else {
      return ($newValueFrom * $newValueTo);
    }
  }
  
  
  // Convert currency From into To -- UNIVERSAL CONVERSATION
  function uconvert($from = '', $to = '', $amount = 0, $round = 2, $is_number_format = true) {
    
    $amount = floatval(str_replace(',', '.', $amount));
    if (!is_numeric($amount)) { return 'N/A'; }
    if ($amount == 0) { return number_format(0, $round, '.', ' '); }
    if (!is_numeric($round) || $round < 0 || $round > 10) { $round = 2; }
    if (!array_key_exists($this->UCToCurrency, $this->UCContent)) {
      return 'N/A'; 
    }

    if ($from == $this->UCToCurrency) {
      $newValueFrom = $amount;
    }
    elseif (array_key_exists($from, $this->UCContent)) {
      $newValueFrom = ($amount / $this->UCContent[$from]);
    }
    else {
      return 'N/A'; 
    }
    
    if ($to == $this->UCToCurrency) {
      $newValueTo = 1;
    }
    elseif (array_key_exists($to, $this->UCContent)) {
      $newValueTo = $this->UCContent[$to];
    }
    else {
      return 'N/A'; 
    }
    
    if ($is_number_format) {
      return number_format(($newValueFrom * $newValueTo), $round, '.', ' ');
    }
    else {
      return ($newValueFrom * $newValueTo);
    }
  }
}
?>