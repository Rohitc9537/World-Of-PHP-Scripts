<?
/***************************************************************\
*                                                               *
*   Filename:         cxrAPI.class.php                          *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Include currency data file
require_once('cxrCurrencyData.class.php');
// Include cxrErrors class
require_once('cxrMsg.class.php');
// Include cxr Get Data class
require_once('cxrGetData.class.php');
// Include cxr Converter class
require_once('cxrConverter.class.php');
// Include cxr Universal Converter class
require_once('cxrUniversalConverter.class.php');
// Include cxr Html Code class
require_once('cxrHtmlCode.class.php');

// General CXR class
class CXRAPI extends CXRHtmlCode {
  
  function CXRInit() {
    
    $this->CXRMsgInit();
    if ($this->GetDataInit()) {
      $this->UCInit();
      return true;
    }
    else {
      return false; 
    }
  }
}

?>