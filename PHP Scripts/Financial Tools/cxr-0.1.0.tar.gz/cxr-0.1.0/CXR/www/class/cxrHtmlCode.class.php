<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrHtmlCode.class.php                     *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// CXR CLASS to conver currency
class CXRHtmlCode extends CXRUC {
  
  // Quick Converter settings
  var $QCTBorder = 0;
  var $QCTCellSpacing = 0;
  var $QCTCellPadding = 0;
  var $QCTWidth = 150;
  var $QCCaption = 'Quick Converter';
  var $QCFromText = 'From';
  var $QCToText = 'To';
  var $QCAmountText = 'Amount';
  var $QCConvertBtnText = 'Convert';
  var $QCDataFeedFormat = "%SOURCE_URL_A_CUSTOM%";
  var $QCShowCaption = true;
  var $QCShowDataFeed = true;
  var $QCShowAdvertisement = true;
  
  // Advanced Converter settings
  var $ACTBorder = 0;
  var $ACTCellSpacing = 0;
  var $ACTCellPadding = 0;
  var $ACTWidth = 350;
  var $ACCaption = 'Advanced Converter';
  var $ACDataFeedText = 'Data feed';
  var $ACFromText = 'From';
  var $ACToText = 'To';
  var $ACFromToEmpty = 'Select data feed first';
  var $ACAmountText = 'Amount';
  var $ACConvertBtnText = 'Convert';
  var $ACShowCaption = true;
  var $ACShowHelp = true;
  var $ACShowAdvertisement = true;
  var $ACMsgIndent = 15;
  var $ACMessages = array(
    0 => 'Select <b>Data feed</b>',
    1 => 'Choose currency to convert <b>From</b>',
    2 => 'Choose currency to convert <b>To</b>',
    3 => 'Enter any <b>Amount</b>',
    4 => 'Click <b>Convert</b> button to perform conversation');
  
  // Converting result settings
  var $CRTBorder = 0;
  var $CRTCellSpacing = 0;
  var $CRTCellPadding = 0;
  var $CRTWidth = 373;
  var $CRCaption = 'Converting result';
  var $CRDataFeedFormat = "Data feed: %SOURCE_URL_A_DESCRIPTION% (%UPDATED%)";
  var $CRCloseWindowText = 'Close window';
  var $CRShowCaption = true;
  var $CRShowCloseWindowLink = true;
  var $CRShowDataFeed = true;
  var $CRShowCopyRight = true;
  
  // Currency Rates settings
  var $RTBorder = 0;
  var $RTCellSpacing = 0;
  var $RTCellPadding = 0;
  var $RTWidth = 150;
  var $RCaption = 'Currency Rates';
  var $RTitleCurrency = 'Code';
  var $RTitleRate = 'Rate';
  var $RDataFeedFormat = "%SOURCE_URL_A_DESCRIPTION%<br />(%UPDATED%)";
  var $RShowCaption = true;
  var $RShowTitle = true;
  var $RShowDataFeed = true;
  var $RShowAdvertisement = true;
  
  // Universal Converter settings
  var $UCTBorder = 0;
  var $UCTCellSpacing = 0;
  var $UCTCellPadding = 0;
  var $UCTWidth = 150;
  var $UCCaption = 'Universal Converter';
  var $UCFromText = 'From';
  var $UCToText = 'To';
  var $UCAmountText = 'Amount';
  var $UCConvertBtnText = 'Convert';
  var $UCShowCaption = true;
  var $UCShowAdvertisement = true;
  

  
  // Data Feed Info
  function dataFeedInfo($DFPrimary = 'EUR', $format = '', $customHrefTxt = '') {

    if (array_key_exists($DFPrimary, $this->CXR_CONTENT)) {
      $result = '';
      $paterns = array(
        0 => '/%UPDATED%/',
        1 => '/%DESCRIPTION%/',
        2 => '/%SOURCE_URL%/',
        3 => '/%SOURCE_URL_A%/',
        4 => '/%SOURCE_URL_A_DESCRIPTION%/',
        5 => '/%SOURCE_URL_A_CUSTOM%/'); 
      $matches = array(
        0 => $this->CXR_CONTENT[$DFPrimary]['description']['UPDATED'],
        1 => $this->CXR_CONTENT[$DFPrimary]['description']['DESCRIPTION'],
        2 => $this->CXR_CONTENT[$DFPrimary]['description']['SOURCE_URL'],
        3 => '<a class="CXRRLink" href="'.$this->CXR_CONTENT[$DFPrimary]['description']['SOURCE_URL'].'">'.$this->CXR_CONTENT[$DFPrimary]['description']['SOURCE_URL'].'</a>',
        4 => '<a class="CXRRLink" href="'.$this->CXR_CONTENT[$DFPrimary]['description']['SOURCE_URL'].'">'.$this->CXR_CONTENT[$DFPrimary]['description']['DESCRIPTION'].'</a>',
        5 => '<a class="CXRRLink" href="'.$this->CXR_CONTENT[$DFPrimary]['description']['SOURCE_URL'].'">'.$customHrefTxt.'</a>'
      );
      return preg_replace($paterns, $matches, $format);   
    }
    else {
      return 'N/A'; 
    }
  }
  
  // Make randomize by microseconds
  function make_seed() {
    list($usec, $sec) = explode(' ', microtime());
    return (float) $sec + ((float) $usec * 100000);
  }
  
  
  // CXR Quick Converter
  function quickConverter($QCPrimary = 'EUR') {
    
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
      if (stristr($_SERVER['HTTP_USER_AGENT'], 'Opera')) {
        if (stristr($_SERVER['HTTP_USER_AGENT'], 'Linux')) {
          $minus = 6;
        }
        else {
          $minus = 4;
        }
      }
      else {
        $minus = 2;
      }
    }
    else {
      $minus = 2; 
    }
    
    if (stristr($this->QCTWidth, '%')) {
      $QCTDSelectWidthLeft = '50%';
      $QCTDSelectWidthRight = '50%';
      $QCSlectCurrency = '100%';
      $QCInputWidth = '100%';
    }
    else {
      $TWidth = intval(str_replace('%', '', $this->QCTWidth));
      $QCTDSelectWidthLeft = $TWidth >> 1;
      $QCTDSelectWidthRight = $TWidth - $QCTDSelectWidthLeft;
      $QCSlectCurrency = $QCTDSelectWidthLeft - $minus;
      $QCInputWidth = $QCTDSelectWidthLeft * 2 - $minus - 2;
      $QCSlectCurrency .= 'px';
      $QCInputWidth .= 'px';
    }

    $selectList = '';
    $indent = '                ';
    if (array_key_exists($QCPrimary, $this->CXR_CONTENT)) {      
      //$selectList .= "<option value=\"$QCPrimary\">$QCPrimary</option>\n";
      foreach ($this->CXR_CONTENT[$QCPrimary]['rates'] as $key => $value) {
        $selectList .= $indent."<option value=\"$key\">$key</option>\n";
      }
    }
    else {
      $selectList = $indent.'<option value="0">Not available</option>';
    }
    
    srand($this->make_seed());
    $randval = rand();
    
    $result_str = '
    <!--           BEGIN           -->
    <!--    CXR Quick Converter    -->
    <!-- http://www.cxr.ensart.com -->
      <form 
        action="'.$this->WWW_PATH.'www/convert.php" 
        enctype="multipart/form-data" 
        method="post" 
        name="CXRQuickConvert'.$randval.'" 
        target="CXRConvertWin" 
        onsubmit="CXRCheckQC(this, '.$randval.'); return false;">
        <table 
          border="'.$this->QCTBorder.'" 
          class="CXRCQTableMain" 
          cellspacing="'.$this->QCTCellSpacing.'" 
          cellpadding="'.$this->QCTCellPadding.'" 
          width="'.$this->QCTWidth.'">'."\n";
    
   if ($this->QCShowCaption) {
      $result_str .= '           
          <tr>
            <td 
              class="CXRQCTDCaption"
              colspan="2" 
              width="100%">
              '.$this->QCCaption.'
            </td>
          </tr>'."\n";
   }
   
   $result_str .= '      
          <tr>
            <td
              class="CXRQCTDSelectCurrencyFrom"
              width="'.$QCTDSelectWidthLeft.'">
              <select 
                class="CXRQCSelectCurrency" 
                name="CXRFrom" 
                id="CXRQCFrom'.$randval.'" 
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$QCSlectCurrency.';">
                
                <option value="Empty" selected>'.$this->QCFromText.'</option>
                '.$selectList.'
              </select>
            </td>
            <td
              class="CXRQCTDSelectCurrencyTo"
              width="'.$QCTDSelectWidthRight.'">
              <select 
                class="CXRQCSelectCurrency" 
                name="CXRTo" 
                id="CXRQCTo'.$randval.'" 
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$QCSlectCurrency.';">
                
                <option value="Empty" selected>'.$this->QCToText.'</option>
                '.$selectList.'
              </select>
              <input 
                type="hidden" 
                name="CXRPrimaryCurrency" 
                value="'.$QCPrimary.'">
              <input 
                  type="hidden" 
                  name="ConverterIs" 
                  value="QC">
            </td>
          </tr>
          <tr>
            <td  
              class="CXRQCTDAmount"
              colspan="2" 
              width="100%">
              <input 
                class="CXRQCValue" 
                id="CXRQCAmount'.$randval.'" 
                name="CXRAmount" 
                type="text" 
                value="'.$this->QCAmountText.'" 
                onfocus="CXRClearIt(this.id)" 
                onblur="CXRFillIt(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$QCInputWidth.';">
              <input 
                type="hidden" 
                name="CXRQCAmountHidden" 
                id="CXRQCAmount'.$randval.'Hidden"
                value="'.$this->QCAmountText.'">
            </td>
          </tr>
          <tr>
            <td 
              class="CXRQCTDSubmit" 
              colspan="2" 
              width="100%">
              <input 
                class="CXRQCSubmit" 
                name="CXRConvert"
                id="CXRQCConvert'.$randval.'"
                type="submit" 
                value="'.$this->QCConvertBtnText.'"
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$QCInputWidth.';">
            </td>
          </tr>'."\n";
   
    if ($this->QCShowDataFeed) {
      $result_str .= '           
          <tr>
            <td 
              class="CXRQCTDDataFeed"
              colspan="2" 
              width="100%">
                '.$this->dataFeedInfo($QCPrimary, $this->QCDataFeedFormat, "Data feed...").'
            </td>
          </tr>'."\n";
    }
          
    if ($this->QCShowAdvertisement) {
      $result_str .= '  
          <tr>
            <td 
              class="CXRQCTDAdvertisement"
              colspan="2" 
              width="100%">
              <a class="CXRQCLink" href="http://www.cxr.ensart.com" target="_blank">www.cxr.ensart.com</a>
            </td>
          </tr>'."\n";
    }
    
    $result_str .= '      
        </table>
      </form>
    <!--            END            -->
    <!--    CXR Quick Converter    -->'."\n";
     
    echo $result_str;
  }
  
  
  // CXR Advanced Converter
  function advancedConverter() {    
    
    $result_str = '';
    $isDisabled = '';
    $dfSelect = '';
    $currencySelect = '';
    $indent = '                    ';
    
    $OperaSpec = 2;
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
      if (stristr($_SERVER['HTTP_USER_AGENT'], 'Opera')) {
        if (stristr($_SERVER['HTTP_USER_AGENT'], 'Linux')) {
          $minus = 6;
          $OperaSpec = 4;
        }
        else {
          $minus = 4;
        }
      }
      else {
        $minus = 2;
      }
    }
    else {
      $minus = 2;
    }
    
    if (stristr($this->ACTWidth, '%')) {
      $ACTDSelectWidthLeft = '50%';
      $ACTDSelectWidthRight = '50%';
      $ACSelectCurrency = '100%';
      $ACInputWidth = '100%';
    }
    else {
      $TWidth = intval(str_replace('%', '', $this->ACTWidth));
      $ACTDSelectWidthLeft = $TWidth >> 1;
      $ACTDSelectWidthRight = $TWidth - $ACTDSelectWidthLeft;
      $ACSelectDataFeed = $ACTDSelectWidthLeft * 2 - $minus - $OperaSpec;
      $ACSelectCurrency = $ACTDSelectWidthLeft - $minus;
      $ACInputWidth = $ACTDSelectWidthLeft * 2 - $minus - 2;
      $Sufix = 'px';
      $ACSelectCurrency .= $Sufix;
      $ACInputWidth .= $Sufix;
    }
    
    $graphicsPath = $this->WWW_PATH.'www/graphics/';
    
    if ((isset($_GET['df']) && array_key_exists($_GET['df'], $this->CXR_CONTENT))) {
      $dfSelect = '<option value="Empty">'.$this->ACDataFeedText.'</option>'."\n";
      foreach ($this->CXR_CONTENT as $key => $value) {
        if ($key == $_GET['df']) {
          $dfSelect .= $indent.'<option value="'.$key.'" selected>'.$this->CXR_CONTENT[$key]['description']['DESCRIPTION'].' ['.$key.'] '.$this->CXR_CONTENT[$key]['description']['UPDATED'].'</option>'."\n";
        }
        else {
          $dfSelect .= $indent.'<option value="'.$key.'">'.$this->CXR_CONTENT[$key]['description']['DESCRIPTION'].' ['.$key.'] '.$this->CXR_CONTENT[$key]['description']['UPDATED'].'</option>'."\n";
        }
      }
      $tmpCurrency = $this->CXRGetInfo($_GET['df']);
      //$currencySelect .= '<option value="'.$_GET['df'].'">'.$_GET['df'].' ('.$tmpCurrency['currency'].')</option>'."\n";
      foreach ($this->CXR_CONTENT[$_GET['df']]['rates'] as $key => $value) {
        $tmpCurrency = $this->CXRGetInfo($key);
        $currencySelect .= $indent.'<option value="'.$key.'">'.$key.' ('.$tmpCurrency['currency'].')</option>'."\n";
      }
      $isDisabled = '';
    }
    else {
      $dfSelect = '<option value="Empty" selected>'.$this->ACDataFeedText.'</option>'."\n";
      foreach ($this->CXR_CONTENT as $key => $value) {
        $dfSelect .= $indent.'<option value="'.$key.'">'.$this->CXR_CONTENT[$key]['description']['DESCRIPTION'].' ['.$key.'] '.$this->CXR_CONTENT[$key]['description']['UPDATED'].'</option>'."\n";
      }
      $currencySelect = '<option value="NULL">'.$this->ACFromToEmpty.'</option>';
      $isDisabled = 'disabled';
    }
    
    srand($this->make_seed());
    $randval = rand();
    
    $result_str .= '
    <!--             BEGIN            -->
    <!--    CXR Advanced Converter    -->
    <!--   http://www.cxr.ensart.com  -->
      <form 
        action="'.$this->WWW_PATH.'www/convert.php" 
        enctype="multipart/form-data" 
        method="post" 
        name="CXRAdvancedConverter'.$randval.'" 
        target="CXRConvertWin" 
        onsubmit="CXRCheckAC(this, '.$randval.'); return false;">
        <table
          border="'.$this->ACTBorder.'" 
          class="CXRACTableMain" 
          cellspacing="'.$this->ACTCellSpacing.'" 
          cellpadding="'.$this->ACTCellPadding.'" 
          width="'.$this->ACTWidth.'">'."\n";
    
    if ($this->ACShowCaption) {
      $result_str .= '          
          <tr>
            <td 
              class="CXRACTDCaption" 
              colspan="2" 
              width="100%">
              '.$this->ACCaption.'
            </td>
          </tr>'."\n";
    }
    
    $result_str .= ' 
          <tr>
            <td 
              class="CXRACTDDataFeed" 
              colspan="2" 
              width="100%">
                <select 
                  class="CXRACSelectDataFeed" 
                  name="CXRPrimaryCurrency" 
                  id="CXRACDataFeed'.$randval.'" 
                  onfocus="CXRChgOnFocus(this.id)" 
                  onblur="CXRChgOnBlur(this.id)" 
                  onmouseover="CXRChgOnMousOver(this.id)" 
                  onmouseout="CXRChgOnMousOut(this.id)" 
                  onchange="window.location=\''.$_SERVER['PHP_SELF'].'?df=\'+this.options[selectedIndex].value"
                  style="width: '.$ACSelectDataFeed.';">
                  
                    '.$dfSelect.'
                  
              </select>
            </td>
          </tr>
          <tr>
            <td 
              class="CXRACTDSelectCurrencyFrom"
              width="'.$ACTDSelectWidthLeft.'">
                <select 
                  class="CXRACSelectCurrency" 
                  name="CXRFrom" 
                  id="CXRACCurrencyFrom'.$randval.'" 
                  onfocus="CXRChgOnFocus(this.id)" 
                  onblur="CXRChgOnBlur(this.id)" 
                  onmouseover="CXRChgOnMousOver(this.id)" 
                  onmouseout="CXRChgOnMousOut(this.id)"
                  style="width: '.$ACSelectCurrency.';">
                
                    <option value="Empty" selected>'.$this->ACFromText.'</option>
                    '.$currencySelect.'
                      
                </select>
            </td>
            <td 
              class="CXRACTDSelectCurrencyTo"
              width="'.$ACTDSelectWidthRight.'">
                <select 
                  class="CXRACSelectCurrency" 
                  name="CXRTo" 
                  id="CXRACCurrencyTo'.$randval.'" 
                  onfocus="CXRChgOnFocus(this.id)" 
                  onblur="CXRChgOnBlur(this.id)" 
                  onmouseover="CXRChgOnMousOver(this.id)" 
                  onmouseout="CXRChgOnMousOut(this.id)"
                  style="width: '.$ACSelectCurrency.';">
                    
                    <option value="Empty" selected>'.$this->ACToText.'</option>
                    '.$currencySelect.'
                      
                </select>
            </td>
          </tr>
          <tr>
            <td 
              class="CXRACTDAmount"
              colspan="2" 
              width="100%">
                <input 
                  class="CXRACValue" 
                  id="CXRACAmount'.$randval.'" 
                  name="CXRAmount" 
                  type="text" 
                  value="'.$this->ACAmountText.'" 
                  onfocus="CXRClearIt(this.id)" 
                  onblur="CXRFillIt(this.id)" 
                  onmouseover="CXRChgOnMousOver(this.id)" 
                  onmouseout="CXRChgOnMousOut(this.id)"
                  style="width: '.$ACInputWidth.';">
                <input 
                  type="hidden" 
                  name="CXRACAmountHidden" 
                  id="CXRACAmount'.$randval.'Hidden"
                  value="'.$this->ACAmountText.'">
                <input 
                  type="hidden" 
                  name="ConverterIs" 
                  value="AC">
            </td>
          </tr>
          <tr>
            <td 
              class="CXRACTDSubmit"
              colspan="2"  
              width="100%">
                <input 
                  class="CXRACSubmit" 
                  name="CXRConvert" 
                  id="CXRACConvert'.$randval.'"
                  type="submit" 
                  value="'.$this->ACConvertBtnText.'"
                  onfocus="CXRChgOnFocus(this.id)" 
                  onblur="CXRChgOnBlur(this.id)" 
                  onmouseover="CXRChgOnMousOver(this.id)" 
                  onmouseout="CXRChgOnMousOut(this.id)" '.$isDisabled.'
                  style="width: '.$ACInputWidth.';">
            </td>
          </tr>'."\n";
    if ($this->ACShowHelp) {
      $result_str .= '
          <tr>
            <td 
              colspan="2" 
              width="100%">
                &nbsp;
            </td>
          </tr>
          <tr>
            <td 
              class="CXRACTDHelpMsg" 
              colspan="2" 
              width="100%">
                <img alt="" border="0" height="2" src="'.$graphicsPath.'blank.gif" width="'.$this->ACMsgIndent.'"><img alt="" border="0" src="'.$graphicsPath.'right_arrow.gif"> '.$this->ACMessages[0].'<br />
                <img alt="" border="0" height="2" src="'.$graphicsPath.'blank.gif" width="'.$this->ACMsgIndent.'"><img alt="" border="0" src="'.$graphicsPath.'right_arrow.gif"> '.$this->ACMessages[1].'<br />
                <img alt="" border="0" height="2" src="'.$graphicsPath.'blank.gif" width="'.$this->ACMsgIndent.'"><img alt="" border="0" src="'.$graphicsPath.'right_arrow.gif"> '.$this->ACMessages[2].'<br />
                <img alt="" border="0" height="2" src="'.$graphicsPath.'blank.gif" width="'.$this->ACMsgIndent.'"><img alt="" border="0" src="'.$graphicsPath.'right_arrow.gif"> '.$this->ACMessages[3].'<br />
                <img alt="" border="0" height="2" src="'.$graphicsPath.'blank.gif" width="'.$this->ACMsgIndent.'"><img alt="" border="0" src="'.$graphicsPath.'right_arrow.gif"> '.$this->ACMessages[4].'<br />
            </td>
          </tr>'."\n";
    }
    if ($this->ACShowAdvertisement) {   
      $result_str .= '
          <tr>
            <td
              class="CXRACTDAdvertisement"
              colspan="2" 
              width="100%">
                <br /><a class="CXRACLink" href="http://www.cxr.ensart.com" target="_blank">www.cxr.ensart.com</a><br />
            </td>
          </tr>'."\n";
    }
    
    $result_str .= '      
        </table>
      </form>
    <!--              END             -->
    <!--    CXR Advanced Converter    -->'."\n";
    
    echo $result_str;
  }
  
  
  // Choose converting result function
  function convertingResult() {
    
    if (isset($_POST['ConverterIs'])) {
      if ($_POST['ConverterIs'] == 'QC' || $_POST['ConverterIs'] == 'AC') {
        $this->convertingRes(); 
      }
      elseif ($_POST['ConverterIs'] == 'UC') {
        $this->uconvertingRes(); 
      }
      else {
        echo "ERROR. Wrong converter type.\n"; 
      }
    }
    else {
      echo "ERROR. Unknown converter type.\n"; 
    } 
  }
  
  
  // Converting Result (Quick & Advanced)
  function convertingRes() {
    
    $result_str = '';
    $primary = 'N/A';
    $from = 'N/A';
    $fromName = 'N/A';
    $to = 'N/A';
    $toName = 'N/A';
    $tmpCurrency = '';
    $amount = 0;
    
    $CRTDSelectWidthLeft = $this->CRTWidth >> 1;
    $CRTDSelectWidthRight = $this->CRTWidth - $CRTDSelectWidthLeft;
    if (isset($_POST['CXRPrimaryCurrency']) && isset($_POST['CXRFrom']) && isset($_POST['CXRTo']) && isset($_POST['CXRAmount'])) {
      $primary = $_POST['CXRPrimaryCurrency'];
      if ($tmpCurrency = $this->CXRGetInfo($_POST['CXRFrom'])) {
        $from = $_POST['CXRFrom'];
        $fromName = $tmpCurrency['currency'];
      }
      if ($tmpCurrency = $this->CXRGetInfo($_POST['CXRTo'])) {
        $to = $_POST['CXRTo'];
        $toName =  $tmpCurrency['currency'];
      }
      $amount = (float) str_replace(',', '.', $_POST['CXRAmount']);
      if (!is_numeric($amount)) { $amount = 0; }
      $result_str .= '
    <!--             BEGIN            -->
    <!--     CXR Converting Result    -->
    <!--   http://www.cxr.ensart.com  -->
      <table 
        border="'.$this->CRTBorder.'" 
        class="CXRCRTableMain" 
        cellspacing="'.$this->CRTCellSpacing.'" 
        cellpadding="'.$this->CRTCellPadding.'" 
        width="'.$this->CRTWidth.'">'."\n";
      
      if ($this->CRShowCaption) {
        $result_str .= '
        <tr>
          <td 
            class="CXRCRTDCaption" 
            colspan="3" 
            width="100%">
            '.$this->CRCaption.'
          </td>
        </tr>'."\n";
      }
      
      $result_str .= '      
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>
        <tr valign="top">
          <td 
            class="CXRCRTDFrom" 
            width="45%">
              '.$this->convert($primary, $from, $from, $amount).' '.$from.'
          </td>
          <td 
            class="CXRCRTDEq" 
            width="10%">
              =
          </td>
          <td 
            class="CXRCRTDTo" 
            width="45%">
               '.$this->convert($primary, $from, $to, $amount).' '.$to.'
          </td>
        </tr>
        <tr>
          <td 
            class="CXRCRTDFromName" 
            width="45%">
              '.$fromName.'
          </td>
          <td 
            width="10%">
              &nbsp;
          </td>
          <td 
            class="CXRCRTDToName" 
            width="45%">
              '.$toName.'
          </td>
        </tr>
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>
        <tr>
          <td 
            class="CXRCRTDFromToConv" 
            width="45%">
              1 '.$from.' = '.$this->convert($primary, $from, $to, 1).' '.$to.'
          </td>
          <td 
            width="10%">
              &nbsp;
          </td>
          <td 
            class="CXRCRTDToFromConv" 
            width="45%">
              1 '.$to.' = '.$this->convert($primary, $to, $from, 1).' '.$from.'
          </td>
        </tr>
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>'."\n";
        
      if ($this->CRShowDataFeed) {
        $result_str .= '
        <tr>
          <td
            class="CXRCRTDDataFeed" 
            colspan="3"
            width="100%">
              '.$this->dataFeedInfo($primary, $this->CRDataFeedFormat).'
          </td>
        </tr>'."\n";
      }
      
      $result_str .= '      
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br /><br /><br />
          </td>
        </tr>'."\n";
      
      if ($this->CRShowCloseWindowLink) {
        $result_str .= '
        <tr>
          <td
            class="CXRCRTDCloseWindow" 
            colspan="3"
            width="100%">
              <a class="CXRCRLink" href="javascript: window.close()">'.$this->CRCloseWindowText.'</a>
          </td>
        </tr>'."\n";
      }
      
      $result_str .= '      
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>'."\n";
      
      if ($this->CRShowCopyRight) {    
        $result_str .= '
        <tr>
          <td
            class="CXRCRTDCopyright" 
            colspan="3"
            width="100%">
              Copyright &copy; 2005 <a class="CXRCRCopyrightLink" href="http://www.cxr.ensart.com/">EnsART Studios</a>. All rights reserved.
          </td>
        </tr>'."\n";
      }

      $result_str .= '
      </table>
    <!--              END             -->
    <!--     CXR Converting Result    -->'."\n";
    
    }
    else {
      $result_str .= 'ERROR. Cannot get currency data.'."\n";
    }
    
    echo $result_str;
  }
  
  
  // Universal Converting Result
  function uconvertingRes() {
    
    $result_str = '';
    $primary = 'N/A';
    $from = 'N/A';
    $fromName = 'N/A';
    $to = 'N/A';
    $toName = 'N/A';
    $tmpCurrency = '';
    $amount = 0;
    
    $CRTDSelectWidthLeft = $this->CRTWidth >> 1;
    $CRTDSelectWidthRight = $this->CRTWidth - $CRTDSelectWidthLeft;
    if (isset($_POST['CXRFrom']) && isset($_POST['CXRTo']) && isset($_POST['CXRAmount'])) {
      if ($tmpCurrency = $this->CXRGetInfo($_POST['CXRFrom'])) {
        $from = $_POST['CXRFrom'];
        $fromName = $tmpCurrency['currency'];
      }
      if ($tmpCurrency = $this->CXRGetInfo($_POST['CXRTo'])) {
        $to = $_POST['CXRTo'];
        $toName =  $tmpCurrency['currency'];
      }
      $amount = (float) str_replace(',', '.', $_POST['CXRAmount']);
      if (!is_numeric($amount)) { $amount = 0; }
      $result_str .= '
    <!--             BEGIN             -->
    <!--     CXR UConverting Result    -->
    <!--   http://www.cxr.ensart.com   -->
      <table 
        border="'.$this->CRTBorder.'" 
        class="CXRCRTableMain" 
        cellspacing="'.$this->CRTCellSpacing.'" 
        cellpadding="'.$this->CRTCellPadding.'" 
        width="'.$this->CRTWidth.'">'."\n";
      
      if ($this->CRShowCaption) {
        $result_str .= '   
        <tr>
          <td 
            class="CXRCRTDCaption" 
            colspan="3" 
            width="100%">
            '.$this->CRCaption.'
          </td>
        </tr>'."\n";
      }
      
      $result_str .= '  
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>
        <tr valign="top">
          <td 
            class="CXRCRTDFrom" 
            width="45%">
              '.$this->uconvert($from, $from, $amount).' '.$from.'
          </td>
          <td 
            class="CXRCRTDEq" 
            width="10%">
              =
          </td>
          <td 
            class="CXRCRTDTo" 
            width="45%">
               '.$this->uconvert($from, $to, $amount).' '.$to.'
          </td>
        </tr>
        <tr>
          <td 
            class="CXRCRTDFromName" 
            width="45%">
              '.$fromName.'
          </td>
          <td 
            width="10%">
              &nbsp;
          </td>
          <td 
            class="CXRCRTDToName" 
            width="45%">
              '.$toName.'
          </td>
        </tr>
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>
        <tr>
          <td 
            class="CXRCRTDFromName" 
            width="45%">
              1 '.$from.' = '.$this->uconvert($from, $to, 1).' '.$to.'
          </td>
          <td 
            width="10%">
              &nbsp;
          </td>
          <td 
            class="CXRCRTDToName" 
            width="45%">
              1 '.$to.' = '.$this->uconvert($to, $from, 1).' '.$from.'
          </td>
        </tr>'."\n";
        
      if ($this->CRShowCloseWindowLink) {
        $result_str .= ' 
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br /><br /><br />
          </td>
        </tr>
        <tr>
          <td
            class="CXRCRTDCloseWindow" 
            colspan="3"
            width="100%">
              <a class="CXRCRLink" href="javascript: window.close()">'.$this->CRCloseWindowText.'</a>
          </td>
        </tr>'."\n";
      }
      
      $result_str .= '        
        <tr>
          <td 
            colspan="3"
            width="100%">
              &nbsp;<br /><br />
          </td>
        </tr>'."\n";
      
      if ($this->CRShowCopyRight) {    
        $result_str .= '
        <tr>
          <td
            class="CXRCRTDCopyright" 
            colspan="3"
            width="100%">
              Copyright &copy; 2005 <a class="CXRCRCopyrightLink" href="http://www.cxr.ensart.com/">EnsART Studios</a>. All rights reserved.
          </td>
        </tr>'."\n";
      }

      $result_str .= '
      </table>
    <!--              END             -->
    <!--     CXR Converting Result    -->'."\n";
    
    }
    else {
      $result_str .= 'ERROR. Cannot get currency data.'."\n";
    }
    
    echo $result_str;
  }
  
  
  // CXR Currency Rates
  function rates($RPrimary = 'EUR', $RCurrencyList = '') {
    
    $AllInList = true;
    
    if (!empty($RCurrencyList)) {
      $AllInList = false;
      $RCurrencyArray = array();
      $RCurrencyArray = explode(',', $RCurrencyList);
      for ($i = 0; $i < count($RCurrencyArray); ++$i) {
        $RCurrencyArray[$i] = strtoupper(trim($RCurrencyArray[$i]));
      }
    }
    
    
    $ratesList = '';
    $indent = '        ';
    if (array_key_exists($RPrimary, $this->CXR_CONTENT)) {      
      if ($AllInList) {
        $OddEven = 1;
        foreach ($this->CXR_CONTENT[$RPrimary]['rates'] as $key => $value) {
          if($OddEven & 1) $OddEvenText = 'Odd';
            else $OddEvenText = 'Even';
          $ratesList .= $indent."<tr>
            <td
              class=\"CXRRTDRateLineCurrency".$OddEvenText."\"
              width=\"50%\">
              &nbsp;".$key."
            </td>
            <td
              class=\"CXRRTDRateLineRate".$OddEvenText."\"
              width=\"50%\">
              ".$this->convert($RPrimary, $RPrimary, $key, 1, 4)."&nbsp;
            </td>
          </tr>\n";
          $OddEven++;
        }
      }
      else {
        $OddEven = 1;
        for ($i = 0; $i < count($RCurrencyArray); ++$i) {
          if (array_key_exists($RCurrencyArray[$i], $this->CXR_CONTENT[$RPrimary]['rates'])) {
            if($OddEven & 1) $OddEvenText = 'Odd';
              else $OddEvenText = 'Even';
            $ratesList .= $indent."<tr>
              <td
                class=\"CXRRTDRateLineCurrency".$OddEvenText."\"
                width=\"50%\">
                &nbsp;".$RCurrencyArray[$i]."
              </td>
              <td
                class=\"CXRRTDRateLineRate".$OddEvenText."\"
                width=\"50%\">
                ".$this->convert($RPrimary, $RPrimary, $RCurrencyArray[$i], 1, 4)."&nbsp;
              </td>
            </tr>\n";
            $OddEven++;
          }
        }
      }
    }
    else {
      $selectList = $indent.'<option value="0">Not available</option>';
    }
    
    $result_str = '
    <!--           BEGIN           -->
    <!--     CXR Currency Rates    -->
    <!-- http://www.cxr.ensart.com -->
      <table 
        border="'.$this->RTBorder.'" 
        class="CXRRTableMain" 
        cellspacing="'.$this->RTCellSpacing.'" 
        cellpadding="'.$this->RTCellPadding.'" 
        width="'.$this->RTWidth.'">'."\n";
     
    if ($this->RShowCaption) {   
       $result_str .= '
        <tr>
          <td 
            class="CXRRTDCaption"
            colspan="2" 
            width="100%">
            '.$this->RCaption.'
          </td>
        </tr>'."\n";
     }
     
    if ($this->RShowTitle) {   
      $result_str .= '   
        <tr>
          <td
            class="CXRRTDTitleCode"
            width="50%">
            &nbsp;'.$this->RTitleCurrency.'
          </td>
          <td
            class="CXRRTDTitleRate"
            width="50%">
            '.$this->RTitleRate.'&nbsp;
          </td>
        </tr>'."\n";
    }
        
    $result_str .= $ratesList."\n";
     
    if ($this->RShowDataFeed) {   
       $result_str .= '        
        <tr>
          <td
            class="CXRRTDDataFeed"
            colspan="2"
            width="100%">
            &nbsp;'.$this->dataFeedInfo($RPrimary, $this->RDataFeedFormat).'&nbsp;
          </td>
        </tr>'."\n";
    }
    
    if ($this->RShowAdvertisement) {   
      $result_str .= '
        <tr>
          <td 
            class="CXRRTDAdvertisement"
            colspan="2" 
            width="100%">
            <a class="CXRRLink" href="http://www.cxr.ensart.com" target="_blank">www.cxr.ensart.com</a>
          </td>
        </tr>'."\n";
    }

    $result_str .= '
      </table>
    <!--            END            -->
    <!--     CXR Currency Rates    -->'."\n";
     
    echo $result_str;
  }
  
  
  // CXR Universal Converter
  function universalConverter() {
    
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
      if (stristr($_SERVER['HTTP_USER_AGENT'], 'Opera')) {
        if (stristr($_SERVER['HTTP_USER_AGENT'], 'Linux')) {
          $minus = 6;
        }
        else {
          $minus = 4;
        }
      }
      else {
        $minus = 2;
      }
    }
    else {
      $minus = 2; 
    }
    
    if (stristr($this->UCTWidth, '%')) {
      $UCTDSelectWidthLeft = '50%';
      $UCTDSelectWidthRight = '50%';
      $UCSlectCurrency = '100%';
      $UCInputWidth = '100%';
    }
    else {
      $TWidth = intval(str_replace('%', '', $this->UCTWidth));
      $UCTDSelectWidthLeft = $TWidth >> 1;
      $UCTDSelectWidthRight = $TWidth - $UCTDSelectWidthLeft;
      $UCSlectCurrency = $UCTDSelectWidthLeft - $minus;
      $UCInputWidth = $UCTDSelectWidthLeft * 2 - $minus - 2;
      $UCSlectCurrency .= 'px';
      $UCInputWidth .= 'px';
    }

    $selectList = '';
    $indent = '                ';
    
    if ($this->UCInit()) {
      foreach ($this->UCContent as $key => $value) {
        $selectList .= $indent."<option value=\"$key\">$key</option>\n";
      }
    }
    else {
      $selectList = $indent.'<option value="0">Not available</option>';
    }
    
    srand($this->make_seed());
    $randval = rand();
    
    $result_str = '
    <!--             BEGIN             -->
    <!--    CXR Universal Converter    -->
    <!--   http://www.cxr.ensart.com   -->
      <form 
        action="'.$this->WWW_PATH.'www/convert.php" 
        enctype="multipart/form-data" 
        method="post" 
        name="CXRUniversalConverter'.$randval.'" 
        target="CXRConvertWin" 
        onsubmit="CXRCheckUC(this, '.$randval.'); return false;">
        <table 
          border="'.$this->UCTBorder.'" 
          class="CXRUQTableMain" 
          cellspacing="'.$this->UCTCellSpacing.'" 
          cellpadding="'.$this->UCTCellPadding.'" 
          width="'.$this->UCTWidth.'">'."\n";
    
   if ($this->UCShowCaption) {
      $result_str .= '           
          <tr>
            <td 
              class="CXRUCTDCaption"
              colspan="2" 
              width="100%">
              '.$this->UCCaption.'
            </td>
          </tr>'."\n";
   }
   
   $result_str .= '      
          <tr>
            <td
              class="CXRUCTDSelectCurrencyFrom"
              width="'.$UCTDSelectWidthLeft.'">
              <select 
                class="CXRUCSelectCurrency" 
                name="CXRFrom" 
                id="CXRUCFrom'.$randval.'" 
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$UCSlectCurrency.';">
                
                <option value="Empty" selected>'.$this->UCFromText.'</option>
                '.$selectList.'
              </select>
            </td>
            <td
              class="CXRUCTDSelectCurrencyTo"
              width="'.$UCTDSelectWidthRight.'">
              <select 
                class="CXRUCSelectCurrency" 
                name="CXRTo" 
                id="CXRUCTo'.$randval.'" 
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$UCSlectCurrency.';">
                
                <option value="Empty" selected>'.$this->UCToText.'</option>
                '.$selectList.'
              </select>
            </td>
          </tr>
          <tr>
            <td  
              class="CXRUCTDAmount"
              colspan="2" 
              width="100%">
              <input 
                class="CXRUCValue" 
                id="CXRUCAmount'.$randval.'" 
                name="CXRAmount" 
                type="text" 
                value="'.$this->UCAmountText.'" 
                onfocus="CXRClearIt(this.id)" 
                onblur="CXRFillIt(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$UCInputWidth.';">
              <input 
                type="hidden" 
                name="CXRUCAmountHidden" 
                id="CXRUCAmount'.$randval.'Hidden"
                value="'.$this->UCAmountText.'">
              <input 
                  type="hidden" 
                  name="ConverterIs" 
                  value="UC">
            </td>
          </tr>
          <tr>
            <td 
              class="CXRUCTDSubmit" 
              colspan="2" 
              width="100%">
              <input 
                class="CXRUCSubmit" 
                name="CXRConvert"
                id="CXRUCConvert'.$randval.'"
                type="submit" 
                value="'.$this->UCConvertBtnText.'"
                onfocus="CXRChgOnFocus(this.id)" 
                onblur="CXRChgOnBlur(this.id)" 
                onmouseover="CXRChgOnMousOver(this.id)" 
                onmouseout="CXRChgOnMousOut(this.id)"
                style="width: '.$UCInputWidth.';">
            </td>
          </tr>'."\n";
          
    if ($this->UCShowAdvertisement) {
      $result_str .= '  
          <tr>
            <td 
              class="CXRUCTDAdvertisement"
              colspan="2" 
              width="100%">
              <a class="CXRUCLink" href="http://www.cxr.ensart.com" target="_blank">www.cxr.ensart.com</a>
            </td>
          </tr>'."\n";
    }
    
    $result_str .= '      
        </table>
      </form>
    <!--              END              -->
    <!--    CXR Universal Converter    -->'."\n";
     
    echo $result_str;
  }
}
?>