<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrMsg.class.php                          *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// CXR global errors list
class CXRMsg extends CXRCurrencyData  {
  // Errors
  var $CXR_ERRNO;
  var $CXR_ERROR;
  var $ERRORS_LIST;
  
  // CXRMsg Init
  function CXRMsgInit() {
    
    $this->CXR_ERRNO = 0;
    $this->CXR_ERROR = '';
    $this->ERRORS_LIST = array (
      0  => '',
      1  => 'Path to CXR is not set.',
      2  => 'Incorrect data directory or path to data directory.',
      3  => 'Cannot open data dir.',
      4  => 'Where is no data files.',
      5  => 'Cannot open data file.'
    );
  }
}
?>