/***************************************************************\
*                                                               *
*   Filename:         cxrJS.js                                  *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

//Global error messages
var errorMsg = new Array(7);
errorMsg[0] = '- Please select currency to convert From\n';
errorMsg[1] = '- Please select currency to convert To\n';
errorMsg[2] = '- Please enter any amount to convert\n';
errorMsg[3] = '- Please select Data feed first\n';
errorMsg[4] = '- Please select currency to convert From\n';
errorMsg[5] = '- Please select currency to convert To\n';
errorMsg[6] = '- Please enter any amount to convert\n';


//Global onFocus flag
var isFocusOn = false;
var currentID = false;

//Set windows status bar message
function CXRSetMsg(msg) {
  window.status = msg;
  return true;
}

//Clear item value
function CXRClearIt(elmID) {
  var obj = document.getElementById(elmID);
  var objH = document.getElementById(elmID + 'Hidden');
  var objValue = obj.value;
  var TDAmountText = objH.value;
  isFocusOn = true;
  currentID = elmID;
  var currentClass = obj.className;
  if (currentClass.substring(currentClass.length - 11, currentClass.length) != 'OnMouseOver') {
    obj.className = currentClass + 'OnMouseOver';
  }
  if (objValue == TDAmountText) {
    obj.value = '';
  }
}

//Fill item value
function CXRFillIt(elmID) {
  var obj = document.getElementById(elmID);
  var objH = document.getElementById(elmID + 'Hidden');
  var objValue = obj.value;
  var TDAmountText = objH.value;
  isFocusOn = false;
  currentID = false;
  var currentClass = obj.className;
  if (currentClass.substring(currentClass.length - 11, currentClass.length) == 'OnMouseOver') {
    obj.className = currentClass.substring(0 , currentClass.length - 11);
  }
  if (objValue.length < 1) {
   obj.value = TDAmountText;
  }
}


//Change color onFocus
function CXRChgOnFocus(elmID) {
  var obj = document.getElementById(elmID);
  isFocusOn = true;
  currentID = elmID;
  var currentClass = obj.className;
  if (currentClass.substring(currentClass.length - 11, currentClass.length) != 'OnMouseOver') {
    obj.className = currentClass + 'OnMouseOver';
  }
}

//Change color onBlur
function CXRChgOnBlur(elmID) {
  var obj = document.getElementById(elmID);
  isFocusOn = false;
  currentID = false;
  var currentClass = obj.className;
  if (currentClass.substring(currentClass.length - 11, currentClass.length) == 'OnMouseOver') {
    obj.className = currentClass.substring(0 , currentClass.length - 11);
  }
}

//Change color onMouseOver
function CXRChgOnMousOver(elmID) {
  var obj = document.getElementById(elmID);
  var currentClass = obj.className;
  if (currentClass.substring(currentClass.length - 11, currentClass.length) != 'OnMouseOver') {
    obj.className = currentClass + 'OnMouseOver';
  }
}

//Change color onMouseOut
function CXRChgOnMousOut(elmID) {
  var obj = document.getElementById(elmID);  
  var currentClass = obj.className;      
  if (isFocusOn == true && currentID == elmID) {
    obj.className = currentClass;
  }
  else {
    if (currentClass.substring(currentClass.length - 11, currentClass.length) == "OnMouseOver") {
      obj.className = currentClass.substring(0 , currentClass.length - 11);
    }
  }
}

//Check Quick Converter fields
function CXRCheckQC(thisForm, randVal) {
  var objFrom = document.getElementById('CXRQCFrom'+randVal);
  var objTo = document.getElementById('CXRQCTo'+randVal);
  var objAmount = document.getElementById('CXRQCAmount'+randVal);
  var formAction = thisForm.action;
  var isError = 0;
  var errorStr = '';

  if (objFrom.value == 'Empty') {
    errorStr += errorMsg[0];
    isError++;
  }
  if (objTo.value == 'Empty') {
    errorStr += errorMsg[1];
    isError++;
  }
  if (objAmount.value == 'Amount') {
    errorStr += errorMsg[2];
    isError++;
  }
  
  if (isError == 0) {
    CXRNewWindow(formAction, 390, 285);
    thisForm.submit();
  }
  else {
    alert(errorStr);
  }
}

//Check Advanced Converter fields
function CXRCheckAC(thisForm, randVal) {
  var objSource = document.getElementById('CXRACDataFeed'+randVal);
  var objFrom = document.getElementById('CXRACCurrencyFrom'+randVal);
  var objTo = document.getElementById('CXRACCurrencyTo'+randVal);
  var objAmount = document.getElementById('CXRACAmount'+randVal);
  var formAction = thisForm.action;
  var isError = 0;
  var errorStr = '';

  if (objSource.value == 'Empty') {
    errorStr = errorMsg[3];
    isError++;
  }
  if (objFrom.value == 'Empty' || objFrom.value == 'NULL') {
    errorStr += errorMsg[4];
    isError++;
  }
  if (objTo.value == 'Empty' || objTo.value == 'NULL') {
    errorStr += errorMsg[5];
    isError++;
  }
  if (objAmount.value == 'Amount') {
    errorStr += errorMsg[6];
    isError++;
  }
  
  if (isError == 0) {
    CXRNewWindow(formAction, 390, 285);
    thisForm.submit();
  }
  else {
    alert(errorStr);
  }
}

//Check Universal Converter fields
function CXRCheckUC(thisForm, randVal) {
  var objFrom = document.getElementById('CXRUCFrom'+randVal);
  var objTo = document.getElementById('CXRUCTo'+randVal);
  var objAmount = document.getElementById('CXRUCAmount'+randVal);
  var formAction = thisForm.action;
  var isError = 0;
  var errorStr = '';

  if (objFrom.value == 'Empty') {
    errorStr += errorMsg[0];
    isError++;
  }
  if (objTo.value == 'Empty') {
    errorStr += errorMsg[1];
    isError++;
  }
  if (objAmount.value == 'Amount') {
    errorStr += errorMsg[2];
    isError++;
  }
  
  if (isError == 0) {
    CXRNewWindow(formAction, 390, 285);
    thisForm.submit();
  }
  else {
    alert(errorStr);
  }
}

// Create new window
function CXRNewWindow(windowLocation, windowWidth, windowHeight) {
  var windowLeft = (screen.width - windowWidth)/2;
  var windowTop = (screen.height - windowHeight)/2;
  var windowProperties = 'width='+windowWidth+',height='+windowHeight+',left='+windowLeft+',top='+windowTop+',scrollbars=false';
  var newWin = window.open(windowLocation, 'CXRConvertWin', windowProperties);
  if (parseInt(navigator.appVersion) >= 4) { newWin.window.focus(); };
}
