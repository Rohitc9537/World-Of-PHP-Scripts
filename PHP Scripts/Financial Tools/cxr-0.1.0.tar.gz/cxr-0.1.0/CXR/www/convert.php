<?php
/***************************************************************\
*                                                               *
*   Filename:         convert.php                               *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

require_once('cxrAPI.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="Author" content="Igor Pavlenko/EnsART Professionals">
    <title>Currency eXchange rates: Converting result</title>
    <!--           BEGIN           -->
    <!--        CXR include        -->
    <!-- http://www.cxr.ensart.com -->
    <link rel="stylesheet" type="text/css" href="style/cxrCSS.css">
    <!--            END            -->
    <!--        CXR include        -->
  </head>
  
  <body>

  <? $cxr->convertingResult(); ?>
  
  </body>
</html>