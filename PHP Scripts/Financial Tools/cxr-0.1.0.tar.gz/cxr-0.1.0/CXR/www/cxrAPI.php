<?php
/***************************************************************\
*                                                               *
*   Filename:         cxrAPI.php                                *
*   Version:          v. 0.1.0                                  *
*   Last Modified:    24/04/2005                                *
*   Copyright:        EnsART Professionals � 2005               *
*                     www.ensart.com                            *
*   Author:           Igor [ip] Pavlenko                        *
*                     ip@ensart.com                             *
*                                                               *
\***************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Include CXRInit Class
require_once('class/cxrAPI.class.php');


// CXR CLASS work example
$cxr = new CXRAPI;
$cxr->setPath('%CXR_DATA_DIR%');
$cxr->setWWWPath('%CXR_WWW_PATH%');


/* Options section (Put in this section options you need */

// <- del comment and put options string here

/* End Options section */


$cxr->CXRInit();
?>