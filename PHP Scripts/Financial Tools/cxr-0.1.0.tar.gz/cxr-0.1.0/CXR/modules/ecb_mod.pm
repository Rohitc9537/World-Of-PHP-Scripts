package ecb_mod;

#/***************************************************************\
#*                                                               *
#*   Filename:         ecb_mod.pm                                *
#*   Version:          v. 0.1.0                                  *
#*   Last Modified:    24/04/2005                                *
#*   Copyright:        EnsART Professionals � 2005               *
#*                     www.ensart.com                            *
#*   Author:           Igor [ip] Pavlenko                        *
#*                     ip@ensart.com                             *
#*                                                               *
#\***************************************************************/
#
#/***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General Public License as published by  *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************/

# Module for Currency eXchange Rate updater
#
# @MODULE = ecb_mod.pm
# @VERSION = 0.1.0
# @DATE = 2005-04-20
# @AUTHOR = IP (ip@ensart.com)
# @SERVER = http://www.ecb.int/
# @NAME = "The European Central Bank"
# @DATA_URL = http://www.ecb.int/stats/eurofxref/eurofxref-daily.xml
# @DATA_FORMAT = xml
#


use POSIX qw(strftime);


#------------------------------------------------------------------------------#
# proceedCXR - get data with CXR and convert it in new format
# string proceedCXR()
#

sub proceedCXR {

  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime (time + 3600);
  
  my %data = (
             'url'              => 'http://www.ecb.int/stats/eurofxref/eurofxref-daily.xml',
             'www'              => 'http://www.ecb.int/',
             'description'      => 'The European Central Bank',
             'primaryCurrency'  => 'EUR'
             );

  if ($wday == 0) {
    return 'N/A';
  }

  my $content = &{main::getContent}($data{'url'});
  if ($content eq 'N/A') {
    return 'N/A';
  }
  
  my $xdh = new XML::Simple();
  my $xmlData = eval { $xdh->XMLin($content, ForceArray => 1); };
    if ($@) {
      my $tmpMsg = $@;
      $tmpMsg =~ s/\n/ /g;
      &{main::loging}(20, $tmpMsg);
      return 'N/A';
    }

  my $output = "UPDATED=".$xmlData->{Cube}[0]->{Cube}[0]->{'time'}."\n";
  $output .= "SOURCE_URL=".$data{'www'}."\n";
  $output .= "DESCRIPTION=".$data{'description'}."\n";
  $output .= "PRIMARY_CURRENCY=".$data{'primaryCurrency'}."\n";

  $output .= $data{'primaryCurrency'}."=1\n";
  my $i = 0;
  my $currency = undef;
  my $rate = undef;
  while (exists $xmlData->{Cube}[0]->{Cube}[0]->{Cube}[$i]) {
    $currency = uc $xmlData->{Cube}[0]->{Cube}[0]->{Cube}[$i]->{'currency'};
    $rate = $xmlData->{Cube}[0]->{Cube}[0]->{Cube}[$i]->{'rate'};
    $rate =~ s/\,/\./;
    $output .= $currency.'='.sprintf("%.12f", $rate)."\n";
    $i++;
  }

  return $output;
}


#
#------------------------------------------------------------------------------#


1;