package cbr_mod;

#/***************************************************************\
#*                                                               *
#*   Filename:         cbr_mod.pm                                *
#*   Version:          v. 0.1.1                                  *
#*   Last Modified:    31/05/2005                                *
#*   Copyright:        EnsART Professionals � 2005               *
#*                     www.ensart.com                            *
#*   Author:           Igor [ip] Pavlenko                        *
#*                     ip@ensart.com                             *
#*                                                               *
#\***************************************************************/
#
#/***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General Public License as published by  *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************/

# Module for Currency eXchange Rate updater
#
# @MODULE = cbr_mod.pm
# @VERSION = 0.1.1
# @DATE = 2005-05-31
# @AUTHOR = IP (ip@ensart.com)
# @SERVER = http://www.cbr.ru/
# @NAME = "The Central Bank of the Russian Federation"
# @DATA_URL = http://www.cbr.ru/scripts/xml_daily.asp
# @DATA_FORMAT = xml
#


use POSIX qw(strftime);


#------------------------------------------------------------------------------#
# proceedCXR - get data with CXR and convert it in new format
# string proceedCXR()
#

sub proceedCXR {

  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime (time + 10800);
  
  my %data = (
             'url'              => 'http://www.cbr.ru/scripts/xml_daily.asp?date_req='.strftime("%d.%m.%Y", localtime()),
             'www'              => 'http://www.cbr.ru/',
             'description'      => 'The Central Bank of the Russian Federation',
             'primaryCurrency'  => 'RUB'
             );

  if ($wday == 0) {
    return 'N/A';
  }

  my $content = &{main::getContent}($data{'url'});
  if ($content eq 'N/A') {
    return 'N/A';
  }
  
  my $xdh = new XML::Simple();

  my $xmlData = eval { $xdh->XMLin($content, ForceArray => 1); };
    if ($@) {
      my $tmpMsg = $@;
      $tmpMsg =~ s/\n/ /g;
      &{main::loging}(20, $tmpMsg);
      return 'N/A';
    }

  my $day = substr($xmlData->{'Date'}, 0, 2);
  my $month = substr($xmlData->{'Date'}, 3, 2);
  my $Y = substr($xmlData->{'Date'}, 6, 4);
  my $output = "UPDATED=".$Y."-".$month."-".$day."\n";
  $output .= "SOURCE_URL=".$data{'www'}."\n";
  $output .= "DESCRIPTION=".$data{'description'}."\n";
  $output .= "PRIMARY_CURRENCY=".$data{'primaryCurrency'}."\n";
  
  $output .= $data{'primaryCurrency'}."=1\n";
  my $i = 0;
  my $currency = undef;
  my $rate = undef;
  while (exists $xmlData->{'Valute'}[$i]) {
    $currency = uc $xmlData->{'Valute'}[$i]->{'CharCode'}[0];
    $rate = $xmlData->{'Valute'}[$i]->{'Value'}[0];
    $rate =~ s/\,/\./;
    $rate = (1 / ( $rate / $xmlData->{'Valute'}[$i]->{'Nominal'}[0] ));
    $output .= $currency.'='.sprintf("%.12f", $rate)."\n";
    $i++;
  }

  return $output;
}


#
#------------------------------------------------------------------------------#


1;