package rba_mod;

#/***************************************************************\
#*                                                               *
#*   Filename:         rba_mod.pm                                *
#*   Version:          v. 0.1.0                                  *
#*   Last Modified:    31/05/2005                                *
#*   Copyright:        EnsART Professionals © 2005               *
#*                     www.ensart.com                            *
#*   Author:           Igor [ip] Pavlenko                        *
#*                     ip@ensart.com                             *
#*                                                               *
#\***************************************************************/
#
#/***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General Public License as published by  *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************/

# Module for Currency eXchange Rate updater
#
# @MODULE = rba_mod.pm
# @VERSION = 0.1.0
# @DATE = 2005-05-31
# @AUTHOR = IP (ip@ensart.com)
# @SERVER = http://www.rba.gov.au
# @NAME = "Reserve Bank of Australia"
# @DATA_URL = http://www.rba.gov.au/Statistics/exchange_rates.html?printable=true
# @DATA_FORMAT = HTML
#


use POSIX qw(strftime);
use HTML::TableContentParser;



#------------------------------------------------------------------------------#
# proceedCXR - get data with CXR and convert it in new format
# string proceedCXR()
#

sub proceedCXR {
  
  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime (time + 32400);
  my %months = (
                "Jan" => "01",
                "Feb" => "02",
                "Mar" => "03",
                "Apr" => "04",
                "May" => "05",
                "Jun" => "06",
                "Jul" => "07",
                "Aug" => "08",
                "Sep" => "09",
                "Oct" => "10",
                "Nov" => "11",
                "Dec" => "12"
               );
  my %currency = (
                  "United States dollar" => "USD",
                  "Japanese yen" => "JPY",
                  "European euro" => "EUR",
                  "South Korean won" => "KRW",
                  "New Zealand dollar" => "NZD",
                  "Chinese renminbi" => "CNY",
                  "UK pound sterling" => "GBP",
                  "New Taiwan dollar" => "TWD",
                  "Singapore dollar" => "SGD",
                  "Indonesian rupiah" => "IDR",
                  "Hong Kong dollar" => "HKD",
                  "Malaysian ringgit" => "MYR",
                  "Swiss franc" => "CHF"
                 );
  
  my %data = (
             'url'              => 'http://www.rba.gov.au/Statistics/exchange_rates.html?printable=true',
             'www'              => 'http://www.rba.gov.au/',
             'description'      => 'Reserve Bank of Australia',
             'primaryCurrency'  => 'AUD'
             );

  if ($wday == 0) {
    return 'N/A';
  }

  my $content = &{main::getContent}($data{'url'});
  if ($content eq 'N/A') {
    return 'N/A';
  }
  
  my $ERtable = '<table><tr>';
  my @strings = split /\n/, $content;
  my $start = 'href="/Statistics/HistoricalExchangeRates/index.html">Click for earlier rates</a>';
  my $end = '</table>';
  my $isStart = 0;
  foreach (@strings) {
    if ($isStart == 0) {
      if (/$start/i) {
        $isStart = 1;
      }
    }
    if ($isStart == 1) {
      if (/$end/i) {
        $ERtable .= $_;
        last;
      }
      $ERtable .= $_;
    }
  }
  
  my $output = '';
  my $tcp = HTML::TableContentParser->new;
  my $tables = $tcp->parse($ERtable);
  my $rowCount = 0;
  my $cellCount = 0;
  my $value = '';
  my $CODE = '';
  for $t (@$tables) {
    for $r (@{$t->{rows}}) {
      for $c (@{$r->{cells}}) {
        if ($cellCount == 0) {
          $CODE = $currency{$c->{data}};
        }
        if ($cellCount == 5) {
          $value = $c->{data};
          $value =~ s/<[^>]*>//gs;
          if ($rowCount == 0) {
            #DATE
            my ($DD, $MM, $YYYY) = split / /, $value;
            $MM = $months{$MM};
            $output .= "UPDATED=".$YYYY."-".$MM."-".$DD."\n";
            $output .= "SOURCE_URL=".$data{'www'}."\n";
            $output .= "DESCRIPTION=".$data{'description'}."\n";
            $output .= "PRIMARY_CURRENCY=".$data{'primaryCurrency'}."\n";
            $output .= "AUD=1\n";
          }
          if ($rowCount > 0 && $rowCount < 14) {
            #RATE
            $value =~ s/\,/\./;
            $output .= $CODE.'='.sprintf("%.12f", $value)."\n";
          }
        }
        $cellCount++;
      }
      $rowCount++;
      $cellCount = 0;
      $CODE = '';
    }
    $rowCount = 0;
  }
  
  return $output;
}


#
#------------------------------------------------------------------------------#


1;