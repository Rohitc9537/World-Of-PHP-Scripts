package frbny_mod;

#/***************************************************************\
#*                                                               *
#*   Filename:         frbny_mod.pm                              *
#*   Version:          v. 0.1.0                                  *
#*   Last Modified:    25/07/2005                                *
#*   Copyright:        EnsART Professionals � 2005               *
#*                     www.ensart.com                            *
#*   Author:           Igor [ip] Pavlenko                        *
#*                     ip@ensart.com                             *
#*                                                               *
#\***************************************************************/
#
#/***************************************************************************
#*                                                                          *
#*   This program is free software; you can redistribute it and/or modify   *
#*   it under the terms of the GNU General Public License as published by   *
#*   the Free Software Foundation; either version 2 of the License, or      *
#*   (at your option) any later version.                                    *
#*                                                                          *
#***************************************************************************/

# Module for Currency eXchange Rate updater
#
# @MODULE = frbny_mod.pm
# @VERSION = 0.1.0
# @DATE = 2005-07-25
# @AUTHOR = IP (ip@ensart.com)
# @SERVER = http://www.newyorkfed.org/
# @NAME = "Federal Reserve Bank of New York"
# @DATA_URL = http://www.newyorkfed.org/markets/fxrates/FXtoXML.cfm?FEXdate=YYYY-MM-DD 00:00:00&FEXtime=1200
# @DATA_FORMAT = xml
#


use POSIX qw(strftime);
use Data::Dumper;

#------------------------------------------------------------------------------#
# proceedCXR - get data with CXR and convert it in new format
# string proceedCXR()
#

sub proceedCXR {

  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime (time - 21600);
  
  if ($wday == 0 || $wday == 6) {
    return 'N/A';
  }
  if ($wday == 1 && $hour < 12) {
    return 'N/A';
  }
  
  my $YYYY = undef;
  my $MM = undef;
  my $DD = undef;
  my $curDate = undef;
    
  if ($hour < 12) {
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime (time - 108000);
    $YYYY = (1900+$year);
    $MM = sprintf("%02d", $mon + 1);
    $DD = sprintf("%02d", $mday);
    $curDate = $YYYY.'-'.$MM.'-'.$DD;
  }
  else {
    $YYYY = (1900+$year);
    $MM = sprintf("%02d", $mon + 1);
    $DD = sprintf("%02d", $mday);
    $curDate = $YYYY.'-'.$MM.'-'.$DD;
  }
  
  my %data = (
             'url'              => 'http://www.newyorkfed.org/markets/fxrates/FXtoXML.cfm?FEXdate='.$curDate.' 00:00:00&FEXtime=1200',
             'www'              => 'http://www.newyorkfed.org/',
             'description'      => 'Federal Reserve Bank of New York',
             'primaryCurrency'  => 'USD'
             );

 

  my $content = &{main::getContent}($data{'url'});
  if ($content eq 'N/A') {
    return 'N/A';
  }
  
  my $xdh = new XML::Simple();
  my $xmlData = eval { $xdh->XMLin($content, ForceArray => 1); };
    if ($@) {
      my $tmpMsg = $@;
      $tmpMsg =~ s/\n/ /g;
      &{main::loging}(20, $tmpMsg);
      return 'N/A';
    }
    
  my $output = undef;
  
  if (exists($xmlData->{'frbny:DataSet'}[0]->{'frbny:Series'})) {
    my $series = $xmlData->{'frbny:DataSet'}[0]->{'frbny:Series'};
    $output = "UPDATED=".${$series}[0]->{'frbny:Obs'}[0]->{'frbny:TIME_PERIOD'}[0]."\n";
    $output .= "SOURCE_URL=".$data{'www'}."\n";
    $output .= "DESCRIPTION=".$data{'description'}."\n";
    $output .= "PRIMARY_CURRENCY=".$data{'primaryCurrency'}."\n";
  
    $output .= $data{'primaryCurrency'}."=1\n";
    my $i = 0;
    my $currency = undef;
    my $currencyUnit = undef;
    my $rate = undef;
    while (exists(${$series}[$i])) {
      $currency = uc(${$series}[$i]->{'frbny:Key'}[0]->{'frbny:CURR'}[0]);
      $currencyUnit = uc(${$series}[$i]->{'UNIT'});
      $rate = ${$series}[$i]->{'frbny:Obs'}[0]->{'frbny:OBS_VALUE'}[0];
      $rate =~ s/\,/\./;
      if ($currency ne $data{'primaryCurrency'}) {
        if ($rate != 0) {
          $rate = 1 / $rate;
        }
        $currencyUnit = $currency;
      }
      $output .= $currencyUnit.'='.sprintf("%.12f", $rate)."\n";
      $currency = undef;
      $currencyUnit = undef;
      $rate = undef;
      $i++;
    }
  }
  else {
    return 'N/A';
  }
  
  return $output;
}


#
#------------------------------------------------------------------------------#


1;