<?
$action = 1;
$IS_ERROR = false;
$ERROR = '';

$defUCXRPath = $_SERVER['DOCUMENT_ROOT'].' [GO ONE LEVEL UP?] [DIR NAME]';
$defCXRPath = $_SERVER['DOCUMENT_ROOT'].' [DIR NAME]';
$defWWWPath = 'http://'.$_SERVER['HTTP_HOST'].'/[DIR NAME]';
$defLoging = 'true';
$defModules = array();

function setPath($path) {
  
  if (strpos($path, '/') !== false) {
    // So, should be UNIX path
    if (substr($path, -1) != '/') {
      $path .= '/';
    }
    return $path; 
  }
  elseif (strpos($path, '\\') !== false) {
    // Should be Windows path 
    if (substr($path, -1) != '\\') {
      $path .= '\\';
    }
    return $path; 
  }
  else {
    return false;
  }
}

function setWWWPath($wwwPath) {
  
  if (substr($wwwPath, -1) != '/') {
    return $wwwPath.'/';
  }
  else {
    return $wwwPath;
  }
}

function getAttributes($fcontent = array()) {
  $attributes = array(
    "@MODULE",
    "@VERSION",
    "@DATE",
    "@AUTHOR",
    "@SERVER",
    "@NAME",
    "@DATA_URL",
    "@DATA_FORMAT"
  );
  $result = array();
  
  foreach ($fcontent as $key => $value) {
    $isAtPos = strpos($value, '@');
    if ($isAtPos) {
    	foreach ($attributes as $num => $atr) {
    	  $pos = strpos($value, $atr);
    	  if ($pos) {
    	    $atPos = strpos($value, '@');
    	    list($atrName, $atrVal) = explode('=', substr($value, $atPos));
    	    $atrName = trim($atrName);
    	    $atrVal = trim($atrVal);
    	    $result[$atrName] = $atrVal;
    	    unset($pos);
    	    break;
    	  }
    	}
    	unset($isAtPos);
    }
  }
  
  return $result;
}


function getFilesList($path = '', $isModules = false) {
  $dh = 0;
  $ext = '.pm';
  $file = '';
  $list = array();
  
  $path = setPath($path);
  
  if ($path) {
    if (is_dir($path)) {
      if ($dh = opendir($path)) {
        while (($file = readdir($dh)) !== false) {
          if ($isModules) {
            if (substr($file, -3) == $ext) {
              $fcontent = file($path.$file);
              $list[$file] = getAttributes($fcontent);
            }
          }
          else {
            if (is_file($path.$file)) {
              array_push($list, $file);
            }
          }
        }
        closedir($dh);
        return $list;
      }
      else {
        return false;
      }
    }
    else {
      return false;
    }
  }
  else {
    return false;
  }
}

function install($path = '', $toUCXR = '', $toCXR = '', $toWWW = '', $isLoging = 'true', $modulesList = array()) {
  global $IS_ERROR, $ERROR;
  
  $path = setPath($path);
  $toUCXR = setPath($toUCXR);
  $toCXR = setPath($toCXR);
  $toWWW = setWWWPath($toWWW);
  $slesh = substr($toCXR, -1);
  
  $addModules = '';
  for ($i = 0; $i < count($modulesList); ++$i) {
    if (substr($modulesList[$i], -3) == '.pm') {
      $addModules .= '    <module value="'.$modulesList[$i].'" />'."\n";
    }
  }
  
  $ucxrDirs = array('bin', 'conf', 'logs', 'modules');
  $cxrDirs = array('data', 'www', 'www'.$slesh.'class', 'www'.$slesh.'graphics', 'www'.$slesh.'js', 'www'.$slesh.'style');
  $parseUCXR = array('bin'.$slesh.'updaterCXR.pl', 'conf'.$slesh.'updaterCXR.xml');
  $parseCXR = array('www'.$slesh.'cxrAPI.php');
  $exec = array('updaterCXR.pl');
  
  $paterns = array(
    0 => '/%CXR_PATH%/',
    1 => '/%CXR_DATA_DIR%/',
    2 => '/%CXR_MODULES%/',
    3 => '/%CXR_WWW_PATH%/',
    4 => '/%IS_LOGING%/'); 
  $matches = array(
    0 => $toUCXR,
    1 => $toCXR.'data/',
    2 => $addModules,
    3 => $toWWW,
    4 => $isLoging);
  
  
  if (!file_exists($toUCXR)) {
    if (!@mkdir($toUCXR, 0777)) {
      $IS_ERROR = true;
      $ERROR = 'Can not create <b>'.$toUCXR.'</b> directory.';
      return false;
    } 
    chmod($toUCXR, 0777);
  }
  if (!file_exists($toCXR)) {
    if (!@mkdir($toCXR, 0777)) {
      $IS_ERROR = true;
      $ERROR = 'Can not create <b>'.$toCXR.'</b> directory.';
      return false;
    }
    chmod($toCXR, 0777);
  }
    
  for ($i = 0; $i < count($ucxrDirs); ++$i) {
    if (!file_exists($toUCXR.$ucxrDirs[$i])) {
      if (!@mkdir($toUCXR.$ucxrDirs[$i], 0777)) {
        $IS_ERROR = true;
        $ERROR = 'Can not create <b>'.$toUCXR.$ucxrDirs[$i].'</b> directory.';
        return false;
      }
      chmod($toUCXR.$ucxrDirs[$i], 0777);
    }
    $files = getFilesList($path.$ucxrDirs[$i]);
    for ($j = 0; $j < count($files); $j++) {
      if (!@copy(setPath($path.$ucxrDirs[$i]).$files[$j], setPath($toUCXR.$ucxrDirs[$i]).$files[$j])) {
        $IS_ERROR = true;
        $ERROR = 'Can not copy file <b>'.setPath($path.$ucxrDirs[$i]).$files[$j].'</b> to <b>'.setPath($toUCXR.$ucxrDirs[$i]).$files[$j].'</b>';
        return false;
      }
      if (in_array($files[$j], $exec)) {
        chmod(setPath($toUCXR.$ucxrDirs[$i]).$files[$j], 0777);
      }
      else {
        chmod(setPath($toUCXR.$ucxrDirs[$i]).$files[$j], 0666);
      }
    }
  }
  
  for ($i = 0; $i < count($cxrDirs); ++$i) {
    if (!file_exists($toCXR.$cxrDirs[$i])) {
      if (!@mkdir($toCXR.$cxrDirs[$i], 0777)) {
        $IS_ERROR = true;
        $ERROR = 'Can not create <b>'.$toCXR.$cxrDirs[$i].'</b> directory.';
        return false;
      }
      chmod($toCXR.$cxrDirs[$i], 0777);
    }
    $files = getFilesList($path.$cxrDirs[$i]);
    for ($j = 0; $j < count($files); $j++) {
      if (!@copy(setPath($path.$cxrDirs[$i]).$files[$j], setPath($toCXR.$cxrDirs[$i]).$files[$j])) {
        $IS_ERROR = true;
        $ERROR = 'Can not copy file <b>'.setPath($path.$cxrDirs[$i]).$files[$j].'</b> to <b>'.setPath($toCXR.$cxrDirs[$i]).$files[$j].'</b>';
        return false;
      }
      chmod(setPath($toCXR.$cxrDirs[$i]).$files[$j], 0666);
    }
  }

  for ($i = 0; $i < count($parseUCXR); ++$i) {
    $fcontent = @file_get_contents($toUCXR.$parseUCXR[$i]);
    $fsize = @filesize($toUCXR.$parseUCXR[$i]);
    $fh = @fopen($toUCXR.$parseUCXR[$i], "wb");    
    $fcontent = preg_replace($paterns, $matches, $fcontent);
    @fwrite($fh, $fcontent);
    @fclose($fh);
  }
  
  for ($i = 0; $i < count($parseCXR); ++$i) {
    $fcontent = @file_get_contents($toCXR.$parseCXR[$i]);
    $fsize = @filesize($toCXR.$parseCXR[$i]);
    $fh = @fopen($toCXR.$parseCXR[$i], "wb");    
    $fcontent = preg_replace($paterns, $matches, $fcontent);
    @fwrite($fh, $fcontent);
    @fclose($fh);
  }
  
  return true;
  
}

//install('CXR/', '/srv/www/htdocs/CXR', '/srv/www/htdocs/CXR', 'http://localhost/');
$modules = getFilesList('CXR/modules/', true);
//echo "<pre>".print_r($_POST)."</pre>";

if (isset($_POST['install'])) {
  
  
  if (!isset($_POST['ucxr_path']) || empty($_POST['ucxr_path']) || $_POST['ucxr_path'] == $defUCXRPath) {
    $IS_ERROR = true;
    $ERROR .= '<b>updaterCXR installation dir</b> was not set.<br />';
  }
  else {
    $defUCXRPath = $_POST['ucxr_path'];
  }
  
  if (!isset($_POST['cxr_path']) || empty($_POST['cxr_path']) || $_POST['cxr_path'] == $defCXRPath) {
    $IS_ERROR = true;
    $ERROR .= '<b>CXR API installation dir</b> was not set.<br />';
  }
  else {
    $defCXRPath = $_POST['cxr_path'];
  }
  
  if (!isset($_POST['www_path']) || empty($_POST['www_path']) || $_POST['www_path'] == $defWWWPath) {
    $IS_ERROR = true;
    $ERROR .= '<b>CXR API URL</b> was not set.<br />';
  }
  else {
    $defWWWPath = $_POST['www_path'];
  }
  
  if (!isset($_POST['loging'])) {
    $IS_ERROR = true;
    $ERROR .= '<b>Enable loging</b> was not set.<br />';
  }
  else {
    $defLoging = $_POST['loging'];
  }
  
  if (!isset($_POST['addModules'])) {
    $IS_ERROR = true;
    $ERROR .= '<b>Install modules</b> was not set.<br />';
  }
  else {
    $defModules = $_POST['addModules'];
  }
  
  if (!$IS_ERROR) {
    // installation 
    if (install('CXR/', $_POST['ucxr_path'], $_POST['cxr_path'], $_POST['www_path'], $_POST['loging'], $_POST['addModules'])) {
      $action = 2; 
    }
  }
  
}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="Author" content="Igor Pavlenko/EnsART Professionals">
    <style type="text/css">
      body  {
        background-color: #FFFFFF;
        color: #000000;
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-size: 11px;
        font-weight: normal;
        padding: 0px;
        margin: 5px;
      }
      
      .tableMain {
        color: #000000;
        empty-cells: show;
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-size: 11px;
        border-width: 1px;
        border-style: none;
        padding: 0px;
      }
      
      a:link {
        font-size: 11px;
        color: #BF0000;
      }
      
      a:active {
        font-size: 11px;
        color: #BF0000;
      }
      
      a:visited {
        font-size: 11px;
        color: #BF0000;
      }
      
      a:hover {
        font-size: 11px;
        color: #2C9EFF;
      }
      
      a.copyrightHref:link {
        color: #999999;
      	font-size: 10px;
      }
      
      a.copyrightHref:active {
        color: #999999;
      	font-size: 10px;	
      }
      
      a.copyrightHref:visited {
        color: #999999;
      	font-size: 10px;	
      }
      
      a.copyrightHref:hover {
        color: #2C9EFF;
      	font-size: 10px;	
      }
      
      .copyright {
        color: #999999;
        font-size: 10px;
        text-align: center;
      }
      
      h1 {
        color: #2C9EFF;
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-weight: bold;
        font-size: 16px;
      }
      
      h2 {
        color: #2C9EFF;
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-weight: bold;
        font-size: 14px;
      }
      
      h3 {
        color: #2C9EFF;
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-weight: bold;
        font-size: 12px;
      }
      
      .inputText {
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-size: 11px;
        background-color: #FFFFFF;
        border-color: #B4B4B4;
        border-style: solid;
        border-width: 1px;
        color: #000000;
        width: 396px;
      }
      
      .submitForm {
        font-family: Verdana, Arial,  Geneva, Helvetica, sans-serif;
        font-size: 11px;
        background-color: #EFEFEF;
        border-color: #B4B4B4;
        border-style: solid;
        border-width: 1px;
        color: #000000;
        width: 100px;
      }
      
      .head {
        background-color: #E2E2E2;
        border-color: #CCCCCC;
        border-style: solid;
        border-width: 1px;
        text-align: center;
      }
      
      .empty {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 1px;
        border-top-width: 0px;
        border-right-width: 1px;
        border-bottom-width: 0px;
      }
    
      .label {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 1px;
        border-top-width: 0px;
        border-right-width: 0px;
        border-bottom-width: 0px;
        text-align: right;
      }
      
      .value {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 0px;
        border-top-width: 0px;
        border-right-width: 1px;
        border-bottom-width: 0px;
        text-align: left;
      }
      
      .valueHelp {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 0px;
        border-top-width: 0px;
        border-right-width: 1px;
        border-bottom-width: 0px;
        color: #999999;
        font-size: 10px;
        text-align: left;
      }
      
      .SubmitLabel {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 1px;
        border-top-width: 0px;
        border-right-width: 0px;
        border-bottom-width: 1px;
        text-align: right;
      }
      
      .SubmitValue {
        border-color: #CCCCCC;
        border-style: solid;
        border-left-width: 0px;
        border-top-width: 0px;
        border-right-width: 1px;
        border-bottom-width: 1px;
        text-align: right;
      }

    </style>
    <title>Currency eXchange rates: Installation</title>
  </head>
  
  <body>

    <? if ($action == 1) { ?>
    <div align="center">
    <form action="<?=$_SERVER['PHP_SELF'];?>" enctype="multipart/form-data" method="post" name="contactsForm">
      <table class="tableMain" cellspacing="0" cellpadding="2" width="600">
        <tr>
          <td class="head" colspan="2">
            <h1>CURRENCY EXCHANGE RATES SYSTEM INSTALLATION</h1>
          </td>
        </tr>
        
        <? if ($IS_ERROR) { ?>
        
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="value" width="400"><span style="color: red;"><?=$ERROR;?></span></td>
        </tr>
        
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <? } ?>
        
        <tr>
          <td class="label" width="200"><br />updaterCXR installation dir:&nbsp;</td>
          <td class="value" width="400"><br /><input class="inputText" name="ucxr_path" type="text" value="<?=$defUCXRPath;?>"></td>
        </tr>
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="valueHelp" width="400">It is a good idea to set it one level up of WWW root dir. I.e. it is should be not accesseable through WWW.</td>
        </tr>
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
          <td class="label" width="200">CXR API installation dir:&nbsp;</td>
          <td class="value" width="400"><input class="inputText" name="cxr_path" type="text" value="<?=$defCXRPath;?>"></td>
        </tr>
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="valueHelp" width="400">Should be accesseable through the WEB. "CXR" directory in your site WWW root dir will be good.</td>
        </tr>
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
          <td class="label" width="200">CXR API URL:&nbsp;</td>
          <td class="value" width="400"><input class="inputText" name="www_path" type="text" value="<?=$defWWWPath;?>"></td>
        </tr>
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="valueHelp" width="400">E.g. your site URL is "http://www.mysite.com/" and CXR API installation is in "CXR" directory in your
            WEB site WWW root directory. So, it is should be like this: "http://www.mysite.com/CXR/".
          </td>
        </tr>
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <tr valign="top">
          <td class="label" width="200">Enable loging:&nbsp;</td>
          <td class="value" width="400">
            <input name="loging" type="radio" value="true" <?=($defLoging == 'true') ? 'checked' : ''; ?>>Yes<br />
            <input name="loging" type="radio" value="false" <?=($defLoging == 'false') ? 'checked' : ''; ?>>No<br />
          </td>
        </tr>
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="valueHelp" width="400">Enable or disable loging of all updaterCXR actions.</td>
        </tr>
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <? if (count($modules) > 0) { ?>
        <tr valign="top">
          <td class="label" width="200">Install modules:&nbsp;</td>
          <td class="value" width="400">
            <?php
              foreach ($modules as $key => $value) {
                (in_array($key, $defModules)) ? $checked = 'checked' : $checked = '' ;
              	echo "<input name=\"addModules[]\" type=\"checkbox\" value=\"$key\" $checked>".$value['@NAME']." (v. ".$value['@VERSION'].")<br />\n";
              }
            ?>
          </td>
        </tr>
        <tr>
          <td class="label" width="200">&nbsp;</td>
          <td class="valueHelp" width="400">Please, select at least one module.</td>
        </tr>
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        <? } ?>
        
        <tr>
          <td class="SubmitLabel" width="200">&nbsp;</td>
          <td class="SubmitValue" width="400">
            <br />
            <br />
            <input class="submitForm" name="reset" type="reset" value="Reset">&nbsp;&nbsp;
            <input class="submitForm" name="install" type="submit" value="Install">
            <br />
            <br />
          </td>
        </tr>
      </table>
    </form>
    </div>
    <? } 
       elseif ($action == 2) { 
    ?>
    	
    <div align="center">
      <table class="tableMain" cellspacing="0" cellpadding="2" width="600">
        <tr>
          <td class="head" colspan="2">
            <h1>INSATLLATION COMPLETE</h1>
          </td>
        </tr>
        
        <tr>
          <td class="empty" colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
          <td align="center" class="empty" colspan="2">DO NOT FORGET TO <b>DELETE</b> SOURCE OF INSTALLATION FROM WWW DIRECTORY.</td>
        </tr>
        
        <tr>
          <td align="center" class="empty" colspan="2">Get more details about use and customization: <a href="http://www.cxr.ensart.com/documentation/">CXR on-line manual</a>.</td>
        </tr>
        
        <tr>
          <td class="SubmitLabel" width="200">&nbsp;</td>
          <td class="SubmitValue" width="400">&nbsp;</td>
        </tr>
      </table>
    <? } ?>
    <br />
    <div align="center" class="copyright">Copyright &copy; 2005 <a class="copyrightHref" href="http://www.ensart.com/">EnsART Studios</a>. All rights reserved.</div>
    <br />
  </body>
</html>