<?

// READ THE READ-ME.TXT IF YOU HAVEN'T ALREADY

// MySQL Host
$sql_host = "localhost";

// MySQL Database
$sql_db = "DATABASE";

// MySQL Username
$sql_user = "USERNAME";

// MySQL Password
$sql_pass = "PASSWORD";

?>