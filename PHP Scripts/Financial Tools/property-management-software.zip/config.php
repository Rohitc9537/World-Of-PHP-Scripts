<?php
define("_LIBPATH","./lib/");
require_once _LIBPATH . "site.php";
?>