--------------------------------------------------------------
|MD Send to Friend version 2                                 |
|(c)Matthew Dingley 2002                                     |
|For more scripts or assistance go to MD Web at:             |
|www.matthewdingley.co.uk                                    |
--------------------------------------------------------------

What it does
-The user can send your website to a friend, straight off your website, making
it a perfect marketing strategy. But if the user forgets to fill in a field,
it will return the form to the user highlighting the forgotten field.

How to use
-Just put it into any directory but make sure it is named friend.php otherwise
it will not work. You need to change the two variables to change the color of
highlight that will go round the box if the user forgets to fill it in. You
also need to change the next one to the address of the site that will be
included in the e-mail
-If you know what you're doing, you can change variable $body which is the text
that is sent to the user's friend. I can do it for you if you supply the
information that you want including. Just go to the website.
-If you are confident with PHP you can change the variable '$body' so that you 
can customize the message sent.

Requirements
-Server side - A PHP enabled server with the mail() function enabled
-Client side - The user will need css capabilaties for the highlighting

Help/Assistance/Feedback
-Go to www.matthewdingley.co.uk and go to the contact
section for any help or feedback about this program

New in version 2
-HTML MIME email supported

Licence

-To use this program, you have to keep the copyright notice intact or provide
a mention back to my website at www.matthewdingley.co.uk and make it
clear that it is (c)Matthew Dingley 2002

-You may not distribute this program in any way. You can make a reasonable amount of copies
for your personal use only

-This program is free to use on a non-commercial site. If you want to use it on
a commercial site (excluding .org sites) go to the website for more information.