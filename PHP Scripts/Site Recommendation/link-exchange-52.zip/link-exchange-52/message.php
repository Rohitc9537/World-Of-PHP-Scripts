<? include "_header.inc"; ?>

<table>
	<tr><td width=100% height=380 align=center>
    <?=$_REQUEST["msg"]?>
		<br>
    <a href="javascript:history.back()">Go Back</a>
	</tr>
</table>

<?  include "_footer.inc"; ?>