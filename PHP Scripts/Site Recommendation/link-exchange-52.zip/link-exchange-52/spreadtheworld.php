<? include "_header.inc" ?>
<table cellpadding=10>
	<tr>
		<td align=center>
			<b><big><big>LINK MAIL EXCHANGE PROGRAM</big></big></b>
	<tr>
		<td>
			<img src="lnkxmail1.jpg" alt="Spread The World, Before" 
				style="float:left;" />
 	     <br><br><br>&nbsp; &nbsp; Although you do not join this program,
			<br>
	 		 &nbsp; &nbsp; your site is a link of our website.
	<tr>
		<td>
			<img src="lnkxmail2.jpg" alt="Spread The World, After" 
				style="float:right;"/>
			<b>It's FREE!</b> Your site is not just a link of our website.
		  <br><br>
			but also, whenever a link is added to our web site, a mail will be 
			sent to you telling that a new site has been added.
			<br><br>
			Think about this as a big picture!.
			Got it? Yes! Let me explain what happens after you join this program. 
			<br>
			<br>1. "A" site, a program member, sends a mail for link exchange to you.
			<br>2. You add your link to "A" site, which has this program.
			<br>3. "A" site sends a mail to "B" site, a program member. 
			<br>4. "B" site sends a mail for link exchange to you.
			<br>And on and on....
 			<br><br>
			What I am saying is <b>you don't have to surf around to add your link.
      You just wait mail</b>, and add your link on the sender site.
</table>
<? include "_footer.inc" ?>