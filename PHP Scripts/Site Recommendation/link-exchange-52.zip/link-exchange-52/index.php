<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="refresh" content="0;URL=http:free_link_exchange.php">
</head>
<body>
If your browser does not automatically redirect you in 5 seconds,
click <a href="free_link_change.php">here</a> to go to the new site.
</body>
</html>
