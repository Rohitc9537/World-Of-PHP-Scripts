<html><head>
<title>My page</title>
<script language="JavaScript" src="w4ftell.js"></script>
</head>
<body>
<a href="javascript:newWindow('sendpage.php?'+document.location.href,'tell',400,300,'')">Tell-a-friend about this page</a>
</body>
</html>
