<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>GateQuest php Site Recommender</title>
	<link rel="stylesheet" href="recommend.css" type="text/css">
</head>

<body>

<table width="100%" height="100%">
	<tr>
		<td align="center" valign="middle">
			<?php include("inc.recommend.php"); ?>
			<br><a href="javascript:window.close()">Close Window</a>
		</td>
	</tr>
</table>

</body>
</html>
