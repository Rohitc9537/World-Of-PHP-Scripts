<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>GateQuest php Site Recommender - Include Method</title>
	<link rel="stylesheet" href="recommend.css" type="text/css">
</head>

<body>

<table width="100%" height="100%">
	<tr>
		<td height="65" style="padding: 10px 0px 0px 10px"><a href="javascript:history.go(-1);"><img alt="" border="0" width="100" height="65" src="/art/gq_logo_back.gif"></a></td>
	</tr>
	<tr>
		<td align="center" valign="middle">
			<?php include("inc.recommend.php"); ?>
		</td>
	</tr>
</table>

</body>
</html>
