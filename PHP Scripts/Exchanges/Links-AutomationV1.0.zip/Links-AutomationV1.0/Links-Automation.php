<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Links-Automation.com- Automated links exchange</title>
<meta http-equiv="Content-Type" content="text/html;">
</head>

<body>
<STYLE type="text/css" media="screen">
.CategoryTable
	{
	BORDER:1px solid black;
	WIDTH: 100%;
	}
.CategoryCell
	{
	TEXT-ALIGN: center;
	BORDER:1px solid black;
	}
.CategoryLink
	{
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	COLOR: red;
	FONT-SIZE:10pt;
	FONT-WEIGHT: bold;
	}
.LinkListingTable
	{
	BORDER:1px solid black;
	WIDTH: 100%;
	}
.LinkListing
	{
	MARGIN-TOP: 5px;
	MARGIN-BOTTOM: 5px;
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	COLOR: black;
	FONT-SIZE:10pt;
	}
.LinkURL
	{
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	COLOR: red;
	FONT-SIZE:10pt;
	FONT-WEIGHT: bold;
	}
.NavigationText
	{
	MARGIN-TOP: 5px;
	MARGIN-BOTTOM: 5px;
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	COLOR: black;
	FONT-SIZE:10pt;
	TEXT-ALIGN: center;
	}
.NavigationLinks
	{
	MARGIN-TOP: 5px;
	MARGIN-BOTTOM: 5px;
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	COLOR: blue;
	FONT-SIZE:10pt;
	TEXT-ALIGN: center;
	}
.SearchTerm
	{
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	FONT-SIZE:9pt;
	}
.SearchSelectBox
	{
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	FONT-SIZE:9pt;
	}
.SearchSubmit
	{
	FONT-FAMILY:verdana, arial, helvetica, sans-serif;
	FONT-SIZE:9pt;
	}
</STYLE>
	<? include("BodyOfLinks-Automation.php");?>
</body>
</html>
