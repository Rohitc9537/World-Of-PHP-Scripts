<?php
$file_rev="041305";
//
// phpBannerExchange auto-generated config file
// Change this file at your own risk!
//

$businessname="your@paypalaccount.com";
$ipn_page="ipn.php";
$propername="PayPal";

$payment_currency="US";

$currency_sign="\$";
$currency_int="USD";
$decimal_separator=".";
$thousands_separator=",";
$places="2";

?>