<?php

//
// phpBannerExchange auto-generated config file
// Change this file at your own risk!
//

// DO NOT CHANGE THIS OR YOUR HANDS WILL FALL OFF
// (and it could screw up future installation processes)


?>