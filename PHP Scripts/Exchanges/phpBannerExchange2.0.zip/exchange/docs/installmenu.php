<div id="llinks">
<div class="sidetitle"><? echo "Install Guide"; ?></div>
  <div class="side">
<a href="install.php#new">What's New</a><br>
<a href="install.php#quickstart">Quick Start</a><br>
<a href="install.php#detailed">Install.php</a><br>
<a href="install.php#vars">Variables</a><br>
<a href="install.php#dbstructure">Database Structure</a><br>
<a href="install.php#upgrading">Upgrading</a><br>
<a href="install.php#gethelp">Getting Help/Bugs</a>
  </div>
  </div>
  </div>
