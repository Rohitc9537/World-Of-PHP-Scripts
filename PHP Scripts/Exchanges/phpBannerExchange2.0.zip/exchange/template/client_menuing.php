<div id="llinks">
<div class="sidetitle">{navigation}</div>
  <div class="side">
<a href="{baseurl}/client/stats.php?SID={session}">{home}</a><br>
<a href="{baseurl}/client/logout.php?SID={session}">{logout}</a>
  </div>

<div class="sidetitle">{stats}</div>
  <div class="side">
<a href="{baseurl}/client/emailstats.php?SID={session}">{emailstats}</a><br>
  </div>

<div class="sidetitle">{site}</div>
  <div class="side">
  {commerce}
<a href="{baseurl}/client/banners.php?SID={session}">{banners}</a><br>
<a href="{baseurl}/client/category.php?SID={session}">{category}</a><br>
<a href="{baseurl}/client/gethtml.php?SID={session}">{gethtml}</a><br>
  </div>

<div class="sidetitle">{information}</div>
  <div class="side">
<a href="{baseurl}/client/editinfo.php?SID={session}">{changemail}</a><br>
<a href="{baseurl}/client/editpass.php?SID={session}">{changepass}</a><br>
<a href="{baseurl}/client/promo.php?SID={session}">{promo}</a><br>
  </div>
  </div>
