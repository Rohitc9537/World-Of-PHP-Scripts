<center>
<p>&nbsp;
<p>&nbsp;
<p>&nbsp;
<p>&nbsp;
<a href="http://www.eschew.net/scripts/">phpBannerExchange 2.0</a><br>Administered by <a href="mailto:{ownermail}">{adminname}</a>
</a>
