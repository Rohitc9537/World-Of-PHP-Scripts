<?

$removal = "\n\n\n\n\n\nYou are receiving this message because you signed up for $exchangename. If you no longer wish to receive these newsletters, please <a href=\"$baseurl/client/remove.php?email=%email%&id=%id%\">click here</a> to set your mailing preferences to not receive mailings from us. Please note that we will still contact you, but only in emergencies or important information regarding the Banner Exchange..\n\n";

?>