<?
$usrsubject = "Welcome to ".$exchangename."!";
$usrcontent = "You are recieving this email because someone used this email account to sign up for ".$exchangename.".  If you did not sign up for this service or did not request this information, please accept our apologies.\n\nYour login ID is: $login\nYour Password is: $pass\n\nYou may log on to check your stats, get your HTML code, add and remove banners, and other administrative functions at any time by going to:\n   $baseurl\n\nThank you for your interest!\n\n$adminname."; 
?>