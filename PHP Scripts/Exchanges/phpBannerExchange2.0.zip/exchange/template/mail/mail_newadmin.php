<?
$subject = "New Banner Exchange Account!";
$content = "There is a new banner exchange account awaiting approval! Go here: ".$baseurl."/admin/";
?>
