<?
$usrsubject = "Your ".$exchangename." password...";
$usrcontent = "You are recieving this email because someone used this email account to sign up for ".$exchangename.".  If you did not sign up for this service or did not request this information, please accept our apologies.\n\nYour new password is: $newpw\n\nIt is strongly recommended you log in to your account immediately and reset the password. You may log in by going to the following URL:\n   $baseurl\n\nRegards,\n\n$adminname.";
?>