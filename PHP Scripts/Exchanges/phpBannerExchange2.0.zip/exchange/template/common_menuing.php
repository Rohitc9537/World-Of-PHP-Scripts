<div id="llinks">
<div class="sidetitle">{menu_head}</div>
  <div class="side">
<a href="{baseurl}/index.php?SID={session}">{home}</a><br>
<a href="{baseurl}/recoverpw.php?SID={session}">{lostpw}</a><br>
<a href="{baseurl}/faq.php?SID={session}">{faq}</a><br>
<a href="{baseurl}/signup.php?SID={session}">{signup}</a><br>
<a href="{baseurl}/rules.php?SID={session}">{rules}</a><br>
<a href="{baseurl}/cou.php?SID={session}">{cou}</a><br>
  </div>

<div class="sidetitle">{extras}</div>
  <div class="side">
<a href="top.php?SID={session}">{topbanns}</a><br>
<a href="overall.php?SID={session}">{overallstats}</a><br>
  </div>
  </div>