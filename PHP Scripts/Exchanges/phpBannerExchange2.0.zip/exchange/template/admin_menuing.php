<div id="llinks">
<div class="sidetitle">{acct_head}</div>
  <div class="side">
<a href="{baseurl}/admin/validate.php?SID={session}">{valacct}</a><br>
<a href="{baseurl}/admin/addacct.php?SID={session}">{addacct}</a><br>
<a href="{baseurl}/admin/listall.php?SID={session}">{listacct}</a><br>
<a href="{baseurl}/admin/changedefaultbanner.php?SID={session}">{changedefault}</a><br>
  </div>

<div class="sidetitle">{admin_head}</div>
  <div class="side">
<a href="{baseurl}/admin/email.php?SID={session}">{mailer}</a><br>
<a href="{baseurl}/admin/catmain.php?SID={session}">{categories}</a><br>
<a href="{baseurl}/admin/addadmin.php?SID={session}">{addadmin}</a><br>
<a href="{baseurl}/admin/editpass.php?SID={session}">{editpass}</a><br>
  </div>

<div class="sidetitle">{tools_head}</div>
	<div class="side">
<a href="{baseurl}/admin/dbtools.php?SID={session}">{dbtools}</a><br>
<a href="{baseurl}/admin/templates.php?SID={session}">{templates}</a><br>
<a href="{baseurl}/admin/editvars.php?SID={session}">{vars}</a><br>
<a href="{baseurl}/admin/editcss.php?SID={session}">{editcss}</a><br>
<a href="{baseurl}/admin/faq.php?SID={session}">{faqmgr}</a><br>
<a href="{baseurl}/admin/checkbanners.php?SID={session}">{checkbanners}</a><br>
<a href="{baseurl}/admin/editstuff.php?SID={session}&obj=cou">{editcou}</a><br>
<a href="{baseurl}/admin/editstuff.php?SID={session}&obj=rules">{editrules}</a><br>
<a href="{baseurl}/admin/promos.php?SID={session}">{promo}</a><br>
<a href="{baseurl}/admin/update.php?SID={session}">{update}</a><br>
{exchangestate}<br>
{commerce}
	</div>
<div class="sidetitle">{nav_head}</div>
  <div class="side">
<a href="{baseurl}/admin/stats.php?SID={session}">{home}</a><br>
<a href="{baseurl}/admin/logout.php?SID={session}">{logout}</a><br>
<a href="{baseurl}/docs/admin.php?SID={session}" target="_blank">{help}</a>
  </div>
  </div>