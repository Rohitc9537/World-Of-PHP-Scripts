<html>
<head>
<title>Linkman</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#000000" text="#FFFFFF" link="#FFFFFF" alink="#FF0000" vlink="#CCCCCC">
<?php include('links.txt'); ?>
<hr size="2" noshade align="left" width="13%">
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<a href="submit.php" target="_self">Add Your Link</a> <font size="1">All new links 
get placed last on the field.</font></font> 
</body>
</html>
