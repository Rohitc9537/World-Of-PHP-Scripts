
<p><font face="Verdana, Arial, Helvetica, sans-serif"><font face="Verdana, Arial, Helvetica, sans-serif"><b>MyBannerExchange 
    </b></font><br>
    <font size="-1">This index page should service only as an EXAMPLE. Nothing 
    in the config file applies here. This page is here only to show you what files 
    to link to for the signup and login pages.</font></font></p>
  <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif"><b><a href="create.php">Create 
    Account</a><br>
    <a href="edit.php">Log In</a></b></font></p>
  <p>
