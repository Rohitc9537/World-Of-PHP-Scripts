<br /><br /><br /><br /><br /><br /><br /><br />
</div>
<div align="center"><font face="arial"><a href="http://www.phpdictionary.com/">PHP Dictionary</a> - Copyright 2005</font></div>
<div align="center"></div>
</body>
</html>