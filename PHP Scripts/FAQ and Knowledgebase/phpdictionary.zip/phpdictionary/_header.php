<html>
<head>
<title><?php echo $GLOBALS['page_title']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="default.css" rel="stylesheet" type="text/css">
<script src="default.js"></script>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
-->
</style>
</head>

<body bgcolor="#F5F5F5" topmargin="0">
<tr>
		<td><br />
		<div align="center"><h1><font face="arial"><?php echo $GLOBALS['page_title']; ?></font></h1>
		  <span class="style1">Here is the description of the site</span><br>
	      </div>
		<div align="center">
		  <br />

		  
		  </div>
		  <div align="center">