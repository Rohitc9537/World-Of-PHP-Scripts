<?php
echo "This is a example headerfile";
?>