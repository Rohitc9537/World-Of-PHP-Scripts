<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_email_new_com_subject = "FAQEngine - Neuer Kommentar";
$l_email_new_com_mail = "{date}:\r\nNeuer Benutzerkommentar zu FAQ-Nr. {faqnr}\r\n\r\n";
$l_email_new_userquestion_subject = "FAQEngine - neue Benutzerfrage";
$l_email_new_userquestion_ascmail= "Neue Benutzerfrage Nr. {qnr}\r\nKlicken Sie auf diesen Link, um die Frage anzusehen:\r\n{qlink}\r\n\r\n";
$l_email_new_userquestion_htmlmail= "Neue Benutzerfrage Nr. {qnr}<br>Klicken Sie auf diesen Link, um die Frage anzusehen:<br><a href=\"{qlink}\">{qlink}</a>";
?>