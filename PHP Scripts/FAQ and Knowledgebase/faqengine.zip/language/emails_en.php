<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_email_new_com_subject = "FAQEngine - new comment";
$l_email_new_com_mail = "{date}:\r\nNew user comment on FAQ #{faqnr}\r\n\r\n";
$l_email_new_userquestion_subject = "FAQEngine - new user question";
$l_email_new_userquestion_ascmail= "New user question #{qnr}\r\nClick on this link to see:\r\n{qlink}\r\n\r\n";
$l_email_new_userquestion_htmlmail= "New user question #{qnr}<br>Click on this link to see:<br><a href=\"{qlink}\">{qlink}</a>";
?>
