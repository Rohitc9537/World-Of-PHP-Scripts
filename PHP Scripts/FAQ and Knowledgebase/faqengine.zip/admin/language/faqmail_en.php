<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_fm['heading'] = "FAQ";
$l_fm['progname'] = "Programname";
$l_fm['noentries'] = "no entries";
$l_fm['withoutcategory'] = "without category";
$l_fm['withoutsubcat'] = "without subcategory";
$l_fm['bbccode'] = "Code";
$l_fm['bbcquote'] = "Quote";
$l_fm['question'] = "Question";
$l_fm['answer'] = "Answer";
$l_fm['attachement'] = "download attachment";
$l_fm['currtime'] = "actual time on server is ";
$l_fm['timezone_note'] = "all times are";
$l_fm['content'] = "Content";
$l_fm['generated_with'] = "Powered by";
$l_fm['compmail'] = "This email contains the FAQ for {progname} ({proglang}) on {actdate} as gzip compressed file.";
$l_fm['dateformat'] = "m/d/Y H:i";
$l_fm['generated'] = "Generated";
$l_fm['mailsubject'] = "FAQs for program {progname}";
$l_fm['floginsubj'] = "FAQEngine - failed login attempt";
$l_fm['floginbody'] = "Failed login.\r\n{date}, {remoteip}\r\nUsername: {username}\r\nPassword: {password}\r\n\r\n";
?>