<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_uq_answer_prelude = "Am {date} haben Sie folgende Frage gestellt:";
$l_uq_answer_subject = "Antwort auf FAQ-Anfrage (#{refid})";
$l_uq_answer_is = "Die Antwort darauf lautet:";
$l_uq_sc_subject = "Statuswechsel der FAQ-Anfrage (#{refid})";
$l_uq_sc_states = array("neu","in Bearbeitung","zur�ckgestellt","bearbeitet");
$l_uq_sc_body = "Der Status Ihrer FAQ-Anfrage (#{refid}) vom {date} hat sich ge�ndert.\nDer neue Status ist: {state}";
$l_uq_dateformat = "d.m.Y H:i:s";
?>