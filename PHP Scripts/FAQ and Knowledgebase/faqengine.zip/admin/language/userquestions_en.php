<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_uq_answer_prelude = "On {date} You posted the following question:";
$l_uq_answer_subject = "Answer to FAQ-question posting (#{refid})";
$l_uq_answer_is = "The answer is:";
$l_uq_sc_subject = "State for FAQ-question posting (#{refid}) changed";
$l_uq_sc_states = array("new","work in progress","deferred","finished");
$l_uq_sc_body = "The state of Your FAQ-question posting (#{refid}) on {date} has been changed.\nThe new state is: {state}";
$l_uq_dateformat = "m/d/Y H:i:s";
?>