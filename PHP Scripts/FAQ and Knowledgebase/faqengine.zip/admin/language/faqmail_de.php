<?php
/***************************************************************************
 * (c)2001-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_fm['heading'] = "FAQ";
$l_fm['progname'] = "Programmname";
$l_fm['noentries'] = "keine Eintr&auml;ge";
$l_fm['withoutcategory'] = "Ohne Kategorie";
$l_fm['withoutsubcat'] = "Ohne Unterkategorie";
$l_fm['bbccode'] = "Code";
$l_fm['bbcquote'] = "Zitat";
$l_fm['question'] = "Frage";
$l_fm['answer'] = "Antwort";
$l_fm['attachement'] = "Dateianhang herunterladen";
$l_fm['currtime'] = "Aktuelle Uhrzeit auf dem Server: ";
$l_fm['timezone_note'] = "Alle Zeitangaben sind in";
$l_fm['content'] = "Inhalt";
$l_fm['generated_with'] = "Powered by";
$l_fm['compmail'] = "Diese E-Mail enth&auml;lt die FAQ-Liste f&uuml;r {progname} ({proglang}) vom {actdate} in komprimierter Form.";
$l_fm['dateformat'] = "d.m.Y H:i";
$l_fm['generated'] = "Erzeugt";
$l_fm['mailsubject'] = "FAQs fuer das Programm {progname}";
$l_fm['floginsubj'] = "FAQEngine - fehlgeschlagener Anmeldeversuch";
$l_fm['floginbody'] = "Fehlgeschlagener Loginversuch.\r\n{date}, {remoteip}\r\nBenutzername: {username}\r\nPasswort: {password}\r\n\r\n";
?>