<?php

$db_location = 'localhost';
$db_username = 'username';
$db_password = 'password';
$db_database = 'database';
$db_prefix = 'starsol_faq_';

$site_name = 'Starsol Scripts';
$site_domain = 'starsol.co.uk';

$rating_switch = '1';

$admin_username = 'admin_u';
$admin_password = 'admin_p';

?>