JIpFromX by jasx	Richiesto: Php4 + mysql	     


 QUESTO SCRIPT PUO' ESSERE UTILIZZATE SOTTO LICENZA GPL 2.0 � SUCCESSIVE
 OGNI USO E DIFFUSIONE DI QUESTO SCRIPT E' CONSENTITO ED INCORAGGIATO DALL' AUTORE, ANCHE PER USI COMMERCIALI, PURCHE' NEL RISPETTO
 DI QUESTA LICENZA E A CONDIZIONE CHE, ANCHE NELLE VERSIONE MODIFICATE, VENGA LASCIATA INTATTA QUESTA LICENZA E I RIFERIMANTI 
 ALL'AUTORE ORIGINALE.  	                                                                                       

 L'AUTORE DECLINA OGNI GENERE DI RESPONSABILITA' DERIVANTE DALL' USO DI QUESTO SCRIPT, CHE VIENE FORNITO "COSI' COM'E'" SENZA ALCUN
 TIPO DI GARANZIA, NEANCHE IMPLICITA. CHI UTILIZZI QUESTO SCRIPT ACCETTA IMPLICITAMENTE QUESTA GARANZIA E LO FA SOTTO LA SUA DIRETTA 
 RESPONSABILITA'.
 

 Per consigli , contatti , bugs	 ( e se volete donazioni:PppP )	
 jasx@inwind.it			


 Per utilizzare lo script:

1) importate tramite phpmysqladmin o un qualsiasiasi frontend per mysql il file JipfromX.sql
2) Nel file JipfromX.php settate i dati di connessione dal db
3) Buon lavoro:) c'ya :)


IL DATABASE � FORNITO DA http://www.Directi.com;
AGGIORNATO AL MESE 05/2003