Bizzar IP Redirection

*************************************
**                                 **
** Written by: Brad Derstine       **
** Contact: Brad@BizzarScripts.net **
** Website: www.BizzarScripts.net  **
**                                 **
*************************************

Requirements:
The script has no requirements other than a webserver that supports PHP.

*************************************

Installation Instructions:
1.) Extract the php file into a folder of your choosing.

*************************************

Usage Instructions:
Use the following url and replace the pathing with your site.

http://www.yourdomain.com/script_folder/ipredirect.php

*************************************
This is my first script I ever wrote.  I needed to redirect people to different webpages based on their IP address, and not finding a decent script on the internet, I wrote my own.  The script is pretty self explanatory when you open it up. Just change the octet value to whatever value you want and you can base it on each of the 4 octets.

You can also use ranges and stuff in the octets for ip ranges, just need to edit the lines.  You'll see where to edit them.  If you still have problems or questions, feel free to email me.

Good luck and enjoy!

-Brad
Brad@BizzarScripts.net