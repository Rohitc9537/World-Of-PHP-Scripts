<?php

// uDi - You Direct It, written by, and copyright Mike Cheesman.

require "config.php";
include "$header"; ?>
uDi - You Direct It, allows you to offer <i><b>come.to</b></i> style redirection on <i>your</i> website.  It is simple to install, and simple to administer.  Simple to signup and edit accounts.  Allow your users to signup for <i><b>yourdomain.com/them</b></i>, and help them cover up those ugly free host URL's.<P><P>Enable easy to remember URL's, help change this:<br><i><b>http://server.uglyhostname.com/section/user</b></i><br>into this:<br><i><b>http://yourdomain.com/user</b></i><P>
<?php include "$footer"; ?>
