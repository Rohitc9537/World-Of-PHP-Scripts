///////////////////////////////////////////////////////
// uDi - You Direct It, was written by Mike Cheesman /////////////////////
// It is free to you, thus free to anyone else, it is not for sale, but //
// is freeware.  Please send any comment's or bug reports to:           //
// mike@comfymusic.net.  Please read the following, and enjoy my script //
//////////////////////////////////////////////////////////////////////////

BEFORE YOU START, PLEASE NOTE THAT uDi DOES NOT WORK ON SERVERS RUNNING PHP IN SAFEMODE.


INSTALLATION
============

1.  UnZip the contents to a folder on your hard drive.
2.  Edit the following values in 'config.php':
	$website, $sitename, $adminmail, $adminusername, $adminpass, $header, $footer, $credir.
	Use the comments beside each, to help you out.
3.  Once #2 is done, upload all the files you got in the zip (minus the readme) to your web server.
4.  CHMOD everything, 777 EVEN THE FOLDER YOU PLACE IT IN.
5.  Surf to the control panel, (http://yoursite.com/cpanel.php) and login, bookmark this page for future reference.
6.  Enjoy, and please send me feedback and suggestions.

CHANGING THE DESIGN
===================

Changing the design of the script is simple.  Create a template, then copy everything right before the content, and paste it in to you header file, copy everything after the content, and paste it into your footer file.  Simple!

WORKING EXAMPLE
===============

Visit http://www.themudd.org to view a working example of uDi.  Please do not use this service to test uDi, only signup if you really want an account.

UPDATES/ADDITIONS
=================
(newest to oldest)
META-Tag feature submitted by Reggie Goldman of TheMudd.org, and edited somewhat by me to get out the kinks.

WHOIS script submitted by Reggie Goldman of TheMudd.org

=================

Thanks,
Mike.

ICQ: 76600538
Email: mike@comfymusic.net