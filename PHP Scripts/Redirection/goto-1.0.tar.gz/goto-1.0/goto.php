<?php
/**
 * PHP Goto v 1.0
 *
 * Copyright (c) 2002 LAMP Scripts
 * http://www.lampscripts.net
 *
 * This code is subject to version 1.0 of the LAMP Scripts license,
 * which is included with this package in the file LICENSE, and is
 * available via the world-wide-web at
 * http://www.lampscripts.net/legal/license-1.0.html or by sending
 * a blank email to license@lampscripts.net
 *
 * Credits: Matt Brown <mattbrown@lamphost.net>
 */

    /**
     * goto.php
     */

    /* Get URL to "goto" from POST var */
    $url = $_POST["url"];

    if ($url == "") {
        /* If "goto" URL is not set, then set it to the refering page */
        $url = $_SERVER["HTTP_REFERER"];
    } elseif (!ereg("^http\:\/\/", $url) && !ereg("^https\:\/\/", $url) && !ereg("^ftp\:\/\/", $url)) {
        /* if protocol of http or https or ftp is not specified, set it to http */
        $url = "http://" . $url;
    }
    /* "goto" the specified URL */
    header("Location: $url");
?>