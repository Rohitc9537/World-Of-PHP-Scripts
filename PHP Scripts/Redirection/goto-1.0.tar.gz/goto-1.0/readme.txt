PHP Goto v 1.0, Copyright (c) 2002 LAMP Scripts

INSTALL
1. Put the file goto.php in your web directory.
2. Create a form that points to goto.php. See USAGE below for details.

USAGE
GoTo will redirect a user to an URL that they select from a form. The
allowed protocols are HTTP, HTTPS, and FTP. If the protocol is not
specified with the form data, it defaults to HTTP.

Example form:

<form action="goto.php" method="POST" enctype="application/x-www-form-urlencoded">
<select name="url" onchange="javascript:this.form.submit();">
<option selected value="example.com">Example 1</option>
<option selected value="www.example.com">Example 2</option>
<option selected value="http://www.example.com">Example 3</option>
<option selected value="https://www.example.com">Example 4</option>
<option selected value="ftp://example.com">Example 5</option>
<option selected value="ftp://ftp.example.com">Example 6</option>
<option selected value="ftp.example.com">Example 7</option>
</select>
<input type="submit">
</form>

The javascript in onchange causes the form to automaticly submit as soon as a
user makes a selection. It is recommended that you also create a standard
form submit button in case a user does not have javascript enabled.

Example 1 will redirect to http://example.com
Example 2 will redirect to http://www.example.com
Example 3 will redirect to http://www.example.com
Example 4 will redirect to https://www.example.com
Example 5 will redirect to ftp://example.com
Example 6 will redirect to ftp://ftp.example.com
Example 7 will redirect to http://ftp.example.com


NOTES
This script requires PHP 4.1.0 or greater. It uses the new input mechanism,
specificly the PHP Superglobal $_POST. It should be trivial to modify the
script to make it compatible with older versions of PHP. While I do not know
of any security risk with this script in particular, I have chosen not to
make it backwards compatible. It is my belief that the new input mechanism
is a significant security improvement in PHP - all PHP installations
should upgrade to the most recent versions to take advantage of this, and
all scripts should now be written using this input mechanism.
mattbrown@lamphost.net
