Professional Links v1.1

README
_______


1. Files Included

admin.php - upload, chmod 755
index.php - edit, upload, chmod 755
links.txt - upload, chmod 777
bilinmeyen.html - edit (if you like), upload

2. Set Up

Edit index.php to set your keyword input as you'd like in your form.
Upload all files, and run admin.php to add keywords. Create a form
in your HTML document with a text box called 'go' (or whatever), or create a link
like 'www.yourdomain.com/plinks/index.php?go=yourlink' in your doc.
Admin can also be used to update urls, and keywords later.
No password protection is set up yet, feel free to add it or chmod
admin.php '770' when not being used.

Thanx..!

---------------------------------------------
<Professional Links v1.1>
<By Og�n MER��L�G�L from TURKEY/ISTANBUL>
<ogun@photoshoptools.com>
<http://www.photoshoptools.com/plinks
---------------------------------------------