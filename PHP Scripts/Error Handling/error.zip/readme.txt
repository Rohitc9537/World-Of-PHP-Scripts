Just modify .htaccess and upload all files to u're
root directory (/home/user/public_html/).

if u have problems installing contact me:
mail -  contact@xsteam.org
ym   -  blueyez_09


