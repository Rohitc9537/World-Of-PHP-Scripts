        <h2>Configuration &amp; Options</h2>
        
        <form method='post' action='<?php echo $structure['installURL']; ?>operations/options.php'>
          
          <input type='hidden' name='referrer' value='<?php echo $structure['full']; ?>' />
          <fieldset>
          <legend>General Options</legend>
          
          <?php if ($errors['techEmail'] == true) {  ?>
          
          <p class='warning'>The supplied e-mail address isn't valid.</p>
          <?php } ?>
          
          <p>Please enter the e-mail address of the person responsible for 
          fixing errors:<br />
          <input type='text' id='techEmail' name='techEmail' <?php if ($generalOptions['techEmail']) { echo " value='".$generalOptions['techEmail']."'"; }?> /></p>
          
          <?php if ($errors['timeZoneDiff'] == true) { ?>
          
          <p class='warning'>The supplied timezone isn't possible. The values must be between +12 and -12</p>
          <?php } ?>
          
          <p>Please enter the timezone difference between you and the server:<br />
          <input type='text' id='timeZoneDiff' name='timeZoneDiff' <?php if ($generalOptions['timeZoneDiff']) { echo " value='".$generalOptions['timeZoneDiff']."'"; }?> />
          The current server time is : <?php echo date('g:i a F jS Y'); ?></p>
          
          </fieldset>
          
          <fieldset>
          
          <legend>Record Only the Following Status Codes</legend>
          
          <p>Deselecting these will <strong>not</strong> stop serving Error 
          Documents to requesting clients, they will see the <strong>exact same 
          thing</strong> that everyone else will be told, the only difference 
          is that these events won't be placed in the database.</p>
          
          <ul>
            
            <?php
            $statusCodeResult = mysql_query('SELECT * from status_codes');
            while ($row = mysql_fetch_array($statusCodeResult, MYSQL_ASSOC)) 
              {
                niceError($row['status_code']);
               ?>
             
               <li><input type='checkbox' name='<?php echo $row['status_code'];?>' <?php if ($row['record'] == 'on') { echo ' checked="checked"';} ?> /><label for='<?php echo $row['status_code'];?>'><a href='<?php echo $niceError['URL'].$niceError['link']; ?>'>&ldquo;<?php echo $niceError['title'] ?>&rdquo; events <acronym title='Hyper Text Transfer Protocol'>HTTP</acronym> Status Code <?php echo $row['status_code'];?></a></a></label></li>
             
               <?php
              }
            ?>
            
          </ul>
          
          </fieldset>
          
          <p><input type='submit' name='set' value='update' /></p>
          
        </form>
