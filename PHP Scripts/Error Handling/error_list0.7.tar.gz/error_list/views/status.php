<?php
//Copyright 2005 Ashley Graham amg@angryguerilla.com
//first because it can hang/kill apache
niceError($structure['status']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
  
		<title><?php echo $structure['host']; ?> &raquo; A Problem Has Arisen</title>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="An error has occurred. Please bear with us." />
    <meta name="copyright" content="Copyright (c) 2005 Ashley Graham." />
    
    <link rel='stylesheet' href='<?php echo $structure['installURL']; ?>css/status.css' type='text/css' />
	
  </head>
  
	<body>
    
    <div id="wrap">
      
    <?php
      if ( $_SERVER['HTTP_REFERER'] == $structure['installURL'])
        {
          ?>
      
      <h1>Event Not Recorded</h1>
      
      <p>Pages linked from the admin page are not recorded, to keep the database small.</p>
      
      <p>The requested resource is still, unfortunately broken.</p>
      
      <p><a href='<?php echo $structure['installURL']; ?>'>Go back</a> to the admin panel.</p>
      
      <?php
        }
      else
        {
          $count = tableCount('events');
          
          switch($count)
            {//this could be an option
              case '5':
              mailAdmin('5');
              break;
              case '25':
              mailAdmin('25');
              break;
              case '50':
              mailAdmin('50');
              break;
              case '75':
              mailAdmin('75');
              break;
              case '100':
              mailAdmin('100');
              break;
            }
          
          if ($recordOptions[$structure['status']] == 'on')
            {//they want it recorded
              $selectSql = "SELECT id FROM events WHERE 
                           `http_code` = '".$structure['status']."' AND 
                           `request` = '".$_SERVER['REQUEST_URI']."' AND 
                           `referrer` = '".$_SERVER['HTTP_REFERER']."' AND 
                           `agent` = '".$_SERVER['HTTP_USER_AGENT']."'";
              
              $selectResult = mysql_query($selectSql);
              
              if (!mysql_num_rows($selectResult)) 
                {//the above sql failed
                  $insertSql = "INSERT INTO events 
                  (http_code,request,referrer,date_time,agent) 
                  VALUES 
                  ('".$structure['status']."',
                   '".$_SERVER['REQUEST_URI']."',
                   '".$_SERVER['HTTP_REFERER']."',
                   NOW(),
                   '".$_SERVER['HTTP_USER_AGENT']."')";
                  $insertResult = mysql_query($insertSql);
                }
            }
            ?>
      
      <h1>A Problem Has Arisen</h1>
      
      <p>There was a minor technical problem when fulfilling your request. As it 
      stands, you're not going to be able to get where you wanted to go.</p>
      
      <p>The following structure leading up to the requested file is available, 
      and may help you find what you were looking for:</p>
      
      <p><code><?php echo createURL(); ?></code></p>
      
      <p>The server responded with this remark:</p>
      
      <blockquote><p>&ldquo;<?php echo $niceError['title'];?>&rdquo;</p></blockquote>
      
      <?php
        }
        ?>
      
    </div>
    
  </body>
  
</html>
