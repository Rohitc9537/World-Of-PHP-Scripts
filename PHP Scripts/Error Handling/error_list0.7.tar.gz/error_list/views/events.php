      <?php
      $count = tableCount('events');
      if ($count > 0) 
      {
        $group_result = mysql_query("SELECT http_code from `events` GROUP BY http_code");
      ?>
        
        <h2><?php
        if ($count == 1) 
          {
            echo "1";
          } 
        else 
          {
            echo $count;
          }
        ?> Pending Error Event<?php if ($count > 1) { echo 's'; } ?></h2>
        
        <form method='post' action='<?php echo $structure['full']; ?>operations/delete.php'>
          
          <input type='hidden' name='referrer' value='<?php echo $structure['full']; ?>' />
        <?php while ($table = mysql_fetch_array($group_result, MYSQL_NUM)) 
            {
              niceError($table['0']);
              ?>
          
          <table summary='These are events for status code <?php echo $table['0'];?> that have yet to fix.'>
          
          <caption><a href='<?php echo $niceError['URL'].$niceError['link']; ?>'>&ldquo;<?php echo $niceError['title'] ?>&rdquo; events <acronym title='Hyper Text Transfer Protocol'>HTTP</acronym> Status Code <?php echo $table['0'];?></a></caption>
              
              <tr>
                  
                  <th colspan='3'><span title='What did they want?'>Requested&nbsp;Page</span></th>
                  <th><span title='Who were they?'>User&nbsp;Agent</span></th>
                  <th><span title='When did it happen?'>Date</span></th>
                  <th><span title='Where did they come from?'>Referrer</span></th>
                  
              </tr>
              <?php $result_error = mysql_query("SELECT * FROM events WHERE `http_code` = '".$table['0']."'");
                    while ($row = mysql_fetch_assoc($result_error)) { ?>
              
              <tr<?php if ($color) { echo " class='alt'"; } ?>>
                  
                  <td><label for='id<?php echo $row['id']?>'><?php echo $row["request"]; ?></label></td>
                  <td class='smallCell'><a href='<?php echo $row['request']; ?>' title='Check the requested resource.' class='request_link'>&raquo;</a></td>
                  <td class='smallCell'><input type='checkbox' name='id<?php echo $row['id']?>' value='<?php echo $row['request']?>' id='id<?php echo $row['id']; ?>' /></td>
                  <td><span title='<?php echo $row['agent']; ?>'><?php echo cleanAgent($row["agent"]);?></span></td>
                  <td><?php echo cleanDate($row["date_time"]); ?></td>
                  <td><?php if ($row['referrer'] != '') { ?><a href='<?php echo $row['referrer']; ?>' title='<?php echo $row['referrer']; ?>'><?php echo cleanReffer($row['referrer']); ?><?php } ?></td>
                  
              </tr>
              
              <?php } ?>
              
            </table>
            
      <?php } ?>
          
          <p><input type='submit' name='set' id='set' value='delete' /></p>
          
        </form>
        <?php } else { ?>
        
        <h2>Congratulations!</h2>
        
        <p>There are currently no errors in the database. You've done a really good job.</p>
        <p>You get a cookie.</p>
        <p>I guess there's nothing to do now, save sit around waiting for errors to occur.</p>
        
        <?php
          //optimize the table
          $optimize_sql = "OPTIMIZE TABLE events";
          if (!mysql_query($optimize_sql)) { ?>
              
          <p>Despite the excellent job you have just done, taking care of your visitors and such, we we're unable to optimize your database.</p>
          <p><strong>This can lead to problems</strong>, if you don't take care of it manually.</p>
          
        <?php } } ?>

