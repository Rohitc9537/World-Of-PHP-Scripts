CREATE TABLE `events` (
  `id` int(6)NOT NULL auto_increment,
  `http_code` varchar(3) NOT NULL default '0',
  `request` tinytext NOT NULL,
  `referrer` varchar(255) NOT NULL default '',
  `agent` varchar(255) NOT NULL default '',
  `date_time` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

-- 
-- Dumping data for table `events`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `options`
-- 

CREATE TABLE `options` (
  `title` varchar(50)NOT NULL default '',
  `value` varchar(255)NOT NULL default ''
) ENGINE=MyISAM COMMENT='List of all available options, and their settings.';

-- 
-- Dumping data for table `options`
-- 

INSERT INTO `options` VALUES ('techEmail', '');
INSERT INTO `options` VALUES ('timeZoneDiff', '');
INSERT INTO `options` VALUES ('password', md5('password'));

-- --------------------------------------------------------

-- 
-- Table structure for table `status_codes`
-- 

CREATE TABLE `status_codes` (
  `status_code` varchar(3) NOT NULL default '',
  `title` varchar(75) NOT NULL default '',
  `description` text NOT NULL,
  `link` varchar(3) NOT NULL default '',
  `record` varchar(3) NOT NULL default '',
  PRIMARY KEY  (`status_code`)
) ENGINE=MyISAM COMMENT='List of all HTTP status codes.';

-- 
-- Dumping data for table `status_codes`
-- 

INSERT INTO `status_codes` VALUES ('401', 'Unauthorized', '', '2', 'on');
INSERT INTO `status_codes` VALUES ('403', 'Forbidden', '', '4', 'on');
INSERT INTO `status_codes` VALUES ('404', 'Not Found', '', '5', 'on');
INSERT INTO `status_codes` VALUES ('405', 'Method Not Allowed', '', '6', 'on');
INSERT INTO `status_codes` VALUES ('406', 'Not Acceptable', '', '7', 'on');
INSERT INTO `status_codes` VALUES ('407', 'Proxy Authorization Required', '', '8', 'on');
INSERT INTO `status_codes` VALUES ('408', 'Request Timeout', '', '9', 'on');
INSERT INTO `status_codes` VALUES ('409', 'Conflict', '', '10', 'on');
INSERT INTO `status_codes` VALUES ('410', 'Gone', '', '11', 'on');
INSERT INTO `status_codes` VALUES ('411', 'Length Required', '', '12', 'on');
INSERT INTO `status_codes` VALUES ('412', 'Precondition Failed', '', '13', 'on');
INSERT INTO `status_codes` VALUES ('413', 'Request Entity Too Large', '', '14', 'on');
INSERT INTO `status_codes` VALUES ('414', 'Request-URI Too Long', '', '15', 'on');
INSERT INTO `status_codes` VALUES ('415', 'Unsupported Media Type', '', '16', 'on');
INSERT INTO `status_codes` VALUES ('416', 'Requested Range Not Satisfiable', '', '17', 'on');
INSERT INTO `status_codes` VALUES ('417', 'Expectation Failed', '', '18', 'on');
        
