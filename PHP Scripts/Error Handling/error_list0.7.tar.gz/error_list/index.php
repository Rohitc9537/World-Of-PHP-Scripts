<?php
if ($_SERVER['HTTP_USER_AGENT'] == ini_get('user_agent')) 
  {
    die('Error: Infinite loop detected.');
  }
require('./config.php');
require('./functions.php');
databaseConnect();
/*Setup some URL and file structure*/
if ($_REQUEST['status'])
  {//if status is set, assign it to something useful
    $structure['status'] = $_REQUEST['status'];
  }

if ($_REQUEST['page']) 
  {//the page, where they are in the admin panel
    $structure['page'] = $_REQUEST['page'];
  } 
else if ($_REQUEST['status'])
  {
    $structure['status'] = $_REQUEST['status'];
  }
else if (!$_REQUEST['page'])
  {
    $structure['page'] = 'events';
  }

/*Setup some file and URL structure*/
$url = parse_url($_SERVER['REQUEST_URI']);

//now we begin to setup the file and web
//structure
$structure['host'] = $_SERVER['HTTP_HOST'];
$structure['path'] = $url['path'];
$structure['full'] = 'http://'.$structure['host'].$structure['path'];
$structure['installURL'] = 'http://'.$structure['host'].dirname($_SERVER['PHP_SELF']).'/';
$structure['installPath'] = removeLastItem($_SERVER['SCRIPT_FILENAME'], '/', '/').'/';

switch ($structure['page'])
  {
    case 'events':
     $structure['description'] = 'These are the recent error pages at your site.';
     break;
     
    case 'options':
     $structure['description'] = 'Here you can change the way Error List works for you.';
     break;
     
    case '':
     $structure['description'] = 'An error has occurred. Please bear with us.';
     break;
  }

$structure['pageTitle'] = "Error List &raquo; ".ucfirst($structure['page']);

/*Setup the admin's options*/
$sql = mysql_query('SELECT * from options');
while ($row = mysql_fetch_array($sql, MYSQL_ASSOC)) 
  {
    $generalOptions[$row['title']] = $row['value'];
  }
  
if ($structure['page'] == 'options' OR $structure['status']) 
  {
    recordOptions();
  }
if ($structure['page']) 
  {
    $result = mysql_query('SELECT value FROM options where `title` = "password"');
    $p = mysql_result($result, 0);
    session_start();
    if (!session_is_registered('admin') OR $structure['page'] == 'logout') 
      {
        require('./html/login.php');
        exit;
      }
    require('./html/header.php');
    require('./views/'.$structure['page'].'.php');
    require('./html/footer.php');
  } 
else if ($structure['status']) 
  {
    require('./views/status.php');
  }

?>
