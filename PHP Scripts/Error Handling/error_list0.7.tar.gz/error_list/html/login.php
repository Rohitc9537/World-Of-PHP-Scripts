<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
  <head>
    
    <title><?php echo $structure['pageTitle'];?></title>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="<?php echo $structure['description']; ?>" />
    <meta name="copyright" content="Copyright (c) 2005 Ashley Graham." />
    
    <meta name='robots' content='noindex,nofollow' /><!--I try to stop evil robots from generating errors.-->
    
    <style>
    <!--
    *{font-family:serif;}
    body{margin: 6em auto; text-align: center;width: 550px;}
    input{color: #4d4d4d; width: 8em;font-size: 2em;border: 1px solid #efefef;padding: 0.2em 0.2em;}
    //-->
    </style>
    
  </head>
  
  <body>
    
    <form method='post' action='<?php echo $structure['full']; ?>operations/login.php'>
    
    <input type='hidden' name='referrer' value='<?php echo $structure['full']; ?>' />
    
    <p><input type='text' name='password' value='password' /><input type='submit' name='set' value='login' /></p>
    
    </form>
    
  </body>
    
</html>
<!--This has been Error Manager -->
