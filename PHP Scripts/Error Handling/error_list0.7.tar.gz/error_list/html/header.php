<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
  <head>
    
    <title><?php echo $structure['pageTitle'];?></title>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="<?php echo $structure['description']; ?>" />
    <meta name="copyright" content="Copyright (c) 2005 Ashley Graham." />
    
    <meta name='robots' content='noindex,nofollow' /><!--I try to stop evil robots from generating errors.-->
    
    <link rel='stylesheet' href='<?php echo $structure['installURL']; ?>css/admin.css' type='text/css' />
    
  </head>
  
  <body>
    
    <div id='wrap'>
      
      <div id="masthead">
      
        <h1>Error List</h1>
        
        <ul>
          <li><a href='<?php echo $structure['installURL'];?>'>Events</a></li>
          <li><a href='<?php echo $structure['installURL'];?>options/'>Options</a></li>
        </ul>
        
      </div>
      
      <div id='content'>
