      </div>
      
      <div id='footer'>
        
        <p>&copy 2005 <a href="http://smarterfish.com/" title="Error Manager Homepage">Smarter Fish</a>. <a href='http://www.gnu.org/licenses/gpl.html'>License</a>.</p>
        
      </div>
      
    </div>
    
  </body>
    
</html>
<!--This has been Error Manager -->
