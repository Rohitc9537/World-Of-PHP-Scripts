<?php
if ($_POST['set'] == 'update') 
  {
    require('../config.php');
    require('../functions.php');
    databaseConnect();
    recordOptions();
    foreach ($_POST as $key=>$value)
      {
        $_POST[$key] = strip_tags(trim($value));
        if ($value == 'on')
          {
            $recordPost[$key] = $value;
          }
      }
    foreach ($recordOptions as $key=>$values)
      {
        if ($recordOptions[$key] != $recordPost[$key])
          {
            if ($recordPost[$key] == 'on')
              {
                $t = 'on';
              }
            $sql = "UPDATE status_codes SET record = '$t' where status_code = '$key'";
            mysql_query($sql);
          }
      }
    $errors = array();
    $techEmail = $_POST['techEmail'];
    $timeZoneDiff = $_POST['timeZoneDiff'];
    if(ereg("^.+@.+\..+$", $techEmail) OR $techEmail == '') 
      {
        $sql = "UPDATE options SET value = '$techEmail' where title = 'techEmail'";
        mysql_query($sql);
      }
    else
      {
        $errors['techEmail'] = true;
      }
    if ($timeZoneDiff) 
      {
        if ($timeZoneDiff > 12 OR $timeZoneDiff < -12)
          {
            $errors['timeZoneDiff'] = true;
          }
        else if((ereg("([+|-]{1})([0-9]{1,2})", $timeZoneDiff)) OR ($timeZoneDiff == '0')) 
          {
            $sql = "UPDATE options SET value = '$timeZoneDiff' where title = 'timeZoneDiff'";
            mysql_query($sql);
          }
        else
          {
            $errors['timeZoneDiff'] = true;
          }
      }
    header('Location:'.$_POST['referrer']);
  }
?>
