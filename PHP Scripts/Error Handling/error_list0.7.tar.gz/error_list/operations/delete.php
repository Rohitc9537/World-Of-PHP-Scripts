<?php
if($_POST['set'] == 'delete') {
  require('../config.php');
  require('../functions.php');
  databaseConnect();
  foreach ($_POST as $keys=>$values)
    {//foreach $_POST item
      if (strstr($keys, 'id'))
        {//if the key contains the word id, put into the array
          $id[] .= $values;
        }
      else
        {//otherwise go to the next one
          continue;
        }
    }
  $numbers = makeList($id, true);
  $sql = 'select `id` from `events` where `request` in('.$numbers.')';
  $result = mysql_query($sql);
  while ($row = mysql_fetch_array($result, MYSQL_NUM)) 
    {
      $list[] .= $row[0];
    }
  
  $number = makeList($list);
  $sql = "delete from events where `id` in ($number)";
  if (mysql_query($sql)) 
    {
      $success = true;
    } 
  header('Location:'.$_POST['referrer']);
  }
?>
