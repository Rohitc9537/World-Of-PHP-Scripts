<?php
if ($_POST['set'] == 'login')
  {
    require('../config.php');
    require('../functions.php');
    databaseConnect();
    $password = $_POST['password'];
    
    $result = mysql_query('SELECT value FROM options where `title` = "password"');
    if (!$result) 
      {
         die('Could not query:' . mysql_error());
      }
    if (mysql_result($result, 0) == md5($password)) 
      {
        session_start();
        session_register("admin");
        header('Location:'.$_POST['referrer']);
      }
    else 
      {
        header('Location:'.$_POST['referrer']);
      }
    
  }
?>
