<?php
/*
These are general setup functions, used the most.
*/

function databaseConnect()
{
  global $em_db;
  $database  = "Could not access the database, please make sure that it exists, and that the appropriate values have been added to the configuration file included in this package.";
  if (@mysql_pconnect($em_db['server'],$em_db['username'],$em_db['password'])) 
    {
      //we can connect...
      if (@!mysql_select_db($em_db['database'])) 
        {
          //...but we couldn't select 
          die($database);
        } 
    }	
  else 
    {
      //we couldn't connect
      die($database);
    }
}

function niceError($code)
{
  global $niceError;
  $niceError['URL'] = 'http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.';
  $sql = "select * from status_codes where status_code = ".$code;
  $status_code = mysql_query($sql);
  $status_code = mysql_fetch_array($status_code, MYSQL_ASSOC);
  $niceError['code'] = $status_code['status_code'];
  $niceError['title'] = $status_code['title'];
  $niceError['link'] = $status_code['link'];
  $niceError['description'] = $status_code['description'];
  return $niceError;
}

/*
These are used solely by status.php
*/

function mailAdmin($number)
{
  global $structure, $generalOptions;
  if (!$generalOptions['emailTech'])
    {//if an email isnt specified, quit.
      return;
    }
  
  $subject = $number.' Pending Error Events at http://'.$structure['host'].'/';
  $message = 'This is an automated e-mail, do not respond.'."\r\n".
             'You have received this message from your installation of Error Manager.'."\r\n\r\n".
             'There are '.$number.' Error Events that you should attend to.'."\r\n".
             'Please do so now: '.$structure['installURL']."\r\n";
  
  mail($generalOptions['emailTech'], $subject, $message);
}

function createURL() 
{
  global $structure;
  $link = 'http://'.$structure['host'].'/';
	$request = $_SERVER['REQUEST_URI'];
	$request = explode('/', $request);
	echo "http://&nbsp;<a href='/'>".$structure['host']."</a>&nbsp;/";
  foreach ($request as $n => $dirs) 
    {
      if (current($request) == $dirs['0']) 
        {//if the current $dirs is the first one, skip it
          continue;
        }
      //structure has $dirs added to it's end
      $link .= $dirs.'/';
      if (@fopen($link, 'r')) 
        {
          $file_exists = true;
        } 
      else 
        {
          $file_exists = false;
        }
      if (!strstr($dirs, '.') || !$dirs == end($request)) 
        {//if it's not the last one, continue down the line.
          if ($file_exists) 
            {
              echo "&nbsp;<a href='/";
            }
          foreach ($request as $i => $links) 
          {
            if (current($request) == $links['0']) 
              {//if the current $links is the first one, skip it
                continue;
              }
            if ($file_exists) 
              {
                echo $links.'/';
              }
            if ($i === $n) 
              {//if $i (which is a child of $n) is $n, stop
                break;
              }
          }
          if ($file_exists) 
            {
              echo "'>".$dirs."</a>&nbsp;/";
            } 
          else if (!$file_exists) 
            {
              echo '&nbsp;'.$dirs.'&nbsp;/';
            }
        } 
      else 
        {//if it's the last one OR it contains a period/dot close-up
          if ($file_exists) 
            {//echo the entire requested uri, but only the last directory
              echo "&nbsp;<a href='".$_SERVER['REQUEST_URI']."'>".$dirs."</a>&nbsp;";
            } 
          else if (!$file_exists) 
            {//only echo the directory
              echo "&nbsp;".$dirs."&nbsp;";
            }
        }
    }
}
/*
These are simple modification and helper functions
*/

function tableCount($var) 
{
  $count =  mysql_result(mysql_query("SELECT COUNT(id) FROM " . $var),0);
  return $count;
}

//a nice clean agent listing.
//it expects a string, and returns one
//based on some simple needle-in-a-haystack finding
//it tries to guess what user agent the event-creator was using.
function cleanAgent($val)
{
  if (strstr($val, "bot") || 
      strstr($val, "slurp") ||
      strstr($val, "Crawl") || 
      strstr($val, "spider") ||
      strstr($val, "Syndic8") || 
      strstr($val, "BecomeBot")) 
    {
        echo "Crawler/Search&nbsp;Engine";
    }
  else if (strstr($val, "iRider") || 
           strstr($val, "Gecko") ||
           strstr($val, "Safari") || 
           strstr($val, "iCab") ||
           strstr($val, "Camino") || 
           strstr($val, "Chimera") ||
           strstr($val, "Firefox") || 
           strstr($val, "Firebird") ||
           strstr($val, "Phoenix") || 
           strstr($val, "Gecko") ||
           strstr($val, "Netscape") || 
           strstr($val, "Opera") ||
           strstr($val, "Omniweb") || 
           strstr($val, "Konqueror") ||
           strstr($val, "Links") || 
           strstr($val, "Lynx")) 
    {
      echo "Browser";
    }
  else if ($val = '') 
    {
      echo "Empty";
    }
  else
    {
      echo "Unknown";
    }
}

function cleanReffer($var) 
{
  //this echos only the host of a given domain
  $domain = explode('/', $var);
  echo $domain[2];
}

function removeLastItem($string, $split, $join)
{
  //this gets a string, turns it into an array, removes the last item, and rejoins the string
  $var = explode($split, $string);
  array_pop($var);
  $var = implode($join, $var);
  return $var;
}

function cleanDate($val)
{
  global $generalOptions;
  $split = explode(" ", $val);
  $year = $split['0'];
  $time = $split['1'];
  
  $year = explode('-', $year);
  $time = explode(':', $time);
  $time['0'] = $time['0'] + $generalOptions['timeZoneDiff'];
  
  //the full time stamp
  $time_stamp = date("F jS", mktime('', '', '', $year['1'], $year['2'], $year['0']));
  $time_stamp_clean = date("F jS g:i a", mktime($time['0'], $time['1'], $time['2'], $year['1'], $year['2'], $year['0']));
  //the numerical day
  $day = date("j", mktime($time['0'], $time['1'], $time['2'], $year['1'], $year['2'], $year['0']));
  
  //the name of the day
  $day_name = date("l", mktime($time['0'], $time['1'], $time['2'], $year['1'], $year['2'], $year['0']));
  
  //todays numerical day
  $week = date("j");
  
  $foo = $week - 7;
  echo "<span class='inline_help' title='";
  echo $time_stamp_clean;
  echo "'>";
  if ($day == $week)
    {
      echo "Today";
    }
  else if ($day == $week - 1) 
    {
      echo "Yesterday";
    } 
  else if ($day > $foo) 
    {
      echo $day_name;
    } 
  else 
    {
      echo "<span class='important'>".$time_stamp."</span>";
    }
  echo "</span>";
}

function recordOptions()
{
  global $recordOptions;
  $sql = mysql_query("SELECT status_code,record from status_codes");
  while ($row = mysql_fetch_array($sql, MYSQL_ASSOC)) 
    {
      $recordOptions[$row['status_code']] = $row['record'];
    }
  return $recordOptions;
}

function makeList($array, $p = false)
{
  //global $numbers;
  foreach ($array as $keys => $values) 
    {
      if ($p == true) 
        {
          //if 'p' is on output parenthesis
          $var .= '"'.$values.'",';
        } 
      else 
        {
          $var .= $values.",";
        }
    }
  //remove the last comma
  $var = substr($var, 0, -1);
  return $var;
}

?>
