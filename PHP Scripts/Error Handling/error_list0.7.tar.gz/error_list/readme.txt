Error List 0.7

Welcome to Error List v0.7
Copyright 2005 Ashley Mervyn Graham

License:
------

Copyright 2005 Ashley Graham amg@angryguerilla.com

This file is part of Error List.

Error List is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

Error List is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Error List; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Installation:
---------

These instructions assume that you have installed Error List into
a subdirectory off of your root folder name "/error_list/". So, to access Error List, 
you visit this page: http://dimain.com/error_list/

You must edit the sql.sql file and change the value of 'password' to whatever you 
want it to be. It stands right now (line 32):

INSERT INTO `options` VALUES ('password', md5('password'));

Change the second 'password' to what you want your password to be. If you want your 
password to be 'marvin', you would change the line to read:

INSERT INTO `options` VALUES ('password', md5('marvin'));

Create a database, with a user that is allowed to access it (the database). 
Import the file "sql.sql" into the newly created database. You can either use the 
command-line client or something like phpmyadmin.

Make changes to "config.php", to match your database. These are the only 
preconfigurations you must perform.

Upload everything to your server.

Make the following changes to your the main .htaccess file in your server:

ErrorDocument 401 /error_list/index.php?status=401
ErrorDocument 403 /error_list/index.php?status=403
ErrorDocument 404 /error_list/index.php?status=404
ErrorDocument 405 /error_list/index.php?status=405
ErrorDocument 406 /error_list/index.php?status=406
ErrorDocument 407 /error_list/index.php?status=407
ErrorDocument 408 /error_list/index.php?status=408
ErrorDocument 409 /error_list/index.php?status=409
ErrorDocument 410 /error_list/index.php?status=410
ErrorDocument 411 /error_list/index.php?status=411
ErrorDocument 412 /error_list/index.php?status=412
ErrorDocument 413 /error_list/index.php?status=413
ErrorDocument 414 /error_list/index.php?status=414
ErrorDocument 415 /error_list/index.php?status=415
ErrorDocument 416 /error_list/index.php?status=416
ErrorDocument 417 /error_list/index.php?status=417

If the script is different from a different URL, change the above, accordingly.

Everything *should* work.

Technical Support:
----

You should be all done, if something went wrong, e-mail me and I'll
try to help: amg@angryguerilla.com

I can't guarantee that you will get actual help, but I'll likely respond to 
everything you send my way.

Requirements:
-----

Your php.ini file must set "allow_url_fopen = On".

Features:
-----

It will e-mail the designated technician when it determines there are "too many"
events within the database, as long as you supply an e-mail address. If you don't
supply one, it won't e-mail them.

The script stops recording if there are 100 events, pages are still served, but 
the database doesn't get touched. This is because (1) I'm lazy, and don't feel like
coding some paging feature, and (2) I think you should pay attention to errors:
the smaller the number, the more likely you are to deal with them.

You can turn off recording errors at your whim.


Bugs/Errors:
------

In the somewhat rare event that a requested page is marked in two status
codes, the application will delete it for both status codes. This is due to the 
fact that delete statements are called by their request column; this is due to 
of bulk-delete.

The function createURL() adds a folder-slash at the end in certain 
circumstances when it shouldn't, I can't figure out why.

Really bad server errors, usually involving a bad .htaccess page won't be recorded. 
This is Apache, not me. There's no way around them, yet.

The error page can hang if there is a problem with your php.ini file. As it stands
the feature to build URL's relies upon fopen to test the requested directores, 
the script dies if the requesting agent matches the ini setting for http_user_agent.

Goals:
------

Editing and maintenance of .htaccess files.

Feeds that people can subscribe to.

Major improvements on the error page.

Make the summary page offer more ways of viewing the events that have happened, 
and have it actually offer you reports. This would require keeping the error 
events around "forever".

Add reporting of coding events. Display the related error page to the user. If 
the application can't find the specified data/resource issue 404 code, if 
something is broken, issue a 500, et cetera.

Add a way of adding some sort of system status, where the operator can set aside 
a period of time when the system might incur some extra hiccups, and why it 
happenned; system upgrade, mysql downtime, etc.

Change Log:
------
Version 0.7
`````````
Got the error-checking finally working, it gets the environment variable for PHP's
user-agent (when requesting files) and compares it to the current one. if they 
match, the page dies to stop an infinite loop from occurring.

There was yet another problem with .htaccess files, now fixed, apparently.

Altered the way we die(), if certain parameters aren't met.

Re-introduced setting options within the interface, trying to clean the clutter
of files throughout the system.

Removed all status_code error files, in liking of one cleaner file. Planned to be 
expanded on by a later release.

More renaming of functions as well as remaking the structure to all be the same.

Changed the way we handle requests, they are all sent through index.php and 
include files as necessary.

Removed the install script. Now using a simple sql dump file. Also removed the 
install file checking function.

Revamped the available options, most are guessed (correctly), those that can't be,
are included on the options page.

Began work on rewriterule creation maintenance.

Version 0.6b
`````````
Mainly a clean-up of the previous version.

Added the suggestion of robots.txt to block spiders from going into the directory.
This can help with spiders/bots generating hits on pre-existing events.

Changed $dirs and $link to mirror the original array $request. Some kind of error 
was being generated.

Added an option to not record 412 errors, much like the 410 option.

Changed the way we delete items, and the information presented to the deletion 
process. Instead of deleting by "request", we now expect request information to be 
present, in the beginning of the deletion process, and then select the id's that 
match up against the request, and then delete with those id's.

Added a link to help documents (at the bottom of the page).

Changed the way we display dates, instead of a flat reference, we now utilize a 
day-name sorting.

Changed some error pages, and the way we handle them internally.

Removed recording of errors if they were generated/called from the admin panel

Version 0.6a
`````````
Removed a lot of features, mainly sticking with viewing errors for now.

Removed a lot of functions, mainly those not being used by the file writing, and 
the old way of deleting items.

Changed the table into a function. Now smaller, leaner. Still needs to be 
reworked.

Added automatic "bulk delete".

Added the concept of "cookies". You get one if your database is empty.

Added a nagging feature, it e-mail's you at certain intervals to remind you
to deal with errors.

Removed recording of errors after a certain number, just in case something goes 
really wrong.

Cleaned up the the error code pages.

Added default recording of 412 (precondition failed) errors. Still a little hazy 
on what that all means. Some use it for security, some use it for specific 
results on requests, some use it for spam blocking.

Cleaned up the function $em_create_link(). Now much nicer.

Removed the help, and reference section. Moved to smarterfish.com

Added the 'status' column for error events

Removed the login feature, see below as to why.

Removed the creating of rewrite rules: security hazard. It might return in
another light someday.

Added command-line URLs. /error_manager/view/404/ will let you view only those 
errors with a 404 status code. You can sort through this too.

Changed the way dates are handled, now utilizing a timestap. It's one single 
column, instead of two. Related:

Added the variable to deal with timezone. Don't know why it didn't bother me 
more before.

Removed the single table layout, opting for multiple tables, each a 
different view.


Version 0.5
`````````
Skipped a number; due to removal of content. The 0.5 release wasn't really 
anything spectacular anyway.


Version 0.4
`````````
Once again, redid the interface of the administration panel.

Got rid of one table, instead using one: events.

Renamed a lot of functions.

Remade the kind of type the row "id" is from tinyint to int.


Version 0.3.1
`````````
Removed a lot of unneeded features within the script. Mainly 
simplification.

Added the "reference" and "help" section, they are remote documents
(kept on my server) so they can be constantly updated without
re-releasing the software.

Also a bug fix; somewhere...


Version 0.3
`````````
Cleaned up the interface.

The file "error.php" now builds the file dynamically, as well as
inputting the data.

Allowed myself to add features easily.

Made some other minor changes.

Simplified the database, because the first one was a mess.


Version 0.2:
`````````
Added an installation script.

Made it use a database, instead of simple email.

Added the operation to inform you of the current redirects.

Licensed it under the GPL.

Removed most settings from within the program, instead using variables
to allow the program to work anywhere.

Condensed all operations into config.php


Version 0.1:
`````````
It worked, and it was ugly.

