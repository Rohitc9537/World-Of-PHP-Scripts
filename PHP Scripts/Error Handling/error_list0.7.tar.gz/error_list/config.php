<?php
/****
Mysql Information
This is required information. You must fill in the correct values for this script to work properly.
****/

$em_db['server']	= "localhost";// leave as localhost unless you know otherwise
$em_db['username'] = "user";// The username used to access your database
$em_db['password'] = "pass"; // The corresponding password.
$em_db['database']	= "database"; // The database where you would like to store the stats table

?>
