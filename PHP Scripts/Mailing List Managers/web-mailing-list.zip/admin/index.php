<?php
include("connect.php");
?>
<html>
<head><title>Admin Panel</title></head>
<body>
<a href="addnews.php">Add News</a><br />
<a href="show.php">Show News</a><br />
<a href="viewusers.php">View Users</a><br />
</body>
</html>