<?php
session_start();
if ($_SESSION['admin'] != 'yes')
die("Only admins can view this page.");
mysql_connect("localhost","username","password") or die(mysql_error());
mysql_select_db("newsletterdb");
?>