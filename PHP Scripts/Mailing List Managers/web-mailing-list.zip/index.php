<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Public Page</title>
</head>
<body>
<a href="register.php">Sign Up</a><br />
<a href="unsubscribe.php">Remove Email From List</a>
</body>
</html>