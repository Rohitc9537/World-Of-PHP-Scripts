<html>
<head>
<title>New products</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel=stylesheet href=http://www.hotwebtools.com/css/index.css>
</head>

<body>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><a href=http://www.hotwebtools.com><img src=http://www.hotwebtools.com/images/header.gif alt=logo border=0></a></td>
  </tr>
</table>

<table width="100%"  border="0" cellspacing="0" cellpadding="3" class="content">
  <tr valign="top"> 
    <td width="16%" bgcolor="#eeeeee"> <table width="100%"  border="0" cellspacing="0" cellpadding="3">
        <tr> 
          <td bgcolor="#333333"><b><font color="#FFFFFF">Menu</font></b></td>
        </tr>
        <tr> 
          <td bgcolor="#eeeeee"><a href="a">Backlink Checker</a></td>
        </tr>
        <tr> 
          <td bgcolor="#eeeeee"><a href="a">SEO Tools</a></td>
        </tr>
        <tr> 
          <td bgcolor="#eeeeee"><a href="a">Drawing Canvas</a></td>
        </tr>
        <tr> 
          <td bgcolor="#eeeeee"><a href="a">Image Editor</a></td>
        </tr>
        <tr> 
          <td bgcolor="#eeeeee"><a href="a">Login</a></td>
        </tr>
      </table></td>
    <td width="84%"><b>New Product</b> <hr size="1">
      This is a newsletter send to you as a notification that our website 'hotwebtools.com' 
      had recently build a new opensource program. It is a mailing system where 
      people are allowed to manage their own mailing list easily. 
      <p>This system sends out HTML email to anyone who had subscribe to your 
        newsletter mailing list. In order to appear more professional and eye 
        catching, this system enables you to draw your own template which suits 
        the color and style of your website.</p>
      <p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
