<?php
$host ='localhost';
$username = '';
$pass = '';
$db = '';
$homePageUrl = ''; /// enter your site name
$installationUrl = ''; /// full path to installation. Dont add tralling slash at the end
?>