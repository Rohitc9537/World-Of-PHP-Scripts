<?php
$conn = mysql_connect($host, $username, $pass);
mysql_select_db($db);
?>