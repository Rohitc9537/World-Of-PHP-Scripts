<?PHP

//---------------------------------------------------------
// EVENTIVE
// Version v0.1
//
// Written by Andrew Whitehead
// (c) Andrew Whitehead 2004
//
// THIS TAG MUST NOT BE REMOVED
//---------------------------------------------------------

//Change the below variables to your liking

$dbhost = "localhost";                                       	//Usually localhost
$dbname = "eventive";                                        	//Name of the database
$dbuser = "user";                                     		//Name of the database user
$dbpass = "pass";                                          	//Password of the user

$defaultformat = "0";                                        	//The default layout for the countdown

?>
