Tizag PHP Dynamic Image Countdown
----------------------------------------------

Do not reproduce this counter without written consent from tizag.com

Important!
----------------------------------------------
You must have both the GD and Freetype PHP libraries installed for this 
counter to work.

Installation
----------------------------------------------
Unzip "tizag-countdown_Version_2.zip" to the desired location on your webserver.  
One of the folders that will be unzipped is the directory "pics".  This
directory  will need to have its permissions modified.  

Perform a CHMOD "777" the pics directory.  You can perform CHMOD with the FTP 
program you use to upload your files with.  The pics directory also contains a 
file named "data.dat" that stores all the settings for your counter.

Making Your First Countdown
----------------------------------------------
Using your web browser, navigate it to the location of "index.php" that you just
unzipped.  Complete the countdown generation form to create either a graphical or 
a plain text countdown.

The ONLY Acceptable Image File Formats: .jpg, .jpeg, .gif, .png!

The maximum allowed file size is 1,000 KB.

Placing the Countdown on Your Web Page
----------------------------------------------
Either click the link "View Current Countdown & HTML Code" or load htmlcode.php
to view the required HTML code to place your countdown.  Copy the
code in its entirety to any web page to view your new countdown!

Thank you and we hope you enjoy Tizag's PHP Countdown

Contact tools@tizag.com for Support if you followed the above directions and the
countdown still does not work.  Take care.