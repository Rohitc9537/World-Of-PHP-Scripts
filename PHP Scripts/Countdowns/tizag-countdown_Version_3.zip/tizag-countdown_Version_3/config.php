<?php

mysql_connect("localhost", "erack_sandbox", "prince") or die(mysql_error());
mysql_select_db("erack_sandbox") or die(mysql_error());
$table = "countdown";

?>