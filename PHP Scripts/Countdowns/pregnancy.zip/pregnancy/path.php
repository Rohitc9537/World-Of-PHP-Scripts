To include The Pregnancy Script on any PHP enabled page, use this code:<br><br>
<?
echo "&#60;? include(\"".dirname(__FILE__)."/pregnancy.php\")&#59; ?>";
?>
