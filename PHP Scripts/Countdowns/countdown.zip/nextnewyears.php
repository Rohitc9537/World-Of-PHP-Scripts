<?
echo "&toyear=".(date("Y")+1);
echo "&event_name=Newyears ".(date("Y")+1);
echo "&tosec=0";
echo "&tomin=0";
echo "&tohour=0";
echo "&today=1";
echo "&tomonth=1";
echo "&vloaded=1";
?>