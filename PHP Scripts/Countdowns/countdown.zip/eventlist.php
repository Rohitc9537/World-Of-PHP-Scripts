<?
/*
MVW Counter
===========

By Gary Kertopermono

This credit tag may not be removed.
*/

$dummy = true;

$eventname = Array();
$eventdesc = Array();

$eventname[] = "adventchildren";
$eventdesc[] = "Advent Children DVD release (US)";

$eventname[] = "adventchildrenjp";
$eventdesc[] = "Advent Children DVD release (JP)";
?>