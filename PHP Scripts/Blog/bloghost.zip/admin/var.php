<?php
$youremail="webmaster@chipmunk-scripts.com";
$path="http://www.ferretfusion.com";
?>