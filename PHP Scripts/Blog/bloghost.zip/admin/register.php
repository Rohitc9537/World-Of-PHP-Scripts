<link rel="stylesheet" href="style.css" type="text/css">
<center>
<table class='maintable'>
<tr class='headline'><td><center>Register Admin</center></td></tr>
<tr class='mainrow'><td>
<form action='reguser.php' method='post'>
Admin name:<br>
<input type='text' name='username' size='20'><br>
Password:<br>
<input type='password' name='password' size='20'><br>
Re-type Password:<br>
<input type='password' name='pass2' size='20'><br>
<input type='submit' name='submit' value='submit'>
</form>
</center>