<?php
session_start();
?>
<link rel="stylesheet" href="style.css" type="text/css">
<center><table border='0' width=100%><tr><td valign='top' width=30%>
<?PHP
include "connect.php";
$blogadmin=$_SESSION['blogadmin'];
$getadmin="SELECT * from bl_admin where username='$blogadmin'";
$getadmin2=mysql_query($getadmin) or die("Cannot get admin");
$getadmin3=mysql_fetch_array($getadmin2);
if($getadmin3['status']==3)
{
   include "left.php";
   print "</td>";
   print "<td valign='top' width=70%>";
   print "<table class='maintable'><tr class='headline'><td><center>Main Admin</center></td></tr>";
   print "<tr class='mainrow'><td>";
   $getbannedips="SELECT * from bl_banip"; 
   $getbannedips2=mysql_query($getbannedips) or die("Could not get banned ips");
   print "<table class='maintable'><tr class='headline'><td colspan='2'><center>Bannips</center></td></tr>";
   while($getbannedips3=mysql_fetch_array($getbannedips2))
   {
     print "<tr class='mainrow'><td>$getbannedips3[banip]</td><td><A href='deleteban.php?ID=$getbannedips3[banipid]'>Delete</a></td></tr>";
   }
   print "</table>";

   print "</td></tr></table>";
}
else
{
  print "Not logged in.";
  print "</td></tr></table>";
 

}
?>