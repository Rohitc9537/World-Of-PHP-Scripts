<?php
/**
 * Default page stub. This actually redirects to another backoffice page.
 *
 * Include whatever page you'd like to use as the admin default.
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @package admin
 */


/**
 * You can choose the page you want as the default below:
 */
require dirname(__FILE__).'/b2edit.php';

?>