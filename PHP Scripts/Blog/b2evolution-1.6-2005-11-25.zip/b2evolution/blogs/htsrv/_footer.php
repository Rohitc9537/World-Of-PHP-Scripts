<?php
/**
 * This is the footer file for login/registering services
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @package htsrv
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );
?>

</div>

<p class="footer"><?php echo $app_footer_text; ?></p>

<?php debug_info(); ?>

</body>
</html>