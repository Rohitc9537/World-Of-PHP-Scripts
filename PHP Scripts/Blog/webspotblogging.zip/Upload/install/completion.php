<?
$page = "Installation Completion";
$path = "../";
include("../inc/mainheader.inc.php");
?>
You have successfully set up a blogging system.<BR><BR>
<b>Please remove this directory to finish completely.<BR></b>
Thanks for choosing WebspotBlogging for your website. I hope you find this web application great!!!
<?
include("../inc/footer.inc.php");
?>