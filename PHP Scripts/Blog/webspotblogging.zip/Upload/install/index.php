<?
$path = "../";
$page = "Installation Wizard : Welcome";
include("../inc/installheader.inc.php");
?>
Thanks for taking the time to install WebspotBlogging. This wizard will help you. Before you start make sure you have done the following:<ul>
<li>Uploaded the whole contents of the 'upload' directory on to your webspace</li>
<li>And Have got your database settings</li>
</ul><BR>
Hopefully you've done this stuff. So let's begin setting up WebspotBlogging.<BR><BR>
To Continue Press the next button.<BR><BR>
<form action="check.php" method="link">
<input type="submit" value="Next Step" style="float:right;">
</form>
<?
include("../inc/footer.inc.php");
?>