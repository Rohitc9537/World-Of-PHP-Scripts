<?php
/**
* WebspotBlogging
* Copyright 2005
*
* Website : http://blogging.webspot.co.uk/
* Licence : http://blogging.webspot.co.uk/eula.php
*
**/
$path = "../";
$admincheck = 1;
$page = "Credits";
include("../inc/adminheader.inc.php");
?>
Without these people WebspotBlogging wouldn't be as good as it is.<BR><BR>
Andrew is in charge of the project and does most of the coding. Although he is quite good at coding he doesn't really know what colours to use and what things should look like.<BR>
But luckily there's Beau who sorts out all of the design work and makes some graphics for the project
<?
include("../inc/footer.inc.php");
?>