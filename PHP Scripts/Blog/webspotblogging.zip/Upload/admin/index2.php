<?php
/**
* WebspotBlogging
* Copyright 2005
*
* Website : http://blogging.webspot.co.uk/
* Licence : http://blogging.webspot.co.uk/eula.php
*
**/
$path = "../";
include("../inc/global.php");
$admincheck = 1;
include("../inc/checks.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Admin CP</title>
</head>
<frameset cols="20%,*" border="0">
<frame frameborder="0" src="left.php">
<frameset rows="70,*" border="0">
<frame frameborder="0" src="top.php">
<frame frameborder="0" src="home.php" name="mainframe">
</frameset>
</frameset><noframes></noframes>
</html>
