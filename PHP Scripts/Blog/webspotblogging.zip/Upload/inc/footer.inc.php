<?
/**
* WebspotBlogging
* Copyright 2005
*
* Website : http://blogging.webspot.co.uk/
* Licence : http://blogging.webspot.co.uk/eula.php
*
**/
?>
</td></div></tr>
</table>
<?
echo "<div style='float:right;font-family:Verdana;font-size:7.5pt;'>";
echo "<BR>";
echo "Powered By <a href='http://www.webspot.co.uk/' target='_blank'>WebspotBlogging</a> v2.0<BR>";
echo "Copyright &copy; 2005 <a href='http://www.webspot.co.uk/' target='_blank'><b>Webspot.co.uk</b></a>";
echo "</div><BR><BR>";
?>
</BODY>
</HTML>