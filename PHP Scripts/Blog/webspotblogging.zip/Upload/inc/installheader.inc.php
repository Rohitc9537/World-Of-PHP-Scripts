<HTML>
<HEAD>

<style>
.subheader{
color: #FFFFFF;
background: url("../styles/default/subheader.gif");
font-family: Tahoma, Verdana, Arial, Helvetica, Sans-Serif;
font-size: 11px;
vertical-align: center;
border-bottom:#000000 1px solid;
}
.post_content{
color: #000000;
background: #EDEDED;
font-family: Tahoma, Verdana, Arial, Helvetica, Sans-Serif;
font-size: 13px;
vertical-align: center;
}
.content{
color: #000000;
background-color: #DCDCDC;
font-family: Tahoma, Verdana, Arial, Helvetica, Sans-Serif;
font-size: 13px;
vertical-align: center;
}
.topbar{
color: #FFFFFF;
background-color: #70B66D;
font-family: Tahoma, Verdana, Arial, Helvetica, Sans-Serif;
font-size: 13px;
vertical-align: center;
margin:0px 0px 0px 0px;
border-bottom:#000000 1px solid;
}
.topbar a{
color:#ffffff;
}
.topbar a:visited{
color:#ffffff;
}
.topbar a:hover{
color:#ffffff;
background-color:#70B66D;
}
.header{
color: #FFFFFF;
background: url("../styles/default/header.gif");
font-family: Tahoma, Verdana, Arial, Helvetica, Sans-Serif;
font-size: 11px;
vertical-align: center;
border-bottom:#000000 1px solid;
}
.tblborder{
border:#000000 1px solid;
background: #EFEFEF;
}
a:visited{
color:blue;
}
body{
background-color:#EEEEEE;
}
</style>
<title>
WebspotBlogging v2 -- Installation Wizard</title>
</HEAD>
<body>
<div align="right"><img src="../styles/default/logo.gif"></div>
<table cellpadding="8" cellspacing="0" border="0" width="96%" class="tblborder" align="center"><tr>
<td colspan="4" class="header" align="center">
WebspotBlogging v2 -- Installation Wizard</td>
</tr>
<tr>
</tr>
<tr>
<div align="center">
<td class="content">
<BR>