Webspot Blogging version 2

Please read the documentation in the Docs directory before uploading.