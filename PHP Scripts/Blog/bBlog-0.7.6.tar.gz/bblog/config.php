<html><body><h1>bBlog 0.7.6</h1>
<p>bBlog is not installed, this is the config.php file and has not been overwritten by the installer.</p>
<p>Please see the <a href="http://www.bblog.com/docs/" target="_blank">bBlog online manual</a> for install instructions.</p>

<p><i>Quick instructions for the impatient: go to the <a href="bblog/install.php">bblog/install.php</a> page.</i></p>
</body></html>
<?php die; ?>
