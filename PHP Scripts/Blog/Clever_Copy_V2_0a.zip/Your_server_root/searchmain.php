<?php
echo "<br><center><form action='mainsearch.php' method='post'>";
echo "$search_terms_label<br>";
echo "<input name='searchterm' type='text' size='20' class='text'><br><br>";
echo "<input type='submit' value=$search_button_label class='buttons'></form>";
echo "</font>";
?>