<?php
session_start();
include "languages/default.php";
?>
<head><title><?php echo $admin_title; ?></title></head>
<link rel="stylesheet" href="style.css" type="text/css">
<?php
include "index.php";
echo "<br><br>Clever Copy took over 500 hours to write and contains (the last time I counted) 21,418 lines of code. It was written by ";
echo "me, Magus Perde. Special mention goes to <a href='http://liquidfrog.bestdirectbuy.com' target='_new'>Liquid Frog</a> for many of the core functions and processes.<br><br>";
echo "Thanks also go to those who have made their scripts freely available to use. They are many and their copyrights and weblinks are in place in the code where necessary<br>"; 
?>