<?php
 $FLog_dir_plugins = 'plugins/';
 $FLog_dir_data    = 'data/';
 $FLog_dir_themes  = 'themes/';
 $FLog_dir_include = 'include/';
 $FLog_dir_files   = 'files/';
 require_once($FLog_dir_include.'core.inc.php');
?>