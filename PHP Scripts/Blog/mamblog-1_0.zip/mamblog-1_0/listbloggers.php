<?php
/**
* FileName: listbloggers.php
*	Date: 10-19-2003
* License: GNU General Public License
* Script Version #: 1.0
* MOS Version #: 4.5
* Script TimeStamp: "10/19/2003 14:08PM"
* Original Script: Olle Johansson - Olle@Johansson.com
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

?>