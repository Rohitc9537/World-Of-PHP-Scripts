<?php
$cfg_mamblog['version'] = "1.0";
$cfg_mamblog['count'] = "6";
$cfg_mamblog['intro'] = "3";
$cfg_mamblog['image'] = "0";
$cfg_mamblog['sort'] = "datedesc";
$cfg_mamblog['showdefault'] = "all";
$cfg_mamblog['showarchivelink'] = "1";
$cfg_mamblog['specified'] = "";
$cfg_mamblog['useattribs'] = "0";
$cfg_mamblog['use_bgcolor'] = "0";
$cfg_mamblog['use_fgcolor'] = "0";
$cfg_mamblog['use_border'] = "0";
$cfg_mamblog['use_bordercolor'] = "0";
$cfg_mamblog['use_width'] = "0";
$cfg_mamblog['use_height'] = "0";
$cfg_mamblog['use_textalign'] = "0";
$cfg_mamblog['use_allowcomments'] = "0";
$cfg_mamblog['use_showcomments'] = "0";
$cfg_mamblog['use_frontpage'] = "1";
$cfg_mamblog['use_state'] = "1";
$cfg_mamblog['use_access'] = "1";
$cfg_mamblog['min_width'] = "100";
$cfg_mamblog['max_width'] = "600";
$cfg_mamblog['min_height'] = "50";
$cfg_mamblog['max_height'] = "400";
$cfg_mamblog['commentsystem'] = "none";
$cfg_mamblog['joomlaboardid'] = '0';
$cfg_mamblog['itemstructure'] = "1";
$cfg_mamblog['header'] = "Show latest blog entries";
$cfg_mamblog['maxchars'] = "0";
$cfg_mamblog['showusername'] = "0";
$cfg_mamblog['editor'] = "_jx_default";
$cfg_mamblog['editorwidth'] = "400";
$cfg_mamblog['editorheight'] = "200";
$cfg_mamblog['preset_values'] =
array(
      "state" => "1",
      "frontpage" => "0",
	  "access" => "1",
	  "attribs" => "
allowcomments=1
showcomments=1
textalign=left
fgcolor=black
bgcolor=white
border=1
bordercolor=black
width=250
height=100
",
);
?>
