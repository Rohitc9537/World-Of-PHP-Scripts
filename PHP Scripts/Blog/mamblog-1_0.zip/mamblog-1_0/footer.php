  <p><?php echo _BLOG_CREATED_BY; ?>
     <font class="small"><a href="http://mambo.theyard.org" target="_blank">Olle Johansson</a></font>
	 <br />
	 Visit <a href="http://mambo.theyard.org" target="blank">Mambo at the Yard</a> for more exciting Mambo addons.
     <br />
     <font class="small"><?php echo _BLOG_VERSION; ?>: <?php echo $cfg_mamblog['version']; ?></font>
  </p>
