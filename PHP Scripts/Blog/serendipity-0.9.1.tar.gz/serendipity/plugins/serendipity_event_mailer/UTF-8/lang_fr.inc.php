<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_MAILER_NAME', 'Envoyer les billets par E-Mail');
@define('PLUGIN_EVENT_MAILER_DESC', 'Envoie un billet par Email à un destinataire de votre choix lorsqu\'il est publié');
@define('PLUGIN_EVENT_MAILER_RECIPIENT', 'Destinataire');
@define('PLUGIN_EVENT_MAILER_RECIPIENTDESC', 'L\'adresse Email à laquelle le billet dot être envoyé (suggestion: une mailing list)');
@define('PLUGIN_EVENT_MAILER_LINK', 'Envoyer un lien au billet?');
@define('PLUGIN_EVENT_MAILER_LINKDESC', 'Inclut un lien au billet original dans l\'email.');
@define('PLUGIN_EVENT_MAILER_STRIPTAGS', 'Enlever le HTML?');
@define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC', 'Enlève toutes les balises HTML contenues dans le billet.');

/* vim: set sts=4 ts=4 expandtab : */
?>