<?php # $Id: lang_ja.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 Tadashi Jokagi <elf2000@users.sourceforge.net>           #
#                                                                        #
##########################################################################

        @define('PLUGIN_EVENT_MAILER_NAME', '電子メールでエントリを送信する');
        @define('PLUGIN_EVENT_MAILER_DESC', '指定のアドレスに電子メールで新しく作られたエントリを送ります。');
        @define('PLUGIN_EVENT_MAILER_RECIPIENT', 'メール受信者');
        @define('PLUGIN_EVENT_MAILER_RECIPIENTDESC', 'エントリを送信したい電子メールアドレス (提案: メーリングリスト)');
        @define('PLUGIN_EVENT_MAILER_LINK', '記事へのリンクをメールしますか?');
        @define('PLUGIN_EVENT_MAILER_LINKDESC', 'メールに記事へのリンクを含みます。');
        @define('PLUGIN_EVENT_MAILER_STRIPTAGS', 'HTML を削除しますか?');
        @define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC', '電子メールから HTML タグを削除します。');

/* vim: set sts=4 ts=4 expandtab : */
?>
