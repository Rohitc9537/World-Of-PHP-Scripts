<?php # $Id: serendipity_event_nl2br.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_NL2BR_NAME',     'Textformatierung: NL2BR');
        @define('PLUGIN_EVENT_NL2BR_DESC',     'Konvertiert Zeilenumbr�che zu HTML');
