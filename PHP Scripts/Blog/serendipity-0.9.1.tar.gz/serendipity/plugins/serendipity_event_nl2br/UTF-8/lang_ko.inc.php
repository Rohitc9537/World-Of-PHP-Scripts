<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_NL2BR_NAME',     '마크업: NL2BR');
        @define('PLUGIN_EVENT_NL2BR_DESC',     '새 줄을 BR 태그로 변환함');

?>
