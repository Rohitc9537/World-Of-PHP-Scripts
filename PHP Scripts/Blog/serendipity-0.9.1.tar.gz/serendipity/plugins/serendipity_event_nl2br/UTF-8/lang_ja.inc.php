<?php # $Id: lang_ja.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 Tadashi Jokagi <elf2000@users.sourceforge.net>           #
#                                                                        #
##########################################################################

        @define('PLUGIN_EVENT_NL2BR_NAME',     'マークアップ: NL2BR');
        @define('PLUGIN_EVENT_NL2BR_DESC',     '改行を BR タグに変換します。');

/* vim: set sts=4 ts=4 expandtab : */
?>
