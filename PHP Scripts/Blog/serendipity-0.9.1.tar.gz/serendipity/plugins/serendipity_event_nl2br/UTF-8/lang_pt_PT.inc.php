<?php # $Id:$

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <jmatos@math.ist.utl.pt>                                  #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_NL2BR_NAME',     'Código: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC',     'Converte os fins de linha em etiquetas BR');

/* vim: set sts=4 ts=4 expandtab : */
?>