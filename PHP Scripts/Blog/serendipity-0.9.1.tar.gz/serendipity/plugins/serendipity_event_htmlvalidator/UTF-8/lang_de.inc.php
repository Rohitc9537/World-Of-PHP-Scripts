<?php # $Id: serendipity_event_htmlvalidator.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_HTMLVALIDATOR_NAME', 'HTML Validator');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DESC', 'Überprüft, ob ein Artikel XML-konform ist');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSET', 'Zeichensatz');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSETDESC', 'Der übliche Zeichensatz Ihrer Einträge');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPE', 'Dokumenttyp');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPEDESC', 'Der übliche Dokumenttyp Ihrer Einträge');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_VALIDATE', 'Bei jeder Vorschau aktiviert');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_GOVALIDATE', 'HTML-Validator bei der Vorschau ausführen');
