<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_HTMLVALIDATOR_NAME', 'HTML 적합성 검사');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DESC', '글이 XML 규격을 따르는지 적합성 검사를 실시함');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSET', '문자열 종류');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSETDESC', '글을 작성할 때 사용한 문자열의 종류');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPE', '문서 종류');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPEDESC', '글을 작성할 때 사용한 문서의 종류');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_VALIDATE', '미리보기 할 때 검사');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_GOVALIDATE', '미리보기에 HTML 적합성 검사 보여주기');

?>
