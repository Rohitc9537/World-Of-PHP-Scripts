<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_HTMLVALIDATOR_NAME', 'HTML 查驗');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DESC', '以 XML 標準查驗文章');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSET', '編碼');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_CHARSETDESC', '文章使用的編碼');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPE', 'Doctype');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_DOCTYPEDESC', '使用的文章類型 (Doctype)');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_VALIDATE', '預覽時進行查驗');
        @define('PLUGIN_EVENT_HTMLVALIDATOR_GOVALIDATE', '預覽時顯示 HTML 查驗');
?>