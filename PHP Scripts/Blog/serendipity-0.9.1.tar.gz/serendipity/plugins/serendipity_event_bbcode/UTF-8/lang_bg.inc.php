<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $

        @define('PLUGIN_EVENT_BBCODE_NAME',     'Текстово форматиране: BBCode');
        @define('PLUGIN_EVENT_BBCODE_DESC',     'Форматиране на текст (постинг, коментар, HTML поле) с BBcode');
        @define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'Форматирането с <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> е разрешено');
