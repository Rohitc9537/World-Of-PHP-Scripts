<?php # $Id: lang_es.inc.php,v 1.0 2005/08/20 11:37:42 garvinhicking Exp $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Rodrigo Lazo <rlazo.paz@gmail.com>
/* vim: set sts=4 ts=4 expandtab : */

@define('PLUGIN_EVENT_BBCODE_NAME',     'Formato: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Dar formato al texto utilizando BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'Formato <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> permitido');

?>