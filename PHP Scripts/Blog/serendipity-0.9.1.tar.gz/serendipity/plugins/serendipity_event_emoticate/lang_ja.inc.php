<?php # $Id: lang_ja.inc.php 410 2005-08-18 16:05:09Z elf2000 $

/**
 *  @version $Revision$
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 346
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'マークアップ: 感情表現');
@define('PLUGIN_EVENT_EMOTICATE_DESC', '標準的な感情表現を画像に変換します。');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', '標準的な感情表現、 :-) や ;-) といったものは画像に変換します。');

/* vim: set sts=4 ts=4 expandtab : */
?>
