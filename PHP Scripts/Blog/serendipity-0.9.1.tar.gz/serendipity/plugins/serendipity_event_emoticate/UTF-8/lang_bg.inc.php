<?php # $Id: serendipity_event_emoticate.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_EMOTICATE_NAME', 'Форматиране на текст: Усмивки');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', 'Конвертира стандартните знаци за изразяване на емоции в графични изображения');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Стандартните знаци :) и ;) се конвертират в графични изображения');

