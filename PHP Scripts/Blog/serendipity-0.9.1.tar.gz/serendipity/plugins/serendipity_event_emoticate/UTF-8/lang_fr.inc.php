<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Balises: Smilies');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Convertit les smilies standard en images');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Les smilies standard comme :-) et ;-) sont convertis en images.');

/* vim: set sts=4 ts=4 expandtab : */
?>