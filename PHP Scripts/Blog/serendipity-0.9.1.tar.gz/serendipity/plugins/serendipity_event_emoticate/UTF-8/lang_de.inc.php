<?php # $Id: serendipity_event_emoticate.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_EMOTICATE_NAME', 'Textformatierung: Smilies');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', 'Standard Text-Smilies in Grafiken konvertieren');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard-Text Smilies wie :-) und ;-) werden zu Bildern konvertiert.');
