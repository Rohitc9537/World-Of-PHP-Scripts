<?php # $Id: lang_ja.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 Tadashi Jokagi <elf2000@users.sourceforge.net>           #
#                                                                        #
##########################################################################

        @define('PLUGIN_EVENT_EMOTICATE_NAME', 'マークアップ: 感情表現');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', '標準的な感情表現を画像に変換します。');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', '標準的な感情表現、 :-) や ;-) といったものは画像に変換します。');

/* vim: set sts=4 ts=4 expandtab : */
?>
