<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_EVENT_EMOTICATE_NAME', 'Textabreyting: Tilfinningav��a');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', 'Breyta venjulegum textabrosk�llum � graf�skar myndir');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Venjulegum brosk�llum, eins og :-) og ;-), ver�ur breytt � myndir.');

/* vim: set sts=4 ts=4 expandtab : */
?>