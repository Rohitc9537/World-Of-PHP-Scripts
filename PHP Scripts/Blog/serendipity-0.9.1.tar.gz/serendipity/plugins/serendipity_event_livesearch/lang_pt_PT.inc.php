<?php # $Id:$
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Jo�o P Matos <jmatos@math.ist.utl.pt>
/* vim: set sts=4 ts=4 expandtab : */

@define('PLUGIN_EVENT_LIVESEARCH_NAME', 'Livesearch');
@define('PLUGIN_EVENT_LIVESEARCH_DESC', 'Melhora o funcionamento interno da busca ao juntar actualiza��es em tempo real ao pressionar as teclas (JavaScript)');
@define('PLUGIN_EVENT_LIVESEARCH_WAIT', 'Espere, enviando pedido...');

?>