<?php # $Id: lang_es.inc.php,v 1.0 2005/08/20 11:37:42 garvinhicking Exp $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Rodrigo Lazo <rlazo.paz@gmail.com>
/* vim: set sts=4 ts=4 expandtab : */

@define('PLUGIN_EVENT_LIVESEARCH_NAME', 'Livesearch');
@define('PLUGIN_EVENT_LIVESEARCH_DESC', 'Mejora el funcionamiento interno de la búsqueda al añadir actualizaciones en tiempo real al presionar las teclas (JavaScript)');
@define('PLUGIN_EVENT_LIVESEARCH_WAIT', 'Espere, enviando pedido...');

?>