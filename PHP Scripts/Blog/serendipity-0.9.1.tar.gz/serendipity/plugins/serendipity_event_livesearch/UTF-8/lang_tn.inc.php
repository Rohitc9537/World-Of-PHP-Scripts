<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_LIVESEARCH_NAME', '即時搜尋');
        @define('PLUGIN_EVENT_LIVESEARCH_DESC', '提高搜尋的功能，輸入的搜尋字可快速顯示。');
        @define('PLUGIN_EVENT_LIVESEARCH_WAIT', '稍待，傳送資料...');
?>