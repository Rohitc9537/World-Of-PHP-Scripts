<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_LIVESEARCH_NAME', '실시간 검색');
        @define('PLUGIN_EVENT_LIVESEARCH_DESC', '기본 검색 기능을 향상시켜 글자를 입력할 때마다 실시간으로 검색결과를 갱신함 (자바스트립트 사용)');
        @define('PLUGIN_EVENT_LIVESEARCH_WAIT', '요청을 보냈습니다. 기다려주십시오...');

?>
