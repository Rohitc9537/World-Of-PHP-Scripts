<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_LIVESEARCH_NAME', 'Recherche active');
@define('PLUGIN_EVENT_LIVESEARCH_DESC', 'Améliore la fonction de recherche par des mises à jour a chaque pression de touche du clavier (JavaScript)');
@define('PLUGIN_EVENT_LIVESEARCH_WAIT', 'Patientez, envoi de la requête...');

/* vim: set sts=4 ts=4 expandtab : */
?>