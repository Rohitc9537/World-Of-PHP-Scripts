<?php # $Id: serendipity_event_livesearch.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_LIVESEARCH_NAME', 'LiveSearch');
        @define('PLUGIN_EVENT_LIVESEARCH_DESC', 'Erweitert die Suchfunktion mit einer Live-aktualisierung (JavaScript)');
        @define('PLUGIN_EVENT_LIVESEARCH_WAIT', 'Suche aktiviert, bitte warten...');
