<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_RECENTENTRIES_TITLE', 'N�legar f�rslur');
        @define('PLUGIN_RECENTENTRIES_BLAHBLAH', 'S�nir titla og dagsetningar n�legustu f�rslanna');
        @define('PLUGIN_RECENTENTRIES_NUMBER', 'Fj�ldi f�rsla');
        @define('PLUGIN_RECENTENTRIES_NUMBER_BLAHBLAH', 'Hversu margar f�rslur �ttu a� vera s�ndar? (Sj�lfgefi� gildi: 10)');

/* vim: set sts=4 ts=4 expandtab : */
?>