<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_RECENTENTRIES_TITLE', 'Nýlegar færslur');
        @define('PLUGIN_RECENTENTRIES_BLAHBLAH', 'Sýnir titla og dagsetningar nýlegustu færslanna');
        @define('PLUGIN_RECENTENTRIES_NUMBER', 'Fjöldi færsla');
        @define('PLUGIN_RECENTENTRIES_NUMBER_BLAHBLAH', 'Hversu margar færslur ættu að vera sýndar? (Sjálfgefið gildi: 10)');

/* vim: set sts=4 ts=4 expandtab : */
?>