<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_RECENTENTRIES_TITLE', '최근 글');
        @define('PLUGIN_RECENTENTRIES_BLAHBLAH', '가장 최근에 적은 글의 제목과 날짜를 보여줌');
        @define('PLUGIN_RECENTENTRIES_NUMBER', '글의 수');
        @define('PLUGIN_RECENTENTRIES_NUMBER_BLAHBLAH', '몇 개의 글을 보여주겠습니까? (기본값: 10)');
        @define('PLUGIN_RECENTENTRIES_NUMBER_FROM', '첫 페이지 글 생략');
        @define('PLUGIN_RECENTENTRIES_NUMBER_FROM_DESC', '첫 페이지에 나타나지 않는 최근 글만 보여주겠습니까? (기본값: 첫 ' . $serendipity['fetchLimit'] . '개의 글은 생략함)');
        @define('PLUGIN_RECENTENTRIES_NUMBER_FROM_RADIO_ALL', '모두 보여주기');
        @define('PLUGIN_RECENTENTRIES_NUMBER_FROM_RADIO_RECENT', '첫 페이지 글은 생략');

?>
