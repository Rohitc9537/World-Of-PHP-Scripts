<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_WEBLOGPING_PING', '새로운 글 알리기 (XML-RPC 핑 사용) 대상:');
        @define('PLUGIN_EVENT_WEBLOGPING_SENDINGPING', 'XML-RPC 핑을 %s 호스트로 보내는 중');
        @define('PLUGIN_EVENT_WEBLOGPING_TITLE', '글 발표');
        @define('PLUGIN_EVENT_WEBLOGPING_DESC', '온라인 서비스에 새로운 글이 올라왔음을 알림');
        @define('PLUGIN_EVENT_WEBLOGPING_SUPERSEDES', '(%s에 우선함)');
        @define('PLUGIN_EVENT_WEBLOGPING_CUSTOM', '핑 서비스 직접 설정');
        @define('PLUGIN_EVENT_WEBLOGPING_CUSTOM_BLAHBLA', '","로 구분하여 한 개 이상의 특별 핑 서비스를 입력합니다. 입력 사항은 "호스트.도메인/경로" 식으로 적어야 합니다. 호스트 이름 앞에 "*"를 입력하면 확장 XML-RPC 옵션이 해당 호스트에 전송됩니다 (호스트가 지원해야 함).');
        @define('PLUGIN_EVENT_WEBLOGPING_SEND_FAILURE', '실패 (사유: %s)');
        @define('PLUGIN_EVENT_WEBLOGPING_SEND_SUCCESS', '성공');

?>
