<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P. Matos <jmatos@math.ist.utl.pt>                                 #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_WEBLOGPING_PING', 'Anunciar as entradas (por ping XML) a:');
@define('PLUGIN_EVENT_WEBLOGPING_SENDINGPING', 'Enviar o ping XML-RPC � m�quina %s');
@define('PLUGIN_EVENT_WEBLOGPING_TITLE', 'Anunciar as entradas');
@define('PLUGIN_EVENT_WEBLOGPING_DESC', 'Enviar uma actualiza��o de novas entradas aos servi�os de indexa��o');
@define('PLUGIN_EVENT_WEBLOGPING_SUPERSEDES', '(substitui %s)');
@define('PLUGIN_EVENT_WEBLOGPING_CUSTOM', 'Servi�os ping adicionais');
@define('PLUGIN_EVENT_WEBLOGPING_CUSTOM_BLAHBLA', 'Um ou mais servi�os ping adicionais, separados por ",". As entradas precisam de ser formatadas como: "m�quina.dom�nio/caminho". Se um "*" for introduzido no princ�pio do nome de uma m�quina, as op��es XML-RPC adicionais ser�o enviadas para essa m�quina (se suportadas por essa m�quina).');
@define('PLUGIN_EVENT_WEBLOGPING_SEND_FAILURE', 'Falhan�o(Raz�o: %s)');
@define('PLUGIN_EVENT_WEBLOGPING_SEND_SUCCESS', 'Sucesso!!');

/* vim: set sts=4 ts=4 expandtab : */
?>