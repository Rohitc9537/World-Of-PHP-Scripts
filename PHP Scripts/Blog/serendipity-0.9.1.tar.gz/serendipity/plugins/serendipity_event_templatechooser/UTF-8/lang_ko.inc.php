<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_TEMPLATECHOOSER_NAME',     '템플릿 선택');
        @define('PLUGIN_EVENT_TEMPLATECHOOSER_DESC',     '방문자가 즉석에서 템플릿을 바꿀 수 있도록 함');

?>
