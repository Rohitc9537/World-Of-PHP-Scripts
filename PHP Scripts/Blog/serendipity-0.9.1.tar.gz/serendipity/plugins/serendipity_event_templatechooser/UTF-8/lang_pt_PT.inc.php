<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <jmatos@math.ist.utl.pt>                                  #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TEMPLATECHOOSER_NAME', 'Selector de tema');
@define('PLUGIN_EVENT_TEMPLATECHOOSER_DESC', 'Permite aos utilizadores do seu blogue mudar o tema facilmente');

/* vim: set sts=4 ts=4 expandtab : */
?>