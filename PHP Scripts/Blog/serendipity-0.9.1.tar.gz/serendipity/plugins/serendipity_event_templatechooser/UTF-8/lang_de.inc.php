<?php # $Id: serendipity_event_templatechooser.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_TEMPLATECHOOSER_NAME',     'Templateauswahl');
        @define('PLUGIN_EVENT_TEMPLATECHOOSER_DESC',     'Ermöglicht Besuchern das Template zu ändern');
