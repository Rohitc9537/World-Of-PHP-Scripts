<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_TRACKBACK_NAME', '마크업: 진출 추적');
        @define('PLUGIN_EVENT_TRACKBACK_DESC', '외부 인터넷 주소를 클릭한 것을 추적함');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION', '답글 단 사용자의 인터넷 주소에 대해 주소 리다이렉트 사용');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_BLAHBLA', '덧글 악용을 줄일 수 있으나 답글을 다는 사용자의 주소를 링크하는데서 오는 긍정적인 효과도 막게 됩니다. 세렌디피티 내부 루틴은 목표 페이지로 리다이렉트한 후 진출 상황을 기록에 남깁니다. 구글 페이지랭크 보호기는 해당 링크가 구글에서 랭크가 상승하는 것을 막습니다. 빈 값을 사용할 경우 이 기능을 완전히 끕니다 (기본값).');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_NONE', '없음');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_S9Y', '세렌디피티 진출 추적 루틴');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_GOOGLE', '구글 페이지랭크 보호기');

?>
