<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_TRACKBACK_NAME', '標記語言：記錄出源');
        @define('PLUGIN_EVENT_TRACKBACK_DESC', '記錄每個點擊的外來 URLs');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION', '使用網頁轉址的功能？');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_BLAHBLA', '減少迴響的濫用，和禁止連結到迴響。s9y 的出源程序會轉址到目標頁面和記錄出源。Google PageRank Deflector 會禁止連結增加它的等級排列。如果是不使用將會關閉這個功能 (預設)。');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_NONE', '不使用');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_S9Y', 's9y 的出源程序');
        @define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_GOOGLE', 'Google PageRank Deflector');
?>