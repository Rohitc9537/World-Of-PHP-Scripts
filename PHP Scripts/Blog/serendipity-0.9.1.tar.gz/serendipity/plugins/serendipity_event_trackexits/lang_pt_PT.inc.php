<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P. Matos <jmatos@math.ist.utl.pt>                                 #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TRACKBACK_NAME', 'C�digo: Gest�o das liga��es para o exterior');
@define('PLUGIN_EVENT_TRACKBACK_DESC', 'Regista os cliques nas liga��es para o exterior do seu blogue');
@define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION', 'Incluir liga��es para as p�ginas dos utilizadores?');
@define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_BLAHBLA', 'Reduz o abuso dos coment�rios, mas anula tamb�m o efeito postivo duma liga��o para uma p�gina de um utilizador. As rotinas internas do Serendipity redirigem para a p�gina alvo e acrescentam ao log. O deflector de Google PageRank impede que a liga��o ganhe PageRank no Google.');
@define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_NONE', 'Nenhum');
@define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_S9Y', 'Sim');
@define('PLUGIN_EVENT_TRACKBACK_COMMENTREDIRECTION_GOOGLE', 'Sim, activando o deflector de Google PageRank');

/* vim: set sts=4 ts=4 expandtab : */
?>