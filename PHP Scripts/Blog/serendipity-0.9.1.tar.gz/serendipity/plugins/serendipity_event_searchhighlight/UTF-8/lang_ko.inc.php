<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_SEARCHHIGHLIGHT_NAME',     '검색 질의어를 강조 표시');
        @define('PLUGIN_EVENT_SEARCHHIGHLIGHT_DESC',     '페이지를 검색하기 위해 검색엔진에 입력한 질의어를 강조해서 나타냄');

?>
