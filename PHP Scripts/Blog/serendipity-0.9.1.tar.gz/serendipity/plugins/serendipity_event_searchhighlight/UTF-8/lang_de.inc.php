<?php # $Id: serendipity_event_searchhighlight.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_SEARCHHIGHLIGHT_NAME',     'Hebe Suchwörter hervor');
        @define('PLUGIN_EVENT_SEARCHHIGHLIGHT_DESC',     'Hebt Suchwörter hervor, die ein User in einer Suchmaschine eingegeben hat');
