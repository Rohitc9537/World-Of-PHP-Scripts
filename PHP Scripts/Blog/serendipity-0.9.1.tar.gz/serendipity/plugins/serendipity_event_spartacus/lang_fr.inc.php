<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_SPARTACUS_NAME', 'Spartacus');
@define('PLUGIN_EVENT_SPARTACUS_DESC', '[S]erendipity [P]lugin [A]ccess [R]epository [T]ool [A]nd [C]ustomization/[U]nification [S]ystem - Vous permet de t�l�charger des plugins directement de notre d�p�t officiel.');
@define('PLUGIN_EVENT_SPARTACUS_FETCH', 'Cliquez ici pour t�l�charger un nouveau %s du d�p�t officiel de Serendipity');
@define('PLUGIN_EVENT_SPARTACUS_FETCHERROR', 'Impossible d\'acc�der � l\'adresse %s. Peut-�tre que le serveur de Serendipity ou de SourceForge.net n\'est momentan�ment pas accessible. Merci de r�essayer plus tard.');
@define('PLUGIN_EVENT_SPARTACUS_FETCHING', 'Essaie d\'acc�der � l\'adresse %s...');

/* vim: set sts=4 ts=4 expandtab : */
?>