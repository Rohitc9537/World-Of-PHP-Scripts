<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_SPARTACUS_NAME', 'Spartacus');
@define('PLUGIN_EVENT_SPARTACUS_DESC', '[S]erendipity [P]lugin [A]ccess [R]epository [T]ool [A]nd [C]ustomization/[U]nification [S]ystem - Vous permet de télécharger des plugins directement de notre dépôt officiel.');
@define('PLUGIN_EVENT_SPARTACUS_FETCH', 'Cliquez ici pour télécharger un nouveau %s du dépôt officiel de Serendipity');
@define('PLUGIN_EVENT_SPARTACUS_FETCHERROR', 'Impossible d\'accéder à l\'adresse %s. Peut-être que le serveur de Serendipity ou de SourceForge.net n\'est momentanément pas accessible. Merci de réessayer plus tard.');
@define('PLUGIN_EVENT_SPARTACUS_FETCHING', 'Essaie d\'accéder à l\'adresse %s...');

/* vim: set sts=4 ts=4 expandtab : */
?>