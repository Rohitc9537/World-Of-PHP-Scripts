<?php # $Id: serendipity_event_textwiki.php 271 2005-07-14 09:39:01Z garvinhicking $

        @define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Textformatierung: Wiki');
        @define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Wiki-Formatierung durchf�hren');
        @define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '<a href="http://c2.com/cgi/wiki">Wiki</a>-Formatierung erlaubt');
