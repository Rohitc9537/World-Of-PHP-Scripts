<?php # $Id: lang_ja.inc.php 511 2005-09-30 03:51:47Z elf2000 $

/**
 *  @version $Revision$
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 346
 */

@define('PLUGIN_EVENT_TEXTWIKI_NAME',     'マークアップ: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Text_Wiki を使用してテキストをマークアップします。');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '<a href="http://c2.com/cgi/wiki">Wiki</a> 書式を許可します。');

?>
