<?php # $Id: lang_es.inc.php,v 1.0 2005/08/20 11:37:42 garvinhicking Exp $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Rodrigo Lazo <rlazo.paz@gmail.com>
/* vim: set sts=4 ts=4 expandtab : */


@define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Formato: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Dar formato al texto utilizando Text_Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', 'Formato <a href="http://c2.com/cgi/wiki">Wiki</a> permitido');

?>