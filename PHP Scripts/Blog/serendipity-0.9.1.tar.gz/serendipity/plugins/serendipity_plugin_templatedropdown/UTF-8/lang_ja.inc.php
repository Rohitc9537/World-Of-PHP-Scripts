<?php # $Id: lang_ja.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 Tadashi Jokagi <elf2000@users.sourceforge.net>           #
#                                                                        #
##########################################################################

        @define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'テンプレートドロップダウン');
        @define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'テンプレート変更のボックスを表示します。');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   '送信ボタンの表示は?');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   '送信ボタンの表示をしますか?');

/* vim: set sts=4 ts=4 expandtab : */
?>
