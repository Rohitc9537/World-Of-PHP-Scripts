<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_TEMPLATEDROPDOWN_NAME',     '佈景選擇');
        @define('PLUGIN_TEMPLATEDROPDOWN_DESC',     '顯示改變佈景的選擇');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   '送出按鈕？');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   '要顯示送出按鈕嗎？');
?>