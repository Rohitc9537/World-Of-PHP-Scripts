<?php # $Id: serendipity_plugin_templatedropdown.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Template dropdown');
        @define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Zeigt eine Box um Templates zu �ndern');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Submit-Button?');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'Einen Submit-Button anzeigen?');
