<?php # $Id: lang_ja.inc.php 511 2005-09-30 03:51:47Z elf2000 $

/**
 *  @version $Revision: 1.3 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 346
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'テンプレートドロップダウン');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'テンプレート変更のボックスを表示します。');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   '送信ボタンの表示は?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   '送信ボタンの表示をしますか?');

/* vim: set sts=4 ts=4 expandtab : */
?>
