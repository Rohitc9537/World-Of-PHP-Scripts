<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_SHOUTBOX_NAME', 'Shoutbox');
        @define('PLUGIN_SHOUTBOX_DELETE', '刪除');
        @define('PLUGIN_SHOUTBOX_SUBMIT', '發言');
        @define('PLUGIN_SHOUTBOX_BLAHBLAH', '顯示 Shoutbox');
        @define('PLUGIN_SHOUTBOX_WORDWRAP', '自動段行');
        @define('PLUGIN_SHOUTBOX_WORDWRAP_BLAHBLAH', '要多少字之後自動換行？(預設：30)');
        @define('PLUGIN_SHOUTBOX_MAXCHARS', '顯示長度');
        @define('PLUGIN_SHOUTBOX_MAXCHARS_BLAHBLAH', '每個迴響要顯示多少個字？(預設：120)');
        @define('PLUGIN_SHOUTBOX_MAXENTRIES', '留言數量');
        @define('PLUGIN_SHOUTBOX_MAXENTRIES_BLAHBLAH', '要顯示多少個留言數量？(預設：15)');
?>