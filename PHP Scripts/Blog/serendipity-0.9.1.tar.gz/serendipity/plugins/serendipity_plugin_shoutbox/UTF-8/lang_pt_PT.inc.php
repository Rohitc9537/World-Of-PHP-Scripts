<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <jmatos@math.ist.utl.pt>                                #
#                                                                        #
##########################################################################

@define('PLUGIN_SHOUTBOX_NAME', 'Shoutbox');
@define('PLUGIN_SHOUTBOX_DELETE', 'Apagar');
@define('PLUGIN_SHOUTBOX_SUBMIT', 'Criar');
@define('PLUGIN_SHOUTBOX_BLAHBLAH', 'Mostra uma shoutbox onde os visitantes podem colocar comentários ad hoc');
@define('PLUGIN_SHOUTBOX_WORDWRAP', 'Dobra de linhas');
@define('PLUGIN_SHOUTBOX_WORDWRAP_BLAHBLAH', 'Dobra de linha automática depois de X palavras. Valor por omissão: 30');
@define('PLUGIN_SHOUTBOX_MAXCHARS', 'Caracteres por comentário');
@define('PLUGIN_SHOUTBOX_MAXCHARS_BLAHBLAH', 'Quantos caracteres serão mostrados por comentário? Valor por omissão: 120');
@define('PLUGIN_SHOUTBOX_MAXENTRIES', 'Número de comentários');
@define('PLUGIN_SHOUTBOX_MAXENTRIES_BLAHBLAH', 'Quantos comentários mostrar? Por omissão: 15');

/* vim: set sts=4 ts=4 expandtab : */
?>