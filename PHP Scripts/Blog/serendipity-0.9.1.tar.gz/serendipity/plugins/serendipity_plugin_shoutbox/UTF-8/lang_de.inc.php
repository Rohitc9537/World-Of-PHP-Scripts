<?php # $Id: serendipity_plugin_shoutbox.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_SHOUTBOX_NAME', 'Shoutbox');
        @define('PLUGIN_SHOUTBOX_BLAHBLAH', 'Zeigt eine Shoutbox für beliebige Kommentare');
        @define('PLUGIN_SHOUTBOX_DELETE', 'Löschen');
        @define('PLUGIN_SHOUTBOX_SUBMIT', 'Abschicken');
        @define('PLUGIN_SHOUTBOX_WORDWRAP', 'Zeilenumbruch');
        @define('PLUGIN_SHOUTBOX_WORDWRAP_BLAHBLAH', 'Nach wievielen Zeichen soll ein Zeilenumbruch eingefügt werden?');
        @define('PLUGIN_SHOUTBOX_MAXCHARS', 'Zeichen pro Kommentar');
        @define('PLUGIN_SHOUTBOX_MAXCHARS_BLAHBLAH', 'Wieviele Zeichen sollen pro Kommentar gezeigt werden? (Standard: 120)');
        @define('PLUGIN_SHOUTBOX_MAXENTRIES', 'Anzahl an Kommentaren');
        @define('PLUGIN_SHOUTBOX_MAXENTRIES_BLAHBLAH', 'Wieviele Kommentare sollen gezeigt werden? (Standard: 15)');
