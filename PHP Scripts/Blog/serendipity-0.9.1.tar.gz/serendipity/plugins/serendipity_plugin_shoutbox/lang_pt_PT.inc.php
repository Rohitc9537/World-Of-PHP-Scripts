<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P Matos <jmatos@math.ist.utl.pt>                                #
#                                                                        #
##########################################################################

@define('PLUGIN_SHOUTBOX_NAME', 'Shoutbox');
@define('PLUGIN_SHOUTBOX_DELETE', 'Apagar');
@define('PLUGIN_SHOUTBOX_SUBMIT', 'Criar');
@define('PLUGIN_SHOUTBOX_BLAHBLAH', 'Mostra uma shoutbox onde os visitantes podem colocar coment�rios ad hoc');
@define('PLUGIN_SHOUTBOX_WORDWRAP', 'Dobra de linhas');
@define('PLUGIN_SHOUTBOX_WORDWRAP_BLAHBLAH', 'Dobra de linha autom�tica depois de X palavras. Valor por omiss�o: 30');
@define('PLUGIN_SHOUTBOX_MAXCHARS', 'Caracteres por coment�rio');
@define('PLUGIN_SHOUTBOX_MAXCHARS_BLAHBLAH', 'Quantos caracteres ser�o mostrados por coment�rio? Valor por omiss�o: 120');
@define('PLUGIN_SHOUTBOX_MAXENTRIES', 'N�mero de coment�rios');
@define('PLUGIN_SHOUTBOX_MAXENTRIES_BLAHBLAH', 'Quantos coment�rios mostrar? Por omiss�o: 15');

/* vim: set sts=4 ts=4 expandtab : */
?>