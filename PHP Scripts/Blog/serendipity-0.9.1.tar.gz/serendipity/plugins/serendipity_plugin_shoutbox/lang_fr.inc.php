<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_SHOUTBOX_NAME', 'Shoutbox');
@define('PLUGIN_SHOUTBOX_DELETE', 'Effacer');
@define('PLUGIN_SHOUTBOX_SUBMIT', 'Crier');
@define('PLUGIN_SHOUTBOX_BLAHBLAH', 'Affiche une shoutbox o� les visiteurs peuvent donner des commentaires en vrac');
@define('PLUGIN_SHOUTBOX_WORDWRAP', 'Retour � la ligne');
@define('PLUGIN_SHOUTBOX_WORDWRAP_BLAHBLAH', 'Retour a la ligne automatique apr�s X mots. Valeur par d�faut: 30');
@define('PLUGIN_SHOUTBOX_MAXCHARS', 'Caract�res par commentaire');
@define('PLUGIN_SHOUTBOX_MAXCHARS_BLAHBLAH', 'D�finit le nombre maximum de caract�res pour un commentaire. Valeur par d�faut: 120');
@define('PLUGIN_SHOUTBOX_MAXENTRIES', 'Nombre de commentaires');
@define('PLUGIN_SHOUTBOX_MAXENTRIES_BLAHBLAH', 'D�finit le nombre maximum de commentaires � afficher.');

/* vim: set sts=4 ts=4 expandtab : */
?>