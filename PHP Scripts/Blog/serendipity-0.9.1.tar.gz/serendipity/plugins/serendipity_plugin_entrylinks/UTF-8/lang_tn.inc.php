<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_ENTRYLINKS_NAME', '文章連結');
        @define('PLUGIN_ENTRYLINKS_BLAHBLAH', '顯示文章內出現的連結');
        @define('PLUGIN_ENTRYLINKS_NEWWIN', '跳出新視窗？');
        @define('PLUGIN_ENTRYLINKS_NEWWIN_BLAHBLAH', '文章裡的連結要跳出新視窗嗎？(預設：主視窗)');
        @define('PLUGIN_ENTRYLINKS_REFERERS', '參照連結');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP', '自動段行');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP_BLAHBLAH', '要多少字之後自動換行？(預設：30)');
        @define('PLUGIN_ENTRYLINKS_MAXREF', '參照連結數量');
        @define('PLUGIN_ENTRYLINKS_MAXREF_BLAHBLAH', '要顯示多少個參照連結？(預設：15)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY', '排序參照連結');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_BLAHBLAH', '要怎樣排序參照連結？(預設：連結數量)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_DAY', '日期');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_FULLCOUNT', '連結數量');
?>