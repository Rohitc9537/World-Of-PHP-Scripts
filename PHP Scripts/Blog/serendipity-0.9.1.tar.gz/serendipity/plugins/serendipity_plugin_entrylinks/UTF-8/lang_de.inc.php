<?php # $Id: serendipity_plugin_entrylinks.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_ENTRYLINKS_NAME', 'Links des Artikels');
        @define('PLUGIN_ENTRYLINKS_BLAHBLAH', 'Zeigt alle referenzierten Links eines Artikels');
        @define('PLUGIN_ENTRYLINKS_NEWWIN', 'Links in neuem Fenster öffnen?');
        @define('PLUGIN_ENTRYLINKS_NEWWIN_BLAHBLAH', 'Sollen die Links in einem neuen Fenster geöffnet werden? (Standard: Nein)');
        @define('PLUGIN_ENTRYLINKS_REFERERS', 'Eingehende Links');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP', 'Zeilenumbruch');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP_BLAHBLAH', 'Nach wievielen Wörtern soll ein Zeilenumbruch eingefügt werden? (Standard: 30)');
        @define('PLUGIN_ENTRYLINKS_MAXREF', 'Anzahl eingehender Links');
        @define('PLUGIN_ENTRYLINKS_MAXREF_BLAHBLAH', 'Wieviele eingehende Links sollen höchstens dargestellt werden? (Standard: 15)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY', 'Reihenfolge eingehender Links');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_BLAHBLAH', 'Wonach sollen die eingehenden Links geordnet werden? (Standard: Häufigkeit)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_DAY', 'Datum');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_FULLCOUNT', 'Häufigkeit');
