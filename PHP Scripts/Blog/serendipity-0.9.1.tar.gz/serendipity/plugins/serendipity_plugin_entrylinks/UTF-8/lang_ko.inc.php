<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_ENTRYLINKS_NAME', '글에 있는 링크');
        @define('PLUGIN_ENTRYLINKS_BLAHBLAH', '글 안에 나타난 모든 링크를 보여줌');
        @define('PLUGIN_ENTRYLINKS_NEWWIN', '링크를 새 창에 보여주기');
        @define('PLUGIN_ENTRYLINKS_NEWWIN_BLAHBLAH', '링크를 누르면 새 창에 보여주겠습니까? (기본값: 현재 창)');
        @define('PLUGIN_ENTRYLINKS_REFERERS', '참고 링크');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP', '자동 줄바꿈');
        @define('PLUGIN_ENTRYLINKS_WORDWRAP_BLAHBLAH', '몇 글자 후에 자동 줄바꿈을 하겠습니까? (기본값: 30)');
        @define('PLUGIN_ENTRYLINKS_MAXREF', '최대 참고 링크 수');
        @define('PLUGIN_ENTRYLINKS_MAXREF_BLAHBLAH', '몇 개의 참고 링크를 보여주겠습니까? (기본값: 15)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY', '참고 링크 순서');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_BLAHBLAH', '어떤 방식으로 참고 링크의 순서를 정하겠습니까? (기본값: 링크의 수)');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_DAY', '날짜');
        @define('PLUGIN_ENTRYLINKS_ORDERBY_FULLCOUNT', '링크의 수');

?>
