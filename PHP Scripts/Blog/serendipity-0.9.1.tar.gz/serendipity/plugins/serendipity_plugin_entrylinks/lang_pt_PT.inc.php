<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P. Matos <jmatos@math.ist.utl.pt>                                 #
#                                                                        #
##########################################################################

@define('PLUGIN_ENTRYLINKS_NAME', 'Liga��es da entrada');
@define('PLUGIN_ENTRYLINKS_BLAHBLAH', 'Mostra todas as liga��es referenciadas numa entrada');
@define('PLUGIN_ENTRYLINKS_NEWWIN', 'Abrir numa nova janela?');
@define('PLUGIN_ENTRYLINKS_NEWWIN_BLAHBLAH', 'Devem as liga��es abrir numa nova janela? (Por omiss�o: janela corrente.');
@define('PLUGIN_ENTRYLINKS_REFERERS', 'Liga��es referentes');
@define('PLUGIN_ENTRYLINKS_WORDWRAP', 'Dobras de linhas');
@define('PLUGIN_ENTRYLINKS_WORDWRAP_BLAHBLAH', 'Quantas palavras at� uma dobra de linha? Valor por omiss�o: 30');
@define('PLUGIN_ENTRYLINKS_MAXREF', 'N�mero m�ximo de liga��es referentes');
@define('PLUGIN_ENTRYLINKS_MAXREF_BLAHBLAH', 'Quantas liga��es referentes devem ser mostradas? Valor por omiss�o: 15');
@define('PLUGIN_ENTRYLINKS_ORDERBY', 'Ordem das liga��es');
@define('PLUGIN_ENTRYLINKS_ORDERBY_BLAHBLAH', 'Qual crit�rio a usar para classificar as liga��es? Par omiss�o: o n�mero de liga��es.');
@define('PLUGIN_ENTRYLINKS_ORDERBY_DAY', 'Por data');
@define('PLUGIN_ENTRYLINKS_ORDERBY_FULLCOUNT', 'Por n�mero de liga��es');

/* vim: set sts=4 ts=4 expandtab : */
?>