<?php # $Id: lang_ja.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 Tadashi Jokagi <elf2000@users.sourceforge.net>           #
#                                                                        #
##########################################################################

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'ブラウザーの互換性');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', '異なる方法(CSS) を用いて最大限にブラウザーの互換性を強化します。');

?>
