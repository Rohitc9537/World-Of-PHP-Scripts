<?php # $Id: serendipity_event_browsercompatibility.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Browser-Kompatibilität');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Wendet verschiedene (CSS) Methoden an, um maximale Browserkompatibilität zu erreichen');
