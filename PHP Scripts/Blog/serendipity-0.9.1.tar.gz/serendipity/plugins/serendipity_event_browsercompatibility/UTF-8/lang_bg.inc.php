<?php # $Id: serendipity_event_browsercompatibility.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Съвместимост с браузърите');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Използване на различни (CSS) методи за осигуряване на максимална съвместимост с браузърите');
