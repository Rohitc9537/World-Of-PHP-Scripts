<?php # $Id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_CREATIVECOMMONS_NAME',        'CC 授權條款');
		@define('PLUGIN_CREATIVECOMMONS_DESC',        '請選擇適合您的網誌的授權條款');
        @define('PLUGIN_CREATIVECOMMONS_TXT',         '顯示文字？');
        @define('PLUGIN_CREATIVECOMMONS_TXT_DESC',    '為了能正確的傳達條款內容，請提供條款簡介。');
        @define('PLUGIN_CREATIVECOMMONS_CAP',         '原著作內容的版權是 <a href="#license_uri#">CC 授權條款</a>');
        @define('PLUGIN_CREATIVECOMMONS_CAP_PD',      '原著作內容使用的條款是 <a href="#license_url#}">公共領域</a>');
        // @define('PLUGIN_CREATIVECOMMONS_BY',          'Require attribution?');
        // @define('PLUGIN_CREATIVECOMMONS_BY_DESC',     'The licensor permits others to copy, distribute, display, and perform the work. In return, licensees must give the original author credit.');
        @define('PLUGIN_CREATIVECOMMONS_NC',          '允許商業用途？');
        @define('PLUGIN_CREATIVECOMMONS_NC_DESC',     '作者允許其他人複製，散佈，和展示他的作品。但不允許任何商業用途，除非得到允許。');
        @define('PLUGIN_CREATIVECOMMONS_ND',          '允許修改內容？');
        @define('PLUGIN_CREATIVECOMMONS_ND_DESC',     '作者允許其他人複製，散佈，和展示未修改的作品。');
        @define('PLUGIN_CREATIVECOMMONS_SA_DESC',     '允許，如果用途相同');
?>