<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P. Matos <jmatos@math.ist.utl.pt>                                 #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Agregador de dados dos plugins');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Mostra dados reunidos por um certo plugin de eventos.');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Plugin de acontecimento fonte');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Seleccione o plugin cujos dados devem ser mostrados');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Introduza o título deste elemento de barra lateral (deixar vazio para herdar o título do plugin de acontecimento)');

/* vim: set sts=4 ts=4 expandtab : */
?>