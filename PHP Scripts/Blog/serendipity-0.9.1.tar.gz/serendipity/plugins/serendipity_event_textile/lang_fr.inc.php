<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TEXTILE_NAME', 'Balises: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'Permet l\'utilisation de balises Textile dans le texte des billets');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', 'Syntaxe <a href="http://www.textism.com/tools/textile/">Textile</a> autoris�e');

/* vim: set sts=4 ts=4 expandtab : */
?>