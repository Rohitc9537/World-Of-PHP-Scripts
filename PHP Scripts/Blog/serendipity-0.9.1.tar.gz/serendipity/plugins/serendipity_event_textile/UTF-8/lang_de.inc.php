<?php # $Id: serendipity_event_textile.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_TEXTILE_NAME',     'Textformatierung: Textile');
        @define('PLUGIN_EVENT_TEXTILE_DESC',     'Textile-Formatierung durchführen');
        @define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">Textile</a>-Formatierung erlaubt');
