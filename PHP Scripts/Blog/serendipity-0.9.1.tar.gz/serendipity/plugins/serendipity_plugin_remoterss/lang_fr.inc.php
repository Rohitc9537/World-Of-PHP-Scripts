<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_REMOTERSS_TITLE', 'Fil RSS/OPML externe');
@define('PLUGIN_REMOTERSS_BLAHBLAH', 'Affiche les billets d\'un fil RSS/OPML externe (exemple: blogroll)');
@define('PLUGIN_REMOTERSS_NUMBER', 'Nombre de billets');
@define('PLUGIN_REMOTERSS_NUMBER_BLAHBLAH', 'D�finit le nombre de billets � afficher. (Par d�faut, tous les billets du fil)');
@define('PLUGIN_REMOTERSS_SIDEBARTITLE', 'Titre du fil');
@define('PLUGIN_REMOTERSS_SIDEBARTITLE_BLAHBLAH', 'Titre du fil dans la barre lat�rale');
@define('PLUGIN_REMOTERSS_RSSURI', 'Adresse du fil');
@define('PLUGIN_REMOTERSS_RSSURI_BLAHBLAH', 'D�finit l\'adresse du fil RSS/OPML � afficher');
@define('PLUGIN_REMOTERSS_NOURI', 'Pas de fil RSS/OPML s�lectionn�');
@define('PLUGIN_REMOTERSS_RSSTARGET', 'Cible des liens');
@define('PLUGIN_REMOTERSS_RSSTARGET_BLAHBLAH', 'Cible des liens aux billets affich�s. Valeur par d�faut: _blank');
@define('PLUGIN_REMOTERSS_CACHETIME', 'Intervalle de mise � jour');
@define('PLUGIN_REMOTERSS_CACHETIME_BLAHBLAH', 'Le contenu d\'un fil sont stock�s dans un ficher cache qui est actualis� toutes les X minutes. Valeur par d�faut: 3');
@define('PLUGIN_REMOTERSS_FEEDTYPE', 'Type de file');
@define('PLUGIN_REMOTERSS_FEEDTYPE_BLAHBLAH', 'Choisissez le format du fil');
@define('PLUGIN_REMOTERSS_BULLETIMG', 'Image titre');
@define('PLUGIN_REMOTERSS_BULLETIMG_BLAHBLAH', 'Image � afficher avec chaque titre.');
@define('PLUGIN_REMOTERSS_DISPLAYDATE', 'Afficher la date');
@define('PLUGIN_REMOTERSS_DISPLAYDATE_BLAHBLAH', 'Afficher la date du billet sous son titre?');

/* vim: set sts=4 ts=4 expandtab : */
?>