<?php # $Id: serendipity_event_xhtmlcleanup.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_XHTMLCLEANUP_NAME', '�bliche XHTML-Fehler beseitigen');
        @define('PLUGIN_EVENT_XHTMLCLEANUP_DESC', 'Korrigiert �bliche Fehler, die beim XHTML-Markup der Eintr�ge gemacht werden k�nnen');
