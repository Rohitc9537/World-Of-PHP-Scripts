<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_XHTMLCLEANUP_NAME', '일반적인 XHTML 에러 수정');
        @define('PLUGIN_EVENT_XHTMLCLEANUP_DESC', '글에서 자주 발생하는 XHTML 마크업 문제를 수정합니다. 블로그가 XHTML 규격을 따르게 하는데 도움을 줍니다.');

?>
