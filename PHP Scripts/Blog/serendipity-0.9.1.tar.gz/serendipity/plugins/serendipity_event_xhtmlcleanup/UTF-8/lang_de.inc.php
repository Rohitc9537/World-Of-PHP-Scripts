<?php # $Id: serendipity_event_xhtmlcleanup.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_XHTMLCLEANUP_NAME', 'Übliche XHTML-Fehler beseitigen');
        @define('PLUGIN_EVENT_XHTMLCLEANUP_DESC', 'Korrigiert übliche Fehler, die beim XHTML-Markup der Einträge gemacht werden können');
