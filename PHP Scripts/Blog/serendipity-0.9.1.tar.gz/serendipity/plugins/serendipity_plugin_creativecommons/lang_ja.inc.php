<?php # $Id: lang_ja.inc.php 511 2005-09-30 03:51:47Z elf2000 $

/**
 *  @version $Revision$
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 346
 */

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'クリエイティブコモンズ');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'サイドバーにクリエイティブコモンズを告示します。');

?>
