<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'Affiche un contrat Creative Commons dans la barre lat�rale.');

/* vim: set sts=4 ts=4 expandtab : */
?>