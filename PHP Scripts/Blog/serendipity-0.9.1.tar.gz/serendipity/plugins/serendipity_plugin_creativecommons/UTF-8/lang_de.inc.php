<?php # $Id: serendipity_plugin_creativecommons.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'Zeigt einen Creative Commons Hinweis an');
