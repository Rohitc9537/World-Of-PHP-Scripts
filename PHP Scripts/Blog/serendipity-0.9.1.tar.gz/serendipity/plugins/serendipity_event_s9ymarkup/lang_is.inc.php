<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textabreyting: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Virkja grunntextabreytingar � texta � f�rslum');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'A� setja texta innan stjarna gerir hann feitletra�an (*or�*), og til a� undirstrika setur ma�ur strik ni�ri � undan og eftir or�i (_or�_).');

/* vim: set sts=4 ts=4 expandtab : */
?>