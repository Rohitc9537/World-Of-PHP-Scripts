<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textabreyting: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Virkja grunntextabreytingar á texta í færslum');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Að setja texta innan stjarna gerir hann feitletraðan (*orð*), og til að undirstrika setur maður strik niðri á undan og eftir orði (_orð_).');

/* vim: set sts=4 ts=4 expandtab : */
?>