<?php # $Id: serendipity_event_s9ymarkup.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Текстово форматиране: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Прилага базово форматиране на текст');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Звездички означават bold (*текст*), подчертаване се прави с "_" (_текст_)');
