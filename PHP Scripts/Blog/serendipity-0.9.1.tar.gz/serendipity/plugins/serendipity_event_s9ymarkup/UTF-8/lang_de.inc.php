<?php # $Id: serendipity_event_s9ymarkup.php 235 2005-07-08 13:29:39Z garvinhicking $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textformatierung: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Standard Serendipity Textformatierung durchführen');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Umschließende Sterne heben ein Wort hervor (*wort*), per _wort_ kann ein Wort unterstrichen werden.');
