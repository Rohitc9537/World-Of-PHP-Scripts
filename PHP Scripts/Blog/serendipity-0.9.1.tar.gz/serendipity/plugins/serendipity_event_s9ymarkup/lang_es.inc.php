<?php # $Id: lang_es.inc.php,v 1.0 2005/08/20 11:37:42 garvinhicking Exp $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Rodrigo Lazo <rlazo.paz@gmail.com>
/* vim: set sts=4 ts=4 expandtab : */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Formato: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Aplica formato b�sico serendipity a la entrada de texto');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Encerrando entre asteriscos convierte el texto en negrita (*palabra*), el subrayado es hecho as�: _palabra_.');

?>