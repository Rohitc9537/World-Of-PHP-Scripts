<?php # $Id: lang_ko.inc.php,v 1.0 2005/06/29 13:41:13 garvinhicking Exp $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_COMMENTS_BLAHBLAH', '최근에 달린 덧글을 보여줌');
        @define('PLUGIN_COMMENTS_WORDWRAP', '자동 줄바꿈');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', '몇 글자 후에 자동 줄바꿈을 하겠습니까? (기본값: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', '덧글 당 최대 글자 수');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '각 덧글에 대해 최대 몇 글자를 보여주겠습니까? (기본값: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', '최대 덧글 수');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', '몇 개의 덧글을 보여주겠습니까? (기본값: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s 님이 %s 에 대해');

?>
