<?php # $Id: lang_is.inc.php 7 2005-04-16 06:39:31Z s_bergmann $

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'Sýnir síðustu athugasemdir á færslurnar þínar');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'Línuskil');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Hversu mörg orð þar til línuskil eiga sér stað? (Sjálfgefið gildi: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'Hámarksstafafjöldi á athugasemd');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Hversu margir stafir eiga að vera birtir fyrir hverja athugasemd? (Sjálfgefið gildi: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'Hámarksfjöldi athugasemda');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Hversu margar athugasemdir skal sýna? (Sjálfgefið gildi: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s um%s');
/* vim: set sts=4 ts=4 expandtab : */
?>