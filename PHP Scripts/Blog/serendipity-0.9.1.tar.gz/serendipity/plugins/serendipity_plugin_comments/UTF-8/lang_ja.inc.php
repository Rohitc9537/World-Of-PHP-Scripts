<?php

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'あなたのエントリへの最後のコメントを表示します。');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'ワードラップ');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'ワードラップするまでそれくらいの単語が現れますか? (デフォルト: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'コメントの最大文字数');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '各コメントで何文字位表示しますか? (デフォルト: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'コメントの最大数');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'どれくらいのコメントを表示しますか? (デフォルト: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s エントリ:%s');

?>
