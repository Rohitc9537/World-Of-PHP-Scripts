<?php # $Id: serendipity_plugin_comments.php 264 2005-07-13 16:59:13Z garvinhicking $

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'Zeigt die letzten Kommentare');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'Zeilenumbruch');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Nach wievielen Wörtern soll ein Zeilenumbruch eingefügt werden? (Standard: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'Zeichen pro Kommentar');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Wieviele Zeichen sollen pro Kommentar gezeigt werden? (Standard: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'Anzahl an Kommentaren');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Wieviele Kommentare sollen gezeigt werden? (Standard: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s zu%s');
