<?php 

   //Edit everything below to match your mySQL database configuration.

   //database host
   $db_host = "localhost"; 

   //database name
   $db_name = "database_name_here";

   //database user
   $db_user = "database_user_here"; 

   //database user password
   $db_pass = "database_user_password_here";  


   //Shoutbox Configuration

   //Message length limit (in characters)
   $max_length = 150;

   //Shoutbox message limit (Dont set this too high!)
   $dmessage = 20;

?> 
