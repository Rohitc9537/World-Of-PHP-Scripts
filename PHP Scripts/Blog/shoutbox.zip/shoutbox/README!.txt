--------------------------------------------------------------
- Shout It! By r2xDesign
- Website: www.r2xDesign.net
- Support: www.r2xdesign.net/forums
- Description: A simple shoutbox that you can use for your website.
--------------------------------------------------------------

INSTRUCTION:
1. Open up config.php and edit all variables in it.
2. - Open up create_table.txt and copy the SQL query.
    - You need to run this SQL query to the right database using phpMyAdmin or other SQL GUI you're using.
3. Upload the folder "shoutbox" in your MAIN site directory.
4. - Go to your www.yoursite.com/shoutbox/shoutbox.php to see the shoutbox
    - To include the shoutbox to your main site use this PHP code:

         <?php include("shoutbox/shoutbox.php"); ?> 
    
    Use the code above wherever you want to put your shoutbox.
5. You can edit the shoutbox looks by modifying the CSS internal style.
6. Please do not remove the link to r2xDesign.net, this is all I ask for! Thank You.

LATEST UPDATE:
- Added "posted date" on mouseover
- You can now customize the shoutbox message limit
- Much cleaner code

Subcribe to this script! http://www.r2xdesign.net/index.php?page=subscribe&id=5
View other scripts: http://www.r2xdesign.net/page-phpscripts.php