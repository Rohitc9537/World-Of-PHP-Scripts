aoblogger by Mike Helton (addicted one)
Version 1.5
Release Date: 9.22.05


***
Expected in version 2.0
__________________

Version 2.0 will have a login page for the admin account only to completely disable anyone else from creating the initial entries. It will still remain a very simple blog script. 

***


***
Changes since 1.0
__________________

Made the blog more secure than it was before. It is not virtually unhackable. I made the comment counting feature exact and removed 2 un-needed rows from the 'blog' table. Message and name minumum and maximum lengths have been set. The code is a lot cleaner. 

***



This blogger is free, all I ask is that you keep the comment in the header of the index.php file. It will not be visible to anyone. I only want it there so that I can see all of the sites using my script. 

To install, make a new database and enter the name, password, and user in the file "config.php", then run sql.sql on the database. If you are unsure how to do that, contact your webhost. 

Rename ppppp.php to something only you will know that way only you can post a new blog entry. After that, open config.php and change the part that says "ppppp.php" to the new name that you gave the file (including the .php) To post a new blog entry, run the newly renamed "ppppp.php" and you're set. 

Any questions or comments, email me mshelton@oakland.edu

I'll be glad to help.