<?php
	// Static loader for blog 'My first blog' (Blog created Created on June 6, 2005, 3:12 am
	$blog_id=1;
	include dirname(__FILE__)."/bmc/start.php";
?>