Cross-Browser Rich Text Editor adopted by boastMachine

Author:
-------
Vyacheslav Smolin (http://www.richarea.com, http://html2xhtml.richarea.com,
re@richarea.com)