

</div> <!-- end content //-->

</div> <!-- end main //-->

<div id="footer">
Powered by <a href="http://boastology.com" title="boastMachine :: powering the best blogs!">boastMachine <?php echo BMC_VERSION; ?></a>
</div> <!-- end footer //-->

</div> <!-- end wrap //-->
</body></html>