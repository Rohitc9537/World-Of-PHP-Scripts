

</div> <!-- end content //-->

</div> <!-- end main //-->

<div id="footer">
<a href="http://boastology.com" title="boastMachine :: Powering the best blogs!">boastMachine <?php echo BMC_VERSION; ?></a>
</div> <!-- end footer //-->
<div id="curve_bottom"></div>
</div> <!-- end wrap //-->
</body></html>