<strong><?php echo $lang['user_joined']." :".$date; ?></strong><br />
<a href="{$bmc_vars['site_url']}/profile.php?id=<?php echo $user['id']; ?>" title="<?php echo $user['user_name']; ?>"><?php echo $user['login']; ?></a>
<br /><br />
