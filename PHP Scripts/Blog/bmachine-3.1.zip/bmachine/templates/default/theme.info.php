<?php

// THIS THEME CONF FILE SHOULD BE PRESENT INSIDE A THEME
// DIR FOR boastMachine to DETECT!

$theme_name="Default"; // Theme's name

$theme_auth="Kailash Nadh"; // Author's name

$theme_mail="kailash@bnsoft.net"; // Author's email

$theme_site="http://bnsoft.net"; // Author's site


?>