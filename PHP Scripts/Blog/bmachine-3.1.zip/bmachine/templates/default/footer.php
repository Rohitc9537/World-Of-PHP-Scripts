
</div> <!-- end content //-->

</div> <!-- end container //-->
&nbsp;
</div> <!-- end main //-->
<div id="curve_bottom"></div> <!-- end curve_bottom //-->

<div id="footer">
Powered by <a href="http://boastology.com">boastMachine <?php echo BMC_VERSION; ?></a>
</div> <!-- end footer //-->

</div> <!-- end wrap //-->



<?php

	// Log the referer (3.1)
	include_once(CFG_ROOT."/reflog.php");

	// Users Online (3.1)
	include_once(CFG_ROOT."/users_online.php");

?>

</body>
</html>