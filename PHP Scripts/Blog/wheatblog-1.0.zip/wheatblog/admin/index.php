<?php
//
// File:    admin/index.php
// License: GNU GPL
// Purpose: Present admin form.
//
require('../settings.php');
$page_title = 'Administration';
include_once("$wb_inc_dir/header.php");

	insert_navigation();

include_once("$wb_inc_dir/footer.php");
?>
