<!-- include the footer -->

<?php 

	

  // wheatblog code: stop
?>
</div><!-- closes the main box -->
<div id="clear">
<?php insert_tagline(); ?>
</div><!-- clears the floatin' fuggers -->
</div> <!-- close container -->
</body>
</html>

<?php exit(0); ?>
