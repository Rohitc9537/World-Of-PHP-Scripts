Putting an image link between [IMG] and [/IMG] will produce an image.<br>
Putting a URL like this [URL=yoururl]titleof site[/URL] will produce a hyperlink