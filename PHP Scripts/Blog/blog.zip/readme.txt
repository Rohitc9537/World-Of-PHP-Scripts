*Thanks for PHPFREAKS.COM for help with the calendar code
*To use this script you must agree not to take any copyright links linking to chipmunk-scripts off any part of the script, failure to comply will result in loss of free liscense to use the script.
To install this script, you must have the following
1. Linux/Unix/FreeBSD OS
2. Apache webserver
3. PHP4.x/MYSQL 3.x or higher
5. GD library must be installed if you want to use the photo gallery

Steps:
----------------
modify admin/connect.php and put your mysql username, password, and database name where indicated
run install.php and install mysql tables, then delete install.php
run admin/register.php to register yourself an admin name and password then delete admin/register.php and admin/reguser.php
the admin login is at admin/login.php
To change colors and look of the blog, edit the admin/style.css file .
If you want to use the photo gallery, please chmod the photos and photos/thumbs folder to 777
Before using the custom right and left blocks I suggest you know some html and css
There is a header.php and footer.php, those are header and footers you can edit
Within the admin panel you will find all the options for your blog. Any questions please ask webmaster@java-gaming.com 
