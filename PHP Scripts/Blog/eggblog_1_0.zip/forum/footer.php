<?php
require_once("../_etc/footer.php");
?>