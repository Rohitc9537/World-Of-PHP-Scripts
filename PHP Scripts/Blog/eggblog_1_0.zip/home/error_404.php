<?php
require "../_etc/header.php";
echo "		<h2>HTTP 404 error</h2>
		<p><b>THis page cannot be found.</b></p>
		<p>Please <a href=\"javascript:history.go(-1)\">go back</a> and try again.</p>\n";
require "../_etc/footer.php";
?>