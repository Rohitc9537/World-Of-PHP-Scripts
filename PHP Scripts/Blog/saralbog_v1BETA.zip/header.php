<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>SaralBlog</title>
<style type="text/css">
body { font-family: Georgia, Times, Serif; font-weight: normal; font-size: 12px; }
#header { height: 117px; width: 740px; border: 1px solid #E7D0AD; background-image: url('header.gif'); background-position: 1px 1px; background-repeat: no-repeat; }
#inlink { height: 117px; width: 740px; }
#contentin { height: 117px; width: 690px; padding-left: 50px; padding-top: 20px }
#main { width: 740px; }
#content { width: 500px; margin-left: 1px; float: left; }
#menu { width: 240px; margin-left: 500px; text-align: right;}
#blogcontainer { margin-bottom: 5px; }
#blogtitle { font-size: 14px; color: #660000; font-weight: bold }
#blogfoot { font-size: 10px; text-align: right; }
input { border: 1px solid #000000; margin: 2px; }
#copyright { text-align: center; font-size: 8pt; width: 740px; position: absolute; }
.title { color: #CDCAB9; font-size: 24pt }
.title { text-decoration: none; color: #CDCAB9 }
</style>
</head>
<body>
<div id="header">
<div id="contentin">
<span class="title"><? echo $blogtitle; ?></span><br />
<small><? echo $blogdesc; ?></small>
</div>
</div>
<div id="main">
<div id="content">
<small><? echo $loginline; ?></small>


