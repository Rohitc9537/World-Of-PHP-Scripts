<?php
/***************************************************************************
 *   language/francais.php
 *
 *   copyright � 2004 Axel Achten / e-motionalis.net
 *   contact: thefiddler@e-motionalis.net
 *   this file is a part of the " e-moBLOG " weblog engine
 *
 *   This program is a free software. You can modify it as you wish, though
 *   we would just appreciate if you could keep the copyright notice on the
 *   pages (including the engine version and link)  even if you should feel
 *   free to add your own copyright if you modified and enhanced the code.
 *
 *   Please note though that, this software being copyrighted means that the
 *   whole code (or part of it) is.  You should thus not sell any version of
 *   this program, neither any modified version of it using part of the fol-
 *   lowing code. Moreover, please do not use it for commercial purposes.
 *
 *   IMPORTANT NOTE: if you ever happen to translate this file to a foreign
 *   language which is not included in the e-moBLOG releases yet, I would
 *   be very glad if you could send it to me along with your name and
 *   website URL, such as I can add it to the official e-moBLOG releases
 *   language files (credits with your name & website URL will be
 *   mentionned, of course). Thank you very much.
 *
 ***************************************************************************/

 
// installation
$lang['i_confirm'] = "<b>ceci va installer e-moBLOG sur votre serveur.</b><br />soyez s�rs d'avoir bien �dit� le fichier /includes/db.php avant<br />comme indiqu� dans le fichier \"how-to.txt\".";
$lang['i_proceed'] = "continuer";
$lang['i_cancel'] = "si vous ne voulez pas continuer, veuillez simplement fermer cette fen�tre.";
$lang['i_done'] = "f�licitations, l'installation est termin�e.<br />merci d'avoir choisi e-moBLOG!<br /><br />tenez-vous au courant des mises � jours:";
$lang['i_link'] = "http://www.e-motionalis.net";
$lang['i_admin'] = "vous pouvez maintenant acc�der � votre panneau de contr�le � l'adresse suivante:";

// configuration
$lang['c_loginoptions'] = "informations d'acc�s administrateur";
$lang['c_general'] = "configuration g�n�rale";
$lang['c_options'] = "options diverses";
$lang['c_login'] = "nom d'utilisateur:";
$lang['c_password'] = "mot de passe:";
$lang['c_confirmpass'] = "confirmation du mot de passe:";
$lang['c_bname'] = "nom du blog:";
$lang['c_bname_desc'] = "ceci est le nom de votre blog - il appara�tra dans la barre de titre du navigateur.";
$lang['c_burl'] = "URL du blog:";
$lang['c_burl_desc'] = "ceci est l'URL compl�te de votre blog, avec le slash de fin - le fichier index.php doit se trouver � cette URL - exemple: http://www.mondomaine.com/monaccompte/blog/";
$lang['c_aname'] = "nom du propri�taire:";
$lang['c_aname_desc'] = "ceci est le nom du propri�taire de ce blog.";
$lang['c_aemail'] = "e-mail du propri�taire:";
$lang['c_aemail_desc'] = "ceci est l'adresse e-mail du propri�taire de ce blog - c'est �galement l'adresse � laquelle les commentaires seront envoy�s s'il n'y a qu'un auteur � ce blog et si vous choisissez de recevoir les commentaires des visiteurs par e-mail (voir les options plus bas).";
$lang['c_bdesc'] = "description du blog:";
$lang['c_bdesc_desc'] = "ceci est la description de ce blog telle qu'elle appara�tra dans les meta-tags (et donc dans les moteurs de recherche).";
$lang['c_bkeys'] = "mots cl�s du blog:";
$lang['c_bkeys_desc'] = "mettez ici les mots cl�s de votre blog tels qu'ils seront utilis�s par les moteurs de recherche - separez chaque mot par une virgule.";
$lang['c_comments'] = "syst�me de commentaire:";
$lang['c_comments_desc'] = "d�termine la mani�re dont les commentaires seront trait�s (defaut = sur la page).";
$lang['c_center'] = "alignement du blog:";
$lang['c_center_desc'] = "ceci d�termine si votre blog est align� � gauche ou centr� (defaut = � gauche).";
$lang['c_center_0'] = "� gauche";
$lang['c_center_1'] = "centr�";
$lang['c_poster'] = "auteurs multiples:";
$lang['c_poster_desc'] = "d�termine si vous �tes le seul auteur de ce blog ou s'il y en a plusieurs (defaut = auteur unique).";
$lang['c_smileys'] = "smileys:";
$lang['c_smileys_desc'] = "d�termine la mani�re de traiter les smileys dans les messages (articles et commentaires), si l'option \"sur la page\" est choisie (defaut = standard).";
$lang['c_language'] = "langue:";
$lang['c_language_desc'] = "d�termine la langue de ce blog (defaut = english).";
$lang['c_limit'] = "limite du nombre d'articles:";
$lang['c_limit_desc'] = "entrez un nombre si vous souhaitez limiter le nombre d'articles affich�s sur le blog - par exemple, si vous r�glez cette option sur 3, la page principale du blog n'affichera que les 3 derniers articles post�s, tous les autres �tant disponibles via les archives - r�glez ceci � 0 si vous d�sirez afficher tous les articles post�s pour le mois en cours (defaut = 0).";
$lang['c_maxwidth'] = "largeur:";
$lang['c_maxwidth_desc'] = "d�termine la largeur de ce blog - la valeur par d�faut est 400, ce qui signifie 400 pixels de large (defaut = 400 / minimum = 270).";
$lang['c_servertime'] = "d�callage du serveur:";
$lang['c_servertime_desc'] = "r�glez ceci sur le d�calage horaire de votre serveur par rapport � votre situation g�ographique si vous voulez que les dates et heures soient affich�es correctement - par exemple, si votre serveur est � NY et que vous habitez � Paris, la valeur de d�calage est -06 (au contraire, si vous habitez � NY et que votre serveur se situe � Paris, le d�calage horaire du serveur sera de +06 - n'oubliez pas le signe - ou +, c'est important!).";
$lang['c_setbutton'] = "appliquer";
$lang['c_cancelbutton'] = "annuler";
$lang['c_comments_0'] = "sans";
$lang['c_comments_1'] = "sur la page";
$lang['c_comments_2'] = "envoy�s par mail";
$lang['c_smileys_0'] = "standard";
$lang['c_smileys_1'] = "images";
$lang['c_smileys_2'] = "sans smileys";
$lang['c_poster_0'] = "auteur unique";
$lang['c_poster_1'] = "auteurs multiples";
$lang['c_moblogging'] = "options mobile blogging";
$lang['c_moblogging_state'] = "mobile blogging";
$lang['c_moblogging_desc'] = "le mobile blogging vous permets de poster un message sur votre blog depuis un p�riph�rique portable, tel un t�l�phone portable ou un PocketPC. Le principe consiste � envoyer un message de votre p�riph�rique portable vers une adresse e-mail dont les nouveaux messages vont �tre v�rifi�s par le syst�me e-moBLOG. Notez que ceci pourrait ralentir quelque peu votre blog de temps � autre, selon la vitesse de r�ponse du serveur mail o� se trouve l'adresse � v�rifier. Veuillez lire le fichier HOW-TO.txt *tr�s attentivement* avant d'utiliser cette option (defaut = d�sactiv�).";
$lang['c_moblogging_0'] = "d�sactiv�";
$lang['c_moblogging_1'] = "activ�";
$lang['c_mserver'] = "serveur e-mail";
$lang['c_mserver_desc'] = "ceci est l'adresse du serveur mail � utiliser pour le mobile blogging. Attention, vous devez utiliser une adresse e-mail qui ne servira *que* au mobile blogging, car tout message envoy� � cette adresse sera v�rifi�, affich� sur le blog, et d�finitivement effac� du serveur.";
$lang['c_mport'] = "port du serveur e-mail";
$lang['c_mport_desc'] = "ceci est le port de connexion au serveur mail pr�cis� ci-dessus (defaut = 110).";
$lang['c_mtype'] = "type de boite e-mail";
$lang['c_mtype_0'] = "pop3";
$lang['c_mtype_1'] = "imap";
$lang['c_mtype_desc'] = "ceci est le type de boite e-mail utilis�. Si votre boite mail ne supporte aucun de ces deux protocoles, le mobile blogging ne marchera pas (defaut = pop3).";
$lang['c_mlogin'] = "nom d'utilisateur de la boite e-mail";
$lang['c_mlogin_desc'] = "ceci est le nom d'utilisateur complet n�cessaire pour la connexion � votre boite mail d�di�e au mobile blogging.";
$lang['c_mpassword'] = "mot de passe de la boite e-mail";
$lang['c_mpassword_desc'] = "ceci est le mot de passe � utiliser pour la connexion � votre boite mail d�di�e au mobile blogging.";
$lang['c_resize'] = "redimensionnement automatique";
$lang['c_resize_desc'] = "determine si les images seront redimensionn�es automatiquement ou pas. R�glez ceci � \"activ�\" si vous voulez que toutes les images contenues dans vos articles soient r�tr�cies � la largeur maximum de votre blog (valeur sp�cif�e ci-dessous) lorsqu'elles d�passent cette valeur (defaut = activ�).";
$lang['c_absolute'] = "chemin absolu du blog";
$lang['c_absolute_desc'] = "ceci est le chemin absolu du r�pertoire source de votre blog. Veillez � include le signe \"/\" � la fin. (par ex.  /home/votredomaine/public_html/votreblog/  -ceci est un exemple, si vous n'�tes pas s�r, demandez ce renseignement � votre administrateur syst�me ou � votre support technique).";

// admin pages
$lang['a_name'] = "nom de l'auteur:";
$lang['a_email'] = "e-mail de l'auteur:";
$lang['a_title'] = "titre de l'article:";
$lang['a_content'] = "contenu:";
$lang['a_audio'] = "chanson du jour:";
$lang['a_quote'] = "citation du jour:";
$lang['a_postbutton'] = "ajouter";
$lang['a_updatebutton'] = "mettre � jour";
$lang['a_clearbutton'] = "effacer";
$lang['a_addpost'] = "ajouter un article";
$lang['a_modtodaypost'] = "ajouter au dernier article";
$lang['a_editpost'] = "modifier un article";
$lang['a_config'] = "options";
$lang['a_addline'] = "ligne";
$lang['a_postsfrom'] = "articles de";
$lang['a_delete'] = "effacer";
$lang['a_edit'] = "modifier";
$lang['a_delconfirm'] = "voulez-vous vraiment effacer cet article?";
$lang['a_delcommconfirm'] = "voulez-vous vraiment effacer ce commentaire?";
$lang['a_logout'] = "d�connexion";
$lang['a_ccontent'] = "commentaire";
$lang['a_editcomment'] = "modifier commentaire";
$lang['a_updatecbutton'] = "modifier";
$lang['a_addimage'] = "ajouter/modifier image";
$lang['a_url'] = "url de l'image";
$lang['a_descr'] = "description";
$lang['a_delimgconfirm'] = "voulez-vous vraiment effacer cette image?";
$lang['saveimages'] = "ajout des images dans la gallerie?";

// mots � usage g�n�ral
$lang['top'] = "haut";
$lang['link'] = "lier cet article";
$lang['index'] = "index";
$lang['required'] = "note: les champs marqu�s d'une * sont obligatoires.";
$lang['no_posts'] = "il n'y a encore aucun article ce mois-ci.";
$lang['rss'] = "rss";
$lang['search'] = "recherche";
$lang['search_posts'] = "chercher dans les articles";
$lang['numpages'] = "il y a d'autres articles trouv�s:";
$lang['page'] = "page";
$lang['gallery'] = "gallerie";
$lang['frompost'] = "provenant de";
$lang['no_images'] = "il n'y a pas d'images.";
$lang['numimages'] = "tri�es par date - plus d'images:";
$lang['noresults'] = "aucun article trouv�.";
$lang['visitor'] = "personne �gar�e sur ce blog";
$lang['visitors'] = "personnes lisant ce blog";
$lang['powered'] = "powered by";

// commentaires
$lang['comment'] = "commentaire";
$lang['comments'] = "commentaires";
$lang['posted_by'] = "post� par";
$lang['no_comments'] = "il n'y a encore aucun commentaire sur cet article.";
$lang['post'] = "POSTER UN COMMENTAIRE";
$lang['uname'] = "votre nom";
$lang['uemail'] = "votre e-mail";
$lang['ucomment'] = "votre commentaire";
$lang['post_button'] = "poster";
$lang['clear_button'] = "effacer";
$lang['postip'] = "IP";
$lang['delcomm'] = "effacer ce commentaire";

// erreurs
$lang['error'] = "erreur: ";
$lang['pic_format'] = "format non-support�.";
$lang['pic_gif'] = "format GIF non support�.";
$lang['field_error'] = "veuillez remplir les champs nom et commentaire.";
$lang['field2_error'] = "veuillez compl�ter tous les champs.";
$lang['pass_error'] = "les mots de passe entr�s ne correspondent pas.";
$lang['email_error'] = "veuillez entrer une adresse e-mail valide.";

// confirmations
$lang['add_status'] = "<b>le nouveau message a �t� ajout�.</b>";
$lang['mod_status'] = "<b>le message a �t� modifi�.</b>";
$lang['del_status'] = "<b>le message a �t� effac�.</b>";
$lang['delcomm_status'] = "<b>le commentaire a �t� effac�.</b>";
$lang['conf_status'] = "<b>la configuration a �t� mise � jour.</b>";
$lang['modc_status'] = "<b>le commentaire a �t� modifi�.</b>";

// commentaires envoy�s par mail
$lang['mailcomment'] = "envoyer un commentaire";
$lang['mailsubject'] = "[commentaire envoy� par e-moBLOG]";
$lang['mailfrom'] = "envoy� par";
$lang['mailaddress'] = "adresse e-mail";
$lang['mailarticle'] = "concernant l'article";
$lang['email_sent'] = "votre commentaire a �t� envoy�. merci!";

// archives
$lang['archives'] = "archives";
$lang['archivesfrom'] = "archives de";
$lang['links'] = "archives des liens";
$lang['all_links'] = "tous les liens post�s";
$lang['no_links'] = "il n'y a encore aucun lien post� ce mois-ci.";

// aide
$lang['help'] = "aide";
$lang['helpfile1'] = " Vous <b>devez</b> au moins remplir les champs nom et commentaire. Le champ e-mail n'est pas obligatoire.";
$lang['helpfile2'] = " Les balises HTML ne sont pas accept�es, mais vous pouvez utiliser certaines balises UBB.";
$lang['helpfile3'] = " Voici une liste des balises UBB qui peuvent �tre utilis�es, avec leur fonctionnement:";
$lang['help_bius'] = "les balises [b] [i] [s] et [u] peuvent �tre respectivement utilis�es pour mettre un texte ou une portion de celui-ci en <b>gras</b>, <i>italique</i>, <s>barr�</s> et <u>soulign�</u>.<br /> Exemple: [b]<b>texte en gras</b>[/b]";
$lang['help_center'] = "la balise [center] peut �tre utilis�e pour centrer un texte ou une image sur le blog.<br /> Exemple: [center]votre texte ou image[/center]";
$lang['help_url'] = "la balise [url=...] peut �tre utilis�e pour faire un lien vers une URL.<br /> Exemple: [url=http://www.mondomaine.com]ceci est un lien[/url] (Voir la note plus bas)";
$lang['help_img'] = "la balise [img] peut �tre utilis�e pour afficher une image dans votre commentaire. Les formats d'image valides sont le JPG et le PNG. Le format GIF n'est <b>pas</b> support� et ne sera pas affich�.<br /> Exemple: [img]http://www.mondomaine.com/monimage.jpg[/img]";
$lang['help_note'] = " <u>Note:</u> Toute adresse e-mail ou URL que vous �crivez dans votre commentaire sera automatiquement format�e en un lien vers cette m�me adresse e-mail ou URL. Vous ne devez employer aucune balise pour cela. Veuillez aussi ne pas utiliser de caract�res d'espacement dans les URL."; 

// admin help
$lang['a_help'] = "aide";
$lang['a_helpfile1'] = " Les champs obligatoires sont toujours marqu�s d'une *";
$lang['a_helpfile2'] = " Les balises HTML ne sont pas accept�es, mais vous pouvez utiliser certaines balises UBB.";
$lang['a_helpfile3'] = " Voici une liste des balises UBB qui peuvent �tre utilis�es, avec leur fonctionnement:";
$lang['a_help_bius'] = "les balises [b] [i] [s] et [u] peuvent �tre respectivement utilis�es pour mettre un texte ou une portion de celui-ci en <b>gras</b>, <i>italique</i>, <s>barr�</s> et <u>soulign�</u>.<br /> Exemple: [b]<b>texte en gras</b>[/b]";
$lang['a_help_center'] = "la balise [center] peut �tre utilis�e pour centrer un texte ou une image sur le blog.<br /> Exemple: [center]votre texte ou image[/center]";
$lang['a_help_url'] = "la balise [url=...] peut �tre utilis�e pour faire un lien vers une URL.<br /> Exemple: [url=http://www.mondomaine.com]ceci est un lien[/url] (Voir la note plus bas)";
$lang['a_help_img'] = "la balise [img] peut �tre utilis�e pour afficher une image dans votre commentaire. Les formats d'image valides sont le JPG et le PNG. Le format GIF n'est <b>pas</b> support� et ne sera pas affich�. Veuillez noter que les images plus larges que la largeur maximale sp�cifi�e dans la configuration de ce blog seront automatiquement redimensionn�es, mais ceci peut n�cessiter beaucoup de ressources au niveau du serveur, c'est pourquoi nous vous recommandons de redimensioner vous-m�me vos images autant que possible, avant de les poster.<br /> Exemple: [img]http://www.mondomaine.com/monimage.jpg[/img]<br /> Example: [img]http://www.mydomain.com/mypicture.jpg[/img]<br /><br />Vous pouvez �galement aligner l'image � droite ou � gauche de votre texte en utilisant les balises [img left] ou [img right] au lieu de simplement [img]. Notez que si l'option d'auto-redimensionnement des images est activ�e et que vous postez une image plus large que la largeur maximale du blog, il est pr�f�rable d'utiliser la balise [img].";
$lang['a_help_note'] = " <u>Note:</u> Toute adresse e-mail ou URL que vous �crivez dans votre commentaire sera automatiquement format�e en un lien vers cette m�me adresse e-mail ou URL. Vous ne devez employer aucune balise pour cela. Veuillez aussi ne pas utiliser de caract�res d'espacement dans les URL.";

// abr�viations des mois de l'ann�e
$lang['jan'] = "jan";
$lang['feb'] = "fev";
$lang['mar'] = "mar";
$lang['apr'] = "avr";
$lang['may'] = "mai";
$lang['june'] = "juin";
$lang['july'] = "juil";
$lang['aug'] = "ao�t";
$lang['sep'] = "sep";
$lang['oct'] = "oct";
$lang['nov'] = "nov";
$lang['dec'] = "d�c";

// noms complets des mois de l'ann�e
$lang['jan1'] = "janvier";
$lang['feb1'] = "f�vrier";
$lang['mar1'] = "mars";
$lang['apr1'] = "avril";
$lang['may1'] = "mai";
$lang['june1'] = "juin";
$lang['july1'] = "juillet";
$lang['aug1'] = "ao�t";
$lang['sep1'] = "septembre";
$lang['oct1'] = "octobre";
$lang['nov1'] = "novembre";
$lang['dec1'] = "d�cembre";
?>