<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');

	if(isset($_REQUEST['id']) && $_REQUEST['id'] != '' && !array_key_exists('text', $_REQUEST)) {
		
		$id = intval($_REQUEST['id']);

		require('inc/config.php');
		require('inc/mysql.php');
		
		$query = 'SELECT UNIX_TIMESTAMP(date_created) AS date_created, topic, text, category_id, ping_url, draft FROM ' . $conf_mysql_prefix . 'data WHERE id=\'' . $id . '\' LIMIT 1';
		
		$q = mysql_query($query);
		$r = mysql_fetch_assoc($q);
		
		mysql_close();
		
		$topic			= sStripSlashes($r['topic']);
		$text				= sStripSlashes($r['text']);
		$category_id	= intval($r['category_id']);
		$date_created	= date('YmdHis', $r['date_created']);
		$date_modified = date('YmdHis', time());
		$ping				= 0;
		$ping_url		= sStripSlashes($r['ping_url']);
		$silent			= 1;
		$draft			= intval($r['draft']);
	}
	else if(array_key_exists('text', $_POST)) {
		if(array_key_exists('id', $_POST)) {
			$id = intval($_POST['id']);
		}
		else {
			$id = null;
		}
		
		$topic			= sStripSlashes($_POST['topic']);
		$text				= sStripSlashes($_POST['text']);
		$category_id 	= intval($_POST['category_id']);
		
		if(strlen($_POST['date_created']) == 14) {
			$date_created = $_POST['date_created'];
		}
		else {
			$date_created = date('YmdHis');
		}
		
		if(array_key_exists('silent', $_POST)) {
			$silent = 1;
			$date_modified = $date_created;
		}
		else {
			$silent = 0;
			$date_modified = date('YmdHis', time());
		}
		
		if(array_key_exists('ping', $_POST) && intval($_POST['ping']) > 0) {
			$ping = intval($_POST['ping']);
		}
		else {
			$ping = null;
		}
		
		if(array_key_exists('ping_url', $_POST) && strlen($_POST['ping_url']) > 0) {
			$ping_url = 1;
		}
		else {
			$ping_url = null;
		}
		
		if(array_key_exists('draft', $_POST) && intval($_POST['draft']) > 0) {
			$draft = 1;
		}
		else {
			$draft = null;
		}
	}
	else {
		$id				= null;
		$topic			= null;
		$text				= null;
		$category_id	= 1;
		$date_created	= null;
		$date_modified = null;
		$silent			= 1;
		$ping				= 0;
		$ping_url		= null;
	}

	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	ob_start();

?>
	<!-- EDIT -->
<?php

	if(array_key_exists('topic', $_REQUEST)) {
		
		require('inc/mysql.php');
		require('inc/sRenderPost.php');
		
		if(!function_exists('truncate')) {
			require('inc/func_truncate.php');
		}
		
		$queryCategory = 'SELECT category FROM ' . $conf_mysql_prefix . 'categories WHERE id=\'' . $category_id . '\' LIMIT 1';
		$qCategory = mysql_query($queryCategory);
		$nCategory = mysql_num_rows($qCategory);
		
		if($nCategory > 0) {
			$rCategory = mysql_fetch_assoc($qCategory);
			$category = $rCategory['category'];
		}
		else {
			$category = lang('Uncategorized');
		}
		
		echo "\t\t" . '<div class="sblog_post">' . "\n";
		echo "\t\t\t" . '<div style="background-color: #FEE; color: #F00; font-weight: bold; text-align: center; padding: 10px; border: 2px #F00 solid;">' . lang('This is a preview. Your changes has not been saved yet!') . '</div>' . "\n";
		echo "\t\t" . '</div>' . "\n";

		sRenderPost($id, $category_id, $category, mktime(substr($date_created, 8, 2), substr($date_created, 10, 2), substr($date_created, 12, 2), substr($date_created, 4, 2), substr($date_created, 6, 2), substr($date_created, 0, 4)), mktime(substr($date_modified, 8, 2), substr($date_modified, 10, 2), substr($date_modified, 12, 2), substr($date_modified, 4, 2), substr($date_modified, 6, 2), substr($date_modified, 0, 4)), $topic, $text);
		
		mysql_close();

	}

?>
			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Create post'); ?></h1>
			</div>
			<div class="sblog_post_text">
			<form id="edit" method="post" action="edit_do.php">
				<div>
					<input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='index.php';return false" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Preview'); ?>" tabindex="3" accesskey="p" onclick="document.getElementById('edit').action='<?php echo $_SERVER['PHP_SELF']; ?>'" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Draft'); ?>" onclick="javascript:document.getElementById('draft').value=1;submit();" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Publish'); ?>" tabindex="4" accesskey="s" onclick="javascript:document.getElementById('draft').value=0;document.getElementById('edit').action='edit_do.php'" class="sblog_button" /><br /><br />
				</div>
				<fieldset>
					<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
					<input type="hidden" name="ref" id="ref" value="<?php echo $_SERVER['PHP_SELF']; ?>" />
					<input type="hidden" name="date_created" id="date_created" value="<?php echo $date_created; ?>" />
					<legend><?php echo lang('Category'); ?></legend>
					<select name="category_id" id="category_id">
						<option value="1">&laquo; <?php echo lang('Uncategorized'); ?> &raquo;</option>
<?php

	require('inc/mysql.php');

	$queryCategories = 'SELECT id, category FROM ' . $conf_mysql_prefix . 'categories WHERE id!=\'1\' ORDER BY category ASC';
	$qCategories = mysql_query($queryCategories);
	
	while($rCategories = mysql_fetch_assoc($qCategories)) {
		if($category_id == $rCategories['id']) {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
		
		echo "\t\t\t\t\t\t" . '<option value="' . $rCategories['id'] . '"' . $selected . '>' . htmlspecialchars($rCategories['category']) . '</option>' . "\n";
	}
	
?>
					</select>
					<input type="reset" value="<?php echo lang('Add new category'); ?>" onclick="javascript:document.getElementById('edit').action='categories.php';submit();" class="sblog_button" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Images'); ?></legend>
					<select name="image" id="image" onchange="javascript:document.getElementById('text').value+='[img]' + this.options[selectedIndex].value + '[/img]';" class="sblog_input">
						<option value=""></option>
<?php

	$dir_name = null;
	$queryImages = 'SELECT i.filename, d.dir_name FROM ' . $conf_mysql_prefix . 'img AS i, ' . $conf_mysql_prefix . 'img_dir AS d WHERE i.dir_id=d.id ORDER by d.dir_name ASC, i.filename ASC';
	$qImages = mysql_query($queryImages);

	while($rImages = mysql_fetch_assoc($qImages)) {
		if($rImages['dir_name'] != $dir_name) {
			if($dir_name != null) {
				echo "\t\t\t\t\t\t" . '</optgroup>' . "\n";
			}
			echo "\t\t\t\t\t\t" . '<optgroup label="' . htmlspecialchars($rImages['dir_name']) . '">' . "\n";
		}

		echo "\t\t\t\t\t\t" . '<option value="upload/' . rawurlencode($rImages['filename']) . '">' . $rImages['filename'] . '</option>' . "\n";

		$dir_name = $rImages['dir_name'];
	}
	
	echo "\t\t\t\t\t\t" . '</optgroup>' . "\n";

?>
					</select>
					<input type="submit" value="<?php echo lang('Upload image'); ?>" onclick="javascript:document.getElementById('edit').action='image_ul.php';submit();" class="sblog_button" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Topic'); ?></legend>
					<input type="text" name="topic" id="topic" size="40" value="<?php echo htmlspecialchars($topic); ?>" tabindex="1" class="sblog_input" />
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Text'); ?></legend>
					<script type="text/javascript">edToolbar();</script><br />
					<a href="http://servous.se/doc/using/bbcode" rel="external" title="<?php echo lang('Syntax'); ?>" class="sblog_external"><?php echo lang('Syntax'); ?></a>
					<textarea name="text" id="text" tabindex="2" cols="40" rows="10" class="sblog_text"><?php echo htmlspecialchars($text); ?></textarea><br />
<?php

	if(isset($silent) && $silent == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<label for="silent"><input type="checkbox" name="silent" id="silent" value="1"<?php echo $checked; ?> /> <?php echo lang('Silent edit'); ?></label>
					<input type="hidden" name="draft" id="draft" value="0" />
					<script type="text/javascript">var edCanvas = document.getElementById('text');</script> 
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Smilies'); ?></legend>
					<a href="#" title=":)" onclick="javascript:document.getElementById('text').value+=':)';return false"><img src="img/smilies/smile.png" alt=":)" /></a>
					<a href="#" title=":|" onclick="javascript:document.getElementById('text').value+=':|';return false"><img src="img/smilies/neutral.png" alt=":|" /></a>
					<a href="#" title=":(" onclick="javascript:document.getElementById('text').value+=':(';return false"><img src="img/smilies/sad.png" alt=":(" /></a>
					<a href="#" title=":D" onclick="javascript:document.getElementById('text').value+=':D';return false"><img src="img/smilies/big_smile.png" alt=":D" /></a>
					<a href="#" title=":o" onclick="javascript:document.getElementById('text').value+=':o';return false"><img src="img/smilies/yikes.png" alt=":o" /></a>
					<a href="#" title=";)" onclick="javascript:document.getElementById('text').value+=';)';return false"><img src="img/smilies/wink.png" alt=";)" /></a>
					<a href="#" title="=/" onclick="javascript:document.getElementById('text').value+='=/';return false"><img src="img/smilies/hmm.png" alt="=/" /></a>
					<a href="#" title=":P" onclick="javascript:document.getElementById('text').value+=':P';return false"><img src="img/smilies/tongue.png" alt=":P" /></a>
					<a href="#" title=":lol:" onclick="javascript:document.getElementById('text').value+=':lol:';return false"><img src="img/smilies/lol.png" alt=":lol:" /></a>
					<a href="#" title=":mad:" onclick="javascript:document.getElementById('text').value+=':mad:';return false"><img src="img/smilies/mad.png" alt=":mad:" /></a>
					<a href="#" title=":roll:" onclick="javascript:document.getElementById('text').value+=':roll:';return false"><img src="img/smilies/roll.png" alt=":roll:" /></a>
					<a href="#" title=":cool:" onclick="javascript:document.getElementById('text').value+=':cool:';return false"><img src="img/smilies/cool.png" alt=":cool:" /></a>
				</fieldset>
				<fieldset>
					<legend><?php echo lang('Trackback ping'); ?></legend>
<?php

	if(isset($ping) && $ping == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
					<label for="ping"><input type="checkbox" name="ping" id="ping" value="1"<?php echo $checked; ?> /> <?php echo lang('Send trackback pings to the following URLs (one URL per row)'); ?>:</label><br /><br />
					<textarea name="ping_url" id="ping_url" rows="4" cols="40" class="sblog_text" style="height: 50px;"><?php echo $ping_url; ?></textarea>
				</fieldset>
				<div>
					<br /><input type="button" value="<?php echo lang('Cancel'); ?>" onclick="javascript:location.href='index.php';return false" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Preview'); ?>" tabindex="3" accesskey="p" onclick="document.getElementById('edit').action='<?php echo $_SERVER['PHP_SELF']; ?>'" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Draft'); ?>" onclick="javascript:document.getElementById('draft').value=1;submit();" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Publish'); ?>" tabindex="4" accesskey="s" onclick="javascript:document.getElementById('draft').value=0;document.getElementById('edit').action='edit_do.php'" class="sblog_button" /><br /><br />
				</div>
			</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>

			<script type="text/javascript">document.getElementById('topic').focus();</script>

<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();

	require('inc/tpl_foot.php');
	
	mysql_close();
	
	echo $tpl_main;

?>