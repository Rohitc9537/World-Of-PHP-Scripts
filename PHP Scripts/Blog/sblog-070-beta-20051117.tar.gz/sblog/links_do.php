<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/mysql.php');

	$link_title		= mysql_real_escape_string($_REQUEST['link_title']);
	$link_url		= mysql_real_escape_string(str_replace('http://', '', $_REQUEST['link_url']));
	
	if($link_title != '' && $link_url != '') {
		
		if(array_key_exists('id', $_POST) && intval($_POST['id']) > 0) {
			$id = intval($_POST['id']);
			$query = 'UPDATE ' . $conf_mysql_prefix . 'links SET link_title=\'' . $link_title . '\', link_url=\'' . $link_url . '\' WHERE id=\'' . $id . '\' LIMIT 1';
		}
		else {
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'links SET date_created=NOW(), link_title=\'' . $link_title . '\', link_url=\'' . $link_url . '\'';
		}
		
		mysql_query($query);
	}

	mysql_close();	
	header('Location: links.php');
	exit;

?>