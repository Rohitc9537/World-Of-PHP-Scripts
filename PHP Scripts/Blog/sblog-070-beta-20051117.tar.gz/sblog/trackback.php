<?php

	require('inc/config.php');

	if(isset($conf_trackback_act) && $conf_trackback_act == 0) {
		header('HTTP/1.1 404 Not Found');
		exit;
	}

	require('inc/mysql.php');	
	require('inc/sRewrite.php');

	if(array_key_exists('blog_id', $_REQUEST)) {
		$blog_id = intval($_REQUEST['blog_id']);
	}
	else {
		$blog_id = 0;
	}

	if(array_key_exists('url', $_REQUEST) && strlen(str_replace('http://', '', $_REQUEST['url'])) > 12 && $blog_id > 0) {
		// verify 'title'		
		if(array_key_exists('title', $_REQUEST)) {
			$title = $_REQUEST['title'];
			
			if(strlen($_REQUEST['title']) > 255) {
				$title = substr($title, 0, 252) . '...'; // max 255 chars
			}
		}
		else {
			$title = null;
		}
	
		// verify 'excerpt'
		if(array_key_exists('excerpt', $_REQUEST)) {
			$excerpt = $_REQUEST['excerpt'];
			
			if(strlen($excerpt) > 255) {
				$excerpt = substr($excerpt, 0, 252) . '...'; // max 255 chars
			}
		}
		else {
			$excerpt = null;
		}
	
		// verify 'url'
		if(array_key_exists('url', $_REQUEST)) {
			$url = 'http://' . str_replace('http://', '', $_REQUEST['url']); // no limit
		}
		else {
			$url = null;
		}
	
		// verify 'blog_name'
		if(array_key_exists('blog_name', $_REQUEST)) {
			$blog_name = $_REQUEST['blog_name'];
			
			if(strlen($blog_name) > 255) {
				$blog_name = substr($blog_name, 0, 252) . '...'; // max 255 chars
			}
		}
		else {
			$blog_name = null;
		}
	
		if($blog_id > 0 && strlen($url) > 7) {
			// insert received data
			$query = 'INSERT INTO ' . $conf_mysql_prefix . 'trackbacks SET date_created=NOW(), blog_id=\'' . mysql_real_escape_string($blog_id) . '\', title=\'' . mysql_real_escape_string($title) . '\', excerpt=\'' . mysql_real_escape_string($excerpt) . '\', url=\'' . mysql_real_escape_string($url) . '\', blog_name=\'' . mysql_real_escape_string($blog_name) . '\'';
			$id = mysql_insert_id();
			mysql_query($query);
			
			$error = 0;
			$message = 'The trackback was successfully received!';

			// send mail to admin
			if(isset($conf_comments_email) && $conf_comments_email == 1) {
				
				// include function for stripping out bbcodes
				require('inc/func_truncate.php');
				require('inc/func_bbcode_strip.php');
				
				// import mail template
				$tpl = implode('', file($conf_doc_root . 'template/mail/trackback.tpl'));
				
				// define url var
				$article = sRewrite('trackback', 'id', $blog_id);
				
				$pattern	=	array(
									'<url>',
									'<article>'
								);
				
				$replace	=	array(
									$url,
									$article
								);
				
				// define mail vars
				$to		= $conf_admin_email;
				$subject	= $conf_page_title . ': New trackback ping';
				$body		= str_replace($pattern, $replace, $tpl);
				$from		= 'From: ' . $conf_page_title . '<sblog-mailer@' . $_SERVER['HTTP_HOST'] . '>' . "\r\n";
				
				// send mail to admin
				mail($to, $subject, $body, $from);
			}
		}
		else {
			$error = 1;
			$message = 'Something went terribly wrong!';
		}

		// reply to the ping
		header('Content-type: text/xml');	
		echo '<?xml version="1.0" encoding="' . $charset . '"?>' . "\n";
		echo '<response>' . "\n";
		echo "\t" . '<error>' . $error . '</error>' . "\n";
		echo "\t" . '<message>' . $message . '</message>' . "\n";
		echo '</response>' . "\n";
		
	}
	else {
		ob_start();
		
		// include headers
		require('inc/tpl_header.php');
		require('inc/tpl_menu.php');
		
		// include blocks
		require('inc/block_custom.php');			// custom blocks

?>
			<div class="sblog_post">
				<div class="sblog_post_topic">
					<h1 class="sblog_post_topic_text"><?php echo lang('Trackbacks'); ?></h1>
				</div>
				<div class="sblog_post_text">
					<strong><?php echo lang('Trackback URL for this post'); ?>:</strong><br /><br />
					<input type="text" name="trackbackurl" value="<?php echo sRewrite('trackback', 'id', $blog_id); ?>" class="sblog_input" style="width: 320px;" /><br /><br />
					
					<input type="button" value="<?php echo lang('Go back'); ?>" onclick="javascript:history.back(-1);" class="sblog_button" />
				</div>
			</div>
<?php

	require('inc/mysql.php');
	
	$query = 'SELECT id, blog_id, UNIX_TIMESTAMP(date_created) AS date_created, title, excerpt, url, blog_name FROM ' . $conf_mysql_prefix . 'trackbacks WHERE blog_id=\'' . $blog_id . '\' ORDER BY date_created DESC';
	
	$q = mysql_query($query);
	$n = mysql_num_rows($q);

	if($n > 0) {
		while($r = mysql_fetch_assoc($q)) {
			echo "\t\t\t\t" . '<div class="sblog_comment">' . "\n";
			echo "\t\t\t\t\t" . '<div class="sblog_comment_topic">' . "\n";
	
			echo "\t\t\t\t\t\t";		
	
			if(strlen($r['title']) > 0) {
				echo '<a href="' . $r['url'] . '" rel="external">' . htmlspecialchars($r['title']) . '</a>';
			}
			else {
				echo '<a href="' . $r['url'] . '" rel="external">' . $r['url'] . '</a>';
			}
	
			if(strlen($r['blog_name']) > 0) {
				echo ' @ ' . htmlspecialchars($r['blog_name']) . ' ';
			}
			
			echo "\n";
	
			echo "\t\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t\t" . '<div class="sblog_comment_text">' . "\n";
			echo "\t\t\t\t\t" . '<div class="sblog_comment_edit">' . lang('Posted') . ': ' . sDateTime($r['date_created'], $conf_date) . '</div>' . "\n";
	
			if(strlen($r['excerpt']) > 0) {
				echo htmlspecialchars($r['excerpt']) . "\n";
			}
			
			echo "\t\t\t\t\t" . '</div>' . "\n";

			if(array_key_exists('Username', $_SESSION) && $_SESSION['Username'] == $conf_admin_username) {
				echo "\t\t\t" . '<div class="sblog_comment_options">' . "\n";
				echo "\t\t\t\t" . '<a href="' . $conf_web_root . 'trackback_del.php?blog_id=' . $r['blog_id'] . '&amp;id=' . $r['id'] . '" class="sblog_comment_options_link">' . lang('delete') . '</a>' . "\n";
				echo "\t\t\t" . '</div>' . "\n";
			}

			echo "\t\t\t\t" . '</div>' . "\n";
		}
	}
	
	mysql_close();

?>
<?php
		require('inc/tpl_foot.php');
		
		$tpl_temp = trim(ob_get_contents());
		$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
		
		ob_end_clean();
		
		echo $tpl_main;
	}

?>