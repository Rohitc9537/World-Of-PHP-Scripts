<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/mysql.php');
	
	if(array_key_exists('id', $_POST) && intval($_POST['id']) != 0) {
		$id = intval($_POST['id']);
	}
	
	$menu_title = mysql_real_escape_string($_POST['menu_title']);
	$menu_description = mysql_real_escape_string($_POST['menu_description']);
	$menu_url = mysql_real_escape_string($_POST['menu_url']);
	$menu_vis = intval($_POST['menu_vis']);
	
	if(intval($id) != 0) {	
		$query = 'UPDATE ' . $conf_mysql_prefix . 'menu SET menu_title=\'' . $menu_title . '\', menu_description=\'' . $menu_description . '\', menu_url=\'' . $menu_url . '\', menu_vis=\'' . $menu_vis . '\' WHERE id=\'' . $id . '\' LIMIT 1';
	}
	else {
		$query = 'INSERT INTO ' . $conf_mysql_prefix . 'menu SET menu_title=\'' . $menu_title . '\', menu_description=\'' . $menu_description . '\', menu_url=\'' . $menu_url . '\', menu_vis=\'' . $menu_vis . '\'';
	}
	
	mysql_query($query);
	
	if(intval($id) == 0) {
		$id = mysql_insert_id();
	}
	
	mysql_close();

	header('Location: menu_edit.php?id=' . $id);
	exit;

?>