<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// do not declare truncate() more than once!
	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}
	
	if(!isset($conf_syndicate_act) || $conf_syndicate_act == 1) {
	
?>
<!-- START OF BLOCK_SYNDICATION -->
			<div class="sblog_block">
				<div class="sblog_block_topic">
					<h2 class="sblog_block_topic_text"><?php echo lang('Syndication'); ?></h2>
				</div>
				<div class="sblog_block_text">
					<a href="<?php echo $conf_web_root; ?>syndication.php?action=article" title="RSS Articles"><img src="<?php echo $conf_web_root; ?>img/rss_articles.png" alt="RSS Articles" /></a>
<?php

	if(!isset($conf_comments_act) || $conf_comments_act == 1) {
		echo "\t\t\t\t\t" . '<br /><a href="' . $conf_web_root . 'syndication.php?action=comment" title="RSS Comments"><img src="' . $conf_web_root . 'img/rss_comments.png" alt="RSS Comments" /></a>' . "\n";
	}

?>
				</div>
			</div>
			<!-- END OF BLOCK_SYNDICATION -->
<?php

	}

?>