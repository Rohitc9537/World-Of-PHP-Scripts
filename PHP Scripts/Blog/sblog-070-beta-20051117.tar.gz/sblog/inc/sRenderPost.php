<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// function for rendering the posts
	function sRenderPost($id, $category_id, $category, $date_created, $date_modified, $topic, $text) {
		global $conf_web_root, $conf_mysql_prefix, $conf_comments_act, $conf_trackback_act, $conf_date;

		// define variables
		$id				= intval($id);
		$category		= sStripSlashes($category);
		$date_created	= $date_created;
		$date_modified	= $date_modified;
		
		if(strlen($topic) > 0) {
			$topic = sStripSlashes($topic);
		}
		else {
			$topic = '-{ ' . lang('no topic') . ' }-';
		}
		
		$text = sStripSlashes($text);
		
		// fetch comments for current post
		$query_comments	= "SELECT id FROM " . $conf_mysql_prefix . "comments WHERE blog_id='" . $id . "'";
		$q_comments			= mysql_query($query_comments);
		$n_comments			= mysql_num_rows($q_comments);

		// fetch trackbacks for current post
		$query_trackbacks	= "SELECT id FROM " . $conf_mysql_prefix . "trackbacks WHERE blog_id='" . $id . "'";
		$q_trackbacks		= mysql_query($query_trackbacks);
		$n_trackbacks		= mysql_num_rows($q_trackbacks);

		echo "\t\t\t" . '<!-- START OF POST -->' . "\n";
		echo "\t\t\t" . '<div class="sblog_post">' . "\n";
		echo "\t\t\t\t" . '<div class="sblog_post_topic"><h1 class="sblog_post_topic_text">' . htmlspecialchars($topic) . '</h1></div>' . "\n";
		echo "\t\t\t\t" . '<div class="sblog_post_text">' . "\n";
		
		// echo category if not 'Uncategorized'
		if($category_id != 1) {
			echo "\t\t\t\t\t" . '<span class="sblog_category">' . lang('Category') . ': <a href="' . sRewrite('category', 'cat', $category_id) . '" title="' . htmlspecialchars($category) . '">' . htmlspecialchars($category) . '</a></span><br />' . "\n";
		}
	
		echo "\t\t\t\t\t" . '<div class="sblog_post_edit">' . lang('Posted') . ': ' . sDateTime($date_created, $conf_date);
	
		// echo out 'last modified' date if post has been modified
		if($date_modified != $date_created) {
			echo ', ' . lang('Edited') . ': ' . sDateTime($date_modified, $conf_date) . "\n";
		}
		
		echo '</div><br />' . "\n";

		if(!array_key_exists('id', $_GET) && !array_key_exists('id', $_POST) && preg_match('/(?:\r\n)\[more(?:=(.*?))?\](?:\r\n)/i', $text, $matches)) {
			if(array_key_exists('1', $matches)) {
				$read_more = htmlspecialchars($matches[1]);
			}
			else {
				$read_more = lang('Read more');
			}
			
			echo "\t\t\t\t\t" . bbcode(substr($text, 0, strpos($text, '[more'))) . "\n" . '<a href="' . sRewrite('article', 'id', $id) . '">' . $read_more . '</a>' . "\n";
		}
		else {
			if(array_key_exists('id', $_POST)) {
				$pattern =	array(
									'/\[more(?:=(.*?))?\]/i'
								);
				
				$replace =	array(
									'[b][MORE] \1[/b]'
								);
			}
			else {
				$pattern =	array(
									'/(?:\r\n)\[more(?:=(.*?))?\](?:\r\n)/i'
								);
				
				$replace =	array(
									null
								);
			}
			
			echo "\t\t\t\t\t" . bbcode(preg_replace($pattern, $replace, $text)) . "\n";
		}
		
		echo "\t\t\t\t" . '</div>' . "\n";
		
		echo "\t\t\t\t" . '<div class="sblog_post_options">';
		
		if($id != 0) {
			// permalink
			echo '<a href="' . sRewrite('article', 'id', $id) . '" title="' . lang('Permalink') . '" class="sblog_post_options_link_perma">' . lang('Permalink') . '</a> ';
		
			// comments if enabled
			if(!isset($conf_comments_act) || $conf_comments_act == 1) {
				echo '<a href="' . sRewrite('comments', 'id', $id) . '" title="' . lang('Comments') . '" class="sblog_post_options_link_comments">' . lang('Comments') . ' (' . $n_comments . ')</a> ';
			}
			
			// trackbacks if enabled
			if(!isset($conf_trackback_act) || $conf_trackback_act == 1) {
				echo '<a href="' . sRewrite('trackback', 'id', $id) . '" title="' . lang('Trackbacks') . '" class="sblog_post_options_link_trackback">' . lang('Trackbacks') . ' (' . $n_trackbacks . ')</a> ';
			}

			// administrator functions
			if(array_key_exists("Username", $_SESSION) && $_SESSION['Username'] != '') {
				echo '<a href="' . $conf_web_root . 'del.php?id=' . $id . '" title="' . lang('Delete') . '" class="sblog_post_options_link_delete">' . lang('Delete') . '</a> <a href="' . $conf_web_root . 'edit.php?id=' . $id . '" title="' . lang('Edit') . '" class="sblog_post_options_link_edit">' . lang('Edit') . '</a>';
			}
		}
		else {
			echo "\t\t\t\t" . '&nbsp;' . "\n";
		}
		
		echo '</div>' . "\n";
		echo "\t\t\t" . '</div>' . "\n";
		echo "\t\t\t" . '<!-- END OF POST -->' . "\n\n";

	}

?>