<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// import some important stuff
	require(dirname(__FILE__) . '/../config.php');
	require(dirname(__FILE__) . '/mysql.php');
	require(dirname(__FILE__) . '/func_config_update.php');
	require(dirname(__FILE__) . '/sCensor.php');
	require(dirname(__FILE__) . '/sRewrite.php');
	require(dirname(__FILE__) . '/sStripSlashes.php');
	require(dirname(__FILE__) . '/sDateTime.php');

	// load admin (global) configuration from database
	$query = 'SELECT conf_name, conf_value FROM ' . $conf_mysql_prefix . 'config';
	
	$q = mysql_query($query);
	
	// define $conf_* vars
	while($r = mysql_fetch_assoc($q)) {
		$$r['conf_name'] = $r['conf_value'];
	}

	if(file_exists('inc/version.ini')) {	
		$v = parse_ini_file('inc/version.ini', false);
		
		if($conf_current_version != $v['conf_current_version']) {
			sblog_config_update('conf_current_version', $v['conf_current_version']);
		}
		
		if($conf_current_build != $v['conf_current_build']) {
			sblog_config_update('conf_current_build', $v['conf_current_build']);
		}
	}
	
	// load username and password from cookie
	if(array_key_exists('username', $_COOKIE) && array_key_exists('password', $_COOKIE)) {
		if($_COOKIE['username'] == $conf_admin_username && $_COOKIE['password'] == $conf_admin_password) {
			$_SESSION['Username'] = $conf_admin_username;
		}
	}

	// load user (visitor) configuration from cookie	
	if(array_key_exists('conf_style_user', $_COOKIE) && $_COOKIE['conf_style_user'] != '') {
		$conf_style_user = $_COOKIE['conf_style_user'];
	}
	
	// PHP session XHTML compliance
	ini_set('url_rewriter.tags', 'a=href,area=href,frame=src,input=src,fieldset=');
	ini_set('arg_separator.output', '&amp;');

	// set date and time
	if(!isset($conf_date) || $conf_date == '') {
		$conf_date = '%Y-%m-%d %H:%M';
	}
	
	// set max image width
	if(!isset($conf_img_width) || $conf_img_width == 0) {
		$conf_img_width = 320;
	}
	
	// link_new
	if(!isset($conf_link_new)) {
		$conf_link_new = 0;
	}
	
	// limits
	if(!isset($conf_block_chars)) {
		$conf_block_chars = 20;
	}
	
	if(!isset($conf_trunc_pos)) {
		$conf_trunc_pos = 'right';
	}
	
	if(!isset($conf_page_disp)) {
		$conf_page_disp = 4;
	}
	
	if(!isset($conf_bar_latest_disp)) {
		$conf_bar_latest_disp = 10;
	}

	if(!isset($conf_bar_comments_disp)) {
		$conf_bar_comments_disp = 10;
	}
	
	if(!isset($conf_syndicate_limit)) {
		$conf_syndicate_limit = 15;
	}

	// mod_rewrite
	if(!isset($conf_mod_rewrite)) {
		$conf_mod_rewrite = 0;
	}
	
	// time zone
	if(!isset($conf_time_offset)) {
		$conf_time_offset = 0;
	}
	
	// expert options
	if(!isset($conf_expert)) {
		$conf_expert = 0;
	}
	
	// style logo
	if(!isset($conf_style_logo)) {
		$conf_style_logo = 0;
	}
	
	// character set
	if(!isset($charset)) {
		$charset = 'iso-8859-1';
	}
	
	// close mysql connection
	mysql_close();

?>