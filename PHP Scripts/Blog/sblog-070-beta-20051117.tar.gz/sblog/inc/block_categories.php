<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// do not declare truncate() more than once!
	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}

?>
<!-- START OF BLOCK_CATEGORY -->
			<div class="sblog_block">
				<div class="sblog_block_topic">
					<h2 class="sblog_block_topic_text"><?php echo lang('Categories'); ?></h2>
				</div>
				<div class="sblog_block_text">
<?php

	$queryUncategorized = 'SELECT id FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND category_id=\'1\'';
	$qUncategorized = mysql_query($queryUncategorized);
	$nUncategorized = mysql_num_rows($qUncategorized);

	$queryCategories = 'SELECT COUNT(d.id) AS n, c.id, c.category FROM ' . $conf_mysql_prefix . 'data AS d, ' . $conf_mysql_prefix . 'categories AS c WHERE d.draft=\'0\' AND d.category_id=c.id AND c.id!=\'1\' GROUP BY d.category_id ORDER BY category ASC';
	$qCategories = mysql_query($queryCategories);
	$nCategories = mysql_num_rows($qCategories);

	echo "\t\t\t\t\t" . '<ul>' . "\n";		
	
	if($nUncategorized > 0) {
		echo "\t\t\t\t\t\t" . '<li><a href="' . sRewrite('category', 'cat', 1) . '" title="' . lang('Uncategorized') . '">' . lang('Uncategorized') . '</a>';
		
		if(!isset($conf_count_posts_vis) || intval($conf_count_posts_vis) == 1) {
			echo ' ' . $nUncategorized;
		}
		
		echo '</li>' . "\n";
	}

	if($nCategories > 0) {		
		while($rCategories = mysql_fetch_assoc($qCategories)) {
			echo "\t\t\t\t\t\t" . '<li><a href="' . sRewrite('category', 'cat', $rCategories['id']) . '" title="' . htmlspecialchars($rCategories['category']) . '">' . truncate($rCategories['category'], $conf_block_chars) . '</a> ';
			
			if(!isset($conf_count_posts_vis) || intval($conf_count_posts_vis) == 1) {
				echo $rCategories['n'];
			}
			
			echo '</li>' . "\n";
		}
	}
	
	echo "\t\t\t\t\t" . '</ul>' . "\n";

?>
				</div>
			</div>
			<!-- END OF BLOCK_CATEGORY -->