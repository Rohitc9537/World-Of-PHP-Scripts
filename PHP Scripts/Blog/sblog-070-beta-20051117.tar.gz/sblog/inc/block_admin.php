<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// do not declare truncate() more than once!
	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}
	
?>
<!-- START OF BLOCK_ADMIN -->
			<div class="sblog_block">
				<div class="sblog_block_topic">
					<h2 class="sblog_block_topic_text"><?php echo lang('Administrator'); ?></h2>
				</div>
				<div class="sblog_block_text">
					<ul>
<?php

	if(array_key_exists('Username', $_SESSION) && $_SESSION['Username'] == $conf_admin_username) {
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'settings.php" title="' . lang('Settings') . '" class="sblog_admin_settings">' . lang('Settings') . '</a></li>' . "\n";
		
		if($conf_expert == 1) {
			echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'static.php" title="' . lang('Static pages') . '" class="sblog_admin_static">' . lang('Static pages') . '</a></li>' . "\n";
		}
		
		if($conf_expert == 1) {
			echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'menu_pos.php" title="' . lang('Menu') . '" class="sblog_admin_menu">' . lang('Menu') . '</a></li>' . "\n";
		}
		
		if($conf_expert == 1) {
			echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'blocks_pos.php" title="' . lang('Blocks') . '" class="sblog_admin_blocks">' . lang('Blocks') . '</a></li>' . "\n";
		}
		
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'categories.php" title="' . lang('Categories') . '" class="sblog_admin_categories">' . lang('Categories') . '</a></li>' . "\n";
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'posts.php" title="' . lang('Posts') . '" class="sblog_admin_posts">' . lang('Posts') . '</a></li>' . "\n";
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'image.php" title="' . lang('Images') . '" class="sblog_admin_images">' . lang('Images') . '</a></li>' . "\n";
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'links.php" title="' . lang('Links') . '" class="sblog_admin_links">' . lang('Links') . '</a></li>' . "\n";
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'censoring.php" title="' . lang('Censoring') . '" class="sblog_admin_censoring">' . lang('Censoring') . '</a></li>' . "\n";
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'logout.php" title="' . lang('Logout') . '" class="sblog_admin_logout">' . lang('Logout') . '</a></li>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t" . '<li><a href="' . $conf_web_root . 'login.php" title="' . lang('Login') . '">' . lang('Login') . '</a></li>' . "\n";
	}

?>
					</ul>
				</div>
			</div>
			<!-- END OF BLOCK_ADMIN -->