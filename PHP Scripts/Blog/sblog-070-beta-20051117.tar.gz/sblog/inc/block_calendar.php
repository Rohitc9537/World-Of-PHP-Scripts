<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/
	
	// do not declare truncate() more than once!
	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}

?>
			<!-- START OF TPL_BAR_CALENDAR -->
			<div class="sblog_block">
				<div class="sblog_block_topic">
					<h2 class="sblog_block_topic_text"><?php echo lang('Calendar'); ?></h2>
				</div>
<?php

	if(isset($_GET['date']) && strlen($_GET['date']) == 6 || isset($_GET['date']) && strlen($_GET['date']) == 8) {
		$cal_year = substr($_GET['date'], 0, 4);
		$cal_month = substr($_GET['date'], 4, 2);
		$cal_day = substr($_GET['date'], 6, 2);
	}
	else if(isset($_GET['date']) && strlen($_GET['date']) == 6 || isset($_GET['date']) && strlen($_GET['date']) == 8) {
		$cal_year = substr($_GET['date'], 0, 4);
		$cal_month = substr($_GET['date'], 4, 2);
		$cal_day = null;
	}
	else {
		$cal_year = sDateTime(time(), '%Y');
		$cal_month = sDateTime(time(), '%m');
		$cal_day = null;
	}
	
	$queryCalendar = 'SELECT SUBSTRING(date_created, 1, 10) AS date, COUNT(id) AS n FROM ' . $conf_mysql_prefix . 'data WHERE draft=\'0\' AND SUBSTRING(date_created, 1, 7)=\'' . $cal_year . '-' . $cal_month . '\' GROUP BY date';
	$qCalendar = mysql_query($queryCalendar);
	$nCalendar = mysql_num_rows($qCalendar);

	$posts = array();
	
	while($rCalendar = mysql_fetch_assoc($qCalendar)) {
		$posts[$rCalendar['date']] = $rCalendar['n'];
	}

	require('inc/sCalendar.php');
	
	$cal = new sCalendar();
	
	$calendar = $cal->render();

	$mktime = gmmktime(gmdate('H'), gmdate('i'), gmdate('s'), $cal->thisMonth(), gmdate('d'), $cal->thisYear());
	
	echo "\t\t\t\t" . '<table cellspacing="0" cellpadding="0" border="0" class="sblog_cal">' . "\n";
	echo "\t\t\t\t\t" . '<tr>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal_header">';
	
	if($cal->prevMonth() == 12) {
		echo '<a href="' . sRewrite('archive', 'date', $cal->prevYear() . str_pad($cal->prevMonth(), 2, '0', STR_PAD_LEFT)) . '">&laquo;</a>';
	}
	else {
		echo '<a href="' . sRewrite('archive', 'date', $cal->thisYear() . str_pad($cal->prevMonth(), 2, '0', STR_PAD_LEFT)) . '">&laquo;</a>';
	}
	
	echo '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td colspan="5" class="sblog_cal_header"><a href="' . sRewrite('archive', 'date', $cal->thisYear() . str_pad($cal->thisMonth(), 2, '0', STR_PAD_LEFT)) . '">' . ucwords(sDateTime($mktime, '%B %Y')) . '</a></td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal_header">';
	
	if($cal->nextMonth() == 1) {
		echo '<a href="' . sRewrite('archive', 'date', $cal->nextYear() . str_pad($cal->nextMonth(), 2, '0', STR_PAD_LEFT)) . '">&raquo;</a>';
	}
	else {
		echo '<a href="' . sRewrite('archive', 'date', $cal->thisYear() . str_pad($cal->nextMonth(), 2, '0', STR_PAD_LEFT)) . '">&raquo;</a>';
	}
	
	echo '</td>' . "\n";
	echo "\t\t\t\t\t" . '</tr>' . "\n";
	echo "\t\t\t\t\t" . '<tr>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Monday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Tuesday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Wednesday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Thursday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Friday'), 0 ,1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Saturday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t\t" . '<td class="sblog_cal">' . substr(lang('Sunday'), 0, 1) . '</td>' . "\n";
	echo "\t\t\t\t\t" . '</tr>' . "\n";

	foreach($calendar as $w) {
		echo "\t\t\t\t\t" . '<tr>' . "\n";
		foreach($w as $d) {
			if($cal_year == $cal->thisYear() && $cal_month == $cal->thisMonth() && $d == $cal_day && $d != null) {
				$class = 'sblog_cal_active';
			}
			else if($cal_year == sDateTime(time(), '%Y') && $cal_month == sDateTime(time(), '%m') && $d == sDateTime(time(), '%d')) {
				$class = 'sblog_cal_today';
			}
			else if($d != null) {
				$class = 'sblog_cal_day';
			}
			else {
				$class = 'sblog_cal_empty';
			}
			
			echo "\t\t\t\t\t\t" . '<td class="' . $class . '">';
			
			$today = $cal->thisYear() . '-' . str_pad($cal->thisMonth(), 2, '0', STR_PAD_LEFT) . '-' . str_pad($d, 2, '0', STR_PAD_LEFT);
			
			if(array_key_exists($today, $posts)) {
				echo '<a href="' . sRewrite('archive', 'date', str_replace('-', '', $today)) . '" title="' . $posts[$today] . ' ' . lang('post(s)') . '">' . $d . '</a>';
			}
			else {
				echo $d;
			}
			
			echo '</td>' . "\n";
		}
		echo "\t\t\t\t\t" . '</tr>' . "\n";
	}
	echo "\t\t\t\t" . '</table>' . "\n";

?>
			</div>
			<!-- END OF TPL_BAR_CALENDAR -->