<?php

	// this function checks if magic_quotes_gpc is enabled
	// if it is, the slashes will be stripped

	if(!function_exists('sStripSlashes')) {
		function sStripSlashes($string) {
			
			if(get_magic_quotes_gpc() == 1) {
				$string = stripslashes($string);
			}

			return $string;
		}
	}

?>