<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	/* start <sblog_main> */
	ob_start();

?>

<?php

	require('inc/sRenderStatic.php');
	require('inc/mysql.php');
	
	if(array_key_exists('id', $_REQUEST)) {
		$id = intval($_REQUEST['id']);
	}
	else {
		$id = null;
	}

	$query = 'SELECT id, UNIX_TIMESTAMP(date_created) AS date_created, UNIX_TIMESTAMP(date_modified) AS date_modified, topic, content, static_style, static_top FROM ' . $conf_mysql_prefix . 'static WHERE draft=\'0\' AND id=\'' . $id . '\' LIMIT 1';
	
	$q = mysql_query($query);
	$n = mysql_num_rows($q);
	
	if($n > 0) {
		$r = mysql_fetch_assoc($q);
		sRenderStatic($r['id'], $r['date_created'], $r['topic'], $r['content'], $r['static_style'], $r['static_top']);
	}
	else {
		echo '<div class="sblog_post">';
		echo '<div class="sblog_post_topic">' . lang('This page has been deleted!') . '</div>';
		echo '</div>';
	}
	
	mysql_close();

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */

?>