<?php

	function sCheckEmail($email) {
		return preg_match('/^[^@ ]+@[^@ ]+\.[a-zA-Z]{2,}+$/', $email);
	}

?>