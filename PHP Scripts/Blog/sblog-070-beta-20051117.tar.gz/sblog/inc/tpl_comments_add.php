<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	if(array_key_exists('id', $_REQUEST) && intval($_REQUEST['id']) > 0) {
		
		if(array_key_exists('comment_username', $_COOKIE) && strlen($_COOKIE['comment_username']) > 0) {
			$comment_username = $_COOKIE['comment_username'];
		}
		else {
			$comment_username = null;
		}
		
		if(array_key_exists('comment_email', $_COOKIE) && strlen($_COOKIE['comment_email']) > 0) {
			$comment_email = $_COOKIE['comment_email'];
		}
		else {
			$comment_email = null;
		}
		
		if(array_key_exists('comment_homepage', $_COOKIE) && strlen($_COOKIE['comment_homepage']) > 0) {
			$comment_homepage = $_COOKIE['comment_homepage'];
		}
		else {
			$comment_homepage = null;
		}

		// start <sblog_comments>
		ob_start();

?>
<a name="add_comment"></a>
	<form id="comments" method="post" action="<?php echo $conf_web_root; ?>comments_do.php">
	<fieldset>
		<input type="hidden" name="blog_id" id="blog_id" value="<?php echo $_REQUEST['id']; ?>" />
		<legend><?php echo lang('Post comment'); ?></legend>
		<div class="sblog_var">
			<?php echo lang('Name') . "\n"; ?>
		</div>
		<div class="sblog_val">
			<input type="text" name="username" id="username" value="<?php echo htmlspecialchars(sStripSlashes($comment_username)); ?>" class="sblog_input" />
		</div>
		
		<div class="sblog_var">
			<?php echo lang('E-mail') . "\n"; ?>
		</div>
		<div class="sblog_val">
			<input type="text" name="email" id="email" value="<?php echo htmlspecialchars(sStripSlashes($comment_email)); ?>" class="sblog_input" />
		</div>
		
		<div class="sblog_var">
			<?php echo lang('Homepage') . "\n"; ?>
		</div>
		<div class="sblog_val">
			<input type="text" name="homepage" id="homepage" value="<?php echo htmlspecialchars(sStripSlashes($comment_homepage)); ?>" class="sblog_input" />
		</div>

		<div class="sblog_var">
			<?php echo lang('Comment'); ?>
		</div>
		<div class="sblog_val">
			<textarea name="comment" id="comment" cols="40" rows="4" class="sblog_comment"></textarea>
		</div>
		<input type="reset" value="<?php echo lang('Go back'); ?>" onclick="javascript:history.go(-1);return false" /> <input type="submit" value="<?php echo lang('OK'); ?>" />
	</fieldset>
	</form>
<?php

		$tpl_temp = trim(ob_get_contents());
		$tpl_main = str_replace('<sblog_comments_add>', $tpl_temp, $tpl_main);
		
		ob_end_clean();
		
		/* end <sblog_main> */
	}
	else {
		$tpl_main = str_replace('<sblog_comments_add>', null, $tpl_main);
	}
	
?>