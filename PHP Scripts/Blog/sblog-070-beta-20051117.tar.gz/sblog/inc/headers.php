<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// include language function
	require('inc/lang.php');
	
	// include BBCode function
	require('inc/func_bbcode.php');

	// start output buffering
	ob_start();

	// verify selected style
	if(isset($conf_style_user) && file_exists('style/' . $conf_style_user . '.css')) {
		$style = $conf_style_user;
	}	
	else if(file_exists('style/' . $conf_style_default . '.css')) {
		$style = $conf_style_default; // default to system style
	}
	else {
		$style = 'Blue'; // default to 'Blue' style
	}
	
	if($conf_style_logo == 1) {
		if(file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.jpg')) {
			$logo = '<img src="' . $conf_web_root . 'style/' . $conf_style_default . '/logo.jpg" alt="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" title="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" />';
		}
		else if(file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.png')) {
			$logo = '<img src="' . $conf_web_root . 'style/' . $conf_style_default . '/logo.png" alt="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" title="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" />';
		}
		else if(file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.gif')) {
			$logo = '<img src="' . $conf_web_root . 'style/' . $conf_style_default . '/logo.gif" alt="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" title="' . htmlspecialchars(sStripSlashes($conf_page_title)) . '" />';
		}
		else {
			$logo = htmlspecialchars(sStripSlashes($conf_page_title));
		}
	}
	else {
		$logo = htmlspecialchars(sStripSlashes($conf_page_title));
	}

?>
<meta http-equiv="Content-type" content="text/html; charset=<?php echo $charset; ?>" />
<meta name="keywords" content="sBLOG, Servous, <?php echo htmlspecialchars(sStripSlashes($conf_page_title)); ?>, <?php echo htmlspecialchars(sStripSlashes($conf_page_description)); ?>" />
<meta name="description" content="<?php echo htmlspecialchars(sStripSlashes($conf_page_description)); ?>" />
<meta name="generator" content="sBLOG <?php echo $conf_current_version; ?> (Build <?php echo $conf_current_build; ?>)" />
<link rel="shortcut icon" href="<?php echo $conf_web_root; ?>favicon.ico" />
<link rel="stylesheet" href="<?php echo $conf_web_root; ?>style/<?php echo $style; ?>.css" />

<?php

	if($conf_syndicate_act == 1) {
		echo '<link rel="alternate" type="application/rss+xml" title="' . $conf_page_title . '" href="' . $conf_web_root . 'syndication.php?action=article" />' . "\n";
		echo '<link rel="alternate" type="application/rss+xml" title="' . $conf_page_title . ' (comments)" href="' . $conf_web_root . 'syndication.php?action=comment" />' . "\n";
	}

?>

<title><?php echo htmlspecialchars(sStripSlashes($conf_page_title)); ?></title>
<script src="<?php echo $conf_web_root; ?>js/js_quicktags.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo $conf_web_root; ?>js/external.js"></script>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_header>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	$tpl_main = str_replace('<sblog_web_root>', $conf_web_root, $tpl_main);
	$tpl_main = str_replace('<sblog_page_title>', $logo, $tpl_main);
	$tpl_main = str_replace('<sblog_page_description>', htmlspecialchars(sStripSlashes($conf_page_description)), $tpl_main);

?>