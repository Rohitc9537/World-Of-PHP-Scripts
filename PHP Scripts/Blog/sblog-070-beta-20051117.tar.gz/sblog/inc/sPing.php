<?php

	function sPing($host, $title, $url, $excerpt, $blog_name) {
		global $conf_web_root, $charset;

		// define variables
		$host = str_replace('http://', '', $host);
		$path = explode('/', $host);
		$host = $path[0];
		
		unset($path[0]);
		
		$path = '/' . implode('/', $path);

		$fp = @fsockopen($host, 80, $errno, $errstr, 30);
		
		if(!$fp) {
			return false;
		}
		else {
			$query  = 'title=' . rawurlencode($title);
			$query .= '&url=' . rawurlencode($url);
			$query .= '&excerpt=' . rawurlencode($excerpt);
			$query .= '&blog_name=' . rawurlencode($blog_name);

			$out = 'POST ' . $path . ' HTTP/1.1' . "\r\n";
			$out .= 'Host: ' . $host . "\r\n";
			$out .= 'Connection: close' . "\r\n";
			$out .= 'Content-Length: ' . strlen($query) . "\r\n";
			$out .= 'Content-Type: application/x-www-form-urlencoded; charset=' . $charset . "\r\n\r\n";
			$out .= $query . "\r\n";

			fclose($fp);
			
			return true;
		}
	}

?>