<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	// checkboxes
	if(!isset($conf_syndicate_act) || $conf_syndicate_act == 1) {
		$syndicate_act_check = ' checked="checked"';
	}
	else {
		$syndicate_act_check = null;
	}

	if(!isset($conf_trackback_act) || $conf_trackback_act == 1) {
		$trackback_act_check = ' checked="checked"';
	}
	else {
		$trackback_act_check = null;
	}

	if(!isset($conf_comments_act) || $conf_comments_act == 1) {
		$comments_act_check = ' checked="checked"';
	}
	else {
		$comments_act_check = null;
	}

	if(!isset($conf_comments_email) || $conf_comments_email == 1) {
		$comments_email_check = ' checked="checked"';
	}
	else {
		$comments_email_check = null;
	}
	
	// time zones
	$time_zones =	array(
							'-12.00' => '-12',
							'-11.00' => '-11',
							'-10.00 HST' => '-10',
							'-09.30' => '-9.5',
							'-09.00 AKST' => '-9',
							'-08.30' => '-8.5',
							'-08.00 PST' => '-8',
							'-07.00 MST' => '-7',
							'-06.00 CST' => '-6',
							'-05.00 EST' => '-5',
							'-04.00 AST' => '-4',
							'-03.30 NST' => '-3.5',
							'-03.00 ADT' => '-3',
							'-02.00' => '-2',
							'-01.00' => '-1',
							'�00.00 GMT/UTC' => '0',
							'+01.00 CET' => '+1',
							'+02.00' => '+2',
							'+03.00 NAO' => '+3',
							'+03.30' => '+3.5',
							'+04.00' => '+4',
							'+04.30' => '+4.5',
							'+05.00' => '+5',
							'+05.30 IST' => '+5.5',
							'+06.00' => '+6',
							'+06.30' => '+6.5',
							'+07.00 CIA' => '+7',
							'+08.00 AWST' => '+8',
							'+09.00 JST/KST' => '+9',
							'+09.30 ACST' => '+9.5',
							'+10.00 AEST' => '+10',
							'+10.30 DST' => '+10.5',
							'+11.00' => '+11',
							'+11.30' => '+11.5',
							'+12.00' => '+12',
							'+13.00' => '+13',
						);

	// date formats
	
	$date_formats =	array(
								sDateTime(time(), '%Y-%m-%d %H:%M') => '%Y-%m-%d %H:%M',
								sDateTime(time(), '%Y/%m/%d %H:%M') => '%Y/%m/%d %H:%M',
								sDateTime(time(), '%Y%m%d %H:%M') => '%Y%m%d %H:%M',
								sDateTime(time(), '%y-%m-%d %H:%M') => '%y-%m-%d %H:%M',
								sDateTime(time(), '%y/%m/%d %H:%M') => '%y/%m/%d %H:%M',
								sDateTime(time(), '%y%m%d %H:%M') => '%y%m%d %H:%M',
								sDateTime(time(), '%Y %B %d, %A %H:%M') => '%Y %B %d, %A %H:%M',
								sDateTime(time(), '%H:%M %A, %B %d %Y') => '%H:%M %A, %B %d %Y',
								sDateTime(time(), '%d.%m.%Y %H:%M') => '%d.%m.%Y %H:%M'
							);

	/* start <sblog_main> */
	ob_start();

?>
<!-- OPTIONS -->
			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Settings'); ?></h1>
			</div>
			<div class="sblog_post_text">
				<form id="settings" method="post" action="settings_do.php">
					<div>
					<input type="submit" value="<?php echo lang('Save'); ?>" class="sblog_button" /><br /><br />
					</div>
					
					<fieldset>
						<legend><?php echo lang('General'); ?></legend>
						<a href="settings_admin_login.php"><?php echo lang('Change the administrator\'s username and password.'); ?></a><br /><br />
						<div class="sblog_var">
							<?php echo lang('Page title'); ?>
						</div>
						<div class="sblog_val">
							<input type="text" name="page_title" id="page_title" size="40" maxlength="40" value="<?php echo htmlspecialchars(sStripSlashes($conf_page_title)); ?>" class="sblog_input" />
<?php

	if($conf_expert == 1 && file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.jpg') || $conf_expert == 1 && file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.png') || $conf_expert == 1 && file_exists($conf_doc_root . 'style/' . $conf_style_default . '/logo.gif')) {
		if($conf_style_logo == 1) {
			$checked = ' checked="checked"';
		}
		else{
			$checked = null;
		}
		
		echo "\t\t\t\t\t\t\t" . '<br /><label for"=style_logo"><input type="checkbox" name="style_logo" id="style_logo" value="1"' . $checked . ' /> ' . lang('Use style logo') . '</label>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="style_logo" value="' . $conf_style_logo . '" />' . "\n";
	}

?>
						</div>
						<div class="sblog_var">
							<?php echo lang('Page description'); ?>
						</div>
						<div class="sblog_val">
							<input type="text" name="page_description" id="page_description" size="40" maxlength="80" value="<?php echo htmlspecialchars(sStripSlashes($conf_page_description)); ?>" class="sblog_input" />
						</div>
						<div class="sblog_var">
							<?php echo lang('E-mail'); ?>
						</div>
						<div class="sblog_val">
							<input type="text" name="admin_email" id="admin_email" size="40" value="<?php echo htmlspecialchars($conf_admin_email); ?>" class="sblog_input" />
						</div>
					</fieldset>
					<fieldset>
						<legend><?php echo lang('Comments'); ?></legend>
						<label for="comments_act" class="sblog_label_col"><input type="checkbox" name="comments_act" id="comments_act" value="1"<?php echo $comments_act_check; ?> /> <?php echo lang('Enable user comments'); ?></label>
<?php

	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<label for="trackback_act" class="sblog_label_col"><input type="checkbox" name="trackback_act" id="trackback_act" value="1"' . $trackback_act_check . ' /> ' . lang('Enable trackbacks') . '</label>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t" . '<input type="hidden" name="trackback_act" id="trackback_act" value="' . $conf_trackback_act . '" />' . "\n";
	}

?>
						<label for="comments_email" class="sblog_label_col"><input type="checkbox" name="comments_email" id="comments_email" value="1"<?php echo $comments_email_check; ?> /> <?php echo lang('Send me e-mails when new comments are posted.'); ?></label>
					</fieldset>
<?php

	echo "\t\t\t\t\t" . '<fieldset>' . "\n";
	echo "\t\t\t\t\t\t" . '<legend>' . lang('Limits') . '</legend>' . "\n";
	echo "\t\t\t\t\t\t" . '<input type="text" name="page_disp" id="page_disp" size="3" maxlength="3" value="' . htmlspecialchars(sStripSlashes($conf_page_disp)) . '" class="sblog_input" /> ' . lang('Posts per page') . '<br />' . "\n";
	echo "\t\t\t\t\t\t" . '<input type="text" name="bar_latest_disp" id="bar_latest_disp" size="3" maxlength="3" value="' . htmlspecialchars(sStripSlashes($conf_bar_latest_disp)) . '" class="sblog_input" /> ' . sprintf(lang('Number of rows in "%s"'), '<strong>' . lang('Latest posts') . '</strong>') . '<br />' . "\n";
	echo "\t\t\t\t\t\t" . '<input type="text" name="bar_comments_disp" id="bar_comments_disp" size="3" maxlength="3" value="' . htmlspecialchars(sStripSlashes($conf_bar_comments_disp)) . '" class="sblog_input" /> ' . sprintf(lang('Number of rows in "%s"'), '<strong>' . lang('Comments') . '</strong>') . '<br />' . "\n";
	
	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<input type="text" name="img_width" id="img_width" size="3" maxlength="4" value="' . $conf_img_width . '" class="sblog_input" /> ' . lang('Max. image width (in pixels). This requires GD to work.') . ' ' . lang('Default') . ': 320<br />' . "\n";
	}
	
	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<input type="text" name="block_chars" id="block_chars" size="3" maxlength="3" value="' . $conf_block_chars . '" class="sblog_input" /> ' . lang('Max number of characters in blocks.') . ' ' . lang('Default') . ': 20<br />' . "\n";
	}
	
	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<input type="text" name="syndicate_limit" id="syndicate_limit" size="3" maxlength="3" value="' . $conf_syndicate_limit . '" class="sblog_input" /> ' . lang('Number of posts to syndicate.') . ' ' . lang('Default') . ': 15<br />' . "\n";
	}
	
	echo "\t\t\t\t\t" . '</fieldset>' . "\n";

?>
					<fieldset>
						<legend><?php echo lang('Date and time'); ?></legend>
						<div class="sblog_var">
							<?php echo lang('Time Zone') . "\n"; ?>
						</div>
						<div class="sblog_val">
							<select name="time_offset" id="time_offset">
<?php

	while(list($var, $val) = each($time_zones)) {
		if($val == $conf_time_offset) {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
		
		echo "\t\t\t\t\t\t\t\t" . '<option value="' . $val . '"' . $selected . '>' . $var . '</option>' . "\n";
	}

?>
							</select><br />
<?php
	if(!isset($conf_local_time_vis) || intval($conf_local_time_vis) == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}
?>
							<label for="local_time_vis"><input type="checkbox" name="local_time_vis" id="local_time_vis" value="1"<?php echo $checked; ?> /> <?php echo lang('Show local time'); ?></label>
						</div>

						<div class="sblog_var">
							<?php echo lang('Date and Time') . "\n"; ?>
						</div>
						<div class="sblog_val">
							<select name="conf_date" id="conf_date">
<?php

	while(list($var, $val) = each($date_formats)) {
		if($val == $conf_date) {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
		
		echo "\t\t\t\t\t\t\t\t" . '<option value="' . $val . '"' . $selected . '>' . $var . '</option>' . "\n";
	}

?>
							</select>
						</div>
					</fieldset>
					<fieldset>
						<legend><?php echo lang('Miscellaneous'); ?></legend>
						<div class="sblog_var">
							<?php echo lang('Expert'); ?>
						</div>
						<div class="sblog_val">
<?php

	if(intval($conf_expert) == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
							<label for="expert"><input type="checkbox" name="expert" id="expert" value="1"<?php echo $checked; ?> /> <?php echo lang('Show expert options'); ?></label>
						</div>
<?php

// ####################################################################################################
// VERSION
// ####################################################################################################

	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Version') . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
	
		if(!isset($conf_version_vis) || intval($conf_version_vis) == 1) {
			$checked = ' checked="checked"';
		}
		else {
			$checked = null;
		}
	
		echo "\t\t\t\t\t\t\t" . '<label for="version_vis"><input type="checkbox" name="version_vis" id="version_vis" value="1"' . $checked . ' /> ' . lang('Display version') . '</label><br />' . "\n";
		echo "\t\t\t\t\t\t\t" . '<strong>' . $conf_current_version . '</strong> (Build ' . $conf_current_build . ')<br />' . "\n";
		echo "\t\t\t\t\t\t\t" . '<a href="upgrade.php" title="' . lang('Check for upgrade') . '">' . lang('Check for upgrade') . '</a>' . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="version_vis" id="version_vis" value="' . $conf_version_vis . '" />' . "\n";
	}

?>
						<div class="sblog_var">
							<?php echo lang('Style'); ?>
						</div>
						<div class="sblog_val">
							<select name="style_default" id="style_default">
<?php

	if($handle = opendir('style/')) {
		while(false !== ($file = readdir($handle))) {
			if(is_file('style/' . $file) && substr($file, -4) == '.css') {
				if(basename($file, '.css') == $conf_style_default) {
					$selected = ' selected="selected"';
				}
				else {
					$selected = null;
				}
				
				echo "\t\t\t\t\t\t\t\t\t" . '<option value="' . basename($file, '.css') . '"' . $selected . '>' . basename($file, '.css') . '</option>' . "\n";
			}
		}
	}

?>
							</select><br />
							<a href="http://servous.se/?c=styles" rel="external" title="<?php echo lang('Download new styles'); ?>" class="sblog_external"><?php echo lang('Download new styles'); ?></a>
						</div>
<?php

// ####################################################################################################
// COUNT POSTS
// ####################################################################################################

	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Count posts') . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
	
		if(!isset($conf_count_posts_vis) || intval($conf_count_posts_vis) == 1) {
			$checked = ' checked="checked"';
		}
		else {
			$checked = null;
		}
	
		echo "\t\t\t\t\t\t\t" . '<label for="count_posts_vis"><input type="checkbox" name="count_posts_vis" id="count_posts_vis" value="1"' . $checked . ' /> ' . sprintf(lang('Count posts in "%s" block'), lang('Categories')) . '</label>' . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="count_posts_vis" id="count_posts_vis" value="' . $conf_count_posts_vis . '" />' . "\n";
	}

// ####################################################################################################
// TRUNCATE
// ####################################################################################################

	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Truncate') . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Truncate long text from the') . "\n";
		echo "\t\t\t\t\t\t\t" . '<select name="trunc_pos">' . "n";
		echo "\t\t\t\t\t\t\t\t" . '<option value="right">' . strtolower(lang('Right')) . '</option>' . "\n";
	
		if($conf_trunc_pos == 'center') {
			$selected = ' selected="selected"';
		}
		else {
			$selected = null;
		}
	
		echo "\t\t\t\t\t\t\t\t" . '<option value="center"' . $selected . '>' . strtolower(lang('Middle')) . '</option>' . "\n";
		echo "\t\t\t\t\t\t\t" . '</select>' . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
	}

?>
						<div class="sblog_var">
							<?php echo lang('Language'); ?>
						</div>
						<div class="sblog_val">
							<select name="lang_default" id="lang_default">
								<option value="English"><?php echo lang('Default'); ?></option>
<?php

	if($handle = opendir('lang/')) {
		while(false !== ($file = readdir($handle))) {
			if(is_file('lang/' . $file) && substr($file, -4) == '.php') {
				if(basename($file, '.php') == $conf_lang_default) {
					$selected = ' selected="selected"';
				}
				else {
					$selected = null;
				}
				
				echo "\t\t\t\t\t\t\t\t\t" . '<option value="' . basename($file, '.php') . '"' . $selected . '>' . basename($file, '.php') . '</option>' . "\n";
			}
		}
	}

?>
							</select><br />
							<a href="http://servous.se/?c=translation" rel="external" title="<?php echo lang('Download language files'); ?>" class="sblog_external"><?php echo lang('Download language files'); ?></a>
						</div>
						<div class="sblog_var">
							<?php echo lang('Links'); ?>
						</div>
						<div class="sblog_val">
<?php

	if(intval($conf_link_new) == 1) {
		$checked = ' checked="checked"';
	}
	else {
		$checked = null;
	}

?>
							<label for="link_new"><input type="checkbox" name="link_new" id="link_new" value="1"<?php echo $checked; ?> /> <?php echo lang('Open links in a new window.'); ?></label>
						</div>
<?php

// ####################################################################################################
// MOD_REWRITE
// ####################################################################################################

	if($conf_expert == 1) {
		if(intval($conf_mod_rewrite) == 1) {
			$checked = ' checked="checked"';
		}
		else {
			$checked = null;
		}
	
		echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Permalinks') . '<br />' . "\n";
		echo "\t\t\t\t\t\t\t" . '<a href="http://servous.se/doc/mod_rewrite" rel="external" class="sblog_external">mod_rewrite</a>' . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
		echo "\t\t\t\t\t\t" . '<label for="mod_rewrite"><input type="checkbox" name="mod_rewrite" id="mod_rewrite" value="1"' . $checked . ' /> ' . lang('Enable URL rewriting') . '</label><br />' . "\n";
		echo "\t\t\t\t\t\t" . printf(lang('To make this work you must have %s installed on your server. (If you\'re not sure, leave this box unchecked.)'), 'mod_rewrite') . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t" . '<input type="hidden" name="mod_rewrite" id="mod_rewrite" value="' . $conf_mod_rewrite . '" />' . "\n";
	}

// ####################################################################################################
// SYNDICATE
// ####################################################################################################

	if($conf_expert == 1) {
		echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
		echo "\t\t\t\t\t\t\t" . lang('Syndicate') . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
		echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
		echo "\t\t\t\t\t\t\t" . '<label for="syndicate_act"><input type="checkbox" name="syndicate_act" id="syndicate_act" value="1"' . $syndicate_act_check . ' /> ' . lang('Enable syndication') . '</label>' . "\n";
		echo "\t\t\t\t\t\t" . '</div>' . "\n";
	}
	else {
		echo "\t\t\t\t\t\t\t" . '<input type="hidden" name="syndicate_act" id="syndicate_act" value="' . $conf_syndicate_act . '" />' . "\n";
	}

?>
					</fieldset>
					<div>
					<br /><input type="submit" value="<?php echo lang('Save'); ?>" class="sblog_button" /><br /><br />
					</div>
				</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>