<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// admin only
	require('inc/auth.php');

	if(array_key_exists('id', $_REQUEST) && intval($_REQUEST['id']) > 0) {
		
		$id = intval($_REQUEST['id']);
		$blog_id = intval($_REQUEST['blog_id']);
		
		require('inc/config.php');
		require('inc/mysql.php');
		
		$query = 'DELETE FROM ' . $conf_mysql_prefix . 'trackbacks WHERE id=\'' . $id . '\' LIMIT 1';
		
		mysql_query($query);
		
		mysql_close();
	}
	
	header('Location: trackback.php?blog_id=' . $blog_id);
	exit;

?>