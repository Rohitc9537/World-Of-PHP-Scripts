<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');

	// include blocks
	require('inc/block_custom.php');			// custom blocks
	
	require('inc/mysql.php');

	if(array_key_exists('ref', $_REQUEST)) {
		$ref = sStripSlashes($_REQUEST['ref']);
	}
	else {
		$ref = 'categories.php';
	}
	
	if(array_key_exists('id', $_REQUEST)) {
		$id = intval($_REQUEST['id']);
	}
	else {
		$id = null;
	}
	
	if(array_key_exists('category_id', $_REQUEST)) {
		$category_id = intval($_REQUEST['category_id']);
	}
	else {
		$category_id = null;
	}
	
	if(array_key_exists('topic', $_REQUEST)) {
		$topic = sStripSlashes($_REQUEST['topic']);
	}
	else {
		$topic = null;
	}
	
	if(array_key_exists('text', $_REQUEST)) {
		$text = sStripSlashes($_REQUEST['text']);
	}
	else {
		$text= null;
	}
	
	if(array_key_exists('date_created', $_REQUEST)) {
		$date_created = $_REQUEST['date_created'];
	}
	else {
		$date_created = gmdate('YmdHis');
	}
	
	if(array_key_exists('cat_id', $_GET) && intval($_GET['cat_id']) > 0) {
		$cat_id = intval($_GET['cat_id']);
		
		$queryEdit = 'SELECT category FROM ' . $conf_mysql_prefix . 'categories WHERE id=\'' . $cat_id . '\' LIMIT 1';
		$qEdit = mysql_query($queryEdit);
		$rEdit = mysql_fetch_assoc($qEdit);
		$category = $rEdit['category'];
	}
	else {
		$cat_id = null;
		$category = null;
	}

	/* start <sblog_main> */
	ob_start();

?>
			<form id="categories" method="post" action="categories_do.php">
			<div class="sblog_post">
			<div class="sblog_post_topic">
				<h1><?php echo lang('Categories'); ?></h1>
			</div>
			<div class="sblog_post_text">
					<input type="button" value="<?php echo lang('Go back'); ?>" onclick="javascript:document.getElementById('categories').action='<?php echo $ref; ?>';submit();" class="sblog_button" />
					<input type="submit" value="<?php echo lang('Create'); ?>" class="sblog_button" /><br /><br />
					<fieldset>
						<input type="hidden" name="cat_id" id="cat_id" value="<?php echo $cat_id; ?>" />
						<input type="hidden" name="ref" id="ref" value="<?php echo $ref; ?>" />
						<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
						<input type="hidden" name="category_id" id="category_id" value="<?php echo $category_id; ?>" />
						<input type="hidden" name="topic" id="topic" value="<?php echo htmlspecialchars($topic); ?>" />
						<input type="hidden" name="text" id="text" value="<?php echo htmlspecialchars($text); ?>" />
						<input type="hidden" name="date_created" id="date_created" value="<?php echo $date_created; ?>" />
						<input type="hidden" name="del_id" id="del_id" value="" />
						<legend><?php echo lang('Add new category'); ?></legend>
						<div class="sblog_var"><?php echo lang('Category'); ?></div>
						<div class="sblog_val"><input type="text" name="category" id="category" value="<?php echo htmlspecialchars(sStripSlashes($category)); ?>" class="sblog_input" /></div>
					</fieldset>
<?php

	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}

	$query = 'SELECT id, category FROM ' . $conf_mysql_prefix . 'categories WHERE id!=\'1\' ORDER BY category ASC';
	
	$q = mysql_query($query);
	$n = mysql_num_rows($q);
	
	if($n > 0) {
		echo "\t\t\t\t\t" . '<fieldset>' . "\n";
		echo "\t\t\t\t\t\t" . '<legend>' . lang('Existing categories') . '</legend>' . "\n";
		
		while($r = mysql_fetch_assoc($q)) {
			echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="#" onclick="javascript:document.getElementById(\'del_id\').value=\'' . $r['id'] . '\';document.getElementById(\'categories\').action=\'categories_del.php\';document.getElementById(\'categories\').submit();return false">' . lang('Delete') . '</a>' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="' . $_SERVER['PHP_SELF'] . '?cat_id=' . $r['id'] . '">' . lang('Edit') . '</a>' . "\n";
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
			echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
			echo "\t\t\t\t\t\t\t" . '<a href="' . sRewrite('category', 'cat', $r['id']) . '">' . truncate($r['category'], 32) . '</a>' . "\n";
			echo "\t\t\t\t\t\t" . '</div>' . "\n";
		}
		
		echo "\t\t\t\t\t" . '</fieldset>' . "\n";
	}

	mysql_close();

?>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>
			</form>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>