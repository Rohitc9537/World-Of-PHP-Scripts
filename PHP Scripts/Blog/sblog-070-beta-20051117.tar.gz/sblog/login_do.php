<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	session_start();

	require('inc/config.php');

	if($_POST['username'] == $conf_admin_username && md5($_POST['password']) == $conf_admin_password) {
		$_SESSION['Username'] = $conf_admin_username;

		setcookie('username', $conf_admin_username, time() + (3600 * 24 * 7));
		setcookie('password', $conf_admin_password, time() + (3600 * 24 * 7));
	}
	
	header("Location: index.php");
	exit;

?>