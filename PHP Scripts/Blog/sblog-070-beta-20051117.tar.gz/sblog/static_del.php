<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// make sure only administrator access this page
	require('inc/auth.php');

	if(array_key_exists('id', $_REQUEST) && intval($_REQUEST['id']) > 0 && array_key_exists('ok', $_REQUEST) && intval($_REQUEST['ok']) == 1) {
		$id = intval($_REQUEST['id']);
		
		require('inc/mysql.php');
		
		$query = 'DELETE FROM ' . $conf_mysql_prefix . 'static WHERE id=\'' . $id . '\' LIMIT 1';
		
		mysql_query($query);
		mysql_close();
		
		header("Location: static.php");
		exit;
	}
	else {
		// include headers
		require('inc/tpl_header.php');
		require('inc/tpl_menu.php');

		// include blocks
		require('inc/block_custom.php');			// custom blocks

		/* start <sblog_main> */
	
		ob_start();

?>

	<div class="sblog_post">
		<div class="sblog_post_topic">
			<h1><?php echo lang('Delete static page?'); ?></h1>
		</div>
		<div class="sblog_post_text">
			<?php echo lang('Are you sure you want to delete this page?'); ?><br /><br />
			<input type="button" value="<?php echo lang('Go back'); ?>" onClick="javascript:history.go(-1);return false" class="sblog_button" />
			<input type="button" value="<?php echo lang('OK'); ?>" onClick="javascript:location.href='static_del.php?id=<?php echo $_REQUEST['id']; ?>&ok=1';return false" class="sblog_button" />
		</div>
		<div class="sblog_post_options">&nbsp;</div>
	</div>
<?php

		$tpl_temp = trim(ob_get_contents());
		$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
		
		ob_end_clean();
		
		/* end <sblog_main> */
		
		require('inc/tpl_foot.php');
	
		echo $tpl_main;
	}

?>