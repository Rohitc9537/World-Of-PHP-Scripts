<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="../style/Blue.css" />
<title>sBLOG Installer: Step 2 / 4</title>
<style type="text/css">
<!--

	.ok {
		color: #000;
	}
	
	.error {
		color: #900;
	}
	
	.alter {
		color: #F90;
	}
	
	.update {
		color: #69C;
	}
	
	.create {
		color: #090;
	}
	
	.none {
		color: #CCC;
	}

-->
</style>
</head>
<body>

<?php

	// fetch version info
	if(file_exists('../inc/version.ini')) {
		$v = parse_ini_file('../inc/version.ini', false);
	}
	else {
		$v['conf_current_version'] = null;
		$v['conf_current_buidl'] = null;
	}
	
	// define variables
	$msg = null;
	$error = null;

	// mysql
	$mysql_hostname = $_POST['mysql_hostname'];
	$mysql_username = $_POST['mysql_username'];
	$mysql_password = $_POST['mysql_password'];
	$mysql_database = $_POST['mysql_database'];
	$mysql_prefix = $_POST['mysql_prefix'];
	
	// administrator
	$admin_username = $_POST['admin_username'];
	$admin_password = $_POST['admin_password'];
	$admin_email = $_POST['admin_email'];
	
	// version variables
	$conf_current_version = $v['conf_current_version'];
	$conf_current_build = $v['conf_current_build'];
	
	// server
	$doc_root = $_POST['doc_root'];
	$web_root = $_POST['web_root'];
	
	if(strlen($admin_username) == 0) {
		$error = 1;
		$msg[] = '<span class="error"><strong>Administrator:</strong> Invalid username!</span>';
	}
	
	if(strlen($admin_password) < 4) {
		$error = 1;
		$msg[] = '<span class="error"><strong>Administrator:</strong> The password is too short!</span>';
	}
	
	if(strlen($admin_email) == 0) {
		$error = 1;
		$msg[] = '<span class="error"><strong>Administrator:</strong> An e-mail address is required!</span>';
	}
	
	if(strlen($doc_root) == 0) {
		$error = 1;
		$msg[] = '<span class="error">Document root: You have to specify the document root!</span>';
	}

	if(strlen($web_root) == 0) {
		$error = 1;
		$msg[] = '<span class="error">Web root: You have to specify the web root!</span>';
	}
	else if(substr($web_root, 0, 7) != 'http://' || substr($web_root, -1, 1) != '/') {
		$error = 1;
		$msg[] = '<span class="error">Web root: The web root must start with "http://" and end width "/" !</span>';
	}
	
	// connect to host
	if(@mysql_connect($mysql_hostname, $mysql_username, $mysql_password)) {
		$msg[] = '<span class="ok"><strong>MySQL:</strong> Connected to host.</span>';
		
		// select database
		if(@mysql_select_db($mysql_database)) {
			$msg[] = '<span class="ok"><strong>MySQL:</strong> Selecting database "' . $mysql_database . '".</span>';

			// generate list of tables			
			$queryShowTables = 'SHOW TABLES FROM ' . $mysql_database;
			$qShowTables = mysql_query($queryShowTables);
			
			$tables = array();
			while($rShowTables = mysql_fetch_row($qShowTables)) {
				$tables[$rShowTables[0]] = 1;
			}

			// create sblog_blocks
			$queryBlocks = 'CREATE TABLE ' . $mysql_prefix . 'blocks (id int(11) unsigned NOT NULL auto_increment, block_topic varchar(64) default NULL, block_content text, block_vis set(\'0\',\'1\') NOT NULL default \'0\', block_pos int(11) unsigned default \'0\', block_style set(\'0\',\'1\') NOT NULL default \'1\', block_top set(\'0\',\'1\') NOT NULL default \'1\', PRIMARY KEY (id));';

			if(!array_key_exists($mysql_prefix . 'blocks', $tables)) {
				mysql_query($queryBlocks);
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'blocks created.</span>';
				
				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (1,\'{CALENDAR}\',NULL,\'1\',10,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (2,\'{ARCHIVE}\',NULL,\'1\',20,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (3,\'{CATEGORIES}\',NULL,\'1\',30,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (4,\'{LATEST}\',NULL,\'1\',40,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (5,\'{COMMENTS}\',NULL,\'1\',50,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (6,\'{SEARCH}\',NULL,\'1\',60,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (7,\'{LINKS}\',NULL,\'1\',70,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (8,\'{STYLE}\',NULL,\'1\',80,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (9,\'{RSS}\',NULL,\'1\',90,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (10,\'{ADMIN}\',NULL,\'1\',100,\'1\',\'1\');');
			}
			else if(array_key_exists($mysql_prefix . 'blocks', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'blocks already exists. Leaving it as it is.</span>';

				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (1,\'{CALENDAR}\',NULL,\'1\',10,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (2,\'{ARCHIVE}\',NULL,\'1\',20,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (3,\'{CATEGORIES}\',NULL,\'1\',30,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (4,\'{LATEST}\',NULL,\'1\',40,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (5,\'{COMMENTS}\',NULL,\'1\',50,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (6,\'{SEARCH}\',NULL,\'1\',60,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (7,\'{LINKS}\',NULL,\'1\',70,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (8,\'{STYLE}\',NULL,\'1\',80,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (9,\'{RSS}\',NULL,\'1\',90,\'1\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'blocks (id, block_topic, block_content, block_vis, block_pos, block_style, block_top) VALUES (10,\'{ADMIN}\',NULL,\'1\',100,\'1\',\'1\');');
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'blocks!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_categories
			$queryCategories = 'CREATE TABLE ' . $mysql_prefix . 'categories (id int(11) unsigned NOT NULL auto_increment, date_created datetime default NULL, date_modified timestamp NOT NULL, category varchar(32) NOT NULL default \'\', PRIMARY KEY (id));';

			if(!array_key_exists($mysql_prefix . 'categories', $tables) && mysql_query($queryCategories)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'categories created.</span>';
				
				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'categories (id, date_created, category) VALUES (1, \'' . date('Y-m-d H:i:s') . '\', \'Uncategorized\');');
			}
			else if(array_key_exists($mysql_prefix . 'categories', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'categories already exists. Leaving it as it is.</span>';
				
				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'categories (id, date_created, category) VALUES (1, \'' . date('Y-m-d H:i:s') . '\', \'Uncategorized\');');
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'categories!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_censoring
			$queryCensoring = 'CREATE TABLE ' . $mysql_prefix . 'censoring (id int(11) unsigned NOT NULL auto_increment, word_orig text NOT NULL, word_repl text, PRIMARY KEY (id));';

			if(!array_key_exists($mysql_prefix . 'censoring', $tables) && mysql_query($queryCensoring)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'censoring created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'censoring', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'censoring already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'censoring!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}
			
			// create sblog_comments
			$queryComments = 'CREATE TABLE ' . $mysql_prefix . 'comments (id int(11) unsigned NOT NULL auto_increment, blog_id int(11) unsigned NOT NULL default \'0\', date_created datetime NOT NULL default \'0000-00-00 00:00:00\', username varchar(32) NOT NULL default \'n/a\', email varchar(255) default NULL, homepage text, comment text NOT NULL, PRIMARY KEY (id));';
			
			if(!array_key_exists($mysql_prefix . 'comments', $tables) && mysql_query($queryComments)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'comments created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'comments', $tables)) {
				$queryCommentsAlter = 'ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'comments CHANGE COLUMN homepage homepage text NULL;';
				if(mysql_query($queryCommentsAlter)) {
					$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'comments already exists. Updating structure.</span>';
				}
				else {
					$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'comments already exists. Leaving it as it is.</span>';
				}
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'comments!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}
			
			// create sblog_config
			$queryConfig = 'CREATE TABLE ' . $mysql_prefix . 'config (conf_name varchar(32) NOT NULL default \'\', conf_value text, PRIMARY KEY (conf_name));';
			
			if(mysql_query($queryConfig) || array_key_exists($mysql_prefix . 'config', $tables)) {
				if(array_key_exists($mysql_prefix . 'config', $tables)) {
					$msg[] = '<span class="update"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'config exists. Updating data.</span>';
				}
				else {
					$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'config created.</span>';
				}

				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_admin_email\',\'' . $admin_email . '\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_admin_password\',\'' . md5($admin_password) . '\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_admin_username\',\'' . $admin_username . '\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_bar_comments_disp\',\'10\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_bar_latest_disp\',\'10\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_block_chars\',\'20\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_comments_act\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_comments_email\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_count_posts_vis\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_current_build\',\'' . $conf_current_build . '\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_current_version\',\'' . $conf_current_version . '\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_date\',\'%Y-%m-%d %H:%M\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_expert\',\'0\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_img_width\',\'320\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_lang_default\',\'English\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_link_new\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_local_time_vis\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_mod_rewrite\',\'0\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_page_description\',\'Yet another great sBLOG!\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_page_disp\',\'4\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_page_title\',\'sBLOG\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_style_default\',\'Blue\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_syndicate_act\',\'1\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_syndicate_limit\',\'15\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_time_offset\',\'0\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_trackback_act\',\'0\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_trunc_pos\',\'right\');');
				mysql_query('INSERT INTO ' . $mysql_prefix . 'config (conf_name, conf_value) VALUES (\'conf_version_vis\',\'1\');');

				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'%Y-%m-%d %H:%M\' WHERE conf_name=\'conf_date\';');
				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'' . $admin_email . '\' WHERE conf_name=\'conf_admin_email\';');
				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'Blue\' WHERE conf_name=\'conf_style_default\';');

				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'' . $conf_current_version . '\' WHERE conf_name=\'conf_current_version\';');
				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'' . $conf_current_build . '\' WHERE conf_name=\'conf_current_build\';');

				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'' . $admin_username . '\' WHERE conf_name=\'conf_admin_username\';');
				mysql_query('UPDATE ' . $mysql_prefix . 'config SET conf_value=\'' . md5($admin_password) . '\' WHERE conf_name=\'conf_admin_password\';');
			}
			else if(array_key_exists($mysql_prefix . 'config', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'config already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'config!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}
			
			// create sblog_data
			$queryData = 'CREATE TABLE ' . $mysql_prefix . 'data (id int(11) unsigned NOT NULL auto_increment, category_id int(11) NOT NULL default \'1\', date_created datetime NOT NULL default \'0000-00-00 00:00:00\', date_modified timestamp NOT NULL, topic varchar(64) NOT NULL default \'n/a\', text text, ping set(\'0\',\'1\') NOT NULL default \'0\', ping_url text, draft set(\'0\',\'1\') NOT NULL default \'0\', PRIMARY KEY (id));';

			if(!array_key_exists($mysql_prefix . 'data', $tables) && mysql_query($queryData)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data created.</span>';
				mysql_query('INSERT INTO ' . $mysql_prefix . 'data SET date_created=\'' . date('YmdHis') . '\', date_modified=\'' . date('YmdHis') . '\', topic=\'Hello World\', text=\'[b]Hello World[/b] :D\';');
			}
			else if(array_key_exists($mysql_prefix . 'data', $tables)) {
				$queryDataFields = 'SHOW COLUMNS FROM ' . $mysql_prefix . 'data';
				$qDataFields = mysql_query($queryDataFields);
				
				while($rDataFields = mysql_fetch_assoc($qDataFields)) {
					$fields[$rDataFields['Field']] =	array(
																	'type' => $rDataFields['Type'],
																	'null' => $rDataFields['Null'],
																	'default' => $rDataFields['Default']
																);
				}
				
				if(array_key_exists('text', $fields) && $fields['text']['type'] != 'text' || array_key_exists('date_created', $fields) && $fields['date_created']['type'] != 'datetime') {
					if(mysql_query('ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'data CHANGE COLUMN text text text NULL, CHANGE COLUMN date_created date_created datetime;')) {
						$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data already exists. Updating structure. (text, date_created))</span>';
					}
					else {
						$error = 1;
						$msg[] = '<span class="error"><strong>MySQL:</strong> Could not update structure for ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
					}
				}
				
				if(!array_key_exists('category_id', $fields)) {
					if(mysql_query('ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'data ADD COLUMN category_id int(11) NOT NULL default \'1\' AFTER id;')) {
						$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data already exists. Updating structure. (category_id)</span>';
					}
					else {
						$msg[] = '<span class="error"><strong>MySQL:</strong> Could not update structure for ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
					}
				}
				
				if(!array_key_exists('ping', $fields)) {
					if(mysql_query('ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'data ADD COLUMN ping set(\'0\',\'1\') NOT NULL default \'0\' AFTER text;')) {
						$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data already exists. Updating structure. (ping)</span>';
					}
					else {
						$msg[] = '<span class="error"><strong>MySQL:</strong> Could not update structure for ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
					}
				}
				
				if(!array_key_exists('ping_url', $fields)) {
					if(mysql_query('ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'data ADD COLUMN ping_url text AFTER text;')) {
						$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data already exists. Updating structure. (ping_url)</span>';
					}
					else {
						$msg[] = '<span class="error"><strong>MySQL:</strong> Could not update structure for ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
					}
				}
				
				if(!array_key_exists('draft', $fields)) {
					if(mysql_query('ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'data ADD COLUMN draft set(\'0\',\'1\') NOT NULL default \'0\' AFTER text;')) {
						$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'data already exists. Updating structure. (draft)</span>';
					}
					else {
						$msg[] = '<span class="error"><strong>MySQL:</strong> Could not update structure for ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
					}
				}
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'data!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}
			
			// create sblog_img
			$queryImg = 'CREATE TABLE ' . $mysql_prefix . 'img (id int(11) NOT NULL auto_increment, dir_id int(11) unsigned default \'1\', filename varchar(255) NOT NULL default \'\', filetype text, filesize int(11) unsigned default NULL, filemtime datetime default NULL, description varchar(255) default NULL, PRIMARY KEY (id));';

			if(!array_key_exists($mysql_prefix . 'img', $tables) && mysql_query($queryImg)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'img created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'img', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'img already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'img!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_img_dir
			$queryImgDir = 'CREATE TABLE ' . $mysql_prefix . 'img_dir (id int(11) NOT NULL auto_increment, dir_name varchar(32) NOT NULL default \'\', PRIMARY KEY (id));';
			
			if(mysql_query($queryImgDir) || array_key_exists($mysql_prefix . 'img_dir', $tables)) {
				if(array_key_exists($mysql_prefix . 'img_dir', $tables)) {
					$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'img_dir exists. Leaving it as it is.</span>';
				}
				else {
					$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'img_dir created.</span>';
				}

				// default values
				mysql_query('INSERT INTO ' . $mysql_prefix . 'img_dir (id, dir_name) VALUES (1,\'Default\');');
			}
			else if(array_key_exists($mysql_prefix . 'img_dir', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'img_dir already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'img_dir!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_links
			$queryLinks = 'CREATE TABLE ' . $mysql_prefix . 'links (id int(11) unsigned NOT NULL auto_increment, date_created datetime default NULL, date_modified timestamp NOT NULL, link_title varchar(32) NOT NULL default \'n/a\', link_url text, PRIMARY KEY (id));';
			
			if(!array_key_exists($mysql_prefix . 'links', $tables) && mysql_query($queryLinks)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'links created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'links', $tables)) {
				$queryLinksAlter = 'ALTER TABLE ' . $mysql_database . '.' . $mysql_prefix . 'links CHANGE COLUMN link_url link_url text NULL, CHANGE COLUMN date_created date_created datetime;';
				if(mysql_query($queryLinksAlter)) {
					$msg[] = '<span class="alter"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'links already exists. Updating structure.</span>';
				}
				else {
					$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'links already exists. Leaving it as it is.</span>';
				}
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'links!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}
			
			// create sblog_menu
			$queryMenu = 'CREATE TABLE ' . $mysql_prefix . 'menu (id int(11) unsigned NOT NULL auto_increment, menu_title varchar(64) default NULL, menu_description varchar(255) default NULL, menu_url text, menu_vis set(\'0\',\'1\') NOT NULL default \'0\', menu_pos int(11) unsigned default \'0\', PRIMARY KEY (id));';
			
			if(!array_key_exists($mysql_prefix . 'menu', $tables) && mysql_query($queryMenu)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'menu created.</span>';
				mysql_query('INSERT INTO ' . $mysql_prefix . 'menu SET menu_title=\'Home\', menu_description=\'Home\', menu_url=\'' . $web_root . '\', menu_vis=\'1\', menu_pos=\'10\'');
				echo mysql_error();
			}
			else if(array_key_exists($mysql_prefix . 'menu', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'menu already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'menu!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_static
			$queryStatic = 'CREATE TABLE ' . $mysql_prefix . 'static (id int(11) unsigned NOT NULL auto_increment, date_created datetime NOT NULL, date_modified timestamp NOT NULL, topic varchar(64) NOT NULL default \'n/a\', content text, draft set(\'0\',\'1\') NOT NULL default \'0\', static_style set(\'0\',\'1\') NOT NULL default \'1\', static_top set(\'0\',\'1\') NOT NULL default \'1\', PRIMARY KEY (id));';
			
			if(!array_key_exists($mysql_prefix . 'static', $tables) && mysql_query($queryStatic)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'static created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'static', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'static already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'static!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

			// create sblog_trackbacks
			$queryTrackbacks = 'CREATE TABLE ' . $mysql_prefix . 'trackbacks (id int(11) NOT NULL auto_increment, date_created datetime NOT NULL default \'0000-00-00 00:00:00\', blog_id int(11) NOT NULL default \'0\', title varchar(255) default NULL, excerpt varchar(255) default NULL, url text NOT NULL, blog_name varchar(255) default NULL, PRIMARY KEY (id));';
			
			if(!array_key_exists($mysql_prefix . 'trackbacks', $tables) && mysql_query($queryTrackbacks)) {
				$msg[] = '<span class="create"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'trackbacks created.</span>';
			}
			else if(array_key_exists($mysql_prefix . 'trackbacks', $tables)) {
				$msg[] = '<span class="none"><strong>MySQL:</strong> Table ' . $mysql_prefix . 'trackbacks already exists. Leaving it as it is.</span>';
			}
			else {
				$error = 1;
				$msg[] = '<span class="error"><strong>MySQL:</strong> Could not create ' . $mysql_prefix . 'trackbacks!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
			}

		}
		else {
			$error = 1;
			$msg[] = '<span class="error"><strong>MySQL:</strong> Database "' . $mysql_database . '" does not exist!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
		}
		mysql_close();
	}
	else {
		$error = 1;
		$msg[] = '<span class="error"><strong>MySQL:</strong> Could not connect to "' . $mysql_hostname . '"!<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
		$msg[] = '<span class="error"><strong>MySQL:</strong> Make sure you entered correct hostname, username and password.<br />' . mysql_errno() . ' ' . mysql_error() . '</span>';
	}

?>

<div id="sblog_root">
	<div id="sblog_head">
		<div id="sblog_page_title">
			<h1 id="sblog_page_title_text">sBLOG Installer</h1>
		</div>
		<div id="sblog_page_description">
			<h2 id="sblog_page_description_text">Step: 2 / 4</h2>
		</div>
	</div>
	<div id="sblog_body">
		<div id="sblog_block_body">
			<div><img src="sblogo.png" alt="sBLOGo" /></div>
		</div>
		<div id="sblog_main">
			<form id="install" method="post" action="install_chmod.php">
				<input type="hidden" name="mysql_hostname" id="mysql_hostname" value="<?php echo $mysql_hostname; ?>" />
				<input type="hidden" name="mysql_username" id="mysql_username" value="<?php echo $mysql_username; ?>" />
				<input type="hidden" name="mysql_password" id="mysql_password" value="<?php echo $mysql_password; ?>" />
				<input type="hidden" name="mysql_database" id="mysql_database" value="<?php echo $mysql_database; ?>" />
				<input type="hidden" name="mysql_prefix" id="mysql_prefix" value="<?php echo $mysql_prefix; ?>" />
				<input type="hidden" name="admin_username" id="admin_username" value="<?php echo $admin_username; ?>" />
				<input type="hidden" name="admin_password" id="admin_password" value="<?php echo $admin_password; ?>" />
				<input type="hidden" name="admin_email" id="admin_email" value="<?php echo $admin_email; ?>" />
				<input type="hidden" name="doc_root" id="doc_root" value="<?php echo $doc_root; ?>" />
				<input type="hidden" name="web_root" id="web_root" value="<?php echo $web_root; ?>" />
<?php

	if($error == 1) {
		$next = ' disabled="disabled"';
	}
	else {
		$next = null;
	}

	if(isset($msg)) {
		echo "\t\t\t" . '<fieldset>' . "\n";
		echo "\t\t\t\t" . '<legend>Message(s)</legend>' . "\n";
		echo "\t\t\t\t" . '<ul>' . "\n";
		while(list(, $val) = each($msg)) {
			echo "\t\t\t\t\t" . '<li>' . $val . "</li>\n";
		}
		echo "\t\t\t\t" . '</ul>' . "\n";
		echo "\t\t\t" . '</fieldset>' . "\n";
	}

?>
				<fieldset>
					<legend>Options</legend>
					<input type="reset" value="Go back" onclick="javascript:history.go(-1);return false" class="sblog_button" />
					<input type="submit" value="Next step"<?php echo $next; ?> class="sblog_button" />
				</fieldset>
				</form>
			</div>
	</div>
	<div id="sblog_copy"></div>
	<div id="sblog_foot"></div>
</div>

</body>
</html>