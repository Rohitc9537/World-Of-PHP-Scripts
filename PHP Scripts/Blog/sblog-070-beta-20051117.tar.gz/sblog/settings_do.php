<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('config.php');
	require('inc/config.php');
	require('inc/func_config_update.php');
	require('inc/mysql.php');

	// PERSONAL
	if(array_key_exists('admin_email', $_POST)) {
		sblog_config_update('conf_admin_email', mysql_real_escape_string($_POST['admin_email']));
	}
	
	if(array_key_exists('comments_email', $_POST) && intval($_POST['comments_email']) > 0) {
		$comments_email = 1;
	}
	else {
		$comments_email = 0;
	}
	sblog_config_update('conf_comments_email', $comments_email);
	
	if(array_key_exists('comments_act', $_POST) && intval($_POST['comments_act']) > 0) {
		$comments_act = 1;
	}
	else {
		$comments_act = 0;
	}
	sblog_config_update('conf_comments_act', $comments_act);
	
	if(array_key_exists('trackback_act', $_POST) && intval($_POST['trackback_act']) > 0) {
		$trackback_act = 1;
	}
	else {
		$trackback_act = 0;
	}
	sblog_config_update('conf_trackback_act', $trackback_act);
	
	if(array_key_exists('syndicate_act', $_POST) && intval($_POST['syndicate_act']) > 0) {
		$syndicate_act = 1;
	}
	else {
		$syndicate_act = 0;
	}
	sblog_config_update('conf_syndicate_act', $syndicate_act);

	// PAGE
	sblog_config_update('conf_page_title', mysql_real_escape_string($_POST['page_title']));
	
	if(array_key_exists('style_logo', $_POST)) {
		$style_logo = 1;
	}
	else {
		$style_logo = 0;
	}
	
	sblog_config_update('conf_style_logo', $style_logo);
	
	sblog_config_update('conf_page_description', mysql_real_escape_string($_POST['page_description']));

	// LIMITS
	if(array_key_exists('page_disp', $_POST)) {
		sblog_config_update('conf_page_disp', intval($_POST['page_disp']));
	}
	
	if(array_key_exists('bar_latest_disp', $_POST)) {
		sblog_config_update('conf_bar_latest_disp', intval($_POST['bar_latest_disp']));
	}
	
	if(array_key_exists('bar_comments_disp', $_POST)) {
		sblog_config_update('conf_bar_comments_disp', intval($_POST['bar_comments_disp']));
	}
	
	if(array_key_exists('img_width', $_POST)) {
		sblog_config_update('conf_img_width', intval($_POST['img_width']));
	}
	
	if(array_key_exists('block_chars', $_POST)) {
		sblog_config_update('conf_block_chars', intval($_POST['block_chars']));
	}
	
	if(array_key_exists('syndicate_limit', $_POST)) {
		sblog_config_update('conf_syndicate_limit', intval($_POST['syndicate_limit']));
	}
	
	// DATE AND TIME
	sblog_config_update('conf_date', mysql_real_escape_string($_POST['conf_date']));
	sblog_config_update('conf_time_offset', mysql_real_escape_string($_POST['time_offset']));

	// STYLE
	sblog_config_update('conf_style_default', mysql_real_escape_string($_POST['style_default']));

	// LANGUAGE
	sblog_config_update('conf_lang_default', mysql_real_escape_string($_POST['lang_default']));
	
	// LINKS
	if(array_key_exists('link_new', $_POST)) {
		$link_new = 1;
	}
	else {
		$link_new = 0;
	}
	sblog_config_update('conf_link_new', $link_new);
	
	if(array_key_exists('mod_rewrite', $_POST) && intval($_POST['mod_rewrite']) > 0) {
		$mod_rewrite = 1;
	}
	else {
		$mod_rewrite = 0;
	}
	sblog_config_update('conf_mod_rewrite', $mod_rewrite);
	
	// MISC
	if(array_key_exists('expert', $_POST)) {
		$expert = 1;
	}
	else {
		$expert = 0;
	}
	sblog_config_update('conf_expert', $expert);

	if(array_key_exists('version_vis', $_POST)) {
		$version_vis = 1;
	}
	else {
		$version_vis = 0;
	}
	sblog_config_update('conf_version_vis', $version_vis);
	
	if(array_key_exists('local_time_vis', $_POST)) {
		$local_time_vis = 1;
	}
	else {
		$local_time_vis = 0;
	}
	sblog_config_update('conf_local_time_vis', $local_time_vis);
	
	if(array_key_exists('count_posts_vis', $_POST)) {
		$count_posts_vis = 1;
	}
	else {
		$count_posts_vis = 0;
	}
	
	sblog_config_update('conf_count_posts_vis', $count_posts_vis);
	
	sblog_config_update('conf_trunc_pos', $_POST['trunc_pos']);

	mysql_close();
	
	header("Location: settings.php");
	exit;

?>