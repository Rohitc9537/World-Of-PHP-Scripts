<?php

	require('inc/auth.php');
	
	$id = intval($_REQUEST['id']);
	
	if($id > 1) {
		/* open mysql connection */
		require('inc/mysql.php');
		
		/* delete image directory */
		$query = 'DELETE FROM ' . $conf_mysql_prefix . 'img_dir WHERE id=\'' . $id . '\' LIMIT 1';
		mysql_query($query);
		
		/* update images assigned to the deleted directory */
		$query = 'UPDATE ' . $conf_mysql_prefix . 'img SET dir_id=\'1\' WHERE dir_id=\'' . $id . '\'';
		mysql_query($query);
		
		/* close mysql connection */
		mysql_close();
	}
	
	header('Location: img_folder.php');
	exit;

?>