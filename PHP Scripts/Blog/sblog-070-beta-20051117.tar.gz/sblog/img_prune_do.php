<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// include headers
	require('inc/tpl_header.php');			// header
	require('inc/tpl_menu.php');				// menu
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	/* start <sblog_main> */
	ob_start();

?>
<!-- START OF LIST -->
<div class="sblog_post">
	<div class="sblog_post_topic">
		<h1><?php echo lang('Prune'); ?></h1>
	</div>
	<div class="sblog_post_text">
		<input type="button" value="<?php echo lang('Go back'); ?>" onclick="javascript:location.href='image.php'" class="sblog_button" /><br /><br />
<?php

	require('inc/mysql.php');
	
	$query = 'SELECT id, filename FROM ' . $conf_mysql_prefix . 'img';
	$q = mysql_query($query);
	
	$c = 0;
	
	while($r = mysql_fetch_assoc($q)) {
		$queryFind = 'SELECT id FROM ' . $conf_mysql_prefix . 'data WHERE text LIKE \'%upload/' . $r['filename'] . '%\'';
		$qFind = mysql_query($queryFind);
		$nFind = mysql_num_rows($qFind);
		if($nFind == 0) {
			$c++;
			// filenames
			$filename = 'upload/' . $r['filename'];
			$thumbnail = 'upload/tn/' . $r['filename'];
		
			// remove image and thumbnail
			@unlink($filename);
			@unlink($thumbnail);
			
			mysql_query('DELETE FROM ' . $conf_mysql_prefix . 'img WHERE id=\'' . $r['id'] . '\'');

			echo "\t\t\t" . $r['filename'] . '<br />' . "\n";
		}
	}
	
	echo "\t\t\t" . '<br />' . sprintf(lang('Done. %u image(s) were deleted.'), $c) . "\n";
	
	mysql_close();

?>
	</div>
	<div class="sblog_post_options">&nbsp;</div>
</div>
<!-- END OF LIST -->
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');

	echo $tpl_main;

?>