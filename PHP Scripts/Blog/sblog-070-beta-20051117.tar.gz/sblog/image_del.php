<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	// admin only!
	require('inc/auth.php');
	
	$id = intval($_GET['id']);
	
	// open mysql connection
	require('inc/mysql.php');
	
	// mysql queries
	$query = 'SELECT id, filename FROM ' . $conf_mysql_prefix . 'img WHERE id=\'' . $id . '\' LIMIT 1';
	$q = mysql_query($query);
	$n = mysql_num_rows($q);

	if($n > 0) {
		// fetch results
		$r = mysql_fetch_assoc($q);
		
		// delete image from database
		mysql_query('DELETE FROM ' . $conf_mysql_prefix . 'img WHERE id=\'' . $r['id'] . '\' LIMIT 1');
		
		// filenames
		$filename = 'upload/' . $r['filename'];
		$thumbnail = 'upload/tn/' . $r['filename'];
	
		// remove image and thumbnail
		@unlink($filename);
		@unlink($thumbnail);
	}
	
	// close mysql connection
	mysql_close();
	
	// send back user to 'images'
	header('Location: image.php');
	exit;	

?>