<?php

	header('Location: ../syndication.php?action=article');

?>