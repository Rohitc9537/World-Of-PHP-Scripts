<?php

	/**************************************************

		Project	sBLOG <http://sblog.sourceforge.net>
		Author	Servous <servous@gmail.com>
		License	GPL

	 **************************************************/

	require('inc/auth.php');
	require('inc/tpl_header.php');
	require('inc/tpl_menu.php');
	
	// include blocks
	require('inc/block_custom.php');			// custom blocks

	require('inc/mysql.php');

	if(array_key_exists('id', $_GET) && intval($_GET['id']) > 0) {
		$id = intval($_GET['id']);
		
		$queryEdit = 'SELECT dir_name FROM ' . $conf_mysql_prefix . 'img_dir WHERE id=\'' . $id . '\' LIMIT 1';
		$qEdit = mysql_query($queryEdit);
		$rEdit = mysql_fetch_assoc($qEdit);
		
		$dir_name = $rEdit['dir_name'];
	}
	else {
		$id = null;
		$dir_name = null;
	}

	/* start <sblog_main> */
	ob_start();

?>
				<div class="sblog_post">
				<div class="sblog_post_topic">
					<h1><?php echo lang('Images') . ': ' . lang('Folders'); ?></h1>
				</div>
				<div class="sblog_post_text">
				<form id="img_dir" method="post" action="img_folder_do.php">
					<div><input type="submit" value="<?php echo lang('Create folder'); ?>" class="sblog_button" /><br /><br /></div>
					<fieldset>
						<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
						<legend><?php echo lang('Create folder'); ?></legend>
						<div class="sblog_var"><?php echo lang('Folder'); ?></div>
						<div class="sblog_val"><input type="text" name="dir_name" id="dir_name" value="<?php echo htmlspecialchars(sStripSlashes($dir_name)); ?>" class="sblog_input" /></div>
					</fieldset>
<?php

	if(!function_exists('truncate')) {
		require('inc/func_truncate.php');
	}

	$query = 'SELECT id, dir_name FROM ' . $conf_mysql_prefix . 'img_dir ORDER BY dir_name ASC';
	
	$q = mysql_query($query);
	$n = mysql_num_rows($q);
	
	if($n > 1) {
		echo "\t\t\t\t\t" . '<fieldset>' . "\n";
		echo "\t\t\t\t\t\t" . '<legend>' . lang('Existing folders') . '</legend>' . "\n";

		while($r = mysql_fetch_assoc($q)) {
			if($r['id'] != 1) {
				echo "\t\t\t\t\t\t" . '<div class="sblog_var">' . "\n";
				echo "\t\t\t\t\t\t\t" . '<a href="img_folder_del.php?id=' . $r['id'] . '">' . lang('Delete') . '</a>' . "\n";
				echo "\t\t\t\t\t\t\t" . '<a href="img_folder.php?id=' . $r['id'] . '">' . lang('Edit') . '</a>' . "\n";
				echo "\t\t\t\t\t\t" . '</div>' . "\n";
				echo "\t\t\t\t\t\t" . '<div class="sblog_val">' . "\n";
				echo "\t\t\t\t\t\t\t" . truncate($r['dir_name'], 32) . "\n";
				echo "\t\t\t\t\t\t" . '</div>' . "\n";
			}
		}

		echo "\t\t\t\t\t" . '</fieldset>' . "\n";
	}
	
	mysql_close();

?>
				</form>
			</div>
			<div class="sblog_post_options">&nbsp;</div>
			</div>
<?php

	$tpl_temp = trim(ob_get_contents());
	$tpl_main = str_replace('<sblog_main>', $tpl_temp, $tpl_main);
	
	ob_end_clean();
	
	/* end <sblog_main> */
	
	require('inc/tpl_foot.php');
	
	echo $tpl_main;

?>