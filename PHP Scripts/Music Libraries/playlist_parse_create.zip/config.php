<?
// Upload a playlist in .m3u format in the same folder as the script files and add its name to the variable below

$playlist = "all.m3u";
?>
