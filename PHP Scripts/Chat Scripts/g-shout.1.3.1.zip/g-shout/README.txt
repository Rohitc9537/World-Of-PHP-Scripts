G-Shout version 2.0.1
----------------------
Release Date: February 15, 2005

Author  : Yohanes Pradono aka donie
Website : http://gravitasi.com
Email   : donie@gravitasi.com



All documentation, including installation instructions, can be found in the "user_guide" directory
For installation, read INSTALL.txt first and then run install.php script.

Sorry for my bad English, coz I am not a native English speaker.
Any ideas? Questions? Bugs reporting? or just wanna make a friendship? Feel free to send me email (donie@gravitasi.com)
Want to know more about me? Read docs/donie.txt

Thank you for using G-Shout.


Best Regards
-donie-

