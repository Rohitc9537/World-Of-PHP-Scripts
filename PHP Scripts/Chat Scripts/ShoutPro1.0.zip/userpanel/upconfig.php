<?php
/*
ShoutPro 1.0 - User Panel - upconfig.php
ShoutPro is released under the GNU General Public Liscense.  A full copy of this license is included with this distribution under the file LICENSE.TXT.  By using ShoutPro or the source code, you acknowledge you have read and agree to the license.

This file is upconfig.php.  It is part of the User Panel addon to ShoutPro.  Please set the varialbes in this file.
*/

$path = ".."; //Set this as the relative path from this folder to the ShoutPro folder.  No trailing slash is needed.  If the User Panel folder is inside the main ShoutPro folder, this should be set to ".."  If the User Panel files are in the main ShoutPro folder, set the path to "".
?>