fuck|^|f***|^|
shit|^|s***|^|
bitch|^|b****|^|