[b]|^|<b>|^|
[/b]|^|</b>|^|
[i]|^|<i>|^|
[/i]|^|</i>|^|
[u]|^|<u>|^|
[/u]|^|</u>|^|
[url]|^|[<a href='|^|
[/url]|^|' target='_blank'>www</a>]|^|
[mail]|^|[<a href=\'mailto:|^|
[/mail]|^|'>@</a>]|^|