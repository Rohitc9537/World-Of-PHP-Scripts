<?php die("You don't belong here, go away."); ?>
