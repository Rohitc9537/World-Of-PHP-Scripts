<?php require("config.php"); ?>
<html>
<head>
<title><?php echo $EZChat_ban_title; ?></title>
<link href="ez.css" rel="stylesheet" type="text/css">

</head>

<body>
<div id="chatbox" align="center">
<table vspace="5" width="178">
<tr>
	<td align="center" class="banned">You have been banned from this chatbox.<br>
      <br>
    If you feel that the ban is unjust then please contact the <a href="mailto:<?php echo $EZChat_email; ?>">System Administrator</a> and plead your
    case.</td>
</tr>
</table>
</div>
</body>
</html>