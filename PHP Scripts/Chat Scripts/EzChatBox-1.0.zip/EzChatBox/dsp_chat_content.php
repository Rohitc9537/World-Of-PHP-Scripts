
<font face="Arial" size="2" color="#ffffcc"><b><i>Terminal_fire</i></b>  <font size="1">(15:18)</font> : <font color="#ffffff">Thank you for choosing EZChatBox - Alpha Release. <img src="Images/smilies/smile.gif" alt="smile" /></font></font><br />
