<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Smilies</title>
<script language="JavaScript">
<!--
function x() 
{ return; }

function insertEmoticon(addSmilie) {
    var addSmilie; var revisedMessage;
    var currentMessage = window.opener.document.inpform.message.value;
    revisedMessage = currentMessage+addSmilie;
    window.opener.document.inpform.message.value=revisedMessage;
    window.opener.document.inpform.message.focus();
	
}
//-->
</script>

<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: small;
}
-->
</style>
</head>

<body>
<span class="style1">Please choose the smilie you wish to add.</span>
<br>
<br>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':)');"><img src='Images/smilies/smile.gif' alt=':)' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':o');"><img src='Images/smilies/amazed.gif' alt=':o' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':eek:');"><img src='Images/smilies/weird.gif' alt=':eek:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':D');"><img src='Images/smilies/biggrin.gif' alt=':D' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':worried:');"><img src='Images/smilies/worried.gif' alt=':worried:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':hehe:');"><img src='Images/smilies/wink.gif' alt=':hehe:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':wacko:');"><img src='Images/smilies/wacko.gif' alt=':wacko:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':p');"><img src='Images/smilies/cheesy.gif' alt=':p' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':s');"><img src='Images/smilies/confused.gif' alt=':s' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon('(H)');"><img src='Images/smilies/cool.gif' alt='(H)' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':cry:');"><img src='Images/smilies/crying.gif' alt=":'(" border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':$');"><img src='Images/smilies/embarrest.gif' alt=':$' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon('(6)');"><img src='Images/smilies/evil.gif' alt='(6)' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':huh:');"><img src='Images/smilies/huh.gif' alt=':huh:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':lol:');"><img src='Images/smilies/laugh.gif' alt=':lol:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':mad:');"><img src='Images/smilies/mad.gif' alt=':mad:' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon('|)');"><img src='Images/smilies/notrust.gif' alt='|)' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':relax:');"><img src='Images/smilies/noworry.gif' alt=':relax:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon('8()');"><img src='Images/smilies/nuts.gif' alt='8()' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':|');"><img src='Images/smilies/oh.gif' alt=':|' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':5queeze:');"><img src='Images/smilies/push.gif' alt=':5queeze:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':rolleyes:');"><img src='Images/smilies/rolleyes.gif' alt=':rolleyes:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':sad:');"><img src='Images/smilies/sad-2.gif' alt=':sad:' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':(');"><img src='Images/smilies/sad.gif' alt=':(' border="0"></a></td>
</tr>
<tr>
	<td colspan="4"><img src="Images/spacer.gif" height="8"></td>
</tr>
<tr>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':x');"><img src='Images/smilies/sick.gif' alt=':x' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':8');"><img src='Images/smilies/smile-2.gif' alt=':8' border="0"></a></td>
	<td align="center" width="25%"><a href="javascript:x();javascript:window.close()" onClick="insertEmoticon(':suspicious:');"><img src='Images/smilies/suspicious.gif' alt=':suspicious:' border="0"></a></td>
	<td align="center" width="25%">&nbsp;</td>
</tr>
</table>
</body>
</html>