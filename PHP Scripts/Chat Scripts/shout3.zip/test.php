<table width=120 border=1 bgcolor="#EACA19">
<tr><td><?php include("shout.txt"); ?></td></tr>
<tr><td>
<form method="POST" action="shout.php">
name:<input size="15" maxlength="15" type="text" name="name">
shout:<input size="15" maxlength="25" type="text" name="c">
<center>
<input type="submit" value="Shout">
</center>
</form>
</td></tr></table>
