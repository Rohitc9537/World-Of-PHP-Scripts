 <html>
<head>
<title>IRC ToChat Beta Test 1</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="DESCRIPTION" content="ToChat script chat irc... " />
<meta name="ROBOTS" content="INDEX,FOLLOW" />
<meta name="resource-type" content="document" />
<meta http-equiv="expires" content="0" />
<meta name="author" content="Maroc Touch" />
<meta name="copyright" content="Copyright (c) 2003 by Maroc Touch" />
<meta name="revisit-after" content="1 days" />
<meta name="distribution" content="Global" />
<meta name="generator" content="ToChat 1.3 - http://www.to.ma" />
<meta name="rating" content="General" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#996699" link="#3333FF" vlink="#333366" alink="#0000CC" topmargin="0" leftmargin="0" rightmargin="0">
<div align="center">
    <script type="text/javascript"><!--
google_ad_client = "pub-8863871430268948";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "660000";
google_color_bg = "7D2626";
google_color_link = "FFFFFF";
google_color_url = "DAA520";
google_color_text = "BDB76B";
//--></script>
    <script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
  </script>
</div>
<br>