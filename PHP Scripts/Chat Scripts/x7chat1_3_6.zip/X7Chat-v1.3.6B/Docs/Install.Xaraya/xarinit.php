<?php
/**
 * File: $Id:
 */

function X7chat_init()
{

    return true;
}

function X7chat_upgrade($oldversion)
{
    return true;
}

function X7chat_delete()
{
    return true;
}

?>
