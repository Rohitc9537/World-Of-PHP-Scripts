<?php
/**
 * File: $Id:
 */
$modversion['name']           = 'X7chat';
$modversion['id']             = '138';
$modversion['version']        = '1.3.6B';
$modversion['displayname']    = xarML('X7 Chat');
$modversion['description']    = 'A PHP based chat room.';
$modversion['credits']        = 'The X7 Group';
$modversion['help']           = '';
$modversion['changelog']      = '';
$modversion['license']        = 'GNU GPL';
$modversion['official']       = 0;
$modversion['author']         = 'X7 Group';
$modversion['contact']        = 'http://www.x7chat.com/';
$modversion['admin']          = 0;
$modversion['user']           = 1;
$modversion['securityschema'] = array('chat::' => '::');
$modversion['class']          = 'Content';
$modversion['category']       = 'Complete';
?>
