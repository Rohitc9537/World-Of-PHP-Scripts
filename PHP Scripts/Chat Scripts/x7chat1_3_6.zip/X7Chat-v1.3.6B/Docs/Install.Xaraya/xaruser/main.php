<?
function chat_user_main()
{ 
    	echo '<script language="javascript" type="text/javascript">
			window.open("http://x7chat.com/Xaraya/Chat/","Chat");
 			history.go(-1);
		</script> ';
}
?>