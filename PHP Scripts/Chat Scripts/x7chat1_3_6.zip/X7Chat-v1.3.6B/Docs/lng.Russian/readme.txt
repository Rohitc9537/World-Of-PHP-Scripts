Here are the buttons for X7 Chat translated into Russian.  To use unrar the file
and upload the buttons into the images directory and overwrite the old ones.

Translated to Russian by: Volf
