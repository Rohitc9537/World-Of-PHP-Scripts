										How to install Ready ChatBox

History:
1.0 - June 15, 2005 -The original.										
1.2 - June 22, 2005 -Added language filter, flood protection, and changed the validation a bit.

  Copyright � 2005 WebsiteReady.Net. All Rights Reserved
  This file is part of Ready ChatBox.
  This script should have been freely downloadable at:
  http://www.websiteready.net
  
Ready ChatBox is distributed in the hopes that it will be useful,
  but WITHOUT ANY WARRANTY. Use at your own risk.
  
You should have received a copy of the GNU General Public License
  along with Ready ChatBox; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
  You may obtain a copy at http://www.gnu.org/copyleft/gpl.html
  
The link back to WebsiteReady may not be removed. It helps others to obtain the script.
The link is so that others may use the script, just as you are - does that not seem fair?
If you REALLY want to remove it, you may contact WebsiteReady.Net and purchase a copyright removal.
  
Thanks for using Ready ChatBox!
  

  Steps to install Ready ChatBox:
  
1.) Edit the settings.php file in the chatbox directory to fit your needs.  Descriptions are given in the file.
  
2.) Upload the chatbox directory to your server.
  
3.) In your web browser, go to yoursite.com/chatbox/install.php
	  Click the "install" button, and continue doing what it says.
  
4.) Once you have installed successfuly, you need to login to the administration panel.
	Once you do so, you will be given the code to include your chatbox in your php file.
	To have your chatbox work, you need to put it on your (PHP) page.
	The code should look something like this:
		<?php 
		inclue('/home/user/public_html/path/to/chatbox/chatbox.php') 
		?>
5.) You are now done :)
	Good luck and I hope this script works well for you :)
	You can get support for this script at:
	http://www.websiteready.net
	
  