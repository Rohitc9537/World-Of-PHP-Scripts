
<html>
<head>
<title>ClearChat Smilies</title>
<link rel="stylesheet" href="../common/clearchat.css" type="text/css">
<script language="JavaScript" src="../common/clearchat.js" type="text/javascript"></script>
</head>
<body bgcolor="#000044">

<table border="0" cellspacing="0" cellpadding="0">

<tr>
<td width="160">
<table border="0" cellspacing="11" cellpadding="0">

<tr>
<td colspan="4" align="center"><span class="heading">Available<br>smilies</span></td>
</tr>

<?php
require "config.php";
?>

<tr height="25">
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-bigeek- or :O';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-bigeek-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>bigeek.gif" width="15" border="0" alt="Big eek"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-biggrin- or :D';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-biggrin-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>biggrin.gif" width="15" border="0" alt="Big grin"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-bigrazz- or :P';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-bigrazz-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>bigrazz.gif" width="15" border="0" alt="Big razz"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-confusedw-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-confusedw-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>confusedw.gif" width="15" border="0" alt="Confused"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-cool- or 8)';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-cool-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>cool.gif" width="15" border="0" alt="Cool"></a></td>
</tr>

<tr height="25">
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-cry-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-cry-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>cry.gif" width="15" border="0" alt="Crying"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-dead- or X(';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-dead-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>dead.gif" width="15" border="0" alt="Dead"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-eek-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-eek-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>eek.gif" width="15" border="0" alt="Eek"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-embarrassed-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-embarrassed-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>embarrassed.gif" width="15" border="0" alt="Embarrassed"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-laugh-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-laugh-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>laugh.gif" width="15" border="0" alt="Laughing"></a></td>
</tr>

<tr height="25">
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-mad-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-mad-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>mad.gif" width="15" border="0" alt="Mad"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-no-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-no-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>no.gif" width="15" border="0" alt="No"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-careless- or :|';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-careless-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>none.gif" width="15" border="0" alt="Careless"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-razz-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-razz-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>razz.gif" width="15" border="0" alt="Razz"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-roll-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-roll-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>roll.gif" width="15" border="0" alt="Rolling eyes"></a></td>
</tr>

<tr height="25">
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-rolleyes-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-rolleyes-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>rolleyes.gif" width="15" border="0" alt="Rolling eyes"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-sad- or :(';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-sad-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>sad.gif" width="15" border="0" alt="Sad"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-shy-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-shy-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>shy.gif" width="15" border="0" alt="Shy"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-sighw-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-sighw-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>sighw.gif" width="15" border="0" alt="Sigh"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-sleepw-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-sleepw-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>sleepw.gif" width="15" border="0" alt="Sleeping"></a></td>
</tr>

<tr height="25">
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-smile- or :)';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-smile-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>smile.gif" width="15" border="0" alt="Smile"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-smilegrin- or ;D';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-smilegrin-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>smilewinkgrin.gif" width="15" border="0" alt="Smile &amp; grin"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-upsetw-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-upsetw-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>upsetw.gif" width="15" border="0" alt="Upset"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-wink- or ;)';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-wink-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>wink.gif" width="15" border="0" alt="Wink"></a></td>
<td width="18" valign="bottom" align="center"><a href="Javascript:void(0)" onMouseOver="window.document.preview.previewfield.value='-yes-';" onMouseOut="window.document.preview.previewfield.value='';" onClick="addSmiley('-yes-');"><img src="../common/smilies/<?php echo $smileycolor; ?>/<?php echo $smileycolor; ?>yes.gif" width="15" border="0" alt="Yes"></a></td>
</tr>

<tr>
<td valign="top" colspan="5" align="center">
<form name="preview" action="smilies.php">
<input type="text" name="previewfield" size="16" readonly>
</form>
</td>
</tr>

</table>
</td>

<td width="110">
<span class="say">Here are all the available smiles you can use in ClearChat. Move your mouse over a smiley, and the code for it will be displayed in the field. If you want to add a smiley to the chat-field simply click on it and the code will be inserted for you.</span>
</td>
</tr>

<tr>
<td colspan="2" height="24" align="center" valign="middle">
<a href="JavaScript:onClick=window.close()">Close window</a>
</td>
</tr>

</table>

</body>
</html>