<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="pragma" content="no-cache">
<title>Undocked ClearChat</title>
</head>
<frameset rows="65,*" frameborder="0" framespacing="0" border="0">
<frame src="input.php?username=<?php echo $username; ?>" name="inputframe" scrolling="no" noresize>
<frame src="view.php" name="outputframe" scrolling="auto" noresize>
</frameset>
</html>