<HTML>
<FRAMESET rows="*,0,0" border="1" FRAMEBORDER="0">
<FRAME name="rtmenu" src="rt_menu.php" marginwidth=10 marginheight=0 noresize FRAMEBORDER=1 scrolling='no' border=1>
<FRAME name="chatter" src="chatter.php?user=<?php print($_GET['user']); ?>" marginwidth=10 marginheight=0 noresize FRAMEBORDER=0 scrolling='no' border=1>
<FRAME name="process" src="process.php?first=1" marginwidth=10 marginheight=0 noresize FRAMEBORDER=0 scrolling='no' border=1>
</FRAMESET>
</HTML>