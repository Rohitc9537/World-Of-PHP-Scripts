<html>
<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Admin Help by Liquid Frog</title>
</head>
<table border="0" cellpadding="2" style="border-collapse: collapse" bordercolor="#111111" width="955" id="AutoNumber2" cellspacing="0">
  <tr>
    <td width="5">&nbsp;</td>
    <td width="565" colspan="2" bgcolor="#EBE7E7">
    <p align="center"><font face="Verdana" size="1">ADMIN HELP</font></p>
    <p>&nbsp;</td>
    <td width="11">&nbsp;</td>
    <td width="363" rowspan="22" bgcolor="#99CCFF" valign="top">
    <p align="justify"><font face="Verdana" size="1">We hope that you are
    pleased with your chat script and that it works well for you. We would like
    to take this opportunity to make you aware of one of our current product
    lines.</font></p>
    <p align="justify"><b><font face="Verdana" size="1">AVANTI WEB STATS:</font></b></p>
    <p align="justify"><font face="Verdana" size="1">How many websites do you
    run? Are you tired of logging into each one to check your stats? Now you can
    check ALL your stats for ALL your sites AT THE SAME TIME and in THE SAME
    PLACE - YOUR DESKTOP!</font></p>
    <p align="justify"><font face="Verdana" size="1">Avanti is the only stats
    package that can do this. Whilst this is clever enough, we understand that
    it is only of value if the stats it provides are highly detailed. Avanti is
    probably the most advanced stats package available anywhere. Not only that
    but it also includes a comprehensive site checker. Be warned if your sites
    go down and get them back up immediately! Want more? Avanti also has an
    inbuilt hit counter. Check out the features list.</font></p>
    <p align="justify"><font face="Verdana" size="1">Features:</font></p>
    <ul>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>No database to set up</b>
      </font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Easy install and
      set up</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Works on all types of web
      site</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Automatic update
      notification</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Web site scripts written
      in PHP</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>All site stats password
      protected</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Show stat details as text
      or charts</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Exclude your own IP from
      the stats</b> </font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Statistics
      downloaded to your local PC</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Print statistics
      straight to your printer</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Free updates for
      the life of the software</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">All stats are
      viewable from your desktop</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Monitors ALL your
      websites for availability</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Monitors traffic
      details from ALL your sites</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">One licence covers
      any number of websites</font></b><font size="1"> </font></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Individual site
      stats are viewable from your site</font></b><font size="1"> </font></font>
      </li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Monitor your web traffic
      details in near real time</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>See which search engine
      queries have been used</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Can be set to monitor
      multiple pages on your sites</b> </font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Monitor traffic on
      any number of web sites you like</font></b><font size="1"> </font></font>
      </li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Warns you by email and
      popup if your sites go down</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Track visitors right
      through your site to the exit page</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>You can define how many
      days worth of stats to display</b> </font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">ALL your stats
      available in one place for instant checking</font></b><font size="1">
      </font></font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Define filters to show
      stats only from certain days or weeks etc</b> </font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Discover a
      multitude of statistics about your sites </font></b></font></li>
      <li>
      <p align="left"><font face="Verdana"><b><font size="1">Notifies you
      immediately a website is unreachable by your visitors</font></b><font size="1">
      </font></font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>See which search engines
      send you the most traffic (and the least)</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Runs in the background on
      your PC to continually monitor your sites</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>3 in 1 - records your
      stats, monitors your sites and provides a hit counter</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Web site monitoring from
      your PC can be disabled with a single right click</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Allows you the choice of
      showing or hiding the inbuilt&nbsp; web site hit counter</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Highly configurable - you
      decide how often to check for stats &amp; site availability</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>Records stats for years&nbsp;
      - Look back and see how your traffic patterns changed</b> </font></li>
      <li>
      <p align="left"><font size="1" face="Verdana"><b>And still more!</b>
      </font></li>
    </ul>
    <p align="justify"><font face="Verdana" size="1">Remember, this is just <i>
    some</i> of what Avanti will do. For full details and to get your own free
    copy, click [<a target="_blank" href="http://liquidfrog.bestdirectbuy.com/Avanti_Web_Stats.htm">here</a>]</font></td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="565" colspan="2" bgcolor="#EBE7E7">
    <p align="center"><font face="Verdana" size="1">Chatter box is a free script
    provided by Liquid Frog Software. For help or support click&nbsp; <a target="_blank" href="http://www.liquidfrog.com">[here]</a></font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="565" colspan="2" bgcolor="#EBE7E7">&nbsp;</td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Main Menu -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">The main admin page</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Add banner -</font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Allows you to add a banner to the banner list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Delete
    banner -</font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Deletes the selected banner from the banners
    list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">View Banners
    -</font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Allows you to view banner stats</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Add IP -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Add an IP to the ban list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Delete IP -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Remove an IP from the ban list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">View all
    IP's - </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Shows all the IP's in the ban list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Kick User -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Kicks the selected user</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Ban User -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Bans the selected user and adds his IP to the
    banned IP list</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Log out -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Logs you out of admin</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Enter Chat -
    </font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">Enters chat using the name &quot;Admin&quot;</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7"><font face="Verdana" size="1">Admin Help -</font></td>
    <td width="451" bgcolor="#EBE7E7" align="justify">
    <font face="Verdana" size="1">This file</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7">&nbsp;</td>
    <td width="451" bgcolor="#EBE7E7">&nbsp;</td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7" valign="top"><b><font face="Verdana" size="1">Removing
    the link to Liquid Frog -</font></b></td>
    <td width="451" bgcolor="#EBE7E7" valign="top"><font face="Verdana" size="1">Please be aware that because this is a free
    script we can offer no support for it other than what is in the Faq's
    already. We hope you find this script both enjoyable and useful. From time
    to time we update or add new free scripts and software. If you would like to
    be notified when this happens, go to the Liquid Frog site and click on News Letter
    in the menu. You can also check out our privacy policy in the same way.</font><p align="justify">
            <font face="Verdana" size="1">If you use this script please leave 
            the link to Liquid Frog intact - it is a condition of use. You may 
            request removal of the link for a small fee and we will mail you the 
            version of the script without the link. Link removal is just $7.99, 
            please order below: </font><p align="justify">
            &nbsp;<table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber3" height="49">
      <tr>
        <td width="50%" height="19"><font face="Verdana" size="1">Pay Pal:</font></td>
        <td width="50%" height="19"><font face="Verdana" size="1">Credit Card:</font></td>
      </tr>
      <tr>
        <td width="50%" height="23">
        <p align="center"><font face="Verdana" size="1">
<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but23.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" width="67" height="22" align="left"></font></td>
        <td width="50%" height="23">
        <a target="_blank" href="http://store.eSellerate.net/s.aspx?s=STR5398925396">
        <img border="0" src="esellerate.gif" lowsrc="Purchase%20link%20removal%20via%20credit%20card"></a></td>
      </tr>
    </table>
    <p align="center">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="liquidfrog@liquidfrog.bestdirectbuy.com">
<input type="hidden" name="item_name" value="Chatter Box - Web link removal">
<input type="hidden" name="item_number" value="Chatter Box - Web link removal">
<input type="hidden" name="amount" value="7.99">
<input type="hidden" name="no_shipping" value="1">
<input type="hidden" name="return" value="http://liquidfrog.bestdirectbuy.com/link_remove_success.html">
<input type="hidden" name="cancel_return" value="http://liquidfrog.bestdirectbuy.com/link_remove_cancel.html">
<input type="hidden" name="currency_code" value="USD">
&nbsp;<p></p>
<p></p>
<p></p>
<p></p>
<p></p>
<p></p>
</form></font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7" valign="top"><b><font face="Verdana" size="1">Problems?</font></b></td>
    <td width="451" bgcolor="#EBE7E7" align="justify" valign="top">&nbsp;</td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7" valign="top"><b><font face="Verdana" size="1">I can't see the chat


messages -</font></b></td>
    <td width="451" bgcolor="#EBE7E7" align="justify" valign="top"><font face="Verdana" size="1">Occasionally the chat window


may not refresh. This could be for many reasons but they are mostly browser


related and is a problem easily overcome. Simply type a single space into the


chat area and press enter. This will have the effect of forcing a refresh and


the chat messages will become visible again.</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7" valign="top"><b><font face="Verdana" size="1">I keep hearing clicking


noises - What is it? -</font></b></td>
    <td width="451" bgcolor="#EBE7E7"><font face="Verdana" size="1">This script is written in both


PHP and JavaScript. The clicking noises you can hear are the PHP part of the


script processing the refresh in order to show new messages. This is a function


of the server the script is installed on (PHP is a server side language) and


there is nothing that can be done. In the next version of this script we may


re-write the code so that it refreshes in a slightly different way to try and


avoid the clicking noise. If it bothers you the best idea is to simply turn your


sound down or off.</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7" valign="top"><b><font face="Verdana" size="1">I have noticed that my chat


session is slowing down -</font></b></td>
    <td width="451" bgcolor="#EBE7E7"><font face="Verdana" size="1">From time to time you may


notice that your chat window takes longer to refresh than normal. This is


possibly because you have set the chat script to have a


high maximum chatter number. This script works best when there are 8 or less


chatters. We recommend that an administrator does not set this number higher


than 10 unless they have a powerful server and plenty of bandwidth. If there are


more than 6 or 8 people chatting at the same time, it is likely that you will


notice some loss of performance and, if there are more than 10 people chatting,


the performance loss will probably be significant. You can help to avoid


performance issues by disabling smilies. Because smilies are graphic files, they


take more processing to display than simple text. The more smilies that are


used, the slower the chat will be.</font></td>
    <td width="11">&nbsp;</td>
  </tr>
  <tr>
    <td width="5">&nbsp;</td>
    <td width="114" bgcolor="#EBE7E7">&nbsp;</td>
    <td width="451" bgcolor="#EBE7E7">&nbsp;</td>
    <td width="11">&nbsp;</td>
  </tr>
</table>
</body>
</html>