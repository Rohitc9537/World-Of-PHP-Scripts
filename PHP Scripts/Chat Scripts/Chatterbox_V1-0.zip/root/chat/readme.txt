To remove the link to Liquid Frog from this script
click Help in Admin