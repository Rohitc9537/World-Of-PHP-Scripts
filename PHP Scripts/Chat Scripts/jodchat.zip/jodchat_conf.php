<?

//password must not contain any spaces
$moderator_password = "secret";

//to enable moderator kicking set $moderator_kick = true;
$moderator_kick = false;


//to enable moderator bombing set $moderator_bomb = true;
$moderator_bomb = false;

//tell browser at what rate to check for new messages
$check_rate = 2;



?>