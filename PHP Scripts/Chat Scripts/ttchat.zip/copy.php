<? 
/*
This is TigerTom's Chat Room Software (TTChat).

http://www.tigertom.com
http://www.ttfreeware.com

Copyright (c) 2005 T. O' Donnell

Released under the GNU General Public License, with the
following proviso: 

That the HTML of hyperlinks to the authors' websites
this software generates shall remain intact and unaltered, 
in any version of this software you make.
 
If this is not strictly adhered to, your licence shall be 
rendered null, void and invalid.
*/

include("chat.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title><? echo chat_name; ?></title>
<link rel="STYLESHEET" type="text/css" href="chatstyles.css">
</head>

<body style="margin: 0px">

<p align="center">
<!--// Removing or altering the hyperlinks to our sites in any way invalidates your licence to use this script //-->
<FONT style="font-size: 7pt"><a href="http://www.ttfreeware.com">TTChat</a> originally developed for <a href="http://www.tigertom.com">TigerTom</a> by <a href="http://www.lpin.net">LP Inform�tica</a></FONT></p>

</body>
</html>
