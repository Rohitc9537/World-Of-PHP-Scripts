======================================================================================================================
INTRODUCTION
======================================================================================================================
This is a PHP chat-box. It requires PHP and MySQL. 

======================================================================================================================
LICENSE
======================================================================================================================
This script is freeware for non-commercial use. If you like it, please feel free to make a donation!
However, if you intend to use the script in a commercial project, please donate at least EUR 10.
You can make a donation on my website: http://www.gerd-tentler.de/tools/shoutbox/.

======================================================================================================================
USAGE
======================================================================================================================
Extract the files to your webserver, adapt the configuration ("config.inc.php", "shoutbox.css") to your needs, and 
create the MySQL table using the provided "shoutbox.sql". Then include "shoutbox.inc.php" in your website (PHP file) 
where you want your chat-box to appear.

======================================================================================================================
Source code + example available at http://www.gerd-tentler.de/tools/shoutbox/.
======================================================================================================================