<?
header('location: chat.php');
?>