DSCHAT 1.0 README
-------------------------

CONTENTS:
 1) Installation
 2) Explanation
 
1) INSTALLATION
 -Upload all the files (including the folders) somewhere onto your site
 -CHMOD:
  -users to 0777.
  -cdata.html to 0777.
  -chatconfig.html to 0777.
 -Edit chatconfig.php to the things prompted.
 -Re-upload chatconfig.php.
 -Enjoy!
 
2) EXPLANATION
 Here's a small explanation so you know what things are and how they work.
  This script should be pretty self explanitory... Should; Thats why I'm
  still going to explain it.
  First, you have to log in. The way it's made, you don't need a password
  to get into the chat. I personally love this. So just select your
  nickname and click Submit. Then click Go to the chat! when you're 
  logged in.
  Now you're in the chat! Talk by selecting the text bar at the bottom
  and type.. Then hit Enter or click Send and it'll appear in the
  chat box above! Notice on the right, it says who's in the chat room.
  Now, it says a notice when people leave, enter, the chat data gets dumped,
  and when someone gets kicked.
  Every 15 lines of text, the room 'dumps' it's self. This means that it
  clears the data files and the room is clear so you can see what you're
  typing again. You can also do this manually by using the Admin Panel.
  To get into the admin panel, click Admin Panel at the bottom right.
  Now you can use the password you provided when you configured it the
  room. Here you can kick people, dump the chat data, and edit the config
  file.
  Well, that's about it. Just remember: If you close the window without 
  clicking Log Out at the top, you'll be in there forever until you
  log back in or get kicked.
  Also, new to DSChat, the Autokick system. It automatically kicks everyone
  in the chat at midnight, every night. Very useful if your users don't know
  how to click "Logout", like mine.
  Enjoy, and leave the powered by link on or else I will be
  forced to prod you with a stick really hard.
  
  
  TROUBLESHOOTING:
  If you have any trouble, just post under the DSNewsletter 1.0 topic on the
  Dvondrake Studios forums at http://forums.dvondrake.com.
  
----------------------------------------------------------------------------------
Everything, even this readme, is copyright 2005 Dvondrake Studios
http://www.dvondrake.com/