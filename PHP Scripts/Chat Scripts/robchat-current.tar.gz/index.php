<script>
function popIt(file)
        {
        arg1 = file;
        openWin = window.open(arg1,"myWindow","top=80 ,left=80,width=727,height=408, buttons=no,scrollbars=yes,location=no,menubar=no,resizable=yes, status=no,directories=no,toolbar=no");
        openWin.focus();
        }
</script>

<?
include("xmlhttp.js");
include("xmlhttp.php");
echo "<html>";
echo "<body style='overflow:hidden;' bgcolor='#ff9900'>";
echo "<font style='font-family:Monospace; font-size:18px;'>5425 Coffee Chat</font><p>";
echo "<form name='chat' action=javascript:update()>";

echo "<table border=0 cellpadding=0 cellspacing=0>";
echo "<tr><td><font style='font-family:Monospace; font-size:12px;'>Name</font></td>";
echo "<td width=3></td>";
echo "<td><font style='font-family:Monospace; font-size:12px;'>Text</font></td></tr>";
echo "<tr><td><input type=text size=6 name='screenname' onFocus='javascript:whofocus(1)' onBlur='javascript:whofocus(0)' style='border-style:none;font-family:Monospace; font-size:12px;'></td>";
echo "<td width=3></td>";
echo "<td><input type=text size=68 name='message' style='border-style:none;font-family:Monospace; font-size:12px;'></td>";
echo "<td><button type=submit style='font-family:Monospace; font-size:11px;'>Send</button></td></tr>";
echo "</table>";
echo "<textarea cols=80 rows=20 name='chatwindow' wrap=virtual style='scrollbar-face-color:#ff9900;font-family:Monospace;border-style:none; font-size:12px; background-color:ffcc00;color:black;'></textarea>&nbsp;";
echo "<textarea cols=15 rows=20 name='whowindow' wrap=virtual style='scrollbar-face-color:#ff9900;font-family:Monospace;border-style:none;font-size:12px; background-color:ffcc00;color:black;'></textarea><br><br>";
echo "<a href=javascript:popIt(" . chr(39) . $PHP_SELF . chr(39). ")>Send chat into a popup window</a>";
echo "</form>";
echo "</body>";
echo "</html>";
?>
