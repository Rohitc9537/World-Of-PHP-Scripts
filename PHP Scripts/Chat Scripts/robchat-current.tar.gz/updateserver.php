<?
$chatfile = "chat.txt";
$chatadd = date("n/j/y g:ia",time()) ." ". stripslashes($_GET[msg]) . "\n";
$handle = fopen($chatfile,'a');
fwrite($handle,$chatadd);
fclose($handle);
$chat = file($chatfile);
$chat = array_reverse($chat);
for ($i=0;$i<=sizeof($chat);$i++)
	{
	echo $chat[$i];
	}
?>
