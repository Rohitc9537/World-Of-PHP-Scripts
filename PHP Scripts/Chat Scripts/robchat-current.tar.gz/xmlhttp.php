<script>
var typing;
function whofocus(state)
	{
	typing = state;
	return false;
	}
	
function read(who)
        {

	if (typing==1)
		{
		return false;
		};	
	
	var frm;
        frm=document.forms[0];

	// Pass the update server the value that was typed in.
	var url;
        url="readchat.php?who=" + who + "";
        xmlhttp.open("GET",url,true);
        xmlhttp.onreadystatechange=function()
                {
                if (xmlhttp.readyState==4)
                        {
                        frm.elements[3].value=xmlhttp.responseText;
                        }
                };

        xmlhttp.setRequestHeader('Accept','message/x-jl-formresult');
        xmlhttp.send(null);

	if(typing==0)
		{
		setTimeout("readwho()",1000);
		};

        return false;
	}

function readwho()
        {
	var frm;
        frm=document.forms[0];

	// Pass the update server the value that was typed in.
	var url;
        url="readwho.php";
        xmlhttp.open("GET",url,true);
        xmlhttp.onreadystatechange=function()
                {
                if (xmlhttp.readyState==4)
                        {
                        frm.elements[4].value=xmlhttp.responseText;
                        }
                };

        xmlhttp.setRequestHeader('Accept','message/x-jl-formresult');
        xmlhttp.send(null);

        return false;
	}

function update(msg)
        {
	var frm;
        frm=document.forms[0];

	if (frm.elements[0].value.length == 0)
		{
		alert('You must enter a screen name');
		return;
		}

	// Pass the update server the value that was typed in.
        url="updateserver.php?msg=" + frm.elements[0].value + "> " + frm.elements[1].value;
        xmlhttp.open("GET",url,true);
        xmlhttp.onreadystatechange=function()
                {
                if (xmlhttp.readyState==4)
                        {
                        frm.elements[3].value=xmlhttp.responseText;
                        }
                };

	frm.elements[1].focus();
	frm.elements[1].value = "";

        xmlhttp.setRequestHeader('Accept','message/x-jl-formresult');
        xmlhttp.send(null);
	}

</script>
