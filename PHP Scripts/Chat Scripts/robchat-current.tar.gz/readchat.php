<?
$chatfile = "chat.txt";
$chat = file($chatfile);
$chat = array_reverse($chat);
for ($i=0;$i<=sizeof($chat);$i++)
	{
	echo $chat[$i];
	}

//Process the WHO's online file.

//Find out if our user is already in the who file
$whofile = "who.txt";
$who = file($whofile);
$currentwho = trim($_GET[who]);
for ($i=0;$i<=sizeof($who);$i++)
	{
	$filewho = substr($who[$i],0,strpos($who[$i],"-"));

	// Get rid of stale users
	$now = time();
	if ((($now - substr($who[$i],strpos($who[$i],"-") +1,10)) > 5 ) && strlen($who[$i]) > 0)
		{
		//echo "Stale User: " . $who[$i] . "\n";
		$who[$i]="";
		}

	if ($filewho == trim($_GET[who]) && strlen(trim($_GET[who]))>0)
		{
		//Update the timestamp
		$found=1;
		$who[$i] = trim($_GET[who]) . "-" . time() . "\n";
		}
	}

// Write out the new who file

sort($who,SORT_STRING);
$who = array_reverse($who);
$handle = fopen($whofile,'w+');
for ($j=0;$j<=sizeof($who);$j++)
	{
	fwrite($handle,$who[$j]);
	}
fclose($handle);


if ($found!=1 && strlen(trim($_GET[who]))>0)
	{
	// The user is not in the who list, add them.
	$whoadd = stripslashes($_GET[who]) . "-" . time() . "\n";
	$handle = fopen($whofile,'a');
	fwrite($handle,$whoadd);
	fclose($handle);
	}

?>
