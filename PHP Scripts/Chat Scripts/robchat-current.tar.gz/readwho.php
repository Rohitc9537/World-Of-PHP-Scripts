<?
$whofile = "who.txt";
$who = file($whofile);
$who = array_reverse($who);
for ($i=0;$i<=sizeof($who);$i++)
	{
	if (strlen(trim($who[$i])) > 0)
		{
		$whouser = substr($who[$i],0,strpos($who[$i],"-"));
		echo $whouser . "\n";
		}
	}
?>
