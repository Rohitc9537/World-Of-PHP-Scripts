JaxBox v0.1 - AJAX Shoutbox - README
================================================

What is JaxBox?
	JaxBox is a php/AJAX shoutbox. the script is intended to
	demonstrate simple AJAX functionality in a (somewhat)
	practical application. 

What JaxBox Isn't:
	JaxBox is not a plug & play script. You will need to put
	a little work into integrating it into your website. You
	are welcome to use it as a shoutbox, but it is meant
	primarily to demonstrate usage.

Requirements:
	- PHP 4.0.3 or higher
	- The ability to CHMOD files
	- A JavaScript enabled browser

Installation:
	Upload everything to your website.
	CHMOD "shouts.txt" to 777 (755 on some filesystems)

	That's it. :) - The demo should work.

License:
	Nothing, really. Feel free to modify it for whatever uses
	you have in mind.

Thanks:
	Rai Shekkar wrote most of the JavaScript. I did the styling
	and the PHP, markup and some very minor JavaScript edits.
	The code was obtained from the tutorial on his website: 

	http://rajshekhar.net/blog/archives/85-Rasmus-30-second-AJAX-Tutorial.html

