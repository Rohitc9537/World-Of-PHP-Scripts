<?php
// Line 3: Location of where you shoutbox will be located, dont include / at the end
$location = "http://PATH TO SHOUTBOX";
// Line 5: Background color for the shoutbox pages
$bgcolor = "#E7E7E7";
// Line 7: Text color for the shoutbox pages
$text = "#333333";
// Line 9: Visited link color
$vlink = "#000000";
// Line 11: Active link color
$alink = "#FF9900";
// Line 13: Default link color
$link = "#000000";
// Line 15: Default background color of table rows
$table1 = "#F5F5F5";
// Line 17: Secondary background color of table tows
$table2 = "#F7F7F7";
// Line 19: Color of the table border
$table_bdr = "#CCCCCC";
// Line 21: Add to the hour of the time
$time_a = 0;
// Line 23: Max characters allowed to be posted in the message field
$max_char = 90;
// Line 25: Allow the shoutbox pages to scroll down or be fixed in position
$scroll = "no";
// Line 27: Title of the shoutbox pages which appears in the title bar
$title = "Title Name Here";
// Line 29: Change the refresh time of the page, recommended default is 0
$refresh = 0;
// Line 31: Second field value, the default  value is mailto: for e-mail of poster. Change to homepage put http://
$field2 = "mailto:";
// Line 33: Second field value input display, either http:// for homepage or you@domain.com for e-mail.
$field2input = "www.domain.com";
// Line 35: Second field display name either E-mail or Homepage.
$field2name = "E-mail";

$ipban = 'data/ipban.db';

$showonline = "<font face=\"Verdana, Arial, Helvetica, sans-serif\" font size=\"1\" color=\"#000000\"><b><online></b> users online</font>";

$firstonline = "<font face=\"Verdana, Arial, Helvetica, sans-serif\" font size=\"1\" color=\"#000000\"><b>1</b> user online</font>";

$datafile = "data/online.db";

$recordfile = "data/record.db";

$settings = 1;
?>