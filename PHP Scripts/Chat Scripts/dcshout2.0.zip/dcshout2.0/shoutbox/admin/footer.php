</td>
    </tr>
<tr>
<td>
<b>Dc shout by <a href="http://codez.darkdevils.co.uk">Devil Coderz</a>(c)2004-2005</b>
</td>
</table>
  </center>
</div>

</body>

</html>


