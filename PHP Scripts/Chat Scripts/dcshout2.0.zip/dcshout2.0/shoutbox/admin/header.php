<? session_start( ); ?>
<html>

<head>
<title>DC Shout Admin</title>
<link rel="stylesheet" type="text/css" href="http://codez.darkdevils.co.uk/css.css">
</head>

<body>

<div align="center">
  <center>
  <table border="1" cellpadding="0" cellspacing="1" width="653" height="345" bordercolor="#FFFFFF">
    <tr>
      <td width="653" height="37" bgcolor="#C0C0C0" bordercolor="#000000"><font size="6">DC
        Shout Admin</font></td>
    </tr>
    <tr>
      <td width="653" height="16" bgcolor="#C0C0C0" bordercolor="#000000">
        <p align="center"><a href="index.php?dc=logout">Logout</a> - <a href="options.php">Options</a> - <a href="word.php">Word Filter</a> - <a href="cpass.php">Change Password</a> -
       <a href="viewshout.php">View Shouts</a></td>
    </tr>
    <tr>
      <td width="653" height="292" bordercolor="#000000" valign="top">










