<link rel="stylesheet" type="text/css" href="http://codez.darkdevils.co.uk/css.css">
<table border="0" cellpadding="0" cellspacing="1" width="81" height="97">
    <tr>
      <iframe src="shoutbox/shout.php" scrolling="auto" width="149" height="150" frameborder="0" name="shoutbox">
Your browser doesn't support IFrames. The shoutbox cannot be displayed.</iframe> 
      <td width="44" height="13"><b>Name:</b></td>
      <td width="118" height="13">
 

 <form method="POST" action="shoutbox/shout.php" target="shoutbox">
          
          <input type="text" NAME="user" size="11">
        
      </td>
    </tr>
    <tr>
      <td width="44" height="72" bordercolor="#FFFFFF" class="news"><b>Message:</b></td>
      <td width="118" height="72" valign="top">
          <textarea rows="2" NAME="message" cols="8"></textarea>
        
        </td>
    </tr>
      <tr>
      <td width="158" height="26" colspan="2">
      
          <input type="submit" value="Submit" name="submit"><input type="reset" value="Reset" name="reset"></p>
        </form>
        <br>
<a href="javascript:bb()" target="shoutbox"><b>BB codes</b></a>
<br>
<a href="javascript:show()" target="shoutbox"><b>View past</b></a>
</td>
      </tr>
  </table>







