<?php
//Dc_shout functions script v2.0






?>












