<><><><><><><><><><><><><><><><><><><><><><><><><><>
Dc-Shout 2.0 readme file
<><><><><><><><><><><><><><><><><><<><><><><><><<><>
This will tell you how to install a new copy of Dc-shout.
If you don't want to install a new copy read upgrade.txt

Step 1
Upload all the files to your host You don't have to upload the trhis file and upgrade.txt.

Step 2
Edit config.php in the admin folder with all your database stuff
You must do this or you will get errors

Step 3
Open up install.php in you web broser e.g www.your-site.com/shoutbox/install.php
Click the new install link not the upgrade.
Then delete install.php so people can not use it.

Step 4
You can now login to the admin panel with this username and password
username= admin
password= test

Step 5
Edit the templates to your liking and to add a new tmeplate set just add a new folder and and the new template set and to chage the set edit the config.php in the admin folder

Step 6
Just  edit the shoutbox options and make sure you cxhage your password 


