<?php

print"<ul>";
print"<li><a href=$PHP_SELF?p=hospital>Hospital</a>";
print"<li><a href=$PHP_SELF?p=inn>Inn</a>";
print"</ul>";
