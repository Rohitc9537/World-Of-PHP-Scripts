<P><h1>Game Rules</h1></P>

<P>1. users must report any bugs to a member of the staff, using a bug to your advantage will result in Character downgrading or deletion depending on the size.</P>

<P>2. Any attemp to hack or otherwise infringe on another users account will result in being banned from the server</P>

<P>3. Any attemp to cheat the Refferal System will result in Character downgrading or deletion.</P>

<P>4. Any attemp to cheat the vote System will result in Character downgrading or deletion.</P>

<P>5. Abusing language/behaviour is unwelcome in Tsunami Channel Wars</P>

<P>6. if rule breaking behaviour keeps up, the punishments will get worse.</P>

<P>Rule breakers might find themselves in the prison, nothing can be achieved in the prison until the sentence time is up.</P>