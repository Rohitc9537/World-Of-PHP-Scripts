<?php

$tilesize=35;
$width=15;
$height=15;
$widthb=$width*$tilesize;
$heightb=$height*$tilesize;
$size=$width*$height;