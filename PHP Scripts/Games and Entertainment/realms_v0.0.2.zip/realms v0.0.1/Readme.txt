    //   ) )  //   / /  // | |     / /        /|    //| |     //   ) ) 
   //___/ /  //____    //__| |    / /        //|   // | |    ((        
  / ___ (   / ____    / ___  |   / /        // |  //  | |      \\      
 //   | |  //        //    | |  / /        //  | //   | |        ) )   
//    | | //____/ / //     | | / /____/ / //   |//    | | ((___ / /   
Realms source readme

1) Installation
2) Creating the Admin account
3) Information
4) Changelog

-------------

1) Installation

i...) Edit mysql.php to include your MySQL details
ii..) Edit config.php with desired settings
iii.) IMPORTANT - Add your mysql username to the secret word list in config.php
iv..) Upload all files to webspace
v...) Make sure the entries folder has create file and write file permissions
vi..) Run install.php
vii.) Delete install.php

-------------

2) Creating the Admin account

i...) Register a new account
ii..) Log into your mysql admin panel (PHPMyAdmin recomended)
iii.) Edit your newly created user data in "users" table, and change position to Admin

-------------

3) Information
The realms project aims to be the main internet life sim source out there, it was born as Tsunami channel wars, but has grown past the restraints of a fan project, now its here for you to use

if you have any problems with this source drop me an email at realms@tcgames.net or post to the http://www.tcgames.net forums, you can also play realms on my server at http://realms.tcgames.net

-------------

4) Changelog

8/22/2005
---
first release
---
