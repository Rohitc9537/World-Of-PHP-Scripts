<?php

print"<ul>";
print"<li><a href=$GAME_SELF?p=slots>Slots</a>";
print"<li><a href=$GAME_SELF?p=gridgame>The Grid Game</a>";
print"</ul>";