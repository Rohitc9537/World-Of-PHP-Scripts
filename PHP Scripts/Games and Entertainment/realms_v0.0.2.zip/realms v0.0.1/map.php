<?php

$testmap = "w*w*w*w*g*g*b*b*b*b*j*w*w*w*w*w*g*b*b*c*b*j*w*w*w*w*w*g*b*b*b*b*j*w*w*w*g*g*g*b*b*h*b*j*w*w*g*g*b*b*b*b*b*b*j*g*g*g*g*g*b*b*b*b*b*j*w*w*w*w*g*g*b*b*b*b*j*w*g*g*g*w*g*g*b*b*b*j*w*g*w*g*g*g*g*b*b*b*j*g*g*g*g*g*g*g*g*b*b";