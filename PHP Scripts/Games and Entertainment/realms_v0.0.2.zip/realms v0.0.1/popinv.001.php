<?php

print"<ul>";
print"<li><a href=$PHP_SELF?p=items>Your Items</a>";
print"<li><a href=$PHP_SELF?p=usershop>Your Shop</a>";
print"<li><a href=$PHP_SELF?p=shops>Shops</a>";
print"<li><a href=$PHP_SELF?p=bank>Bank</a>";
print"</ul>";