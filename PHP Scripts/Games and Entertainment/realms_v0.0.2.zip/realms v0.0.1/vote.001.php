<?php




print"<a href=\"http://apexwebgaming.com/in/103\"><img src=\"http://apexwebgaming.com/images/vote_1.gif\" width=\"468\" height=\"60\" alt=\"Vote at Apex Web Gaming\" border=\"0\"></a>
<BR>
<SCRIPT language=\"Javascript\" src=\"http://apexwebgaming.com/current_stats.php?id=103\"></SCRIPT>
<BR>";