<?
if ($page=="index") include "home.php";
if ($page=="logout") include "home.php";
if ($page=="authmain") include "home.php";
if ($page=="reg") include "register.php";
if ($page=="members") include "siteadmin/members.php";
if ($page=="roster") include "rostermain.php";
if ($page=="profile") include "profile.php";
if ($page=="charedit") include "users/charedit.php";
if ($page=="editresults") include "users/editresults.php";
if ($page=="addchar") include "users/addchar.php";
if ($page=="delchar") include "users/delchar.php";
if ($page=="delchar2") include "users/delchar2.php";
if ($page=="alts") include "users/alts.php";
if ($page=="indivalts") include "users/indivalts.php";
if ($page=="umem") include "siteadmin/unapproved.php";
if ($page=="delu") include "siteadmin/deleteusers.php";
if ($page=="trialists") include "siteadmin/trialists.php";
?>
