<br /><br />
<?
if (isset($_SESSION['valid_user']))
{
	echo '<a href="index.php?page=profile" />My Profile</a>';
}
?>
<br />
<a href="index.php?page=roster" />Roster</a><br />



