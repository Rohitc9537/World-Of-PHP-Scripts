CREATE TABLE `chat` (
  `id` int(255) NOT NULL auto_increment,
  `gid` int(255) NOT NULL default '0',
  `uid` int(255) NOT NULL default '0',
  `msg` text NOT NULL,
  `ts` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `documents` (
  `id` int(255) NOT NULL auto_increment,
  `sid` int(255) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `text` text NOT NULL,
  `author` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
INSERT INTO `documents` VALUES (1, 0, 'About TryChess', '<IMG src="images/logo.png" align="left"><UL>\r\n<LI><B>TryChess</B>\r\n<UL><LI>TryChess is a game developped in PHP5 by Reichert Bernard\r\n<i>(valen16@trypill.org)</i> It is free to use but not yet\r\nopen source. This will change as soon as it works without\r\nany problems.\r\n</LI></UL>\r\n</LI>\r\n<LI><B>Documentation</B>\r\n<UL><LI>Documentation done by: Raphael Hinger <i>(cooki@trypill.org)</i>\r\n</LI></UL></LI></UL>\r\n<DIV align="right"><FONT size="-1"><I>"Chess, with all its philosophical depth,\r\nits aesthetic appeal, is first of all a game in the best sense\r\nof the word, a game in which are revealed your intellect,\r\ncharacter, will. - <B>Boris Spassky</B>"</I></FONT></DIV>\r\n\r\n<DIV align="left"><FONT size="-1"><I>"Chess is the greatest game ever invented, because\r\nit only looks like a game. - <B>Scott Kerns</B>"</I></FONT></DIV>\r\n\r\n<H3>Credits:</H3>\r\n<B>The figures were taken from the game: <A href="http://knights-chess.com/" target="_blank"><I>knights-chess</I></A></B>\r\nThe authors are:\r\nDefault Style: <B>Gilles CAULIER</B> (caulier.gilles_AT_free.fr) (Original style name: <I>Provence</I>)\r\n<A href="images/downloads/provence.tar.gz">download figures</A>', '1');
CREATE TABLE `field` (
  `id` int(255) NOT NULL auto_increment,
  `gid` int(255) NOT NULL default '0',
  `type` int(1) NOT NULL default '0',
  `in_game` int(1) NOT NULL default '1',
  `h_row` int(2) NOT NULL default '0',
  `v_row` int(2) NOT NULL default '0',
  `color` int(1) NOT NULL default '0',
  `initial_position` int(1) NOT NULL default '1',
  `pawn_move` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `forum` (
  `id` int(255) NOT NULL auto_increment,
  `sid` int(255) NOT NULL default '0',
  `uid` int(255) NOT NULL default '0',
  `nick` varchar(255) NOT NULL default '',
  `ts` int(255) NOT NULL default '0',
  `subject` varchar(255) NOT NULL default '',
  `msg` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `game` (
  `id` int(255) NOT NULL auto_increment,
  `black_player` int(255) NOT NULL default '0',
  `white_player` int(255) NOT NULL default '0',
  `active_player` int(255) NOT NULL default '0',
  `start_time` int(255) NOT NULL default '0',
  `turns` int(255) NOT NULL default '0',
  `winner` int(255) NOT NULL default '0',
  `tid` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `history` (
  `id` int(255) NOT NULL auto_increment,
  `gid` int(255) NOT NULL default '0',
  `oid` int(255) NOT NULL default '0',
  `color` int(1) NOT NULL default '0',
  `fromh` int(1) NOT NULL default '0',
  `fromv` int(1) NOT NULL default '0',
  `toh` int(1) NOT NULL default '0',
  `tov` int(1) NOT NULL default '0',
  `type` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `loader` (
  `id` int(255) NOT NULL auto_increment,
  `uid` int(255) NOT NULL default '0',
  `gid` int(255) NOT NULL default '0',
  `req_sess` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `new_users` (
  `nick` varchar(255) NOT NULL default '',
  `pw` varchar(255) NOT NULL default '',
  `mail` varchar(255) NOT NULL default '',
  `act_key` varchar(255) NOT NULL default ''
) TYPE=MyISAM;
CREATE TABLE `news` (
  `id` int(255) NOT NULL auto_increment,
  `ts` int(255) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `news` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `settings` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `tournament_games` (
  `id` int(255) NOT NULL auto_increment,
  `gid` int(255) NOT NULL default '0',
  `tid` int(255) NOT NULL default '0',
  `level` int(255) NOT NULL default '0',
  `is_final` int(1) NOT NULL default '0',
  `is_over` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `tournament_participants` (
  `id` int(255) NOT NULL auto_increment,
  `uid` int(255) NOT NULL default '0',
  `tid` int(255) NOT NULL default '0',
  `out` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `tournaments` (
  `id` int(255) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `start_date` int(255) NOT NULL default '0',
  `end_date` int(255) NOT NULL default '0',
  `started` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`,`title`,`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
CREATE TABLE `users` (
  `id` int(255) NOT NULL auto_increment,
  `nick` varchar(255) NOT NULL default '',
  `pw` varchar(255) NOT NULL default '',
  `gid` int(255) NOT NULL default '0',
  `mail` varchar(255) NOT NULL default '',
  `won` int(255) NOT NULL default '0',
  `lost` int(255) NOT NULL default '0',
  `is_admin` int(1) NOT NULL default '0',
  `last_activity` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
    