<?php
//login
require "class.view.php";

class login extends view{
	function __construct()
	{
		parent::__construct();
	}
	public function show($error="")
	{
		$this->title = "login";
		
		$fields["action"] = "index.php?modul=login&method=login";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Nick";
		$fields["field_text"][] = "Password";
		$fields["field_text"][] = "Login";
		$fields["field_name"][] = "nick";
		$fields["field_name"][] = "pw";
		$fields["field_name"][] = "Login";
		
		$login = $this->createForm($fields);
		$fields = "";
		$fields["action"] = "index.php?modul=login&method=register";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Nick";
		$fields["field_text"][] = "Password";
		$fields["field_text"][] = "Password";
		$fields["field_text"][] = "E-Mail";
		$fields["field_text"][] = "Login";
		$fields["field_name"][] = "nick";
		$fields["field_name"][] = "pw";
		$fields["field_name"][] = "pwa";
		$fields["field_name"][] = "mail";
		$fields["field_name"][] = "Register";
		
		$register = $this->createForm($fields);
		$out = "
			<FONT color=\"#993333\">$error<BR></FONT>
			$login
			<SCRIPT language=\"Javascript\">
						function show(name1,name2)
						{
							if(document.getElementById(name1)!=0)
									document.getElementById(name1).style.display = \"none\";
							if(document.getElementById(name2)!=0)
								document.getElementById(name2).style.display = \"block\";
						}
			</SCRIPT>
			<DIV id=\"hide\">
				<A href=\"#\" onClick=\"Javascript:show('hide','show')\">Hide Menu</A>
				$register
			</DIV>
			<DIV id=\"show\">
				<A href=\"#\" onClick=\"Javascript:show('show','hide')\">Register, it's free!</A>
			</DIV>
			<SCRIPT language=\"Javascript\">
				show('hide','show');
			</SCRIPT>
		";
		$qu = mysql_query("SELECT id FROM ".$this->settings->mysql_prefix."users");
		$users = mysql_num_rows($qu);
		mysql_free_result($qu);
		
		$this->output.=$this->createTable("Welcome to TryChess","<IMG src=\"images/logo.png\" align=\"right\">TryChess is a multiplayer chess game,<BR> this means you can play online against your friends or meet new people.<BR>To Play simply clicke the <B>Register</B> Link on the bottom of this page.<BR>Fill out the form, click register and login.<BR> Please enter a correct e-mail it is needed by the game,<BR>to inform you about new matches started against you<BR>and moves an opponent player made.<BR> <FONT color=\"#993333\">(Your e-mail addresses will <B>not</B> be given to a third one, and you will <B>not</B> <BR>receive any spam  => this is a non profit online game which was developed just for fun)</U></FONT> <BR><BR><BR>TryChess has currently <B>$users</B> registred users.<BR>").
		$this->createTable("Login (or register): ",$out);
		$this->show_output();
	}
	function login()
	{
      $nick = $_POST['nick'];
		$pw = $_POST['pw'];
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE nick='$nick' AND pw='".md5($pw)."'");
		if(mysql_num_rows($query) == 0)
			$this->show("Login failed");
		else
		{
			session_register("user");
			$row = mysql_fetch_object($query);
			$_SESSION['user']['id'] = $row->id;
			$_SESSION['user']['gid'] = $row->gid;
			$_SESSION['user']['nick'] = $row->nick;
			$_SESSION['user']['mail'] = $row->mail;
			$_SESSION['user']['is_admin'] = $row->is_admin;
			if($row->gid == 0)
			{
				$_SESSION['user']['modul'] = "manage";
				$_SESSION['user']['method'] = "show";
			}else
			{
				$_SESSION['user']['modul'] = "game";
				$_SESSION['user']['method'] = "show";
			}
			header("Location: index.php");
		}
	}
	function logout()
	{
		session_unregister("user");
		header("Location: index.php?modul=login&method=show");
	}
	function register()
	{                      
		$nick = $_POST['nick'];
		$pw = $_POST['pw'];
		$pwa = $_POST['pwa'];
		$mail = $_POST['mail'];
		$error =""; 
		if(mysql_num_rows(mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE nick='$nick'"))>0)
			$error.="Nick already taken.<BR>";
		if(mysql_num_rows(mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."new_users WHERE nick='$nick'"))>0)
			$error.="Nick already taken.<BR>";
		if(strlen($nick) <= 3)
		{
			   $error .= "Nick to short.<BR>";
		}
		if(strlen($pw) <= 3)
		{
			   $error .= "Password to short.<BR>";
		}
		if($pw != $pwa)
		{
			   $error .= "Passwords do not match.<BR>";
		}
		if( !eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*"
				."@([a-z0-9]+([\.-][a-z0-9]+))*$",
					$mail, $regs) )
		{
			$error .= "Invalid mail address.<BR>";
		}  
		/*elseif( gethostbyname($regs[2]) == $regs[2] )
		{
			$error.="Mail host: '$regs[2]' not found.<BR>";
		}*/
		if($error!="")
			$this->show("<B>Some errors occured:</B><BR>".$error);
		else
		{
			if($this->settings->use_mail)
			{
				$act_key = md5(microtime()."trychess".rand(0,100));
				$query = "INSERT INTO ".$this->settings->mysql_prefix."new_users (nick,pw,mail,act_key) VALUES ('$nick','".md5($pw)."','$mail','$act_key')";
				mysql_query($query);
				$error = "<B>Registered Succesfully.<br/>\nCheck your mail for account activation!<BR>";
				//format mail message
				$message="You have signed up for a TryChess account.\nPlease click the following link to activate your account\n".$this->settings->chess_host."index.php?modul=loader&method=activate&act_key=$act_key\n------------------------------------\nYour data:\nNick: $nick\nPassword: $pw\nHost: ".$this->settings->chess_host."\nE-mail: $mail\n------------------------------------";
				mail($mail,"TryChess account activation",$message,"From: ".$this->settings->admin_mail);
			}else
			{
				$query = "INSERT INTO ".$this->settings->mysql_prefix."users (nick,pw,mail) VALUES 	('$nick','".md5($pw)."','$mail')";
				mysql_query($query);
				$error = "<B>Registered Succesfully!<br/>You can login now.<BR>";
			}
			
			$this->show($error);
			
		}
	}
	function change()
	{                      
		if(!session_is_registered("user"))
			header("Location: index.php?modul=login&do=show");
			
		$pw = $_POST['pw'];
		$pwa = $_POST['pwa'];
		$mail = $_POST['mail'];
		$error =""; 
		if(strlen($pw) <= 3 && strlen($pw) > 0)
		{
			   $error .= "Password to short.<BR>";
		}
		if($pw != $pwa && strlen($pw) > 0)
		{
			   $error .= "Passwords do not match.<BR>";
		}
		if( !eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*"
				."@([a-z0-9]+([\.-][a-z0-9]+))*$",
					$mail, $regs) )
		{
			$error .= "Invalid mail address.<BR>";
		}  
		
		if($error!="")
			header("Location: index.php?modul=manage&method=show&do=profile&error=$error");
		else
		{
			
			if(strlen($pw)>0)
				$pwq = "pw='".md5($pw)."',";
			else
				$pwq = "";
			$query = "UPDATE ".$this->settings->mysql_prefix."users set $pwq mail='$mail' WHERE id='".$_SESSION['user']['id']."'";

			mysql_query($query);
			$error = "<B>Updated Succesfully!</B>";
			
			
			
			$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE id='".$_SESSION['user']['id']."'");
				session_unregister("user");
				session_register("user");
				$row = mysql_fetch_object($query);
				$_SESSION['user']['id'] = $row->id;
				$_SESSION['user']['gid'] = $row->gid;
				$_SESSION['user']['nick'] = $row->nick;
				$_SESSION['user']['mail'] = $row->mail;
				$_SESSION['user']['is_admin'] = $row->is_admin;
				if($row->gid == 0)
				{
					$_SESSION['user']['modul'] = "manage";
					$_SESSION['user']['method'] = "show";
				}else
				{
					$_SESSION['user']['modul'] = "game";
					$_SESSION['user']['method'] = "show";
				}
		
			header("Location: index.php?modul=manage&method=show&do=profile&error=$error");
		}
	}
}
?>