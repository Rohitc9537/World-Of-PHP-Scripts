<?

//pawn
if(!class_exists("figure"))
	require "class.figure.php";
class pawn extends figure
{
	function __construct($id,$color,$field,$prefix)
	{
		parent::__construct($id,$color,$field,$prefix);
		
		//set speed vectors
		$this->v_y = 1;
		if($this->color == 1 )
		{
			$this->v_y *=-1;
		}  
	}
	
	function get_allowed()
	{
		if($this->color==1)
			$y = -1;
		else
			$y = 1;
		
		//check field(s) before me:
		if($this->find_figure($this->v_pos+$y,$this->h_pos,true)=="")
		{
			$fields[$this->v_pos+$y][$this->h_pos]['color'] = 'g';
			if($this->initial_position == 1)
			{
				if($this->find_figure($this->v_pos+$y*2,$this->h_pos,true)=="")
				{
					$fields[$this->v_pos+($this->v_y*2)][$this->h_pos]['color'] = 'g';
				}
			}
		}
			
		//check if there is an attacable figure on the left?
		if($this->find_figure_by_color(($this->v_pos),($this->h_pos+1),$this->oponent_color,true)!="")
		{
			$fields[$this->v_pos+$this->v_y][$this->h_pos+1]['color'] = 'r';
			$fields[$this->v_pos][$this->h_pos+1]['color'] = 'r';
		}
		if($this->find_figure_by_color(($this->v_pos),($this->h_pos-1),$this->oponent_color,true)!="")
		{
			$fields[$this->v_pos+$this->v_y][$this->h_pos-1]['color'] = 'r';
			$fields[$this->v_pos][$this->h_pos-1]['color'] = 'r';
		}
		if($this->find_figure_by_color(($this->v_pos+$y),($this->h_pos+1),$this->oponent_color)!="")
		{
		   $fields[$this->v_pos+$y][$this->h_pos+1]['color'] = 'r';
		}
		//check if there is an attacable figure on the left?
		if($this->find_figure_by_color(($this->v_pos+$y),($this->h_pos-1),$this->oponent_color)!="")
		{
		   $fields[$this->v_pos+$y][$this->h_pos-1]['color'] = 'r';
		}

		
		return $fields;
	}
	function move($x,$y)
	{
		//is en passant was applied
		if(($y == $this->h_pos+1 | $y == $this->h_pos-1) && $x == $this->v_pos)
		{
			mysql_query("UPDATE ".$this->prefix."field SET in_game='0' WHERE v_row = '$x' and h_row='$y' and gid='".$this->gid."'");
			$x+=$this->v_y;
			$_SESSION['user']['info'] = "En Passant";
		}
		//if pawn was moved two
		if($x == $this->v_pos+2 | $x == $this->v_pos-2)
		{
			$move_two = ",pawn_move='1' ";
		}else
			$move_two = "";
		if(($this->color == 0 && $x == 7) | ($this->color == 1 && $x == 0))
			$type = ",type='3' ";
		else
			$type = "";
		parent::move($x,$y,$type.$move_two);
	}

}