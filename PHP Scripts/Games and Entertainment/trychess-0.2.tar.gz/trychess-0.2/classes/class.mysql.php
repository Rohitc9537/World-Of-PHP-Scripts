<?php
class mysql{
	var $mysql_link;
	
	function __construct()
	{
		$this->mysql_link = NULL;
	}
	
	function connect($settings)
	{
		
		$this->mysql_link = mysql_connect(
									$settings->mysql_host,
									$settings->mysql_login,
									$settings->mysql_pw);
									
		if($this->mysql_link)
		{

			mysql_select_db($settings->mysql_db);
			return true;
		}
		return false;
	}

	
	function __destruct()
	{

		if($this->mysql_link!=NULL)
			mysql_close();
	}
}
?>