<?
	class error_logger
	{
		var $file_name;
		function __construct($file_name)
		{
			$this->file_name = $file_name;
		}
		function error($string,$prioity = 0)
		{
			$string = time()."-".$prioity."-".$string."\n";
			$fp = fopen($this->file_name,'a');
			fwrite($fp,$string);
			fclose($fp);
		}
	}
?>