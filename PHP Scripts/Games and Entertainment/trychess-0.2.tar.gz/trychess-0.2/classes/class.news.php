<?php
	require "class.view.php";
class news extends view
{
	function __construct()
	{                     
		parent::__construct();
	}
	public function show($info = "")
	{
		$this->output.="<BR>".
		$this->show_news();
			
		
		
		$this->show_output();
	}
	function show_news()
	{
		$query =  mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."news ORDER BY ts DESC");
		while($row = mysql_fetch_object($query))
		{
			
			if($_SESSION['user']['is_admin'] == '1')
			{
				$del = " <A href=\"index.php?modul=news&method=del_news&id=".$row->id."\" onClick=\"return confirm('Are you sure to delet this?')\">delete</A>";
			}
			else
				$del = "";
			$news.= $this->createTable($row->title.$del,nl2br($row->news)."<BR>".date("d/m/Y - h:i:s",$row->ts))."<BR>";
		}
		mysql_free_result($query);
		
		//if admin, show form:
		if($_SESSION['user']['is_admin'] == '1')
		{
			$fields = "";
			$fields["action"] = "index.php?modul=news&method=add_news";
			$fields["field_type"][] = "t";
			$fields["field_type"][] = "a";
			
			$fields["field_type"][] = "s";
			$fields["field_text"][] = "Title";
			$fields["field_text"][] = "Text";

			$fields["field_text"][] = "Add news";
			$fields["field_name"][] = "title";
			$fields["field_name"][] = "news";
			$fields["field_name"][] = "Add news";
			
			$form = $this->createTable("Add news:",$this->createForm($fields));
		}
		return "<TABLE width=\"100%\" ><TR><TD width=\"70%\"  valign=\"top\">".$news.$form."</TD>";
	}
	function add_news()
	{
		if($_SESSION['user']['is_admin'] == '1')
		{
			$title = $_POST['title'];
			$news = $_POST['news'];
			mysql_query("INSERT INTO ".$this->settings->mysql_prefix."news (ts,title,news) VALUES ('".time()."','$title','$news')");
			header("Location: index.php?modul=news&method=show");
		}
	}
	function del_news()
	{
		if($_SESSION['user']['is_admin'] == '1')
		{
			mysql_query("DELETE FROM ".$this->settings->mysql_prefix."news WHERE id='".$_GET['id']."'");
			header("Location: index.php?modul=news&method=show");
		}
	}


}
?>