<?php
//bishop
if(!class_exists("figure"))
	require "class.figure.php";
class bishop extends figure
{
	
	function get_allowed()
	{
		
	
			//check the four possible ways:
		//move forward:
		for($a=0;$a<=3;$a++)
		{
			$bGo = true;
			$vi=0;
			$vj=0;
			switch($a)
			{
				case 0:
					$vi = 1;
					$vj = 1;
					break;
				case 1:
					$vi = 1;
					$vj = -1;
					break;
				case 2:
					$vi = -1;
					$vj = 1;
					break;
				case 3:
					$vi = -1;
					$vj = -1;
					break;
			}
			$i = 0;
			$j = 0;
			
			while($bGo)
			{
				
				$i+=$vi;
				$j+=$vj;
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->oponent_color)=="")
				{
					if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->color)=="")
						$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'g';
					else
						$bGo = false;
					
				}
				else
				{
					$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'r';                      
					$bGo = false;
				}
				if(($this->v_pos+$i > 7) | ($this->v_pos+$i < 0))
					$bGo = false;
				if(($this->h_pos+$j > 7) | ($this->h_pos+$j < 0))
					$bGo = false;
			}
		}
		

		return $fields;
		
	}
	
}
?>