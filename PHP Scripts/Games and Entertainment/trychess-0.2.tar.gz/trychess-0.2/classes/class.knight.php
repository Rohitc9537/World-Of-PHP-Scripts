<?

//knight
if(!class_exists("figure"))
	require "class.figure.php";
class knight extends figure
{

	function get_allowed()
	{
		
		//check the four possible ways:
		
		for($i = -2;$i<=2;$i++)
		{
			if($i != 0)
			{
				if($i%2 == 0)
					$j=1;
				else
					$j = 2;
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->color)=="")
				{
					$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'g';
				}
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->oponent_color)!="")	
					$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'r';
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos-$j),$this->color)=="")
				{
					$fields[$this->v_pos+$i][$this->h_pos-$j]['color'] = 'g';
				}
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos-$j),$this->oponent_color)!="")
					$fields[$this->v_pos+$i][$this->h_pos-$j]['color'] = 'r';
			}
		}
		return $fields;
		
	}
	
}