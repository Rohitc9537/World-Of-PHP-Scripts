<?php
//tournament managment class
class tournaments extends core
{
	static function signup($uid,$prefix,$tid)
	{
		$rows = mysql_num_rows(mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid' AND uid='$uid'"));
		if($rows!=0)
			return false;
		else
		{
			mysql_query("INSERT INTO ".$prefix."tournament_participants (uid,tid) VALUES('$uid','$tid')");
			return true;
		}
	}
	static function get_list($uid,$prefix)
	{
		$query = mysql_query("SELECT * FROM ".$prefix."tournaments WHERE start_date>'".time()."'ORDER BY start_date ASC");
		while($row = mysql_fetch_assoc($query))
		{
			if(mysql_num_rows(mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE uid = '$uid' and tid='".$row['id']."'")) == 0)
				$list[] = $row;
		}
		mysql_free_result($query);
		
		if(count($list) == 0)
			return;
		
		$content = "<TABLE width=\"100%\">
		<TR>
			<TD><B>Tournament name:<B/></TD>
			<TD><B>Start date:<B/></TD>
			<TD><B>End date:<B/></TD>
			<TD><B>Options:<B/></TD>
		</TR>";
		
		for($i = 0; $i < count($list);$i++)
		{
			$content.="
			<TR>
				<TD>".$list[$i]['title']."</TD>
				<TD>".date("d.m.y H:i:s",$list[$i]['start_date'])."</TD>
				<TD>".date("d.m.y H:i:s",$list[$i]['end_date'])."</TD>
				<TD><A href=\"index.php?modul=manage&method=tournament_signup&id=".$list[$i]['id']."\">sign up</A></TD>
			</TR>";
			
		}
		$content.="</TABLE>";
		return $content;
	}
	static function get_reg_list($uid,$prefix,&$first=0)
	{
		$query = mysql_query("SELECT * FROM ".$prefix."tournaments ORDER BY start_date ASC");
		while($row = mysql_fetch_assoc($query))
		{
			if(mysql_num_rows(mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE uid = '$uid' and tid='".$row['id']."'")) != 0)
				$list[] = $row;
		}
		mysql_free_result($query);
		
		if(count($list) == 0)
			return;

		$content = "<TABLE width=\"100%\">
		<TR>
			<TD><B>Tournament name:<B/></TD>
			<TD><B>Start date:<B/></TD>
			<TD><B>Options:<B/></TD>
		</TR>";
		
		for($i = 0; $i < count($list);$i++)
		{
			if($i == 0)
				$first = $list[$i]['id'];
			$content.="
			<TR>
				<TD>".$list[$i]['title']."</TD>
				<TD>".date("d.m.y H:i:s",$list[$i]['start_date'])."</TD>
				<TD><A href=\"index.php?modul=manage&method=show&do=tournaments&id=".$list[$i]['id']."\">view details</A></TD>
			</TR>";
			
		}
		$content.="</TABLE>";

		return $content;
	}
	static function get_details($uid,$prefix,$tid)
	{
		if($tid<=0)
			return;
		$row = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."tournaments WHERE id='$tid'"));
		$ingame_users = mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid' AND out='0'");
		$details = "<TABLE width=\"100%\"><TR><TD><B>Title: </B>".$row->title."<BR/><B>Description:</B><br/>".$row->description."</TD></TR></TABLE>";
		if(mysql_num_rows($ingame_users) == 1)
		{
			$winning_user = mysql_fetch_object($ingame_users);
			$winning_user = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."users WHERE id='".$winning_user->uid."'"));
			
			$details .= "<BR/>Winner is: <b>".$winning_user->nick."</b><BR/>";
		}
		if($row->start_date>time())
		{
			
			$usercnt = mysql_num_rows(mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid'"));
			return "<TABLE width=\"100%\"><TR><TD><B>Title: </B>".$row->title."<BR/><B>Description:</B><br/>".$row->description."<br/><B>Tournament did not started yet</B><br/>$usercnt users signed up until now.</TD></TR></TABLE>";
		}else
		{
		 	if($row->started=='0')
				tournaments::start($prefix,$tid);
			$bGo=true;
			$level=0;
			while($bGo)
			{
				$query = mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid='$tid' AND level=$level ORDER BY id");
				if(mysql_num_rows($query) == 0)
					$bGo=false;
				else
				{
					$rows = mysql_num_rows($query);
					$out = "<TABLE align=\"center\"><TR>";
					$final = false;
					$a = 0;
						while($row = mysql_fetch_object($query))
						{
							$a++;
							if($row->is_final==1)
								$final = true;
							$game = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."game WHERE id='".$row->gid."'"));
							$u1 = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."users WHERE id='".$game->white_player."'"));
							$u2 = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."users WHERE id='".$game->black_player."'"));
							if($game->winner == $u1->id)
								$u1->nick = "<b>".$u1->nick."</b>";
							if($game->winner == $u2->id)
								$u2->nick = "<b>".$u2->nick."</b>";
							if($_SESSION['user']['id'] == $u2->id | $_SESSION['user']['id'] == $u1->id)
							{
								$href = "<a class=\"bright\" href=\"index.php?modul=manage&method=continue_game&gid=".$row->gid."\">";
								$href_ = "</a>";
							}else
							{
								$href="";
								$href_="";
							}
							$class= "table_ext_bright_A";
							if($a%2 == 0)
								$class= "table_ext_A";
							$out.="<TD class=\"$class\" width=\"".(100/$rows)."%\"><span class=\"bright_text\">".$href.$u1->nick." vs. ".$u2->nick.$href_."</span></TD>";
						}
					$out.="</TR></TABLE>";
					$rounds[]  = $out;
					
					if(mysql_num_rows($query) == 1)
						$names[] = "Final Round ";
					else if($final)
						$names[] = "Decisive Round ".($level+1);
					else
						$names[] = "Playoff Round ".($level+1);
					$level++;
				}
			}
			if(count($names)!=0)
				$names = array_reverse($names);
			if(count($rounds	)!=0)
				$rounds = array_reverse($rounds);
			$output .= "<TABLE width=\"100%	\">";
			for($i=0;$i<count($rounds);$i++)
			{
				$class= "table_ext_bright";
				if($i%2 == 0)
					$class= "table_ext";
				$output .= "<TR><TD class=\"$class\">".$names[$i]."</TD><TD align=\"center\"  class=\"$class\">".$rounds[$i]."</TD></TR>"	;
			}
			$output.="</TABLE>";
			return "<TR><TD>$details</TD></TR><TR><TD>".$output."</TD></TR>";
		}
		
	}
	static function start($prefix,$tid)
	{
		$query = mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid' ORDER BY rand()");
		$players = mysql_num_rows($query);
		if($players==1)exit;
		$sqrt = sqrt($players);
		$natural_sqrt = $sqrt;
		settype($natural_sqrt,"integer");
		if($sqrt-$natural_sqrt == 0)
			tournaments::finals($prefix,$tid,0);
		else
			tournaments::playoffs($prefix,$tid,0);
		mysql_query("UPDATE ".$prefix."tournaments SET started='1' WHERE id='$tid'");
	}
	static function playoffs($prefix,$tid,$level)
	{
		$query = mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid' AND out='0' ORDER BY rand()");
		$row_first = mysql_fetch_object($query);
		$row_last = $row_first;
		while($row_act = mysql_fetch_object($query))
		{
				tournaments::new_game($prefix,$tid,$row_act->uid,$row_last->uid,$level);

				$row_last = $row_act;
				
				
		}
		tournaments::new_game($prefix,$tid,$row_first->uid,$row_last->uid,$level);
	}
	static function finals($prefix,$tid,$level)
	{
		
		$query = mysql_query("SELECT * FROM ".$prefix."tournament_participants WHERE tid='$tid' AND out='0' ORDER BY rand()");
		if(mysql_num_rows($query) == 1)
		{
			return;
			
		}
		else
		{
			while($row_one = mysql_fetch_object($query))
			{
				if($row_two=mysql_fetch_object($query))
				{
					tournaments::new_game($prefix,$tid,$row_one->uid,$row_two->uid,$level,1);
				}
			}
		}
	}
	static function go_one($prefix,$tid)
	{
	
		//fetch current level
		$row = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid = '$tid' ORDER BY level DESC LIMIT 1"));
		$current_level = $row->level;
		//check if all games are over yet in this level:
		$games_running = mysql_num_rows(mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid = '$tid' AND is_over='0'"));
		//if there are still games running do nothing
		if($games_running!=0)
			return
		
		//else create new level:
		
			
		$winners="";
		$a = mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid='$tid' and level='$current_level'");
		while($row = mysql_fetch_object($a))
		{
			$rowa = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."game WHERE id='".$row->gid."'"));
			$winners[$rowa->winner]++;
		}
	
		

		$players = count($winners);
		if($players==1)
		{
			//tournament finished, set second player as loser;
			$winners = array_keys($winners);
			$sql = "UPDATE ".$prefix."tournament_participants SET out='1' WHERE uid <> '".$winners[0]."' AND tid='$tid'";
			mysql_query($sql);
			return;
		}
		//check if finals are on now or not:
		$sqrt = sqrt($players);
		$natural_sqrt = $sqrt;
		settype($natural_sqrt,"integer");
		//if we can start final rounds with players with one or two winning games
		if($sqrt-$natural_sqrt == 0 | $players == 2)
		{
			//kickout other players which lost all games
			$winners = array_keys($winners);
			for($i = 0;$i<count($winners);$i++)
			{
				if($i != 0)
					$or = " AND ";
				else
					$or = "";
					
				$uids .= $or." uid <> '".$winners[$i]."'";
			}
			$sql = "UPDATE ".$prefix."tournament_participants SET out='1' WHERE ($uids) AND tid='$tid'";
			mysql_query($sql);
			//start new final round with players which won one or two playoff games in the last level:
			tournaments::finals($prefix,$tid,$current_level+1);
			
		}
		else
		{
			//check if we can start finals with players with two winning games
			$double_winners = "";
			$winners = "";
			$a = mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid='$tid' and level='$current_level'");
			while($row = mysql_fetch_object($a))
			{
				$rowa = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."game WHERE id='".$row->gid."'"));
				$winners[$rowa->winner]++;
				if($winners[$rowa->winner] == 2)
				{
					$double_winners[$rowa->winner]++;
				}
			}
			
			$players = count($double_winners);
			//check if finals are on now or not:
			$sqrt = sqrt($players);
			$natural_sqrt = $sqrt;
			settype($natural_sqrt,"integer");
			//if we can start final rounds with players with one or two winning games
			if(($sqrt-$natural_sqrt == 0|$players == 2 )&& $players >1)
			{
				//kickout other players which lost all games or one
				$double_winners = array_keys($double_winners);
				for($i = 0;$i<count($double_winners);$i++)
				{
					if($i != 0)
						$or = " AND ";
					else
						$or = "";
						
					$uids .= $or." uid <> '".$double_winners[$i]."'";
				}
				$sql = "UPDATE ".$prefix."tournament_participants SET out='1' WHERE ($uids) AND tid='$tid'";
				mysql_query($sql);
				//start new final round with players which won two playoff games in 	the last level:
				
				tournaments::finals($prefix,$tid,$current_level+1);
			}
			else{
				//kickout losers with no winning games
				$winners = array_keys($winners);
				for($i = 0;$i<count($winners);$i++)
				{
					if($i != 0)
						$or = " AND ";
					else
						$or = "";
						
					$uids .= $or." uid <> '".$winners[$i]."'";
				}
				$sql = "UPDATE ".$prefix."tournament_participants SET out='1' WHERE ($uids) AND tid='$tid'";
				mysql_query($sql);
				//start new playoff round:
				
				tournaments::playoffs($prefix,$tid,$current_level+1);
			}
		}
		
	}
	static function game_over($prefix,$winner,$loser,$gid,$tid)
	{
		//if a game is over we need to set game over flag
		mysql_query("UPDATE ".$prefix."tournament_games SET is_over='1' WHERE gid='$gid' AND tid='$tid'");
		$row = mysql_fetch_object(mysql_query("SELECT * FROM ".$prefix."tournament_games WHERE tid='$tid' AND gid='$gid'"));
		if($row->is_final==1)
			$add = "out='1'";
		else
			$add = "out='0'";
		
		//and update user settings about his lost...
		mysql_query("UPDATE ".$prefix."tournament_participants SET $add WHERE tid='$tid' AND uid='$loser'");
		
		//and manage new level if needed:
		tournaments::go_one($prefix,$tid);
	}
	static function new_game($prefix,$tid,$white_id,$black_id,$level,$is_final=0)
	{
		
		//create game
		mysql_query("INSERT INTO ".$prefix."game (white_player,black_player,active_player,start_time,tid) VALUES ('$white_id','$black_id','$white_id','".time()."',$tid)");
		//game id
		$gid = mysql_insert_id();
		mysql_query("INSERT INTO ".$prefix."tournament_games (gid,tid,level,is_final) VALUES ($gid,$tid,$level,$is_final)");
		//create field:
		//types:
		//		-1 = farmer
		//		-2 = king
		//		-3 = queen
		//		-4 = runner
		//		-5 = horse
		//		-6 = tower
		
		//white farmers	
		$figures['type'][] = '1';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		//black farmers
		$figures['type'][] = '1';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		//kings_
		$figures['type'][] = '2';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '2';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//queens
		$figures['type'][] = '3';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '3';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//towers
		$figures['type'][] = '6';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '6';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '6';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '6';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//horses
		$figures['type'][] = '5';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '5';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '5';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '5';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//runners
		$figures['type'][] = '4';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '4';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '4';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '4';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$settings = new settings;
		for($i = 0;$i<count($figures['type']);$i++)
		{
			$sql = "INSERT INTO ".$prefix."field (gid,h_row,v_row,in_game,color,type) values ('$gid','".$figures["hpos"][$i]."','".$figures["vpos"][$i]."','1','".$figures["color"][$i]."','".$figures["type"][$i]."')";
			mysql_query($sql);
		}
		$query = mysql_query("SELECT * FROM ".$prefix."users WHERE id='".$black_id."'");
		$urow = mysql_fetch_object($query);
		mysql_free_result($query);
		if(time() - $urow->last_activity > 300){
			if($settings->use_mail)
			{
				$req_sess=md5(microtime().$uid.$gid);
				mysql_query("INSERT INTO ".$prefix."loader (uid,gid,req_sess) VALUES ('$black_id','$gid','$req_sess')");
				mail($urow->mail,"[TryChess]A new tournament match was created","
				A tournament match was started\nTo play, go to ".$settings->chess_host."index.php?modul=loader&method=check&req_sess=$req_sess\nThis link will automaticly bring you to the game and login,\nit is only valide once!\n\n-------------------------------\nHave fun!\n");
			}
		}
		$query = mysql_query("SELECT * FROM ".$prefix."users WHERE id='".$white_id."'");
		$urow = mysql_fetch_object($query);
		mysql_free_result($query);
		if(time() - $urow->last_activity > 300){
			if($settings->use_mail)
			{
				$req_sess=md5(microtime().$uid.$gid);
				mysql_query("INSERT INTO ".$prefix."loader (uid,gid,req_sess) VALUES ('$black_id','$gid','$req_sess')");
				mail($urow->mail,"[TryChess]A new tournament match was created","
				A tournament match was started\nTo play, go to ".$settings->chess_host."index.php?modul=loader&method=check&req_sess=$req_sess\nThis link will automaticly bring you to the game and login,\nit is only valide once!\n\n-------------------------------\nHave fun!\n");
			}
		}
	}
};
?>