<?php
require "class.view.php";
class forum extends view
{
	function __construct()
	{                     
		parent::__construct();
	}
	public function show($info = "")
	{
	
		$this->output.="<BR>".
		$this->show_forum();
		$this->show_output();
		
	}
	function uidToNick($id)
	{
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."users WHERE id='$id'");
		$row = mysql_fetch_object($query);
		mysql_free_result($query);
		if(($_SESSION['user']['id'] != "") && ($_SESSION['user']['id'] != $id))
			return "<A href=\"index.php?modul=manage&method=new_game&oid=$id\" onclick=\"return confirm('Create game against: ".$row->nick."?')\">".$row->nick."</A>";
		else
			return $row->nick;
	}
	function msg_menu($uid,$mid)
	{
		if(($_SESSION['user']['id']!="" && $_SESSION['user']['id']==$uid) | $_SESSION['user']['is_admin']=='1')
		{
			return " | <A href=\"index.php?modul=forum&method=del_msg&id=$mid\">delete</A> | <A href=\"index.php?modul=forum&method=show&edit=true&id=$mid\">edit</A>";
		}
	}
	function show_msg($id,$level)
	{
		if($id != 0)
		{
			$query =  mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE id='$id'");
			$row = mysql_fetch_object($query);
			if($row->uid == 0)
				$nick = "&lt;".$row->nick."&gt;";
			else
				$nick = $this->uidToNick($row->uid);
			$return = "<TABLE width=\"100%\">
							<TR>
								<TD width=\"".($level)."%\">
								
								</TD>
								<TD class=\"table_ext_bright\">
									<A href=\"index.php?modul=forum&method=show&id=".$row->id."\">.".$row->subject."</A>(".$nick." - ".date("d/m/Y - h:i:s",$row->ts).")
								</TD>
							</TR>
							";
			if($_GET['id'] == $id)
			{
				$return .="<TR>
								<TD width=\"".$level."%\">
								
								</TD>
									<TD class=\"table_body\">
										<A href=\"index.php?modul=forum&method=show&id=$id&reply=true\">reply</A>".$this->msg_menu($row->uid,$row->id)."<BR>
										".nl2br($row->msg)."
									</TD>
							</TR>";
			}
			$return.="</TABLE>";
		}
		if($_GET['edit'] == 'true' && $_GET['id'] == $id)
			$return.=$this->edit_msg_form();
		if($_GET['reply'] == 'true' && $_GET['id'] == $id)
			$return.=$this->new_msg_form();
		$query2 =  mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE sid='$id' order by ts desc");
		while($row2 = mysql_fetch_object($query2))
		{
			$return.=$this->show_msg($row2->id,$level+1);
		}
		return $return;
	}
	function show_forum()
	{
		$this->output.=$this->createTable("Forum: ","<TABLE width=\"100%\">
																		<A href=\"index.php?modul=forum&method=show&id=$id&reply=true\">New Thread</A><BR>".
																		$this->show_msg(0,0)
																	."</TABLE>");
		
	}
	function new_msg_form()
	{
			$fields = "";
			$fields["action"] = "index.php?modul=forum&method=new_msg&id=".$_GET['id'];
			if($_SESSION['user']['id'] == "")
			{
				$fields["field_type"][] = "t";
				$fields["field_text"][] = "Nick";
				$fields["field_name"][] = "nick";
			}
			$fields["field_type"][] = "t";
			$fields["field_type"][] = "a";
			
			$fields["field_type"][] = "s";
			$fields["field_text"][] = "Subject";
			$fields["field_text"][] = "Message";

			$fields["field_text"][] = "Submit";
			$fields["field_name"][] = "subj";
			$fields["field_name"][] = "msg";
			$fields["field_name"][] = "submit";
			
			$form = $this->createTable("Post Message:",$this->createForm($fields));
			return $form;
	}
	function edit_msg_form()
	{
		$row = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE id='".$_GET['id']."'"));
		$uid = $row->uid;
		if(($_SESSION['user']['id']!="" && $_SESSION['user']['id']==$uid) | $_SESSION['user']['is_admin']=='1')
		{
			$row = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE id='".$_GET['id']."'"));
			$fields = "";
			$fields["action"] = "index.php?modul=forum&method=edit_msg&id=".$_GET['id'];
			$fields["field_type"][] = "t";
			$fields["field_type"][] = "a";
			
			$fields["field_type"][] = "s";
			$fields["field_text"][] = "Subject";
			$fields["field_text"][] = "Message";

			$fields["field_text"][] = "Submit";
			$fields["field_name"][] = "subj";
			$fields["field_name"][] = "msg";
			$fields["field_name"][] = "submit";
			$fields["field_value"][] = $row->subject;
			$fields["field_value"][] = $row->msg;
			$fields["field_value"][] = "";
			$form = $this->createTable("Post Message:",$this->createForm($fields));
			return $form;
		}
	}
	function new_msg()
	{
		$id = $_GET['id'];
		$subj = $_POST['subj'];
		$msg = $_POST['msg'];
		$uid = $_SESSION['user']['id'];
		if($_SESSION['user']['id'] == "")
		{
			$nick = $_POST['nick'];
			if(strlen($nick)==0)
				header("Location: index.php?modul=forum&method=show&info=Please enter a nick.	");
		}
		if(strlen($msg) == 0 | strlen($subj)==0)
			header("Location: index.php?modul=forum&method=show&info=Please enter a subject and a message");
		
		mysql_query("INSERT INTO ".$this->settings->mysql_prefix."forum (sid,uid,nick,subject,msg,ts) VALUES ('$id','$uid','$nick','$subj','$msg','".time()."')");
		$iid = mysql_insert_id();
		header("Location: index.php?modul=forum&method=show&id=$iid");
		exit;
	}
	function edit_msg()
	{
		$row = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE id='".$_GET['id']."'"));
		$uid = $row->uid;
		if(($_SESSION['user']['id']!="" && $_SESSION['user']['id']==$uid) | $_SESSION['user']['is_admin']=='1')
		{
			$id = $_GET['id'];
			$subj = $_POST['subj'];
			$msg = $_POST['msg'];
			mysql_query("UPDATE ".$this->settings->mysql_prefix."forum SET subject='$subj',msg='$msg' WHERE id='$id'");
			header("Location: index.php?modul=forum&method=show&id=$id");
			exit;
		}
	}
	function del_msg_exec($id)
	{
		if($id == 0)
			exit;
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE sid='$id'");
		while($row = mysql_fetch_object($query))
		{
			$this->del_msg_exec($row->id);
		}
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."forum WHERE id='$id'");
		
	}
	function del_msg()
	{
		
		$row = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."forum WHERE id='".$_GET['id']."'"));
		$uid = $row->uid;
		if(($_SESSION['user']['id']!="" && $_SESSION['user']['id']==$uid) | $_SESSION['user']['is_admin']=='1')
		{
			$this->del_msg_exec($_GET['id']);
		}
		header("Location: index.php?modul=forum&method=show");
	}

}
?>