<?php
require "class.view.php";

class admin extends view
{
	function __construct()
	{
		if($_SESSION['user']['is_admin'] != 1)
		{
			header("Location: index.php?modul=login");
			exit;
		}
		parent::__construct();
		$this->title = "administration";
	}
	function show()
	{
		$this->menu();
		$this->show_output();
	}
	function menu()
	{
		
		
		$content .= "<a href=\"index.php?modul=admin&method=settings\">Site settings</a> |";
		$content .= "<a href=\"index.php?modul=admin&method=users\">Manage users</a> |";
		$content .= "<a href=\"index.php?modul=admin&method=tournaments\">Tournaments</a> |";
		$content .= "<a href=\"index.php?modul=admin&method=stats\">Statistics</a>";
		$this->output.=$this->createTable("Administration",$content);
		
		//if there is any info which should be shown it will be shown here:
		if(strlen($_REQUEST['errors']) > 0)
		{
			$errors = unserialize(base64_decode($_REQUEST['errors']));
			for($i = 0;$i < count($errors);$i++)
			{
				$info .= $errors[$i]."<br/>\n";
			}
			$this->output.=$this->createTable("Information","<font color=\"#99333\">$info</FONT>");
		}
	}
	function settings()
	{
		$this->output.=$this->createTable("Settings","Not implemented yet.");
		$this->show_output();
	}
	function stats()
	{
		$this->output.=$this->createTable("Stats","Not implemented yet.");
		$this->show_output();
	}
	function users()
	{
		$this->menu();
		//fetch users:
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users ORDER BY id ASC");
		$content = "
		<FORM method=\"POST\" action=\"index.php?modul=admin&method=users_update\">
		<TABLE width=\"100%\">
		<TR>
			<TD><B>Nick:</B></TD>
			<TD><B>Mail:</B></TD>
			<TD width=\"10%\"><B>Won:</B></TD>
			<TD width=\"10%\"><B>Lost:</B></TD>
			<TD><B>Options:</B></TD>
		</TR>";
		
		$id = $_REQUEST['id'];
		while($row = mysql_fetch_object($query))
		{
			if($row->is_admin != 1)
			{$admin = "set admin";}
			else
			{$admin = "reset admin";}
			
			if($id != $row->id)
			{
			$content .= "<TR>
			<TD><I>".$row->nick."</I></TD>
			<TD><A href=\"mailto: ".$row->mail."\">".$row->mail."</A></TD>
			<TD>".$row->won."</TD>
			<TD>".$row->lost."</TD>
			<TD><A href=\"index.php?modul=admin&method=users_del&id=".$row->id."\" onclick=\"return confirm('Are you sure to remove this user?')\">delete</A> | <A href=\"index.php?modul=admin&method=users&id=".$row->id."\">edit</A> | <A href=\"index.php?modul=admin&method=users_toggle_admin&id=".$row->id."\" onclick=\"return confirm('Are you sure to give/take admin rights?')\">$admin</A></TD>
		</TR>";
			}else
			{
				$content .= "<TR>
			<TD>
			<INPUT type=\"hidden\" name=\"id\" value=\"".$row->id."\" />
			<INPUT class=\"input\" type=\"text\" name=\"nick\" value=\"".$row->nick."\" /></TD>
			<TD><INPUT class=\"input\" type=\"text\" name=\"mail\" value=\"".$row->mail."\" />
			<TD>".$row->won."</TD>
			<TD>".$row->lost."</TD>
			<INPUT class=\"button\" type=\"submit\" name=\"button\" value=\"Update\" /></TD>
			<TD><A href=\"index.php?modul=admin&method=users_del&id=".$row->id."\" onclick=\"return confirm('Are you sure to remove this user?')\">delete</A> | <A href=\"index.php?modul=admin&method=users&id=".$row->id."\">edit</A> | <A href=\"index.php?modul=admin&method=users_toggle_admin&id=".$row->id."\" onclick=\"return confirm('Are you sure to give/take admin rights?')\">$admin</A></TD>
			</TR>";
		}
		}
		$content.="</TABLE>
		</FORM>";
		mysql_free_result($query);
		$this->output.=$this->createTable("User administration",$content);
		
		
		$this->show_output();
	}
	function users_update()
	{
		$errors = "";
		$id = $_REQUEST['id'];
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE  id ='$id'");
		$row = mysql_fetch_object($query);
		if($row == NULL)
			$errors[] = "User does not exists.";
		else
		{
			mysql_query("UPDATE ".$this->settings->mysql_prefix."users  SET nick='".$_POST['nick']."',mail='".$_POST['mail']."' WHERE id='$id'");
			
			$errors[] = "User details updated.";
		}
		$errors = base64_encode(serialize($errors));
		header("Location: index.php?modul=admin&method=users&errors=$errors");
		exit;

	}
	function users_del()
	{
		$errors = "";
		$id = $_REQUEST['id'];
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE  id ='$id'");
		$row = mysql_fetch_object($query);
		if($row == NULL)
			$errors[] = "User does not exists.";
		elseif($row->is_admin == '1')
			$errors[] = "You can't delete an admin";
		else
		{
			$qu = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."game WHERE  white_player ='$id' OR black_player ='$id'");
			while($game_row = mysql_fetch_object($qu))
			{
				$gid = $game_row->id;
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."game WHERE id='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."field WHERE gid='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."chat WHERE gid='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."history WHERE gid='$gid'");
			}
			mysql_query("DELETE FROM ".$this->settings->mysql_prefix."loader WHERE  uid ='$id'");
			mysql_query("DELETE FROM ".$this->settings->mysql_prefix."users WHERE  id ='$id'");
			$errors[] = "User was removed";
		}
		$errors = base64_encode(serialize($errors));
		header("Location: index.php?modul=admin&method=users&errors=$errors");
		exit;

	}
	function users_toggle_admin()
	{
		$errors = "";
		$id = $_REQUEST['id'];
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE  id ='$id'");
		$row = mysql_fetch_object($query);
		if($row == NULL)
			$errors[] = "User does not exists.";
		elseif($row->is_admin == '1')
		{
			mysql_query("UPDATE ".$this->settings->mysql_prefix."users SET is_admin='0' WHERE id='$id'");
			$errors[] = "Admin right were taken from this user.";
		}
		else
		{
			mysql_query("UPDATE ".$this->settings->mysql_prefix."users SET is_admin='1' WHERE id='$id'");
			$errors[] = "User is now admin.";
		}
		$errors = base64_encode(serialize($errors));
		header("Location: index.php?modul=admin&method=users&errors=$errors");
		exit;

	}
	function tournaments()
	{
		$this->menu();
		$this->title = "tournaments";
		
		//fetch tournaments:
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."tournaments ORDER BY id ASC");
		$content = "
		<FORM method=\"POST\" action=\"index.php?modul=admin&method=tournaments_update\">
		<TABLE width=\"100%\">
		<TR>
			<TD><B>Title:</B></TD>
			<TD><B>Start:</B></TD>
			<TD><B>Users registered:</B></TD>
			<TD><B>Options:</B></TD>
		</TR>";
		while($row = mysql_fetch_object($query))
		{
			$opts = "<A href=\"index.php?modul=admin&method=tournaments_delete&id=".$row->id."\" onclick=\"return confirm('Are you sure to delete this tournament?')\">delete</A> | <A href=\"index.php?modul=admin&method=tounaments_edit&id=".$row->id."\" onclick=\"alert('Not Implemented yet.');return false;\">edit</A> ";
			$usercount = mysql_num_rows(mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."tournament_participants WHERE tid='".$row->id."'"));
			$content.="
			<TR>
			<TD>".$row->title."</TD>
			<TD>".date("d.m.y H:i:s",$row->start_date)."</TD>
			<TD>$usercount</TD>
			<TD>$opts</TD>
		</TR>";
		}
		$content .= "</TABLE></FORM>";
		
		$this->output .= $this->createTable("Manage tournamtents:",$content);
		
		$fields["action"] = "index.php?modul=admin&method=tournaments_create";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "a";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "t";
// 		$fields["field_type"][] = "t";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Title";
		$fields["field_text"][] = "Description";
		$fields["field_text"][] = "";
		$fields["field_text"][] = "Registration Deadline<br/>/ Startdate:";
// 		$fields["field_text"][] = "Enddate:";
		$fields["field_text"][] = "Create";
		
		$fields["field_name"][] = "title";
		$fields["field_name"][] = "desc";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "deadline";
// 		$fields["field_name"][] = "end";
		$fields["field_name"][] = "";
		
		$fields["field_value"][] = $_REQUEST['title'];
		$fields["field_value"][] = $_REQUEST['desc'];
		
		if($_REQUEST['deadline'] == "")
			$deadline = date("d.m.y H:i:s",time());
		else
			$deadline = $_REQUEST['deadline'];
// 		if($_REQUEST['end'] == "")
// 			$end = date("d.m.y H:i:s",time());
// // 		else
// 			$end = $_REQUEST['end'];
		$fields["field_value"][] = "Enter a date in this format: ".date("d.m.y H:i:s",time());
		$fields["field_value"][] = $deadline;
// 		$fields["field_value"][] = $end;
		
		$this->output .= $this->createTable("Create new tournamtent:",$this->createForm($fields));
		$this->show_output();
	}
	function tournaments_create()
	{
		//split time from dat
		$parts = split(" ",$_REQUEST['deadline']);
		//split minutes secondes and hours
		$time = split("\:",$parts[1]);
		//split day,minutes and years
		$date = split("\.",$parts[0]);
		$startdate = mktime ( $time[0], $time[1],$time[2], $date[1],$date[0],$date[2]);
		//return info:
		$errors = NULL;
		if(count($time) != 3 | count($date) != 3)
		{
			$errors[] = "Invalid start date format.";
		}
		
		//split time from dat
// 		$parts = split(" ",$_REQUEST['end']);
		//split minutes secondes and hours
// 		$time = split("\:",$parts[1]);
		//split day,minutes and years
// 		$date = split("\.",$parts[0]);
// 		$enddate = mktime ( $time[0], $time[1],$time[2], $date[1],$date[0],$date[2]);
		
		//return info:
		$errors = NULL;
		$enddate=0;
// 		if(count($time) != 3 | count($date) != 3)
// 		{
// 			$errors[] = "Invalid end date format.";
// 		}
// 		if($enddate<=$startdate)
// 			$errors[] = "Enddate must be after startdate.";
		if(strlen($_REQUEST['title']) == 0)
			$errors[] = "Enter a title please.";
		if(count($errors) == 0)
		{
			
			
			mysql_query("INSERT into ".$this->settings->mysql_prefix."tournaments (title,description,start_date,end_date) VALUES ('".$_REQUEST['title']."','".$_REQUEST['desc']."','$startdate','$enddate')");
			$errors[]="Tournament created.";
			$errors = base64_encode(serialize($errors));
			header("Location: index.php?modul=admin&method=tournaments&errors=$errors");
			exit;
		}
		else
		{
			$_REQUEST['errors'] = base64_encode(serialize($errors));
			$this->tournaments();
		}
	}
	function tournaments_delete()
	{
		$id = $_REQUEST['id'];
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."game WHERE tid ='$id' ");
		while($row = mysql_fetch_object($query))
		{
			$gid = $row->id;
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."game WHERE id='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."field WHERE gid='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."chat WHERE gid='$gid'");
				mysql_query("DELETE FROM ".$this->settings->mysql_prefix."history WHERE gid='$gid'");
		}
		mysql_free_result($query);
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."tournaments WHERE id='$id'");
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."tournament_participants WHERE tid='$id'");
		
		$errors[] = "Tournament was deleted.";
		
		$errors = base64_encode(serialize($errors));
		header("Location: index.php?modul=admin&method=tournaments&errors=$errors");
		exit;
		
	}
}
?>