<?php
//king
if(!class_exists("figure"))
	require "class.figure.php";
class king extends figure{
	
	function check_rochade()
	{
		

	}
	function get_allowed()
	{
		//check rochade
		global $check;
		if($this->initial_position == 1 && !$check)
		{
			$rooks = $this->find_figures_by_type($this->color,6);
			if(is_array($rooks))
			{
				foreach($rooks as $rook)
				{
					
					if($rook['initial_position']==1)
					{
						$rochade_allowed = true;
						$i = 0;
						if($rook['h_row']<$this->h_pos)
						{
							$dir = -1;
							for($i = $this->h_pos+$dir;$i>$rook['h_row'];$i+=$dir)
							{
								if($this->find_figure($this->v_pos,$i,1))
								{
									$rochade_allowed = false;
									
								}
							}
							
					
						}
						else
						{
							$dir = 1;
							for($i = $this->h_pos+$dir;$i<$rook['h_row'];$i+=$dir)
							{
								if($this->find_figure($this->v_pos,$i,1))
								{
									$rochade_allowed = false;
									
								}
							}						
						}
						//if($this->color==0)$dir*=-1;
						if($rochade_allowed)
						{
							if($dir==1)
								$dir =2;
							if($this->h_pos!=$i-$dir)
								$fields[$this->v_pos][$i-$dir]['color'] = 'g';
						}
					}
				}
			}
		}
		//check normal moves
		for($i = -1;$i<=1;$i++)
			for($j = -1;$j<=1;$j++)
			{
				if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->oponent_color)=="")
				{
					if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->color)=="")
						$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'g';
					
				}
				else
				{
					$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'r';                      
				}
			}

		return $fields;
		
	}
	function move($x,$y,$addons="")
	{
			$rochade=false;
			if($this->h_pos+1<$y)
				$rochade=true;
			else if($this->h_pos-1>$y)
				$rochade=true;
			global $check;

			
			if($rochade && !$check)
			{
				if($rochade && $y == 1)
				{
					mysql_query("UPDATE ".$this->prefix."field SET h_row = '2' WHERE type='6' and h_row='0' and color='".$this->color."' and gid='".$this->gid."'");
					$_SESSION['user']['info'] = "Rochade";
				}
				if($rochade && $y == 5){
					mysql_query("UPDATE ".$this->prefix."field SET h_row = '4' WHERE type='6' and h_row='7' and color='".$this->color."' and gid='".$this->gid."'");
					$_SESSION['user']['info'] = "Rochade";
				}
			}
			
			parent::move($x,$y,$addons);
			
		
	}
	
}
?>
