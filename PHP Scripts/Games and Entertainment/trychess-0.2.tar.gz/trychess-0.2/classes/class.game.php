<?php
require "class.view.php";
class game extends view
{
	var $gid;
	var $my_turn;
	var $my_color;
	var $my_oponent;
	var $check;
	var $field;
	var $ofield;
	var $game_over;
	function __construct()
	{
		if(!session_is_registered("user"))
			header("Location: index.php?modul=login&method=show");
		$this->gid = $_SESSION['user']['gid'];	
		parent::__construct();
		//load game field
		$this->undo_modify();
		$this->game_over = false;
		$this->collect_info();
	}
	public function show($info = "")
	{
		if($this->gid ==0)
		{
			header("Location: index.php?modul=manage&method=show");
		}
		
		if(!$this->game_over)
		{
			$this->check = $this->check_check();
			if($this->check == 2)
				if($this->check_checkmate())
				{
					$this->check=3;
					
					mysql_query("UPDATE ".$this->settings->mysql_prefix."game SET winner='".$this->my_oponent."' WHERE id='".$this->gid."'");
					mysql_query("UPDATE ".$this->settings->mysql_prefix."users SET won=won+1 WHERE id = '".$this->my_oponent."'");
					mysql_query("UPDATE ".$this->settings->mysql_prefix."users SET lost=lost+1 WHERE id = '".$_SESSION['user']['id']."'");
					mysql_query("UPDATE ".$this->settings->mysql_prefix."game SET active_player=".$this->my_oponent." WHERE id='".$this->gid."'");
					{
						$this_game = mysql_fetch_object(mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."game WHERE id='".$this->gid."'"));
						if($this_game->tid!=0)
						{
							require "class.tournaments.php";
							if($this_game->black_player == $this->my_oponent)
								$loser = $this_game->white_player;
							else
								$loser = $this_game->black_player;
							tournaments::game_over($this->settings->mysql_prefix,$this->my_oponent,$loser,$this->gid,$this_game->tid);
						}
					}
					header("Location: index.php?modul=game&method=show");
				}

		}else
			$this->show_game_over();
		$this->show_field($gid);
		$this->show_output();
		
	}
	public function leave()
	{
		$_SESSION['user']['gid'] = 0;
		header("Location: index.php?modul=manage&method=show");
		exit;
	}
	private function show_field()
	{
		if($this->my_color=='w')
		{
			$chars = "<TD bgcolor=\"#bb6633\" align=\"center\"></TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">A</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">B</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">C</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">D</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">E</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">F</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">G</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">H</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\"></TD>";
		}else
		{
				$chars = "<TD bgcolor=\"#bb6633\" align=\"center\"></TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">H</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">G</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">F</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">E</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">D</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">C</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">B</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\">A</TD>
				<TD bgcolor=\"#bb6633\" align=\"center\"></TD>";
		}
		$field="
		<TABLE width=\"100%\">
			<TR>
				<TD width=\"30%\" valign=top>
					".$this->get_menu().$this->get_histroy()."
					
				</TD>
			<TD width=\"40%\">
			
		<TABLE align=\"center\" class=\"table_chess\">
			<TR>
				$chars
			</TR>
		";
		
		
		$allowed_moves = "";
		//if a figure is selected,
		//calculate its allowed moves
		if(isset($_GET['marked']) && $this->my_turn)
		{
			$type = $this->get_type($_GET['marked']);
			if(!class_exists($type))
				require "class.".$type.".php";
			$figure = new $type($_GET['marked'],$this->my_color,$this->field,$this->settings->mysql_prefix);
			$allowed_moves =$figure->get_allowed();
			
		}
		
		for($i = 0;$i<=7;$i++)
		{
			if($this->my_color == 'w')
				$a = 7-$i;
			else
				$a = $i;
			$field.="<TR>
				<TD width=17 bgcolor=\"#bb6633\" align=\"center\">".($a+1)."</TD>
				";
			for($j = 0;$j<=7;$j++)
			{
				if($this->my_color == 'w')
					$b = 7-$j;
				else
					$b = $j;
					
				//init cell code
				$gbb = "";
				$bg = "";
				
				//if move is allowed
				if(isset($allowed_moves[$a][$b]))
				{
					if($allowed_moves[$a][$b]['color']=='r') //if a figure can be taken
					{
						$bg="background=\"images/red.png\"><a href=\"index.php?modul=game&method=move_figure&id=".$_GET['marked']."&v_row=$a&h_row=$b\">";
						$gbb = "</A>";
					}
					else if($allowed_moves[$a][$b]['color']=='g')//can move here (no opponent figure taken)
						$bg="><a href=\"index.php?modul=game&method=move_figure&id=".$_GET['marked']."&v_row=$a&h_row=$b\"><IMG src=\"images/green.png\" border=\"0\"></A>";
				}

				
				if($bg == "")//if no move allowed simply chode the bg color
				{
					$x = $i;
					$y = $j;
					
					if($this->my_color=='w')
					{
						$d = 7-$x;
						$e = 7-$y;
					}
					else
					{
						$d = $x;
						$e = $y;
					}
					$last_move = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."history WHERE gid='".$this->gid."' ORDER BY id DESC LIMIT 1"));
					
					if($last_move->fromv == ($d) && $last_move->fromh == $e )
						$bg="background=\"images/yellow.png\">";
					else if($last_move->tov == ($d) && $last_move->toh == $e )
						$bg="background=\"images/yellow.png\">";
					else if(($x%2 == 0 && $y%2==0)||($x%2 != 0 && $y%2!=0)){
						$bg="background=\"images/white.png\">";
					}else{
						$bg="background=\"images/black.png\">";
						
					}
				}
				//add field and load figure if a figure is in this field
				$field.="<TD class=\"table_chess\" width=\"50\" height=\"50\"   $bg".$this->figure_image($a,$b)."$gbb</TD>";

			}
			//if end of a line, set text
			$field.="
			<TD width=17 bgcolor=\"#bb6633\" align=\"center\">".($a+1)."</TD>
			</TR>	
			";
		}
		$field.="
								<TR>
				$chars
			</TR>
			</TABLE>
		</TD>
		<TD width=\"30%\" valign=top>
			".$this->get_chat()."
		</TD>
	</TR>
</TABLE>";
		$this->output.="<BR>".$this->createTable("Field: ",$field)."";
	}
	function show_game_over()
	{
		$text = "";
		$game_query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."game WHERE id='".$this->gid."'");
		$game_row = mysql_fetch_object($game_query);
		
		mysql_free_result($game_query);
		
		//check user info's
		if($game_row->winner == $_SESSION['user']['id'])
		{
			$text = "<H2><FONT color=\"#993333\">You've won!</FONT></H2>";
		}else
		{
			$text = "<H2><FONT color=\"#993333\">You've lost!</FONT></H2>";
		}
		$this->output.="<BR>".$this->createTable("Game Over",$text);
	}
	function collect_info()
	{
		$game_query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."game WHERE id='".$this->gid."'");
		$game_row = mysql_fetch_object($game_query);
		
		mysql_free_result($game_query);
		
		//check user info's
		if($game_row->white_player == $_SESSION['user']['id'])
		{
			$this->my_color = "w";
			$this->my_oponent = $game_row->black_player;
		}else
		{
			$this->my_color = "b";
			$this->my_oponent = $game_row->white_player;
		}
		 
		if($game_row->winner!=0)
		{
			$this->my_turn = false;
			$_SESSION['user']['playing'] = 1;
			$this->game_over = true;
		}else
			if($game_row->active_player == $_SESSION['user']['id'])
			{
				$this->my_turn = true;
				$_SESSION['user']['playing'] = 1;
			}else
			{
				$_SESSION['user']['playing'] = 0;
				$this->my_turn = false;
			}
		
	}
	
	function get_graveyard()
	{
		$results = array(array(0,0,0,0,0,0,0),array(0,0,0,0,0,0,0));
		for($i = 0;$i<count($this->field);$i++)
		{
			if($this->field[$i]['in_game']==0)
			{
				$results[$this->field[$i]['color']][$this->field[$i]['type']]++;
			}
		
		}

		$white_ones = "
		<IMG src=\"images/w1.gif\" width=25 height=25>: ".$results[0][1]."<BR>
			<IMG src=\"images/w3.gif\" width=25 height=25>: ".$results[0][3]." <IMG src=\"images/w4.gif\" width=25 height=25>: ".$results[0][4]."<BR>
			<IMG src=\"images/w5.gif\" width=25 height=25>: ".$results[0][5]." <IMG src=\"images/w6.gif\" width=25 height=25>: ".$results[0][6]."<BR>";
		$black_ones = "
		<IMG src=\"images/b1.gif\" width=25 height=25>: ".$results[1][1]."<BR>
			<IMG src=\"images/b3.gif\" width=25 height=25>: ".$results[1][3]." <IMG src=\"images/b4.gif\" width=25 height=25>: ".$results[1][4]."<BR>
			<IMG src=\"images/b5.gif\" width=25 height=25>: ".$results[1][5]." <IMG src=\"images/b6.gif\" width=25 height=25>: ".$results[1][6]."<BR>";
		if($this->my_color == 'w')
		{
			$output = "<B>Graveyard:<BR>(you've lost)</B><BR>$white_ones
			<BR><B>(you've won)</B><BR>$black_ones";
		}
		else
		{
			$output = "<B>Graveyard:<BR>(you've lost)</B><BR>$black_ones
			<BR><B>(you've won)</B><BR>$white_ones";
		}
		
		return $output;
		
	}
	
   function find_figure($vpos,$hpos, $ingame=false)
	{
		
		
		for($i = 0;$i<count($this->field);$i++)
		{
				if($this->field[$i]['v_row'] == $vpos && $this->field[$i]['h_row'] == $hpos)
				{
					if($this->field[$i]['in_game']==$ingame)
					{
						return $this->field[$i];
						
					}
				}
		}
		
	}
	function figure_image($i,$j)
	{
		
		//return html code for a figure
		$fig = $this->find_figure($i,$j,1);
		if($fig == '')
		{
			return "";
		}
		$name = $this->get_name($fig['type']);
		switch($fig['color'])
		{
			case 1:
				if($this->my_turn && $this->my_color == 'b')
					return "<A href=\"index.php?method=show&modul=game&marked=".$fig['id']."\" alt=\"$name\"><IMG height=\"50\" src=\"images/b".$fig['type'].".gif\" border=\"0\"></A>";
				else
					return "<IMG height=\"50\" src=\"images/b".$fig['type'].".gif\" border=\"0\">";
				break;
			case 0:
				if($this->my_turn && $this->my_color == 'w')
					return "<A href=\"index.php?method=show&modul=game&marked=".$fig['id']."\" alt=\"$name\"><IMG height=\"50\" src=\"images/w".$fig['type'].".gif\" border=\"0\" ></A>";
				else
					return "<IMG height=\"50\" src=\"images/w".$fig['type'].".gif\" border=\"0\">";
				break;
			default:
				break;
		}
	}
	
	function get_chat()
	{
		if($this->my_turn)
			$playing = 1;
		else
			$playing = 0;
		$output = "<IFRAME width=99% height=350 src=\"index.php?modul=chat&method=show&playing=$playing\"></IFRAME> ";
		  return $this->createTable("Chat:",$output);
	}
	function get_menu()
	{
		if(strlen($_SESSION['user']['info'])>0)
			$output.="<H3><FONT color=\"#993333\">".$_SESSION['user']['info']."</FONT></h3><BR>";
		
		$_SESSION['user']['info'] = "";
		if($this->my_turn)
		{
			$output.="Your turn.<BR>";
		}else{
			$output.="Oponents turn.<BR>";
		}
		
		if($this->my_color == 'w')
		{
			$output.="You are <B>WHITE</B>.<BR>";
		}else{
			$output.="You are <B>BLACK</B>.<BR>";
		}
		$output .= "<A href=\"index.php?modul=game&method=leave\">leave game</A><BR>
		<HR>
		".$this->get_graveyard()."<BR>";
		if($this->check == 2)
			$output.="<H2><FONT COLOR=\"#99333\">Check!</FONT></B></H2>";
		else if($this->check == 3)
			$output.="<H2><FONT COLOR=\"#99333\">Check mate!</FONT></B></H2>";
		return $this->createTable("Menu:",$output);
	}
	function get_name($type)
	{
			
			switch($type)
			{
				case 1:
					return "pawn";
					break;
				case 2:
					return "king";
					break;
				case 3:
					return "queen";
					break;
				case 4:
					return "bishop";
					break;
				case 5:
					return "knight";
					break;
				case 6:
					return "rook";
					break;
				default:
					return "";
					break;
			}
	}
	function get_type_id($id)
	{
			//return html code for a figure
			for($i = 0;$i < count($this->field);$i++)
				if($this->field[$i]['id'] == $id)
				{
					$searched_item = $this->field[$i];
					break;
				}
				
			return $searched_item['type'];
			
	}
	function get_type($id)
	{
			//return html code for a figure
			for($i = 0;$i < count($this->field);$i++)
				if($this->field[$i]['id'] == $id)
				{
					$searched_item = $this->field[$i];
					break;
				}
				
			return $this->get_name($searched_item['type']);
			
	}
	
	
	function simulate($figure,$v_pos,$h_pos)
	{
		$this->modify_field($figure->id,$v_pos,$h_pos);
		if($this->check_check() == 2)
		{
			$_SESSION['user']['info'] = "You can't move this figure! <B>(Check)</B>";
			return false;
		}
		else
			return true; 
		$this->undo_modify();
	}
	//move figure:
	function move_figure()
	{
		//figure id=
		$id = $_GET['id'];
		$v_pos = $_GET['v_row'];
		$h_pos = $_GET['h_row'];
		
		$type = $this->get_type($id);
		require "class.".$type.".php";
		$figure = new $type($id,$this->my_color,$this->field,$this->settings->mysql_prefix);
		$this->check = $this->check_check();
		$bMoved = false;
		if($this->my_turn)
		{
			if($this->my_color == 'w')
			{
				if($figure->is_allowed($v_pos ,$h_pos))
				{
					
						if($this->simulate($figure,$v_pos,$h_pos))
						{

							$figure->move($v_pos ,$h_pos);
							$bMoved =true;
							$rows = mysql_num_rows(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."history WHERE gid='".$this->gid."'"));
							$new_pos = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."field WHERE id='".$figure->id."'"));
							mysql_query("INSERT INTO ".$this->settings->mysql_prefix."history (gid,oid,color,fromh,fromv,toh,tov,type) VALUES ('".$this->gid."','".($rows+1)."','0','".$figure->h_pos."','".$figure->v_pos."','".$new_pos->h_row."','".$new_pos->v_row."','".$this->get_type_id($id)."')");
							mysql_query("UPDATE ".$this->settings->mysql_prefix."game SET active_player=black_player WHERE id='".$this->gid."'");
						}
					
				}
			}
			else
			{
				if($figure->is_allowed($v_pos ,$h_pos))
				{
						if($this->simulate($figure,$v_pos,$h_pos))
						{
							$figure->move($v_pos ,$h_pos);
							$bMoved =true;
							$rows = mysql_num_rows(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."history WHERE gid='".$this->gid."'"));
							
							$new_pos = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."field WHERE id='".$figure->id."'"));
							mysql_query("INSERT INTO ".$this->settings->mysql_prefix."history (gid,oid,color,fromh,fromv,toh,tov,type) VALUES ('".$this->gid."','".($rows+1)."','0','".$figure->h_pos."','".$figure->v_pos."','".$new_pos->h_row."','".$new_pos->v_row."','".$this->get_type_id($id)."')");
							
							mysql_query("UPDATE ".$this->settings->mysql_prefix."game SET active_player=white_player WHERE id='".$this->gid."'");
						}
				}
			}
			if($bMoved)
			{
				
				$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."users WHERE id='".$this->my_oponent."'");
				$urow = mysql_fetch_object($query);
				mysql_free_result($query);
				if(time() - $urow->last_activity > 300)
				{
					$req_sess=md5(microtime().$urow->id.$this->gid);
					mysql_query("INSERT INTO ".$this->settings->mysql_prefix."loader (uid,gid,req_sess) VALUES ('".$this->my_oponent."','".$this->gid."','$req_sess')");

					mail($urow->mail,"[TryChess]Your oponent made a move",$_SESSION['user']['nick']." made a move.\nNow it is your turn to play.\nTo play goto:\n ".$this->settings->chess_host."index.php?modul=loader&method=check&req_sess=$req_sess\nThis link will automaticly bring you to the game and login,\nit is only valide for one click\n\n-------------------------------\nHave fun!\n","From: ".$this->settings->admin_mail);
				}
			}
		}
		header("Location: index.php?modul=game&method=show");
	}
	function find_figures($color,$ingame)
	{
		
		for($i = 0;$i<count($this->field);$i++)
		{
				if($this->field[$i]['color'] == $color && $this->field[$i]['in_game']==$ingame)
				{
						$ret[]=$this->field[$i];
				}
		}
		return $ret;
		
	}
	private function check_check_ext($x,$y)
	{
		
		if($this->my_color == 'w')
		{
			$oponent_color = 1;
		}
		else
		{
			$oponent_color = 0;
		}
		$oponents = $this->find_figures($oponent_color,1);
		for($i = 0;$i<count($oponents);$i++)
		{
			
			$type = $this->get_name($oponents[$i]['type']);
			if(!class_exists($type))
				require "class.".$type.".php";
			$figure = new $type($oponents[$i]['id'],$oponent_color,$this->field,$this->settings->mysql_prefix);
			$allowed_moves =$figure->get_allowed();
			
			if($allowed_moves[$x][$y]['color']=='r')
			{
				//check!
				return 2;
				
			}

		}
		//not check
		return 1;

	}
	private function get_char_fromh($h)
	{
		
		switch($h)
		{
			case 0:
				return 'H';
				break;
			case 1:
				return 'G';
				break;
			case 2:
				return 'F';
				break;
			case 3:
				return 'E';
				break;
			case 4:
				return 'D';
				break;
			case 5:
				return 'C';
				break;
			case 6:
				return 'B';
				break;
			case 7:
				return 'A';
				break;
		}
	}
	private function get_histroy()
	{
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."history WHERE gid='".$this->gid."' ORDER BY oid DESC LIMIT 10");
		while($row = mysql_fetch_object($query))
		{
			if($row->color == 0)
				$color = "White";
			else
				$color = "Black";
			$list .= $color." ".$this->get_name($row->type)." From: ".$this->get_char_fromh($row->fromh)." ".($row->fromv+1)." TO: ".$this->get_char_fromh($row->toh)." ".($row->tov+1)."<BR>";
		}
		return $this->createTable("History",$list);
	}
	private function find_king($color)    
	{
		for($i = 0;$i<count($this->field);$i++)
		{
				if($this->field[$i]['type'] == 2 && $this->field[$i]['color'] == $color)
				{
					
						return $this->field[$i];
					
				}
		}
	}
	private function check_check()
	{
		if($this->my_color == 'w')
		{
			$king_color = 0;
			$oponent_color = 1;
		}
		else
		{
			$king_color = 1;
			$oponent_color = 0;
		}
		$king = $this->find_king($king_color);
		if( $this->check_check_ext($king['v_row'],$king['h_row']) == 2)
		{
			global $check;
			$check=true;
			return 2;
		}
				
				

	}

	
	function modify_field($id,$v_pos,$h_pos)
	{
		for($i = 0;$i<count($this->field);$i++)
			if($this->field[$i]['v_row']==$v_pos && $this->field[$i]['h_row']==$h_pos)
				$this->field[$i]['in_game']=0;
		for($i = 0;$i<count($this->field);$i++)
			if($this->field[$i]['id']==$id)
			{
				$this->field[$i]['v_row']=$v_pos;
				$this->field[$i]['h_row']=$h_pos;
				
			}
				
	}
	function undo_modify()
	{
		$this->field = "";
		
		$field_query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."field WHERE gid='".$this->gid."'");
		while($row = mysql_fetch_array($field_query))
		{
			
				$this->field[]= $row;
		}
		$this->ofield = $this->field;
		mysql_free_result($field_query);
				
	}
	function reload_field()
	{
		$this->field = $this->ofield;
	}
	function check_checkmate()
	{  
		//check my kings color and oponents color
		if($this->my_color == 'w')
		{
			$king_color = 0;
			$oponent_color = 1;
		}
		else
		{
			$king_color = 1;
			$oponent_color = 0;
		}
		$figures = $this->find_figures($king_color,1);
		$ck = 0;
		
		//for each of my figures try...
		for($a = 0;$a<count($figures);$a++)
		{
			$fig_type = $this->get_name($figures[$a]['type']);
			if(!class_exists($fig_type))
				require "class.".$fig_type.".php";
			$figure = new $fig_type($figures[$a]['id'],$king_color,$this->field,$this->settings->mysql_prefix);
			//fetch allowed moves
			$figure_allowed_moves =$figure->get_allowed();
			//if($fig_type == "king")
//				$figure_allowed_moves[$figure->v_pos][$figure->h_pos]['color'] = 'g';
			//... all alloves moves
			for($i = 0;$i<8;$i++)
			{
				for($j = 0;$j<8;$j++)
				{
					//if move is allowed
					if($figure_allowed_moves[$i][$j]['color']!="")
					{
						//simulate modification on the field
						$this->modify_field($figure->id,$i,$j);
						
						//and check if my king is in check
						if($this->check_check() != 2)
						{
							//if $ck is still 0 after all the tests, check mate!
							$ck++;
						}
						$this->reload_field();
					}
				}
			}
			//move figure back to its original position
			//$this->modify_field($figure->id,$figure->v_pos,$figure->h_pos);
		}
		
		//reload original field
		$this->reload_field();
		if($ck == 0)
			return true;
		else
			return false;

	}  
}
?>
