<?php
require "class.core.php";
class loader extends core
{
	function check()
	{
		if($_GET['req_sess']!='')
		{
			$req_sess = $_GET['req_sess'];
			$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."loader WHERE req_sess='$req_sess'");
			if(mysql_num_rows($query)==0)
				exit;
			$row = mysql_fetch_object($query);
			$uq = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE id='".$row->uid."'");
			$ur = mysql_fetch_object($uq);
			if(session_is_registered("user"))
				session_unregister("user");
			session_register("user");
			
			$_SESSION['user']['id'] = $ur->id;
			$_SESSION['user']['gid'] = $ur->gid;
			$_SESSION['user']['nick'] = $ur->nick;
			$_SESSION['user']['mail'] = $ur->mail;
			$_SESSION['user']['is_admin'] = $ur->is_admin;
			$_SESSION['user']['modul'] = "game";
			$_SESSION['user']['method'] = "show";
			$_SESSION['user']['gid'] = $row->gid;
			mysql_query("DELETE FROM ".$this->settings->mysql_prefix."loader WHERE id='".$row->id."'");
			header("Location: index.php?modul=manage&method=continue_game&gid=".$row->gid);
		}
	}
	function activate()
	{
		if($_GET['act_key']!='')
		{
			$act_key = $_GET['act_key'];
			$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."new_users WHERE act_key='".$act_key."'");
			if(mysql_num_rows($query) == 0)
				exit;
			
			$row = mysql_fetch_object($query);
			mysql_query("INSERT INTO ".$this->settings->mysql_prefix."users (nick,pw,mail) VALUES ('".$row->nick."','".$row->pw."','".$row->mail."')");
			$id = mysql_insert_id();
			$_SESSION['user']['id'] = $id;
			$_SESSION['user']['nick'] = $row->nick;
			$_SESSION['user']['mail'] = $row->mail;
			$_SESSION['user']['modul'] = "manage";
			$_SESSION['user']['method'] = "show";
			mysql_query("DELETE FROM ".$this->settings->mysql_prefix."new_users WHERE act_key='".$row->act_key."'");
			if($this->settings->new_member)
				mail($this->admin_mail,"[TryChess]New member",$row->nick."
".$row->mail);
			header("Location: index.php?modul=manage&method=show");
		}
	}
}
?>