<?php
require "class.view.php";

class document extends view
{
	function __construct()
	{
		parent::__construct();
		
		$this->title = "documentation";
		
			
			
	}
	function show()
	{
		$id = $_GET['id'];
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."documents WHERE sid = '$id' order by id ASC");

		
		//create document list:
		while($row = mysql_fetch_object($query))
			$list .= "&nbsp;&nbsp;-<B><A href=\"index.php?modul=document&method=show&id=".$row->id."\">$row->title</A></B><BR>
			";
			
		$query2 = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."documents WHERE id = '$id'");
		$crow = mysql_fetch_object($query2);
		if(mysql_num_rows($query2) == 0)
		{
			$title = "NONE";
			$text = "none";
		}
		else{

		
			$title = $crow->title;
			$text = NL2BR($crow->text);
		}
		$query3 = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."documents WHERE id='".$crow->sid."'");
		if(mysql_num_rows($query3) == 0)
			$list = "<B><A href=\"index.php?modul=document&method=show&id=0\">Documentation</A></B><BR>
			&nbsp;&nbsp;<B>".$crow->title."</B><BR>".$list;
		else
		{
			$prow = mysql_fetch_object($query3);
			$list = "<B><A href=\"index.php?modul=document&method=show&id=".$prow->id."\">$prow->title</A></B><BR>
			&nbsp;&nbsp;<B>".$crow->title."</B><BR>".$list	;
		}
		
		if($_SESSION['user']['is_admin'] == 1)
		{
			$del = "<A href=\"index.php?modul=document&method=del_doc&id=".$id."\" onClick=\"return confirm('Are you sure to delete this?')\">delete</A>";
		}else
			$del = "";
		if($_SESSION['user']['is_admin'] == 1)
			$new_doc =$this->add_doc_form();
		else
			$new_doc ="";
		$this->output.="<TABLE width=\"100%\">
			<TR>
				<TD width=\"20%\" valign=\"top\">
					".$this->createTable("Menu",$list)."
				</TD>
				<TD  valign=\"top\">
					".$this->createTable($title.$del,$text).$this->get_edit_form($id).$new_doc."
				</TD>
			</TR>
			</TABLE>";
		
		$this->show_output();
	}
	function add_doc_form()
	{
		if(!isset($_GET['id']))
			$id=0;
		else
			$id = $_GET['id'];
		$fields["action"] = "index.php?modul=document&method=new_doc&id=$id";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "a";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Title";
		$fields["field_text"][] = "Text";
		$fields["field_text"][] = "Save";
		$fields["field_name"][] = "title";
		$fields["field_name"][] = "text";
		$fields["field_name"][] = "save";
		
		$form= $this->createForm($fields);
		return $this->createTable("New Doument",$form);
	}
	function get_edit_form($id)
	{
		if($_SESSION['user']['is_admin'] != 1)
			return;
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."documents WHERE id='$id'");
		$row = mysql_fetch_object($query);
		$fields["action"] = "index.php?modul=document&method=edit_doc&id=$id";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "a";
		$fields["field_type"][] = "s";
		$fields["field_value"][] = $row->title;
		$fields["field_value"][] = $row->text;
		$fields["field_value"][] = "";
		$fields["field_text"][] = "Title";
		$fields["field_text"][] = "Text";
		$fields["field_text"][] = "Save";
		$fields["field_name"][] = "title";
		$fields["field_name"][] = "text";
		$fields["field_name"][] = "save";
		
		$form= $this->createForm($fields);
		return $this->createTable("Edit Doument",$form);
	
	}
	function new_doc()
	{
		if($_SESSION['user']['is_admin'] != 1)
			return;
		$id = $_GET['id'];
		$title = $_POST['title'];
		$text = $_POST['text'];
		$uid = $_SESSION['user']['id'];
		mysql_query("INSERT INTO ".$this->settings->mysql_prefix."documents (sid,title,text,author) VALUES ('$id','$title','$text','$uid')");
		header("Location: index.php?modul=document&method=show&id=$id");
	}
	function edit_doc()
	{
		if($_SESSION['user']['is_admin'] != 1)
			return;
		$id = $_GET['id'];
		$title = $_POST['title'];
		$text = $_POST['text'];
		$uid = $_SESSION['user']['id'];
		mysql_query("UPDATE ".$this->settings->mysql_prefix."documents SET title = '$title',text='$text' WHERE id='$id'");
		header("Location: index.php?modul=document&method=show&id=$id");
	}
	function del_child_doc($id)
	{
		$query = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."documents WHERE sid='$id'");
		while($row = mysql_fetch_object($query))
		{
			$this->del_child_doc($row->id);
		}
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."documents WHERE id='".$id."'");
		
	}
	function del_doc()
	{
		if(!isset($_GET['id']))
			$id=0;
		else
			$id = $_GET['id'];
		$bGo = true;
		if($_SESSION['user']['is_admin'] == 1)
			$this->del_child_doc($id);
		header("Location: index.php?modul=document&method=show");
		exit;
	}
}
?>