<?php
//chat class
require "class.core.php";
class chat extends core
{
	function show()
	{
		$gid = $_SESSION['user']['gid'];
		$form = "
			<FORM method=\"POST\" action=\"index.php?modul=chat&method=newmsg\">
				<INPUT type=\"text\" name=\"msg\"class=\"input_large\"><INPUT class=\"button\" type=\"submit\" value=\"Send\">
			</FORM>";
		$inneriframe = "<IFRAME width=0% height=0 src=\"index.php?modul=chat&method=check_new&time=0\"/> ";
		$output = "<HTML>
						<HEAD>
							<TITLE>Chat</TITLE>
							<LINK rel=\"stylesheet\" href=\"styles/main.css\" type=\"text/css\" />
						</HEAD>
						<BODY class=\"body\">
							$form<BR><span id=\"chat\"></span>
							$inneriframe
							
						</BODY>
					</HTML>";
		print $output;
	}
	function newmsg()
	{
		$msg = $_POST['msg'];
		$gid = $_SESSION['user']['gid'];
		$uid = $_SESSION['user']['id'];
		mysql_query("INSERT INTO ".$this->settings->mysql_prefix."chat (gid,uid,msg,ts) VALUES ('$gid','$uid','$msg','".time()."')");
		header("Location: index.php?modul=chat&method=show");
	}
	function idToNick($id)
	{
		$urow = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."users WHERE id='$id'"));
		return $urow->nick;
		
	}
	function check_new()
	{
		$gid = $_SESSION['user']['gid'];
		$time = $_GET[time];
		$query1 = mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."chat WHERE gid='$gid' and ts>'$time' ORDER BY id desc");
		while($row = mysql_fetch_object($query1))
		{
			if($time < $row->ts)$time = $row->ts;
			if($row->uid != $_SESSION['user'][id])
				$font = "<FONT color=\"#444400\">";
			else
				$font = "<FONT color=\"#000000\">";
			$text.="$font<U><B>".$this->idToNick($row->uid)."</B></U><FONT size=\"-1\"><I>(".date("h:i:s",$row->ts).")</I></FONT><B>:</B> ".$row->msg."<BR></FONT>";
			
		}
		mysql_free_result($query1);
		if($_SESSION['user']['playing'] == '0')
		{
			$game_row = mysql_fetch_object(mysql_query("SELECT * FROM  ".$this->settings->mysql_prefix."game WHERE id='$gid'"));
			if($game_row->active_player == $_SESSION['user']['id'])
			{
				if($game_row->winner==0)
				 $reload_parent = "parent.parent.document.location.href=parent.parent.document.location.href";
				else
				 $reload_parent = "parent.parent.document.location.href=parent.parent.document.location.href+'&game=over'";
			}
		}
		;
		$text = str_replace("'","\'",$text);
		print "<HTML>
						<HEAD>
							<TITLE>Renew...</TITLE>
							<META HTTP-EQUIV=\"refresh\" content=\"3;URL=index.php?method=check_new&modul=chat&time=$time\">
						</HEAD>
						<BODY>
							<SCRIPT language=\"Javascript\">
								parent.document.getElementById('chat').innerHTML='$text'+parent.document.getElementById('chat').innerHTML;
								$reload_parent
							</SCRIPT>
						</BODY>
					</HTML>";
	}
}
?>