<?php
class figure
{
	//position on the field
	var $v_pos;
	var $h_pos;
	//game_id
	var $gid;
	var $id;
	var $color;
	var $oponent_color;
	//reference to the field
	var $field;
	//pawn move is needed for en passant
	var $pawn_move;
	//was not moved yet:
	var $initial_position;
	//prefix for mysql_queries
	var $prefix;
	function __construct($id,$color,$field,$prefix)
	{
		//setup stuff
		$this->prefix = $prefix;
		//can't move on the x axis;
		$v_x = 0;
		$query = mysql_query("SELECT * FROM ".$prefix."field WHERE id = '$id'");
		$this->id = $id;
		if(mysql_num_rows($query) == 0)
			return;
		$row = mysql_fetch_object($query);
		//set pawn move
		$this->pawn_move = $row->pawn_move;
		
		//set current position
		$this->v_pos = $row->v_row;
		$this->h_pos = $row->h_row;
		
		$this->gid = $row->gid;
		
		
		$this->initial_position = $row->initial_position;
		if($color == 'w')
		{
			$this->color = 0;
			$this->oponent_color = 1;
		}
		else
		{
			$this->color = 1;
			$this->oponent_color = 0;
		}	
		//set field:
		$this->field = $field;
	}
	
	function is_allowed($x,$y)
	{

		
		$fields = $this->get_allowed();

		if($fields[$x][$y]['color']!='')
		{
			return true;	
		}
		else
			return false;

	}
	function move($x,$y,$addon="")
	{
		mysql_query("UPDATE ".$this->prefix."field SET pawn_move='0' WHERE gid=". $this->gid);
		
		mysql_query("UPDATE ".$this->prefix."game SET turns=turns+1 WHERE id='".$this->gid."'");
		mysql_query("UPDATE ".$this->prefix."field SET in_game='0' WHERE v_row = '$x' and h_row='$y' and gid='".$this->gid."'");
		mysql_query("UPDATE ".$this->prefix."field SET v_row = '$x',h_row='$y', initial_position='0'$addon where id='".$this->id."'");
		
		
	}
	  
	  
	function find_figure($vpos,$hpos, $ingame=0)
	{
		
		for($i = 0;$i<=count($this->field);$i++)
		{
				if($this->field[$i]['v_row'] == $vpos && $this->field[$i]['h_row'] == $hpos)
				{
					if($this->field[$i]['in_game']==$ingame)
					{
						return $this->field[$i];
					}
				}
		}
		
	}
	function find_figure_by_color($vpos,$hpos, $color,$pawn_move=false)
	{
		
		for($i = 0;$i<count($this->field);$i++)
		{
				if($this->field[$i]['v_row'] == $vpos && $this->field[$i]['h_row'] == $hpos)
				{
					if($this->field[$i]['color']==$color && $this->field[$i]['in_game']==1)
					{
						if(!$pawn_move)
							return $this->field[$i];
						else if($this->field[$i]['pawn_move'] == 1)
							return $this->field[$i];
					}
				}
		}
		
	}
	function find_figures_by_type($color,$type)
	{
		
		for($i = 0;$i<count($this->field);$i++)
		{
					if($this->field[$i]['color']==$color && $this->field[$i]['in_game']==1 && $this->field[$i]['type']==$type)
					{
						$figures[] = $this->field[$i];
					}
		}
		return $figures;
		
	}
	
}
?>
