<?php
//king
if(!class_exists("figure"))
	require "class.figure.php";
class queen extends figure
{

	function get_allowed()
	{
		
		//check the all possible ways:
		//one
		for($a = -1;$a<=1;$a++)
		{
			for($b = -1;$b<=1;$b++)
			{
				if(!($a==0 && $b==0))
				{
					$i = 0;
					$j = 0;
					$bGo = true;
					while($bGo)
					{
						$i+=$a;
						$j+=$b;
						if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->oponent_color)=="")
						{
							if($this->find_figure_by_color(($this->v_pos+$i),($this->h_pos+$j),$this->color)=="")
							{
								$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'g';
								
							}else
								$bGo = false;
						}else
						{
								$fields[$this->v_pos+$i][$this->h_pos+$j]['color'] = 'r';
								$bGo = false;
						}
						if(($this->v_pos+$i)<0|($this->v_pos+$i)>7 | ($this->h_pos+$j)<0|($this->h_pos+$j)>7)
							$bGo = false;
					}
				}
				
			}
		}

		return $fields;
		
	}

}
?>