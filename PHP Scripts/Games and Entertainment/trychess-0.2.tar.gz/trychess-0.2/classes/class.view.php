<?PHP
//view class
require "class.core.php";
class view extends core
{
	var $output;
	var $settings;
	var $title;
	function __construct()
	{
		global $no_core;
		if(!$no_core)
			parent::__construct();
	}
	function show_output()
	{
		//construct menu:
		global $no_core;
		if(!$no_core){
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."documents WHERE sid='0' order by id asc");
		while($row = mysql_fetch_object($query))
		{
			$do .= " | <A href=\"index.php?modul=document&method=show&id=".$row->id."\">".$row->title."</A> ";
		}}
		$admin = "";
		if($_SESSION['user']['is_admin'] == 1)
		{
			$admin = " | <A href=\"index.php?modul=admin&method=show\">Administration</A>";
		}
		$menu = "<A href=\"index.php?modul=login&method=show\">Home</A> | <A href=\"index.php?modul=manage&method=show\">Play game</A> | <A href=\"index.php?modul=news&method=show\">News</A> | <A href=\"index.php?modul=forum&method=show\">Forum</A>$do$admin";
		require "includes/header.php";
		print $this->output;
		require "includes/footer.php";
	}
	//create a form based on a form array
	//this array has diffrent fields to format the form inputs
	//fields are:
	//$fileds["action"] - where the form should be send
	//$fileds["field_type"] - type of the field:
	//				types are:
	//					-t: normal text input
	//					-p: password input
	//					-s: submit button
	//					-b: normal button
	//					-a: text area
	//					-c: text comment in form
	
	public function createForm($fields)
	{
		$out = "<FORM method=\"POST\" action=\"".$fields["action"]."\">
					<TABLE>";
		//run through the format array (do this for each field)
		for($i = 0;$i<count($fields["field_type"]);$i++)
		{
			//check which type
			switch($fields["field_type"][$i])
			{
				case "c":
					$out.="
						<TR>
							<TD colspan=\"1\">
								".$fields["field_text"][$i]."
							</TD>
							<TD colspan=\"1\">
								<B>".$fields["field_value"][$i]."</B>
							</TD>
						</TR>";
					break;			
				//text input
				case "t":
					$out.="
						<TR>
							<TD colspan=\"1\">
								".$fields["field_text"][$i]."
							</TD>
							<TD colspan=\"1\">
								<INPUT type=\"text\" name=\"".$fields["field_name"][$i]."\" value=\"".$fields["field_value"][$i]."\" class=\"input\">
							</TD>
						</TR>";
					break;
				//text area
				case "a":
					$out.="
						<TR>
							<TD colspan=\"2\">
								".$fields["field_text"][$i]."
							</TD>
						</TR>
						<TR>
							<TD colspan=\"2\">
								<TEXTAREA name=\"".$fields["field_name"][$i]."\"  class=\"textarea\">".$fields["field_value"][$i]."</TEXTAREA>
							</TD>
						</TR>";
					break;
				//password input
				case "p":
					$out.="
						<TR>
							<TD colspan=\"1\">
								".$fields["field_text"][$i]."
							</TD>
							<TD colspan=\"1\">
								<INPUT type=\"password\" name=\"".$fields["field_name"][$i]."\" value=\"".$fields["field_value"][$i]."\" class=\"input\">
							</TD>
						</TR>";
					break;
				//submit button
				case "s":
					$out.="
						<TR>
							<TD colspan=\"2\">
								<INPUT type=\"submit\" name=\"".$fields["field_name"][$i]."\" value=\"".$fields["field_text"][$i]."\" class=\"button\">
							</TD>
						</TR>";
					break;
					
				//print an empty row
				default:
					$out .= "<TR>
					<TD colspan=\"2\">&nbsp;</TD>
					</TR>";
					break;
			}     
		}
		$out .= "
			</TABLE>
		</FORM>";
		
		return $out;
	}
	//create a blank table with $text as text,...
	public function createEmptyTable($text,$width="100%",$alignement="center")
	{
		$table ="
		<TABLE width=\"$width\" align=\"$alignement\">
			<TR class=\"table_title\">
				<TD>
					$text
				</TD>
			</TR>
		</TABLE>";
		return $table;
	}
	//create a standart table
	public function createTable($title,$text,$width="100%")
	{
		$table ="
		<TABLE width=\"$width\">
			<TR>
				<TD class=\"table_title\">
					$title
				</TD>
			</TR>
			<TR>
				<TD class=\"table_body\">
					$text
				</TD>
			</TR>
		</TABLE>";
		return $table;
	}
}
?>