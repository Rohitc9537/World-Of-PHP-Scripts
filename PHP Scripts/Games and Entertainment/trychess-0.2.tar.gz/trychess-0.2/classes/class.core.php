<?php

class core{
	var $settings;
	var $mysql;
	var $error_logger;
	function __construct()
	{

		require "class.settings.php";
		require "class.mysql.php";
		require "class.error_logger.php";
		$this->settings = new settings;
		$this->error_logger = new error_logger($this->settings->log_file);
		$this->mysql = new mysql();
		$this->mysql->connect($this->settings);
		
		//set activity:
		if(session_is_registered("user") | $_SESSION['user']['id']!="")
		{
			mysql_query("UPDATE ".$this->settings->mysql_prefix."users SET last_activity = '".time()."' WHERE id='".$_SESSION['user']['id']."'");
		}
	}

}

?>