<?php
//login
require "class.view.php";
global $no_core;
$no_core = true;
class install extends view{
	function __construct()
	{
		if(file_exists("classes/class.settings.php"))
		{
			header("Location: index.php");
			exit;
		}
		parent::__construct();
	}
	public function show($error="")
	{
		
		$this->title = "install";
		
		$fields["action"] = "index.php?modul=install&method=install";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "t";//host
		$fields["field_type"][] = "t";//db
		$fields["field_type"][] = "t";//nick
		$fields["field_type"][] = "p";//pw
		$fields["field_type"][] = "t";//prefix
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "USER SETTINGS";
		$fields["field_text"][] = "Admin Nick";
		$fields["field_text"][] = "Admin Password";
		$fields["field_text"][] = "Admin Password*";
		$fields["field_text"][] = "Admin Mail";
		$fields["field_text"][] = "MySQL SETTINGS";
		$fields["field_text"][] = "MySQL Host";
		$fields["field_text"][] = "MySQL Database";
		$fields["field_text"][] = "MySQL Login";
		$fields["field_text"][] = "MySQL Password";
		$fields["field_text"][] = "Table Prefix";
		$fields["field_text"][] = "SERVER SETTINGS";
		$fields["field_text"][] = "";
		$fields["field_text"][] = "Exact host address";
		$fields["field_text"][] = "";
		$fields["field_text"][] = "Use mail functions";
		$fields["field_text"][] = "Install";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "nick";
		$fields["field_name"][] = "pw";
		$fields["field_name"][] = "pwa";
		$fields["field_name"][] = "mail";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "mysql_host";
		$fields["field_name"][] = "mysql_db";
		$fields["field_name"][] = "mysql_nick";
		$fields["field_name"][] = "mysql_pw";
		$fields["field_name"][] = "mysql_prefix";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "full_host";
		$fields["field_name"][] = "";
		$fields["field_name"][] = "use_mail";
		$fields["field_name"][] = "install";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "localhost";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "trychess_";
		$fields["field_value"][] = "";
		$fields["field_value"][] = "enter address like: http://chess.trypill.org/ (ending \"/\" needed!)";
		$script = str_replace("index.php","","http://".$_SERVER["HTTP_HOST"].$_SERVER["SCRIPT_NAME"]);
		
		$fields["field_value"][] = $script;
		$fields["field_value"][] = "e-mail support will inform users about new games and... (1=on,0=off)";
		$fields["field_value"][] = "1";
		$fields["field_value"][] = "";
		
		$install = $this->createForm($fields);
		
		
		
		$out = "
			<FONT color=\"#993333\">$error<BR></FONT>
			$install 

		";
		$this->output .= $this->createTable("Install: ",$out);
		$this->show_output();
	}
	function install()
	{
		
		$error_=false;
		if(strlen($_REQUEST['nick'])<4)
		{
			$error[] = "Enter a nick with at least 4 chars.";
			$error_ = true;
		}
		if($_REQUEST['pw'] != $_REQUEST['pwa'])
		{
			$error[] = "Enter twice the same password.";
			$error_ = true;
		}
		if( !eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*"
				."@([a-z0-9]+([\.-][a-z0-9]+))*$",
					$_REQUEST['mail'], $regs) )
		{
			$error[] = "Invalid admin mail address.<BR>";
			$error_ = true;
		}
		$chess_host = $_REQUEST['full_host'];
		if(strlen($chess_host)==0)
		{
			$error[] = "Enter the URL to the TryChess Script.<BR>";
			$error_ = true;
		}
		
		$link = mysql_connect($_REQUEST['mysql_host'],$_REQUEST['mysql_nick'],$_REQUEST['mysql_pw']);
		if($link)
		{
			$db_selected = mysql_select_db($_REQUEST['mysql_db'],$link);
			if($db_selected)
			{
				$this->exec_sql("install.sql",$_REQUEST['mysql_prefix']);
				$error[] = "Created tables and inserted values.";
			}
			else
			{
				if(!mysql_query("CREATE DATABASE `".$_REQUEST['mysql_db']."`"))
				{
					$error[] = "You are not allowed to create a Database.<br/> use an existing one.";
					$error_=true;
				}else
				{
					$error[] = "Created Database";
					mysql_select_db($_REQUEST['mysql_db']);
					$this->exec_sql("install.sql",$_REQUEST['mysql_prefix']);
					$error[] = "Created tables and inserted values.";
				}
				
			}
				
			
		}else
		{
			$error[] = "Invalid MySQL Settings";
			$error_=true;
		}
		if(!$error_)
		{
			mysql_query("INSERT INTO ".$_REQUEST['mysql_prefix']."users  (nick,pw,mail,is_admin) VALUES ('".$_REQUEST['nick']."','".md5($_REQUEST['pw'])."','".$_REQUEST['mail']."','1')");
			if($_REQUEST['use_mail'] == 1)
				$use_mail = "true";
			else
				$use_mail = "false";
			
$settings="<?php
class settings{
	var \$mysql_login;
	var \$mysql_pw;
	var \$mysql_host;
	var \$mysql_db;
	var \$version;
	var \$use_mail;
	var \$admin_mail;
	var \$chess_host;
	var \$new_member;
	var \$mysql_prefix;
	function __construct()
	{
		\$this->version = \"0.2\";
		\$this->mysql_login	=	\"".$_REQUEST['mysql_nick']."\";
		\$this->mysql_pw	=	\"".$_REQUEST['mysql_pw']."\";
		\$this->mysql_host	=	\"".$_REQUEST['mysql_host']."\";
		\$this->mysql_db	=	\"".$_REQUEST['mysql_db']."\";
		\$this->mysql_prefix	=	\"".$_REQUEST['mysql_prefix']."\";
		
		\$this->use_mail 	=	$use_mail;
		\$this->admin_mail 	=	\"valen16@trypill.org\";
		\$this->chess_host 	=	\"$chess_host\";
		\$this->new_member	=	false;
	}
}

?>";
			if (!$handle = @fopen("classes/class.settings.php", 'a')) {
				$error[] = "Could not create settings file!<br/> Donwload <a href=\"index.php?module=install&method=download&file=".base64_encode($settings)."\">this file</a> and copy it in the subfolder \"classes\" from the TryChess directory";
				
			}else
			{
				fwrite($handle, $settings);
				$error[] = "Settings file created";
				$error[] = "Installation completed";
			}
			$this->error($error);
			$this->success();
			
		}else
		{
			$this->error($error);
			$this->show();
		}
	}
	function error($error)
	{
		$text = "<font color=\"#993333\">";
		for($i = 0; $i<count($error);$i++)
		{
			$text.= $error[$i]."<br/>";
		}
		$this->output .= view::createTable("Information",$text);
	}
	function download()
	{
		$string = base64_decode($_REQUEST['file']);
		
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: inline; filename=class.settings.php");
		echo $string;
		exit;
	}
	function success()
	{
		$text = "If you've done all off the above listed tasks (possibly none are needed)<br/>
		you can now <a href=\"index.php?modul=login&method=show\">enter TryChess</a> the first time";
		$this->output .= view::createTable("Installation completed",$text);
		$this->show_output();
	}
	function exec_sql($file,$prefix)
	{
		
		$fp = @fopen($file, "r");
		$file = fread($fp, 80000);
		fclose($fp);
		
		$lines = explode(';',  $file); 
		$cnt = count($lines); 
		
		for($i=0; $i<count($lines)-1; $i++  ) {
			
			$lines[$i] = str_replace("INSERT INTO `","INSERT INTO `$prefix",$lines[$i]);
			$lines[$i] = str_replace("CREATE TABLE `","CREATE TABLE `$prefix",$lines[$i]);
			if(!mysql_query($lines[$i])) {
			
				echo "Error on line $i of Query:<br>";
				echo mysql_error();
				die;
			}
		}
	}
	
}
?>