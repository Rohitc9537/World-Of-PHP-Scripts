<?php
require "class.view.php";
class manage extends view
{
	function __construct()
	{                
		if(!session_is_registered("user") | $_SESSION['user']['nick']=="")
		{
			header("Location: index.php?modul=login&method=show");
		}       
		parent::__construct();
	}
	public function show($info = "")
	{
		if(!isset($_GET['do']))
			$do = "show_games";
		else
			$do = "show_".$_GET['do'];
		if($_GET['do'] == "search")
			$do = "show_games";
		
		
		
		$this->output.="<BR>".$this->createTable("Manage:",
		"<TABLE width=\"100%\">
			<TR>
			<TD width=\"20%\" valign=\"top\">
			".$this->show_menu()."
			</TD>
			<TD valign=\"top\">
			".call_user_method($do,$this)."
			</TD>
			</TR>
		</TABLE>
		")	;
		
		$this->show_output();
	}
	function show_menu()
	{
		if($_GET['do'] == "games"|!isset($_GET['do']))
			$act1 = "active_menu";
      if($_GET['do'] == "search")
			$act3 = "active_menu";
		if($_GET['do'] == "profile")
			$act4 = "active_menu";
		$output.="<TABLE><TR><TD class=\"$act1\"><A href=\"index.php?modul=manage&method=show&do=games\">Your Games</A></TD></TR>
		<TR><TD class=\"$act3\"><A href=\"index.php?modul=manage&method=show&do=tournaments\">Tournaments</A></TD></TR>
		<TR><TD class=\"$act3\"><A href=\"index.php?modul=manage&method=show&do=search#search\">Search oponent</A></TD></TR>
		<TR><TD class=\"$act4\"><A href=\"index.php?modul=manage&method=show&do=profile\">Your Profile</A></TD></TR></TABLE>";
		return $this->createTable("Menu:",$output);
	}
	
	function show_profile()
	{
		$fields = "";
		$fields["action"] = "index.php?modul=login&method=change";
		$fields["field_type"][] = "c";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "p";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Nick";
		$fields["field_text"][] = "Password";
		$fields["field_text"][] = "Password";
		$fields["field_text"][] = "E-Mail";
		$fields["field_text"][] = "Update";
		$fields["field_name"][] = "nick";
		$fields["field_name"][] = "pw";
		$fields["field_name"][] = "pwa";
		$fields["field_name"][] = "mail";
		$fields["field_name"][] = "Update";
		$fields["field_value"][]=$_SESSION['user']['nick'];
		$fields["field_value"][]="";
		$fields["field_value"][]="";
		$fields["field_value"][]=$_SESSION['user']['mail'];
		if(isset($_GET['error']))
			$error = "<FONT color=\"#993333\">".$_GET['error']."</FONT><BR>";
		return $this->createTable("Your profile:",$error.$this->createForm($fields));
	}
	function show_games()
	{
		//list current games
		$sql1 = "SELECT * FROM ".$this->settings->mysql_prefix."game WHERE (black_player='".$_SESSION['user']['id']."' OR white_player='".$_SESSION['user']['id']."') AND tid='0'";
		$query1 = mysql_query($sql1);
		if(mysql_num_rows($query1) == 0)
		{
			$current_games = "<B>No games running!";
		}else
		{
			$current_games = "
			<TABLE width=\"100%\">
			<TR>
				<TD width=\"10%\"><B>Black Player</B></TD>
				<TD width=\"10%\"><B>White Player</B></TD>
				<TD width=\"15%\"><B>Playing Since</B></TD>
				<TD width=\"13%\"><B>Moves made</B></TD>
				<TD width=\"10%\"><B>Winner</B></TD>
				<TD><B>Options</B></TD>
			</TR>
			";
			$i = 0;
			while($row = mysql_fetch_object($query1))
			{
				if($i%2 == 0)
					$class = "table_ext";
				else
					$class = "table_body";
				$wplayer = mysql_fetch_object(mysql_query("SELECT nick,id from ".$this->settings->mysql_prefix."users WHERE id='$row->white_player'"));
				$bplayer = mysql_fetch_object(mysql_query("SELECT nick,id from ".$this->settings->mysql_prefix."users WHERE id='$row->black_player'"));
				if($row->winner == $row->black_player)
					$winner = $bplayer->nick;
				else if($row->winner == $row->white_player)
					$winner = $wplayer->nick;
				else
					$winner = "none yet";
				
				if($bplayer->id == $row->active_player)
				{
					$b1 = "<B>";
					$b2 = "</B>";
				}
				else
				{
					$b1 = "";
					$b2 = "";
				}
				if($wplayer->id == $row->active_player)
				{
					$c1 = "<B>";
					$c2 = "</B>";
				}
				else
				{
					$c1 = "";
					$c2 = "";
				}
				$current_games .= "
				<TR class=\"$class\">
					<TD>
						$b1 $bplayer->nick $b2
					</TD>
					<TD>
						$c1 $wplayer->nick $c2
					</TD>
					<TD>
						".date("d/m/Y - h:i:s",$row->start_time)."
					</TD>
					<TD>$row->turns</TD>
					<TD>$winner</TD>
					<TD><A href=\"index.php?modul=manage&method=continue_game&gid=$row->id\"><IMG src=\"images/continue.png\" border=0>continue</A> | <A href=\"index.php?modul=manage&method=delete_game&gid=$row->id\" onClick=\"return confirm('Are you sure to delete this game?')\"><IMG src=\"images/delete.png\" border=0>delete</A></TD>
				</TR>";
				$i++;
			}
			$current_games .= "
			</TABLE>";
		}	   
		$return=$this->createTable("Your current games: ",$current_games)."<BR>";
		
		//search for oponent:
		$fields["action"] = "index.php";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Opponent Nick";
		$fields["field_text"][] = "Search";
		$fields["field_name"][] = "onick";
		$fields["field_name"][] = "search";
		
		$search = $this->createForm($fields);
		//if search query was allready set:
		$result="";
		if($_POST["onick"])
		{
			$nick = $_POST["onick"];
			if($nick != "")
			{
				$query2 = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE nick like '%$nick%'");
				while($row = mysql_fetch_object($query2))
				{
					$result .= $this->get_user_link($row->id,$row->nick,$row->won,$row->lost)."&nbsp; &nbsp; &nbsp; <BR>";
					if($i%3 == 0)
					{
						$result.="<BR>";
					}
				}
			}
		}
		if(isset($_GET['char']))
		{
				$query2 = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE nick like '".$_GET['char']."%'");
				while($row = mysql_fetch_object($query2))
				{
					$result .= $this->get_user_link($row->id,$row->nick,$row->won,$row->lost)."&nbsp; &nbsp; &nbsp; <BR>";
				}
		}
		//make list:
		$i = 'A';
		do
		{
			$list.= "<A href=\"index.php?modul=manage&method=show&char=$i\">$i</A> : ";
			$i++;
		}while($i != 'Z');
		$list.= "<A href=\"index.php?modul=manage&method=show&char=Z\">Z</A> <HR> ";
		
		
		
		return $return.$this->show_new_tournaments().$this->show_signed_tournaments()."<TABLE width=\"100%\"><TR valign=\"top\"><TD width=\"70%\">".$this->createTable("<A name=\"search\"></A>Search for an oponent: ",$search.$list.$result)."<BR>".$this->invite_friend()."</TD><TD>".$this->get_top_players()."<BR>".$this->get_online_players()."</TD></TR></TABLE><BR>";
	}
	
	function get_top_players()
	{
		//find top ten players:
		$top_query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE won>0 OR lost>0 ORDER BY (won+1)/(lost+1) DESC  LIMIT 10");
		$i=1;
		while($top_row = mysql_fetch_object($top_query))
		{
			$top_players.= "$i - ".$this->get_user_link($top_row->id,$top_row->nick,$top_row->won,$top_row->lost)."<BR>"; 
			$i++;
		}
		return $this->createTable("Top 10 Players: (won/lost) ",$top_players);
	}
	function get_online_players()
	{
		//find top ten players:
		$la_query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE last_activity>".(time()-300)." ORDER BY
		 last_activity DESC LIMIT 10");
		$i=1;
		
		while($la_row = mysql_fetch_object($la_query))
		{
			$dif_time = time()-($la_row->last_activity);
		
			$dif_string = date("i:s",$dif_time);
			$la_players.= "$i - ".$this->get_user_link($la_row->id,$la_row->nick,$la_row->won,$la_row->lost)." ($dif_string)<BR>"; 
			$i++;
		}
		return $this->createTable("Online Players: (inactive since: min:sec)",$la_players."<BR><FONT size=\"-1\">(active in the last 5 minutes)</FONT>");
	}
	function get_user_link($id,$nick,$wins,$lost)
	{
		if($id != $_SESSION['user']['id'])
			return "<A href=\"index.php?modul=manage&method=new_game&oid=$id\" onclick=\"return confirm('Create game against: $nick?')\">$nick</A> ($wins/$lost)";
		else
			return "$nick ($wins/$lost)";
	}
	function continue_game()
	{
		$_SESSION["user"]["gid"] = $_GET["gid"];
		header("Location: index.php?modul=game&method=show");
		exit;
	}
	function delete_game()
	{
		$gid = $_GET["gid"];
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."game WHERE id='$gid'");
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."field WHERE gid='$gid'");
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."chat WHERE gid='$gid'");
		mysql_query("DELETE FROM ".$this->settings->mysql_prefix."history WHERE gid='$gid'");
		header("Location: index.php?modul=manage&method=show");
		exit;
	}
	function new_game()
	{
		$white_id = $_SESSION['user']['id'];
		$black_id = $_GET['oid'];
		//create game
		mysql_query("INSERT INTO ".$this->settings->mysql_prefix."game (white_player,black_player,active_player,start_time) VALUES ('$white_id','$black_id','$white_id','".time()."')");
		//game id
		$gid = mysql_insert_id();
		//create field:
		//types:
		//		-1 = farmer
		//		-2 = king
		//		-3 = queen
		//		-4 = runner
		//		-5 = horse
		//		-6 = tower
		
		//white farmers	
		$figures['type'][] = '1';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		$figures['type'][] = '1';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '1';
		$figures['color'][] = '0';
		//black farmers
		$figures['type'][] = '1';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		$figures['type'][] = '1';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '6';
		$figures['color'][] = '1';
		//kings_
		$figures['type'][] = '2';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '2';
		$figures['hpos'][] = '3';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//queens
		$figures['type'][] = '3';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '3';
		$figures['hpos'][] = '4';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//towers
		$figures['type'][] = '6';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '6';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '6';
		$figures['hpos'][] = '0';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '6';
		$figures['hpos'][] = '7';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//horses
		$figures['type'][] = '5';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '5';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '5';
		$figures['hpos'][] = '1';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '5';
		$figures['hpos'][] = '6';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		//runners
		$figures['type'][] = '4';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '4';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '0';
		$figures['color'][] = '0';
		$figures['type'][] = '4';
		$figures['hpos'][] = '2';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		$figures['type'][] = '4';
		$figures['hpos'][] = '5';
		$figures['vpos'][] = '7';
		$figures['color'][] = '1';
		for($i = 0;$i<count($figures['type']);$i++)
		{
			$sql = "INSERT INTO ".$this->settings->mysql_prefix."field (gid,h_row,v_row,in_game,color,type) values ('$gid','".$figures["hpos"][$i]."','".$figures["vpos"][$i]."','1','".$figures["color"][$i]."','".$figures["type"][$i]."')";
			mysql_query($sql);
		}
		$_SESSION["user"]["gid"] = $gid;
		$query = mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."users WHERE id='".$black_id."'");
		$urow = mysql_fetch_object($query);
		mysql_free_result($query);
		if(time() - $urow->last_activity > 300){
			if($this->settings->use_mail)
			{
				$req_sess=md5(microtime().$uid.$gid);
				mysql_query("INSERT INTO ".$this->settings->mysql_prefix."loader (uid,gid,req_sess) VALUES ('$black_id','$gid','$req_sess')");
				mail($urow->mail,"[TryChess]A new match was created",$_SESSION['user']['nick']." started a new match against you\nTo play, go to ".$this->settings->chess_host."index.php?modul=loader&method=check&req_sess=$req_sess\nThis link will automaticly bring you to the game and login,\nit is only valide once!\n\n-------------------------------\nHave fun!\n","From: ".$this->settings->admin_mail);
			}
		}
		header("Location: index.php?modul=game&method=show");
		
	}
	
	function invite_friend()
	{
		$fields["action"] = "index.php?modul=manage&method=invite";
		$fields["field_type"][] = "t";
		$fields["field_type"][] = "a";
		$fields["field_type"][] = "s";
		$fields["field_text"][] = "Your friend's e-mail";
		$fields["field_text"][] = "Your message";
		$fields["field_text"][] = "Invite";
		$fields["field_name"][] = "mail";
		$fields["field_name"][] = "text";
		$fields["field_name"][] = "send";
		$text= $this->createForm($fields);
		
		$text = "Enter your friend's e-mail address and write a message...<BR>TryChess will send a mail to him".$text;
		return $this->createTable("Invite a friend",$text);
	}
	function invite()
	{
		$mail = $_POST['mail'];
		$text = $_POST['text'];
		$umail = $_SESSION['user']['mail'];
		$nick = $_SESSION['user']['nick'];
		$message =
		"$nick ($umail) invited you for an online chess match at:\n".$this->settings->chess_host."\n---------------------------------------------\nHe/She wrote:\n$text";
		if($this->settings->use_mail)
			mail($mail,"$umail invited you for a chess match",$message,"FROM: noreply@trypill.org");
		header("Location: index.php?modul=manage&method=show");
	}
	
	function show_new_tournaments()
	{
		require "class.tournaments.php";
		if($this->need_tournaments())
		{
			
			$tour = tournaments::get_list($_SESSION['user']['id'],$this->settings->mysql_prefix);
			if($tour != "")
				return $this->createTable("Tournaments (new)",$tour);
			
				
		}
		
	}
	function show_signed_tournaments()
	{
		
		$tour = tournaments::get_reg_list($_SESSION['user']['id'],$this->settings->mysql_prefix);
		if($tour != "")
			return $this->createTable("Tournaments (active)",$tour);
		
	}
	function need_tournaments()
	{
		
		$rows = mysql_num_rows(mysql_query("SELECT * FROM ".$this->settings->mysql_prefix."tournaments WHERE start_date>'".time()."' ORDER BY start_date ASC"));
		
		if($rows == 0)
			return false;
		else
			return true;
	}
	function tournament_signup()
	{
		require "class.tournaments.php";
		if(tournaments::signup($_SESSION['user']['id'],$this->settings->mysql_prefix,$_REQUEST['id']))
		{
			$error = "You signed up succesfully for this tournament";
			header("Location: index.php?module=manage&method=tournaments&error=$error");
		}else
		{
			$error = "Operation failed";
			header("Location: index.php?module=manage&method=show&error=$error");
		}
		
	}
	function show_tournaments()
	{
		//fetch current tournaments
		require "class.tournaments.php";
		$first = 0;
		$output = $this->createTable("Your tournaments",tournaments::get_reg_list($_SESSION['user']['id'],$this->settings->mysql_prefix,$first));
		if($_GET['id'] == 0)
			$id = $first;
		else
			$id = $_GET['id'];
		if($id>0);
		$output .= $this->createTable("Tournament details",tournaments::get_details($_SESSION['user']['id'],$this->settings->mysql_prefix,$id));
		return $output;
	}
}
?>