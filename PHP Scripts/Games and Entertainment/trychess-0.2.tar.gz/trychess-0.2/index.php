<?php
//index
session_start();
if(!file_exists("classes/class.settings.php"))
{
	$modul = "install";
	$method = $_GET['method'];
	if($method == "")
		$method = "show";
}
else if(isset($_GET['method']) && isset($_GET['modul']))
{
	$modul = $_GET['modul'];
	$method = $_GET['method'];
}
else if(!session_is_registered("user"))
{
	$modul = "login";
	$method = "show";
}
else
{
	$modul = $_SESSION['user']['modul'];
	$method = $_SESSION['user']['method'];
}

require "classes/class.".$modul.".php";
$object = new $modul;
call_user_method($method,$object);
?>