	<TABLE width="100%">
		<TR>
			<TD class="table_ext">
				<a href="http://trychess.sf.net">TryChess</a>
			</TD>
			<TD class="table_ext">
				
			</TD>
		</TR>
	</TABLE>
	</BODY>
</HTML>
