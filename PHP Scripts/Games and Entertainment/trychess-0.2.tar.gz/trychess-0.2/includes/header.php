<HTML xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
	<HEAD>
		<TITLE>TryChess <?php print $this->title ?></TITLE>
		<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<META author="valen16" mail="valen16@trypill.org">
		<META NAME="AUDIENCE" CONTENT="ALL">
		<META NAME="RESOURCE-TYPE" CONTENT="DOCUMENT">
		<META NAME="DISTRIBUTION" CONTENT="GLOBAL">
		<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">
		<META NAME="REVISIT-AFTER" CONTENT="1 DAYS">
		<META NAME="RATING" CONTENT="GENERAL">
		<META http-equiv="Content-Type" content="text/html; charset=utf-8">
		<META http-equiv="Content-Style-Type" content="text/css" />
		<LINK rel="stylesheet" href="styles/main.css" type="text/css" />
	</HEAD>
	<BODY class="body">
		<TABLE width="100%">
			<TR>
				<TD width="90%" class="table_title">
					<B><IMG src="images/icon.png">TryChess <?php print $this->settings->version ?></B>
				</TD>
				<TD  class="table_ext" align="right">
					<?
						if(session_is_registered("user"))
							print "<A href=\"index.php?modul=login&method=logout\">logout</A> -
							 <b>".$_SESSION['user']['nick']."</b>";
						else
							print "not logged in";
					?>
				</TD>
			</TR>
			<TR>
				<TD class="table_body" colspan="2">
					<? print $menu; ?>
				</TD>
			</TR>
		</TABLE>
