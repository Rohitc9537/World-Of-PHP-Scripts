<?php

/*
 *
 *  AMXBans, managing bans for Half-Life modifications
 *  Copyright (C) 2003, 2004  Ronald Renes / Jeroen de Rover
 *
 *	web		: http://www.xs4all.nl/~yomama/amxbans/
 *	mail	: yomama@xs4all.nl
 *	ICQ		: 104115504
 *   
 *	This file is part of AMXBans.
 *
 *  AMXBans is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  AMXBans is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with AMXBans; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

session_start();

require("$config->path_root/include/functions.inc.php");
if(isset($_COOKIE["amxbans"])) {
	$cook							= explode(":", $_COOKIE["amxbans"]);
	$uid							= $cook[0];
	$pwd							= $cook[1];
	$lvl							= $cook[2];
	$uip							= $cook[3];
	$logcode					= $cook[4];
	$bans_add					= $cook[5];
	$bans_edit				= $cook[6];
	$bans_delete			= $cook[7];
	$bans_unban				= $cook[8];
	$bans_import			= $cook[9];
	$bans_export			= $cook[10];
	$amxadmins_view		= $cook[11];
	$amxadmins_edit		= $cook[12];
	$webadmins_view		= $cook[13];
	$webadmins_edit		= $cook[14];
	$permissions_edit	= $cook[15];
	$prune_db					= $cook[16];
	$servers_edit			= $cook[17];
	$ip_view					= $cook[18];

	if (isset($_POST['uid'])) {
	 $uid = $_POST['uid'];
	}

	if (isset($_POST['pwd'])) {
	 $pwd = $_POST['pwd'];
	}

	if (isset($_POST['uip'])) {
	 $uip = $_POST['uip'];
	}

	if (isset($_POST['lvl'])) {
	 $lvl = $_POST['lvl'];
	}

	if (isset($_POST['bans_add'])) {
	 $bans_add = $_POST['bans_add'];
	}

	if (isset($_POST['bans_edit'])) {
	 $bans_edit = $_POST['bans_edit'];
	}

	if (isset($_POST['bans_delete'])) {
	 $bans_delete = $_POST['bans_delete'];
	}

	if (isset($_POST['bans_unban'])) {
	 $bans_unban = $_POST['bans_unban'];
	}

	if (isset($_POST['bans_import'])) {
	 $bans_import = $_POST['bans_import'];
	}

	if (isset($_POST['bans_export'])) {
	 $bans_export = $_POST['bans_export'];
	}

	if (isset($_POST['amxadmins_view'])) {
	 $amxadmins_view = $_POST['amxadmins_view'];
	}

	if (isset($_POST['amxadmins_edit'])) {
	 $amxadmins_edit = $_POST['amxadmins_edit'];
	}

	if (isset($_POST['webadmins_view'])) {
	 $webadmins_view = $_POST['webadmins_view'];
	}

	if (isset($_POST['webadmins_edit'])) {
	 $webadmins_edit = $_POST['webadmins_edit'];
	}

	if (isset($_POST['permissions_edit'])) {
	 $permissions_edit = $_POST['permissions_edit'];
	}

	if (isset($_POST['prune_db'])) {
	 $prune_db = $_POST['prune_db'];
	}

	if (isset($_POST['servers_edit'])) {
	 $servers_edit = $_POST['servers_edit'];
	}

	if (isset($_POST['ip_view'])) {
	 $ip_view = $_POST['ip_view'];
	}

} else {
	if (isset($_POST['uid'])) {
	 $uid = $_POST['uid'];
	} else {
	 $uid = $_SESSION['uid'];
	}

	if (isset($_POST['pwd'])) {
	 $pwd = $_POST['pwd'];
	} else {
	 $pwd = $_SESSION['pwd'];
	}

	if (isset($_POST['uip'])) {
	 $uip = $_POST['uip'];
	} else {
	 $uip = $_SESSION['uip'];
	}

	if (isset($_POST['lvl'])) {
	 $lvl = $_POST['lvl'];
	} else {
	 $lvl = $_SESSION['lvl'];
	}

	if (isset($_POST['bans_add'])) {
	 $bans_add = $_POST['bans_add'];
	} else {
	 $bans_add = $_SESSION['bans_add'];
	}

	if (isset($_POST['bans_edit'])) {
	 $bans_edit = $_POST['bans_edit'];
	} else {
	 $bans_edit = $_SESSION['bans_edit'];
	}

	if (isset($_POST['bans_delete'])) {
	 $bans_delete = $_POST['bans_delete'];
	} else {
	 $bans_delete = $_SESSION['bans_delete'];
	}

	if (isset($_POST['bans_unban'])) {
	 $bans_unban = $_POST['bans_unban'];
	} else {
	 $bans_unban = $_SESSION['bans_unban'];
	}

	if (isset($_POST['bans_import'])) {
	 $bans_import = $_POST['bans_import'];
	} else {
	 $bans_import = $_SESSION['bans_import'];
	}

	if (isset($_POST['bans_export'])) {
	 $bans_export = $_POST['bans_export'];
	} else {
	 $bans_export = $_SESSION['bans_export'];
	}

	if (isset($_POST['amxadmins_view'])) {
	 $amxadmins_view = $_POST['amxadmins_view'];
	} else {
	 $amxadmins_view = $_SESSION['amxadmins_view'];
	}

	if (isset($_POST['amxadmins_edit'])) {
	 $amxadmins_edit = $_POST['amxadmins_edit'];
	} else {
	 $amxadmins_edit = $_SESSION['amxadmins_edit'];
	}

	if (isset($_POST['webadmins_view'])) {
	 $webadmins_view = $_POST['webadmins_view'];
	} else {
	 $webadmins_view = $_SESSION['webadmins_view'];
	}

	if (isset($_POST['webadmins_edit'])) {
	 $webadmins_edit = $_POST['webadmins_edit'];
	} else {
	 $webadmins_edit = $_SESSION['webadmins_edit'];
	}

	if (isset($_POST['permissions_edit'])) {
	 $permissions_edit = $_POST['permissions_edit'];
	} else {
	 $permissions_edit = $_SESSION['permissions_edit'];
	}

	if (isset($_POST['prune_db'])) {
	 $prune_db = $_POST['prune_db'];
	} else {
	 $prune_db = $_SESSION['prune_db'];
	}

	if (isset($_POST['servers_edit'])) {
	 $servers_edit = $_POST['servers_edit'];
	} else {
	 $servers_edit = $_SESSION['servers_edit'];
	}

	if (isset($_POST['ip_view'])) {
	 $ip_view = $_POST['ip_view'];
	} else {
	 $ip_view = $_SESSION['ip_view'];
	}
}

if(!isset($uid)) {

	$urlparams = GetUrlParams();

	/////////////////////////////////////////////////////////////////
	//	Template parsing
	/////////////////////////////////////////////////////////////////

	$title			= "Login";

	$smarty = new dynamicPage;

	$smarty->assign("meta","");
	$smarty->assign("title",$title);
	$smarty->assign("dir",$config->document_root);
	$smarty->assign("this",$_SERVER['PHP_SELF']);
	$smarty->display('main_header.tpl');
	$smarty->display('login.tpl');
	$smarty->display('main_footer.tpl');

	exit;
}

$_SESSION['uid'] = $uid;
$_SESSION['pwd'] = $pwd;
$_SESSION['uip'] = $uip;

if(isset($_COOKIE["amxbans"])) {
	$sql = "SELECT * FROM $config->webadmins WHERE username = '$uid' AND password = '$pwd'";
} else {
	$sql = "SELECT * FROM $config->webadmins WHERE username = '$uid' AND password = md5('$pwd')";
}

$result		= mysql_query($sql);

if (!$result) {
	echo "A database error occurred while checking your login details.";
	exit;
}

if (mysql_num_rows($result) == 0) {
  unset($_SESSION['uid']);
  unset($_SESSION['pwd']);
  unset($_SESSION['uip']);
  unset($_SESSION['lvl']);
	unset($_SESSION['bans_add']);
	unset($_SESSION['bans_edit']);
	unset($_SESSION['bans_delete']);
	unset($_SESSION['bans_unban']);
	unset($_SESSION['bans_import']);
	unset($_SESSION['bans_export']);
	unset($_SESSION['amxadmins_view']);
	unset($_SESSION['amxadmins_edit']);
	unset($_SESSION['webadmins_view']);
	unset($_SESSION['webadmins_edit']);
	unset($_SESSION['permissions_edit']);
	unset($_SESSION['prune_db']);
	unset($_SESSION['servers_edit']);
	unset($_SESSION['ip_view']);

	echo "Your username or password is incorrect, or you are not an admin.";

	$now = date("U");
	$add_log	= mysql_query("INSERT INTO $config->logs VALUES ('', '$now', '".$_SERVER['REMOTE_ADDR']."', 'unknown', 'admin logins', '$uid failed to login')") or die (mysql_error());

	exit;
}

while ($my_admin		= mysql_fetch_array($result)) {
	$lvl							= $my_admin['level'];
	$userid						= $my_admin['user_id'];
	$bans_add					= CheckAbility("bans_add", $lvl);
	$bans_edit				= CheckAbility("bans_edit", $lvl);
	$bans_delete			= CheckAbility("bans_delete", $lvl);
	$bans_unban				= CheckAbility("bans_unban", $lvl);
	$bans_import			= CheckAbility("bans_import", $lvl);
	$bans_export			= CheckAbility("bans_export", $lvl);
	$amxadmins_view		= CheckAbility("amxadmins_view", $lvl);
	$amxadmins_edit		= CheckAbility("amxadmins_edit", $lvl);
	$webadmins_view		= CheckAbility("webadmins_view", $lvl);
	$webadmins_edit		= CheckAbility("webadmins_edit", $lvl);
	$permissions_edit	= CheckAbility("permissions_edit", $lvl);
	$prune_db					= CheckAbility("prune_db", $lvl);
	$servers_edit			= CheckAbility("servers_edit", $lvl);
	$ip_view					= CheckAbility("ip_view", $lvl);

	if($_POST['remember'] == "on") {
		$logcode			= md5(GenerateString(8));
		$res					= mysql_query("UPDATE $config->webadmins SET logcode = '$logcode' WHERE username = '$uid'");
		$pwdhash			= md5($pwd);
		$cookiestring = $uid.":".$pwdhash.":".$lvl.":".$uip.":".$logcode.":".$bans_add.":".$bans_edit.":".$bans_delete.":".$bans_unban.":".$bans_import.":".$bans_export.":".$amxadmins_view.":".$amxadmins_edit.":".$webadmins_view.":".$webadmins_edit.":".$permissions_edit.":".$prune_db.":".$servers_edit.":".$ip_view;

		setcookie("amxbans", $cookiestring, time()+60*60*24*7, "$config->document_root/", $_SERVER['SERVER_NAME']);
	}
}

$_SESSION['lvl'] = $lvl;
$_SESSION['userid'] = $userid;
$_SESSION['bans_add'] = $bans_add;
$_SESSION['bans_edit'] = $bans_edit;
$_SESSION['bans_delete'] = $bans_delete;
$_SESSION['bans_unban'] = $bans_unban;
$_SESSION['bans_import'] = $bans_import;
$_SESSION['bans_export'] = $bans_export;
$_SESSION['amxadmins_view'] = $amxadmins_view;
$_SESSION['amxadmins_edit'] = $amxadmins_edit;
$_SESSION['webadmins_view'] = $webadmins_view;
$_SESSION['webadmins_edit'] = $webadmins_edit;
$_SESSION['permissions_edit'] = $permissions_edit;
$_SESSION['prune_db'] = $prune_db;
$_SESSION['servers_edit'] = $servers_edit;
$_SESSION['ip_view'] = $ip_view;

?>
