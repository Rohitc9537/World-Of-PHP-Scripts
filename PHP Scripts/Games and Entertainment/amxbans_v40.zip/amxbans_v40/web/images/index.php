<?php header( "Location:../ban_list.php" ); ?>
