This is how challenging other player work. If you win, you gain 1/10 of the other playerr's skillpoints(so it makes no sense
to challenge someone with less than 10 skillpoints) and the other player dies and loses 1/3 of his skill pts and has to revive.
However, if you lose, he gains 1/10 of your skill points and you die and lose 1/3 of your skill pts.