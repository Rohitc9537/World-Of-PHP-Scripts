<html>
<form method="POST" action="authenticate.php">
Type Username Here: <input type="text" name="isadmin" size="15"><br>
Type Password Here: <input type="password" name="password" size="15" mask="x"><br>
<input type="submit" value="submit" name="submit">



</form>
</html>
