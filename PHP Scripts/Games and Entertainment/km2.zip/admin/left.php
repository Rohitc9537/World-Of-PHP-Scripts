<table border='2' width='100%' bordercolor='red'>
<tr>
<td bgcolor='red'><font color='white'><b>Admin Options</b></font></td></tr>
<tr><td bgcolor='white'>
<A href='addmonster.php'>Add Monster</a><br>
<A href='deletemonster.php'>Delete Monster</a><br>
<A href='manageuser.php'>User Management</a><br>
<A href='reset.php'>Reset Game</a><br>
</td></tr></table>
