<link rel="stylesheet" href="style.css" type="text/css">
<center>
<table class='maintable'>
<tr class='headline'><td><center><font color='white'>Register admin name</font></center></td></tr>
<tr class='mainrow'><td><center>
<table><form action='reguser.php' method='post'>
<tr class='mainrow'><td>Username:</td><td><input type='text' name='username' size='20'></td></tr>
<tr class='mainrow'><td>Password:</td><td><input type='password' name='password' size='20'></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='submit'></form></td></tr>
</form>
</table>
</center>
</td></tr></table>