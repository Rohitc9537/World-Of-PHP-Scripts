<?php
	// The dice style, choose from 1,2 or 3 (browse through styles directory to preview)
	$dice_style = 3;
	
	// The number of dice to use
	$dice_num = 5;
	
	// The absolute URL of your site, for instance, "www.mywebsite.com"
	$dice_absolute_url = 'www.mysite.com';
?>