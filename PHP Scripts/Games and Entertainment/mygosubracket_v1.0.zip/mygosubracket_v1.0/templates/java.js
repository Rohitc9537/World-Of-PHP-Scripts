function echo(string) {
  document.write(string);
}
function openwindow(url,width,height){
 window.open(url, '', 'scrollbars,height='+height+',width='+width+'');
}