<?php
unset($b);
$b[] = "rd|nd|bd|qd|kd|bd|nd|rd";
$b[] = "pd|pd|pd|pd|pd|pd|pd|pd";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "pl|pl|pl|pl|pl|pl|pl|pl";
$b[] = "rl|nl|bl|ql|kl|bl|nl|rl";
?>
