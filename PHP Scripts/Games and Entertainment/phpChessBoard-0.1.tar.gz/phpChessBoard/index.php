<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
  <head>
    <meta name="generator" content="HTML Tidy for Linux/x86 (vers 1st April 2002), see www.w3.org">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="author" content="Andreas Stieger">
    <meta name="description" content="phpChessBoard - display a chess board in PHP ">
    <meta name="keywords" content="phpChessBoard, chess board, chess diagram, Schachbrett, Schachdiagramm, PHP">
    
    <title>phpChessBoard - display a chess board in PHP</title>
  </head>

  <body>

<?php include("phpChessBoard.php"); ?>

  <h1>phpChessBoard - display a chess board in PHP</h1>

  <h2>turn this...</h2>
  
<?php highlight_file("example.php"); ?>

  <h2>into this...</h2>
  
<?php include("example.php"); 
       chess_board($b); 
?>

  <h2>with this...</h2>
  
<?php highlight_file("phpChessBoard.php"); ?>

  <h2>download</h2>
    
  <p><a href="phpChessBoard-0.1.tar.gz">phpChessBoard-0.1.tar.gz</a></p>

  </body>
</html>

