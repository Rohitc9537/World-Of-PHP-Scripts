<?php

/*

phpChessBoard display a chess board in PHP 
Copyright (C) 2005 Andreas Stieger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


Versions: 

0.1 initial release

The images Chess_[prnqk][dl][dl]44.png are GPL, from Wikimedia Commons, see gpl.txt
The other images Chess_*44.png are GFDL, from Wikimedia Commons, see fdl.txt


usage:

1. include this file
2. create an array of stings, example see below
   r: rook, n: knight, b: bishop, k: king, q: queen
   l: light, d: dark
3. call chess_board($array) or chess_board_flip($array, true|false)
   Obviously, the board will be flipped if called with true.

Example showing the basic setup. Note that a1 is in the lower left corner.

unset($b);
$b[] = "rd|nd|bd|qd|kd|bd|nd|rd";
$b[] = "pd|pd|pd|pd|pd|pd|pd|pd";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "  |  |  |  |  |  |  |  ";
$b[] = "pl|pl|pl|pl|pl|pl|pl|pl";
$b[] = "rl|nl|bl|ql|kl|bl|nl|rl";

===========================================================================

*/

DEFINE("IMAGE_PREFIX","Chess_img/Chess_");
DEFINE("IMAGE_SUFFIX","44.png");

function chess_hline($flip) { 

?>
<tr align="center" height="20">
  <td></td>
    <?php for ($col=0;$col<=7;$col++) { ?>
      <td><?= chr( $flip?(ord('h')-$col):(ord('a')+$col)) ?></td>
    <?php } ?>
  <td></td>
</tr>
<?php 
}

function chess_board($b) { chess_board_flip($b, false); }

function chess_board_flip($b, $flip) { 

?>

<table style="border: 1px solid black; background-color: grey;" cellpadding="0" cellspacing="0">

<tbody>

<?php chess_hline($flip); ?>

<?php for ($row=1;$row<=8;$row++) { ?>
  <tr align="center">
    <td width="20"><?= $flip?($row):(9-$row) ?></td>
    <?php for ($col=1;$col<=8;$col++) { 
        $piece = trim( substr($b[$flip?(8-$row):($row-1)], ($flip?(8-$col):($col-1))*3, 2) );
        $color = ((($row + $col) % 2) == 0 )?'l':'d';
        $file = IMAGE_PREFIX.$piece.$color.IMAGE_SUFFIX;
    ?>
            <td><img src="<?= $file?>" height="44" width="44" /></td>
     <?php } ?> 
   <td width="20"><?= $flip?($row):(9-$row) ?></td>
  </tr>  
<?php } ?>

<?php chess_hline($flip); ?>

</tbody>
</table>

<?php
}



?>



