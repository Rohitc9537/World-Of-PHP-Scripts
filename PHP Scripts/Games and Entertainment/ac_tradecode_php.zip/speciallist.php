<?php

$speciallist[0x0900] = "Does not yet work";
$speciallist[0x1dc4] = "NES Contest only";
$speciallist[0x1dc8] = "NES Contest only";
$speciallist[0x1dcc] = "NES Contest only";
$speciallist[0x1dd0] = "NES Contest only";
$speciallist[0x1de4] = "Does not yet work";
$speciallist[0x1de8] = "Does not yet work";
$speciallist[0x1dec] = "Does not yet work";
$speciallist[0x1df0] = "Does not yet work";
$speciallist[0x2E01] = "K.K. Love Song and two NES games";
?>