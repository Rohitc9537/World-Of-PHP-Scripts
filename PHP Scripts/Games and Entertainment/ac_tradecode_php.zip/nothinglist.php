<?php

$itemlist[0x250B] = "Nothing";
$itemlist[0x2225] = "Nothing";

?>