<?php
/////////////
// Unknown //
/////////////
$itemlist[0x2104] = "Unknown";
$itemlist[0x252E] = "Unknown";
$itemlist[0x2F04] = "Unknown";
$itemlist[0x2F06] = "Unknown";

//////////////////
// Effect Codes //
//////////////////
$itemlist[0xFFFF] = "Lockup Item";

?>