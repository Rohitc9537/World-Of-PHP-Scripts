/* This file is part of Follow Me - Automatic Dynamic Menus
 *
 *  
 *
 * Copyright (C) 2004, Patrice Grometto [Le Grom]  optipalm@free.fr http://optipalm.free.fr/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * See installing.txt for installation details
 */