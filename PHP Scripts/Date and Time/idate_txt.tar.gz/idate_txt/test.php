<HTML><HEAD><TITLE>International Sample Date</TITLE></HEAD>
<BODY BGCOLOR="white">

<BR><BR><P ALIGN="Center"><FONT FACE="Arial, helvetica" SIZE="+2" COLOR="#336699"><STRONG><EM>Sample / Examples</EM></STRONG></FONT></P><BR>

<?php require "idate_txt.php"; ?>

<B>
Date En: <?php echo date_international(""); ?>
<BR><BR>
Date Fr: <?php echo date_international("", "Fr"); ?>
<BR><BR>
Date De: <?php echo date_international("", "De", ""); ?>
<BR><BR>
Date Es: <?php echo date_international("", "Es", ""); ?>
<BR><BR>
Date Se: <?php echo date_international("", "Se", ""); ?>
<BR><BR>
</B>


<CENTER><BR><BR>
	<FONT FACE="Arial" SIZE=-2>
	<EM>&copy Copyright 2000 <A HREF="http://www.ftls.org/ftls.shtml">FTLS</A> (Tyndiuk Fr&eacute;d&eacute;ric). All rights reserved.
	<BR>FTLS's PHP Scripts Archive : <A HREF="http://www.ftls.org/php/">http://www.ftls.org/php/</A></EM></FONT>
</CENTER></BODY></HTML>