<?php
// En: Begin PHP code  / Fr: debut code PHP
/******************************************************************************\
* International Date                           Version 1.0                     *
* Copyright 2000 Frederic TYNDIUK (FTLS)       All Rights Reserved.            *
* E-Mail: tyndiuk@ftls.org                     Script License: GPL             *
* Created  02/28/2000                          Last Modified 02/28/2000        *
* Scripts Archive at:                          http://www.ftls.org/php/        *
*******************************************************************************/
// use : string date_international (string $date_format, string [language],  int [timestamp]);
/*******************************************************************************/

function date_international ($date_format, $lang = "En", $time=0) {

	// use : string date_international (string $date_format, string [language],  int [timestamp]);
	// En: $date_format: chose format with same PHP date args.
	// En: $lang: "En", "Fr", "De", "Es", "Se"
		//	d - day of the month, numeric, 2 digits (with leading zeros)
		//	D - day of the week, textual, 3 letters; i.e. "Fri"
		//	F - month, textual, long; i.e. "January"
		//	h - hour, numeric, 12 hour format
		//	H - hour, numeric, 24 hour format
		//	i - minutes, numeric
		//	j - day of the month, numeric, without leading zeros
		//	l (lowercase 'L') - day of the week, textual, long; i.e. "Friday"
		//	m - month, numeric
		//	M - month, textual, 3 letters; i.e. "Jan"
		//	s - seconds, numeric
		//	U - seconds since the epoch
		//	Y - year, numeric, 4 digits
		//	w - day of the week, numeric, 0 represents Sunday
		//	y - year, numeric, 2 digits

	// Fr: $date_format: choisissez le format avec les meme arguments que date PHP.
	// Fr: $lang: "En", "Fr", "De", "Es", "Se"
		//	d - Jour du mois, sur deux chiffres (�ventuellement avec un z�ros) : "01" � "31" 
		//	D - Jour de la semaine, en trois lettres (et en anglais) : par exemple "Fri" (pour Vendredi) 
		//	F - Mois, textuel, version longue; en anglais, i.e. "January" (pour Janvier) 
		//	h - Heure, au format 12h, "01" � "12" 
		//	H - heure, au format 24h,. "00" � "23" 
		//	g - Heure, au format 12h sans les z�ros initiaux, "1" � "12" 
		//	G - Heure, au format 24h sans les z�ros initiaux,. "0" � "23" 
		//	i - Minutes; "00" � "59" 
		//	j - Jour du mois sans les z�ros initiaux: "1" � "31" 
		//	l ('L' minuscule) - Jour de la semaine, textuel, version longue; en anglais, i.e. "Friday" (pour Vendredi) 
		//	m - Mois; i.e. "01" � "12" 
		//	n - Mois sans les z�ros initiaux; i.e. "1" � "12" 
		//	M - Mois, en trois lettres (et en anglais) : par exemple "Jan" (pour Janvier) 
		//	s - Secondes; i.e. "00" � "59" 
		//	t - Nombre de jour dans le mois donn�e, i.e. "28" � "31" 
		//	U - Secondes depuis une �poque 
		//	w - Jour de la semaine, num�rique, i.e. "0" (Dimanche) to "6" (Samedi) 
		//	Y - Ann�e, 4 chiffres; i.e. "1999" 
		//	y - Ann�e, 2 chiffres; i.e. "99" 

	if ($lang == "Fr") {
		$week_days_long = array('Sunday' => 'Dimanche', 'Monday' => 'Lundi', 'Tuesday' => 'Mardi',
			'Wednesday' => 'Mercredi', 'Thursday' => 'Jeudi', 'Friday' => 'Vendredi',
			'Saturday' => 'Samedi');
		$months_long = array('January' => 'Janvier', 'February' => 'F&eacute;vrier',
			'March' => 'Mars', 'April' => 'Avril','May' => 'Mai', 'June' => 'Juin',
			'July' => 'Juillet', 'August' => 'Ao&ucirc;t', 'September' => 'Septembre',
			'October' => 'Octobre', 'November' => 'Novembre', 'December' => 'D&eacute;cembre');
		$week_days_short = array('Sun' => 'Dim', 'Mon' => 'Lun', 'Tue' => 'Mar', 'Wed'=>'Mer',
			'Thu' => 'Jeu', 'Fri' => 'Ven', 'Sat' => 'Sam');
		$months_short = array('Jan' => 'Jan', 'Feb' => 'F&eacute;v', 'Mar' => 'Mar', 'Apr' => 'Avr',
			'May' => 'Mai', 'Jun' => 'Juin', 'Jul' => 'Jui', 'Aug' => 'Ao&ucirc;',
			'Sep' => 'Sep', 'Oct' => 'Oct', 'Nov' => 'Nov', 'Dec' => 'D&eacute;c');
	} elseif ($lang == "Se") {
		$week_days_long = array('Sunday' => 'S&ouml;ndag', 'Monday' => 'M&aring;ndag', 'Tuesday' => 'Tisdag',
			'Wednesday' => 'Onsdag', 'Thursday' => 'Torsdag', 'Friday' => 'Fredag',
			'Saturday' => 'S&ouml;ndag');
		$months_long = array('January' => 'Januari', 'February' => 'Februari',
			'March' => 'Mars', 'April' => 'April','May' => 'Maj', 'June' => 'Juni',
			'July' => 'Juli', 'August' => 'Augusti', 'September' => 'September',
			'October' => 'Oktober', 'November' => 'November', 'December' => 'December');
		$week_days_short = array('Sun' => 'S&ouml;n', 'Mon' => 'M&aring;n', 'Tue' => 'Tis', 'Wed'=>'Ons',
			'Thu' => 'Tor', 'Fri' => 'Fre', 'Sat' => 'S&ouml;n');
		$months_short = array('Jan' => 'Jan', 'Feb' => 'Feb', 'Mar' => 'Mar', 'Apr' => 'Apr',
			'May' => 'Maj', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Aug',
			'Sep' => 'Sep', 'Oct' => 'Oct', 'Nov' => 'Nov', 'Dec' => 'Dec');
	} elseif ($lang == "De") {
		$week_days_long = array('Sunday' => 'Sonntag', 'Monday' => 'Montag', 'Tuesday' => 'Dienstag',
			'Wednesday' => 'Mittwoch', 'Thursday' => 'Donnerstag', 'Friday' => 'Freitag',
			'Saturday' => 'Samstag');
		$months_long = array('January' => 'Januar', 'February' => 'Februar',
			'March' => 'M&auml;rz', 'April' => 'Avril', 'May' => 'Mai', 'June' => 'Juni',
			'July' => 'Juli', 'August' => 'August', 'September' => 'September',
			'October' => 'Oktober', 'November' => 'November', 'December' => 'Dezember');
		$week_days_short = array('Sun' => 'Son', 'Mon' => 'Mon', 'Tue' => 'Die', 'Wed'=>'Mit',
			'Thu' => 'Don', 'Fri' => 'Fre', 'Sat' => 'Sam');
		$months_short = array('Jan' => 'Jan', 'Feb' => 'Feb', 'Mar' => 'M&auml;r', 'Apr' => 'Apr',
			'May' => 'Mai', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Aug;',
			'Sep' => 'Sep', 'Oct' => 'Okt', 'Nov' => 'Nov', 'Dec' => 'Dez');
	} elseif ($lang == "Es") {
		$week_days_long = array('Sunday' => 'Domingo', 'Monday' => 'Lunes', 'Tuesday' => 'Martes',
			'Wednesday' => 'Miercoles', 'Thursday' => 'Jueves', 'Friday' => 'Viernes',
			'Saturday' => 'Sabado');
		$months_long = array('January' => 'Enero', 'February' => 'Febrero',
			'March' => 'Marso', 'April' => 'Abril','May' => 'Mayo', 'June' => 'Junio',
			'July' => 'Jullo', 'August' => 'Agosto', 'September' => 'Septiembre',
			'October' => 'Octubre', 'November' => 'Noviembre', 'December' => 'Diciembre');
		$week_days_short = array('Sun' => 'Dom', 'Mon' => 'Lun', 'Tue' => 'Mar', 'Wed'=>'Mie',
			'Thu' => 'Jeu', 'Fri' => 'Vie', 'Sat' => 'Sab');
		$months_short = array('Jan' => 'Ene', 'Feb' => 'Feb', 'Mar' => 'Mar', 'Apr' => 'Abr',
			'May' => 'Mai', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Ago;',
			'Sep' => 'Sep', 'Oct' => 'Oct', 'Nov' => 'Nov', 'Dec' => 'Dec');
	}

	if (! $time) $time = time();
	if (! $lang) $lang = "En";
	if (! $date_format) { if ($lang == "En") $date_format = "F, l j Y - H:i:s"; else $date_format = "l j F Y - H:i:s"; }

	$clock = date($date_format, $time);

	if(preg_match("/F/", $date_format) && ($lang != "En")) {
		$model = date("F", $time);
		$replace = $months_long[date("F", $time)];
		$clock = preg_replace("/$model/", $replace, $clock);
	}

	if(preg_match("/l/", $date_format) && ($lang != "En")) {
		$model = date("l", $time);
		$replace = $week_days_long[date("l", $time)];
		$clock = preg_replace("/$model/", $replace, $clock);
	}

	if(preg_match("/M/", $date_format) && ($lang != "En")) {
		$model = date("M", $time);
		$replace = $months_short[date("M", $time)];
		$clock = preg_replace("/$model/", $replace, $clock);
	}

	if(preg_match("/D/", $date_format) && ($lang != "En")) {
		$model = date("D", $time);
		$replace = $week_days_short[date("D", $time)];
		$clock = preg_replace("/$model/", $replace, $clock);
	}

	return $clock;
// End PHP code.
}
?>
