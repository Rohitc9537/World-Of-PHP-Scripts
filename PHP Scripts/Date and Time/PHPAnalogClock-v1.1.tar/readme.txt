**********************************
* The PHP Analog Clock           *
* http://analogclock.caiphp.com/ *
* cai@caiphp.com                 *
**********************************
*   Description                  *
*******************************************************************************
*     The PHP Analog Clock is the most versatile PHP clock available on the   *
* internet.  You can change the way the entire clock looks, from its face to  *
* its hands.                                                                  *
*******************************************************************************
*   How-to                       *                                            *
*******************************************************************************
*     Using the script is rather easy.  The file clock.php does all the dirty *
* work for you, and must be included in every skin file.  A skin file is just *
* another PHP script, but it tells the clock what to draw.                    *
*     There are several example files packaged with the script, inside the    *
* examples/ folder.  Each of these files will draw a clock (if you visit them *
* directly in your browser, you should see the image).  You can use these in  *
* HTML by using the <img /> tag: <img src="myclock.php" alt="My Clock" />     *
*     This assumes that myclock.php is in the same directory as the current   *
* HTML file.  Inside myclock.php, the require_once line at the top should be  *
* able to locate the clock.php script, which you could have in the same       *
* directory.                                                                  *
*     For information on creating your own skins, check out the manual:       *
* http://analogclock.caiphp.com/manual.php                                    *
*******************************************************************************
*   Requirements                 *                                            *
*******************************************************************************
* - GD version 2.0 or higher (PHP-bundled version recommended)                *
* - PHP 4.3 or higher                                                         *
*******************************************************************************
*   History                      *                                            *
*******************************************************************************
* v1.1  - 02-Oct-05 - Cleaned up how the clock works (it's much better now!)  *
*                   - New types of hands (lines, triangles, diamonds)         *
*                   - Basic bullets                                           *
*                   - Correctly calculates clock center on non-square clocks  *
*                   - Anti-aliasing is now optional                           *
* v1.0  - 01-Aug-04 - Complete redo                                           *
*                   - Object-oriented application                             *
*                   - Hand thickness                                          *
*                   - Label support                                           *
*                   - Much more...                                            *
**********************************                                            *
*   Older versions               *                                            *
**********************************                                            *
* v0.3  - 22-Oct-03 - Timezone support added (+ or - GMT)                     *
*                   - Line thickness (looks horrible, however)                *
* v0.2  - 21-Oct-03 - Made hands graphical                                    *
* v0.1  - 20-Oct-03 - First released version                                  *
*******************************************************************************
*   Bug report                   *                                            *
*******************************************************************************
*   I have done my best to keep this software bug free, but a few may have    *
* made it into the release.  If you happen to find one, please describe, in   *
* detail, what you did to get the bug, how repeatable it is, and provide the  *
* errors, if any are given, and email them to cai@caiphp.com.  I will attempt *
* to fix them, and give credit you in this header.  Happy bug hunting!        *
*******************************************************************************
*   Donations                    *                                            *
*******************************************************************************
*   I am providing this software free of charge, for any use, as long as you  *
* give credit where credit is due.  If you like this software, and are kind   *
* enough to support it, please donate whatever you can afford.  There is a    *
* PayPal donate button on the links section of http://www.caiphp.com/, or you *
* can donate straight to cai@caiphp.com through PayPal.  Thanks!              *
*******************************************************************************
