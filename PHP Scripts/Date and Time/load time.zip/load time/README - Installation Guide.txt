			       Gilly � 2005 - webmaster@gilly.org.uk
============================ Gilly's Portfolio http://www.gilly.org.uk ============================

Gilly's Page Load Time - v1.0

***********************************************************************************
*
* Please, if you use this script consider donating to help keep Gilly's Portfolio
* alive by visiting our website and clicking Donate (if you havent already)
*																
***********************************************************************************


Files Just Downloaded
~~~~~~~~~~~~~

The contents of "load time.zip" ........

1.	page load.php
2.	Readme.txt
3.	Just incase you forgot where it came from.... an Internet Shortcut


Installation Help
~~~~~~~~~~

1.  	Place the top snippet of code at the top of your PHP page.
	
2.	Now place the bottom snippet at the end of your page.
	
3.  	You can chagne the last line of code to say anything you like, just leave the %f

5.	Finished!

Thats All!
~~~~~~

Thank you for downloading this script, I hope you like it - feedback would be appreciated.

If you need any help with this script, use the contact form here http://www.gilly.org.uk/index.php?act=contact

If you find any bugs or errors in this README or the script please let me know http://www.gilly.org.uk/index.php?act=bug

Gilly- Web Developer

==========================================================================