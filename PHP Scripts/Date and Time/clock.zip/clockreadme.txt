*****************************************
*NanoOnline - Online Graphical PHP Clock*
*****************************************
*     Script Written by Robert Wood     *                         
*     mailto: info@nanohost.com         *
*      visit: http://www.nanohost.com   *
*      F R E E W A R E                  *
*                                       *
*                                       *
*                                       *
*                                       *
*                                       *
*****************************************


The only thing that you must do to run this script properly, is take all the image files and place them in a directory called "clock". That way, when the images in the script are called, they will be loaded without any problems. The images must be located in:  clock/

Upload clock.php3 along with the image directory to your webserver, and you will have a simple graphical clock!


Any Questions or comments can be sent to
info@nanohost.com


Thanks,
Robert Wood
http://www.nanohost.com