<form action="addurl.php" method=post>

	<input type=text name=url value="http://" size=20>
	<INPUT type=submit value=add url>

</FORM>

