<BR><BR>{placeholder for footer html here}</center>
<BR>
<Div align=center><A HREF="http://free-php.net">powered by free-php <? echo $scriptname; ?></A></DIV>
<BR>
</center>
</BODY>
</HTML>