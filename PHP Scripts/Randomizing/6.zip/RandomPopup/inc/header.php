<HTML>
<HEAD>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title><? echo $scriptname; ?></title>
	<META name="description" content="">
	<META name="keywords" content="">
	<META name="revisit-after" content="7days">
	<META name="robots" content="index, follow">

</HEAD>
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 rightmargin=0>
<center>
<br>{placeholder for header html here}<br>
<br>
 To view an example popup open <a href="example.php">example.php</a><br>
 To add urls open <a href="addurl.php">addurl.php</a><br>
 To delete urls open <a href="deleteurl.php">deleteurl.php</a><br><br>

 You can include this in any page of your site at the very top or at the top of<br>your header file using a php include statement like so :: <b>include('/path/to/popup.php');</b>
 <br><br>