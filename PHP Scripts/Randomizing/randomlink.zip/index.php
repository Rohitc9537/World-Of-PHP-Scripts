<title>Chipmunk PHP Scripts --Random Link script Example</title>



<center>

<?
include "../headad.php";
?>
</center>
<center>
<table border='0' width='800' cellspacing='20'>
<tr><td valign='top' width='150'>
<?
include '../left.php';
?>
</td>
<td valign='top' width='460'>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#6B84AE" width="460" id="AutoNumber1" height="198">
  <tr>
    <td width="460" background="../../topbackground.jpg" height="20" valign="top">
   <font color="blue"><center><b>Chipmunk Randomlinks example<b></center></font></td>
  </tr>
  <tr>
    <td width="460" height="177" bgcolor="#F2F2F2" valign="top">
<center>
<?php
include "link.php";
?>
</center>

</td>
  </tr>
</table>
</td>
<td valign='top' width='150'>
<?
include '../right.php';
?>
</td></tr></table>
<br><br>
<center>
<?
include '../footer.php';
?>
</center>