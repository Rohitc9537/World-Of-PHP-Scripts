<table border='2' width='100%' bordercolor='red'>
<tr>
<td bgcolor='red'><font color='white'><b>Admin Options</b></font></td></tr>
<tr><td bgcolor='white'>
<A href='addlink.php'>Add link</a><br>
<A href='validate.php'>Validate Links</a><br>
<A href='deletelink.php'>Delete link</a><br>
<A href='search.php'>Search links</a><br>
<A href='prunestats.php'>Prune stats</a><br>
</td></tr></table>
