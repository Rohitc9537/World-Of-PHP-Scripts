<?PHP
$submitlink='Yes'; //let user submit links, Yes or No
$numlinks=5; //how many links do you want it to show
$titlecolor='#808080'; //title color of the title random five links text
$barcolor='#246FF8'; //title of site title and rank bar
$rows='#C0C0C0'; //link table row color
?>
