<html>
<form method="POST" action="authenticate.php">
Type Username Here: <input type="text" name="linkadmin" size="15"><br>
Type Password Here: <input type="password" name="password" size="15"><br>
<input type="submit" value="submit" name="submit">



</form>
</html>
