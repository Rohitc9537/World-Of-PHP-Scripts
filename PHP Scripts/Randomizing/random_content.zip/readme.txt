========================================================================
------------------------------------------------------------------------
                            Random Content v1.0
                  http://www.triumphantmedia.com/resources

			     CREATED UNDER THE
                        GNU GENERAL PUBLIC LICENSE
------------------------------------------------------------------------
========================================================================


                            SCRIPT DESCRIPTION
                            ******************

Random Content v1.0 is a tiny PHP script that will display random
content (quotes, trivia, proverbs, fortunes, etc.) from a text file.



                           SCRIPT INSTRUCTIONS
                           *******************

Replace the sample text in random_content.txt with your desired content.
This is the only necessary modification.

To insert the random content into a page, use the following code:

                   <? include("random_content.php"); ?>

In order for this script to function, your page's name must end with
.php and both random_content.php and random_content.txt must be
located in the same directory.



                           CONTENT STYLIZATION
                           *******************

Content can be styled using CSS, however each specific item of content
must remain on the same line, without breaks.

If you wish to include line breaks, use the <br /> tag.  For example:

If this is the layout of your desired content:

What
you
see
is
not
what
you
get.

You must code the text in random_content.txt file like this (without
pressing return):

What<br />you<br />see<br />is<br />not<br />what<br />you<br />get.



                                FINAL NOTES
                                ***********

If you implement this script on your site, send an email to
info@triumphantmedia.com to let us know!  We'll check out your site 
and possibly hook you up with a link.

Peace.