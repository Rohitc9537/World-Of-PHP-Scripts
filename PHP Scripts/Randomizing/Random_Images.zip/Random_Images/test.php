<?php?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd"><html><head>
<title>The test page for a random jpg script</title><link rel="stylesheet" type="text/css" href="style.css">
</head><body><div>
<?php 
echo "The pictures loaded from your db";
include ('Ran_Img.php');
include('form.php');
</div></body></html>