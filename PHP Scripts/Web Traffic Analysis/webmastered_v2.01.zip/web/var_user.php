<?PHP
$company = "Your Company";
$pw = "test";
$emailto = "";
$adminemail = "";
$signature = "Kind Regards
Fred Bloggs
http://www.yoursite.com

";
$back = "";
$logo = "mock_logo.gif";
$background = "white";
$font = "verdana";
$size = "10";
$color = "black";
$link = "blue";
$visit = "blue";
$hover = "red";
$active = "red";
$decoration = "none";
$fieldcolor = "ivory";
$fieldtextcolor = "navy";
$align = "CENTER";
$url = "www.yoursite.com";
$zone = "+15";
$zone2 = ($zone - 24);
$zone3 = ($zone - 48);
$zone4 = ($zone - 72);
$zone5 = ($zone - 96);
$zone6 = ($zone - 120);
$zone7 = ($zone - 144);
$zone8 = ($zone - 168);
?>