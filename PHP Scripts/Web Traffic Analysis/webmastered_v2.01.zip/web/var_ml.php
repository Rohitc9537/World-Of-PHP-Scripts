<?PHP
$subscribemail = "Thank You and Welcome to my Mailing List. You will be kept up to date with news regarding this business.
If you have enjoyed my website, it would be great if you could tell a friend!";
$message = "";
?>