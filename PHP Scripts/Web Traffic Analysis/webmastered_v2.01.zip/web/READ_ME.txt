Webmastered v1.04
-----------------

1. Extract all files. (will automatically be extracted to a folder
named "web")

2. Upload "web" folder to your main directory.

3. CHMOD all .php & .txt files to "read, write & execute".

4. Point your browser to http://(your root url)/web/admin.htm

5. Go to "Account Admin" and enter with the password "test"
(without the inverted commas)

6. Enter all your details.

7. Go to "Copy & Paste Codes" and follow instructions.

8. You must "date initiate" the pages within the Website Statistics,
click the "Clear Stats - Initiate Date" link on each page. (top right)


NOTE: This software is free to to use & distribute as long as the sponsored
links are kept as is.
There are no sponsored links on any of the emails or auto responders.

This software was designed with thought to help promote Rob Tognoni's music
to as many people who will listen. Rob is one of the hardest working blues/rock
guitarists around today, and it is very much appreciated that you take
the time to just listen! :-)

http://www.robtognoni.com


-----------------------





