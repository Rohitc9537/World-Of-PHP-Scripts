<?PHP
$gtext_2 = "Thank you for taking the time to sign our guestbook!

I'd like to take this opportunity to tell you about our new product...blah...blah

Thank you
Fred Bloggs";
$ttext = "Thank you for taking the time to send your private message!

I'd like to take this opportunity to tell you about our new product...blah...blah";
$posts = "15";

?>