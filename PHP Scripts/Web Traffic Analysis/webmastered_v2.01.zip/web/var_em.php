<?PHP
$rtext= "Thank you for taking the time to send your feedback! We will respond to you asap.

I'd like to take this opportunity to tell you about our new product...blah...blah";

?>