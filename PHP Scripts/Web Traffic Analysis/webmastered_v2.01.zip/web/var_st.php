<?PHP
$zone = "+15";
$zone2 = ($zone - 24);
$zone3 = ($zone - 48);
$zone4 = ($zone - 72);
$zone5 = ($zone - 96);
$zone6 = ($zone - 120);
$zone7 = ($zone - 144);
$zone8 = ($zone - 168);

?>