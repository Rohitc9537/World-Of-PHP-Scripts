<?php
// $my_host	= Mysql host address
$my_host = "localhost";
// $my_user = Mysql username
$my_user = "root";
// $my_pass = Mysql password
$my_pass = "root";
// $my_db = Mysql database name
$my_db = "hitinfo";

// $username = Username for administration login
// $password = Password for administration login
$username = "Admin";
$password = "qwerty";
?>