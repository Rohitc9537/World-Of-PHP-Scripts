<?php

/*------------------------------------------------------------------------------
Add the names of the domains you want to track below this block.
Example:

$alias[]='actualscripts.net';
$alias[]='actualscripts.org';

ActualAnalyzer will now store the statistics for actualscripts.net and
actualscripts.org also.

Add the names of the domains you want to track under this line!
------------------------------------------------------------------------------*/






?>