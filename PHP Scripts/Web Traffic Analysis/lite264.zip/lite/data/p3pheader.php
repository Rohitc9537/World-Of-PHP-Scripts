<?php

/*----------------------------------------------------------------------------*/
// Headers for Platform for Privacy Preferences (P3P)
// See more about P3P project at http://www.w3.org/P3P/
/*----------------------------------------------------------------------------*/

Header('p3p: policyref="/w3c/p3p.xml", CP="NOI CURa ADMa DEVa TAIa OUR BUS IND UNI COM NAV INT"');

?>