<?php
$begin=<<<BEGIN
<DIV class=bor750><table width=750 border=0 cellspacing=0 cellpadding=0 align=center><tr height=20>
<td colspan=5 background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td>
</tr><tr>

BEGIN;

$center=<<<CENTER
<tr height=50 align=center valign=bottom><td width="20%">%%I1%%</td><td width="20%">%%I2%%</td><td width="20%">%%I3%%</td><td width="20%">%%I4%%</td><td width="20%">%%I5%%</td></tr>
<tr height=30 align=center><td>%%1%%</td><td>%%2%%</td><td>%%3%%</td><td>%%4%%</td><td>%%5%%</td></tr>

CENTER;

$end=<<<END
</tr><tr height=20><td colspan=5 background="%%RF%%style/%%STYLE%%/image/bg2.gif" align=right><SPAN class=f10>&nbsp;</SPAN></td></tr></table></DIV><br>

END;
?>