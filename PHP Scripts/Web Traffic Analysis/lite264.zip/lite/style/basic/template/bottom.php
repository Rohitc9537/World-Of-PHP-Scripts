<?php
$bottom=<<<BOTTOM
<table width=750 border=0 cellspacing=0 cellpadding=0><tr valign=center><td colspan=2 bgcolor="#cccccc"><img src="%%RF%%style/%%STYLE%%/image/0.gif" width="1" height="1"></td></tr>
<tr><td colspan=2 height=3><img src="%%RF%%style/%%STYLE%%/image/0.gif" width="1" height="1"></td></tr>
<tr height=25 valign=top><td><SPAN class=f11>&nbsp;&nbsp;Actual<b>Analyzer</b> %%SERIES%% %%VER%%</SPAN></td>
<td align=right><SPAN class=f11>Copyright &copy; 2002-2004. <a style="color:#000000" href="http://www.actualscripts.com/" target=_blank>ActualScripts</a>, Company. All rights reserved.&nbsp;&nbsp;</SPAN></td>
</tr></table></form></div></body></html>

BOTTOM;
?>