<?php
$auth=<<<AUTH
<DIV class=bor750><table width=750 border=0 cellspacing=0 cellpadding=0 align=center><tr height=20>
<input type=hidden name=authpan value=1>
<td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td>
</tr><tr><td bgcolor="#EEEEEE"><table border=0 cellspacing=1 cellpadding=0><tr bgcolor="#EEEEEE" height=20>
<td><SPAN class=f11>&nbsp;&nbsp;%%UNAMEDESC%%:&nbsp;&nbsp;</SPAN></td><td><input TABINDEX=1 type=text size=10 maxlength=20 name=unamef class=box90 value="%%UNAME%%"></td>
<td><SPAN class=f11>&nbsp;&nbsp;&nbsp;&nbsp;%%PASSWDESC%%:&nbsp;&nbsp;</SPAN></td><td><input TABINDEX=2 type=password size=10 maxlength=20 name=passwf class=box90 value="%%PASSW%%"></td>
<td><SPAN class=f11>&nbsp;&nbsp;</span></td><td><input TABINDEX=3 name=remlog type=checkbox%%RSTATUS%%></td><td><SPAN class=f11>%%REMEMBER%%</span></td>
</tr></table></td></tr><tr height=20>
<td align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"><input TABINDEX=3 name=set width=20 height=20 type=image src="%%RF%%style/%%STYLE%%/image/go.gif" title="%%LOGIN%%" border=0></td></tr></table></DIV><br>

AUTH;
?>