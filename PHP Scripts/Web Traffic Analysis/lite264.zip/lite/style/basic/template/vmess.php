<?php
$top=<<<MES
<DIV class=bor750>
<table width=750 border=0 cellspacing=0 cellpadding=0 align=center>
<tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td></tr>
<tr bgcolor="#EEEEEE" height=20><td align=center><SPAN class=f11>&nbsp;&nbsp;%%MESSAGE%%</SPAN></td></tr>
<tr height=20><td height=20 align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"></tr></table></DIV><br>

MES;
?>