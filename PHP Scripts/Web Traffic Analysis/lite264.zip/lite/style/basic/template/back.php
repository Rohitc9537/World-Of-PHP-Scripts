<?php

$cmess=<<<CMESS
<DIV class=bor750>
<table width=750 border=0 cellspacing=0 cellpadding=0 align=center>
<tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td></tr>
<tr bgcolor="#EEEEEE" height=20><td align=center><SPAN class=f11>%%MESS%%</SPAN></td></tr>
<tr height=20><td align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"><table width="100%" border=0 cellspacing=0 cellpadding=0><tr>
<td align=center><a href="admin.php" onclick="return false"><img TABINDEX=7 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/back.gif" title="%%BACK%%" border=0 onclick='javascript:history.back()'></a></td>
</tr></table></td></tr></table></DIV><br>

CMESS;

?>