This little program can make an access log for certain pages, and the log file can be analyzed by other log analyzing software. If you want to get the combined format log with referer and user agent information, or you want to know the referer information of certain pages, but your hosting provider doesn't offer access log downloading, or just provide the common format log, then you can use this program.
 
Steps of installing:

1.Upload the files in the zip file(except the /emptylog/) to a same directory, such as /logwriter/.
2.Then edit logwriter.php. Please edit $logwriter_logdir to the physical directory where the file is. If you are not clear, please run path.php.
3.Please edit $logwriter_timezone to the time zone where your server is.  
4.Set access.log to 777.
5.Add "<?php require "./logwriter/logwriter.php"; ?>" to any page you want to track.

Hint:
To save the system resources, please upload the empty log in the /emptylog/ to overwrite after a certain period.

We also offer customization service. If you want to add new functions to your program, or want to give your program a new look and feel, please let us know your need.The most important, we charge you the incredible low price--only $5/h. (flexcustom@china-on-site.com) Meanwhile,if you have other project like website design,  you can also outsource it to us.We offer the best service and the lowest price. ( outsource@china-on-site.com)

Introduction of FlexPHPSite:

FlexPHPSite is a website content management system.  You can customize database table structure or add new table to the database. You can edit it according to your demand and make it applicable to most websites, not only content management.

I  You can add or customize the fields according to your demand. All the contents will change automatically in both front program and admin program. You can also define whether they are displayed or not. If displayed, you can define their display sequence.

II In our opinion, link is the most important function of a website, so we offer you a powerful link customizing system. Here we have five link methods for your choice: global link, table link, keyword link, option link and single link. You can customize every link as you wish.
  
III  You can define the search program in the front program. 

IV  The system allow your vistor provide contents for you. The administrator will receive a message and audit the submission.

V  Our install system is automatic. Our help system is friendly. It can help you master our system quickly. 

VI  You can define your table's parent table when you add a table. 

VII  Easy for internationalization. All the program text are defined in a file. Once you edit this file, you can create a new version of your program of a different language. You can also customize the text in your program.

Our Pro version has the following additional functions:

I  When you add contents, it will generate search engine friendly pages like 12.php and cookingcatalog12.php. Since the parameter in the URl is removed, search engine can crawl them smoothly. This is good for your search engine promotion.

II  You can manage the page contents for search engine, such as meta keywords. You can implement these contents on one page or many pages for better search engine promotion.

III You can add administors and assign their permission.

IV Technique support and service.


For more information, please visit: http://www.china-on-site.com/flexphpsite/

Thanks a lot to the author of phpcounter, Pierre Far. It's his program enlighten me to write this little program. 

