<?php
$show = "percent";
$refshow = "10";
$keyshow = "5";
$ldec = "none";
$lcolor = "3f3f3f";
$hcolor = "3f3f3f";
$font_family = "verdana, geneva, arial, helvetica, sans-serif";
$font_size = "11";
$color = "3f3f3f";
$font_style = "normal";
$font_weight = "normal";
$letter_spacing = "0";
$admin = "no";
$sortlist = "yes";
$username = "user";
$password = "abc123";
$bgcolor = "ffffff";
$chbrowser = 1;
$chjs = 1;
$chcolor = 1;
$chscreen = 1;
$chos = 1;
$chcountry = 1;
$chkeywords = 1;
$chref = 1;
$chip = 1;
?>