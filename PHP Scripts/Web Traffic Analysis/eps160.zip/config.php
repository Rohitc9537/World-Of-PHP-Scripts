<?
$path_absolute = "."; 					// path absolute of the website
$path_img = "$path_absolute/img";		// directory for images
$path_data = "$path_absolute/data";		// directory for data (chmod 666, or change it to mdb-database/data for windows)
?>