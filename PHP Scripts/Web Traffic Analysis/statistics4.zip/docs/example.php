<?php include_once("statistics/weblog.php"); ?>
<html>
<head>
</head>
<body>

<script language="javascript">document.write('<img src="statistics/weblog.php?sh='+screen.height+'&sw='+screen.width+'&sc='+screen.colorDepth+'&res=<?php echo $weblog_id; ?>" width="1" height="1" alt="">');</script>
<noscript><img src="statistics/weblog.php?res=<?php echo $weblog_id; ?>" width="1" height="1" alt=""></noscript>


<h1 align="center">Your data has been logged!</h1>
</body>
</html>