Thank you for trying SHOWlog.

Configure SHOWlog in 'config/'-folder.

Get help in 'docs/'-folder.
There is an 'example.php' for how to add logging to your page.

If you've created your own template or a translation to another language, please send it
to me. I will upload it to the SHOWlog-Projectpage.

Feel free to add a comment in my guestbook on http://www.lady-s.org/stats 
or visit my homepage http://www.sirsocke.de.

If you need to contact me for bug-reporting or helping write a mail to fli4l@sirsocke.de but...
!!! Please read the documentation in 'docs/' before contacting me !!!

much fun with SHOWlog
Daniel Sokoll