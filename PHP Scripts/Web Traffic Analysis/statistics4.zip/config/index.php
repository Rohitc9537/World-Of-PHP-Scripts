<?php
header("Location: ../");	
?>