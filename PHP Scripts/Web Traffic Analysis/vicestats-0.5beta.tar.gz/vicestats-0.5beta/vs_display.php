<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

function vs_header() {
	global $vs_siteDomain, $vs_defaultUser, $vs_location;

	$tabs='';
	if ('multi'==$vs_defaultUser) {
		if (isset($_SESSION['userID'])) {
			$extra='';
			if (1==$_SESSION['userID']) {
				$extra="<a href='vs_users.php'>Users</a>";
			}
			$tabs=<<<QQ
		<div class='tabs'>
			{$extra}
			<a href='{$vs_location}'>Home</a>
			<a href='vs_code.php'>Code</a>
			<a href='vs_logout.php'>Log Out</a>
		</div>
QQ;
		}
	}

	print <<<QQ
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Vice Stats for {$vs_siteDomain}</title>
<style type="text/css">@import url(vs.css);</style>
<script type="text/javascript" src="vs.js"></script>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
</head>
<body>

<h2>
	{$tabs}
	Vice Stats 0.5b from 
	<a href="http://www.arantius.com/topic/arantius/vice+stats/" class='plain'>arantius.com</a> - 
	Report for {$vs_siteDomain}
</h2>

QQ;
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_show1colHead($title, $label, $col1) {
	print "<table>";
	print "<thead>";
	print "<tr><th colspan='3' style='text-align: center;'>{$title}</th></tr>";
	print "<tr><th>{$label}</th><th class='smallcol'>{$col1}</th></tr>";
	print "</thead>";
}
function vs_show1col($sql) {
	print "<table>";
	$result=mysql_query($sql);
	$i=0;
	while ($row=mysql_fetch_row($result)) {
		$col1=vs_trunc($row[0], 46);
		if (isset($row[2]) && !empty($row[2])) {
			$row[2]=str_replace("'", '%27', $row[2]);
			$row[3]=str_replace("'", '%27', $row[3]);
			$col1="<a href='{$row[2]}' title='{$row[3]}'>{$col1}</a>";
		}

		print "<tr class='zebra".(int)(0==$i++%3)."'>";
		printf("<td>%s</td><td class='smallcol'>%s</td>", $col1, $row[1]);
		print "</tr>";
	}

	print "</table>";
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_show2colsHead($title, $label, $col1, $col2) {
	print "<table>";
	print "<thead>";
	print "<tr><th colspan='3' style='text-align: center;'>{$title}</th></tr>";
	print "<tr><th>{$label}</th><th class='smallcol'>{$col1}</th><th class='smallcol'>{$col2}</th></tr>";
	print "</thead>";
	print "</table>";
}
function vs_show2cols($sql) {
	print "<table>";
	$result=mysql_query($sql);
	$i=0;
	while ($row=mysql_fetch_row($result)) {
		$col1=vs_trunc($row[0], 34);
		if (isset($row[3]) && !empty($row[3])) {
			$row[3]=str_replace("'", '%27', $row[3]);
			$row[4]=str_replace("'", '%27', $row[4]);
			$col1="<a href='{$row[3]}' title='{$row[4]}'>{$col1}</a>";
		}
		$col2=$row[1];
		if (isset($row[5]) && !empty($row[5])) {
			$row[5]=str_replace("'", '%27', $row[5]);
			$row[6]=str_replace("'", '%27', $row[6]);
			$col2="<a href='{$row[5]}' title='{$row[6]}'>{$col2}</a>";
		}

		print "<tr class='zebra".(int)(0==$i++%3)."'>";
		printf("<td>%s</td><td class='smallcol'>%s</td><td class='smallcol'>%s</td>", 
			$col1, $col2, $row[2]);
		print "</tr>";
	}

	print "</table>";
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_trunc($val, $len=30) {
	if (strlen($val)<=$len) return $val;
	return substr($val, 0, $len)."...";
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_niceTime($sec) {
	$hour=$min=0;
	if ($sec>=3600) {
		$hour=floor($sec/3600);
		$sec=$sec%3600;
	}
	if ($sec>=60) {
		$min=floor($sec/60);
		$sec=$sec%60;
	}
	return sprintf("%02d:%02d:%02d", $hour, $min, $sec);
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_chartLink($a, $b) {
	return sprintf(
		'<a href="vs_graph.php?type=%s" onclick="if (swapGraph(this, \'%s\')) return false;" class="plain">%s</a>',
		$a, $a, $b
	);
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function multiPageLinks($start, $perPage, $link) {
	$maxLinks=20; //most links to show at once

	$result=mysql_query("SELECT FOUND_ROWS()");
	$end=mysql_result($result, 0, 0);
	if (0==$start and $end<$perPage) return;

	$start=mysql_escape_string($start);
	print "<p>Display page: ";
	if ($end>$perPage) {
		$pages=ceil($end/$perPage);
		$skip1=0;    //where to start
		$skip2=$end; //where to finish
		if ($pages>$maxLinks) {
			if ($start<($maxLinks*$perPage/2)) {
				$skip2=$maxLinks*$perPage;
			} else if ($start>$end-($maxLinks*$perPage/2)) {
				$skip1=$end-($maxLinks*$perPage);
			} else {
				$skip1=$start-($maxLinks*$perPage/2);
				$skip2=$start+($maxLinks*$perPage/2);
			}
		}

		if ($start>0) {
			printf("<a href=\"$link\">&laquo;</a>&nbsp;", $start-$perPage);
		} else {
			print "&laquo;&nbsp;";
		}
		if ($skip1>0) print " ... ";
		for($i=$skip1; $i<$skip2; $i+=$perPage) {
			if ($i==$start) {
				printf("<strong>%d</strong> &nbsp;", ($i/$perPage)+1 );
			} else {
				printf("<a href=\"$link\">%d</a> &nbsp;", $i, ($i/$perPage)+1);
			}
		}
		if ($skip2<$end) print "...";

		if (($start+$perPage)<$end) {
			printf("&nbsp;<a href=\"$link\">&raquo;</a>", $start+$perPage);
		} else {
			print "&nbsp;&raquo;";
		}
	}
	print "</p>";
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function wrapURL($url) {
	return preg_replace('/([\/&])/', '$1<wbr>', rawurldecode($url));
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

?>
