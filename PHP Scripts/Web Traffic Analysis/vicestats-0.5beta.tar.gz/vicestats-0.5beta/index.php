<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

ob_start(); //along with the ob_flush() calls down below, this makes 
            //incremental loading cleaner
vs_dbConnect();
vs_checkLogin();

vs_header();

if ('multi'==$vs_defaultUser && 1==$vs_user) {
	print "</body></html>";
	exit;
}
?>

<h1>
	<div class='tabs'>
		<a href='vs_search.php?engine'>Engines</a>
		<a href='vs_search.php?spider'>Spiders</a>
	</div>
	Searches
</h1>
<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('searchrec');
	vs_show2colsHead('Recent', 'Terms', 'Engine', 'Time');
	vs_show2cols($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('searchfreq');
	vs_show1colHead(vs_chartLink('searchfreq', 'Frequent'), 'Terms', 'Count');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>
<? ob_flush(); ?>

<h1>Referrals</h1>
<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('refrec');
	vs_show1colHead('Recent', 'Domain', 'Time');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('reffreq');
	vs_show1colHead(vs_chartLink('reffreq', 'Frequent'), 'Domain', 'Count');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>
<? ob_flush(); ?>

<h1>
	<div class='tabs'>
		<a href='vs_resource.php'>Lookup</a>
	</div>
	Resources
</h1>
<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('resrec');
	vs_show1colHead('Recent', 'Resource', 'Time');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('resfreq');
	vs_show1colHead(vs_chartLink('resfreq', 'Frequent'), 'Resource', 'Hits');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>
<? ob_flush(); ?>

<h1>
	<div class='tabs'>
		<a href='vs_ignore.php'>Ignore</a>
	</div>
	Hits & Visits
</h1>
<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('hvday');
	vs_show2colsHead(vs_chartLink('hvday', 'Past 24 Hours'), 'Hour', 'Hits', 'Visits');
	vs_show2cols($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('hvweek');
	vs_show2colsHead(vs_chartLink('hvweek', 'Past Week'), 'Day', 'Hits', 'Visits');
	vs_show2cols($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>
<? ob_flush(); ?>

<h1>
	<div class='tabs'>
		<a href='vs_visitor.php'>Visitors</a>
	</div>
	Demographics
</h1>
<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('demo');
	//print $sql;
	vs_show2colshead('Visits', 'Entry', 'Duration', 'Time');
	vs_show2cols($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('country');
	vs_show1colHead(vs_chartLink('country', 'Countries'), 'Country', 'Visits');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>
<? ob_flush(); ?>

<table class='twocol'>
<tr>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('browser');
	vs_show2colshead(vs_chartLink('browser', 'Browsers'), 'Browser', 'Version', 'Visits');
	vs_show2cols($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
	<td class='oflow'><div>
	<?
	$sql=vs_makeSql('platform');
	vs_show1colHead(vs_chartLink('platform', 'Platforms'), 'Platform', 'Visits');
	vs_show1col($sql);
	?>
	</div></td>
	<td class='space'>&nbsp;</td>
</tr>
</table>

<div class='footer'>
	This product uses the IP-to-Country Database
	provided by <a href="http://www.webhosting.info">WebHosting.Info</a>
	available from </span><a href="http://ip-to-country.webhosting.info">http://ip-to-country.webhosting.info</a>.
</div>

</body>
</html>
