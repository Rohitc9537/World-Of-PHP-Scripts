<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

if (isset($_GET['cookie'])) {
	setcookie('vs_ignore', (1==$_GET['cookie']?1:''), time()+60*60*24*365, '/');
	header('Location: vs_ignore.php');
	exit;
}

include('vs_config.php');
//include('vs_funcs.php');
include('vs_display.php');
//vs_dbConnect();

vs_header();
?>
<h1>
	<div class='tabs'>
		<a href='vs_ignore.php?cookie=1'>Cookie</a>
	</div>
	Ignore
</h1>

<p>Your current IP address <b>is <?=(in_array($_SERVER['REMOTE_ADDR'], $vs_ignore)?'':'not')?></b> in the $vs_ignore array.</p>
<p>Your current browser <b>does <?=(isset($_COOKIE['vs_ignore'])?'':'not')?></b> have an ignore cookie set.</p>
<p>If either above sentence is positive, your visits will not be counted.</p>

<form method='get' action='vs_ignore.php'>
	<input type='hidden' name='cookie' value='1'>
	Click this button to <input type='submit' value='set an ignore cookie'>
</form>

<form method='get' action='vs_ignore.php'>
	<input type='hidden' name='cookie' value='0'>
	Click this button to <input type='submit' value='remove the ignore cookie'>
</form>

</body>
</html>