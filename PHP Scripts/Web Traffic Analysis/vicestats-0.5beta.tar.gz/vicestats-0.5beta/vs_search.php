<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

ob_start(); //along with the ob_flush() calls down below, this makes 
            //incremental loading cleaner
vs_dbConnect();
vs_checkLogin();

function showSearchForm() {
	$s='';
	if (isset($_GET['s'])) $s=$_GET['s'];
	?>
	<form method='get' action='vs_resource.php'>
	<p>Enter any part of the URL to locate a resource that matches:</p>
	<input type='text' name='s' value='<?=$s?>' size='50'>
	<input type='submit' value=' Go '>
	</form>
	</body></html>
	<?
}

vs_header();
?>
<h1>
	<div class='tabs'>
		<a href='vs_search.php?engine'>Engines</a>
		<a href='vs_search.php?spider'>Spiders</a>
	</div>
	Searches
</h1>

<?
if (empty($_GET)) {
	print "<p>Error</p>";
	exit;
} else if (isset($_GET['engine']) && empty($_GET['engine'])) {
	$sql="SELECT COUNT(h.time) AS hits, e.name, e.ID as engineID 
		FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource r, {$vs_dbPrefix}searchEngine e
		WHERE h.referralID=r.ID AND r.searchEngineID=e.ID
			AND h.userID={$vs_user}
		GROUP BY e.ID
		ORDER BY hits DESC";
	$result=mysql_query($sql);

	if (mysql_num_rows($result)>0) {
		print "<table>";
		print "<tr><th>Engine</th><th>Referrals</th></tr>";
		while ($row=mysql_fetch_assoc($result)) {
			$row['dispURL']=wrapURL($row['URL']);
			print '<tr>';
			print "<td><a href='vs_search.php?engine={$row['engineID']}'>{$row['name']}</a></td>";
			print "<td>{$row['hits']}</td>";
			print '</tr>';
		}
	}
} else if (isset($_GET['engine']) && !empty($_GET['engine'])) {
	$engine=mysql_real_escape_string($_GET['engine']);
	$sql="SELECT name FROM {$vs_dbPrefix}searchEngine WHERE ID={$engine}";
	$result=mysql_query($sql);
	$engineName=mysql_result($result, 0, 0);

	$start=0;
	if (isset($_GET['start'])) $start=mysql_real_escape_string($_GET['start']);
	$sql="SELECT SQL_CALC_FOUND_ROWS COUNT(h.time) AS hits, p.phrase
		FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource r, {$vs_dbPrefix}searchPhrase p
		WHERE h.referralID=r.ID AND r.searchPhraseID=p.ID AND r.searchEngineID={$engine}
			AND h.userID={$vs_user}
		GROUP BY p.ID
		ORDER BY hits DESC
		LIMIT {$start}, {$vs_maxRows}";
	$result=mysql_query($sql);

	if (mysql_num_rows($result)>0) {
		print "<p>Search phrases for engine: {$engineName}</p>";
		multiPageLinks($start, $vs_maxRows, 'vs_search.php?engine='.urlencode($engine).'&amp;start=%d');
		print "<table>";
		print "<tr><th>Phrase</th><th>Referrals</th></tr>";
		while ($row=mysql_fetch_assoc($result)) {
			$row['dispURL']=wrapURL($row['URL']);
			print '<tr>';
			print "<td>{$row['phrase']}</td>";
			print "<td>{$row['hits']}</td>";
			print '</tr>';
		}
	}
}

?>

</body>
</html>
