<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

vs_dbConnect();
vs_checkLogin();

$incFile=dirname(__FILE__).'/vs.php';
$sql="SELECT code FROM {$vs_dbPrefix}user WHERE ID={$_SESSION['userID']}";
$result=mysql_query($sql);
$code=mysql_result($result, 0, 0);

vs_header();
?>
<p>You can use the code below in order to track visitors to your web pages.
There are two methods available, depending on the types of pages to be tracked.
Pages written in PHP (and located on the same physical server as the Vice
Stats installation) may be tracked directly with the following code:</p>

<pre>&lt;?php
$vs_code='<?=$code?>';
@include_once('<?=$incFile?>');
?&gt;</pre>

<p>If instead you use plain HTML files or another server scripting type, you
may use a simple JavaScript command to run Vice Stats tracking on any page.
The following HTML code inserted into any page will track visits to that 
page:</p>

<pre>&lt;script type='text/javascript' src='<?=$vs_location?>vs_js.php?vs_code=<?=$code?>'&gt;&lt;/script&gt;</pre>

</body>
</html>
