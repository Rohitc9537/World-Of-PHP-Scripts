<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

vs_dbConnect();
vs_checkLogin();

if (!empty($_POST)) switch ($_POST['act']) {
case 'edit':
case 'add':
	$sql=('edit'==$_POST['act']?'UPDATE':'INSERT INTO').
		" {$vs_dbPrefix}user SET ";
	foreach (array('username', 'password', 'url') as $k) {
		if (empty($_POST[$k])) continue;
		if ('password'==$k) $_POST[$k]=sha1($_POST[$k]);
		$sql.="$k='".mysql_real_escape_string(stripslashes($_POST[$k]))."', ";
	}
	$sql=rtrim($sql, ', ');
	if ('add'==$_POST['act']) {
		$c='0123456789-|ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
		$codeUsed=true;
		do {
			$code='';
			for ($i=0; $i<8; $i++) {
				$code.=$c[rand(0, strlen($c)-1)];
			}
			$sql2="SELECT ID FROM {$vs_dbPrefix}user WHERE code='{$code}'";
			$result2=mysql_query($sql2);
			$codeUsed=(mysql_num_rows($result2)>0);
		} while ($codeUsed);
		$sql.=", code='{$code}'";
	}

	if ('edit'==$_POST['act']) $sql.=" WHERE ID='{$_POST['userID']}'";

	$result=mysql_query($sql);
	print $sql.'<hr>'.mysql_error();

	header('Location: '.$_SERVER['SCRIPT_NAME']);
	exit;
}

vs_header();

$user=array();
$user['username']='';
$user['password']='';
$user['url']='';

if (isset($_GET['userID'])) {
	$userID=preg_replace('/[^0-9]/', '', $_GET['userID']);
	$sql="SELECT * FROM {$vs_dbPrefix}user WHERE ID={$userID}";
	$result=mysql_query($sql);
	$user=mysql_fetch_assoc($result);
}
?>
<h2>Add user</h2>
<form method='post' action='<?=$_SERVER['SCRIPT_NAME']?>'>
<input type='hidden' name='act' value='<?=(isset($_GET['userID'])?'edit':'add')?>' />
<input type='hidden' name='userID' value='<?=$_GET['userID']?>' />
<table>
<tr>
	<td>Username:</td>
	<td><input type='text' name='username' value='<?=$user['username']?>' /></td>
</tr>
<tr>
	<td>Password:</td>
	<td>
		<input type='text' name='password' />
		<?=(isset($_GET['userID'])?' Leave empty to leave password unchanged':'')?>
	</td>
</tr>
<tr>
	<td>Base URL:</td>
	<td><input type='text' name='url' value='<?=$user['url']?>' /></td>
</tr>
</table>
<input type='submit' value='<?=(isset($_GET['userID'])?'Edit':'Add')?>' />
</form>

<h2>Existing users</h2>
<?
$sql="SELECT ID, username, url FROM {$vs_dbPrefix}user ORDER BY username ASC";
$result=mysql_query($sql);
print '<ul>';
while ($row=mysql_fetch_assoc($result)) {
	print "<li>";
	print "<a href='{$_SERVER['SCRIPT_NAME']}?userID={$row['ID']}'>Edit</a> ";
	print $row['username'];
	print "</li>";
}
print '</ul>';
?>

</body>
</html>
