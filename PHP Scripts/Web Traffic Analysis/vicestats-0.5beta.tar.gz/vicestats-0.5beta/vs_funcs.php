<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

$vs_dbLink=NULL;

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_dbConnect() {
	global $vs_dbLink, $vs_dbHost, $vs_dbName, $vs_dbUser, $vs_dbPass;
	if ($vs_dbLink) return;

	$link=mysql_connect($vs_dbHost, $vs_dbUser, $vs_dbPass);
	if (false===$link) return;

	if (!mysql_select_db($vs_dbName, $link)) return;

	$vs_dbLink=$link;
}

function vs_dbClose() {
	global $vs_dbLink;
	mysql_close($vs_dbLink);
}

function vs_query($sql) {
	global $vs_dbLink, $vs_debug;
	$sql=str_replace("\t\t", "\t", $sql);
	$result=mysql_query($sql, $vs_dbLink);
	if ($vs_debug<3) return $result;

	vs_log("TRY: {$sql}");
	if (mysql_errno($vs_dbLink)) {
		vs_log("ERROR: ".mysql_errno($vs_dbLink));
		vs_log(mysql_error($vs_dbLink));
	} else {
		if (false!==strpos($sql, 'SELECT')) {
			vs_log("ROWS: ".mysql_num_rows($result));
		} else {
			vs_log("AFFECTED: ".mysql_affected_rows($vs_dbLink));
		}
	}
	return $result;
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_log($msg, $level=1) {
	global $vs_debug;
	$vs_dir=dirname(__FILE__);

	if (0==$vs_debug) return;
	//if ($level<$vs_debug) return;

	$l=fopen($vs_dir.'/vs_log.txt', 'a');
	fwrite($l, "{$msg}\n");
	fclose($l);
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_getmicrotime(){ 
	list($usec, $sec) = explode(" ",microtime()); 
	return ((float)$usec + (float)$sec); 
} 

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function &vs_getBrowser($ua) {
	global $vs_dbLink, $vs_dbPrefix;
	$vs_dir=dirname(__FILE__);

	//try to grab all the detail straight from the database
	$ua=mysql_real_escape_string(trim($ua), $vs_dbLink);
	$sql="SELECT * FROM {$vs_dbPrefix}browser WHERE UA='{$ua}'";
	$result=vs_query($sql);
	if (1==mysql_num_rows($result)) {
		$row=mysql_fetch_assoc($result);
		return $row;
	} else {
		//if we have never seen this browser before load browscap
		$browscap=parse_ini_file($vs_dir.'/browscap-lite.ini', 1);
		$browser=array(
			'ID'=>NULL,
			'ua'=>$ua,
			'browser'=>'?',
			'platform'=>'?',
			'versionMajor'=>'?',
			'versionMinor'=>'?',
			'spider'=>0,
		);

		//and parse through it to find the details of this browser
		foreach($browscap as $u=>$b) {
			if (fnmatch($u, $ua)) {
				do {
					foreach (array('platform'=>'platform', 'browser'=>'browser', 'majorver'=>'versionMajor', 'minorver'=>'versionMinor') as $k1=>$k2) {
						if (isset($b[$k1]) && '?'==$browser[$k2]) $browser[$k2]=$b[$k1];
					}
					$browser['spider']=(int)( 
						isset($b['crawler'])&&$b['crawler'] 
						|| 
						isset($b['stripper'])&&$b['stripper'] 
						);
				} while (isset($b['parent']) && $b=$browscap[$b['parent']]);
			}
		}

		//some extra checks for unknown browssers
		if ('?'==$browser['browser']) {
			$browser['browser']='Unknown';
			if (0==$browser['spider'] && preg_match('/(bot|spider|crawl|slurp)/i', $browser['ua'])) {
				$browser['spider']=1;
			}
		}

		//now save it to the database
		$sql="INSERT INTO {$vs_dbPrefix}browser SET ";
		unset($browser['ID']);
		foreach ($browser as $k=>$v) $sql.="{$k}='{$v}', ";
		$sql=rtrim($sql, ', ');
		$result=vs_query($sql);
		$browser['ID']=mysql_insert_id();
		return $browser;
	}	
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function &vs_getVisitor($loopDetect=3) {
	if (0==$loopDetect) return array('NULL', 'NULL');

	global $vs_dbLink, $vs_dbPrefix, $vs_visitor, $vs_dns, $vs_sessionLength, $vs_ip, $vs_refInSite;
	$vHash='';
	//we consider HTTP_X_FORWARDED_FOR as well, because it can
	//(occasionally) distinguish distinct hosts behind a proxy
	$addr=$_SERVER['REMOTE_ADDR'] .	(isset($_SERVER['HTTP_X_FORWARDED_FOR'])?$_SERVER['HTTP_X_FORWARDED_FOR']:"");

	if ('cookie'==$vs_visitor) {
		if (isset($_COOKIE['vs_visitor'])) {
			//if we have the cookie use it
			$vHash=$_COOKIE['vs_visitor'];
		} else {
			//otherwise set it
			$vHash=md5($addr.uniqid(rand(), true));
			if (!setcookie('vs_visitor', $vHash, time()+2592000, '/')) $vHash=md5($addr);
		}
	} else if ('header'==$vs_visitor) {
		//start based off the address
		$vHash=$addr;
		foreach (array('HTTP_USER_AGENT', 'HTTP_ACCEPT', 'HTTP_ACCEPT_LANGUAGE', 
			'HTTP_ACCEPT_ENCODING', 'HTTP_ACCEPT_CHARSET') as $k
		) {
			//and then the applicable headers if we have them
			if (isset($_SERVER[$k])) $vHash.=$_SERVER[$k];
		}
		$vHash=md5($vHash);
	} else if ('jscookie'==$vs_visitor && isset($_GET['hash'])) {
		$vHash=$_GET['hash'];
	} else  {
		//default mode = just use the IP
		$vHash=md5($addr);
	}

	$sql="SELECT v.ID AS visitorID, MAX(h.visitorSession) AS visitorSession, MAX(h.time) AS time
		FROM {$vs_dbPrefix}visitor AS v
		LEFT JOIN {$vs_dbPrefix}hit AS h ON v.ID=h.visitorID 
		WHERE v.hash='{$vHash}'
		GROUP BY v.ID LIMIT 1";
	$result=vs_query($sql);
	if (0==mysql_num_rows($result)) {
		//no rows=first visit, create visitor record
		//to begin figure out the country of origin
		$sql="SELECT countryID FROM {$vs_dbPrefix}geocode WHERE ipfrom<={$vs_ip} AND {$vs_ip}<=ipto";
		$result=vs_query($sql);
		$countryID=(0==mysql_num_rows($result)?'NULL':mysql_result($result, 0, 0));

		//then save all the details
		$sql="INSERT INTO {$vs_dbPrefix}visitor SET
			hash='{$vHash}', ip='{$vs_ip}', countryID={$countryID}";
		if ($vs_dns) {
			//including host name if appropriate
			$host=mysql_real_escape_string(gethostbyaddr($_SERVER['REMOTE_ADDR']));
			$sql.=", host='{$host}'";
		}
		$result=vs_query($sql);
		if (mysql_errno($vs_dbLink)) {
			//if we couldn't insert, someone probably requested two pages
			//at the same time and we already have their record, so let's start over
			return vs_getVisitor(--$loopDetect);
		} else {
			return array(mysql_insert_id($vs_dbLink), 1);
		}
	} else {
		//we've seen this visitor before
		//should we increment the session counter?
		$row=mysql_fetch_assoc($result);
		if ( !$vs_refInSite && (
				empty($row['time']) ||
				strtotime($row['time'])+$vs_sessionLength < time() 
			) 
		) {
			$row['visitorSession']++; //it's the next session
		}
		$ret=array($row['visitorID'], (int)$row['visitorSession']);
		return $ret;
	}
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_getResourceID($type) {
	global $vs_dbLink, $vs_dbPrefix, $vs_visitorID, $vs_refInSite;

	switch ($type) {
	case 'ref':
		//make sure the url starts with 'http:' otherwise parse out the url
		//and lowercase the host for comparison sanity
		if (!isset($_SERVER['HTTP_REFERER']) || empty($_SERVER['HTTP_REFERER'])) return 'NULL';
		if (0!==strpos($_SERVER['HTTP_REFERER'], 'http:')) return 'NULL';
		$url=mysql_real_escape_string($_SERVER['HTTP_REFERER'], $vs_dbLink);
		$url=parse_url($url);
		break;
	case 'site':
		//build an array like parse_url for the current
		//url which we cannot read directly
		$url=array();
		$url['scheme']=(isset($_SERVER['HTTPS']) && 'on'==$_SERVER['HTTPS'])?'https':'http';
		$url['host']=strtolower(mysql_real_escape_string($_SERVER['HTTP_HOST'], $vs_dbLink));
		$uri=mysql_real_escape_string($_SERVER['REQUEST_URI'], $vs_dbLink);
		if (strpos($uri, '?') && !empty($uri)) {
			$uri=split('\?', $uri);
			$url['path']=$uri[0];
			$url['query']=$uri[1];
		} else {
			$url['path']=$uri;
		}
		//strip off the default document for directories if it's there
		//to make reports more compact and readable
		$url['path']=preg_replace('/index.(html?|php)$/', '', $url['path']);
	}
	
	// ask.com does ugly things, this will log the actual search 
	// page instead of the crufty redirect script as referrer
	if ( 'ref'==$type && strpos($url['host'].$url['path'], 'ask.com/redir') ) {
		parse_str($url['query'], $url);
		$url=parse_url($url['bpg']);
	}

	//I want to store the ? in the query
	if (isset($url['query']) && !empty($url['query'])) $url['query']='?'.$url['query'];
	//and use + instead of %20 in path
	$url['path']=str_replace('%20', '+', $url['path']);
	//and not store the default port
	$url['host']=preg_replace('/:80$/', '', $url['host']);
	//and make sure hostnames are all lowercase
	$url['host']=strtolower($url['host']);

	$clause=array();
	foreach(array('scheme', 'host', 'path', 'query') as $k) {
		if (isset($url[$k])) $clause[]="{$k}='{$url[$k]}'";
	}
	
	$sql="SELECT ID, searchPhraseID 
		FROM {$vs_dbPrefix}resource 
		WHERE ".implode(' AND ', $clause)." ORDER BY ID ASC LIMIT 1";
	$sql=rtrim($sql, ', ');
	$result=vs_query($sql);
	if (1==mysql_num_rows($result)) {
		$row=mysql_fetch_assoc($result);
		if ('ref'==$type && !empty($vs_visitorID)) {
			//If we just saw this visitor from this referrer, 
			//don't record multiple referrals
			$sql2="SELECT h.time 
				FROM {$vs_dbPrefix}hit h
				WHERE h.referralID={$row['ID']} AND visitorID={$vs_visitorID} 
					AND time>DATE_SUB(NOW(), INTERVAL 5 MINUTE)
				LIMIT 1";
			$result2=vs_query($sql2);
			if (1==mysql_num_rows($result2)) return 'NULL';
		}
		return $row['ID'];
	} else {
		if ('ref'==$type) {
			//if this is a new referral type, figure out the search engine if applicable
			list($vs_searchPhraseID, $vs_searchEngineID)=vs_getSearchPhraseID($url);
			$type=($vs_refInSite?'site':'ref');
		}
		$sql="INSERT INTO {$vs_dbPrefix}resource SET ".implode(', ', $clause).", type='{$type}'";
		if ('ref'==$type) $sql.=", searchPhraseID={$vs_searchPhraseID}, searchEngineID={$vs_searchEngineID}";
		vs_query($sql);
		return mysql_insert_id($vs_dbLink);
	}
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_getSearchPhraseID($ref) {
	global $vs_dbLink, $vs_dbPrefix, $vs_visitorID, $vs_refInSite, $vs_refInSite;

	//if the referrer is in-site it's definetly not a search engine
	if ($vs_refInSite) return array('NULL', 'NULL');

	//get all search engine records to analyze them
	$sql="SELECT * FROM {$vs_dbPrefix}searchEngine";
	$result=vs_query($sql);
	while ($row=mysql_fetch_assoc($result)) {
		if (false!==strpos($ref['host'], $row['domain']) ||
			('Other'==$row['name'] && false!==strpos(strtolower($ref['path']), 'search/') )
		) {
			vs_log("FOUND ENGINE: {$row['ID']} {$row['domain']} ?");

			//here we go we found the referring domain.  can we find the terms?
			$e=('Excite'==$row['name']?'\/':''); //excite requires special treatment
			if (preg_match("/[?&\/]{$row['param']}([^?&{$e}]*)/", $ref['query'], $matches)) {
				//loooks like we found the terms
				$terms=strtolower(urldecode($matches[sizeof($matches)-1]));
				
				//excite screws with things in the URL
				if ('Excite'==$row['name']) $terms=urldecode($terms);
				
				if (empty($terms)) break;
				$terms=mysql_real_escape_string($terms, $vs_dbLink);
				$sql="SELECT ID FROM {$vs_dbPrefix}searchPhrase WHERE phrase='{$terms}' LIMIT 1";
				$result=vs_query($sql);
				if (1==mysql_num_rows($result)) {
					return array(mysql_result($result, 0, 0), $row['ID']);
				} else {
					$sql="INSERT INTO {$vs_dbPrefix}searchPhrase SET phrase='{$terms}'";
					vs_query($sql);
					return array(mysql_insert_id($vs_dbLink), $row['ID']);
				}
			}
			break;
		}
	}

	//we found nothing
	return array('NULL', 'NULL');
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_makeSql($type) {
	global $vs_groupMinor, $vs_groupAll, $vs_dbPrefix, $vs_maxRows, 
		$vs_hideSpiders, $vs_reportLength, $vs_user;

	$spiderClause='';
	if ($vs_hideSpiders) {
		$spiderClause='AND b.spider=0';
	}
	$onlySince="AND h.time>'".date('Y-m-d 00:00', time()-$vs_reportLength)."'";
	$userClause="AND h.userID={$vs_user}";

	switch ($type) {
	case 'browser':
		$v="CONCAT(b.versionMajor, '.', b.versionMinor)";
		$g="b.browser, b.versionMajor, b.versionMinor";
		if ($vs_groupMinor) {
			$v="b.versionMajor";
			$g="b.browser, b.versionMajor";
		}
		if ($vs_groupAll) {
			$v="'All'";
			$g="b.browser";
		}

		$sql="SELECT b.browser, $v AS ver, 
				COUNT(DISTINCT h.visitorID, h.visitorSession) AS visits
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			WHERE h.browserID=b.ID {$spiderClause} {$onlySince} {$userClause}
			GROUP BY $g
			ORDER BY visits DESC
			LIMIT {$vs_maxRows}";
		return $sql;
	case 'platform':
		return "SELECT b.platform,
				COUNT(DISTINCT h.visitorID, h.visitorSession) AS visits
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			WHERE h.browserID=b.ID {$spiderClause} {$onlySince} {$userClause}
			GROUP BY b.platform
			ORDER BY visits DESC
			LIMIT {$vs_maxRows}";
	case 'country':
		return "SELECT c.name AS country,
				COUNT(DISTINCT h.visitorID, h.visitorSession) AS visits
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}visitor v, 
				{$vs_dbPrefix}country c, {$vs_dbPrefix}browser b
			WHERE h.visitorID=v.ID AND v.countryID=c.ID 
				AND h.browserID=b.ID 
				{$spiderClause} {$onlySince} {$userClause}
			GROUP BY v.countryID
			ORDER BY visits DESC
			LIMIT {$vs_maxRows}";
	case 'hvday':
		$timeFilter=date('Y-m-d H:00', time()-60*60*23);
		return "SELECT DATE_FORMAT(h.time, '%h %p') AS label, COUNT(h.time) AS hits, 
			COUNT(DISTINCT h.visitorID, h.visitorSession) AS visits
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			WHERE h.time>'{$timeFilter}'
				AND h.browserID=b.ID {$spiderClause} {$userClause}
			GROUP BY HOUR(h.time)
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	case 'hvweek':
		$timeFilter=date('Y-m-d 00:00', time()-60*60*24*6);
		return "SELECT DAYNAME(h.time) AS label, COUNT(h.time) AS hits, 
				COUNT(DISTINCT h.visitorID, h.visitorSession) AS visits
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			WHERE h.time>'{$timeFilter}'
				AND h.browserID=b.ID {$spiderClause} {$userClause}
			GROUP BY DAYOFMONTH(h.time)
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	case 'resrec':
		return "SELECT res.path, DATE_FORMAT(h.time, '%h:%i %p') AS restime,
				CONCAT('vs_resource.php?ID=', res.ID),
				CONCAT(ref.scheme, '://', ref.host, ref.path, IF(ref.query IS NULL, '', ref.query))
			FROM {$vs_dbPrefix}resource res, {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			LEFT JOIN {$vs_dbPrefix}resource ref ON h.referralID=ref.ID 
			WHERE h.resourceID=res.ID AND h.browserID=b.ID 
				{$spiderClause} {$onlySince} {$userClause}
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	case 'resfreq':
		return "SELECT r.path, COUNT(h.time) AS hits,
				CONCAT('vs_resource.php?ID=', r.ID)
			FROM {$vs_dbPrefix}resource r, {$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
			WHERE h.resourceID=r.ID AND h.browserID=b.ID 
				{$spiderClause} {$onlySince} {$userClause}
			GROUP BY r.path
			HAVING hits>1
			ORDER BY hits DESC
			LIMIT {$vs_maxRows}";
	case 'refrec':
		return "SELECT ref.host, DATE_FORMAT(h.time, '%h:%i %p') AS reftime,
				CONCAT(ref.scheme, '://', ref.host, ref.path, IF(ref.query IS NULL, '', ref.query)),
				CONCAT(res.scheme, '://', res.host, res.path, IF(res.query IS NULL, '', res.query))
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource ref, {$vs_dbPrefix}resource res, 
				{$vs_dbPrefix}browser b
			WHERE h.referralID=ref.ID AND h.resourceID=res.ID 
				AND ref.type='ref' AND ref.searchEngineID IS NULL
				AND h.browserID=b.ID {$spiderClause} {$onlySince} {$userClause}
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	case 'reffreq':
		return "SELECT r.host, COUNT(h.time) AS referrals
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource r, {$vs_dbPrefix}browser b
			WHERE h.referralID=r.ID AND r.type='ref' AND r.searchEngineID IS NULL
				AND h.time>DATE_SUB(NOW(), INTERVAL 1 MONTH)
				AND h.browserID=b.ID 
				{$spiderClause} {$onlySince} {$userClause}
			GROUP BY r.host
			HAVING referrals>1
			ORDER BY referrals DESC
			LIMIT {$vs_maxRows}";
	case 'searchrec':
		return "SELECT p.phrase AS terms, e.name AS engine, DATE_FORMAT(h.time, '%h:%i %p') AS hittime,
				CONCAT('vs_visitor.php?ID=', h.visitorID) AS vis, '', 
				CONCAT(ref.scheme, '://', ref.host, ref.path, IF(ref.query IS NULL, '', ref.query)),
				CONCAT(res.scheme, '://', res.host, res.path, IF(res.query IS NULL, '', res.query))
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}searchPhrase p, 
				{$vs_dbPrefix}resource res, {$vs_dbPrefix}resource ref, 
				{$vs_dbPrefix}searchEngine e
			WHERE ref.searchPhraseID=p.ID AND ref.searchEngineID=e.ID
				AND h.referralID=ref.ID AND h.resourceID=res.id
				{$onlySince} {$userClause}
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	case 'searchfreq':
		return "SELECT p.phrase AS terms, COUNT(h.time) AS searches
			FROM {$vs_dbPrefix}searchPhrase p, {$vs_dbPrefix}hit h, 
				{$vs_dbPrefix}resource r
			WHERE r.searchPhraseID=p.ID AND h.referralID=r.ID 
				{$onlySince} {$userClause}
			GROUP BY p.phrase
			HAVING searches>1
			ORDER BY searches DESC
			LIMIT {$vs_maxRows}";
	case 'demo':
		$having=($vs_hideZeroVisit?'HAVING dur>0':'');
		return "SELECT r.path, SEC_TO_TIME(
					UNIX_TIMESTAMP(MAX(h.time))-UNIX_TIMESTAMP(MIN(h.time))
				) as dur, 
				DATE_FORMAT(MIN(h.time), '%h:%i %p'),
				CONCAT('vs_visitor.php?ID=', h.visitorID) AS vis
			FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource as r
			WHERE h.visitorID IS NOT NULL AND h.resourceID=r.ID
				{$onlySince} {$userClause}
			GROUP BY CONCAT(h.visitoriD, '-', h.visitorSession)
			{$having}
			ORDER BY h.time DESC
			LIMIT {$vs_maxRows}";
	}
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_detectUserID() {
	global $vs_defaultUser, $vs_code, $vs_user, $vs_dbLink, $vs_dbPrefix;
	if ('multi'===$vs_defaultUser) {
		if (!isset($vs_code) && isset($_GET['vs_code'])) {
			$vs_code=$_GET['vs_code'];
		}
		if (!isset($vs_code)) {
			$vs_user=-1;
			return;
		}
		$vs_code=mysql_real_escape_string($vs_code, $vs_dbLink);
		$sql="SELECT ID FROM {$vs_dbPrefix}user WHERE code='{$vs_code}'";
		$result=mysql_query($sql);
		if (0==mysql_num_rows($result)) {
			$vs_user=-1;
			return;
		}
		$row=mysql_fetch_assoc($result);
		$vs_user=$row['ID'];
		vs_loadSiteDomain();
	} else {
		$vs_user=$vs_defaultUser;
	}
	vs_log("userID: {$vs_user}");
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_loadSiteDomain() {
	global $vs_user, $vs_siteDomain, $vs_defaultUser, $vs_dbLink, $vs_dbPrefix;
	if ('multi'==$vs_defaultUser) {
		$vs_user=preg_replace('/[^0-9]/', '', $vs_user);
		$sql="SELECT url FROM {$vs_dbPrefix}user WHERE ID='{$vs_user}' LIMIT 1";
		$result=mysql_query($sql, $vs_dbLink);
		if (!$result) return;
		if (1!=mysql_num_rows($result)) return;
		$row=mysql_fetch_assoc($result);
		$vs_siteDomain=$row['url'];
	}
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

function vs_checkLogin($noForm=false) {
	global $vs_defaultUser, $vs_user, $vs_dbLink, $vs_dbPrefix;
	if ('multi'===$vs_defaultUser) {
		session_start();
		if (isset($_SESSION['userID'])) {
			$vs_user=$_SESSION['userID'];
			vs_loadSiteDomain();
			return;
		}
		//if we aren't supposed to ask, just forget this page here,
		//they aren't logged in.
		if ($noForm) die;

		$error='';
		if (isset($_POST['username'])) {
			$sql="SELECT ID 
				FROM {$vs_dbPrefix}user
				WHERE username='".mysql_real_escape_string($_POST['username'], $vs_dbLink)."'
					AND password=SHA1('".mysql_real_escape_string($_POST['password'], $vs_dbLink)."')";
			$result=mysql_query($sql, $vs_dbLink);
			if (1==mysql_num_rows($result)) {
				$row=mysql_fetch_assoc($result);
				$_SESSION['userID']=$row['ID'];
				header('Location: '.$_SERVER['REQUEST_URI']);
				exit;
			} else {
				$error='Invalid username/password.';
			}
		}

		vs_header();
		if (!empty($error)) print "<p class='error'>{$error}</p>";
		?>
		<form method='post' action='<?=$_SERVER["REQUEST_URI"]?>' />
		Please log in to view your stats:
		<table>
		<tr>
			<td>Username:</td>
			<td><input type='text' name='username' /></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type='password' name='password' /></td>
		</tr>
		</table>
		<input type='submit' value='Log in' />
		</form>
		<?
		die;
	} else {
		$vs_user=$vs_defaultUser;
	}
}

// \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ // \\ //

?>
