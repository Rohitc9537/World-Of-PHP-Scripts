<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>
<!doctype html public "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Vice Stats - Tracker Sample</title>
<style type="text/css">
</style>
<script type="text/javascript">
</script>
</head>
<body>

<p>This is a stub page that serves no purpose besides being an example of the Vice Stats tracking code.  Once Vice Stats is installed properly on your system, this page should show up in your stats page when loaded.</p>
<? @include('vs.php'); ?>

</body>
</html>