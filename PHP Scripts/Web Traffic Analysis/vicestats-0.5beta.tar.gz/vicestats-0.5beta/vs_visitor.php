<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

ob_start(); //along with the ob_flush() calls down below, this makes 
            //incremental loading cleaner
vs_dbConnect();
vs_checkLogin();

function showSearchForm() {
	$s='';
	if (isset($_GET['s'])) $s=$_GET['s'];
	?>
	<form method='get' action='vs_visitor.php'>
	<p>Enter a full IP address or any part of a hostname (If you have hostname resolution enabled) to locate a visitor that matches.</p>
	<input type='text' name='s' value='<?=$s?>'>
	<input type='submit' value=' Go '>
	</form>
	</body></html>
	<?
}

vs_header();
?>
<h1>
	<div class='tabs'>
		<a href='vs_visitor.php'>Search</a>
	</div>
	Visitor
</h1>

<?
$start=0;
if (isset($_GET['start'])) $start=mysql_real_escape_string($_GET['start']);
$sql="SELECT SQL_CALC_FOUND_ROWS v.ID, v.ip, v.host, h.time,
		SEC_TO_TIME(UNIX_TIMESTAMP(MAX(h.time))-UNIX_TIMESTAMP(MIN(h.time))) as dur, 
		MIN(CONCAT(h.time, '=', res.path, IF(res.query IS NULL, '', res.query))) AS firstPage,
		MAX(CONCAT(h.time, '=', res.path, IF(res.query IS NULL, '', res.query))) AS lastPage
	FROM {$vs_dbPrefix}visitor v, {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource res
	WHERE h.visitorID=v.ID AND h.resourceID=res.ID %s
		AND h.userID={$vs_user}
	GROUP BY v.ID, h.visitorSession
	ORDER BY %s
	LIMIT {$start}, {$vs_maxRows}";
$result=false;

if (empty($_GET) || (isset($_GET['s']) && empty($_GET['s'])) ) {
	showSearchForm();
} elseif (isset($_GET['s'])) {
	$s=mysql_real_escape_string(trim($_GET['s']));
	if (preg_match('/^[\d\.]+$/', $s)) $s=sprintf("%u", ip2long($s));

	$sql=sprintf($sql, "AND ( v.ip='{$s}' OR v.host LIKE '%{$s}%' )", "v.ip ASC");
	$result=mysql_query($sql);
	if (0==mysql_num_rows($result)) {
		print "<p>No matching visitors.</p>";
		showSearchForm();
		exit;
	}
} else {
	if (!isset($_GET['ID']) || empty($_GET['ID'])) {
		showSearchForm();
	}
}

if (empty($_GET)) {
	$sql=sprintf($sql, "", "h.time DESC");
	$result=mysql_query($sql);
	print "<p>Or, browse recent visitors:</p>";
}
if ($result) {
	if (mysql_num_rows($result)>$vs_maxRows) {
		multiPageLinks($start, mysql_num_rows($result), $vs_maxRows, 'vs_visitor.php?s='.urlencode($s).'&amp;start=%d');
		$sql.=" LIMIT {$start}, {$vs_maxRows}";
		$result=mysql_query($sql);
	}
	print "<table width='100%'><tr><th>Last Time</th><th>Duration</th><th>First Page</th><th>Last Page</th><th>Host</th><th>&nbsp;</th></tr>";
	$i=0;
	while ($row=mysql_fetch_assoc($result)) {
		//strip off the max-concat trick part
		$row['firstPage']=wrapURL(substr($row['firstPage'], strpos($row['firstPage'], '=')+1));
		$row['lastPage']=wrapURL(substr($row['lastPage'], strpos($row['lastPage'], '=')+1));
		if ($row['firstPage']==$row['lastPage']) $row['lastPage']='';

		$class="zebra".(int)(0==$i++%3);
		$row['host']=str_replace('.', '.<wbr>', $row['host']);

		print "<tr class='{$class}'>";
		print "<td><nobr>{$row['time']}&nbsp;</nobr></td>";
		print "<td>{$row['dur']}</td>";
		print "<td>{$row['firstPage']}</td>";
		print "<td>{$row['lastPage']}</td>";
		print "<td><a href='vs_visitor.php?ID={$row['ID']}'>".long2ip($row['ip'])."</a></td>";
		if (!empty($row['host'])) $row['host']="({$row['host']})";
		print "<td>{$row['host']}</td>";
		print "</tr>";
	}
	print "</table>";
	exit;
}

if (isset($_GET['ID'])) $visitor['ID']=mysql_real_escape_string($_GET['ID'], $vs_dbLink);

$clause='';
if (isset($_GET['sess'])) {
	$_GET['sess']=mysql_real_escape_string($_GET['sess'], $vs_dbLink);
	$clause="AND h.visitorSession={$_GET['sess']}";
}

$sql="SELECT v.ID, v.ip, v.host, c.name as country, MAX(h.time) AS visitTime, 
		h.visitorSession AS session, b.ua
	FROM {$vs_dbPrefix}visitor v, 
		{$vs_dbPrefix}hit h, {$vs_dbPrefix}browser b
	LEFT JOIN {$vs_dbPrefix}country c ON v.countryID=c.ID 
	WHERE v.ID={$visitor['ID']} 
		AND h.visitorID=v.ID AND h.browserID=b.ID {$clause}
		AND h.userID={$vs_user}
	GROUP BY v.ID";
$result=mysql_query($sql);
$visitor=mysql_fetch_assoc($result);

$visitor['ip']=long2ip($visitor['ip']);
if (empty($visitor['host'])) $visitor['host']=gethostbyaddr($visitor['ip']);
?>

<p>Here's the things I know about this visitor:</p>
<dl>
<dt>IP Address:</dt><dd><?=$visitor['ip']?></dd>
<dt>Hostname:</dt><dd><?=$visitor['host']?></dd>
<dt>Most recent visit:</dt><dd><?=$visitor['visitTime']?></dd>
<dt>Browser:</dt><dd><?=$visitor['ua']?></dd>
</dl>

<h1>All sessions:</h1>
<table class='withspace'>
<tr><th>&nbsp;</th><th>Start time</th><th>Duration</th><th>Entry page</th><th>Referrer</th></tr>
<?
$sql="SELECT h.time, h.visitorSession,SEC_TO_TIME(
			UNIX_TIMESTAMP(MAX(h.time))-UNIX_TIMESTAMP(MIN(h.time))
		) as dur,
		CONCAT(res.path, IF(res.query IS NULL, '', res.query)) AS page,
		CONCAT(ref.scheme, '://', ref.host, ref.path, IF(ref.query IS NULL, '', ref.query)) AS ref
	FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource res
	LEFT JOIN {$vs_dbPrefix}resource ref ON h.referralID=ref.ID
	WHERE h.resourceID=res.ID AND h.visitorID={$visitor['ID']} 
		AND h.userID={$vs_user}
	GROUP BY h.visitorSession
	ORDER BY h.time ASC";
$result=mysql_query($sql);
$i=0;
while ($row=mysql_fetch_assoc($result)) {
	$row['pageDisp']=preg_replace('/([\/+])/', '$1<wbr>', $row['page']);
	$row['refDisp']=preg_replace('/([\/&])/', '$1<wbr>', $row['ref']);

	$class="zebra".(int)(0==$i++%3);
	print "<tr class='{$class}'>";
	print "<td>{$row['visitorSession']}</td>";
	print "<td><nobr>{$row['time']}</nobr></td>";
	print "<td>{$row['dur']}</td>";
	print "<td><a href='vs_visitor.php?ID={$visitor['ID']}&amp;sess={$row['visitorSession']}'>{$row['pageDisp']}</a></td>";
	print "<td><a href='{$row['ref']}'>{$row['refDisp']}</a></td>";
	print "</tr>\n";
	$visitor['session']=$row['visitorSession'];
}
?>
</table>
<br />

<?
if (isset($_GET['sess'])) {
	$visitor['session']=$_GET['sess'];
}
print "<h1>Session {$visitor['session']}:</h1>";
print "<ul>";
$sql="SELECT CONCAT(r.path, IF(r.query IS NULL, '', r.query)) AS page, h.time
	FROM {$vs_dbPrefix}hit h, {$vs_dbPrefix}resource r
	WHERE h.visitorID={$visitor['ID']} AND h.visitorSession={$visitor['session']}
		AND h.resourceID=r.ID
		AND h.userID={$vs_user}
	ORDER BY h.time ASC";
$result=mysql_query($sql);
$lastTime=-1;
$dur='00:00:00';
while ($row=mysql_fetch_assoc($result)) {
	$t=strtotime($row['time']);
	if ($lastTime>0) $dur=vs_niceTime($t-$lastTime);
	printf('<li>%1$s - %2$s - <a href="%3$s">%3$s</a></li>',
		$row['time'], $dur, $row['page']);
	$lastTime=$t;
}
print "</ul>";
?>

</body>
</html>
