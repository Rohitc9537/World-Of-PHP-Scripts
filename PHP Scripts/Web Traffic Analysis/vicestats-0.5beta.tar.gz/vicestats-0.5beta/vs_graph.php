<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//error messages will just screw up the image so get rid of them
error_reporting(E_NONE);

class Chart {
	var $colors, $white, $black, $gray;

	var $sizeX, $sizeY;
	var $legendX, $legendY;
	var $img, $font;

	var $data;

	function chart($dispType) {
		global $vs_siteDomain;

		$this->sizeX=430;
		$this->sizeY=169;
		$this->data=array();

		$this->img=imagecreate($this->sizeX, $this->sizeY);

		$this->white=imagecolorallocate($this->img, 255, 255, 255);
		$this->gray=imagecolorallocate($this->img, 128, 128, 128);
		$this->black=imagecolorallocate($this->img, 0, 0, 0);
		$this->colors=array(
			imagecolorallocate($this->img, 255,0,0),
			imagecolorallocate($this->img, 0,255,0),
			imagecolorallocate($this->img, 0,0,255),
			imagecolorallocate($this->img, 255,255,0),
			imagecolorallocate($this->img, 0,255,255),
			imagecolorallocate($this->img, 255,0,255),
			imagecolorallocate($this->img, 192,192,192),
			imagecolorallocate($this->img, 138,43,226),
			imagecolorallocate($this->img, 127,255,212),
		);

		$label='Vice Stats - '.$vs_siteDomain;
		if (!empty($dispType)) $label.=" - {$dispType}";
		imagestring($this->img, 3, 0, 0, $label, $this->black);
	}

	function loadData($key, $val) {
		$this->data[$key]=$val;
	}

	function loadDataStack($type, $key, $val) {
		if (!isset($this->data[$type])) $this->data[$type]=array();
		$this->data[$type][$key]=$val;
	}

	function dump() {
		header("Content-type: image/png");
		imagepng($this->img);
	}

	function legendBox($chart, $y, $i) {
		imagerectangle($this->img, $chart, $y, $chart+6, $y+6, $this->black);
		imagefilledrectangle($this->img, $chart+1, $y+1, $chart+5, $y+5, $this->colors[$i]);
	}
}

class Pie extends Chart {
	var $centerX, $centerY, $diam;
	var $showPercents;

	function Pie($dispType) {
		$this->chart($dispType); //set up parent constructor stuff first

		$this->centerX=128;
		$this->centerY=92;
		$this->diam=153;

		$this->legendX=250;
		$this->legendY=23;

		$this->showPercents=true;
	}

	function percentify() {
		//collapse too-many-values
		$i=0;
		$s=0;
		foreach(array_keys($this->data) as $k) {
			$i++;
			if ($i>sizeof($this->colors)) {
				$s+=$this->data[$k];
				unset($this->data[$k]);
			}
		}
		if (0!=$s) $this->data['Other']=$s;

		$s=array_sum($this->data);
		foreach(array_keys($this->data) as $k) {
			$this->data[$k]=$this->data[$k]/$s;
		}

		//collapse too-small-values
		$s=0;
		foreach(array_keys($this->data) as $k) {
			$i++;
			if ($this->data[$k]<0.02 || 'Other'==$k) {
				$s+=$this->data[$k];
				unset($this->data[$k]);
			}
		}
		if (0!=$s) $this->data['Other']=$s;
	}

	function drawLegend($data) {
		$fmt='% 2d%% %s';
		if (!$this->showPercents) $fmt='% 3d %s';
		$i=0;
		foreach($data as $k=>$v) {
			$this->legendBox($this->legendX, $this->legendY, $i);
			imagestring($this->img, 4, $this->legendX+9, $this->legendY-4, 
				sprintf($fmt, $v*($this->showPercents?100:1), $k), $this->black
			);
			$this->legendY+=14;
			$i++;
		}
	}

	function longLabels() {
		$this->centerX=80;
		$this->legendX=175;
	}

	function draw() {
		$show=$this->data;
		arsort($this->data);
		$this->percentify();
		$this->drawLegend( ($this->showPercents?$this->data:$show) );
		unset($show);

		//draw the circle
		imagefilledarc($this->img, 
			$this->centerX, $this->centerY, 
			$this->diam, $this->diam, 0, 360, 
			$this->black, IMG_ARC_NOFILL
		);

		if (sizeof($this->data)==1) {
			//only one element just fill the circle
			imagefill($this->img, $this->centerX, $this->centerY, $this->colors[0]);
		} else {
			$angle=0;
			$i=0;
			foreach(array_merge(array(0), $this->data) as $v) {
				//draw lines
				imageline($this->img, $this->centerX, $this->centerY, 
					$this->centerX+sin($angle*2*M_PI)*($this->diam/2-1), 
					$this->centerY-cos($angle*2*M_PI)*($this->diam/2-1), 
					$this->black
				);
				//fill slices
				if (0!=$v) imagefill($this->img,
					$this->centerX+sin(($angle+0.005)*2*M_PI)*($this->diam/2-3), 
					$this->centerY-cos(($angle+0.005)*2*M_PI)*($this->diam/2-3), 
					$this->colors[$i-1]
				);
				$angle+=$v;
				$i++;
			}
		}
		$this->dump();
	}
}

class Bar extends Chart {
	var $colorNum;

	function Bar($dispType) {
		$this->chart($dispType); //set up parent constructor stuff first

		$this->colorNum=0;
		$this->legendX=$this->sizeX-60;
		$this->legendY=25;
	}
	
	function drawLegend() {
		$i=0;
		foreach($this->data as $k=>$v) {
			$this->legendBox($this->legendX, $this->legendY, $i);
			imagestring($this->img, 4, 
				$this->legendX+9, $this->legendY-4, 
				$k, $this->black
			);
			$this->legendY+=14;
			$i++;
		}
	}

	function draw() {
		$left=25;
		$top=18;
		$right=$this->legendX-4;
		$bottom=$this->sizeY-5;
		$hei=$bottom-$top;
		$wid=$right-$left;
		imagerectangle($this->img, $left, $top, $right, $bottom, $this->gray);

		$this->drawLegend();

		//find most max value across sets
		$max=0;
		foreach ($this->data as $set) {
			$thisMax=max($set);
			$max=max($max, $thisMax);
		}
		
		//find appropriate step value
		$stepVals=array(5, 10, 25, 50, 75, 100, 250, 500, 1000, 2000, 3000, 5000, 10000);
		$steps=0;
		foreach($stepVals as $step) {
			for ($steps=3; $steps<6; $steps++) {
				if ($step*$steps>$max) break 2;
			}
		}
		$graphMax=$step*$steps;

		//draw vertical axis labels
		for ($i=0; $i<$steps+1; $i++) {
			imagestring($this->img, 1,
				0, $bottom-($hei/$steps*$i)-4,
				sprintf("% 5d", $step*$i),
				$this->gray
			);
		}
		//draw vertical axis lines
		imagesetstyle($this->img, array($this->gray, $this->white));
		for ($i=1; $i<$steps; $i++) {
			$y=$bottom-($hei/$steps*$i);
			imageline($this->img,
				$left+1, $y,
				$right-1, $y,
				IMG_COLOR_STYLED
			);
		}
		
		//don't draw bars over the box
		$top+=1;
		$bottom-=1;
		//figure out how wide our bars should be
		$barWid=($right-$left-6)/sizeof($set);

		foreach($this->data as $set) {
			$x=$left+5;
			foreach ($set as $k=>$v) {
				$y=max($top, $bottom-($v/$graphMax)*$hei);
				//draw bar
				imagefilledrectangle($this->img,
					$x, $y,
					$x+$barWid-5, $bottom,
					$this->colors[$this->colorNum]
				);

				$x+=$barWid;
			}
			$this->colorNum++;
		}

		foreach($this->data as $set) {
			$x=$left+5;
			foreach ($set as $k=>$v) {
				//draw label
				$lx=$x+($barWid/2)+1;
				imagefttext($this->img, 12, 90,
					$lx, $bottom-4, $this->black,
					'ProggySmall.ttf', $k
				);
				$x+=$barWid;
			}
			$this->colorNum++;
		}

		$this->dump();
	}
}

require_once('vs_config.php');
require_once('vs_funcs.php');
vs_dbConnect();
vs_checkLogin(true);

if (!isset($_GET['type'])) $_GET['type']='';
switch ($_GET['type']) {
case 'browser':
	$chart=new Pie('Browsers');
	$sql=vs_makeSql('browser');
	$result=mysql_query($sql);
	while ($row=mysql_fetch_assoc($result)) {
		$label="{$row['browser']} {$row['ver']}";
		if ('?'==$row['ver'] || 'All'==$row['ver']) $label=$row['browser'];
		$chart->loadData($label, $row['visits']);
	}
	$chart->draw();
	break;
case 'platform':
case 'country':
	$chart=new Pie( ('platform'==$_GET['type']?'Platforms':'Countries') );
	$sql=vs_makeSql($_GET['type']);
	$result=mysql_query($sql);
	while ($row=mysql_fetch_assoc($result)) $chart->loadData($row[$_GET['type']], $row['visits']);
	$chart->draw();
	break;
case 'hvday':
case 'hvweek':
	$chart=new Bar( 'Hits and Visits, past '.('hvday'==$_GET['type']?'24 hours':'Week') );
	$sql=vs_makeSql($_GET['type']);
	$result=mysql_query($sql);
	//load in an empty graph so all points show
	if ('hvday'==$_GET['type']) {
		$hours=array('12 AM', '01 AM', '02 AM', '03 AM', '04 AM', '05 AM', '06 AM', '07 AM', '08 AM', '09 AM', '10 AM', '11 AM', '12 PM', '01 PM', '02 PM', '03 PM', '04 PM', '05 PM', '06 PM', '07 PM', '08 PM', '09 PM', '10 PM', '11 PM');
		$h=date('H');
		for ($i=1; $i<=24; $i++) {
			$chart->loadDataStack('Hits', $hours[($h+$i)%24], -1);
			$chart->loadDataStack('Visits', $hours[($h+$i)%24], -1);
		}
	} else if ('hvweek'==$_GET['type']) {
		$days=array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
		$d=date('w');
		for ($i=1; $i<=7; $i++) {
			$chart->loadDataStack('Hits', $days[($d+$i)%7], -1);
			$chart->loadDataStack('Visits', $days[($d+$i)%7], -1);
		}
	}
	//then fill in the actual details
	while ($row=mysql_fetch_assoc($result)) {
		$chart->loadDataStack('Hits', $row['label'], $row['hits']);
		$chart->loadDataStack('Visits', $row['label'], $row['visits']);
	}
	$chart->draw();
	break;
case 'searchfreq':
case 'reffreq':
case 'resfreq':
	$labels=array(
		'searchfreq'=>'Frequent searches',
		'reffreq'=>'Frequent referrers',
		'resfreq'=>'Frequent resources',
	);
	$chart=new Pie( $labels[$_GET['type']] );
	$chart->longLabels();
	//$chart->showPercents=false;

	$sql=vs_makeSql($_GET['type']);
	$result=mysql_query($sql);
	while ($row=mysql_fetch_array($result)) $chart->loadData($row[0], $row[1]);
	$chart->draw();
	break;
}
vs_dbClose();
?>
