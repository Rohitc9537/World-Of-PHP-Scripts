<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//
// This is a "secret feature" that can be used to import a standard
// apache log file into the vice stats database.  This is extremely
// alpha, untested code at this point.  It should probably only be
// run on a brand-new installation, to minimize the possible loss 
// of data.
//

if ('cli'!=php_sapi_name()) {
	print "This is only meant to be used at the command line.";
	die;
}

if (3!=$argc) {
	print "Missing parameters!\n";
	print "Usage: php {$argv[0]} [http|https] [site domain]\n";
	exit;
}

include('vs_config.php');
include('vs_funcs.php');
vs_dbConnect();
$vs_visitor='ip'; //bulk dns lookups cost a lot of time!

//server masquerade stuff
$_SERVER=array();
$_SERVER['HTTP_HOST']=$argv[2];
unset($_SERVER['HTTPS']);
if ('https'==$argv[1]) $_SERVER['HTTPS']='on';

if (!defined("STDIN")) {
	define("STDIN", fopen('php://stdin','r'));
}

$log_regex='/([\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}) .*? .*? \[(.*?)\] "[A-Z]+ (.*?) HTTP\/1.." (\d+) \d+ "(.*?)" "(.*?)"/';

$i=0; $j=0;
while ($line=fgets(STDIN)) {
	$i++;
	//preg each line
	if (preg_match($log_regex, $line, $matches)) {
		//if this was an error, ignore it
		if ($matches[4]>=400) continue;
		//if this isn't a page, skip it
		if (!preg_match('/(\/|\.php|\.html?)$/', $matches[3])) continue;

		//masquerade settings
		//print_r($matches);
		$_SERVER['REMOTE_ADDR']=$matches[1];
		$_SERVER['HTTP_USER_AGENT']=$matches[6];
		$_SERVER['HTTP_REFERER']=$matches[5];
		$_SERVER['REQUEST_URI']=$matches[3];

		if (in_array($_SERVER['REMOTE_ADDR'], $vs_ignore)) continue;

		//we're in, count it
		$j++;
		print ":";
		if (0==$j%50) print " $j/$i\n";

		//fix time
		$matches[2]=substr($matches[2], 0, strpos($matches[2], ' '));
		$matches[2]=substr_replace($matches[2], ' ', 11, 1);
		$matches[2]=str_replace('/', ' ', $matches[2]);
		$matches[2]=strtotime($matches[2]);
		$matches[2]=date('Y-m-d h:m:s', $matches[2]);

		//process record
		$vs_browser=vs_getBrowser($_SERVER['HTTP_USER_AGENT']);
		$vs_ip=sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
		if ($vs_browser['spider']) {
			$vs_visitorID='NULL';
			$vs_visitorSession='NULL';
			$vs_searchPhraseID='NULL';
			$vs_referralID='NULL';
		} else {
			list($vs_visitorID, $vs_visitorSession)=vs_getVisitor();
			$vs_searchPhraseID=vs_getSearchPhraseID($_SERVER['HTTP_REFERER']);
			$vs_referralID=vs_getResourceID('ref');
		}
		$vs_resourceID=vs_getResourceID('site');
		$sql="INSERT DELAYED INTO {$vs_dbPrefix}hit SET 
			time='{$matches[2]}', visitorID={$vs_visitorID}, visitorSession={$vs_visitorSession},
			browserID={$vs_browser['ID']}, searchPhraseID={$vs_searchPhraseID},
			referralID={$vs_referralID}, resourceID={$vs_resourceID}";
		//print "$sql\n";
		@mysql_query($sql, $vs_dbLink);
	}
}
vs_dbClose();

print "\nlines: $i grokked: $j\n";
?>