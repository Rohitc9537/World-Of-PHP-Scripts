/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

function swapGraph(el, graphType) {
	while ('DIV'!=el.tagName && null!=el.parentNode) {
		el=el.parentNode;
	}
	
	var newContent;

	if (el.otherContent) {
		newContent=el.otherContent;
		newContent.otherContent=null;
	} else {
		var img=document.createElement('img');
		img.src='vs_graph.php?type='+graphType;

		var newContent=document.createElement('div');
		newContent.onclick=(function(){swapGraph(this, "");});
		newContent.className='clickme';
		newContent.appendChild(img);
		newContent.otherContent=el;
	}

	var cont=el.parentNode;
	cont.replaceChild(newContent, el);

	return true;
}

//preload the 'loading' image to be sure it shows up when needed
var preload=new Image();
preload.src='loading.gif';
