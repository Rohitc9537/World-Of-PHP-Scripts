<?
header('Content-type: text/javascript');
?>
(function(){
var ref=escape(document.referrer);
var host=escape(document.location.host);
var uri=escape(
	document.location.pathname +
	document.location.search +
	document.location.hash
);
var hash='';
<?
include_once('vs_config.php');
if ('jscookie'==$vs_visitor) {
?>
if ('string'==typeof(document.cookie)) {
	var found=document.cookie.match(/(^|; )vs_hash=([0-9a-zA-Z]{32})/);

	if (found) {
		hash=found[2];
	} else {
		var c='01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		for (var i=0; i<32; i++) hash+=c.charAt(Math.floor(Math.random()*62));
		document.cookie='vs_hash='+hash+'; path=/';
	}
}
<? } ?>
var https=('https:'==document.location.protocol?'on':'off');

var img='<?=$vs_location?>vs_img.php?ref='+ref+'&host='+host+'&uri='+uri+'+&https='+https;
if (''!=hash) img+='&hash='+hash;
<?
if (isset($_GET['vs_code'])) {
	print "img+='&vs_code={$_GET['vs_code']}';\n";
}

if ($vs_linkIcon) { ?>
document.write("<"+"a href='<?=$vs_location?>'><"+"img src='"+img+"' border='0' /></a>");
<? } else { ?>
document.write("<"+"img src='"+img+"'>");
<? } ?>
}())
