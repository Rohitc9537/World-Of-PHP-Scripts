<?
session_start();
$_SESSION=array();
session_destroy();
header('Location: '.dirname($_SERVER['REQUEST_URI']).'/');
?>