<?
$img=imagecreate(150, 50);
$red=imagecolorallocate($img, 255,0,0);
$black=imagecolorallocate($img, 0,0,0);

switch ($_GET['test']) {
case 1:
	imageline($img, 0, 25, 150, 25, $black);
	break;
case 2:
	imagestring($img, 2, 3, 3, "Test 2...", $black);
	break;
case 3:
	imagefttext($img, 12, 90,
		15, 47, $black,
		'ProggySmall.ttf', "Test 3\nTest 3\nTest 3"
	);
	break;
}

header("Content-type: image/png");
imagepng($img);
?>