<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>
<!doctype html public "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Vice Stats - Install</title>
<style type="text/css">
</style>
<script type="text/javascript">
</script>
</head>
<body>

<form method="get" action="<?=$_SERVER['REQUEST_URI']?>">
<h2>Vice Stats Installer</h2>
<?
$dir=dirname($_SERVER['SCRIPT_FILENAME']);
@include($dir.'/vs_config.php');
@include($dir.'/vs_funcs.php');

$dostep=1;
if (isset($_GET['dostep'])) $dostep=$_GET['dostep'];

print "<h3>Step {$dostep}</h3>";

//$output=false;
switch ($dostep) {
case 1: //start, check for browscap
	//$output=true;
	print "<p>We will be going through a number of steps to install Vice Stats onto your system.  <strong>Do not</strong> press refresh/reload during this process, only use the continue buttons at the bottom of the page.</p>";

	print "<p>Vice Stats relies on a custom modified version of browscap.ini to determine browser and spider user agents.  This file should have come with the distribution, but we will check to be sure.</p>";

	//we have browscap-lite.ini?
	$browscapExists=file_exists($dir.'/browscap-lite.ini')
		&& (filesize($dir.'/browscap-lite.ini')>0);
	$browscapFresh=true;

	if (!$browscapExists) {
		$browscap='';
		$browscapComment='';

		//don't have the file, check for the un-parsed version.
		$browscapExists=file_exists($dir.'/browscap.ini');
		if ($browscapExists) {
			print "<p>We don't have the lite file, but we have an original.  Cleaning out the details we don't need now...</p>";
			//parse out the original file to condense & reverse it
			flush();
			$file=@fopen($dir.'/browscap.ini', 'r');
			for ($i=0; $i<9; $i++) $browscapComment.=fgets($file);
			$section='';
			while ($line=fgets($file)) {
				//once we reach this section, throw the rest away
				if ('[*]'==trim($line)) break;

				//double-quote values for parsing safety
				if (0!==strncmp('[', $line, 1)) {
					$line=preg_replace('/=(.*)/', '="${1}"', $line);
				}

				//replace "True" and "False" with 1 and 0
				$line=str_replace(
					array('"True"', '"False"'),
					array('1',      '0'),
					$line
				);

				//if the line contains stuff we want, store it
				if (preg_match('/^(browser|parent|crawler|stripper|majorver|minorver|platform|\[)/', $line)) {
					$browscap.=$line;
				}
			}
			fclose($file);

			//try to write the file
			$file=@fopen($dir.'/browscap-lite.ini', 'w');
			if (!$file) {
				print "<p>I couldn't open a file for writing in my directory, you'll have to do it for me!  Put the contents of the box below as a file named browscap-lite.ini in my directory and click continue.</p>";
				print "<textarea rows='11' cols='' style='width: 98%; margin: auto;'>{$browscap}</textarea>";
			} else {
				fwrite($file, $browscap);
				fclose($file);
				print "<p>Saved the new browscap for you.  Let's continue.</p>";
			}
		} else {
			print "<p>I don't see browscap-lite.ini or browscap.ini.  Please download the PHP browscap.ini from: <a href='http://www.garykeith.com/browsers/downloads.asp'>http://www.garykeith.com/browsers/downloads.asp</a> and place it in my directory, named browscap.ini.  Then click continue below.</p>";
		}
	} else {
		//we should probably check the contents of the file here.  version 2 !!
		print "<p>Ok everything seems to be in order with browscap-lite.ini!  Let's go to the next step.</p>";
		$dostep++;
	}
	break;
case 2:
	print "<p>Let's check for proper configuration now...</p>";

	$configExists=file_exists($dir."/vs_config.php");

	if (!$configExists) {
		print "<p>Sorry I cannot find the configuration file.  Please make sure there is a vs_config.php file in my directory, and click continue.</p>";
	} else {
		@include($dir.'/vs_config.php');
		if (!isset($vs_siteDomain)) {
			print "<p>Either I couldn't read the config file, or it's very screwed up.  Try to recreate it from the vs_config.php.default file contained in the distribution and click continue.</p>";
		} else {
			if ( empty($vs_siteDomain) || empty($vs_dbHost) || empty($vs_dbName) ||
				empty($vs_dbUser) || empty($vs_dbPass)
			) {
				print "<p>Some of the required settings don't seem to be set.  Please check the vs_config.php file.</p>";
				break;
			}
			
			vs_dbConnect();
			if (NULL==$vs_dbLink) {
				print "<p>I could not connect to the database that you configured.  Please check the values.</p>";
			} else {
				print "<p>Great, everything seems to be configured well!</p>";
				$dostep++;
			}
		}
	}
	break;
case 3:
	print "<p>It's time to get the database set up and ready.  I'll try to do it for you.</p>";

	vs_dbConnect();

	$tables=true;
	foreach (array('browser', 'hit', 'resource', 'searchPhrase', 'visitor') as $tbl) {
		$sql="SHOW TABLE STATUS LIKE '{$vs_dbPrefix}{$tbl}'";
		$result=@mysql_query($sql);
		if (!$result || 0==mysql_num_rows($result)) {
			$tables=false;
			break;
		}
	}

	if ($tables) {
		print "<p>Looks like we have the tables!</p>";
		$dostep++;
	} else {
		print "<p>Our tables are not in place.  Let's try to put them there...</p>";
		$file=fopen($dir.'/mysql-create-tables.sql', 'r');
		$sql='';

		while (!feof($file)) {
			$line=fgets($file);
			$line=str_replace('`vs_', "`{$vs_dbPrefix}", $line);
			$sql.=$line;
		}

		foreach(explode(';', $sql) as $s) {
			$result=@mysql_query($s);
			if (0===strpos($s, 'CREATE TABLE') && false===$result) {
				print mysql_error();
				print "<p>I don't seem to be able to create them, perhaps I do not have permission.  You'll need to execute the SQL below to create these tables in the proper database:</p>";
				print "<textarea rows='11' cols='' style='width: 98%; margin: auto;'>{$sql}</textarea>";
				break;
			}
		}
	}
	break;
case 4:
	print "<p>Now we will load in the IP-to-country data.  This might take a little while.</p>";
	flush();

	vs_dbConnect();
	
	$file=@fopen($dir.'/ip-to-country.csv', 'r');
	if (!$file) {
		print "<p>I can't open the .csv file containing the data.  Weird!</p>";
		break;
	}

	@mysql_query("TRUNCATE {$vs_dbPrefix}geocode");
	@mysql_query("TRUNCATE {$vs_dbPrefix}country");

	$countries=array();
	$i=0;
	$sql="";
	while (!feof($file)) {
		if (0==$i%25) {
			if ($sql) {
				$sql=substr($sql, 0, strlen($sql)-2);
				//print "$sql<hr>";
				@mysql_query($sql, $vs_dbLink);
			}
			$sql="INSERT INTO {$vs_dbPrefix}geocode (ipfrom, ipto, countryID) VALUES ";
		}
		$line=trim(fgets($file));
		if (''==$line) continue;
		$line=str_replace('"', '', $line);
		$line=explode(',', $line);
		$line[4]=addslashes(ucwords(strtolower($line[4])));

		$countryID=0;
		if (isset($countries[$line[4]])) {
			$countryID=$countries[$line[4]];
		} else {
			$sql2="INSERT INTO {$vs_dbPrefix}country SET name='$line[4]'";
			@mysql_query($sql2, $vs_dbLink);
			$countryID=$countries[$line[4]]=@mysql_insert_id();
		}

		$sql.="({$line[0]}, {$line[1]}, {$countryID}), ";
		$i++;
	}
	$sql=substr($sql, 0, strlen($sql)-2);
	@mysql_query($sql, $vs_dbLink);

	print "<p>Great, everything seems to be in order!  We should be ready to go.  You'll just need to insert the tracking code on each page you want to count.  Be sure to read the documentation.</p>";
	print "<p>Next is the last thing to check: the GD extension to draw images.</p>";

	$dostep++;
	break;
case 5:
	print "<p>Below, we will draw a few images.  If all the images display properly, this means that the GD extension to PHP is installed on your web server and working properly.</p>";

	print "<p>Test one is the most basic test.  A red box with a black line through it should show below:</p>";
	print "<p><img src='vs_gdtest.php?test=1'></p>";

	print "<p>Test two checks for the ability to write text.  Red on black again, should say 'Test 2':</p>";
	print "<p><img src='vs_gdtest.php?test=2'></p>";

	print "<p>Test three is the last test, checking rotated text.  Red on black again, should say 'Test 3' a few times:</p>";
	print "<p><img src='vs_gdtest.php?test=3'></p>";

	print "<p>If all the images above show as described, then you're ready to go!  If not, you'll need to get your server administrator to get the GD extension for PHP working properly, or live without the graphical reporting features.</p>";
	die;
}
?>
<input type="hidden" name="dostep" value="<?=$dostep?>" />
<input type="submit" value="Continue" />
</form>

</body>
</html>
