<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

include('vs_config.php');
include('vs_funcs.php');
include('vs_display.php');

ob_start(); //along with the ob_flush() calls down below, this makes 
            //incremental loading cleaner
vs_dbConnect();
vs_checkLogin();

function showSearchForm() {
	$s='';
	if (isset($_GET['s'])) $s=$_GET['s'];
	?>
	<form method='get' action='vs_resource.php'>
	<p>Enter any part of the URL to locate a resource that matches:</p>
	<input type='text' name='s' value='<?=$s?>' size='50'>
	<input type='submit' value=' Go '>
	</form>
	</body></html>
	<?
}

vs_header();
?>
<h1>
	<div class='tabs'>
		<a href='vs_resource.php'>Lookup</a>
	</div>
	Resource
</h1>

<?
if (empty($_GET) || (isset($_GET['s']) && empty($_GET['s'])) ) {
	showSearchForm();
	exit;
} elseif (isset($_GET['s'])) {
	$s=mysql_real_escape_string(trim($_GET['s']));

	$start=0;
	if (isset($_GET['start'])) $start=mysql_real_escape_string($_GET['start']);
	$sql="SELECT SQL_CALC_FOUND_ROWS r.ID, r.type, MAX(h.time) AS lastHit,
			CONCAT(r.scheme, '://', r.host, r.path, IF(r.query IS NULL, '', r.query)) AS URL
		FROM {$vs_dbPrefix}resource r, {$vs_dbPrefix}hit h
		WHERE (h.resourceID=r.ID OR h.referralID=r.ID)
			AND h.userID={$vs_user}
		GROUP BY r.ID
		HAVING URL LIKE '%{$s}%'
		ORDER BY r.type ASC, URL ASC
		LIMIT {$start}, {$vs_maxRows}";
	$result=mysql_query($sql);
	if (0==mysql_num_rows($result)) {
		print "<p>No matching resources.</p>";
		showSearchForm();
		exit;
	} else {
		multiPageLinks($start, $vs_maxRows, 'vs_resource.php?s='.urlencode($s).'&amp;start=%d');
		print "<table width='100%'><tr><th>Last Access</th><th>Type</th><th>Resource</th></tr>";
		$i=0;
		while ($row=mysql_fetch_assoc($result)) {
			$class="zebra".(int)(0==$i++%3);
			$row['URL']=wrapURL($row['URL']);
			
			print "<tr class='{$class}'>";
			print "<td><nobr>{$row['lastHit']}&nbsp;</nobr></td>";
			print "<td>{$row['type']}</td>";
			print "<td><a href='vs_resource.php?ID={$row['ID']}'>".vs_trunc($row['URL'], 125)."</a></td>";
			print "</tr>";
		}
		print "</table>";
	}
	exit;
} else {
	if (!isset($_GET['ID']) || empty($_GET['ID'])) {
		showSearchForm();
	}
}
$_GET['ID']=mysql_real_escape_string($_GET['ID']);

$sql="SELECT r.ID, r.type
	FROM {$vs_dbPrefix}resource r
	WHERE r.ID={$_GET['ID']}";
$result=mysql_query($sql);
$resource=mysql_fetch_assoc($result);
$sql="SELECT r.ID, r.type, sp.phrase, COUNT(h.time) AS accesses,
		CONCAT(r.scheme, '://', r.host, r.path, IF(r.query IS NULL, '', r.query)) AS URL
	FROM {$vs_dbPrefix}resource r
	LEFT JOIN {$vs_dbPrefix}hit h ON h.".('ref'==$resource['type']?'referral':'resource')."ID=r.ID
	LEFT JOIN {$vs_dbPrefix}searchPhrase sp ON r.searchPhraseID=sp.ID
	WHERE r.ID={$_GET['ID']}
		AND h.userID={$vs_user}
	GROUP BY r.ID";
$result=mysql_query($sql);
if (0==mysql_num_rows($result)) {
	print "<p>No hits or acess denied.</p>";
	die;
}
$resource=mysql_fetch_assoc($result);
$resource['dispURL']=wrapURL($resource['URL']);
?>

<dl>
<dt>URL</dt><dd><a href='<?=$resource['URL']?>'><?=$resource['dispURL']?></a></dd>
<dt>Type</dt><dd><?=ucfirst($resource['type'])?></dd>
<dt><?=('ref'==$resource['type']?'Referrals':'Hits')?></dt><dd><?=$resource['accesses']?></dd>
<? if (!empty($resource['phrase'])) { ?>
<dt>Search phrase</dt><dd><?=$resource['phrase']?></dd>
<? } ?>
</dl>

<?
$sql="SELECT r1.ID, COUNT(h.time) AS accesses,
		CONCAT(r1.scheme, '://', r1.host, r1.path, IF(r1.query IS NULL, '', r1.query)) AS URL
	FROM {$vs_dbPrefix}resource r1, {$vs_dbPrefix}resource r2, {$vs_dbPrefix}hit h
	WHERE h.".('ref'==$resource['type']?'resource':'referral')."ID=r1.ID 
		AND h.".('ref'==$resource['type']?'referral':'resource')."ID=r2.ID 
		AND r2.ID={$resource['ID']}
		AND h.userID={$vs_user}
	GROUP BY r1.ID
	ORDER BY accesses DESC";
$result=mysql_query($sql);

if (mysql_num_rows($result)>0) {
	print '<p>Resources referred to'.('ref'==$resource['type']?'':' by').':';
	?>
	<table>
	<tr><th>Accesses&nbsp;</th><th>Resource</th></tr>
	<?
	while ($row=mysql_fetch_assoc($result)) {
		$row['dispURL']=wrapURL($row['URL']);
		print '<tr>';
		print "<td>{$row['accesses']}</td>";
		print "<td><a href='vs_resource.php?ID={$row['ID']}'>{$row['dispURL']}</a></td>";
		print '</tr>';
	}
} ?>

</body>
</html>
