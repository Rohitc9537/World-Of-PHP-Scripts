<?
header('Cache-control: no-cache');
header('Pragma: no-cache');

$_SERVER['HTTP_REFERER']=$_GET['ref'];
$_SERVER['HTTP_HOST']=$_GET['host'];
$_SERVER['REQUEST_URI']=$_GET['uri'];
$_SERVER['HTTPS']=$_GET['https'];
if (isset($_GET['vs_user'])) {
	$vs_user=$_GET['vs_user'];
}

include_once('vs_config.php');
$vs_showIcon=$vs_showIcon && !(isset($_GET['vs_img']) && 'off'==$_GET['vs_img']);
header('Content-type: image/gif');
if ($vs_showIcon) {
	print base64_decode('R0lGODlhEAAQAKIFAAAAAP8AAAAA/6qqqgD/AP///wAAAAAAACH5BAEAAAUALAAAAAAQABAAAANGCKo19a6NAYIF7eVY6oUZ5HgBtmkQaYbSaJVo/KjawszvCgi8ntc8ge8zCw5LNmMtR2juestLk/AURkvT6hGQVc5s4IUmAQA7');
} else {
	//1x1 transparent
	print base64_decode('R0lGODlhAQABAIAAAP///wAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==');
}

include('vs.php');
?>
