DROP TABLE IF EXISTS `vs_browser`;
CREATE TABLE IF NOT EXISTS `vs_browser` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `ua` varchar(255) NOT NULL default '',
  `platform` varchar(64) NOT NULL default '',
  `browser` varchar(64) NOT NULL default '',
  `versionMajor` varchar(16) NOT NULL default '',
  `versionMinor` varchar(16) NOT NULL default '',
  `spider` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `UA` (`ua`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_country`;
CREATE TABLE IF NOT EXISTS `vs_country` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`ID`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_geocode`;
CREATE TABLE IF NOT EXISTS `vs_geocode` (
  `ipfrom` int(10) unsigned NOT NULL default '0',
  `ipto` int(10) unsigned NOT NULL default '0',
  `countryID` int(64) unsigned NOT NULL default '0',
  KEY `ipfrom` (`ipfrom`),
  KEY `ipto` (`ipto`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_hit`;
CREATE TABLE IF NOT EXISTS `vs_hit` (
  `userID` int(10) unsigned NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `visitorID` int(10) unsigned default NULL,
  `visitorSession` mediumint(8) unsigned default NULL,
  `browserID` int(10) unsigned NOT NULL default '0',
  `referralID` int(10) unsigned default NULL,
  `resourceID` int(10) unsigned NOT NULL default '0',
  KEY `when` (`time`),
  KEY `userID` (`userID`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_resource`;
CREATE TABLE IF NOT EXISTS `vs_resource` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `scheme` enum('http','https') NOT NULL default 'http',
  `host` varchar(255) NOT NULL default '',
  `path` varchar(255) NOT NULL default '',
  `query` text,
  `type` enum('site','ref') NOT NULL default 'site',
  `searchEngineID` int(10) unsigned default NULL,
  `searchPhraseID` int(10) unsigned default NULL,
  PRIMARY KEY  (`ID`),
  KEY `host` (`host`),
  KEY `path` (`path`),
  KEY `type` (`type`),
  KEY `search` (`searchEngineID`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_searchEngine`;
CREATE TABLE IF NOT EXISTS `vs_searchEngine` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  `domain` varchar(255) NOT NULL default '',
  `param` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`ID`)
);

INSERT INTO `vs_searchEngine` VALUES (1, 'Google', 'google.', '(as_)?[pq]=');
INSERT INTO `vs_searchEngine` VALUES (2, 'MSN', 'msn.', '(q|searchString)=');
INSERT INTO `vs_searchEngine` VALUES (3, 'Yahoo', 'yahoo.', '(va|vp|[pK])=');
INSERT INTO `vs_searchEngine` VALUES (4, 'AOL', 'search.aol', 'query=');
INSERT INTO `vs_searchEngine` VALUES (5, 'Lycos', 'lycos.', 'query=');
INSERT INTO `vs_searchEngine` VALUES (6, 'Alexa', 'alexa.com', 'q=');
INSERT INTO `vs_searchEngine` VALUES (7, 'All The Web', 'alltheweb.com', 'q(uery)?=');
INSERT INTO `vs_searchEngine` VALUES (8, 'AltaVista', 'altavista.', '(aqa|q)=');
INSERT INTO `vs_searchEngine` VALUES (9, 'A9', 'a9.com', '\\/');
INSERT INTO `vs_searchEngine` VALUES (10, 'Netscape Search', 'netscape.', '(search|query)=');
INSERT INTO `vs_searchEngine` VALUES (11, 'Search.com', 'www.search.com', 'q=');
INSERT INTO `vs_searchEngine` VALUES (12, 'Excite', 'excite.', 'search(=|\\/web\\/)');
INSERT INTO `vs_searchEngine` VALUES (13, 'Dogpile', 'dogpile.com', 'search\\/web\\/');
INSERT INTO `vs_searchEngine` VALUES (14, 'Dmoz', 'dmoz.org', 'search=');
INSERT INTO `vs_searchEngine` VALUES (15, 'Walla', 'walla.co', 'q=');
INSERT INTO `vs_searchEngine` VALUES (16, 'Mamma', 'mamma.com', 'query=');
INSERT INTO `vs_searchEngine` VALUES (17, 'Ask.com', 'ask.co', '(ask|q)=');
INSERT INTO `vs_searchEngine` VALUES (18, 'AvantFind', 'avantfind.', '[kK]eywords=');
INSERT INTO `vs_searchEngine` VALUES (19, 'HotBot', 'hotbot.com', 'query=');
INSERT INTO `vs_searchEngine` VALUES (20, 'Overture', 'overture.com', 'Keywords=');
INSERT INTO `vs_searchEngine` VALUES (21, 'Other', 'search.', '((k|q|qry|query|s|search(for)?|Keywords|w|qkw)=|search\\/web\\/)');

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_searchPhrase`;
CREATE TABLE IF NOT EXISTS `vs_searchPhrase` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `phrase` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
);

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_user`;
CREATE TABLE IF NOT EXISTS `vs_user` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `code` varchar(8) binary NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `username` (`username`)
);

INSERT INTO `vs_user` VALUES (1, 'vsadmin', 'c16d6be6a4d42595f066cd308228b013a640d60c', 'admin account', '');

-- --------------------------------------------------------

DROP TABLE IF EXISTS `vs_visitor`;
CREATE TABLE IF NOT EXISTS `vs_visitor` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `countryID` int(10) unsigned default NULL,
  `hash` varchar(32) default NULL,
  `ip` int(10) unsigned NOT NULL default '0',
  `host` varchar(255) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `hash` (`hash`),
  KEY `ip` (`ip`)
);
