<?
/*
Vice Stats - Web site statistics gathering suite.
Copyright (C) 2005 Anthony Lieuallen

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//make sure we don't spit out unsightly errors
$vs_er=ini_get('error_reporting');
error_reporting(0);

//in case we were included into a function
global $vs_siteDomain, $vs_dbHost, $vs_dbName, $vs_dbUser, $vs_dbPass,
	$vs_dbPrefix, $vs_visitor, $vs_sessionLength, $vs_ignore, $vs_dns,
	$vs_maxRows, $vs_timeOffset, $vs_resourceQuery, $vs_referQuery,
	$vs_groupMinor, $vs_groupAll, $vs_hideZeroVisit, $vs_hideSpiders,
	$vs_debug, $vs_ip, $vs_visitorID, $vs_visitorSession, $vs_refInSite,
	$vs_reportLength, $vs_location, $vs_showIcon, $vs_linkIcon,
	$vs_defaultUser, $vs_user;

include_once('vs_config.php');
//if we're really seriously debugging, turn on error messages.
if ($vs_debug>9) error_reporting(E_ALL);
include_once('vs_funcs.php');

//begin processing, stop if we should ignore this visit
$vs_s=vs_getmicrotime();
if (in_array($_SERVER['REMOTE_ADDR'], $vs_ignore)
	|| isset($_COOKIE['vs_ignore']) ) return;

//make the referrer value safe
if (isset($_SERVER['HTTP_REFERER'])) {
	$_SERVER['HTTP_REFERER']=stripslashes($_SERVER['HTTP_REFERER']); //hmmm.....
}

//connect to the database
vs_dbConnect();
vs_log('-----------------------------------------------------');
vs_log(date('r'));

//make sure we record a valid user
vs_detectUserID();
if (-1==$vs_user) {
	vs_log('Could not find proper user ID');
	return;
}

$vs_refInSite=false;
if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {
	vs_log("Ref: {$_SERVER['HTTP_REFERER']}");
	$vs_ref=parse_url($_SERVER['HTTP_REFERER']);
	$vs_siteDomain=strtolower($vs_siteDomain);
	$vs_ref=strtolower($vs_ref['host']).$vs_ref['path'];
	$vs_refInSite=(false!==strpos($vs_ref, $vs_siteDomain));
}

$vs_browser=vs_getBrowser($_SERVER['HTTP_USER_AGENT']);
$vs_ip=sprintf("%u", ip2long($_SERVER['REMOTE_ADDR']));
if ($vs_browser['spider']) {
	$vs_visitorID='NULL';
	$vs_visitorSession='NULL';
	$vs_referralID=vs_getResourceID('ref'); //eh ...
} else {
	list($vs_visitorID, $vs_visitorSession)=vs_getVisitor();
	if (isset($_SERVER['HTTP_REFERER'])) {
		$vs_referralID=vs_getResourceID('ref');
	} else {
		$vs_referralID='NULL';
	}
}
$vs_resourceID=vs_getResourceID('site');
vs_query("INSERT DELAYED INTO {$vs_dbPrefix}hit SET 
	userID={$vs_user}, time=NOW(), visitorID={$vs_visitorID}, 
	visitorSession={$vs_visitorSession}, browserID={$vs_browser['ID']}, 
	referralID={$vs_referralID}, resourceID={$vs_resourceID}");
vs_dbClose();
$vs_e=vs_getmicrotime();
vs_log("I took: ".($vs_e-$vs_s)." seconds.");

//remove global variables unneded outside this script
unset($vs_siteDomain, $vs_dbHost, $vs_dbName, $vs_dbUser, $vs_dbPass,
	$vs_dbPrefix, $vs_visitor, $vs_sessionLength, $vs_ignore, $vs_dns,
	$vs_maxRows, $vs_timeOffset, $vs_resourceQuery, $vs_referQuery,
	$vs_groupMinor, $vs_groupAll, $vs_hideZeroVisit, $vs_hideSpiders,
	$vs_debug, $vs_ip, $vs_visitorID, $vs_visitorSession, $vs_refInSite,
	$vs_reportLength, $vs_location, $vs_defaultUser, $vs_user
);

//set error reporting back to what it used to be 
error_reporting($vs_er);
?>
