http://www.iamskill.com

Log Visitor Data By TheBrokenOne

You'll need to make a database table using the mysql query
in the commented code & you'll have to change the username, password & database variables to
the ones you use in your own mysql database.

To view the visitor data just go webstats2.php?skill_mode=2 & it'll show all your data.

Just use include 'webstats2.php'; on any php webpage you want to track visitor stats for. Basically
its a one file installation + make the mysql datbase table.

If you want to discount referrals from inner pages on your site search for $dommy & change it to 
your domain name, this will discount all urls from your domain in the top referrers list