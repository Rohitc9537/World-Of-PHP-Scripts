<?php
/************************************************************************/
/* AWStats Access 3.0: Provides access to AWStats outside of cPanel     */
/* ============================================                         */
/* Created for and by members of TotalChoiceHosting.com                 */
/* Copyright (C) 2005 by TotalChoiceHosting.com                         */
/*                                                                      */
/* This file is part of AWStats Access.                                 */
/*  AWStats Access is free software; you can redistribute it and/or     */
/*  modify it under the terms of the GNU General Public License as      */
/*  published by the Free Software Foundation; either version 2 of      */
/*  the License, or (at your option) any later version.                 */
/*                                                                      */
/*  AWStats Access is distributed in the hope that it will be useful,   */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of      */
/*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the       */
/*  GNU General Public License for more details.                        */
/*                                                                      */
/*  You should have received a copy of the GNU General Public License   */
/*  along with Foobar; if not, write to                                 */
/*	Free Software Foundation, Inc.                                      */
/*  59 Temple Place, Suite 330                                          */
/*	Boston, MA  02111-1307  USA                                         */
/************************************************************************/

$username = "user"; /* used to access this utility */
$password = "pass"; /* used to access this utility */
$site = "yoursite.com";
$cpnlusername = "cpanelusername";
$cpnlpassword = "cpanelpassword";
?>
