
To include the script into a page, copy the files weblog.php and log.txt into your website folder then add the following line of code in any page you want to record its logs:
<?php include 'weblog.php'; ?>

Copyright (C) 2005 Abbas Alafoo

Distribution and registration:
This is a tutorial script. The files are Copyrighted (c) by Abbas Alafoo. Permission for 
non commercial use of "alafoo php weblog" is granted without fee. Permission is also granted for
non commercial redistribution of the script under the condition no changes are made
in the code nor the copyright statement.

Please send your comments, suggestions and report errors to the following Email address:
admin@website-hostings.net

Licensed under the terms of the GNU Lesser General Public License:
http://www.opensource.org/licenses/lgpl-license.php