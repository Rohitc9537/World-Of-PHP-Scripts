<?php include 'weblog.php'; ?>

This example shows how does 'alafoo php weblog' works. Open the file 'log.txt' to see the new entry.