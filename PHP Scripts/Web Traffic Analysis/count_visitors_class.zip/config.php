<?php 
define("DB_SERVER", "localhost");
define("DB_NAME", "finalwebsites_com_1");
define ("DB_USER", "admin");
define ("DB_PASSWORD", "admin");

define ("DB_TABLE", "visits");
define ("IMG", "./1px.png"); // change this constant to use dif. image/path
?>