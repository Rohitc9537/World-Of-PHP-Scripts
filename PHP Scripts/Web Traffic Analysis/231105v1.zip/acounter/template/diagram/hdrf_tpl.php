<?php die("Access restricted");?>
<input class=box1 type="text" size=34 name=refname%%num%% value=%%ref%%>
<input class=b33 type="button" value="Go" onClick="GoRef(this.form.refname%%num%%.value)"> 
