<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td height="25" colspan="4" align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">No records</SPAN>
    </font></td>
  </tr>