<?php die("Access restricted");?>
<td align="center" width="%%vdtimewidth%%">
  <font size="%%fsize%%" color="%%fcolor%%">
 <SPAN class="%%class%%">%%item%%</SPAN>
  </font>
</td>
