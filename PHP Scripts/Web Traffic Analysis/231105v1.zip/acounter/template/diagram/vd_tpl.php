<?php die("Access restricted");?>
<table width="570" bgcolor="#CCCCCC" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align=center vAlign=bottom>
      <table height="210" width="%%dwidth%%" border="0" cellspacing="0" cellpadding="0">
        <tr>
  	    %%columns%%
        </tr>
      </table>
    </td>
   </tr>
  <tr>
    <td align="center">
      <table border="1" cellspacing="0" cellpadding="0">
        <tr><td width="%%twidth%%" height=1></td></tr> 
      </table>
    </td>
  </tr>
   <tr>
    <td align="center">
      <table bgcolor=#CCCCCC height=20 width="%%twidth%%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          %%items%%
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td align="center">
      <table bgcolor=#000066 height=24 border="0" cellspacing="0" cellpadding="1">
        <tr bgcolor=#000066>
          <td><input type="image" border=0 name="hbegin" width="23" height=20 src="%%url%%images/scroll/hbegin.gif"></td>
          <td><input type="image" border=0 name="hleft" width="23" src="%%url%%images/scroll/hleft.gif"></td>
	  <td>

      <table bgcolor=#FFFFFF height=20 width="%%twidth%%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align=center>
            <font size=3 color="#000066"><b>
             <SPAN class="%%class%%">%%range%%</SPAN> 
            </b></font>
            </SPAN>
          </td>
        </tr>
      </table>

	  </td>
          <td><input type="image" border=0 name="hright" width="23" src="%%url%%images/scroll/hright.gif"></td>
          <td><input type="image" border=0 name="hend" width="23" src="%%url%%images/scroll/hend.gif"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width=560 height=10>
    </td>
  </tr>
</table>

