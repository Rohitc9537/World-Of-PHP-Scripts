<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td align=center valign=center height=25 width="30"><font size=3 color="#000000">
      <SPAN class="%%class%%">%%num%%</SPAN>
    </font></td>
    <td valign=center><font size=3 color="#000000">
      <SPAN class="%%class%%">%%name%%</SPAN>
    </font></td>
    <td width="210">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td valign=center><img border=0 height=20 src="%%url%%images/diagram/horiz/%%color%%left.gif"></td>
          <td valign=center><img border=0 height=20 width="%%width%%" src="%%url%%images/diagram/horiz/%%color%%center.gif"></td>
          <td valign=center><img border=0 height=20 width=9 src="%%url%%images/diagram/horiz/%%color%%right.gif"></td>
          <td valign=center ><font size=3 color="#000000">
            <SPAN class="%%class%%">&nbsp;%%value%%</SPAN>
          </font></td>
        </tr>
      </table>
    </td>
  </tr>