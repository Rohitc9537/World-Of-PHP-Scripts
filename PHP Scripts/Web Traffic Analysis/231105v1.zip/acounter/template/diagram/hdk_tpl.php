<?php die("Access restricted");?>
<input class=b66 type="submit" name="vsummary_x" value="%%val2%%">