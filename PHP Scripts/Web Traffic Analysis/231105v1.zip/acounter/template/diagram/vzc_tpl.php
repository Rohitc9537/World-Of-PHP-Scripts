<?php die("Access restricted");?>
    <td align=center vAlign=bottom>
<input type="hidden" name="vdcol%%num%%" value="%%inttim%%">
<table width="30" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td align=center><img border=0 width="30" src="%%url%%images/diagram/vertical/%%color%%zero.gif" onclick = "col_select(%%num%%);"></td>
  </tr>
</table>
    </td>  
