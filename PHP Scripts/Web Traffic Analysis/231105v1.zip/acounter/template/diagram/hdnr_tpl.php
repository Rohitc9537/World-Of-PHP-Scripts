<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
          <td  valign=center align=center class=f8 height=25 width="30"><font size=3 color="#000000">
            <SPAN class="%%class%%">%%num%%</SPAN>
          </font></td>
          <td valign=center><font size=3 color="#000000">
            <SPAN class="%%class%%">%%name%%</SPAN>
          </font></td>
          <td width="210">
            <table border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td height=25 width="100%"></td>
              </tr> 
            </table>
          </td>
  </tr>
