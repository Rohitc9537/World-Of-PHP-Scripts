<?php die("Access restricted");?>
        <option value="%%value%%"%%active%%>%%name%%</option>
