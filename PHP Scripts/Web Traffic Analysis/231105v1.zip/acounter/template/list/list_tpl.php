<?php die("Access restricted");?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <select name="%%list%%"%%ext%%>
        %%items%%
      </select>
    </td>
  </tr>
</table>
