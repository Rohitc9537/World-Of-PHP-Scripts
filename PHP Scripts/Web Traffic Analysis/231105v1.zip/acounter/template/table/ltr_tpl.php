<?php die("Access restricted");?>
<input type="text" size=27 class=box3 name=refname%%num%% value=%%val4%%>
<input class=b33 type="button" value="Go" onClick="GoRef(this.form.refname%%num%%.value)">
