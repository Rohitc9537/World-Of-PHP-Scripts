<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td height="25" align="center">
        <input type="hidden" name="vdcol%%num%%" value="%%inttim%%">
        <input class=b22 type="submit" name="vdcolumn%%num%%_x" value="%%val2%%">
    <td align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val3%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val4%%</SPAN> 
    </font></td>
  </tr>