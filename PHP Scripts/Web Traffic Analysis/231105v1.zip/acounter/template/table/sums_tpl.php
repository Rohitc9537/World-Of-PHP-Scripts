<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td height="25" width="240" align="center">
        <input type="hidden" name="vdcol%%num%%" value="%%inttim%%">
        <input class=b2 type="submit" name="vdcolumn%%num%%_x" value="%%vals2%%">
    </td>
    <td align="center"><font size=3 color="#000000">
      <SPAN class="%%class%%">%%vals3%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
      <SPAN class="%%class%%">%%vals4%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
      <SPAN class="%%class%%">%%vals5%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
      <SPAN class="%%class%%">%%vals6%%</SPAN> 
    </font></td>
  </tr>