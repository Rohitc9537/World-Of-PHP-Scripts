<?php die("Access restricted");?>
<table width="570" bgcolor="#CCCCCC" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align=center valign="top">
      <table width="560" bgcolor="#666666" border="1" cellspacing="0" cellpadding="0">
        <tr bgcolor="#666666">
          <td width="380" height="25" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">Interval</SPAN>
          </font></b></td>
          <td width="80" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">Value</SPAN>
          </font></b></td>
          <td width="100" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">%</SPAN>
          </font></b></td>
        </tr>
          %%rows%%
        <tr bgcolor="#666666">
          <td height="25" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">%%val2%%</SPAN>
          </font></b></td>
          <td width="80" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">%%val3%%</SPAN>
          </font></b></td>
          <td width="100" align="center"><b><font size=3 color="#FFFFFF">
             <SPAN class="%%class%%">%%val4%%</SPAN>
          </font></b></td>
        </tr>
      </table>

    </td>
  </tr>
  <tr>
    <td align="center">
      <table width="560" bgcolor=#000066 height=24 border="0" cellspacing="0" cellpadding="1">
        <tr bgcolor=#000066>
          <td><input type="image" border=0 name="hbegin" width="23" src="%%url%%images/scroll/vbegin.gif"></td>
          <td><input type="image" border=0 name="hleft" width="23" src="%%url%%images/scroll/vup.gif"></td>
          <td width="100%" align=center>
      <table width="100%" bgcolor=#FFFFFF height=20 border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align=center>
            <font size=3 color="#000066"><b>
             <SPAN class="%%class%%">%%range%%</SPAN>
            </b></font>
            </SPAN>
          </td>
        </tr>
      </table>
          </td>
          <td><input type="image" border=0 name="hright" width="23" src="%%url%%images/scroll/vdown.gif"></td>
          <td><input type="image" border=0 name="hend" width="23" src="%%url%%images/scroll/vend.gif"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width=560 height=10>
    </td>
  </tr>
</table>