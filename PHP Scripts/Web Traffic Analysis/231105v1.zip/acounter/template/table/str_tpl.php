<?php die("Access restricted");?>
<input type="text" class=box2 size=38 name=refname%%num%% value=%%val2%%>
<input type="button" class=b33 value="Go" onClick="GoRef(this.form.refname%%num%%.value)">