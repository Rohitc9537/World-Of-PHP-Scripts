<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td class=f8 height="25" align="center"><font size=2 color="#000000">
        <SPAN class="%%class%%">%%num%%</SPAN> 
    </font></td>
    <td class=f8 align="center"><font size=2 color="#000000">
        <SPAN class="%%class%%">%%val1%%</SPAN> 
    </font></td>
    <td class=f8 align="left"><font size=2 color="#000000">
        <SPAN class="%%class%%">%%val4%%</SPAN> 
    </font></td>
    <td width="140" class=f8 align="left"><font size=2 color="#000000">
        <SPAN class="%%class%%">%%val2%%</SPAN> 
    </font></td>
    <td width="60" class=f8 align="center"><font size=2 color="#000000">
        <SPAN class="%%class%%">%%val3%%</SPAN> 
    </font></td>
  </tr>