<?php die("Access restricted");?>
  <tr bgcolor="#CCCCCC">
    <td height="25" align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val1%%</SPAN> 
    </font></td>
    <td align="left"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val2%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val3%%</SPAN> 
    </font></td>
    <td align="center"><font size=3 color="#000000">
       <SPAN class="%%class%%">%%val4%%</SPAN> 
    </font></td>
  </tr>