<?php die("Access restricted");?>
<input class=b22 type="submit" name="vsummary_x" value="%%val2%%">
