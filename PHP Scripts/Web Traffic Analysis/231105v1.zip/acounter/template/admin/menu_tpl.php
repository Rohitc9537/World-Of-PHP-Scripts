<?php die("Access restricted");?>
<table width=160 border="0" cellspacing="1" cellpadding="0">
  <tr>
      <td><input type="hidden" name="voldaction" value="%%action%%"></td>
  </tr>
  <tr>
      <td align=center>
        <input type="image" border=0 name="aconfig" src="%%url%%images/admin/config.gif">
      </td>
  </tr>
  <tr>
      <td align=center>
        <input type="image" border=0 name="ahtml" src="%%url%%images/admin/html.gif">
      </td>
  </tr>
  <tr>
      <td align=center>
        <input type="image" border=0 name="aaccount" src="%%url%%images/admin/account.gif">
      </td>
  </tr>
</table>