<?php die("Access restricted");?>
<table height="100" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
      <td colspan=4 align=center>
          <font size=3 color="#000000">
             <SPAN class="%%class%%">%%emes%%</b></SPAN>
          </font></td>
  </tr>
  <tr>
      <td width=150></td>
      <td align=center><input name="aaccount_x" type="submit" class=b7 value="Return"></td>
      <td width=150></td>
  </tr>
</table>