<?php die("Access restricted");?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr><td>
    <textarea class="box7" cols=68 rows=12 name="textfield">%%ahtml%%</textarea>
  </td></tr>
</table>