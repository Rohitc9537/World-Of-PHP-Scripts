<?php die("Access restricted");?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr height=15>
      <td align=center width=210>
        <font size=2 color="#000000"><SPAN class="%%class%%">URL of 'acounter' folder</SPAN></font>
      </td>
      <td align=left><SPAN class="f12"><input class="box5" type="text" size=48 maxlength=250 name=aurl value="%%aurl%%"></td>
  </tr>
  <tr height=15>
      <td align=center width=210>
        <font size=2 color="#000000"><SPAN class="%%class%%">Path to 'acounter' folder</SPAN></font>
      </td>
      <td align=left><SPAN class="f12"><input class="box5" type="text" size=48 maxlength=250 name=apath value="%%apath%%">
  </tr>
 <tr align=right valign=bottom>
      <td height=50 align=right valign=bottom colspan=2><input name="asavethis" type="submit" class=b55 value="Save the parameters"></SPAN></td>
  </tr>
</table>