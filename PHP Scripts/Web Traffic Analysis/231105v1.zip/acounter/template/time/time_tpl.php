<?php die("Access restricted");?>
<table border="0" cellspacing="0" cellpadding="0">
    <td width=5></td>
    <td valign=center>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <select name="vtimeday">
        %%dayitems%%
      </select>
    </td>
  </tr>
</table>
    </td>
    <td valign=center>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <select name="vtimemonth">
        %%monthitems%%
      </select>
    </td>
  </tr>
</table>
    </td>
    <td valign=center>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <select name="vtimeyear">
        %%yearitems%%
      </select>
    </td>
  </tr>
</table>
    </td>
    <td>
      <input class=b3 type="submit" name="vdate" value="Go">
    </td>
  </tr>
</table>
