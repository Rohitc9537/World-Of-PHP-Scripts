<?php die("Access restricted");?>
<table width=160 border="0" cellspacing="1" cellpadding="0">
  <tr>
      <td><input type="hidden" name="voldaction" value="%%action%%"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vsummary" src="%%url%%images/menu/summary.gif"></td>
  </tr>
  <tr>
      <td height="20"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vvisitors" src="%%url%%images/menu/visitors.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vhosts" src="%%url%%images/menu/hosts.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vreloads" src="%%url%%images/menu/reloads.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vhits" src="%%url%%images/menu/hits.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vreturns" src="%%url%%images/menu/returns.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vips" src="%%url%%images/menu/ips.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vrefservers" src="%%url%%images/menu/refserv.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vrefpages" src="%%url%%images/menu/refpages.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vlanguages" src="%%url%%images/menu/language.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vonlines" src="%%url%%images/menu/onlines.gif"></td>
  </tr>
  <tr>
      <td><input type="image" border=0 name="vlogs" src="%%url%%images/menu/logs.gif"></td>
  </tr>
</table>