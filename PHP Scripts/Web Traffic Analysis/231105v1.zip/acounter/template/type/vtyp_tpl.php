<?php die("Access restricted");?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
      <td><input type="hidden" name="voldtype" value="%%type%%"></td>
      <td><input type="image" border=0 name="vdiagram" src="%%url%%images/type/diagram.gif"></td>
      <td><input type="image" border=0 name="vstattable" src="%%url%%images/type/table.gif"></td>
  </tr>
</table>