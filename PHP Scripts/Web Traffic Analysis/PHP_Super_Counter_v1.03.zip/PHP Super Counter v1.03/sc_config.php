<?

/*
***************************************************
***************************************************
*          :: PHP Super Counter v1.03 ::          *
* Coded by Roel S.F. Abspoel (roel@abspoel.com)   *
***************************************************
*    Magtrb.com  13/11/05 21:12
*http://www.magtrb.com/Scripts/pafiledb.php?action=category&id=77
* you can post any new ideas or comments at
*http://www.magtrb.com/Invision/index.php?s=&act=SF&f=9
* no need for registration to post just post directlly in english.
***************************************************     */

$SQL_HOST="localhost";
$SQL_USER="root";
$SQL_PWD="";
$SQL_DB="test";

$showicon = false;
$Password = "2004511";
$ReloadDelay = 300;
$TABLE_HEAD_COLOR = "#368436";
$TABLE_COLOR = "#D6D77E";
$TEXT_COLOR = "#000000";

$SQL_COUNTTABLE="SC_COUNTER";
$SQL_LOGTABLE="SC_LOG";
$SQL_REFERENCETABLE="SC_REFERENCE";
$SQL_BLOCKIPTABLE="SC_BLOCKIPS";
$SQL_STATSTABLE="SC_STATS";

?>
