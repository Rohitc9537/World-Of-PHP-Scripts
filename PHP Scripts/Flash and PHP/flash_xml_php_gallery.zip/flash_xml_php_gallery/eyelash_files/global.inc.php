<?
$arr_global=array();
$arr_global["images_folder"]="eyelash_images/";
$arr_global["images"]=$arr_global["images_folder"] . "big/";
$arr_global["thumbnails"] = $arr_global["images_folder"] . "small/";
$arr_global["texts"] = $arr_global["images_folder"] . "texts/";
$arr_global["admin_username"] = "eye";										
$arr_global["admin_password"] = "lash";	
$arr_global["image_max_width"]=500;
?>