To use a language, replace the "config.php" file inside the directory "required"
Para usar un lenguaje, cambia el archivo "config.php" dentro del directorio "required"