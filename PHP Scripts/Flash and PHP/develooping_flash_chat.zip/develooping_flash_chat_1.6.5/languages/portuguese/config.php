<?php
error_reporting(7);

/*   (Develooping flash Chat version 1.2)  */
/*   ____________________________________  */

/* portuguese translation by Douglas Pechtoll Prado */

/*___________________________________________________*/
/*___________________________________________________*/
/*___________________________________________________*/
/*                   Configura��es                   */
/*___________________________________________________*/
/*___________________________________________________*/
/*___________________________________________________*/


/*   Configura��es do Chat 	*/
/*   _________________		*/

$url="http://www.seudominio.com.br/chat/chat/"; //url de seu diret�rio de escripts

$text_order = "down"; //use "down" ou "up" para mostrar mensagens de cima para baixo ou vice-versa

$review_text_order = "down"; //o mesmo acima mas para a janela de revis�o de mensagens

$delete_empty_room = "no"; //use "yes" para deletar as mensagens quando a sala estiver vazia

$show_without_time = "no"; //"no" mostrar sempre a hora , "yes" mostrar a hora apenas quando o usu�rio entra ou sai da sala

$password_system = "ip"; //"ip" ou "password" usar ip ou password para identificar usu�rios

/*   NOTE:   O sistema de "banimento" funciona somente com a op��o acima em "ip" */
/*           Use "password" somente quando os usu�rios vem do mesmo ip*/


/*   Vari�veis administrativas */
/*   _______________________   */

$admin_name = "admin"; //nome do usu�rio administrador(max. 12 caracteres)

$admin_password = "admin"; // password do administrador(max. 12 caracteres)


/*   Vari�veis num�ricas do Chat  	*/
/*   _______________________   	*/

$correct_time = 0;//diferen�a em segundos para o hor�rio do servidor

$chat_lenght = 15;//n�mero de mensagens mostradas na sala do Chat

$review_lenght = 500;//n�mero de mensagens mostradas na janela de revis�o

$total_lenght = 1000;//n�mero de mensagens arquivadas no arquivo do chat

$minutes_to_delete = 15; //minutes to delete inactive users


/*   Palavras Filtradas */
/*   _________________  */

$words_to_filter = array("fodendo", "foda", "merda", "pica", "caralho");//lista de palavras que devem ser trocadas (adicione mais se voc� quiser)

$replace_by = "*@#!";// express�o que ser� apresentada no local das palavras trocadas da lista acima


/*___________________________________________________*/
/*___________________________________________________*/
/*___________________________________________________*/
/*                    Tradu��o                       */
/*___________________________________________________*/
/*___________________________________________________*/
/*___________________________________________________*/


/*   Express�es a traduzir na p�gina de introdu��o 	*/
/*   _____________________________________________ 	*/

$intro_alert="Por favor:"; //

$alert_message_1="-O nome deve ter pelo menos 4 caracteres"; //

$alert_message_2="-A password (senha) deve ter pelo menos 4 caracteres"; //

$alert_message_3="-N�o use caracteres especiais ou n�meros no nome"; //

$alert_message_4="-Desculpe, precisamos conhecer o n�mero de seu IP para permitir seu acesso"; //

$alert_message_5="-N�o use caracteres especiais na password (senha)"; //

$person_word=" pessoa"; //

$plural_particle="s"; //
 
$now_in_the_chat= " est�o agora na sala de Chat";//

$require_sentence = "Este chat requer Flash 4"; //

$name_word = "Nome"; //

$password_word = "Senha"; //

$enter_button = "Enter" ; //

$enter_sentence_1 = "Para entrar na sala de chat , digite seu nome ";//

$enter_sentence_2 = "e sua senha";//

$enter_sentence_3 = " e click no bot�o";//

$name_taken= "nome escolhido";


/*   Express�es a traduzir na sala de chat   */
/*   ______________________________________  */

$private_message_expression = "\(para (.*)\)"; //Express�o regular para o inicio das mensagens particulares

$before_name="(para "; // se voc� mudou a Express�o regular acima , utilize aqui a mesma palavra colocada entre "\ e (.*)

$after_name=")"; // se voc� mudou a Express�o regular , utilize aqui o mesmo texto que utilizou ap�s (.*) 

$not_here_string = "-O destinat�rio n�o est� na sala-"; // O destinat�rio de uma mensagem particular n�o est� na sala

$bye_string = "At� logo. Esperamos v�-lo em breve,";//mensagem apresentada ao usu�rio que deixa a sala de chat

$enter_string = "(entrou na sala)";//mensagem apresentada a todos quando um novo usu�rio entra na sala de chat.

$bye_user = "(deixou a sala)";//mensagem apresentada a todos quando um usu�rio deixa a sala de chat.

$kicked_user = "---Voc� foi expulso desta sala de chat---";//mensagem apresentada ao usu�rio que � expulso da sala de chat.

$bye_kicked_user = "Da pr�xima vez, tente ser mais educado";//mensagem de despedida para usu�rios expulsos

$bye_banned_user = "Sua entrada nesta sala de chat foi proibida";//despedida a usu�rios banidos

$banned_user = "Sinto muito, voc� n�o pode entrar nesta sala";//mensagem apresentada a usu�rios banidos que tentam entrar na sala


/*   Express�es a traduzir na interface do chat   */
/*   ___________________________________________  */

$intro_text="Antes de entrar, leia as seguintes informa��es.
";

$intro_text .="Caso exista na sala algu�m com o mesmo nome escolhido por voc�, um n�mero ser� adicionado ao final de seu nome. ";

$intro_text .="Por ex. caso o nome digitado por voc� seja Carlos, e j� exista algu�m na sala chamado Carlos, seu nome ser� alterado para Carlos1.
";

$intro_text .="Voc� pode ver os usu�rios conectados e enviar mensagens particulares aos mesmos, ativar e desativar o som(�cone 'alto-falante') e revisar a conversa (�cone 'seta de retorno').
";

$intro_text .="Isto � tudo. Aproveite o chat.";//

$conn="
Conectando a sala de chat. Por favor, aguarde um momento..."; //

$you_are="voc� �"; //

$connected_users= "Usu�rios conectados";//

$private_message_to= "mensagem particular para";//

$private_message_text="As mensagens particulares s� podem ser vistas pelo pr�prio remetente e o respectivo destinat�rio.
";//
 
$private_message_text.="Escreva o nome do usu�rio exatamente como aparece, ou o mesmo n�o receber� a mensagem.
";// 

$private_message_text.="Lembre-se que voc� pode copiar um texto selecionado e cola-lo em outro campo usando o bot�o direito no Windows ou control-click no Mac.";//


/*   Express�es a traduzir na p�gina de revis�o de mensagens  */
/*   _______________________________________________________  */

$review_title ="�ltimas mensagens no Chat";// titulo da p�gina de revis�o de mensagens


/*   Express�es a traduzir na p�gina de administra��o   */
/*   _________________________________________________  */

$link_to_admin ="Administra��o";// texto para o link da p�gina de administra��o

$intro_admin_title = "Administra��o do Develooping Chat";// t�tulo da p�gina de administra��o

$intro_admin_name = "Nome";//Texto para o campo nome na p�gina de administra��o

$intro_admin_password = "Senha";//Texto para o campo senha na p�gina de administra��o

$intro_admin_button= "Ok";//Texto do bot�o p�gina de administra��o

$no_users = "N�o existem usu�rios na sala";// mensagem caso n�o existam usu�rios na sala 

$text_for_kick_button = "Expuls";//texto para o bot�o expulsar

$text_for_bann_button = "Banir";//texto para o bot�o banir ips

$no_ips = "N�o existem IP's banidos na sala";//

$text_for_pardon_button = "Perdoar";//texto para o bot�o de perdoar ips

$ip_link = "Administra��o de IPs banidos";//texto para o link de IPs banidos

$no_ip_link = "O chat n�o est� usando o IP para identificar os usu�rios , ent�o eles n�o podem ser banidos";//texto caso voc� use senha ao inv�s de IP

$users_link = "Administra��o por lista de usu�rios";//texto para o link de usu�rios conectados 

?>
