AdesMailForm
Author: AdesTynyshev <ades@adesdesign.net>
Version: 2.2
http://www.adesdesign.net

FREE to use, if you want remove Powered by AdesFormMail text you need to buy this script.
---------------------------------------------------------------------------

Requirements
---------------------------------------------------------------------------
    - PHP4.0.0 or Higher
    - Flash Player

Installation
---------------------------------------------------------------------------

1. Unzip the file
2. Open form.php and change the your@email.com to your own email.
3. Upload all the files: AdesFormMail.php, AdesFormMail.swf and form.php to your directory
4. Go to and open AdesFormMail.php in your browser.
5. Use form2.php if you are having error with form.php, sometimes you will not recieve the mail, or you will recieve empty parameters. That is because of your servers configuration. Rename form2.php to form.php and it should be fine.

Buy this Script for Only USD 16.30
---------------------------------------------------------------------------

What you will get when you buy the script? 

   - You will be able to use it in any way you like.
   - You will get the fla files, so that you can change and modify the script
   - Powered by AdesFormMail message will be removed from your script

http://www.adesdesign.net/php/products_adesformmail.php buy now online.

 

 