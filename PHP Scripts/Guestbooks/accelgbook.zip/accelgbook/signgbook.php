<?php include "header.php"; ?>
<HTML><HEAD><TITLE>Sign Our Guestbook</TITLE>
<LINK href="style.css" type=text/css rel=stylesheet>
</HEAD>
<BODY vLink=#333333 aLink=#ffcc33 bgColor=#333333 leftMargin=0 topMargin=0 " 
marginheight="0" marginwidth="0">
<TABLE cellSpacing=0 cellPadding=0 width=770 bgColor=#000000 border=0>
  <TBODY>
  <TR vAlign=top>
    <TD vAlign=center width=770>
      <h1><font color="#EEEEEE">accelGbook</font></h1>
      <!-- end top nav -->
    </TD>
  </TR></TBODY></TABLE>
<TABLE cellSpacing=0 cellPadding=0 width=770 bgColor=#99cc00 border=0>
  <TBODY>
  <TR>
    <TD>
      </TD></TR></TBODY></TABLE>
<TABLE cellSpacing=0 cellPadding=0 width=722 bgColor=#ffffff border=0>
  <TBODY>
  <TR>
    <TD 
    background="images/bg_grey.gif" 
    bgColor=#eeeeee colSpan=2 width="828"><IMG height=20 
      src="images/p.gif" 
      width=770></TD></TR>
  <TR>
    <TD bgColor=#ffcc33 width="25"><IMG height=16 
      src="images/p.gif" 
      width=25></TD>
    <TD vAlign=center bgColor=#ffcc33 width="750">
      <p align="right"><b><a href="/">Home</a>&nbsp; |&nbsp; <a href="gbook.php">View 
      Our Guestbook</a>&nbsp;&nbsp;&nbsp;</b></p>  
    </TD>
  </TR>
  <TR>
    <TD width="585" colspan="2"><?php include 'sign_accelgbook.php'; ?></TD>  
  </TR>
  </TBODY></TABLE><!-- begin DHTML layers for global nav menu -->
<TABLE cellSpacing=0 cellPadding=2 width=770 bgColor=#ffffff border=0>
  <TBODY>
  <TR>
    <TD><IMG height=13 
      src="images/p.gif" 
      width=766></TD></TR>
  <TR>
    <TD vAlign=center align=middle bgColor=#99cc00>Powered By <a href="http://www.russeldesign.com"> accelGbook</a>    
</TD></TR></TBODY></TABLE>

</BODY></HTML>  

