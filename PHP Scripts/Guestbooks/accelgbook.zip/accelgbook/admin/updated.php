
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>deleted</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../forText.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {
	color: #FF3300;
	font-size: 12px;
}
-->
</style>
</head>

<body>
<table width="600" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td height="30" class="forTableBgLeft"><div align="center">Modified Successfully</div></td>
  </tr>
  <tr>
    <td class="forTableBgRight"><div align="center">Record ID: <?php echo $_GET['modifyID']; ?> has been modified</div></td>
  </tr>
</table>
</body>
</html>
