<?php

/* CHANGE THE USERNAME AND PASSWORD */

define("ADMINUSER", "admin"); // admin username 
define("ADMINPASSWORD", "admin"); // admin password 

#######################################################################

define("ADMINHOME", "frame.html"); 
?>