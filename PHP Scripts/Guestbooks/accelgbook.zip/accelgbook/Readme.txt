This is the second release of accelGbook

Features Added:
Admin Area
Added some text Field
Fix Some Bugs


first version of accelGbook. 

Features:
Unlimited Data Entry
Very Easy to Integrate in your own websites


