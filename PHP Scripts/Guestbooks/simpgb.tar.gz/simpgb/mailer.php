<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$redirect=0;
require_once('./config.php');
require_once('./functions.php');
$local_flash=array("backform","inputform");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("no such language available $act_lang");
require_once('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$noseccheck)
{
	die($l_config_writeable);
}
$pagemode="";
require_once('./includes/get_layout.inc');
require_once('./includes/block_leacher.inc');
if($blockoldbrowser==1)
{
	if(is_ns3() || is_msie3())
	{
		$sql="select * from ".$tableprefix."_texts where textid='oldbrowser' and lang='$act_lang'";
		if(!$result = mysql_query($sql, $db))
		    die("Could not connect to the database.");
		if($myrow = mysql_fetch_array($result))
			echo undo_htmlspecialchars($myrow["text"]);
		else
			echo $l_oldbrowser;
		exit;
	}
}
include_once('./includes/htmlMimeMail.inc');
if($use_smtpmail)
{
	include_once('./includes/smtp.inc');
	include_once('./includes/RFC822.inc');
}
require_once("./includes/bbcode.inc");
if(!isset($entrynr) && !isset($mtype))
	die($l_callingerror);
if(isset($mytype) && ($mtype!="admmail"))
	die($l_callingerror);
if(($allowinternalmailer==0) && (!isset($mtype)))
	die($l_functiondisabled);
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
		if(($customheader) && ($cheadnobr==0))
			echo "<br>\n";
	}
	if($customheader)
		echo "$customheader\n";
	if(($headerfile) && ($headerfilepos==1))
	{
		if(($customheader) && ($cheadnobr==0))
			echo "<br>\n";
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
	}
}
if(!isset($start))
	$start=0;
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db))
    die("Could not connect to the database.".mysql_error());
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
		include_once("./includes/mhead.inc");
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
?>
</td></tr></table>
<?php
		include('./includes/footer.inc');
		exit;
	}
}
if(isset($mode))
{
	if(!isset($mtype))
	{
		$sql="select * from ".$tableprefix."_data where entrynr='$entrynr'";
		if(!$result = mysql_query($sql, $db))
    		die("Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("No such entry");
		$receiver[]=$myrow["posteremail"];
		$displayreceiver=$myrow["posteremail"];
	}
	else
	{
		$sql="select * from ".$tableprefix."_adm_mail mail, ".$tableprefix."_users u where u.usernr=mail.usernr and length(u.email)>0 group by u.usernr";
		if(!$result = mysql_query($sql, $db))
    		die("Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("No such entry");
		do{
			$receiver[]=$myrow["email"];
		}while($myrow=mysql_fetch_array($result));
		$displayreceiver=$l_admin;
	}
	$errors=0;
	$errmsg="";
	if(!isset($sendermail))
		$sendermail="";
	if(!$sendermail)
	{
		$errors=1;
		$errmsg.="<tr bgcolor=\"$contentbgcolor\"><td colspan=\"2\" align=\"center\">";
		$errmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$errmsg.="$l_noemail</font></td></tr>";
	}
	if($sendermail && !validate_email($sendermail))
	{
		$errors=1;
		$errmsg.="<tr bgcolor=\"$contentbgcolor\"><td colspan=\"2\" align=\"center\">";
		$errmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$errmsg.="$l_novalidemail</font></td></tr>";
	}
	if(!$input_text)
	{
		$errors=1;
		$errmsg.="<tr bgcolor=\"$contentbgcolor\"><td colspan=\"2\" align=\"center\">";
		$errmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$errmsg.="$l_notext</font></td></tr>";
	}
	else
	{
		if(!bittst($emailfeatures,BIT_1) || !bittst($emailfeatures,BIT_5))
			$input_text=strip_tags($input_text);
		if($trimperiods==1)
			$input_text = preg_replace ("/(.)\\1{".$trimperiodlength.",}/", "\\1\\1", $input_text);
		if(($maxmaillength>0) && ($errors==0))
		{
			if(strlen($input_text)>$maxmaillength)
			{
				$errors=1;
				$errmsg.="<tr bgcolor=\"$contentbgcolor\"><td colspan=\"2\" align=\"center\">";
				$errmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
				$errmsg.="$l_msgtoolong $maxmaillength $l_chars)</font></td></tr>";
			}
		}
	}
	if($errors==1)
	{
		$pagetype="send";
		include_once("./includes/mhead.inc");
		echo $errmsg;
		echo "<tr bgcolor=\"$contentbgcolor\"><td colspan=\"2\" align=\"center\">";
		echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		echo "<a class=\"actionline\" href=\"javascript:history.back()\">$l_back</a>";
		echo "</font></td></tr>";
		include('./includes/footer.inc');
		exit;
	}
	if(!$subject)
		$subject = str_replace("{sitename}",$simpgbsitename,$l_defsubj);
	else
		$subject = strip_tags($subject);
	if($allowhtml==0)
	{
		$input_text=strip_tags($input_text);
	}
	if(bittst($emailfeatures,BIT_1))
	{
		if(!bittst($emailfeatures,BIT_5))
			$input_text = strip_tags($input_text);
		if(bittst($emailfeatures,BIT_2))
		{
			if(!isset($disableautourl))
				$input_text = make_clickable($input_text);
			if(!isset($disablebbcode))
				$input_text = bbencode($input_text,$allowedbbcodes);
		}
		if(bittst($emailfeatures,BIT_3) && !isset($disableemoticons))
		{
			$input_text = encode_emoticons($input_text, $url_emoticons, $db);
		}
	}
	$html_mail=$input_text;
	$asc_mail=strip_tags($input_text);
	$html_mail=str_replace("\n","<br>",$html_mail);
	$html_mail=str_replace("\r","",$html_mail);
	$gburl="http://".$simpgbsitename.$url_simpgb."/guestbook.php";
	$asc_mail.="$crlf---$crlf";
	$html_mail.="<hr>";
	$mailsig=str_replace("{sitename}",$simpgbsitename,$l_mnote);
	$mailsig=str_replace("{gburl}",$gburl,$mailsig);
	$asc_mail.=strip_tags($mailsig);
	$html_mail.=$mailsig;
	if(bittst($emailfeatures,BIT_4))
		$html_mail=str_replace($url_gfx,"",$html_mail);
 	while(list($null, $actrcv) = each($receiver))
	{
		$mail = new htmlMimeMail();
		$mail->setCrlf($crlf);
		$mail->setTextCharset($contentcharset);
		if(bittst($emailfeatures,BIT_1))
		{
			$mail->setHTMLCharset($contentcharset);
			if(bittst($emailfeatures,BIT_4))
				$mail->SetHTML($html_mail, $asc_mail,$path_gfx."/");
			else
				$mail->SetHTML($html_mail, $asc_mail);
		}
    	else
		   	$mail->setText($asc_mail);
		if($sender)
			$fromadr="\"$sender\" <$sendermail>";
		else
			$fromadr=$sendermail;
		$mail->setSubject($subject);
		$mail->setFrom($fromadr);
		$currentreceiver=array($actrcv);
		@set_time_limit($msendlimit);
		if($use_smtpmail)
		{
			$mail->setSMTPParams($smtpserver,$smtpport,NULL,$smtpauth,$smtpuser,$smtppasswd);
	        $mail->send($currentreceiver, "smtp");
		}
		else
	    	$mail->send($currentreceiver, "mail");
	}
	$sql="select * from ".$tableprefix."_texts where textid='mailsent' and lang='$act_lang'";
	if(!$result = mysql_query($sql, $db))
		die("Unable to connect to database.".mysql_error());
	$pagetype="send";
	$redirect=1;
	include_once('./includes/mhead.inc');
	echo "</table></td></tr></table></div>";
	if($headerspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$headerspace\"></div>";
	echo "<div align=\"$tblalign\">";
	echo "<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"$tblalign\" class=\"sgbtable\">";
	echo "<tr BGCOLOR=\"$bordercolor\"><td>";
	echo "<TABLE BORDER=\"0\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"100%\" bgcolor=\"$bordercolor\">";
	echo "<tr bgcolor=\"$contentbgcolor\">";
	if($myrow=mysql_fetch_array($result))
	{
		echo "<td align=\"left\" colspan=\"2\">";
		echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$displaytext=stripslashes($myrow["text"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		$displaytext = str_replace("{receiver}",$displayreceiver,$displaytext);
		echo $displaytext;
	}
	else
	{
		echo "<td align=\"center\" colspan=\"2\">";
		echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		echo str_replace("{receiver}",$displayreceiver,$l_mailsent);
	}
	echo "</font></td></tr>";
	echo "</table></td></tr></table></div>";
	if($actionboxspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$actionboxspace\"></div>";
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr BGCOLOR="<?php echo $bordercolor?>"><td>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%" bgcolor="<?php echo $bordercolor?>">
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<a class="actionline" href="guestbook.php?<?php echo "$langvar=$act_lang"?>&amp;layout=<?php echo $layout?>"><?php echo $l_gotoguestbook?></a></font></td></tr>
</table></td></tr></table></div>
<?php
	if($copyrightboxspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$copyrightboxspace\"></div>";
	include_once('./includes/footer.inc');
	exit;
}
else
{
	if(!isset($mtype))
	{
		$sql="select * from ".$tableprefix."_data where entrynr='$entrynr'";
		if(!$result = mysql_query($sql, $db))
    		die("Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("No such entry");
		$receiver=$myrow["posteremail"];
	}
	else
		$receiver=$l_admin;
	$pagetype="enter";
	require_once("./includes/mhead.inc");
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td colspan="2" align="center">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b><?php echo $l_sendmailto?>: <?php echo $receiver?><b></font></td></tr>
</table></td></tr></table></div>
<?php
	if($headerspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$headerspace\"></div>";
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<form onSubmit="return checkemailform();" name="inputform" action="<?php echo $act_script_url?>" method="post">
<input type="hidden" name="mode" value="sendmail">
<?php
if(isset($entrynr))
	echo "<input type=\"hidden\" name=\"entrynr\" value=\"$entrynr\">";
if(isset($mtype))
	echo "<input type=\"hidden\" name=\"mtype\" value=\"$mtype\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="layout" value="<?php echo $layout?>">
<input type="hidden" name="start" value="<?php echo $start?>">
<tr class="inputline"><td align="right" width="30%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<?php echo $l_yourname?>:</font></td><td><input class="sgbinput" type="text" name="sender" size="40" maxlength="80"></td></tr>
<tr class="requiredline"><td align="right" width="30%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<?php echo $l_youremail?>:</font></td><td><input class="sgbinput" type="text" name="sendermail" size="40" maxlength="80"></td></tr>
<tr class="inputline"><td align="right" width="30%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<?php echo $l_subject?>:</font></td><td><input class="sgbinput" type="text" name="subject" size="40" maxlength="80"></td></tr>
<tr class="requiredline"><td align="right" width="30%" valign="top">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<?php
echo "$l_text:";
if($maxmaillength>0)
{
	echo "<br>$l_max $maxmaillength $l_chars";
?>
<script type="text/javascript" language="JavaScript1.2"><!--
 document.write('<br><?php echo $l_charsleft?>: <input type="text" size="5" name="counter" value="<?php echo $maxmaillength?>" readonly onfocus="document.inputform.input_text.focus()" style="background-color:#00ff00">&nbsp;');
 //--></script>
<?php
}
?>
</font></td>
<td>
<table width="100%" align="center" cellpadding="0" cellspacing="0" bgcolor="<?php echo $bordercolor?>">
<tr><td><table width="100%" align="center" cellpadding="2" cellspacing="2"><tr class="requiredline"><td>
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<textarea class="sgbinput" name="input_text" rows="10" cols="40" onKeyup="countmaxchars()"></textarea></font>
<?php
	if(bittst($emailfeatures,BIT_1))
	{
		echo "<table width=\"100%\" bgcolor=\"$bordercolor\" cellspacing=\"0\" cellpadding=\"1\">";
		if(bittst($emailfeatures,BIT_3))
		{
			echo "<tr><td>";
			include_once("./includes/emoticon_list.inc");
			echo "</td></tr>";
		}
		if(bittst($emailfeatures,BIT_2))
		{
			echo "<tr><td>";
			echo allowed_bbcodes($allowedbbcodes, $bbcode_pics, $l_bbcode_labels, $fontbuttons, $l_bbcode_helps);
			echo "</td></tr>";
		}
		if(bittst($emailfeatures,BIT_2) || bittst($emailfeatures,BIT_3))
		{
?>
<tr><td><table width="100%" bgcolor="<?php echo $contentbgcolor?>">
<tr bgcolor="<?php echo $contentbgcolor?>">
<td><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
			if(bittst($emailfeatures,BIT_3))
			{
?>
<input class="sgbcheckbox" type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?><br>
<?php
			}
			if(bittst($emailfeatures,BIT_2))
			{
?>
<input class="sgbcheckbox" type="checkbox" name="disableautourl" value="1"> <?php echo $l_disableautourl?><br>
<input class="sgbcheckbox" type="checkbox" name="disablebbcode" value="1"> <?php echo $l_disablebbcode?>
<?php
			}
?>
</font></td></tr></table></td></tr>
<?php
		}
		echo "</table>";
	}
?>
</td></tr></table></td></tr></table></td></tr>
<tr class="requiredline"><td align="center" colspan="2">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>">
<?php echo $l_requiredmarked?></font></td></tr>
</table></td></tr></table></div>
<?php
if($actionboxspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$actionboxspace\"></div>";
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr BGCOLOR="<?php echo $bordercolor?>"><td>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%" bgcolor="<?php echo $bordercolor?>">
<tr bgcolor="<?php echo $actionbgcolor?>"><td colspan="2" align="center">
<?php
	if($sendmailpic)
	{
		if(!is_flash_file($sendmailpic))
		{
			$imagesize = GetImageSize ($path_gfx."/".$sendmailpic);
			echo "<a href=\"javascript:if(checkinputform()) document.inputform.submit();\"><img src=\"$url_gfx/$sendmailpic\" border=\"0\" align=\"absmiddle\" title=\"$l_sendemail\" alt=\"$l_sendemail\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"></a>";
		}
		else
		{
			$imagesize = GetImageSize ($path_gfx."/".$sendmailpic);
			echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
  			echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
  			echo "id=\"inputform_movie\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\">\n";
  			echo "<param name=\"movie\" value=\"$url_gfx/$sendmailpic\">\n";
  			echo "<param name=\"menu\" value=false>\n";
  			echo "<param name=\"quality\" value=\"high\">\n";
  			echo "<param name=\"wmode\" value=\"transparent\">\n";
  			echo "<param name=\"bgcolor\" value=\"$actionbgcolor\">\n";
  			echo "<embed name=\"inputform_movie\" src=\"$url_gfx/$sendmailpic\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$actionbgcolor\"\n";
			echo "width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"\n";
			echo "type=\"application/x-shockwave-flash\"\n";
    		echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
			echo "swLiveConnect=true\n";
  			echo "</embed>\n";
			echo "</object>\n";
		}
	}
	else
	{
		echo "<input class=\"sgbbutton\" type=\"submit\" value=\"$l_sendemail\">";
	}
?>
</td></tr>
</form>
</table></td></tr></table></div>
<?php
if($copyrightboxspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$copyrightboxspace\"></div>";
include_once('./includes/footer.inc');
}
?>
