<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
define( "BIT_0", 0 );
define( "BIT_1", 1 );
define( "BIT_2", 2 );
define( "BIT_3", 4 );
define( "BIT_4", 8 );
define( "BIT_5", 16 );
define( "BIT_6", 32 );
define( "BIT_7", 64 );
define( "BIT_8", 128 );
define( "BIT_9", 256 );
define( "BIT_10", 512 );
define( "BIT_11", 1024 );
define( "BIT_12", 2048 );
define( "BIT_13", 4096 );
define( "BIT_14", 8192 );
define( "BIT_15", 16384 );
define( "BIT_16", 32768 );
define( "BIT_17", 65536 );
define( "BIT_18", 131072 );
define( "BIT_19", 262144 );
define( "BIT_20", 524288 );
define( "BIT_21", 1048576 );
define( "BIT_22", 2097152 );
define( "BIT_23", 4194304 );
define( "BIT_24", 8388608 );
define( "BIT_25", 16777216 );
define( "BIT_26", 33554432 );
define( "BIT_27", 67108864 );
define( "BIT_28", 134217728 );
define( "BIT_29", 268435456 );
define( "BIT_30", 536870912 );
define( "BIT_31", 1073741824 );

function language_avail($checklang, $dirname="language/")
{
	$dir = opendir($dirname);
	$langfound=false;
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			if($file == $checklang)
				$langfound=true;
		}
	}
	return $langfound;
}

function get_avail_langs($dirname="language/")
{
	$avail_langs=array();
	$dir = opendir($dirname);
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			array_push($avail_langs,$file);
		}
	}
	return $avail_langs;
}

function dateToJuliandays($day, $month, $year)
{
	$juliandays = 367*$year - floor(7*($year+floor(($month+9)/12))/4)
      - floor(3*(floor(($year+($month-9)/7)/100)+1)/4)
      + floor(275*$month/9) + $day + 1721028.5 + 12/24;
    return $juliandays;
}

function juliandaysToDate($JD,$dateformat)
{
	$Z = $JD+0.5;
	$F = $Z - floor($Z);

	$Z = floor($Z);
	$W = floor(($Z - 1867216.25)/36524.25);
	$X = floor($W/4);
	$A = $Z + 1 + $W - $X;
	$B = $A + 1524;
	$C = floor(($B - 122.1)/365.25);
	$D = floor(365.25*$C);
	$E = floor(($B - $D)/30.6001);

	if($E>13)
		$NewMonth = $E-13;
	else
		$NewMonth = $E-1;
	$NewDay = $B - $D - floor(30.6001*$E) +$F;
	if($NewMonth<3)
		$NewYear = $C-4715;
	else
		$NewYear = $C-4716;
	$returndate=date($dateformat,mktime(0,0,0,$NewMonth,$NewDay,$NewYear));
	return $returndate;
}

function undo_htmlspecialchars($input,$doquotes=true)
{
	$input = preg_replace("/&gt;/i", ">", $input);
	$input = preg_replace("/&lt;/i", "<", $input);
	$input = preg_replace("/&quot;/i", "\"", $input);
	if($doquotes)
		$input = preg_replace("/&amp;/i", "&", $input);
	return $input;
}

function html_special_encode($input)
{
	$input = preg_replace("/\"/i", "&quot;", $input);
	return $input;
}

function do_htmlentities($input)
{
	global $encodecharset;
	if(phpversion() >= '4.3.0')
		$input=htmlentities($input,ENT_COMPAT,$encodecharset);
	else
		$input=htmlentities($input);
	return $input;
}

function do_htmlspecialchars($input)
{
	global $encodecharset;
	if(phpversion() >= '4.3.0')
		$input=htmlspecialchars($input,ENT_COMPAT,$encodecharset);
	else
		$input=htmlspecialchars($input);
	return $input;
}

function undo_htmlentities($input)
{
	global $encodecharset;
	if(phpversion() >= '4.3.0')
	{
		$input=html_entity_decode($input,ENT_COMPAT,$encodecharset);
	}
	else
	{
		$trans = get_html_translation_table (HTML_ENTITIES);
		$trans = array_flip($trans);
		$input=strtr($input,$trans);
	}
	return $input;
}

function validate_email($email)
{
	$email_regex="^([-!#\$%&'*+./0-9=?A-Z^_`a-z{|}~ ])+@([-!#\$%&'*+/0-9=?A-Z^_`a-z{|}~ ]+\\.)+[a-zA-Z]{2,4}\$";
	return(eregi($email_regex,$email)!=0);
}

function validate_icq($icq)
{
	$icq_regex="[a-zA-Z]";
	return(eregi($icq_regex,$icq)==0);
}

function get_start_tag($style)
{
	$start_tags=array("","<b>","<i>","<b><i>");
	return($start_tags[$style]);
}

function get_end_tag($style)
{
	$end_tags=array("","</b>","</i>","</i></b>");
	return($end_tags[$style]);
}

function forbidden_freemailer($email, $db)
{
	global $tableprefix;

	$sql="select * from ".$tableprefix."_freemailer";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if (!$myrow = mysql_fetch_array($result))
		return false;
	do{
		if(substr_count(strtolower($email), strtolower($myrow["address"]))>0)
			return true;
	} while($myrow = mysql_fetch_array($result));
	return false;
}

function escape_slashes($input)
{
	$output = str_replace('/', '\/', $input);
	return $output;
}

function isbanned($ipadr, $db)
{
	global $banprefix, $banreason, $tableprefix, $act_lang;

	$sql="select * from ".$banprefix."_banlist";
	if(!$result = mysql_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database (".$banprefix."_banlist)");
	if (!$myrow = mysql_fetch_array($result))
	{
		return false; exit;
	}
	do{
		if(ipinrange($ipadr,$myrow["ipadr"],$myrow["subnetmask"]))
		{
			$banreason=stripslashes($myrow["reason"]);
			$banreason = undo_htmlspecialchars($banreason);
			if(!$banreason)
			{
				$tmpsql="select * from ".$tableprefix."_texts where textid='defbr' and lang='$act_lang'";
				if(!$tmpresult = mysql_query($tmpsql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database (".$tableprefix."_texts)");
				if($tmprow=mysql_fetch_array($tmpresult))
				{
					$banreason=stripslashes($myrow["text"]);
					$banreason = undo_htmlspecialchars($banreason);
				}
			}
			return true;
		}
	}while($myrow = mysql_fetch_array($result));
	return false;
}

function ipinrange($network, $mask, $ip) {
    $ip_long=ip2long($ip);
    $network_long=ip2long($network);
    $mask_long=ip2long($mask);

    if (($ip_long & $mask_long) == $network_long) {
        return true;
    } else {
        return false;
    }
}

function bittst($bitfield, $bit)
{
        return ($bitfield & $bit);
}

function setbit($bitfield, $bit)
{
        $bitfield |= $bit;
        return($bitfield);
}

function clearbit($bitfield, $bit)
{
        $bitfield &= ~$bit;
        return($bitfield);
}

function language_select($default, $name="language", $dirname="language/", $suppresslang="", $doautosubmit=0, $formname="")
{
	$dir = opendir($dirname);
	$lang_select = "<SELECT class=\"sgbselect\" NAME=\"$name\"";
	if($doautosubmit==1)
		$lang_select.= " onchange=\"document.$formname.submit()\"";
	$lang_select.= ">\n";
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			if(!$suppresslang || ($file!=$suppresslang))
			{
				$file == $default ? $selected = " SELECTED" : $selected = "";
				$lang_select .= "  <OPTION value=\"$file\"$selected>$file</option>\n";
			}
		}
	}
	$lang_select .= "</SELECT>\n";
	closedir($dir);
	return $lang_select;
}

function layout_select($default, $name, $tableprefix, $db)
{
	$sql = "select distinct id from ".$tableprefix."_layout order by id asc";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if(!$myrow=mysql_fetch_array($result))
		return;
	echo "<select class=\"sgbselect\" name=\"$name\">";
	do{
		echo "<option value=\"".$myrow["id"]."\"";
		if($myrow["id"]==$default)
			echo " selected";
		echo ">".$myrow["id"]."</option>";
	}while($myrow=mysql_fetch_array($result));
	echo "</select>\n";
}

function remove_htmltags($input)
{
	$temp = "";
	$add=true;
	for ($i = 0; $i < strlen($input); $i++)
	{
		if (substr($input, $i, 1) == "<")
			$add = false;
		if ($add)
			$temp .= substr($input, $i, 1);
		if (substr($input, $i, 1) == ">")
			$add = true;
	}
	return $temp;
}

function remove_htmltags_encode($input)
{
	$temp = "";
	$add=true;
	$input=stripslashes($input);
	for ($i = 0; $i < strlen($input); $i++)
	{
		if (substr($input, $i, 1) == "<")
			$add = false;
		if ($add)
			$temp .= substr($input, $i, 1);
		if (substr($input, $i, 1) == ">")
			$add = true;
	}
	$temp=strip_tags($temp);
	return addslashes($temp);
}

function get_userip()
{
	global $REMOTE_ADDR, $db, $tableprefix, $new_global_handling;

	$sql = "select * from ".$tableprefix."_settings where settingnr=1";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if($myrow=mysql_fetch_array($result))
	{
		$try_real_ip=$myrow["tryrealip"];
		$realipmode=$myrow["realipmode"];
	}
	else
	{
		$try_real_ip=0;
		$realipmode=0;
	}

	if($try_real_ip)
	{
		if($realipmode==0)
			$ip=get_real_ip_0();
		else
			$ip=get_real_ip_1();
	}
	else
		$ip = $REMOTE_ADDR;
	return $ip;
}

function get_real_ip_0()
{
	global $new_global_handling;

	if($new_global_handling)
		$realip = isset($_SERVER['x_forwarded_for']) ? $_SERVER['x_forwarded_for'] : $_SERVER['remote_addr'];
	else
		$realip = isset($HTTP_SERVER_VARS['x_forwarded_for']) ? $HTTP_SERVER_VARS['x_forwarded_for'] : $HTTP_SERVER_VARS['remote_addr'];
	return $realip;
}

function get_real_ip_1()
{
	global $REMOTE_ADDR;

	if( getenv('HTTP_X_FORWARDED_FOR') != '' )
		$realip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
	else
		$realip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
}

function is_flash_file($check_filename)
{
	$fileext=strrchr($check_filename,".");
	if(!$fileext)
		return false;
	$fileext=strtolower(substr($fileext,1));
	if($fileext=="swf")
		return true;
	return false;
}

function get_file($filename)
{
	$return = "";
	if($fp = fopen($filename, 'rb'))
	{
		while(!feof($fp)){
			$return .= fread($fp, 1024);
		}
		fclose($fp);
		return $return;
	}
	else
	{
		return FALSE;
	}
}

function is_gecko()
{
	global $HTTP_USER_AGENT;

	if (eregi('Konqueror.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (eregi("Netscape6",$HTTP_USER_AGENT))
		return false;
	if (eregi("Gecko",$HTTP_USER_AGENT) ||
		eregi("Mozilla/5",$HTTP_USER_AGENT))
		return true;
	return false;
}

function is_konqueror()
{
	global $HTTP_USER_AGENT;

	if (eregi('Konqueror.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_ns6()
{
	global $HTTP_USER_AGENT;

	if (eregi("Netscape6",$HTTP_USER_AGENT))
		return true;
	return false;
}

function is_ns4()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Opera.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
	{
		list($major,$minor)=explode(".",$log_version[1]);
		if($major=="4")
			return true;
	}
	return false;
}

function is_ns3()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Opera.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
	{
		list($major,$minor)=explode(".",$log_version[1]);
		if($major=="3")
			return true;
	}
	return false;
}

function is_msie3()
{
	if(!is_msie())
		return false;
	if(get_browser_version()>=4)
		return false;
	return true;
}

function is_opera()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'Opera.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_msie()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_win()
{
	global $HTTP_USER_AGENT;

    if (preg_match('/(win[dows]*)[\s]?([0-9a-z]*)[\w\s]?([a-z0-9.]*)/i',$HTTP_USER_AGENT))
    	return true;
    return false;
}

function get_browser_version()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
	    return($log_version[1]);
	elseif (ereg( 'Opera ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
    elseif (ereg( 'Netscape6/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
    elseif (ereg( 'Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
	else
		return(0);
}

function adms4maildefined()
{
	global $tableprefix, $db;

	$sql="select * from ".$tableprefix."_adm_mail";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(mysql_num_rows($result)>0)
		return true;
	return false;
}

function is_leacher($useragent)
{
	global $leacherprefix, $db;

	$sql="select * from ".$leacherprefix."_leachers";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database (is_leacher).");
	while($myrow=mysql_fetch_array($result))
	{
		if(strstr ($useragent, $myrow["useragent"]))
			return true;
	}
	return false;
}

function sortorder_select($default, $name, $sortorders)
{
	echo "<select class=\"sgbselect\" name=\"$name\">";
	for($i=0;$i<count($sortorders);$i++)
	{
		echo "<option value=\"".$i."\"";
		if($i==$default)
			echo " selected";
		echo ">".$sortorders[$i]."</option>";
	}
	echo "</select>\n";
}

function undo_html_ampersand($input)
{
	$input = preg_replace("/&amp;/i", "&", $input);
	return $input;
}

function is_daylight_savings($gmtime, $DSTStart = '', $DSTEnd = '')
{
	if(!$DSTStart || !$DSTEnd)
		return false;

	$DSTStart = split(":",$DSTStart);
	$DSTEnd = split(":",$DSTEnd);

	$gmtMonth = date("n",$gmtime);
	if ($gmtMonth < $DSTStart[2] || $gmtMonth > $DSTEnd[2])
		return false;
 	else if(($gmtMonth > $DSTStart[2]) && ($gmtMonth < $DSTEnd[2]))
		return true;
	else
	{
		if ($gmtMonth == $DSTStart[2])
		{
			$True = true;
			$week = $DSTStart[0];
			$ImportantDay = $DSTStart[1];
		}
		else
		{
			$True = false;
			$week = $DSTEnd[0];
			$ImportantDay = $DSTEnd[1];
		}
		$gmtDay = date("j",$gmtime);
		if(!$week)
		{
			$gmtDay=date("d",$gmtime);
			if($gmtDay>=$week)
				return($True);
			else
				return(!$True);
		}
		if ($week == 'L')
		{
			$week = 4;
			$ldom = 4;//last day of month factor
		}
		//if the week in which it starts/ends has not been reached
		if($gmtDay < ($week-1)*7)
			return (!$True);
		else
		{
			$gmtDate = getdate($gmtime);
			//go by a Day of the Week Basis
			for ($i=($week-1)*7;$i<(($week*7)+$ldom);$i++)
			{
				$checkDate = mktime(0,0,0,$gmtDate["mon"],$i,$gmtDate["year"]);
				//get the actual day it starts/ends
				if (date("D",$checkDate) == "Sun" && date("n",$checkDate) == $gmtMonth )
					$day = date("j",$checkDate);
			}
		}
		if ($gmtDay < $day)
			return (!$True);
		else
			return $True;
	}
}

function calctzoffset($offset_str)
{
	$sign = substr($offset_str, 0, 1);
	$hours = substr($offset_str, 1, 2);
	$mins = substr($offset_str, 3, 2);
	$secs = ((int)$hours * 3600) + ((int)$mins * 60);
	if ($sign == '-') $secs = 0 - $secs;
	return $secs;
}

function transposetime($origtime,$origtz,$desttz)
{
	global $timezones;

	$now=time();
	if(is_daylight_savings($now,$timezones[$origtz][3],$timezones[$origtz][4]))
		$origoffset=calctzoffset($timezones[$origtz][2]);
	else
		$origoffset=calctzoffset($timezones[$origtz][1]);
	$gmtime=$origtime-$origoffset;
	if(is_daylight_savings($now,$timezones[$desttz][3],$timezones[$desttz][4]))
		$destoffset=calctzoffset($timezones[$desttz][2]);
	else
		$destoffset=calctzoffset($timezones[$desttz][1]);
	$desttime=$gmtime+$destoffset;
	return $desttime;
}

function tzgmtoffset($tz)
{
	global $timezones;

	$now=time();
	if(is_daylight_savings($now,$timezones[$tz][3],$timezones[$tz][4]))
		$offset=calctzoffset($timezones[$tz][2]);
	else
		$offset=calctzoffset($timezones[$tz][1]);
	if(substr(timezonename($tz),0,3)=="GMT")
		return("");
	$gmtoffset="GMT";
	if($offset!=0)
	{
		$offsethours=abs(floor($offset/60/60));
		$offsetmins=abs((abs($offset)-($offsethours*60*60))/60);
		if($offset<0)
			$gmtoffset.="-";
		else
			$gmtoffset.="+";
		$gmtoffset.=$offsethours;
		if($offsetmins>0)
			$gmtoffset.=sprintf("%02d",$offsetmins);
	}
	return $gmtoffset;
}

function timezonename($tz)
{
	global $timezones;

	$now=time();
	if(is_daylight_savings($now,$timezones[$tz][3],$timezones[$tz][4]))
		return ($timezones[$tz][6]);
	else
		return($timezones[$tz][5]);
}

function emailencode($email)
{
	$encodedemail="";
	for($i=0;$i<strlen($email);$i++)
	{
		$encodedemail.="&#".ord($email[$i]).";";
	}
	return $encodedemail;
}

function getRealFileExtension($filename)
{
	return ereg( ".([^\.]+)$", $filename, $r ) ? $r[1] : "";
}

function getRealFilename($filename)
{
	$tmpext=".".getRealFileExtension($filename);
	$tmpfilename=str_replace($tmpext,"",$filename);
	return($tmpfilename);

}

function display_encoded($input)
{
	$input = undo_html_ampersand(do_htmlentities(stripslashes($input)));
	return $input;
}

function is_phpfile($filename)
{
	global $php_fileext;
	$fileext=strrchr($filename,".");
	if(!$fileext)
		return false;
	$fileext=strtolower(substr($fileext,1));
	if(in_array($fileext,$php_fileext))
		return true;
	return false;
}
function file_output($filename)
{
	$filedata=get_file($filename);
	if($filedata)
		echo $filedata;
}
?>