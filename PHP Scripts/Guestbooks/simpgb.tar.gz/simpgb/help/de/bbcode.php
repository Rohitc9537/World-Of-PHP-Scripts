<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$act_lang="de";
require_once('../../config.php');
require_once($path_simpgb.'/functions.php');
include_once($path_simpgb.'/includes/get_layout.inc');
$bbcmarkcolor="blau";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<?php
if(is_ns4() && $ns4style)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$ns4style."\" type=\"text/css\">\n";
else if(is_ns6() && $ns6style)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$ns6style."\" type=\"text/css\">\n";
else if(is_opera() && $operastyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$operastyle."\" type=\"text/css\">\n";
else if(is_konqueror() && $konquerorstyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$konquerorstyle."\" type=\"text/css\">\n";
else if(is_gecko() && $geckostyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$geckostyle."\" type=\"text/css\">\n";
else
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$stylesheet."\" type=\"text/css\">\n";
?>
<style type="text/css">
<!--
.rainbow {
  behavior:url(../../rainbow.htc)
}
<?php
echo "body {\r\n";
echo "	font-family: $contentfont;\r\n";
echo "	color: $contentfontcolor;\r\n";
echo "}\r\n";
?>
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>SimpGB - BBCode Hilfe</title>
</head>
<body bgcolor="<?php echo $pagebgcolor?>">
<table width="95%" align="center">
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Verwendung von BBCode / Was ist BBCode?</b></font>
</td>
</tr>
<tr bgcolor="<?php echo $contentbgcolor?>">
<td>
<font size="<?php echo $contentfontsize?>">BBCode ist eine Variante von HTML-Tags, die Sie vielleicht schon kennen. Grunds&auml;tzlich k&ouml;nnen Sie mit BBCode
Formatierungen in Ihren Text einbringen, die normalerweise HTML erfordern w&uuml;rden, so zum Beispiel <b>Fettdruck</b>.
BBCode ist eine Alternative zu HTML-Code, weil BBCode weniger Fachwissen ben&ouml;tigt und sicherer zu benutzen ist.
Eventuell falsche Syntax wird Ihre Seite nicht unleserlich machen.<br>
Die Verwendung von BBCode ist bei allen Eingabefeldern m&ouml;glich, bei denen sich ein Link zu dieser Hilfe befindet.<br>
<i>Hinweis: Die BBCodes k&ouml;nnen durch die Administratioren einzeln deaktiviert werden, so dass nicht bei jeder Installation von
SimpGB die gleichen BBCodes zur Verf&uuml;gung stehen m&uuml;ssen. Diese Hilfe beschreibt nur die hier auch aktivierten BBCodes.</i><br><br>
<table border="0" cellpadding="0" cellspacing="0" width="100%" align="CENTER"><TR><td bgcolor="<?php echo $bordercolor?>">
<table border="0" cellpadding="4" cellspacing="1" width="100%">
<?php
if(bittst($allowedbbcodes,BIT_14))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Verweise auf Internetadressen (URLs) einbinden</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
Falls <i>URLs automatisch umwandeln</i> f&uuml;r die Adminoberfl&auml;che aktiviert ist, brauchen Sie nicht mehr den [URL]-Code, um einen Hyperlink zu erzeugen.
Schreiben Sie einfach den kompletten Link auf eine der folgenden Wege und der Hyperlink wird automatisch erstellt.
Sie k&ouml;nnen so in Ihrem Beitrag ganz einfach auf eine beliebige andere Internetseite verweisen, die dann durch einen
einfachen Klick erreichbar ist:</font>
<UL>
<LI><span class="example">http://www.foo.de</span>
<LI><span class="example">www.foo.com</span>
</UL>
<font size="<?php echo $contentfontsize?>">
Benutzen Sie entweder die komplette http:// -Adresse oder k&uuml;rzen Sie mit www. ab. Wenn die Seite, auf die Sie
verweisen m&ouml;chten, nicht mit www. beginnt, m&uuml;ssen Sie die komplette URL http:// verwenden.
Sie k&ouml;nnen auch https:// oder ftp:// -Adressen in Links verwenden.
<br><br>
Der alte [URL]-Code funktioniert weiterhin, wie weiter unten beschrieben.
Umklammern Sie einfach den Link wie folgt (BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> markiert).
<br><br></font><center>
<span class="bbcexample">[url]</span><font size="<?php echo $contentfontsize?>">www.foo.de</font><span class="bbcexample">[/url]</span>
<P></center>
<font size="<?php echo $contentfontsize?>">
Auch richtige Hyperlinks k&ouml;nnen Sie mit dem [url]-Code einbinden. Das Format ist:
</font>
<BR><br><center>
<span class="bbcexample">[url=http://www.foo.de]</span>foo.de<span class="bbcexample">[/url]</span>
</center><p>
<font size="<?php echo $contentfontsize?>">In den bisher genannten Beispielen erzeugt BBCode automatsich einen Hyperlink zur umklammerten URL (Internetadresse).
BBCode stellt auch sicher, dass der link in einem neuen Fenster ge&ouml;ffnet wird, wenn der Besucher auf den Link klickt.
Beachten Sie, dass der Teil &quot;http://&quot; der URL optional ist. Mit dem zweiten der obigen Beispiele k&ouml;nnen Sie die URL zu einer
beliebigen Seite lenken, die nach dem Gleichheitszeichen steht.
Bitte beachten Sie, dass Sie innerhalb der URL-Adresse KEINE Anf&uuml;hrungszeichen verwenden.
</font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_13))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>email-Adressen einbinden</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Um eine email-Adresse innerhalb Ihrer Nachricht anzugeben, umklammern Sie die Adresse wie im folgenden Beispiel:
(BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> markiert).
<br><br>
</font>
<CENTER><font size="<?php echo $contentfontsize?>">
<span class="bbcexample">[email]</span>bar@foo.de<span class="bbcexample">[/email]</span>
</CENTER>
<br><br>
<font size="<?php echo $contentfontsize?>">In diesem Beispiel erzeugt BBCode daraus einen Link, der automatisch das email-Programm des Besuchers startet, um
an <i>bar@foo.de</i> eine Email schreiben zu k&ouml;nnen.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_15))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>RealAudio einbinden</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Um eine RealAudio Datei innerhalb Ihrer Nachricht abzuspielen, umklammern Sie die Adresse der Datei wie im folgenden Beispiel:
(BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> markiert).
<br><br>
</font>
<CENTER><font size="<?php echo $contentfontsize?>">
<span class="bbcexample">[realaudio]</span>rtsp://www.foo.bar/audio.ram<span class="bbcexample">[/realaudio]</span></font>
</CENTER>
<br><br>
<font size="<?php echo $contentfontsize?>">In diesem Beispiel bindet BBCode die Audiodatei automatisch in Ihren Beitrag ein. Beachten Sie bitte, dass der
"rtsp://" -Teil der URL f&uuml;r das  <span class="bbcexample">[realaudio]</span>-Tag unverzichtbar ist.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_27))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Windowsmedia einbinden</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Um eine Windowsmedia Datei innerhalb Ihrer Nachricht abzuspielen, umklammern Sie die Adresse der Datei wie im folgenden Beispiel:
(BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> markiert).
<br><br>
</font>
<CENTER><font size="<?php echo $contentfontsize?>">
<span class="bbcexample">[stream]</span>http://www.foo.bar/audio.wma<span class="bbcexample">[/stream]</span></font>
</CENTER>
<br><br>
<font size="<?php echo $contentfontsize?>">In diesem Beispiel bindet BBCode die Audiodatei automatisch in Ihren Beitrag ein. Beachten Sie bitte, dass der
"http://" -Teil der URL f&uuml;r das  <span class="bbcexample">[stream]</span>-Tag unverzichtbar ist.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_7))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Bilder hinzuf&uuml;gen</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Verwenden Sie einfach den [img]-Code wie im folgenden Beispiel, um ein Bild in Ihren Text einzubinden.
 (BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> dargestellt).
<br><br>
<CENTER>
<span class="bbcexample">[img]</span>http://www.foo.bar/images/bild.gif<span class="bbcexample">[/img]</span>
</CENTER>
<br><br>
In diesem Beispiel bindet BBCode das Bild automatisch in Ihren Beitrag ein. Beachten Sie bitte, dass der
"http://" -Teil der URL f&uuml;r das  <span class="bbcexample">[img]</span>-Tag unverzichtbar ist.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_16))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>SWF-Dateien einbinden</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Verwenden Sie einfach den [swf]-Code wie im folgenden Beispiel, um eine Flashanimation in Ihren Text einzubinden.
 (BBCode ist <span class="bbcexample"><?php echo $bbcmarkcolor?></span> dargestellt).
<br><br>
<CENTER>
<span class="bbcexample">[swf width=244 height=39]</span>http://www.foo.bar/animation.swf<span class="bbcexample">[/swf]</span>
</CENTER>
<br><br>
In diesem Beispiel bindet BBCode die Animation automatisch in Ihren Beitrag ein. Beachten Sie bitte, dass der
"http://" -Teil der URL f&uuml;r das  <span class="bbcexample">[swf]</span>-Tag unverzichtbar ist.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_1))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Fettdruck</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit den [b] [/b] - Markierungen (Tags) <b>fettdrucken</b>
<br><br>
</font><CENTER>
<font size="<?php echo $contentfontsize?>">Hello, <span class="bbcexample">[b]</span><B>Tom</B><span class="bbcexample">[/b]</span></font>
</CENTER>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_2))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Kursivschrift</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit den [i] [/i] - Markierungen (Tags) <i>schr&auml;gstellen</i>
<br><br>
<CENTER>
Hello, <span class="bbcexample">[i]</span><I>Jerry</I><span class="bbcexample">[/i]</span></font>
</CENTER>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_5))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Sub- und Superscript</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit den [sub] [/sub] oder [sup] [/sup] - Markierungen (Tags) <sub>tief</sub> oder <sup>hoch</sup> stellen.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[sub]</span><sub>Tom</sub><span class="bbcexample">[/sub]</span><BR>
Hello, <span class="bbcexample">[sup]</span><sup>Jerry</sup><span class="bbcexample">[/sup]</span></font>
</CENTER></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_3))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Durchgestrichener Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen mit den [s] [/s] - Markierungen (Tags) durchgestrichenen Text erzeugen.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[s]</span><s>Tom</s><span class="bbcexample">[/s]</span></font>
</CENTER></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_4))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Typewriter Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen mit den [tt] [/tt] - Markierungen (Tags) Text in <tt>Schreibmaschinenart</tt> erzeugen.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[tt]</span><tt>Tom</tt><span class="bbcexample">[/tt]</span></font>
</CENTER></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_6))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Zentrierter Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit [center] [/center] - Markierungen (Tags) zentrieren.
<br><br>
Hello, <span class="bbcexample">[center]</span>Tom<span class="bbcexample">[/center]</span><br>
erzeugt:<br>
Hello, <center>Tom</center></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_18))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Textausrichtung &auml;ndern</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen die Textausrichtung mit den [align=ausrichtung] [/align] - Markierungen (Tags)&auml;ndern.
<br><br>
Hello, <span class="bbcexample">[align=right]</span>Tom<span class="bbcexample">[/align]</span><br>
erzeugt:<br>
Hello, <p align=right>Tom</p></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_11))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Textgr&ouml;sse &auml;ndern</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen mit den [size=gr&ouml;sse] [/size] - Markierungen (Tags) die Textgr&ouml;sse &auml;ndern.
<br><br><center>
Hello, <span class="bbcexample">[size=5]</span><Font size="5">Tom</font><span class="bbcexample">[/size]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_17))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Zeichensatz &auml;ndern</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen mit den [font=zeichensatz] [/font] - Markierungen (Tags) den Zeichensatz &auml;ndern.
<br><br><center>
Hello, <span class="bbcexample">[font=Comic Sans MS]</span><Font face="Comic Sans MS">Tom</font><span class="bbcexample">[/font]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_12))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Farbiger Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit [color=farbe] [/color] - Markierungen (Tags) farbig darstellen
<br><br>
<CENTER>
Hello, <span class="bbcexample">[color=green]</span><FONT COLOR="green">Tom</Font><span class="bbcexample">[/font]</span><BR>
Hello, <span class="bbcexample">[color=yellow]</span><font color="yellow">Jerry</font><span class="bbcexample">[/font]</span>
</CENTER></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_10))
{
?>
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Aufz&auml;hlungen</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen auch Listen mit Aufz&auml;hlungspunkten (Punkt oder Zahl) erzeugen:
<br><br>
Liste mit Aufz&auml;hlungspunkten:
<br><br>
<span class="bbcexample">[list]</span><BR>
<span class="bbcexample">[*]</span> Dieses ist der erste Streich.<BR>
<span class="bbcexample">[*]</span> Und der zweite folgt sogleich.<BR>
<span class="bbcexample">[/list]</span>
<br><br>
Dies erzeugt:
<ul>
<LI>Dieses ist der erste Streich.</li>
<LI>Und der zweite folgt sogleich.</li>
</ul>
Beachten Sie, dass Sie jede Liste mit [/list] abschliessen m&uuml;ssen.
<br><br>
Numerierte Listen sind genauso einfach. Schreiben Sie einfach [LIST=A] oder [LIST=1].
[List=A] erzeugt eine Liste, die von A bis Z numeriert ist, [List=1] erzeugt eine numerierte Liste.
<br><br>
Hier ein Beispiel:
<br><br>
<span class="bbcexample">[list=A]</span><BR>
<span class="bbcexample">[*]</span> Dieses ist der erste Streich.<BR>
<span class="bbcexample">[*]</span> Und der zweite folgt sogleich.<BR>
<span class="bbcexample">[/list]</span>
<br><br>
Dies erzeugt:
<ol type=A>
<LI>Dieses ist der erste Streich.</li>
<LI>Und der zweite folgt sogleich.</li>
</ul>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_9))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Zitieren</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Um etwas zu zitieren umklammern Sie das Zitat wie folgt:
(BBCode ist wieder <span class="bbcexample">blau</span> markiert).
<P>
<CENTER>
<span class="bbcexample">[QUOTE]</span>Dies ist ein Zitat<span class="bbcexample">[/QUOTE]</span>
</CENTER>
<P>
In diesem Beispiel r&uuml;ckt BBCode diesen Text als Zitat ein.</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_8))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Code Tag</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">&Auml;hnlich wie beim "Quote"-Tag [QUOTE] k&ouml;nnen Sie mit dem [CODE] Tag den Zeilenumbruch erhalten.
Das ist bei der Wiedergabe von Gedichten oder von Programmcode sinnvoll.
<br><br>
<span class="bbcexample">[CODE]</span>#!/usr/bin/perl
<br><br>
print "Content-type: text/html\n\n";
<BR>
print "Hallo Welt!";
<span class="bbcexample">[/CODE]</span>
<br><br>
In diesem Beispiel r&uuml;ckt BBCode den Text als Zitat ein und erh&auml;lt zus&auml;tzlich den
Zeilenumbruch.
</FONT></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_19) || bittst($allowedbbcodes,BIT_20))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Text scrollen</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text entweder vertikal oder horizontal scrollen lassen (Ergebnis nur bei
Benutzung des Internetexplorers sichtbar).<br>
<?php
if(bittst($allowedbbcodes,BIT_19))
{
?>
F&uuml;r vertikales scrollen benutzen Sie [updown][/updown]<br>
<?php
}
if(bittst($allowedbbcodes,BIT_20))
{
?>
F&uuml;r horizontales [scroll][/scroll].
<?php
}
?>
<br><br>
<?php
if(bittst($allowedbbcodes,BIT_19))
{
?>
<span class="bbcexample">[updown]</span>tom<span class="bbcexample">[/updown]</span><br>
<marquee behavior=scroll direction=up scrollamount=1 height=60>tom</marquee>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_20))
{
?>
<span class="bbcexample">[scroll]</span>jerry<span class="bbcexample">[/scroll]</span><br>
<marquee>jerry</marquee>
<?php
}
?>
</FONT></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_21) || bittst($allowedbbcodes,BIT_22) || bittst($allowedbbcodes,BIT_23) || bittst($allowedbbcodes,BIT_24) || bittst($allowedbbcodes,BIT_25) || bittst($allowedbbcodes,BIT_26) || bittst($allowedbbcodes,BIT_28))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Spezialeffekte f&uuml;r Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD>
<font size="<?php echo $contentfontsize?>">Sie k&ouml;nnen Text mit verschiedenen Spezialeffekten versehen (Ergebnis nur bei
Benutzung des Internetexplorers sichtbar).<br><br>
<?php
if(bittst($allowedbbcodes,BIT_21))
{
?>
<b>Fading Text:</b><br>
<span class="bbcexample">[fade]</span>tom<span class="bbcexample">[/fade]</span><br>
<span style="height:1; filter:alpha(opacity=100, finishopacity=0, style=1, startx=0, finishx=100%)">tom</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_22))
{
?>
<b>gespiegelter Text:</b><br>
<span class="bbcexample">[flip=v]</span>jerry<span class="bbcexample">[/flip]</span><br>
<span style="filter: flipv; height:1">jerry</span><br>
<span class="bbcexample">[flip=h]</span>donald<span class="bbcexample">[/flip]</span><br>
<span style="filter: fliph; height:1">donald</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_23))
{
?>
<b>gl&uuml;hender Text:</b><br>
<span class="bbcexample">[glow]</span>goofy<span class="bbcexample">[/glow]</span><br>
<span style="filter:glow(color=#ffff99); height:20">goofy</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_24))
{
?>
<b>Text mit Schatten:</b><br>
<span class="bbcexample">[shadow=yellow]</span>feuerstein<span class="bbcexample">[/shadow]</span><br>
<span style="filter:shadow(color=yellow); height:20">feuerstein</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_25))
{
?>
<b>Text mit Verwischeffeckt:</b><br>
<span class="bbcexample">[blur]</span>dino<span class="bbcexample">[/blur]</span><br>
<span style="height: 20; filter:blur(add=1,direction=270,strength=10)">dino</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_26))
{
?>
<b>Text mit Schlagschatten:</b><br>
<span class="bbcexample">[dropshadow=yellow]</span>wilma<span class="bbcexample">[/dropshadow]</span><br>
<span style="height:20; filter:dropshadow(color=yellow, offx=3, offy=3)">wilma</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_28))
{
?>
<b>Regenbogentext:</b><br>
<span class="bbcexample">[rainbow=red]</span>fred<span class="bbcexample">[/rainbow]</span><br>
<table border="1" bordercolor="red" style="border-collapse: collapse" cellpadding="8" cellpadding="0"><tr><td bgcolor="#000000"><b><SPAN class="rainbow">fred</SPAN></b></td></tr></table>
<?php
}
?>
</FONT>
</td></tr>
<?php
}
?>
</table>
</td></tr></table></td></tr></table>
</body>
</html>