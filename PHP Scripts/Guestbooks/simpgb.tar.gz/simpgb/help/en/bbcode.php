<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$act_lang="en";
require_once('../../config.php');
require_once($path_simpgb.'/functions.php');
include_once($path_simpgb.'/includes/get_layout.inc');
$bbcmarkcolor="blue";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<?php
if(is_ns4() && $ns4style)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$ns4style."\" type=\"text/css\">\n";
else if(is_ns6() && $ns6style)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$ns6style."\" type=\"text/css\">\n";
else if(is_opera() && $operastyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$operastyle."\" type=\"text/css\">\n";
else if(is_konqueror() && $konquerorstyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$konquerorstyle."\" type=\"text/css\">\n";
else if(is_gecko() && $geckostyle)
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$geckostyle."\" type=\"text/css\">\n";
else
	echo"<link rel=stylesheet href=\"".$url_simpgb."/".$stylesheet."\" type=\"text/css\">\n";
?>
<style type="text/css">
<!--
.rainbow {
  behavior:url(../../rainbow.htc)
}
<?php
echo "body {\r\n";
echo "	font-family: $contentfont;\r\n";
echo "	color: $contentfontcolor;\r\n";
echo "}\r\n";
?>
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>SimpGB - BBCode Help</title>
</head>
<body bgcolor="<?php echo $pagebgcolor?>">
<table width="95%" align="center">
<tr bgcolor="<?php echo $headingbgcolor?>"><td>
<font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Using BB Code</b></font>
</td>
</tr>
<tr bgcolor="<?php echo $contentbgcolor?>">
<td>
<font size="<?php echo $contentfontsize?>">BBCode is a variation on the HTML tags you may already be familiar with.
Basically, it allows you to add functionality or style to your message that would normally require HTML.
You may want to use BBCode, because there is less coding required and it is safer to use (incorrect coding syntax will not lead to as many problems).
<br>
You can use BBCode for all textareas, where a link to this help is placed.<br>
<i>Please note: Admins can disable any BBCode, so not all installations of SimpGB will support all
BBCodes available. This help only will describe the BBCodes admin has enabled for this installation of SimpGB.</i></font><br><br>
<table border="0" cellpadding="0" cellspacing="0" width="100%" align="CENTER"><TR><td bgcolor="<?php echo $bordercolor?>">
<table border="0" cellpadding="4" cellspacing="1" width="100%">
<?php
if(bittst($allowedbbcodes,BIT_14))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>URL Hyperlinking</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
If <i>automatically encode URL</i> is enabled for the administration interface,you no longer need to use the [URL] code to create a hyperlink.
Simply type the complete URL in either of the following manners and the hyperlink will be created automatically:
</font>
<UL>
<LI><span class="example">http://www.foo.de</span>
<LI><span class="example">www.foo.com</span>
</UL>
<font size="<?php echo $contentfontsize?>">
Notice that you can either use the complete http:// address or shorten it to the www domain.
If the site does not begin with &quot;www&quot;, you must use the complete &quot;http://&quot; address.
Also, you may use https and ftp URL prefixes in auto-link mode.
<br><br>
The old [URL] code will still work, as detailed below.
Just encase the link as shown in the following example (BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br><center>
<span class="bbcexample">[url]</span>www.foo.de<span class="bbcexample">[/url]</span>
<P></center>
You can also have true hyperlinks using the [url] code.  Just use the following format:
<BR><br><center>
<span class="bbcexample">[url=http://www.foo.de]</span>foo.de<span class="bbcexample">[/url]</span>
</center><p>
In the examples above, the BBCode automatically generates a hyperlink to the URL that is encased.
It will also ensure that the link is opened in a new window when the user clicks on it.
Note that the &quot;http://&quot; part of the URL is completely optional.
In the second example above, the URL will hypelink the text to whatever URL you provide after the equal sign.
 Also note that you should NOT use quotation marks inside the URL tag.
</font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_13))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Email Links</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To add a hyperlinked email address within your message, just encase the email address as shown in the following example
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[email]</span>bar@foo.de<span class="bbcexample">[/email]</span>
</CENTER>
<P>
In the example above, the BBCode automatically generates a hyperlink to the email address that is encased.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_15))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Adding realaudio files</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To add a realaudio file within your message, just encase the URL of the audiofile as shown in the following example
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[realaudio]</span>rtsp://www.foo.bar/audio.ram<span class="bbcexample">[/realaudio]</span>
</CENTER>
<br><br>
In the example above, the BBCode automatically makes the audiofile play on your message.  Note: the &quot;rtsp://&quot; part of the URL is REQUIRED for the <span class="bbcexample">[realaudio]</span> code.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_27))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Adding windowsmedia files</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To add a windowsmedia file within your message, just encase the URL of the audiofile as shown in the following example
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[stream]</span>http://www.foo.bar/audio.wma<span class="bbcexample">[/stream]</span>
</CENTER>
<br><br>
In the example above, the BBCode automatically makes the audiofile play on your message.  Note: the &quot;http://&quot; part of the URL is REQUIRED for the <span class="bbcexample">[stream]</span> code.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_16))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Adding Flash animations</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To add a Flash animation (SWF file) within your message, just encase the URL of the animation as shown in the following example
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[swf width=244 height=39]</span>http://www.foo.bar/animation.swf<span class="bbcexample">[/swf]</span>
</CENTER>
<br><br>
In the example above, the BBCode automatically makes the animation visible in your message.  Note: the &quot;http://&quot; part of the URL is REQUIRED for the <span class="bbcexample">[swf]</span> code.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_7))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Adding Images</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To add a graphic within your message, just encase the URL of the graphic image as shown in the following example
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[img]</span>http://www.foo.bar/images/image.gif<span class="bbcexample">[/img]</span>
</CENTER>
<br><br>
In the example above, the BBCode automatically makes the graphic visible in your message.  Note: the &quot;http://&quot; part of the URL is REQUIRED for the <span class="bbcexample">[img]</span> code.
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_1))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Bold</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make text bold by encasing the applicable sections of your text with the [b] [/b] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[b]</span><B>Tom</B><span class="bbcexample">[/b]</span>
</CENTER></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_2))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Italics</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make italicized text by encasing the applicable sections of your text with the [i] [/i] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[i]</span><I>Jerry</I><span class="bbcexample">[/i]</span>
</CENTER></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_5))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>sub and super script</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make text sub or super script by encasing the applicable sections of your text with either the [sub] [/sub] or [sup] [/sup] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[sub]</span><sub>Tom</sub><span class="bbcexample">[/sub]</span><BR>
Hello, <span class="bbcexample">[sup]</span><sup>Jerry</sup><span class="bbcexample">[/sup]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_3))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>strike through text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make strike through text by encasing the applicable sections of your text with the [s] [/s] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[s]</span><s>Jerry</s><span class="bbcexample">[/s]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_4))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>typewriter text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make diplay text in typewriter style by encasing the applicable sections of your text with the [tt] [/tt] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[tt]</span><tt>Jerry</tt><span class="bbcexample">[/tt]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_6))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>centered text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can center text by encasing the applicable sections of your text with the [center] [/center] tags.
<br><br>
Hello, <span class="bbcexample">[center]</span>Jerry<span class="bbcexample">[/center]</span><br>
Will produce:<br>
Hello, <center>Jerry</center></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_18))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>changing alignment</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can change alignment of text by encasing the applicable sections of your text with the [align=alignment] [/align] tags.
<br><br>
Hello, <span class="bbcexample">[align=right]</span>Jerry<span class="bbcexample">[/align]</span><br>
Will produce:<br>
Hello, <p align=right>Jerry</p></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_11))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>change textsize</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can change textsize by encasing the applicable sections of your text with the [size=size] [/size] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[size=5]</span><font size="5">Jerry</font><span class="bbcexample">[/size]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_17))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>change fontface</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can change fontface by encasing the applicable sections of your text with the [font=fontface] [/font] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[font=Comic Sans MS]</span><Font face="Comic Sans MS">Tom</font><span class="bbcexample">[/font]</span>
</CENTER></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_12))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Color Text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make colored text by encasing the applicable sections of your text with [color=color] [/color] tags.
<br><br>
<CENTER>
Hello, <span class="bbcexample">[color=green]</span><FONT COLOR="green">Tom</Font><span class="bbcexample">[/font]</span><BR>
Hello, <span class="bbcexample">[color=yellow]</span><font color="yellow">Jerry</font><span class="bbcexample">[/font]</span>
</CENTER></font>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_10))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Bullets</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can make bulleted lists or ordered lists (by number or letter).
<br><br>
Unordered, bulleted list:
<br><br>
<span class="bbcexample">[list]</span><BR>
<span class="bbcexample">[*]</span>This is the first bulleted item.<BR>
<span class="bbcexample">[*]</span>This is the second bulleted item.<BR>
<span class="bbcexample">[/list]</span>
<br><br>
This produces:
<ul>
<LI>This is the first bulleted item.
<LI>This is the second bulleted item.
</ul>
Note that you must include a closing [/list] when you end each list.
<br><br>
Making ordered lists is just as easy.  Just add either [LIST=A] or [LIST=1].  Typing [List=A] will produce a list from A to Z.  Using [List=1] will produce numbered lists.
<br><br>
Here's an example:
<br><br>
<span class="bbcexample">[list=A]</span><BR>
<span class="bbcexample">[*]</span> This is the first bulleted item.<BR>
<span class="bbcexample">[*]</span> This is the second bulleted item.<BR>
<span class="bbcexample">[/list]</span>
<br><br>
This produces:
<ol type=A>
<LI>This is the first bulleted item.
<LI>This is the second bulleted item.
</ul></font></td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_9))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Quoting</b></font></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
To reference something specific enclose it as shown below
(BBCode is in <span class="bbcexample"><?php echo $bbcmarkcolor?></span>).
<br><br>
<CENTER>
<span class="bbcexample">[QUOTE]</span>Ask not what your country can do for you....<BR>ask what you can do for your country.<span class="bbcexample">[/QUOTE]</span>
</CENTER>
<br><br>
In the example above, the BBCode automatically blockquotes the text you reference.</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_8))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Code Tag</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
Similar to the Quote tage, the Code tag adds some &lt;PRE&gt; tags to preserve formatting.  This useful for displaying programming code, for instance.
<br><br>
<span class="bbcexample">[CODE]</span>#!/usr/bin/perl
<br>
print "Content-type: text/html\n\n";
<BR>
print "Hello World!";
<span class="bbcexample">[/CODE]</span>
<br><br>
In the example above, the BBCode automatically blockquotes the text you reference and preserves the formatting of the coded text.</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_19) || bittst($allowedbbcodes,BIT_20))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>Scroller</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can let text scroll vertical or horizontal (Result only visible for users of InternetExplorer).<br>
<?php
if(bittst($allowedbbcodes,BIT_19))
{
?>
For a vertical scroller use [updown][/updown]<br>
<?php
}
if(bittst($allowedbbcodes,BIT_20))
{
?>
For a horizontal [scroll][/scroll].
<?php
}
?>
<br><br>
<?php
if(bittst($allowedbbcodes,BIT_19))
{
?>
<span class="bbcexample">[updown]</span>tom<span class="bbcexample">[/updown]</span><br>
<marquee behavior=scroll direction=up scrollamount=1 height=60>tom</marquee>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_20))
{
?>
<span class="bbcexample">[scroll]</span>jerry<span class="bbcexample">[/scroll]</span><br>
<marquee>jerry</marquee>
<?php
}
?>
</FONT>
</td></tr>
<?php
}
if(bittst($allowedbbcodes,BIT_21) || bittst($allowedbbcodes,BIT_22) || bittst($allowedbbcodes,BIT_23) || bittst($allowedbbcodes,BIT_24) || bittst($allowedbbcodes,BIT_25) || bittst($allowedbbcodes,BIT_26) || bittst($allowedbbcodes,BIT_28))
{
?>
<TR bgcolor="<?php echo $headingbgcolor?>"><TD>
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<b>special effects for text</b></FONT></td></tr>
<TR bgcolor="<?php echo $contentbgcolor?>"><TD><font size="<?php echo $contentfontsize?>">
You can do various special effects on text (Result only visible for users of InternetExplorer).<br>
<?php
if(bittst($allowedbbcodes,BIT_21))
{
?>
<b>Fading text:</b><br>
<span class="bbcexample">[fade]</span>tom<span class="bbcexample">[/fade]</span><br>
<span style="height:1; filter:alpha(opacity=100, finishopacity=0, style=1, startx=0, finishx=100%)">tom</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_22))
{
?>
<b>flipped text:</b><br>
<span class="bbcexample">[flip=v]</span>jerry<span class="bbcexample">[/flip]</span><br>
<span style="filter: flipv; height:1">jerry</span><br>
<span class="bbcexample">[flip=h]</span>donald<span class="bbcexample">[/flip]</span><br>
<span style="filter: fliph; height:1">donald</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_23))
{
?>
<b>glowing text:</b><br>
<span class="bbcexample">[glow]</span>goofy<span class="bbcexample">[/glow]</span><br>
<span style="filter:glow(color=#ffff99); height:20">goofy</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_24))
{
?>
<b>Text with shadow:</b><br>
<span class="bbcexample">[shadow=yellow]</span>flintstone<span class="bbcexample">[/shadow]</span><br>
<span style="filter:shadow(color=yellow); height:20">flintstone</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_25))
{
?>
<b>Text with blur:</b><br>
<span class="bbcexample">[blur]</span>dino<span class="bbcexample">[/blur]</span><br>
<span style="height: 20; filter:blur(add=1,direction=270,strength=10)">dino</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_26))
{
?>
<b>Text with dropshadow:</b><br>
<span class="bbcexample">[dropshadow=yellow]</span>wilma<span class="bbcexample">[/dropshadow]</span><br>
<span style="height:20; filter:dropshadow(color=yellow, offx=3, offy=3)">wilma</span>
<br><br>
<?php
}
if(bittst($allowedbbcodes,BIT_28))
{
?>
<b>Rainbowtext:</b><br>
<span class="bbcexample">[rainbow=red]</span>fred<span class="bbcexample">[/rainbow]</span><br>
<table border="1" bordercolor="red" style="border-collapse: collapse" cellpadding="8" cellpadding="0"><tr><td bgcolor="#000000"><b><SPAN class="rainbow">fred</SPAN></b></td></tr></table>
<?php
}
?>
</FONT>
</td></tr>
<?php
}
?>
</table>
</td></tr></table></td></tr></table>
</body>
</html>