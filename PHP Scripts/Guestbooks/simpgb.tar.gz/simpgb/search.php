<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('./config.php');
require_once('./functions.php');
$local_flash=array("backform","searchform","helpform");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("no such language available $act_lang");
include_once('./language/lang_'.$act_lang.'.php');
header('Pragma: no-cache');
header('Expires: 0');
$db_dateformat="Y-m-d H:i:s";
if((@fopen("./config.php", "a")) && !$noseccheck)
{
	die($l_config_writeable);
}
require_once('./includes/get_layout.inc');
require_once('./includes/block_leacher.inc');
if($blockoldbrowser==1)
{
	if(is_ns3() || is_msie3())
	{
		$sql="select * from ".$tableprefix."_texts where textid='oldbrowser' and lang='$act_lang'";
		if(!$result = mysql_query($sql, $db))
		    die("Could not connect to the database.");
		if($myrow = mysql_fetch_array($result))
			echo undo_htmlspecialchars($myrow["text"]);
		else
			echo $l_oldbrowser;
		exit;
	}
}
include_once('./includes/date_selectors.inc');
$banreason="";
$actdate = date("Y-m-d H:i:00");
if($lastvisitcookie==1)
{
	$expiretime = $lastvisitdays * 24 * 60 * 60;
	$thiscookie=$cookiename."[lastvisit]";
	if(isset($_COOKIE[$cookiename]))
	{
		$cookiedata=$_COOKIE[$cookiename];
		$cookiedate=$cookiedata["lastvisit"];
		if($cookiedate && (strpos($cookiedate,"-")>0))
		{
			list($mydate,$mytime)=explode(" ",$cookiedate);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			$lastvisitdate=mktime($hour,$min,0,$month,$day,$year);
			if((time()-$lastvisitdate)>($lastvisitsessiontime*60))
				setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
		}
		else
			setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
	}
	else
	{
		setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
		$lastvisitdate=time()-($lastvisitdefhours*60*60);
	}
}
else
	$lastvisitdate=time()-($lastvisitdefhours*60*60);
if(!isset($start))
	$start=0;
if(!isset($startday))
	$startday=date("d");
if(!isset($startmonth))
	$startmonth=date("m");
if(!isset($startyear))
	$startyear=date("Y");
$startdate=$startyear."-".$startmonth."-".$startday;
if(!isset($endday))
	$endday=date("d");
if(!isset($endmonth))
	$endmonth=date("m");
if(!isset($endyear))
	$endyear=date("Y");
$enddate=$endyear."-".$endmonth."-".$endday;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="generator" content="SimpGB v<?php echo $version?>, <?php echo $copyright_asc?>">
<meta name="fid" content="b073e76b30344b970271303a892b1d91">
<?php
$pagetitle=$l_searchguestbook;
if(file_exists("metadata.php"))
	include_once("metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_searchguestbook?></title>
<?php
}
if(is_ns4() && $ns4style)
	echo"<link rel=stylesheet href=\"$ns4style\" type=\"text/css\">\n";
else if(is_ns6() && $ns6style)
	echo"<link rel=stylesheet href=\"$ns6style\" type=\"text/css\">\n";
else if(is_opera() && $operastyle)
	echo"<link rel=stylesheet href=\"$operastyle\" type=\"text/css\">\n";
else if(is_konqueror() && $konquerorstyle)
	echo"<link rel=stylesheet href=\"$konquerorstyle\" type=\"text/css\">\n";
else if(is_gecko() && $geckostyle)
	echo"<link rel=stylesheet href=\"$geckostyle\" type=\"text/css\">\n";
else
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">\n";
if(is_msie())
{
	echo "<SCRIPT LANGUAGE=\"VBScript\">\n<!--\n";
	for($i=0;$i<count($local_flash);$i++)
	{
?>
Sub <?php echo $local_flash[$i]?>_movie_FSCommand(ByVal command, ByVal args)
    call <?php echo $local_flash[$i]?>_movie_DoFSCommand(command, args)
end sub
<?php
	}
	echo "// -->\n</script>\n";
}
?>
<script type="text/javascript" language="javascript">
function enable_datesels(enable)
{
	document.searchform.startday.disabled=!enable;
	document.searchform.startmonth.disabled=!enable;
	document.searchform.startyear.disabled=!enable;
	document.searchform.endday.disabled=!enable;
	document.searchform.endmonth.disabled=!enable;
	document.searchform.endyear.disabled=!enable;
}
</script>
<script type="text/javascript" language="JavaScript">
<?php
echo "<!--\n";
for($i=0;$i<count($local_flash);$i++)
{
?>
function <?php echo $local_flash[$i]?>_movie_DoFSCommand(command, args) {
	if (command == "submitform") {
		document.<?php echo $local_flash[$i]?>.submit();
}
}
<?php
}
echo "// -->\n</script>\n";
include_once("./includes/styles.inc");
?>
</head>
<body bgcolor="<?php echo $pagebgcolor?>" text="<?php echo $contentfontcolor?>">
<?php
if($enablesearch==0)
	die($l_functiondisabled);
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
		if(($customheader) && ($cheadnobr==0))
			echo "<br>\n";
	}
	if($customheader)
		echo "$customheader\n";
	if(($headerfile) && ($headerfilepos==1))
	{
		if(($customheader) && ($cheadnobr==0))
			echo "<br>\n";
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="99%"><a name="#top"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $l_searchguestbook?></b></font></a></td>
<td align="center" valign="middle" width="1%">
<form name="backform" action="guestbook.php" method="post">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="layout" value="<?php echo $layout?>">
<input type="hidden" name="start" value="<?php echo $start?>">
<?php
	if($backpic)
	{
		if(!is_flash_file($backpic))
		{
			$imagesize = GetImageSize ($path_gfx."/".$backpic);
			echo "<a href=\"javascript:document.backform.submit();\"><img src=\"$url_gfx/$backpic\" border=\"0\" align=\"absmiddle\" title=\"$l_back\" alt=\"$l_back\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"></a>";
		}
		else
		{
			$imagesize = GetImageSize ($path_gfx."/".$backpic);
			echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
  			echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
  			echo "id=\"backform_movie\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\">\n";
  			echo "<param name=\"movie\" value=\"$url_gfx/$backpic\">\n";
  			echo "<param name=\"menu\" value=false>\n";
  			echo "<param name=\"quality\" value=\"high\">\n";
  			echo "<param name=\"wmode\" value=\"transparent\">\n";
  			echo "<param name=\"bgcolor\" value=\"$headingbgcolor\">\n";
  			echo "<embed name=\"backform_movie\" src=\"$url_gfx/$backpic\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$headingbgcolor\"\n";
			echo "width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"\n";
			echo "type=\"application/x-shockwave-flash\"\n";
    		echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
			echo "swLiveConnect=true\n";
  			echo "</embed>\n";
			echo "</object>\n";
		}
	}
	else
		echo "<input class=\"sgbbutton\" type=\"submit\" value=\"$l_back\">";
?>
</form></td></tr>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
?>
</td></tr></table>
<?php
		include('./includes/footer.inc');
		exit;
	}
}
if(!isset($searchvalues))
	$searchvalues="";
?>
</table></td></tr></table></div>
<?php
	if($headerspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$headerspace\"></div>";
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr bgcolor="<?php echo $contentbgcolor?>"><td align="center" colspan="3">
<form name="searchform" method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="mode" value="search">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="layout" value="<?php echo $layout?>">
<input type="hidden" name="category" value="<?php echo $category?>">
<input type="hidden" name="start" value="<?php echo $start?>">
<input class="sgbinput" type="text" name="searchvalues" value="<?php echo $searchvalues?>" size="40" maxlength="255">&nbsp;&nbsp;
<?php
	if($searchpic)
	{
		if(!is_flash_file($searchpic))
		{
			$imagesize = GetImageSize ($path_gfx."/".$searchpic);
			echo "<a href=\"javascript:document.searchform.submit();\"><img src=\"$url_gfx/$searchpic\" border=\"0\" align=\"absmiddle\" title=\"$l_search\" alt=\"$l_search\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"></a>";
		}
		else
		{
			$imagesize = GetImageSize ($path_gfx."/".$searchpic);
			echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
  			echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
  			echo "id=\"searchform_movie\"> width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"\n";
  			echo "<param name=\"movie\" value=\"$url_gfx/$searchpic\">\n";
  			echo "<param name=\"menu\" value=false>\n";
  			echo "<param name=\"quality\" value=\"high\">\n";
  			echo "<param name=\"wmode\" value=\"transparent\">\n";
  			echo "<param name=\"bgcolor\" value=\"$headingbgcolor\">\n";
  			echo "<embed name=\"searchform_movie\" src=\"$url_gfx/$searchpic\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$headingbgcolor\"\n";
			echo "width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"\n";
			echo "type=\"application/x-shockwave-flash\"\n";
    		echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
			echo "swLiveConnect=true\n";
  			echo "</embed>\n";
			echo "</object>\n";
		}
	}
	else
		echo "<input class=\"sgbbutton\" type=\"submit\" value=\"$l_search\">";
?>
<br>
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php echo $l_searchon?>:
<input class="sgbcheckbox" type="checkbox" name="searchentries" value="1" <?php if(isset($searchentries)) echo "checked"?>><?php echo $l_searchentries?>
<input class="sgbcheckbox" type="checkbox" name="searchcomments" value="1" <?php if(isset($searchcomments)) echo "checked"?>><?php echo $l_searchcomments?>
<input class="sgbcheckbox" type="checkbox" name="searchusernames" value="1" <?php if(isset($searchusernames)) echo "checked"?>><?php echo $l_searchusernames?>
<tr bgcolor="<?php echo $contentbgcolor?>"><td align="right" valign="top" width="20%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<input class="sgbcheckbox" type="checkbox" value="1" name="timeframe" onClick="enable_datesels(document.searchform.timeframe.checked)" <?php if(isset($timeframe)) echo "checked"?>>
<?php echo $l_betweendate?>:</font></td>
<td><table width="100%" align="left" bgcolor="<?php echo $bordercolor?>" cellspacing="1" cellpadding="0">
<tr bgcolor="<?php echo $contentbgcolor?>"><td align="left" width="50%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<i><?php echo $l_startdate?>:</i>
</font></td>
<td align="left" width="50%">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<i><?php echo $l_enddate?>:</i>
</font></td></tr><tr>
<td>
<table width="100%" height="100%" bgcolor="<?php echo $contentbgcolor?>" cellspacing="0" cellpadding="0">
<?php
echo "<tr>";
for($i=0;$i<count($l_dateselformat);$i++)
{
	echo "<td bgcolor=\"$contentbgcolor\" align=\"center\" width=\"15%\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	if($l_dateselformat[$i]=="day")
		echo $l_day;
	if($l_dateselformat[$i]=="month")
		echo $l_month;
	if($l_dateselformat[$i]=="year")
		echo $l_year;
	echo "</font></td>";
}
echo "<td width=\"55%\"></td>";
echo "</tr><tr><td colspan=\"3\"><hr width=\"100%\"></td></tr>\n";
for($i=0;$i<count($l_dateselformat);$i++)
{
	echo "<td bgcolor=\"$contentbgcolor\" align=\"center\" width=\"15%\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	if($l_dateselformat[$i]=="day")
		echo day_selector("startday",$startdate,isset($timeframe));
	if($l_dateselformat[$i]=="month")
		echo month_selector("startmonth",$startdate,isset($timeframe));
	if($l_dateselformat[$i]=="year")
		echo year_selector("startyear",$startdate,isset($timeframe));
	echo "</font></td>\n";
}
echo "<td width=\"55%\"></td>";
?>
</tr></table></td>
<td>
<table width="100%" height="100%" bgcolor="<?php echo $contentbgcolor?>" cellspacing="0" cellpadding="0">
<?php
echo "<tr>";
for($i=0;$i<count($l_dateselformat);$i++)
{
	echo "<td bgcolor=\"$contentbgcolor\" align=\"center\" width=\"15%\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	if($l_dateselformat[$i]=="day")
		echo $l_day;
	if($l_dateselformat[$i]=="month")
		echo $l_month;
	if($l_dateselformat[$i]=="year")
		echo $l_year;
	echo "</font></td>";
}
echo "<td width=\"55%\"></td>";
echo "</tr><tr><td colspan=\"3\"><hr width=\"100%\"></td></tr>\n";
for($i=0;$i<count($l_dateselformat);$i++)
{
	echo "<td bgcolor=\"$contentbgcolor\" align=\"center\" width=\"15%\">";
	if($l_dateselformat[$i]=="day")
		echo day_selector("endday",$enddate,isset($timeframe));
	if($l_dateselformat[$i]=="month")
		echo month_selector("endmonth",$enddate,isset($timeframe));
	if($l_dateselformat[$i]=="year")
		echo year_selector("endyear",$enddate,isset($timeframe));
	echo "</td>";
}
echo "<td width=\"55%\"></td>";
?>
</table></td></tr></table></td></form>
<td align="center" valign="middle">
<form name="helpform" action="<?php echo "help/$act_lang/search.php"?>" method="get" target="_blank">
<input type="hidden" name="layout" value="<?php echo $layout?>">
<?php
	if($helppic)
	{
		if(!is_flash_file($helppic))
		{
			$imagesize = GetImageSize ($path_gfx."/".$helppic);
			echo "<a href=\"javascript:document.helpform.submit();\"><img src=\"$url_gfx/$helppic\" border=\"0\" align=\"absmiddle\" title=\"$l_help\" alt=\"$l_help\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"></a>";
		}
		else
		{
			$imagesize = GetImageSize ($path_gfx."/".$helppic);
			echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
  			echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
  			echo "id=\"helpform_movie\" width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\">\n";
  			echo "<param name=\"movie\" value=\"$url_gfx/$helppic\">\n";
  			echo "<param name=\"menu\" value=false>\n";
  			echo "<param name=\"quality\" value=\"high\">\n";
  			echo "<param name=\"wmode\" value=\"transparent\">\n";
  			echo "<param name=\"bgcolor\" value=\"$headingbgcolor\">\n";
  			echo "<embed name=\"helpform_movie\" src=\"$url_gfx/$helppic\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$headingbgcolor\"\n";
			echo "width=\"".$imagesize[0]."\" height=\"".$imagesize[1]."\"\n";
			echo "type=\"application/x-shockwave-flash\"\n";
    		echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
			echo "swLiveConnect=true\n";
  			echo "</embed>\n";
			echo "</object>\n";
		}
	}
	else
		echo "<input class=\"sgbbutton\" type=\"submit\" value=\"$l_help\">";
?>
</form>
</td></tr>
</table></td></tr>
<?php
if(isset($mode))
{
$searchvalues=trim($searchvalues);
$searchvalues=do_htmlentities($searchvalues);
$searchvalues=undo_htmlspecialchars($searchvalues);
$cansearch=0;
if(isset($searchentries))
	$cansearch=1;
if(isset($searchcomments))
	$cansearch=1;
if(isset($searchusernames))
	$cansearch=1;
echo "</table></div>";
if($actionboxspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$actionboxspace\"></div>";
echo "<div align=\"$tblalign\">";
echo "<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"$tblalign\" class=\"sgbtable\">";
if( !$searchvalues && !isset($timeframe) || ($searchvalues && ($cansearch==0)))
{
?>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<td align="center">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php echo $l_nosearchcriteria?>
</font></td></tr></table></td></tr></table></div>
<?php
if($copyrightboxspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$copyrightboxspace\"></div>";
include_once('./includes/footer.inc');
exit;
}
?>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $l_result?></b></font></td></tr>
</table></td></tr></table></div>
<?php
$sql = "select dat.* from ".$tableprefix."_data dat, ".$tableprefix."_search search where dat.validated=1 and search.entrynr=dat.entrynr and ";
if($separatebylang==1)
	$sql.="dat.language='$act_lang' and ";
if(isset($timeframe))
{
	$s_startdate=$startdate." 00:00";
	list($mydate,$mytime)=explode(" ",$s_startdate);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min) = explode(":",$mytime);
	$temptime=mktime($hour,$min,0,$month,$day,$year);
	$temptime=transposetime($temptime,$displaytimezone,$servertimezone);
	$s_startdate=date($db_dateformat,$temptime);

	$s_enddate=$enddate." 23:59";
	list($mydate,$mytime)=explode(" ",$s_enddate);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min) = explode(":",$mytime);
	$temptime=mktime($hour,$min,0,$month,$day,$year);
	$temptime=transposetime($temptime,$displaytimezone,$servertimezone);
	$s_enddate=date($db_dateformat,$temptime);

	$sql.= "dat.date >= '$s_startdate' and dat.date <= '$s_enddate' ";
}
$musts=array();
$cans=array();
$nots=array();
$searchcriterias=0;
$hassearchterms=false;
$searchvalues=trim($searchvalues);
$searchterms = explode(" ",$searchvalues);
foreach($searchterms as $searchstring)
{
	$qualifier=substr($searchstring,0,1);
	if($qualifier=='-')
	{
		$tmpnot=trim(substr($searchstring,1,strlen($searchstring)-1));
		if($tmpnot)
		{
			array_push($nots,$tmpnot);
			$hassearchterms=true;
		}
	}elseif ($qualifier=='+')
	{
		$tmpmust=trim(substr($searchstring,1,strlen($searchstring)-1));
		if($tmpmusts)
		{
			array_push($musts,$tmpmusts);
			$hassearchterms=true;
		}
	}
	else
	{
		$tmpcan=trim($searchstring);
		if($tmpcan)
		{
			array_push($cans,$tmpcan);
			$hassearchterms=true;
		}
	}
}
if($hassearchterms)
{
	if(isset($timeframe))
		$sql.="and ";
	$sql.="(";
}
if(isset($searchentries))
{
	$first=1;
	$sql.="(";
	if(count($musts)>0)
	{
		$sql .="(";
		$searchcriterias++;
		for($i=0;$i<count($musts);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(";
			$sql.="search.text like '%".$musts[$i]."%'";
			$sql.=")";;
		}
		$sql .=")";
	}
	$first=1;
	if(count($nots)>0)
	{
		if($searchcriterias>0)
			$sql .=" and ";
		else
			$sql.="(";
		$searchcriterias++;
		for($i=0;$i<count($nots);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(search.text not like '%".$nots[$i]."%')";
		}
		$sql .=")";
	}
	$first=1;
	if((count($cans)>0) && (count($musts)<1))
	{
		if($searchcriterias>0)
			$sql .=" and ";
		else
			$sql .="(";
		$searchcriterias++;
		for($i=0;$i<count($cans);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" or ";
			$sql.="(search.text like '%".$cans[$i]."%')";
		}
		$sql .=")";
	}
	$sql.=")";
}
if(isset($searchcomments))
{
	$local_searchcriterias=0;
	if($searchcriterias>0)
		$sql.=" or ";
	$first=1;
	$sql.="(";
	if(count($musts)>0)
	{
		$sql .="(";
		$searchcriterias++;
		$local_searchcriterias++;
		for($i=0;$i<count($musts);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(search.comment like '%".$musts[$i]."%')";
		}
		$sql .=")";
	}
	$first=1;
	if(count($nots)>0)
	{
		if($local_searchcriterias>0)
			$sql .=" and ";
		else
			$sql.="(";
		$searchcriterias++;
		$local_searchcriterias++;
		for($i=0;$i<count($nots);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(search.comment not like '%".$nots[$i]."%')";
		}
		$sql .=")";
	}
	$first=1;
	if((count($cans)>0) && (count($musts)<1))
	{
		if($local_searchcriterias>0)
			$sql .=" and ";
		else
			$sql .="(";
		$local_searchcriterias++;
		$searchcriterias++;
		for($i=0;$i<count($cans);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" or ";
			$sql.="(search.comment like '%".$cans[$i]."%')";
		}
		$sql .=")";
	}
	$sql.=")";
}
if(isset($searchusernames))
{
	$local_searchcriterias=0;
	if($searchcriterias>0)
		$sql.=" or ";
	$first=1;
	$sql.="(";
	if(count($musts)>0)
	{
		$sql .="(";
		$searchcriterias++;
		$local_searchcriterias++;
		for($i=0;$i<count($musts);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(dat.poster like '%".$musts[$i]."%')";
		}
		$sql .=")";
	}
	$first=1;
	if(count($nots)>0)
	{
		if($local_searchcriterias>0)
			$sql .=" and ";
		else
			$sql.="(";
		$searchcriterias++;
		$local_searchcriterias++;
		for($i=0;$i<count($nots);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" and ";
			$sql.="(dat.poster not like '%".$nots[$i]."%')";
		}
		$sql .=")";
	}
	$first=1;
	if((count($cans)>0) && (count($musts)<1))
	{
		if($local_searchcriterias>0)
			$sql .=" and ";
		else
			$sql .="(";
		$searchcriterias++;
		$local_searchcriterias++;
		for($i=0;$i<count($cans);$i++)
		{
			if($first==1)
				$first=0;
			else
				$sql .=" or ";
			$sql.="(dat.poster like '%".$cans[$i]."%')";
		}
		$sql .=")";
	}
	$sql.=")";
}
if($searchcriterias>0)
	$sql.=")";
$sql.= " group by dat.entrynr order by dat.date desc";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.<br>".mysql_error()."<br>".$sql);
$numentries=mysql_numrows($result);
if($maxentries>0)
{
	if(!isset($start))
		$start=0;
	if($actionboxspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" width=\"1\" height=\"$actionboxspace\"></div>";
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sgbtable">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
	echo "<TR BGCOLOR=\"$headingbgcolor\" ALIGN=\"CENTER\">";
	echo "<TD ALIGN=\"CENTER\" VALIGN=\"MIDDLE\" colspan=\"2\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$headingfontcolor\">";
	if(isset($searchstart) && ($searchstart>0) && ($numentries>$maxentries))
	{
		$sql .=" limit $searchstart,$maxentries";
	}
	else
	{
		$sql .=" limit $maxentries";
		$searchstart=0;
	}
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(mysql_num_rows($result)>0)
	{
		if(($maxentries+$searchstart)>$numentries)
			$displayresults=$numentries;
		else
			$displayresults=($maxentries+$start);
		$displaystart=$searchstart+1;
		$displayend=$displayresults;
		echo "<b>$l_page ".ceil(($searchstart/$maxentries)+1)."/".ceil(($numentries/$maxentries))."</b><br><b>($l_entries $displaystart - $displayend $l_of $numentries)</b>";
	}
	else
		echo "&nbsp;";
	echo "</font></td></tr>";
}
if(($maxentries>0) && ($numentries>$maxentries))
{
	echo "<tr bgcolor=\"$headingbgcolor\"><td align=\"center\" colspan=\"2\">";
	echo "<font face=\"$headingfont\" size=\"1\" color=\"$headingfontcolor\"><b>$l_page</b> ";
	if(floor(($searchstart+$maxentries)/$maxentries)>1)
	{
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=0&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_first)
			echo "<img src=\"$url_gfx/$pagepic_first\" border=\"0\" align=\"absmiddle\" title=\"$l_page_first\" alt=\"$l_page_first\">";
		else
			echo "<b>[&lt;&lt;]</b>";
		echo "</a> ";
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".($searchstart-$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_prev)
			echo "<img src=\"$url_gfx/$pagepic_prev\" border=\"0\" align=\"absmiddle\" title=\"$l_page_back\" alt=\"$l_page_back\">";
		else
			echo "<b>[&lt;]</b>";
		echo "</a> ";
	}
	for($i=1;$i<($numentries/$maxentries)+1;$i++)
	{
		if(floor(($searchstart+$maxentries)/$maxentries)!=$i)
		{
			echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".(($i-1)*$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
			if(isset($searchentries))
				echo "&amp;searchentries=1";
			if(isset($searchcommentss))
				echo "&amp;searchcomments=1";
			if(isset($searchusernames))
				echo "&amp;searchusernames=1";
			echo "\"><b>[$i]</b></a> ";
		}
		else
			echo "<b>($i)</b> ";
	}
	if($searchstart < (($i-2)*$maxentries))
	{
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".($searchstart+$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_fwd)
			echo "<img src=\"$url_gfx/$pagepic_fwd\" border=\"0\" align=\"absmiddle\" title=\"$l_page_forward\" alt=\"$l_page_forward\">";
		else
			echo "<b>[&gt;]</b>";
		echo "</a> ";
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".(($i-2)*$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_last)
			echo "<img src=\"$url_gfx/$pagepic_last\" border=\"0\" align=\"absmiddle\" title=\"$l_page_last\" alt=\"$l_page_last\">";
		else
			echo "<b>[&gt;&gt;]</b>";
		echo "</a> ";
	}
	echo "</font></td></tr>";
}
echo "</table></td></tr></table></div>";
if($pagenavspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$pagenavspace\"></div>";
echo "<div align=\"$tblalign\">";
echo "<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"$tblalign\" class=\"sgbtable\">";
echo "<tr><TD BGCOLOR=\"$bordercolor\">";
echo "<TABLE BORDER=\"0\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"100%\">";
echo "<tr><td align=\"center\" colspan=\"2\"><table width=\"100%\" align=\"center\" bgcolor=\"$contentbgcolor\" cellspacing=\"0\" cellpadding=\"0\">\n";
if(mysql_numrows($result)==0)
{
	echo "<tr bgcolor=\"$contentbgcolor\"><td align=\"center\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	echo "$l_noentries";
	echo "</font></td></tr>";
}
include_once("./includes/userbox.inc");
while($myrow=mysql_fetch_array($result))
{
	list($mydate,$mytime)=explode(" ",$myrow["date"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	if($month>0)
		$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
	else
		$displaydate="";
	$gendertext="";
	$genderpic="";
	if($myrow["gender"])
	{
		if($myrow["gender"]=="m")
		{
			$genderpic=$malepic;
			$gendertext=$l_male;
		}
		else
		{
			$genderpic=$femalepic;
			$gendertext=$l_female;
		}
	}
	$countryname="";
	$countryflag="";
	if($myrow["country"])
	{
		$countryname=$myrow["country"];
		$tempsql="select * from ".$tableprefix."_flags where country='".$myrow["country"]."'";
		if(!$tempresult = mysql_query($tempsql, $db))
		    die("Unable to connect to database.".mysql_error());
		if($temprow=mysql_fetch_array($tempresult))
			$countryflag=$temprow["image"];
	}
	list($mydate,$mytime)=explode(" ",$myrow["date"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	$thisentrydate=mktime($hour,$min,$sec,$month,$day,$year);
	$isnewentry=$thisentrydate>=$lastvisitdate;
	switch($userinfopos)
	{
		case 0:
			display_poster_line($posterbgcolor, $posterfont, $posterfontsize, $posterfontcolor, $myrow["poster"], $countryflag, $countryname, $myrow["useragent"], $myrow["homepage"], $myrow["posteremail"], $myrow["icq"], $url_gfx, $browserpic, $homepagepic, $icqpic, $emailpic, $l_poster, $url_flags, $l_sendicqmsg, $l_visithomepage, $l_sendemail, $gotoppic, $l_gotop, $genderpic, $gendertext, $myrow["aim"], $aimpic, $l_altaim, $posterpic, $myrow["avatar"], $url_avatars, $myrow["msnm"], $msnmpic, $myrow["yim"], $yimpic, $l_yimlabel, $myrow["location"], $myrow["company"], $companypic, $l_company, $newentrypic, $isnewentry);
			break;
		case 3:
			echo "<tr bgcolor=\"$contentbgcolor\"><td bgcolor=\"$contentbgcolor\">\n";
			echo "<table width=\"100%\" height=\"100%\" bgcolor=\"$contentbgcolor\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">\n";
			break;
		case 2:
			echo "<tr bgcolor=\"$contentbgcolor\">\n";
			display_poster_box($posterbgcolor, $posterfont, $posterfontsize, $posterfontcolor, $myrow["poster"], $countryflag, $countryname, $myrow["useragent"], $myrow["homepage"], $myrow["posteremail"], $myrow["icq"], $url_gfx, $browserpic, $homepagepic, $icqpic, $emailpic, $l_poster, $url_flags, $l_sendicqmsg, $l_visithomepage, $l_sendemail, "left", $bordercolor, $gotoppic, $l_gotop, $genderpic, $gendertext, $myrow["aim"], $aimpic, $l_altaim, $posterpic, $myrow["avatar"], $url_avatars, $myrow["msnm"], $msnmpic, $myrow["yim"], $yimpic, $l_yimlabel, $myrow["location"], $myrow["company"], $companypic, $l_company, $newentrypic, $isnewentry, $picturepic, $myrow["userpic"], $l_userpic, $allowinternalmailer, $start);
			echo "\n<td bgcolor=\"$contentbgcolor\">";
			echo "<table width=\"100%\" height=\"100%\" bgcolor=\"$contentbgcolor\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">\n";
			break;
	}
	if($userinfopos!=2)
		echo "<tr bgcolor=\"$timestampbgcolor\">";
	echo "<td align=\"left\"";
	if($userinfopos<2)
		echo " colspan=\"2\"";
	echo ">\n";
	echo "<font face=\"$timestampfont\" size=\"$timestampfontsize\" color=\"$timestampfontcolor\">\n";
	echo get_start_tag($timestampstyle);
	echo $displaydate;
	echo get_end_tag($timestampstyle);
	echo "</font></td></tr>\n";
	if(strlen($myrow["heading"])>0)
	{
		echo "<tr bgcolor=\"$entryheadingbgcolor\"><td align=\"left\"";
		if($userinfopos<2)
			echo " colspan=\"2\"";
		echo ">\n";
		echo "<font face=\"$entryheadingfont\" size=\"$entryheadingfontsize\" color=\"$entryheadingfontcolor\">\n";
		echo get_start_tag($entryheadingstyle);
		echo do_htmlentities($myrow["heading"]);
		echo get_end_tag($entryheadingstyle);
		echo "</font></td></tr>\n";
	}
	echo "<tr bgcolor=\"$contentbgcolor\"><td align=\"left\"";
	if($userinfopos<2)
		echo " colspan=\"2\"";
	echo ">\n";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">\n";
	$displaytext=stripslashes($myrow["text"]);
	$displaytext = undo_htmlspecialchars($displaytext);
	$displaytext = str_replace("{contentbgcolor}",$contentbgcolor,$displaytext);
	$displaytext = str_replace("{contentfontcolor}",$contentfontcolor,$displaytext);
	$displaytext = str_replace("{contentfont}",$contentfont,$displaytext);
	$displaytext = str_replace("{contentfontsize}",$contentfontsize,$displaytext);
	$displaytext = str_replace("{bbc_quote}",$l_bbc_quote,$displaytext);
	$displaytext = str_replace("{bbc_code}",$l_bbc_code,$displaytext);
	echo $displaytext."</font></td></tr>\n";
	if($userinfopos==1)
		display_poster_line($posterbgcolor, $posterfont, $posterfontsize, $posterfontcolor, $myrow["poster"], $countryflag, $countryname, $myrow["useragent"], $myrow["homepage"], $myrow["posteremail"], $myrow["icq"], $url_gfx, $browserpic, $homepagepic, $icqpic, $emailpic, $l_poster, $url_flags, $l_sendicqmsg, $l_visithomepage, $l_sendemail, $gotoppic, $l_gotop, $genderpic, $gendertext, $myrow["aim"], $aimpic, $l_altaim, $posterpic, $myrow["avatar"], $url_avatars, $myrow["msnm"], $msnmpic, $myrow["yim"], $yimpic, $l_yimlabel, $myrow["location"], $myrow["company"], $companypic, $l_company, $newentrypic, $isnewentry);
	if($myrow["modcomment"])
	{
		list($mydate,$mytime)=explode(" ",$myrow["commentdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
		echo "<tr bgcolor=\"$modcommentbgcolor\"><td align=\"left\"";
		if($userinfopos<2)
			echo " colspan=\"2\"";
		echo ">\n";
		echo "<font face=\"$modcommentfont\" size=\"$modcommentfontsize\" color=\"$modcommentfontcolor\">\n";
		echo "<i>$l_modcomment ($displaydate):</i><br>";
		$displaytext=stripslashes($myrow["modcomment"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		echo $displaytext."</font></td></tr>\n";
	}
	switch($userinfopos)
	{
		case 2:
			echo "</table></td></tr>\n";
			break;
		case 3:
			echo "</table></td>";
			display_poster_box($posterbgcolor, $posterfont, $posterfontsize, $posterfontcolor, $myrow["poster"], $countryflag, $countryname, $myrow["useragent"], $myrow["homepage"], $myrow["posteremail"], $myrow["icq"], $url_gfx, $browserpic, $homepagepic, $icqpic, $emailpic, $l_poster, $url_flags, $l_sendicqmsg, $l_visithomepage, $l_sendemail, "left", $bordercolor, $gotoppic, $l_gotop, $genderpic, $gendertext, $myrow["aim"], $aimpic, $l_altaim, $posterpic, $myrow["avatar"], $url_avatars, $myrow["msnm"], $msnmpic, $myrow["yim"], $yimpic, $l_yimlabel, $myrow["location"], $myrow["company"], $companypic, $l_company, $newentrypic, $isnewentry, $picturepic, $myrow["userpic"], $l_userpic, $allowinternalmailer, $start);
			echo "</tr>";
			break;
	}
	echo "<tr bgcolor=\"$bordercolor\"><td colspan=\"2\">";
	echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
}
?>
</table></td></tr>
<?php
if(($maxentries>0) && ($numentries>$maxentries))
{
	echo "</table></td></tr></table></div>";
	if($pagenavspace>0)
		echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$pagenavspace\"></div>";
	echo "<div align=\"$tblalign\">";
	echo "<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"$tblalign\" class=\"sgbtable\">";
	echo "<tr><TD BGCOLOR=\"$bordercolor\">";
	echo "<TABLE BORDER=\"0\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"100%\">";
	echo "<tr bgcolor=\"$headingbgcolor\"><td align=\"center\" colspan=\"2\">";
	echo "<font face=\"$headingfont\" size=\"1\" color=\"$headingfontcolor\"><b>$l_page</b> ";
	if(floor(($searchstart+$maxentries)/$maxentries)>1)
	{
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=0&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_first)
			echo "<img src=\"$url_gfx/$pagepic_first\" border=\"0\" align=\"absmiddle\" title=\"$l_page_first\" alt=\"$l_page_first\">";
		else
			echo "<b>[&lt;&lt;]</b>";
		echo "</a> ";
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".($searchstart-$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_prev)
			echo "<img src=\"$url_gfx/$pagepic_prev\" border=\"0\" align=\"absmiddle\" title=\"$l_page_back\" alt=\"$l_page_back\">";
		else
			echo "<b>[&lt;]</b>";
		echo "</a> ";
	}
	for($i=1;$i<($numentries/$maxentries)+1;$i++)
	{
		if(floor(($searchstart+$maxentries)/$maxentries)!=$i)
		{
			echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".(($i-1)*$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
			if(isset($searchentries))
				echo "&amp;searchentries=1";
			if(isset($searchcommentss))
				echo "&amp;searchcomments=1";
			if(isset($searchusernames))
				echo "&amp;searchusernames=1";
			echo "\"><b>[$i]</b></a> ";
		}
		else
			echo "<b>($i)</b> ";
	}
	if($searchstart < (($i-2)*$maxentries))
	{
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".($searchstart+$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_fwd)
			echo "<img src=\"$url_gfx/$pagepic_fwd\" border=\"0\" align=\"absmiddle\" title=\"$l_page_forward\" alt=\"$l_page_forward\">";
		else
			echo "<b>[&gt;]</b>";
		echo "</a> ";
		echo "<a class=\"pagenav\" href=\"$act_script_url?$langvar=$act_lang&amp;layout=$layout&amp;start=$start&amp;searchstart=".(($i-2)*$maxentries)."&amp;mode=search&amp;searchvalues=".urlencode($searchvalues);
		if(isset($searchentries))
			echo "&amp;searchentries=1";
		if(isset($searchcommentss))
			echo "&amp;searchcomments=1";
		if(isset($searchusernames))
			echo "&amp;searchusernames=1";
		echo "\">";
		if($pagepic_last)
			echo "<img src=\"$url_gfx/$pagepic_last\" border=\"0\" align=\"absmiddle\" title=\"$l_page_last\" alt=\"$l_page_last\">";
		else
			echo "<b>[&gt;&gt;]</b>";
		echo "</a> ";
	}
	echo "</font></td></tr>";
}
echo "</table></td></tr>";
}
?>
</table></div>
<?php
if($copyrightboxspace>0)
	echo "<br clear=all><div align=\"$tblalign\"><img src=\"$url_gfx/space.gif\" height=\"$copyrightboxspace\"></div>";
include_once('./includes/footer.inc');
?>
