<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$redirect=0;
require_once('./config.php');
require_once('./functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("no such language available $act_lang");
include_once('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$noseccheck)
{
	die($l_config_writeable);
}
$pagemode="";
$banreason="";
include_once('./includes/get_layout.inc');
require_once('./includes/block_leacher.inc');
if($blockoldbrowser==1)
{
	if(is_ns3() || is_msie3())
	{
		$sql="select * from ".$tableprefix."_texts where textid='oldbrowser' and lang='$act_lang'";
		if(!$result = mysql_query($sql, $db))
			die("Could not connect to the database. ".mysql_error());
		if($myrow = mysql_fetch_array($result))
			echo undo_htmlspecialchars($myrow["text"]);
		else
			echo $l_oldbrowser;
		exit;
	}
}
$actdate = date("Y-m-d H:i:00");
if($lastvisitcookie==1)
{
	$expiretime = $lastvisitdays * 24 * 60 * 60;
	$thiscookie=$cookiename."[lastvisit]";
	if(isset($_COOKIE[$cookiename]))
	{
		$cookiedata=$_COOKIE[$cookiename];
		$cookiedate=$cookiedata["lastvisit"];
		if($cookiedate && (strpos($cookiedate,"-")>0))
		{
			list($mydate,$mytime)=explode(" ",$cookiedate);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			$lastvisitdate=mktime($hour,$min,0,$month,$day,$year);
			if((time()-$lastvisitdate)>($lastvisitsessiontime*60))
				setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
		}
		else
			setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
	}
	else
	{
		setcookie($thiscookie,$actdate,time()+$expiretime,$cookiepath,$cookiedomain,$cookiesecure);
		$lastvisitdate=time()-($lastvisitdefhours*60*60);
	}
}
else
	$lastvisitdate=time()-($lastvisitdefhours*60*60);
if(!isset($start))
	$start=0;
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.".mysql_error());
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
		include_once('./includes/gbhead.inc');
}
if($userbanlist==2)
{
	$banreason="";
	if(isbanned(get_userip(),$db))
		include_once('./includes/gbhead.inc');
}
if(isset($mode))
{
	if($mode=="add")
	{
		include("./includes/gb_add.inc");
	}
	if($mode=="new")
	{
		include("./includes/gb_new.inc");
	}
}
include("./includes/gb_display.inc");
?>