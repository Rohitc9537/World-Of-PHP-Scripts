<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
$page="index";
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_admin_title;
require_once('./heading.php');
if($admin_rights>0)
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="indexsep"><td align="center"><a name="#entries"><b><?php echo $l_entries?></b></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("entries.php?$langvar=$act_lang")?>"><?php echo $l_editentries?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("stats.php?$langvar=$act_lang")?>"><?php echo $l_stats?></a></td></tr>
<?php
if($admin_rights > 1)
{
?>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("rebuildsearch.php?$langvar=$act_lang")?>"><?php echo $l_rebuildsearch?></a></td></tr>
<tr class="indexsep"><td align="center"><a name="#set"><b><?php echo $l_settings?></b></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("layout.php?$langvar=$act_lang")?>"><?php echo $l_layout?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("settings.php?$langvar=$act_lang")?>"><?php echo $l_syssettings?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("emoticons.php?$langvar=$act_lang")?>"><?php echo $l_emoticons?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("avatars.php?$langvar=$act_lang")?>"><?php echo $l_avatars?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("flags.php?$langvar=$act_lang")?>"><?php echo $l_flags?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("badwords.php?$langvar=$act_lang")?>"><?php echo $l_badwordlist?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("reserved_names.php?$langvar=$act_lang")?>"><?php echo $l_reserved_names?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("texts.php?$langvar=$act_lang")?>"><?php echo $l_texts?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("selections.php?$langvar=$act_lang")?>"><?php echo $l_selections?></a></td></tr>
<?php
}
if($admin_rights > 2)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("freemailer.php?$langvar=$act_lang")?>"><?php echo $l_freemailerlist?></a></td></tr>
<?php
}
?>
<tr class="indexsep"><td align="center"><a name="#users"><b><?php echo $l_user?></b></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("users.php?$langvar=$act_lang")?>"><?php echo $l_editusers?></a></td></tr>
<?php
if($admin_rights>2)
{
?>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("loginfailures.php?$langvar=$act_lang")?>"><?php echo $l_failed_logins?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("banlist.php?$langvar=$act_lang")?>"><?php echo $l_ipbanlist?></a></td></tr>
<tr class="indexsep"><td align="center"><a name="#admin"><b><?php echo $l_administration?></b></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("hostcache.php?$langvar=$act_lang")?>"><?php echo $l_hostcache?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("leacher.php?$langvar=$act_lang")?>"><?php echo $l_leacherlist?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("sessions.php?$langvar=$act_lang")?>"><?php echo $l_cleansession?></a></td></tr>
<?php
if($admin_rights>3)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("shutdown.php?$langvar=$act_lang")?>"><?php echo $l_shutdownsys?></a></td></tr>
<?php
}
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("backup.php?$langvar=$act_lang")?>"><?php echo $l_dbbackup?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("restore.php?$langvar=$act_lang")?>"><?php echo $l_dbrestore?></a></td></tr>
<?php
if($admin_rights>3)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("tblrepair.php?$langvar=$act_lang")?>"><?php echo $l_repairtables?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("tblpack.php?$langvar=$act_lang")?>"><?php echo $l_optimizetables?></a></td></tr>
<?php
}
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("resetcount.php?$langvar=$act_lang&mode=viewcount")?>"><?php echo $l_resetviewcount?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("files_cleanup.php?$langvar=$act_lang")?>"><?php echo $l_files_cleanup?></a></td></tr>
<?php
}
if($admin_rights>=$att2fs)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("attach2fs.php?$langvar=$act_lang")?>"><?php echo $l_attach2fs?></a></td></tr>
<?php
}
if($admin_rights>=$att2db)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("attach2db.php?$langvar=$act_lang")?>"><?php echo $l_attach2db?></a></td></tr>
<?php
}
?>
</table></td></tr></table>
<?php
}
else
{
	$sql="select * from ".$tableprefix."_texts where textid=\"acclck\" and lang=\"".$act_lang."\"";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Could not connect to the database.");
	echo "<table align=\"center\" width=\"80%\" CELLPADDING=\"1\" CELLSPACING=\"0\" border=\"0\" valign=\"top\">";
	echo "<tr><TD BGCOLOR=\"#000000\">";
	echo "<table align=\"center\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">";
	echo "<tr class=\"displayrow\"><td align=\"center\">";
	if(!$myrow=mysql_fetch_array($result))
		echo $l_acclocked;
	else
		echo stripslashes($myrow["text"]);
	echo "</td></tr></table></td></tr></table>";
}
include('./trailer.php');
?>
