<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_layout;
$page="layout";
require_once('./heading.php');
include_once('./includes/color_chooser.inc');
include_once('./includes/layout_selects.inc');
if(!isset($layoutlang))
	$layoutlang=$act_lang;
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
if(isset($dellayout))
{
	$sql = "delete from ".$tableprefix."_layout where id='$layoutid'";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center" colspan="2"><?php echo $l_layoutdeleted?></td></tr>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_selectlayout?></a></div>
<?php
	include_once('./trailer.php');
	exit;
}
if(!isset($layoutid) && !isset($mode))
{
	$sql = "select * from ".$tableprefix."_layout group by id";
	if(!$result = mysql_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form name="sellayoutform" method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if($myrow=mysql_fetch_array($result))
	{
		if(is_konqueror())
			echo "<tr><td></td></tr>";
		echo "<tr class=\"inputrow\"><td align=\"center\" colspan=\"2\">$l_selectlayout:";
		echo "<select name=\"layoutid\"";
		if($admddautosub==1)
			echo " onchange=\"document.sellayoutform.submit()\"";
		echo ">";
		do{
			echo "<option value=\"".$myrow["id"]."\"";
			if($myrow["deflayout"]==1)
				echo " selected class=\"deflayout\"";
			echo ">".$myrow["id"];
			if($myrow["deflayout"]==1)
				echo " [*]";
			echo "</option>";
		}while($myrow=mysql_fetch_array($result));
	}
?>
</select>&nbsp;&nbsp;
<input class="sgbbutton" type="submit" value="<?php echo $l_ok?>"><br>
<span class="remark"><?php echo $l_defremark?></span>
</td></tr></form>
<tr class="actionrow"><td align="center" colspan="2">
<a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang&layoutid=")?>"><?php echo $l_newlayout?></a>
<?php
if($upload_avail)
{
?>
&nbsp;&nbsp;&nbsp;
<a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang&mode=import")?>"><?php echo $l_importlayout?></a>
<?php
}
?>
&nbsp;&nbsp;&nbsp;
<a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang&mode=export")?>"><?php echo $l_exportlayout?></a>
</td></tr>
</table></td></tr></table>
<?php
	include_once('./trailer.php');
	exit;
}
if(isset($setdefault))
{
	$sql = "update ".$tableprefix."_layout set deflayout=0 where deflayout=1";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	$sql = "update ".$tableprefix."_layout set deflayout=1 where id='$layoutid'";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
}
if(isset($mode))
{
	if($mode=="export")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_exportlayout?></b></td></tr>
<form action="layout_export.php" method="post">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	$sql = "select * from ".$tableprefix."_layout group by id";
	if(!$result = mysql_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_selectlayout?>:</td>
<td>
<select name="layoutid">
<?php
	if($myrow=mysql_fetch_array($result))
	{
		do{
			echo "<option value=\"".$myrow["id"]."\"";
			if($myrow["deflayout"]==1)
				echo " selected";
			echo ">".$myrow["id"];
			echo "</option>";
		}while($myrow=mysql_fetch_array($result));
	}
?>
</select></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="includeemoticons" value="1" checked>
<?php echo $l_exportemoticons?></td></tr>
<tr class="actionrow"><td align="center" colspan="2">
<input class="sgbbutton" type="submit" value="<?php echo $l_export?>">
</td></tr>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		echo "</form>";
		echo "</table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_layoutselection</a>";
		echo "</div>";
		include_once('./trailer.php');
		exit;
	}
	if($mode=="import")
	{
		if(!$upload_avail)
			die($l_uploadnotavail);
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_importlayout?></b></td></tr>
<form ENCTYPE="multipart/form-data" action="<?php echo $act_script_url?>" method="post">
<input type="hidden" name="mode" value="doimport">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
		if(is_konqueror())
			echo "<tr><td></td></tr>";
		$sql = "select * from ".$tableprefix."_layout group by id";
		if(!$result = mysql_query($sql, $db)) {
			die("Could not connect to the database.");
	}
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_file?>:</td>
<td><input class="sgbfile" name="layoutfile" type="file"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_layoutid?>:<br>
<span class="remark"><?php echo $l_layoutimportnote?></span></td>
<td><input class="sgbinput" name="layoutid" type="text" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="includeemoticons" value="1" checked>
<?php echo $l_importemoticons?></td></tr>
<tr class="actionrow"><td align="center" colspan="2">
<input class="sgbbutton" type="submit" value="<?php echo $l_import?>">
</td></tr>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		echo "</form>";
		echo "</table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_layoutselection</a>";
		echo "</div>";
		include_once('./trailer.php');
		exit;
	}
	if($mode=="doimport")
	{
		include_once('./includes/layout_import.inc');
		exit;
	}
	if($mode=="copylang")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form action="<?php echo $act_script_url?>" method="post">
<?php
		if(is_konqueror())
			echo "<tr><td></td></tr>";
?>
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_copyotherlang?></b></td></tr>
<tr class="inputrow">
<td align="right" width="30%"><?php echo $l_destlang?>:</td>
<td>
<?php echo language_select("","destlang","../language/",$oldlang)?>
</td></tr>
<tr class="inputrow"><td>&nbsp;</td><td>
<input type="checkbox" name="dooverwrite" value="1"> <?php echo $l_overwriteexisting?></td></tr>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="oldlang" value="<?php echo $oldlang?>">
<input type="hidden" name="layoutid" value="<?php echo $layoutid?>">
<input type="hidden" name="mode" value="dolangcopy">
<tr class="actionrow"><td colspan="2" align="center"><input class="sgbbutton" type="submit" value="<?php echo $l_copy?>"></td></tr>
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
		echo "</form>";
		echo "</table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_layoutselection</a>";
		echo "</div>";
		include_once('./trailer.php');
		exit;
	}
	if($mode=="dolangcopy")
	{
		include_once('./includes/layout_dolangcopy.inc');
		include_once('./trailer.php');
		exit;
	}
	if($mode=="copy")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form action="<?php echo $act_script_url?>" method="post">
<?php
		if(is_konqueror())
			echo "<tr><td></td></tr>";
?>
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_copylayout?></b></td></tr>
<tr class="inputrow">
<td align="right" width="30%"><?php echo $l_newlayoutid?>:</td>
<td><input class="sgbinput" type="text" name="newlayoutid" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td>
<input type="checkbox" name="dooverwrite" value="1"> <?php echo $l_overwriteexisting?></td></tr>
<input type="hidden" name="oldid" value="<?php echo $oldid?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="layoutlang" value="<?php echo $layoutlang?>">
<input type="hidden" name="mode" value="docopy">
<tr class="actionrow"><td colspan="2" align="center"><input class="sgbbutton" type="submit" value="<?php echo $l_copy?>"></td></tr>
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
		echo "</form>";
		echo "</table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_layoutselection</a>";
		echo "</div>";
		include_once('./trailer.php');
		exit;
	}
	if($mode=="docopy")
	{
		include_once('./includes/layout_docopy.inc');
		include_once('./trailer.php');
		exit;
	}
	if(!$layoutid)
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="errorrow"><td align="center" colspan="2"><?php echo $l_nolayoutid?></td></tr>
<?php
		echo "<tr class=\"actionrow\"><td align=\"center\">";
		echo "<a href=\"javascript:history.back()\">$l_back</a>";
		echo "</td></tr></table></td></tr></table>";
		include('./trailer.php');
		exit;
	}
	include("./includes/layout_action.inc");
	if(!isset($layoutnr))
	{
		include_once('./includes/layout_new.inc');
	}
	else
	{
		include_once('./includes/layout_update.inc');
	}
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error()."<br>".$sql);
}
$sql = "select * from ".$tableprefix."_layout where lang='$layoutlang' and id='$layoutid'";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
{
	include('./includes/layout_defs.inc');
}
else
{
	include('./includes/layout_getvals.inc');
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form name="langselform" method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_layoutlang?>: <?php echo language_select($layoutlang,"layoutlang","../language/","",$admddautosub,"langselform")?>
<input class="sgbbutton" type="submit" value="<?php echo $l_change?>">
<input type="hidden" name="layoutid" value="<?php echo $layoutid?>">
</td></tr></form>
<tr class="actionrow"><td align="center" colspan="2"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_changelayout?></a>
<?php
if((strlen($layoutid)>0) && ($deflayout==0) && isset($layoutnr))
	echo "&nbsp;&nbsp;<a href=\"".do_url_session("$act_script_url?dellayout=1&layoutid=$layoutid&$langvar=$act_lang")."\">$l_deletelayout</a>";
if((strlen($layoutid)>0) && isset($layoutnr))
{
	echo "&nbsp;&nbsp;<a href=\"".do_url_session("$act_script_url?mode=copy&oldid=$layoutid&$langvar=$act_lang&layoutlang=$layoutlang")."\">$l_copylayout</a>";
	echo "&nbsp;&nbsp;<a href=\"".do_url_session("$act_script_url?mode=copylang&$langvar=$act_lang&oldlang=$layoutlang&layoutid=$layoutid")."\">$l_copyotherlang</a>";
}
?>
</td></tr>
<tr class="inforow"><td align="center" colspan="2"><b>
<?php
	echo "$l_actuallyselected: $layoutid, $layoutlang";
	if(!isset($layoutnr))
		echo " <span class=\"remark\">($l_newlayout)</span>";
?>
</b></td></tr>
<form name="layoutform" <?php if($upload_avail) echo "ENCTYPE=\"multipart/form-data\""?> method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="colorfield" value="">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="submit">
<input type="hidden" name="layoutlang" value="<?php echo $layoutlang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_id?>:</td>
<?php
if(isset($layoutnr))
	echo "<input type=\"hidden\" name=\"layoutnr\" value=\"$layoutnr\">";
if(strlen($layoutid)<1)
{
	echo "<td class=\"inputrow\"><input type=\"text\" name=\"layoutid\" size=\"10\" maxlength=\"10\">";
}
else
{
	echo "<td>".$layoutid;
	echo "<input type=\"hidden\" name=\"layoutid\" value=\"$layoutid\">";
	echo "<tr class=\"displayrow\"><td>&nbsp;</td>";
	if($deflayout==1)
		echo "<td>$l_default";
	else
	{
		if(isset($layoutnr))
			echo "<td class=\"actionrow\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&layoutlang=$layoutlang&layoutid=$layoutid&setdefault=1")."\">$l_setdefault</a>";
		else
			echo "<td class=\"inputrow\"><input type=\"checkbox\" name=\"deflayout\" value=\"1\"> $l_setdefault";
	}
}
?>
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_heading?></b></td>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_text?>:</td>
<td align="left"><input class="sgbinput" type="text" name="heading" value="<?php echo $heading?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_headingeffect?>:</td>
<td>
<table class="layoutgbheading" width="100%" cellspacing="1" cellpadding="1">
<?php
for($i=0;$i<count($l_headingeffects);$i++)
{
	echo "<tr class=\"layoutgbheading".($i%2)."\">";
	echo "<td align=\"center\" width=\"2%\" align=\"center\"><input type=\"radio\" name=\"gbheadingeffect\" value=\"$i\"";
	if($i==$gbheadingeffect)
		echo " checked";
	echo "></td>";
	echo "<td align=\"left\">$l_headingeffects[$i]</td>";
	echo "<td align=\"center\" width=\"5%\">";
	if($effects_java[$i]==1)
		echo "<img alt=\"$l_is_java\" title=\"$l_is_java\" src=\"gfx/java.gif\" border=\"0\" align=\"absmiddle\"></a>";
	else if($effects_java[$i]==2)
		echo "<img src=\"gfx/js.gif\" alt=\"$l_is_js\" title=\"$l_is_js\" border=\"0\" align=\"absmiddle\">";
	else
		echo "&nbsp;";
	echo "</td></tr>";
}
?>
</table></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_noeffect?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("headingbgcolor",$headingbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("headingfontcolor",$headingfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="headingfont" value="<?php echo do_htmlentities($headingfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="headingfontsize" value="<?php echo $headingfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_effects?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_alignment?>:</td>
<td><select class="sgblayout" name="fxalign">
<?php
for($i=0;$i<count($l_fx_aligns);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$fxalign)
		echo " selected";
	echo ">".$l_fx_aligns[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_applet_width?>:</td>
<td><input class="sgbinput" type="text" name="gbhapplet_width" value="<?php echo $gbhapplet_width?>" size="4" maxlength="4">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_applet_height?>:</td>
<td><input class="sgbinput" type="text" name="gbhapplet_height" value="<?php echo $gbhapplet_height?>" size="4" maxlength="4">&nbsp;<?php echo $l_points?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_firetext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="ftext_font" value="<?php echo $ftext_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="ftext_fontsize" value="<?php echo $ftext_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("ftext_fontcolor",$ftext_fontcolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_fan?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("fan_bgcolor",$fan_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="fan_font" value="<?php echo $fan_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="fan_fontsize" value="<?php echo $fan_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fan_basecolor?>:</td>
<td><select class="sgblayout" name="fan_basecolor">
<?php
for($i=0;$i<count($l_fan_basecolors);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$fan_basecolor)
		echo " selected";
	echo ">".$l_fan_basecolors[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_speed?>:</td>
<td><select class="sgblayout" name="fan_speed">
<?php
for($i=1;$i<10;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$fan_speed)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_hspacing?>:</td>
<td><input class="sgbinput" type="text" name="fan_hspacing" value="<?php echo $fan_hspacing?>" size="4" maxlength="4">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_vspacing?>:</td>
<td><input class="sgbinput" type="text" name="fan_vspacing" value="<?php echo $fan_vspacing?>" size="4" maxlength="4">&nbsp;<?php echo $l_points?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_animtext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("atext_bgcolor",$atext_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="atext_font" value="<?php echo $atext_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("atext_fontcolor",$atext_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="atext_fontstyle">
<?php
for($i=0;$i<count($atext_fontstyles);$i++)
{
	echo "<option value=\"".$atext_fontstyles[$i]."\"";
	if($atext_fontstyles[$i]==$atext_fontstyle)
		echo " selected";
	echo ">".$atext_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_animtype?>:</td>
<td><select class="sgblayout" name="atext_type">
<?php
for($i=0;$i<count($atext_types);$i++)
{
	echo "<option value=\"".$atext_types[$i]."\"";
	if($atext_types[$i]==$atext_type)
		echo " selected";
	echo ">".$atext_types[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_alignment?>:</td>
<td><select class="sgblayout" name="atext_align">
<?php
for($i=0;$i<count($atext_aligns);$i++)
{
	echo "<option value=\"".$atext_aligns[$i]."\"";
	if($atext_aligns[$i]==$atext_align)
		echo " selected";
	echo ">".$atext_aligns[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_animdelay?>:</td>
<td><input class="sgbinput" type="text" name="atext_delaytime" size="4" maxlength="10" value="<?php echo $atext_delaytime?>">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_minfsize?>:</td>
<td><input class="sgbinput" type="text" name="atext_minfsize" size="4" maxlength="4" value="<?php echo $atext_minfsize?>">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxfsize?>:</td>
<td><input class="sgbinput" type="text" name="atext_maxfsize" size="4" maxlength="4" value="<?php echo $atext_maxfsize?>">&nbsp;<?php echo $l_points?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_firework?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("fw_bgcolor",$fw_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="fw_font" value="<?php echo $fw_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="fw_fontsize" value="<?php echo $fw_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("fw_fontcolor",$fw_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_num_rockets?>:</td>
<td><input class="sgbinput" type="text" name="fw_rockets" value="<?php echo $fw_rockets?>" size="4" maxlength="4"></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_jittertext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("jt_bgcolor",$jt_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="jt_font" value="<?php echo $jt_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="jt_fontsize" value="<?php echo $jt_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("jt_fontcolor",$jt_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_animspeed?>:</td>
<td><input class="sgbinput" type="text" name="jt_speed" value="<?php echo $jt_speed?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_randomcolor?>:</td>
<td><input type="radio" name="jt_randomcolor" value="1" <?php if($jt_randomcolor!=0) echo "checked"?>>&nbsp;<?php echo $l_yes?><br>
<input type="radio" name="jt_randomcolor" value="0" <?php if($jt_randomcolor==0) echo "checked"?>>&nbsp;<?php echo $l_no?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_particletext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("pt_bgcolor",$pt_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="pt_font" value="<?php echo $pt_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="pt_fontsize" value="<?php echo $pt_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("pt_fontcolor",$pt_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_animspeed?>:</td>
<td><input class="sgbinput" type="text" name="pt_fps" value="<?php echo $pt_fps?>" size="4" maxlength="4">&nbsp;fps</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_useblur?>:</td>
<td><input type="radio" name="pt_useblur" value="1" <?php if($pt_useblur!=0) echo "checked"?>>&nbsp;<?php echo $l_yes?><br>
<input type="radio" name="pt_useblur" value="0" <?php if($pt_useblur==0) echo "checked"?>>&nbsp;<?php echo $l_no?></td></tr>
<tr class="listheading3"><td align="left" colspan="2"><b><?php echo $l_sineshift?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_usesineshift?>:</td>
<td><input type="radio" name="pt_usesineshift" value="1" <?php if($pt_usesineshift!=0) echo "checked"?>>&nbsp;<?php echo $l_yes?><br>
<input type="radio" name="pt_usesineshift" value="0" <?php if($pt_usesineshift==0) echo "checked"?>>&nbsp;<?php echo $l_no?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_speed?>:</td>
<td><input class="sgbinput" type="text" name="pt_sineshiftspeed" value="<?php echo $pt_sineshiftspeed?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_waveperiod?>:</td>
<td><input class="sgbinput" type="text" name="pt_sineperiod" value="<?php echo $pt_sineperiod?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_wavescale?>:</td>
<td><input class="sgbinput" type="text" name="pt_sinescale" value="<?php echo $pt_sinescale?>" size="10" maxlength="10"></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_rainbowtext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("rt_bgcolor",$rt_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="rt_font" value="<?php echo $rt_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="rt_fontsize" value="<?php echo $rt_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="rt_fontstyle">
<?php
for($i=0;$i<count($l_rt_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$rt_fontstyle)
		echo " selected";
	echo ">".$l_rt_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_delaytime?>:</td>
<td><input class="sgbinput" type="text" name="rt_sleeptime" value="<?php echo $rt_sleeptime?>" size="4" maxlength="10"></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_zipzap?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("zz_bgcolor",$zz_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="zz_font" value="<?php echo $zz_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="zz_fontsize" value="<?php echo $zz_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("zz_fontcolor",$zz_fontcolor)?>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="zz_fontstyle">
<?php
for($i=0;$i<count($l_zz_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$zz_fontstyle)
		echo " selected";
	echo ">".$l_zz_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_delaytime?>:</td>
<td><input class="sgbinput" type="text" name="zz_delay" value="<?php echo $zz_delay?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input class="sgbinput" type="text" name="zz_pause" value="<?php echo $zz_pause?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_circletext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("circle_bgcolor",$circle_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="circle_font" value="<?php echo $circle_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="circle_fontsize" value="<?php echo $circle_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("circle_fontcolor",$circle_fontcolor)?>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="circle_fontstyle">
<?php
for($i=0;$i<count($l_circle_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$circle_fontstyle)
		echo " selected";
	echo ">".$l_circle_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontpadding?>:</td>
<td><input class="sgbinput" type="text" name="circle_fontpadding" value="<?php echo $circle_fontpadding?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_texteffect?>:</td>
<td><select class="sgblayout" name="circle_texteffects">
<?php
for($i=0;$i<count($l_circle_texteffects);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$circle_texteffects)
		echo " selected";
	echo ">".$l_circle_texteffects[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgpic?>:</td>
<?php echo gfx_selector("circle_bgimage",$circle_bgimage)?>
<tr class="inputrow"><td align="right"><?php echo $l_bgpic_align?>:</td>
<td><select class="sgblayout" name="circle_imgalign">
<?php
for($i=0;$i<count($l_circle_img_aligns);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$circle_imgalign)
		echo " selected";
	echo ">".$l_circle_img_aligns[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_circle_direction?>:</td>
<td>
<?php
for($i=0;$i<count($l_circle_directions);$i++)
{
	if($i>0)
		echo "<br>";
	echo "<input type=\"radio\" name=\"circle_direction\" value=\"$i\"";
	if($i==$circle_direction)
		echo " checked";
	echo ">&nbsp;".$l_circle_directions[$i];
}
?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input class="sgbinput" type="text" name="circle_pause" value="<?php echo $circle_pause?>" size="4" maxlength="4">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_rotationfactor?>:</td>
<td><input class="sgbinput" type="text" name="circle_rotationfactor" value="<?php echo $circle_rotationfactor?>" size="4" maxlength="10"></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_pacman?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("pac_bgcolor",$pac_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="pac_font" value="<?php echo $pac_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="pac_fontsize" value="<?php echo $pac_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("pac_fontcolor",$pac_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_paccolor?>:</td>
<?php echo color_chooser("pac_paccolor",$pac_paccolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_sky?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sky_bgcolor",$sky_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="sky_font" value="<?php echo $sky_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="sky_fontsize" value="<?php echo $sky_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="sky_fontstyle">
<?php
for($i=0;$i<count($l_sky_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sky_fontstyle)
		echo " selected";
	echo ">".$l_sky_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgpic?>:</td>
<?php echo gfx_selector("sky_bgimg",$sky_bgimg)?>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input class="sgbinput" type="text" name="sky_sleeptime" value="<?php echo $sky_sleeptime?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_starwave?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sw_bgcolor",$sw_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="sw_font" value="<?php echo $sw_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="sw_fontsize" value="<?php echo $sw_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sw_fontcolor",$sw_fontcolor)?>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_stars?>:</td>
<td><input type="radio" name="sw_stars" value="1" <?php if ($sw_stars==1) echo "checked"?>>&nbsp;<?php echo $l_enabled?><br>
<input type="radio" name="sw_stars" value="0" <?php if ($sw_stars==0) echo "checked"?>>&nbsp;<?php echo $l_disabled?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_numstars?>:</td>
<td><select name="sw_numstars" class="sgblayout">
<?php
for($i=3;$i<51;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sw_numstars)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_delay?>:</td>
<td><input class="sgbinput" type="text" name="sw_naptime" value="<?php echo $sw_naptime?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input class="sgbinput" type="text" name="sw_pause" value="<?php echo $sw_pause?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_waveamp?>:</td>
<td><select class="sgblayout" name="sw_ampmulti">
<?php
for($i=0;$i<21;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sw_ampmulti)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_wavefrequency?>:</td>
<td><select class="sgblayout" name="sw_frequency">
<?php
for($i=0;$i<21;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sw_frequency)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_blinktext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("blt_bgcolor",$blt_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="blt_font" value="<?php echo $blt_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="blt_fontsize" value="<?php echo $blt_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("blt_fontcolor",$blt_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="blt_fontstyle">
<?php
for($i=0;$i<count($l_blt_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$blt_fontstyle)
		echo " selected";
	echo ">".$l_blt_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_delay?>:</td>
<td><input class="sgbinput" type="text" name="blt_delay" value="<?php echo $blt_delay?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_colored_text?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("ct_bgcolor",$ct_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="ct_font" value="<?php echo $ct_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="ct_fontsize" value="<?php echo $ct_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="ct_fontstyle">
<?php
for($i=0;$i<count($l_ct_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$ct_fontstyle)
		echo " selected";
	echo ">".$l_ct_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<?php
for($i=1;$i<5;$i++)
{
	$varname="ct_fontcolor".$i;
	echo "<tr class=\"inputrow\"><td align=\"right\">".$l_fontcolor." ".$i.":</td>";
	echo color_chooser("ct_fontcolor".$i,$$varname);
}
?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_neontext?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("neon_bgcolor",$neon_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="neon_font" value="<?php echo $neon_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="neon_fontsize" value="<?php echo $neon_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="neon_fontstyle">
<?php
for($i=0;$i<count($l_neon_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$neon_fontstyle)
		echo " selected";
	echo ">".$l_neon_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo "$l_fontcolor ($l_turned_off)"?>:</td>
<?php echo color_chooser("neon_fontcolor1",$neon_fontcolor1)?>
<tr class="inputrow"><td align="right"><?php echo "$l_fontcolor ($l_turned_on)"?>:</td>
<?php echo color_chooser("neon_fontcolor2",$neon_fontcolor2)?>
<tr class="inputrow"><td align="right"><?php echo $l_delay?>:</td>
<td><input class="sgbinput" type="text" name="neon_delay" value="<?php echo $neon_delay?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_neontext2?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("neon2_bgcolor",$neon2_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="neon2_font" value="<?php echo $neon2_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="neon2_fontsize" value="<?php echo $neon2_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="neon2_fontstyle">
<?php
for($i=0;$i<count($l_neon2_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$neon2_fontstyle)
		echo " selected";
	echo ">".$l_neon2_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo "$l_fontcolor 1 ($l_turned_off)"?>:</td>
<?php echo color_chooser("neon2_fontcolor1",$neon2_fontcolor1)?>
<tr class="inputrow"><td align="right"><?php echo "$l_fontcolor 2 ($l_turned_on)"?>:</td>
<?php echo color_chooser("neon2_fontcolor2",$neon2_fontcolor2)?>
<tr class="inputrow"><td align="right"><?php echo "$l_fontcolor 3 (".$l_turned_on.")"?>:</td>
<?php echo color_chooser("neon2_fontcolor3",$neon2_fontcolor3)?>
<tr class="inputrow"><td align="right"><?php echo $l_flashspeed?>:</td>
<td><input class="sgbinput" type="text" name="neon2_flashspeed" value="<?php echo $neon2_flashspeed?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo "$l_flashletters ($l_color&nbsp;1)"?>:</td>
<td><input class="sgbinput" type="text" name="neon2_flashletters" value="<?php echo $neon2_flashletters?>" size="4" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo "$l_flashletters ($l_color&nbsp;2)"?>:</td>
<td><input class="sgbinput" type="text" name="neon2_flashletters2" value="<?php echo $neon2_flashletters2?>" size="4" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo "$l_pause"?>:</td>
<td><input class="sgbinput" type="text" name="neon2_flashpause" value="<?php echo $neon2_flashpause?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_rainbow?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("rainbow_bgcolor",$rainbow_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="rainbow_font" value="<?php echo $rainbow_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="rainbow_fontsize" value="<?php echo $rainbow_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td><select class="sgblayout" name="rainbow_fontstyle">
<?php
for($i=0;$i<count($l_rainbow_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$rainbow_fontstyle)
		echo " selected";
	echo ">".$l_rainbow_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_fade?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("ft_bgcolor",$ft_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="ft_font" value="<?php echo $ft_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="ft_fontsize" value="<?php echo $ft_fontsize?>" size="4" maxlength="10">&nbsp;<?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_color?>:</td>
<td><select class="sgblayout" name="ft_rgb">
<?php
for($i=0;$i<count($l_ft_rgb);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$ft_rgb)
		echo " selected";
	echo ">".$l_ft_rgb[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_zoom?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("zoom_bgcolor",$zoom_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="zoom_font" value="<?php echo $zoom_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_zoomcolor?>:</td>
<?php echo color_chooser("zoom_zoomcolor",$zoom_zoomcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("zoom_fontcolor",$zoom_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_startfontsize?>:</td>
<td><input class="sgbinput" type="text" name="zoom_startsize" value="<?php echo $zoom_startsize?>" size="4" maxlength="10">&nbsp;px</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_endfontsize?>:</td>
<td><input class="sgbinput" type="text" name="zoom_endsize" value="<?php echo $zoom_endsize?>" size="4" maxlength="10">&nbsp;px</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_stepsize?>:</td>
<td><input class="sgbinput" type="text" name="zoom_step" value="<?php echo $zoom_step?>" size="4" maxlength="10">&nbsp;px</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_zoomspeed?>:</td>
<td><input class="sgbinput" type="text" name="zoom_zoomspeed" value="<?php echo $zoom_zoomspeed?>" size="4" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input class="sgbinput" type="text" name="zoom_pause" value="<?php echo $zoom_pause?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fadespeed?>:</td>
<td><input class="sgbinput" type="text" name="zoom_fadespeed" value="<?php echo $zoom_fadespeed?>" size="4" maxlength="10"></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_typer?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("typer_bgcolor",$typer_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sgbinput" type="text" name="typer_font" value="<?php echo $typer_font?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sgbinput" type="text" name="typer_fontsize" value="<?php echo $typer_fontsize?>" size="4" maxlength="10">&nbsp;px</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("typer_fontcolor",$typer_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_speed?>:</td>
<td><input class="sgbinput" type="text" name="typer_speed" value="<?php echo $typer_speed?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_alignment?>:</td>
<td><select class="sgblayout" name="typer_align">
<?php
for($i=0;$i<count($l_typer_aligns);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$typer_align)
		echo " selected";
	echo ">".$l_typer_aligns[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_led?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_textline?> 1:</td>
<td><input type="text" class="sgbinput" name="led_msg1" value="<?php echo $led_msg1?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_textline?> 2:</td>
<td><input type="text" class="sgbinput" name="led_msg2" value="<?php echo $led_msg2?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_textline?> 3:</td>
<td><input type="text" class="sgbinput" name="led_msg3" value="<?php echo $led_msg3?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_textline?> 4:</td>
<td><input type="text" class="sgbinput" name="led_msg4" value="<?php echo $led_msg4?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pause?>:</td>
<td><input type="text" class="sgbinput" name="led_pause" value="<?php echo $led_pause?>" size="4" maxlength="10">&nbsp;ms</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_entries?></b></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_layout?></b></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_actionboxpos?>:</td>
<td><input type="checkbox" name="actionboxtop" value="1" <?php if(bittst($actionboxpos,BIT_1)) echo "checked"?>> <?php echo $l_pagetop?><br>
<input type="checkbox" name="actionboxbottom" value="1" <?php if(bittst($actionboxpos,BIT_2)) echo "checked"?>> <?php echo $l_pagebottom?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_userinfopos?>:</td><td><select name="userinfopos">
<?php
for($i=0;$i<count($l_userinfopositions);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$userinfopos)
		echo " selected";
	echo ">".$l_userinfopositions[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pboxwidth?></td><td align="left">
<input type="text" class="sgbinput" name="pboxwidth" size="10" maxlength="10" value="<?php echo $pboxwidth?>"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="showentrynr" value="1" <?php if($displayentrynr) echo "checked"?>> <?php echo $l_display_entrynr?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_pics?></b></td></tr>
<tr class="inputrow2"><td align="right"><?php echo $l_user?>:</td>
<?php echo gfx_selector("posterpic",$posterpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_homepage?>:</td>
<?php echo gfx_selector("homepagepic",$homepagepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_icq?>:</td>
<?php echo gfx_selector("icqpic",$icqpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_aim?>:</td>
<?php echo gfx_selector("aimpic",$aimpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_msnm?>:</td>
<?php echo gfx_selector("msnmpic",$msnmpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_yim?>:</td>
<?php echo gfx_selector("yimpic",$yimpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_email?>:</td>
<?php echo gfx_selector("emailpic",$emailpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_browser?>:</td>
<?php echo gfx_selector("browserpic",$browserpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_gotop?>:</td>
<?php echo gfx_selector("gotoppic",$gotoppic)?>
<tr class="inputrow"><td align="right"><?php echo $l_male?>:</td>
<?php echo gfx_selector("malepic",$malepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_female?>:</td>
<?php echo gfx_selector("femalepic",$femalepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_company?>:</td>
<?php echo gfx_selector("companypic",$companypic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_postdate?>:</td>
<?php echo gfx_selector("datetimepic",$datetimepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_userpic?>:</td>
<?php echo gfx_selector("picturepic",$picturepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_closebutton?>:</td>
<?php echo gfx_selector("closepic",$closepic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_smilies_more?>:</td>
<?php echo gfx_selector("morepic",$morepic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_stickyentry?>:</td>
<?php echo gfx_selector("stickypic",$stickypic)?>
<tr class="inputrow"><td align="right"><?php echo $l_attachement?>:</td>
<?php echo gfx_selector("attachpic",$attachpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_quote?>:</td>
<?php echo gfx_selector("quotepic",$quotepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_newentry?>:</td>
<?php echo gfx_selector("newentrypic",$newentrypic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_addentry?>:</td>
<?php echo gfx_selector("addentrypic",$addentrypic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_changelang?>:</td>
<?php echo gfx_selector("changepic",$changepic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_search?>:</td>
<?php echo gfx_selector("searchpic",$searchpic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_help?>:</td>
<?php echo gfx_selector("helppic",$helppic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_back?>:</td>
<?php echo gfx_selector("backpic",$backpic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_sendmail?>:</td>
<?php echo gfx_selector("sendmailpic",$sendmailpic,true)?>
<tr class="inputrow2"><td align="right"><?php echo $l_admmailpic?>:</td>
<?php echo gfx_selector("admmailpic",$admmailpic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_admmenupic?>:</td>
<?php echo gfx_selector("admmenupic",$admmenupic)?>
<tr class="inputrow2"><td align="right"><?php echo $l_sitehomepic?>:</td>
<?php echo gfx_selector("sitehomepic",$sitehomepic)?>
<tr class="inputrow"><td align="right"><?php echo $l_directeditpic?>:</td>
<?php echo gfx_selector("directeditpic",$directeditpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_delentrypic?>:</td>
<?php echo gfx_selector("delentrypic",$delentrypic)?>
<tr class="inputrow"><td align="right"><?php echo $l_comentrypic?>:</td>
<?php echo gfx_selector("comentrypic",$comentrypic)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_bbcodebuttonpics?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bb_bold?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_bold",$bbcodepic_bold)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_italic?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_italic",$bbcodepic_italic)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_stroke?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_strike",$bbcodepic_strike)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_typewriter?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_type",$bbcodepic_type)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_sub?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_sub",$bbcodepic_sub)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_super?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_super",$bbcodepic_super)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_center?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_center",$bbcodepic_center)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_images?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_pic",$bbcodepic_pic)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_code?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_code",$bbcodepic_code)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_quote?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_quote",$bbcodepic_quote)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_liststart?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_liststart",$bbcodepic_liststart)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_listitem?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_listitem",$bbcodepic_listitem)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_listend?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_listend",$bbcodepic_listend)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_fontsize?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_size",$bbcodepic_size)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_colortext?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_color",$bbcodepic_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_email?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_email",$bbcodepic_email)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_url?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_url",$bbcodepic_url)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_real?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_real",$bbcodepic_real)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_swf?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_swf",$bbcodepic_swf)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_font?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_font",$bbcodepic_font)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_updown?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_updown",$bbcodepic_updown)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_scroll?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_scroll",$bbcodepic_scroll)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_fade?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_fade",$bbcodepic_fade)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_flipv?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_flipv",$bbcodepic_flipv)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_fliph?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_fliph",$bbcodepic_fliph)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_glow?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_glow",$bbcodepic_glow)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_shadow?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_shadow",$bbcodepic_shadow)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_blur?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_blur",$bbcodepic_blur)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_dropshadow?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_dropshadow",$bbcodepic_dropshadow)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_wmv?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_wmv",$bbcodepic_wmv)?>
<tr class="inputrow"><td align="right"><?php echo $l_bb_rainbow?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_rainbow",$bbcodepic_rainbow)?>
<tr class="inputrow"><td align="right"><?php echo $l_help?>:</td>
<?php echo gfx_selector_bbc("bbcodepic_help",$bbcodepic_help)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_bb_effectcolors?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_glow?>:</td>
<?php echo color_chooser("glowcolor",$glowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_shadow?>:</td>
<?php echo color_chooser("shadowcolor",$shadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_dropshadow?>:</td>
<?php echo color_chooser("dropshadowcolor",$dropshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_rainbow_bordercolor?>:</td>
<?php echo color_chooser("rainbow_bordercolor",$rainbow_bordercolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_bbcodebuttons?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bprow?>:</td><td>
<input type="text" class="sgbinput" name="bprow" value="<?php echo $bprow?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_font?>:</td><td>
<input type="radio" name="fontselector" value="0" <?php if(!bittst($fontbuttons,BIT_1)) echo "checked"?>><?php echo $l_button?><br>
<input type="radio" name="fontselector" value="1" <?php if(bittst($fontbuttons,BIT_1)) echo "checked"?>><?php echo $l_dropdownlist?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontsize?>:</td><td>
<input type="radio" name="fontsizeselector" value="0" <?php if(!bittst($fontbuttons,BIT_2)) echo "checked"?>><?php echo $l_button?><br>
<input type="radio" name="fontsizeselector" value="1" <?php if(bittst($fontbuttons,BIT_2)) echo "checked"?>><?php echo $l_dropdownlist?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_fontcolor?>:</td><td>
<input type="radio" name="fontcolorselector" value="0" <?php if(!bittst($fontbuttons,BIT_3)) echo "checked"?>><?php echo $l_button?><br>
<input type="radio" name="fontcolorselector" value="1" <?php if(bittst($fontbuttons,BIT_3) && !bittst($fontbuttons,BIT_4)) echo "checked"?>><?php echo $l_dropdownlist?><br>
<input type="radio" name="fontcolorselector" value="2" <?php if(bittst($fontbuttons,BIT_3) && bittst($fontbuttons,BIT_4)) echo "checked"?>><?php echo $l_colorbar?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_selectboxes?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("selectcolor",$selectcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("bbcsel_color",$bbcsel_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcsel_font" value="<?php echo do_htmlentities($bbcsel_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcsel_fontsize" value="<?php echo $bbcsel_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbcsel_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$bbcsel_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="bbcsel_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$bbcsel_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbcsel_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$bbcsel_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcsel_borderwidth" value="<?php echo $bbcsel_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("bbcsel_bordercolor",$bbcsel_bordercolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_helpline?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("helpline_bgcolor",$helpline_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("helpline_color",$helpline_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="helpline_font" value="<?php echo do_htmlentities($helpline_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="helpline_fontsize" value="<?php echo $helpline_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="helpline_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$helpline_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="helpline_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$helpline_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="helpline_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$helpline_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="helpline_borderwidth" value="<?php echo $helpline_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("helpline_bordercolor",$helpline_bordercolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_bbccode?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("bbccode_bgcolor",$bbccode_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("bbccode_color",$bbccode_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbccode_font" value="<?php echo do_htmlentities($bbccode_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbccode_fontsize" value="<?php echo $bbccode_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbccode_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$bbccode_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="bbccode_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$bbccode_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbccode_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$bbccode_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbccode_borderwidth" value="<?php echo $bbccode_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("bbccode_bordercolor",$bbccode_bordercolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_bbcquote?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("bbcquote_bgcolor",$bbcquote_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("bbcquote_color",$bbcquote_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcquote_font" value="<?php echo do_htmlentities($bbcquote_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcquote_fontsize" value="<?php echo $bbcquote_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbcquote_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$bbcquote_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="bbcquote_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$bbcquote_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="bbcquote_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$bbcquote_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="bbcquote_borderwidth" value="<?php echo $bbcquote_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("bbcquote_bordercolor",$bbcquote_bordercolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_pagenavbuttons?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_page_forward?>:</td>
<?php echo gfx_selector("pagepic_fwd",$pagepic_fwd)?>
<tr class="inputrow"><td align="right"><?php echo $l_page_back?>:</td>
<?php echo gfx_selector("pagepic_prev",$pagepic_prev)?>
<tr class="inputrow"><td align="right"><?php echo $l_page_last?>:</td>
<?php echo gfx_selector("pagepic_last",$pagepic_last)?>
<tr class="inputrow"><td align="right"><?php echo $l_page_first?>:</td>
<?php echo gfx_selector("pagepic_first",$pagepic_first)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_heading?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("entryheadingbgcolor",$entryheadingbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("entryheadingfontcolor",$entryheadingfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="entryheadingfont" value="<?php echo do_htmlentities($entryheadingfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="entryheadingfontsize" value="<?php echo $entryheadingfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select class="sgblayout" name="entryheadingstyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$entryheadingstyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_text?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("contentbgcolor",$contentbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("contentfontcolor",$contentfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="contentfont" value="<?php echo do_htmlentities($contentfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="contentfontsize" value="<?php echo $contentfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_timestamp?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("timestampbgcolor",$timestampbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("timestampfontcolor",$timestampfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="timestampfont" value="<?php echo do_htmlentities($timestampfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="timestampfontsize" value="<?php echo $timestampfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select class="sgblayout" name="timestampstyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$timestampstyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sgbinput" type="text" name="dateformat" value="<?php echo $dateformat?>" size="20" maxlength="20"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_poster?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("posterbgcolor",$posterbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("posterfontcolor",$posterfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="posterfont" value="<?php echo do_htmlentities($posterfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="posterfontsize" value="<?php echo $posterfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_modcomment?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("modcommentbgcolor",$modcommentbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("modcommentfontcolor",$modcommentfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="modcommentfont" value="<?php echo do_htmlentities($modcommentfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="modcommentfontsize" value="<?php echo $modcommentfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_attachement?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("attachbgcolor",$attachbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("attachfontcolor",$attachfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="attachfont" value="<?php echo do_htmlentities($attachfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="attachfontsize" value="<?php echo $attachfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_actionline?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("actionbgcolor",$actionbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("actionfontcolor",$actionfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="actionfont" value="<?php echo do_htmlentities($actionfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="actionfontsize" value="<?php echo $actionfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_requiredfields?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("requiredbgcolor",$requiredbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("requiredfontcolor",$requiredfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_bgpic?>:</td>
<?php echo gfx_selector("required_bgpic",$required_bgpic)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_linkcolors?></b></td>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_general?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("linkcolor",$linkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("alinkcolor",$alinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("vlinkcolor",$vlinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_requiredfields?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("required_linkcolor",$required_linkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("required_alinkcolor",$required_alinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("required_vlinkcolor",$required_vlinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_actionline?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("actionlinkcolor",$actionlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("actionalinkcolor",$actionalinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("actionvlinkcolor",$actionvlinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_pagenav?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("pagenavlinkcolor",$pagenavlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("pagenavalinkcolor",$pagenavalinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("pagenavvlinkcolor",$pagenavvlinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_emoticonbox?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("smile_linkcolor",$smile_linkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("smile_alinkcolor",$smile_alinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("smile_vlinkcolor",$smile_vlinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_bbcodebox?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_linkcolor?>:</td>
<?php echo color_chooser("bbbox_linkcolor",$bbbox_linkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_alinkcolor?>:</td>
<?php echo color_chooser("bbbox_alinkcolor",$bbbox_alinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<?php echo color_chooser("bbbox_vlinkcolor",$bbbox_vlinkcolor)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_userviewstyles?></b></td>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_emoticonbox?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("smile_bgcolor",$smile_bgcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_bbcodebox?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("bbbox_bgcolor",$bbbox_bgcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_browserscrollbar?></b></td>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="enablesbcolors" value="1" <?php if($colorscrollbars==1) echo "checked"?>> <?php echo $l_enable?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_sbfacecolor?>:</td>
<?php echo color_chooser("sbfacecolor",$sbfacecolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbhighlightcolor?>:</td>
<?php echo color_chooser("sbhighlightcolor",$sbhighlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbshadowcolor?>:</td>
<?php echo color_chooser("sbshadowcolor",$sbshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbdarkshadowcolor?>:</td>
<?php echo color_chooser("sbdarkshadowcolor",$sbdarkshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sb3dlightcolor?>:</td>
<?php echo color_chooser("sb3dlightcolor",$sb3dlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbarrowcolor?>:</td>
<?php echo color_chooser("sbarrowcolor",$sbarrowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbtrackcolor?>:</td>
<?php echo color_chooser("sbtrackcolor",$sbtrackcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_selectboxes?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sgbsel_bgcolor",$sgbsel_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sgbsel_color",$sgbsel_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbsel_font" value="<?php echo do_htmlentities($sgbsel_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbsel_fontsize" value="<?php echo $sgbsel_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbsel_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$sgbsel_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="sgbsel_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$sgbsel_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbsel_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$sgbsel_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbsel_borderwidth" value="<?php echo $sgbsel_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("sgbsel_bordercolor",$sgbsel_bordercolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_checkboxes?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sgbchk_bgcolor",$sgbchk_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sgbchk_color",$sgbchk_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbchk_font" value="<?php echo do_htmlentities($sgbchk_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbchk_fontsize" value="<?php echo $sgbchk_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbchk_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$sgbchk_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="sgbchk_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$sgbchk_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbchk_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$sgbchk_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbchk_borderwidth" value="<?php echo $sgbchk_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("sgbchk_bordercolor",$sgbchk_bordercolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_inputfields_textareas?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sgbinput_bgcolor",$sgbinput_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sgbinput_color",$sgbinput_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbinput_font" value="<?php echo do_htmlentities($sgbinput_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbinput_fontsize" value="<?php echo $sgbinput_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbinput_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$sgbinput_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="sgbinput_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$sgbinput_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbinput_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$sgbinput_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbinput_borderwidth" value="<?php echo $sgbinput_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("sgbinput_bordercolor",$sgbinput_bordercolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_inputcounter?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_color?> #1:<br>
<span class="remark">(<?php echo $l_toomanychars?>)</span></td>
<?php echo color_chooser("cnt_color1",$cnt_color1)?>
<tr class="inputrow"><td align="right"><?php echo $l_color?> #2:<br>
<span class="remark">(<?php echo $l_numcharsok?>)</span></td>
<?php echo color_chooser("cnt_color2",$cnt_color2)?>
<tr class="inputrow"><td align="right"><?php echo $l_color?> #3:<br>
<span class="remark">(<?php echo $l_toofewchars?>)</span></td>
<?php echo color_chooser("cnt_color3",$cnt_color3)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_scrollbar?> <span class="remark">(<?php echo $l_textareas?>)</span></b></td>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="textareanoscbar" value="1" <?php if($noscbartextarea==1) echo "checked"?>>
<?php echo $l_dontuse?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_sbfacecolor?>:</td>
<?php echo color_chooser("sgbisb_facecolor",$sgbisb_facecolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbhighlightcolor?>:</td>
<?php echo color_chooser("sgbisb_highlightcolor",$sgbisb_highlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbshadowcolor?>:</td>
<?php echo color_chooser("sgbisb_shadowcolor",$sgbisb_shadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbdarkshadowcolor?>:</td>
<?php echo color_chooser("sgbisb_darkshadowcolor",$sgbisb_darkshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sb3dlightcolor?>:</td>
<?php echo color_chooser("sgbisb_3dlightcolor",$sgbisb_3dlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbarrowcolor?>:</td>
<?php echo color_chooser("sgbisb_arrowcolor",$sgbisb_arrowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbtrackcolor?>:</td>
<?php echo color_chooser("sgbisb_trackcolor",$sgbisb_trackcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_buttons?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sgbbutton_bgcolor",$sgbbutton_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sgbbutton_color",$sgbbutton_color)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbbutton_font" value="<?php echo do_htmlentities($sgbbutton_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbbutton_fontsize" value="<?php echo $sgbbutton_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbbutton_fontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fontstyles[$i]==$sgbbutton_fontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="sgblayout" name="sgbbutton_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$sgbbutton_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="sgblayout" name="sgbbutton_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$sgbbutton_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="sgbbutton_borderwidth" value="<?php echo $sgbbutton_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("sgbbutton_bordercolor",$sgbbutton_bordercolor)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_copyrightnotice?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("copyrightbgcolor",$copyrightbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("copyrightfontcolor",$copyrightfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sgbinput" type="text" name="copyrightfont" value="<?php echo do_htmlentities($copyrightfont)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sgbinput" type="text" name="copyrightfontsize" value="<?php echo $copyrightfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_general?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_maxentries?>:</td><td>
<select name="maxentries"><option value="0" <?php if($maxentries==0) echo "selected"?>><?php echo $l_all?></option>
<?php
for($i=1;$i<100;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$maxentries)
		echo " selected";
	echo ">$i</option>";
}
?></select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_tablewidth?>:</td>
<td align="left"><input class="sgbinput" type="text" name="TableWidth" value="<?php echo $TableWidth?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_tablealign?>:</td>
<td><select name="tablealign" class="sgblayout">
<?php
for($i=0;$i<count($l_table_aligns);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$tablealign)
		echo " selected";
	echo ">".$l_table_aligns[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_tableborder?>:</td>
<?php echo color_chooser("bordercolor",$bordercolor)?>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="enablecurrtime" value="1" <?php if($showcurrtime==1) echo "checked"?>>
<?php echo $l_showcurrtime?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="displayusersonline" value="1" <?php if($enableusersonline==1) echo "checked"?>>
<?php echo $l_enableusersonline?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="displaylangselector" value="1" <?php if($enablelangselector==1) echo "checked"?>>
<?php echo $l_enablelangselector?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="displaylayoutselector" value="1" <?php if($enablelayoutselector==1) echo "checked"?>>
<?php echo $l_enablelayoutselector?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="sortselector" value="1" <?php if($enablesortselector==1) echo "checked"?>>
<?php echo $l_enablesortselector?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="visitcookie" value="1" <?php if($lastvisitcookie==1) echo "checked"?>>
<?php echo $l_lastvisitcookie?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="nousrpreview" value="1" <?php if($usrnopreview==1) echo "checked"?>>
<?php echo $l_nopreviewbutton?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_pagelayout?></b></td>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_customheader?>:<br>
<input name="enablecustomheader" value="1" type="checkbox"
<?php if($usecustomheader==1) echo " checked"?>> <?php echo $l_enable?></td>
<td align="left"><textarea class="sgbinput" name="customheader" cols="40" rows="8"><?php echo do_htmlentities($customheader)?></textarea>
<?php
if($upload_avail)
{
	echo "<hr noshade color=\"#000000\" size=\"1\" width=\"90%\" align=\"center\">";
	echo "$l_upload: <input class=\"sgbfile\" type=\"file\" name=\"customheaderfile\"><br>";
}
?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" name="chnobrtrans" value="1" <?php if(bittst($nonltrans,BIT_1)) echo "checked"?>> <?php echo $l_nobrtranslation?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" value="1" name="clearcustomheader"> <?php echo $l_clear?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<?php echo $l_includefile?>: <input class="sgbinput" type="text" size="30" maxlength="240" name="headerfile" value="<?php echo $headerfile?>"><br>
<input type="radio" name="headerfilepos" value="0" <?php if ($headerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomheader?><br>
<input type="radio" name="headerfilepos" value="1" <?php if ($headerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomheader?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" name="nocheadbr" value="1" <?php if($cheadnobr==1) echo " checked"?>> <?php echo $l_chnobr?>
</td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_customfooter?>:<br>
<input name="enablecustomfooter" value="1" type="checkbox"
<?php if($usecustomfooter==1) echo " checked"?>> <?php echo $l_enable?></td>
<td align="left"><textarea class="sgbinput" name="customfooter" cols="40" rows="8"><?php echo do_htmlentities($customfooter)?></textarea>
<?php
if($upload_avail)
{
	echo "<hr noshade color=\"#000000\" size=\"1\" width=\"90%\" align=\"center\">";
	echo "$l_upload: <input class=\"sgbfile\" type=\"file\" name=\"customfooterfile\"><br>";
}
?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" name="cfnobrtrans" value="1" <?php if(bittst($nonltrans,BIT_2)) echo "checked"?>> <?php echo $l_nobrtranslation?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" value="1" name="clearcustomfooter"> <?php echo $l_clear?>
<hr noshade color="#000000" size="1">
<?php echo $l_includefile?>: <input class="sgbinput" type="text" size="30" maxlength="240" name="footerfile" value="<?php echo $footerfile?>"><br>
<input type="radio" name="footerfilepos" value="0" <?php if ($footerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomfooter?><br>
<input type="radio" name="footerfilepos" value="1" <?php if ($footerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomfooter?>
<hr noshade color="#000000" size="1" width="90%" align="center">
<input type="checkbox" name="nocfootbr" value="1" <?php if($cfootnobr==1) echo " checked"?>> <?php echo $l_cfnobr?>
</td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_noentries_text?>:</td>
<td align="left"><textarea class="sgbinput" name="noentriestxt" cols="40" rows="8"><?php echo do_htmlentities($noentriestxt)?></textarea>
<hr noshade color="#000000" size="1">
<?php
if($upload_avail)
	echo "$l_upload: <input class=\"sgbfile\" type=\"file\" name=\"noentriesfile\"><br>";
?>
<input type="checkbox" value="1" name="clearnoentries"> <?php echo $l_clear?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_headerspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="headerspace" value="<?php echo $headerspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_addboxspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="addboxspace" value="<?php echo $addboxspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_actionboxspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="actionboxspace" value="<?php echo $actionboxspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pagenavspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="pagenavspace" value="<?php echo $pagenavspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_infoboxspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="infoboxspace" value="<?php echo $infoboxspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_copyrightboxspace?>:</td>
<td><input class="sgbinput" type="text" size="10" maxlength="10" name="copyrightboxspace" value="<?php echo $copyrightboxspace?>"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_contentnote?>:</td>
<td><input class="sgbinput" type="text" size="40" maxlength="250" name="contentnote" value="<?php echo html_special_encode(undo_htmlspecialchars(do_htmlentities($contentnote),false))?>"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_pagebg?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("pagebgcolor",$pagebgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_bgpic?>:</td>
<?php echo gfx_selector("pagebgpic",$pagebgpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagebgrepeat?>:</td>
<td><select class="sgblayout" name="pagebgrepeat">
<?php
for($i=0;$i<count($pagebgrepeats);$i++)
{
	echo "<option value=\"".$pagebgrepeats[$i]."\"";
	if($pagebgrepeats[$i]==$pagebgrepeat)
		echo " selected";
	echo ">".$pagebgrepeats[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pagebgposition?>:</td>
<td><select class="sgblayout" name="pagebgposition">
<?php
$layoutpredef=false;
for($i=0;$i<count($pagebgpositions);$i++)
{
	echo "<option value=\"".$pagebgpositions[$i]."\"";
	if($pagebgpositions[$i]==$pagebgposition)
	{
		echo " selected";
		$layoutpredef=true;
	}
	echo ">".$pagebgpositions[$i]."</option>";
}
?>
</select>&nbsp;&nbsp;<input type="text" class="sgbinput" name="pagebgpostxt" value="<?php if(!$layoutpredef) echo $pagebgposition?>" size="10" maxlength="80">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_pagebgattach?>:</td>
<td><select class="sgblayout" name="pagebgattach">
<?php
for($i=0;$i<count($pagebgattachs);$i++)
{
	echo "<option value=\"".$pagebgattachs[$i]."\"";
	if($pagebgattachs[$i]==$pagebgattach)
		echo " selected";
	echo ">".$pagebgattachs[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_stylesheets?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_general?>:</td>
<td><input class="sgbinput" type="text" name="stylesheet" value="<?php echo $stylesheet?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_ns4?>:</td>
<td><input class="sgbinput" type="text" name="ns4style" value="<?php echo $ns4style?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_ns6?>:</td>
<td><input class="sgbinput" type="text" name="ns6style" value="<?php echo $ns6style?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_opera?>:</td>
<td><input class="sgbinput" type="text" name="operastyle" value="<?php echo $operastyle?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_konqueror?>:</td>
<td><input class="sgbinput" type="text" name="konquerorstyle" value="<?php echo $konquerorstyle?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_gecko?>:</td>
<td><input class="sgbinput" type="text" name="geckostyle" value="<?php echo $geckostyle?>" size="40" maxlength="80"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_inputfields?></b></td>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_name?>:</td>
<td><input type="checkbox" name="enablename" onClick="layout_inputname()" value="1" <?php if(bittst($inputfields,BIT_1)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirename" value="1" <?php if(!bittst($inputfields,BIT_1)) echo "disabled"?> <?php if(bittst($inputfields,BIT_2)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_gender?>:</td>
<td><input type="checkbox" name="enablegender" onClick="layout_gender()" value="1" <?php if(bittst($inputfields,BIT_3)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requiregender" value="1" <?php if(!bittst($inputfields,BIT_3)) echo "disabled"?> <?php if(bittst($inputfields,BIT_4)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_email?>:</td>
<td><input type="checkbox" name="enableemail" onClick="layout_email()" value="1" <?php if(bittst($inputfields,BIT_5)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireemail" value="1" <?php if(!bittst($inputfields,BIT_5)) echo "disabled"?> <?php if(bittst($inputfields,BIT_6)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_country?>:</td>
<td><input type="checkbox" name="enablecountry" onClick="layout_country()" value="1" <?php if(bittst($inputfields,BIT_7)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirecountry" value="1" <?php if(!bittst($inputfields,BIT_7)) echo "disabled"?> <?php if(bittst($inputfields,BIT_8)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_homepage?>:</td>
<td><input type="checkbox" name="enablehomepage" onClick="layout_homepage()" value="1" <?php if(bittst($inputfields,BIT_9)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirehomepage" value="1" <?php if(!bittst($inputfields,BIT_9)) echo "disabled"?> <?php if(bittst($inputfields,BIT_10)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_icqnr?>:</td>
<td><input type="checkbox" name="enableicq" onClick="layout_icq()" value="1" <?php if(bittst($inputfields,BIT_11)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireicq" value="1" <?php if(!bittst($inputfields,BIT_11)) echo "disabled"?> <?php if(bittst($inputfields,BIT_12)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_aim?>:</td>
<td><input type="checkbox" name="enableaim" onClick="layout_aim()" value="1" <?php if(bittst($inputfields,BIT_13)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireaim" value="1" <?php if(!bittst($inputfields,BIT_13)) echo "disabled"?> <?php if(bittst($inputfields,BIT_14)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_heading?>:</td>
<td><input type="checkbox" name="enableheading" onClick="layout_heading()" value="1" <?php if(bittst($inputfields,BIT_15)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireheading" value="1" <?php if(!bittst($inputfields,BIT_15)) echo "disabled"?> <?php if(bittst($inputfields,BIT_16)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_avatar?>:</td>
<td><input type="checkbox" name="enableavatar" onClick="layout_avatar()" value="1" <?php if(bittst($inputfields,BIT_17)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireavatar" value="1" <?php if(!bittst($inputfields,BIT_17)) echo "disabled"?> <?php if(bittst($inputfields,BIT_18)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_msnm?>:</td>
<td><input type="checkbox" name="enablemsnm" onClick="layout_msnm()" value="1" <?php if(bittst($inputfields,BIT_19)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requiremsnm" value="1" <?php if(!bittst($inputfields,BIT_19)) echo "disabled"?> <?php if(bittst($inputfields,BIT_20)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_yim?>:</td>
<td><input type="checkbox" name="enableyim" onClick="layout_yim()" value="1" <?php if(bittst($inputfields,BIT_21)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireyim" value="1" <?php if(!bittst($inputfields,BIT_21)) echo "disabled"?> <?php if(bittst($inputfields,BIT_22)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_age?>:</td>
<td><input type="checkbox" name="enableage" onClick="layout_age()" value="1" <?php if(bittst($inputfields,BIT_23)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireage" value="1" <?php if(!bittst($inputfields,BIT_23)) echo "disabled"?> <?php if(bittst($inputfields,BIT_24)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_location?>:</td>
<td><input type="checkbox" name="enablelocation" onClick="layout_location()" value="1" <?php if(bittst($inputfields,BIT_25)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirelocation" value="1" <?php if(!bittst($inputfields,BIT_25)) echo "disabled"?> <?php if(bittst($inputfields,BIT_26)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_company?>:</td>
<td><input type="checkbox" name="enablecompany" onClick="layout_company()" value="1" <?php if(bittst($inputfields,BIT_27)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirecompany" value="1" <?php if(!bittst($inputfields,BIT_27)) echo "disabled"?> <?php if(bittst($inputfields,BIT_28)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_found?>:</td>
<td><input type="checkbox" name="enablefound" onClick="layout_found()" value="1" <?php if(bittst($inputfields,BIT_29)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requirefound" value="1" <?php if(!bittst($inputfields,BIT_29)) echo "disabled"?> <?php if(bittst($inputfields,BIT_30)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_userpic?>:</td>
<td><input type="checkbox" name="enableuserpic" onClick="layout_userpic()" value="1" <?php if(bittst($inputfields2,BIT_1)) echo "checked"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireuserpic" value="1" <?php if(!bittst($inputfields2,BIT_1)) echo "disabled"?> <?php if(bittst($inputfields2,BIT_2)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_attachement?>:</td>
<td><input type="checkbox" name="enableattach" onClick="layout_attachement()" value="1" <?php if(bittst($inputfields2,BIT_3) && $upload_avail) echo "checked"?> <?php if(!$upload_avail) echo "disabled"?>> <?php echo $l_enable?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="requireattach" value="1" <?php if(!bittst($inputfields2,BIT_3)) echo "disabled"?> <?php if(bittst($inputfields2,BIT_4)) echo "checked"?>> <?php echo $l_requiredfield?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_uploadedavatar?></b></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_picmaxdim?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxwidth.":<br>".$l_piclimremark?></td><td><input class="sgbinput" type="text" name="avmaxwidth" value="<?php echo $avmaxwidth?>" size="3" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxheight.":<br>".$l_piclimremark?></td><td><input class="sgbinput" type="text" name="avmaxheight" value="<?php echo $avmaxheight?>" size="3" maxlength="10"> <?php echo $l_pixel?></td></tr>
<?php
if(!$gdavail)
{
	if(extension_loaded("gd"))
		echo "<tr class=\"displayrow\"><td align=\"left\" colspan=\"2\">".$l_note.": ".$l_nolibgd1."</td></tr>";
	else
		echo "<tr class=\"displayrow\"><td align=\"left\" colspan=\"2\">".$l_note.": ".$l_nolibgd2."</td></tr>";
}
?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_attachement?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxfilesize?>:</td><td>
<input class="sgbinput" type="text" name="maxuserfilesize" value="<?php echo $maxuserfilesize?>" size="10" maxlength="10"> <?php echo $l_bytes?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_emoticons?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxallowed?>:</td><td>
<input class="sgbinput" type="text" name="emoticonlimit" size="4" maxlength="4" value="<?php echo $emoticonlimit?>"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_popupwindows?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_width?>:</td><td><input class="sgbinput" type="text" name="popupwidth" value="<?php echo $popupwidth?>" size="3" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_height?>:</td><td><input class="sgbinput" type="text" name="popupheight" value="<?php echo $popupheight?>" size="3" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" value="<?php if(strlen($layoutid)>0) echo $l_update; else echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<?php
include_once('./trailer.php');
?>
