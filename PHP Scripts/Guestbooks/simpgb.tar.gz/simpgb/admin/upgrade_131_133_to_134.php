<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpGB: Upgrade from 1.31-1.33 to 1.34</h3></div>
<br>
<?php
echo "Upgrading tables..<br>";
flush();
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add nonltrans tinyint(4) unsigned default '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>