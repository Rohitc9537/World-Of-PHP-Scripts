<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
$page_title=$l_attach2fs;
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights < 3)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if($attach_in_fs)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($mode))
{
		$processedfiles=0;
		$sql="select * from ".$tableprefix."_bindata";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Could not connect to the database.");
		while($myrow=mysql_fetch_array($result))
		{
			if($myrow["bindata"])
			{
				$processedfiles++;
				$filename=stripslashes($myrow["filename"]);
				if(file_exists($path_attach."/".$filename))
				{
					$tmpnum=1;
					$tmpext=getRealFileExtension($filename);
					$tmpfilename=getRealFilename($filename);
					while(file_exists($path_attach."/".$tmpfilename."_".$tmpnum.".".$tmpext))
						$tmpnum++;
					$physfile=$tmpfilename."_".$tmpnum.".".$tmpext;
				}
				else
					$physfile=$filename;
				$newfile=@fopen($path_attach."/".$physfile,"wb");
				if(!$newfile)
					die("<tr class=\"errorrow\"><td>Error creating file $physfile (".$myrow["entrynr"].")");
				if(!fwrite($newfile,$myrow["bindata"]))
					die("<tr class=\"errorrow\"><td>Error writing to file $physfile (".$myrow["entrynr"].")");
				fclose($newfile);
				if($attach_do_chmod)
					chmod($patch_attach."/".$physfile, $attach_fmode);
				$tmpsql="UPDATE ".$tableprefix."_bindata set fs_filename='$physfile', bindata='' where entrynr=".$myrow["entrynr"];
				if(!$tmpresult = mysql_query($tmpsql, $db))
				    die("<tr class=\"errorrow\"><td>Could not connect to the database. ".mysql_error());
				@mysql_free_result($tmpresult);
			}
		}
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_filesfromdb2fsdone<br>";
		printf($l_files_processed,$processedfiles);
		echo "<br>$l_switch_attach_fs</td></tr>";
}
else
{
	echo "<tr class=\"displayrow\"><td align=\"center\">";
	echo $l_attach2fs_prelude;
	echo "</td></tr>";
	echo "<form method=\"post\" action=\"$act_script_url\">";
	echo "<tr class=\"actionrow\"><td align=\"center\">";
	echo "<input type=\"hidden\" name=\"mode\" value=\"do\">";
	echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
	echo "<input type=\"submit\" name=\"submit\" value=\"$l_ok\" class=\"sgbbutton\">";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	echo "</td></tr>";
	echo "</form>";
}
echo "</table></td></tr></table>";
include('./trailer.php');
?>