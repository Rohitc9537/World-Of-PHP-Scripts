<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpGB: Upgrade from 1.30 to 1.31</h3></div>
<br>
<?php
echo "Upgrading tables..<br>";
flush();
$sql = "ALTER TABLE ".$tableprefix."_data ";
$sql.= "add postingid varchar(40) NOT NULL default ''";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_data");
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add usrnopreview tinyint(1) unsigned NOT NULL default '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>