<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
$page_title=$l_reserved_names;
require_once('./heading.php');
if(!isset($input_name))
	$input_name="";
$errmsg_new="";
$errmsg_edit="";
$entryadded=false;
$entryupdated=false;
$entrydeleted=false;
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 2)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($mode))
{
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		$input_name=trim($input_name);
		if(!$input_name)
		{
			$errmsg_new.="<li>$l_noname</li>";
			$errors=1;
		}
		if($errors==0)
		{
			$input_name=addslashes($input_name);
			$sql = "INSERT INTO ".$tableprefix."_reserved_names (name) ";
			$sql .="VALUES ('$input_name')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add reserved name to database.");
			$entryadded=true;
			$input_name="";
		}
	}
	if(isset($delete))
	{
		$deleteSQL = "delete from ".$tableprefix."_reserved_names where (indexnr=$input_indexnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		$entrydeleted=true;
		$input_name="";
	}
	if(isset($update))
	{
		$errors=0;
		$input_name=trim($input_name);
		if(!$input_name)
		{
			$errmsg_edit.="<li>$l_noname</li>";
			$errors=1;
		}
		if($errors==0)
		{
			$input_name=addslashes($input_name);
			$sql = "UPDATE ".$tableprefix."_reserved_names SET name='$input_name' ";
			$sql .="WHERE (indexnr = $input_indexnr)";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.".mysql_error());
			$entryupdated=true;
		}
		$input_name="";
	}
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td align="center" colspan="2">
<b><?php echo $l_add_reserved_name?></b></td></tr>
<?php
if($errmsg_new)
{
	echo "<tr bgcolor=\"#c0c0c0\"><td colspan=\"2\">";
	echo "$l_errorsoccured:<ul>$errmsg_new</ul></td></tr>";
}
if($entryadded)
{
	echo "<tr bgcolor=\"#c0c0c0\"><td colspan=\"2\" align=\"center\">";
	echo "<i>$l_reserved_name_added</i></td></tr>";
}
?>
<tr class="rowheadings" >
<td class="rowheadings" align="center" width="70%"><b><?php echo $l_reserved_name?></b></td>
<td width="30%">&nbsp;</td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="add">
<?php
if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="center">
<input class="sgbinput" type="text" name="input_name" size="50" maxlength="240" value="<?php echo $input_name?>"></td>
<td><input class="sgbbutton" type="submit" value="<?php echo $l_add?>"></td></tr></form>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<b><?php echo $l_actual_reserved_names?></b></td></tr>
<?php
if($errmsg_edit)
{
	echo "<tr class=\"errorrow\"><td colspan=\"3\">";
	echo "$l_errorsoccured:<ul>$errmsg_edit</ul></td></tr>";
}
if($entrydeleted)
{
	echo "<tr class=\"displayrow\"><td colspan=\"3\" align=\"center\">";
	echo "<i>$l_reserved_name_deleted</i></td></tr>";
}
if($entryupdated)
{
	echo "<tr class=\"displayrow\"><td colspan=\"3\" align=\"center\">";
	echo "<i>$l_reserved_name_updated</i></td></tr>";
}
$sql = "select * from ".$tableprefix."_reserved_names order by name asc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = mysql_fetch_array($result))
{
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td class="rowheadings" align="center" width="70%"><b><?php echo $l_reserved_name?></b></td>
<td width="30%">&nbsp;</td></tr>
<?php
		do {
			$act_id=$myrow["indexnr"];
			echo "<form method=\"post\" action=\"$act_script_url\">";
			if($sessid_url)
				echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
			echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
			echo "<input type=\"hidden\" name=\"input_indexnr\" value=\"$act_id\">";
			echo "<input type=\"hidden\" name=\"mode\" value=\"1\">";
			if(is_konqueror())
				echo "<tr><td></td></tr>";
			echo "<tr class=\"inputrow\">";
			echo "<td align=\"center\">";
			echo "<input class=\"sgbinput\" type=\"text\" name=\"input_name\" value=\"".do_htmlentities($myrow["name"])."\" size=\"50\" maxlength=\"240\"></td>";
			echo "<td>";
			echo "<input class=\"sgbbutton\" type=\"submit\" name=\"delete\" value=\"$l_delete\">";
			echo "&nbsp;&nbsp;";
			echo "<input class=\"sgbbutton\" type=\"submit\" name=\"update\" value=\"$l_update\">";
			echo "</td></tr></form>";
	   } while($myrow = mysql_fetch_array($result));
   echo "</table></tr></td></table>";
}
include('./trailer.php');
?>