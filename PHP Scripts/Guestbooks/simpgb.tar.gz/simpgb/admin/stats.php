<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_stats;
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<?php
if($admin_rights<1)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
?>
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td align="center" colspan="2">
<b><?php echo $l_posts?></b>
</td></tr>
<tr class="displayrow"><td align="center" colspan="2">
<?php
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
$totalentries=$myrow["numentries"];
echo "$l_total: $totalentries $l_entries";
$tempsql = "select * from ".$tableprefix."_counts";
if(!$tempresult = mysql_query($tempsql, $db))
    die("Could not connect to the database.");
if($temprow=mysql_fetch_array($tempresult))
{
	$numhits=$temprow["numhits"];
	list($year, $month, $day) = explode("-",$temprow["hitcountstart"]);
	if($month>0)
		$displaydate=date($l_dateform,mktime(0,0,0,$month,$day,$year));
	else
		$displaydate="";
	echo "<br>$numhits hits $l_since $displaydate";
}
echo "</td></tr>";
if($totalentries>0)
{
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
$langs=language_list("../language");
$langposts=0;
for($i=0;$i<count($langs);$i++)
{
	echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
	$sql="select count(entrynr) as numentries from ".$tableprefix."_data where language='".$langs[$i]."'";
	if(!$result = mysql_query($sql, $db))
		die("Could not connect to the database.");
	$myrow=mysql_fetch_array($result);
	echo $langs[$i].": ".$myrow["numentries"]."</td><td align=\"left\">";
	$percentage=round(($myrow["numentries"]/$totalentries)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	$langposts+=$myrow["numentries"];
}
$nolangnum=$totalentries-$langposts;
if($nolangnum>0)
{
	echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
	echo $l_nolang.": ".$nolangnum."</td><td align=\"left\">";
	$percentage=round(($nolangnum/$totalentries)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
}
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where private=1";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_markedprivate</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where validated=0";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_notvalidated</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where editedbyadmin!=0";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_edbyadmin</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
$withgender=0;
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where gender='f'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
$withgender+=$myrow["numentries"];
echo "$l_femaleposter: ".$myrow["numentries"]."</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where gender='m'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
$withgender+=$myrow["numentries"];
echo "$l_maleposter: ".$myrow["numentries"]."</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$nogender=$totalentries-$withgender;
if($nogender>0)
{
	echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
	echo $l_nogender.": ".$nogender."</td><td align=\"left\">";
	$percentage=round(($nogender/$totalentries)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
}
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where homepage!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withhomepage</td><td align=\"left\">";;
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where posteremail!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withemail</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where country!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withcountry</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where location!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withlocation</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where age!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withage</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where icq!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withicq</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where aim!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withaim</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where msnm!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withmsnm</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where yim!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withyim</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where avatar!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withavatar</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where modcomment!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withmodcomment</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where company!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withcompany</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "<tr class=\"displayrow\"><td align=\"center\" width=\"60%\">";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where found!=''";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo $myrow["numentries"]." $l_posts $l_withfound</td><td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
?>
<tr class="listheading1"><td align="center" valign="top" colspan="2">
<?php echo $l_operatingsystems?></td></tr>
<?php
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent like '%win%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Windows: ";
$win=$myrow["numentries"];
echo $win;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent like '%mac%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Macintosh: ";
$mac=$myrow["numentries"];
echo $mac;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent like '%os/2%' or useragent like '%ibm-webexplorer%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "OS/2: ";
$os2=$myrow["numentries"];
echo $os2;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent like '%linux%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Linux: ";
$linux=$myrow["numentries"];
echo $linux;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%unix%' OR useragent LIKE '%SunOS%' OR useragent LIKE '%FreeBSD%' OR useragent LIKE '%IRIX%' OR useragent LIKE '%HP-UX%' OR useragent LIKE '%OSF%' OR useragent LIKE '%AIX%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Unix: ";
$unix=$myrow["numentries"];
echo $unix;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "$l_other: ";
$other=$totalentries-($win+$mac+$linux+$unix+$os2);
echo $other;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($other/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "</td></tr>";
?>
<tr class="listheading1"><td align="center" valign="top" colspan="2">
<?php echo $l_browser?></td></tr>
<?php
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent like '%MSIE%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "MS Internet Explorer: ";
$msie=$myrow["numentries"];
echo $msie;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%Mozilla%' AND useragent NOT LIKE '%MSIE%' OR '%Opera%' OR '%iCab%' OR '%Konqueror%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Mozilla/Netscape: ";
$mozilla=$myrow["numentries"];
echo $mozilla;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%Opera%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Opera: ";
$opera=$myrow["numentries"];
echo $opera;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%iCab%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "iCab: ";
$icab=$myrow["numentries"];
echo $icab;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%Lynx%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Lynx: ";
$lynx=$myrow["numentries"];
echo $lynx;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
$sql = "select count(entrynr) as numentries from ".$tableprefix."_data where useragent LIKE '%Konqueror%'";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$myrow=mysql_fetch_array($result);
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "Konqueror: ";
$konqueror=$myrow["numentries"];
echo $konqueror;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($myrow["numentries"]/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
echo "$l_other: ";
$other=$totalentries-($msie+$mozilla+$lynx+$icab+$konqueror);
echo $other;
echo "</td>";
echo "<td align=\"left\">";
$percentage=round(($other/$totalentries)*100);
echo do_htmlentities("$percentage%");
echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "</td></tr>";
?>
<tr class="displayrow"><td align="center" colspan="2">
<?php
$sql = "select distinct posterip from ".$tableprefix."_data";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
$numips=mysql_num_rows($result);
echo "$numips $l_diffips";
echo "</td></tr>";
echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
echo "</td></tr>";
}
?>
<tr class="listheading0"><td align="center" colspan="2">
<b><?php echo $l_visitors?></b>
</td></tr>
<?php
$sql = "select * from ".$tableprefix."_counts";
if(!$result = mysql_query($sql, $db))
	die("Could not connect to the database.");
if(!$myrow=mysql_fetch_array($result))
{
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	echo $l_noentries;
	echo "</td></tr>";
}
else
{
	$totalhits=$myrow["numhits"];
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	list($year, $month, $day) = explode("-",$myrow["hitcountstart"]);
	if($month>0)
		$displaydate=date($l_dateform,mktime(0,0,0,$month,$day,$year));
	else
		$displaydate="";
	echo "$l_statstart: $displaydate";
	echo "<br>$totalhits hits";
	echo "</td></tr>";
	if($totalhits>0)
	{
	echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
	echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
	echo "</td></tr>";
	echo "<tr class=\"listheading1\"><td align=\"center\" valign=\"top\" colspan=\"2\">";
	echo "$l_browser</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "MS Internet Explorer: ";
	$msie=$myrow["msie"];
	echo $msie;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($msie/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Netscape/Mozilla: ";
	$mozilla=$myrow["mozilla"];
	echo $mozilla;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($mozilla/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Opera: ";
	$opera=$myrow["opera"];
	echo $opera;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($opera/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "iCab: ";
	$icab=$myrow["icab"];
	echo $icab;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($icab/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Lynx: ";
	$lynx=$myrow["lynx"];
	echo $lynx;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($lynx/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Konqueror: ";
	$konqueror=$myrow["konqueror"];
	echo $konqueror;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($konqueror/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "$l_other: ";
	$other=$totalhits-($msie+$mozilla+$lynx+$icab+$opera+$konqueror);
	echo $other;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($other/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
	echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
	echo "</td></tr>";
	echo "<tr class=\"listheading1\"><td align=\"center\" valign=\"top\" colspan=\"2\">";
	echo "$l_operatingsystems</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Windows: ";
	$win=$myrow["win"];
	echo $win;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($win/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "OS/2: ";
	$os2=$myrow["os2"];
	echo $os2;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($os2/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Macintosh: ";
	$mac=$myrow["mac"];
	echo $mac;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($mac/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Linux: ";
	$linux=$myrow["linux"];
	echo $linux;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($linux/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Unix: ";
	$unix=$myrow["unix"];
	echo $unix;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($unix/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "Bots/Spiders: ";
	$bots=$myrow["bots"];
	echo $bots;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($bots/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	echo "<tr class=\"displayrow\"><td align=\"right\" valign=\"top\">";
	echo "$l_other: ";
	$other=$totalhits-($win+$os2+$mac+$linux+$unix+$bots);
	echo $other;
	echo "</td>";
	echo "<td align=\"left\">";
	$percentage=round(($other/$totalhits)*100);
	echo do_htmlentities("$percentage%");
	echo " <img class=\"statbar\" src=\"gfx/bargif.gif\" border=\"0\" width=\"".(round($percentage/3)*3)."\" height=\"10\">";
	echo "</td></tr>";
	}
}
?>
<tr class="listheading0"><td align="center" colspan="2">
<b><?php echo $l_dbinfos?></b>
</td></tr>
<?php
	$dbtotal=0;
	$spaceused=0;
	$sql="show table status from $dbname like '".$tableprefix."%'";
	if(!$result = mysql_query($sql))
		die("Could not connect to the database.");
 	while($myrow = mysql_fetch_array($result)) {
		$spaceused+=$myrow["Data_length"];
		$spaceused+=$myrow["Index_length"];
 	}
 	$dbtotal+=$spaceused;
 	$spaceused = format_bytes($spaceused);
 	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
 	echo "$l_spaceused (".$tableprefix."_*): $spaceused";
 	echo "</td></tr>";
 	if($hcprefix!=$tableprefix)
 	{
		$spaceused=0;
		$sql="show table status from $dbname like '".$hcprefix."_hostcache'";
		if(!$result = mysql_query($sql))
			die("Could not connect to the database.");
	 	while($myrow = mysql_fetch_array($result)) {
			$spaceused+=$myrow["Data_length"];
			$spaceused+=$myrow["Index_length"];
	 	}
	 	$dbtotal+=$spaceused;
	 	$spaceused = format_bytes($spaceused);
	 	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	 	echo "$l_hostcache: $spaceused";
	 	echo "</td></tr>";
 	}
 	if($banprefix!=$tableprefix)
 	{
		$spaceused=0;
		$sql="show table status from $dbname like '".$banprefix."_banlist'";
		if(!$result = mysql_query($sql))
			die("Could not connect to the database.");
	 	while($myrow = mysql_fetch_array($result)) {
			$spaceused+=$myrow["Data_length"];
			$spaceused+=$myrow["Index_length"];
	 	}
	 	$dbtotal+=$spaceused;
	 	$spaceused = format_bytes($spaceused);
	 	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	 	echo "$l_ipbanlist: $spaceused";
	 	echo "</td></tr>";
 	}
 	if($leacherprefix!=$tableprefix)
 	{
		$spaceused=0;
		$sql="show table status from $dbname like '".$leacherprefix."_leachers'";
		if(!$result = mysql_query($sql))
			die("Could not connect to the database.");
	 	while($myrow = mysql_fetch_array($result)) {
			$spaceused+=$myrow["Data_length"];
			$spaceused+=$myrow["Index_length"];
	 	}
	 	$dbtotal+=$spaceused;
	 	$spaceused = format_bytes($spaceused);
	 	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	 	echo "$l_leacherlist: $spaceused";
	 	echo "</td></tr>";
 	}
 	$dbtotal = format_bytes($dbtotal);
 	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
 	echo "$l_total: $dbtotal";
 	echo "</td></tr>";

?>
<tr class="listheading0"><td align="center" colspan="2">
<b><?php echo $l_diskusage?></b>
<?php
$spaceused = disk_usage($path_simpgb,255);
$spaceused = format_bytes($spaceused);
echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
echo "$l_total: $spaceused";
echo "</td></tr>";
$spaceused = disk_usage($path_simpgb."/gfx",255);
$spaceused = format_bytes($spaceused);
echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
echo "$l_graphics: $spaceused";
echo "</td></tr>";
$spaceused = disk_usage($path_emoticons,255);
$spaceused = format_bytes($spaceused);
echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
echo "$l_emoticons: $spaceused";
echo "</td></tr>";
$spaceused = disk_usage($path_flags,255);
$spaceused = format_bytes($spaceused);
echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
echo "$l_flags: $spaceused";
echo "</td></tr>";
$spaceused = disk_usage($path_avatars,255);
$spaceused = format_bytes($spaceused);
echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
echo "$l_avatars: $spaceused";
echo "</td></tr>";
?>
</table></td></tr></table>
<?php
include('./trailer.php');
?>