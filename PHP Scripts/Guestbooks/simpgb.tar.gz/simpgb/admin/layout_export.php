<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$layoutfileversion="1.34";
$minsgbversion="1.34";
@set_time_limit(600);
require_once('../config.php');
if($admoldhdr)
{
	header('Pragma: no-cache');
	header('Expires: 0');
}
else
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
}
require_once('./functions.php');
require_once('../functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$backupprefix=$tableprefix."_";
$crlf="\n";
$user_loggedin=0;
$userdata=Array();
if($enable_htaccess)
{
	if(isbanned(get_userip(),$db))
	{
?>
<html>
<head>
<meta name="generator" content="SimpGB v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>SimpGB - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_users where username='$myusername'";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database");
	if (!$myrow = mysql_fetch_array($result))
	{
	    die("<tr class=\"errorrow\"><td>User not defined for SimpGB");
	}
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		}
	}
}
else
{
	$userid="";
	if($new_global_handling)
	{
		if(isset($_COOKIE[$sesscookiename]))
		{
			$sessid = $_COOKIE[$sesscookiename];
			$userid = get_userid_from_session($sessid, $sesscookietime, get_userip(), $db);
		}
	}
	else
	{
		if(isset($_COOKIE[$sesscookiename])) {
			$sessid = $_COOKIE[$sesscookiename];
			$userid = get_userid_from_session($sessid, $sesscookietime, get_userip(), $db);
		}
	}
	if ($userid) {
	   $user_loggedin = 1;
	   update_session($sessid, $db);
	   $userdata = get_userdata_by_id($userid, $db);
	   $userdata["lastlogin"]=get_lastlogin_from_session($sessid, $sesscookietime, get_userip(), $db);
	}
}
if($user_loggedin==0)
{
	echo "<div align=\"center\">$l_notloggedin</div>";
	echo "<div align=\"center\">";
	echo "<a href=\"login.php?$langvar=$act_lang\">$l_loginpage</a>";
	die ("</div>");
}
else
{
	$admin_rights=$userdata["rights"];
}
if($admin_rights < 3)
{
	die("$l_functionnotallowed");
}
$crlf="\r\n";
$dump_buffer="{simpgblayout}".$crlf;
$dump_buffer.="{fileversion}".$crlf;
$dump_buffer.=$layoutfileversion.$crlf;
$dump_buffer.=$minsgbversion.$crlf;
$dump_buffer.="{/fileversion}".$crlf;
$dump_buffer.="{layoutid}".$crlf;
$dump_buffer.=$layoutid.$crlf;
$dump_buffer.="{/layoutid}".$crlf;
if(isset($includeemoticons))
{
	$sql="select * from ".$tableprefix."_emoticons where layoutid='$layoutid'";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	while($myrow=mysql_fetch_array($result))
	{
		$dump_buffer.="{emoticon}".$crlf;
		$dump_buffer.=$myrow["code"].$crlf;
		$dump_buffer.=$myrow["emoticon_url"].$crlf;
		$dump_buffer.=$myrow["emotion"].$crlf;
		$dump_buffer.=$myrow["inshortcutlist"].$crlf;
		$dump_buffer.="{/emoticon}".$crlf;
	}
}
$languages=language_list("../language");
for($i=0;$i<count($languages);$i++)
{
	$sql="select * from ".$tableprefix."_layout where id='$layoutid' and lang='".$languages[$i]."'";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.".mysql_error());
	if($myrow=mysql_fetch_array($result))
	{
		$dump_buffer.="{layout}".$crlf;
		$dump_buffer.=$languages[$i].$crlf;
		$dump_buffer.=export_encode($myrow["heading"]).$crlf;
		$dump_buffer.=export_encode($myrow["headingbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["headingfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["headingfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["headingfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["contentbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["contentfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["contentfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["contentfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["TableWidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["timestampfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["timestampfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["timestampfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["dateformat"]).$crlf;
		$dump_buffer.=export_encode($myrow["showcurrtime"]).$crlf;
		$dump_buffer.=export_encode($myrow["customheader"]).$crlf;
		$dump_buffer.=export_encode($myrow["customfooter"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagebgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["stylesheet"]).$crlf;
		$dump_buffer.=export_encode($myrow["entryheadingbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["entryheadingfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["entryheadingstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["entryheadingfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["entryheadingfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["timestampbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["timestampstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["copyrightbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["copyrightfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["copyrightfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["copyrightfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["deflayout"]).$crlf;
		$dump_buffer.=export_encode($myrow["layoutnr"]).$crlf;
		$dump_buffer.=export_encode($myrow["maxentries"]).$crlf;
		$dump_buffer.=export_encode($myrow["userinfopos"]).$crlf;
		$dump_buffer.=export_encode($myrow["homepagepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["emailpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["icqpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["browserpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["addentrypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["posterbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["posterfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["posterfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["posterfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["modcommentbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["modcommentfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["modcommentfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["modcommentfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["requiredbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["requiredfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["gotoppic"]).$crlf;
		$dump_buffer.=export_encode($myrow["malepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["femalepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["inputfields"]).$crlf;
		$dump_buffer.=export_encode($myrow["aimpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["posterpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["enableusersonline"]).$crlf;
		$dump_buffer.=export_encode($myrow["msnmpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["yimpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["enablelangselector"]).$crlf;
		$dump_buffer.=export_encode($myrow["enablelayoutselector"]).$crlf;
		$dump_buffer.=export_encode($myrow["companypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["closepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_bold"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_italic"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_strike"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_type"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_sub"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_super"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_center"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_pic"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_code"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_quote"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_liststart"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_listitem"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_listend"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_size"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_email"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_url"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_real"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_swf"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_help"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_updown"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_scroll"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_fade"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_flipv"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_fliph"]).$crlf;
		$dump_buffer.=export_encode($myrow["morepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagepic_fwd"]).$crlf;;
		$dump_buffer.=export_encode($myrow["pagepic_last"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagepic_prev"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagepic_first"]).$crlf;
		$dump_buffer.=export_encode($myrow["searchpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["backpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["stickypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["attachpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["attachbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["attachfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["attachfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["attachfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["quotepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionbgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionfontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionfont"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionfontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["changepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["helppic"]).$crlf;
		$dump_buffer.=export_encode($myrow["newentrypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["lastvisitcookie"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagebgpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["headerspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionboxspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagenavspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["infoboxspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["copyrightboxspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["noentries"]).$crlf;
		$dump_buffer.=export_encode($myrow["datetimepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["inputfields2"]).$crlf;
		$dump_buffer.=export_encode($myrow["picturepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["selectcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["fontbuttons"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["popupheight"]).$crlf;
		$dump_buffer.=export_encode($myrow["popupwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["maxuserfilesize"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionboxpos"]).$crlf;
		$dump_buffer.=export_encode($myrow["sendmailpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["glowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["shadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_glow"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_shadow"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_blur"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_dropshadow"]).$crlf;
		$dump_buffer.=export_encode($myrow["dropshadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_wmv"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbfacecolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbhighlightcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbshadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sb3dlightcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbarrowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbtrackcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sbdarkshadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["colorscrollbars"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbsel_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbchk_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbinput_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbbutton_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcsel_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["admmailpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_facecolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_highlightcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_shadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_3dlightcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_arrowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_trackcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sgbisb_darkshadowcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["admmenupic"]).$crlf;
		$dump_buffer.=export_encode($myrow["sitehomepic"]).$crlf;
		$dump_buffer.=export_encode($myrow["directeditpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["delentrypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["comentrypic"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["helpline_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbccode_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_color"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_borderstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_fontweight"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_borderwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcquote_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["enablesortselector"]).$crlf;
		$dump_buffer.=export_encode($myrow["required_bgpic"]).$crlf;
		$dump_buffer.=export_encode($myrow["required_linkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["required_vlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["required_alinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["linkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["vlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["alinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionvlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["actionalinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagenavlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagenavvlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagenavalinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["smile_linkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["smile_vlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["smile_alinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["smile_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbbox_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbbox_linkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbbox_vlinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbbox_alinkcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["ns4style"]).$crlf;
		$dump_buffer.=export_encode($myrow["ns6style"]).$crlf;
		$dump_buffer.=export_encode($myrow["operastyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["konquerorstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["geckostyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagebgrepeat"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagebgposition"]).$crlf;
		$dump_buffer.=export_encode($myrow["pagebgattach"]).$crlf;
		$dump_buffer.=export_encode($myrow["gbheadingeffect"]).$crlf;
		$dump_buffer.=export_encode($myrow["ftext_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["ftext_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["ftext_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["gbhapplet_width"]).$crlf;
		$dump_buffer.=export_encode($myrow["gbhapplet_height"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_speed"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_hspacing"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_vspacing"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_basecolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["fan_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_type"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_align"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_delaytime"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_minfsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["atext_maxfsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["fw_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["fw_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["fw_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["fw_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["fw_rockets"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_speed"]).$crlf;
		$dump_buffer.=export_encode($myrow["jt_randomcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_fps"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_usesineshift"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_useblur"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_sineshiftspeed"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_sineperiod"]).$crlf;
		$dump_buffer.=export_encode($myrow["pt_sinescale"]).$crlf;
		$dump_buffer.=export_encode($myrow["rt_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["rt_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["rt_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["rt_sleeptime"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_delay"]).$crlf;
		$dump_buffer.=export_encode($myrow["zz_pause"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_direction"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_bgimage"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_imgalign"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_texteffects"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_fontpadding"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_pause"]).$crlf;
		$dump_buffer.=export_encode($myrow["circle_rotationfactor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pac_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pac_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["pac_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["pac_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["pac_paccolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_bgimg"]).$crlf;
		$dump_buffer.=export_encode($myrow["sky_sleeptime"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_stars"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_numstars"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_naptime"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_pause"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_ampmulti"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_frequency"]).$crlf;
		$dump_buffer.=export_encode($myrow["sw_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_delay"]).$crlf;
		$dump_buffer.=export_encode($myrow["blt_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontcolor1"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontcolor2"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontcolor3"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontcolor4"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["ct_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_fontcolor1"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_fontcolor2"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon_delay"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_fontcolor1"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_fontcolor2"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_fontcolor3"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_flashspeed"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_flashletters"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_flashletters2"]).$crlf;
		$dump_buffer.=export_encode($myrow["neon2_flashpause"]).$crlf;
		$dump_buffer.=export_encode($myrow["rainbow_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["rainbow_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["rainbow_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["rainbow_fontstyle"]).$crlf;
		$dump_buffer.=export_encode($myrow["ft_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["ft_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["ft_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["ft_rgb"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_endsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_startsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_zoomspeed"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_step"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_fadespeed"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_pause"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["zoom_zoomcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_bgcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_fontsize"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_fontcolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_font"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_speed"]).$crlf;
		$dump_buffer.=export_encode($myrow["typer_align"]).$crlf;
		$dump_buffer.=export_encode($myrow["led_msg1"]).$crlf;
		$dump_buffer.=export_encode($myrow["led_msg2"]).$crlf;
		$dump_buffer.=export_encode($myrow["led_msg3"]).$crlf;
		$dump_buffer.=export_encode($myrow["led_msg4"]).$crlf;
		$dump_buffer.=export_encode($myrow["led_pause"]).$crlf;
		$dump_buffer.=export_encode($myrow["tablealign"]).$crlf;
		$dump_buffer.=export_encode($myrow["fxalign"]).$crlf;
		$dump_buffer.=export_encode($myrow["addboxspace"]).$crlf;
		$dump_buffer.=export_encode($myrow["displayentrynr"]).$crlf;
		$dump_buffer.=export_encode($myrow["bbcodepic_rainbow"]).$crlf;
		$dump_buffer.=export_encode($myrow["rainbow_bordercolor"]).$crlf;
		$dump_buffer.=export_encode($myrow["bprow"]).$crlf;
		$dump_buffer.=export_encode($myrow["pboxwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["cnt_color1"]).$crlf;
		$dump_buffer.=export_encode($myrow["cnt_color2"]).$crlf;
		$dump_buffer.=export_encode($myrow["cnt_color3"]).$crlf;
		$dump_buffer.=export_encode($myrow["noscbartextarea"]).$crlf;
		$dump_buffer.=export_encode($myrow["emoticonlimit"]).$crlf;
		$dump_buffer.=export_encode($myrow["avmaxwidth"]).$crlf;
		$dump_buffer.=export_encode($myrow["avmaxheight"]).$crlf;
		$dump_buffer.=export_encode($myrow["headerfile"]).$crlf;
		$dump_buffer.=export_encode($myrow["footerfile"]).$crlf;
		$dump_buffer.=export_encode($myrow["headerfilepos"]).$crlf;
		$dump_buffer.=export_encode($myrow["footerfilepos"]).$crlf;
		$dump_buffer.=export_encode($myrow["usecustomheader"]).$crlf;
		$dump_buffer.=export_encode($myrow["usecustomfooter"]).$crlf;
		$dump_buffer.=export_encode($myrow["cheadnobr"]).$crlf;
		$dump_buffer.=export_encode($myrow["cfootnobr"]).$crlf;
		$dump_buffer.=export_encode($myrow["usrnopreview"]).$crlf;
		$dump_buffer.=export_encode($myrow["nonltrans"]).$crlf;
		$dump_buffer.="{/layout}".$crlf;
	}
}
$dump_buffer.="{/simpgblayout}".$crlf;
header('Content-Type: application/octetstream');
header('Content-Disposition: filename="simpgb_'.$layoutid.'.lay"');
header("Content-Transfer-Encoding: binary\n");
header("Content-length: ".strlen($dump_buffer)."\n");
echo $dump_buffer;
function export_encode($text)
{
	$text=addslashes($text);
	$text=str_replace("\n","\\n",$text);
	$text=str_replace("\r","",$text);
	return $text;
}
?>
