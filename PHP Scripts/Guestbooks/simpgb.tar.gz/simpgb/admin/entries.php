<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_entries;
$page="entries";
$bbcbuttons=true;
require_once('./heading.php');
$headingtext="";
include_once('./includes/bbcode_buttons.inc');
$maxentries=$admin_maxentries;
$dateformat=$l_datefrmt;
if(!isset($start))
	$start=0;
if($admin_rights<1)
{
	echo "<table align=\"center\" width=\"80%\" CELLPADDING=\"1\" CELLSPACING=\"0\" border=\"0\" valign=\"top\">";
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($mode) && ($admin_rights>1))
{
	if($mode=="delete")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_delentry?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<tr class="displayrow">
<form method="post" action="<?php echo $act_script_url?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="entrylnag" value="<?php echo $entrylang?>">
<input type="hidden" name="input_entrynr" value="<?php echo $input_entrynr?>">
<input type="hidden" name="mode" value="del">
<td align="center"><?php echo $l_delwarning?></td></tr>
<tr class="actionrow">
<td align="center"><input class="sgbbutton" type="submit" name="submit" value="<?php echo $l_yes?>"></td></tr>
</table></td></tr></table>
<?php
		include('./trailer.php');
		exit;
	}
	if($mode=="validate")
	{
		$sql="update ".$tableprefix."_data set validated=1 where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
	}
	if($mode=="comment")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_writecomment?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "select * from ".$tableprefix."_data where entrynr='$input_entrynr'";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
		if(!$myrow=mysql_fetch_array($result))
			die("no such entry");
		list($mydate,$mytime)=explode(" ",$myrow["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
		{
			$temptime=mktime($hour,$min,$sec,$month,$day,$year);
			$temptime=transposetime($temptime,$servertimezone,$displaytimezone);
			$displaydate=date($dateformat,$temptime);
		}
		else
			$displaydate="";
		$displaytext=stripslashes($myrow["text"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		$displaytext = str_replace("{contentbgcolor}",$contentbgcolor,$displaytext);
		$displaytext = str_replace("{contentfontcolor}",$contentfontcolor,$displaytext);
		$displaytext = str_replace("{contentfont}",$contentfont,$displaytext);
		$displaytext = str_replace("{contentfontsize}",$contentfontsize,$displaytext);
		$displaytext = str_replace("{bbc_quote}",$l_bbc_quote,$displaytext);
		$displaytext = str_replace("{bbc_code}",$l_bbc_code,$displaytext);
		$genderpic="";
		$gendertext="";
		if($myrow["gender"]=="m")
		{
			$genderpic="male.gif";
			$gendertext=$l_male;
		}
		if($myrow["gender"]=="f")
		{
			$genderpic="female.gif";
			$gendertext=$l_male;
		}
		$countryname="";
		$countryflag="";
		if($myrow["country"])
		{
			$countryname=$myrow["country"];
			$tempsql="select * from ".$tableprefix."_flags where country='".$myrow["country"]."'";
			if(!$tempresult = mysql_query($tempsql, $db))
			    die("Unable to connect to database.".mysql_error());
			if($temprow=mysql_fetch_array($tempresult))
				$countryflag=$temprow["image"];
		}
		echo "<tr class=\"userinfo\"><td align=\"left\">";
		if($myrow["poster"])
		{
			echo "<img src=\"$url_gfx/user.gif\" border=\"0\" align=\"middle\"";
			if($myrow["age"])
			{
				echo " alt=\"$l_age: ".$myrow["age"]."\"";
				echo " title=\"$l_age: ".$myrow["age"]."\"";
			}
			else
			{
			 	echo " alt=\"$l_poster\"";
			 	echo " title=\"$l_poster\"";
			}
			echo ">&nbsp;<b>".undo_htmlspecialchars(do_htmlentities($myrow["poster"]))."</b>";
		}
		if($genderpic)
			echo "&nbsp; <img src=\"$url_gfx/$genderpic\" title=\"$gendertext\" alt=\"$gendertext\" border=\"0\" align=\"middle\">";
		if($myrow["company"])
			echo "&nbsp; <img src=\"$url_gfx/company.gif\" alt=\"$l_company: ".$myrow["company"]."\" title=\"$l_company: ".$myrow["company"]."\" border=\"0\" align=\"middle\">";
		$avatar=$myrow["avatar"];
		if($avatar)
		{
			echo "&nbsp;";
			if(!is_flash_file($avatar))
				echo "<img src=\"$url_avatars/$avatar\" border=\"0\">";
			else
			{
				echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
				echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
				echo "id=\"avatar\">\n";
				echo "<param name=\"movie\" value=\"$url_avatars/$avatar\">\n";
				echo "<param name=\"menu\" value=false>\n";
				echo "<param name=\"quality\" value=\"high\">\n";
				echo "<param name=\"wmode\" value=\"transparent\">\n";
				echo "<param name=\"bgcolor\" value=\"$posterbgcolor\">\n";
				echo "<embed name=\"avatar\" src=\"$url_avatars/$avatar\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$posterbgcolor\"\n";
				echo "type=\"application/x-shockwave-flash\"\n";
   				echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
				echo "</embed>\n";
				echo "</object>\n";
			}
		}
		if(($countryflag) || ($countryname))
		{
			if($myrow["location"])
				$countryname.=" (".$myrow["location"].")";
			if($countryflag)
				echo "&nbsp;&nbsp; <img src=\"$url_flags/$countryflag\" border=\"0\" align=\"middle\" title=\"$countryname\" alt=\"$countryname\">";
			else
				echo "&nbsp;&nbsp;&nbsp;$countryname";
		}
		else if($myrow["location"])
			echo "&nbsp;&nbsp; (".$myrow["location"].")";
		echo "</font></td><td align=\"right\" width=\"10%\" valign=\"middle\">";
		if($myrow["userpic"])
			echo "<a href=\"".$myrow["userpic"]."\" target=\"_blank\"><img src=\"$url_gfx/photo.gif\" title=\"$l_userpic\" alt=\"$l_userpic\" border=\"0\" align=\"middle\"></a>&nbsp;";
		if($myrow["useragent"])
			echo "<img src=\"$url_gfx/browser.gif\" alt=\"".$myrow["useragent"]."\" title=\"".$myrow["useragent"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["homepage"])
			echo "<img src=\"$url_gfx/homepage.gif\" alt=\"".$myrow["homepage"]."\" title=\"".$myrow["homepage"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["posteremail"])
			echo "<img src=\"$url_gfx/email.gif\" alt=\"".$myrow["posteremail"]."\" title=\"".$myrow["posteremail"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["icq"])
			echo "<img src=\"$url_gfx/icq.gif\" alt=\"".$myrow["icq"]."\" title=\"".$myrow["icq"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["aim"])
			echo "<img src=\"$url_gfx/aim.gif\" alt=\"".$myrow["aim"]."\" title=\"".$myrow["aim"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["msnm"])
			echo "<img src=\"$url_gfx/msn.gif\" alt=\"".$myrow["msnm"]."\" title=\"".$myrow["msnm"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["yim"])
			echo "<img src=\"$url_gfx/yahoo.gif\" alt=\"".$myrow["yim"]."\" title=\"".$myrow["yim"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($admin_rights>1)
		{
			$displayip=$myrow["posterip"];
			$hostname=gethostname($myrow["posterip"],$db,false);
			$displayip="$hostname ($displayip)";
			echo "<img src=\"$url_gfx/ip.gif\" alt=\"$displayip\" title=\"$displayip\" border=\"0\" align=\"middle\">";
			if((strlen($hostname)<1) && ($enablehostresolve==1))
				echo "</a>";
			echo "&nbsp;";
		}
		else
			echo "<img src=\"$url_gfx/ip.gif\" alt=\"$l_iplogged\" title=\"$l_iplogged\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["found"])
			echo "<img src=\"gfx/found.gif\" alt=\"$l_found: ".$myrow["found"]."\" title=\"$l_found: ".$myrow["found"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["private"]==1)
			echo "<img src=\"gfx/private.gif\" alt=\"$l_markedprivate\" title=\"$l_markedprivate\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["editedbyadmin"]!=0)
		{
			if($admin_rights>1)
			{
				list($mydate,$mytime)=explode(" ",$myrow["admineditdate"]);
				list($year, $month, $day) = explode("-", $mydate);
				list($hour, $min, $sec) = explode(":",$mytime);
				if($month>0)
					$editdate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
				else
					$editdate="";
				$tempsql="select * from ".$tableprefix."_users where usernr='".$myrow["editedbyadmin"]."'";
				if(!$tempresult = mysql_query($tempsql, $db))
				    die("Unable to connect to database.".mysql_error());
				if($temprow=mysql_fetch_array($tempresult))
					$adminlabel="$l_editedby: ".$temprow["username"]." ($editdate)";
				else
					$adminlabel=$l_editedbyadmin;
				echo "<img src=\"gfx/edited.gif\" alt=\"$adminlabel\" title=\"$adminlabel\" border=\"0\" align=\"middle\">&nbsp;";
			}
			else
				echo "<img src=\"gfx/edited.gif\" alt=\"$l_editedbyadmin\" title=\"$l_editedbyadmin\" border=\"0\" align=\"middle\">&nbsp;";
		}
		echo "&nbsp;</td></tr>";
		echo "<tr class=\"gbheading\"><td align=\"left\" colspan=\"2\">";
		echo "$displaydate:</td></tr>";
		echo "<tr class=\"gbentry\"><td align=\"left\" colspan=\"2\">";
		echo "$displaytext</td></tr>";
		echo "</table></td></tr>";
		$modcomment = stripslashes($myrow["modcomment"]);
		$modcomment = str_replace("<BR>", "\n", $modcomment);
		$modcomment = undo_htmlspecialchars($modcomment);
		$modcomment = str_replace("{contentbgcolor}",$contentbgcolor,$modcomment);
		$modcomment = str_replace("{contentfontcolor}",$contentfontcolor,$modcomment);
		$modcomment = str_replace("{contentfont}",$contentfont,$modcomment);
		$modcomment = str_replace("{contentfontsize}",$contentfontsize,$modcomment);
		$modcomment = str_replace("{bbc_quote}",$l_bbc_quote,$modcomment);
		$modcomment = str_replace("{bbc_code}",$l_bbc_code,$modcomment);
		$hassig=0;
		if(preg_match("#<!-- Signature Start -->(.*?)<!-- Signature End -->#s", $modcomment))
		{
			$hassig=1;
			$modcomment=preg_replace("#<!-- Signature Start -->(.*?)<!-- Signature End -->#s", "", $modcomment);
		}
		$modcomment = bbdecode($modcomment);
		$modcomment = undo_make_clickable($modcomment);
		$modcomment = decode_emoticons($modcomment, $url_emoticons, $db)
?>
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form <?php if($upload_avail) echo "enctype=\"multipart/form-data\""?> name="commentform" method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize?>">
<input type="hidden" name="mode" value="postcomment">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="input_entrynr" value="<?php echo $myrow["entrynr"]?>">
<input type="hidden" name="entrylang" value="<?php echo $entrylang?>">
<input type="hidden" name="start" value="<?php echo $start?>">
<?php
		$hasattach=0;
		$tempsql="select * from ".$tableprefix."_bindata where entrynr='".$myrow["entrynr"]."'";
		if(!$tempresult = mysql_query($tempsql, $db))
		    die("Unable to connect to database.".mysql_error());
		if(mysql_num_rows($tempresult)>0)
			$hasattach=1;
if(is_konqueror())
		echo "<tr><td></td></tr>";
if($myrow["commenteditor"]!=0)
{
?>
<tr class="modcomment"><td align="left" colspan="2">
<?php
	$tempsql = "select * from ".$tableprefix."_users where usernr='".$myrow["commenteditor"]."'";
	if(!$tempresult = mysql_query($tempsql, $db))
	    die("Unable to connect to database.".mysql_error());
	if($temprow=mysql_fetch_array($tempresult))
		echo do_htmlentities($temprow["username"])." $l_on ";
	list($mydate,$mytime)=explode(" ",$myrow["commentdate"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	if($month>0)
		echo date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
	echo ":";
}
?>
</td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_comment?>:
<input type="hidden" name="destfield" value="comment">
</td>
<td><textarea class="sgbinput" id="comment" name="comment" rows="10" cols="40"><?php echo $modcomment?></textarea><br>
<?php
emoticon_choosebox("comment");
display_bbcodes($bbcode_pics, "comment","commentform",true,true);
?>
</td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_attachfile?>:</td>
<td>
<?php
		if($upload_avail)
			echo "<input class=\"sgbfile\" type=\"file\" name=\"uploadfile\">";
		else
			echo $l_uploadnotavail;
		if($hasattach==1)
			echo "<br><input type=\"checkbox\" name=\"delattach\" value=\"1\">$l_delattach";
?>
</td></tr>
<tr class="optionrow"><td align="right" width="30%" valign="top"><?php echo $l_options?>:</td>
<td><input type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?><br>
<input type="checkbox" name="disableautourl" value="1"> <?php echo $l_disableautourl?><br>
<input type="checkbox" name="disablebbcode" value="1"> <?php echo $l_disablebbcode?><br>
<input type="checkbox" name="nosig" value="1"> <?php echo $l_disablesignature?><br>
<input type="checkbox" name="ontop" value="1" <?php if($myrow["sticky"]==1) echo "checked"?>> <?php echo $l_topentry?></td></tr>
<tr class="actionrow"><td colspan="2" align="center"><input class="sgbbutton" type="submit" value="<?php echo $l_submit?>"></td></tr>
</table></td></tr></table>
<?php
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		include('./trailer.php');
		exit;
	}
	if($mode=="new")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_newentry?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<form <?php if($upload_avail) echo "enctype=\"multipart/form-data\""?> name="commentform" method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize?>">
<input type="hidden" name="mode" value="add">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="entrylang" value="<?php echo $entrylang?>">
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_heading?>:</td>
<td><input class="sgbinput" type="text" name="heading" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_text?>:<br>
<input type="hidden" name="destfield" value="entrytext">
</td>
<td><textarea class="sgbinput" id="entrytext" name="entrytext" rows="10" cols="40"></textarea><br>
<?php
emoticon_choosebox("entrytext");
display_bbcodes($bbcode_pics,"entrytext","commentform",true,true);
?>
</td></tr>
<?php
if($upload_avail)
{
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_attachfile?>:</td>
<td><input class="sgbfile" type="file" name="uploadfile"></td></tr>
<?php
}
?>
<tr class="optionrow"><td align="right" width="30%" valign="top"><?php echo $l_options?>:</td>
<td><input type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?><br>
<input type="checkbox" name="disableautourl" value="1"> <?php echo $l_disableautourl?><br>
<input type="checkbox" name="disablebbcode" value="1"> <?php echo $l_disablebbcode?><br>
<input type="checkbox" name="nosig" value="1"> <?php echo $l_disablesignature?><br>
<input type="checkbox" name="ontop" value="1"> <?php echo $l_topentry?></td></tr>
<tr class="actionrow"><td colspan="2" align="center"><input class="sgbbutton" type="submit" value="<?php echo $l_submit?>"></td></tr>
</table></td></tr></table>
<?php
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		include('./trailer.php');
		exit;
	}
	if($mode=="add")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_newentry?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$errors=0;
		$entrytext=trim($entrytext);
		if(!$entrytext)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_notext</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if($new_global_handling)
				$tmp_file=$_FILES['uploadfile']['tmp_name'];
			else
				$tmp_file=$HTTP_POST_FILES['uploadfile']['tmp_name'];
			if($upload_avail && is_uploaded_file($tmp_file))
			{
				if($new_global_handling)
				{
					$filename=$_FILES['uploadfile']['name'];
					$filesize=$_FILES['uploadfile']['size'];
					$filetype=$_FILES['uploadfile']['type'];
				}
				else
				{
					$filename=$HTTP_POST_FILES['uploadfile']['name'];
					$filesize=$HTTP_POST_FILES['uploadfile']['size'];
					$filetype=$HTTP_POST_FILES['uploadfile']['type'];
				}
				if(isset($path_tempdir) && $path_tempdir)
				{
					if(!move_uploaded_file ($tmp_file, $path_tempdir."/".$filename))
						die("unable to move uploaded file to $path_tempdir");
					$orgfile=$path_tempdir."/".$filename;
				}
				else
					$orgfile=$tmp_file;
				if(!$attach_in_fs)
					$filedata = addslashes(get_file($orgfile));
				else
				{
					if(file_exists($path_attach."/".$filename))
					{
						$tmpnum=1;
						$tmpext=getRealFileExtension($filename);
						$tmpfilename=getRealFilename($filename);
						while(file_exists($path_attach."/".$tmpfilename."_".$tmpnum.".".$tmpext))
							$tmpnum++;
						$physfile=$tmpfilename."_".$tmpnum.".".$tmpext;
					}
					else
						$physfile=$filename;
					$filedata="";
					copy ($orgfile,$path_attach."/".$physfile);
				}
				if(isset($path_tempdir) && $path_tempdir)
					unlink($path_tempdir."/".$filename);
			}
			if(!isset($heading))
				$heading="";
			if(isset($ontop))
				$sticky=1;
			else
				$sticky=0;
			if(($userdata["sig"]) && (!isset($nosig)))
				$entrytext.="\n<!-- Signature Start --><hr width=\"100\" align=\"left\">".$userdata["sig"]."<!-- Signature End -->";
			$actdate = date("Y-m-d H:i:s");
			if(!isset($disableautourl))
				$entrytext = make_clickable($entrytext);
			if(!isset($disablebbcode))
				$entrytext = bbencode($entrytext);
			if(!isset($disableemoticons))
				$entrytext = encode_emoticons($entrytext, $url_emoticons, $db);
			$entrytext = do_htmlentities($entrytext);
			if($heading)
				$searchtext=$heading." ";
			else
				$searchtext="";
			$searchtext.= undo_htmlentities($entrytext);
			$searchtext = remove_htmltags($searchtext);
			$searchtext = strtolower($searchtext);
			$searchtext = do_htmlentities($searchtext);
			$searchtext = undo_htmlspecialchars($searchtext);
			$entrytext = str_replace("\n", "<BR>", $entrytext);
			if($userdata["displayname"])
				$poster=$userdata["displayname"];
			else
				$poster=$userdata["username"];
			$sql = "insert into ".$tableprefix."_data (date, text, heading, poster, posteremail, posterip, language, country, avatar, validated, location, sticky, useragent) ";
			$sql.= "values ('$actdate', '$entrytext', '$heading', '$poster', '".$userdata["email"]."', '".get_userip()."', '$entrylang', '".$userdata["country"]."', '".$userdata["avatar"]."', 1, '".$userdata["location"]."', $sticky, '$HTTP_USER_AGENT')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add entry to database.".mysql_error());
			$entrynr=mysql_insert_id($db);
			$sql = "insert into ".$tableprefix."_search (entrynr, text) values ($entrynr, '$searchtext')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add entry to database.".mysql_error());
			if($upload_avail && is_uploaded_file($tmp_file))
			{
				$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize";
				if($attach_in_fs)
					$sql.=", fs_filename";
				$sql.= ") values (";
				$sql.= "$entrynr, '$filedata', '$filename', '$filetype', '$filesize'";
				if($attach_in_fs)
					$sql.=", '$physfile'";
				$sql.= ")";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td align=\"center\">Unable to add entry to database.".mysql_error());
			}
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_entryadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
		include('./trailer.php');
		exit;
	}
	if($mode=="edit")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_editentry?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "select * from ".$tableprefix."_data where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
			die("Unable to connect to database.".mysql_error());
		if(!$myrow=mysql_fetch_array($result))
			die("no such entry");
		list($mydate,$mytime)=explode(" ",$myrow["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
		{
			$temptime=mktime($hour,$min,$sec,$month,$day,$year);
			$temptime=transposetime($temptime,$servertimezone,$displaytimezone);
			$displaydate=date($dateformat,$temptime);
		}
		else
			$displaydate="";
		$displaytext=stripslashes($myrow["text"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		$displaytext = str_replace("<BR>","\n",$displaytext);
		$genderpic="";
		$gendertext="";
		if($myrow["gender"]=="m")
		{
			$genderpic="male.gif";
			$gendertext=$l_male;
		}
		if($myrow["gender"]=="f")
		{
			$genderpic="female.gif";
			$gendertext=$l_male;
		}
		$countryname="";
		$countryflag="";
		if($myrow["country"])
		{
			$countryname=$myrow["country"];
			$tempsql="select * from ".$tableprefix."_flags where country='".$myrow["country"]."'";
			if(!$tempresult = mysql_query($tempsql, $db))
			    die("Unable to connect to database.".mysql_error());
			if($temprow=mysql_fetch_array($tempresult))
				$countryflag=$temprow["image"];
		}
		echo "<tr class=\"userinfo\"><td align=\"left\">";
		if($myrow["poster"])
		{
			echo "<img src=\"$url_gfx/user.gif\" border=\"0\" align=\"middle\"";
			if($myrow["age"])
			{
				echo " alt=\"$l_age: ".$myrow["age"]."\"";
				echo " title=\"$l_age: ".$myrow["age"]."\"";
			}
			else
			{
			 	echo " alt=\"$l_poster\"";
			 	echo " title=\"$l_poster\"";
			}
			echo ">&nbsp;<b>".undo_htmlspecialchars(do_htmlentities($myrow["poster"]))."</b>";
		}
		if($genderpic)
			echo "&nbsp; <img src=\"$url_gfx/$genderpic\" alt=\"$gendertext\" title=\"$gendertext\" border=\"0\" align=\"middle\">";
		if($myrow["company"])
			echo "&nbsp; <img src=\"$url_gfx/company.gif\" alt=\"$l_company: ".$myrow["company"]."\" title=\"$l_company: ".$myrow["company"]."\" border=\"0\" align=\"middle\">";
		$avatar=$myrow["avatar"];
		if($avatar)
		{
			echo "&nbsp;";
			if(!is_flash_file($avatar))
				echo "<img src=\"$url_avatars/$avatar\" border=\"0\">";
			else
			{
				echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
				echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
				echo "id=\"avatar\">\n";
				echo "<param name=\"movie\" value=\"$url_avatars/$avatar\">\n";
				echo "<param name=\"menu\" value=false>\n";
				echo "<param name=\"quality\" value=\"high\">\n";
				echo "<param name=\"wmode\" value=\"transparent\">\n";
				echo "<param name=\"bgcolor\" value=\"$posterbgcolor\">\n";
				echo "<embed name=\"avatar\" src=\"$url_avatars/$avatar\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$posterbgcolor\"\n";
				echo "type=\"application/x-shockwave-flash\"\n";
   				echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
				echo "</embed>\n";
				echo "</object>\n";
			}
		}
		if(($countryflag) || ($countryname))
		{
			if($myrow["location"])
				$countryname.=" (".$myrow["location"].")";
			if($countryflag)
				echo "&nbsp;&nbsp; <img src=\"$url_flags/$countryflag\" border=\"0\" align=\"middle\" alt=\"$countryname\" title=\"$countryname\">";
			else
				echo "&nbsp;&nbsp;&nbsp;$countryname";
		}
		else if($myrow["location"])
			echo "&nbsp;&nbsp; (".$myrow["location"].")";
		echo "</font></td><td align=\"right\" width=\"10%\" valign=\"middle\">";
		if($myrow["userpic"])
			echo "<a href=\"".$myrow["userpic"]."\" target=\"_blank\"><img src=\"$url_gfx/photo.gif\" alt=\"$l_userpic\" title=\"$l_userpic\" border=\"0\" align=\"middle\"></a>&nbsp;";
		if($myrow["useragent"])
			echo "<img src=\"$url_gfx/browser.gif\" alt=\"".$myrow["useragent"]."\" title=\"".$myrow["useragent"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["homepage"])
			echo "<img src=\"$url_gfx/homepage.gif\" alt=\"".$myrow["homepage"]."\" title=\"".$myrow["homepage"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["posteremail"])
			echo "<img src=\"$url_gfx/email.gif\" alt=\"".$myrow["posteremail"]."\" title=\"".$myrow["posteremail"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["icq"])
			echo "<img src=\"$url_gfx/icq.gif\" alt=\"".$myrow["icq"]."\" title=\"".$myrow["icq"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["aim"])
			echo "<img src=\"$url_gfx/aim.gif\" alt=\"".$myrow["aim"]."\" title=\"".$myrow["aim"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["msnm"])
			echo "<img src=\"$url_gfx/msn.gif\" alt=\"".$myrow["msnm"]."\" title=\"".$myrow["msnm"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["yim"])
			echo "<img src=\"$url_gfx/yahoo.gif\" alt=\"".$myrow["yim"]."\" title=\"".$myrow["yim"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($admin_rights>1)
		{
			$displayip=$myrow["posterip"];
			$hostname=gethostname($myrow["posterip"],$db,false);
			$displayip="$hostname ($displayip)";
			echo "<img src=\"$url_gfx/ip.gif\" alt=\"$displayip\" title=\"$displayip\" border=\"0\" align=\"middle\">";
			if((strlen($hostname)<1) && ($enablehostresolve==1))
				echo "</a>";
			echo "&nbsp;";
		}
		else
			echo "<img src=\"$url_gfx/ip.gif\" alt=\"$l_iplogged\" title=\"$l_iplogged\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["found"])
			echo "<img src=\"gfx/found.gif\" alt=\"$l_found: ".$myrow["found"]."\" title=\"$l_found: ".$myrow["found"]."\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["private"]==1)
			echo "<img src=\"gfx/private.gif\" alt=\"$l_markedprivate\" title=\"$l_markedprivate\" border=\"0\" align=\"middle\">&nbsp;";
		if($myrow["editedbyadmin"]!=0)
		{
			if($admin_rights>1)
			{
				list($mydate,$mytime)=explode(" ",$myrow["admineditdate"]);
				list($year, $month, $day) = explode("-", $mydate);
				list($hour, $min, $sec) = explode(":",$mytime);
				if($month>0)
					$editdate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
				else
					$editdate="";
				$tempsql="select * from ".$tableprefix."_users where usernr=".$myrow["editedbyadmin"];
				if(!$tempresult = mysql_query($tempsql, $db))
				    die("Unable to connect to database.".mysql_error());
				if($temprow=mysql_fetch_array($tempresult))
					$adminlabel="$l_editedby: ".$temprow["username"]." ($editdate)";
				else
					$adminlabel=$l_editedbyadmin;
				echo "<img src=\"gfx/edited.gif\" alt=\"$adminlabel\" title=\"$adminlabel\" border=\"0\" align=\"middle\">&nbsp;";
			}
			else
				echo "<img src=\"gfx/edited.gif\" alt=\"$l_editedbyadmin\" title=\"$l_editedbyadmin\" border=\"0\" align=\"middle\">&nbsp;";
		}
		echo "&nbsp;</td></tr>";
		echo "<tr class=\"gbheading\"><td align=\"left\" colspan=\"2\">";
		echo "$displaydate:</td></tr>";
		echo "</table></td></tr>";
		$hassig=0;
		if(preg_match("#<!-- Signature Start -->(.*?)<!-- Signature End -->#s", $displaytext))
		{
			$hassig=1;
			$displaytext=preg_replace("#<!-- Signature Start -->(.*?)<!-- Signature End -->#s", "", $displaytext);
		}
		$displaytext = bbdecode($displaytext);
		$displaytext = undo_make_clickable($displaytext);
		$displaytext = decode_emoticons($displaytext, $url_emoticons, $db);
		$hasattach=0;
		$tempsql="select * from ".$tableprefix."_bindata where entrynr=".$myrow["entrynr"];
		if(!$tempresult = mysql_query($tempsql, $db))
			die("Unable to connect to database.".mysql_error());
		if(mysql_num_rows($tempresult)>0)
			$hasattach=1;
?>
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form <?php if($upload_avail) echo "enctype=\"multipart/form-data\""?> name="commentform" method="post" action="<?php echo $act_script_url?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize?>">
<input type="hidden" name="mode" value="update">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="input_entrynr" value="<?php echo $myrow["entrynr"]?>">
<input type="hidden" name="entrylang" value="<?php echo $entrylang?>">
<input type="hidden" name="start" value="<?php echo $start?>">
<?php
		if(is_konqueror())
			echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_heading?>:</td>
<td><input class="sgbinput" type="text" name="heading" size="40" maxlength="80" value="<?php echo $myrow["heading"]?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_text?>:<br>
<input type="hidden" name="destfield" value="comment">
</td>
<td><textarea class="sgbinput" id="comment" name="comment" rows="10" cols="40"><?php echo $displaytext?></textarea><br>
<?php
		emoticon_choosebox("comment");
		display_bbcodes($bbcode_pics, "comment","commentform",true,true);
?>
</td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_attachfile?>:</td>
<td>
<?php
		if($upload_avail)
			echo "<input class=\"sgbfile\" type=\"file\" name=\"uploadfile\">";
		else
			echo $l_uploadnotavail;
		if($hasattach==1)
			echo "<br><input type=\"checkbox\" name=\"delattach\" value=\"1\">$l_delattach";
?>
</td></tr>
<tr class="optionrow"><td align="right" width="30%" valign="top"><?php echo $l_options?>:</td>
<td><input type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?><br>
<input type="checkbox" name="disableautourl" value="1"> <?php echo $l_disableautourl?><br>
<input type="checkbox" name="disablebbcode" value="1"> <?php echo $l_disablebbcode?><br>
<input type="checkbox" name="nosig" value="1" <?php if($hassig==0) echo "checked"?>> <?php echo $l_disablesignature?><br>
<input type="checkbox" name="ontop" value="1" <?php if($myrow["sticky"]==1) echo "checked"?>> <?php echo $l_topentry?>
<?php
if($myrow["validated"]==0)
			echo "<br><input type=\"checkbox\" name=\"validate\" value=\"1\"> $l_validate";
?>
</td></tr>
<tr class="actionrow"><td colspan="2" align="center"><input class="sgbbutton" type="submit" value="<?php echo $l_submit?>">
</td></tr>
</table></td></tr></table>
<?php
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		include('./trailer.php');
		exit;
	}
	if($mode=="update")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_editentry?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$errors=0;
		$comment=trim($comment);
		if(!$comment)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_notext</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if(!isset($heading))
				$heading="";
			$actdate = date("Y-m-d H:i:s");
			if(($userdata["sig"]) && (!isset($nosig)))
				$comment.="\n<!-- Signature Start --><hr width=\"100\" align=\"left\">".$userdata["sig"]."<!-- Signature End -->";
			if(!isset($disableautourl))
				$comment = make_clickable($comment);
			if(!isset($disablebbcode))
				$comment = bbencode($comment);
			if(!isset($disableemoticons))
				$comment = encode_emoticons($comment, $url_emoticons, $db);
			$comment = do_htmlentities($comment);
			if($heading)
				$searchtext=$heading." ";
			else
				$searchtext="";
			$searchtext.= undo_htmlentities($comment);
			$searchtext = remove_htmltags($searchtext);
			$searchtext = strtolower($searchtext);
			$searchtext = do_htmlentities($searchtext);
			$searchtext = undo_htmlspecialchars($searchtext);
			$comment = str_replace("\n", "<BR>", $comment);
			if(isset($ontop))
				$sticky=1;
			else
				$sticky=0;
			$sql = "update ".$tableprefix."_data set sticky=$sticky, text='$comment', admineditdate='$actdate', editedbyadmin=".$userdata["usernr"];
			if(isset($validate))
				$sql.=", validated=1";
			$sql.= " where entrynr=$input_entrynr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
			$sql = "update ".$tableprefix."_search set text='$searchtext' where entrynr=$input_entrynr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
			if($new_global_handling)
				$tmp_file=$_FILES['uploadfile']['tmp_name'];
			else
				$tmp_file=$HTTP_POST_FILES['uploadfile']['tmp_name'];
			if(isset($delattach))
			{
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["fs_filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
			}
			else if($upload_avail && is_uploaded_file($tmp_file))
			{
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["fs_filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
				if($new_global_handling)
				{
					$filename=$_FILES['uploadfile']['name'];
					$filesize=$_FILES['uploadfile']['size'];
					$filetype=$_FILES['uploadfile']['type'];
				}
				else
				{
					$filename=$HTTP_POST_FILES['uploadfile']['name'];
					$filesize=$HTTP_POST_FILES['uploadfile']['size'];
					$filetype=$HTTP_POST_FILES['uploadfile']['type'];
				}
				if(isset($path_tempdir) && $path_tempdir)
				{
					if(!move_uploaded_file ($tmp_file, $path_tempdir."/".$filename))
						die("<tr class=\"errorrow\"><td>unable to move uploaded file to $path_tempdir");
					$orgfile=$path_tempdir."/".$filename;
				}
				else
					$orgfile=$tmp_file;
				if(!$attach_in_fs)
				{
					$filedata = addslashes(get_file($orgfile));
					$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize) ";
					$sql.= "values ($input_entrynr, '$filedata', '$filename', '$filetype', '$filesize')";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
				}
				else
				{
					if(file_exists($path_attach."/".$filename))
					{
						$tmpnum=1;
						$tmpext=getRealFileExtension($filename);
						$tmpfilename=getRealFilename($filename);
						while(file_exists($path_attach."/".$tmpfilename."_".$tmpnum.".".$tmpext))
							$tmpnum++;
						$physfile=$tmpfilename."_".$tmpnum.".".$tmpext;
					}
					else
						$physfile=$filename;
					$filedata="";
					copy ($orgfile,$path_attach."/".$physfile);
					$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize, fs_filename) ";
					$sql.= "values ($input_entrynr, '$filedata', '$filename', '$filetype', '$filesize', '$physfile')";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
				}
				if(isset($path_tempdir) && $path_tempdir)
				{
					unlink($path_tempdir."/".$filename);
				}
			}
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_entryupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
		include('./trailer.php');
		exit;
	}
	if($mode=="resolve")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		if($enablehostresolve!=1)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "select * from ".$tableprefix."_data where entrynr='$input_entrynr'";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to add comment to database.".mysql_error());
		if($myrow=mysql_fetch_array($result))
			gethostname($myrow["posterip"],$db,true);
	}
	if($mode=="postcomment")
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td colspan="2" align="center"><b><?php echo $l_writecomment?></b></td></tr>
<?php
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$errors=0;
		$comment=trim($comment);
		if(!$comment)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nocomment</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if(($userdata["sig"]) && (!isset($nosig)))
				$comment.="\n<!-- Signature Start --><hr width=\"50\">".$userdata["sig"]."<!-- Signature End -->";
			$actdate = date("Y-m-d H:i:s");
			if(!isset($disableautourl))
				$comment = make_clickable($comment);
			if(!isset($disablebbcode))
				$comment = bbencode($comment);
			if(!isset($disableemoticons))
				$comment = encode_emoticons($comment, $url_emoticons, $db);
			$comment = do_htmlentities($comment);
			$searchtext = undo_htmlentities($comment);
			$searchtext = remove_htmltags($searchtext);
			$searchtext = strtolower($searchtext);
			$searchtext = do_htmlentities($searchtext);
			$searchtext = undo_htmlspecialchars($searchtext);
			$comment = str_replace("\n", "<BR>", $comment);
			$comment = addslashes($comment);
			if(isset($ontop))
				$sticky=1;
			else
				$sticky=0;
			$sql = "update ".$tableprefix."_data set sticky=$sticky, modcomment='$comment', commentdate='$actdate', commenteditor=".$userdata["usernr"]." where entrynr=$input_entrynr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add comment to database.".mysql_error());
			$sql = "update ".$tableprefix."_search set comment='$searchtext' where entrynr=$input_entrynr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add comment to database.".mysql_error());
			if($new_global_handling)
				$tmp_file=$_FILES['uploadfile']['tmp_name'];
			else
				$tmp_file=$HTTP_POST_FILES['uploadfile']['tmp_name'];
			if(isset($delattach))
			{
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["fs_filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to add comment to database.".mysql_error());
			}
			else if($upload_avail && is_uploaded_file($tmp_file))
			{
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to add comment to database.".mysql_error());
				if($new_global_handling)
				{
					$filesize=$_FILES['uploadfile']['size'];
					$filename=$_FILES['uploadfile']['name'];
					$filetype=$_FILES['uploadfile']['type'];
				}
				else
				{
					$filesize=$HTTP_POST_FILES['uploadfile']['size'];
					$filename=$HTTP_POST_FILES['uploadfile']['name'];
					$filetype=$HTTP_POST_FILES['uploadfile']['type'];
				}
				if(isset($path_tempdir) && $path_tempdir)
				{
					if(!move_uploaded_file ($tmp_file, $path_tempdir."/".$filename))
						die("<tr class=\"errorrow\"><td>unable to move uploaded file to $path_tempdir");
					$orgfile=$path_tempdir."/".$filename;
				}
				else
					$orgfile=$tmp_file;
				if(!$attach_in_fs)
				{
					$filedata = addslashes(get_file($orgfilefile));
					if($filedata)
					{
						$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize) ";
						$sql.= "values ($input_entrynr, '$filedata', '$filename', '$filetype', '$filesize')";
						if(!$result = mysql_query($sql, $db))
						    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					}
				}
				else
				{
					if(file_exists($path_attach."/".$filename))
					{
						$tmpnum=1;
						$tmpext=getRealFileExtension($filename);
						$tmpfilename=getRealFilename($filename);
						while(file_exists($path_attach."/".$tmpfilename."_".$tmpnum.".".$tmpext))
							$tmpnum++;
						$physfile=$tmpfilename."_".$tmpnum.".".$tmpext;
					}
					else
						$physfile=$filename;
					$filedata="";
					copy ($orgfile,$path_attach."/".$physfile);
					$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize, fs_filename) ";
					$sql.= "values ($input_entrynr, '$filedata', '$filename', '$filetype', '$filesize', '$physfile')";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
				}
				if(isset($path_tempdir) && $path_tempdir)
				{
					unlink($path_tempdir."/".$filename);
				}
			}
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_commentadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">$l_entries</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
		include('./trailer.php');
		exit;
	}
	if($mode=="stick")
	{
		$sql = "update ".$tableprefix."_data set sticky=1 where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to update database.".mysql_error());
	}
	if($mode=="unstick")
	{
		$sql = "update ".$tableprefix."_data set sticky=0 where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to update database.".mysql_error());
	}
	if($mode=="delcomment")
	{
		$sql = "update ".$tableprefix."_data set modcomment='', commentdate='0000-00-00 00:00:00' where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to delete comment from database.".mysql_error());
		$sql = "update ".$tableprefix."_search set comment='' where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to delete comment from database.".mysql_error());
	}
	if($mode=="del")
	{
		$sql = "delete from ".$tableprefix."_data where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		if($attach_in_fs)
		{
			$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
			if($myrow=mysql_fetch_array($result))
				unlink($path_attach."/".$myrow["fs_filename"]);
		}
		$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		$sql = "delete from ".$tableprefix."_search where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	}
	if($mode=="delattach")
	{
		if($attach_in_fs)
		{
			$sql = "select * from ".$tableprefix."_bindata where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
			if($myrow=mysql_fetch_array($result))
				unlink($path_attach."/".$myrow["fs_filename"]);
		}
		$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_entrynr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	}
	if($mode=="massaction")
	{
		if(isset($entries) && isset($del))
		{
    		while(list($null, $entry) = each($_POST["entries"]))
    		{
				$del_query = "delete from ".$tableprefix."_data where entrynr=$entry";
    		   	if(!mysql_query($del_query, $db))
				    die("<tr class=\"errorrow\"><td>Unable to update the database.".mysql_error());
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr='$entry'";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["fs_filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$entry";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
				$sql = "delete from ".$tableprefix."_search where entrynr=$entry";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			}
		}
		if(isset($entries) && isset($validate))
		{
    		while(list($null, $entry) = each($_POST["entries"]))
    		{
				$del_query = "update ".$tableprefix."_data set validated = 1 where entrynr=$entry";
    		   	if(!mysql_query($del_query, $db))
				    die("<tr class=\"errorrow\"><td>Unable to update the database.".mysql_error());
			}
		}
	}
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if(!isset($entrylang))
	$entrylang=$act_lang;
echo "<form name=\"lselform\" method=\"post\" action=\"$act_script_url\">";
if($sessid_url)
	echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
if(is_konqueror())
	echo "<tr><td></td></tr>";
echo "<tr class=\"inputrow\"><td align=\"center\" valign=\"middle\" colspan=\"2\">";
echo $l_selectentrylang.": ";
echo language_select($entrylang,"entrylang","../language","",$admddautosub,"lselform");
echo "&nbsp;&nbsp;<input class=\"sgbbutton\" type=\"submit\" value=\"$l_ok\">";
echo "</td></tr></form>";
$sql = "select * from ".$tableprefix."_data where language='$entrylang' order by date desc";
if(!$result = mysql_query($sql, $db))
    die("<tr class=\"displayrow\"><td>Unable to connect to database.".mysql_error());
if($admin_rights>1)
{
	echo "<tr class=\"actionrow\"><td align=\"center\" valign=\"middle\" colspan=\"2\">";
	echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=new&entrylang=$entrylang")."\">$l_newentry</a>";
	echo "</td></tr>";
}
echo "<tr class=\"inforow\"><td align=\"center\" colspan=\"2\">";
echo $l_currentlyselected.": ".$entrylang;
echo "</td></tr>";
if($maxentries>0)
{
	$numentries=mysql_numrows($result);
	if(isset($start) && ($start>0) && ($numentries>$maxentries))
	{
		$sql .=" limit $start,$maxentries";
	}
	else
	{
		$sql .=" limit $maxentries";
		$start=0;
	}
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	if(mysql_numrows($result)>0)
	{
		echo "<tr class=\"headingrow\"><td align=\"center\" valign=\"middle\" colspan=\"2\">";
		echo "<b>$l_page ".ceil(($start/$maxentries)+1)."/".ceil(($numentries/$maxentries))."</b><br><b>($l_totalentries: $numentries)</b>";
		echo "</td></tr>";
	}
}
if(($maxentries>0) && ($numentries>$maxentries))
{
	echo "<tr class=\"pagenav\"><td align=\"center\" colspan=\"2\">";
	if(floor(($start+$maxentries)/$maxentries)>1)
	{
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;start=0&amp;entrylang=$entrylang");
		echo "\">[&lt;&lt;]</a> ";
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".($start-$maxentries));
		echo "\">[&lt;]</a> ";
	}
	for($i=1;$i<($numentries/$maxentries)+1;$i++)
	{
		if(floor(($start+$maxentries)/$maxentries)!=$i)
		{
			echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".(($i-1)*$maxentries));
			echo "\">[$i]</a> ";
		}
		else
			echo "($i) ";
	}
	if($start < (($i-2)*$maxentries))
	{
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".($start+$maxentries));
		echo "\">[&gt;]</a> ";
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".(($i-2)*$maxentries));
		echo "\">[&gt;&gt;]</a> ";
	}
	echo "</font></td></tr>";
}
echo "<tr><td align=\"center\" colspan=\"2\"><table width=\"100%\" align=\"center\" bgcolor=\"#cccccc\" cellspacing=\"0\" cellpadding=\"0\">\n";
if(mysql_numrows($result)==0)
{
	echo "<tr class=\"displayrow\"><td align=\"center\">";
	echo "$l_noentries";
	echo "</td></tr>";
}
if($admin_rights>1)
{
	echo "<form name=\"listform\" method=\"post\" action=\"$act_script_url\">";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
	echo "<input type=\"hidden\" name=\"entrylang\" value=\"$entrylang\">";
	echo "<input type=\"hidden\" name=\"mode\" value=\"massaction\">";
	echo "<input type=\"hidden\" name=\"start\" value=\"$start\">";
}
list($mydate,$mytime)=explode(" ",$userdata["lastlogin"]);
list($year, $month, $day) = explode("-", $mydate);
list($hour, $min, $sec) = explode(":",$mytime);
$lastvisitdate=mktime($hour,$min,0,$month,$day,$year);
while($myrow=mysql_fetch_array($result))
{
	$act_id=$myrow["entrynr"];
	list($mydate,$mytime)=explode(" ",$myrow["date"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	if($month>0)
	{
		$temptime=mktime($hour,$min,$sec,$month,$day,$year);
		$temptime=transposetime($temptime,$servertimezone,$displaytimezone);
		$displaydate=date($dateformat,$temptime);
	}
	else
		$displaydate="";
	$countryname="";
	$countryflag="";
	if($myrow["country"])
	{
		$countryname=$myrow["country"];
		$tempsql="select * from ".$tableprefix."_flags where country='".$myrow["country"]."'";
		if(!$tempresult = mysql_query($tempsql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		if($temprow=mysql_fetch_array($tempresult))
			$countryflag=$temprow["image"];
	}
	echo "<tr class=\"displayrow\">\n";
	echo "<td align=\"left\" width=\"10%\" valign=\"top\" height=\"100%\" class=\"userinfo\">";
	echo "<table width=\"100%\" height=\"100%\" border=\"0\" class=\"userinfo\" align=\"center\" valign=\"top\" cellspacing=\"1\" cellpadding=\"1\">";
	echo "<tr><td align=\"left\" valign=\"top\">";
	list($mydate,$mytime)=explode(" ",$myrow["date"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	$thisentrydate=mktime($hour,$min,$sec,$month,$day,$year);
	if($thisentrydate>=$lastvisitdate)
	{
		echo "<img src=\"gfx/new.gif\" border=\"0\" align=\"middle\"> ";
	}
	echo "<b>$act_id)</b> ";
	if($myrow["poster"])
	{
		echo "<img src=\"$url_gfx/user.gif\" border=\"0\" align=\"middle\"";
		if($myrow["age"])
		{
			echo " alt=\"$l_age: ".$myrow["age"]."\"";
			echo " title=\"$l_age: ".$myrow["age"]."\"";
		}
		else
		{
		 	echo " alt=\"$l_poster\"";
		 	echo " title=\"$l_poster\"";
		}
		echo ">&nbsp;<b>".undo_htmlspecialchars(do_htmlentities($myrow["poster"]))."</b>";
	}
	if($myrow["gender"])
	{
		if($myrow["gender"]=="m")
			echo "&nbsp; <img src=\"$url_gfx/male.gif\" alt=\"$l_male\" title=\"$l_male\" border=\"0\" align=\"middle\">";
		else
			echo "&nbsp; <img src=\"$url_gfx/female.gif\" alt=\"$l_female\" title=\"$l_female\" border=\"0\" align=\"middle\">";
	}
	echo "</td></tr>";
	if($myrow["company"])
	{
		echo "<tr><td align=\"left\" valign=\"middle\">";
		echo "<img src=\"$url_gfx/company.gif\" border=\"0\" align=\"middle\" title=\"$l_company\" alt=\"$l_company\">&nbsp;";
		echo $myrow["company"];
		echo "</td></tr>";
	}
	echo "<tr><td align=\"left\" valign=\"middle\">";
	if($countryflag || $countryname)
	{
		if($myrow["location"])
			$countryname.=" (".$myrow["location"].")";
		if($countryflag)
			echo "&nbsp;<img src=\"$url_flags/$countryflag\" border=\"0\" align=\"middle\" title=\"$countryname\" alt=\"$countryname\">";
		else if($countryname)
			echo "&nbsp;$countryname";
	}
	else if($myrow["location"])
			echo " (".$myrow["location"].")";
	echo "</td></tr>";
	$avatar=$myrow["avatar"];
	if($avatar)
	{
		echo "<tr><td align=\"left\" valign=\"middle\"><hr>";
		if(!is_flash_file($avatar))
			echo "<img src=\"$url_avatars/$avatar\" border=\"0\">";
		else
		{
			echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
			echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
			echo "id=\"avatar\">\n";
			echo "<param name=\"movie\" value=\"$url_avatars/$avatar\">\n";
			echo "<param name=\"menu\" value=false>\n";
			echo "<param name=\"quality\" value=\"high\">\n";
			echo "<param name=\"wmode\" value=\"transparent\">\n";
			echo "<param name=\"bgcolor\" value=\"$posterbgcolor\">\n";
			echo "<embed name=\"avatar\" src=\"$url_avatars/$avatar\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"$posterbgcolor\"\n";
			echo "type=\"application/x-shockwave-flash\"\n";
			echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
			echo "</embed>\n";
			echo "</object>\n";
		}
		echo "</td></tr>";
	}
	echo "<tr><td align=\"left\" valign=\"bottom\">";
	if($myrow["userpic"])
		echo "<a href=\"".$myrow["userpic"]."\" target=\"_blank\"><img src=\"$url_gfx/photo.gif\" alt=\"$l_userpic\" title=\"$l_userpic\" border=\"0\" align=\"middle\"></a>&nbsp;";
	if($myrow["useragent"])
		echo "<img src=\"$url_gfx/browser.gif\" alt=\"".$myrow["useragent"]."\" title=\"".$myrow["useragent"]."\" border=\"0\" align=\"middle\">\n";
	if($myrow["homepage"])
		echo "<a href=\"".$myrow["homepage"]."\" target=\"_blank\"><img src=\"$url_gfx/homepage.gif\" alt=\"".$myrow["homepage"]."\" title=\"".$myrow["homepage"]."\" border=\"0\" align=\"middle\"></a>\n";
	if($myrow["posteremail"])
		echo "<a href=\"mailto:".$myrow["posteremail"]."\"><img src=\"$url_gfx/email.gif\" alt=\"".$myrow["posteremail"]."\" title=\"".$myrow["posteremail"]."\" border=\"0\" align=\"middle\"></a>\n";
	if($myrow["icq"])
		echo "<a href=\"http://wwp.icq.com/scripts/contact.dll?msgto=".$myrow["icq"]."\" target=\"_blank\"><img src=\"$url_gfx/icq.gif\" alt=\"".$myrow["icq"]."\" title=\"".$myrow["icq"]."\" border=\"0\" align=\"middle\"></a>\n";
	if($myrow["aim"])
		echo "<a href=\"aim:goim?screenname=".$myrow["aim"]."&message=Hello\"><img src=\"$url_gfx/aim.gif\" alt=\"".$myrow["aim"]."\" title=\"".$myrow["aim"]."\" border=\"0\" align=\"middle\"></a>\n";
	if($myrow["msnm"])
		echo "<img src=\"$url_gfx/msn.gif\" alt=\"".$myrow["msnm"]."\" title=\"".$myrow["msnm"]."\" border=\"0\" align=\"middle\">\n";
	if($myrow["yim"])
		echo "<a href=\"http://edit.yahoo.com/config/send_webmesg?.target=".$myrow["yim"]."&.src=pg\"><img src=\"$url_gfx/yahoo.gif\" alt=\"".$myrow["yim"]."\" title=\"".$myrow["yim"]."\" border=\"0\" align=\"middle\"></a>\n";
	if($admin_rights>1)
	{
		$displayip=$myrow["posterip"];
		$hostname=gethostname($myrow["posterip"],$db,false);
		if((strlen($hostname)<1) && ($enablehostresolve==1))
			echo " <a href=\"".do_url_session("$act_script_url?mode=resolve&input_entrynr=$act_id&$langvar=$act_lang&entrylang=$entrylang&start=$start")."\">";
		else
		{
			$displayip="$hostname ($displayip)";
			echo " <a href=\"javascript:showip('$displayip')\">";
		}
		echo "<img src=\"$url_gfx/ip.gif\" alt=\"$displayip\" title=\"$displayip\" border=\"0\" align=\"middle\">";
		if((strlen($hostname)<1) && ($enablehostresolve==1))
			echo "</a>";
		echo "&nbsp; ";
	}
	else
		echo "<img src=\"$url_gfx/ip.gif\" alt=\"$l_iplogged\" title=\"$l_iplogged\" border=\"0\" align=\"middle\">&nbsp; ";
	if($myrow["found"])
		echo "<img src=\"gfx/found.gif\" alt=\"$l_found: ".$myrow["found"]."\" title=\"$l_found: ".$myrow["found"]."\" border=\"0\" align=\"middle\">\n";
	if($myrow["private"]==1)
		echo "<img src=\"gfx/private.gif\" alt=\"$l_markedprivate\" title=\"$l_markedprivate\" border=\"0\" align=\"middle\">\n";
	$hasattach=0;
	$tempsql = "select * from ".$tableprefix."_bindata where entrynr=".$myrow["entrynr"];
	if(!$tempresult = mysql_query($tempsql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	if($temprow=mysql_fetch_array($tempresult))
	{
		$hasattach=1;
		$fileinfo=$temprow["filename"]." (".$temprow["filesize"]." Bytes)";
		echo "<a href=\"../gbdownload.php?entrynr=".$myrow["entrynr"]."\"><img src=\"$url_gfx/attach.gif\" alt=\"$fileinfo\" title=\"$fileinfo\" border=\"0\" align=\"middle\"></a>\n";
	}
	if($myrow["sticky"]==1)
		echo "<img src=\"$url_gfx/stick.gif\" alt=\"$l_topentry\" title=\"$l_topentry\" border=\"0\" align=\"middle\">\n";
	if($myrow["editedbyadmin"]!=0)
	{
		if($admin_rights>1)
		{
			list($mydate,$mytime)=explode(" ",$myrow["admineditdate"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			if($month>0)
				$editdate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
			else
				$editdate="";
			$tempsql="select * from ".$tableprefix."_users where usernr=".$myrow["editedbyadmin"];
			if(!$tempresult = mysql_query($tempsql, $db))
			    die("<td class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			if($temprow=mysql_fetch_array($tempresult))
				$adminlabel="$l_editedby: ".$temprow["username"]." ($editdate)";
			else
				$adminlabel=$l_editedbyadmin;
			echo "<img src=\"gfx/edited.gif\" alt=\"$adminlabel\" title=\"$adminlabel\" border=\"0\" align=\"middle\">&nbsp; ";
		}
		else
			echo "<img src=\"gfx/edited.gif\" alt=\"$l_editedbyadmin\" title=\"$l_editedbyadmin\" border=\"0\" align=\"middle\">&nbsp; ";
	}
	echo "</td></tr></table></td>";
	echo "\n<td class=\"gbentry\">";
	echo "<table width=\"100%\" height=\"100%\" valign=\"top\" class=\"gbentry\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">\n";
	echo "<tr class=\"gbheading\">";
	echo "<td align=\"left\">";
	echo $displaydate;
	echo "</td></tr>\n";
	if(strlen($myrow["heading"])>0)
	{
		echo "<tr bgcolor=\"#c0c0c0\"><td align=\"left\">";
		$displayheading=stripslashes($myrow["heading"]);
		$displayheading=undo_htmlspecialchars($displayheading);
		echo $displayheading;
		echo "</td></tr>\n";
	}
	echo "<tr class=\"gbentry\"><td align=\"left\">";
	$displaytext=stripslashes($myrow["text"]);
	$displaytext = undo_htmlspecialchars($displaytext);
	$displaytext = str_replace("{contentbgcolor}",$contentbgcolor,$displaytext);
	$displaytext = str_replace("{contentfontcolor}",$contentfontcolor,$displaytext);
	$displaytext = str_replace("{contentfont}",$contentfont,$displaytext);
	$displaytext = str_replace("{contentfontsize}",$contentfontsize,$displaytext);
	$displaytext = str_replace("{bbc_quote}",$l_bbc_quote,$displaytext);
	$displaytext = str_replace("{bbc_code}",$l_bbc_code,$displaytext);
	echo $displaytext."</td></tr>\n";
	if($myrow["modcomment"])
	{
		list($mydate,$mytime)=explode(" ",$myrow["commentdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
		{
			$temptime=mktime($hour,$min,$sec,$month,$day,$year);
			$temptime=transposetime($temptime,$servertimezone,$displaytimezone);
			$displaydate=date($dateformat,$temptime);
		}
		else
			$displaydate="";
		echo "<tr class=\"modcomment\"><td align=\"left\">";
		if($admin_rights>1)
		{
			$tempsql = "select * from ".$tableprefix."_users where usernr=".$myrow["commenteditor"];
			if(!$tempresult = mysql_query($tempsql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			if($temprow=mysql_fetch_array($tempresult))
				echo "<i>".$temprow["username"]." ($displaydate):</i><br>";
			else
				echo "<i>$l_modcomment ($displaydate):</i><br>";
		}
		else
			echo "<i>$l_modcomment ($displaydate):</i><br>";
		$displaytext=stripslashes($myrow["modcomment"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		$displaytext = str_replace("{contentbgcolor}",$contentbgcolor,$displaytext);
		$displaytext = str_replace("{contentfontcolor}",$contentfontcolor,$displaytext);
		$displaytext = str_replace("{contentfont}",$contentfont,$displaytext);
		$displaytext = str_replace("{contentfontsize}",$contentfontsize,$displaytext);
		$displaytext = str_replace("{bbc_quote}",$l_bbc_quote,$displaytext);
		$displaytext = str_replace("{bbc_code}",$l_bbc_code,$displaytext);
		echo $displaytext."</td></tr>\n";
	}
	echo "</table></td></tr>\n";
	if($admin_rights>1)
	{
		echo "<tr class=\"adminactions\"><td colspan=\"2\" align=\"right\">";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=edit&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/edit.gif\" border=\"0\" alt=\"$l_edit\" title=\"$l_edit\" align=\"middle\"></a>&nbsp; ";
		if($myrow["validated"]==0)
			echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=validate&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/checkmark.gif\" border=\"0\" alt=\"$l_validate\" title=\"$l_validate\" align=\"middle\"></a>&nbsp; ";
		if($myrow["modcomment"])
			echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=delcomment&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/delcomment.gif\" border=\"0\" alt=\"$l_deletecomment\" title=\"$l_deletecomment\" align=\"middle\"></a>&nbsp; ";
		echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=comment&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/editcomment.gif\" border=\"0\" alt=\"$l_writecomment\" title=\"$l_writecomment\" align=\"middle\"></a>&nbsp; ";
		$dellink=do_url_session("$act_script_url?$langvar=$act_lang&mode=del&input_entrynr=$act_id&entrylang=$entrylang&start=$start");
		if($admdelconfirm==1)
			echo "<a href=\"javascript:confirmDel('$l_entry #$act_id','$dellink')\"><img src=\"gfx/delete.gif\" border=\"0\" alt=\"$l_delete\" title=\"$l_delete\" align=\"middle\"></a>&nbsp; ";
		else
			echo "<a href=\"".$dellink."\"><img src=\"gfx/delete.gif\" border=\"0\" alt=\"$l_delete\" title=\"$l_delete\" align=\"middle\"></a>&nbsp; ";
		if($myrow["sticky"]==0)
			echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=stick&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/top_entry.gif\" border=\"0\" alt=\"$l_topentry\" title=\"$l_topentry\" align=\"middle\"></a>&nbsp; ";
		else
			echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=unstick&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/detop_entry.gif\" border=\"0\" alt=\"$l_detopentry\" title=\"$l_detopentry\" align=\"middle\"></a>&nbsp; ";
		if($hasattach==1)
			echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=delattach&input_entrynr=$act_id&entrylang=$entrylang&start=$start")."\"><img src=\"gfx/delattach.gif\" border=\"0\" alt=\"$l_delattach\" title=\"$l_delattach\" align=\"middle\"></a>&nbsp; ";
		echo "<input type=\"checkbox\" name=\"entries[]\" value=\"".$myrow["entrynr"]."\">";
		echo "</td></tr>";
	}
	echo "<tr bgcolor=\"#000000\"><td colspan=\"2\">";
	echo "<img src=\"$url_gfx/space.gif\" border=\"0\" height=\"2\" width=\"2\"></td></tr>";
}
if(($admin_rights>1) && (mysql_numrows($result)>0))
{
	echo "<tr class=\"actionrow\"><td align=\"right\" colspan=\"2\">";
	echo "<input class=\"sgbbutton\" type=\"submit\" name=\"validate\" value=\"$l_validatemarked\">&nbsp;&nbsp;";
	echo "<input class=\"sgbbutton\" type=\"submit\" name=\"del\" value=\"$l_delmarked\"><br>";
	echo "<input class=\"sgbbutton\" type=\"button\" onclick=\"checkAll(document.listform)\" value=\"$l_checkall\">&nbsp;&nbsp;";
	echo "<input class=\"sgbbutton\" type=\"button\" onclick=\"uncheckAll(document.listform)\" value=\"$l_uncheckall\">";
	echo "</td></tr></form>";
}
?>
</table></td></tr>
<?php
if(($maxentries>0) && ($numentries>$maxentries))
{
	echo "<tr class=\"pagenav\"><td align=\"center\" colspan=\"2\">";
	if(floor(($start+$maxentries)/$maxentries)>1)
	{
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;start=0&amp;entrylang=$entrylang");
		echo "\">[&lt;&lt;]</a> ";
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".($start-$maxentries));
		echo "\">[&lt;]</a> ";
	}
	for($i=1;$i<($numentries/$maxentries)+1;$i++)
	{
		if(floor(($start+$maxentries)/$maxentries)!=$i)
		{
			echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".(($i-1)*$maxentries));
			echo "\">[$i]</a> ";
		}
		else
			echo "<b>($i)</b> ";
	}
	if($start < (($i-2)*$maxentries))
	{
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".($start+$maxentries));
		echo "\">[&gt;]</a> ";
		echo "<a class=\"pagenav\" href=\"".do_url_session("$act_script_url?$langvar=$act_lang&amp;entrylang=$entrylang&amp;start=".(($i-2)*$maxentries));
		echo "\">[&gt;&gt;]</a> ";
	}
	echo "</font></td></tr>";
}
echo "</table></td></tr></table>";
if($admin_rights>1)
{
	echo "<div class=\"bottombox\" align=\"center\">";
	echo "<a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&mode=new&entrylang=$entrylang")."\">$l_newentry</a>";
	echo "</div>";
}
include('./trailer.php')
?>
