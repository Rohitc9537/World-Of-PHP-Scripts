<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_avatars;
$page="avatars";
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_addavatar?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_description?>:</td><td><input class="sgbinput" type="text" name="description" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_image?>:</td><td><input class="sgbinput" type="text" name="image" size="40" maxlength="140">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_avatarupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("avatar_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="actionrow"><td align="center" colspan="2">
<input type="hidden" name="mode" value="add">
<input class="sgbbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_avatars?></a></div>
<?php
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$description)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nodescription</td></tr>";
			$errors=1;
		}
		if(!$image)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noimage</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$description=addslashes(do_htmlentities($description));
			$image=addslashes($image);
			$sql = "INSERT INTO ".$tableprefix."_avatars (name, image) ";
			$sql .="VALUES ('$description','$image')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add avatar to database.");
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_avataradded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?mode=new&$langvar=$act_lang")."\">$l_addavatar</a></div>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_avatars</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_avatars where (avatarnr=$input_avatarnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\"><td align=\"center\">";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_avatars</a></div>";
	}
	if($mode=="edit")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_avatars where (avatarnr='$input_avatarnr')";
		if(!$result = mysql_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.".mysql_error());
		if (!$myrow = mysql_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_editavatar?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="input_avatarnr" value="<?php echo $myrow["avatarnr"]?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_description?>:</td><td><input class="sgbinput" type="text" name="description" size="40" maxlength="80" value="<?php echo stripslashes($myrow["name"])?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_image?>:</td><td><input class="sgbinput" type="text" name="image" size="40" maxlength="140" value="<?php echo do_htmlentities(stripslashes($myrow["image"]))?>">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_avatarupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("avatar_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="update"><input class="sgbbutton" type="submit" value="<?php echo $l_update?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_avatars?></a></div>
<?php
	}
	if($mode=="update")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$description)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nodescription</td></tr>";
			$errors=1;
		}
		if(!$image)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noimage</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$description=addslashes(do_htmlentities($description));
			$image=addslashes($image);
			$sql = "update ".$tableprefix."_avatars set name='$description', image='$image' ";
			$sql .="where avatarnr=$input_avatarnr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update avatar in database.");
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_avatarupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_avatars</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights>1)
{
?>
<tr class="actionrow"><td align="center" colspan="4">
<a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addavatar?>
</td></tr>
<?php
}
if(!isset($sortorder))
	$sortorder=0;
$sql = "select * from ".$tableprefix."_avatars ";
if($sortorder==0)
	$sql.="order by name asc";
else
	$sql.="order by image asc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = mysql_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"4\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td class="rowheadings" align="center" width="30%"><b><?php echo $l_icon?></b></td>
<td class="rowheadings" align="center" width="30%"><b><a class="rowheadings" href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang&sortorder=1")?>"><?php echo $l_file?></a></b></td>
<td class="rowheadings" align="center" width="30%"><b><a class="rowheadings" href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang&sortorder=0")?>"><?php echo $l_description?></a></b></td>
<td class="rowheadings" width="30%">&nbsp;</td></tr>
<?php
		do {
			$act_id=$myrow["avatarnr"];
			echo "<tr class=\"displayrow\">";
			echo "<td align=\"center\">";
			if(!is_flash_file($myrow["image"]))
				echo "<img src=\"$url_avatars/".$myrow["image"]."\" border=\"0\">";
			else
			{
				echo "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"\n";
				echo "codebase=\"http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0\"\n";
				echo "id=\"avatar\">\n";
				echo "<param name=\"movie\" value=\"$url_avatars/".$myrow["image"]."\">\n";
				echo "<param name=\"menu\" value=false>\n";
				echo "<param name=\"quality\" value=\"high\">\n";
				echo "<param name=\"wmode\" value=\"transparent\">\n";
				echo "<param name=\"bgcolor\" value=\"#cccccc\">\n";
				echo "<embed name=\"avatar\" src=\"$url_avatars/".$myrow["image"]."\" menu=\"false\" quality=\"high\" wmode=\"transparent\" bgcolor=\"#cccccc\"\n";
				echo "type=\"application/x-shockwave-flash\"\n";
   				echo "pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
				echo "</embed>\n";
				echo "</object>\n";
			}
			echo "</td>";
			echo "<td align=\"center\">".do_htmlentities($myrow["image"])."</td>";
			echo "<td align=\"center\">".do_htmlentities($myrow["name"])."</td>";
			echo "<td>";
		if($admin_rights > 1)
		{
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_avatarnr=$act_id&$langvar=$act_lang")."\">";
			echo "<img src=\"gfx/delete.gif\" border=\"0\" src=\"$l_delete\" alt=\"$l_delete\"></a> ";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=edit&$langvar=$act_lang&input_avatarnr=$act_id")."\">";
			echo "<img src=\"gfx/edit.gif\" border=\"0\" title=\"$l_edit\" alt=\"$l_edit\"></a>";
		}
		echo "</td></tr>";
   } while($myrow = mysql_fetch_array($result));
   echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
?>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addavatar?></a></div>
<?php
}
}
include('./trailer.php');
?>