<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
$page_title=$l_flags;
$page="flags";
require_once('./heading.php');
if($admin_rights < 2)
	die("$l_functionnotallowed");
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="setdefault")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql="update ".$tableprefix."_flags set defentry=0";
		if(!$result=mysql_query($sql, $db))
		    die("Unable to update database.");
		$sql="update ".$tableprefix."_flags set defentry=1 where flagnr=$input_flagnr";
		if(!$result=mysql_query($sql, $db))
		    die("Unable to update database.");
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_done<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_flags</a></div>";
	}
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_addflag?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_country?>:</td><td><input class="sgbinput" type="text" name="country" size="30" maxlength="30"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_flag?>:</td><td><input class="sgbinput" type="text" name="image" size="40" maxlength="80">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_flagupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("flag_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="add"><input class="sgbbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_flags?></a></div>
<?php
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$country)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nocountry</td></tr>";
			$errors=1;
		}
		else
		{
			$sql="select * from ".$tableprefix."_flags where country='$country'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database.");
			if($myrow=mysql_fetch_array($result))
			{
				echo "<tr class=\"errorrow\"><td align=\"center\">";
				echo "$l_countryexists</td></tr>";
				$errors=1;
			}
		}
		if(!$image)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noflag</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$displaypos=1;
			$sql = "select max(displaypos) as newdisplaypos from ".$tableprefix."_flags";
			if(!$result=mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add flag to database.");
			if($myrow=mysql_fetch_array($result))
				$displaypos=$myrow["newdisplaypos"]+1;
			$image=addslashes($image);
			$sql = "INSERT INTO ".$tableprefix."_flags (country, image, displaypos) ";
			$sql .="VALUES ('$country','$image', $displaypos)";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add flag to database.");
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_flagadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?mode=new&$langvar=$act_lang")."\">$l_addflag</a></div>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_flags</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_flags where (flagnr=$input_flagnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\"><td align=\"center\">";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_flags</a></div>";
	}
	if($mode=="edit")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_flags where (flagnr=$input_flagnr)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("<tr class=\"errorrow\"><td>no such entry");
?>
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_editflag?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="input_flagnr" value="<?php echo $myrow["flagnr"]?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_country?>:</td><td><input class="sgbinput" type="text" name="country" size="30" maxlength="30" value="<?php echo do_htmlentities(stripslashes($myrow["country"]))?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_flag?>:</td><td><input class="sgbinput" type="text" name="image" size="40" maxlength="80" value="<?php echo do_htmlentities(stripslashes($myrow["image"]))?>">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_flagupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("flag_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="update"><input class="sgbbutton" type="submit" value="<?php echo $l_update?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_flags?></a></div>
<?php
	}
	if($mode=="update")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$country)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nocountry</td></tr>";
			$errors=1;
		}
		else
		{
			$sql="select * from ".$tableprefix."_flags where country='$country' and flagnr!='$input_flagnr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database.");
			if($myrow=mysql_fetch_array($result))
			{
				echo "<tr class=\"errorrow\"><td align=\"center\">";
				echo "$l_countryexists</td></tr>";
				$errors=1;
			}
		}
		if(!$image)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noflag</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$image=addslashes($image);
			$sql = "UPDATE ".$tableprefix."_flags SET country='$country', image='$image' ";
			$sql .="WHERE (flagnr = $input_flagnr)";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.".mysql_error());
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_flagupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_flags</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights>1)
{
?>
<tr class="actionrow"><td align="center" colspan="6">
<a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addflag?>
</td></tr>
<?php
}
if(isset($move))
{
	if($move=="up")
	{
		$sql="select displaypos from ".$tableprefix."_flags where flagnr='$input_flagnr'";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		if(!$myrow=mysql_fetch_array($result))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Calling error.");
		$newpos=$myrow["displaypos"]-1;
		$sql="update ".$tableprefix."_flags set displaypos=displaypos+1 where displaypos=$newpos";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		$sql="update ".$tableprefix."_flags set displaypos=$newpos where flagnr=$input_flagnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
	}
	if($move=="down")
	{
		$sql="select displaypos from ".$tableprefix."_flags where flagnr='$input_flagnr'";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		if(!$myrow=mysql_fetch_array($result))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Calling error.");
		$newpos=$myrow["displaypos"]+1;
		$sql="update ".$tableprefix."_flags set displaypos=displaypos-1 where displaypos=$newpos";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		$sql="update ".$tableprefix."_flags set displaypos=$newpos where flagnr=$input_flagnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
	}
}
$sql = "select * from ".$tableprefix."_flags order by displaypos asc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = mysql_fetch_array($result))
{
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"6\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td class="rowheadings" align="center" width="20%"><b><?php echo $l_flag?></b></td>
<td class="rowheadings" align="center" width="40%"><b><?php echo $l_country?></b></td>
<td class="rowheadings" align="center" width="20%"><b><?php echo $l_default?></b></td>
<td class="rowheadings" width="5%">&nbsp;</td>
<td class="rowheadings" width="5%">&nbsp;</td>
<td>&nbsp;</td></tr>
<?php
	$mycount=0;
	do {
		$mycount++;
		$act_id=$myrow["flagnr"];
		echo "<tr class=\"displayrow\">";
		echo "<td align=\"center\"><img src=\"$url_flags/".$myrow["image"]."\" border=\"0\"></td>";
		echo "<td align=\"center\">".do_htmlentities($myrow["country"])."</td>";
		echo "<td align=\"center\">";
		if($myrow["defentry"]==1)
			echo "<img src=\"gfx/checkmark.gif\" align=\"middle\" border=\"0\">";
		else
		{
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=setdefault&input_flagnr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_set</a>";
		}
		echo "</td>";
		if($myrow["displaypos"]==0)
		{
			$tempsql="select max(displaypos) as newdisplaypos from ".$tableprefix."_flags";
			if(!$tempresult = mysql_query($tempsql, $db))
				die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			if(!$temprow = mysql_fetch_array($tempresult))
				$newpos=1;
			else
				$newpos=$temprow["newdisplaypos"]+1;
			$updatesql="update ".$tableprefix."_flags set displaypos=$newpos where flagnr=".$myrow["flagnr"];
			if(!$updateresult = mysql_query($updatesql, $db))
				die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		}
		if($mycount>1)
		{
			echo "<td align=\"center\">";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?move=up&input_flagnr=$act_id&$$langvar=$act_lang")."\">";
			echo "<img src=\"gfx/up.gif\" border=\"0\" title=\"$l_move_up\" alt=\"$l_move_up\"></a>";
			echo "</td>";
		}
		else
			echo "<td>&nbsp;</td>";
		if($mycount<mysql_num_rows($result))
		{
			echo "<td align=\"center\">";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?move=down&input_flagnr=$act_id&$$langvar=$act_lang")."\">";
			echo "<img src=\"gfx/down.gif\" border=\"0\" title=\"$l_move_down\" alt=\"$l_move_down\"></a>";
			echo "</td>";
		}
		else
			echo "<td>&nbsp;</td>";
		echo "<td>";
		if($admin_rights > 1)
		{
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_flagnr=$act_id&$langvar=$act_lang")."\">";
			echo "<img src=\"gfx/delete.gif\" border=\"0\" alt=\"$l_delete\" title=\"$l_delete\"></a> ";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=edit&$langvar=$act_lang&input_flagnr=$act_id")."\">";
			echo "<img src=\"gfx/edit.gif\" border=\"0\" alt=\"$l_edit\" title=\"$l_edit\"></a>";
		}
		echo "</td></tr>";
   } while($myrow = mysql_fetch_array($result));
   echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
?>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addflag?></a></div>
<?php
}
}
include('./trailer.php');
?>