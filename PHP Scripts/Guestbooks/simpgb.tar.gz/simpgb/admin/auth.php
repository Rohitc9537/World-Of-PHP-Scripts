<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function do_login($username, $pw, $db)
{
	global $tableprefix, $userdata, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure, $act_lang, $langvar, $url_sessid, $sessid_url, $enablerecoverpw, $max_login_logs;

	$pinlogin=0;
	$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
	if(!$result = mysql_query($sql, $db)) {
		die("<tr class=\"errorrow\"><td>Could not connect to the database. (1) ".mysql_error());
	}
	if ($myrow = mysql_fetch_array($result))
	{
		$watchlogins=$myrow["watchlogins"];
		$enablefailednotify=$myrow["enablefailednotify"];
		$simpgbmail=$myrow["simpgbmail"];
		if(!$simpgbmail)
			$simpgbmail="simpgb@foo.bar";
		$loginlimit=$myrow["loginlimit"];
		$dateformat="Y-m-d H:i:s";
	}
	else
	{
		$watchlogins=1;
		$enablefailednotify=0;
		$simpgbmail="simpgb@foo.bar";
		$dateformat="Y-m-d H:i:s";
		$loginlimit=0;
	}
	if(isbanned(get_userip(),$db))
	{
		return -99; exit;
	}
	if(!$username)
	{
		return -1; exit;
	}
	if(!$pw)
	{
		return -2; exit;
	}
	$entered_pw=$pw;
	$pw=md5($pw);
	$sql = "select * from ".$tableprefix."_users where (username = '$username') and (password = '$pw')";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database (".$tableprefix."_users 1).".mysql_error());
	if (!$myrow = mysql_fetch_array($result))
	{
		if(!$enablerecoverpw)
		{
			log_failed($username, $entered_pw, get_userip(), $dateformat, $db, $tableprefix, $enablefailednotify, $simpgbmail);
			return 0;
		}
		$sql = "select * from ".$tableprefix."_users where (username = '$username') and (autopin = '$entered_pw') and (autopin!=0)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database (".$tableprefix."_users 2).".mysql_error());
		if (!$myrow = mysql_fetch_array($result))
		{
			log_failed($username, $entered_pw, get_userip(), $dateformat, $db, $tableprefix, $enablefailednotify, $simpgbmail);
			return 0;
		}
		else
			$pinlogin=1;
	}
	$userdata = get_userdata($username, $db);
	if(($userdata["rights"]<4) && ($loginlimit>0))
	{
		cleanup_old_sessions($sesscookietime,$db);
		if($loginlimit <= count_logged_users($db))
		{
			return 22; exit;
		}
	}
	$sessid = new_session($userdata["usernr"], get_userip(), $sesscookietime, $db, $userdata["lastlogin"]);
	if($sessid_url)
		$url_sessid=$sessid;
	else
		set_sessioncookie($sessid, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure);
	$actdate = date("Y-m-d H:i:s");
	$sql = "UPDATE ".$tableprefix."_users set lastlogin='$actdate' where usernr=".$userdata["usernr"];
	if(!$result = mysql_query($sql, $db))
		die("<tr class=\"errorrow\"><td>Could not connect to database (".$tableprefix."_users 3).".mysql_error());
	if($watchlogins==1)
	{
		if($max_login_logs>0)
		{
			$sql = "select * from ".$tableprefix."_iplog where usernr=".$userdata["usernr"];
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
			while(mysql_num_rows($result)>=$max_login_logs)
			{
				$sql = "select * from ".$tableprefix."_iplog where usernr=".$userdata["usernr"]." order by logtime asc limit 1";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
				$myrow=mysql_fetch_array($result);
				$sql = "delete from ".$tableprefix."_iplog where logtime='".$myrow["logtime"]."' and usernr=".$userdata["usernr"];
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
				$sql = "select * from ".$tableprefix."_iplog where usernr=".$userdata["usernr"];
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to get userdata from DB");
			}
		}
		$actdate = date("Y-m-d H:i:s");
		$sql = "INSERT ".$tableprefix."_iplog (usernr, logtime, ipadr, used_lang) values (".$userdata["usernr"].", '$actdate', '".get_userip()."', '$act_lang')";
		if(!$result = mysql_query($sql, $db))
			die("<tr class=\"errorrow\"><td>Could not connect to the database (".$tableprefix."_iplog).".mysql_error());
	}
	if($pinlogin==0)
	{
		$sql = "update ".$tableprefix."_users set autopin=0 where usernr=".$userdata["usernr"];
		if(!$result = mysql_query($sql, $db))
			die("<tr class=\"errorrow\"><td>Could not connect to the database (".$tableprefix."_users).".mysql_error());
		return 1; exit;
	}
	else
	{
		return 4711; exit;
	}
}

function count_logged_users($db)
{
	global $tableprefix;
	$sql = "select * from ".$tableprefix."_session";
	if(!$result=mysql_query($sql,$db))
		die("<tr class=\"errorrow\"><td>Error counting logged users");
	return mysql_numrows($result);
}

function get_userdata($username, $db)
{
	global $tableprefix;
	$sql = "SELECT * FROM ".$tableprefix."_users WHERE username = '$username'";
	if(!$result = mysql_query($sql, $db))
		$userdata = array("error" => "1");
	if(!$myrow = mysql_fetch_array($result))
		$userdata = array("error" => "1");
	return($myrow);
}

function cleanup_old_sessions($lifetime,$db)
{
	global $tableprefix;
	$expiretime = (string) (time() - $lifetime);
	$delsql = "DELETE FROM ".$tableprefix."_session WHERE (starttime < $expiretime)";
	$delresult = mysql_query($delsql, $db);
	if (!$delresult)
		die("<tr class=\"errorrow\"><td>Error deleting old sessions");
}

function new_session($userid, $ip, $lifetime, $db, $lastlogin)
{
	global $tableprefix;
	mt_srand((double)microtime()*1000000);
	$sessid = mt_rand();
	$currtime = (string) (time());
	cleanup_old_sessions($lifetime,$db);
	$sql = "INSERT INTO ".$tableprefix."_session (sessid, usernr, starttime, remoteip, lastlogin) VALUES ($sessid, $userid, $currtime, '$ip', '$lastlogin')";
	$result = mysql_query($sql, $db);
	if ($result)
		return $sessid;
	else
		die("<tr class=\"errorrow\"><td>Unable to create new session");
}

function set_sessioncookie($sessid, $cookietime, $cookiename, $cookiepath, $cookiedomain, $cookiesecure) {
	$cookieexpire=time()+($cookietime*2);
	setcookie($cookiename,$sessid,$cookieexpire,$cookiepath,$cookiedomain,$cookiesecure);
}

function get_userid_from_session($sessid, $cookietime, $ip, $db)
{
	global $tableprefix;
	$mintime = time() - $cookietime;
	$sql = "SELECT usernr FROM ".$tableprefix."_session WHERE (sessid = $sessid) AND (starttime > $mintime) AND (remoteip = '$ip')";
	$result = mysql_query($sql, $db);
	if (!$result)
		die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	$row = mysql_fetch_array($result);
	if (!$row) {
		return 0;
	} else {
		return $row["usernr"];
	}
}

function get_lastlogin_from_session($sessid, $cookietime, $ip, $db)
{
	global $tableprefix;
	$mintime = time() - $cookietime;
	$sql = "SELECT lastlogin FROM ".$tableprefix."_session WHERE (sessid = $sessid) AND (starttime > $mintime) AND (remoteip = '$ip')";
	$result = mysql_query($sql, $db);
	if (!$result)
		die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	$row = mysql_fetch_array($result);
	if (!$row) {
		return 0;
	} else {
		return $row["lastlogin"];
	}
}

function update_session($sessid, $db)
{
	global $tableprefix, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure, $sessid_url;
	$newtime = (string) time();
	$sql = "UPDATE ".$tableprefix."_session SET starttime=$newtime WHERE (sessid = $sessid)";
	$result = mysql_query($sql, $db);
	if (!$result)
		die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	if(!$sessid_url)
		set_sessioncookie($sessid, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure);
	return 1;
}

function get_userdata_by_id($userid, $db)
{
	global $tableprefix;
	$sql = "SELECT * FROM ".$tableprefix."_users WHERE usernr = '$userid'";
	if(!$result = mysql_query($sql, $db)) {
		$userdata = array("error" => "1");
		return ($userdata);
	}
	if(!$myrow = mysql_fetch_array($result)) {
		$userdata = array("error" => "1");
		return ($userdata);
	}
	return($myrow);
}

function end_session($userid, $db)
{
	global $tableprefix;
	$sql = "DELETE FROM ".$tableprefix."_session WHERE (usernr = $userid)";
	$result = mysql_query($sql, $db);
	if (!$result)
		die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	return 1;
}

function log_failed($username, $password, $remoteip, $dateformat, $db, $tableprefix, $enablefailednotify, $simpgbmail)
{
	global $max_failed_logs, $use_smtpmail, $l_fm_subj, $l_fm_msg, $contentcharset, $crlf;

	$actdate = date("Y-m-d H:i:s");
	$displaydate = date($dateformat);
	if($max_failed_logs>0)
	{
		$sql = "select * from ".$tableprefix."_failed_logins";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
		while(mysql_num_rows($result)>=$max_failed_logs)
		{
			$sql = "select * from ".$tableprefix."_failed_logins order by logindate asc limit 1";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
			$myrow=mysql_fetch_array($result);
			$sql = "delete from ".$tableprefix."_failed_logins where logindate='".$myrow["logindate"]."'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
			$sql = "select * from ".$tableprefix."_failed_logins";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
		}
	}
	$sql = "INSERT INTO ".$tableprefix."_failed_logins (username, ipadr, logindate, usedpw) ";
	$sql .="values ('$username', '$remoteip', '$actdate', '$password')";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	if($enablefailednotify)
	{
		include_once('../includes/htmlMimeMail.inc');
		if($use_smtpmail)
		{
			include_once('../includes/smtp.inc');
			include_once('../includes/RFC822.inc');
		}
		$sql = "select u.email from ".$tableprefix."_failed_notify fn, ".$tableprefix."_users u where u.usernr=fn.usernr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
		if($myrow=mysql_fetch_array($result))
		{
			$usercount=0;
			$mailmsg = sprintf($l_fm_msg,$displaydate,$remoteip,$username,$password);
			do{
				$receiver[$usercount]=$myrow["email"];
				$usercount++;
			}while($myrow=mysql_fetch_array($result));
			$mail = new htmlMimeMail();
			$mail->setCrlf($crlf);
			$mail->setTextCharset($contentcharset);
			$mail->setText($mailmsg);
			$mail->setSubject($l_fm_subj);
			$mail->setFrom($simpgbmail);
			for($i=0;$i<count($receiver);$i++)
			{
				$currentreceiver=array($receiver[$i]);
				if($use_smtpmail)
				{
					$mail->setSMTPParams($smtpserver,$smtpport,NULL,$smtpauth,$smtpuser,$smtppasswd);
						$mail->send($currentreceiver, "smtp");
				}
				else
						$mail->send($currentreceiver, "mail");
			}
		}
	}
}

function count_sessions()
{
	global $tableprefix, $sesscookietime, $db, $loginlimit;

	cleanup_old_sessions($sesscookietime,$db);
	$sql = "SELECT * FROM ".$tableprefix."_session";
	$result = mysql_query($sql, $db);
	if (!$result)
		die("<tr class=\"errorrow\"><td>Error counting sessions");
	$numsessions=mysql_num_rows($result);
	if($numsessions>1)
	{
		if($loginlimit>0)
		{
			if($numsessions<$loginlimit)
				return ("<span class=\"sesswarn\">$numsessions");
			else
				return ("<span class=\"sesslimit\">$numsessions");
		}
		else
			return ("<span class=\"sesswarn\">$numsessions");
	}
	else
		return ("<span class=\"sessok\">$numsessions");
}
?>