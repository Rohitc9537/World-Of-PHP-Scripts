<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_resetviewcount;
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights < 2)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($mode))
{
	if($mode=="viewcount")
	{
		$actdate = date("Y-m-d");
		$sql = "delete from ".$tableprefix."_counts";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\">Could not connect to the database.");
		$sql = "insert into ".$tableprefix."_counts (hitcountstart) values('$actdate')";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td align=\"center\">Could not connect to the database.");
?>
<tr class="displayrow"><td align="center"><?php echo $l_viewcountreset?></td></tr>
</table></td></tr></table>
<?php
	}
}
include('./trailer.php');
?>