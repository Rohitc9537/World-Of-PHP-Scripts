<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('../functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('../language/lang_'.$act_lang.'.php');
?>
<html>
<head>
<meta name="generator" content="SimpGB v<?php echo $version?>, <?php echo $copyright_asc?>">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_emoticonlist?></title>
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
<script language='javascript'>
function chooseemoticon(code)
{
	mywin=parent.window.opener;
	field = mywin.document.commentform.destfield.value;
	eval('currentText = mywin.document.commentform.'+field+'.value');
	revisedText = currentText+" "+code+" ";
	eval('mywin.document.commentform.'+field+'.value=revisedText');
	parent.window.focus();
	top.window.close();
	eval('mywin.document.commentform.'+field+'.focus()');
}
</SCRIPT>
</head>
<body>
<?php
	$sql = "select * from ".$tableprefix."_emoticons";
	if(!$result = mysql_query($sql, $db))
	   	die("Could not connect to the database.");
?>
<table width="98%" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER">
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR class="headingrow" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="98%"><h3><?php echo $l_emoticonlist?></h3></td>
<td align="center" valign="middle" width="2%"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $url_gfx?>/close.gif" border="0" title="<?php echo $l_close?>" alt="<?php echo $l_close?>"></a></td></tr>
</table></td></tr>
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
	if(!$myrow=mysql_fetch_array($result))
	{
?>
<tr class="displayrow" align="center">
<td align="left" valign="middle" colspan="2"><?php echo $l_nonavailable?></td></tr>
<?php
	}
	else
	{
?>
<tr class="rowheadings" align="center">
<td class="rowheadings" align="center" valign="middle" width="2%">&nbsp;</td>
<td class="rowheadings" align="center" valign="middle" width="20%"><b><?php echo $l_code?></b></td>
<td class="rowheadings" align="center" valign="middle"><b><?php echo $l_emotion?></b></td>
<?php
		do{
?>
<tr class="displayrow" align="center">
<td align="center" valign="middle" width="2%">
<a href="javascript:chooseemoticon('<?php echo " ".stripslashes($myrow["code"])." "?>')"><img src="<?php echo "$url_emoticons/".stripslashes($myrow["emoticon_url"])?>" border="0"></a></td>
<td align="center" valign="middle" width="20%">
<?php echo do_htmlentities(stripslashes($myrow["code"]))?></td>
<td align="center" valign="middle">
<?php echo do_htmlentities(stripslashes($myrow["emotion"]))?></td></tr>
<?php
		}while($myrow=mysql_fetch_array($result));
	}
?>
</table></td></tr>
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR class="headingrow" ALIGN="CENTER"><td>&nbsp;</td>
<td align="center" valign="middle" width="2%">
<a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $url_gfx?>/close.gif" border="0" title="<?php echo $l_close?>" alt="<?php echo $l_close?>"></a>
</td></tr>
</table></td></tr></table>
</body></html>
