<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
if(!isset($bbcbuttons))
	$bbcbuttons=false;
if(!isset($page))
	$page="";
if(!$noseccheck)
{
	$stop_now=0;
	$stopmsg="";
	if(file_exists("mkconfig.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","mkconfig.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_avatars.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_avatars.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_emoticons.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_emoticons.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_flags.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_flags.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_freemailer.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_freemailer.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("install.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","install.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	$dir = opendir("./");
	while ($file = readdir($dir))
	{
		if (ereg("^upgrade_", $file))
		{
			$stop_now=1;
			$msg=str_replace("{file}",$file,$l_remove_file);
			$stopmsg.="<li>$msg";
		}
	}
	if(@fopen("../config.php", "a"))
	{
		$stop_now=1;
		$stopmsg.="<li>$l_config_writeable";
	}
	if($stop_now==1)
		die("<ul>".$stopmsg."</ul>");
}
$servertimezone=0;
$displaytimezone=0;
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db))
    die("<tr class=\"errorrow\"><td>Could not connect to the database. ".mysql_error());
if($myrow = mysql_fetch_array($result))
{
	$usemenubar=$myrow["usemenubar"];
	$servertimezone=$myrow["servertimezone"];
	$displaytimezone=$myrow["displaytimezone"];
	$admdelconfirm=$myrow["admdelconfirm"];
	$msendlimit=$myrow["msendlimit"];
	$admddautosub=$myrow["admddautosub"];
	$loginlimit=$myrow["loginlimit"];
}
else
{
	$usemenubar=0;
	$servertimezone=0;
	$displaytimezone=0;
	$admdelconfirm=0;
	$msendlimit=30;
	$admddautosub=0;
	$loginlimit=0;
}
require_once('../functions.php');
require_once('./functions.php');
if(is_leacher($HTTP_USER_AGENT))
{
	header("HTTP/1.0 403 Forbidden");
	exit;
}
if($admoldhdr)
{
	header('Pragma: no-cache');
	header('Expires: 0');
}
else
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
}
if(!isset($redirect))
{
	// Page to redirect after login
	$redirect=$url_simpgb."/admin/index.php?$langvar=$act_lang";
	if($iis_workaround && $HTTP_SERVER_VARS['QUERY_STRING'])
		$redirect = $act_script_url . "?" .$HTTP_SERVER_VARS['QUERY_STRING'];
	else if($new_global_handling)
		$redirect=$_SERVER["REQUEST_URI"];
	else
		$redirect=$REQUEST_URI;
}
include_once('../includes/bbcode.inc');
$user_loggedin=0;
$userdata = Array();
if(!isset($page))
	$page="";
$url_sessid=0;
$banreason="";
if(isset($do_login))
{
	$myusername=addslashes(strtolower($username));
	$result=do_login($myusername,$userpw,$db);
	if($result==22)
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>SimpGB - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
		if(is_ns4())
			echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
		else if(is_ns6())
			echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
		else if(is_opera())
			echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
		else if(is_konqueror())
			echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
		else if(is_gecko())
			echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
		else
			echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" valign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="sitename"><h4><?php echo "$simpgbsitedesc ($simpgbsitename)"?></h4></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><?php echo $l_too_many_users?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	if($result==-99)
	{
?>
<!DOCTYPE public "-//w3c//dtd html 4.01 transitional//en"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>SimpGB - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" valign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="sitename"><h4><?php echo "$simpgbsitedesc ($simpgbsitename)"?></h4></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	if(($result!=1) && ($result!=4711))
	{
?>
<!DOCTYPE public "-//w3c//dtd html 4.01 transitional//en"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>SimpGB - <?php echo $l_loginpage?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" valign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="sitename"><h4><?php echo "$simpgbsitedesc ($simpgbsitename)"?></h4></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="errorrow"><td align="center" colspan="2">
<?php echo $l_loginerror?></td></tr>
<tr class="inputrow"><form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="redirect" value="<?php echo $redirect?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input class="sgbinput" type="text" name="username" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_password?>:</td><td><input class="sgbinput" type="password" name="userpw" size="40" maxlength="40"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" name="do_login" value="<?php echo $l_login?>"></td></tr>
<?php
if($enablerecoverpw && !$enable_htaccess)
{
?>
<tr class="actionrow"><td align="center" colspan="2"><a href="pwlost.php?<?php echo "$langvar=$act_lang"?>"><?php echo $l_pwlost?></td></tr>
<?php
}
?>
</form></table></td></tr></table>
<?php
	echo "<hr><div class=\"copyright\" align=\"center\">$copyright_url $copyright_note</div>";
	exit;
	}
	else
	{
		if($result==4711)
			$redirect="changepw.php?$langvar=$act_lang";
		if($sessid_url)
			$redirect=do_url_session($redirect);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0.01; URL=$redirect\">";
		exit;
	}
}
if($enable_htaccess)
{
	if(isbanned(get_userip(),$db))
	{
?>
<!DOCTYPE public "-//w3c//dtd html 4.01 transitional//en"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="generator" content="SimpGB v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>SimpGB - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" valign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="sitename"><h4><?php echo "$simpgbsitedesc ($simpgbsitename)"?></h4></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_users where username='$myusername'";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database ".mysql_error());
	if (!$myrow = mysql_fetch_array($result))
	    die("<tr class=\"errorrow\"><td>User not defined for SimpGB");
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		}
	}
}
else
{
	$userid="";
	if($new_global_handling)
	{
		if(isset($_COOKIE[$sesscookiename]))
		{
			$sessid = $_COOKIE[$sesscookiename];
			$userid = get_userid_from_session($sessid, $sesscookietime, get_userip(), $db);
		}
	}
	else
	{
		if(isset($_COOKIE[$sesscookiename])) {
			$sessid = $_COOKIE[$sesscookiename];
			$userid = get_userid_from_session($sessid, $sesscookietime, get_userip(), $db);
		}
	}
	if ($userid) {
	   $user_loggedin = 1;
	   update_session($sessid, $db);
	   $userdata = get_userdata_by_id($userid, $db);
	   $userdata["lastlogin"]=get_lastlogin_from_session($sessid, $sesscookietime, get_userip(), $db);
	}
}
if($user_loggedin==0)
	$page_title=$l_loginpage;
?>
<!DOCTYPE public "-//w3c//dtd html 4.01 transitional//en"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>SimpGB - <?php echo $page_title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./css/sgbadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./css/sgbadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./css/sgbadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./css/sgbadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./css/sgbadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./css/sgbadm.css type=text/css>\n";
if($user_loggedin!=0)
{
	if($attach_in_fs)
	{
		$att2fs=4;
		$att2db=3;
	}
	else
	{
		$att2fs=3;
		$arr2db=4;
	}
	include_once("menus.php");
	if(!is_opera() && !is_ns4() && !is_gecko() && !is_msie())
	{
		include("./includes/js/menu1.inc");
	}
	else
	{
		include("./includes/js/menu2.inc");
	}
	include_once("./includes/js/global.inc");
	if($page)
	{
		if(file_exists('./includes/js/'.$page.'.inc'))
			include_once('./includes/js/'.$page.'.inc');
	}
	if($bbcbuttons)
	{
		include_once('../includes/get_layout.inc');
		include_once("./includes/js/bbcodes.inc");
	}
}
?>
</head>
<body>
<table width="80%" align="CENTER" valign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpGB v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="sitename"><h4><?php echo "$simpgbsitedesc ($simpgbsitename)"?></h4></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr></table>
<?php
if($user_loggedin==0)
{
	if(isbanned(get_userip(),$db))
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<?php
		if($banreason)
		{
?>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
<?php
		}
?>
</table></td></tr></table></body></html>
<?php
		exit;
	}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center" colspan="2">
<?php echo $l_notloggedin?></td></tr>
<tr class="inputrow"><form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="redirect" value="<?php echo $redirect?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input class="sgbinput" type="text" name="username" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_password?>:</td><td><input class="sgbinput" type="password" name="userpw" size="40" maxlength="40"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" name="do_login" value="<?php echo $l_login?>"></td></tr>
<?php
if($enablerecoverpw && !$enable_htaccess)
{
?>
<tr class="actionrow"><td align="center" colspan="2"><a href="pwlost.php?<?php echo "$langvar=$act_lang"?>"><?php echo $l_pwlost?></td></tr>
<?php
}
?>
</form></table></td></tr></table>
<?php
	echo "<hr><div class=\"copyright\" align=\"center\">$copyright_url $copyright_note</div>";
	exit;
}
else
{
	$shutdown=0;
	$act_usernr=$userdata["usernr"];
	$admin_rights=$userdata["rights"];
	if($admin_rights<0)
		die("<tr class=\"errorrow\"><td>$l_functionnotallowed");
	$sql = "select * from ".$tableprefix."_misc";
	if(!$result = mysql_query($sql, $db))
		die("<tr class=\"errorrow\"><td>Could not connect to the database (".$tableprefix."_misc)".mysql_error());
	if ($temprow = mysql_fetch_array($result))
	{
		if(($temprow["shutdown"]>0) && ($admin_rights<4))
		{
			echo "<div align=\"center\">";
			$shutdowntext=stripslashes($temprow["shutdowntext"]);
			$shutdowntext = undo_htmlspecialchars($shutdowntext);
			echo $shutdowntext;
			echo "</div>";
			$shutdown=1;
			include('trailer.php');
			exit;
		}
	}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	$nummenucols=0;
	if($usemenubar==1)
	{
		if(!is_opera() && !is_ns4() && !is_gecko() && !is_msie())
		{
			echo "<tr class=\"menurow\">";
			for($i=0;$i<count($l_menus);$i++)
			{
				if($l_menus[$i][0]["level"]<=$userdata["rights"])
				{
					echo "<td align=\"center\" valign=\"middle\" width=\"80\" height=\"20\">";
					echo "<a href=\"".do_url_session($l_menus[$i][0]["url"])."\" ";
					echo "onMouseOver = \"enterTopItem ($i);\" onMouseOut = \"exitTopItem ($i);\" class=\"topMenu\">".$l_menus[$i][0]["entry"]."</a></td>";
					$nummenucols++;
				}
			}
		}
		else
		{
			echo "<tr class=\"menurow\">";
			for($i=0;$i<count($l_menus);$i++)
			{
				if($l_menus[$i][0]["level"]<=$userdata["rights"])
				{
  					echo "<td width=\"20%\">";
  					echo "<ilayer id=\"layerMenu$i\"><div id=\"divMenu$i\">";
    				echo "<img src=\"gfx/space.gif\" width=\"6\" height=\"25\" alt=\"\" border=\"0\">";
  					echo "</div></ilayer></td>";
  					$nummenucols++;
  				}
			}
			for($j=$nummenucols;$j<count($l_menus);$j++)
			{
				echo "<td width=\"20%\">";
   				echo "<img src=\"gfx/space.gif\" width=\"6\" height=\"25\" alt=\"\" border=\"0\">";
   				echo "</td>";
   			}
		}
	}
	else
		echo "<tr class=\"menurow\">";
	echo "</tr>";
	if((($userdata["rights"]>2)||($shutdown<1)) && ($page!="index"))
	{
		echo "<tr class=\"actionrow\"><td align=\"center\"";
		if($nummenucols>0)
			echo " colspan=\"".count($l_menus)."\"";
		echo ">";
		echo "<a href=\"".do_url_session("index.php?$langvar=$act_lang")."\">$l_mainmenu</a>";
		echo "</td></tr>";
	}
	echo "</table></td></tr></table>";
}
?>
