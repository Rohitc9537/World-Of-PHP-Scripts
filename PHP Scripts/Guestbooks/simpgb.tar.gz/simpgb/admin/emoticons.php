<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
$page_title=$l_emoticons;
$page="emoticons";
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		// Display empty form for entering userdata
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_addemoticon?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_code?>:</td><td><input class="sgbinput" type="text" name="code" size="20" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_url?>:</td><td><input class="sgbinput" type="text" name="emoticon_url" size="40" maxlength="100">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_emoticonupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("emoticon_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_emotion?>:</td><td><input class="sgbinput" type="text" name="emotion" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_layout?>:</td><td>
<select name="layoutid">
<option value="" selected><?php echo $l_all?></option>
<?php
	$tempsql = "select * from ".$tableprefix."_layout group by id";
	if(!$tempresult = mysql_query($tempsql, $db)) {
	    die("Could not connect to the database.");
	}
	if($temprow=mysql_fetch_array($tempresult))
	{
		do{
			echo "<option value=\"".$temprow["id"]."\"";
			echo ">".$temprow["id"];
			echo "</option>";
		}while($temprow=mysql_fetch_array($tempresult));
	}
?>
</select>
</td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="inlist" value="1"><?php echo $l_inshortcutlist?></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="add"><input class="sgbbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_emoticons?></a></div>
<?php
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(isset($inlist))
			$inshortcutlist=1;
		else
			$inshortcutlist=0;
		if(!$code)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nocode</td></tr>";
			$errors=1;
		}
		if(!$emoticon_url)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nourl</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$code=addslashes($code);
			$emoticon_url=addslashes($emoticon_url);
			$emotion=addslashes($emotion);
			$sql = "INSERT INTO ".$tableprefix."_emoticons (layoutid, code, emoticon_url, emotion, inshortcutlist) ";
			$sql .="VALUES ('$layoutid', '$code','$emoticon_url', '$emotion', '$inshortcutlist')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add emoticon to database.");
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_emoticonadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_emoticons</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_emoticons where (iconnr=$input_iconnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\"><td align=\"center\">";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_emoticons</a></div>";
	}
	if($mode=="edit")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_emoticons where (iconnr='$input_iconnr')";
		if(!$result = mysql_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_editemoticon?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="input_iconnr" value="<?php echo $myrow["iconnr"]?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_code?>:</td><td><input class="sgbinput" type="text" name="code" size="20" maxlength="20" value="<?php echo do_htmlentities(stripslashes($myrow["code"]))?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_url?>:</td><td><input class="sgbinput" type="text" name="emoticon_url" size="40" maxlength="100" value="<?php echo do_htmlentities(stripslashes($myrow["emoticon_url"]))?>">
<input class="sgbbutton" type="button" value="<?php if($upload_avail) echo $l_emoticonupload; else echo $l_choose;?>" onClick="openWindow('<?php echo do_url_session("emoticon_upload.php?$langvar=$act_lang")?>')">
</td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_emotion?>:</td><td><input class="sgbinput" type="text" name="emotion" size="40" maxlength="80" value="<?php echo do_htmlentities(stripslashes($myrow["emotion"]))?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_layout?>:</td><td>
<select name="layoutid">
<option value="" <?php if(!$myrow["layoutid"]) echo "selected"?>><?php echo $l_all?></option>
<?php
	$tempsql = "select * from ".$tableprefix."_layout group by id";
	if(!$tempresult = mysql_query($tempsql, $db)) {
	    die("Could not connect to the database.");
	}
	if($temprow=mysql_fetch_array($tempresult))
	{
		do{
			echo "<option value=\"".$temprow["id"]."\"";
			if($temprow["id"]==$myrow["layoutid"])
				echo " selected";
			echo ">".$temprow["id"];
			echo "</option>";
		}while($temprow=mysql_fetch_array($tempresult));
	}
?>
</select>
</td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="inlist" value="1" <?php if ($myrow["inshortcutlist"]==1) echo "checked"?>><?php echo $l_inshortcutlist?></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="update"><input class="sgbbutton" type="submit" value="<?php echo $l_update?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?$langvar=$act_lang")?>"><?php echo $l_emoticons?></a></div>
<?php
	}
	if($mode=="update")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(isset($inlist))
			$inshortcutlist=1;
		else
			$inshortcutlist=0;
		if(!$code)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nocode</td></tr>";
			$errors=1;
		}
		if(!$emoticon_url)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nourl</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$code=addslashes($code);
			$emoticon_url=addslashes($emoticon_url);
			$emotion=addslashes($emotion);
			$sql = "UPDATE ".$tableprefix."_emoticons SET layoutid='$layoutid', code='$code', emoticon_url='$emoticon_url', emotion='$emotion', inshortcutlist=$inshortcutlist ";
			$sql .="WHERE (iconnr = $input_iconnr)";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.".mysql_error());
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_emoticonupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang")."\">$l_emoticons</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights>1)
{
?>
<tr class="actionrow"><td align="center" colspan="6">
<a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addemoticon?></a>
</td></tr>
<?php
}
$sql = "select * from ".$tableprefix."_emoticons order by layoutid asc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = mysql_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"4\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td class="rowheadings" align="center" width="10%"><b><?php echo $l_icon?></b></td>
<td class="rowheadings" align="center" width="20%"><b><?php echo $l_code?></b></td>
<td class="rowheadings" align="center" width="30%"><b><?php echo $l_emotion?></b></td>
<td class="rowheadings" align="center" width="10%"><b><?php echo $l_inshortcutlist?></b></td>
<td class="rowheadings" align="center" width="20%"><b><?php echo $l_layout?></b></td>
<td class="rowheadings" width="30%">&nbsp;</td></tr>
<?php
	do {
		$act_id=$myrow["iconnr"];
		echo "<tr class=\"displayrow\">";
		echo "<td align=\"center\"><img src=\"$url_emoticons/".$myrow["emoticon_url"]."\" border=\"0\"></td>";
		echo "<td align=\"center\">".do_htmlentities($myrow["code"])."</td>";
		echo "<td align=\"center\">".do_htmlentities($myrow["emotion"])."</td>";
		echo "<td align=\"center\">";
		if($myrow["inshortcutlist"]==1)
			echo "<img src=\"gfx/checkmark.gif\" border=\"0\">";
		else
			echo "&nbsp;";
		echo "</td>";
		echo "<td align=\"center\">";
		if($myrow["layoutid"])
			echo $myrow["layoutid"];
		else
			echo $l_all;
		echo "</td>";
		echo "<td>";
		if($admin_rights > 1)
		{
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_iconnr=$act_id&$langvar=$act_lang")."\">";
			echo "<img src=\"gfx/delete.gif\" border=\"0\" alt=\"$l_delete\" title=\"$l_delete\"></a>";
			echo " ";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=edit&$langvar=$act_lang&input_iconnr=$act_id")."\">";
			echo "<img src=\"gfx/edit.gif\" border=\"0\" alt=\"$l_edit\" title=\"$l_edit\"></a>";
		}
		echo "</td></tr>";
   } while($myrow = mysql_fetch_array($result));
   echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
?>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>"><?php echo $l_addemoticon?></a></div>
<?php
}
}
include('./trailer.php');
?>