<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function language_list($dirname="language/")
{
	$langs = array();
	$dir = opendir($dirname);
	while($file = readdir($dir))
	{
		if (ereg("^lang_",$file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			array_push($langs,$file);
		}
	}
	closedir($dir);
	return $langs;
}

function gethostname($ipadr, $db, $doresolve)
{
	global $hcprefix;

	$sql="select * from ".$hcprefix."_hostcache where ipadr='$ipadr'";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	$acthostname="";
	if ((!$myrow = mysql_fetch_array($result)) && ($doresolve==true))
	{
		$acthostname=gethostbyaddr($ipadr);
		$sql = "insert into ".$hcprefix."_hostcache (ipadr, hostname) values ('$ipadr','$acthostname')";
		if(!$result = mysql_query($sql, $db))
		    die("Could not connect to the database.");
	}
	else
		$acthostname=$myrow["hostname"];
	return $acthostname;
}

function country_selector($name, $defentry, $tableprefix, $db, $selecttext)
{
	$sql = "select * from ".$tableprefix."_flags order by displaypos asc";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	echo "<select name=\"$name\">";
	echo "<option value=\"\">$selecttext</option>";
	if(!$myrow=mysql_fetch_array($result))
		return;
	do{
		echo "<option value=\"".$myrow["country"]."\"";
		if($myrow["country"]==$defentry)
			echo " selected";
		echo ">".$myrow["country"]."</option>";
	}while($myrow=mysql_fetch_array($result));
	echo "</select>";
}

function do_url_session($url)
{
	global $sessid_url, $url_sessid, $sesscookiename;

	$url=ereg_replace("[&?]+$", "", $url);
	if($sessid_url)
	{
		$url2="";
		if(strrpos($url,"#")>0)
		{
			$url2=substr($url,strrpos($url,"#"));
			$url=substr($url,0,strrpos($url,"#"));
		}
		$url .= ( strpos($url, "?") != false ?  "&" : "?" ).urlencode($sesscookiename)."=".$url_sessid;
		if(strlen($url2)>0)
			$url.=$url2;
    }
    return $url;
}

function format_bytes($size)
{
	if($size>(1024*1024))
		return (round($size/(1024*1024),1)." MB");
	if($size>1024)
		return (round($size/1024,1)." KBytes");
	return $size." Bytes";
}

function disk_usage($directory, $depth = NULL)
{
	$usage=0;
	if(is_file($directory))
		return filesize($directory);
	if(isset($depth) && $depth < 0)
		return 0;
	if($directory[strlen($directory)-1] != '\\' || $directory[strlen($directory)-1] != '/')
		$directory .= '/';
	$dirhandle=@opendir($directory);
	if(!$dirhandle)
	return 0;

	while($entry = readdir($dirhandle))
	{
		if($entry != '.' && $entry != '..')
			$usage += disk_usage($directory.$entry, isset($depth) ? $depth - 1 : NULL);
	}
	closedir($dirhandle);
	return $usage;
}

function tz_select($default, $name="timezone")
{
	global $timezones;

	$tzselect="<select name=\"$name\">";
	for($i=0;$i<count($timezones);$i++)
	{
		$tzselect.="<option value=\"$i\"";
		if($i==$default)
			$tzselect.=" selected";
		$tzselect.=">";
		$tzselect.=$timezones[$i][0];
		$tzselect.="</option>";
	}
	$tzselect.="</select>";
	return $tzselect;
}
?>