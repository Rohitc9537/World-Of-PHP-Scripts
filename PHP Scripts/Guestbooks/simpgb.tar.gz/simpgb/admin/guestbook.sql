# phpMyAdmin SQL Dump
# version 2.5.6-rc2
# http://www.phpmyadmin.net
#
# Host: localhost
# Erstellungszeit: 25. Januar 2005 um 01:30
# Server Version: 4.0.23
# PHP-Version: 4.3.10
# 
# Datenbank: `guestbook`
# 

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_adm_mail`
#

DROP TABLE IF EXISTS simpgb_adm_mail;
CREATE TABLE simpgb_adm_mail (
  usernr int(3) unsigned NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_avatars`
#

DROP TABLE IF EXISTS simpgb_avatars;
CREATE TABLE simpgb_avatars (
  avatarnr int(10) unsigned NOT NULL auto_increment,
  image varchar(140) NOT NULL default '',
  name varchar(80) NOT NULL default '',
  PRIMARY KEY  (avatarnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_bad_words`
#

DROP TABLE IF EXISTS simpgb_bad_words;
CREATE TABLE simpgb_bad_words (
  indexnr int(10) unsigned NOT NULL auto_increment,
  word varchar(100) NOT NULL default '',
  replacement varchar(100) NOT NULL default '',
  PRIMARY KEY  (indexnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_banlist`
#

DROP TABLE IF EXISTS simpgb_banlist;
CREATE TABLE simpgb_banlist (
  bannr int(10) unsigned NOT NULL auto_increment,
  ipadr varchar(16) NOT NULL default '0.0.0.0',
  subnetmask varchar(16) NOT NULL default '0.0.0.0',
  reason text,
  PRIMARY KEY  (bannr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_bindata`
#

DROP TABLE IF EXISTS simpgb_bindata;
CREATE TABLE simpgb_bindata (
  entrynr int(10) unsigned NOT NULL default '0',
  bindata longblob NOT NULL,
  filename varchar(240) NOT NULL default '',
  mimetype varchar(240) NOT NULL default '',
  filesize int(10) NOT NULL default '0',
  fs_filename varchar(240) NOT NULL default '',
  UNIQUE KEY entrynr (entrynr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_counts`
#

DROP TABLE IF EXISTS simpgb_counts;
CREATE TABLE simpgb_counts (
  numhits int(10) unsigned NOT NULL default '0',
  hitcountstart date NOT NULL default '0000-00-00',
  msie int(10) unsigned NOT NULL default '0',
  mozilla int(10) unsigned NOT NULL default '0',
  opera int(10) unsigned NOT NULL default '0',
  icab int(10) unsigned NOT NULL default '0',
  lynx int(10) unsigned NOT NULL default '0',
  konqueror int(10) unsigned NOT NULL default '0',
  win int(10) unsigned NOT NULL default '0',
  mac int(10) unsigned NOT NULL default '0',
  linux int(10) unsigned NOT NULL default '0',
  unix int(10) unsigned NOT NULL default '0',
  bots int(10) unsigned NOT NULL default '0',
  os2 int(10) unsigned NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_data`
#

DROP TABLE IF EXISTS simpgb_data;
CREATE TABLE simpgb_data (
  entrynr int(10) unsigned NOT NULL auto_increment,
  date datetime NOT NULL default '0000-00-00 00:00:00',
  text text NOT NULL,
  heading varchar(80) NOT NULL default '',
  poster varchar(240) NOT NULL default '',
  posteremail varchar(240) NOT NULL default '',
  posterip varchar(16) NOT NULL default '',
  language varchar(4) NOT NULL default 'de',
  country varchar(30) NOT NULL default '',
  icq int(11) NOT NULL default '0',
  homepage varchar(240) NOT NULL default '',
  useragent varchar(240) NOT NULL default '',
  modcomment text NOT NULL,
  commentdate datetime NOT NULL default '0000-00-00 00:00:00',
  gender char(1) NOT NULL default '',
  aim varchar(70) NOT NULL default '',
  avatar varchar(240) NOT NULL default '',
  msnm varchar(25) NOT NULL default '',
  yim varchar(25) NOT NULL default '',
  validated tinyint(1) unsigned NOT NULL default '1',
  location varchar(160) NOT NULL default '',
  age varchar(40) NOT NULL default '',
  private tinyint(1) unsigned NOT NULL default '0',
  company varchar(140) NOT NULL default '',
  found varchar(40) NOT NULL default '',
  editedbyadmin tinyint(3) unsigned NOT NULL default '0',
  admineditdate datetime NOT NULL default '0000-00-00 00:00:00',
  commenteditor tinyint(3) unsigned NOT NULL default '0',
  sticky tinyint(1) unsigned NOT NULL default '0',
  userpic varchar(240) NOT NULL default '',
  postingid varchar(40) NOT NULL default '',
  PRIMARY KEY  (entrynr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_emoticons`
#

DROP TABLE IF EXISTS simpgb_emoticons;
CREATE TABLE simpgb_emoticons (
  iconnr int(10) unsigned NOT NULL auto_increment,
  code varchar(20) NOT NULL default '',
  emoticon_url varchar(100) NOT NULL default '',
  emotion varchar(80) NOT NULL default '',
  inshortcutlist tinyint(1) unsigned NOT NULL default '0',
  layoutid varchar(10) NOT NULL default '',
  PRIMARY KEY  (iconnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_failed_logins`
#

DROP TABLE IF EXISTS simpgb_failed_logins;
CREATE TABLE simpgb_failed_logins (
  loginnr int(10) unsigned NOT NULL auto_increment,
  username varchar(250) NOT NULL default '0',
  ipadr varchar(16) NOT NULL default '',
  logindate datetime NOT NULL default '0000-00-00 00:00:00',
  usedpw varchar(240) NOT NULL default '',
  PRIMARY KEY  (loginnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_failed_notify`
#

DROP TABLE IF EXISTS simpgb_failed_notify;
CREATE TABLE simpgb_failed_notify (
  usernr int(10) unsigned NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_flags`
#

DROP TABLE IF EXISTS simpgb_flags;
CREATE TABLE simpgb_flags (
  flagnr int(10) unsigned NOT NULL auto_increment,
  country varchar(30) NOT NULL default '',
  image varchar(80) NOT NULL default '',
  defentry tinyint(1) unsigned NOT NULL default '0',
  displaypos int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (flagnr),
  UNIQUE KEY country (country)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_freemailer`
#

DROP TABLE IF EXISTS simpgb_freemailer;
CREATE TABLE simpgb_freemailer (
  entrynr int(10) unsigned NOT NULL auto_increment,
  address varchar(100) NOT NULL default '',
  PRIMARY KEY  (entrynr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_hostcache`
#

DROP TABLE IF EXISTS simpgb_hostcache;
CREATE TABLE simpgb_hostcache (
  ipadr varchar(16) NOT NULL default '0',
  hostname varchar(240) NOT NULL default '',
  UNIQUE KEY ipadr (ipadr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_iplog`
#

DROP TABLE IF EXISTS simpgb_iplog;
CREATE TABLE simpgb_iplog (
  lognr int(10) unsigned NOT NULL auto_increment,
  usernr int(10) unsigned NOT NULL default '0',
  logtime datetime NOT NULL default '0000-00-00 00:00:00',
  ipadr varchar(16) NOT NULL default '',
  used_lang varchar(4) NOT NULL default '',
  PRIMARY KEY  (lognr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_layout`
#

DROP TABLE IF EXISTS simpgb_layout;
CREATE TABLE simpgb_layout (
  lang varchar(4) NOT NULL default '0',
  heading varchar(80) NOT NULL default '',
  headingbgcolor varchar(7) NOT NULL default '',
  headingfontcolor varchar(7) NOT NULL default '',
  headingfont varchar(240) NOT NULL default '',
  headingfontsize varchar(4) NOT NULL default '',
  bordercolor varchar(7) NOT NULL default '',
  contentbgcolor varchar(7) NOT NULL default '',
  contentfontcolor varchar(7) NOT NULL default '',
  contentfont varchar(240) NOT NULL default '',
  contentfontsize varchar(4) NOT NULL default '',
  TableWidth varchar(10) NOT NULL default '',
  timestampfontcolor varchar(7) NOT NULL default '',
  timestampfontsize varchar(4) NOT NULL default '',
  timestampfont varchar(240) NOT NULL default '',
  dateformat varchar(20) NOT NULL default '',
  showcurrtime tinyint(1) unsigned NOT NULL default '0',
  customheader text NOT NULL,
  pagebgcolor varchar(7) NOT NULL default '',
  stylesheet varchar(80) NOT NULL default '',
  entryheadingbgcolor varchar(7) NOT NULL default '',
  entryheadingfontcolor varchar(7) NOT NULL default '',
  entryheadingstyle tinyint(1) NOT NULL default '0',
  entryheadingfont varchar(240) NOT NULL default '',
  entryheadingfontsize varchar(4) NOT NULL default '',
  timestampbgcolor varchar(7) NOT NULL default '',
  timestampstyle tinyint(1) unsigned NOT NULL default '0',
  copyrightbgcolor varchar(7) NOT NULL default '',
  copyrightfontcolor varchar(7) NOT NULL default '',
  copyrightfont varchar(240) NOT NULL default '',
  copyrightfontsize varchar(4) NOT NULL default '',
  layoutnr int(10) NOT NULL auto_increment,
  id varchar(10) NOT NULL default '',
  deflayout tinyint(1) unsigned NOT NULL default '0',
  maxentries tinyint(2) unsigned NOT NULL default '0',
  userinfopos tinyint(1) unsigned NOT NULL default '0',
  homepagepic varchar(240) NOT NULL default '',
  emailpic varchar(240) NOT NULL default '',
  icqpic varchar(240) NOT NULL default '',
  browserpic varchar(240) NOT NULL default '',
  addentrypic varchar(240) NOT NULL default '',
  posterbgcolor varchar(7) NOT NULL default '',
  posterfontcolor varchar(7) NOT NULL default '',
  posterfont varchar(240) NOT NULL default '',
  posterfontsize varchar(4) NOT NULL default '',
  modcommentbgcolor varchar(7) NOT NULL default '',
  modcommentfontcolor varchar(7) NOT NULL default '',
  modcommentfont varchar(240) NOT NULL default '',
  modcommentfontsize varchar(4) NOT NULL default '',
  requiredbgcolor varchar(7) NOT NULL default '',
  requiredfontcolor varchar(7) NOT NULL default '',
  gotoppic varchar(240) NOT NULL default '',
  malepic varchar(240) NOT NULL default '',
  femalepic varchar(240) NOT NULL default '',
  inputfields int(10) unsigned NOT NULL default '0',
  aimpic varchar(240) NOT NULL default '',
  posterpic varchar(240) NOT NULL default '',
  enableusersonline tinyint(1) unsigned NOT NULL default '1',
  msnmpic varchar(240) NOT NULL default '',
  yimpic varchar(240) NOT NULL default '',
  enablelangselector tinyint(1) unsigned NOT NULL default '0',
  enablelayoutselector tinyint(1) unsigned NOT NULL default '0',
  companypic varchar(240) NOT NULL default '',
  closepic varchar(240) NOT NULL default 'close.gif',
  bbcodepic_bold varchar(240) NOT NULL default 'bbcode_bold.gif',
  bbcodepic_italic varchar(240) NOT NULL default 'bbcode_italic.gif',
  bbcodepic_strike varchar(240) NOT NULL default 'bbcode_strike.gif',
  bbcodepic_type varchar(240) NOT NULL default 'bbcode_type.gif',
  bbcodepic_sub varchar(240) NOT NULL default 'bbcode_sub.gif',
  bbcodepic_super varchar(240) NOT NULL default 'bbcode_super.gif',
  bbcodepic_center varchar(240) NOT NULL default 'bbcode_center.gif',
  bbcodepic_pic varchar(240) NOT NULL default 'bbcode_pic.gif',
  bbcodepic_code varchar(240) NOT NULL default 'bbcode_code.gif',
  bbcodepic_quote varchar(240) NOT NULL default 'bbcode_quote.gif',
  bbcodepic_liststart varchar(240) NOT NULL default 'bbcode_liststart.gif',
  bbcodepic_listend varchar(240) NOT NULL default 'bbcode_listend.gif',
  bbcodepic_listitem varchar(240) NOT NULL default 'bbcode_listitem.gif',
  bbcodepic_size varchar(240) NOT NULL default 'bbcode_size.gif',
  bbcodepic_color varchar(240) NOT NULL default 'bbcode_color.gif',
  bbcodepic_email varchar(240) NOT NULL default 'bbcode_email.gif',
  bbcodepic_url varchar(240) NOT NULL default 'bbcode_url.gif',
  bbcodepic_real varchar(240) NOT NULL default 'bbcode_real.gif',
  bbcodepic_swf varchar(240) NOT NULL default 'bbcode_swf.gif',
  bbcodepic_help varchar(240) NOT NULL default 'bbcode_help.gif',
  morepic varchar(240) NOT NULL default 'en/more.gif',
  pagepic_fwd varchar(240) NOT NULL default 'next.gif',
  pagepic_last varchar(240) NOT NULL default 'last.gif',
  pagepic_prev varchar(240) NOT NULL default 'previous.gif',
  pagepic_first varchar(240) NOT NULL default 'first.gif',
  customfooter text NOT NULL,
  searchpic varchar(240) NOT NULL default 'search.gif',
  backpic varchar(240) NOT NULL default 'back.gif',
  stickypic varchar(240) NOT NULL default 'stick.gif',
  attachpic varchar(240) NOT NULL default 'attach.gif',
  attachbgcolor varchar(7) NOT NULL default '#e0e0e0',
  attachfontcolor varchar(7) NOT NULL default '#000000',
  attachfontsize varchar(4) NOT NULL default '2',
  attachfont varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  quotepic varchar(240) NOT NULL default 'quote.gif',
  actionbgcolor varchar(7) NOT NULL default '#94AAD6',
  actionfontcolor varchar(7) NOT NULL default '#FFF0C0',
  actionfont varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  actionfontsize varchar(4) NOT NULL default '2',
  changepic varchar(240) NOT NULL default 'change.gif',
  helppic varchar(240) NOT NULL default 'help.gif',
  newentrypic varchar(240) NOT NULL default 'en/new.gif',
  lastvisitcookie tinyint(1) unsigned NOT NULL default '1',
  pagebgpic varchar(240) NOT NULL default '',
  headerspace int(10) unsigned NOT NULL default '10',
  actionboxspace int(10) unsigned NOT NULL default '10',
  pagenavspace int(10) unsigned NOT NULL default '10',
  infoboxspace int(10) unsigned NOT NULL default '10',
  copyrightboxspace int(10) unsigned NOT NULL default '10',
  noentries text NOT NULL,
  datetimepic varchar(240) NOT NULL default 'calendar.gif',
  picturepic varchar(240) NOT NULL default 'photo.gif',
  inputfields2 int(10) unsigned NOT NULL default '0',
  selectcolor varchar(7) NOT NULL default '#a0a0a0',
  fontbuttons int(10) unsigned NOT NULL default '0',
  bbcodepic_font varchar(240) NOT NULL default 'bbcode_font.gif',
  popupwidth int(10) unsigned NOT NULL default '400',
  popupheight int(10) unsigned NOT NULL default '400',
  maxuserfilesize int(10) unsigned NOT NULL default '250000',
  bbcodepic_updown varchar(240) NOT NULL default 'bbcode_updown.gif',
  bbcodepic_scroll varchar(240) NOT NULL default 'bbcode_scroll.gif',
  sendmailpic varchar(240) NOT NULL default 'sendmail.gif',
  actionboxpos int(5) unsigned NOT NULL default '3',
  bbcodepic_fade varchar(240) NOT NULL default 'bbcode_fade.gif',
  bbcodepic_fliph varchar(240) NOT NULL default 'bbcode_fliph.gif',
  bbcodepic_flipv varchar(240) NOT NULL default 'bbcode_flipv.gif',
  glowcolor varchar(7) NOT NULL default '#ffff99',
  shadowcolor varchar(7) NOT NULL default '#823700',
  bbcodepic_glow varchar(240) NOT NULL default 'bbcode_glow.gif',
  bbcodepic_shadow varchar(240) NOT NULL default 'bbcode_shadow.gif',
  bbcodepic_blur varchar(240) NOT NULL default 'bbcode_blur.gif',
  bbcodepic_dropshadow varchar(240) NOT NULL default 'bbcode_dropshadow.gif',
  dropshadowcolor varchar(7) NOT NULL default '#ffff99',
  bbcodepic_wmv varchar(240) NOT NULL default 'bbcode_wmv.gif',
  colorscrollbars tinyint(1) unsigned NOT NULL default '0',
  sb3dlightcolor varchar(7) NOT NULL default '#1E90FF',
  sbarrowcolor varchar(7) NOT NULL default '#0000ff',
  sbdarkshadowcolor varchar(7) NOT NULL default '#4682B4',
  sbfacecolor varchar(7) NOT NULL default '#94AAD6',
  sbhighlightcolor varchar(7) NOT NULL default '#AFEEEE',
  sbshadowcolor varchar(7) NOT NULL default '#ADD8E6',
  sbtrackcolor varchar(7) NOT NULL default '#E0FFFF',
  sgbsel_bgcolor varchar(7) NOT NULL default '#00008B',
  sgbsel_color varchar(7) NOT NULL default '#F8F8FF',
  sgbsel_borderstyle varchar(20) NOT NULL default 'none',
  sgbsel_fontsize varchar(10) NOT NULL default '10pt',
  sgbsel_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  sgbsel_borderwidth varchar(20) NOT NULL default '',
  sgbchk_bgcolor varchar(7) NOT NULL default '',
  sgbchk_color varchar(7) NOT NULL default '',
  sgbchk_borderstyle varchar(20) NOT NULL default 'none',
  sgbchk_fontsize varchar(10) NOT NULL default '',
  sgbchk_font varchar(240) NOT NULL default '',
  sgbchk_borderwidth varchar(20) NOT NULL default '',
  sgbsel_bordercolor varchar(7) NOT NULL default '',
  sgbchk_bordercolor varchar(7) NOT NULL default '',
  sgbsel_fontstyle varchar(20) NOT NULL default 'normal',
  sgbchk_fontstyle varchar(20) NOT NULL default 'normal',
  sgbsel_fontweight varchar(20) NOT NULL default '',
  sgbchk_fontweight varchar(20) NOT NULL default '',
  sgbinput_bgcolor varchar(7) NOT NULL default '#00008B',
  sgbinput_color varchar(7) NOT NULL default '#F8F8FF',
  sgbinput_borderstyle varchar(20) NOT NULL default 'inset',
  sgbinput_fontsize varchar(10) NOT NULL default '10pt',
  sgbinput_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  sgbinput_borderwidth varchar(20) NOT NULL default 'thin',
  sgbinput_bordercolor varchar(7) NOT NULL default '#191970',
  sgbinput_fontstyle varchar(20) NOT NULL default '',
  sgbinput_fontweight varchar(20) NOT NULL default '',
  sgbbutton_bgcolor varchar(7) NOT NULL default '#94AAD6',
  sgbbutton_color varchar(7) NOT NULL default '#000080',
  sgbbutton_borderstyle varchar(20) NOT NULL default 'inset',
  sgbbutton_fontsize varchar(10) NOT NULL default '10pt',
  sgbbutton_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  sgbbutton_borderwidth varchar(20) NOT NULL default 'thin',
  sgbbutton_bordercolor varchar(7) NOT NULL default '#191970',
  sgbbutton_fontstyle varchar(20) NOT NULL default 'normal',
  sgbbutton_fontweight varchar(20) NOT NULL default 'normal',
  bbcsel_color varchar(7) NOT NULL default '#000000',
  bbcsel_borderstyle varchar(20) NOT NULL default '',
  bbcsel_fontsize varchar(10) NOT NULL default '10pt',
  bbcsel_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  bbcsel_borderwidth varchar(20) NOT NULL default '',
  bbcsel_bordercolor varchar(7) NOT NULL default '',
  bbcsel_fontstyle varchar(20) NOT NULL default 'normal',
  bbcsel_fontweight varchar(20) NOT NULL default 'bold',
  admmailpic varchar(240) NOT NULL default 'en/admmail.gif',
  sgbisb_3dlightcolor varchar(7) NOT NULL default '#1E90FF',
  sgbisb_arrowcolor varchar(7) NOT NULL default '#0000ff',
  sgbisb_darkshadowcolor varchar(7) NOT NULL default '#4682B4',
  sgbisb_facecolor varchar(7) NOT NULL default '#94AAD6',
  sgbisb_highlightcolor varchar(7) NOT NULL default '#AFEEEE',
  sgbisb_shadowcolor varchar(7) NOT NULL default '#ADD8E6',
  sgbisb_trackcolor varchar(7) NOT NULL default '#E0FFFF',
  admmenupic varchar(240) NOT NULL default 'admmenu.gif',
  sitehomepic varchar(240) NOT NULL default 'homepage.gif',
  directeditpic varchar(240) NOT NULL default 'editpost.gif',
  delentrypic varchar(240) NOT NULL default 'delentry.gif',
  comentrypic varchar(240) NOT NULL default 'writecomment.gif',
  helpline_color varchar(7) NOT NULL default '#333333',
  helpline_borderstyle varchar(20) NOT NULL default 'none',
  helpline_fontsize varchar(10) NOT NULL default '10px',
  helpline_font varchar(240) NOT NULL default '"Courier New", Courier, monospace',
  helpline_bgcolor varchar(7) NOT NULL default '#c0c0c0',
  helpline_fontstyle varchar(20) NOT NULL default 'normal',
  helpline_bordercolor varchar(7) NOT NULL default '#c0c0c0',
  helpline_fontweight varchar(20) NOT NULL default 'normal',
  helpline_borderwidth varchar(20) NOT NULL default '',
  bbccode_color varchar(7) NOT NULL default '#444444',
  bbccode_borderstyle varchar(20) NOT NULL default 'solid',
  bbccode_fontsize varchar(10) NOT NULL default '8pt',
  bbccode_font varchar(240) NOT NULL default '"Courier New", Courier, monospace',
  bbccode_bgcolor varchar(7) NOT NULL default '#DCDCDC',
  bbccode_fontstyle varchar(20) NOT NULL default 'normal',
  bbccode_bordercolor varchar(7) NOT NULL default '#000000',
  bbccode_fontweight varchar(20) NOT NULL default 'normal',
  bbccode_borderwidth varchar(20) NOT NULL default '1',
  bbcquote_color varchar(7) NOT NULL default '#444444',
  bbcquote_borderstyle varchar(20) NOT NULL default 'solid',
  bbcquote_fontsize varchar(10) NOT NULL default '10pt',
  bbcquote_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  bbcquote_bgcolor varchar(7) NOT NULL default '#DCDCDC',
  bbcquote_fontstyle varchar(20) NOT NULL default 'normal',
  bbcquote_bordercolor varchar(7) NOT NULL default '#000000',
  bbcquote_fontweight varchar(20) NOT NULL default 'normal',
  bbcquote_borderwidth varchar(20) NOT NULL default '1',
  enablesortselector tinyint(1) unsigned NOT NULL default '0',
  required_bgpic varchar(240) NOT NULL default '',
  required_linkcolor varchar(7) NOT NULL default '#92ce00',
  required_vlinkcolor varchar(7) NOT NULL default '#92ce00',
  required_alinkcolor varchar(7) NOT NULL default '#92ce00',
  linkcolor varchar(7) NOT NULL default '#076d75',
  vlinkcolor varchar(7) NOT NULL default '#076d75',
  alinkcolor varchar(7) NOT NULL default '#076d75',
  actionlinkcolor varchar(7) NOT NULL default '#F0FFFF',
  actionvlinkcolor varchar(7) NOT NULL default '#F0FFFF',
  actionalinkcolor varchar(7) NOT NULL default '#F0FFFF',
  pagenavlinkcolor varchar(7) NOT NULL default '#FFF0C0',
  pagenavvlinkcolor varchar(7) NOT NULL default '#FFF0C0',
  pagenavalinkcolor varchar(7) NOT NULL default '#FFF0C0',
  smile_bgcolor varchar(7) NOT NULL default '#778899',
  smile_linkcolor varchar(7) NOT NULL default '#F0E68C',
  smile_vlinkcolor varchar(7) NOT NULL default '#F0E68C',
  smile_alinkcolor varchar(7) NOT NULL default '#F0E68C',
  bbbox_bgcolor varchar(7) NOT NULL default '#c0c0c0',
  bbbox_linkcolor varchar(7) NOT NULL default '#669999',
  bbbox_vlinkcolor varchar(7) NOT NULL default '#669999',
  bbbox_alinkcolor varchar(7) NOT NULL default '#669999',
  ns4style varchar(240) NOT NULL default 'simpgb_ns4.css',
  ns6style varchar(240) NOT NULL default 'simpgb_ns6.css',
  operastyle varchar(240) NOT NULL default 'simpgb_opera.css',
  konquerorstyle varchar(240) NOT NULL default 'simpgb_konqueror.css',
  geckostyle varchar(240) NOT NULL default 'simpgb_gecko.css',
  pagebgrepeat varchar(80) NOT NULL default 'repeat',
  pagebgposition varchar(80) NOT NULL default 'top',
  pagebgattach varchar(80) NOT NULL default 'scroll',
  ftext_font varchar(80) NOT NULL default 'Verdana',
  ftext_fontsize varchar(10) NOT NULL default '24',
  ftext_fontcolor varchar(7) NOT NULL default '#000000',
  gbheadingeffect int(10) unsigned NOT NULL default '0',
  gbhapplet_width int(10) unsigned NOT NULL default '200',
  gbhapplet_height int(10) unsigned NOT NULL default '200',
  fan_font varchar(80) NOT NULL default 'Verdana',
  fan_fontsize varchar(10) NOT NULL default '24',
  fan_speed tinyint(4) unsigned NOT NULL default '4',
  fan_hspacing tinyint(4) unsigned NOT NULL default '4',
  fan_vspacing tinyint(4) unsigned NOT NULL default '20',
  fan_basecolor tinyint(4) unsigned NOT NULL default '1',
  fan_bgcolor varchar(7) NOT NULL default '#000000',
  atext_font varchar(80) NOT NULL default 'Verdana',
  atext_fontstyle varchar(20) NOT NULL default 'plain',
  atext_type varchar(20) NOT NULL default 'blink',
  atext_align varchar(20) NOT NULL default 'center',
  atext_fontcolor varchar(7) NOT NULL default '#aaaaaa',
  atext_bgcolor varchar(7) NOT NULL default '#000000',
  atext_delaytime int(10) unsigned NOT NULL default '100',
  atext_minfsize tinyint(4) unsigned NOT NULL default '6',
  atext_maxfsize tinyint(4) unsigned NOT NULL default '28',
  fw_font varchar(80) NOT NULL default 'Verdana',
  fw_fontsize varchar(10) NOT NULL default '36',
  fw_fontcolor varchar(7) NOT NULL default '#ffffff',
  fw_bgcolor varchar(7) NOT NULL default '#000000',
  fw_rockets tinyint(4) unsigned NOT NULL default '8',
  jt_font varchar(80) NOT NULL default 'Verdana',
  jt_fontsize varchar(10) NOT NULL default '24',
  jt_fontcolor varchar(7) NOT NULL default '#eeeeee',
  jt_bgcolor varchar(7) NOT NULL default '#000000',
  jt_speed tinyint(4) unsigned NOT NULL default '200',
  jt_randomcolor tinyint(1) unsigned NOT NULL default '0',
  pt_font varchar(80) NOT NULL default 'Verdana',
  pt_fontsize varchar(10) NOT NULL default '24',
  pt_fontcolor varchar(7) NOT NULL default '#ffffff',
  pt_bgcolor varchar(7) NOT NULL default '#000000',
  pt_fps tinyint(4) unsigned NOT NULL default '50',
  pt_usesineshift tinyint(1) unsigned NOT NULL default '1',
  pt_useblur tinyint(1) unsigned NOT NULL default '1',
  pt_sineshiftspeed tinyint(4) unsigned NOT NULL default '100',
  pt_sineperiod tinyint(4) unsigned NOT NULL default '20',
  pt_sinescale int(10) unsigned NOT NULL default '15000',
  rt_bgcolor varchar(7) NOT NULL default '#000000',
  rt_font varchar(80) NOT NULL default 'Verdana',
  rt_fontsize varchar(10) NOT NULL default '26',
  rt_fontstyle tinyint(4) unsigned NOT NULL default '0',
  rt_sleeptime int(10) unsigned NOT NULL default '100',
  zz_bgcolor varchar(7) NOT NULL default '#000000',
  zz_fontcolor varchar(7) NOT NULL default '#ffffff',
  zz_font varchar(80) NOT NULL default 'Verdana',
  zz_fontsize varchar(10) NOT NULL default '24',
  zz_fontstyle tinyint(4) unsigned NOT NULL default '0',
  zz_delay int(10) unsigned NOT NULL default '5',
  zz_pause int(10) unsigned NOT NULL default '2000',
  circle_font varchar(80) NOT NULL default 'Verdana',
  circle_fontcolor varchar(7) NOT NULL default '#ffffff',
  circle_fontsize varchar(10) NOT NULL default '24',
  circle_fontstyle tinyint(4) unsigned NOT NULL default '0',
  circle_bgcolor varchar(7) NOT NULL default '#000000',
  circle_direction tinyint(1) unsigned NOT NULL default '0',
  circle_bgimage varchar(240) NOT NULL default '',
  circle_imgalign tinyint(2) unsigned NOT NULL default '0',
  circle_texteffects tinyint(4) unsigned NOT NULL default '0',
  circle_fontpadding tinyint(4) unsigned NOT NULL default '0',
  circle_pause int(10) unsigned NOT NULL default '100',
  circle_rotationfactor tinyint(4) unsigned NOT NULL default '100',
  pac_font varchar(80) NOT NULL default 'Verdana',
  pac_fontcolor varchar(7) NOT NULL default '#ff0000',
  pac_fontsize varchar(10) NOT NULL default '24',
  pac_bgcolor varchar(7) NOT NULL default '#aaaaaa',
  pac_paccolor varchar(7) NOT NULL default '#00ff00',
  sky_font varchar(80) NOT NULL default 'Verdana',
  sky_fontsize varchar(10) NOT NULL default '24',
  sky_bgcolor varchar(7) NOT NULL default '#0000ff',
  sky_bgimg varchar(80) NOT NULL default 'cloud.gif',
  sky_fontstyle tinyint(4) unsigned NOT NULL default '0',
  sky_sleeptime int(10) unsigned NOT NULL default '100',
  sw_font varchar(80) NOT NULL default 'Verdana',
  sw_fontsize varchar(10) NOT NULL default '24',
  sw_fontcolor varchar(7) NOT NULL default '#ffffff',
  sw_bgcolor varchar(7) NOT NULL default '#000000',
  sw_stars tinyint(1) unsigned NOT NULL default '1',
  sw_naptime int(10) unsigned NOT NULL default '50',
  sw_pause int(10) unsigned NOT NULL default '100',
  sw_numstars tinyint(4) unsigned NOT NULL default '10',
  sw_ampmulti tinyint(4) unsigned NOT NULL default '3',
  sw_frequency tinyint(4) unsigned NOT NULL default '3',
  blt_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  blt_fontsize varchar(10) NOT NULL default '24',
  blt_fontcolor varchar(7) NOT NULL default '#ff0000',
  blt_bgcolor varchar(7) NOT NULL default '#aaaaaa',
  blt_delay int(10) unsigned NOT NULL default '1000',
  blt_fontstyle tinyint(4) unsigned NOT NULL default '0',
  ct_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  ct_fontsize varchar(10) NOT NULL default '24',
  ct_fontcolor1 varchar(7) NOT NULL default '#ff0000',
  ct_fontcolor2 varchar(7) NOT NULL default '#00ff00',
  ct_fontcolor3 varchar(7) NOT NULL default '#0000ff',
  ct_fontcolor4 varchar(7) NOT NULL default '#ff00ff',
  ct_fontstyle tinyint(4) unsigned NOT NULL default '0',
  ct_bgcolor varchar(7) NOT NULL default '#aaaaaa',
  neon_bgcolor varchar(7) NOT NULL default '#aaaaaa',
  neon_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  neon_fontsize varchar(10) NOT NULL default '24',
  neon_fontstyle tinyint(4) unsigned NOT NULL default '0',
  neon_fontcolor1 varchar(7) NOT NULL default '#555555',
  neon_fontcolor2 varchar(7) NOT NULL default '#ffff00',
  neon_delay int(10) unsigned NOT NULL default '100',
  neon2_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  neon2_fontsize varchar(10) NOT NULL default '24',
  neon2_bgcolor varchar(7) NOT NULL default '#aaaaaa',
  neon2_fontstyle tinyint(4) unsigned NOT NULL default '0',
  neon2_fontcolor1 varchar(7) NOT NULL default '#999999',
  neon2_fontcolor2 varchar(7) NOT NULL default '#ffff00',
  neon2_fontcolor3 varchar(7) NOT NULL default '#ffff88',
  neon2_flashspeed int(10) unsigned NOT NULL default '100',
  neon2_flashletters tinyint(4) unsigned NOT NULL default '4',
  neon2_flashletters2 tinyint(4) unsigned NOT NULL default '1',
  neon2_flashpause int(10) unsigned NOT NULL default '0',
  rainbow_bgcolor varchar(7) NOT NULL default '#999999',
  rainbow_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  rainbow_fontsize varchar(10) NOT NULL default '24',
  rainbow_fontstyle tinyint(4) unsigned NOT NULL default '0',
  ft_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  ft_fontsize varchar(10) NOT NULL default '24',
  ft_bgcolor varchar(7) NOT NULL default '#999999',
  ft_rgb tinyint(4) unsigned NOT NULL default '1',
  zoom_endsize int(10) unsigned NOT NULL default '70',
  zoom_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  zoom_bgcolor varchar(7) NOT NULL default '#999999',
  zoom_startsize int(10) unsigned NOT NULL default '10',
  zoom_zoomspeed int(10) unsigned NOT NULL default '100',
  zoom_step tinyint(4) unsigned NOT NULL default '1',
  zoom_fadespeed int(10) unsigned NOT NULL default '70',
  zoom_pause int(10) unsigned NOT NULL default '70',
  zoom_fontcolor varchar(7) NOT NULL default '#ff00ff',
  zoom_zoomcolor varchar(7) NOT NULL default '#00ff00',
  typer_bgcolor varchar(7) NOT NULL default '#999999',
  typer_fontsize int(10) unsigned NOT NULL default '70',
  typer_fontcolor varchar(7) NOT NULL default '#00ffff',
  typer_font varchar(240) NOT NULL default 'Verdana, Geneva, Arial, Helvetica, sans-serif',
  typer_speed int(10) unsigned NOT NULL default '150',
  typer_align tinyint(4) unsigned NOT NULL default '2',
  led_msg1 varchar(80) NOT NULL default 'guestbook',
  led_msg2 varchar(80) NOT NULL default '',
  led_msg3 varchar(80) NOT NULL default '',
  led_msg4 varchar(80) NOT NULL default '',
  led_pause int(10) unsigned NOT NULL default '3000',
  tablealign tinyint(4) unsigned NOT NULL default '2',
  fxalign tinyint(4) unsigned NOT NULL default '2',
  addboxspace int(10) unsigned NOT NULL default '10',
  contentnote varchar(250) NOT NULL default '',
  displayentrynr tinyint(1) unsigned NOT NULL default '0',
  rainbow_bordercolor varchar(7) NOT NULL default '#ff0000',
  bprow tinyint(4) unsigned NOT NULL default '6',
  bbcodepic_rainbow varchar(240) NOT NULL default 'bbcode_rainbow.gif',
  pboxwidth varchar(10) NOT NULL default '10%',
  cnt_color1 varchar(7) NOT NULL default '#ff0000',
  cnt_color2 varchar(7) NOT NULL default '#00ff00',
  cnt_color3 varchar(7) NOT NULL default '#ff7575',
  noscbartextarea tinyint(1) unsigned NOT NULL default '0',
  emoticonlimit int(4) unsigned NOT NULL default '0',
  avmaxwidth int(10) unsigned NOT NULL default '0',
  avmaxheight int(10) unsigned NOT NULL default '0',
  headerfile varchar(250) NOT NULL default '',
  footerfile varchar(250) NOT NULL default '',
  headerfilepos tinyint(1) unsigned default '0',
  footerfilepos tinyint(1) unsigned default '0',
  cheadnobr tinyint(1) unsigned default '0',
  cfootnobr tinyint(1) unsigned default '0',
  usecustomheader tinyint(1) unsigned default '0',
  usecustomfooter tinyint(1) unsigned default '0',
  usrnopreview tinyint(1) unsigned NOT NULL default '0',
  nonltrans tinyint(4) unsigned default '0',
  PRIMARY KEY  (layoutnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_leachers`
#

DROP TABLE IF EXISTS simpgb_leachers;
CREATE TABLE simpgb_leachers (
  entrynr int(10) unsigned NOT NULL auto_increment,
  useragent varchar(80) NOT NULL default '',
  description text,
  PRIMARY KEY  (entrynr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_misc`
#

DROP TABLE IF EXISTS simpgb_misc;
CREATE TABLE simpgb_misc (
  shutdown tinyint(3) unsigned NOT NULL default '0',
  shutdowntext text
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_notify`
#

DROP TABLE IF EXISTS simpgb_notify;
CREATE TABLE simpgb_notify (
  usernr int(10) unsigned NOT NULL default '0'
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_reserved_names`
#

DROP TABLE IF EXISTS simpgb_reserved_names;
CREATE TABLE simpgb_reserved_names (
  indexnr int(10) unsigned NOT NULL auto_increment,
  name varchar(240) NOT NULL default '',
  PRIMARY KEY  (indexnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_search`
#

DROP TABLE IF EXISTS simpgb_search;
CREATE TABLE simpgb_search (
  entrynr int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  comment text NOT NULL
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_selections`
#

DROP TABLE IF EXISTS simpgb_selections;
CREATE TABLE simpgb_selections (
  entrynr int(10) unsigned NOT NULL auto_increment,
  fieldid varchar(10) NOT NULL default '',
  text varchar(40) NOT NULL default '',
  displaypos int(10) unsigned NOT NULL default '0',
  optionvalue varchar(40) NOT NULL default '',
  language varchar(10) NOT NULL default '',
  defvalue tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (entrynr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_session`
#

DROP TABLE IF EXISTS simpgb_session;
CREATE TABLE simpgb_session (
  sessid int(10) unsigned NOT NULL default '0',
  usernr int(10) NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  remoteip varchar(15) NOT NULL default '',
  lastlogin datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (sessid),
  KEY sess_id (sessid),
  KEY start_time (starttime),
  KEY remote_ip (remoteip)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_settings`
#

DROP TABLE IF EXISTS simpgb_settings;
CREATE TABLE simpgb_settings (
  settingnr int(10) unsigned NOT NULL auto_increment,
  watchlogins tinyint(1) unsigned NOT NULL default '0',
  enablefailednotify tinyint(1) unsigned NOT NULL default '0',
  simpgbmail varchar(180) NOT NULL default '',
  loginlimit int(2) unsigned NOT NULL default '0',
  usemenubar tinyint(1) unsigned NOT NULL default '0',
  nofreemailer tinyint(1) unsigned NOT NULL default '0',
  enablehostresolve tinyint(1) unsigned NOT NULL default '0',
  enablebbcode tinyint(1) unsigned NOT NULL default '1',
  enableemoticons tinyint(1) unsigned NOT NULL default '1',
  emoticonautoclose tinyint(1) unsigned NOT NULL default '1',
  sortingmethod tinyint(1) unsigned NOT NULL default '0',
  separatebylang tinyint(1) unsigned NOT NULL default '0',
  allowhtml tinyint(1) unsigned NOT NULL default '0',
  enablebadwordlist tinyint(1) unsigned NOT NULL default '1',
  floodprotectdelay int(4) unsigned NOT NULL default '60',
  userbanlist tinyint(1) unsigned NOT NULL default '0',
  maxwordlength smallint(3) unsigned NOT NULL default '20',
  enableavatarupload tinyint(1) unsigned NOT NULL default '0',
  newentrynotify tinyint(1) unsigned NOT NULL default '0',
  validateposts tinyint(1) unsigned NOT NULL default '1',
  minmsglength int(5) unsigned NOT NULL default '0',
  allowprivateposts tinyint(1) unsigned NOT NULL default '0',
  maxmsglength int(5) unsigned NOT NULL default '500',
  allowedbbcodes int(10) unsigned NOT NULL default '16383',
  redirectdelay tinyint(2) NOT NULL default '5',
  enablesearch tinyint(1) unsigned NOT NULL default '0',
  useronlinetime int(4) unsigned NOT NULL default '300',
  tryrealip tinyint(1) unsigned NOT NULL default '0',
  minfontsize tinyint(2) NOT NULL default '-5',
  maxfontsize tinyint(2) NOT NULL default '5',
  allowinternalmailer tinyint(1) unsigned NOT NULL default '0',
  maxmaillength int(10) unsigned NOT NULL default '300',
  emailfeatures int(5) unsigned NOT NULL default '0',
  allowadmmail tinyint(1) unsigned NOT NULL default '1',
  trimperiods tinyint(1) unsigned NOT NULL default '0',
  trimperiodlength int(10) unsigned NOT NULL default '6',
  admmenulink tinyint(1) unsigned NOT NULL default '1',
  sitehome varchar(240) NOT NULL default '',
  linksitehome tinyint(1) unsigned NOT NULL default '1',
  simpgbmailname varchar(180) NOT NULL default '',
  directeditlink tinyint(1) unsigned NOT NULL default '0',
  enablequote tinyint(1) unsigned NOT NULL default '1',
  enabledel tinyint(1) unsigned NOT NULL default '0',
  enablemodcom tinyint(1) unsigned NOT NULL default '0',
  blockoldbrowser tinyint(1) unsigned NOT NULL default '1',
  servertimezone int(10) NOT NULL default '0',
  displaytimezone int(10) NOT NULL default '0',
  disableposting tinyint(1) unsigned NOT NULL default '0',
  blockleacher tinyint(1) unsigned NOT NULL default '0',
  sendpostingmail tinyint(1) unsigned NOT NULL default '0',
  lastvisitdays int(10) unsigned NOT NULL default '365',
  lastvisitsessiontime int(10) unsigned NOT NULL default '60',
  lastvisitdefhours int(10) unsigned NOT NULL default '24',
  admdelconfirm tinyint(1) unsigned NOT NULL default '0',
  msendlimit int(10) unsigned NOT NULL default '30',
  admddautosub tinyint(1) unsigned NOT NULL default '0',
  realipmode tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (settingnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_texts`
#

DROP TABLE IF EXISTS simpgb_texts;
CREATE TABLE simpgb_texts (
  textnr int(10) unsigned NOT NULL auto_increment,
  textid varchar(20) NOT NULL default '',
  lang varchar(4) NOT NULL default '',
  text text NOT NULL,
  PRIMARY KEY  (textnr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_users`
#

DROP TABLE IF EXISTS simpgb_users;
CREATE TABLE simpgb_users (
  usernr tinyint(3) unsigned NOT NULL auto_increment,
  username varchar(80) NOT NULL default '',
  password varchar(40) binary NOT NULL default '',
  email varchar(80) default NULL,
  rights int(2) unsigned NOT NULL default '0',
  lastlogin datetime NOT NULL default '0000-00-00 00:00:00',
  lockpw tinyint(1) unsigned NOT NULL default '0',
  displayname varchar(80) NOT NULL default '',
  country varchar(30) NOT NULL default '',
  sig varchar(240) NOT NULL default '',
  avatar varchar(140) NOT NULL default '',
  location varchar(160) NOT NULL default '',
  autopin int(10) unsigned NOT NULL default '0',
  lockentry tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (usernr)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `simpgb_users_online`
#

DROP TABLE IF EXISTS simpgb_users_online;
CREATE TABLE simpgb_users_online (
  timestamp int(15) unsigned NOT NULL default '0',
  ip varchar(18) NOT NULL default '0',
  PRIMARY KEY  (timestamp)
) TYPE=MyISAM;
