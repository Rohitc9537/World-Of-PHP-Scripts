<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>SimpGB V<?php echo $version?> Install</h3></div>
<br>
<?php
if(isset($submit))
{
if(isset($importflags))
{
	require('./fill_flags.php');
}
if(isset($importfreemailer))
{
	require('./fill_freemailer.php');
}
if(isset($importavatars))
{
	require('./fill_avatars.php');
}
if(isset($importemoticons))
{
	require('./fill_emoticons.php');
}
if(isset($importleacher))
{
	require('./fill_leacher.php');
}
if(!$admin_pw1 || !$admin_pw2 || !$admin_user)
	die("Needed fields not filled");
if($admin_pw1 != $admin_pw2)
{
	echo "<div align=\"center\">";
	echo "<font color=\"#ff2200\"><b>Error</b>: Passwords don't match</font>";
	echo "</div><br>";
}
else
{
echo "Creating tables...<br>";
// create table simpgb_leachers
if(!table_exists($leacherprefix."_leachers"))
{
	$sql = "CREATE TABLE ".$leacherprefix."_leachers (";
	$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
  	$sql.= "useragent varchar(80) NOT NULL default '',";
	$sql.= "description text,";
	$sql.= "PRIMARY KEY  (entrynr))";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$leacherprefix."_leachers".mysql_error());
}
// create table simpgb_adm_mail
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_adm_mail;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_adm_mail");
$sql = "CREATE TABLE ".$tableprefix."_adm_mail (";
$sql.= "usernr int(3) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_adm_mail");
// create table simpgb_reserved_names
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_reserved_names;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_reserved_names");
$sql = "CREATE TABLE ".$tableprefix."_reserved_names (";
$sql.= "indexnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "name varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (indexnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_reserved_names");
// create table simpgb_counts
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_counts;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_counts");
$sql = "CREATE TABLE ".$tableprefix."_counts (";
$sql.= "numhits int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "hitcountstart date NOT NULL DEFAULT '0000-00-00', ";
$sql.= "msie int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "mozilla int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "opera int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "icab int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "lynx int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "konqueror int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "win int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "mac int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "linux int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "unix int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bots int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "os2 int(10) unsigned NOT NULL DEFAULT '0' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_counts");
// create table simpgb_search
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_search;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_search");
$sql = "CREATE TABLE ".$tableprefix."_search (";
$sql.= "entrynr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "text text NOT NULL DEFAULT '' ,";
$sql.= "comment text NOT NULL DEFAULT '' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_search");
// create table simpgb_bindata
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_bindata;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_bindata");
$sql = "CREATE TABLE ".$tableprefix."_bindata (";
$sql.= "entrynr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bindata longblob NOT NULL DEFAULT '' ,";
$sql.= "filename varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "mimetype varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "filesize int(10) NOT NULL DEFAULT '0' ,";
$sql.= "fs_filename varchar(240) NOT NULL default '',";
$sql.= "UNIQUE entrynr (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_bindata");
// create table simpgb_texts
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_texts;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_texts");
$sql = "CREATE TABLE ".$tableprefix."_texts (";
$sql.= "textnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "textid varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "lang varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "text text NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (textnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_texts");
// create table simpgb_selections
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_selections;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_selections");
$sql = "CREATE TABLE ".$tableprefix."_selections (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "fieldid varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "text varchar(40) NOT NULL DEFAULT '' ,";
$sql.= "displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "optionvalue varchar(40) NOT NULL DEFAULT '' ,";
$sql.= "language varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "defvalue tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_selections");
// create table simpgb_notify
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_notify;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_notify");
$sql = "CREATE TABLE ".$tableprefix."_notify (";
$sql.= "usernr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_notify");
// create table simpgb_users_online
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_users_online;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_users_online");
$sql = "CREATE TABLE ".$tableprefix."_users_online (";
$sql.= "timestamp int(15) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "ip varchar(18) NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (timestamp));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_users_online");
// create table simpgb_flags
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_flags;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_flags");
$sql = "CREATE TABLE ".$tableprefix."_flags (";
$sql.= "flagnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "country varchar(30) NOT NULL DEFAULT '' ,";
$sql.= "image varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "defentry tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (flagnr),";
$sql.= "UNIQUE country (country));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_flags");
// create table simpgb_avatars
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_avatars;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_avatars");
$sql = "CREATE TABLE ".$tableprefix."_avatars (";
$sql.= "avatarnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "image varchar(140) NOT NULL DEFAULT '' ,";
$sql.= "name varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (avatarnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_avatars");
// create table simpgb_bad_words
if(!table_exists($badwordprefix."_bad_words"))
{
	$sql = "CREATE TABLE ".$badwordprefix."_bad_words (";
	$sql.="indexnr int(10) unsigned NOT NULL auto_increment,";
	$sql.="word varchar(100) NOT NULL DEFAULT '' ,";
	$sql.="replacement varchar(100) NOT NULL DEFAULT '' ,";
	$sql.="PRIMARY KEY (indexnr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$badwordprefix."_bad_words");
}
// create table simpgb_banlist
if(!table_exists($banprefix."_banlist"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$banprefix."_banlist (";
	$sql.= "bannr int(10) unsigned NOT NULL auto_increment,";
	$sql.= "ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql.= "subnetmask varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql.= "reason text ,";
	$sql.= "PRIMARY KEY (bannr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$banprefix."_banlist");
}
// create table simpgb_data
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_data;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_data");
$sql = "CREATE TABLE ".$tableprefix."_data (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "date datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "text text NOT NULL DEFAULT '' ,";
$sql.= "heading varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "poster varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "posteremail varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "posterip varchar(16) NOT NULL DEFAULT '' ,";
$sql.= "language varchar(4) NOT NULL DEFAULT 'de' ,";
$sql.= "country varchar(30) NOT NULL DEFAULT '' ,";
$sql.= "icq int(11) NOT NULL DEFAULT '0' ,";
$sql.= "homepage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "useragent varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "modcomment text NOT NULL DEFAULT '' ,";
$sql.= "commentdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "gender char(1) NOT NULL DEFAULT '' ,";
$sql.= "aim varchar(70) NOT NULL DEFAULT '' ,";
$sql.= "avatar varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "msnm varchar(25) NOT NULL DEFAULT '' ,";
$sql.= "yim varchar(25) NOT NULL DEFAULT '' ,";
$sql.= "validated tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "location varchar(160) NOT NULL DEFAULT '' ,";
$sql.= "age varchar(40) NOT NULL DEFAULT '' ,";
$sql.= "private tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "company varchar(140) NOT NULL DEFAULT '' ,";
$sql.= "found varchar(40) NOT NULL DEFAULT '' ,";
$sql.= "editedbyadmin tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "admineditdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "commenteditor tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "sticky tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "userpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "postingid varchar(40) NOT NULL default '',";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_data");
// create table simpgb_emoticons
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_emoticons;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_emoticons");
$sql = "CREATE TABLE ".$tableprefix."_emoticons (";
$sql.= "iconnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "code varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "emoticon_url varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "emotion varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "inshortcutlist tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "layoutid varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (iconnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_emoticons");
// create table simpgb_failed_logins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_logins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_logins");
$sql = "CREATE TABLE ".$tableprefix."_failed_logins (";
$sql.= "loginnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "username varchar(250) NOT NULL DEFAULT '0' ,";
$sql.= "ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql.= "logindate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "usedpw varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (loginnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_logins");
// create table simpgb_failed_notify
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_notify;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_notify");
$sql = "CREATE TABLE ".$tableprefix."_failed_notify (";
$sql.= "usernr int(10) unsigned NOT NULL DEFAULT '0' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_notify");
// create table simpgb_freemailer
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_freemailer;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_freemailer");
$sql = "CREATE TABLE ".$tableprefix."_freemailer (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "address varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_freemailer");
// create table simpgb_hostcache
if(!table_exists($hcprefix."_hostcache"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$hcprefix."_hostcache (";
	$sql.= "ipadr varchar(16) NOT NULL DEFAULT '0' ,";
	$sql.= "hostname varchar(240) NOT NULL DEFAULT '' ,";
	$sql.= "UNIQUE ipadr (ipadr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$hcprefix."_hostcache");
}
// create table simpgb_iplog
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_iplog;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_iplog");
$sql = "CREATE TABLE ".$tableprefix."_iplog (";
$sql.= "lognr int(10) unsigned NOT NULL auto_increment,";
$sql.= "usernr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "logtime datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql.= "used_lang varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (lognr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_iplog");
// create table simpgb_layout
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_layout;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_layout");
$sql = "CREATE TABLE ".$tableprefix."_layout (";
$sql.= "lang varchar(4) NOT NULL DEFAULT '0' ,";
$sql.= "heading varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "headingbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "headingfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "headingfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "headingfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "contentbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "contentfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "contentfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "contentfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "TableWidth varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "timestampfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "timestampfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "timestampfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "dateformat varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "showcurrtime tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "customheader text NOT NULL DEFAULT '' ,";
$sql.= "pagebgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "stylesheet varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "entryheadingbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "entryheadingfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "entryheadingstyle tinyint(1) NOT NULL DEFAULT '0' ,";
$sql.= "entryheadingfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "entryheadingfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "timestampbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "timestampstyle tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "copyrightbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "copyrightfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "copyrightfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "copyrightfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "layoutnr int(10) NOT NULL auto_increment,";
$sql.= "id varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "deflayout tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "maxentries tinyint(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "userinfopos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "homepagepic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "emailpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "icqpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "browserpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "addentrypic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "posterbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "posterfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "posterfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "posterfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "modcommentbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "modcommentfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "modcommentfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "modcommentfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "requiredbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "requiredfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "gotoppic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "malepic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "femalepic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "inputfields int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "aimpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "posterpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "enableusersonline tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "msnmpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "yimpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "enablelangselector tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablelayoutselector tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "companypic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "closepic varchar(240) NOT NULL DEFAULT 'close.gif' ,";
$sql.= "bbcodepic_bold varchar(240) NOT NULL DEFAULT 'bbcode_bold.gif' ,";
$sql.= "bbcodepic_italic varchar(240) NOT NULL DEFAULT 'bbcode_italic.gif' ,";
$sql.= "bbcodepic_strike varchar(240) NOT NULL DEFAULT 'bbcode_strike.gif' ,";
$sql.= "bbcodepic_type varchar(240) NOT NULL DEFAULT 'bbcode_type.gif' ,";
$sql.= "bbcodepic_sub varchar(240) NOT NULL DEFAULT 'bbcode_sub.gif' ,";
$sql.= "bbcodepic_super varchar(240) NOT NULL DEFAULT 'bbcode_super.gif' ,";
$sql.= "bbcodepic_center varchar(240) NOT NULL DEFAULT 'bbcode_center.gif' ,";
$sql.= "bbcodepic_pic varchar(240) NOT NULL DEFAULT 'bbcode_pic.gif' ,";
$sql.= "bbcodepic_code varchar(240) NOT NULL DEFAULT 'bbcode_code.gif' ,";
$sql.= "bbcodepic_quote varchar(240) NOT NULL DEFAULT 'bbcode_quote.gif' ,";
$sql.= "bbcodepic_liststart varchar(240) NOT NULL DEFAULT 'bbcode_liststart.gif' ,";
$sql.= "bbcodepic_listend varchar(240) NOT NULL DEFAULT 'bbcode_listend.gif' ,";
$sql.= "bbcodepic_listitem varchar(240) NOT NULL DEFAULT 'bbcode_listitem.gif' ,";
$sql.= "bbcodepic_size varchar(240) NOT NULL DEFAULT 'bbcode_size.gif' ,";
$sql.= "bbcodepic_color varchar(240) NOT NULL DEFAULT 'bbcode_color.gif' ,";
$sql.= "bbcodepic_email varchar(240) NOT NULL DEFAULT 'bbcode_email.gif' ,";
$sql.= "bbcodepic_url varchar(240) NOT NULL DEFAULT 'bbcode_url.gif' ,";
$sql.= "bbcodepic_real varchar(240) NOT NULL DEFAULT 'bbcode_real.gif' ,";
$sql.= "bbcodepic_swf varchar(240) NOT NULL DEFAULT 'bbcode_swf.gif' ,";
$sql.= "bbcodepic_help varchar(240) NOT NULL DEFAULT 'bbcode_help.gif' ,";
$sql.= "morepic varchar(240) NOT NULL DEFAULT 'en/more.gif' ,";
$sql.= "pagepic_fwd varchar(240) NOT NULL DEFAULT 'next.gif' ,";
$sql.= "pagepic_last varchar(240) NOT NULL DEFAULT 'last.gif' ,";
$sql.= "pagepic_prev varchar(240) NOT NULL DEFAULT 'previous.gif' ,";
$sql.= "pagepic_first varchar(240) NOT NULL DEFAULT 'first.gif' ,";
$sql.= "customfooter text NOT NULL DEFAULT '' ,";
$sql.= "searchpic varchar(240) NOT NULL DEFAULT 'search.gif' ,";
$sql.= "backpic varchar(240) NOT NULL DEFAULT 'back.gif' ,";
$sql.= "stickypic varchar(240) NOT NULL DEFAULT 'stick.gif' ,";
$sql.= "attachpic varchar(240) NOT NULL DEFAULT 'attach.gif' ,";
$sql.= "attachbgcolor varchar(7) NOT NULL DEFAULT '#e0e0e0' ,";
$sql.= "attachfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "attachfontsize varchar(4) NOT NULL DEFAULT '2' ,";
$sql.= "attachfont varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "quotepic varchar(240) NOT NULL DEFAULT 'quote.gif' ,";
$sql.= "actionbgcolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "actionfontcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "actionfont varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "actionfontsize varchar(4) NOT NULL DEFAULT '2' ,";
$sql.= "changepic varchar(240) NOT NULL DEFAULT 'change.gif' ,";
$sql.= "helppic varchar(240) NOT NULL DEFAULT 'help.gif' ,";
$sql.= "newentrypic varchar(240) NOT NULL DEFAULT 'en/new.gif' ,";
$sql.= "lastvisitcookie tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "pagebgpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "headerspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "actionboxspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "pagenavspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "infoboxspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "copyrightboxspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "noentries text NOT NULL DEFAULT '' ,";
$sql.= "datetimepic varchar(240) NOT NULL DEFAULT 'calendar.gif' ,";
$sql.= "picturepic varchar(240) NOT NULL DEFAULT 'photo.gif' ,";
$sql.= "inputfields2 int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "selectcolor varchar(7) NOT NULL DEFAULT '#a0a0a0' ,";
$sql.= "fontbuttons int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bbcodepic_font varchar(240) NOT NULL DEFAULT 'bbcode_font.gif' ,";
$sql.= "popupwidth int(10) unsigned NOT NULL DEFAULT '400' ,";
$sql.= "popupheight int(10) unsigned NOT NULL DEFAULT '400' ,";
$sql.= "maxuserfilesize int(10) unsigned NOT NULL DEFAULT '250000' ,";
$sql.= "bbcodepic_updown varchar(240) NOT NULL DEFAULT 'bbcode_updown.gif' ,";
$sql.= "bbcodepic_scroll varchar(240) NOT NULL DEFAULT 'bbcode_scroll.gif' ,";
$sql.= "sendmailpic varchar(240) NOT NULL DEFAULT 'sendmail.gif' ,";
$sql.= "actionboxpos int(5) unsigned NOT NULL DEFAULT '3' ,";
$sql.= "bbcodepic_fade varchar(240) NOT NULL DEFAULT 'bbcode_fade.gif' ,";
$sql.= "bbcodepic_fliph varchar(240) NOT NULL DEFAULT 'bbcode_fliph.gif' ,";
$sql.= "bbcodepic_flipv varchar(240) NOT NULL DEFAULT 'bbcode_flipv.gif' ,";
$sql.= "glowcolor varchar(7) NOT NULL DEFAULT '#ffff99' ,";
$sql.= "shadowcolor varchar(7) NOT NULL DEFAULT '#823700' ,";
$sql.= "bbcodepic_glow varchar(240) NOT NULL DEFAULT 'bbcode_glow.gif' ,";
$sql.= "bbcodepic_shadow varchar(240) NOT NULL DEFAULT 'bbcode_shadow.gif' ,";
$sql.= "bbcodepic_blur varchar(240) NOT NULL DEFAULT 'bbcode_blur.gif' ,";
$sql.= "bbcodepic_dropshadow varchar(240) NOT NULL DEFAULT 'bbcode_dropshadow.gif' ,";
$sql.= "dropshadowcolor varchar(7) NOT NULL DEFAULT '#ffff99' ,";
$sql.= "bbcodepic_wmv varchar(240) NOT NULL DEFAULT 'bbcode_wmv.gif' ,";
$sql.= "colorscrollbars tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "sb3dlightcolor varchar(7) NOT NULL DEFAULT '#1E90FF' ,";
$sql.= "sbarrowcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "sbdarkshadowcolor varchar(7) NOT NULL DEFAULT '#4682B4' ,";
$sql.= "sbfacecolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "sbhighlightcolor varchar(7) NOT NULL DEFAULT '#AFEEEE' ,";
$sql.= "sbshadowcolor varchar(7) NOT NULL DEFAULT '#ADD8E6' ,";
$sql.= "sbtrackcolor varchar(7) NOT NULL DEFAULT '#E0FFFF' ,";
$sql.= "sgbsel_bgcolor varchar(7) NOT NULL DEFAULT '#00008B' ,";
$sql.= "sgbsel_color varchar(7) NOT NULL DEFAULT '#F8F8FF' ,";
$sql.= "sgbsel_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,";
$sql.= "sgbsel_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "sgbsel_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "sgbsel_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_bgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_color varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,";
$sql.= "sgbchk_fontsize varchar(10) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_font varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbsel_bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "sgbsel_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "sgbchk_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "sgbsel_fontweight varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbchk_fontweight varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbinput_bgcolor varchar(7) NOT NULL DEFAULT '#00008B' ,";
$sql.= "sgbinput_color varchar(7) NOT NULL DEFAULT '#F8F8FF' ,";
$sql.= "sgbinput_borderstyle varchar(20) NOT NULL DEFAULT 'inset' ,";
$sql.= "sgbinput_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "sgbinput_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "sgbinput_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.= "sgbinput_bordercolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "sgbinput_fontstyle varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbinput_fontweight varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "sgbbutton_bgcolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "sgbbutton_color varchar(7) NOT NULL DEFAULT '#000080' ,";
$sql.= "sgbbutton_borderstyle varchar(20) NOT NULL DEFAULT 'inset' ,";
$sql.= "sgbbutton_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "sgbbutton_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "sgbbutton_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.= "sgbbutton_bordercolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "sgbbutton_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "sgbbutton_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbcsel_color varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "bbcsel_borderstyle varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "bbcsel_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "bbcsel_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "bbcsel_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "bbcsel_bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "bbcsel_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbcsel_fontweight varchar(20) NOT NULL DEFAULT 'bold' ,";
$sql.= "admmailpic varchar(240) NOT NULL DEFAULT 'en/admmail.gif' ,";
$sql.= "sgbisb_3dlightcolor varchar(7) NOT NULL DEFAULT '#1E90FF' ,";
$sql.= "sgbisb_arrowcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "sgbisb_darkshadowcolor varchar(7) NOT NULL DEFAULT '#4682B4' ,";
$sql.= "sgbisb_facecolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "sgbisb_highlightcolor varchar(7) NOT NULL DEFAULT '#AFEEEE' ,";
$sql.= "sgbisb_shadowcolor varchar(7) NOT NULL DEFAULT '#ADD8E6' ,";
$sql.= "sgbisb_trackcolor varchar(7) NOT NULL DEFAULT '#E0FFFF' ,";
$sql.= "admmenupic varchar(240) NOT NULL DEFAULT 'admmenu.gif' ,";
$sql.= "sitehomepic varchar(240) NOT NULL DEFAULT 'homepage.gif' ,";
$sql.= "directeditpic varchar(240) NOT NULL DEFAULT 'editpost.gif' ,";
$sql.= "delentrypic varchar(240) NOT NULL DEFAULT 'delentry.gif' ,";
$sql.= "comentrypic varchar(240) NOT NULL DEFAULT 'writecomment.gif' ,";
$sql.= "helpline_color varchar(7) NOT NULL DEFAULT '#333333' ,";
$sql.= "helpline_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,";
$sql.= "helpline_fontsize varchar(10) NOT NULL DEFAULT '10px' ,";
$sql.= "helpline_font varchar(240) NOT NULL DEFAULT '\"Courier New\", Courier, monospace' ,";
$sql.= "helpline_bgcolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,";
$sql.= "helpline_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "helpline_bordercolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,";
$sql.= "helpline_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "helpline_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "bbccode_color varchar(7) NOT NULL DEFAULT '#444444' ,";
$sql.= "bbccode_borderstyle varchar(20) NOT NULL DEFAULT 'solid' ,";
$sql.= "bbccode_fontsize varchar(10) NOT NULL DEFAULT '8pt' ,";
$sql.= "bbccode_font varchar(240) NOT NULL DEFAULT '\"Courier New\", Courier, monospace' ,";
$sql.= "bbccode_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.= "bbccode_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbccode_bordercolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "bbccode_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbccode_borderwidth varchar(20) NOT NULL DEFAULT '1' ,";
$sql.= "bbcquote_color varchar(7) NOT NULL DEFAULT '#444444' ,";
$sql.= "bbcquote_borderstyle varchar(20) NOT NULL DEFAULT 'solid' ,";
$sql.= "bbcquote_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "bbcquote_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "bbcquote_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.= "bbcquote_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbcquote_bordercolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "bbcquote_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "bbcquote_borderwidth varchar(20) NOT NULL DEFAULT '1' ,";
$sql.= "enablesortselector tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "required_bgpic varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "required_linkcolor varchar(7) NOT NULL DEFAULT '#92ce00' ,";
$sql.= "required_vlinkcolor varchar(7) NOT NULL DEFAULT '#92ce00' ,";
$sql.= "required_alinkcolor varchar(7) NOT NULL DEFAULT '#92ce00' ,";
$sql.= "linkcolor varchar(7) NOT NULL DEFAULT '#076d75' ,";
$sql.= "vlinkcolor varchar(7) NOT NULL DEFAULT '#076d75' ,";
$sql.= "alinkcolor varchar(7) NOT NULL DEFAULT '#076d75' ,";
$sql.= "actionlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "actionvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "actionalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "pagenavlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "pagenavvlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "pagenavalinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "smile_bgcolor varchar(7) NOT NULL DEFAULT '#778899' ,";
$sql.= "smile_linkcolor varchar(7) NOT NULL DEFAULT '#F0E68C' ,";
$sql.= "smile_vlinkcolor varchar(7) NOT NULL DEFAULT '#F0E68C' ,";
$sql.= "smile_alinkcolor varchar(7) NOT NULL DEFAULT '#F0E68C' ,";
$sql.= "bbbox_bgcolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,";
$sql.= "bbbox_linkcolor varchar(7) NOT NULL DEFAULT '#669999' ,";
$sql.= "bbbox_vlinkcolor varchar(7) NOT NULL DEFAULT '#669999' ,";
$sql.= "bbbox_alinkcolor varchar(7) NOT NULL DEFAULT '#669999' ,";
$sql.= "ns4style varchar(240) NOT NULL DEFAULT 'simpgb_ns4.css' ,";
$sql.= "ns6style varchar(240) NOT NULL DEFAULT 'simpgb_ns6.css' ,";
$sql.= "operastyle varchar(240) NOT NULL DEFAULT 'simpgb_opera.css' ,";
$sql.= "konquerorstyle varchar(240) NOT NULL DEFAULT 'simpgb_konqueror.css' ,";
$sql.= "geckostyle varchar(240) NOT NULL DEFAULT 'simpgb_gecko.css' ,";
$sql.= "pagebgrepeat varchar(80) NOT NULL DEFAULT 'repeat' ,";
$sql.= "pagebgposition varchar(80) NOT NULL DEFAULT 'top' ,";
$sql.= "pagebgattach varchar(80) NOT NULL DEFAULT 'scroll' ,";
$sql.= "ftext_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "ftext_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "ftext_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "gbheadingeffect int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "gbhapplet_width int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "gbhapplet_height int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "fan_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "fan_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "fan_speed tinyint(4) unsigned NOT NULL DEFAULT '4' ,";
$sql.= "fan_hspacing tinyint(4) unsigned NOT NULL DEFAULT '4' ,";
$sql.= "fan_vspacing tinyint(4) unsigned NOT NULL DEFAULT '20' ,";
$sql.= "fan_basecolor tinyint(4) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "fan_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "atext_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "atext_fontstyle varchar(20) NOT NULL DEFAULT 'plain' ,";
$sql.= "atext_type varchar(20) NOT NULL DEFAULT 'blink' ,";
$sql.= "atext_align varchar(20) NOT NULL DEFAULT 'center' ,";
$sql.= "atext_fontcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "atext_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "atext_delaytime int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "atext_minfsize tinyint(4) unsigned NOT NULL DEFAULT '6' ,";
$sql.= "atext_maxfsize tinyint(4) unsigned NOT NULL DEFAULT '28' ,";
$sql.= "fw_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "fw_fontsize varchar(10) NOT NULL DEFAULT '36' ,";
$sql.= "fw_fontcolor varchar(7) NOT NULL DEFAULT '#ffffff' ,";
$sql.= "fw_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "fw_rockets tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.= "jt_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "jt_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "jt_fontcolor varchar(7) NOT NULL DEFAULT '#eeeeee' ,";
$sql.= "jt_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "jt_speed tinyint(4) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "jt_randomcolor tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "pt_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "pt_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "pt_fontcolor varchar(7) NOT NULL DEFAULT '#ffffff' ,";
$sql.= "pt_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "pt_fps tinyint(4) unsigned NOT NULL DEFAULT '50' ,";
$sql.= "pt_usesineshift tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "pt_useblur tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "pt_sineshiftspeed tinyint(4) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "pt_sineperiod tinyint(4) unsigned NOT NULL DEFAULT '20' ,";
$sql.= "pt_sinescale int(10) unsigned NOT NULL DEFAULT '15000' ,";
$sql.= "rt_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "rt_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "rt_fontsize varchar(10) NOT NULL DEFAULT '26' ,";
$sql.= "rt_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "rt_sleeptime int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "zz_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "zz_fontcolor varchar(7) NOT NULL DEFAULT '#ffffff' ,";
$sql.= "zz_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "zz_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "zz_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "zz_delay int(10) unsigned NOT NULL DEFAULT '5' ,";
$sql.= "zz_pause int(10) unsigned NOT NULL DEFAULT '2000' ,";
$sql.= "circle_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "circle_fontcolor varchar(7) NOT NULL DEFAULT '#ffffff' ,";
$sql.= "circle_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "circle_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "circle_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "circle_direction tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "circle_bgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "circle_imgalign tinyint(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "circle_texteffects tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "circle_fontpadding tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "circle_pause int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "circle_rotationfactor tinyint(4) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "pac_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "pac_fontcolor varchar(7) NOT NULL DEFAULT '#ff0000' ,";
$sql.= "pac_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "pac_bgcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "pac_paccolor varchar(7) NOT NULL DEFAULT '#00ff00' ,";
$sql.= "sky_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "sky_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "sky_bgcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "sky_bgimg varchar(80) NOT NULL DEFAULT 'cloud.gif' ,";
$sql.= "sky_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "sky_sleeptime int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "sw_font varchar(80) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "sw_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "sw_fontcolor varchar(7) NOT NULL DEFAULT '#ffffff' ,";
$sql.= "sw_bgcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "sw_stars tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "sw_naptime int(10) unsigned NOT NULL DEFAULT '50' ,";
$sql.= "sw_pause int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "sw_numstars tinyint(4) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "sw_ampmulti tinyint(4) unsigned NOT NULL DEFAULT '3' ,";
$sql.= "sw_frequency tinyint(4) unsigned NOT NULL DEFAULT '3' ,";
$sql.= "blt_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "blt_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "blt_fontcolor varchar(7) NOT NULL DEFAULT '#ff0000' ,";
$sql.= "blt_bgcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "blt_delay int(10) unsigned NOT NULL DEFAULT '1000' ,";
$sql.= "blt_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "ct_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "ct_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "ct_fontcolor1 varchar(7) NOT NULL DEFAULT '#ff0000' ,";
$sql.= "ct_fontcolor2 varchar(7) NOT NULL DEFAULT '#00ff00' ,";
$sql.= "ct_fontcolor3 varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "ct_fontcolor4 varchar(7) NOT NULL DEFAULT '#ff00ff' ,";
$sql.= "ct_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "ct_bgcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "neon_bgcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "neon_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "neon_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "neon_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "neon_fontcolor1 varchar(7) NOT NULL DEFAULT '#555555' ,";
$sql.= "neon_fontcolor2 varchar(7) NOT NULL DEFAULT '#ffff00' ,";
$sql.= "neon_delay int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "neon2_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "neon2_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "neon2_bgcolor varchar(7) NOT NULL DEFAULT '#aaaaaa' ,";
$sql.= "neon2_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "neon2_fontcolor1 varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.= "neon2_fontcolor2 varchar(7) NOT NULL DEFAULT '#ffff00' ,";
$sql.= "neon2_fontcolor3 varchar(7) NOT NULL DEFAULT '#ffff88' ,";
$sql.= "neon2_flashspeed int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "neon2_flashletters tinyint(4) unsigned NOT NULL DEFAULT '4' ,";
$sql.= "neon2_flashletters2 tinyint(4) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "neon2_flashpause int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "rainbow_bgcolor varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.= "rainbow_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "rainbow_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "rainbow_fontstyle tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "ft_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "ft_fontsize varchar(10) NOT NULL DEFAULT '24' ,";
$sql.= "ft_bgcolor varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.= "ft_rgb tinyint(4) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "zoom_endsize int(10) unsigned NOT NULL DEFAULT '70' ,";
$sql.= "zoom_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "zoom_bgcolor varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.= "zoom_startsize int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "zoom_zoomspeed int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "zoom_step tinyint(4) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "zoom_fadespeed int(10) unsigned NOT NULL DEFAULT '70' ,";
$sql.= "zoom_pause int(10) unsigned NOT NULL DEFAULT '70' ,";
$sql.= "zoom_fontcolor varchar(7) NOT NULL DEFAULT '#ff00ff' ,";
$sql.= "zoom_zoomcolor varchar(7) NOT NULL DEFAULT '#00ff00' ,";
$sql.= "typer_bgcolor varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.= "typer_fontsize int(10) unsigned NOT NULL DEFAULT '70' ,";
$sql.= "typer_fontcolor varchar(7) NOT NULL DEFAULT '#00ffff' ,";
$sql.= "typer_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "typer_speed int(10) unsigned NOT NULL DEFAULT '150' ,";
$sql.= "typer_align tinyint(4) unsigned NOT NULL DEFAULT '2' ,";
$sql.= "led_msg1 varchar(80) NOT NULL DEFAULT 'guestbook' ,";
$sql.= "led_msg2 varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "led_msg3 varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "led_msg4 varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "led_pause int(10) unsigned NOT NULL DEFAULT '3000' ,";
$sql.= "tablealign tinyint(4) unsigned NOT NULL DEFAULT '2' ,";
$sql.= "fxalign tinyint(4) unsigned NOT NULL DEFAULT '2' ,";
$sql.= "addboxspace int(10) unsigned NOT NULL DEFAULT '10' ,";
$sql.= "contentnote varchar(250) NOT NULL DEFAULT '' ,";
$sql.= "displayentrynr tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "rainbow_bordercolor varchar(7) NOT NULL default '#ff0000',";
$sql.= "bprow tinyint(4) unsigned NOT NULL default '6',";
$sql.= "bbcodepic_rainbow varchar(240) NOT NULL default 'bbcode_rainbow.gif',";
$sql.= "pboxwidth varchar(10) NOT NULL default '10%',";
$sql.= "cnt_color1 varchar(7) NOT NULL default '#ff0000',";
$sql.= "cnt_color2 varchar(7) NOT NULL default '#00ff00',";
$sql.= "cnt_color3 varchar(7) NOT NULL default '#ff7575',";
$sql.= "noscbartextarea tinyint(1) unsigned NOT NULL default '0',";
$sql.= "emoticonlimit int(4) unsigned NOT NULL default '0',";
$sql.= "avmaxwidth int(10) unsigned NOT NULL default '0',";
$sql.= "avmaxheight int(10) unsigned NOT NULL default '0',";
$sql.= "headerfile varchar(250) NOT NULL default '',";
$sql.= "footerfile varchar(250) NOT NULL default '',";
$sql.= "headerfilepos tinyint(1) unsigned default '0',";
$sql.= "footerfilepos tinyint(1) unsigned default '0',";
$sql.= "cheadnobr tinyint(1) unsigned default '0',";
$sql.= "cfootnobr tinyint(1) unsigned default '0',";
$sql.= "usecustomheader tinyint(1) unsigned default '0',";
$sql.= "usecustomfooter tinyint(1) unsigned default '0',";
$sql.= "usrnopreview tinyint(1) unsigned NOT NULL default '0',";
$sql.= "nonltrans tinyint(4) unsigned default '0',";
$sql.= "PRIMARY KEY (layoutnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_layout");
// create table simpgb_misc
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_misc;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_misc");
$sql = "CREATE TABLE ".$tableprefix."_misc (";
$sql.= "shutdown tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "shutdowntext text );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_misc");
// create table simpgb_session
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_session;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_session");
$sql = "CREATE TABLE ".$tableprefix."_session (";
$sql.= "sessid int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "usernr int(10) NOT NULL DEFAULT '0' ,";
$sql.= "starttime int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "remoteip varchar(15) NOT NULL DEFAULT '' ,";
$sql.= "lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (sessid),";
$sql.= "INDEX sess_id (sessid),";
$sql.= "INDEX start_time (starttime),";
$sql.= "INDEX remote_ip (remoteip));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_session");
// create table simpgb_settings
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_settings;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_settings");
$sql = "CREATE TABLE ".$tableprefix."_settings (";
$sql.= "settingnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "watchlogins tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablefailednotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "simpgbmail varchar(180) NOT NULL DEFAULT '' ,";
$sql.= "loginlimit int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "usemenubar tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "nofreemailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablehostresolve tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablebbcode tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "enableemoticons tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "emoticonautoclose tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "sortingmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "separatebylang tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "allowhtml tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablebadwordlist tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "floodprotectdelay int(4) unsigned NOT NULL DEFAULT '60' ,";
$sql.= "userbanlist tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "maxwordlength smallint(3) unsigned NOT NULL DEFAULT '20' ,";
$sql.= "enableavatarupload tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "newentrynotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "validateposts tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "minmsglength int(5) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "allowprivateposts tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "maxmsglength int(5) unsigned NOT NULL DEFAULT '500' ,";
$sql.= "allowedbbcodes int(10) unsigned NOT NULL DEFAULT '16383' ,";
$sql.= "redirectdelay tinyint(2) NOT NULL DEFAULT '5' ,";
$sql.= "enablesearch tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "useronlinetime int(4) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "tryrealip tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "minfontsize tinyint(2) NOT NULL DEFAULT '-5' ,";
$sql.= "maxfontsize tinyint(2) NOT NULL DEFAULT '5' ,";
$sql.= "allowinternalmailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "maxmaillength int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "emailfeatures int(5) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "allowadmmail tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "trimperiods tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "trimperiodlength int(10) unsigned NOT NULL DEFAULT '6' ,";
$sql.= "admmenulink tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "sitehome varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "linksitehome tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "simpgbmailname varchar(180) NOT NULL DEFAULT '' ,";
$sql.= "directeditlink tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablequote tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "enabledel tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablemodcom tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "blockoldbrowser tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "servertimezone int(10) NOT NULL default '0',";
$sql.= "displaytimezone int(10) NOT NULL default '0',";
$sql.= "disableposting tinyint(1) unsigned NOT NULL default '0',";
$sql.= "blockleacher tinyint(1) unsigned NOT NULL default '0',";
$sql.= "sendpostingmail tinyint(1) unsigned NOT NULL default '0',";
$sql.= "lastvisitdays int(10) unsigned NOT NULL default '365',";
$sql.= "lastvisitsessiontime int(10) unsigned NOT NULL default '60',";
$sql.= "lastvisitdefhours int(10) unsigned NOT NULL default '24',";
$sql.= "admdelconfirm tinyint(1) unsigned NOT NULL default '0',";
$sql.= "msendlimit int(10) unsigned NOT NULL default '30',";
$sql.= "admddautosub tinyint(1) unsigned NOT NULL default '0',";
$sql.= "realipmode tinyint(1) unsigned NOT NULL default '0',";
$sql.= "PRIMARY KEY (settingnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_settings");
// create table simpgb_users
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_users;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_users");
$sql = "CREATE TABLE ".$tableprefix."_users (";
$sql.= "usernr tinyint(3) unsigned NOT NULL auto_increment,";
$sql.= "username varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "password varchar(40) binary NOT NULL DEFAULT '' ,";
$sql.= "email varchar(80) ,";
$sql.= "rights int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "lockpw tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "displayname varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "country varchar(30) NOT NULL DEFAULT '' ,";
$sql.= "sig varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "avatar varchar(140) NOT NULL DEFAULT '' ,";
$sql.= "location varchar(160) NOT NULL DEFAULT '' ,";
$sql.= "autopin int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "lockentry tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (usernr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_users");
// insert adminuser
$admin_pw=md5($admin_pw1);
$admin_user=addslashes(strtolower($admin_user));
$sql = "INSERT INTO ".$tableprefix."_users (";
$sql .="username, password, rights";
if(isset($admin_email))
	$sql .=", email";
$sql .=")";
$sql .="VALUES ('$admin_user', '$admin_pw', 4";
if(isset($admin_email))
	$sql .=", '$admin_email'";
$sql .=");";
if(!$result = mysql_query($sql, $db))
	die("Unable to create adminuser");
echo "Adding default layout...<br>";
$sql="INSERT INTO ".$tableprefix."_layout VALUES ('en', 'Guestbook', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '+2', '#000000', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '98%', '#000000', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'm/d/Y H:i:s', 1, '', '#c0c0c0', 'simpgb.css', '#e0e0e0', '#222222', 1, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#cccccc', 2, '#cccccc', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', 1, 'default', 1, 0, 2, 'homepage.gif', 'email.gif', 'icq.gif', 'browser.gif', 'addentry.gif', '#e0e0e0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#d0d0d0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#ddb0b0', '#000000', 'go_top.gif', 'male.gif', 'female.gif', 85284183, 'aim.gif', 'user.gif', 1, 'msn.gif', 'yahoo.gif', 0, 0, 'company.gif', 'close.gif', 'bbcode_bold.gif', 'bbcode_italic.gif', 'bbcode_strike.gif', 'bbcode_type.gif', 'bbcode_sub.gif', 'bbcode_super.gif', 'bbcode_center.gif', 'bbcode_pic.gif', 'bbcode_code.gif', 'bbcode_quote.gif', 'bbcode_liststart.gif', 'bbcode_listend.gif', 'bbcode_listitem.gif', 'bbcode_size.gif', 'bbcode_color.gif', 'bbcode_email.gif', 'bbcode_url.gif', 'bbcode_real.gif', 'bbcode_swf.gif', 'bbcode_help.gif', 'more.gif', 'next.gif', 'last.gif', 'previous.gif', 'first.gif', '', 'search.gif', 'back.gif', 'stick.gif', 'attach.gif', '#e0e0e0', '#000000', '2', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'quote.gif', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', 'change.gif', 'help.gif', 'en/new.gif', 1, '', 10, 10, 10, 10, 10, '', 'calendar.gif', 'photo.gif', 0, '#a0a0a0', 15, 'bbcode_font.gif', 400, 400, 250000, 'bbcode_updown.gif', 'bbcode_scroll.gif', 'sendmail.gif', 3, 'bbcode_fade.gif', 'bbcode_fliph.gif', 'bbcode_flipv.gif', '#ffff99', '#823700', 'bbcode_glow.gif', 'bbcode_shadow.gif', 'bbcode_blur.gif', 'bbcode_dropshadow.gif', '#ffff99', 'bbcode_wmv.gif', 1, '#1E90FF', '#0000ff', '#4682B4', '#94AAD6', '#AFEEEE', '#ADD8E6', '#E0FFFF', '#00008B', '#F8F8FF', 'none', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '', '', '', 'none', '', '', '', '', '', 'normal', 'normal', '', '', '#00008B', '#F8F8FF', 'inset', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'thin', '#191970', '', '', '#94AAD6', '#000080', 'inset', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'thin', '#191970', 'normal', 'normal', '#000000', '', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '', '', 'normal', 'bold', 'admmail.gif', '#1E90FF', '#0000ff', '#4682B4', '#94AAD6', '#AFEEEE', '#ADD8E6', '#E0FFFF', 'admmenu.gif', 'homepage.gif', 'editpost.gif', 'delentry.gif', 'writecomment.gif', '#333333', 'none', '10px', '\"Courier New\", Courier, monospace', '#c0c0c0', 'normal', '#c0c0c0', 'normal', '', '#444444', 'solid', '8pt', '\"Courier New\", Courier, monospace', '#DCDCD', 'normal', '#000000', 'normal', '1', '#444444', 'solid', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '#DCDCDC', 'normal', '#000000', 'normal', 'thin', 0, '', '#92ce00', '#92ce00', '#92ce00', '#076d75', '#076d75', '#076d75', '#F0FFFF', '#F0FFFF', '#F0FFFF', '#FFF0C0', '#FFF0C0', '#FFF0C0', '#778899', '#F0E68C', '#F0E68C', '#F0E68C', '#c0c0c0', '#669999', '#669999', '#669999', 'simpgb_ns4.css', 'simpgb_ns6.css', 'simpgb_opera.css', 'simpgb_konqueror.css', 'simpgb_gecko.css', 'repeat', 'top', 'scroll', 'Verdana', '24', '#000000', 0, 200, 200, 'Verdana', '24', 4, 4, 20, 6, '#ffff26', 'Verdana', 'bold', 'wave', 'center', '#aaaaaa', '#000000', 100, 6, 28, 'Verdana', '36', '#ffffff', '#000000', 20, 'Verdana', '24', '#eeeeee', '#000000', 200, 1, 'Verdana', '24', '#ffffff', '#000000', 50, 1, 1, 100, 20, 15000, '#000000', 'Verdana', '26', 0, 100, '#000000', '#ffffff', 'Verdana', '24', 0, 5, 2000, 'Verdana', '#ffffff', '24', 0, '#000000', 0, '', 1, 4, 0, 100, 100, 'Verdana', '#ff0000', '24', '#aaaaaa', '#00ff00', 'Verdana', '24', '#0000ff', 'cloud.gif', 0, 100, 'Verdana', '24', '#ffff3d', '#000000', 1, 50, 100, 10, 3, 3, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#ff0000', '#aaaaaa', 1000, 0, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#ff0000', '#00ff00', '#0000ff', '#ff00ff', 0, '#aaaaaa', '#aaaaaa', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', 0, '#555555', '#ffff00', 100, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#aaaaaa', 0, '#999999', '#ffff00', '#ffff88', 100, 4, 1, 0, '#999999', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', 2, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#999999', 1, 70, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '#999999', 10, 40, 5, 40, 70, '#ff00ff', '#00ff00', '#999999', 70, '#00ffff', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 150, 2, 'guestbook', '', '', '', 3000, 2, 2, 10, '', 0, '#ff0000', 6, 'bbcode_rainbow.gif', '10%', '#ff0000', '#00ff00', '#ff7575', 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0);";
if(!$result = mysql_query($sql, $db))
	die("Unable to add layout (1) ".mysql_error());
$sql="INSERT INTO ".$tableprefix."_layout VALUES ('de', 'G&auml;stebuch', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '+2', '#000000', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '98%', '#000000', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'd.m.Y H:i:s', 1, '', '#c0c0c0', 'simpgb.css', '#e0e0e0', '#222222', 1, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#cccccc', 2, '#cccccc', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', 2, 'default', 1, 4, 2, 'homepage.gif', 'email.gif', 'icq.gif', 'browser.gif', 'addentry.gif', '#e0e0e0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#d0d0d0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#ff1526', '#ffffaf', 'go_top.gif', 'male.gif', 'female.gif', 85415255, 'aim.gif', 'user.gif', 1, 'msn.gif', 'yahoo.gif', 0, 0, 'company.gif', 'close.gif', 'bbcode_bold.gif', 'bbcode_italic.gif', 'bbcode_strike.gif', 'bbcode_type.gif', 'bbcode_sub.gif', 'bbcode_super.gif', 'bbcode_center.gif', 'bbcode_pic.gif', 'bbcode_code.gif', 'bbcode_quote.gif', 'bbcode_liststart.gif', 'bbcode_listend.gif', 'bbcode_listitem.gif', 'bbcode_size.gif', 'bbcode_color.gif', 'bbcode_email.gif', 'bbcode_url.gif', 'bbcode_real.gif', 'bbcode_swf.gif', 'bbcode_help.gif', 'more.gif', 'next.gif', 'last.gif', 'previous.gif', 'first.gif', '', 'search.gif', 'back.gif', 'stick.gif', 'attach.gif', '#e0e0e0', '#000000', '2', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'quote.gif', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', 'change.gif', 'help.gif', 'de/new.gif', 1, '', 10, 10, 10, 10, 10, '', 'calendar.gif', 'photo.gif', 0, '#a0a0a0', 15, 'bbcode_font.gif', 400, 400, 250000, 'bbcode_updown.gif', 'bbcode_scroll.gif', 'sendmail.gif', 3, 'bbcode_fade.gif', 'bbcode_fliph.gif', 'bbcode_flipv.gif', '#ffff99', '#823700', 'bbcode_glow.gif', 'bbcode_shadow.gif', 'bbcode_blur.gif', 'bbcode_dropshadow.gif', '#ffff99', 'bbcode_wmv.gif', 1, '#1E90FF', '#0000ff', '#4682B4', '#94AAD6', '#AFEEEE', '#ADD8E6', '#E0FFFF', '#00008B', '#F8F8FF', 'none', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '', '', '', 'none', '', '', '', '', '', 'normal', 'normal', '', '', '#00008B', '#F8F8FF', 'inset', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'thin', '#191970', '', '', '#94AAD6', '#000080', 'inset', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'thin', '#191970', 'normal', 'normal', '#000000', '', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '', '', 'normal', 'bold', 'admmail.gif', '#1E90FF', '#0000ff', '#4682B4', '#94AAD6', '#AFEEEE', '#ADD8E6', '#E0FFFF', 'admmenu.gif', 'homepage.gif', 'editpost.gif', 'delentry.gif', 'writecomment.gif', '#333333', 'none', '10px', '\"Courier New\", Courier, monospace', '#c0c0c0', 'normal', '#c0c0c0', 'normal', '', '#444444', 'solid', '8pt', '\"Courier New\", Courier, monospace', '#DCDCD', 'normal', '#000000', 'normal', '1', '#444444', 'solid', '10pt', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '#DCDCDC', 'normal', '#000000', 'normal', 'thin', 0, '', '#92ce00', '#92ce00', '#92ce00', '#076d75', '#076d75', '#076d75', '#F0FFFF', '#F0FFFF', '#F0FFFF', '#FFF0C0', '#FFF0C0', '#FFF0C0', '#778899', '#F0E68C', '#F0E68C', '#F0E68C', '#c0c0c0', '#669999', '#669999', '#669999', 'simpgb_ns4.css', 'simpgb_ns6.css', 'simpgb_opera.css', 'simpgb_konqueror.css', 'simpgb_gecko.css', 'repeat', 'top', 'scroll', 'Verdana', '24', '#000000', 0, 200, 200, 'Verdana', '24', 4, 4, 20, 6, '#ffff26', 'Verdana', 'bold', 'wave', 'center', '#aaaaaa', '#000000', 100, 6, 28, 'Verdana', '36', '#ffffff', '#000000', 20, 'Verdana', '24', '#eeeeee', '#000000', 200, 1, 'Verdana', '24', '#ffffff', '#000000', 50, 1, 1, 100, 20, 18000, '#000000', 'Verdana', '26', 0, 100, '#000000', '#ffffff', 'Verdana', '24', 0, 5, 2000, 'Verdana', '#ffffff', '24', 0, '#000000', 0, '', 1, 4, 0, 100, 100, 'Verdana', '#ff0000', '24', '#aaaaaa', '#00ff00', 'Verdana', '24', '#0000ff', 'cloud.gif', 0, 100, 'Verdana', '24', '#ffff3d', '#000000', 1, 50, 100, 10, 3, 3, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#ff0000', '#aaaaaa', 1000, 3, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#ff0000', '#ffff94', '#0000ff', '#ff00ff', 0, '#0ee9ed', '#8dffff', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', 0, '#8a0066', '#ffff00', 100, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#aaaaaa', 0, '#4b4d00', '#ffff00', '#ffff88', 100, 4, 1, 0, '#999999', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', 2, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '24', '#999999', 1, 70, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '#999999', 10, 40, 5, 40, 70, '#ff00ff', '#00ff00', '#999999', 70, '#00ffff', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 150, 2, 'gaestebuch', '', '', '', 3000, 2, 2, 10, '', 0, '#ff0000', 6, 'bbcode_rainbow.gif', '10%', '#ff0000', '#00ff00', '#ff7575', 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0);";
if(!$result = mysql_query($sql, $db))
	die("Unable to add layout (2) ".mysql_error());
echo "Adding default settings...<br>";
$sql="INSERT INTO ".$tableprefix."_settings VALUES (1, 1, 0, 'simpgb@localhost', 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 30, 1, 60, 0, 0, 0, 20, 1, 500, 1048575, 5, 1, 300, 0, -5, 5, 0 , 300, 31, 1 ,0 ,6, 1, '', 0, 'SimpGB', 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 365, 60, 24, 0, 30, 0, 0);";
if(!$result = mysql_query($sql, $db))
	die("Unable to add settings ".mysql_error());
if(isset($importavatars))
{
	echo "Adding default avatars...<br>";
	fill_avatars($tableprefix,$db);
}
if(isset($importflags))
{
	echo "Adding default flags...<br>";
	fill_flags($tableprefix,$db);
}
if(isset($importfreemailer))
{
	echo "Adding default freemailers...<br>";
	fill_freemailer($tableprefix,$db);
}
if(isset($importemoticons))
{
	echo "Adding default smilies...<br>";
	fill_emoticons($tableprefix,$db);
}
if(isset($importleacher))
{
	echo "Adding default offline browser...<br>";
	fill_leacher($leacherprefix,$db);
}
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_*.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
<?php
exit;
}
}
if(!isset($admin_user))
	$admin_user="";
if(!isset($admin_email))
	$admin_email="";
?>
<table align="center" width="80%">
<tr><td align="center" colspan="3"><b>Adminuser</b></td></tr>
<form action="<?php echo $act_script_url?>" method="post">
<tr><td align="right">Username:</td><td align="center" width="1%">*</td>
<td><input type="text" name="admin_user" size="40" maxlength="80" value="<?php echo $admin_user?>"></td></tr>
<tr><td align="right">E-Mail:</td><td align="center" width="1%">&nbsp;</td>
<td><input type="text" name="admin_email" size="40" maxlength="80" value="<?php echo $admin_email?>"></td></tr>
<tr><td align="right">Password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw1" size="40" maxlength="40"></td></tr>
<tr><td align="right">retype password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw2" size="40" maxlength="40"></td></tr>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importfreemailer" value="1"> import predefined freemailer</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importflags" value="1"> import predefined flags</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importavatars" value="1"> import predefined avatars</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importemoticons" value="1"> import predefined smilies</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importleacher" value="1"> import predefined offline browser</td></TR>
<tr><td align="center" colspan="3"><input type="submit" name="submit" value="submit"></td></tr>
</form>
</table>
</body></html>
<?php
function table_exists($searchedtable)
{
	global $dbname;

	$tables = mysql_list_tables($dbname);
	$numtables = @mysql_numrows($tables);
	for($i=0;$i<$numtables;$i++)
	{
		$tablename = mysql_tablename($tables,$i);
		if($tablename==$searchedtable)
			return true;
	}
	return false;
}
?>