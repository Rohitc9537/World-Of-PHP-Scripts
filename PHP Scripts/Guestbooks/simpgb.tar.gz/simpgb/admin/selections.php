<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_selections;
require_once('./heading.php');
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(!isset($sellang))
	$sellang=$act_lang;
if(isset($mode))
{
	if($mode=="move")
	{
		if($direction=="up")
		{
			$sql="select displaypos from ".$tableprefix."_selections where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			if(!$myrow=mysql_fetch_array($result))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Calling error.");
			$newpos=$myrow["displaypos"]-1;
			$sql="update ".$tableprefix."_selections set displaypos=displaypos+1 where displaypos='$newpos' and language='$sellang' and fieldid='$selectid'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			$sql="update ".$tableprefix."_selections set displaypos=$newpos where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		}
		if($direction=="down")
		{
			$sql="select displaypos from ".$tableprefix."_selections where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			if(!$myrow=mysql_fetch_array($result))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Calling error.");
			$newpos=$myrow["displaypos"]+1;
			$sql="update ".$tableprefix."_selections set displaypos=displaypos-1 where displaypos='$newpos' and language='$sellang' and fieldid='$selectid'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			$sql="update ".$tableprefix."_selections set displaypos=$newpos where entrynr='$input_entrynr'";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		}
	}
	if($mode=="new")
	{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_newselection?>:
<?php echo $l_selectionids["$selectid"]?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="sellang" value="<?php echo $sellang?>">
<input type="hidden" name="selectid" value="<?php echo $selectid?>">
<input type="hidden" name="mode" value="add">
<?php
if(is_konqueror())
	echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%">
<?php echo $l_displaytext?>:</td>
<td><input class="sgbinput" type="text" name="input_text" size="40" maxlength="40"></td></tr>
<tr class="inputrow"><td align="right" width="30%">
<?php echo $l_assignedvalue?>:</td>
<td><input class="sgbinput" type="text" name="input_value" size="40" maxlength="40"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
</form></table></td></tr></table>
<?php
		include('./trailer.php');
		echo "</body></html>";
		exit;
	}
	if($mode=="edit")
	{
		$sql="select * from ".$tableprefix."_selections where entrynr='$input_entrynr'";
		if(!$result=mysql_query($sql, $db))
			die("Unable to add entry to database.");
		if(!$myrow=mysql_fetch_array($result))
			die("no such entry");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_editselection?>:
<?php echo $l_selectionids["$selectid"]?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="sellang" value="<?php echo $sellang?>">
<input type="hidden" name="selectid" value="<?php echo $selectid?>">
<input type="hidden" name="input_entrynr" value="<?php echo $input_entrynr?>">
<input type="hidden" name="mode" value="update">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="inputrow"><td align="right" width="30%">
<?php echo $l_displaytext?>:</td>
<td><input class="sgbinput" type="text" name="input_text" size="40" maxlength="40" value="<?php echo $myrow["text"]?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%">
<?php echo $l_assignedvalue?>:</td>
<td><input class="sgbinput" type="text" name="input_value" size="40" maxlength="40" value="<?php echo $myrow["optionvalue"]?>"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" value="<?php echo $l_update?>"></td></tr>
</form></table></td></tr></table>
<?php
		include('./trailer.php');
		echo "</body></html>";
		exit;
	}
	if($mode=="delete")
	{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_selections where (entrynr='$input_entrynr')";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\"><td align=\"center\">";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&selectid=$selectid&sellang=$sellang")."\">$l_selections</a></div>";
		include('./trailer.php');
		echo "</body></html>";
		exit;
	}
	if($mode=="add")
	{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		$input_text=trim($input_text);
		$input_value=trim($input_value);
		if(!$input_text)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nodisplaytext</td></tr>";
			$errors=1;
		}
		if(!$input_value)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noassignedvalue</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$displaypos=1;
			$sql = "select max(displaypos) as newdisplaypos from ".$tableprefix."_selections where fieldid='$selectid' and language='$sellang'";
			if(!$result=mysql_query($sql, $db))
			    die("Unable to add entry to database.");
			if($myrow=mysql_fetch_array($result))
				$displaypos=$myrow["newdisplaypos"]+1;
			$sql = "insert into ".$tableprefix."_selections (fieldid, text, displaypos, optionvalue, language) ";
			$sql.= "values ('$selectid', '$input_text', $displaypos, '$input_value', '$sellang')";
			if(!$result = mysql_query($sql, $db))
			    die("Unable to add entry to database.".mysql_error());
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_entryadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&selectid=$selectid&sellang=$sellang")."\">$l_selections</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
		include('./trailer.php');
		echo "</body></html>";
		exit;
	}
	if($mode=="update")
	{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		$input_text=trim($input_text);
		$input_value=trim($input_value);
		if(!$input_text)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nodisplaytext</td></tr>";
			$errors=1;
		}
		if(!$input_value)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noassignedvalue</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql = "update ".$tableprefix."_selections set text='$input_text', optionvalue='$input_value' where entrynr=$input_entrynr";
			if(!$result = mysql_query($sql, $db))
			    die("Unable to update entry in database.".mysql_error());
			echo "<tr class=\"displayrow\"><td align=\"center\">";
			echo "$l_entryupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?$langvar=$act_lang&selectid=$selectid&sellang=$sellang")."\">$l_selections</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
		include('./trailer.php');
		echo "</body></html>";
		exit;
	}
	if($mode=="setdefault")
	{
		$sql="update ".$tableprefix."_selections set defvalue=0 where language='$sellang' and fieldid='$selectid'";
		if(!$result=mysql_query($sql, $db))
		    die("Unable to update database.");
		$sql="update ".$tableprefix."_selections set defvalue=1 where entrynr='$input_entrynr'";
		if(!$result=mysql_query($sql, $db))
		    die("Unable to update database.");
	}
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<tr class="inputrow"><td align="center" colspan="7">
<?php echo $l_selectionbox?>: <select name="selectid">
<?php
while(list($key, $val) = each($l_selectionids))
{
	echo "<option value=\"".$key."\"";
	if(isset($selectid) && ($key==$selectid))
		echo "selected";
	echo ">".$val."</option>";
}
?>
</select>&nbsp;
<?php echo $l_language?>: <?php echo language_select($sellang,"sellang","../language")?>
&nbsp;<input class="sgbbutton" type="submit" value="<?php echo $l_ok?>"></td></tr></form>
<?php
if(!isset($selectid))
{
	echo "</table></td></tr></table>";
	include('./trailer.php');
	echo "</body></html>";
	exit;
}
$sql = "select * from ".$tableprefix."_selections where fieldid='$selectid' and language='$sellang' order by displaypos asc";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow = mysql_fetch_array($result))
{
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"7\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td class="rowheadings" align="center" width="30%"><b><?php echo $l_displaytext?></b></td>
<td class="rowheadings" align="center" width="30%"><b><?php echo $l_assignedvalue?></b></td>
<td class="rowheadings" align="center" width="20%"><b><?php echo $l_default?></b></td>
<td class="rowheadings" width="5%">&nbsp;</td>
<td class="rowheadings" width="5%">&nbsp;</td>
<td class="rowheadings">&nbsp;</td></tr>
<?php
$mycount=0;
do{
	$mycount++;
	$act_id=$myrow["entrynr"];
	echo "<tr class=\"displayrow\">";
	echo "<td align=\"center\">".$myrow["text"]."</td>";
	echo "<td align=\"center\">".$myrow["optionvalue"]."</td>";
	echo "<td align=\"center\">";
	if($myrow["defvalue"]==1)
		echo "<img src=\"gfx/checkmark.gif\" border=\"0\">";
	else
	{
		echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=setdefault&input_entrynr=$act_id&$langvar=$act_lang&sellang=$sellang&selectid=$selectid")."\">";
		echo "$l_set</a>";
	}
	echo "</td>";
	if($mycount>1)
	{
		echo "<td align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?mode=move&input_entrynr=$act_id&sellang=$sellang&$$langvar=$act_lang&direction=up&selectid=$selectid")."\">";
		echo "<img src=\"gfx/up.gif\" border=\"0\" title=\"$l_move_up\" alt=\"$l_move_up\"></a>";
		echo "</td>";
	}
	else
		echo "<td>&nbsp;</td>";
	if($mycount<mysql_num_rows($result))
	{
		echo "<td align=\"center\">";
		echo "<a href=\"".do_url_session("$act_script_url?mode=move&$langvar=$act_lang&input_entrynr=$act_id&sellang=$sellang&direction=down&selectid=$selectid")."\">";
		echo "<img src=\"gfx/down.gif\" border=\"0\" title=\"$l_move_down\" alt=\"$l_move_down\"></a>";
		echo "</td>";
	}
	else
		echo "<td>&nbsp;</td>";
	echo "<td>";
	echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_entrynr=$act_id&$langvar=$act_lang&sellang=$sellang&selectid=$selectid")."\">";
	echo "<img src=\"gfx/delete.gif\" border=\"0\" alt=\"$l_delete\" title=\"$l_delete\"></a> ";
	echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=edit&$langvar=$act_lang&input_entrynr=$act_id&sellang=$sellang&selectid=$selectid")."\">";
	echo "<img src=\"gfx/edit.gif\" border=\"0\" alt=\"$l_edit\" title=\"$l_edit\"></a>";
	echo "</td></tr>";
}while($myrow=mysql_fetch_array($result));
echo "</table></tr></td></table>";
}
?>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?mode=new&$langvar=$act_lang")?>&selectid=<?php echo $selectid?>"><?php echo $l_newentry?></a></div>
<?php
include('./trailer.php');
?>
</body></html>