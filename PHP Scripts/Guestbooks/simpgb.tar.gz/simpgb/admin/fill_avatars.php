<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function fill_avatars($tableprefix, $db)
{
$arr = array(
"VALUES (1, '1.gif', 'smiling bear');",
"VALUES (2, '100.gif', 'ghost');",
"VALUES (3, '101.gif', 'goofy');",
"VALUES (4, '105.gif', 'haegar');",
"VALUES (5, '108.gif', 'skunk');",
"VALUES (6, '110.gif', 'mad cow');",
"VALUES (7, '119.gif', 'kermit');",
"VALUES (8, '114.gif', 'jerry');",
"VALUES (9, '122.gif', 'car');",
"VALUES (10, '134.gif', 'snowman');",
"VALUES (11, '144.gif', 'tigger');",
"VALUES (12, '136.gif', 'roadrunner');",
"VALUES (13, '145.gif', 'mad smilie');",
"VALUES (14, '15.gif', 'alien');",
"VALUES (15, '182.gif', 'pink panther');",
"VALUES (16, '32.gif', 'r2d2');",
"VALUES (17, '86.gif', 'worm');",
"VALUES (19, 'bart1.gif', 'bart');",
"VALUES (20, 'braniac.gif', 'smurf');",
"VALUES (21, 'bwf.gif', 'animated frog');",
"VALUES (22, 'cb_snoopy.gif', 'snoopy');",
"VALUES (23, 'cleatus.gif', 'Cleatus');",
"VALUES (24, 'dilbert.gif', 'dilbert');",
"VALUES (25, 'garfield.gif', 'garfield');",
"VALUES (26, 'maggie.gif', 'maggie');",
"VALUES (27, 'mushroom.gif', 'mushroom');",
"VALUES (28, 'scuba_steve.gif', 'scuba steve');",
"VALUES (29, 'woodstock.gif', 'woodstock');",
"VALUES (30, 'worm_in_hole.gif', 'worm in hole');",
"VALUES (31, 'cook.gif', 'cook');",
"VALUES (32, 'wuschel.gif', 'wuschel');",
"VALUES (33, 'brain.gif', 'Brain');",
"VALUES (34, 'donkey.gif', 'Donkey');",
"VALUES (35, 'dr_opus.gif', 'Dr. Opus');",
"VALUES (36, 'gromit.gif', 'Gromit');",
"VALUES (37, 'pinky.gif', 'Pinky');",
"VALUES (38, 'star_trek.gif', 'Star Trek');"
);
for($i = 0; $i< count($arr); $i++)
{
	$sql = "INSERT INTO ".$tableprefix."_avatars ";
	$sql .=$arr[$i];
	if(!$result = mysql_query($sql, $db))
		die("Unable to insert data into ".$tableprefix."_avatars ($i)");
}
}
?>
