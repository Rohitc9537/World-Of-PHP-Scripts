<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
require_once('./auth.php');
$page_title=$l_syssettings;
require_once('./heading.php');
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if(isset($mode))
{
	if(isset($admdoautosub))
		$admddautosub=1;
	else
		$admddautosub=0;
	if(isset($delconfirm))
		$admdelconfirm=1;
	else
		$admdelconfirm=0;
	if(isset($thankyoumail))
		$sendpostingmail=1;
	else
		$sendpostingmail=0;
	if(isset($noleacher))
		$blockleacher=1;
	else
		$blockleacher=0;
	if(isset($noposting))
		$disableposting=1;
	else
		$disableposting=0;
	if(isset($oldblock))
		$blockoldbrowser=1;
	else
		$blockoldbrowser=0;
	if(isset($dellink))
		$enabledel=1;
	else
		$enabledel=0;
	if(isset($modcomlink))
		$enablemodcom=1;
	else
		$enablemodcom=0;
	if(isset($allowquote))
		$enablequote=1;
	else
		$enablequote=0;
	if(isset($directedit))
		$directeditlink=1;
	else
		$directeditlink=0;
	if(isset($sitehomelink))
		$linksitehome=1;
	else
		$linksitehome=0;
	if(isset($linkadmmenu))
		$admmenulink=1;
	else
		$admmenulink=0;
	if(isset($periodtrim))
		$trimperiods=1;
	else
		$trimperiods=0;
	if(isset($enableadmmail))
		$allowadmmail=1;
	else
		$allowadmmail=0;
	$emailfeatures=0;
	if(isset($imailhtml))
		$emailfeatures=setbit($emailfeatures,BIT_1);
	if(isset($imailbbcode))
		$emailfeatures=setbit($emailfeatures,BIT_2);
	if(isset($imailsmilies))
		$emailfeatures=setbit($emailfeatures,BIT_3);
	if(isset($imailembgfx))
		$emailfeatures=setbit($emailfeatures,BIT_4);
	if(isset($imailhtmlcode))
		$emailfeatures=setbit($emailfeatures,BIT_5);
	if(isset($internalmailer))
		$allowinternalmailer=1;
	else
		$allowinternalmailer=0;
	if(isset($realip))
		$tryrealip=1;
	else
		$tryrealip=0;
	if(isset($usesearch))
		$enablesearch=1;
	else
		$enablesearch=0;
	$allowedbbcodes=0;
	if(isset($bb_enable_bold))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_1);
	if(isset($bb_enable_italic))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_2);
	if(isset($bb_enable_stroke))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_3);
	if(isset($bb_enable_typewriter))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_4);
	if(isset($bb_enable_subscript))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_5);
	if(isset($bb_enable_center))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_6);
	if(isset($bb_enable_images))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_7);
	if(isset($bb_enable_code))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_8);
	if(isset($bb_enable_quote))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_9);
	if(isset($bb_enable_lists))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_10);
	if(isset($bb_enable_fontsize))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_11);
	if(isset($bb_enable_color))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_12);
	if(isset($bb_enable_email))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_13);
	if(isset($bb_enable_url))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_14);
	if(isset($bb_enable_real))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_15);
	if(isset($bb_enable_swf))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_16);
	if(isset($bb_enable_font))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_17);
	if(isset($bb_enable_align))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_18);
	if(isset($bb_enable_updown))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_19);
	if(isset($bb_enable_scroll))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_20);
	if(isset($bb_enable_fade))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_21);
	if(isset($bb_enable_flip))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_22);
	if(isset($bb_enable_glow))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_23);
	if(isset($bb_enable_shadow))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_24);
	if(isset($bb_enable_blur))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_25);
	if(isset($bb_enable_dropshadow))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_26);
	if(isset($bb_enable_wmv))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_27);
	if(isset($bb_enable_rainbow))
		$allowedbbcodes=setbit($allowedbbcodes,BIT_28);
	if($allowedbbcodes!=0)
	{
		if(isset($allowbbcode))
			$enablebbcode=1;
		else
			$enablebbcode=0;
	}
	else
		$enablebbcode=0;
	if($minmsglength>$maxmsglength)
		$minmsglength=$maxmsglength;
	if(isset($enableprivate))
		$allowprivateposts=1;
	else
		$allowprivateposts=0;
	if(isset($dovalidation))
		$validateposts=1;
	else
		$validateposts=0;
	if(isset($newnotify))
		$newentrynotify=1;
	else
		$newentrynotify=0;
	if(isset($allowavatarupload) && $upload_avail)
		$enableavatarupload=1;
	else
		$enableavatarupload=0;
	if(isset($docensoring))
		$enablebadwordlist=1;
	else
		$enablebadwordlist=0;
	if(isset($enablehtmlcode))
		$allowhtml=1;
	else
		$allowhtml=0;
	if(isset($seplang))
		$separatebylang=1;
	else
		$separatebylang=0;
	if(isset($allowemoticons))
		$enableemoticons=1;
	else
		$enableemoticons=0;
	if(isset($dowatchlogins))
		$watchlogins=1;
	else
		$watchlogins=0;
	if(isset($enablemenubar))
		$usemenubar=1;
	else
		$usemenubar=0;
	if(isset($enablefreemailer))
		$nofreemailer=0;
	else
		$nofreemailer=1;
	if(isset($dofailednotify))
		$enablefailednotify=1;
	else
		$enablefailednotify=0;
	if(isset($allowhostresolve))
		$enablehostresolve=1;
	else
		$enablehostresolve=0;
	if(isset($autocloseemoticons))
		$emoticonautoclose=1;
	else
		$emoticonautoclose=0;
	if($settingsnew==1)
	{
		$sql = "insert into ".$tableprefix."_settings (watchlogins, usemenubar, nofreemailer, enablefailednotify, loginlimit, simpgbmail, enablehostresolve, enablebbcode, ";
		$sql.= "enableemoticons, emoticonautoclose, sortingmethod, separatebylang, allowhtml, enablebadwordlist, userbanlist, floodprotectdelay, maxwordlength, enableavatarupload, ";
		$sql.= "newentrynotify, validateposts, minmsglength, allowprivateposts, maxmsglength, allowedbbcodes, redirectdelay, enablesearch, useronlinetime, tryrealip, minfontsize, ";
		$sql.= "maxfontsize, allowinternalmailer, maxmaillength, emailfeatures, allowadmmail, trimperiods, trimperiodlength, admmenulink, linksitehome, sitehome, simpgbmailname, ";
		$sql.= "directeditlink, enablequote, enablemodcom, enabledel, blockoldbrowser, servertimezone, displaytimezone, disableposting, blockleacher, sendpostingmail, lastvisitdays, ";
		$sql.= "lastvisitsessiontime, lastvisitdefhours, admdelconfirm, msendlimit, admddautosub, realipmode) ";
		$sql.= "values ($watchlogins, $usemenubar, $nofreemailer, $enablefailednotify, $new_loginlimit, '$simpgbmail', $enablehostresolve, $enablebbcode, ";
		$sql.= "$enableemoticons, $emoticonautoclose, $sortingmethod, $separatebylang, $allowhtml, $enablebadwordlist, $userbanlist, $floodprotectdelay, $maxwordlength, $enableavatarupload, ";
		$sql.= "$newentrynotify, $validateposts, $minmsglength, $allowprivateposts, $maxmsglength, $allowedbbcodes, $redirectdelay, $enablesearch, $useronlinetime, $tryrealip, '$minfontsize', ";
		$sql.= "'$maxfontsize', $allowinternalmailer, $maxmaillength, $emailfeatures, $allowadmmail, $trimperiod, $trimperiodlength, $admmenulink, $linksitehome, '$sitehome', '$simpgbmailname', ";
		$sql.= "$directeditlink, $enablequote, $enablemodcom, $enabledel, $blockoldbrowser, $input_servertimezone, $input_displaytimezone, $disableposting, $blockleacher, $sendpostingmail, ";
		$sql.= "$lastvisitdays, $lastvisitsessiontime, $lastvisitdefhours, $admdelconfirm, $input_msendlimit, $admddautosub, $new_realipmode)";
	}
	else
	{
		$sql = "update ".$tableprefix."_settings set watchlogins=$watchlogins, usemenubar=$usemenubar, nofreemailer=$nofreemailer, enablefailednotify=$enablefailednotify, ";
		$sql.= "loginlimit=$new_loginlimit, simpgbmail='$simpgbmail', enablehostresolve=$enablehostresolve, enablebbcode=$enablebbcode, enableemoticons=$enableemoticons, ";
		$sql.= "emoticonautoclose=$emoticonautoclose, sortingmethod=$sortingmethod, separatebylang=$separatebylang, allowhtml=$allowhtml, enablebadwordlist=$enablebadwordlist, ";
		$sql.= "userbanlist=$userbanlist, floodprotectdelay=$floodprotectdelay, maxwordlength=$maxwordlength, enableavatarupload=$enableavatarupload, newentrynotify=$newentrynotify, ";
		$sql.= "validateposts=$validateposts, minmsglength=$minmsglength, allowprivateposts=$allowprivateposts, maxmsglength=$maxmsglength, allowedbbcodes=$allowedbbcodes, ";
		$sql.= "redirectdelay=$redirectdelay, enablesearch=$enablesearch, useronlinetime=$useronlinetime, tryrealip=$tryrealip, minfontsize='$minfontsize', maxfontsize='$maxfontsize', ";
		$sql.= "allowinternalmailer=$allowinternalmailer, maxmaillength=$maxmaillength, emailfeatures=$emailfeatures, allowadmmail=$allowadmmail, trimperiods=$trimperiods, ";
		$sql.= "trimperiodlength=$trimperiodlength, admmenulink=$admmenulink, linksitehome=$linksitehome, sitehome='$sitehome', simpgbmailname='$simpgbmailname', ";
		$sql.= "directeditlink=$directeditlink, enablequote=$enablequote, enablemodcom=$enablemodcom, enabledel=$enabledel, blockoldbrowser=$blockoldbrowser, ";
		$sql.= "servertimezone=$input_servertimezone, displaytimezone=$input_displaytimezone, disableposting=$disableposting, blockleacher=$blockleacher, sendpostingmail=$sendpostingmail, ";
		$sql.= "lastvisitdays=$lastvisitdays, lastvisitsessiontime=$lastvisitsessiontime, lastvisitdefhours=$lastvisitdefhours, admdelconfirm=$admdelconfirm, msendlimit=$input_msendlimit, ";
		$sql.= "admddautosub=$admddautosub, realipmode=$new_realipmode ";
		$sql.= "where settingnr=1";
	}
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(isset($mailadms))
	{
   		while(list($null, $adm) = each($_POST["mailadms"]))
   		{
			$mod_query = "INSERT INTO ".$tableprefix."_adm_mail (usernr) VALUES ('$adm')";
   		   	if(!mysql_query($mod_query, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	if(isset($rem_mailadms))
	{
		while(list($null, $adm) = each($_POST["rem_mailadms"]))
		{
			$rem_query = "DELETE FROM ".$tableprefix."_adm_mail WHERE usernr = '$adm'";
   			if(!mysql_query($rem_query))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	if(isset($mods))
	{
   		while(list($null, $mod) = each($_POST["mods"]))
   		{
			$mod_query = "INSERT INTO ".$tableprefix."_failed_notify (usernr) VALUES ('$mod')";
   		   	if(!mysql_query($mod_query, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	if(isset($rem_mods))
	{
		while(list($null, $mod) = each($_POST["rem_mods"]))
		{
			$rem_query = "DELETE FROM ".$tableprefix."_failed_notify WHERE usernr = '$mod'";
   			if(!mysql_query($rem_query))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	if(isset($nots))
	{
   		while(list($null, $mod) = each($_POST["nots"]))
   		{
			$mod_query = "INSERT INTO ".$tableprefix."_notify (usernr) VALUES ('$mod')";
   		   	if(!mysql_query($mod_query, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	if(isset($rem_nots))
	{
		while(list($null, $mod) = each($_POST["rem_nots"]))
		{
			$rem_query = "DELETE FROM ".$tableprefix."_notify WHERE usernr = '$mod'";
   			if(!mysql_query($rem_query))
			    die("<tr class=\"errorrow\"><td>Unable to update the database.");
		}
	}
	echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"2\">";
	echo $l_settingsupdated;
	echo "</td></tr>";
}
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
{
	$settingsnew=1;
	$watchlogins=0;
	$enablefailednotify=0;
	$simpgbmail="simpgb@localhost";
	$old_loginlimit=0;
	$usemenubar=0;
	$nofreemailer=0;
	$enablehostresolve=0;
	$enablebbcode=1;
	$enableemoticons=1;
	$emoticonautoclose=1;
	$sortingmethod=0;
	$separatebylang=0;
	$allowhtml=0;
	$enablebadwordlist=1;
	$userbanlist=1;
	$floodprotectdelay=60;
	$maxwordlength=20;
	$enableavatarupload=0;
	$newentrynotify=0;
	$validateposts=0;
	$minmsglength=10;
	$allowprivateposts=0;
	$maxmsglength=500;
	$allowedbbcodes=16383;
	$redirectdelay=5;
	$enablesearch=0;
	$useronlinetime=300;
	$tryrealip=0;
	$minfontsize=-5;
	$maxfontsize=5;
	$allowinternalmailer=0;
	$maxmaillength=300;
	$emailfeatures=31;
	$allowadmmail=1;
	$trimperiods=1;
	$trimperiodlength=6;
	$admmenulink=1;
	$linksitehome=1;
	$sitehome="http://";
	$simpgbmailname="SimpGB";
	$directeditlink=0;
	$enablequote=1;
	$enablemodcom=0;
	$enabledel=0;
	$blockoldbrowser=1;
	$act_servertimezone=0;
	$act_displaytimezone=0;
	$disableposting=0;
	$blockleacher=0;
	$sendpostingmail=0;
	$lastvisitdays=365;
	$lastvisitsessiontime=60;
	$lastvisitdefhours=24;
	$admdelconfirm=0;
	$msendlimit=30;
	$admddautosub=0;
	$realipmode=0;
}
else
{
	$settingsnew=0;
	$watchlogins=$myrow["watchlogins"];
	$enablefailednotify=$myrow["enablefailednotify"];
	$simpgbmail=$myrow["simpgbmail"];
	$old_loginlimit=$myrow["loginlimit"];
	$usemenubar=$myrow["usemenubar"];
	$nofreemailer=$myrow["nofreemailer"];
	$enablehostresolve=$myrow["enablehostresolve"];
	$enablebbcode=$myrow["enablebbcode"];
	$enableemoticons=$myrow["enableemoticons"];
	$emoticonautoclose=$myrow["emoticonautoclose"];
	$sortingmethod=$myrow["sortingmethod"];
	$separatebylang=$myrow["separatebylang"];
	$allowhtml=$myrow["allowhtml"];
	$enablebadwordlist=$myrow["enablebadwordlist"];
	$userbanlist=$myrow["userbanlist"];
	$floodprotectdelay=$myrow["floodprotectdelay"];
	$maxwordlength=$myrow["maxwordlength"];
	$enableavatarupload=$myrow["enableavatarupload"];
	if(!$upload_avail)
		$enableavatarupload=0;
	$newentrynotify=$myrow["newentrynotify"];
	$validateposts=$myrow["validateposts"];
	$minmsglength=$myrow["minmsglength"];
	$allowprivateposts=$myrow["allowprivateposts"];
	$maxmsglength=$myrow["maxmsglength"];
	$allowedbbcodes=$myrow["allowedbbcodes"];
	$redirectdelay=$myrow["redirectdelay"];
	$enablesearch=$myrow["enablesearch"];
	$useronlinetime=$myrow["useronlinetime"];
	$tryrealip=$myrow["tryrealip"];
	$minfontsize=$myrow["minfontsize"];
	$maxfontsize=$myrow["maxfontsize"];
	$allowinternalmailer=$myrow["allowinternalmailer"];
	$maxmaillength=$myrow["maxmaillength"];
	$emailfeatures=$myrow["emailfeatures"];
	$allowadmmail=$myrow["allowadmmail"];
	$trimperiods=$myrow["trimperiods"];
	$trimperiodlength=$myrow["trimperiodlength"];
	$admmenulink=$myrow["admmenulink"];
	$linksitehome=$myrow["linksitehome"];
	$sitehome=$myrow["sitehome"];
	$simpgbmailname=$myrow["simpgbmailname"];
	$directeditlink=$myrow["directeditlink"];
	$enablequote=$myrow["enablequote"];
	$enablemodcom=$myrow["enablemodcom"];
	$enabledel=$myrow["enabledel"];
	$blockoldbrowser=$myrow["blockoldbrowser"];
	$act_servertimezone=$myrow["servertimezone"];
	$act_displaytimezone=$myrow["displaytimezone"];
	$disableposting=$myrow["disableposting"];
	$blockleacher=$myrow["blockleacher"];
	$sendpostingmail=$myrow["sendpostingmail"];
	$lastvisitdays=$myrow["lastvisitdays"];
	$lastvisitsessiontime=$myrow["lastvisitsessiontime"];
	$lastvisitdefhours=$myrow["lastvisitdefhours"];
	$admdelconfirm=$myrow["admdelconfirm"];
	$msendlimit=$myrow["msendlimit"];
	$admddautosub=$myrow["admddautosub"];
	$realipmode=$myrow["realipmode"];
}
?>
<form name="myform" method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="submit">
<input type="hidden" name="settingsnew" value="<?php echo $settingsnew?>">
<?php
if(is_konqueror())
		echo "<tr><td></td></tr>";
?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_userinterface?></b></td>
<tr class="inputrow"><td></td><td><input type="checkbox" name="noposting" value="1" <?php if($disableposting==1) echo "checked"?>> <?php echo $l_disableposting?></td></tr>
<tr class="inputrow"><td></td><td><input type="checkbox" name="oldblock" value="1" <?php if($blockoldbrowser==1) echo "checked"?>> <?php echo $l_blockoldbrowser?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_maxwordlength?>:</td>
<td><input type="text" class="sgbinput" name="maxwordlength" size="5" maxlength="3" value="<?php echo $maxwordlength?>"> <?php echo $l_chars?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_minmsglength?>:</td>
<td><input type="text" class="sgbinput" name="minmsglength" size="5" maxlength="5" value="<?php echo $minmsglength?>"> <?php echo $l_chars?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_maxmsglength?>:</td>
<td><input type="text" class="sgbinput" name="maxmsglength" size="5" maxlength="5" value="<?php echo $maxmsglength?>"> <?php echo $l_chars?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_maxmaillength?>:</td>
<td><input type="text" class="sgbinput" name="maxmaillength" size="5" maxlength="5" value="<?php echo $maxmaillength?>"> <?php echo $l_chars?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_floodprotection?>:</td>
<td><?php echo $l_delaytime?>: <input class="sgbinput" type="text" name="floodprotectdelay" size="4" maxlength="4" value="<?php echo $floodprotectdelay?>"> <?php echo $l_seconds?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_redirectdelay?>:</td>
<td><input class="sgbinput" type="text" name="redirectdelay" value="<?php echo $redirectdelay?>" size="2" maxlength="2"> <?php echo $l_seconds?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_useronlinetime?>:</td>
<td><input class="sgbinput" type="text" name="useronlinetime" size="4" maxlength="4" value="<?php echo $useronlinetime?>"> <?php echo $l_seconds?></td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_userbanlist?>:</td>
<td align="left">
<input type="radio" name="userbanlist" value="0" <?php if($userbanlist==0) echo "checked"?>> <?php echo $l_disable?><br>
<input type="radio" name="userbanlist" value="1" <?php if($userbanlist==1) echo "checked"?>> <?php echo $l_noposting?><br>
<input type="radio" name="userbanlist" value="2" <?php if($userbanlist==2) echo "checked"?>> <?php echo $l_noviewing?><br>
</td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enablehtmlcode" value="1" <?php if($allowhtml==1) echo "checked"?>> <?php echo $l_allowhtml?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="docensoring" value="1" <?php if($enablebadwordlist==1) echo "checked"?>> <?php echo $l_enablebadwordlist?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="dovalidation" value="1" <?php if($validateposts==1) echo "checked"?>> <?php echo $l_validateposts?></td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_sortingmethod?>:</td><td>
<?php
for($i=0;$i<count($l_sortingmethods);$i++)
{
	echo "<input type=\"radio\" name=\"sortingmethod\" value=\"$i\"";
	if($i==$sortingmethod)
		echo " checked";
	echo "> ".$l_sortingmethods[$i]."<br>";
}
?>
</td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="seplang" value="1" <?php if($separatebylang==1) echo "checked"?>> <?php echo $l_separatebylang?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="allowemoticons" value="1" <?php if($enableemoticons==1) echo "checked"?>> <?php echo $l_enableemoticons?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="autocloseemoticons" value="1" <?php if($emoticonautoclose==1) echo "checked"?>> <?php echo $l_emoticonautoclose?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="allowavatarupload" value="1" <?php if($enableavatarupload==1) echo "checked"?> <?php if(!$upload_avail) echo "disabled"?>> <?php echo $l_enableavatarupload?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enableprivate" value="1" <?php if($allowprivateposts==1) echo "checked"?>> <?php echo $l_allowprivateposts?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="usesearch" value="1" <?php if($enablesearch==1) echo "checked"?>> <?php echo $l_enablesearch?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="periodtrim" value="1" <?php if($trimperiods==1) echo "checked"?>> <?php echo $l_trimperiods?><br>
<?php echo $l_periodlength?>: <input class="sgbinput" type="text" name="trimperiodlength" value="<?php echo $trimperiodlength?>" size="3" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="linkadmmenu" value="1" <?php if($admmenulink==1) echo "checked"?>> <?php echo $l_admmenulink?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="sitehomelink" value="1" <?php if($linksitehome==1) echo "checked"?>> <?php echo $l_linksitehome?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_sitehome?>:</td>
<td align="left"><input type="text" name="sitehome" class="sgbinput" size="40" maxlength="240" value="<?php echo $sitehome?>"></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="allowquote" value="1" <?php if($enablequote==1) echo "checked"?>> <?php echo $l_enablequote?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="thankyoumail" value="1" <?php if($sendpostingmail==1) echo "checked"?>> <?php echo $l_sendpostingmail?></td></tr>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_adminfunctions?></b></td>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="directedit" value="1" <?php if($directeditlink==1) echo "checked"?>> <?php echo $l_directeditlink?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="dellink" value="1" <?php if($enabledel==1) echo "checked"?>> <?php echo $l_enabledel?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="modcomlink" value="1" <?php if($enablemodcom==1) echo "checked"?>> <?php echo $l_enablemodcom?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_internalmailer?></b></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="internalmailer" value="1" <?php if($allowinternalmailer==1) echo "checked"?>> <?php echo $l_allowinternalmailer?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="imailhtml" value="1" <?php if(bittst($emailfeatures,BIT_1)) echo "checked"?>> <?php echo $l_imailhtml?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="imailbbcode" value="1" <?php if(bittst($emailfeatures,BIT_2)) echo "checked"?>> <?php echo $l_imailbbcode?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="imailsmilies" value="1" <?php if(bittst($emailfeatures,BIT_3)) echo "checked"?>> <?php echo $l_imailsmilies?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="imailembgfx" value="1" <?php if(bittst($emailfeatures,BIT_4)) echo "checked"?>> <?php echo $l_imailembgfx?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="imailhtmlcode" value="1" <?php if(bittst($emailfeatures,BIT_5)) echo "checked"?>> <?php echo $l_imailhtmlcode?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_bbcode?></b></td>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="allowbbcode" value="1" <?php if($enablebbcode==1) echo "checked"?>> <?php echo $l_enablebbcode?></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_minfontsize?>:</td>
<td><input class="sgbinput" type="text" name="minfontsize" value="<?php echo $minfontsize?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_maxfontsize?>:</td>
<td><input class="sgbinput" type="text" name="maxfontsize" value="<?php echo $maxfontsize?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_allowedbbcodes?>:</td><td>
<input type="checkbox" name="bb_enable_bold" value="1" <?php if(bittst($allowedbbcodes,BIT_1)) echo "checked"?>><?php echo $l_bb_bold?><br>
<input type="checkbox" name="bb_enable_italic" value="1" <?php if(bittst($allowedbbcodes,BIT_2)) echo "checked"?>><?php echo $l_bb_italic?><br>
<input type="checkbox" name="bb_enable_stroke" value="1" <?php if(bittst($allowedbbcodes,BIT_3)) echo "checked"?>><?php echo $l_bb_stroke?><br>
<input type="checkbox" name="bb_enable_typewriter" value="1" <?php if(bittst($allowedbbcodes,BIT_4)) echo "checked"?>><?php echo $l_bb_typewriter?><br>
<input type="checkbox" name="bb_enable_subscript" value="1" <?php if(bittst($allowedbbcodes,BIT_5)) echo "checked"?>><?php echo $l_bb_subscript?><br>
<input type="checkbox" name="bb_enable_center" value="1" <?php if(bittst($allowedbbcodes,BIT_6)) echo "checked"?>><?php echo $l_bb_center?><br>
<input type="checkbox" name="bb_enable_images" value="1" <?php if(bittst($allowedbbcodes,BIT_7)) echo "checked"?>><?php echo $l_bb_images?><br>
<input type="checkbox" name="bb_enable_code" value="1" <?php if(bittst($allowedbbcodes,BIT_8)) echo "checked"?>><?php echo $l_bb_code?><br>
<input type="checkbox" name="bb_enable_quote" value="1" <?php if(bittst($allowedbbcodes,BIT_9)) echo "checked"?>><?php echo $l_bb_quote?><br>
<input type="checkbox" name="bb_enable_lists" value="1" <?php if(bittst($allowedbbcodes,BIT_10)) echo "checked"?>><?php echo $l_bb_lists?><br>
<input type="checkbox" name="bb_enable_fontsize" value="1" <?php if(bittst($allowedbbcodes,BIT_11)) echo "checked"?>><?php echo $l_bb_fontsize?><br>
<input type="checkbox" name="bb_enable_color" value="1" <?php if(bittst($allowedbbcodes,BIT_12)) echo "checked"?>><?php echo $l_bb_colortext?><br>
<input type="checkbox" name="bb_enable_email" value="1" <?php if(bittst($allowedbbcodes,BIT_13)) echo "checked"?>><?php echo $l_bb_email?><br>
<input type="checkbox" name="bb_enable_url" value="1" <?php if(bittst($allowedbbcodes,BIT_14)) echo "checked"?>><?php echo $l_bb_url?><br>
<input type="checkbox" name="bb_enable_real" value="1" <?php if(bittst($allowedbbcodes,BIT_15)) echo "checked"?>><?php echo $l_bb_real?><br>
<input type="checkbox" name="bb_enable_swf" value="1" <?php if(bittst($allowedbbcodes,BIT_16)) echo "checked"?>><?php echo $l_bb_swf?><br>
<input type="checkbox" name="bb_enable_font" value="1" <?php if(bittst($allowedbbcodes,BIT_17)) echo "checked"?>><?php echo $l_bb_font?><br>
<input type="checkbox" name="bb_enable_align" value="1" <?php if(bittst($allowedbbcodes,BIT_18)) echo "checked"?>><?php echo $l_bb_align?><br>
<input type="checkbox" name="bb_enable_updown" value="1" <?php if(bittst($allowedbbcodes,BIT_19)) echo "checked"?>><?php echo $l_bb_updown?><br>
<input type="checkbox" name="bb_enable_scroll" value="1" <?php if(bittst($allowedbbcodes,BIT_20)) echo "checked"?>><?php echo $l_bb_scroll?><br>
<input type="checkbox" name="bb_enable_fade" value="1" <?php if(bittst($allowedbbcodes,BIT_21)) echo "checked"?>><?php echo $l_bb_fade?><br>
<input type="checkbox" name="bb_enable_flip" value="1" <?php if(bittst($allowedbbcodes,BIT_22)) echo "checked"?>><?php echo $l_bb_flip?><br>
<input type="checkbox" name="bb_enable_glow" value="1" <?php if(bittst($allowedbbcodes,BIT_23)) echo "checked"?>><?php echo $l_bb_glow?><br>
<input type="checkbox" name="bb_enable_shadow" value="1" <?php if(bittst($allowedbbcodes,BIT_24)) echo "checked"?>><?php echo $l_bb_shadow?><br>
<input type="checkbox" name="bb_enable_blur" value="1" <?php if(bittst($allowedbbcodes,BIT_25)) echo "checked"?>><?php echo $l_bb_blur?><br>
<input type="checkbox" name="bb_enable_dropshadow" value="1" <?php if(bittst($allowedbbcodes,BIT_26)) echo "checked"?>><?php echo $l_bb_dropshadow?><br>
<input type="checkbox" name="bb_enable_wmv" value="1" <?php if(bittst($allowedbbcodes,BIT_27)) echo "checked"?>><?php echo $l_bb_wmv?><br>
<input type="checkbox" name="bb_enable_rainbow" value="1" <?php if(bittst($allowedbbcodes,BIT_28)) echo "checked"?>><?php echo $l_bb_rainbow?><br>
</td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_admmail?></b></td>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enableadmmail" value="1" <?php if($allowadmmail==1) echo "checked"?>> <?php echo $l_enable?></td></tr>
<tr class="inputrow"><td align="right" width="30%" valign="top"><?php echo $l_admmailadmins?>:</td>
<td align="left" valign="top">
<?php
	$sql = "SELECT * FROM ".$tableprefix."_adm_mail mail, ".$tableprefix."_users u where u.usernr=mail.usernr order by u.username";
	if(!$r = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if ($row = mysql_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_mailadms[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_mailadms[] = $row["usernr"];
		 } while($row = mysql_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_users WHERE rights > 2 and length(email)>0 ";
	if(isset($current_mailadms))
	{
    	while(list($null, $currAdm) = each($current_mailadms)) {
			$sql .= "AND usernr != $currAdm ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = mysql_query($sql, $db))
		die("Could not connect to the database.");
    if($row = mysql_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"mailadms[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = mysql_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_lvisitcookie?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_cookieexpiretime?>:</td>
<td><input type="text" name="lastvisitdays" value="<?php echo $lastvisitdays?>" size="4" maxlength="10" class="sgbinput"> <?php echo $l_days?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_cookiesessiontime?>:</td>
<td><input type="text" name="lastvisitsessiontime" value="<?php echo $lastvisitsessiontime?>" size="4" maxlength="10" class="sgbinput"> <?php echo $l_minutes?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_lastvisitdefhours?>:</td>
<td><input type="text" name="lastvisitdefhours" value="<?php echo $lastvisitdefhours?>" size="4" maxlength="10" class="sgbinput"> <?php echo $l_hours?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_admininterface?></b></td>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="admdoautosub" value="1" <?php if($admddautosub==1) echo "checked"?>> <?php echo $l_ddautosub?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="delconfirm" value="1" <?php if($admdelconfirm==1) echo "checked"?>> <?php echo $l_confirmdelentries?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="dowatchlogins" value="1" <?php if($watchlogins==1) echo "checked"?>> <?php echo $l_watchlogins?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enablemenubar" value="1" <?php if($usemenubar==1) echo "checked"?>> <?php echo $l_usemenubar?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input name="allowhostresolve" value="1" type="checkbox"
<?php if($enablehostresolve==1) echo " checked"?>> <?php echo $l_enablehostresolve?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enablefreemailer" value="1" <?php if($nofreemailer==0) echo "checked"?>> <?php echo $l_enablefreemailer?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_loginlimit?>:</td>
<td align="left"><input class="sgbinput" type="text" name="new_loginlimit" value="<?php echo $old_loginlimit?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_failednotify?>:<br><input name="dofailednotify" value="1" type="checkbox"
<?php if($enablefailednotify==1) echo " checked"?>><?php echo $l_enable?></td>
<td align="left" valign="top">
<?php
	$sql = "SELECT * FROM ".$tableprefix."_failed_notify fn, ".$tableprefix."_users u where u.usernr=fn.usernr order by u.username";
	if(!$r = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if ($row = mysql_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_mods[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_mods[] = $row["usernr"];
		 } while($row = mysql_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_users WHERE rights > 2 ";
	if(isset($current_mods))
	{
    	while(list($null, $currMod) = each($current_mods)) {
			$sql .= "AND usernr != $currMod ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = mysql_query($sql, $db))
		die("Could not connect to the database.");
    if($row = mysql_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"mods[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = mysql_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_general?></b></td>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td><input type="checkbox" name="realip" value="1" <?php if($tryrealip==1) echo "checked"?>><?php echo $l_tryrealip?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_realipmode?>:</td><td valign="top">
<input type="radio" name="new_realipmode" value="0" <?php if($realipmode==0) echo "checked"?>> <?php echo $l_defmode?><br>
<input type="radio" name="new_realipmode" value="1" <?php if($realipmode==1) echo "checked"?>> <?php echo $l_alternatemode?>
</td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td><input type="checkbox" name="noleacher" value="1" <?php if($blockleacher==1) echo "checked"?>><?php echo $l_blockleacher?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_simpgbmail?>:</td>
<td align="left"><input class="sgbinput" type="text" name="simpgbmail" value="<?php echo $simpgbmail?>" size="40" maxlength="180"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_simpgbmailname?>:</td>
<td align="left"><input class="sgbinput" type="text" name="simpgbmailname" value="<?php echo $simpgbmailname?>" size="40" maxlength="180"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_servertimezone?>:</td>
<td>
<?php echo tz_select($act_servertimezone,"input_servertimezone")?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_displaytimezone?>:</td>
<td>
<?php echo tz_select($act_displaytimezone,"input_displaytimezone")?>
</td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_newentrynotify?>:<br><input name="newnotify" value="1" type="checkbox"
<?php if($newentrynotify==1) echo " checked"?>><?php echo $l_enable?></td>
<td align="left" valign="top">
<?php
	$sql = "SELECT u.* FROM ".$tableprefix."_notify n, ".$tableprefix."_users u where u.usernr=n.usernr order by u.username";
	if(!$r = mysql_query($sql, $db))
	    die("Could not connect to the database.".mysql_error());
	if ($row = mysql_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_nots[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_nots[] = $row["usernr"];
		 } while($row = mysql_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_users WHERE rights > 1 ";
	if(isset($current_nots))
	{
    	while(list($null, $currMod) = each($current_nots)) {
			$sql .= "AND usernr != $currMod ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = mysql_query($sql, $db))
		die("Could not connect to the database.");
    if($row = mysql_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"nots[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = mysql_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_msendlimit?>:</td><td align="left">
<input class="sgbinput" name="input_msendlimit" value="<?php echo $msendlimit?>" size="4" maxlength="10" type="text"> <?php echo $l_seconds?><br>
<?php echo $l_msendlimit_remark?></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="sgbbutton" type="submit" value="<?php echo $l_submit?>"></td></tr>
</form>
</table></td></tr></table>
<?php
include('./trailer.php');
?>
