<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_name = "Name";
$l_email = "E-Mailadresse";
$l_noname = "Sie m&uuml;ssen einen Namen eingeben";
$l_notext = "Sie m&uuml;ssen einen Text eingeben";
$l_back = "zur&uuml;ck";
$l_add = "hinzuf&uuml;gen";
$l_addentry = "Eintrag hinzuf&uuml;gen";
$l_heading = "&Uuml;berschrift";
$l_text = "Text";
$l_bbcodehelp = "BBCode Hilfe";
$l_disableautourl = "automatische Umwandlung von URLs ausschalten";
$l_disablebbcode = "BBCode ausschalten";
$l_disableemoticons = "Smilies deaktivieren";
$l_on = "am";
$l_timeonserver = "aktuelle Uhrzeit am Server";
$l_emoticonlist = "Liste der Smilies";
$l_close = "schliessen";
$l_noneavailable = "Keine verf&uuml;gbar";
$l_code = "Code";
$l_emotion = "Emotion";
$l_page = "Seite";
$l_poster = "Verfasser";
$l_homepage = "Homepage";
$l_visithomepage = "Homepage besuchen";
$l_sendemail = "E-Mail schicken";
$l_sendicqmsg = "ICQ-Nachricht schicken";
$l_country = "Land";
$l_noentries = "keine Eintr&auml;ge";
$l_modcomment = "Kommentar eines Moderators";
$l_pleaseselect = "--- bitte ausw&auml;hlen ---";
$l_icqnumber = "ICQ-Nummer";
$l_ipbanned = "Von dieser IP-Adresse aus darf diese Funktion nicht benutzt werden.";
$l_reason = "Grund";
$l_floodmsg1 = "Der Administrator hat festgelegt, dass Sie nur alle";
$l_floodmsg2 = "Sekunden einen Eintrag vornehmen k&ouml;nnen";
$l_gotop = "zum Seitenanfang";
$l_male = "m&auml;nnlich";
$l_female = "weiblich";
$l_nohomepage = "Sie m&uuml;ssen eine URL f&uuml;r die Homepage eingeben";
$l_gender = "Geschlecht";
$l_invalidtext = "Der Text enth&auml;lt zu lange Worte (max.";
$l_charsperword = "Zeichen pro Wort)";
$l_aim = "AIM";
$l_requiredmarked = "Pflichtfelder sind farblich gekennzeichnet";
$l_nogender = "Sie m&uuml;ssen ein Geschlecht w&auml;hlen";
$l_noemail = "Sie m&uuml;ssen eine E-Mailadresse eingeben";
$l_nocountry = "Sie m&uuml;ssen ein Land ausw&auml;hlen";
$l_noicq = "Sie m&uuml;ssen eine ICQ-Nummer eingeben";
$l_noaim = "Sie m&uuml;ssen eine AIM-Adresse angeben";
$l_noheading = "Sie m&uuml;ssen eine &Uuml;berschrift eingeben";
$l_altaim = "AOL Instant Messenger";
$l_novalidemail = "Bitte geben Sie eine g&uuml;ltige E-Mailadresse ein";
$l_novalidicq = "Bitte geben Sie eine g&uuml;ltige ICQ-Nummer an";
$l_novalidhomepage = "Bitte geben Sie eine g&uuml;ltige URL f&uuml;r die Hompage an";
$l_preview = "Vorschau";
$l_previewprelude = "Ihr Eintrage w&uuml;rde so aussehen:";
$l_usersonline = "Gerade im G&auml;stebuch unterwegs";
$l_user = "Benutzer";
$l_avatar = "Avatar";
$l_uploadown = "eigener Upload";
$l_avatarlist = "Liste der Avatars";
$l_noavatar = "Sie m&uuml;ssen ein Avatar ausw&auml;hlen";
$l_description = "Bezeichnung";
$l_msnm = "MSN-Messenger";
$l_yim = "Yahoo Instant Messenger";
$l_nomsnm = "Sie m&uuml;ssen eine MSN-Messenger-Adresse angeben";
$l_noyim = "Sie m&uuml;ssen eine Yahoo Instant Messenger-Adresse angeben";
$l_yimlabel = "Yahoo Instant Messenger";
$l_entryadded = "Eintrag hinzugef&uuml;gt<br>Sie werden nun zum G&auml;stebuch weitergeleitet.";
$l_gotoguestbook = "zum G&auml;stebuch";
$l_totalentries = "Gesamtzahl Eintr&auml;ge";
$l_entries = "Eintr&auml;ge";
$l_of = "von";
$l_language = "Sprache";
$l_ok = "OK";
$l_layout = "Layout";
$l_validatenote = "Der Administrator hat festgelegt, dass neue Eintr&auml;ge<br>vor der Ver&ouml;ffentlichung erst gepr&uuml;ft werden m&uuml;ssen.";
$l_age = "Alter";
$l_location = "Wohnort";
$l_noage = "Sie m&uuml;ssen ein Alter angeben";
$l_nolocation = "Sie m&uuml;ssen einen Wohnort angeben";
$l_company = "Firma";
$l_nocompany = "Sie m&uuml;ssen eine Firma angeben";
$l_nofound = "Sie m&uuml;ssen angeben, wie Sie uns gefunden haben";
$l_msgtooshort = "Ihre Nachricht ist zu kurz (mind.";
$l_chars = "Zeichen";
$l_found = "Wie haben Sie uns gefunden";
$l_privatepost = "privat (kann nur von Administratoren gesehen werden)";
$l_msgtoolong = "Ihre Nachricht ist zu lang (max.";
$l_min = "mind.";
$l_max = "max.";
$l_allowedbbcodes = "zugelassene BBCode-Tags";
$l_more = "mehr";
$l_bbcode_labels = array("fett","kursiv","durchgestrichen","Schreibmaschinenschrift","tiefstellen","hochstellen","zentrieren","Bild","Code","Zitat","Listenanfang","Listenelement","Listenende","Schriftgr&ouml;sse","Textfarbe","E-Mail","URL","Realaudio","SWF","Zeichensatz","vertikaler Scroller","horizontaler Scroller", "fading Text", "vertikal spiegeln", "horizontal spiegeln", "Gl&uuml;hen", "Schatten", "verwischter Text", "Schlagschatten", "Windowsmedia","Regenbogentext");
$l_page_forward = "n&auml;chste Seite";
$l_page_back = "Seite zur&uuml;ck";
$l_page_last = "letzte Seite";
$l_page_first = "erste Seite";
$l_search = "suchen";
$l_searchguestbook = "G&auml;stebuch durchsuchen";
$l_result = "Ergebnis";
$l_attachement = "Anhang herunterladen";
$l_quote = "zitieren";
$l_quotemsg = "Am {postdate} schrieb {poster}:";
$l_totalviews = "Gesamtzahl Hits";
$l_since = "seit dem";
$l_nosearchcriteria = "keine Suchkriterien angegeben";
$l_searchon = "Durchsuchen";
$l_searchentries = "Eintr&auml;ge";
$l_searchcomments = "Kommentare";
$l_searchusernames = "Benutzernamen";
$l_help = "Hilfe";
$l_namenotallowed = "Diesen Benutzernamen k&ouml;nnen Sie nicht verwenden.";
$l_config_writeable ="Die Konfigurationsdatei (config.php) ist nicht schreibgesch&uuml;tzt (PHP kann in die Datei schreiben). Dies ist ein Sicherheitsrisiko.<br>SimpGB startet nicht, bis dies ge&auml;ndert ist.<br>";
$l_guestbook = "G&auml;stebuch";
$l_userpic = "Bild";
$l_nouserpic = "Sie m&uuml;ssen ein Bild angeben";
$l_novaliduserpic = "Bitte geben Sie eine g&uuml;ltige URL f&uuml;r das Bild an";
$l_enterdisplaytext = "Anzuzeigenden Text eingeben";
$l_entercolor = "Gew�nschte Farbe eingeben";
$l_entertextsize = "Gew�nschte Schriftgr�sse eingeben";
$l_enterlinkurl = "URL, mit der verlinkt werden soll";
$l_enterswf = "Anzuzeigende SWF-Datei eingeben";
$l_width = "Breite";
$l_height = "H�he";
$l_enteremail = "E-Mailadresse eingeben";
$l_enterlistitem = "Text f�r Listenelement";
$l_entercode = "Text, der als Codesegment angezeigt werden soll";
$l_enterbold = "Text, der fett dargestellt werden soll";
$l_enterimageurl = "URL des Bildes, das eingef�gt werden soll";
$l_enterrealurl = "URL der Realaudiodatei, die eingef�gt werden soll";
$l_enterquote = "Text, der als Zitat angezeigt werden soll";
$l_enteritalic = "Text, der kursiv dargestellt werden soll";
$l_enterstrikethrough = "Text, der durchgestrichen dargestellt werden soll";
$l_entertypewrite = "Text, der in Schreibmaschinenschrift dargestellt werden soll";
$l_entersuper = "Text, der hochgestellt werden soll";
$l_entersub = "Text, der tiefgestellt werden soll";
$l_entercenter = "Text, der zentriert werden soll";
$l_enterfonttext = "Text, der in diesem Zeichensatz dargestellt werden soll";
$l_enterfont = "Zeichensatz eingeben";
$l_availfonts = array("Andale Mono","Arial","Arial Black","Book Antiqua","Century Gothic","Comic Sans MS","Courier New","Georgia","Impact","Tahoma","Times New Roman","Script MT Bold","Verdana","Lucida Console");
$l_availcolors = array("White","Black","Red","Yellow","Pink","Green","Orange","Purple","Blue","Beige","Brown","Teal","Navy","Maroon","Limegreen");
$l_font = "Schriftart";
$l_fontsize = "Schriftgr&ouml;sse";
$l_fontcolor = "Schriftfarbe";
$l_alignments = array("Left","Right","Center");
$l_alignment = "Ausrichtung";
$l_enteraligntext = "auszurichtender Text";
$l_charsleft = "Zeichen &uuml;brig";
$l_attachfile = "Datei anh&auml;ngen";
$l_toomanychars = "Zu viele Zeichen eingegeben";
$l_filetypenotallowed = "Die Datei ist nicht von einem zul&auml;ssigen Dateityp. Sie k&ouml;nnen nur Dateien von folgenden Typen anh&auml;ngen:";
$l_filetoolarge = "Die Datei ist zu gross";
$l_bytes = "Bytes";
$l_cantattach = "Datei kann nicht angeh&auml;ngt werden";
$l_noattachment = "Sie m&uuml;ssen einen Dateinanhang angeben";
$l_enterupdown = "Text, der vertikal gescrollt werden soll";
$l_enterscroll = "Text, der horizontal gescrollt werden soll";
$l_sendemail = "E-Mail versenden";
$l_sendmailto = "E-Mail versenden an";
$l_callingerror = "Aufruffehler";
$l_yourname = "Ihr Name";
$l_youremail = "Ihre E-Mailadresse";
$l_change = "wechseln";
$l_subject = "Betreff";
$l_defsubj = "Nachricht durch SimpGB ({sitename})";
$l_mnote = "<font size=\"1\">Diese Mail wurde versandt �ber <a href=\"http://www.boesch-it.de\">SimpGB v$version</a> auf <a href=\"{gburl}\">{sitename}</a></font>";
$l_mailsent = "Ihre E-Mail an <i>{receiver}</i> wurde versandt.<br>Sie werden nun zum G&auml;stebuch weitergeleitet.";
$l_enterfade = "Text, der als fading Text dargestellt werden soll";
$l_enterflip = "Text, der gespiegelt werden soll";
$l_entertext = "darzustellenden Text eingeben";
$l_enterwmvurl = "URL der Windowsmediadatei, die eingef�gt werden soll";
$l_dateselformat = array("day","month","year");
$l_day = "Tag";
$l_month = "Monat";
$l_year = "Jahr";
$l_betweendate = "im Zeitrahmen";
$l_startdate = "Anfangsdatum";
$l_enddate = "Enddatum";
$l_admmail = "Mail an Administrator";
$l_admin = "Administrator";
$l_admmenu = "Administrationsmenu";
$l_sitehome = "Homepage";
$l_editmsg = "Eintrag bearbeiten (nur f&uuml;r Admins)";
$l_delentry = "Eintrag l&ouml;schen (nur f&uuml;r Admins)";
$l_comentry = "Kommentar zum Eintrag schreiben (nur f&uuml;r Admins)";
$l_bbccolhelp = "Schriftfarbe: [color=blue]Text[/color]";
$l_bbcode_helps = array(
	"Fettschrift: [b]Text[/b]",
	"Kursivschrift: [i]Text[/i]",
	"durchgestrichener Text: [s]Text[/s]",
	"Schreibmaschinenschrift: [tt]Text[/tt]",
	"tiefstellen: [sub]Text[/sub]",
	"hochstellen: [sup]Text[/sup]",
	"zentrieren: [center]Text[/center]",
	"Bild einf&uuml;gen: [img]http://www.foo.bar/bild.gif[/img]",
	"Code: [code]Text[/code]",
	"Zitat: [quote]Text[/quote]",
	"Listenanfang: [list]",
	"Listenelement: [*]",
	"Listenende: [/list]",
	"Schriftgr&ouml;sse: [size=2]Text[size]",
	"Textfarbe: [color=red]Text[/color]",
	"E-Mail: [email]test@foo.bar[/email]",
	"URL: [url]http://www.foo.bar[/url]",
	"Realaudio: [realaudio]rtsp://www.foo.bar/audio.ram[/realaudio]",
	"SWF: [swf width=12 height=13]http://www.foo.bar/flash.swf[/swf]",
	"Zeichensatz: [font=Arial]Text[/font]",
	"vertikaler Scroller: [updown]Text[/updown]",
	"horizontaler Scroller: [scroll]Text[/scroll]",
	"fading Text: [fade]Text[/fade]",
	"vertikal spiegeln: [flip=v]Text[/flip]",
	"horizontal spiegeln: [flip=h]Text[/flip]",
	"Gl&uuml;hen: [glow=yellow]Text[/glow]",
	"Schatten: [shadow=blue]Text[/shadow]",
	"verwischter Text: [blur]Text[/blur]",
	"Schlagschatten: [dropshadow=yellow]Text[/dropshadow]",
	"Windowsmedia: [stream]http://www.foo,bar/audio.wma[/stream]",
	"Regenbogentext [rainbow=red]Text[/rainbow]",
	"Textausrichtung: [align=right]Text[/align]"
	);
$l_bbc_quote = "Zitat";
$l_bbc_code = "Code";
$l_sortorders = array("nach Datum (absteigend)","nach Datum (aufsteigend)","nach Namen");
$l_sortorder = "Sortierung";
$l_oldbrowser = "Dieses G&auml;stebuch funktioniert nicht mit Internetexplorer Versionen kleiner 4.0 oder Netscape Versionen kleiner 4.0.<br>Bitte benutzen Sie einen neueren Browser.";
$l_ne_subj = "Info from SimpGB";
$l_ne_msg = "Neuer Gaestebucheintrag/new guestbook entry: #%s".$crlf."%s, %s".$crlf.$crlf."--------------------------------".$crlf;
$l_ne_poster = "Verfasser/poster: %s".$crlf;
$l_ne_company = "Firma/company: %s".$crlf;
$l_ne_email = "Email: %s".$crlf;
$l_ne_location = "Wohnort/location: %s".$crlf;
$l_ne_country = "Land/country: %s".$crlf;
$l_ne_homepage = "Homepage: %s".$crlf;
$l_ne_icq = "ICQ: %s".$crlf;
$l_ne_aim = "AIM: %s".$crlf;
$l_ne_msnm = "MSN Messenger: %s".$crlf;
$l_ne_yim = "Yahoo Instant Messenger: %s".$crlf;
$l_ne_found = "Gefunden/found: %s".$crlf;
$l_ne_heading = "�berschrift/heading: %s".$crlf;
$l_ne_entry = "Eintragstext/entry text:".$crlf;
$l_ne_validate = "Eintrag freigeben/validate entry:".$crlf."%s".$crlf;
$l_ne_edit = "Eintrag bearbeiten/edit entry:".$crlf."%s".$crlf.$crlf.$crlf;
$l_generated = "Powered by";
$l_postingdisabled = "Verfassen neuer Eintr&auml;ge deaktiviert";
$l_functiondisabled = "Funktion deaktiviert";
$l_npmailsubject = "Eintrag im Gaestebuch";
$l_npmailbody = "Hallo {postername},".$crlf.$crlf."Danke, dass Du Dich in unserem Gaestebuch eingetragen hast.";
$l_nobody = "Unbekannter";
$l_timezone_note = "Alle Zeitangaben sind in";
$l_maxemoticons = "Sie k&ouml;nnen max. %d Smilies verwenden";
$l_avatartoolarge = "zul&auml;ssige Gr&ouml;sse des Avatars &uuml;berschritten (max. {maxx} x {maxy})";
$l_noflooding = "Ein Beitrag kann nur einmal abgeschickt werden";
// Wenn Sie auf den erzeuten HTML-Seiten eine Info dazu haben wollen, dass Sie die Sprachdatei
// �bersetzt haben, so plazieren Sie diese in dieser Variablen.
// z.B. $l_translationnote = "schw�bische �bersetzung von Hans Mustermann"
$l_translationnote = "";
?>