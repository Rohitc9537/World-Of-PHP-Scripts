<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_name = "Name";
$l_email = "Email";
$l_noname = "You have to enter a name";
$l_notext = "You have to enter a text";
$l_back = "back";
$l_add = "add";
$l_addentry = "add entry";
$l_heading = "heading";
$l_text = "Text";
$l_bbcodehelp = "BBCode help";
$l_disableautourl = "disable automatic encoding for URLs";
$l_disablebbcode = "disable BBCode";
$l_disableemoticons = "disable smilies";
$l_on = "on";
$l_timeonserver = "actual time on server";
$l_emoticonlist = "list of smilies";
$l_close = "close";
$l_noneavailable = "none available";
$l_code = "Code";
$l_emotion = "Emotion";
$l_page = "Page";
$l_poster = "Poster";
$l_homepage = "Homepage";
$l_visithomepage = "visit homepage";
$l_sendemail = "send email";
$l_sendicqmsg = "send ICQ message";
$l_country = "Country";
$l_noentries = "no entries";
$l_modcomment = "moderator's comment";
$l_pleaseselect = "--- please select ---";
$l_icqnumber = "ICQ number";
$l_ipbanned = "Function not allowed from this IP.";
$l_reason = "reason";
$l_floodmsg1 = "Admin has decided, you only can post one entry every ";
$l_floodmsg2 = "seconds";
$l_gotop = "top of page";
$l_male = "male";
$l_female = "female";
$l_nohomepage = "You have to enter an URL for your homepage";
$l_gender = "Gender";
$l_invalidtext = "Text contains too long words (max.";
$l_charsperword = "characters per word)";
$l_aim = "AIM";
$l_requiredmarked = "required fields are marked by color";
$l_nogender = "You have to choose a gender";
$l_noemail = "You have to enter an email";
$l_nocountry = "You have to choose a country";
$l_noicq = "You have to enter an ICQ number";
$l_noaim = "You have to enter an AIM address";
$l_noheading = "You have to enter a heading";
$l_altaim = "Instant Messenger";
$l_novalidemail = "Please provide a valid email";
$l_novalidicq = "Please provide a valid ICQ number";
$l_novalidhomepage = "Please provide a valid URL for your homepage";
$l_preview = "preview";
$l_previewprelude = "Your entry would look like this:";
$l_usersonline = "Currently browsing guestbook";
$l_user = "users";
$l_avatar = "Avatar";
$l_uploadown = "upload own";
$l_avatarlist = "list of avatars";
$l_noavatar = "You have to select an avatar";
$l_description = "description";
$l_msnm = "MSN Messenger";
$l_yim = "Yahoo Instant Messenger";
$l_nomsnm = "You have to provide a MSN Messenger address";
$l_noyim = "You have to provide an Yahoo Instant Messenger address";
$l_yimlabel = "Yahoo Instant Messenger";
$l_entryadded = "entry added<br>you will be redirected to the guestbook";
$l_gotoguestbook = "goto guestbook";
$l_totalentries = "total entries";
$l_entries = "entries";
$l_of = "of";
$l_language = "Language";
$l_ok = "OK";
$l_layout = "Layout";
$l_validatenote = "Admin has decided to have new postings validated<br>before being visible for public.";
$l_age = "Age";
$l_location = "Location";
$l_noage = "You have to provide an age";
$l_nolocation = "You have to provide a location";
$l_company = "Company";
$l_nocompany = "You have to provide a company";
$l_nofound = "You have to enter, how you found us";
$l_msgtooshort = "Your message is too short (min.";
$l_chars = "characters";
$l_found = "How did you find us";
$l_privatepost = "private (only admins can see the entry)";
$l_msgtoolong = "Your message is too long (max.";
$l_min = "min.";
$l_max = "max.";
$l_allowedbbcodes = "allowed BBCode tags";
$l_page_forward = "next page";
$l_page_back = "previous page";
$l_page_last = "last page";
$l_page_first = "first page";
$l_search = "search";
$l_searchguestbook = "search guestbook";
$l_result = "result";
$l_attachement = "download attachment";
$l_quote = "quote";
$l_quotemsg = "On {postdate}, {poster} wrote:";
$l_totalviews = "total views";
$l_since = "since";
$l_nosearchcriteria = "no words to search for / fields to search in entered";
$l_searchon = "search&nbsp;on";
$l_searchentries = "entries";
$l_searchcomments = "comments";
$l_searchusernames = "usernames";
$l_help = "Help";
$l_namenotallowed = "Usage of this username is not allowed.";
$l_config_writeable ="The config file (config.php) is writeable by PHP. This is a major security risk.<br>SimpGB will not be able to run until this is fixed.<br>";
$l_guestbook = "guestbook";
$l_userpic = "Picture";
$l_nouserpic = "You have to provide a picture";
$l_novaliduserpic = "Please provide a valid URL for the picture";
$l_enterdisplaytext = "Enter the text to be displayed";
$l_entercolor = "Enter the color you want";
$l_entertextsize = "Enter the text size you want";
$l_enterlinkurl = "Enter the URL you want to link to";
$l_enterswf = "Enter the SWF-File to be displayed";
$l_width = "Width";
$l_height = "Height";
$l_enteremail = "Enter emailaddress here";
$l_enterlistitem = "Enter Text you want as listitem";
$l_entercode = "Enter the text you want as code";
$l_enterbold = "Enter the text you want bolded";
$l_enterimageurl = "Enter the URL of the Image you wish to insert";
$l_enterrealurl = "Enter the URL of the Realaudio file you wish to insert";
$l_enterquote = "Enter the text you want to quote here";
$l_enteritalic = "Enter the text you want Italic";
$l_enterstrikethrough = "Enter the text you want stroken through";
$l_entertypewrite = "Enter the text you want in typewrite";
$l_entersuper = "Enter the text you want in superscript";
$l_entersub = "Enter the text you want in subscript";
$l_entercenter = "Enter the text you want to center";
$l_enterfonttext = "Enter the text you want in this charset";
$l_enterfont = "Enter font";
$l_availfonts = array("Andale Mono","Arial","Arial Black","Book Antiqua","Century Gothic","Comic Sans MS","Courier New","Georgia","Impact","Tahoma","Times New Roman","Script MT Bold","Verdana","Lucida Console");
$l_availcolors = array("White","Black","Red","Yellow","Pink","Green","Orange","Purple","Blue","Beige","Brown","Teal","Navy","Maroon","Limegreen");
$l_font = "font";
$l_fontsize = "fontsize";
$l_fontcolor = "fontcolor";
$l_more = "more";
$l_bbcode_labels = array("bold","italic","strike","typewriter","subscript","superscript","center","image","code","quote","list start","list item","list end","fontsize","fontcolor","email","URL","realaudio","SWF","font","vertical scroll","scroll", "fading text", "flip vertical", "flip horizontal", "glow", "shadow", "blur", "dropshadow", "windowsmedia","rainbowtext");
$l_alignments = array("Left","Right","Center");
$l_alignment = "alignment";
$l_enteraligntext = "Enter text text you want to align";
$l_charsleft = "characters left";
$l_attachfile = "attach file";
$l_toomanychars = "Too many characters entered";
$l_filetypenotallowed = "The provided file is not of an allowed type. You only can upload files of the following types:";
$l_filetoolarge = "The uploaded file is too large";
$l_bytes = "bytes";
$l_cantattach = "unable to attach file";
$l_noattachment = "You have to provide an attachment";
$l_enterupdown = "Enter the text to use as vertical scroller";
$l_enterscroll = "Enter text to use as scroller";
$l_sendemail = "send email";
$l_sendmailto = "Send email to";
$l_callingerror = "calling error";
$l_yourname = "Your name";
$l_youremail = "Your email";
$l_change = "change";
$l_subject = "Subject";
$l_defsubj = "Email through SimpGB ({sitename})";
$l_mnote = "<font size=\"1\">This email was sent through <a href=\"http://www.boesch-it.de\">SimpGB v$version</a> on <a href=\"{gburl}\">{sitename}</a></font>";
$l_mailsent = "Your email for {receiver} has been sent.<br>You will be forwarded to the guestbook.";
$l_enterfade = "Enter the text to be faded";
$l_enterflip = "Enter the text to be flipped";
$l_entertext = "Enter the text to be displayed";
$l_enterwmvurl = "URL for windowsmediafile, to be inserted";
$l_dateselformat = array("month","day","year");
$l_day = "Day";
$l_month = "Month";
$l_year = "Year";
$l_betweendate = "in the following Timeframe";
$l_startdate = "start date";
$l_enddate = "end date";
$l_admmail = "mail admin";
$l_admin = "Admin";
$l_admmenu = "Administrationmenu";
$l_sitehome = "Homepage";
$l_editmsg = "edit entry (admins only)";
$l_delentry = "delete entry (admins only)";
$l_comentry = "write comment (admins only)";
$l_bbccolhelp = "Fontcolor: [color=blue]Text[/color]";
$l_bbcode_helps = array(
	"bold text: [b]Text[/b]",
	"italic text: [i]Text[/i]",
	"strike through: [s]Text[/s]",
	"Typewriter: [tt]Text[/tt]",
	"subscript: [sub]Text[/sub]",
	"superscript: [sup]Text[/sup]",
	"center: [center]Text[/center]",
	"Image: [img]http://www.foo.bar/bild.gif[/img]",
	"Code: [code]Text[/code]",
	"Quote: [quote]Text[/quote]",
	"Liststart: [list]",
	"Listitem: [*]",
	"Listend: [/list]",
	"Fontsize: [size=2]Text[size]",
	"Fontcolor: [color=red]Text[/color]",
	"Email: [email]test@foo.bar[/email]",
	"URL: [url]http://www.foo.bar[/url]",
	"Realaudio: [realaudio]rtsp://www.foo.bar/audio.ram[/realaudio]",
	"SWF: [swf width=12 height=13]http://www.foo.bar/flash.swf[/swf]",
	"Font: [font=Arial]Text[/font]",
	"vertical scroll: [updown]Text[/updown]",
	"horizontal scroll: [scroll]Text[/scroll]",
	"fading text: [fade]Text[/fade]",
	"vertical mirror: [flip=v]Text[/flip]",
	"horizontal mirror: [flip=h]Text[/flip]",
	"Glow: [glow=yellow]Text[/glow]",
	"Shadow: [shadow=blue]Text[/shadow]",
	"Blur: [blur]Text[/blur]",
	"Dropshadow: [dropshadow=yellow]Text[/dropshadow]",
	"Windowsmedia: [stream]http://www.foo,bar/audio.wma[/stream]",
	"Rainbowtext [rainbow=red]Text[/rainbow]",
	"Textalignment: [align=right]Text[/align]");
$l_bbc_quote = "Quote";
$l_bbc_code = "Code";
$l_sortorders = array("by date (descending)","by date (ascending)","by poster");
$l_sortorder = "Sortorder";
$l_oldbrowser = "This guestbook doesn't work with Internetexplorer <4.0 or Netscape <4.0.<br>Please use a newer browser.";
$l_ne_subj = "Info from SimpGB";
$l_ne_msg = "Neuer Gaestebucheintrag/new guestbook entry: #%s".$crlf."%s, %s".$crlf.$crlf."--------------------------------".$crlf;
$l_ne_poster = "Verfasser/poster: %s".$crlf;
$l_ne_company = "Firma/company: %s".$crlf;
$l_ne_email = "Email: %s\r\n";
$l_ne_location = "Wohnort/location: %s".$crlf;
$l_ne_country = "Land/country: %s".$crlf;
$l_ne_homepage = "Homepage: %s".$crlf;
$l_ne_icq = "ICQ: %s".$crlf;
$l_ne_aim = "AIM: %s".$crlf;
$l_ne_msnm = "MSN Messenger: %s".$crlf;
$l_ne_yim = "Yahoo Instant Messenger: %s".$crlf;
$l_ne_found = "Gefunden/found: %s".$crlf;
$l_ne_heading = "�berschrift/heading: %s".$crlf;
$l_ne_entry = "Eintragstext/entry text:".$crlf;
$l_ne_validate = "Eintrag freigeben/validate entry:".$crlf."%s".$crlf;
$l_ne_edit = "Eintrag bearbeiten/edit entry:".$crlf."%s".$crlf.$crlf.$crlf;
$l_generated = "Powered by";
$l_postingdisabled = "Posting of new entries disabled";
$l_functiondisabled = "Funktion disabled";
$l_npmailsubject = "posting on guestbook";
$l_npmailbody = "Hello {postername},".$crlf.$crlf."thank you for posting on our guestbook.";
$l_nobody = "nobody";
$l_timezone_note = "all times are";
$l_maxemoticons = "You are only allowed to use up to %d smilies in the post";
$l_avatartoolarge = "uploaded avatar too large (max. {maxx} x {maxy})";
$l_noflooding = "an entry only can be submitted once";
// If you want an info stating you have translated the language file in generated HTML pages
// provide the text within this variable
// e.g. $l_translationnote = "translation to greek language done by sokrates"
$l_translationnote = ""
?>