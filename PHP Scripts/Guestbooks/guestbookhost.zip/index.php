<html>
<head>
<title>GuestBookHost Temporary Index Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<div align="center"><font size="+3" face="Verdana, Arial, Helvetica, sans-serif"><br>
  <br>
  <br>
  <a href="signup.php">Create Account</a><br>
  <a href="members.php">Log In</a></font> </div>
</body>
</html>
