AOGuestbook
Author: Mike Helton (addicted one)
Release Date: October 13, 2005
Version 1.2

--------------

This guestbook is very simple. It has a guestbook view file and an add entry file, nothing else. It can easily be integrated into any webpage by placing the contents of each file in a webpage where you would like them to appear, and being sure that "guestbook.php" and "post.php" are in the same directory. 

--------------

Create a new database, then run "sql.sql" on it to create the required tables. After that, edit the "config.php" file to match the passwords of the database. 

--------------

This script is free, you may use it for anything you want. I ask that if you use it, email me a link to it so that I can see my script being used on someone else's site and leave the commented out text in the index page so I can find it via google. That would make my day. (mshelton@oakland.edu)

You may also email me for any questions or comments. 