<?php include("guestbook.php"); ?>

<?php read_guestbook() ?>

<?php guestbook_form() ?>