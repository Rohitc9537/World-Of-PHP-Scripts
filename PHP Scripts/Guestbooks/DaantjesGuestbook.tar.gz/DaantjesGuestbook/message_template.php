<table>
<tr><td>door:</td><td><?=$nickname;?></td></tr>
<tr><td>op:</td><td><?=$posted;?></td></tr>
<tr><td>URL:</td><td><?=$url;?></td></tr>
<tr><td>bericht:</td><td><?=$message;?></td></tr>
</table>
<hr>