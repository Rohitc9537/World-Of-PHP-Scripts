<?
/*
	Daantje's Guestbook v3.1.3
	written by: me@daantje.nl
	first written:	Sat Oct 26 11:10:54 CEST 2002
	last update:    Wed Mar 16 10:04:04 CET 2005

	(c)1999 - 2005 All copyrights by: Daan Eeltink

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	(http://www.gnu.org/licenses/gpl.txt)


	DOCUMENTATION:
	This is my Guestbook class. To make this work you should have a
	MySQL database. First edit the configs in the index.php and build
	some HTML around it, or copy paste the code in some allready existing
	page. Then upload this all to your webspace. The MySQL table sould be
	exessable with a user that can INSERT and SELECT. If you want to use
	the build in admin function, the user should have DELETE rights also.
	MySQL documentation:
	http://www.mysql.com/documentation/mysql/bychapter/manual_Reference.html
	Or just use http://www.phpMyAdmin.org to manage your MySQL database...
	See source for more documentation.

	Rest of documentation is comming later...


	MySQL TABLE DEFINITION:
	Add the table below to your MySQL database.

		CREATE TABLE DaantjesGuestbook (
			ID int(8) NOT NULL auto_increment,
			posted int(4) NOT NULL default '0',
			nickname varchar(100) NOT NULL,
			email varchar(250) default NULL,
			message text NOT NULL,
			url varchar(255) default NULL,
			PRIMARY KEY  (ID)
		) TYPE=MyISAM PACK_KEYS=1;
*/

// BEGIN GUESTBOOK CODE
include("include/DaantjesGuestbook_class.inc.php"); //include class
$DaantjesGuestbook = new DaantjesGuestbook(); //call class

//set some config we mostly need...
$DaantjesGuestbook->config['mysql_host']	= "localhost";
$DaantjesGuestbook->config['mysql_db']		= "daantje";
$DaantjesGuestbook->config['mysql_user']	= "DaantjesGuestboo";
$DaantjesGuestbook->config['mysql_passw']	= "Wr!t3m3";

//set some _OPTIONAL_ configurations...
//UNREMARK A LINE TO USE THE VALUE!
	//$DaantjesGuestbook->config['guestbook_table']	= "DaantjesGuestbook";

	//$DaantjesGuestbook->texts['posted']		= "posted";
	//$DaantjesGuestbook->texts['name'] 		= "name";
	//$DaantjesGuestbook->texts['email']  		= "e-mail";
	//$DaantjesGuestbook->texts['url'] 			= "homepage URL";
	//$DaantjesGuestbook->texts['message'] 		= "message";

	//$DaantjesGuestbook->warning['post'] 		= "The fields 'nickname' and 'message' are required...";
	//$DaantjesGuestbook->warning['done'] 		= "Thanks! Your message has been added to my guestbook";

	//$DaantjesGuestbook->config['messagesPerPage']		= 30;
	//$DaantjesGuestbook->config['URL']					= "$PHP_SELF";
	//$DaantjesGuestbook->config['message_template']	= "message_template.php";  //path to message template file.
	//$DaantjesGuestbook->config['allow_line_breaks']	= FALSE; //allow enters in message, linefeed will be converted into BR tags.

	//$DaantjesGuestbook->config['page_buttons'] = array(
	//	//button        //HTML value
	//	'prev' 	=> 	"<<&nbsp;first",
	//	'back' 	=> 	"<&nbsp;back",
	//	'forw' 	=> 	"forward&nbsp;>",
	//	'next' 	=> 	"last&nbsp;>>",
	//	'spacer'=> 	"&nbsp;|&nbsp;"
	//	);

	//to access the admin, call the guestbook URL and add the variable 'admin' and value it with the admin_passw
	// like:	http://www.yourdomain.bla/guestbook.php?admin=l3tm3!n
	// or:		http://www.yourdomain.bla/index.php?category=MyGuestbook&admin=l3tm3!n
	//When remarked, the admin option will be disabled.
	//$DaantjesGuestbook->config['admin_passw']	= "l3tm3!n";

//END OF _OPTIONAL_ configurations...

//parse guestbook...
$DaantjesGuestbook->engine(); //do needed stuff
$DaantjesGuestbook->form(); //parse form
echo "<br>";
$DaantjesGuestbook->listing(); //parse listing
//and echo my credits ;)
echo "<br><font size=1>".$DaantjesGuestbook->config['credits']."</font>";
// END GUESTBOOK CODE
?>