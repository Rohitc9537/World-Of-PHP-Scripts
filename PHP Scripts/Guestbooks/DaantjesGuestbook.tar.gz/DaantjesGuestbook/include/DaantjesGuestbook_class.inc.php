<?
/*
	Daantje's Guestbook v3.1.3
	written by: me@daantje.nl
	first written:	Sat Oct 26 11:10:54 CEST 2002
	last update:    Wed Mar 16 09:36:42 CET 2005

	(c)1999 - 2005 All copyrights by: Daan Eeltink

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	(http://www.gnu.org/licenses/gpl.txt)


	DOCUMENTATION:
	This is my Guestbook class. To make this work you should have a
	MySQL database. First edit the configs in the index.php and build
	some HTML around it, or copy paste the code in some allready existing
	page. Then upload this all to your webspace. The MySQL table sould be
	exessable with a user that can INSERT and SELECT. If you want to use
	the build in admin function, the user should have DELETE rights also.
	MySQL documentation:
	http://www.mysql.com/documentation/mysql/bychapter/manual_Reference.html
	Or just use http://www.phpMyAdmin.org to manage your MySQL database...
	See source for more documentation.

	Rest of documentation is comming later...


	MySQL TABLE DEFINITION:
	Add the table below to your MySQL database.

		CREATE TABLE DaantjesGuestbook (
			ID int(8) NOT NULL auto_increment,
			posted int(4) NOT NULL default '0',
			nickname varchar(100) NOT NULL,
			email varchar(250) default NULL,
			message text NOT NULL,
			url varchar(255) default NULL,
			PRIMARY KEY  (ID)
		) TYPE=MyISAM PACK_KEYS=1;
*/

class DaantjesGuestbook {
	function DaantjesGuestbook(){
		//Set defaults configs...
		//$this->config['mysql_host']		= "localhost";
		//$this->config['mysql_db']			= "daantje";
		//$this->config['mysql_user']		= "DaantjesGuestboo";
		//$this->config['mysql_passw']		= "Wr!t3m3";
		$this->config['guestbook_table']	= "DaantjesGuestbook";

		$this->texts['posted']				= "posted";
		$this->texts['name'] 				= "name";
		$this->texts['email']  				= "e-mail";
		$this->texts['url'] 				= "homepage URL";
		$this->texts['message'] 			= "message";

		$this->warning['post'] 				= "The fields 'nickname' and 'message' are required...";
		$this->warning['done'] 				= "Thanks! Your message has been added to my guestbook";
		$this->warning['delete']			= "Message is deleted...";

		$this->config['page_buttons'] = array(
			'prev' => "<<&nbsp;first",
			'back' => "<&nbsp;back",
			'forw' => "forward&nbsp;>",
			'next' => "last&nbsp;>>",
			'spacer' => "&nbsp;|&nbsp;"
			);

   		//to access the admin, call the guestbook URL and add the variable 'admin' and value it with the admin_passw
		// like:	http://www.yourdomain.bla/guestbook.php?admin=l3tm3!n
		// or:		http://www.yourdomain.bla/index.php?category=MyGuestbook&admin=l3tm3!n
		//When remarked or not filled, the admin option will be disabled.
		$this->config['admin_passw']		= "";

		$this->config['messagesPerPage']	= 30;
		$this->config['URL']				= "$PHP_SELF";
		$this->config['message_template']	= FALSE;  //path to message template file.
		//$this->config['message_template']	= "message_template.php";  //path to message template file.

		$this->config['allow_line_breaks']	= FALSE;

		//some system configs
		$this->config['variables']		= array('HTTP_POST_VARS','HTTP_GET_VARS');
		$this->config['version']		= "3.1.3";
		$this->config['credits']		= "Daantje's Guestbook v".$this->config['version']."<br>&copy;1999-2005 All copyrights by <a href=http://www.daantje.nl target=_blank>Daan Eeltink</a>";


		/////////////////////////////////////////
		/// DO SOME GLOBAL ENGINE STUFF
		/////////////////////////////////////////
		//make all config['variables'] arrays global for this class
		foreach($this->config['variables'] as $a){
			global $$a; $arr = $$a; reset($arr);
			while(list($k,$v) = each($arr)) $this->$k = $v;
		}
	}

	//to open a database??
	function openDB(){
		global $HTTP_HOST;
		$this->conn = @mysql_pconnect($this->config['mysql_host'],$this->config['mysql_user'],$this->config['mysql_passw']) or die("Sorry, $HTTP_HOST is down. Please come back later.<br>".mysql_error());
		mysql_select_db($this->config['mysql_db'], $this->conn) or die("Sorry, $db can't be used. Please come back later.<br>".mysql_error());
	}

	//post a message to the database...
	function post(){
		//check if name and message are filled
		if($this->nickname && $this->message){
			//fix not set magic_quotes_gpc
			if(ini_get('magic_quotes_gpc') == 0){
				$this->nickname = addslashes($this->nickname);
				$this->url = addslashes($this->url);
				$this->email = addslashes($this->email);
				$this->message = addslashes($this->message);
			}

			//add to db
			$SQL = "INSERT INTO ".$this->config['guestbook_table']." (nickname,email,url,posted,message) VALUES ('".strip_tags($this->nickname)."','".strip_tags($this->email)."','".strip_tags($this->url)."','".time()."','".strip_tags($this->message)."')";
			mysql_query($SQL,$this->conn) or die("<b>[ERROR]</b> SQL error!<br>".mysql_error($this->conn));
			unset($this->nickname,$this->email,$this->url,$this->message); //reset form values
			$this->error = $this->warning['done']; //we're done, give thank you...
		}else{
			//one of the fields name or message were not filled, pus error...
			$this->error = $this->warning['post'];
		}
	}

	//delete a message from the database...
	function delete(){
		//check if needed values are filled
		if($this->delete && $this->deleteMessage){
			$SQL = "DELETE FROM ".$this->config['guestbook_table']." WHERE ID=".$this->deleteMessage;
			mysql_query($SQL,$this->conn) or die("<b>[ERROR]</b> SQL error!<br>$SQL<br>".mysql_error($this->conn));
			$this->error = $this->warning['delete']; //it's deleted...
		}
	}

	//standard form template
	function form(){
		echo "<table border=0 cellpadding=0 cellspacing=0>\n";
		echo "<form action=\"".$this->config['URL']."\" method=post>\n";
		echo "<tr><td nowrap align=right>".$this->texts['name'].":&nbsp;</td><td><input type=text name=nickname value=\"$this->nickname\"></td></tr>\n";
		echo "<tr><td nowrap align=right>".$this->texts['email'].":&nbsp;</td><td><input type=text name=email value=\"$this->email\"></td></tr>\n";
		echo "<tr><td nowrap align=right>".$this->texts['url'].":&nbsp;</td><td><input type=text name=url value=\"$this->url\"></td></tr>\n";
		echo "<tr><td nowrap align=right>".$this->texts['message'].":&nbsp;</td><td><textarea name=message cols=30 rows=5 wrap=virtual>$this->message</textarea></td></tr>\n";
		echo "<tr><td colspan=2><input type=submit name=addGuestbookMessage value=\"Post message\"></td></tr>\n";
		echo "</form></table>\n";
	}

	//standard message template
	function message($nickname,$posted,$message,$email="",$url=""){
		$echo.= "<tr><td valign=top nowrap align=right>".$this->texts['name'].":&nbsp;</td><td>$nickname</td></tr>\n";
		$echo.= "<tr><td valign=top nowrap align=right>".$this->texts['posted'].":&nbsp;</td><td>$posted</td></tr>\n";
		if($url) $echo.= "<tr><td valign=top nowrap align=right>".$this->texts['url'].":&nbsp;</td><td>$url</td></tr>\n";
		$echo.= "<tr><td valign=top nowrap align=right>".$this->texts['message'].":&nbsp;</td><td>$message</td></tr>\n";
		$echo.= "<tr><td valign=top nowrap colspan=2><hr noshade size=1></td></tr>\n";
		return $echo;
	}

	//LIMIT-MENU v5.1 (standalone)
	//All copyrights by me@daantje.nl
	//make page links for limit in query
	function limitMenu($amount,$skip,$pageMax,$totRecs,$link,$skipTrigger){
		if(!eregi("\?",$link)) $link.="?"; elseif(substr($link,-1)!="&") $link.="&";
		if(!$skip) $skip = 0;
		$pageMax--;
		settype($totRecs,"integer");

		$pageCnt=$skip/$amount+1;
		if($pageCnt > 0 && $pageCnt <= round($pageMax/2)){
			$pageCnt = 1;
			$z=0;
		}else{
			$pageCnt = round($pageCnt - round($pageMax/2));
			if($pageCnt+$pageMax > ceil($totRecs/$amount)) $pageCnt = ceil($totRecs/$amount)-$pageMax;
			if($pageCnt<1) $pageCnt = 1;
			$z=$pageCnt*$amount-$amount;
		}
		$orgPageCnt=$pageCnt;
		$newp = $skip-$amount;
		if($skip-($amount) > 0) $returnStr.= "<td class=pageTabOff><A HREF=".$link."$skipTrigger=0 target=_self>".$this->config['page_buttons']['prev']."</a></td><td>".$this->config['page_buttons']['spacer']."</td>";
		if($skip > 0) $returnStr.= "<td class=pageTabOff><a HREF=".$link."$skipTrigger=".$newp." target=_self>".$this->config['page_buttons']['back']."</a></td><td>".$this->config['page_buttons']['spacer']."</td>";
		for($j=$z;$j < $totRecs;$j=$j+$amount){
			$jj = $j;
			if($pageCnt<10) $p = substr("0".$pageCnt,-2); else $p = $pageCnt;
			if($skip==$jj) $returnStr.= "<td class=pageTabOn>".$p."</td><td>".$this->config['page_buttons']['spacer']."</td>";
			else $returnStr.= "<td class=pageTabOff><a HREF=".$link."$skipTrigger=".$jj." target=_self>".$p."</a></td><td>".$this->config['page_buttons']['spacer']."</td>";
			if($pageCnt==$orgPageCnt+$pageMax && $orgPageCnt+$pageMax < $totRecs/$amount) break;
			else $pageCnt++;
		}
		$newp = $skip+$amount;
		if($newp < $totRecs) $returnStr.= "<td class=pageTabOff><a HREF=".$link."$skipTrigger=".$newp." target=_self>".$this->config['page_buttons']['forw']."</a></td><td>".$this->config['page_buttons']['spacer']."</td>";
		if($skip+($amount*2)< $totRecs) $returnStr.= "<td class=pageTabOff><a HREF=".$link."$skipTrigger=".($amount*(ceil($totRecs/$amount))-$amount)." target=_self>".$this->config['page_buttons']['next']."</a></td><td>".$this->config['page_buttons']['spacer']."</td>";
		$c = strlen($this->config['page_buttons']['spacer']);
		if($pageCnt>1) return "<table border=0 cellpadding=0 cellspacing=0><tr>".substr($returnStr,0,-$c)."</tr></table>";
	}

	//count the total messages in the database..
	//this we need to calculate the pages.
	function countMessages(){
		$SQL = "SELECT COUNT(ID) FROM ".$this->config['guestbook_table'];
		$r = mysql_query($SQL,$this->conn) or die("<b>[ERROR]</b> SQL error!<br>".mysql_error($this->conn));
		list($this->totRecs) = mysql_fetch_row($r);
	}

	//generate a listing of all messages
	//this routine contains the call to the limitMenu
	//when $this->config['message_template'] path exists, it will be included
	//else a call will be made to the standard message() function.
	function listing(){
		$this->countMessages();
		if(file_exists($this->config['message_template']))
			$pT = TRUE;
		if(!$this->skip)
			$this->skip = 0;
		if($this->config['messagesPerPage'] < $this->totRecs)
			echo $this->limitMenu($this->config['messagesPerPage'],$this->skip,10,$this->totRecs,$this->config['URL'],"skip");
		$SQL = "SELECT ID,nickname,email,url,posted,message FROM ".$this->config['guestbook_table']." ORDER BY posted DESC LIMIT {$this->skip},".$this->config['messagesPerPage'];
		$r = mysql_query($SQL,$this->conn) or die("<b>[ERROR]</b> SQL error!<br>$SQL<br>".mysql_error($this->conn));
		if(!$pT)
			echo "<table border=0 cellpadding=0 cellspacing=0>\n<tr><td valign=top nowrap colspan=2><br><hr noshade size=1></td></tr>\n";
		while($data = mysql_fetch_assoc($r)){
			foreach($data as $k=>$v){
				if(strlen($v)>30 && $k!='email' && $k!='url'){
					$w = explode(" ",$v);
					$v = "";
					foreach($w as $i){
						if(strlen($i)>30)
							$v.= substr($i,0,30).' ';
						else
							$v.= $i.' ';
					}
				}
				$$k = htmlspecialchars($v);
			}
			if($email)
				$nickname = "<a href=\"mailto:$email\">".$nickname."</a>";
			if($this->config['allow_line_breaks'])
				$message = nl2br($message);
			$message = stripslashes($message);
			//when admin is enabled...
			if($this->delete)
				$nickname.= " [<a href=".$this->config['URL']."?admin=$this->admin&deleteMessage=$ID>DELETE</a>]";
			$posted = date("d M Y H:i:s",$posted);
			if($url){
				if(!strstr($url,"http://"))
					$url = "http://".$url;
				$url = "<a href=\"$url\">".$url."</a>";
			}
			if($pT == TRUE)
				include($this->config['message_template']);
			else
				echo $this->message($nickname,$posted,$message,$email,$url);
		}
		if(!$pT)
			echo "</table><br>\n";
		if($this->config['messagesPerPage'] < $this->totRecs)
			echo $this->limitMenu($this->config['messagesPerPage'],$this->skip,10,$this->totRecs,$this->config['URL'],"skip");
	}

	//this does the job...
	function engine(){
		$this->openDB(); //open db connection
		//admin stuff, TRUE to activate the delete button... Only when $this->config['admin_passw'] is filled!! We don't accept empty config passw!!
		if($this->admin == $this->config['admin_passw'] && $this->config['admin_passw'])
			$this->delete = TRUE;
		else
			$this->delete = FALSE; //always set it to false, or else we can be hacked!

		//do delete action...
		if($this->delete && $this->deleteMessage)
			$this->delete();

		//do the rest...
		if($this->addGuestbookMessage)
			$this->post(); //post message if requested...
		if($this->error)
			echo "<script>alert('".addslashes($this->error)."');</script>\n"; //popup warning...
	}
}
?>
