<? header("location:guestbook.php"); ?>
