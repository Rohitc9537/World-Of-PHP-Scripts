********************************************************************************
----READ ME PLEASE - July 24 2005  - A simple guestbook-comment script v 1.2d---
********************************************************************************
Package contents of this version 1.2 distribution:

- readme.txt - this readme
- comments.php - the main file that you will display on your website
- commadmin.php - an administration module that allows simple editing of posts
- comminstall.php -An installer that creates the table needed to run your script
  
  In the docs folder - No need to upload this to your server: 
  
- docs.html - Documentation that you can read in your browser offline. Includes 
  installation instructions, as well as implementation and customization guides
- several gifs used by the documentation
********************************************************************************

Installation, implementation, and customization instructions are provided inside
the main script, 'comments.php' as well as in the docs folder - open 'docs.html'
in your web browser for an illustrated guide.

This script has been tested on servers running php 4.3 up to 5 and MySQL 4.

Aug 20/05  - bug with sessions and multiple guestbook installs fixed

July 24/05 - bug with 'register_globals on' has been fixed. 10 blank lines are added 
to the bottom of the listing so that it doesn't look dumb when first installed.


Thank You for your interest.

********************************************************************************