<?
 header ("Location: ../index.php");
?>