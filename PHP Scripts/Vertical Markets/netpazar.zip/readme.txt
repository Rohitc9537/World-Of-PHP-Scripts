		NET PAZAR
Installation (PHP, MySQL needed)

1- Unzip these to your "apache/htdocs/pazar" folder
2- Create tables(1 named admin, 1 named netpazar) using "vt.sql" in phpMyAdmin
3- Chmod 777 for "apache/htdocs/pazar/yollanan" folder for picture uploading
4- Edit "conf.php" for proper things
5- "http://localhost/pazar" to run...

Tarik BAGRIYANIK, August 2005