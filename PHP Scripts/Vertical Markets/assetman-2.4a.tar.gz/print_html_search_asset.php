<?php
function display_date($date) {
// Converts an ISO format date selected from database to local format for display.
   global $cfg;
   list($year, $month, $day) = split("-", $date);
   $date = date($cfg["date_arg"], mktime(0, 0, 0, $month, $day, $year));
   return $date;
}

require("config.inc.php");
session_name($cfg["session"]);
session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $fullname = $_SESSION["fullname"];
} else {
   header("Status: 302 Found");
   header("Location: login.php");
}

require("grab_globals.inc.php");
require("connection.inc.php"); ?>
<html>
<head>
	<title>Print HTML Search Result</title>
   <link rel="STYLESHEET" type="text/css" href="style.css">
</head>
<body> <?php
if (!$summary = $db->Execute($_SESSION["search_query"])) {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
   die();
} ?>
<table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
   <tr class="row_head">
      <td><b>Asset</b></td>
      <td><b>Make</b></td>
      <td><b>Model</b></td>
      <td><b>Serial</b></td>
      <td><b>Date</b></td>
      <td><b>PO</b></td>
      <td><b>Configuration</b></td>
      <td align="right"><b>Price&nbsp;&nbsp;</b></td>
      <td><b>Decription</b></td>
   </tr> <?php
   $i = 1;
   while (!$summary->EOF) {
      $config_id = $summary->fields[13];
      if ($config_id != 0) {
         $config = $db->Execute("SELECT name FROM config WHERE id=$config_id");
      }
      if ($i % 2 == 0) {
         echo "<tr class=\"report_even\">";
      } else {
         echo "<tr class=\"report_odd\">";
      }
      echo "<td nowrap>" . $summary->fields["tag"] . "</td>";
      echo "<td nowrap>" . $summary->fields["make"] . "</td>";
      echo "<td nowrap>" . $summary->fields["model"] . "</td>";
      echo "<td nowrap>" . $summary->fields["serial"] . "</td>";
      echo "<td nowrap>" . display_date($summary->fields["date"]) . "</td>";
      if ($summary->fields["po"] != 0) {
         echo "<td nowrap>" . $summary->fields["po"] . "</td>";
      } else {
         echo "<td nowrap>None</td>";
      }
      if ($config_id != 0) {
         echo "<td nowrap>" . $config->fields["name"] . "</td>";
      } else {
         echo "<td nowrap>None</td>";
      }
      echo "<td align=\"right\" nowrap>" . $summary->fields["price"] . "&nbsp;&nbsp;</td>";
      echo "<td>" . $summary->fields["descrip"] . "</td></tr>";
      $i++;
      $summary->MoveNext();
   } ?>
</table>
<?php require("footer.inc.php"); ?>
