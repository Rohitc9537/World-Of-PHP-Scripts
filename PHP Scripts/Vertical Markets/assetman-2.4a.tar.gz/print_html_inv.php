<?php
function display_date($date) {
// Converts an ISO format date selected from database to local format for display.
   global $cfg;
   list($year, $month, $day) = split("-", $date);
   $date = date($cfg["date_arg"], mktime(0, 0, 0, $month, $day, $year));
   return $date;
}

require("config.inc.php");
session_name($cfg["session"]);
session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $fullname = $_SESSION["fullname"];
} else {
   header("Status: 302 Found");
   header("Location: login.php");
}

require("grab_globals.inc.php");
require("connection.inc.php"); ?>
<html>
<head>
	<title>Print HTML Invoice</title>
   <link rel="STYLESHEET" type="text/css" href="style.css">
</head>
<body> <?php
if (!$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number")) {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
   die();
}
if ($inv->RecordCount() == 0) {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice number $inv_number not found.</td></tr></table>";
   die();
}
$org_id = $inv->fields["organization"];
$org = $db->Execute("SELECT * FROM organization WHERE id=$org_id");
$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number");
$inv_lines = $db->Execute("SELECT * FROM inv_lines WHERE inv_number=$inv_number ORDER BY id");
require("form_header.inc.htm"); ?>
<hr>
<table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <tr> 
      <td><b>Date of Invoice: </b><?php echo display_date($inv->fields["date"]); ?></td>
      <td align="right"><b>Invoice Number: </b><?php echo $inv_number; ?></td>
   </tr>
</table>
<hr>
<table class="default" width="50%" border="0" cellspacing="0" cellpadding="1"
   <tr> 
      <td colspan="2"><b>Sold To:</b></td>
   </tr>
   <tr> 
      <td>&nbsp;</td>
      <td nowrap>
         <?php echo $org->fields["name"]; ?><br>
         <?php echo $org->fields["address1"]; ?><br>
         <?php echo $org->fields["city"] . ", " . $org->fields["province"] . ", " . $org->fields["p_code"]; ?><br>
         <?php echo "Attn: " . $org->fields["contact"]; ?>
       </td>
   </tr>
</table>
<table class="default" width="100%" border="0"><tr><td>&nbsp;</td></tr></table>
<table class="small" width="100%" border="1" cellspacing="1" cellpadding="1">
   <tr> 
      <td><b>Recv Date</b></td>
      <td><b>Recv By</b></td>
      <td align="center"><b>Qty</b></td>
      <td><b>Description</b></td>
      <td align="right"><b>Unit Price</b></td>
      <td align="right"><b>Amount</b></td>
   </tr> <?php
   $i = 1;
   $inv_total = 0;
   $tax1_total = 0;
   while (!$inv_lines->EOF) {
      echo "<tr>";
      echo "<td>". display_date($inv_lines->fields["rcv_date"]) . "</td>";
      echo "<td>" . $inv_lines->fields["rcv_by"] . "</td>";
      echo "<td align=\"center\">" . $inv_lines->fields["qty"] . "</td>";
      echo "<td>" . $inv_lines->fields["descrip"] . "</td>";
      echo "<td align=\"right\">" . $inv_lines->fields["unit_price"] . "</td>";
      echo "<td align=\"right\">" . $inv_lines->fields["amount"] . "</td>";
      echo "</tr>";
      $inv_total += $inv_lines->fields["amount"];
      if ($inv_lines->fields["taxable"] == "Y") {
         $tax1_total += $inv_lines->fields["amount"];
      }
      $i++;
      $inv_lines->MoveNext();
   } ?>
   <tr> 
      <td colspan="5" align="right"><b>Subtotal</b></td>
      <td align="right"><?php printf("<b>%s%01.2f</b>", $cfg["curr"], $inv_total); ?></td>
   </tr> <?php
      if ($org->fields["tax_exempt"] == "Y") {
         $tax1 = 0;
         $tax2 = 0;
      } else if ($inv->fields["open"] == "N") {
         $tax1 = $inv->fields["tax1"];
         $tax2 = $inv->fields["tax2"];
      } else {
         $tax1 = round($tax1_total * $cfg["tax1"], 2);
         $tax2 = round($inv_total * $cfg["tax2"], 2);
      }
      $inv_total = $inv_total + $tax1 + $tax2; ?>
   <tr> 
      <td colspan="5" align="right"><b><?php echo $cfg["tax1_name"]; ?></b></td>
      <td align="right"><?php printf("<b>%s%01.2f</b>", $cfg["curr"], $tax1); ?></td>
   </tr>
   <tr> 
      <td colspan="5" align="right"><b><?php echo $cfg["tax2_name"]; ?></b></td>
      <td align="right"><?php printf("<b>%s%01.2f</b>", $cfg["curr"], $tax2); ?></td>
   </tr>
   <tr> 
      <td colspan="5" align="right"><b>Invoice Total</b></td>
      <td align="right"><?php printf("<b>%s%01.2f</b>", $cfg["curr"], $inv_total); ?></td>
   </tr>
</table>
<p class="default"><?php echo $inv->fields["comments"]; ?></p>
<table class="default" align="right" bgcolor="#e8e8e8" border="1" cellspacing="1" cellpadding="1">
   <tr>
      <td align="center" colspan="2">Office Use Only</td>
   </tr>
   <tr>
      <td>Department Approval</td>
      <td width="50%">&nbsp;</td>
   </tr>
   <tr>
      <td>Finance Approval</td>
      <td width="50%">&nbsp;</td>
   </tr>
   <tr>
      <td>G/L Code - Credit</td>
      <td width="50%"><?php echo $inv->fields["gl_credit"]; ?>&nbsp;</td>
   </tr>
   <tr>
      <td>G/L Code - Debit</td>
      <td width="50%"><?php echo $inv->fields["gl_debit"]; ?>&nbsp;</td>
   </tr>
</table>
<?php require("footer.inc.php"); ?>