<?php require("common.inc.php"); ?>

<?php
function inv_form() { ?>
   <table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_inv.php" method="post" name="form1">
      <tr class="row_head"> 
         <td align="center" colspan="2" nowrap><b>Update Invoice Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Invoice Number:</td>
         <td> 
            <input type="text" name="inv_number" size="12">
            <input type="submit" value="Enter">
         </td>
      </tr>
   <input type="hidden" name="action" value="edit">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.inv_number.focus();
   </script> <?php
} ?>

<?php
function edit_form($db, $inv_number) {
   global $cfg, $username, $priv;
   if ($inv_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid Invoice number.</td></tr></table>";
      inv_form($db);
      return FALSE;
   }
   if (!$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($inv->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice number $inv_number not found.</td></tr></table>";
      inv_form($db);
      return FALSE;
   }
   if ($inv->fields["open"] == "N") {
      view_inv($db, $inv_number);
      return TRUE;
   }
   $org_id = $inv->fields["organization"];
   $cr_user_id = $inv->fields["created_by"];
   $org = $db->Execute("SELECT name, tax_exempt FROM organization WHERE id=$org_id");
   $cr_user = $db->Execute("SELECT fullname FROM users WHERE username='$cr_user_id'");
   $inv_lines = $db->Execute("SELECT * FROM inv_lines WHERE inv_number=$inv_number ORDER BY id"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
       <tr class="row_head"> 
         <td nowrap><b>Edit Invoice Information</b></td>
         <td align="right">Invoice Number:&nbsp;<?php echo $inv_number; ?></td>
       </tr>
       <tr class="row_even">
         <td> <?php
         if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "N") { ?>
            &nbsp;&nbsp;Status:<img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
         } else if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "Y") { ?>
            &nbsp;&nbsp;Status:<img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
         } else { ?>
            &nbsp;&nbsp;Status:<img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
         }
         if ($priv > 1 && $inv->fields["approved"] == "Y") { ?>
            <a href="print_inv.php?inv_number=<?php echo $inv_number; ?>"><img src="images/print_btn.gif" border="0" alt="Print"></a> <?php
         } ?>
         </td>
         <td align="right">Date:&nbsp;<?php echo display_date($inv->fields["date"]); ?></td>
       </tr>
       <tr class="row_even"> 
         <td>&nbsp;&nbsp;Organization:&nbsp;<?php echo $org->fields["name"]; ?></td>
         <td align="right">Created By:&nbsp;<?php echo $cr_user->fields["fullname"]; ?></td>
       </tr>
       <tr class="row_even">
         <td colspan="2"> <?php
            if ($priv > 2 || $inv->fields["approved"] == "N") { ?>
               <a href="ed_inv.php?action=add_manual&inv_number=<?php echo $inv_number; ?>">
                  <img src="images/add_line_xp.gif" alt="Add Line Item" border="0"></a>
               <a href="ed_inv.php?action=add_from_po&inv_number=<?php echo $inv_number; ?>">
                  <img src="images/add_from_po_xp.gif" alt="Add Line from PO" border="0"></a>
               <a href="ed_inv.php?action=comments&inv_number=<?php echo $inv_number; ?>">
                  <img src="images/comments_xp.gif" alt="Add/Edit Comments" border="0"></a> <?php
            }
            if ($priv < 3 && $inv->fields["approved"] == "N") { ?>
               <a href="ed_inv.php?action=get_approval&inv_number=<?php echo $inv_number; ?>">
                  <img src="images/get_approval_xp.gif" border="0" alt="Submit Invoice for Approval"></a> <?php
            }
            if ($priv > 2 && $inv->fields["approved"] == "N") { ?>
               <a href="ed_inv.php?action=approve&inv_number=<?php echo $inv_number; ?>">
                  <img src="images/approve_xp.gif" border="0" alt="Approve Invoice"></a> <?php
            } ?>
            <a href="ed_inv.php?action=close_invoice&inv_number=<?php echo $inv_number; ?>">
               <img src="images/close_inv_xp.gif" alt="Close Invoice" border="0"></a>
         </td>
       </tr>
     </table>
   <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
      <td align="center"><b>Item</b></td>
      <td><b>Date</b></td>
      <td><b>Recv By</b></td>
      <td align="center"><b>Qty</b></td>
      <td><b>Description</b></td>
      <td align="center"><b>Taxable</b></td>
      <td align="right"><b>Price</b></td>
      <td align="right"><b>Amount</b></td>
    </tr> <?php
      $inv_total = 0;
      $tax1_total = 0;
      $i = 1;
      while (!$inv_lines->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
         if ($priv > 2 || $inv->fields["approved"] == "N") {
            echo "<td align=\"center\"><a href=\"ed_inv.php?action=edit_line&inv_number=$inv_number&id="
                 . $inv_lines->fields["id"]
                 . "\"><img src=\"images/edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
         } else {
            echo "<td align=\"center\">$i</td>";
         }
         echo "<td>" . display_date($inv_lines->fields["rcv_date"]) . "</td>";
         echo "<td>" . $inv_lines->fields["rcv_by"] . "</td>";
         echo "<td align=\"center\">" . $inv_lines->fields["qty"] . "</td>";
         echo "<td>" . $inv_lines->fields["descrip"] . "</td>";
         echo "<td align=\"center\">" . $inv_lines->fields["taxable"] . "</td>";
         echo "<td align=\"right\">" . $inv_lines->fields["unit_price"] . "</td>";
         echo "<td align=\"right\">" . $inv_lines->fields["amount"] . "</td>";
         echo "</tr>";
         $inv_total += $inv_lines->fields["amount"];
         if ($inv_lines->fields["taxable"] == "Y") {
            $tax1_total += $inv_lines->fields["amount"];
         }
         $i++;
         $inv_lines->MoveNext();
      }
      if ($org->fields["tax_exempt"] == "Y") {
         $tax1 = 0;
         $tax2 = 0;
      } else if ($inv->fields["open"] == "N") {
         $tax1 = $inv->fields["tax1"];
         $tax2 = $inv->fields["tax2"];
      } else {
         $tax1 = round($tax1_total * $cfg["tax1"], 2);
         $tax2 = round($inv_total * $cfg["tax2"], 2);
      }
      $inv_total = $inv_total + $tax1 + $tax2; ?>
      <tr class="row_head">
      <td align="right" colspan="7"><b><?php echo $cfg["tax1_name"]; ?>:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $tax1); ?>
      </tr>
      <tr class="row_head">
      <td align="right" colspan="7"><b><?php echo $cfg["tax2_name"]; ?>:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $tax2); ?>
      </tr>
      <tr class="row_head">
         <td align="right" colspan="7"><b>Invoice Total:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $inv_total); ?>
      </tr>
      <tr class="row_even">
         <td colspan="8">&nbsp;</td> 
      </tr>
      <tr class="row_head">
         <td align="right" colspan="8">
            <a href="ed_inv.php"><img src="images/edit_btn.gif" border="0" alt="Edit"></a>another Invoice.
         </td>
      </tr>
  </table> <?php
} ?>

<?php
function view_inv($db, $inv_number, $from_search = FALSE) {
   global $cfg, $username, $priv;
   if (!$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($inv->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice number $inv_number not found.</td></tr></table>";
      inv_form($db);
      return FALSE;
   }
   $org_id = $inv->fields["organization"];
   $cr_user_id = $inv->fields["created_by"];
   $org = $db->Execute("SELECT name, tax_exempt FROM organization WHERE id=$org_id");
   $cr_user = $db->Execute("SELECT fullname FROM users WHERE username='$cr_user_id'");
   $inv_lines = $db->Execute("SELECT * FROM inv_lines WHERE inv_number=$inv_number ORDER BY id"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
       <tr class="row_head"> 
         <td nowrap><b>View Invoice Information</b></td>
         <td align="right">Invoice Number:&nbsp;<?php echo $inv_number; ?></td>
       </tr>
       <tr class="row_even">
         <td> <?php
         if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "N") { ?>
            &nbsp;&nbsp;Status:<img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
         } else if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "Y") { ?>
            &nbsp;&nbsp;Status:<img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
         } else { ?>
            &nbsp;&nbsp;Status:<img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
         }
         if ($priv > 1 && $inv->fields["open"] == "Y") { ?>
            <a href="ed_inv.php?action=edit&inv_number=<?php echo $inv_number; ?>"><img src="images/edit_btn.gif" border="0" alt="Edit"></a> <?php
         }
         if ($priv > 1 && $inv->fields["approved"] == "Y") { ?>
            <a href="print_inv.php?inv_number=<?php echo $inv_number; ?>"><img src="images/print_btn.gif" border="0" alt="Print"></a> <?php
         } ?>
         </td>
         <td align="right">Date:&nbsp;<?php echo display_date($inv->fields["date"]); ?></td>
       </tr>
       <tr class="row_even"> 
         <td>&nbsp;&nbsp;Organization:&nbsp;<?php echo $org->fields["name"]; ?></td>
         <td align="right">Created By:&nbsp;<?php echo $cr_user->fields["fullname"]; ?></td>
       </tr>
     </table>
   <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
      <td align="center"><b>Item</b></td>
      <td><b>Date</b></td>
      <td><b>Recv By</b></td>
      <td align="center"><b>Qty</b></td>
      <td><b>Description</b></td>
      <td align="center"><b>Taxable</b></td>
      <td align="right"><b>Price</b></td>
      <td align="right"><b>Amount</b></td>
    </tr> <?php
      $inv_total = 0;
      $tax1_total = 0;
      $i = 1;
      while (!$inv_lines->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
         echo "<td align=\"center\">$i</td>";
         echo "<td>" . display_date($inv_lines->fields["rcv_date"]) . "</td>";
         echo "<td>" . $inv_lines->fields["rcv_by"] . "</td>";
         echo "<td align=\"center\">" . $inv_lines->fields["qty"] . "</td>";
         echo "<td>" . $inv_lines->fields["descrip"] . "</td>";
         echo "<td align=\"center\">" . $inv_lines->fields["taxable"] . "</td>";
         echo "<td align=\"right\">" . $inv_lines->fields["unit_price"] . "</td>";
         echo "<td align=\"right\">" . $inv_lines->fields["amount"] . "</td>";
         echo "</tr>";
         $inv_total += $inv_lines->fields["amount"];
         if ($inv_lines->fields["taxable"] == "Y") {
            $tax1_total += $inv_lines->fields["amount"];
         }
         $i++;
         $inv_lines->MoveNext();
      }
      if ($org->fields["tax_exempt"] == "Y") {
         $tax1 = 0;
         $tax2 = 0;
      } else if ($inv->fields["open"] == "N") {
         $tax1 = $inv->fields["tax1"];
         $tax2 = $inv->fields["tax2"];
      } else {
         $tax1 = round($tax1_total * $cfg["tax1"], 2);
         $tax2 = round($inv_total * $cfg["tax2"], 2);
      }
      $inv_total = $inv_total + $tax1 + $tax2; ?>
      <tr class="row_head">
         <td align="right" colspan="7"><b><?php echo $cfg["tax1_name"]; ?>:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $tax1); ?>
      </tr>
      <tr class="row_head">
         <td align="right" colspan="7"><b><?php echo $cfg["tax2_name"]; ?>:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $tax2); ?>
      </tr>
      <tr class="row_head">
         <td align="right" colspan="7"><b>Invoice Total:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $inv_total); ?>
      </tr>
      <tr class="row_even">
         <td colspan="8">&nbsp;</td> 
      </tr>
      <tr class="row_head">
         <td align="right" colspan="8"> <?php
         if ($from_search == TRUE ) { ?>
            <a href="search_inv.php"><img src="images/search_btn.gif" border="0" alt="Edit"></a> <?php
         } else { ?>
            <a href="ed_inv.php"><img src="images/edit_btn.gif" border="0" alt="Edit"></a>another Invoice. <?php
         } ?>
         </td>
      </tr>
  </table> <?php
} ?>

<?php
function new_line_item($inv_number) {
  global $cfg; ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_inv.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="10"><b>Add Line Item to Invoice Number: <?php echo $inv_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Rcv Date:</td>
      <td> 
        <input type="text" name="rcv_date" size="12"
           value="<?php echo date($cfg["date_arg"]); ?>">
      </td>
      <td align="right">Rcv By:</td>
      <td> 
        <input type="text" name="rcv_by" size="16">
      </td>
      <td align="right">Qty:</td>
      <td> 
        <input type="text" name="qty" size="5">
      </td>
      <td align="right">Price:</td>
      <td> 
        <input type="text" name="unit_price" size="12">
      </td>
      <td align="right">Taxable:</td>
      <td> 
        <input type="checkbox" name="taxable" value="Y" checked>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="9"> 
        <textarea name="descrip" cols="50" rows="4" wrap="VIRTUAL"></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="10">
         <img src="images/enter_xp.gif" alt="Enter" border="0"
            onClick="if (valid_inv_line_form(document.form2)) { document.form2.submit(); }">
         <img src="images/reset_xp.gif" alt="Reset" border="0"
            onClick="document.form2.reset();">
         <a href="ed_inv.php?action=cancel&inv_number=<?php echo $inv_number; ?>">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
   <input type="hidden" name="action" value="enter">
   <input type="hidden" name="insert_from_po" value="0">
   <input type="hidden" name="override" value="0">
   <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.rcv_date.focus();
  </script> <?php
} ?>

<?php
function edit_line($db, $inv_number, $id) {
   $inv_line = $db->Execute("SELECT * FROM inv_lines WHERE id=$id"); ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_inv.php" method="post" name="form3">
    <tr class="row_head"> 
      <td colspan="10"><b>Edit Line Item from Invoice Number: <?php echo $inv_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Rcv Date:</td>
      <td> 
        <input type="text" name="rcv_date" size="12"
           value="<?php echo display_date($inv_line->fields["rcv_date"]); ?>">
      </td>
      <td align="right">Rcv By:</td>
      <td> 
        <input type="text" name="rcv_by" size="16"
           value="<?php echo $inv_line->fields["rcv_by"]; ?>">
      </td>
      <td align="right">Qty:</td>
      <td> 
        <input type="text" name="qty" size="5"
           value="<?php echo $inv_line->fields["qty"]; ?>">
      </td>
      <td align="right">Price:</td>
      <td> 
        <input type="text" name="unit_price" size="12"
           value="<?php echo $inv_line->fields["unit_price"]; ?>">
      </td>
      <td align="right">Taxable:</td>
      <td><?php
         if ($inv_line->fields["taxable"] == "Y") { ?>
            <input type="checkbox" name="taxable" value="Y" checked> <?php
         } else { ?>
            <input type="checkbox" name="taxable" value="Y"> <?php
         } ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="9">
        <textarea name="descrip" cols="50" rows="4" wrap="virtual"><?php echo $inv_line->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="10">
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_inv_line_form(document.form3)) { document.form3.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Line Item ?')) { window.location='ed_inv.php?action=delete_line&id=<?php echo $id; ?>&inv_number=<?php echo $inv_number; ?>'; }">
         <img src="images/reset_xp.gif" alt="Reset" border="0"
            onClick="document.form3.reset();">
         <a href="ed_inv.php?action=cancel&inv_number=<?php echo $inv_number; ?>">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="update_line">
  <input type="hidden" name="id" value="<?php echo $id; ?>">
  <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form3.rcv_date.focus();
  </script> <?php
} ?>

<?php
function select_po($db, $inv_number, $page) {
global $cfg;
   $query = "SELECT po.po_number, po.date, po.open, po.approved,"
          . " organization.name, vendor.name"
          . " FROM po, organization, vendor"
          . " WHERE po.vendor = vendor.id"
          . " AND po.organization = organization.id"
          . " ORDER BY po.po_number DESC";
   if (!$summary = $db->PageExecute($query, $cfg["lpp"], $page)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
    <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><b>Select PO Number</b></td>
         <td><b>Date</b></td>
         <td><b>Organization</b></td>
         <td><b>Vendor</b></td>
         <td align="center"><b>Status</b></td>
      </tr> <?php
      $i = 1;
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?>
         <td>
            <a href="ed_inv.php?action=select_line&inv_number=<?php echo $inv_number; ?>&po_number=<?php echo $summary->fields[0]; ?>"><img src="images/select_btn.gif" border="0" alt="Select"></a>
            <?php echo $summary->fields["po_number"]; ?>
         </td>
         <td><?php echo display_date($summary->fields["date"]); ?></td>
         <td><?php echo $summary->fields[4]; ?></td>
         <td><?php echo $summary->fields[5]; ?></td>
         <td align="center"> <?php 
            if ($summary->fields["open"] == "Y" && $summary->fields["approved"] == "N") { ?>
               <img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
            } else if ($summary->fields["open"] == "Y" && $summary->fields["approved"] == "Y") { ?>
               <img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
            } else { ?>
               <img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
            } ?>
         </td>
      </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td align="center"> <?php
            if (!$summary->AtFirstPage()) { ?>
               <a href="ed_inv.php?action=page_po&inv_number=<?php echo $inv_number; ?>&page=<?php echo $summary->AbsolutePage() - 1; ?>">
                  <img src="images/prev_btn.gif" border="0" alt="Previous"></a> <?php
            }
            if (!$summary->AtLastPage()) { ?>
               <a href="ed_inv.php?action=page_po&inv_number=<?php echo $inv_number; ?>&page=<?php echo $summary->AbsolutePage() + 1; ?>">
                  <img src="images/next_btn.gif" border="0" alt="Next"></a> <?php
            } ?>
         </td>
      </tr>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head"> <?php
         if ($summary->AbsolutePage() == -1) {
            echo "<td>&nbsp;</td>";
         } else {
            echo "<td>Page: " . $summary->AbsolutePage() . "</td>";
         } ?>
         <td align="right">
            Select a Purchase Order
         </td>
      </tr>
   </table> <?php
} ?>

<?php
function select_line($db, $inv_number, $po_number) {
   $line_items = $db->Execute("SELECT * FROM line_items WHERE po_number=$po_number ORDER BY id"); ?>
   <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
      <td><b>Select Item</b></td>
      <td align="center"><b>Qty</b></td>
      <td align="center"><b>Avail</b></td>
      <td><b>Unit</b></td>
      <td><b>Description</b></td>
      <td><b>Alloc</b></td>
      <td align="right"><b>Price</b></td>
      <td align="right"><b>Amount</b></td>
      <td align="center"><b>Rcv</b></td>
      <td align="center"><b>Inv</b></td>
    </tr> <?php
    $i = 1;
    while (!$line_items->EOF) {
      if ($i % 2 == 0) {
         echo "<tr class=\"row_even\">";
      } else {
         echo "<tr class=\"row_odd\">";
      }
      echo "<td><a href=\"ed_inv.php?action=fill_form&inv_number=$inv_number&po_line_id="
           . $line_items->fields["id"]
           . "\"><img src=\"images/select_btn.gif\" border=\"0\" alt=\"Select\"></a>";
      echo "$i</td>";
      echo "<td align=\"center\">" . $line_items->fields["qty"] . "</td>";
      echo "<td align=\"center\">" . $line_items->fields["inv_qty"] . "</td>";
      echo "<td>" . $line_items->fields["unit"] . "</td>";
      echo "<td>" . $line_items->fields["descrip"] . "</td>";
      echo "<td>" . $line_items->fields["alloc"] . "</td>";
      echo "<td align=\"right\">" . $line_items->fields["unit_price"] . "</td>";
      echo "<td align=\"right\">" . $line_items->fields["amount"] . "</td>";
      if ($line_items->fields["received"] == "Y") {
         echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"Received\"></td>";
      } else {
         echo "<td align=\"center\"><img src=\"images/no.gif\" border=\"0\" alt=\"Not Received\"></a></td>";
      }
      switch ($line_items->fields["invoiced"]) {
         case "Y":
            echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"All Invoiced\"></td>";
            break;
         case "P":
            echo "<td align=\"center\"><img src=\"images/part_yes.gif\" border=\"0\" alt=\"Some Invoiced\"></td>";
            break;
         case "N":
            echo "<td align=\"center\"><img src=\"images/no.gif\" border=\"0\" alt=\"None Invoiced\"></a></td>";
            break;
      }
      echo "</tr>";
      $i++;
      $line_items->MoveNext();
    } ?>
    </table>
    <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
       <td align="right">
          Select a Line Item
       </td>
    </tr>
  </table> <?php
} ?>

<?php
function fill_form($db, $inv_number, $po_line_id, $override = 0) {
   global $cfg;
   $po_line_item = $db->Execute("SELECT * FROM line_items WHERE id=$po_line_id");
   if ($override == 0) {
      if ($po_line_item->fields["inv_qty"] == 0) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Records indicate there are 0 (zero)"
            . " units available. No Invoice line item was added.<br>"
            . "If you choose Ignore, the Invoice line will be added but no inventory adjustments will be made."
            . "<a href=\"ed_inv.php?action=override_fill_form&inv_number=$inv_number&po_line_id=$po_line_id\"><img src=\"images/ignore_btn.gif\" border=\"0\" alt=\"Override\"></a></td></tr></table>";
         edit_form($db, $inv_number);
         return;
      }
   }
   echo "<table class=\"notice\" width=\"100%\"><tr><td>This information is extracted from"
        . " purchase order ". $po_line_item->fields["po_number"] . "."
        . " Edit the information as required then click Enter.</td></tr></table>"; ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_inv.php" method="post" name="form4">
    <tr class="row_head"> 
      <td colspan="10"><b>Add Line Item to Invoice Number <?php echo $inv_number; ?> from Purchase Order <?php echo $po_line_item->fields["po_number"]; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Rcv Date:</td>
      <td> 
        <input type="text" name="rcv_date" size="12"
           value="<?php echo date($cfg["date_arg"]); ?>">
      </td>
      <td align="right">Rcv By:</td>
      <td> 
        <input type="text" name="rcv_by" size="16"
           value="<?php echo $po_line_item->fields["alloc"]; ?>">
      </td>
      <td align="right">Qty:</td>
      <td> 
        <input type="text" name="qty" size="5"
           value="<?php echo $po_line_item->fields["inv_qty"]; ?>">
      </td>
      <td align="right">Price:</td>
      <td> 
        <input type="text" name="unit_price" size="12"
           value="<?php printf("%01.2f", round($po_line_item->fields["unit_price"] * $cfg["markup"] + $po_line_item->fields["unit_price"], 2)); ?>">
      </td>
      <td align="right">Taxable:</td>
      <td> 
        <input type="checkbox" name="taxable" value="Y" checked>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="9"> 
        <textarea name="descrip" cols="50" rows="4" wrap="virtual"><?php echo $po_line_item->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="10">
         <img src="images/enter_xp.gif" alt="Enter" border="0"
            onClick="if (valid_inv_line_form(document.form4)) { document.form4.submit(); }">
         <img src="images/reset_xp.gif" alt="Reset" border="0"
            onClick="document.form4.reset();">
         <a href="ed_inv.php?action=cancel&inv_number=<?php echo $inv_number; ?>">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="enter">
  <input type="hidden" name="insert_from_po" value="1">
  <input type="hidden" name="override" value="<?php echo $override; ?>">
  <input type="hidden" name="po_line_id" value="<?php echo $po_line_id; ?>">
  <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form4.rcv_date.focus();
  </script> <?php
} ?>

<?php
function edit_comments($inv_number, $comments) { ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_inv.php" method="post" name="form5">
    <tr class="row_head"> 
      <td colspan="2"><b>Add Comments to Invoice Number <?php echo $inv_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Comments:</td>
      <td> 
        <textarea cols="65" rows="4" name="comments" wrap="hard"><?php echo $comments->fields["comments"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="2">
         <img src="images/enter_xp.gif" alt="Enter" border="0"
            onClick="document.form5.submit();">
         <img src="images/reset_xp.gif" alt="Reset" border="0"
            onClick="document.form5.reset();">
         <a href="ed_inv.php?action=cancel&inv_number=<?php echo $inv_number; ?>">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="enter_comments">
  <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form5.comments.focus();
  </script> <?php
} ?>

<?php
function select_super($db, $inv_number) {
   if (!$supers = $db->Execute("SELECT fullname, email FROM users WHERE priv>2 ORDER BY fullname")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_inv.php" method="post" name="form7">
    <tr class="row_head"> 
      <td align="center" colspan="3" nowrap><b>Select Approving Supervisor</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Select Supervisor:</td>
      <td>
         <?php echo $supers->GetMenu("email", "", TRUE, FALSE, 0, "onChange='document.form7.submit();'"); ?> 
      </td>
    </tr>
   <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
   <input type="hidden" name="action" value="mail_approval">
   </form>
</table> <?php
} ?>

<?php
$action = strtolower($action);
if ($priv >= 1 && $action == "view") {
   view_inv($db, $inv_number);
   require("footer.inc.php");
   exit();
}
if ($priv >= 1 && $action == "view_from_search") {
   view_inv($db, $inv_number, TRUE);
   require("footer.inc.php");
   exit();
}
if ($priv > 1) {
   switch ($action) {
      case "add_manual":
         new_line_item($inv_number);
         break;
      case "add_from_po":
         select_po($db, $inv_number, 1);
         break;
      case "approve":
         if ($priv > 2) {
            if (!$db->Execute("UPDATE invoices SET approved='Y', approved_by='$username' WHERE inv_number='$inv_number'")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
            $cr_username = $db->Execute("SELECT created_by FROM invoices WHERE inv_number='$inv_number'");
            if ($cr_username->fields["created_by"] != $username) {
               $query = "SELECT email FROM users WHERE username='" . $cr_username->fields["created_by"] . "'";
               $cr_email = $db->Execute($query);
               mail($cr_email->fields["email"],
                    "Invoice approval",
                    "Invoice $inv_number has been approved by $fullname",
                    "From: AssetMan@" . $_SERVER["SERVER_NAME"] . "\n");
               echo "<table class=\"notice\" width=\"100%\"><tr><td>An Invoice approval notification has been E-Mailed to "
                    . $cr_email->fields["email"] . "</td></tr></table>";
            }
         } else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
         }
         edit_form($db, $inv_number);
         break;
      case "page_po":
         select_po($db, $inv_number, $page);
         break;
      case "select_line":
         select_line($db, $inv_number, $po_number);
         break;
      case "fill_form":
         fill_form($db, $inv_number, $po_line_id);
         break;
      case "override_fill_form":
         fill_form($db, $inv_number, $po_line_id, $override = 1);
         break;
      case "enter":
         if (!isset($taxable)) {
            $taxable = "N";
         }
         $unit_price = sprintf("%01.2f", $unit_price);
         $amount = sprintf("%01.2f", $qty * $unit_price);
         if ($insert_from_po == 1 && $override == 0) {
            $po_line_item = $db->Execute("SELECT qty, inv_qty FROM line_items WHERE id=$po_line_id");
            $po_qty = $po_line_item->fields["qty"];
            $qty_avail = $po_line_item->fields["inv_qty"];
            $qty_left = $qty_avail - $qty;
            if ($qty_left < 0) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>Records indicate there are only $qty_avail"
                  . " unit(s) available. No Invoice line item was added.<br>"
                  . "If you choose Ignore, the Invoice line will be added and the PO line item status will be updated"
                  . " to indicate 0 (zero) units available and all units invoiced."
                  . "<a href=\"ed_inv.php?action=override_fill_form&inv_number=$inv_number&po_line_id=$po_line_id\"><img src=\"images/ignore_btn.gif\" border=\"0\" alt=\"Override\"></a></td></tr></table>";
               edit_form($db, $inv_number);
               break;
            }
            $invoiced = "N";
            if ($qty_left > 0 && $qty_left < $po_qty) {
               $invoiced = "P";
            }
            if ($qty_left == 0) {
               $invoiced = "Y";
            }
            $query = "UPDATE line_items SET"
                   . " inv_qty='$qty_left', invoiced='$invoiced' WHERE id=$po_line_id";
            if (!$db->Execute($query)) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
         }
         if ($insert_from_po == 1 && $override == 1) {
            if (!$db->Execute("UPDATE line_items SET inv_qty='0', invoiced='Y' WHERE id=$po_line_id")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
         }
         $rcv_date = valid_date($rcv_date);
         $id = $db->GenID("inv_lines_seq");
         $query = "INSERT INTO inv_lines (id, inv_number, rcv_date, rcv_by, qty, descrip, unit_price, amount, taxable)"
                . " VALUES ('$id', '$inv_number', '$rcv_date', " . $db->QMagic($rcv_by) . ", '$qty', "
                . $db->QMagic($descrip) . ", '$unit_price', '$amount', '$taxable')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $inv_number);
         break;
      case "cancel":
         edit_form($db, $inv_number);
         break;
      case "edit":
         edit_form($db, $inv_number);
         break;
      case "edit_line":
         edit_line($db, $inv_number, $id);
         break;
      case "get_approval":
         select_super($db, $inv_number);
         break;
      case "mail_approval":
         mail($email,
              "Invoice approval request",
              "Invoice $inv_number has been submitted by $fullname for your approval.",
              "From: AssetMan@" . $_SERVER["SERVER_NAME"] . "\n");
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Your request has been forwarded to $email."
            . " You will be notifed by E-Mail when this Invoice has been approved.</td></tr></table>";
         edit_form($db, $inv_number);
         break;
      case "update_line":
         if (!isset($taxable)) {
            $taxable = "N";
         }
         $unit_price = sprintf("%01.2f", $unit_price);
         $amount = sprintf("%01.2f", $qty * $unit_price);
         $rcv_date = valid_date($rcv_date);
         $query = "UPDATE inv_lines SET"
                . " inv_number='$inv_number', rcv_date='$rcv_date', rcv_by=" . $db->QMagic($rcv_by) . ", "
                . " qty='$qty', descrip=" . $db->QMagic($descrip) . ", unit_price='$unit_price',"
                . " amount='$amount', taxable='$taxable'"
                . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $inv_number);
         break;
      case "delete_line":
         if (!$db->Execute("DELETE FROM inv_lines WHERE id=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $inv_number);
         break;
      case "close_invoice":
         $query = "SELECT SUM(inv_lines.amount)"
                . " FROM inv_lines"
                . " WHERE inv_number=$inv_number"
                . " AND taxable='Y'";
         if (!$inv_tax1_total = $db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         $tax1_total = $inv_tax1_total->fields[0];
         $query = "SELECT invoices.open, invoices.organization, invoices.approved,"
                . " SUM(inv_lines.amount), organization.tax_exempt"
                . " FROM invoices, inv_lines, organization"
                . " WHERE invoices.inv_number=$inv_number"
                . " AND inv_lines.inv_number=$inv_number"
                . " AND invoices.organization=organization.id"
                . " GROUP BY invoices.open, invoices.organization, invoices.approved, organization.tax_exempt";
         if (!$inv_summary_info = $db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if ($inv_summary_info->fields["approved"] == "N") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice $inv_number has not yet been approved!</td></tr></table>";
            edit_form($db, $inv_number);
            break;
         }
         $inv_total = $inv_summary_info->fields[3];
         if ($inv_summary_info->fields["tax_exempt"] == "Y") {
            $tax1 = 0;
            $tax2 = 0;
         } else {
            $tax1 = round($tax1_total * $cfg["tax1"], 2);
            $tax2 = round($inv_total * $cfg["tax2"], 2);
         }
         $total = sprintf("%01.2f", $inv_total + $tax1 + $tax2);
         if (!$db->Execute("UPDATE invoices SET open='N', tax1='$tax1', tax2='$tax2', total='$total' WHERE inv_number=$inv_number")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $inv_number);
         break;
      case "comments":
         $comments = $db->Execute("SELECT comments FROM invoices WHERE inv_number=$inv_number");
         edit_comments($inv_number, $comments);
         break;
      case "enter_comments":
         if (!$db->Execute("UPDATE invoices SET comments=" . $db->QMagic($comments) . " WHERE inv_number=$inv_number")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice comments updated OK.</td></tr></table>";
         edit_form($db, $inv_number);
         break;
      default:
         inv_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
