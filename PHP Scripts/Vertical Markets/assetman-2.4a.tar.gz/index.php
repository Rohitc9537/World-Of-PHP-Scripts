<?php require("common.inc.php"); ?>
<table border="0" cellpadding="10" width="100%"><tr><td>
   <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
         <td align="left">
            <a href="http://www.bctree.com/~assetman/index.htm">
               <img src="images/assetman.gif" alt="Visit the AssetMan Web Site" border="0"></a>
            <hr>
         </td>
         <td align="center">
            <img src="images/ass.gif" alt="Festus the AssetMan Ass" border="0">
         </td>
      </tr>
   </table>
   <p class="default"><?php echo $cfg["signature"]; ?></p>
   <p class="default">Welcome to the Information Services Materiel Management System; <b>"AssetMan".</b><br>
   While primarily intended to be a useful tool for business, AssetMan also serves
   to demonstrate an application platform combining web server, web client, server-side
   and client-side scripting, and database engine components.</p>
   <p class="default">The design goals for AssetMan have been achieved and then some.
   No new functionality is planned at this time although maintenance work continues.</p>
   <p class="default">Navigate AssetMan using the menubar at the top of this window or choose
   a common task from one of these quick pick buttons.</p>
   <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
         <td align="center">
            <a href="new_asset.php">
               <img src="images/new_asset_xp.gif" alt="New Asset" border="0"></a>
            <a href="new_po.php">
               <img src="images/new_po_xp.gif" alt="New Purchase Order" border="0"></a>
            <a href="search_po.php?action=search_all&order_by=po_number&order=DESC">
               <img src="images/po_list_xp.gif" alt="Purchase Order List" border="0"></a>
            <a href="new_inv.php">
               <img src="images/new_inv_xp.gif" alt="New Invoice" border="0"></a>
            <a href="search_inv.php?action=search_all&order_by=inv_number&order=DESC">
               <img src="images/inv_list_xp.gif" alt="Invoice List" border="0"></a>
            <a href="passwd.php">
               <img src="images/ed_pwd_xp.gif" alt="Edit Password" border="0"></a>
         </td>
      </tr>
   </table>
</td></tr></table>
<?php require("footer.inc.php"); ?>
