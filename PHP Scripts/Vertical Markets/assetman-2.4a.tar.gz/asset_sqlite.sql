BEGIN TRANSACTION;
CREATE TABLE config (
  id integer NOT NULL default '0',
  name varchar(50) NOT NULL default '',
  tag1 integer NOT NULL default '0',
  tag2 integer NOT NULL default '0',
  tag3 integer NOT NULL default '0',
  tag4 integer NOT NULL default '0',
  tag5 integer NOT NULL default '0',
  tag6 integer NOT NULL default '0',
  tag7 integer NOT NULL default '0',
  tag8 integer NOT NULL default '0',
  comments text
);
INSERT INTO config VALUES(1,'--- Select Configuration ---',0,0,0,0,0,0,0,0,'dummy record');
CREATE TABLE config_seq (
  id integer NOT NULL default '0'
);
INSERT INTO config_seq VALUES(1);
CREATE TABLE equipment (
  tag integer NOT NULL default '0',
  make varchar(30) NOT NULL default '',
  model varchar(30) NOT NULL default '',
  serial varchar(30) NOT NULL default '',
  vendor integer NOT NULL default '0',
  price decimal(9,2) NOT NULL default '0.00',
  warranty date default NULL,
  descrip text,
  equip_type integer default NULL
);
CREATE TABLE equipment_type (
  id integer NOT NULL default '0',
  descrip varchar(48) NOT NULL default ''
);
INSERT INTO equipment_type VALUES(1,'--- Select Equipment Type ---');
CREATE TABLE equipment_type_seq (
  id integer NOT NULL default '0'
);
INSERT INTO equipment_type_seq VALUES(1);
CREATE TABLE inv_lines (
  id integer NOT NULL default '0',
  inv_number integer NOT NULL default '0',
  rcv_date date NOT NULL default '0000-00-00',
  rcv_by varchar(30) default NULL,
  qty decimal(9,1) NOT NULL default '0.0',
  descrip varchar(255) NOT NULL default '',
  unit_price decimal(9,2) NOT NULL default '0.00',
  amount decimal(9,2) NOT NULL default '0.00',
  taxable char(1) NOT NULL default 'Y'
);
CREATE TABLE inv_lines_seq (
  id integer NOT NULL default '0'
);
INSERT INTO inv_lines_seq VALUES(0);
CREATE TABLE invoices (
  inv_number integer NOT NULL default '0',
  date date NOT NULL default '0000-00-00',
  organization integer NOT NULL default '0',
  gl_credit varchar(12) NOT NULL default '',
  gl_debit varchar(12) NOT NULL default '',
  comments varchar(255) default NULL,
  open char(1) NOT NULL default 'Y',
  tax1 decimal(9,2) NOT NULL default '0.00',
  tax2 decimal(9,2) NOT NULL default '0.00',
  total decimal(9,2) NOT NULL default '0.00',
  created_by varchar(16) default NULL,
  approved char(1) NOT NULL default 'N',
  approved_by varchar(16) default NULL
);
CREATE TABLE invoices_seq (
  id integer NOT NULL default '0'
);
INSERT INTO invoices_seq VALUES(10000);
CREATE TABLE item_master (
  id integer NOT NULL default '0',
  make varchar(30) NOT NULL default '',
  model varchar(30) NOT NULL default '',
  serial varchar(50) NOT NULL default '',
  po_number integer NOT NULL default '0',
  date date NOT NULL default '0000-00-00',
  warranty date NOT NULL default '0000-00-00',
  descrip text
);
CREATE TABLE item_master_seq (
  id integer NOT NULL default '0'
);
INSERT INTO item_master_seq VALUES(0);
CREATE TABLE line_items (
  id integer NOT NULL default '0',
  po_number integer NOT NULL default '0',
  qty integer NOT NULL default '0',
  inv_qty integer NOT NULL default '0',
  unit varchar(10) default 'each',
  descrip varchar(255) NOT NULL default '',
  alloc varchar(16) default NULL,
  unit_price decimal(9,2) NOT NULL default '0.00',
  amount decimal(9,2) NOT NULL default '0.00',
  received char(1) NOT NULL default 'N',
  invoiced char(1) NOT NULL default 'N'
);
CREATE TABLE line_items_seq (
  id integer NOT NULL default '0'
);
INSERT INTO line_items_seq VALUES(0);
CREATE TABLE organization (
  id integer NOT NULL default '0',
  name varchar(50) NOT NULL default '',
  address1 varchar(50) NOT NULL default '',
  address2 varchar(50) default NULL,
  city varchar(30) NOT NULL default '',
  province varchar(10) NOT NULL default '',
  country varchar(30) default '',
  p_code varchar(16) NOT NULL default '',
  contact varchar(50) NOT NULL default '',
  phone varchar(16) default NULL,
  fax varchar(16) default NULL,
  email varchar(50) default NULL,
  tax_exempt char(1) NOT NULL default 'N'
);
INSERT INTO organization VALUES(1,'--- Select Organization ---','dummy record','','city','province','country','p_code','','','','','N');
CREATE TABLE organization_seq (
  id integer NOT NULL default '0'
);
INSERT INTO organization_seq VALUES(1);
CREATE TABLE po (
  po_number integer NOT NULL default '0',
  date date NOT NULL default '0000-00-00',
  vendor integer NOT NULL default '0',
  organization integer NOT NULL default '0',
  open char(1) NOT NULL default 'Y',
  created_by varchar(16) default NULL,
  approved char(1) NOT NULL default 'N',
  approved_by varchar(16) default NULL
);
CREATE TABLE po_seq (
  id integer NOT NULL default '0'
);
INSERT INTO po_seq VALUES(10000);
CREATE TABLE tag (
  tag integer NOT NULL default '0',
  date date NOT NULL default '0000-00-00',
  po integer NOT NULL default '0',
  organization integer NOT NULL default '0',
  config integer NOT NULL default '0'
);
CREATE TABLE users (
  username varchar(16) NOT NULL default '',
  password varchar(48) NOT NULL default '',
  priv char(1) NOT NULL default '1',
  fullname varchar(48) NOT NULL default '',
  email varchar(64) default NULL
);
INSERT INTO users VALUES('admin','21232f297a57a5a743894a0e4a801fc3',4,'AssetMan Administrator','admin@domain.com');
INSERT INTO users VALUES('super','1b3231655cebb7a1f783eddf27d254ca',3,'Supervisor','super@domain.com');
INSERT INTO users VALUES('write','efb2a684e4afb7d55e6147fbe5a332ee',2,'Read / Write User','write@domain.com');
INSERT INTO users VALUES('read','ecae13117d6f0584c25a9da6c8f8415e',1,'Read Only User','read@domain.com');
CREATE TABLE vendor (
  id integer NOT NULL default '0',
  name varchar(50) NOT NULL default '',
  address1 varchar(50) NOT NULL default '',
  address2 varchar(50) default NULL,
  city varchar(30) NOT NULL default '',
  province varchar(10) NOT NULL default '',
  country varchar(30) default '',
  p_code varchar(16) NOT NULL default '',
  attn varchar(50) default NULL,
  main_phone varchar(16) default NULL,
  main_fax varchar(16) default NULL,
  main_email varchar(50) default NULL,
  main_www varchar(50) default NULL,
  tech_phone varchar(16) default NULL,
  tech_fax varchar(16) default NULL,
  tech_email varchar(50) default NULL,
  tech_www varchar(50) default NULL,
  comments text
);
INSERT INTO vendor VALUES(1,'--- Select Vendor ---','dummy record','','city','province','country','p_code','','','','','','','','','',NULL);
CREATE TABLE vendor_seq (
  id integer NOT NULL default '0'
);
INSERT INTO vendor_seq VALUES(1);
CREATE INDEX config_id_key ON config (id);
CREATE INDEX equipment_tag_key ON equipment (tag);
CREATE INDEX equipment_type_id_key ON equipment_type (id);
CREATE INDEX inv_lines_id_key ON inv_lines (id);
CREATE INDEX inv_lines_inv_number_key ON inv_lines (inv_number);
CREATE INDEX invoices_inv_number_key ON invoices (inv_number);
CREATE INDEX item_master_id_key ON item_master (id);
CREATE INDEX item_master_serial_key ON item_master (serial);
CREATE INDEX line_items_id_key ON line_items (id);
CREATE INDEX line_items_po_number_key ON line_items (po_number);
CREATE INDEX orgainzation_id_key ON organization (id);
CREATE INDEX po_po_number_key ON po (po_number);
CREATE INDEX tag_tag_key ON tag (tag);
CREATE INDEX users_priv_key ON users (priv);
CREATE INDEX users_username_key ON users (username);
CREATE INDEX vendor_id_key ON vendor (id);
COMMIT;
