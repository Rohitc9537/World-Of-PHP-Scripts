<?php require("common.inc.php"); ?>

<?php
function paint_table(&$summary) { ?>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><b>Make</b></td>
         <td><b>Model</b></td>
         <td><b>Serial</b></td>
         <td><b>Date</b></td>
         <td><b>PO</b></td>
         <td><b>Description</b></td>
      </tr> <?php
      $i = 1;
      $summary->Move(0);
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?>
         <td>
            <a href="search_item.php?action=show_single&id=<?php echo $summary->fields["id"]; ?>">
               <?php echo $summary->fields["make"]; ?></a>
         </td>
         <td><?php echo $summary->fields["model"]; ?></td>
         <td><?php echo $summary->fields["serial"]; ?></td>
         <td><?php echo display_date($summary->fields["date"]); ?></td>
         <td> <?php
            if ($summary->fields["po_number"] != 0) { ?>
               <a href="ed_po.php?action=view_from_search&po_number=<?php echo $summary->fields["po_number"]; ?>">
                  <?php echo $summary->fields["po_number"]; ?></a> <?php
            } else {
               echo "None";
            } ?>
         </td>
         <td><?php echo $summary->fields["descrip"]; ?></td>
      </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td align="center"> <?php
            if (!$summary->AtFirstPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_item.php?action=paged_query&page=<?php echo $summary->AbsolutePage() - 1; ?>">
                  <img src="images/prev_btn.gif" border="0" alt="Previous"></a> <?php
            }
            echo "&nbsp;";
            if (!$summary->AtLastPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_item.php?action=paged_query&page=<?php echo $summary->AbsolutePage() + 1; ?>">
                  <img src="images/next_btn.gif" border="0" alt="Next"></a> <?php
            } ?>
         </td>
      </tr>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head"> <?php
         if ($summary->AbsolutePage() == -1) {
            echo "<td>&nbsp;</td>";
         } else {
            echo "<td>Page: " . $summary->AbsolutePage() . "</td>";
         } ?>
         <td align="right">
            <a href="search_item.php?action=print_result"><img src="images/print_btn.gif" alt="Print Results" border="0"></a>
            <a href="search_item.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
         </td>
      </tr>
   </table> <?php
} ?>

<?php
function search_single($db, $serial) {
   $query = "SELECT * FROM item_master WHERE serial='$serial'";
   if (!$item = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($item->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Item with serial number $serial not found.</td></tr></table>";
      search_form($db);
      return FALSE;
   }
   if ($item->RecordCount() > 1) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Multiple items with serial number $serial were found.</td></tr></table>";
      paint_table($item);
      return TRUE;
   }
   show_single($db, $item->fields["id"]);
} ?>

<?php
function show_single($db, $id) { 
   $query = "SELECT * FROM item_master WHERE id=$id";
   if (!$item = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
  <table class="default" border="0" width="100%" cellspacing="0" cellpadding="2">
    <tr class="row_head"> 
      <td colspan="4"><b>Item Master Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3"> 
         <?php echo $item->fields["make"]; ?>
         <a href="ed_item.php?action=edit_id&id=<?php echo $id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3"> 
        <?php echo $item->fields["model"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial:</td>
      <td colspan="3"> 
        <?php echo $item->fields["serial"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> <?php
         if ($item->fields["po_number"] != 0) {
            echo $item->fields["po_number"]; ?>
            <a href="ed_po.php?action=view&po_number=<?php echo $item->fields["po_number"]; ?>"><img src="images/view.gif" border="0" alt="View"></a>
            <a href="ed_po.php?action=edit&po_number=<?php echo $item->fields["po_number"]; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a> <?php
         } else {
            echo "None";
         } ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Receive Date:</td>
      <td> 
        <?php echo display_date($item->fields["date"]); ?>
      </td>
      <td align="right">Warranty Expires:</td>
      <td> 
        <?php echo display_date($item->fields["warranty"]); ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3"> 
        <?php echo $item->fields["descrip"]; ?>
      </td>
    </tr>
    <tr class="row_head">
      <td align="right" colspan="4">
         <a href="search_item.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
      </td>
    </tr>
  </table> <?php
} ?>

<?php
function show_items($db) {
   global $action, $make, $model, $po_number, $descrip,
          $from_date, $to_date, $order_by, $order;
   if ($from_date == "") {
      $from_date = "1980-01-01";
   } else {
      $from_date = valid_date($from_date);
   }
   if ($to_date == "") {
      $to_date = date("Y-m-d");
   } else {
      $to_date = valid_date($to_date);
   }
   if ($make == "") {
      $make = "%";
   } else {
      $make = "%" . $make . "%";
   }
   if ($model == "") {
      $model = "%";
   } else {
      $model = "%" . $model . "%";
   }
   if ($order != "DESC") {
      $order = "ASC";
   }
   $descrip = "%" . $descrip . "%";
   $_SESSION["search_query"] =
      "SELECT * FROM item_master"
      . " WHERE date>='$from_date'"
      . " AND date<='$to_date'";
   if ($action == "search_po") {
      $_SESSION["search_query"] .= " AND po_number=$po_number";
   }
   if ($action == "search_make_model") {
      $_SESSION["search_query"] .= " AND make LIKE '$make' AND model LIKE '$model'";
   }
   if ($action == "search_descrip") {
      $_SESSION["search_query"] .= " AND descrip LIKE '$descrip'";
   }
   $_SESSION["search_query"] .= " ORDER BY $order_by $order";
   if (!$summary = paged_query($db)) {
      search_form($db);
   } else {
      paint_table($summary);
   }
} ?>

<?php
function search_form($db) {
   global $cfg; ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="search_item.php" method="get" name="form1">
      <tr class="row_head">
         <td colspan="5"><b>Search the Item Master Dictionary</b></td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td colspan="4">
            <select name="action">
               <option value="search_none" SELECTED>--- Select Search Type ---</option>
               <option value="search_single">Show a Single Item</option>
               <option value="search_all">Show All Items</option>
               <option value="search_make_model">Show Items by Make and Model</option>
               <option value="search_po">Show Items by Purchase Order</option>
               <option value="search_descrip">Show Items by Description</option>
            </select>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Serial No:</td>
         <td colspan="3">
            <input type="text" name="serial" size="12">
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right" nowrap>From Date:</td>
         <td>
            <input type="text" name="from_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
         <td align="right" nowrap>To Date:</td>
         <td>
            <input type="text" name="to_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Make:</td>
         <td>
            <input type="text" name="make" size="12">            
         </td>
         <td align="right">Model:</td>
         <td>
            <input type="text" name="model" size="12">            
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">PO Number:</td>
         <td colspan="3">
            <input type="text" name="po_number" size="12"></td>         
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Description:</td>
         <td colspan="3">
            <input type="text" name="descrip" size="30">            
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Order By:</td>
         <td colspan="3">
            <input type="radio" name="order_by" value="date" checked>Date &nbsp;&nbsp;
            <input type="radio" name="order_by" value="po_number">PO Number &nbsp;&nbsp;
            <input type="checkbox" name="order" value="DESC">Reverse
         </td>
      </tr>
      <tr class="row_head">
         <td colspan="4">
            Select search type, fill in parameters and click Search...
         </td>
         <td align="right">
            <img src="images/search_xp.gif" alt="Search" border="0"
               onClick="document.form1.submit();">
         </td>
      </tr>
   </form>
   </table> <?php
} ?>

<?php
$action = strtolower($action);
switch ($action) {
   case "print_result": ?>
      <script language="JavaScript">
         window.open("print_html_search_item.php");
      </script> <?php
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Search Results opened in a new browser window.</td></tr></table>";
      break;
   case "search_none":
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a Search Type from the drop menu.</td></tr></table>";
      search_form($db);
      break;
   case "search_single":
      search_single($db, $serial);
      break;
   case "show_single":
      show_single($db, $id);
      break;
   case "search_all":
      show_items($db);
      break;
   case "search_po":
      show_items($db);
      break;
   case "search_make_model":
      show_items($db);
      break;
   case "search_descrip":
      show_items($db);
      break;
   case "paged_query":
      $summary = paged_query($db, $page);
      paint_table($summary);
      break;
   default:
      search_form($db);
}
require("footer.inc.php");
?>
