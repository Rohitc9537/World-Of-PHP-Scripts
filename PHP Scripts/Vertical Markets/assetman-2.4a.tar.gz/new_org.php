<?php require("common.inc.php"); ?>

<?php
function display_form() {
  global $refer; ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="new_org.php" method="post" name="form1">
    <tr class="row_head"> 
      <td colspan="4"><b>New Organization Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td> 
        <input type="text" name="name" size="40">
      </td>
      <td align="right">Tax Exempt?</td>
      <td>
         <input type="checkbox" name="tax_exempt" value="Y">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 1:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="40">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 2:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="40">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">City:</td>
      <td><input type="text" name="city" size="20"></td>
      <td align="right">Province/State:</td>
      <td><input type="text" name="province" size="12"></td>
    </tr>
    <tr class="row_even">
    <td align="right">Country:</td>
      <td><input type="text" name="country" size="20"></td>
      <td align="right">Postal/ZIP Code:</td>
      <td><input type="text" name="p_code" size="12"></td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td> 
        <input type="text" name="contact" size="30">
      </td>
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="phone" size="20">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="email" size="30">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="fax" size="20">
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4"> 
         <img src="images/enter_xp.gif" border="0" alt="Enter"
            onClick="if (valid_org_form(document.form1)) { document.form1.submit(); }">
         <img src="images/reset_xp.gif" border="0" alt="Reset"
            onClick="document.form1.reset();">
         <a href="new_org.php?action=cancel">
            <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
      </td>
    </tr> <?php
   if (isset($refer)) { ?>
      <input type="hidden" name="refer" value="<?php echo $refer; ?>"> <?php
   } ?>
  <input type="hidden" name="action" value="insert">
  </form>
  </table>
  <script language="JavaScript">
     document.form1.name.focus();
  </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Organization Dictionary update cancelled.</td></tr></table>";
         break;
      case "insert":
         if (!valid_char_1($name)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid organization name.</td></tr></table>";
            display_form();
            break;
         }
         if (!isset($tax_exempt)) $tax_exempt = "N";
         $id = $db->GenID("organization_seq");
         $query = "INSERT INTO organization (id, name, address1, address2, city, province, country, p_code, contact, phone, fax, email, tax_exempt)"
                . " VALUES ('$id', " . $db->QMagic($name) . ", " . $db->QMagic($address1) . ", " . $db->QMagic($address2) . ", "
                . $db->QMagic($city) . ", " . $db->QMagic($province) . ", " . $db->QMagic($country) . ", " . $db->QMagic($p_code) . ", "
                . $db->QMagic($contact) . ", '$phone', '$fax', " . $db->QMagic($email) . ", '$tax_exempt')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if (isset($refer)) { ?>
            <script language="JavaScript">
               window.location="<?php echo $refer; ?>";
            </script> <?php
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Organization Dictionary updated OK.<a href=\"new_org.php\"><img src=\"images/add_btn.gif\" border=\"0\" alt=\"Add\"></a> another new organization.</td></tr></table>";
         break;
      default:
         display_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
