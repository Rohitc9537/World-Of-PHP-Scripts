<html>
<head>
<script language="JavaScript">
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function mmLoadMenus() {
  if (window.mm_menu_0212112734_0) return;
  window.mm_menu_0212112734_0 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_0.addMenuItem("Asset","location='new_asset.php'");
  mm_menu_0212112734_0.addMenuItem("Configuration","location='new_config.php'");
  mm_menu_0212112734_0.addMenuItem("Equipment&nbsp;Type","location='new_types.php'");
  mm_menu_0212112734_0.addMenuItem("Organization","location='new_org.php'");
  mm_menu_0212112734_0.addMenuItem("Vendor","location='new_vendor.php'");
   mm_menu_0212112734_0.bgImageUp="images/mmmenu6_130x20_up.gif";
   mm_menu_0212112734_0.bgImageOver="images/mmmenu6_130x20_over.gif";
   mm_menu_0212112734_0.hideOnMouseOut=true;
   mm_menu_0212112734_0.bgColor='#555555';
  window.mm_menu_0212112734_1 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_1.addMenuItem("Asset","location='ed_asset.php'");
  mm_menu_0212112734_1.addMenuItem("Configuration","location='ed_config.php'");
  mm_menu_0212112734_1.addMenuItem("Equipment&nbsp;Type","location='ed_types.php'");
  mm_menu_0212112734_1.addMenuItem("Organization","location='ed_org.php'");
  mm_menu_0212112734_1.addMenuItem("Vendor","location='ed_vendor.php'");
  mm_menu_0212112734_1.addMenuItem("My&nbsp;Password","location='passwd.php'");
   mm_menu_0212112734_1.bgImageUp="images/mmmenu5_130x20_up.gif";
   mm_menu_0212112734_1.bgImageOver="images/mmmenu5_130x20_over.gif";
   mm_menu_0212112734_1.hideOnMouseOut=true;
   mm_menu_0212112734_1.bgColor='#555555';
  window.mm_menu_0212112734_2 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_2.addMenuItem("New","location='new_item.php'");
  mm_menu_0212112734_2.addMenuItem("Edit","location='ed_item.php'");
  mm_menu_0212112734_2.addMenuItem("Search","location='search_item.php'");
   mm_menu_0212112734_2.bgImageUp="images/mmmenu4_130x20_up.gif";
   mm_menu_0212112734_2.bgImageOver="images/mmmenu4_130x20_over.gif";
   mm_menu_0212112734_2.hideOnMouseOut=true;
   mm_menu_0212112734_2.bgColor='#555555';
  window.mm_menu_0212112734_3 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_3.addMenuItem("New","location='new_po.php'");
  mm_menu_0212112734_3.addMenuItem("Edit","location='ed_po.php'");
  mm_menu_0212112734_3.addMenuItem("Search","location='search_po.php'");
  mm_menu_0212112734_3.addMenuItem("Quick&nbsp;List","location='search_po.php?action=search_all&order_by=po_number&order=DESC'");
   mm_menu_0212112734_3.bgImageUp="images/mmmenu3_130x20_up.gif";
   mm_menu_0212112734_3.bgImageOver="images/mmmenu3_130x20_over.gif";
   mm_menu_0212112734_3.hideOnMouseOut=true;
   mm_menu_0212112734_3.bgColor='#555555';
  window.mm_menu_0212112734_4 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_4.addMenuItem("New","location='new_inv.php'");
  mm_menu_0212112734_4.addMenuItem("Edit","location='ed_inv.php'");
  mm_menu_0212112734_4.addMenuItem("Search","location='search_inv.php'");
  mm_menu_0212112734_4.addMenuItem("Quick&nbsp;List","location='search_inv.php?action=search_all&order_by=inv_number&order=DESC'");
   mm_menu_0212112734_4.bgImageUp="images/mmmenu2_130x20_up.gif";
   mm_menu_0212112734_4.bgImageOver="images/mmmenu2_130x20_over.gif";
   mm_menu_0212112734_4.hideOnMouseOut=true;
   mm_menu_0212112734_4.bgColor='#555555';
  window.mm_menu_0212112734_5 = new Menu("root",130,20,"Verdana, Arial, Helvetica, sans-serif",12,"#000000","#000000","#6699ff","#99ccff","left","middle",4,0,1000,-5,7,true,true,true,0,false,true);
  mm_menu_0212112734_5.addMenuItem("Asset&nbsp;Dictionary","location='search_asset.php'");
  mm_menu_0212112734_5.addMenuItem("Invoice&nbsp;Dictionary","location='search_inv.php'");
  mm_menu_0212112734_5.addMenuItem("Item&nbsp;Master","location='search_item.php'");
  mm_menu_0212112734_5.addMenuItem("PO&nbsp;Dictionary","location='search_po.php'");
  mm_menu_0212112734_5.addMenuItem("View&nbsp;Organization","location='search_org.php'");
  mm_menu_0212112734_5.addMenuItem("View&nbsp;Vendor","location='search_vendor.php'");
   mm_menu_0212112734_5.bgImageUp="images/mmmenu1_130x20_up.gif";
   mm_menu_0212112734_5.bgImageOver="images/mmmenu1_130x20_over.gif";
   mm_menu_0212112734_5.hideOnMouseOut=true;
   mm_menu_0212112734_5.bgColor='#555555';

  mm_menu_0212112734_5.writeMenus();
} // mmLoadMenus()
</script>
<script language="JavaScript1.2" src="mm_menu.js"></script>
<?php
   require("validation.inc.php");
?>
<link href="style.css" rel="stylesheet" type="text/css">
<title>Asset Manager</title>
</head>
<body class="assetman">
<script language="JavaScript1.2">mmLoadMenus();</script>
<script language="JavaScript">
  if (document.images) {
  menubar_r1_c1_f2 = new Image(80 ,20); menubar_r1_c1_f2.src = "images/menubar_r1_c1_f2.gif";
  menubar_r1_c1_f1 = new Image(80 ,20); menubar_r1_c1_f1.src = "images/menubar_r1_c1.gif";
  menubar_r1_c2_f2 = new Image(80 ,20); menubar_r1_c2_f2.src = "images/menubar_r1_c2_f2.gif";
  menubar_r1_c2_f1 = new Image(80 ,20); menubar_r1_c2_f1.src = "images/menubar_r1_c2.gif";
  menubar_r1_c3_f2 = new Image(80 ,20); menubar_r1_c3_f2.src = "images/menubar_r1_c3_f2.gif";
  menubar_r1_c3_f1 = new Image(80 ,20); menubar_r1_c3_f1.src = "images/menubar_r1_c3.gif";
  menubar_r1_c4_f2 = new Image(80 ,20); menubar_r1_c4_f2.src = "images/menubar_r1_c4_f2.gif";
  menubar_r1_c4_f1 = new Image(80 ,20); menubar_r1_c4_f1.src = "images/menubar_r1_c4.gif";
  menubar_r1_c5_f2 = new Image(80 ,20); menubar_r1_c5_f2.src = "images/menubar_r1_c5_f2.gif";
  menubar_r1_c5_f1 = new Image(80 ,20); menubar_r1_c5_f1.src = "images/menubar_r1_c5.gif";
  menubar_r1_c6_f2 = new Image(80 ,20); menubar_r1_c6_f2.src = "images/menubar_r1_c6_f2.gif";
  menubar_r1_c6_f1 = new Image(80 ,20); menubar_r1_c6_f1.src = "images/menubar_r1_c6.gif";
  menubar_r1_c7_f2 = new Image(80 ,20); menubar_r1_c7_f2.src = "images/menubar_r1_c7_f2.gif";
  menubar_r1_c7_f1 = new Image(80 ,20); menubar_r1_c7_f1.src = "images/menubar_r1_c7.gif";
  menubar_r1_c8_f2 = new Image(80 ,20); menubar_r1_c8_f2.src = "images/menubar_r1_c8_f2.gif";
  menubar_r1_c8_f1 = new Image(80 ,20); menubar_r1_c8_f1.src = "images/menubar_r1_c8.gif";
  menubar_r1_c9_f2 = new Image(80 ,20); menubar_r1_c9_f2.src = "images/menubar_r1_c9_f2.gif";
  menubar_r1_c9_f1 = new Image(80 ,20); menubar_r1_c9_f1.src = "images/menubar_r1_c9.gif";
  }
</script>
<table border="0" cellpadding="0" cellspacing="0" width="720">
<!-- fwtable fwsrc="menubar.png" fwbase="menubar.gif" fwstyle="Generic" fwdocid = "742308039" fwnested="0" -->
  <tr>
   <td><a href="index.php" onMouseOut="MM_swapImgRestore();" onMouseOver="MM_swapImage('menubar_r1_c1','','images/menubar_r1_c1_f2.gif',1);"><img name="menubar_r1_c1" src="images/menubar_r1_c1.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_0,0,20,null,'menubar_r1_c2');MM_swapImage('menubar_r1_c2','','images/menubar_r1_c2_f2.gif',1);"><img name="menubar_r1_c2" src="images/menubar_r1_c2.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_1,0,20,null,'menubar_r1_c3');MM_swapImage('menubar_r1_c3','','images/menubar_r1_c3_f2.gif',1);"><img name="menubar_r1_c3" src="images/menubar_r1_c3.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_2,0,20,null,'menubar_r1_c4');MM_swapImage('menubar_r1_c4','','images/menubar_r1_c4_f2.gif',1);"><img name="menubar_r1_c4" src="images/menubar_r1_c4.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_3,0,20,null,'menubar_r1_c5');MM_swapImage('menubar_r1_c5','','images/menubar_r1_c5_f2.gif',1);"><img name="menubar_r1_c5" src="images/menubar_r1_c5.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_4,0,20,null,'menubar_r1_c6');MM_swapImage('menubar_r1_c6','','images/menubar_r1_c6_f2.gif',1);"><img name="menubar_r1_c6" src="images/menubar_r1_c6.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_showMenu(window.mm_menu_0212112734_5,0,20,null,'menubar_r1_c7');MM_swapImage('menubar_r1_c7','','images/menubar_r1_c7_f2.gif',1);"><img name="menubar_r1_c7" src="images/menubar_r1_c7.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();" onMouseOver="MM_swapImage('menubar_r1_c8','','images/menubar_r1_c8_f2.gif',1);"><img name="menubar_r1_c8" src="images/menubar_r1_c8.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><a href="#" onMouseOut="MM_swapImgRestore();" onMouseOver="MM_swapImage('menubar_r1_c9','','images/menubar_r1_c9_f2.gif',1);" onClick="window.open('help.htm');"><img name="menubar_r1_c9" src="images/menubar_r1_c9.gif" width="80" height="20" border="0" alt=""></a></td>
   <td><img src="images/spacer.gif" width="1" height="20" border="0" alt=""></td>
  </tr>
</table>
<?php
if (isset($username)) { ?>
   <table class="default" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_even">
         <td>&nbsp;&nbsp;Welcome <?php echo $fullname; ?></td>
         <td align="right"> <?php
            if ($priv == 4) { ?>
               <a href="admin.php"><img src="images/admin_btn.gif" alt="Administration" border="0"></a> <?php
            } ?>
            <a href="logout.php"><img src="images/logout_btn.gif" alt="Logout" border="0"></a>
         </td>
      </tr>
   </table> <?php
} ?>