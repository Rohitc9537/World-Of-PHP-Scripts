<?php require("common.inc.php"); ?>

<?php
function display_form($descrip = FALSE) { ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="75%">
   <form action="new_types.php" method="post" name="form1">
      <tr> 
         <td colspan="2" class="row_head">
            <b>New Equipment Type Information</b>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Equipment Type:</td>
         <td>
            <input type="text" name="descrip" size="40" <?php
            if ($descrip !== FALSE) {
               echo "value=\"$descrip\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td colspan="2">
            <img src="images/enter_xp.gif" border="0" alt="Enter"
               onClick="document.form1.submit();">
            <img src="images/reset_xp.gif" border="0" alt="Reset"
               onClick="document.form1.reset();">
            <a href="new_types.php?action=cancel">
               <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
         </td>
      </tr>
    <input type="hidden" name="action" value="insert">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.descrip.focus();
   </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Equipment Type Dictionary update cancelled.</td></tr></table>";
         break;
      case "insert":
         if (!valid_char_1($descrip)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description.</td></tr></table>";
            display_form(stripslashes($descrip));
            break;
         }
         $id = $db->GenID("equipment_type_seq");
         $query = "INSERT INTO equipment_type (id, descrip) VALUES ('$id', " . $db->QMagic($descrip) . ")";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Equipment Type Dictionary updated OK.<a href=\"new_types.php\"><img src=\"images/add_btn.gif\" border=\"0\" alt=\"Add\"></a> another new equipment type.</td></tr></table>";
         break;
      default:
         display_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
