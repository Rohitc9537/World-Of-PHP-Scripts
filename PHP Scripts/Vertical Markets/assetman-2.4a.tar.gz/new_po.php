<?php require("common.inc.php"); ?>

<?php
function display_form($db) {
   global $cfg;
   $vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="new_po.php" method="post" name="form1">
       <tr class="row_head"> 
         <td colspan="2"><b>New Purchase Order Information</b></td>
         <td colspan="2" align="right">PO Number: Next</td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Date:</td>
         <td colspan="3">
            <input type="text" name="date" value="<?php echo date($cfg["date_arg"]); ?>"
               onChange="return BisDate(this,'R')"><?php echo $cfg["date_exp"]; ?>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Vendor:</td>
         <td>
            <?php echo $vendors->GetMenu("vendor", "", FALSE); ?>
         </td>
         <td colspan="2">
            <a href="new_vendor.php?refer=new_po.php">
               <img src="images/new_vendor_xp.gif" alt="New Vendor" border="0"></a>
         </td>
       </tr>
       <tr class="row_even">
         <td align="right">Organization:</td>
         <td>
            <?php echo $orgs->GetMenu("org", "", FALSE); ?>
         </td>
         <td colspan="2">
            <a href="new_org.php?refer=new_po.php">
               <img src="images/new_org_xp.gif" alt="New Organization" border="0"></a>
         </td>
       </tr>
       <tr class="row_even"> 
         <td colspan="4"> 
            <img src="images/enter_xp.gif" border="0" alt="Enter"
               onClick="document.form1.submit();">
            <a href="new_po.php?action=cancel">
               <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
         </td>
       </tr>
     <input type="hidden" name="action" value="create">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.date.focus();
   </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Create purchase order cancelled.</td></tr></table>";
         break;
      case "create":
         if (!$date = valid_date($date)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid date format.</td></tr></table>";
            display_form($db);
            break;
         }
         $po_number = $db->GenID("po_seq");
         $query = "INSERT INTO po (po_number, date, vendor, organization, open, created_by, approved)"
                . " VALUES ('$po_number', '$date', '$vendor', '$org', 'Y', '$username', 'N')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         } ?>
         <script language="JavaScript">
            window.location="ed_po.php?action=edit&po_number=<?php echo $po_number; ?>";
         </script> <?php
         break;
      default:
         display_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
