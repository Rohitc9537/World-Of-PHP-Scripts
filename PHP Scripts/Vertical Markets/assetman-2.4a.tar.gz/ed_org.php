<?php require("common.inc.php"); ?>

<?php
function org_form($db) {
   if (!$org = $db->Execute("SELECT name, id FROM organization ORDER BY name")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_org.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Organization Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Choose Organization:</td>
      <td>
         <?php echo $org->GetMenu("id", "", FALSE, FALSE, 0,
               "onChange='document.form1.submit();'"); ?>
      </td>
    </tr>
   <input type="hidden" name="action" value="edit">
   </form>
   </table> <?php
} ?>

<?php
function delete_org($db, $id) {
   $tag = $db->Execute("SELECT COUNT(tag) FROM tag WHERE organization=$id");
   $invoices = $db->Execute("SELECT COUNT(inv_number) FROM invoices WHERE organization=$id");
   if ($tag->fields[0] > 0 || $invoices->fields[0] > 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>There are references to this organization in other dictionaries. You may not delete this organization.</td></tr></table>";
      return FALSE;
   }
   if (!$db->Execute("DELETE FROM organization WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

function edit_form($db, $id) {
   if (!$org = $db->Execute("SELECT * FROM organization WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="ed_org.php" method="post" name="form2">
       <tr class="row_head"> 
         <td colspan="4"><b>Update Organization Information</b></td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Name:</td>
         <td> 
           <input type="text" name="name" size="40"
              value="<?php echo $org->fields["name"]; ?>">
         </td>
         <td align="right">Tax Exempt?</td> <?php
         if ($org->fields["tax_exempt"] == "Y") { ?>
            <td><input type="checkbox" name="tax_exempt" value="Y" checked></td> <?php
         } else { ?>
            <td><input type="checkbox" name="tax_exempt" value="Y"></td> <?php
         } ?>
       </tr>
       <tr class="row_even"> 
         <td align="right">Address 1:</td>
         <td colspan="3"> 
           <input type="text" name="address1" size="40"
              value="<?php echo $org->fields["address1"]; ?>">
         </td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Address 2:</td>
         <td colspan="3"> 
           <input type="text" name="address2" size="40"
              value="<?php echo $org->fields["address2"]; ?>">
         </td>
       </tr>
       <tr class="row_even"> 
         <td align="right">City:</td>
         <td> 
           <input type="text" name="city" size="20"
              value="<?php echo $org->fields["city"]; ?>">
         </td>
         <td align="right">Province/State:</td>
         <td colspan="3"> 
           <input type="text" name="province" size="12"
              value="<?php echo $org->fields["province"]; ?>">
         </td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Country:</td>
         <td> 
           <input type="text" name="country" size="20"
              value="<?php echo $org->fields["country"]; ?>">
         </td>
         <td align="right">Postal/ZIP Code:</td>
         <td> 
           <input type="text" name="p_code" size="12"
              value="<?php echo $org->fields["p_code"]; ?>">
         </td>
       </tr>
       <tr class="row_head"> 
         <td colspan="4"><b>Main Contact Information</b></td>
       </tr>
       <tr class="row_even"> 
         <td align="right">Name:</td>
         <td> 
           <input type="text" name="contact" size="30"
              value="<?php echo $org->fields["contact"]; ?>">
         </td>
         <td align="right">Phone:</td>
         <td> 
           <input type="text" name="phone" size="20"
              value="<?php echo $org->fields["phone"]; ?>">
         </td>
       </tr>
       <tr class="row_even"> 
         <td align="right">E-Mail:</td>
         <td> 
           <input type="text" name="email" size="30"
              value="<?php echo $org->fields["email"]; ?>">
         </td>
         <td align="right">FAX:</td>
         <td> 
           <input type="text" name="fax" size="20"
              value="<?php echo $org->fields["fax"]; ?>">
         </td>
       </tr>
       <tr class="row_even"> 
         <td colspan="4"> 
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_org_form(document.form2)) { document.form2.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Organization ?')) { window.location='ed_org.php?action=delete&id=<?php echo $id; ?>'; }">
         <a href="ed_org.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
         </td>
       </tr>
     </table>
   <input type="hidden" name="action" value="Update">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   </form>
   <script language="JavaScript">
      document.form2.name.focus();
   </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Organization Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (delete_org($db, $id)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Organization Dictionary updated OK.<a href=\"ed_org.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Organization.</td></tr></table>";
         }
         break;
      case "update":
         if (!valid_char_1($name)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid organization name.</td></tr></table>";
            edit_form($db, $id);
            break;
         }
         if (!isset($tax_exempt)) $tax_exempt = "N";
         $query = "UPDATE organization SET"
                . " name=" . $db->QMagic($name) . ", address1=" . $db->QMagic($address1) . ","
                . " address2=" . $db->QMagic($address2) . ", city=" . $db->QMagic($city) . ","
                . " province=" . $db->QMagic($province) . ", p_code=" . $db->QMagic($p_code) . ","
                . " country=" . $db->QMagic($country) . ", contact=" . $db->QMagic($contact) . ","
                . " phone='$phone', fax='$fax',"
                . " email=" . $db->QMagic($email) . ", tax_exempt='$tax_exempt' WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Organization Dictionary updated OK.<a href=\"ed_org.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Organization.</td></tr></table>";
         break;
      case "edit":
         edit_form($db, $id);
         break;
      default:
         org_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
