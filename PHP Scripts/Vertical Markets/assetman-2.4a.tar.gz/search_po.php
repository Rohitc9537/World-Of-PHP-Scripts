<?php require("common.inc.php"); ?>

<?php
function search_form($db) {
   global $cfg;
   $vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="search_po.php" method="get" name="form1">
      <tr class="row_head">
         <td colspan="5"><b>Search the Purchase Order Dictionary</b></td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td colspan="4">
            <select name="action">
               <option value="search_none" SELECTED>--- Select Search Type ---</option>
               <option value="search_single">Show a Single Purchase Order</option>
               <option value="search_all">Show All Purchase Orders</option>
               <option value="search_org">Show Purchase Orders by Organization</option>
               <option value="search_vendor">Show Purchase Orders by Vendor</option>
            </select>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">PO Number:</td>
         <td colspan="3">
            <input type="text" name="po_number" size="12">
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">From Date:</td>
         <td>
            <input type="text" name="from_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
         <td align="right">To Date:</td>
         <td>
            <input type="text" name="to_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Organization:</td>
         <td colspan="3">
            <?php echo $orgs->GetMenu("org_id", "", FALSE); ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Vendor:</td>
         <td colspan="3">
            <?php echo $vendors->GetMenu("vendor_id", "", FALSE); ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">PO Status:</td>
         <td colspan="3">
            <input type="radio" name="status" value="any" checked>Any &nbsp;&nbsp;
            <input type="radio" name="status" value="open">Open &nbsp;&nbsp;
            <input type="radio" name="status" value="closed">Closed
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Order By:</td>
         <td colspan="3">
            <input type="radio" name="order_by" value="po_number" checked>PO Number &nbsp;&nbsp;
            <input type="radio" name="order_by" value="po.date">Date &nbsp;&nbsp;
            <input type="checkbox" name="order" value="DESC">Reverse
         </td>
      </tr>
      <tr class="row_head">
         <td colspan="4">
            Select search type, fill in parameters and click Search...
         </td>
         <td align="right">
            <img src="images/search_xp.gif" alt="Search" border="0"
               onClick="document.form1.submit();">
         </td>
      </tr>
   </form>
   </table> <?php
} ?>

<?php
function show_po($db) {
   global $action, $status, $org_id, $vendor_id,
          $from_date, $to_date, $order_by, $order;
   if ($from_date == "") {
      $from_date = "1980-01-01";
   } else {
      $from_date = valid_date($from_date);
   }
   if ($to_date == "") {
      $to_date = date("Y-m-d");
   } else {
      $to_date = valid_date($to_date);
   }
   if ($order != "DESC") {
      $order = "ASC";
   }
   $_SESSION["search_query"] =
      "SELECT po.po_number, po.date, po.open, po.approved, organization.name, vendor.name"
      . " FROM po, organization, vendor"
      . " WHERE po.vendor=vendor.id"
      . " AND po.organization=organization.id"
      . " AND po.date>='$from_date'"
      . " AND po.date<='$to_date'";
   if ($action == "search_org") {
      $_SESSION["search_query"] .= " AND po.organization=$org_id";
   }
   if ($action == "search_vendor") {
      $_SESSION["search_query"] .= " AND po.vendor=$vendor_id";
   }
   if ($status == "open") {
      $_SESSION["search_query"] .= " AND po.open='Y'";
   }
   if ($status == "closed") {
      $_SESSION["search_query"] .= " AND po.open='N'";
   }
   $_SESSION["search_query"] .= " ORDER BY $order_by $order";
   if (!$summary = paged_query($db)) {
      search_form($db);
   } else {
      paint_table($summary);
   }
} ?>

<?php
function paint_table(&$summary) { ?>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><b>PO Number</b></td>
         <td><b>Date</b></td>
         <td><b>Organization</b></td>
         <td><b>Vendor</b></td>
         <td align="center"><b>Status</b></td>
      </tr> <?php
      $i = 1;
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?>
         <td>
            <a href="ed_po.php?action=view_from_search&po_number=<?php echo $summary->fields["po_number"]; ?>">
               <?php echo $summary->fields["po_number"]; ?></a>
         </td>
         <td><?php echo display_date($summary->fields["date"]); ?></td>
         <td><?php echo $summary->fields[4]; ?></td>
         <td><?php echo $summary->fields[5]; ?></td>
         <td align="center"> <?php 
            if ($summary->fields["open"] == "Y" && $summary->fields["approved"] == "N") { ?>
               <img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
            } else if ($summary->fields["open"] == "Y" && $summary->fields["approved"] == "Y") { ?>
               <img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
            } else { ?>
               <img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
            } ?>
         </td>
      </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td align="center"> <?php
            if (!$summary->AtFirstPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_po.php?action=paged_query&page=<?php echo $summary->AbsolutePage() - 1; ?>">
                  <img src="images/prev_btn.gif" border="0" alt="Previous"></a> <?php
            }
            echo "&nbsp;";
            if (!$summary->AtLastPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_po.php?action=paged_query&page=<?php echo $summary->AbsolutePage() + 1; ?>">
                  <img src="images/next_btn.gif" border="0" alt="Next"></a> <?php
            } ?>
         </td>
      </tr>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head"> <?php
         if ($summary->AbsolutePage() == -1) {
            echo "<td>&nbsp;</td>";
         } else {
            echo "<td>Page: " . $summary->AbsolutePage() . "</td>";
         } ?>
         <td align="right">
            <a href="search_po.php?action=print_result"><img src="images/print_btn.gif" alt="Print Results" border="0"></a>
            <a href="search_po.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
         </td>
      </tr>
   </table> <?php
} ?>

<?php
$action = strtolower($action);
switch ($action) {
   case "print_result": ?>
      <script language="JavaScript">
         window.open("print_html_search_po.php");
      </script> <?php
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Search Results opened in a new browser window.</td></tr></table>";
      break;
   case "search_none":
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a Search Type from the drop menu.</td></tr></table>";
      search_form($db);
      break;
   case "search_single":
      if (empty($po_number)) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid purchase order number.</td></tr></table>";
         search_form($db);
         break;
      }
      if (!$po = $db->Execute("SELECT * FROM po WHERE po_number=$po_number")) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
         break;
      }
      if ($po->RecordCount() == 0) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $po_number not found.</td></tr></table>";
         search_form($db);
         break;
      } ?>
      <script language="JavaScript">
         window.location="ed_po.php?action=view_from_search&po_number=<?php echo $po_number; ?>";
      </script> <?php
      break;
   case "search_all":
      show_po($db);
      break;
   case "search_org":
      show_po($db);
      break;
   case "search_vendor":
      show_po($db);
      break;
   case "paged_query":
      $summary = paged_query($db, $page);
      paint_table($summary);
      break;
   default:
      search_form($db);
}
require("footer.inc.php");
?>
