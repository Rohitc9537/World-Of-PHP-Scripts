<?php require("common.inc.php"); ?>

<?php
function new_user_form($db) { ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form1" method="post" action="admin.php">
         <tr class="row_head"> 
            <td colspan="2" nowrap><b>New User Information</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Username:</td>
            <td> 
               <input type="text" name="uid" size="16">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Full Name:</td>
            <td> 
               <input type="text" name="given" size="30">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Password:</td>
            <td> 
               <input type="password" name="pwd1" size="16">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Retype Password:</td>
            <td> 
               <input type="password" name="pwd2" size="16" value="">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">E-Mail Address:</td>
            <td> 
               <input type="text" name="email_addr" size="30">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Privilege:</td>
            <td> 
               <select name="privilege">
                  <option value="4">Administrator</option>
                  <option value="3">Supervisor</option>
                  <option value="2">Read / Write</option>
                  <option value="1" selected>Read Only</option>
               </select>
            </td>
         </tr>
         <tr class="row_even"> 
            <td colspan="2" nowrap> 
               <img src="images/enter_xp.gif" border="0" alt="Enter"
                  onClick="document.form1.submit();">
               <img src="images/reset_xp.gif" border="0" alt="Reset"
                  onClick="document.form1.reset();">
               <a href="admin.php?action=cancel">
                  <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
            </td>
         </tr>
      <input type="hidden" name="action" value="insert">
      </form>
   </table>
   <script language="JavaScript">
      document.form1.uid.focus();
   </script> <?php
} ?>

<?php
function edit_user_form($db, $uid) {
   $user = $db->Execute("SELECT fullname, email, priv FROM users WHERE username='$uid'"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form name="form2" method="post" action="admin.php">
         <tr class="row_head"> 
            <td colspan="2" nowrap><b>Edit User Information</b></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Username:</td>
            <td><?php echo $uid; ?></td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Full Name:</td>
            <td> 
               <input type="text" name="given" size="30"
                  value="<?php echo $user->fields["fullname"]; ?>">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Password:</td>
            <td> 
               <input type="password" name="pwd1" size="16">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Retype Password:</td>
            <td> 
               <input type="password" name="pwd2" size="16" value="">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">E-Mail Address:</td>
            <td> 
               <input type="text" name="email_addr" size="30"
                  value="<?php echo $user->fields["email"]; ?>">
            </td>
         </tr>
         <tr class="row_even"> 
            <td nowrap align="right">Privilege:</td>
            <td> 
               <select name="privilege">
                  <option value="4" <?php if ($user->fields["priv"] == 4) echo "selected"; ?>>Administrator</option>
                  <option value="3" <?php if ($user->fields["priv"] == 3) echo "selected"; ?>>Supervisor</option>
                  <option value="2" <?php if ($user->fields["priv"] == 2) echo "selected"; ?>>Read / Write</option>
                  <option value="1" <?php if ($user->fields["priv"] == 1) echo "selected"; ?>>Read Only</option>
               </select>
            </td>
         </tr>
         <tr class="row_even"> 
            <td colspan="2" nowrap> 
               <img src="images/update_xp.gif" border="0" alt="Update"
                  onClick="document.form2.submit();">
               <img src="images/delete_xp.gif" alt="Delete" border="0"
                  onClick="if (isConfirmed('Are you sure you want to DELETE this User ?')) { window.location='admin.php?action=delete&uid=<?php echo $uid; ?>'; }">
               <a href="admin.php?action=cancel">
                  <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
            </td>
         </tr>
      <input type="hidden" name="uid" value="<?php echo $uid; ?>">
      <input type="hidden" name="action" value="update">
      </form>
   </table>
   <script language="JavaScript">
      document.form2.given.focus();
   </script> <?php
} ?>

<?php
function po_form() { ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
  <form action="admin.php" method="get" name="form3">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Edit Purchase Order Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">PO Number:</td>
      <td>
        <input type="text" name="po_number" size="12">
        <input type="submit" value="Enter">
      </td>
    </tr>
  <input type="hidden" name="action" value="edit_po_info"> 
  </form>
</table>
<script language="JavaScript">
   document.form3.po_number.focus();
</script> <?php
} ?>

<?php
function po_info_form($db, $po_number) {
   if ($po_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid PO number.</td></tr></table>";
      po_form();
      return FALSE;
   }
   if (!$po = $db->Execute("SELECT * FROM po WHERE po_number=$po_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($po->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $po_number not found.</td></tr></table>";
      po_form();
      return FALSE;
   }
   $super_users = $db->Execute("SELECT fullname, username FROM users WHERE priv>2 ORDER BY fullname");
   $all_users = $db->Execute("SELECT fullname, username FROM users ORDER BY fullname");
   $vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form action="admin.php" method="post" name="form4">
         <tr class="row_head">
            <td colspan="2" nowrap><b>Edit Purchase Order Information</b></td>
         </tr>
         <tr class="row_even">
            <td align="right">
               PO Number:
            </td>
            <td>
               <a href="ed_po.php?action=view&po_number=<?php echo $po_number; ?>"><?php echo $po_number; ?></a>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Organization:
            </td>
            <td>
               <?php echo $orgs->GetMenu2("org", $po->fields["organization"], FALSE, FALSE, 0,
                                 "onChange='document.form4.submit();'") ?>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Vendor:
            </td>
            <td>
               <?php echo $vendors->GetMenu2("vendor", $po->fields["vendor"], FALSE, FALSE, 0,
                                    "onChange='document.form4.submit();'") ?>
            </td>
          </tr>
         <tr class="row_even">
            <td align="right">
               Status:
            </td>
            <td>
               <select name="status" onChange="document.form4.submit();"> <?php
                  if ($po->fields["open"] == "Y" && $po->fields["approved"] == "N") { ?>
	                  <option value="1" selected>Open, Not Approved</option>
	                  <option value="2">Open, Approved</option>
	                  <option value="3">Closed, Approved</option> <?php
                  } else if ($po->fields["open"] == "Y" && $po->fields["approved"] == "Y") { ?>
	                  <option value="1">Open, Not Approved</option>
	                  <option value="2" selected>Open, Approved</option>
	                  <option value="3">Closed, Approved</option> <?php
                  } else { ?>
	                  <option value="1">Open, Not Approved</option>
	                  <option value="2">Open, Approved</option>
	                  <option value="3" selected>Closed, Approved</option> <?php
                  } ?>
               </select>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Created By:
            </td>
            <td>
               <?php echo $all_users->GetMenu2("cr_user", $po->fields["created_by"], FALSE, FALSE, 0,
                                      "onChange='document.form4.submit();'") ?>
            </td>
         </tr> <?php
         if ($po->fields["approved"] == "Y") { ?>
            <tr class="row_even">
               <td align="right">
                  Approved By:
               </td>
               <td>
                  <?php echo $super_users->GetMenu2("ap_user", $po->fields["approved_by"], TRUE, FALSE, 0,
                                           "onChange='document.form4.submit();'") ?>
               </td>
            </tr> <?php
         } ?>
         <tr class="row_even">
            <td colspan="2">
               <a href="admin.php">
                  <img src="images/done_xp.gif" alt="Back to Main Administration Menu" border="0"></a>
            </td>
         </tr>
         <input type="hidden" name="po_number" value="<?php echo $po_number; ?>">
         <input type="hidden" name="action" value="update_po_info">
      </form>
   </table> <?php
} ?>

<?php
function inv_form() { ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
  <form action="admin.php" method="post" name="form5">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Edit Invoice Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Invoice Number:</td>
      <td>
        <input type="text" name="inv_number" size="12">
        <input type="submit" value="Enter">
      </td>
    </tr>
  <input type="hidden" name="action" value="edit_inv_info"> 
  </form>
</table>
<script language="JavaScript">
   document.form5.inv_number.focus();
</script> <?php
} ?>

<?php
function inv_info_form($db, $inv_number) {
   if ($inv_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid Invoice number.</td></tr></table>";
      inv_form();
      return FALSE;
   }
   if (!$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($inv->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice number $inv_number not found.</td></tr></table>";
      inv_form();
      return FALSE;
   }
   $super_users = $db->Execute("SELECT fullname, username FROM users WHERE priv>2 ORDER BY fullname");
   $all_users = $db->Execute("SELECT fullname, username FROM users ORDER BY fullname");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
      <form action="admin.php" method="post" name="form6">
         <tr class="row_head">
            <td colspan="2" nowrap><b>Edit Invoice Information</b></td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Invoice Number:
            </td>
            <td>
               <a href="ed_inv.php?action=view&inv_number=<?php echo $inv_number; ?>"><?php echo $inv_number; ?></a>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Organization:
            </td>
            <td>
               <?php echo $orgs->GetMenu2("org", $inv->fields["organization"], FALSE, FALSE, 0,
                                 "onChange='document.form6.submit();'") ?>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Status:
            </td>
            <td>
               <select name="status" onChange="document.form6.submit();"> <?php
                  if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "N") { ?>
	                  <option value="1" selected>Open, Not Approved</option>
	                  <option value="2">Open, Approved</option>
	                  <option value="3">Closed, Approved</option> <?php
                  } else if ($inv->fields["open"] == "Y" && $inv->fields["approved"] == "Y") { ?>
	                  <option value="1">Open, Not Approved</option>
	                  <option value="2" selected>Open, Approved</option>
	                  <option value="3">Closed, Approved</option> <?php
                  } else { ?>
	                  <option value="1">Open, Not Approved</option>
	                  <option value="2">Open, Approved</option>
	                  <option value="3" selected>Closed, Approved</option> <?php
                  } ?>
               </select>
            </td>
         </tr>
         <tr class="row_even">
            <td align="right">
               Created By:
            </td>
            <td>
               <?php echo $all_users->GetMenu2("cr_user", $inv->fields["created_by"], FALSE, FALSE, 0,
                                      "onChange='document.form6.submit();'") ?>
            </td>
         </tr> <?php
         if ($inv->fields["approved"] == "Y") { ?>
            <tr class="row_even">
               <td align="right">
                  Approved By:
               </td>
               <td>
                  <?php echo $super_users->GetMenu2("ap_user", $inv->fields["approved_by"], TRUE, FALSE, 0,
                                           "onChange='document.form6.submit();'") ?>
               </td>
            </tr> <?php
         } ?>
         <tr class="row_even">
            <td colspan="2">
               <a href="admin.php">
                  <img src="images/done_xp.gif" alt="Back to Main Administration Menu" border="0"></a>
            </td>
         </tr>
         <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
         <input type="hidden" name="action" value="update_inv_info">
      </form>
   </table> <?php
} ?>

<?php
function paint_table($db) { 
   $summary = $db->Execute("SELECT username, fullname, email, priv FROM users ORDER BY username");?>
   <table border="0" width="100%" cellspacing="0" cellpadding="1"><tr class="row_even"><td>
      <a href="admin.php?action=new">
         <img src="images/new_user_xp.gif" alt="Add New User" border="0"></a>
      <a href="admin.php?action=po_info">
         <img src="images/po_info_xp.gif" alt="Edit PO Information" border="0"></a>
      <a href="admin.php?action=inv_info">
         <img src="images/inv_info_xp.gif" alt="Edit Invoice Information" border="0"></a>
   </td></tr></table>
   <table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
      <tr class="row_head"> 
         <td><b>Username</b></td>
         <td><b>Full Name</b></td>
         <td><b>E-Mail Address</b></td>
         <td><b>Privilege</b></td>
      </tr> <?php
      $i = 1;
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?> 
            <td>
               <a href="admin.php?action=edit&uid=<?php echo $summary->fields["username"]; ?>">
                  <?php echo $summary->fields["username"]; ?></a>
            </td>
            <td><?php echo $summary->fields["fullname"]; ?></td>
            <td><?php echo $summary->fields["email"]; ?></td>
            <td> <?php
               $x = $summary->fields["priv"];
               switch ($x) {
                  case "1":
                     echo "Read Only";
                     break;
                  case "2":
                     echo "Read / Write";
                     break;
                  case "3":
                     echo "Supervisor";
                     break;
                  case "4":
                     echo "Administrator";
                     break;
               } ?>
            </td>
         </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td>&nbsp;</td>
      </tr>
   </table>
 <?php
} ?>

<?php
if ($priv == 4) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         paint_table($db);
         break;
      case "delete":
         if (!$db->Execute("DELETE FROM users WHERE username='$uid'")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>User $uid was deleted OK.</td></tr></table>";
         paint_table($db);
         break;
      case "edit":
         edit_user_form($db, $uid);
         break;
      case "insert":
         if ($uid == "") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The Username field is required.</td></tr></table>";
            new_user_form($db);
            break;
         }
         if ((strlen($pwd1) < 4) || ($pwd1 != $pwd2)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The password is less than 4 characters or the passwords don't match.</td></tr></table>";
            new_user_form($db);
            break;
         }
         $query = "INSERT INTO users (username, fullname, email, priv, password)"
                . " VALUES (" . $db->QMagic($uid) . ", " . $db->QMagic($given) . ", "
                . $db->QMagic($email_addr) . ", '$privilege', '" . md5($pwd1) . "')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         paint_table($db);
         break;
      case "new":
         new_user_form($db);
         break;
      case "update":
         if ($pwd1 == "") {
            $query = "UPDATE users SET"
                   . " fullname=" . $db->QMagic($given) . ", email=" . $db->QMagic($email_addr) . ", priv='$privilege'"
                   . " WHERE username='$uid'";
         } else if ((strlen($pwd1) >= 4) && ($pwd1 == $pwd2)) {
            $query = "UPDATE users SET"
                   . " fullname=" . $db->QMagic($given) . ", email=" . $db->QMagic($email_addr) . ", priv='$privilege',"
                   . " password='" . md5($pwd1) . "'"
                   . " WHERE username='$uid'";
         } else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The password is less than 4 characters or the passwords don't match.</td></tr></table>";
            edit_user_form($db, $uid);
            break;
         }
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         paint_table($db);
         break;
      case "po_info":
         po_form();
         break;
      case "edit_po_info":
         po_info_form($db, $po_number);
         break;
      case "update_po_info":
         if (!isset($ap_user)) {
            $ap_user = "";
         }
         switch ($status) {
            case 1:
               $open = "Y";
               $approved = "N";
               break;
            case 2:
               $open = "Y";
               $approved = "Y";
               break;
            case 3:
               $open = "N";
               $approved = "Y";
               break;
         }
         $query = "UPDATE po SET"
                . " vendor='$vendor', organization='$org',"
                . " open='$open', created_by='$cr_user',"
                . " approved='$approved', approved_by='$ap_user'"
                . " WHERE po_number=$po_number";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         po_info_form($db, $po_number);
         break;
      case "inv_info":
         inv_form();
         break;
      case "edit_inv_info":
         inv_info_form($db, $inv_number);
         break;
      case "update_inv_info":
         if (!isset($ap_user)) {
            $ap_user = "";
         }
         switch ($status) {
            case 1:
               $open = "Y";
               $approved = "N";
               break;
            case 2:
               $open = "Y";
               $approved = "Y";
               break;
            case 3:
               $open = "N";
               $approved = "Y";
               break;
         }
         $query = "UPDATE invoices SET"
                . " organization='$org',"
                . " open='$open', created_by='$cr_user',"
                . " approved='$approved', approved_by='$ap_user'"
                . " WHERE inv_number=$inv_number";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         inv_info_form($db, $inv_number);
         break;
      default:
      paint_table($db); 
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
