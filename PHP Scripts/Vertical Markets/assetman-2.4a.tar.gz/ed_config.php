<?php require("common.inc.php"); ?>

<?php
function config_form($db) {
   if (!$configs = $db->Execute("SELECT name, id  FROM config ORDER BY name")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_config.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Configuration Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Choose Configuration:</td>
      <td>
         <?php echo $configs->GetMenu("id", "", FALSE, FALSE, 0,
               "onChange='document.form1.submit();'"); ?> 
      </td>
    </tr>
   <input type="hidden" name="action" value="edit">
   </form>
</table> <?php
} ?>

<?php
function delete_config($db, $id) {
   if (!$db->Execute("DELETE FROM config WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if (!$db->Execute("UPDATE tag SET config='0' WHERE config=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

function edit_form($db, $id) {
   if (!$config = $db->Execute("SELECT * FROM config WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
<table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_config.php" method="post" name="form2">
      <tr> 
         <td colspan="4" class="row_head"><b>Update Configuration Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Descriptive Name:</td>
         <td colspan="3"> 
            <input type="text" name="name" size="40" 
               value="<?php echo $config->fields["name"]; ?>">
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 1:</td>
         <td> 
            <input type="text" name="tag1" size="12" <?php
            if ($config->fields["tag1"] != 0) {
               echo "value=\"" . $config->fields["tag1"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 2:</td>
         <td> 
            <input type="text" name="tag2" size="12" <?php
            if ($config->fields["tag2"] != 0) {
               echo "value=\"" . $config->fields["tag2"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 3:</td>
         <td>
            <input type="text" name="tag3" size="12" <?php
            if ($config->fields["tag3"] != 0) {
               echo "value=\"" . $config->fields["tag3"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 4:</td>
         <td> 
            <input type="text" name="tag4" size="12" <?php
            if ($config->fields["tag4"] != 0) {
               echo "value=\"" . $config->fields["tag4"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 5:</td>
         <td>
            <input type="text" name="tag5" size="12" <?php
            if ($config->fields["tag5"] != 0) {
               echo "value=\"" . $config->fields["tag5"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 6:</td>
         <td> 
            <input type="text" name="tag6" size="12" <?php
            if ($config->fields["tag6"] != 0) {
               echo "value=\"" . $config->fields["tag6"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 7:</td>
         <td>
            <input type="text" name="tag7" size="12" <?php
            if ($config->fields["tag7"] != 0) {
               echo "value=\"" . $config->fields["tag7"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 8:</td>
         <td> 
            <input type="text" name="tag8" size="12" <?php
            if ($config->fields["tag8"] != 0) {
               echo "value=\"" . $config->fields["tag8"] . "\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right" valign="top">Comments:</td>
         <td colspan="3"> 
            <textarea name="comments" cols="50" 
               rows="5"><?php echo $config->fields["comments"]; ?></textarea>
         </td></tr>
      <tr class="row_even"> 
         <td colspan="4">
            <img src="images/update_xp.gif" alt="Update" border="0"
               onClick="if (valid_config_form(document.form2)) { document.form2.submit(); }">
            <img src="images/delete_xp.gif" alt="Delete" border="0"
               onClick="if (isConfirmed('Are you sure you want to DELETE this Configuration ?')) { window.location='ed_config.php?action=delete&id=<?php echo $id; ?>'; }">
            <a href="ed_config.php?action=cancel">
               <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
         </td>
      </tr>
   <input type="hidden" name="action" value="update">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   </form>
</table>
<script language="JavaScript">
   document.form2.name.focus();
</script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Configuration Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (delete_config($db, $id)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Configuration Dictionary updated OK.<a href=\"ed_config.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Configuration.</td></tr></table>";
         }
         break;
      case "edit_from_asset":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Tag $tag, which you just deleted,"
            . " is a member of this configuration.<br> You should update this configuration now.</td></tr></table>";
            edit_form($db, $id);
            break;
      case "edit":
         edit_form($db, $id);
         break;
      case "update":
         if ($tag1 == "") $tag1 = 0;
         if ($tag2 == "") $tag2 = 0;
         if ($tag3 == "") $tag3 = 0;
         if ($tag4 == "") $tag4 = 0;
         if ($tag5 == "") $tag5 = 0;
         if ($tag6 == "") $tag6 = 0;
         if ($tag7 == "") $tag7 = 0;
         if ($tag8 == "") $tag8 = 0;
         $tags = array($tag1, $tag2, $tag3, $tag4, $tag5, $tag6, $tag7, $tag8);
         rsort($tags);
         // Save the affected tag table records for a possible rollback.
         if (!$rollback = $db->Execute("SELECT * FROM tag WHERE config=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         // Zero the config field in affected tag table records.
         if (!$db->Execute("UPDATE tag SET config='0' WHERE config=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         // Make sure the config name starts with an alpha-numeric character.
         if (!valid_char_1($name)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid configuration name.</td></tr></table>";
            edit_form($db, $id);
            break;
         }
         // Check the supplied tags for dups and non-existant.
         if (!check_tags($db, $tags)) {
            // There is a problem with the tags. Roll back the tag table.
            while (!$rollback->EOF) {
               $query = "UPDATE tag SET"
                      . " config='" . $rollback->fields["config"] . "'"
                      . " WHERE tag=" . $rollback->fields["tag"];
               $db->Execute($query);
               $rollback->MoveNext();
            }
            edit_form($db, $id);
            break;
         }
         // Update the config table
         $query = "UPDATE config SET"
                . " name=" . $db->QMagic($name) . ","
                . " tag1='$tags[0]', tag2='$tags[1]',"
                . " tag3='$tags[2]', tag4='$tags[3]',"
                . " tag5='$tags[4]', tag6='$tags[5]',"
                . " tag7='$tags[6]', tag8='$tags[7]',"
                . " comments=" . $db->QMagic($comments) . ""
                . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         // Update the tag table
         for ($i = 0; $i < count($tags); $i++ ) {
            if (valid_tag($tags[$i])) {
               $query = "UPDATE tag SET config='$id' WHERE tag=$tags[$i]";
               if (!$db->Execute($query)) {
                  echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
                  break;
               }
            }
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Configuration Dictionary updated OK.<a href=\"ed_config.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Configuration.</td></tr></table>";
         break;
      default:
         config_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
