<?php
function display_date($date) {
// Converts an ISO format date selected from database to local format for display.
   global $cfg;
   list($year, $month, $day) = split("-", $date);
   $date = date($cfg["date_arg"], mktime(0, 0, 0, $month, $day, $year));
   return $date;
}

require("config.inc.php");
session_name($cfg["session"]);
session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $fullname = $_SESSION["fullname"];
} else {
   header("Status: 302 Found");
   header("Location: login.php");
}

require("grab_globals.inc.php");
require("connection.inc.php"); ?>
<html>
<head>
	<title>Print HTML Search Result</title>
   <link rel="STYLESHEET" type="text/css" href="style.css">
</head>
<body> <?php
if (!$summary = $db->Execute($_SESSION["search_query"])) {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
   die();
} ?>
<table class="small" width="100%" border="0" cellspacing="0" cellpadding="1">
   <tr class="row_head">
      <td><b>Make</b></td>
      <td><b>Model</b></td>
      <td><b>Serial</b></td>
      <td><b>Date</b></td>
      <td><b>PO</b></td>
      <td><b>Description</b></td>
   </tr> <?php
   $i = 1;
   while (!$summary->EOF) {
      if ($i % 2 == 0) {
         echo "<tr class=\"report_even\">";
      } else {
         echo "<tr class=\"report_odd\">";
      }
      echo "<td nowrap>" . $summary->fields["make"] . "</td>";
      echo "<td nowrap>" . $summary->fields["model"] . "</td>";
      echo "<td nowrap>" . $summary->fields["serial"] . "</td>";
      echo "<td nowrap>" . display_date($summary->fields["date"]) . "</td>";
      echo "<td nowrap>" . $summary->fields["po_number"] . "</td>";
      echo "<td nowrap>" . $summary->fields["descrip"] . "</td>";
      $i++;
      $summary->MoveNext();
   } ?>
</table>
<?php require("footer.inc.php"); ?>
