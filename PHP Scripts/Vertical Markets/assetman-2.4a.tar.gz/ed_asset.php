<?php require("common.inc.php"); ?>

<?php
function delete_tag($db, $tag) {
   if (!$db->Execute("DELETE FROM equipment WHERE tag=$tag")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if (!$db->Execute("DELETE FROM tag WHERE tag=$tag")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
} ?>

<?php
function tag_form() { ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
  <form action="ed_asset.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Asset Tag Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Asset Tag:</td>
      <td>
        <input type="text" name="tag" size="12">
        <input type="submit" value="Enter">
      </td>
    </tr>
  <input type="hidden" name="action" value="edit"> 
  </form>
</table>
<script language="JavaScript">
   document.form1.tag.focus();
</script> <?php
} ?>

<?php
function edit_form($db, $tag) {
   global $cfg;
   if (!valid_tag($tag)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Get with the Program! Enter a valid Asset Tag number!</td></tr></table>";
      tag_form();
      return FALSE;
   }
   $query = "SELECT equipment.*, tag.*"
          . " FROM equipment, tag"
          . " WHERE equipment.tag=$tag AND tag.tag=$tag";
   if (!$asset = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($asset->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Tag $tag not found.</td></tr></table>";
      tag_form();
      return FALSE;
   }
   $vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name");
   $types = $db->Execute("SELECT descrip, id FROM equipment_type ORDER BY descrip");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
  <table class="default" border="0" width="100%" cellspacing="0" cellpadding="1">
  <form action="ed_asset.php" method="post" name="form2">   
    <tr class="row_head"> 
      <td colspan="4"><b>Update Asset Tag Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Asset Tag:</td>
      <td colspan="3"> 
        <?php echo $asset->fields["tag"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="make"
           value="<?php echo $asset->fields["make"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="model"
           value="<?php echo $asset->fields["model"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="serial"
           value="<?php echo $asset->fields["serial"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> 
        <input type="text" name="po_number" size="12" <?php
           if ($asset->fields["po"] != 0) {
              echo "value=\"" . $asset->fields["po"] . "\"";
           }?>>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Vendor:</td>
      <td>
         <?php echo $vendors->GetMenu2("vendor", $asset->fields["vendor"], FALSE); ?>
      </td>
      <td align="right">Receive Date:</td>
      <td> 
         <input type="text" size="12" name="date"
            value="<?php echo display_date($asset->fields["date"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Price:</td>
      <td> 
         <input type="text" size="12" name="price"
            value="<?php echo $asset->fields["price"]; ?>">
      </td>
      <td align="right">Warranty Expires:</td>
      <td> 
         <input type="text" size="12" name="warranty"
            value="<?php echo display_date($asset->fields["warranty"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Equipment Type:</td>
      <td>
         <?php echo $types->GetMenu2("equip_type", $asset->fields["equip_type"], FALSE); ?>
      </td>
      <td align="right">Organization:</td>
      <td>
         <?php echo $orgs->GetMenu2("organization", $asset->fields["organization"], FALSE); ?>
        </select>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3"> 
        <textarea name="descrip" rows="5"
           cols="50"><?php echo $asset->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4">
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_asset_form(document.form2)) { document.form2.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Asset Tag ?')) { window.location='ed_asset.php?action=delete&tag=<?php echo $tag; ?>'; }">
         <a href="ed_asset.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="update">
  <input type="hidden" name="tag" value="<?php echo $tag; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.make.focus();
  </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         $config = $db->Execute("SELECT config FROM tag WHERE tag=$tag");
         if (delete_tag($db, $tag)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Dictionary updated OK.<a href=\"ed_asset.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Asset.</td></tr></table>";
            if ($config->fields["config"] != 0) { ?>
               <script language="JavaScript">
                  window.location="ed_config.php?action=edit_from_asset&tag=<?php echo $tag; ?>&id=<?php echo $config->fields["config"]; ?>";
               </script> <?php
            }
         }
         break;
      case "edit":
         edit_form($db, $tag);
         break;
      case "update":
         if (!$date = valid_date($date)) {
            edit_form($db, $tag);
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid date format.</td></tr></table>";
            break;
         }
         if (!valid_po($db, $po_number)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid PO number"
                 . " or leave the field blank if the PO number is unknown.</td></tr></table>";
            edit_form($db, $tag);
            break;
         }
         if (empty($po_number)) {
            $po_number = 0;
         }
         $warranty = valid_warranty($date, $warranty);
         $price = sprintf("%01.2f", $price);
         $query = "UPDATE equipment SET"
                . " make=" . $db->QMagic($make) . ", model=" . $db->QMagic($model) . ","
                . " serial=" . $db->QMagic($serial) . ", vendor='$vendor',"
                . " price='$price', warranty='$warranty',"
                . " descrip=" . $db->QMagic($descrip) . ", equip_type='$equip_type'"
                . " WHERE tag=$tag";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         $query = "UPDATE tag SET"
                . " date='$date', po='$po_number', organization='$organization'"
                . " WHERE tag=$tag";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Dictionary updated OK.<a href=\"ed_asset.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Asset.</td></tr></table>";
         break;
      default:
         tag_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>

