<?php require("common.inc.php"); ?>

<?php
function search_form($db) {
   global $cfg;
   $vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name");
   $types = $db->Execute("SELECT descrip, id FROM equipment_type ORDER BY descrip");
   $configs = $db->Execute("SELECT name, id FROM config ORDER BY name");
   $orgs = $db->Execute("SELECT name, id FROM organization ORDER BY name"); ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="search_asset.php" method="get" name="form1">
      <tr class="row_head">
         <td colspan="5"><b>Search the Asset Dictionary</b></td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td colspan="4">
            <select name="action">
               <option value="search_none" SELECTED>--- Select Search Type ---</option>
               <option value="search_single">Show a Single Asset</option>
               <option value="search_all">Show All Assets</option>
               <option value="search_make_model">Show Assets by Make and Model</option>
               <option value="search_type">Show Assets by Type</option>
               <option value="search_vendor">Show Assets by Vendor</option>
               <option value="search_config">Show Assets by Configuration</option>
               <option value="search_org">Show Assets by Organization</option>
            </select>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Asset Tag:</td>
         <td colspan="3"><input type="text" name="tag" size="12"></td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right" nowrap>From Date:</td>
         <td>
            <input type="text" name="from_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
         <td align="right" nowrap>To Date:</td>
         <td>
            <input type="text" name="to_date" size="12"
               onchange="return BisDate(this,'N')"><?php echo $cfg["date_exp"]; ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Make:</td>
         <td>
            <input type="text" name="make" size="12">
         </td>
         <td align="right">Model:</td>
         <td>
            <input type="text" name="model" size="12">
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Type:</td>
         <td colspan="3">
            <?php echo $types->GetMenu("type_id", "", FALSE); ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Vendor:</td>
         <td colspan="3">
            <?php echo $vendors->GetMenu("vendor_id", "", FALSE); ?>
         </td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Configuration:</td>
         <td colspan="2">
            <?php echo $configs->GetMenu("config_id", "", FALSE); ?>
         </td>
         <td class="small">Date Range does not apply</td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Organization:</td>
         <td colspan="2">
            <?php echo $orgs->GetMenu("org_id", "", FALSE); ?>
         </td>
         <td class="small">Date Range does not apply</td>
      </tr>
      <tr class="row_even">
         <td width="5%">&nbsp;</td>
         <td align="right">Order By:</td>
         <td colspan="3">
            <input type="radio" name="order_by" value="equipment.tag" checked>Tag &nbsp;&nbsp;
            <input type="radio" name="order_by" value="tag.date">Date &nbsp;&nbsp;
            <input type="radio" name="order_by" value="tag.config">Configuration &nbsp;&nbsp;
            <input type="checkbox" name="order" value="DESC">Descending
         </td>
      </tr>
      <tr class="row_head">
         <td colspan="4">Select search type, fill in parameters and click Search...</td>
         <td align="right">
            <img src="images/search_xp.gif" alt="Search" border="0"
               onClick="document.form1.submit();">
         </td>
      </tr>
   </form>
   </table> <?php
} ?>

<?php
function paint_table($db, &$summary) { ?>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><b>Asset Tag</b></td>
         <td><b>Make</b></td>
         <td><b>Model</b></td>
         <td><b>Serial</b></td>
         <td><b>Date</b></td>
         <td><b>PO</b></td>
         <td><b>Configuration</b></td>
         <td align="right"><b>Price</b></td>
      </tr> <?php
      $i = 1;
      while (!$summary->EOF) {
         $config_id = $summary->fields["config"];
         if ($config_id != 0) {
            $config = $db->Execute("SELECT name FROM config WHERE id=$config_id");
         }
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?>
         <td>
            <a href="search_asset.php?action=search_single&tag=<?php echo $summary->fields["tag"]; ?>">
               <?php echo $summary->fields["tag"]; ?></a>
         </td>
         <td><?php echo $summary->fields["make"]; ?></td>
         <td><?php echo $summary->fields["model"]; ?></td>
         <td><?php echo $summary->fields["serial"]; ?></td>
         <td><?php echo display_date($summary->fields["date"]); ?></td>
         <td> <?php
            if ($summary->fields["po"] != 0) { ?>
               <a href="ed_po.php?action=view_from_search&po_number=<?php echo $summary->fields["po"]; ?>">
                  <?php echo $summary->fields["po"]; ?></a> <?php
            } else {
               echo "None";
            } ?>
         </td>
         <td> <?php
            if ($config_id != 0) { ?>
               <a href="search_asset.php?action=search_config&order_by=equipment.tag&order=ASC&config_id=<?php echo $config_id; ?>">
                  <?php echo $config->fields["name"]; ?></a> <?php
            } else {
               echo "None";
            } ?>
         </td>
         <td align="right"><?php echo $summary->fields["price"]; ?></td>
      </tr><?php
         $i++;
         $summary->MoveNext();
      } ?>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td align="center"> <?php
            if (!$summary->AtFirstPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_asset.php?action=paged_query&page=<?php echo $summary->AbsolutePage() - 1; ?>">
                  <img src="images/prev_btn.gif" border="0" alt="Previous"></a> <?php
            }
            echo "&nbsp;";
            if (!$summary->AtLastPage() && $summary->AbsolutePage() != -1) { ?>
               <a href="search_asset.php?action=paged_query&page=<?php echo $summary->AbsolutePage() + 1; ?>">
                  <img src="images/next_btn.gif" border="0" alt="Next"></a> <?php
            } ?>
         </td>
      </tr>
   </table>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head"> <?php
         if ($summary->AbsolutePage() == -1) {
            echo "<td>&nbsp;</td>";
         } else {
            echo "<td>Page: " . $summary->AbsolutePage() . "</td>";
         } ?>
         <td align="right">
            <a href="search_asset.php?action=print_result"><img src="images/print_btn.gif" alt="Print Results" border="0"></a>
            <a href="search_asset.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
         </td>
      </tr>
   </table> <?php
} ?>

<?php
function search_config($db) {
   global $config_id, $order_by, $order;
   $query = "SELECT * FROM config WHERE id=$config_id";
   if (!$config = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   $_SESSION["search_query"] =
      "SELECT equipment.*, tag.*"
      . " FROM equipment, tag"
      . " WHERE equipment.tag='" . $config->fields["tag1"] . "'"
      . " AND tag.tag='" . $config->fields["tag1"] . "'"
      . " OR equipment.tag='" . $config->fields["tag2"] . "'"
      . " AND tag.tag='" . $config->fields["tag2"] . "'"
      . " OR equipment.tag='" . $config->fields["tag3"] . "'"
      . " AND tag.tag='" . $config->fields["tag3"] . "'"
      . " OR equipment.tag='" . $config->fields["tag4"] . "'"
      . " AND tag.tag='" . $config->fields["tag4"] . "'"
      . " OR equipment.tag='" . $config->fields["tag5"] . "'"
      . " AND tag.tag='" . $config->fields["tag5"] . "'"
      . " OR equipment.tag='" . $config->fields["tag6"] . "'"
      . " AND tag.tag='" . $config->fields["tag6"] . "'"
      . " OR equipment.tag='" . $config->fields["tag7"] . "'"
      . " AND tag.tag='" . $config->fields["tag7"] . "'"
      . " OR equipment.tag='" . $config->fields["tag8"] . "'"
      . " AND tag.tag='" . $config->fields["tag8"] . "'"
      . " ORDER BY $order_by $order";
   if (!$summary = $db->Execute($_SESSION["search_query"])) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($summary->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Your search returned 0 results.</td></tr></table>";
      search_form($db);
   } else {
      paint_table($db, $summary);
   }
} ?>

<?php
function show_assets($db) {
   global $action, $type_id, $org_id, $vendor_id, $from_date, $to_date,
          $order_by, $order, $make, $model;
   if ($from_date == "") {
      $from_date = "1980-01-01";
   } else {
      $from_date = valid_date($from_date);
   }
   if ($to_date == "") {
      $to_date = date("Y-m-d");
   } else {
      $to_date = valid_date($to_date);
   }
   if ($make == "") {
      $make = "%";
   } else {
      $make = "%" . $make . "%";
   }
   if ($model == "") {
      $model = "%";
   } else {
      $model = "%" . $model . "%";
   }
   if ($order != "DESC") {
      $order = "ASC";
   }
   $_SESSION["search_query"] =
      "SELECT equipment.*, tag.*"
      . " FROM equipment, tag"
      . " WHERE equipment.tag=tag.tag"
      . " AND tag.date>='$from_date'"
      . " AND tag.date<='$to_date'";
   if ($action == "search_org") {
      $_SESSION["search_query"] .= " AND tag.organization=$org_id";
   }
   if ($action == "search_type") {
      $_SESSION["search_query"] .= " AND equipment.equip_type=$type_id";
   }
   if ($action == "search_make_model") {
      $_SESSION["search_query"] .= " AND equipment.make LIKE '$make' AND equipment.model LIKE '$model'";
   }
   if ($action == "search_vendor") {
      $_SESSION["search_query"] .= " AND equipment.vendor=$vendor_id";
   }
   $_SESSION["search_query"] .= " ORDER BY $order_by $order";
   if (!$summary = paged_query($db)) {
      search_form($db);
   } else {
      paint_table($db, $summary);
   }
} ?>

<?php
function search_single($db, $tag) {
   if (!valid_tag($tag)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Asset Tag.</td></tr></table>";
      search_form($db);
      return FALSE;
   }
   $query = "SELECT equipment.*, tag.*"
          . " FROM equipment, tag"
          . " WHERE equipment.tag=$tag AND tag.tag=$tag";
   if (!$asset = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($asset->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Asset Tag $tag not found.</td></tr></table>";
      search_form($db);
      return FALSE;
   }
   $vendor_id = $asset->fields["vendor"];
   $type_id = $asset->fields["equip_type"];
   $org_id = $asset->fields["organization"];
   $config_id = $asset->fields["config"];
   $vendor = $db->Execute("SELECT name FROM vendor WHERE id=$vendor_id");
   $type = $db->Execute("SELECT descrip FROM equipment_type WHERE id=$type_id");
   $org = $db->Execute("SELECT name FROM organization WHERE id=$org_id");
   if ($config_id != 0) {
      $config = $db->Execute("SELECT name FROM config WHERE id=$config_id");
   } ?>
   <table class="default" border="0" width="100%" cellspacing="0" cellpadding="2">
    <tr class="row_head"> 
      <td colspan="4"><b>Asset Tag Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Tag Number:</td>
      <td colspan="3">
        <?php echo $asset->fields["tag"]; ?>
        <a href="ed_asset.php?action=edit&tag=<?php echo $asset->fields["tag"]; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Configuration:</td>
      <td colspan="3"> <?php
         if ($config_id != 0) {
            echo $config->fields["name"]; ?>
            <a href="search_asset.php?action=search_config&order_by=equipment.tag&order=ASC&config_id=<?php echo $config_id; ?>"><img src="images/view.gif" border="0" alt="View"></a>
            <a href="ed_config.php?action=edit&id=<?php echo $config_id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a> <?php
         } else {
            echo "None";
         } ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3">
         <?php echo $asset->fields["make"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3">
         <?php echo $asset->fields["model"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial:</td>
      <td colspan="3">
         <?php echo $asset->fields["serial"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> <?php
         if ($asset->fields["po"] != 0) {
            echo $asset->fields["po"]; ?>
            <a href="ed_po.php?action=view&po_number=<?php echo $asset->fields["po"]; ?>"><img src="images/view.gif" border="0" alt="View"></a>
            <a href="ed_po.php?action=edit&po_number=<?php echo $asset->fields["po"]; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a> <?php
         } else {
            echo "None";
         } ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Vendor:</td>
      <td>
         <?php echo $vendor->fields["name"]; ?>
         <a href="search_asset.php?action=view_vendor&vendor_id=<?php echo $vendor_id; ?>"><img src="images/view.gif" border="0" alt="View"></a>
         <a href="ed_vendor.php?action=edit&id=<?php echo $vendor_id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a>
      </td>
      <td align="right">Receive Date:</td>
      <td>
         <?php echo display_date($asset->fields["date"]); ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Price:</td>
      <td>
         <?php echo $asset->fields["price"]; ?>
      </td>
      <td align="right">Warranty Expires:</td>
      <td>
         <?php echo display_date($asset->fields["warranty"]); ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Equipment Type:</td>
      <td>         
         <?php echo $type->fields["descrip"]; ?>
      </td>
      <td align="right">Organization:</td>
      <td>
         <?php echo $org->fields["name"]; ?>
         <a href="search_asset.php?action=view_org&org_id=<?php echo $org_id; ?>"><img src="images/view.gif" border="0" alt="View"></a>
         <a href="ed_org.php?action=edit&id=<?php echo $org_id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3">
         <?php echo $asset->fields["descrip"]; ?>
      </td>
    </tr>
    <tr class="row_head">
      <td align="right" colspan="4">
            <a href="search_asset.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
      </td>
    </tr>
   </table> <?php
} ?>

<?php
function view_vendor($db, $id) {
   if (!$vendor = $db->Execute("SELECT * FROM vendor WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="2">
    <tr class="row_head"> 
      <td colspan="4"><b>View Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td colspan="3"><?php echo $vendor->fields["name"]; ?>
      <a href="ed_vendor.php?action=edit&id=<?php echo $id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 1:</td>
      <td colspan="3"><?php echo $vendor->fields["address1"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 2:</td>
      <td colspan="3"><?php echo $vendor->fields["address2"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">City:</td>
      <td><?php echo $vendor->fields["city"]; ?></td>
      <td align="right">Province/State:</td>
      <td><?php echo $vendor->fields["province"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Country:</td>
      <td><?php echo $vendor->fields["country"]; ?></td>
      <td align="right">Postal/ZIP Code:</td>
      <td><?php echo $vendor->fields["p_code"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Attention:</td>
      <td colspan="3"><?php echo $vendor->fields["attn"]; ?></td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td><?php echo $vendor->fields["main_phone"]; ?></td>
      <td align="right">FAX:</td>
      <td><?php echo $vendor->fields["main_fax"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td><?php echo $vendor->fields["main_email"]; ?></td>
      <td align="right">Web:</td>
      <td><?php echo $vendor->fields["main_www"]; ?></td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Technical or Support Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td><?php echo $vendor->fields["tech_phone"]; ?></td>
      <td align="right">FAX:</td>
      <td><?php echo $vendor->fields["tech_fax"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td><?php echo $vendor->fields["tech_email"]; ?></td>
      <td align="right">Web:</td>
      <td><?php echo $vendor->fields["tech_www"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td valign="top" align="right">Comments:</td>
      <td colspan="3"><?php echo $vendor->fields["comments"]; ?></td>
    </tr>
    <tr class="row_head"> 
      <td align="right" colspan="4">
         <a href="search_asset.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
    </tr>
  </table> <?php
} ?>

<?php
function view_org($db, $id) {
   if (!$org = $db->Execute("SELECT * FROM organization WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="2">
     <tr class="row_head"> 
       <td colspan="4"><b>Organization Information</b></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">Name:</td>
       <td><?php echo $org->fields["name"]; ?>
       <a href="ed_org.php?action=edit&id=<?php echo $id; ?>"><img src="images/edit.gif" border="0" alt="Edit"></a></td>
      <td align="right">Tax Exempt?</td>
      <td><?php echo $org->fields["tax_exempt"]; ?></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">Address 1:</td>
       <td colspan="3"><?php echo $org->fields["address1"]; ?></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">Address 2:</td>
       <td colspan="3"><?php echo $org->fields["address2"]; ?></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">City:</td>
       <td><?php echo $org->fields["city"]; ?></td>
       <td align="right">Province/State:</td>
       <td><?php echo $org->fields["province"]; ?></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">Country:</td>
       <td><?php echo $org->fields["country"]; ?></td>
       <td align="right">Postal/ZIP Code:</td>
       <td><?php echo $org->fields["p_code"]; ?></td>
     </tr>
     <tr class="row_head"> 
       <td colspan="4"><b>Main Contact Information</b></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">Name:</td>
       <td><?php echo $org->fields["contact"]; ?></td>
       <td align="right">Phone:</td>
       <td><?php echo $org->fields["phone"]; ?></td>
     </tr>
     <tr class="row_even"> 
       <td align="right">E-Mail:</td>
       <td><?php echo $org->fields["email"]; ?></td>
       <td align="right">FAX:</td>
       <td><?php echo $org->fields["fax"]; ?></td>
     </tr>
     <tr class="row_head"> 
       <td align="right" colspan="4">
         <a href="search_asset.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
     </tr>
   </table> <?php
} ?>

<?php
$action = strtolower($action);
switch ($action) {
   case "print_result": ?>
      <script language="JavaScript">
         window.open("print_html_search_asset.php");
      </script> <?php
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Search Results opened in a new browser window.</td></tr></table>";
      break;
   case "search_none":
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must select a Search Type from the drop menu.</td></tr></table>";
      search_form($db);
      break;
   case "search_single":
      search_single($db, $tag);
      break;
   case "search_all":
      show_assets($db);
      break;
   case "search_type":
      show_assets($db);
      break;
   case "search_make_model":
      show_assets($db);
      break;
   case "search_org":
      show_assets($db);
      break;
   case "search_vendor":
      show_assets($db);
      break;
   case "view_vendor":
      view_vendor($db, $vendor_id);
      break;
   case "view_org":
      view_org($db, $org_id);
      break;
   case "search_config":
      search_config($db);
      break;
   case "paged_query":
      $summary = paged_query($db, $page);
      paint_table($db, $summary);
      break;
   default:
      search_form($db);
}
require("footer.inc.php");
?>
