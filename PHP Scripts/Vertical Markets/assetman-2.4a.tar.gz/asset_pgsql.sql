--
-- PostgreSQL database dump
--

SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 3 (OID 2200)
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


SET search_path = public, pg_catalog;

--
-- TOC entry 31 (OID 17539)
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE config (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    tag1 integer DEFAULT 0 NOT NULL,
    tag2 integer DEFAULT 0 NOT NULL,
    tag3 integer DEFAULT 0 NOT NULL,
    tag4 integer DEFAULT 0 NOT NULL,
    tag5 integer DEFAULT 0 NOT NULL,
    tag6 integer DEFAULT 0 NOT NULL,
    tag7 integer DEFAULT 0 NOT NULL,
    tag8 integer DEFAULT 0 NOT NULL,
    comments text
) WITHOUT OIDS;


--
-- TOC entry 32 (OID 17539)
-- Name: config; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE config FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE config TO assetman;


--
-- TOC entry 33 (OID 17552)
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE equipment (
    tag integer NOT NULL,
    make character varying(30) NOT NULL,
    model character varying(30) NOT NULL,
    serial character varying(30) NOT NULL,
    vendor integer NOT NULL,
    price numeric(9,2) NOT NULL,
    warranty date,
    descrip text,
    equip_type integer NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 34 (OID 17552)
-- Name: equipment; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE equipment FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE equipment TO assetman;


--
-- TOC entry 35 (OID 17557)
-- Name: equipment_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE equipment_type (
    id integer DEFAULT 0 NOT NULL,
    descrip character varying(48) NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 36 (OID 17557)
-- Name: equipment_type; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE equipment_type FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE equipment_type TO assetman;


--
-- TOC entry 37 (OID 17560)
-- Name: inv_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inv_lines (
    id integer NOT NULL,
    inv_number integer NOT NULL,
    rcv_date date NOT NULL,
    rcv_by character varying(30),
    qty numeric(9,1) NOT NULL,
    descrip character varying(255) NOT NULL,
    unit_price numeric(9,2) NOT NULL,
    amount numeric(9,2) NOT NULL,
    taxable character(1) DEFAULT 'Y'::bpchar NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 38 (OID 17560)
-- Name: inv_lines; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE inv_lines FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inv_lines TO assetman;


--
-- TOC entry 39 (OID 17563)
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE invoices (
    inv_number integer NOT NULL,
    date date NOT NULL,
    organization integer NOT NULL,
    gl_credit character varying(12),
    gl_debit character varying(12),
    comments text,
    open character(1) DEFAULT 'Y'::bpchar NOT NULL,
    tax1 numeric(9,2) DEFAULT 0 NOT NULL,
    tax2 numeric(9,2) DEFAULT 0 NOT NULL,
    total numeric(9,2) DEFAULT 0 NOT NULL,
    created_by character varying(16),
    approved character(1) DEFAULT 'N'::bpchar NOT NULL,
    approved_by character varying(16)
) WITHOUT OIDS;


--
-- TOC entry 40 (OID 17563)
-- Name: invoices; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE invoices FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE invoices TO assetman;


--
-- TOC entry 41 (OID 17573)
-- Name: item_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item_master (
    id integer NOT NULL,
    make character varying(30) NOT NULL,
    model character varying(30) NOT NULL,
    serial character varying(30) NOT NULL,
    po_number integer DEFAULT 0 NOT NULL,
    date date NOT NULL,
    warranty date NOT NULL,
    descrip text NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 42 (OID 17573)
-- Name: item_master; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE item_master FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE item_master TO assetman;


--
-- TOC entry 43 (OID 17579)
-- Name: line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE line_items (
    id integer NOT NULL,
    po_number integer NOT NULL,
    qty integer NOT NULL,
    inv_qty integer NOT NULL,
    unit character varying(10) DEFAULT 'each'::character varying NOT NULL,
    descrip character varying(255),
    alloc character varying(16),
    unit_price numeric(9,2) NOT NULL,
    amount numeric(9,2) NOT NULL,
    received character(1) DEFAULT 'N'::bpchar NOT NULL,
    invoiced character(1) DEFAULT 'N'::bpchar NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 44 (OID 17579)
-- Name: line_items; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE line_items FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE line_items TO assetman;


--
-- TOC entry 45 (OID 17584)
-- Name: organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    address1 character varying(50) NOT NULL,
    address2 character varying(50),
    city character varying(30) NOT NULL,
    province character varying(10) NOT NULL,
    country character varying(30),
    p_code character varying(16) NOT NULL,
    contact character varying(50) NOT NULL,
    phone character varying(16),
    fax character varying(16),
    email character varying(50),
    tax_exempt character(1) DEFAULT 'N'::bpchar NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 46 (OID 17584)
-- Name: organization; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE organization FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE organization TO assetman;


--
-- TOC entry 47 (OID 17587)
-- Name: po; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE po (
    po_number integer NOT NULL,
    date date NOT NULL,
    vendor integer NOT NULL,
    organization integer NOT NULL,
    open character(1) DEFAULT 'Y'::bpchar NOT NULL,
    created_by character varying(16),
    approved character(1) DEFAULT 'N'::bpchar NOT NULL,
    approved_by character varying(16)
) WITHOUT OIDS;


--
-- TOC entry 48 (OID 17587)
-- Name: po; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE po FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE po TO assetman;


--
-- TOC entry 49 (OID 17591)
-- Name: tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tag (
    tag integer NOT NULL,
    date date NOT NULL,
    po integer DEFAULT 0 NOT NULL,
    organization integer DEFAULT 0 NOT NULL,
    config integer DEFAULT 0 NOT NULL
) WITHOUT OIDS;


--
-- TOC entry 50 (OID 17591)
-- Name: tag; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE tag FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE tag TO assetman;


--
-- TOC entry 51 (OID 17596)
-- Name: vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE vendor (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    address1 character varying(50) NOT NULL,
    address2 character varying(50),
    city character varying(30) NOT NULL,
    province character varying(10) NOT NULL,
    country character varying(30),
    p_code character varying(16) NOT NULL,
    attn character varying(50),
    main_phone character varying(16),
    main_fax character varying(16),
    main_email character varying(50),
    main_www character varying(50),
    tech_phone character varying(16),
    tech_fax character varying(16),
    tech_email character varying(50),
    tech_www character varying(50),
    comments text
) WITHOUT OIDS;


--
-- TOC entry 52 (OID 17596)
-- Name: vendor; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE vendor FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE vendor TO assetman;


--
-- TOC entry 4 (OID 17601)
-- Name: config_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE config_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 6 (OID 17601)
-- Name: config_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE config_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE config_seq TO assetman;


--
-- TOC entry 7 (OID 17603)
-- Name: equipment_type_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE equipment_type_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 9 (OID 17603)
-- Name: equipment_type_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE equipment_type_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE equipment_type_seq TO assetman;


--
-- TOC entry 10 (OID 17605)
-- Name: inv_lines_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inv_lines_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 12 (OID 17605)
-- Name: inv_lines_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE inv_lines_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE inv_lines_seq TO assetman;


--
-- TOC entry 13 (OID 17607)
-- Name: invoices_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE invoices_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 15 (OID 17607)
-- Name: invoices_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE invoices_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE invoices_seq TO assetman;


--
-- TOC entry 16 (OID 17609)
-- Name: item_master_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE item_master_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 18 (OID 17609)
-- Name: item_master_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE item_master_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE item_master_seq TO assetman;


--
-- TOC entry 19 (OID 17611)
-- Name: line_items_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE line_items_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 21 (OID 17611)
-- Name: line_items_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE line_items_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE line_items_seq TO assetman;


--
-- TOC entry 22 (OID 17613)
-- Name: organization_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 24 (OID 17613)
-- Name: organization_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE organization_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE organization_seq TO assetman;


--
-- TOC entry 25 (OID 17615)
-- Name: po_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE po_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 27 (OID 17615)
-- Name: po_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE po_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE po_seq TO assetman;


--
-- TOC entry 28 (OID 17617)
-- Name: vendor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE vendor_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 30 (OID 17617)
-- Name: vendor_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE vendor_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE vendor_seq TO assetman;


--
-- TOC entry 53 (OID 17619)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    username character varying(16) NOT NULL,
    "password" character varying(48) NOT NULL,
    priv character(1) DEFAULT '1'::bpchar NOT NULL,
    email character varying(64),
    fullname character varying(48)
) WITHOUT OIDS;


--
-- TOC entry 54 (OID 17619)
-- Name: users; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE users FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE users TO assetman;


--
-- Data for TOC entry 71 (OID 17539)
-- Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO config VALUES (2, '--- Select Configuration ---', 0, 0, 0, 0, 0, 0, 0, 0, 'dummy record');


--
-- Data for TOC entry 72 (OID 17552)
-- Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 73 (OID 17557)
-- Name: equipment_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO equipment_type VALUES (2, '--- Select Equipment Type ---');


--
-- Data for TOC entry 74 (OID 17560)
-- Name: inv_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 75 (OID 17563)
-- Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 76 (OID 17573)
-- Name: item_master; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 77 (OID 17579)
-- Name: line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 78 (OID 17584)
-- Name: organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO organization VALUES (2, '--- Select Organization ---', 'dummy record', '', 'city', 'province', 'country', 'postal code', '', '', '', '', 'N');


--
-- Data for TOC entry 79 (OID 17587)
-- Name: po; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 80 (OID 17591)
-- Name: tag; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for TOC entry 81 (OID 17596)
-- Name: vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO vendor VALUES (2, '--- Select Vendor ---', 'dummy record', '', 'city', 'province', 'country', 'postal code', '', '', '', '', '', '', '', '', '', NULL);


--
-- Data for TOC entry 82 (OID 17619)
-- Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO users VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', '4', 'admin@domain.com', 'AssetMan Administrator');
INSERT INTO users VALUES ('read', 'ecae13117d6f0584c25a9da6c8f8415e', '1', 'read@domain.com', 'Read Only User');
INSERT INTO users VALUES ('super', '1b3231655cebb7a1f783eddf27d254ca', '3', 'super@domain.com', 'Supervisor');
INSERT INTO users VALUES ('write', 'efb2a684e4afb7d55e6147fbe5a332ee', '2', 'write@domain.com', 'Read / Write User');


--
-- TOC entry 58 (OID 17630)
-- Name: inv_lines_inv_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX inv_lines_inv_number_key ON inv_lines USING btree (inv_number);


--
-- TOC entry 62 (OID 17631)
-- Name: item_master_serial_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_master_serial_key ON item_master USING btree (serial);


--
-- TOC entry 64 (OID 17632)
-- Name: line_items_po_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX line_items_po_number_key ON line_items USING btree (po_number);


--
-- TOC entry 70 (OID 17633)
-- Name: users_priv_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_priv_key ON users USING btree (priv);


--
-- TOC entry 55 (OID 17634)
-- Name: config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- TOC entry 56 (OID 17636)
-- Name: equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (tag);


--
-- TOC entry 57 (OID 17638)
-- Name: equipment_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY equipment_type
    ADD CONSTRAINT equipment_type_pkey PRIMARY KEY (id);


--
-- TOC entry 59 (OID 17640)
-- Name: inv_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inv_lines
    ADD CONSTRAINT inv_lines_pkey PRIMARY KEY (id);


--
-- TOC entry 60 (OID 17642)
-- Name: invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (inv_number);


--
-- TOC entry 61 (OID 17644)
-- Name: item_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item_master
    ADD CONSTRAINT item_master_pkey PRIMARY KEY (id);


--
-- TOC entry 63 (OID 17646)
-- Name: line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- TOC entry 65 (OID 17648)
-- Name: organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- TOC entry 66 (OID 17650)
-- Name: po_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY po
    ADD CONSTRAINT po_pkey PRIMARY KEY (po_number);


--
-- TOC entry 67 (OID 17652)
-- Name: tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (tag);


--
-- TOC entry 68 (OID 17654)
-- Name: vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY vendor
    ADD CONSTRAINT vendor_pkey PRIMARY KEY (id);


--
-- TOC entry 69 (OID 17656)
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- TOC entry 5 (OID 17601)
-- Name: config_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('config_seq', 2, true);


--
-- TOC entry 8 (OID 17603)
-- Name: equipment_type_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('equipment_type_seq', 2, true);


--
-- TOC entry 11 (OID 17605)
-- Name: inv_lines_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inv_lines_seq', 1, true);


--
-- TOC entry 14 (OID 17607)
-- Name: invoices_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('invoices_seq', 10000, true);


--
-- TOC entry 17 (OID 17609)
-- Name: item_master_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('item_master_seq', 1, true);


--
-- TOC entry 20 (OID 17611)
-- Name: line_items_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('line_items_seq', 1, true);


--
-- TOC entry 23 (OID 17613)
-- Name: organization_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_seq', 2, true);


--
-- TOC entry 26 (OID 17615)
-- Name: po_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('po_seq', 10000, true);


--
-- TOC entry 29 (OID 17617)
-- Name: vendor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('vendor_seq', 2, true);


--
-- TOC entry 2 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';
