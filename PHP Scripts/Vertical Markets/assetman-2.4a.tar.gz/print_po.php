<?php
require("common.inc.php");
require("mail_and_print.inc.php");

function select_printer($po_number) {
   global $printer1, $printer2, $printer3, $printer4; ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="print_po.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="3" nowrap><b>Print Purchase Order <?php echo $po_number; ?></b></td>
    </tr>
    <tr class="row_even">
      <td align="right">Select Printer:</td>
      <td> 
         <select name="printer">
             <option value="printer1"><?php echo $printer1["name"]; ?></option>
             <option value="printer2"><?php echo $printer2["name"]; ?></option>
             <option value="printer3"><?php echo $printer3["name"]; ?></option>
             <option value="printer4"><?php echo $printer4["name"]; ?></option>
         </select>
      </td>
      <td>
         <img src="images/print_xp.gif" alt="Print Purchase Order" border="0"
            onClick="document.form1.submit();">
         <a href="print_po.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
    <input type="hidden" name="action" value="print_gd_po">
    <input type="hidden" name="po_number" value="<?php echo $po_number; ?>">
   </form>
   </table> <?php
} ?>

<?php
function print_gd_po($db, $po_number, $printer) {
   global $cfg, $printer1, $printer2, $printer3, $printer4;
   if (${$printer}["name"] == "NA" || ${$printer}["name"] == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Select a valid configured printer from the list.</td></tr></table>";
      select_printer($po_number);
      return FALSE;
   }
   if (!$po = $db->Execute("SELECT * FROM po WHERE po_number=$po_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($po->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $po_number not found.</td></tr></table>";
      return FALSE;
   }
   $cr_username = $po->fields["created_by"];
   $appr_username = $po->fields["approved_by"];
   $org_id = $po->fields["organization"];
   $vendor_id = $po->fields["vendor"];
   $cr_userinfo = $db->Execute("SELECT fullname FROM users WHERE username='$cr_username'");
   $appr_userinfo = $db->Execute("SELECT fullname FROM users WHERE username='$appr_username'");
   $org = $db->Execute("SELECT * FROM organization WHERE id=$org_id");
   $vendor = $db->Execute("SELECT * FROM vendor WHERE id=$vendor_id");
   $line_items = $db->Execute("SELECT * FROM line_items WHERE po_number=$po_number ORDER BY id");
   echo "Generating document image. Please be patient...";
   flush();

   // Open the blank form image.
   $im = imagecreatefrompng("forms/po_template.png");
   $black = imagecolorallocate($im, 0, 0, 0);
   $white = imagecolorallocate($im, 255, 255, 255);

   // Fill in the form by drawing text on the image at appropriate coordinates.
   imagettftext($im, 20, 0, 900, 200, $black, $cfg["font_b"],
      $po_number);
   imagettftext($im, 20, 0, 10, 450, $black, $cfg["font_r"],
      display_date($po->fields["date"]));
   imagettftext($im, 20, 0, 125, 265, $black, $cfg["font_r"],
      $vendor->fields["name"]);
   imagettftext($im, 20, 0, 125, 302, $black, $cfg["font_r"],
      $vendor->fields["address1"]);
   imagettftext($im, 20, 0, 125, 339, $black, $cfg["font_r"],
      $vendor->fields["city"] . ", " . $vendor->fields["province"] . ", " . $vendor->fields["p_code"]);
   imagettftext($im, 20, 0, 125, 376, $black, $cfg["font_r"],
      "Attn: " . $vendor->fields["attn"]);
   imagettftext($im, 20, 0, 820, 265, $black, $cfg["font_r"],
      $org->fields["name"]);
   imagettftext($im, 20, 0, 820, 302, $black, $cfg["font_r"],
      $org->fields["address1"]);
   imagettftext($im, 20, 0, 820, 339, $black, $cfg["font_r"],
      $org->fields["city"] . ", " . $org->fields["province"] . ", " . $org->fields["p_code"]);
   imagettftext($im, 20, 0, 820, 376, $black, $cfg["font_r"],
      "Attn: " . $org->fields["contact"]);
   $i = 1;
   $po_total = 0;
   $ppl = 36; // Pixels per line
   $baseline = 519; // Starting Y coordinate. Pixels - $ppl
   while (!$line_items->EOF) {
      $y = $baseline + $ppl * $i;
      imagettftext($im, 16, 0, 10, $y, $black, $cfg["font_r"], $i);
      imagettftext($im, 16, 0, 55, $y, $black, $cfg["font_r"],
         $line_items->fields["qty"]);
      imagettftext($im, 16, 0, 145, $y, $black, $cfg["font_r"],
         $line_items->fields["unit"]);
      imagettftext($im, 16, 0, 220, $y, $black, $cfg["font_r"],
         $line_items->fields["descrip"]);
      $bbox = imagettfbbox(12, 0, $cfg["font_r"], $line_items->fields["alloc"]);
      imagettftext($im, 12, 0, 880 - $bbox[2], $y, $black, $cfg["font_r"],
         $line_items->fields["alloc"]);
      if ($line_items->fields["unit_price"] != 0 ) {
         $bbox = imagettfbbox(16, 0, $cfg["font_r"], $line_items->fields["unit_price"]);
         imagettftext($im, 16, 0, 1030 - $bbox[2], $y, $black, $cfg["font_r"],
            $line_items->fields["unit_price"]);
         $bbox = imagettfbbox(16, 0, $cfg["font_r"], $line_items->fields["amount"]);
         imagettftext($im, 16, 0, 1180 - $bbox[2], $y, $black, $cfg["font_r"],
            $line_items->fields["amount"]);
      }
      $po_total += $line_items->fields["amount"];
      $i++;
      $line_items->MoveNext();
   }
   if ($po_total != 0) {
      $bbox = imagettfbbox(16, 0, $cfg["font_b"], sprintf("%s%01.2f", $cfg["curr"], $po_total));
      imagettftext($im, 16, 0, 1180 - $bbox[2], 1375, $black, $cfg["font_b"],
         sprintf("%s%01.2f", $cfg["curr"], $po_total));
   }
   imagettftext($im, 20, 0, 20, 1455, $black, $cfg["font_r"],
      $cr_userinfo->fields["fullname"]);
   imagettftext($im, 20, 0, 415, 1455, $black, $cfg["font_r"],
      $appr_userinfo->fields["fullname"]);

   // Save the filled in form image...
   imagepng($im, "var/" . session_id() . ".png");
   // And print it.
   if (print_image($printer, "po_" . $po_number . ".pdf"))
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Purchase Order $po_number job queued to " . ${$printer}["name"] . " for print/email/download.</td></tr></table>";
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Print Purchase Order $po_number job cancelled.</td></tr></table>";
         break;
      case "print_gd_po":
         print_gd_po($db, $po_number, $printer);
         break;
      default:
         if ($cfg["gd"] == TRUE) {
            select_printer($po_number);
         } else { ?>
            <script language="JavaScript">
               window.open("print_html_po.php?po_number=<?php echo $po_number; ?>");
            </script> <?php
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Purchase Order $po_number opened in a new browser window.</td></tr></table>";
         }
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
