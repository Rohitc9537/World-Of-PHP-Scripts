<?php
require("config.inc.php");
session_name($cfg["session"]);
session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $fullname = $_SESSION["fullname"];
} else {
   header("Status: 302 Found");
   header("Location: login.php");
}

// Tell browsers not to cache this page
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");

// Include required files
require("grab_globals.inc.php");
require("connection.inc.php");
require("header.inc.php");

// Some functions needed by several pages. Try to move functions required often
// to this file.

function check_tags($db, $tags) {
// Used by new_config and ed_config to ensure that an asset tag exists
// in only one configuration.
   $message = "<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"1\">";
   $error = FALSE;
   for ($i = 0; $i < count($tags); $i++) {
      if (valid_tag($tags[$i])) {
         $asset = $db->Execute("SELECT tag, config FROM tag WHERE tag=$tags[$i]");
         if ($asset->RecordCount() == 0) {
            $error = TRUE;
            $message .= "<tr class=\"notice\"><td>Asset Tag $tags[$i] does not exist.</td></tr>\n";
         }
         if ($asset->fields["config"] != 0) {
            $query = "SELECT * FROM config WHERE id=" . $asset->fields["config"];
            $config = $db->Execute($query);
            $error = TRUE;
            $message .= "<tr class=\"notice\"><td>Asset Tag <a href=\"search_asset.php?action=show_single&tag=$tags[$i]\">$tags[$i]</a>";
            $message .= " already exists in configuration <a href=\"ed_config.php?action=edit&id=";
            $message .= $config->fields["id"] . "\">" . $config->fields["name"] . "</a>.</td></tr>\n";
         }
      }
   }
   $message .= "</table>";
   if ($error == TRUE) {
      echo $message;
      return FALSE;
   }
   return TRUE;
}

function paged_query($db, $page = 1) {
// Used by search_*.php to generate paged recordsets.
   global $cfg;
   // First, check for an empty result.
   if (!$rstest = $db->SelectLimit($_SESSION["search_query"], 1)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($rstest->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Your search returned 0 results.</td></tr></table>";
      return FALSE;
   }
   $rstest->Close();
   // Recordset is not empty so go ahead and page it.
   if (!$summary = $db->PageExecute($_SESSION["search_query"], $cfg["lpp"], $page)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return $summary;
}

function valid_date($date) {
// Validates and converts local format date to ISO format suitable for
// insertion into a database -OR- calculates a date relative to today given a
// number of days in the future or in the past.
   global $cfg;
   if (ereg("^([\+\-]{1})([0-9]+)$", $date, $shortcut)) {
   // $date is a shortcut so calculate and return a date in the future or the
   // in the past relative to today.
      $date = date("Y-m-d");
      list($year, $month, $day) = split("-", $date);
      switch ($shortcut[1]) {
         case "+":
            $date = date("Y-m-d", mktime(0, 0, 0, $month, $day + $shortcut[2], $year));
            break;
         case "-":
            $date = date("Y-m-d", mktime(0, 0, 0, $month, $day - $shortcut[2], $year));
            break;
      }
   return $date;
   }
   switch ($cfg["date_fmt"]) {
   // $date is a date in one format or another. Convert to and return an
   // ISO format date if required or FALSE on error.
      case "usa":
         if (!ereg("^[0-9]{2}\/{1}[0-9]{2}\/{1}[0-9]{4}$", $date)) return FALSE;
         list($month, $day, $year) = split("/", $date);
         $date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
         break;
      case "int":
         if (!ereg("^[0-9]{2}\/{1}[0-9]{2}\/{1}[0-9]{4}$", $date)) return FALSE;
         list($day, $month, $year) = split("/", $date);
         $date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
         break;
      default:
         if (!ereg("^[0-9]{4}\-{1}[0-9]{2}\-{1}[0-9]{2}$", $date)) return FALSE;
   }
   return $date;
}

function display_date($date) {
// Converts an ISO format date selected from database to local format for display.
   global $cfg;
   list($year, $month, $day) = split("-", $date);
   $date = date($cfg["date_arg"], mktime(0, 0, 0, $month, $day, $year));
   return $date;
}


function valid_warranty($rcv_date, $period) {
// Calculates a valid warranty expiration date given a valid receive date and
// a warranty period in years. OR, validates date input format. Returns a valid
// date in ISO format in the future or the unmodified receive date by default.
   if (ereg("^([\+]{1})([0-9]+)$", $period, $shortcut)) {
   // $period is a shortcut so calculate the expiry date.
      if ($shortcut[2] > 99) {
         $shortcut[2] = 99;
      }
      list($year, $month, $day) = split("-", $rcv_date);
      $exp_date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year + $shortcut[2]));
   } else if (!$exp_date = valid_date($period)) { 
   // $period is an absolute date so validate it. Return the receive date if that fails.
      $exp_date = $rcv_date;
   }
   return $exp_date;
}

function valid_po($db, $po) {
// Checks for valid purchase order that exists in the database.
// If user left the field blank, return TRUE.
// If user entered something else, check for a valid PO.
   if (empty($po)) {
      return TRUE;
   }
   $record = $db->Execute("SELECT * FROM po WHERE po_number=$po");
   if ($record->RecordCount() == 0) {
      return FALSE;
   }
   return TRUE;
}

function valid_tag($tag) {
// Checks for valid tag input format. Returns TRUE or FALSE.
   if (!ereg("^[1-9]{1}[0-9]{4}$", $tag)) {
      return FALSE;
   }
   return TRUE;
}

function valid_char_1($value) {
// Checks to ensure character 1 of string value is a valid alphanumeric character
// and not a space or other character.
   if (!ereg("^[a-zA-Z0-9]{1}.*$", $value)) {
      return FALSE;
   }
   return TRUE;
}
?>

