<?php require("common.inc.php"); ?>

<?php function display_form($name = FALSE, $tags = FALSE, $comments = FALSE) { 
   if ($tags === FALSE) $tags = array(0, 0, 0, 0, 0, 0, 0, 0); ?>
   <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
   <form action="new_config.php" method="post" name="form1">
      <tr> 
         <td colspan="4" class="row_head"><b>New Configuration Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Descriptive Name:</td>
         <td colspan="3"> 
            <input type="text" name="name" size="40" <?php
            if ($name !== FALSE) {
               echo "value=\"$name\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 1:</td>
         <td> 
            <input type="text" name="tag1" size="12" <?php
            if ($tags[0] != 0) {
               echo "value=\"$tags[0]\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 2:</td>
         <td> 
            <input type="text" name="tag2" size="12" <?php
            if ($tags[1] != 0) {
               echo "value=\"$tags[1]\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 3:</td>
         <td>
            <input type="text" name="tag3" size="12" <?php
            if ($tags[2] != 0) {
               echo "value=\"$tags[2]\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 4:</td>
         <td> 
            <input type="text" name="tag4" size="12" <?php
            if ($tags[3] != 0) {
               echo "value=\"$tags[3]\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 5:</td>
         <td>
            <input type="text" name="tag5" size="12" <?php
            if ($tags[4] != 0) {
               echo "value=\"$tags[4]\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 6:</td>
         <td> 
            <input type="text" name="tag6" size="12" <?php
            if ($tags[5] != 0) {
               echo "value=\"$tags[5]\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Tag 7:</td>
         <td>
            <input type="text" name="tag7" size="12" <?php
            if ($tags[6] != 0) {
               echo "value=\"$tags[6]\">";
            } else {
               echo ">";
            } ?>
         </td>
         <td align="right">Tag 8:</td>
         <td> 
            <input type="text" name="tag8" size="12" <?php
            if ($tags[7] != 0) {
               echo "value=\"$tags[7]\">";
            } else {
               echo ">";
            } ?>
         </td>
      </tr>
      <tr class="row_even"> 
         <td align="right" valign="top">Comments:</td>
         <td colspan="3"> 
            <textarea name="comments" cols="50" rows="5"><?php
               if ($comments !== FALSE) echo $comments; ?></textarea>
         </td></tr>
      <tr class="row_even"> 
         <td colspan="4">
            <img src="images/enter_xp.gif" border="0" alt="Enter"
               onClick="if (valid_config_form(document.form1)) { document.form1.submit(); }">
            <img src="images/reset_xp.gif" border="0" alt="Reset"
               onClick="document.form1.reset();">
            <a href="new_config.php?action=cancel">
               <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
         </td>
      </tr>
   <input type="hidden" name="action" value="Insert">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.name.focus();
   </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Configuration Dictionary update cancelled.</td></tr></table>";
         break;
      case "insert":
         if ($tag1 == "") $tag1 = 0;
         if ($tag2 == "") $tag2 = 0;
         if ($tag3 == "") $tag3 = 0;
         if ($tag4 == "") $tag4 = 0;
         if ($tag5 == "") $tag5 = 0;
         if ($tag6 == "") $tag6 = 0;
         if ($tag7 == "") $tag7 = 0;
         if ($tag8 == "") $tag8 = 0;
         $tags = array($tag1, $tag2, $tag3, $tag4, $tag5, $tag6, $tag7, $tag8);
         rsort($tags);
         if (!valid_char_1($name)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid configuration name.</td></tr></table>";
            display_form(stripslashes($name), $tags, stripslashes($comments));
            break;
         }
         if (!check_tags($db, $tags)) {
            display_form(stripslashes($name), $tags, stripslashes($comments));
            break;
         }
         $id = $db->GenID("config_seq");
         $query = "INSERT INTO config (id, name, tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, comments)"
                . " VALUES ('$id', " . $db->QMagic($name) . ", '$tags[0]', '$tags[1]', '$tags[2]', '$tags[3]', '$tags[4]', '$tags[5]', '$tags[6]', '$tags[7]', " . $db->QMagic($comments) . ")";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         for ($i = 0; $i < count($tags); $i++ ) {
            if (valid_tag($tags[$i])) {
               $query = "UPDATE tag SET config='$id' WHERE tag=$tags[$i]";
               if (!$db->Execute($query)) {
                  echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
                  break;
               }
            }
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Configuration Dictionary updated OK.<a href=\"new_config.php\"><img src=\"images/add_btn.gif\" border=\"0\" alt=\"Add\"></a>another new configuration.</td></tr></table>";
         break;
      default:
         display_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
