<?php require("common.inc.php"); ?>

<?php
function vendor_form($db) {
   if (!$vendors = $db->Execute("SELECT name, id FROM vendor ORDER BY name")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="ed_vendor.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Choose Vendor:</td>
      <td>
         <?php echo $vendors->GetMenu("id", "", FALSE, FALSE, 0,
                                   "onChange='document.form1.submit();'"); ?>
      </td>
    </tr>
   <input type="hidden" name="action" value="edit">
   </form>
   </table> <?php
} ?>

<?php
function delete_vendor($db, $id) {
   $equipment = $db->Execute("SELECT COUNT(tag) FROM equipment WHERE vendor=$id");
   $po = $db->Execute("SELECT COUNT(po_number) FROM po WHERE vendor=$id");
   if ($equipment->fields[0] > 0 || $po->fields[0] > 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>There are references to this vendor in other dictionaries. You may not delete this vendor.</td></tr></table>";
      return FALSE;
   }
   if (!$db->Execute("DELETE FROM vendor WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

function edit_form($db, $id) {
   if (!$vendor = $db->Execute("SELECT * FROM vendor WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_vendor.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="4"><b>Update Vendor Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Name:</td>
      <td colspan="3"> 
        <input type="text" name="name" size="40"
           value="<?php echo $vendor->fields["name"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 1:</td>
      <td colspan="3"> 
        <input type="text" name="address1" size="40"
           value="<?php echo $vendor->fields["address1"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Address 2:</td>
      <td colspan="3"> 
        <input type="text" name="address2" size="40"
           value="<?php echo $vendor->fields["address2"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">City:</td>
      <td> 
        <input type="text" name="city" size="20"
           value="<?php echo $vendor->fields["city"]; ?>">
      </td>
      <td align="right">Province/State:</td>
      <td> 
        <input type="text" name="province" size="12"
           value="<?php echo $vendor->fields["province"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Country:</td>
      <td> 
        <input type="text" name="country" size="20"
           value="<?php echo $vendor->fields["country"]; ?>">
      </td>
      <td align="right">Postal/ZIP Code:</td>
      <td> 
        <input type="text" name="p_code" size="12"
           value="<?php echo $vendor->fields["p_code"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Attention:</td>
      <td colspan="3">
        <input type="text" name="attn" size="40"
           value="<?php echo $vendor->fields["attn"]; ?>">
      </td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Main Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="main_phone" size="20"
           value="<?php echo $vendor->fields["main_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="main_fax" size="20"
           value="<?php echo $vendor->fields["main_fax"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="main_email" size="30"
           value="<?php echo $vendor->fields["main_email"]; ?>">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="main_www" size="30"
           value="<?php echo $vendor->fields["main_www"]; ?>">
      </td>
    </tr>
    <tr class="row_head"> 
      <td colspan="4"><b>Technical or Support Contact Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Phone:</td>
      <td> 
        <input type="text" name="tech_phone" size="20"
           value="<?php echo $vendor->fields["tech_phone"]; ?>">
      </td>
      <td align="right">FAX:</td>
      <td> 
        <input type="text" name="tech_fax" size="20"
           value="<?php echo $vendor->fields["tech_fax"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">E-Mail:</td>
      <td> 
        <input type="text" name="tech_email" size="30"
           value="<?php echo $vendor->fields["tech_email"]; ?>">
      </td>
      <td align="right">Web:</td>
      <td> 
        <input type="text" name="tech_www" size="30"
           value="<?php echo $vendor->fields["tech_www"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td valign="top" align="right">Comments:</td>
      <td colspan="3"> 
        <textarea name="comments" cols="50" rows="5"
           wrap="VIRTUAL"><?php echo $vendor->fields["comments"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4">
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_vendor_form(document.form2)) { document.form2.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Vendor ?')) { window.location='ed_vendor.php?action=delete&id=<?php echo $id; ?>'; }">
         <a href="ed_vendor.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="Update">
  <input type="hidden" name="id" value="<?php echo $id; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.name.focus();
  </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (delete_vendor($db, $id)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary updated OK.<a href=\"ed_vendor.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Vendor.</td></tr></table>";
         }
         break;
      case "update":
         if (!valid_char_1($name)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid vendor name.</td></tr></table>";
            edit_form($db, $id);
            break;
         }
         $query = "UPDATE vendor SET"
                . " name=" . $db->QMagic($name) . ", attn=" . $db->QMagic($attn) . ","
                . " address1=" . $db->QMagic($address1) . ", address2=" . $db->QMagic($address2) . ","
                . " city=" . $db->QMagic($city) . ", province=" . $db->QMagic($province) . ","
                . " country=" . $db->QMagic($country) . ", p_code=" . $db->QMagic($p_code) . ","
                . " main_phone='$main_phone', main_fax='$main_fax',"
                . " main_email=" . $db->QMagic($main_email) . ", main_www=" . $db->QMagic($main_www) . ","
                . " tech_phone='$tech_phone', tech_fax='$tech_fax',"
                . " tech_email=" . $db->QMagic($tech_email) . ", tech_www=" . $db->QMagic($tech_www) . ","
   	          . " comments=" . $db->QMagic($comments) . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Vendor Dictionary updated OK.<a href=\"ed_vendor.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Vendor.</td></tr></table>";
         break;
      case "edit":
         edit_form($db, $id);
         break;
      default:
         vendor_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
