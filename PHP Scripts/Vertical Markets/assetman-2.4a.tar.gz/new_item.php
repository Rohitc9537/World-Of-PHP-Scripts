<?php require("common.inc.php"); ?>

<?php
function insert_from_po($db, $line_id) {
   global $cfg;
   if (!$line_item = $db->Execute("SELECT * FROM line_items WHERE id=$line_id")) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
         return false;
   } ?>
  <table class="default" border="0" width="100%" cellspacing="0" cellpadding="1">
  <form action="new_item.php" method="post" name="form1">
    <tr class="row_head"> 
      <td colspan="4"><b>New Item Master Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="make">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="model">
      </td>
    </tr>
    <tr class="notice">
      <td colspan="4">
         Carefully enter <b><?php echo $line_item->fields["qty"]; ?></b> serial number(s)
         separated by commas. eg: 123ab456, 321ba654, ...
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Serial:</td>
      <td colspan="3"> 
        <textarea name="serial" rows="2" cols="50" wrap="virtual"></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> 
        <input type="text" name="po_number" size="12"
           value="<?php echo $line_item->fields["po_number"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Receive Date:</td>
      <td> 
        <input type="text" size="12" name="date"
           value="<?php echo date($cfg["date_arg"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
      <td align="right">Warranty Expires:</td>
      <td>
         <input type="text" size="12" name="warranty"><?php echo $cfg["date_exp"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3"> 
        <textarea name="descrip" rows="5" cols="50"
           wrap="virtual"><?php echo $line_item->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="notice">
      <td colspan="4">
         <b><?php echo $line_item->fields["qty"]; ?></b> identical records (except for
         Serial) will be added to the Item Master Dictionary. Click Cancel if this
         is not correct. The PO line item will not be marked received.
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4">
         <img src="images/enter_xp.gif" border="0" alt="Enter"
            onClick="if (valid_item_form(document.form1)) { document.form1.submit(); }">
         <img src="images/reset_xp.gif" border="0" alt="Reset"
            onClick="document.form1.reset();">
         <a href="new_item.php?action=cancel">
            <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="insert_all">
  <input type="hidden" name="num_records" value="<?php echo $line_item->fields["qty"]; ?>"> 
  <input type="hidden" name="line_id" value="<?php echo $line_id; ?>"> 
  </form>
  </table>
  <script language="JavaScript">
     document.form1.make.focus();
  </script> <?php
} ?>

<?php
function display_form($db) {
   global $cfg; ?>
  <table class="default" border="0" width="100%" cellspacing="0" cellpadding="1">
  <form action="new_item.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="4"><b>New Item Master Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="make">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="model">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="serial">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> 
        <input type="text" name="po_number" size="12">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Receive Date:</td>
      <td> 
        <input type="text" size="12" name="date"
           value="<?php echo date($cfg["date_arg"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
      <td align="right">Warranty Expires:</td>
      <td> 
        <input type="text" size="12" name="warranty"><?php echo $cfg["date_exp"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3"> 
        <textarea name="descrip" rows="5" cols="50"></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4"> 
         <img src="images/enter_xp.gif" border="0" alt="Enter"
            onClick="if (valid_item_form(document.form2)) { document.form2.submit(); }">
         <img src="images/reset_xp.gif" border="0" alt="Reset"
            onClick="document.form2.reset();">
         <a href="new_item.php?action=cancel">
            <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="insert">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.make.focus();
  </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary update cancelled.</td></tr></table>";
         break;
      case "from_po":
         insert_from_po($db, $line_id);
         break;
      case "insert":
         if (!$date = valid_date($date)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid date format.</td></tr></table>";
            display_form($db);
            break;
         }
         if (!valid_po($db, $po_number)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid purchase order number"
                 . " or leave the field blank if the PO number is unknown.</td></tr></table>";
            display_form($db);
            break;
         }
         if (empty($po_number)) {
            $po_number = 0;
         }
         $warranty = valid_warranty($date, $warranty);
         $id = $db->GenID("item_master_seq");
         $query = "INSERT INTO item_master (id, make, model, serial, po_number, date, warranty, descrip)"
                . " VALUES ('$id', " . $db->QMagic($make) . ", " . $db->QMagic($model) . ", " . $db->QMagic($serial) . ","
                . " '$po_number', '$date', '$warranty', " . $db->QMagic($descrip) . ")";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary updated OK.<a href=\"new_item.php\"><img src=\"images/add_btn.gif\" border=\"0\" alt=\"Add\"></a> another new item.</td></tr></table>";
         break;
      case "insert_all":
         if (!valid_po($db, $po_number)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid purchase order number"
                 . " or leave the field blank if the PO number is unknown.</td></tr></table>";
            insert_from_po($db, $line_id);
            break;
         }
         if (empty($po_number)) {
            $po_number = 0;
         }
         if (!$date = valid_date($date)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid date format.</td></tr></table>";
            insert_from_po($db, $line_id);
            break;
         }
         $warranty = valid_warranty($date, $warranty);
         $serial_num = explode(",", $serial);
         if (count($serial_num) != $num_records) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>The number of records to add does not match"
                 . " the number of serial numbers you entered.</td></tr></table>";
            insert_from_po($db, $line_id);
            break;
         }
         if (!$db->Execute("UPDATE line_items SET received='Y' WHERE id=$line_id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         for ($i = 0; $i < $num_records; $i++) {
            $serial_num[$i] = trim($serial_num[$i]);
            $id = $db->GenID("item_master_seq");
            $query = "INSERT INTO item_master (id, make, model, serial, po_number, date, warranty, descrip)"
                   . " VALUES ('$id', " . $db->QMagic($make) . ", " . $db->QMagic($model) . ", " . $db->QMagic($serial_num[$i]) . ","
                   . " '$po_number', '$date', '$warranty', " . $db->QMagic($descrip) . ")";
            if (!$db->Execute($query)) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary updated OK."
              . " Resume<a href=\"ed_po.php?action=edit&po_number=$po_number\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>"
              . "of Purchase Order $po_number.</td></tr></table>";
         break;
      default:
         display_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>

