<?php require("common.inc.php"); ?>

<?php
function item_form() { ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
  <form action="ed_item.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Item Master Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial Number:</td>
      <td>
        <input type="text" name="serial" size="12">
        <input type="submit" value="Enter">
      </td>
    </tr>
  <input type="hidden" name="action" value="edit"> 
  </form>
</table>
<script language="JavaScript">
   document.form1.serial.focus();
</script> <?php
} ?>

<?php
function delete_item($db, $id) {
   if (!$db->Execute("DELETE FROM item_master WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
} ?>

<?php
function paint_table(&$summary) {
global $cfg ?>
   <table class="small" border="0" cellpadding="1" cellspacing="0" width="100%">
      <tr class="row_head">
         <td><b>Make</b></td>
         <td><b>Model</b></td>
         <td><b>Serial</b></td>
         <td><b>Date</b></td>
         <td><b>Description</b></td>
      </tr> <?php
      $i = 1;
      $summary->Move(0);
      while (!$summary->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         } ?>
         <td>
            <a href="ed_item.php?action=edit_id&id=<?php echo $summary->fields["id"]; ?>">
               <?php echo $summary->fields["make"]; ?></a>
         </td>
         <td><?php echo $summary->fields["model"]; ?></td>
         <td><?php echo $summary->fields["serial"]; ?></td>
         <td><?php echo display_date($summary->fields["date"]); ?></td>
         <td><?php echo $summary->fields["descrip"]; ?></td>
      </tr> <?php
         $i++;
         $summary->MoveNext();
      } ?>
      <tr class="row_head">
         <td align="right" colspan="5">
            Hmm... I don't see what I'm looking for.<a href="search_item.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>the Item Master Dictionary.
         </td>
      </tr>
   </table> <?php
} ?>

<?php
function get_item($db, $serial) {
   $query = "SELECT * FROM item_master WHERE serial='$serial'";
   if (!$item = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($item->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Item with serial number $serial not found.</td></tr></table>";
      item_form();
      return FALSE;
   }
   if ($item->RecordCount() > 1) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Multiple items with serial number $serial were found.</td></tr></table>";
      paint_table($item);
      return TRUE;
   }
   edit_form($db, $item->fields["id"]);
} ?>

<?php
function edit_form($db, $id) {
   global $cfg;
   $query = "SELECT * FROM item_master WHERE id=$id";
   if (!$item = $db->Execute($query)) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
  <table class="default" border="0" width="100%" cellspacing="0" cellpadding="1">
  <form action="ed_item.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="4"><b>Update Item Master Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Make:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="make"
           value="<?php echo $item->fields["make"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Model:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="model"
           value="<?php echo $item->fields["model"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Serial:</td>
      <td colspan="3"> 
        <input type="text" size="40" name="serial"
           value="<?php echo $item->fields["serial"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Purchase Order:</td>
      <td colspan="3"> 
        <input type="text" size="12" name="po_number" <?php
           if ($item->fields["po_number"] != 0) {
              echo "value=\"" . $item->fields["po_number"] . "\"";
           } ?>>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Receive Date:</td>
      <td> 
        <input type="text" size="12" name="date"
           value="<?php echo display_date($item->fields["date"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
      <td align="right">Warranty Expires:</td>
      <td> 
        <input type="text" size="12" name="warranty"
           value="<?php echo display_date($item->fields["warranty"]); ?>"><?php echo $cfg["date_exp"]; ?>
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="3"> 
        <textarea name="descrip" rows="5"
           cols="50"><?php echo $item->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="4"> 
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_item_form(document.form2)) { document.form2.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Item ?')) { window.location='ed_item.php?action=delete&id=<?php echo $item->fields["id"]; ?>'; }">
         <a href="ed_item.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="update">
  <input type="hidden" name="id" value="<?php echo $item->fields["id"]; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.make.focus();
  </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (!delete_item($db, $id)) {
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary updated OK.<a href=\"ed_item.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Item.</td></tr></table>";
         break;
      case "edit":
         get_item($db, $serial);
         break;
      case "edit_id":
         edit_form($db, $id);
         break;
      case "update":
         if (!$date = valid_date($date)) {
            edit_form($db, $id);
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid date format.</td></tr></table>";
            break;
         }
         if (!valid_po($db, $po_number)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid PO number"
                 . " or leave the field blank if the PO number is unknown.</td></tr></table>";
            edit_form($db, $id);
            break;
         }
         if (empty($po_number)) {
            $po_number = 0;
         }
         $warranty = valid_warranty($date, $warranty);
         $query = "UPDATE item_master SET"
                . " make=" . $db->QMagic($make) . ", model=" . $db->QMagic($model) . ","
                . " serial=" . $db->QMagic($serial) . ", po_number='$po_number',"
                . " date='$date', warranty='$warranty',"
                . " descrip=" . $db->QMagic($descrip) . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Item Master Dictionary updated OK.<a href=\"ed_item.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Item.</td></tr></table>";
         break;
      default:
         item_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
