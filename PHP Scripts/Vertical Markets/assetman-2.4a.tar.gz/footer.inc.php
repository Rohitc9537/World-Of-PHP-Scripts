<?php
// Disconnect from the database
$db->Close(); ?>
</body>
</html>
