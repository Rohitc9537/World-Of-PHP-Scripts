<?php
require("config.inc.php");
session_name($cfg["session"]);
session_start();
if (!empty($_SESSION) && isset($_SESSION["username"])) {
   $username = $_SESSION["username"];
   $priv = $_SESSION["priv"];
   $fullname = $_SESSION["fullname"];
} else {
   header("Status: 302 Found");
   header("Location: login.php");
}

if (file_exists($_GET["pdf_file"])) {
   $len = filesize($_GET["pdf_file"]);
   header("Content-Type: application/pdf");
   header("Content-Length: $len");
   header("Content-Disposition: inline");
   readfile($_GET["pdf_file"]);
   unlink($_GET["pdf_file"]);
} else {
   echo "The document you requested no longer exists. You'll need to reprint it.<br>" .
        "You probably clicked the refresh button. Close this window to return to AssetMan.";
}
?>
