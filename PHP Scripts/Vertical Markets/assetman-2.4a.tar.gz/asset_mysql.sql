# phpMyAdmin SQL Dump
# version 2.5.4
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Feb 26, 2004 at 11:13 AM
# Server version: 3.23.58
# PHP Version: 4.3.4
# 
# Database : `asset`
# 

# --------------------------------------------------------

#
# Table structure for table `config`
#

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `tag1` int(11) NOT NULL default '0',
  `tag2` int(11) NOT NULL default '0',
  `tag3` int(11) NOT NULL default '0',
  `tag4` int(11) NOT NULL default '0',
  `tag5` int(11) NOT NULL default '0',
  `tag6` int(11) NOT NULL default '0',
  `tag7` int(11) NOT NULL default '0',
  `tag8` int(11) NOT NULL default '0',
  `comments` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `config`
#

INSERT INTO `config` (`id`, `name`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`, `tag7`, `tag8`, `comments`) VALUES (1, '--- Select Configuration ---', 0, 0, 0, 0, 0, 0, 0, 0, 'dummy record');

# --------------------------------------------------------

#
# Table structure for table `config_seq`
#

DROP TABLE IF EXISTS `config_seq`;
CREATE TABLE `config_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `config_seq`
#

INSERT INTO `config_seq` (`id`) VALUES (1);

# --------------------------------------------------------

#
# Table structure for table `equipment`
#

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE `equipment` (
  `tag` int(11) NOT NULL default '0',
  `make` varchar(30) NOT NULL default '',
  `model` varchar(30) NOT NULL default '',
  `serial` varchar(30) NOT NULL default '',
  `vendor` int(11) NOT NULL default '0',
  `price` decimal(9,2) NOT NULL default '0.00',
  `warranty` date default NULL,
  `descrip` text,
  `equip_type` int(11) default NULL,
  PRIMARY KEY  (`tag`)
) TYPE=MyISAM;

#
# Dumping data for table `equipment`
#


# --------------------------------------------------------

#
# Table structure for table `equipment_type`
#

DROP TABLE IF EXISTS `equipment_type`;
CREATE TABLE `equipment_type` (
  `id` int(11) NOT NULL default '0',
  `descrip` varchar(48) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `equipment_type`
#

INSERT INTO `equipment_type` (`id`, `descrip`) VALUES (1, '--- Select Equipment Type ---');

# --------------------------------------------------------

#
# Table structure for table `equipment_type_seq`
#

DROP TABLE IF EXISTS `equipment_type_seq`;
CREATE TABLE `equipment_type_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `equipment_type_seq`
#

INSERT INTO `equipment_type_seq` (`id`) VALUES (1);

# --------------------------------------------------------

#
# Table structure for table `inv_lines`
#

DROP TABLE IF EXISTS `inv_lines`;
CREATE TABLE `inv_lines` (
  `id` int(11) NOT NULL default '0',
  `inv_number` int(11) NOT NULL default '0',
  `rcv_date` date NOT NULL default '0000-00-00',
  `rcv_by` varchar(30) default NULL,
  `qty` decimal(9,1) NOT NULL default '0.0',
  `descrip` varchar(255) NOT NULL default '',
  `unit_price` decimal(9,2) NOT NULL default '0.00',
  `amount` decimal(9,2) NOT NULL default '0.00',
  `taxable` enum('Y','N') NOT NULL default 'Y',
  PRIMARY KEY  (`id`),
  KEY `inv_number` (`inv_number`)
) TYPE=MyISAM;

#
# Dumping data for table `inv_lines`
#


# --------------------------------------------------------

#
# Table structure for table `inv_lines_seq`
#

DROP TABLE IF EXISTS `inv_lines_seq`;
CREATE TABLE `inv_lines_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `inv_lines_seq`
#

INSERT INTO `inv_lines_seq` (`id`) VALUES (0);

# --------------------------------------------------------

#
# Table structure for table `invoices`
#

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `inv_number` int(11) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `organization` int(11) NOT NULL default '0',
  `gl_credit` varchar(12) NOT NULL default '',
  `gl_debit` varchar(12) NOT NULL default '',
  `comments` text,
  `open` enum('Y','N') NOT NULL default 'Y',
  `tax1` decimal(9,2) NOT NULL default '0.00',
  `tax2` decimal(9,2) NOT NULL default '0.00',
  `total` decimal(9,2) NOT NULL default '0.00',
  `created_by` varchar(16) default NULL,
  `approved` enum('Y','N') NOT NULL default 'N',
  `approved_by` varchar(16) default NULL,
  PRIMARY KEY  (`inv_number`)
) TYPE=MyISAM;

#
# Dumping data for table `invoices`
#


# --------------------------------------------------------

#
# Table structure for table `invoices_seq`
#

DROP TABLE IF EXISTS `invoices_seq`;
CREATE TABLE `invoices_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `invoices_seq`
#

INSERT INTO `invoices_seq` (`id`) VALUES (10000);

# --------------------------------------------------------

#
# Table structure for table `item_master`
#

DROP TABLE IF EXISTS `item_master`;
CREATE TABLE `item_master` (
  `id` int(11) NOT NULL default '0',
  `make` varchar(30) NOT NULL default '',
  `model` varchar(30) NOT NULL default '',
  `serial` varchar(50) NOT NULL default '',
  `po_number` int(11) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `warranty` date NOT NULL default '0000-00-00',
  `descrip` text,
  PRIMARY KEY  (`id`),
  KEY `serial` (`serial`)
) TYPE=MyISAM;

#
# Dumping data for table `item_master`
#


# --------------------------------------------------------

#
# Table structure for table `item_master_seq`
#

DROP TABLE IF EXISTS `item_master_seq`;
CREATE TABLE `item_master_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `item_master_seq`
#

INSERT INTO `item_master_seq` (`id`) VALUES (0);

# --------------------------------------------------------

#
# Table structure for table `line_items`
#

DROP TABLE IF EXISTS `line_items`;
CREATE TABLE `line_items` (
  `id` int(11) NOT NULL default '0',
  `po_number` int(11) NOT NULL default '0',
  `qty` int(11) NOT NULL default '0',
  `inv_qty` int(11) NOT NULL default '0',
  `unit` varchar(10) default 'each',
  `descrip` varchar(255) NOT NULL default '',
  `alloc` varchar(16) default NULL,
  `unit_price` decimal(9,2) NOT NULL default '0.00',
  `amount` decimal(9,2) NOT NULL default '0.00',
  `received` enum('Y','N') NOT NULL default 'N',
  `invoiced` enum('Y','P','N') NOT NULL default 'N',
  PRIMARY KEY  (`id`),
  KEY `po_number` (`po_number`)
) TYPE=MyISAM;

#
# Dumping data for table `line_items`
#


# --------------------------------------------------------

#
# Table structure for table `line_items_seq`
#

DROP TABLE IF EXISTS `line_items_seq`;
CREATE TABLE `line_items_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `line_items_seq`
#

INSERT INTO `line_items_seq` (`id`) VALUES (0);

# --------------------------------------------------------

#
# Table structure for table `organization`
#

DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `address1` varchar(50) NOT NULL default '',
  `address2` varchar(50) default NULL,
  `city` varchar(30) NOT NULL default '',
  `province` varchar(10) NOT NULL default '',
  `country` varchar(30) default NULL,
  `p_code` varchar(16) NOT NULL default '',
  `contact` varchar(50) default NULL,
  `phone` varchar(16) default NULL,
  `fax` varchar(16) default NULL,
  `email` varchar(50) default NULL,
  `tax_exempt` enum('Y','N') NOT NULL default 'N',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `organization`
#

INSERT INTO `organization` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `p_code`, `contact`, `phone`, `fax`, `email`, `tax_exempt`) VALUES (1, '--- Select Organization ---', 'dummy record', '', 'city', 'province', 'country', 'postal code', '', '', '', '', 'N');

# --------------------------------------------------------

#
# Table structure for table `organization_seq`
#

DROP TABLE IF EXISTS `organization_seq`;
CREATE TABLE `organization_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `organization_seq`
#

INSERT INTO `organization_seq` (`id`) VALUES (1);

# --------------------------------------------------------

#
# Table structure for table `po`
#

DROP TABLE IF EXISTS `po`;
CREATE TABLE `po` (
  `po_number` int(11) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `vendor` int(11) NOT NULL default '0',
  `organization` int(11) NOT NULL default '0',
  `open` enum('Y','N') NOT NULL default 'Y',
  `created_by` varchar(16) default NULL,
  `approved` enum('Y','N') NOT NULL default 'N',
  `approved_by` varchar(16) default NULL,
  PRIMARY KEY  (`po_number`)
) TYPE=MyISAM;

#
# Dumping data for table `po`
#


# --------------------------------------------------------

#
# Table structure for table `po_seq`
#

DROP TABLE IF EXISTS `po_seq`;
CREATE TABLE `po_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `po_seq`
#

INSERT INTO `po_seq` (`id`) VALUES (10000);

# --------------------------------------------------------

#
# Table structure for table `tag`
#

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `tag` int(11) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `po` int(11) NOT NULL default '0',
  `organization` int(11) NOT NULL default '0',
  `config` int(11) NOT NULL default '0',
  PRIMARY KEY  (`tag`)
) TYPE=MyISAM;

#
# Dumping data for table `tag`
#


# --------------------------------------------------------

#
# Table structure for table `users`
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(16) NOT NULL default '',
  `password` varchar(48) NOT NULL default '',
  `priv` enum('1','2','3','4') NOT NULL default '1',
  `fullname` varchar(48) NOT NULL default '',
  `email` varchar(64) default NULL,
  PRIMARY KEY  (`username`),
  KEY `priv` (`priv`)
) TYPE=MyISAM;

#
# Dumping data for table `users`
#

INSERT INTO `users` (`username`, `password`, `priv`, `fullname`, `email`) VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', '4', 'AssetMan Administrator', 'admin@domain.com');
INSERT INTO `users` (`username`, `password`, `priv`, `fullname`, `email`) VALUES ('super', '1b3231655cebb7a1f783eddf27d254ca', '3', 'Supervisor', 'super@domain.com');
INSERT INTO `users` (`username`, `password`, `priv`, `fullname`, `email`) VALUES ('write', 'efb2a684e4afb7d55e6147fbe5a332ee', '2', 'Read / Write User', 'write@domain.com');
INSERT INTO `users` (`username`, `password`, `priv`, `fullname`, `email`) VALUES ('read', 'ecae13117d6f0584c25a9da6c8f8415e', '1', 'Read Only User', 'read@domain.com');

# --------------------------------------------------------

#
# Table structure for table `vendor`
#

DROP TABLE IF EXISTS `vendor`;
CREATE TABLE `vendor` (
  `id` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `address1` varchar(50) NOT NULL default '',
  `address2` varchar(50) default NULL,
  `city` varchar(30) NOT NULL default '',
  `province` varchar(10) NOT NULL default '',
  `country` varchar(30) default NULL,
  `p_code` varchar(16) NOT NULL default '',
  `attn` varchar(50) default NULL,
  `main_phone` varchar(16) default NULL,
  `main_fax` varchar(16) default NULL,
  `main_email` varchar(50) default NULL,
  `main_www` varchar(50) default NULL,
  `tech_phone` varchar(16) default NULL,
  `tech_fax` varchar(16) default NULL,
  `tech_email` varchar(50) default NULL,
  `tech_www` varchar(50) default NULL,
  `comments` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `vendor`
#

INSERT INTO `vendor` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `p_code`, `attn`, `main_phone`, `main_fax`, `main_email`, `main_www`, `tech_phone`, `tech_fax`, `tech_email`, `tech_www`, `comments`) VALUES (1, '--- Select Vendor ---', 'dummy record', '', 'city', 'province', 'country', 'postal code', '', '', '', '', '', '', '', '', '', NULL);

# --------------------------------------------------------

#
# Table structure for table `vendor_seq`
#

DROP TABLE IF EXISTS `vendor_seq`;
CREATE TABLE `vendor_seq` (
  `id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

#
# Dumping data for table `vendor_seq`
#

INSERT INTO `vendor_seq` (`id`) VALUES (1);
