<?php require("common.inc.php"); ?>

<?php
function type_form($db) {
   if (!$types = $db->Execute("SELECT descrip, id FROM equipment_type ORDER BY descrip")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="ed_types.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="2" nowrap><b>Update Equipment Type Information</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Choose Equipment Type:</td>
      <td>
          <?php echo $types->GetMenu("id", "", FALSE, FALSE, 0,
                "onChange='document.form1.submit();'"); ?>
      </td>
    </tr>
   <input type="hidden" name="action" value="query">
   </form>
    </table> <?php
} ?>

<?php
function delete_type($db, $id) {
   $equipment = $db->Execute("SELECT COUNT(tag) FROM equipment WHERE equip_type=$id");
   if ($equipment->fields[0] > 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>There are references to this equipment type in other dictionaries. You may not delete this equipment type.</td></tr></table>";
      return FALSE;
   }
   if (!$db->Execute("DELETE FROM equipment_type WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   return TRUE;
}

function edit_form($db, $id) {
   if (!$type = $db->Execute("SELECT * FROM equipment_type WHERE id=$id")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" align="center" width="80%" border="0" cellspacing="0" cellpadding="1">
   <form action="ed_types.php" method="post" name="form2">
      <tr> 
         <td colspan="4" class="row_head"><b>Update Equipment Type Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">Type ID:</td>
         <td><?php echo $type->fields["id"]; ?></td>
         <td align="right">Equipment Type:</td>
         <td><input type="text" name="descrip" size="40"
                value="<?php echo $type->fields["descrip"]; ?>"></td>
      </tr>
      <tr class="row_even"> 
         <td colspan="4">
            <img src="images/update_xp.gif" alt="Update" border="0"
               onClick="document.form2.submit();">
            <img src="images/delete_xp.gif" alt="Delete" border="0"
               onClick="if (isConfirmed('Are you sure you want to DELETE this Equipment Type ?')) { window.location='ed_types.php?action=delete&id=<?php echo $id; ?>'; }">
            <a href="ed_types.php?action=cancel">
               <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
         </td>
      </tr>
   <input type="hidden" name="action" value="update">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   </form>
   </table>
   <script language="JavaScript">
      document.form2.descrip.focus();
   </script> <?php
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Equipment Type Dictionary update cancelled.</td></tr></table>";
         break;
      case "delete":
         if (delete_type($db, $id)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Equipment Type Dictionary updated OK.<a href=\"ed_types.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Equipment Type.</td></tr></table>";
         }
         break;
      case "query":
         edit_form($db, $id);
         break;
      case "update":
         if (!valid_char_1($descrip)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid description.</td></tr></table>";
            edit_form($db, $id);
            break;
         }
         $query = "UPDATE equipment_type SET"
                . " descrip=" . $db->QMagic($descrip) . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Equipment Type Dictionary updated OK.<a href=\"ed_types.php\"><img src=\"images/edit_btn.gif\" border=\"0\" alt=\"Edit\"></a>another Equipment Type.</td></tr></table>";
         break;
      default:
         type_form($db);
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
