<?php
require("config.inc.php");
session_name($cfg["session"]);
session_start();
unset($username, $priv, $fullname);

require("grab_globals.inc.php");
require("connection.inc.php");
require("header.inc.php");

function user_form() { ?>
   <table class="default" border="0" cellpadding="10" width="100%"><tr><td>
      <table class="default" border="0" cellpadding="0" cellspacing="0" width="100%">
         <tr>
            <td align="left">
               <a href="http://www.bctree.com/~assetman">
                  <img src="images/assetman.gif" alt="Visit the AssetMan Web Site" border="0"></a>
               <hr>
            </td>
            <td align="center">
               <img src="images/ass.gif" alt="Festus the AssetMan Ass" border="0">
            </td>
         </tr>
      </table>
      <table class="default" align="center" border="0" cellpadding="1" cellspacing="0">
         <form action="login.php" method="post" name="form1">
         <tr class="row_head">
            <td align="center" colspan="2"><b>Are you Privileged? Ask Festus!</b></td>
         </tr>
         <tr class="row_even">
            <td align="center" colspan="2">&nbsp;</td>
         </tr>
         <tr class="row_even">
            <td align="right">Username:</td>
            <td><input type="text" name="uid" size="16"></td>
         </tr>
         <tr class="row_even">
            <td align="right">Password:</td>
            <td><input type="password" name="pwd" size="16"></td>
         </tr>
         <tr class="row_even">
            <td colspan="2">
               <input type="submit" value="Login"
            </td>
         </tr>
         <input type="hidden" name="action" value="check_user">
         </form>
      </table>
   </td></tr></table>
   <script language="JavaScript">
      document.form1.uid.focus();
   </script> <?php
}

$action = strtolower($action);
switch ($action) {
   case "check_user":
      if (!$user = $db->Execute("SELECT * FROM users WHERE username='$uid'")) {
         echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
         break;
      }
      if ($user->RecordCount() > 0) {
         if (md5($pwd) != $user->fields["password"]) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Password.</td></tr></table>";
            user_form();
            break;
         }
         $_SESSION["username"] = $user->fields["username"];
         $_SESSION["priv"] = $user->fields["priv"];
         $_SESSION["fullname"] = $user->fields["fullname"]; ?>
         <script language="JavaScript">
            window.location="index.php";
         </script> <?php
      }
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invalid Username.</td></tr></table>";
      user_form();
      break;
   default:
      user_form();
      break;
}

require("footer.inc.php"); ?>
