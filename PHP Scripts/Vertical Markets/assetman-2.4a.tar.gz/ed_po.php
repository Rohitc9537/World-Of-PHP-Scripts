<?php require("common.inc.php"); ?>

<?php
function po_form() { ?>
   <table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_po.php" method="post" name="form1">
      <tr class="row_head"> 
         <td align="center" colspan="2" nowrap><b>Update Purchase Order Information</b></td>
      </tr>
      <tr class="row_even"> 
         <td align="right">PO Number:</td>
         <td> 
            <input type="text" name="po_number" size="12">
            <input type="submit" value="Enter">
         </td>
      </tr>
   <input type="hidden" name="action" value="edit">
   </form>
   </table>
   <script language="JavaScript">
      document.form1.po_number.focus();
   </script> <?php
} ?>

<?php
function edit_form($db, $po_number) {
   global $username, $priv;
   if ($po_number == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>You must enter a valid PO number.</td></tr></table>";
      po_form($db);
      return FALSE;
   }
   if (!$po = $db->Execute("SELECT * FROM po WHERE po_number=$po_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($po->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $po_number not found.</td></tr></table>";
      po_form($db);
      return FALSE;
   }
   if ($po->fields["open"] == "N") {
      view_po($db, $po_number);
      return TRUE;
   }
   $vendor_id = $po->fields["vendor"];
   $org_id = $po->fields["organization"];
   $cr_user_id = $po->fields["created_by"];
   $vendor = $db->Execute("SELECT name FROM vendor WHERE id=$vendor_id");
   $org = $db->Execute("SELECT name FROM organization WHERE id=$org_id");
   $cr_user = $db->Execute("SELECT fullname FROM users WHERE username='$cr_user_id'");
   $line_items = $db->Execute("SELECT * FROM line_items WHERE po_number=$po_number ORDER BY id"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
       <tr class="row_head"> 
         <td nowrap><b>Edit Purchase Order Information</b></td>
         <td align="right">PO Number:&nbsp;<?php echo $po_number; ?></td>
       </tr>
       <tr class="row_even">
         <td> <?php
         if ($po->fields["open"] == "Y" && $po->fields["approved"] == "N") { ?>
            &nbsp;&nbsp;Status:<img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
         } else if ($po->fields["open"] == "Y" && $po->fields["approved"] == "Y") { ?>
            &nbsp;&nbsp;Status:<img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
         } else { ?>
            &nbsp;&nbsp;Status:<img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
         }
         if ($priv > 1 && $po->fields["approved"] == "Y") { ?>
            <a href="print_po.php?po_number=<?php echo $po_number; ?>"><img src="images/print_btn.gif" border="0" alt="Print"></a> <?php
         } ?>
         </td>
         <td align="right">Date:&nbsp;<?php echo display_date($po->fields["date"]); ?></td>
       </tr>
       <tr class="row_even"> 
         <td>&nbsp;&nbsp;Organization:&nbsp;<?php echo $org->fields["name"]; ?></td>
         <td align="right">Created By:&nbsp;<?php echo $cr_user->fields["fullname"]; ?></td>
       </tr>
       <tr class="row_even">
         <td>&nbsp;&nbsp;Vendor:&nbsp;<?php echo $vendor->fields["name"]; ?></td>
         <td>&nbsp;</td>
       </tr>
       <tr class="row_even">
         <td colspan="2"> <?php
            if ($priv > 2 || $po->fields["approved"] == "N") { ?>
               <a href="ed_po.php?action=add_line&po_number=<?php echo $po_number; ?>">
                  <img src="images/add_line_xp.gif" border="0" alt="Add Line Item"></a> <?php
            }
            if ($priv < 3 && $po->fields["approved"] == "N") { ?>
               <a href="ed_po.php?action=get_approval&po_number=<?php echo $po_number; ?>">
                  <img src="images/get_approval_xp.gif" border="0" alt="Submit PO for Approval"></a> <?php
            }
            if ($priv > 2 && $po->fields["approved"] == "N") { ?>
               <a href="ed_po.php?action=approve&po_number=<?php echo $po_number; ?>">
                  <img src="images/approve_xp.gif" border="0" alt="Approve PO"></a> <?php
            } ?>
            <a href="ed_po.php?action=close_po&po_number=<?php echo $po_number; ?>">
               <img src="images/close_po_xp.gif" border="0" alt="Close PO"></a>
         </td>
       </tr>
     </table>
   <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
      <td align="center"><b>Item</b></td>
      <td align="center"><b>Qty</b></td>
      <td><b>Unit</b></td>
      <td><b>Description</b></td>
      <td><b>Alloc</b></td>
      <td align="right"><b>Price</b></td>
      <td align="right"><b>Amount</b></td>
      <td align="center"><b>Rcv</b></td>
      <td align="center"><b>Inv</b></td>
    </tr> <?php
      $po_total = 0;
      $i = 1;
      while (!$line_items->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
         if ($priv > 2 || $po->fields["approved"] == "N") {
            echo "<td align=\"center\"><a href=\"ed_po.php?action=edit_line&po_number=$po_number&id="
                 . $line_items->fields["id"]
                 . "\"><img src=\"images/edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
         } else {
            echo "<td align=\"center\">$i</td>";
         }
         echo "<td align=\"center\">" . $line_items->fields["qty"] . "</td>";
         echo "<td>" . $line_items->fields["unit"] . "</td>";
         echo "<td>" . $line_items->fields["descrip"] . "</td>";
         echo "<td>" . $line_items->fields["alloc"] . "</td>";
         echo "<td align=\"right\">" . $line_items->fields["unit_price"] . "</td>";
         echo "<td align=\"right\">" . $line_items->fields["amount"] . "</td>";
         if ($line_items->fields["received"] == "Y") {
            echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"Received\"></td>";
         } else {
            echo "<td align=\"center\">"
                 ."<a href=\"ed_po.php?action=confirm_recv_line&po_number=$po_number&id="
                 . $line_items->fields["id"] . "\">"
                 . "<img src=\"images/no.gif\" border=\"0\" alt=\"Not Received\"></a></td>";
         }
         switch ($line_items->fields["invoiced"]) {
            case "Y":
               echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"All Invoiced\"></td>";
               break;
            case "P":
               echo "<td align=\"center\"><img src=\"images/part_yes.gif\" border=\"0\" alt=\"Some Invoiced\"></td>";
               break;
            case "N":
               echo "<td align=\"center\"><img src=\"images/no.gif\" border=\"0\" alt=\"None Invoiced\"></a></td>";
               break;
         }
         echo "</tr>";
         $po_total += $line_items->fields["amount"];
         $i++;
         $line_items->MoveNext();
      } ?>
      <tr class="row_head">
         <td align="right" colspan="6"><b>Purchase Order Total:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $po_total); ?>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr class="row_even">
         <td colspan="9">&nbsp;</td> 
      </tr>
      <tr class="row_head">
         <td align="right" colspan="9">
            <a href="ed_po.php"><img src="images/edit_btn.gif" border="0" alt="Edit"></a>another Purchase Order.
         </td>
      </tr>
  </table> <?php
} ?>

<?php
function view_po($db, $po_number, $from_search = FALSE) {
   global $username, $priv;
   if (!$po = $db->Execute("SELECT * FROM po WHERE po_number=$po_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($po->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>PO number $po_number not found.</td></tr></table>";
      po_form($db);
      return;
   }
   $vendor_id = $po->fields["vendor"];
   $org_id = $po->fields["organization"];
   $cr_user_id = $po->fields["created_by"];
   $vendor = $db->Execute("SELECT name FROM vendor WHERE id=$vendor_id");
   $org = $db->Execute("SELECT name FROM organization WHERE id=$org_id");
   $cr_user = $db->Execute("SELECT fullname FROM users WHERE username='$cr_user_id'");
   $line_items = $db->Execute("SELECT * FROM line_items WHERE po_number=$po_number ORDER BY id"); ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head"> 
      <td nowrap><b>View Purchase Order Information</b></td>
      <td align="right">PO Number:&nbsp;<?php echo $po_number; ?></td>
    </tr>
    <tr class="row_even">
      <td> <?php
         if ($po->fields["open"] == "Y" && $po->fields["approved"] == "N") { ?>
            &nbsp;&nbsp;Status:<img src="images/open_btn.gif" border="0" alt="Open. Not Approved"> <?php
         } else if ($po->fields["open"] == "Y" && $po->fields["approved"] == "Y") { ?>
            &nbsp;&nbsp;Status:<img src="images/appr_open_btn.gif" border="0" alt="Open. Approved"> <?php
         } else { ?>
            &nbsp;&nbsp;Status:<img src="images/closed_btn.gif" border="0" alt="Closed"> <?php
         }
         if ($priv > 1 && $po->fields["open"] == "Y") { ?>
            <a href="ed_po.php?action=edit&po_number=<?php echo $po_number; ?>"><img src="images/edit_btn.gif" border="0" alt="Edit"></a> <?php
         }
         if ($priv > 1 && $po->fields["approved"] == "Y") { ?>
            <a href="print_po.php?po_number=<?php echo $po_number; ?>"><img src="images/print_btn.gif" border="0" alt="Print"></a> <?php
         } ?>
      </td>
      <td align="right">Date:&nbsp;<?php echo $po->fields["date"]; ?></td>
    </tr>
    <tr class="row_even"> 
      <td>&nbsp;&nbsp;Organization:&nbsp;<?php echo $org->fields["name"]; ?></td>
      <td align="right">Created By:&nbsp;<?php echo $cr_user->fields["fullname"]; ?></td>
    </tr>
    <tr class="row_even">
      <td>&nbsp;&nbsp;Vendor:&nbsp;<?php echo $vendor->fields["name"]; ?></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <table class="small" cellspacing="0" cellpadding="1" width="100%">
    <tr class="row_head">
      <td align="center"><b>Item</b></td>
      <td align="center"><b>Qty</b></td>
      <td><b>Unit</b></td>
      <td><b>Description</b></td>
      <td><b>Alloc</b></td>
      <td align="right"><b>Price</b></td>
      <td align="right"><b>Amount</b></td>
      <td align="center"><b>Rcv</b></td>
      <td align="center"><b>Inv</b></td>
    </tr> <?php
      $po_total = 0;
      $i = 1;
      while (!$line_items->EOF) {
         if ($i % 2 == 0) {
            echo "<tr class=\"row_even\">";
         } else {
            echo "<tr class=\"row_odd\">";
         }
         echo "<td align=\"center\">$i</td>";
         echo "<td align=\"center\">" . $line_items->fields["qty"] . "</td>";
         echo "<td>" . $line_items->fields["unit"] . "</td>";
         echo "<td>" . $line_items->fields["descrip"] . "</td>";
         echo "<td>" . $line_items->fields["alloc"] . "</td>";
         echo "<td align=\"right\">" . $line_items->fields["unit_price"] . "</td>";
         echo "<td align=\"right\">" . $line_items->fields["amount"] . "</td>";
         if ($line_items->fields["received"] == "Y") {
            echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"Received\"></td>";
         } else {
            echo "<td align=\"center\"><img src=\"images/no.gif\" border=\"0\" alt=\"Not Received\"></td>";
         }
         switch ($line_items->fields["invoiced"]) {
            case "Y":
               echo "<td align=\"center\"><img src=\"images/yes.gif\" border=\"0\" alt=\"All Invoiced\"></td>";
               break;
            case "P":
               echo "<td align=\"center\"><img src=\"images/part_yes.gif\" border=\"0\" alt=\"Some Invoiced\"></td>";
               break;
            case "N":
               echo "<td align=\"center\"><img src=\"images/no.gif\" border=\"0\" alt=\"None Invoiced\"></a></td>";
               break;
         }
         echo "</tr>";
         $po_total += $line_items->fields["amount"];
         $i++;
         $line_items->MoveNext();
      } ?>
      <tr class="row_head">
         <td align="right" colspan="6"><b>Purchase Order Total:</b></td>
         <?php printf("<td align=\"right\"><b>%01.2f</b></td>", $po_total); ?>
         <td colspan="2">&nbsp;</td>
      </tr>
      <tr class="row_even">
         <td colspan="9">&nbsp;</td> 
      </tr>
      <tr class="row_head">
         <td align="right" colspan="9">
            <?php if ($from_search == TRUE) { ?>
               <a href="search_po.php"><img src="images/search_btn.gif" border="0" alt="Search"></a>
            <?php } else { ?>
               <a href="ed_po.php"><img src="images/edit_btn.gif" border="0" alt="Edit"></a>another Purchase Order.
            <?php } ?>
         </td>
      </tr>
   </table> <?php
} ?>

<?php
function new_line_item($po_number) { ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_po.php" method="post" name="form2">
    <tr class="row_head"> 
      <td colspan="8"><b>Add Line Item to PO Number: <?php echo $po_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Quantity:</td>
      <td> 
        <input type="text" name="qty" size="5" value="1">
      </td>
      <td align="right">Unit: </td>
      <td> 
        <input type="text" name="unit" size="10" value="each">
      </td>
      <td align="right">Unit Price:</td>
      <td> 
        <input type="text" name="unit_price" size="16">
      </td>
      <td align="right">Allocation:</td>
      <td> 
        <input type="text" name="alloc" size="16">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="7"> 
        <textarea name="descrip" cols="50" rows="4" wrap="VIRTUAL"></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="8">
         <img src="images/enter_xp.gif" border="0" alt="Enter"
            onClick="if (valid_po_line_form(document.form2)) { document.form2.submit(); }">
         <img src="images/reset_xp.gif" border="0" alt="Reset"
            onClick="document.form2.reset();">
         <a href="ed_po.php?action=cancel&po_number=<?php echo $po_number; ?>">
            <img src="images/cancel_xp.gif" border="0" alt="Cancel"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="enter">
  <input type="hidden" name="po_number" value="<?php echo $po_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form2.qty.focus();
  </script> <?php
} ?>

<?php
function edit_line($db, $po_number, $id) {
   $line_item = $db->Execute("SELECT * FROM line_items WHERE id=$id"); ?>
  <table class="default" width="100%" border="0" cellspacing="0" cellpadding="1">
  <form action="ed_po.php" method="post" name="form3">
    <tr class="row_head"> 
      <td colspan="8"><b>Edit Line Item from PO Number: <?php echo $po_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Quantity:</td>
      <td> 
        <input type="text" name="qty" size="5"
         value="<?php echo $line_item->fields["qty"]; ?>">
      </td>
      <td align="right">Unit: </td>
      <td> 
        <input type="text" name="unit" size="10"
           value="<?php echo $line_item->fields["unit"]; ?>">
      </td>
      <td align="right">Unit Price:</td>
      <td> 
        <input type="text" name="unit_price" size="16"
           value="<?php echo $line_item->fields["unit_price"]; ?>">
      </td>
      <td align="right">Allocation:</td>
      <td> 
        <input type="text" name="alloc" size="16"
           value="<?php echo $line_item->fields["alloc"]; ?>">
      </td>
    </tr>
    <tr class="row_even"> 
      <td align="right" valign="top">Description:</td>
      <td colspan="7"> 
        <textarea name="descrip" cols="50" rows="4" wrap="virtual"><?php echo $line_item->fields["descrip"]; ?></textarea>
      </td>
    </tr>
    <tr class="row_even"> 
      <td colspan="8">
         <img src="images/update_xp.gif" alt="Update" border="0"
            onClick="if (valid_po_line_form(document.form3)) { document.form3.submit(); }">
         <img src="images/delete_xp.gif" alt="Delete" border="0"
            onClick="if (isConfirmed('Are you sure you want to DELETE this Line Item ?')) { window.location='ed_po.php?action=delete_line&id=<?php echo $id; ?>&po_number=<?php echo $po_number; ?>'; }">
         <img src="images/reset_xp.gif" alt="Reset" border="0"
            onClick="document.form3.reset();">
         <a href="ed_po.php?action=cancel&po_number=<?php echo $po_number; ?>">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
  <input type="hidden" name="action" value="update_line">
  <input type="hidden" name="id" value="<?php echo $id; ?>">
  <input type="hidden" name="po_number" value="<?php echo $po_number; ?>">
  </form>
  </table>
  <script language="JavaScript">
     document.form3.qty.focus();
  </script> <?php
} ?>

<?php
function select_super($db, $po_number) {
   if (!$supers = $db->Execute("SELECT fullname, email FROM users WHERE priv>2 ORDER BY fullname")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
<table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="ed_po.php" method="post" name="form4">
    <tr class="row_head"> 
      <td align="center" colspan="3" nowrap><b>Select Approving Supervisor</b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Select Supervisor:</td>
      <td>
         <?php echo $supers->GetMenu("email", "", TRUE, FALSE, 0, "onChange='document.form4.submit();'"); ?> 
      </td>
    </tr>
   <input type="hidden" name="po_number" value="<?php echo $po_number; ?>">
   <input type="hidden" name="action" value="mail_approval">
   </form>
</table> <?php
} ?>

<?php
$action = strtolower($action);
if ($priv >= 1 && $action == "view") {
   view_po($db, $po_number);
   require("footer.inc.php");
   exit();
}
if ($priv >= 1 && $action == "view_from_search") {
   view_po($db, $po_number, TRUE);
   require("footer.inc.php");
   exit();
}
if ($priv > 1) {
   switch ($action) {
      case "add_line":
         new_line_item($po_number);
         break;
      case "approve":
         if ($priv > 2) {
            if (!$db->Execute("UPDATE po SET approved='Y', approved_by='$username' WHERE po_number='$po_number'")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
            $cr_username = $db->Execute("SELECT created_by FROM po WHERE po_number='$po_number'");
            if ($cr_username->fields["created_by"] != $username) {
               $query = "SELECT email FROM users WHERE username='" . $cr_username->fields["created_by"] . "'";
               $cr_email = $db->Execute($query);
               mail($cr_email->fields["email"],
                    "Purchase Order approval",
                    "Purchase Order $po_number has been approved by $fullname",
                    "From: AssetMan@" . $_SERVER["SERVER_NAME"] . "\n");
               echo "<table class=\"notice\" width=\"100%\"><tr><td>A Purchase Order approval notification has been E-Mailed to "
                    . $cr_email->fields["email"] . "</td></tr></table>";
            }
         } else {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
         }
         edit_form($db, $po_number);
         break;
      case "enter":
         $unit_price = sprintf("%01.2f", $unit_price);
         $amount = sprintf("%01.2f", $qty * $unit_price);
         $id = $db->GenID("line_items_seq");
         $query = "INSERT INTO line_items (id, po_number, qty, inv_qty, unit, descrip, alloc, unit_price, amount, received)"
                . " VALUES ('$id', '$po_number', '$qty', '$qty', '$unit', "
                . $db->QMagic($descrip) . ", " . $db->QMagic($alloc) . ", '$unit_price', '$amount', 'N')";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $po_number);
         break;
      case "cancel":
         edit_form($db, $po_number);
         break;
      case "edit":
         edit_form($db, $po_number);
         break;
      case "edit_line":
         edit_line($db, $po_number, $id);
         break;
      case "get_approval":
         select_super($db, $po_number);
         break;
      case "mail_approval":
         mail($email,
              "Purchase Order approval request",
              "Purchase Order $po_number has been submitted by $fullname for your approval.",
              "From: AssetMan@" . $_SERVER["SERVER_NAME"] . "\n");
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Your request has been forwarded to $email."
            . " You will be notifed by E-Mail when this PO has been approved.</td></tr></table>";
         edit_form($db, $po_number);
         break;
      case "update_line":
         $unit_price = sprintf("%01.2f", $unit_price);
         $amount = sprintf("%01.2f", $qty * $unit_price);
         $query = "UPDATE line_items SET"
                . " qty='$qty', inv_qty='$qty', unit='$unit', descrip=" . $db->QMagic($descrip) . ","
                . " alloc=" . $db->QMagic($alloc) . ", unit_price='$unit_price', amount='$amount'"
                . " WHERE id=$id";
         if (!$db->Execute($query)) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $po_number);
         break;
      case "confirm_recv_line":
         if (!$line_item = $db->Execute("SELECT * FROM line_items WHERE id=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Please confirm that you received the following line item...</td></tr></table>"; ?>
         <table class="small" align="center" border="0" cellpadding="1" cellspacing="0" width="100%">
            <tr class="row_head">
               <td><b>Purchase Order</b></td>
               <td align="center"><b>Qty</b></td>
               <td><b>Description</b></td>
               <td align="right"><b>Price</b></td>
               <td align="right"><b>Amount</b></td>
            </tr>
            <tr class="row_odd">
               <td><?php echo $line_item->fields["po_number"]; ?></td>
               <td align="center"><?php echo $line_item->fields["qty"]; ?></td>
               <td><?php echo $line_item->fields["descrip"]; ?></td>
               <td align="right"><?php echo $line_item->fields["unit_price"]; ?></td>
               <td align="right"><?php echo $line_item->fields["amount"]; ?></td>
            </tr>
         </table> <?php
         echo "<table class=\"default\" width=\"100%\"><tr class=\"row_even\"><td><a href=\"new_asset.php?action=from_po&line_id=$id\"><img src=\"images/yes_btn.gif\" border=\"0\" alt=\"Yes\">This is a capital asset. Add to the Asset Dictionary.</a><br>"
              . "<a href=\"new_item.php?action=from_po&line_id=$id\"><img src=\"images/yes_btn.gif\" border=\"0\" alt=\"Yes\">This is not a capital asset but I want to track it. Add to the Item Master Dictionary.</a><br>"
              . "<a href=\"ed_po.php?action=recv_line&po_number=$po_number&id=$id\"><img src=\"images/yes_btn.gif\" border=\"0\" alt=\"Yes\">I don't want to track it or I'll deal with it later. Just mark this line item received.</a><br>"
              . "<a href=\"ed_po.php?action=cancel&po_number=$po_number\"><img src=\"images/no_btn.gif\" border=\"0\" alt=\"No\">I was jes' foolin'. This line item has not been received.</a></td></tr></table>";
         break;
      case "recv_line":
         if (!$line_item = $db->Execute("SELECT received FROM line_items WHERE id=$id")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
         }
         if (!$db->Execute("UPDATE line_items SET received='Y' WHERE id=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $po_number);
         break;
      case "delete_line":
         if (!$db->Execute("DELETE FROM line_items WHERE id=$id")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         edit_form($db, $po_number);
         break;
      case "close_po":
         if (!$line_items = $db->Execute("SELECT received FROM line_items WHERE po_number=$po_number")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         $not_recvd = FALSE;
         while (!$line_items->EOF) {
            if ($line_items->fields["received"] == "N") {
               $not_recvd = TRUE;
            }
            $line_items->MoveNext();
         }
         if ($not_recvd == TRUE) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>One or more line items associated with this purchase order"
               . " have NOT been received. Either receive or delete the offending"
               . " line items. You may then close this purchase order.</td></tr></table>";
            edit_form($db, $po_number);
            break;
         }
         if (!$po = $db->Execute("SELECT open, approved FROM po WHERE po_number=$po_number")) {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
            break;
         }
         if ($po->fields["approved"] == "N") {
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Purchase Order $po_number has not yet been approved!</td></tr></table>";
            edit_form($db, $po_number);
            break;
         }
         if ($po->fields["open"] == "Y") {
            if (!$db->Execute("UPDATE po SET open='N' WHERE po_number=$po_number")) {
               echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
               break;
            }
         }
         edit_form($db, $po_number);
         break;
      default:
         po_form();
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>
