<?php require("common.inc.php"); ?>

<?php
function org_form($db) {
   if (!$org = $db->Execute("SELECT name, id FROM organization ORDER BY name")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   } ?>
   <table class="default" border="0" cellspacing="0" cellpadding="1" align="center">
   <form action="search_org.php" method="post" name="form1">
    <tr class="row_head">
      <td align="center" colspan="2" nowrap><b>View Organization Information</b></td>
    </tr>
    <tr class="row_even">
      <td align="right">Choose Organization:</td>
      <td>
         <?php echo $org->GetMenu("id", "", FALSE, FALSE, 0,
               "onChange='document.form1.submit();'"); ?>
      </td>
    </tr>
   <input type="hidden" name="action" value="view">
   </form>
   </table> <?php
} ?>

<?php
$action = strtolower($action);
switch ($action) {
   case "view": ?>
      <script language="JavaScript">
         window.location="search_asset.php?action=view_org&org_id=<?php echo $id; ?>";
      </script> <?php
      break;
   default:
      org_form($db);
}
require("footer.inc.php");
?>
