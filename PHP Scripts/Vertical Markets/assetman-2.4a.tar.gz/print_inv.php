<?php
require("common.inc.php");
require("mail_and_print.inc.php");

function select_printer($inv_number) {
   global $printer1, $printer2, $printer3, $printer4; ?>
   <table class="default" align="center" border="0" cellspacing="0" cellpadding="1">
   <form action="print_inv.php" method="post" name="form1">
    <tr class="row_head"> 
      <td align="center" colspan="3" nowrap><b>Print Invoice <?php echo $inv_number; ?></b></td>
    </tr>
    <tr class="row_even"> 
      <td align="right">Select Printer:</td>
      <td> 
         <select name="printer">
             <option value="printer1"><?php echo $printer1["name"]; ?></option>
             <option value="printer2"><?php echo $printer2["name"]; ?></option>
             <option value="printer3"><?php echo $printer3["name"]; ?></option>
             <option value="printer4"><?php echo $printer4["name"]; ?></option>
         </select>
      </td>
      <td>
         <img src="images/print_xp.gif" alt="Print Invoice" border="0"
            onClick="document.form1.submit();">
         <a href="print_inv.php?action=cancel">
            <img src="images/cancel_xp.gif" alt="Cancel" border="0"></a>
      </td>
    </tr>
    <input type="hidden" name="action" value="print_gd_inv">
    <input type="hidden" name="inv_number" value="<?php echo $inv_number; ?>">
   </form>
   </table> <?php
} ?>

<?php
function print_gd_inv($db, $inv_number, $printer) {
   global $cfg, $printer1, $printer2, $printer3, $printer4;
   if (${$printer}["name"] == "NA" || ${$printer}["name"] == "") {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Select a valid configured printer from the list.</td></tr></table>";
      select_printer($inv_number);
      return FALSE;
   }
   if (!$inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number")) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>DB ERROR: " . $db->ErrorMsg() . "</td></tr></table>";
      return FALSE;
   }
   if ($inv->RecordCount() == 0) {
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice number $inv_number not found.</td></tr></table>";
      return FALSE;
   }
   $cr_username = $inv->fields["created_by"];
   $org_id = $inv->fields["organization"];
   $cr_userinfo = $db->Execute("SELECT fullname FROM users WHERE username='$cr_username'");
   $org = $db->Execute("SELECT * FROM organization WHERE id=$org_id");
   $inv = $db->Execute("SELECT * FROM invoices WHERE inv_number=$inv_number");
   $inv_lines = $db->Execute("SELECT * FROM inv_lines WHERE inv_number=$inv_number ORDER BY id");
   echo "Generating document image. Please be patient...";
   flush();

   // Open the blank form image.
   $im = imagecreatefrompng("forms/inv_template.png");
   $black = imagecolorallocate($im, 0, 0, 0);
   $white = imagecolorallocate($im, 255, 255, 255);

   // Fill in the form by drawing text on the image at appropriate coordinates.
   imagettftext($im, 20, 0, 885, 115, $black, $cfg["font_b"],
      $inv_number);
   imagettftext($im, 20, 0, 885, 170, $black, $cfg["font_r"],
      display_date($inv->fields["date"]));
   imagettftext($im, 20, 0, 80, 260, $black, $cfg["font_r"],
      $org->fields["name"]);
   imagettftext($im, 20, 0, 80, 302, $black, $cfg["font_r"],
      $org->fields["address1"]);
   imagettftext($im, 20, 0, 80, 344, $black, $cfg["font_r"],
      $org->fields["city"] . ", " . $org->fields["province"] . ", " . $org->fields["p_code"]);
   imagettftext($im, 20, 0, 80, 386, $black, $cfg["font_r"],
      "Attn: " . $org->fields["contact"]);
   $i = 1;
   $inv_total = 0;
   $tax1_total = 0;
   $ppl = 40; // Pixels per line
   $baseline = 475; // Starting Y coordinate. Pixels - $ppl
   while (!$inv_lines->EOF) {
      $y = $baseline + $ppl * $i;
      imagettftext($im, 16, 0, 50, $y, $black, $cfg["font_r"],
         display_date($inv_lines->fields["rcv_date"]));
      imagettftext($im, 16, 0, 180, $y, $black, $cfg["font_r"],
         $inv_lines->fields["rcv_by"]);
      $bbox = imagettfbbox(16, 0, $cfg["font_r"], $inv_lines->fields["qty"]);
      imagettftext($im, 16, 0, 380 - $bbox[2], $y, $black, $cfg["font_r"],
         $inv_lines->fields["qty"]);
      imagettftext($im, 16, 0, 390, $y, $black, $cfg["font_r"],
         $inv_lines->fields["descrip"]);
      $bbox = imagettfbbox(16, 0, $cfg["font_r"], $inv_lines->fields["unit_price"]);
      imagettftext($im, 16, 0, 1020 - $bbox[2], $y, $black, $cfg["font_r"],
         $inv_lines->fields["unit_price"]);
      $bbox = imagettfbbox(16, 0, $cfg["font_r"], $inv_lines->fields["amount"]);
      imagettftext($im, 16, 0, 1140 - $bbox[2], $y, $black, $cfg["font_r"],
         $inv_lines->fields["amount"]);
      $inv_total += $inv_lines->fields["amount"];
      if ($inv_lines->fields["taxable"] == "Y") {
         $tax1_total += $inv_lines->fields["amount"];
      }
      $i++;
      $inv_lines->MoveNext();
   }
   imagettftext($im, 16, 0, 50, 1110, $black, $cfg["font_r"],
      $inv->fields["comments"]);
   $bbox = imagettfbbox(16, 0, $cfg["font_b"], sprintf("%s%01.2f", $cfg["curr"], $inv_total));
   imagettftext($im, 16, 0, 1140 - $bbox[2], 1120, $black, $cfg["font_b"],
      sprintf("%s%01.2f", $cfg["curr"], $inv_total));
   if ($org->fields["tax_exempt"] == "Y") {
      $tax1 = 0;
      $tax2 = 0;
   } else if ($inv->fields["open"] == "N") {
      $tax1 = $inv->fields["tax1"];
      $tax2 = $inv->fields["tax2"];
   } else {
      $tax1 = round($tax1_total * $cfg["tax1"], 2);
      $tax2 = round($inv_total * $cfg["tax2"], 2);
   }
   $inv_total = $inv_total + $tax1 + $tax2;
   imagettftext($im, 16, 0, 925, 1160, $white, $cfg["font_r"], $cfg["tax1_name"]);
   $bbox = imagettfbbox(16, 0, $cfg["font_b"], sprintf("%s%01.2f", $cfg["curr"], $tax1));
   imagettftext($im, 16, 0, 1140 - $bbox[2], 1160, $black, $cfg["font_b"],
      sprintf("%s%01.2f", $cfg["curr"], $tax1));
   imagettftext($im, 16, 0, 925, 1200, $white, $cfg["font_r"], $cfg["tax2_name"]);
   $bbox = imagettfbbox(16, 0, $cfg["font_b"], sprintf("%s%01.2f", $cfg["curr"], $tax2));
   imagettftext($im, 16, 0, 1140 - $bbox[2], 1200, $black, $cfg["font_b"],
      sprintf("%s%01.2f", $cfg["curr"], $tax2));
   $bbox = imagettfbbox(16, 0, $cfg["font_b"], sprintf("%s%01.2f", $cfg["curr"], $inv_total));
   imagettftext($im, 16, 0, 1140 - $bbox[2], 1240, $black, $cfg["font_b"],
      sprintf("%s%01.2f", $cfg["curr"], $inv_total));
   imagettftext($im, 16, 0, 1040, 1430, $black, $cfg["font_r"],
      $inv->fields["gl_credit"]);
   imagettftext($im, 16, 0, 1040, 1465, $black, $cfg["font_r"],
      $inv->fields["gl_debit"]);

   // Save the filled in form image...
   imagepng($im, "var/" . session_id() . ".png");
   // And print it.
   if (print_image($printer, "inv_" . $inv_number . ".pdf"))
      echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice $inv_number job queued to " . ${$printer}["name"] . " for print/email/download.</td></tr></table>";
} ?>

<?php
if ($priv > 1) {
   $action = strtolower($action);
   switch ($action) {
      case "cancel":
         echo "<table class=\"notice\" width=\"100%\"><tr><td>Print Invoice $inv_number job cancelled.</td></tr></table>";
         break;
      case "print_gd_inv":
         print_gd_inv($db, $inv_number, $printer);
         break;
      default:
         if ($cfg["gd"] == TRUE) {
            select_printer($inv_number);
         } else { ?>
            <script language="JavaScript">
               window.open("print_html_inv.php?inv_number=<?php echo $inv_number; ?>");
            </script> <?php
            echo "<table class=\"notice\" width=\"100%\"><tr><td>Invoice $inv_number opened in a new browser window.</td></tr></table>";
         }
   }
} else {
   echo "<table class=\"notice\" width=\"100%\"><tr><td>Insufficient privilege. See AssetMan administrator.</td></tr></table>";
}
require("footer.inc.php");
?>

