<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("disp.php");
require("set_td_colors.php");

$qry="SELECT DISTINCT fname FROM favorites WHERE fuser='".$_SESSION['login']."' ORDER BY fname";
if ($order_by!="") {
	$qry.=" ORDER BY $order_by $dir ";
}	
$result=execute_sql($qry,$start,$count,$num_rows);

headline($what,'','');
echo '</td></tr></table>';

if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require("tbl_header.php");
echo '<th align="left"><p>'.xlate("Favorite list").'</th>';
echo '<th align="right"><p>'.xlate("Tracks").'</th>';
echo '<th> </th><th> </th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	echo '<td>';
	echo '<a href="index.php?what=favoriteid&start=0&order_by=favorite.track_id&special=';
    echo $row['fname'].'">'.$row['fname'].'</a>';
	if ($_SESSION['favoritelistname']==$row['fname']) {
		echo '<b><i><---</i></b> ';
	}	

	echo '</td>';
	$qry2="SELECT fid FROM favorites WHERE fname='".$row['fname']."' AND track_id>'0'";
	$result2=execute_sql($qry2,0,1000000,$nrows2);
	$row2=mysql_fetch_array($result2);
	$nrows2=mysql_num_rows($result2);
	echo '<td align="right">'.$nrows2.'</td>';
	echo '<td align="right">';
	echo '<a href="delete.php?what=favorite&id='.$row['fname'].'">';
	echo '['.xlate("Delete").']</b></a>';
	echo '</td>';
	echo '<td align="right">';
	echo '<a href="index.php?what=edit&edit=favorite&id='.$row['fname'].'">['.xlate("Edit").']</a>';
	print "</td></tr> \n";
}
echo '</table>';	

disp_favorite_lists($_SESSION['login'],'0');
require("page_numbers.php");

?>
