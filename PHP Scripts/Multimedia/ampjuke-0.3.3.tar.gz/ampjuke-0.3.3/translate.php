<?
function xlate($key) {
	$ret=$key; // by default, return the English word if we cannot find a match
	// I know the "cases" below have more statements on one line (=bad programming). So sue me !
	if (strtoupper($_SESSION['lang']=="DA")) {
        require("./lang/da.php");
	} // Danish
	if (strtoupper($_SESSION['lang']=="DE")) {
		require("./lang/de.php");
	} // Deutch	
	if (strtoupper($_SESSION['lang']=="ES")) {
        require("./lang/es.php");
	} // Espanol
	if (strtoupper($_SESSION['lang']=="PT")) {
        require("./lang/pt.php");
	} // Portugu�s
	if (strtoupper($_SESSION['lang']=="SV")) {
        require("./lang/sv.php");
	} // Svenska
	if (strtoupper($_SESSION['lang']=="TR")) {
        require("./lang/tr.php");
	} // Turkish
	return $ret;
}
?>			
		
