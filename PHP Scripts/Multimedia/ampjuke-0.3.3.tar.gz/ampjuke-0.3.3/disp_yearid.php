<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("set_td_colors.php");
require("disp.php");

$qry="SELECT track.id, track.name, track.performer_id, track.duration, track.year, ";
$qry.="track.last_played, track.times_played, ";
$qry.="track.path, performer.pid, performer.pname ";
$qry.="FROM track, performer ";
$qry.="WHERE track.performer_id=performer.pid ";
$qry.="AND track.year='".$special."'";
if ($order_by!='') {
	$qry.=" ORDER BY $order_by $dir ";
}		
$result=execute_sql($qry,$start,$count,$num_rows);

$limit=$special;
headline($what,$special,$limit.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>'); 
// make special options: play/enqueue all from current year.
$text=xlate($playtext.' all tracks from').' <b>'.$special.'</b>';
std_table($tdalt);
echo '<tr><td>';
echo '<a href="play_action.php?act=playall&what=yearid&id='.$special.'">';
echo '<img src="./icons/mnu_arr.gif" border="0">'.$text.'</a> ';
// add to favorite list:
if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) {
	add2fav_link(xlate('Add all tracks to favorite list').' <b>'.$_SESSION['favoritelistname'].'</b>','?what=yearid&id='.$special);
}	
echo '</td></tr></table>';

if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require("tbl_header.php");
// 0.2.4:
if ($_SESSION['show_ids']=="1") {
	tbl_header($what,xlate("ID"),"left","track.id",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);
}	
//
tbl_header("yearid",xlate("Performer"),"left","performer.pname",$order_by,$dir,$newdir,
$count,$special.'&special='.$special);
tbl_header("yearid",xlate("Title"),"left","track.name",$order_by,$dir,$newdir,$count,'&special='.$special);
tbl_header("yearid",xlate("Duration"),"left","track.duration",$order_by,$dir,$newdir,$count,'&special='.$special);
if ($_SESSION['disp_last_played']=="1") {
	tbl_header("yearid",xlate("Last played"),"right","track.last_played",$order_by,$dir,
	$newdir,$count,'&special='.$special);
}
if ($_SESSION['disp_times_played']=="1") {
	tbl_header("yearid",xlate("Played"),"right","track.times_played",$order_by,$dir,
	$newdir,$count,'&special='.$special);
}
echo '<th> </th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	// 0.2.4:
	if ($_SESSION['show_ids']=="1") {
		echo '<td>';
		if ($_SESSION['admin']=="1") { // offer option to edit the track:
			echo '<a href="index.php?what=edit&edit=track&id='.$row['id'].'">'.$row['id'].'</a>';
		} else {
			echo $row['id'];
		}
		echo '</td>';	
	}	
	//	
	$perf=get_performer_name($row['performer_id']);
	add_performer_link($perf,$row['performer_id']);
	add_play_link("play",$row['id'],$row['name']);
	echo '<td>'.$row['duration'].'</td>';
	if ($_SESSION['disp_last_played']=="1") {
		echo '<td align="right">'.mydate($row['last_played']).'</td>';
	}
	if ($_SESSION['disp_times_played']=="1") {
		echo '<td align="right">'.$row['times_played'].'</td>';
	}		
	echo '<td align="right">';
	if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) { // 0.2.4
		add2fav_link('','?what=track&id='.$row['id']);
	}	
	echo '</td>';
	
	print "</tr> \n";
}
echo '</table>';	

include("page_numbers.php");

?>
