<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	

require("disp.php");
require("db.php");
require("sql.php");
require_once("set_td_colors.php"); // 0.3.2: in order to be able to "fancy_tr" the setup page

function select_a_track($where) {
	$ret="";
	$found=0;
	if ($where=="Tracks") {
		$qry="SELECT * FROM track";
		$result=execute_sql($qry,0,1000000,$nr);
		$x=0;
		while ($row=mysql_fetch_array($result)) {
			$track_id[$x]=$row['id'];
			$x++;
		}
	}	
	while ($found==0) {
		$x=rand(0,$nr);	
		$found=1;
	}
	$ret=$x;
	return $ret;
}		
			


if ($act=="setup") { // we're setting up what we wnt random play to do
	echo '<FORM NAME="setup" method="POST" action="index.php?what=random&act=start">';
	std_table("");
	echo '<th colspan="5" align="center" bgcolor="#abcdef">&nbsp<br>'.xlate("Random play").'<br>&nbsp</th>';
	// 0.3.2: The code below has been rewritten, - ie. the "<hr>"'s are gone (apart from the 1st)
	echo '<tr><td colspan="3">&nbsp</td></tr>';
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	echo '<td width="35%">'.xlate("Play tracks from").':</td>';
	echo '<td>';
		echo '<SELECT NAME="name" class="tfield">';
		echo '<OPTION VALUE="Tracks" selected>['.xlate("All").' '.xlate("Tracks").']</OPTION>';
		echo '<OPTION VALUE="Queue">['.xlate("The queue").']</OPTION>';
		$qry="SELECT DISTINCT fname FROM favorites WHERE fuser='".$_SESSION['login']."' ORDER BY fname";
		$result=execute_sql($qry,0,1000000,$nr);	
		while ($row=mysql_fetch_array($result)) {
			echo '<OPTION VALUE="'.$row['fname'].'">'.$row['fname'].'</OPTION>';
		}
		echo '</SELECT>';
	echo '</tr>';	

	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);	
	echo '<td>'.xlate("Play tracks from these year(s)").':</td>';
	echo '<td><input type="text" class="tfield" name="year"></td></tr>';

	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);	
	echo '<td>'.xlate("Number of tracks to select").':</td>';
	echo '<td><input type="text" name="no_of_tracks" class="tfield" value="10"></td></tr>';
	
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);	
	echo '<td>'.xlate("Remove duplicate entries");
	echo ':</td><td><input type="checkbox" name="remove_duplicates" class="tfield" checked="true"></td></tr>';
	echo '<tr><td colspan="5" align="center"><input type="submit" class="tfield" name="submit"';
	echo ' value="'.xlate("Save & continue").'"></td></tr>';
	echo '</table></FORM>';
	// 0.3.2: changes ends.
}


if ($act=="start") { // we want to start playing:
	$max_x=0;
	if ($_POST['name']=="Queue") { // select tracks from the queue...1st populate an array with id's:
		$qry="SELECT * FROM queue WHERE user_name='".$_SESSION['login']."'";
		$qry.=" ORDER BY qid";
		$result=execute_sql($qry,0,100000000,$num_rows);
		$x=0;
		while ($row=mysql_fetch_array($result)) {
			$tbl_id[$x]=$row['track_id'];
			$x++;
		}	
		$max_x=$x;
	}
	if (($_POST['name']!="Queue") && ($_POST['name']!="Track") && ($_POST['name']!="---")) { 
		// select from a playlist...1st populate with id's:
		$qry="SELECT * FROM favorites WHERE fuser='".$_SESSION['login']."' AND fname='".$_POST['name']."'";
		$qry.=" AND track_id>'0'";
		$result=execute_sql($qry,0,10000000,$num_rows);
		$x=0;
		while ($row=mysql_fetch_array($result)) {
			$tbl_id[$x]=$row['track_id'];
			$x++;
		}
		$max_x=$x;
	}		
	if ($_POST['name']=="Tracks") { // select from all tracks:
		$qry="SELECT * FROM track ORDER BY id";
		$result=execute_sql($qry,0,10000000,$num_rows);
		$x=0;
		while ($row=mysql_fetch_array($result)) {
			$tbl_id[$x]=$row['id'];
			$x++;
		}
		$max_x=$x;
	}		
	if ($_POST['year']!="") { // some year(s):
		$max_x=0;
		$qry="SELECT * FROM track WHERE year LIKE '%".$_POST['year']."%'";
		$result=execute_sql($qry,0,100000000,$num_rows);
		$x=0;
		while ($row=mysql_fetch_array($result)) {
			$tbl_id[$x]=$row['id'];
			$x++;
		}	
		$max_x=$x;
	}	
	
	// 0.3.2: Optionally, remove duplicates: 
	if (isset($_POST['remove_duplicates']) && ($_POST['remove_duplicates']=="on")) { 
    	$tbl_id=array_unique($tbl_id);	
   	    $max_x=count($tbl_id);
    }	
	//
	
	$handle=fopen("./tmp/".$_SESSION['login'].".m3u", "w");
	// find out what should be played
	$total_count=1;
	while ($total_count<=$_POST['no_of_tracks'] && $total_count<=$max_x) { // 0.3.2: Added && total_count....
		// 0.3.2:
		$x=rand(0,$max_x-1);
		$rid=$tbl_id[$x];
		while ($tbl_id[$x]==0) {
			$x=rand(0,$max_x-1);
			$rid=$tbl_id[$x];
		}		
		if (isset($_POST['remove_duplicates']) && ($_POST['remove_duplicates']=="on")) { 
			$tbl_id[$x]=0; // =we cannot select that track again
		}	
		//

		$qry="SELECT * FROM track WHERE id=".$rid;
		$result=execute_sql($qry,0,1,$nr);
		$row=mysql_fetch_array($result);
		$file=$row['path'];
		$name=set_name($row['performer_id'],$row['name'],$row['album_id']);
		cpy_file($file,$name,$music_tmp_dir);
		$item=split(":",$row['duration']);
		$s=$item[1] + ($item[0]*60);
		write_m3u($handle,$total_count,$s,$name,$base_http_prog_dir.'/tmp/'.$name);
		update_stats($rid);
		$total_count++;
	}	
	fclose($handle);
	$loc=$base_http_prog_dir."/tmp/".$_SESSION['login'].".m3u?id=".date("U"); // date-stuff is included in order to prevent caching-"tihngies" to just repeat previous/current playlist
	header("Location: $loc");
}	


?>		
		
		