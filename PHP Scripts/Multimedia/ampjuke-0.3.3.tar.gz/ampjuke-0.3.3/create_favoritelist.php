<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>AmpJuke</title>
<meta name="generator" content="TSW WebCoder">
</head>

<body>
<?
session_start();
if (isset($_SESSION['login'])) {
	require("db.php");
	require("sql.php");
	if (isset($_POST['favoritelistname'])) {
		$_SESSION['favoritelistname']=$_POST['favoritelistname'];
	}
	if (isset($_POST['copy'])) { // && ($_SESSION['favoritelistname']!="")) {
		$qry="SELECT * FROM queue WHERE user_name='".$_SESSION['login']."'";
		$result=execute_sql($qry,0,100000000,$nr);
		while ($row=mysql_fetch_array($result)) {
			$qry2="INSERT INTO favorites (fuser, fname, track_id) VALUES";
			$qry2.="('".$_SESSION['login']."' ,'".$_SESSION['favoritelistname']."', '".$row['track_id']."')";
			$res2=execute_sql($qry2,0,-1,$nr);
		}
	}		
	if (isset($_POST['new_favlist'])) {
		$_SESSION['favoritelistname']=$_POST['new_favlist'];
		$qry="INSERT INTO favorites (fuser, fname, track_id) VALUES";
		$qry.="('".$_SESSION['login']."', '".$_SESSION['favoritelistname']."', '0')";
		$result=execute_sql($qry,0,-1,$nr);
	}	
}
echo '<script type="text/javascript" language="javascript">'; echo "history.go(-1);";
echo '</script>';  
?>
</body>
</html>
