<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require_once("sql.php");
require_once("set_td_colors.php");
require_once("disp.php");

if ($act=="disp") {
    $qry="SELECT * FROM user";
    if ($order_by!="") {
	   $qry.=" ORDER BY $order_by $dir ";
    }
    $result=execute_sql($qry,0,1000000,$num_rows);
    headline($what,'','');
    echo '</td></tr></table>';
    if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
    std_table("");
    echo '<tr><td>';
    echo '<a href="index.php?what=users&act=create"><img src="./icons/mnu_arr.gif" border="0">';
    echo ' '.xlate("Create new").'</a></td>';
    echo '</tr></table>';

    std_table("");
    require("tbl_header.php");
    echo '<th bgcolor="#ffffff"> </th>';
    tbl_header("users",xlate("ID"),"left","user.id",$order_by,$dir,$newdir,$count,'&act='.$act);
    tbl_header("users",xlate("Username"),"left","user.name",$order_by,$dir,$newdir,$count,'&act='.$act);
    tbl_header("users",xlate("Administrator"),"left","user.admin",$order_by,$dir,$newdir,$count,'&act='.$act);
    tbl_header("users",xlate("Last login"),"right","user.last_login",$order_by,$dir,$newdir,$count,'&act='.$act);
    tbl_header("users",xlate("IP-address"),"right","user.last_ip",$order_by,$dir,$newdir,$count,'&act='.$act);
    echo '<th> </th>';

    while ($row=mysql_fetch_array($result)) {
	   fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
    	echo '<td><a href="index.php?what=users&act=edit&id='.$row['id'].'">['.xlate("Edit").']</a>&nbsp&nbsp&nbsp&nbsp';
        echo '<a href="index.php?what=users&act=delete&id='.$row['id'].'">['.xlate("Delete").']</a></td>';
    	echo '<td>'.$row['id'].'</td>';
        echo '<td>'.$row['name'].'</td>';
        // 0.3.3: translate Yes/No:
        $adm=xlate("No");
	   if ($row['admin']=="1") { $adm=xlate("Yes"); }
    	echo '<td>'.$adm.'</td>';
        echo '<td align="right">'.$row['last_login'].'</td>';
    	echo '<td align="right">'.$row['last_ip'].'</td>';
    	echo '<td> </td>';
    	print "</tr> \n";
    }
    include("page_numbers.php");
} // if act=disp



if ($act=="edit") {
	$qry="SELECT * FROM user WHERE id='".$id."' LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
	$id=$row['id'];
	$username=$row['name'];
	$admin=$row['admin'];
	$passwd=$row['password'];
	$lang=$row['lang']; 
	$act="create"; // smart !
    // 0.3.3: Avoid "create new" as headline:
    $act2=1;
    //
}	


if ($act=="create") {
	echo '<FORM NAME"="userform" METHOD="POST" action="index.php?what=users&act=store">';
	if (isset($id)) { echo '<input type="hidden" name="id" value="'.$id.'">'; }
	// 0.3.3: Changed to accomodate the diff. btw. "create" and "edit":
	if (!isset($act2)) {
        headline("","Create new","");
    } else {
        headline("","Edit","");
    }
	echo '<table border="1" cellspacing="0" cellpadding="0" rules="rows">';
	echo '<tr><td width="10%">'.xlate("Username").':</td>';
	echo '<td align="left"><input type="text" name="username" class="tfield"';
	if (isset($username)) { echo ' value="'.$username.'"'; }
	echo '></td></tr>';
	echo '<tr><td>'.xlate("Admininstrator").'? :</td>';
	echo '<td><input type="checkbox" name="admin"';
	if (isset($admin) && ($admin=="1")) { echo ' checked'; }
	echo '></td></tr>';
	echo '<tr><td>'.xlate("Password").':</td>';
	echo '<td><input type="text" name="passwd" class="tfield"';
	if (isset($passwd)) { echo ' value="'.$passwd.'"'; }
	echo '></td></tr>';
	echo '<tr><td>'.xlate("Language").':</td><td>';
	if (!isset($lang)) {
		$lang="EN";
	}	
	disp_language_options($lang);
	echo '</td></tr>';
	echo '<tr><td colspan="2" align="center"><input type="submit" class="tfield" value="'.xlate("Save & continue").'" ';
    echo '</td></tr>';
	echo '</table></FORM>';
}	

if ($act=="store") {
	if (isset($_POST['admin'])) { $adm="1"; } else { $adm="0"; }
	if (isset($_POST['id'])) {
		$qry="UPDATE user SET name='".$_POST['username']."', admin='".$adm."', password='".$_POST['passwd'];
        $qry.="', lang='".$_POST['lang']."' WHERE id='".$_POST['id']."' LIMIT 1"; // 0.3.1: added $_POST['lang']
        // 0.3.1: Change current session[lang], if user=current user:
        if ($_SESSION['login']==$_POST['username']) {
            $_SESSION['lang']=$_POST['lang'];
        }
        //
	} else {
		$qry="INSERT INTO user (name, admin, password, lang, count)";
		$qry.=" VALUES ('".$_POST['username']."', '".$adm."', '".$_POST['passwd']."', 'EN', '20')";
	}
	$result=execute_sql($qry,0,-1,$nr);
	echo $qry;
	header("Location: index.php?what=users&act=disp");
}

if ($act=="delete") {
	// get the user name (used for deletion of favorites):
	$qry="SELECT id,name FROM user WHERE id='".$id."'";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
	$name=$row['name'];
	// delete the user-account:
	$qry="DELETE FROM user WHERE id=".$id." LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	// delete the FAVORITES as well:
	$qry="DELETE FROM favorites WHERE fuser='".$name."'";
	$result=execute_sql($qry,0,-1,$nr);
	header("Location: index.php?what=users&act=disp");
}
?>	
