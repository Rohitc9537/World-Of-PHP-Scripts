<?
if (!file_exists('db_new.sql')) {
	session_start();
	if (!isset($_SESSION['login'])) {
		echo 'Not logged in';
		exit;
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>AmpJuke</title>
<meta name="generator" content="PHP Designer 2005">
<link rel="stylesheet" type="text/css" href="./ampstyles.css">

</head>

<body>
<?		
require("db.php");
require("sql.php");
require("disp.php");
$count=1;
parse_str($_SERVER["QUERY_STRING"]);

/*
					SUPPORT FUNCTIONS FOR function process_files
*/					
function find_key($what,$key) {
// Input: "key" we want to find the corresponding ID for in a given table (="what")
$ret=0;
if ($what=='performer') {
	$qry='SELECT * FROM performer WHERE pname="'.$key.'"';
	$result=execute_sql($qry,0,1,$num_rows,'');
	}
if ($what=='album') {
	$qry='SELECT * FROM album WHERE aname="'.$key.'"';
	$result=execute_sql($qry,0,1,$num_rows,'');
	}
if ($what=='track') {
	$qry='SELECT * FROM track WHERE name="'.$key.'"';
	$result=execute_sql($qry,0,1,$num_rows,'');
	}
if ($num_rows>=1) {
	$row=mysql_fetch_array($result);
	if ($what=='performer') { $ret=$row['pid']; }
	if ($what=='album') { $ret=$row['aid']; }
	if ($what=='track') { $ret=$row['id']; }
	}
return $ret;
}	

function find_keys($artist,$album,$trk_name) {
$ret=0;
$art_id=find_key('performer',$artist);
$alb_id=find_key('album',$album);
$qry='SELECT * FROM track WHERE ';
if ($album!="") { 
		$qry.='performer_id='.$art_id.' AND album_id='.$alb_id.' AND name="'.$trk_name.'"';
	} else {
		$qry.='performer_id='.$art_id.' AND name="'.$trk_name.'"';
	}	
$result=execute_sql($qry,0,1,$num_rows,'');
if ($num_rows<>0) { $ret=1; }
return $ret;
}


function add_key($what,$key,$f_key) {
if ($what=='performer') {
	$qry='INSERT INTO performer VALUES("","'.$key.'")';
	}
if ($what=='album') {
	$qry='INSERT INTO album VALUES("","'.$f_key.'","'.$key.'")';
	}
$result=execute_sql($qry,0,-1,$num_rows,'');
}	


function get_value($arr) {
	$ret="";
	if (is_array($arr)) {
	foreach ($arr as $k => $v) { $ret=$v; }
	}
	return $ret;
}	

require_once("./getid3/getid3.php");

function use_getid($dir,&$w,&$ws,&$e,&$es,&$art,&$alb,&$tit,&$yea,&$dur,&$pat,&$tra,$print_details) {
$ws="";
$es="";
$getID3 = new getID3;
$ThisFileInfo = $getID3->analyze($dir);
/*
$ret="";
if (is_array($ThisFileInfo)) {
	$a=$ThisFileInfo['tags'];
	$b=$a['id3v2'];
	if (array_key_exists('artist',$b)) { $art=get_value($b['artist']); } else { $art=''; $e++; $es.="No artist "; }
	if (array_key_exists('title',$b)) { $tit=get_value($b['title']); } else { $tit=''; $e++; $es.=" No title ";}
	if (array_key_exists('album',$b)) { $alb=get_value($b['album']); } else { $alb=''; $w++; $ws.=" No album ";}
	if (array_key_exists('year',$b)) { $yea=get_value($b['year']); } else { $yea=''; $w++; $ws.=" No year ";}
	if (array_key_exists('track',$b)) { $tra=get_value($b['track']); } else { $tra=0; $w++; $ws.=" No track# ";}
	$pat=$ThisFileInfo['filenamepath']; 
	$dur=$ThisFileInfo['playtime_string']; 
	if (strlen($ThisFileInfo['playtime_string'])<5) { $dur='0'.$dur; }
	}
*/
// 0.3.1 the above changed to:
    getid3_lib::CopyTagsToComments($ThisFileInfo);

    // artist from any/all available tag formats:
    $art=@$ThisFileInfo['comments_html']['artist'][0];
    if ($art=="") { $e++; $es.=" No artist: ".$dir.'<br>'; }

    // title:
    $tit=@$ThisFileInfo['comments_html']['title'][0];
    if ($tit=="") { $e++; $es.=" No title: ".$dir.'<br>'; }

    // album: 
    $alb=@$ThisFileInfo['comments_html']['album'][0];
    if ($alb=="") {
        $w++; $ws.=" No album: ".$dir.'<br>';
    }
    
    // year: 
    $yea=@$ThisFileInfo['comments_html']['year'][0];
    if ($yea=="") {
        $w++; $ws.=" No year: ".$dir.'<br>';
    }

    // track#:
    $tra=@$ThisFileInfo['comments_html']['track'][0];
    if ($tra=="") {
        $w++; $ws.=" No track number: ".$dir.'<br>';
    }

    // the rest:
    $pat=$ThisFileInfo['filenamepath'];
    $dur=$ThisFileInfo['playtime_string'];
    if (strlen($ThisFileInfo['playtime_string'])<5) { $dur='0'.$dur; }
    if ($print_details==1) {
        if ($ws=="") {
            echo "OK: ".$dir.'<br>';
        } else {
            echo '<font color="RED"><b>'.$ws.'</b><font color="black">';
        }
    }
//
}




/*


							ACTUAL / REAL STUFF HERE:
							
*/

							
function process_files($dir,&$ok,&$warnings,&$errors,&$act,$print_details) {
$errors=0;
$ok=0;
$warnings=0;
$errors=0;
$total=0;
$first_file=1;
$handle=opendir($dir);
$error_buf="<tr><td>Dir=".$dir."</td>";

while ($file=readdir($handle)) {
	$is_music="1";
	$ext=explode(".", $file);
	if (is_array($ext)) {
    // 0.3.1: We now allow these extenstions: "mp3", "ogg", "wma" and "ape":
        $extension=strtolower(($ext[count($ext)-1])); // just for "readability" on next line:
		if (($extension!="mp3") && ($extenstion!="ogg") && ($extenstion!="wma") && ($extension!="ape")) {
			$is_music="0";
			$error_flag=4;
		}
	//
	}	
	if (($file!="." && $file!="..") && ($is_music=="1")) { // Skip dirs. ("."), parent dirs ("..") & non-MUSIC-files
// Step 0: Read a file:
		$error_flag=0;
		use_getid($dir.$file,$warnings,$ws,$errors,$es,$artist,$album,$title,$year,$duration,$path,$track_no,$print_details);
// Step 1: Check that title/artist contains something:
		if ($artist=="" || $title=="") {
			$error_flag=1;
		}	
// Step 2: If album isn't empty then find out if title, album & artist exists:
		if ($album!="") {
			$title_exists=find_keys($artist,$album,$title);
			if (($title_exists==1) && ($act!="analyze")) {
				$error_flag=2;
			}
		}	
// Step 3: If album is empty then find out if title & artist exists:
		if ($album=="" && $error_flag==0) {
			$title_exists=find_keys($artist,$album,$title);
			if (($title_exists==1) && ($act!="analyze")) {
				$error_flag=3;
			}
		}
// Step 4: We can now start to add some data...
// If we cannot find the artist, then add it:
		if ($error_flag==0) {
			$artist_id=find_key('performer',$artist);
			if (($artist_id==0) && ($act!="analyze")) {
				add_key('performer',$artist,'');
				$artist_id=find_key('performer',$artist);
			}
		}
// Step 5: We can now add some more data...
// If we cannot find the album, then add it:
		if ($error_flag==0 && $album!="") {
		// First, store the previous performer's id (used later):
			if ($first_file!=1) {
				$qry="SELECT * FROM album WHERE aid=".$album_id;
				$result=execute_sql($qry,0,1,$num_rows,'');
				$row=mysql_fetch_array($result);
				$previous_performer_id=$row['aperformer_id'];
			}	
		// Second, add the album:
			$album_id=find_key('album',$album);
			if (($album_id==0) && ($act!="analyze")) {
				add_key('album',$album,$artist_id); // we have artist_id from previous step
				$album_id=find_key('album',$album);
			}	
		}		
		// Optional, Third: IF the album IS empty (ie. bought/"borrowed"/standalone track, set the album_id to 0
		if ($error_flag==0 && $album=="") {
			$album_id=0;
		}	
				
// Step 6: This is a tricky part...
// If the album exists and the album's artist!=current artist and we're @ 2nd file or above, 
// THEN set the album's artist to 0 ("Various"):
		if ($error_flag==0 && $album!="") {
			if ($first_file==0 && $artist_id!=$previous_performer_id) {
				$qry="SELECT * FROM album WHERE aid=".$album_id;
				$result=execute_sql($qry,0,-1,$num_rows,'');
				$row=mysql_fetch_array($result);
				if ($act!="analyze") {
					$qry="UPDATE album SET aperformer_id=1 WHERE aid=".$row['aid'];
					$result=execute_sql($qry,0,-1,$num_rows,'');
				}	
			}
		}
		
// Step 7: If no errors: Add the TRACK and update counters
		if ($error_flag==0) {
			$now=date("U");
			if ($act!="analyze") {
				$qry='INSERT INTO track VALUES("","'.$artist_id.'","'.$album_id.'","'.$track_no.'","'.$title.'",';
				$qry.='"'.$duration.'","'.$now.'","0","'.$year.'","'.$dir.$file.'")';
				$result=execute_sql($qry,0,-1,$num_rows,'');
			}	
			$ok++;	
			$first_file=0;
		}	
			
// Step 8: If errors: Print them.				 
		if ($error_flag!=0) {
			if ($error_flag==1) {
				$errmsg="Title and/or artist is empty: ";
			}
			if ($error_flag==2) {
				$errmsg="Title, album and artist already exists in the database:";
			}
			if ($error_flag==3) {
				$errmsg="Track already in the database:";
			}
			$errmsg.="<br>Track#=$track_no";
			$errmsg.="<br> Artist=$artist";
			$errmsg.="<br>Title=$title";
			$errmsg.="<br>Album=$album";
			$errmsg.="<br>Year=$year";
			$errmsg.="<br>Duration=$duration";
			$errmsg.="<br>Path&file=$dir$file<br>";
			print '<p class="note"><font color="red">Error:<font color="black"><br>'.$errmsg.'</p>';
			$errors++;
		}			

// Step 9: Update counters:
		$total++;
		}
	} // if file!=. & ..	
} // while file=readdir...		



function listall($dir,&$mastercount,&$act,$print_details) // 0.3.1: print_details is new
{ 
    $dir_files = $dir_subdirs = array(); 
    chdir($dir); 
    $handle = @opendir($dir) or die( "Directory \"$dir\"not found."); 
    $count=0; 
     // Loop through all directory entries, construct   
     // two temporary arrays containing files and sub directories 
    while($entry = readdir($handle)) { 
        if(is_dir($entry) && $entry !=  ".." && $entry !=  ".") { 
        	$dir_subdirs[] = $entry; 
        } 
        elseif($entry !=  ".." && $entry !=  ".") {    
            $dir_files[] = $entry; 
            $count++;
        } 
    } // while... 

    sort($dir_files); 
    sort($dir_subdirs); 
       
	if ($count>0) {  
		print "<tr>";
		print '<td valign="top">'.$mastercount.'</td>';
		print '<td valign="top"><b>'.$dir.'</b>';
		print '<td valign="top">'.$count.' files</td><td>';
		process_files($dir,$ok,$warnings,$errors,$act,$print_details);
		print '</td><td valign="top">Ok:'.$ok.' Warnings:'.$warnings.' Errors:'.$errors;
        // 0.3.1: adds a link in case of warnings/errors
        if ((($warnings<>0) || ($errors<>0)) && ($print_details==0)) {
            print '<br><a href="scan.php?act=analyze&clickdir='.$dir.'" target="_blank">';
            print 'Click here for more information.</a>';
        }
        //
		print "</td></tr> \n";	
		$mastercount++;
	}
	
     // Traverse sub directories 
    for($i=0; $i<count($dir_subdirs); $i++) { 
        listall( "$dir$dir_subdirs[$i]/",$mastercount,$act); 
    } 
    closedir($handle); 
} 

/*

        DETERMINE WHAT SHOULD BE DONE:

*/


if (($act=="rebuild") || ($act=="analyze")) {
	// rebuild: we want to re-build the database (f.ex.: new music was added).
	// analyze: we want to have a closer look at a directory.
	// We'll have to allow "inifinite" execution time of scripts, due to possible large amounts of data 
	//(that is: your music collection is BIG and/or you're on a slow server), furhtermore we want only
	// to have "real" errors printed out:
	set_time_limit(0);
	error_reporting(1);
	echo '<div class="note">Start @ '.(date("H:m:s")).'</div>';
	// check if we want to look WITHIN the base_music_dir:
	if (isset($_POST['subdir'])) {
		$base_music_dir.=$_POST['subdir'];
	}	
    // 0.3.1: We might have CLICKED on a link previously (ie.: Analyze & print details about warnings/errors):
    $print_details=0;
    if (isset($clickdir)) {
        $base_music_dir=substr($clickdir,0,strlen($clickdir)-1);
        $print_details=1;
    }
    //
	echo '<table width="100%" border="1" cellspacing="0" cellpadding="0" rules="rows">';
	listall($base_music_dir.'/',$count,$act,$print_details);
	echo '</table><br>';
    $count--;
    // 0.3.1: Changed slightly, - depends on the value of "clickdir":
   	echo '<div class="note">'.$count." dirs done @ ".(date("H:m:s")).'<br>';
    if (!isset($clickdir)) {
        echo '<a href="'.$base_http_prog_dir.'">Click here to continue.</a>';
	} else {
        echo 'Analysis completed.';
    }
    echo '</div>';
    //
}

if ($act=="configure") { // we want to display options:
	require("configuration.php");
	echo '<FORM NAME="cfgform" method="POST" action="scan.php?act=write">';
	echo '<table width="100%" border="1" cellspacing="0" cellpadding="0" rules="rows">';
	echo '<tr bgcolor="#abcdef"><td colspan="5" align="center"><br> <b>Database options</b><br>&nbsp</td></tr>';
// DATABASE STUFF:
	echo '<tr><td>Database host:</td>';
	echo '<td><input type="text" name="db_host" class="tfield" value="'.get_configuration("db_host").'" size="40">';
	echo '</td></tr>';
	echo '<tr><td>Database user:</td>';
	echo '<td><input type="text" name="db_user" class="tfield" value="'.get_configuration("db_user").'" size="40">';
	echo '</td></tr>';
	echo "<tr><td>Database user's password:</td>";
	echo '<td><input type="text" name="db_password" class="tfield" value="'.get_configuration("db_password");
    echo '" size="40">';
	echo '</td></tr>';
	echo '<tr><td>Database name:</td>';
	echo '<td><input type="text" name="db_name" class="tfield" value="'.get_configuration("db_name").'" size="40">';
	echo '</td></tr>';
	if (file_exists("db_new.sql")) {
		echo "<tr><td>Create an empty database:</td>";
		echo '<td><input type="checkbox" name="createdb" value="1" class="tfield">';
		echo '<b>Warning:</b> If you select an existing database, <b>everything</b> within ';
        echo 'it will be <b>deleted</b> !<br>';
		echo '</td></tr>';
		echo "<tr><td>Create empty tables within the database:</td>";		
		echo '<td><input type="checkbox" name="createtbl" value="1" class="tfield">';
		echo '</td></tr>';
	} else {
		echo '<tr><td colspan="2">Rename "<b>db_new.php</b>" to "<b>db_new.sql</b>" if you want ';
        echo 'the option to create a new database and/or new tables from scratch<br>';
		echo 'If your database & tables already exists you might as well delete "<b>db_new.php</b>"';
		echo '</td></tr>';
	}	
// DIR. STUFF:	
	echo '<tr bgcolor="#abcdef"><td colspan="5" align="center"><br> <b>Location of files, tmp. files & ';
    echo 'your music</b><br>&nbsp</td></tr>';
	// Tmp music dir.:
	echo '<tr><td valign="top">Directory to place music temporarily:</td>';
	echo '<td><input type="text" name="music_tmp_dir" class="tfield" ';
    echo 'value="'.get_configuration("music_tmp_dir").'" size="80">';
	echo '<br><b>Remember:</b><br>1. To add a trailing slash. F.ex.: /usr/local/apache2/htdocs/ampjuke/tmp/<br>';
	echo '2. The directory <b>must</b> be accessible from the "outside" (that is www)<br>';
	echo '3. The directory <b>must</b> be writeable for everyone (hint: CHMOD 777 to the directory).';
	echo '</td></tr>';
	// Location of music:
	echo '<tr><td valign="top">"Base" directory where your music files are located:</td>';
	echo '<td><input type="text" name="base_music_dir" class="tfield" ';
    echo 'value="'.get_configuration("base_music_dir").'" size="80">';
	echo '<br><b>Remember:</b><br>1. No trailing slash<br>';
	echo '2. Absolute path. F.ex.: /home/michael/my_music';
	echo '</td></tr>';
	// Location of program:
	echo '<tr><td valign="top">HTTP-Location of program files:</td>';
	echo '<td><input type="text" name="base_http_prog_dir" class="tfield" ';
    echo 'value="'.get_configuration("base_http_prog_dir").'" size="80">';
	echo '<br><b>Examples:</b><br>';
	echo 'http://www.yourhost.com/location-of-ampjuke<br>';
	echo 'http://www.somehost.com/ampjuke';
	echo '</td></tr>';
// MISC STUFF:
	echo '<tr bgcolor="#abcdef"><td colspan="5" align="center"><br> <b>Miscellaneous options </b><br>&nbsp</td></tr>';
	echo '<tr><td valign="top">Date/time format to display:</td>';
	echo '<td><input type="text" name="dateformat" class="tfield" ';
    echo 'value="'.get_configuration("dateformat").'" size="40">';
	echo '<br><b>Examples:</b></br>';
	echo '<b>Y-m-d H:m:s</b> ...will f.ex. display: 2005-05-20 20:05:55<br>';
	echo '<b>r</b> ...will display Sat, 23 Jul 2005 16:01:07 +0200<br>';
	echo 'See <a href="http://www.php.net/manual/en/function.date.php" target="_blank">';
    echo 'the PHP manual</a> for other examples.';
	echo '</td></tr>';
    // 0.3.0: Amazon key & auto-delete of 'tmp' files:
    echo '<tr><td valign="top">Amazon key:</td>';
    echo '<td><input type="text" name="amazon_key" class="tfield" ';
    echo 'value="'.get_configuration("amazon_key").'" size="25">';
    echo '<br>The "Amazon key" is the key you get when you create an ';
    echo '<a href="https://aws-portal.amazon.com/gp/aws/developer/registration/index.html/" target="_blank">';
    echo 'Amazon Web Services (AWS)</a> account.<br>';
    echo 'It is used if you want to display album/cover art and/or you do not have any covers stored in the "covers" folder.<br>';
    echo 'It is very easy to create an AWS account (a couple of minutes), and it will help a lot in';
    echo ' AmpJuke regarding the capability of displaying album/cover art.';
    echo '</tr>';
    echo '<tr><td valign="top">Delete files in "tmp directory" after X hours:</td>';
    echo '<td><input type="text" name="max_hours" class="tfield" ';
    echo 'value="'.get_configuration("max_hours").'" size="5">';
    echo '<br>The setting determines how many hours a music file can exist in the "tmp" directory.';
    echo '<br>The term "tmp directory" refers to the value you enter in the field';
    echo ' "Directory to place music temporarily" above.<br>';
    echo 'The value (<b>must</b> be integer) is the maximum number of hours a music file may exist in the ';
    echo '"tmp directory" before it is deleted.<br>';
    echo 'Suggested value: 24 (that is one day), 48 (two days) or perhaps even bigger.<br>';
    echo 'This entirely depends on the (anticipated) number of tracks you and others might play per day/hour/whatever';
    echo ' combined with the actual size of your harddrive.<br>';
    echo 'Note that users with administrator access still has the option to clear the entire "tmp directory" at any';
    echo 'time, regardless of what this setting is.';
    echo '</tr>';

    //
	echo '<tr><td colspan="5" align="center">';
	echo '<input type="submit" value="Save & continue" class="tfield">';
	echo '</td></tr>';
	echo '</table></form>';
} // if act=configure

// 0.2.4: either we want to rescan or we've just submitted (new) options, - now write 'em to the db.php file:
if (($act=="write") || ($act=="rescan")) { 
	require("configuration.php");
	if ($act=="write") { // 0.2.4:
		$handle=fopen("db.php", "w");
		fwrite($handle, '<?' . chr(13) . chr(10));
		fwrite($handle, '$db_host="'.$_POST['db_host'].'";' . chr(13) . chr(10));
		fwrite($handle, '$db_user="'.$_POST['db_user'].'";' . chr(13) . chr(10));
		fwrite($handle, '$db_password="'.$_POST['db_password'].'";' . chr(13) . chr(10));
		fwrite($handle, '$db_name="'.$_POST['db_name'].'";' . chr(13) . chr(10));
		fwrite($handle, '$music_tmp_dir="'.$_POST['music_tmp_dir'].'";' . chr(13) . chr(10));
		fwrite($handle, '$base_music_dir="'.$_POST['base_music_dir'].'";' . chr(13) . chr(10));
		fwrite($handle, '$base_http_prog_dir="'.$_POST['base_http_prog_dir'].'";' . chr(13) . chr(10));
		fwrite($handle, '$dateformat="'.$_POST['dateformat'].'";' . chr(13) . chr(10));
        // 0.3.0:
        fwrite($handle, '$amazon_key="'.$_POST['amazon_key'].'";' . chr(13) . chr(10));
        fwrite($handle, '$max_hours='.$_POST['max_hours'].';' . chr(13) . chr(10));
        //
		fwrite($handle, "?");
		fwrite($handle, ">" . chr(13) . chr(10));
		fclose($handle);
		if ((isset($_POST['createdb'])) || (isset($_POST['createtbl']))) { // we want to create a new database and/or new tables - from SCRATCH:
			$connection=mysql_connect($_POST['db_host'],$_POST['db_user'],$_POST['db_password']) or die('Create database: Could not connect.');
			if (isset($_POST['createdb'])) { // we really want to create an empty database:
				$qry="DROP DATABASE IF EXISTS ".$_POST['db_name'];
				$result=mysql_query($qry) or die(mysql_error());
				$qry="CREATE DATABASE ".$_POST['db_name'];
				$result=mysql_query($qry, $connection) or die(mysql_error());
			}	
			if (isset($_POST['createtbl'])) { // we want to create empty tables within the database:
				mysql_select_db($_POST['db_name']) or die(mysql_error());
				// First, drop existing tables (if they're there):
				$qry="DROP TABLE IF EXISTS album";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				$qry="DROP TABLE IF EXISTS favorites";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				$qry="DROP TABLE IF EXISTS performer";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				$qry="DROP TABLE IF EXISTS queue";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				$qry="DROP TABLE IF EXISTS track";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				$qry="DROP TABLE IF EXISTS user";
				$result=mysql_query($qry, $connection) or die(mysql_error());
				// Second, create the tables (again):
				require("db_new.sql");
				$result=mysql_query($c_album, $connection) or die(mysql_error());
				$result=mysql_query($c_favorites, $connection) or die(mysql_error());
				$result=mysql_query($c_performer, $connection) or die(mysql_error());
				$result=mysql_query($c_queue, $connection) or die(mysql_error());
				$result=mysql_query($c_track, $connection) or die(mysql_error());
				$result=mysql_query($c_user, $connection) or die(mysql_error());
				// Third, insert the "defaults" in user & performer (so we can login):
                // this query ensures we have a place to store albums w. "various" (ie. multiple) performers:
				$qry="INSERT INTO performer VALUES ('1','')"; 
				$result=execute_sql($qry,0,-1,$nr);
				$qry="INSERT INTO user (name, admin, password, lang, count) VALUES ('admin', '1', 'pass', 'EN', '20')";
				$result=execute_sql($qry,0,-1,$nr);				
			}			
			echo '<p class="note">Ok. Everything is fine so far !<br>';
			if (isset($_POST['createdb'])) { 
				echo 'The database was created successfully.<br>';
			}
			if (isset($_POST['createtbl'])) {	
				echo 'New tables were created successfully.<br>';
			}	
			// 0.2.5: instructions changed:
			echo '<br>Now, do the following:<br>';
			echo '1. Login using username: "<b>admin</b>" and password: "<b>pass</b>"<br>';
			echo '2. Click "<b>Scan music...</b>" in the menu to the left (under "Admins options")<br>';
			echo '3. One the next screen: Click "<b>Scan&import all music...</b>". This step may take a LONG time, in case you have many music files and/or AmpJuke is on a slow server<br>';
			echo '<hr width="80%" color="#abcdef" align="center">';
			echo '<p class="note">&nbsp';
			echo '<font color="red"><b>Special notes:</b><br>';
			echo 'Please <b>change the password for "admin"</b> as one of the first things after logging in in order not to compromise your system.<br>';
			echo 'For improved security, you should also consider renaming/deleting the files "<b>db_new.php</b>" as well as "<b>install.php</b>".<br>';
			echo '<a href="login.php">Click here to login.</a>';
			// 0.3.0: just rename "new_db.sql" & exit script:
			exec("mv db_new.sql db_new.php");
			exit;
		} // _POST[createdb]...
	} // act==write. Version 0.2.4
	// Offer some options (doesn't matter if act=write or act=rescan
	echo '<table border="1" cellspacing="0" cellpadding="0" rules="rows">';
	echo '<tr><td colspan="5" align="center" bgcolor="#abcdef"><b>Music options</b></td></tr>';
	echo '<tr><td valign="top"><a href="scan.php?act=rebuild"><img src="./icons/mnu_arr.gif" border="0"> Scan&import all music available</a></td>';
	echo '<td>If selected, you entire music collection will be re-scannned.<br>Only <b>new</b> music will be added';
	echo ' to the database.<br>This step may take long time to complete.';
	echo '</td></tr>';
	echo '<tr><td valign="top"><form name="newdir" method="POST" action="scan.php?act=rebuild">';
	echo 'Only scan&import for files within:<b>'.$base_music_dir.'</b>';
	echo '<input type="text" name="subdir" value="" size="80" class="tfield"></td>';
	echo '<td>Enter a subdirectory within <b>'.$base_music_dir.'</b> that you want to import music from.<br>';
	echo 'If you f.ex. enter <b>/my_new_music</b>, the program will look for and import new music from <b>'.$base_music_dir.'/my_new_music</b> and any directories below.<br>';
	echo '<b>Note</b>: You will need to put in a leading / (just like in the example)';
	echo '</td></tr></form>';
	echo '<tr><td valign="top"><form name="newdir" method="POST" action="scan.php?act=analyze">';
	echo 'Scan&<b>analyze</b> music within:<b>'.$base_music_dir.'</b>';
	echo '<input type="text" name="subdir" value="" size="80" class="tfield"></td>';
	echo '<td>Enter a subdirectory within <b>'.$base_music_dir.'</b> that you want <b>analyze</b> (no music will be imported).';
	echo '</td></tr></form>';
	echo '</form>';
	echo '<tr><td colspan="5" bgcolor="#abcdef">&nbsp</td></tr>';
	echo '<tr><td colspan="5"><a href="index.php?what=welcome"><img src="./icons/mnu_arr.gif" border="0"> Go back to the "Welcome" page</a>';
	echo '</td></tr>';
	echo '</table>';

} // act=write | rescan
?>
</body>
</html>
