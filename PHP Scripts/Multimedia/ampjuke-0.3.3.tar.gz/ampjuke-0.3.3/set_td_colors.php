<?
function fancy_tr(&$tmpcount,$tdnorm,$tdalt,$tdhighlight) {
	if ($tmpcount/2==round($tmpcount/2)) { 
		print "\n";
		echo '<tr bgcolor='.$tdnorm.' onmouseover="this.style.backgroundColor=';
		echo "'".$tdhighlight."'";
		echo '" onmouseout="this.style.backgroundColor=';
		echo "'".$tdnorm."'";
		echo '">'; 
	} else {
		echo '<tr bgcolor='.$tdalt.' onmouseover="this.style.backgroundColor=';
		echo "'".$tdhighlight."'";
		echo '" onmouseout="this.style.backgroundColor=';
		echo "'".$tdalt."'";
		echo '">'; 
	} 
	$tmpcount++;
} 

function fancy_tr_buf(&$tmpcount,$tdnorm,$tdalt,$tdhighlight) {
	$ret='';
	if ($tmpcount/2==round($tmpcount/2)) { 
		$ret.='<tr bgcolor='.$tdnorm.' onmouseover="this.style.backgroundColor=';
		$ret.="'".$tdhighlight."'";
		$ret.='" onmouseout="this.style.backgroundColor=';
		$ret.="'".$tdnorm."'";
		$ret.='">'; 
	} else {
		$ret.='<tr bgcolor='.$tdalt.' onmouseover="this.style.backgroundColor=';
		$ret.="'".$tdhighlight."'";
		$ret.='" onmouseout="this.style.backgroundColor=';
		$ret.="'".$tdalt."'";
		$ret.='">'; 
	} 
	$tmpcount++;
	return $ret;
} 
	


//echo '<table border="1" rules="rows" cellpadding="0" cellspacing="1px">';
$tmpcount=1;
require("db.php");
?>
