<?
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">';
print '<html><head><title>AmpJuke - Login</title>';
print '<link rel="stylesheet" type="text/css" href="ampstyles.css">';
print "\n";
print '</head>';

print '<body>';

echo '<table border="1" cellspacing="0" cellpadding="1px" rules="none">';
print '<form name="login" method="POST" action="loginvalidate.php">';
echo '<tr>';
echo '<td colspan="2" align="center"><img src="./icons/ampjuke176x62.jpg" border="0"></td>';
echo '</tr><tr bgcolor="#eaeaea">';
echo '<td width="50%" align="right">Login:</td><td width="50%"><input class="tfield" type="text" size="10" name="login">';
echo '</td></tr><tr bgcolor="#eaeaea"><td width="50%" align="right">';
echo 'Password:</td><td width="50%"><input class="tfield" type="password" size="10" name="password">';
echo '</td>';
echo '</tr>';
print '<tr><td colspan="2" align=center><input type="submit" name="Submit" value="Submit" class="tfield"></td></tr>';
print '</form></table>';

print '<script language="JavaScript"> document.forms[0].login.focus(); </script>';


print '</body></html>'
?>