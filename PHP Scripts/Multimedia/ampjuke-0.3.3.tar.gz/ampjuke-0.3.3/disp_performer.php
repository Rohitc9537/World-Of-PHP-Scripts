<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require_once("sql.php");
require_once("set_td_colors.php");
require_once("disp.php");
$qry="SELECT pid, pname FROM performer WHERE pid>1";
if (isset($limit)) {
	if ($what=="search") {
		$qry.=' AND pname LIKE "%'.$limit.'%"';
	} else {
		$qry.=' AND pname LIKE "'.$limit.'%"';
	}	
}
if (($order_by!="") && ($sorttbl=="performer")) {
	$qry.=" ORDER BY $order_by $dir ";
}	

$tmpstart=$start;
$tmpsel=$pagesel;
if ($pagesel=="performer") {
	$result=execute_sql($qry,$start,$count,$num_rows);
} else {
	$result=execute_sql($qry,0,$count,$num_rows);
	$start=0;
	$pagesel="performer";
}	

$l="";
if ($limit=="") { $l.=xlate('All'); }
if ($what=="search") { $l="</i>&nbsp[".xlate("Performers")."]"; }
headline($what,'',$limit.$l.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>'); 
// special options: letters
echo '<td>';
if ($what!="search" && $_SESSION['show_letters']=="1") {
	show_letters("performer","performer.pname"); // 0.2.4
}
echo '</td></tr></table>';

if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require_once("tbl_header.php");
if ($_SESSION['show_ids']=="1") {
	tbl_header($what,xlate("ID"),"left","performer.pid",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=performer&pagesel='.$pagesel);
}	
tbl_header($what,$d_performer,"left","performer.pname",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=performer&pagesel='.$pagesel);
// 0.2.2:
echo '<th align="right">'.xlate("Albums").'</th><th align="right">'.xlate("Tracks").'</th>';
//

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	if ($_SESSION['show_ids']=="1") {
		echo '<td>';
		if ($_SESSION['admin']!="1") {
			echo $row['pid'];
		} else {
			echo '<a href="index.php?what=edit&edit=performer&id='.$row['pid'].'">'.$row['pid'].'</a>';
		}	
		echo '</td>';		
	}	
	add_performer_link($row['pname'],$row['pid']);
	// 0.2.2:
	$q="SELECT aid,aperformer_id FROM album WHERE aperformer_id='".$row['pid']."'";
	$res=execute_sql($q,0,1000000,$nr);
	echo '<td align="right">'.$nr.'</td>';
	$q="SELECT id,performer_id FROM track WHERE performer_id='".$row['pid']."'";
	$res=execute_sql($q,0,1000000,$nr);
	echo '<td align="right">'.$nr.'</td>';
	//
	print "</tr> \n";
}
echo '</table>';	

if ($what=="search") {
	$within="performers";
	$sorttbl="performer";
}	
require("page_numbers.php");
$start=$tmpstart;
$pagesel=$tmpsel;
?>
