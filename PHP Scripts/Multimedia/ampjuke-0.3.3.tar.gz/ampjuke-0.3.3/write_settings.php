<?
session_start();
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}

$q=$_POST['playmethod'];
$ipp=$_POST['count'];
if (!is_numeric($ipp)) { $ipp=10; }
$tdn=$_POST['tdnorm'];
$tda=$_POST['tdalt'];
$tdh=$_POST['tdhighlight'];
$tdb=$_POST['bodycol'];
// 0.3.0:
$ll=$_POST['lang'];
//
$dtp="0";
if (isset($_POST['disp_times_played'])) { $dtp="1"; }

$dlp="0";
if (isset($_POST['disp_last_played'])) { $dlp="1"; }
$showids="0";
if (isset($_POST['show_ids'])) { $showids="1"; }
$showletters="0";
if (isset($_POST['show_letters'])) { $showletters="1"; }

// set values for the current SESSION:
$_SESSION['count']=$ipp;
$_SESSION['tdnorm']=$tdn;
$_SESSION['tdalt']=$tda;
$_SESSION['tdhighlight']=$tdh;
$_SESSION['bodycol']=$tdb;
$_SESSION['enqueue']=$q;
$_SESSION['disp_last_played']=$dlp;
$_SESSION['disp_times_played']=$dtp;
$_SESSION['show_ids']=$showids;
$_SESSION['show_letters']=$showletters;
// 0.3.0:
$_SESSION['lang']=$ll;
//
// construct & execute a query updating the new settings:
$qry="UPDATE user SET count='".$ipp."', enqueue='".$q."',";
$qry.=" tdnorm='".$tdn."', tdalt='".$tda."', tdhighlight='".$tdh."',";
$qry.=" bodycol='".$tdb."', disp_last_played='".$dtp."', disp_times_played='".$dlp."',";
// 0.3.0:
$qry.=" lang='".$ll."'";
//
$qry.=" WHERE name='".$_SESSION['login']."' LIMIT 1";
require("db.php");
require("sql.php");
$result=execute_sql($qry,0,-1,$nr);

echo '<script type="text/javascript" language="javascript">'; echo "history.go(-2);";
echo '</script>';
?>	
