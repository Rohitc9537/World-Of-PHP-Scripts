<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}

//0.3.3: used when displaying options in relation to filtering.
function filter_link($fo,$val,$txt) {
    if ($fo!=$val) {
        echo ' <img src="./icons/mnu_arr.gif" border="0">';
        if ($val==0) {
            echo '<a href="change_disp_options.php?what=filter_tracks&set=0">'.xlate("Filter").':';
            echo xlate($txt).'</a>&nbsp';
        }
        if ($val==1) {
            echo '<a href="change_disp_options.php?what=filter_tracks&set=1">'.xlate("Filter").':';
            echo xlate($txt).'</a>&nbsp';
        }
        if ($val==2) {
            echo '<a href="change_disp_options.php?what=filter_tracks&set=2">'.xlate("Filter").':';
            echo xlate($txt).'<a>';
        }
      }
}
//

require("sql.php");
require("set_td_colors.php");
require("disp.php");
$qry="SELECT track.id, track.name, track.performer_id, ";
$qry.="track.duration, track.year, track.last_played, track.times_played, track.path, ";
$qry.="performer.pid, performer.pname";
$qry.=" FROM track, performer ";
$qry.="WHERE track.performer_id=performer.pid";
if (isset($limit)) {
	if ($what=="search") {
		$qry.=' AND track.name LIKE "%'.$limit.'%"';
	} else {
		$qry.=' AND track.name LIKE "'.$limit.'%"';
	}		
}
// 0.3.3: do we want to filter ?
if (isset($filter_tracks)) {
    if ($filter_tracks==1) {
        $qry.=" AND track.album_id<>0"; // tracks WITH albums
    }
    if ($filter_tracks==2) {
        $qry.=" AND track.album_id=0"; // tracks WITHOUT albums
    }
}
//

if ($order_by=="track.id" && $_SESSION['show_ids']=="0") {
	$order_by="track.name";
	$dir="ASC";
}

if (($order_by!="") && ($sorttbl=="track")) {
	$qry.=" ORDER BY $order_by $dir ";
}

$tmpstart=$start;
$tmpsel=$pagesel;
if ($pagesel=="track") {
	$result=execute_sql($qry,$start,$count,$num_rows);
} else {
	$result=execute_sql($qry,0,$count,$num_rows);
	$start=0;
	$pagesel="track";
}	

$l="";
if ($limit=="") { $l.=xlate('All'); }
if ($what=="search") { $l="</i>&nbsp[".xlate("Tracks")."]"; }

// 0.3.3: Make appropriate headline
switch ($filter_tracks) {
    case 0: $e="No"; break;
    case 1: $e="Tracks only on albums"; break;
    case 2: $e="Tracks not on any album"; break;
}
if ($filter_tracks==0) {
    headline($what,'',$limit.$l.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>');
} else {
    headline('',$e,$limit.$l.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>');
}
//

echo '<td>';
if ($what!="search") { 
	show_letters("track","track.name"); 
}
// 0.3.3: display filter options:
if ($what!="search") {
    echo '&nbsp&nbsp';
    filter_link($filter_tracks,0,"No");
    filter_link($filter_tracks,1,"Tracks only on albums");
    filter_link($filter_tracks,2,"Tracks not on any album");
}
//
echo '</td></tr></table>';

if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require("tbl_header.php");
if ($_SESSION['show_ids']=="1") {
	tbl_header($what,xlate("ID"),"left","track.id",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);
}	
tbl_header($what,$d_performer,"left","performer.pname",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);

tbl_header($what,xlate("Title"),"left","track.name",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);

tbl_header($what,$d_year,"left","track.year",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);

tbl_header($what,xlate("Duration"),"left","track.duration",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);

if ($_SESSION['disp_last_played']=="1") {
	tbl_header($what,xlate("Last played"),"right","track.last_played",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);
}
if ($_SESSION['disp_times_played']=="1") {
	tbl_header($what,xlate("Played"),"right","track.times_played",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=track&pagesel='.$pagesel);
}
echo '<th> </th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	if ($_SESSION['show_ids']=="1") {
		echo '<td>';
		if ($_SESSION['admin']=="1") { // offer option to edit the track:
			echo '<a href="index.php?what=edit&edit=track&id='.$row['id'].'">'.$row['id'].'</a>';
		} else {
			echo $row['id'];
		}
		echo '</td>';	
	}	
	$perf=get_performer_name($row['performer_id']);
	add_performer_link($perf,$row['performer_id']);
	add_play_link("play",$row['id'],$row['name']);
	add_year_link($row['year'],$row['year']);
	echo '<td>'.$row['duration'].'</td>';
	if ($_SESSION['disp_last_played']=="1") {
		echo '<td align="right">'.mydate($row['last_played']).'</td>';
	}
	if ($_SESSION['disp_times_played']=="1") {
		echo '<td align="right">'.$row['times_played'].'</td>';
	}	
	echo '<td align="right">';
	if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) { // 0.2.4
		add2fav_link('','?what=track&id='.$row['id']);
	}	
	echo '</td>';	

	print "</tr> \n";
}
echo '</table>';	

if ($what=="search") {
	$within="tracks";
	$sorttbl="track";
}	
include("page_numbers.php");
$start=$tmpstart;
$pagesel=$tmpsel;
?>
