<?
require("make_header.php");
if ($what=="welcome") {
	require("welcome.php");
}	
if ($what=="track") {
	require("disp_track.php");
}	
if ($what=="performerid") {
	require("disp_performerid.php");
}	
if ($what=="performer") {
	require("disp_performer.php");
}	
if ($what=="albumid") {
	require("disp_albumid.php");
}	
if ($what=="album") {
	require("disp_album.php");
}	
if ($what=="year") {
	require("disp_year.php");
}
if ($what=="favorite") {
	require("disp_favorite.php");
}	
if ($what=="yearid") {
	require("disp_yearid.php");
}		
if ($what=="favoriteid") {
	require("disp_favoriteid.php");
}	
if ($what=="queue") {
	require("disp_queue.php");
}
if ($what=="random") {
	require("random.php");
}	
if ($what=="search") {
	require("search.php");
}		
if ($what=="settings") {
	require("disp_settings.php");
}	
if ($what=="users") {
	require("disp_users.php");
}
if ($what=="edit") {
	require("edit.php");
}	

?>
</td>
</tr>
</table>
<!-- Please do not remove the following 3 lines: -->
<table><tr><td align="right">
<a href="http://www.ampjuke.org" target="_blank"><font color="#a8a8a8">AmpJuke Version <? echo $version ?></a>
</td></tr></table>

</body>
</html>
