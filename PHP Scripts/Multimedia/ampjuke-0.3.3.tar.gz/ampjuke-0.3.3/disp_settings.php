<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("disp.php");
require("set_td_colors.php");
echo '<script language=JavaScript src="picker.js"></script>';
headline($what,'',''); // 0.2.3
echo '<table border="1" cellspacing="0" cellpadding="0" rules="rows">';
echo '<tr><td colspan="2" align="center"><p class="note">';
echo '<b>'.xlate("Play & display options").'</b></td></tr>';
// setup a form:
echo '<FORM NAME="setup" method="POST" action="write_settings.php">';

// play/enqueue:
echo '<tr><td valign="top" width="50%">'.xlate("When a track is selected").':</td>';
echo '<td align="left"><input type="radio" name="playmethod" value="1"';
if ($_SESSION['enqueue']=="1") { echo ' checked'; }
echo '> '.xlate("Put it in the queue").'<br>';
echo '<input type="radio" name="playmethod" value="0"';
if ($_SESSION['enqueue']=="0") { echo ' checked'; }
echo '> '.xlate("Play it immediately");
echo '</td></tr>';
// Items/page:
echo '<tr><td>'.xlate("Number of items per page").' :</td>';
echo '<td align="left"><input type="text" name="count" class="tfield" size="10" value="'.$_SESSION['count'].'"></td>';
echo '</tr>';
// disply options on/off:
echo '<tr><td>'.xlate("Display when a track was played last time").':</td>';
echo '<td align="left"><input type="checkbox" name="disp_last_played"';
if ($_SESSION['disp_last_played']=="1") {
	echo ' checked';
}
echo '>&nbsp</td></tr>';
echo '<tr><td>'.xlate("Display how many times a track has been played").':</td>';
echo '<td align="left"><input type="checkbox" name="disp_times_played"';
if ($_SESSION['disp_times_played']=="1") {
	echo ' checked';
}
echo '>&nbsp</td></tr>';
echo "<tr><td>".xlate("Display ID numbers").":</td>";
echo '<td align="left"><input type="checkbox" name="show_ids"';
if ($_SESSION['show_ids']=="1") {
	echo ' checked';
}
echo '>&nbsp</td></tr>';
echo "<tr><td>".xlate("Show letters (the 'Jump to' option)").":</td>";
echo '<td align="left"><input type="checkbox" name="show_letters"';
if ($_SESSION['show_letters']=="1") {
	echo ' checked';
}
echo '>&nbsp</td></tr>';

// colors:
echo '<tr><td colspan="2" align="center"><p class="note"><b>'.xlate("Colors").'</b></td></tr>';
echo '<tr><td>'.xlate('Pick a "normal" color').':</td>';
echo '<td><input type="text" name="tdnorm" class="tfield" size="8" value="'.$_SESSION['tdnorm'].'">';
?>
<a href="javascript:TCP.popup(document.forms['setup'].elements['tdnorm'], 1)"> <<<>>> </a>
<?
echo '</td></tr>';
echo '<tr><td>'.xlate('Pick an "alternative" color').' :</td>';
echo '<td><input type="text" name="tdalt" class="tfield" size="8" value="'.$_SESSION['tdalt'].'">';
?>
<a href="javascript:TCP.popup(document.forms['setup'].elements['tdalt'], 1)"> <<<>>> </a>
<?
echo '</td></tr>';
echo '<tr><td>'.xlate('Pick the "highlight" color').':</td>';
echo '<td><input type="text" name="tdhighlight" class="tfield" size="8" value="'.$_SESSION['tdhighlight'].'">';
?>
<a href="javascript:TCP.popup(document.forms['setup'].elements['tdhighlight'], 1)"> <<<>>> </a>
<?
echo '</td></tr>';
echo '<tr><td>'.xlate("Pick the background color").':</td>';
echo '<td><input type="text" name="bodycol" class="tfield" size="8" value="'.$_SESSION['bodycol'].'">';
?>
<a href="javascript:TCP.popup(document.forms['setup'].elements['bodycol'], 1)"> <<<>>> </a>
<?
echo '</td></tr>';

echo '<tr><td colspan="2" align="center"><p class="note"><b>'.xlate("Other options").'</b></td></tr>';
echo '<tr><td>'.xlate("Language").':</td>';
echo '<td>';
disp_language_options($_SESSION['lang']);
echo '</td></tr>';
echo '<tr><td bgcolor="#ffffff" colspan="2" align="center">';
// 0.3.2: Translate the submit button's text:
echo '<input type="submit" class="tfield" value="'.xlate("Save & continue").'" name="submit">';
echo '</td></tr></FORM></table>';

?>
