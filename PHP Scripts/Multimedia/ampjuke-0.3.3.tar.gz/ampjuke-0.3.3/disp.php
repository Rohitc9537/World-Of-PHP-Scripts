<? 
/*
DISP.PHP: "Library" of supporting functions for the various DISPLAY_....PHP scripts.
*/
function mydate($d) {
	require("db.php");
	return date($dateformat,$d);
}

function get_performer_name($x) {
	$ret="";
	$qry="SELECT * FROM performer WHERE pid=$x";
	$result=execute_sql($qry,0,1,$n);
	$row=mysql_fetch_array($result);
	$ret=$row['pname'];
	return $ret;
}	


function get_performer_name_track($x,$a,&$perf_name,&$perf_id) {
	$ret="";
	$qry="SELECT * FROM track WHERE track.performer_id=$x AND track.album_id=$a";
	$res=execute_sql($qry,0,1,$nr);
	$r=mysql_fetch_array($res);
	$qry="SELECT * FROM performer WHERE performer.pid=".$r['performer_id'];
	$res=execute_sql($qry,0,1,$nr);
	$r=mysql_fetch_array($res);
	$perf_name=$r['pname'];
	$perf_id=$r['pid'];	
}	

function add_play_link($action,$id,$link_name) {
	echo '<td>';
	echo '<a href="play_action.php?act='.$action.'&id='.$id.'">'.$link_name.'</a>';
	echo '</td>';
}	

function add2fav_link($t,$l) {
	echo '<a href="add2fav.php'.$l.'" title="'.$_SESSION['favoritelistname'].'">';
	if ($t=="") {
		echo '['.xlate("Add to favorite").']';
	} else {
		echo '<img src="./icons/mnu_arr.gif" border="0">'.$t;
	}	
	echo '</a>'; 
}	

function add_year_link($n,$id) { // shows a link to a certain year
	echo '<td>';
	echo '<a href="index.php?what=yearid&start=0&count='.$_SESSION['count'];
    echo '&special='.$id.'&dir=DESC&order_by=track.id">';
	echo $n.'</a>';
	echo '</td>';
}	

function add_performer_link($n,$id) {
	echo '<td>';
	echo '<a href="index.php?what=performerid&start=0&count='.$_SESSION['count'].'&special='.$id.'">';
	echo $n.'</a>';
	echo '</td>';
}	

function add_album_link($n,$id) {
	echo '<td>';
	echo '<a href="index.php?what=albumid&start=0&count='.$_SESSION['count'];
    echo '&special='.$id.'&order_by=track.track_no">';
	echo $n.'</a>';
	echo '</td>';
}	

function std_table($bgcol) {
	if ($bgcol=="1") { // "1"=make a table, but do not set the bgcolor
		echo '<table border="1" cellspacing="0" cellpadding="0" rules="none">';
	} else {
		echo '<table bgcolor="'.$bgcol.'" border="1" cellspacing="0" cellpadding="0" rules="none">';
	}
}		
			

function headline($what,$hl,$limit) {
	echo '<table border="1" cellspacing="0" cellpadding="0" rules="rows" bgcolor="#abcdef">';
    echo '<tr><td colspan="5" align="center">&nbsp<br><b>';
	switch ($what) {
		case "track":
			$hl=xlate('Tracks');
			break;
		case "album":
			$hl=xlate('Albums');
			break;
		case "albumid":
			$hl.=' '; // !
			break;
		case "performer":
			$hl=xlate('Performers');
			break;
		case "performerid":
			$limit=$hl; // uuuuhhh....
			$hl='';
			break;
		case "year":
			$hl=xlate('Year');
			break;
		case "yearid":
			$hl=xlate('Year');
			break;
		case "favorite":
			$hl=xlate('Favorites');
			break;	
		case "favoriteid":
			$hl=xlate('Favorite list');
			break;	
		case "queue":
			$hl=xlate("The queue");
			break;	
		case "search":
			$hl=xlate("Search results");
			break;	
		case "users":
			$hl=xlate("Administration");
			break;
		case "settings":
			$hl=xlate("Personal settings");
			break;		
        case "";
            $hl=xlate($hl);
            break;
	}
	echo $hl;
	if ($limit!="") {
		echo ': <i>'.$limit.'</i>';
	}	
	echo '</b><br>&nbsp</td></tr><tr bgcolor="#ffffff">'; // have to be #ffffff, cause there are LINKS in this part !
}


function show_alphabet($what,$order_by,$c) { // used w. show letters below
	$sorttbl="";
	switch ($what) {
		case "track": $sorttbl="track"; break;
		case "album": $sorttbl="album"; break;
		case "performer": $sorttbl="performer"; break;
	}
	echo '<img src="./icons/mnu_arr.gif" border="0">'; // 0.3.3: "missing" mnu_arrow
	echo xlate('Jump to').': ';
	$l='<a href="index.php?what='.$what.'&start=0&count='.$c.'&sorttbl='.$sorttbl.'&order_by='.$order_by.'&limit=';
	$n=65;
	while ($n<91) {
		echo $l.chr($n).'">'.chr($n).'</a> ';
		$n++;
		}	
}

// make special options: JUMP TO LETTER
function show_letters($what,$field) {
	if ($_SESSION['show_letters']=="1") {
		show_alphabet($what,$field,$_SESSION['count']);
	}
}

// display favorite lists (used in adm./selection of fav. lists):
function disp_favorite_lists($user,$opt) {
	$qry="SELECT DISTINCT fname FROM favorites WHERE fuser='".$user."' ORDER BY fname";
	$result=execute_sql($qry,0,1000000,$nr);
	std_table("");
	echo '<tr><td valign="top">';

	if ($nr>0) { // do we have one or more favorite lists:
		echo '<FORM name="fav_list" METHOD="POST" action="create_favoritelist.php">';
		if ($opt=="1") {
			echo xlate('Copy the queue to the favorite list').':';
		} else {
			echo xlate("Select a favorite list").':';
		}		
		if ($opt=="1") { // we're offering to COPY:
			echo '<input type="hidden" name="copy" value="1">'; 
		}	
		echo '<SELECT NAME="favoritelistname" class="tfield" ONCHANGE="Javascript:submit()">';
		echo '<OPTION VALUE="" selected>---</OPTION>';
		while ($row=mysql_fetch_array($result)) {
			echo '<OPTION VALUE="'.$row['fname'].'">'.$row['fname'].'</OPTION>';
		}
		echo '</SELECT></form>';	
	} 
	echo ' </td>';
	if ($opt!="1") { // we're offering to create a new favorite list:
		echo '<form name="c_form" method="POST" action="create_favoritelist.php">';
		echo '<td valign="top">'.xlate("Create new");
        echo ' :<input type="text" name="new_favlist" length="40" class="tfield"></form>';
	}	

	echo '</td></tr></table>';
}	

// update_stats, write_m3u and get_ablum_name are used in PLAY_ACTION.PHP & RANDOM.PHP:
function update_stats($idx) {
	// setup some stuff (ie. values for the two columns we're about to update):
	$now=date("U");
	$stat_qry="SELECT id, last_played, times_played FROM track WHERE id='".$idx."' LIMIT 1";
	$stat_res=execute_sql($stat_qry,0,-1,$nr);
	$stat_row=mysql_fetch_array($stat_res);
	$c=$stat_row['times_played'];
	$c++;
	// construct the update:
	$stat_qry="UPDATE track SET times_played='".$c."', last_played='".$now."' WHERE id='".$idx."' LIMIT 1";
	$stat_res=execute_sql($stat_qry,0,-1,$nr);
}	


function write_m3u($handle,$no,$duration,$name,$path) {
	if ($no==1) { 
		fwrite($handle, "#EXTM3U".chr(13).chr(10));
	}	
	fwrite($handle, "#EXTINF:$duration,$name".chr(13).chr(10));
	fwrite($handle, $path.chr(13).chr(10));
}	

function get_album_name($x) {
	$qry="SELECT aname FROM album WHERE aid=".$x;
	$result=execute_sql($qry,0,1,$nr);
	$row=mysql_fetch_array($result);
	if ($row['aname']!="") {
		return ' ['.$row['aname'].']';
	} else {
		return "";
	}		
}

function cpy_file($src,$dest,$tmp_dir) {
	if (!file_exists($tmp_dir.$dest)) {
		$e='cp "'.$src.'" "'.$tmp_dir.$dest.'"';
		exec($e);
	}		
}	

function set_name($pid,$n,$aid) { // pid=performer_id, n=name, aid=album_id.
// Basically determine what entries in the playlist should look like.
	$name=get_performer_name($pid).' - '; // performer name, 1st.
	$name.=$n; // track name, 2nd.
	$name.=get_album_name($aid); // album name in "[", 3rd.
	$name=str_replace(" ","_",$name); // Avoid the player gets "confused" regarding spaces...(it does with WinAmp)
	return $name;
}

function disp_language_options($default) { // displays language "picker" for various/installed languages found
// in the "./lang" directory.
// $default will - in most circumstances be $_SESSION['lang'].
    echo '<SELECT NAME="lang" class="tfield">';
    $handle=fopen("./lang/languages.txt", "r");
    while (!feof($handle)) {
        $line=fgets($handle);
        $item=explode(";", $line);
        if (count($item)==2) {
            echo '<OPTION VALUE="'.$item[0].'"';
            if ($default==$item[0]) {
                echo ' selected';
            }
            echo '>'.$item[1].'</OPTION>';
        }
    }
    echo '</SELECT>';
    fclose($handle);
}
?>
