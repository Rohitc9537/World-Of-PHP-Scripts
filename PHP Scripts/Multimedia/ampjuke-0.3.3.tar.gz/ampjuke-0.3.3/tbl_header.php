<?
function tbl_header($what,$hl,$align,$s,$order_by,$dir,$newdir,$count,$special) {
	echo '<th align="'.$align.'">';
	echo '<a href="index.php?what='.$what.'&order_by=';
	echo $s.'&dir=';
	if ($order_by==$s) { echo $newdir; } else { echo $dir; }
	echo "&start=0&count=$count&$special";
	echo '">';
	if ($order_by==$s) { 
		$img="./icons/arrup.gif"; 
		if ($dir=="ASC") { $img="./icons/arrdown.gif"; }
		echo '<p><img src='.$img.' border=0>'.($hl).'</a>';
	} else { echo '<p>'.($hl).'</a>'; }
	echo '</th>';
} 
?>
