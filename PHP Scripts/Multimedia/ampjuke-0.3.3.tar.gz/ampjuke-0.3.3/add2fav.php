<?
session_start();
if (isset($_SESSION['login'])) {
	require("sql.php");

	function add_tr($id) {
		$qry="INSERT INTO favorites VALUES ('','".$_SESSION['login']."','".$_SESSION['favoritelistname']."',".$id.")";
		$res=execute_sql($qry,0,-1,$nr);
	}	
		
	parse_str($_SERVER["QUERY_STRING"]);
	
	if ($what=='track') {
		add_tr($id);
	}
	
	if ($what=='albumid') {
		$qry="SELECT id FROM track WHERE album_id=".$id;
		$result=execute_sql($qry,0,1000000,$nr);
		while ($row=mysql_fetch_array($result)) {
			add_tr($row['id']);
		}
	}	
	
	if ($what=='performerid') {
		$qry="SELECT id FROM track WHERE performer_id=".$id;
		$result=execute_sql($qry,0,100000,$nr);
		while ($row=mysql_fetch_array($result)) {
			add_tr($row['id']);
		}
	}		
	
	if ($what=='yearid') {
		$qry="SELECT id FROM track WHERE year=".$id;
		$result=execute_sql($qry,0,10000000,$nr);
		while ($row=mysql_fetch_array($result)) {
			add_tr($row['id']);
		}		
	}	
} 
echo '<script type="text/javascript" language="javascript">'; echo "history.go(-1);";
echo '</script>';  
?>
		
