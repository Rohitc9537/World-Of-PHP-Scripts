<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require_once("sql.php");
require_once("set_td_colors.php");
require_once("disp.php");
$qry="SELECT aid, aname, pid, pname FROM album, performer WHERE ((album.aperformer_id=performer.pid))";
if (isset($limit)) {
	if ($what=="search") {
		$qry.=' AND aname LIKE "%'.$limit.'%"';
	} else {
		$qry.=' AND aname LIKE "'.$limit.'%"';
	}		
}
if (($order_by!="") && ($sorttbl=="album")) {
	$qry.=" ORDER BY $order_by $dir ";
}

$tmpstart=$start;
$tmpsel=$pagesel;
if ($pagesel=="album") {
	$result=execute_sql($qry,$start,$count,$num_rows);
} else {
	$result=execute_sql($qry,0,$count,$num_rows);
	$start=0;
	$pagesel="album";
}

$l="";
if ($limit=="") { $l.=xlate('All'); }
if ($what=="search") { $l="</i>&nbsp[".xlate("Albums")."]"; }
headline($what,'',$limit.$l.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>'); 
echo '<td>';

if ($what!="search" && $_SESSION['show_letters']=="1") {
	show_letters("album","album.aname");
}
//	
echo '</td></tr></table>';

if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require_once("tbl_header.php");
if ($_SESSION['show_ids']=="1") {
	tbl_header($what,xlate("ID"),"left","album.aid",$order_by,$dir,$newdir,
	$count,'limit='.$limit.'&sorttbl=album&pagesel='.$pagesel);
}	
tbl_header($what,xlate("Album"),"left","album.aname",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=album&pagesel='.$pagesel);

tbl_header($what,xlate("Performer"),"left","performer.pname",$order_by,$dir,$newdir,
$count,'limit='.$limit.'&sorttbl=album&pagesel='.$pagesel);


while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	if ($_SESSION['show_ids']=="1") {
		echo '<td>';
		if ($_SESSION['admin']=="1") {
			echo '<a href="index.php?what=edit&edit=album&id='.$row['aid'].'">'.$row['aid'].'</a>';
		} else {	
			echo $row['aid'];
		}
		echo '</td>';	
	}	
	add_album_link($row['aname'],$row['aid']);
	add_performer_link($row['pname'],$row['pid']);
	print "</tr> \n";
}
echo '</table>';	

if ($what=="search") {
	$within="albums";
	$sorttbl="album"; 
}	
require("page_numbers.php");
$start=$tmpstart;
$pagesel=$tmpsel;
?>
