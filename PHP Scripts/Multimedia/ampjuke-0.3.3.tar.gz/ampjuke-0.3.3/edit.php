<?
if (!isset($_SESSION['login']) && ($_SESSION['admin']!="1")) {
	header("Location: login.php");
	exit;
}

require("sql.php");
require("disp.php");

//
// WRITING SUBMITTED FORM VALUES:
//
if (isset($act) && ($act=="write")) { // we're storing data...find out what should be written:
	if ($_POST['writewhat']=="track") { // ...it's a track:
		$qry="UPDATE track SET name='".addslashes($_POST['name'])."', ";
		$qry.="performer_id='".$_POST['performer_id']."', ";
		$qry.="album_id='".$_POST['album_id']."', ";
		$qry.="year='".$_POST['year']."', ";
		$qry.="path='".addslashes($_POST['path'])."' ";
		$qry.="WHERE id='".$id."' LIMIT 1";
	}
	if ($_POST['writewhat']=="performer") { // ...it's a performer:
		if ($_POST['performer_id']!="0") { // we want to transfer the tracks from this performer to somebody else:
			$qry="UPDATE track SET performer_id='".$_POST['performer_id']."' ";
			$qry.="WHERE performer_id='".$id."'";
		} else { // we're just renaming the fucker:
			$qry="UPDATE performer SET pname='".addslashes($_POST['pname'])."' WHERE pid='".$id."' LIMIT 1";
		}
	}
	if ($_POST['writewhat']=="album") { // ...it's an album:
		if ($_POST['album_id']!="0") { // we want to transfer all tracks on this album to a different album:
			$qry="UPDATE track SET album_id='".$_POST['album_id']."' ";
			$qry.="WHERE album_id='".$id."'";
		} else { // we're just renaming the fucker:
			$qry="UPDATE album SET aname='".addslashes($_POST['aname'])."' ";
			$qry.="WHERE aid='".$id."' LIMIT 1";
		}
	}
	if ($_POST['writewhat']=="favorite") { // ...it's a favorite list:
		$qry="UPDATE favorites SET fname='".addslashes($_POST['favoritelistname'])."' ";
		$qry.=" WHERE fname='".addslashes($id)."' AND fuser='".$_SESSION['login']."'";
	}
	$result=execute_sql($qry,0,-1,$nr);
	echo '<script type="text/javascript" language="javascript">'; echo "history.go(-2);";
	echo '</script>';  
}		

//
//			FUNCTIONS USED FOR EDITING:
//
function disp_performer_selection($default) {
	$pqry="SELECT * FROM performer ORDER BY pname";
	$presult=execute_sql($pqry,0,10000000,$nr);
	echo '<SELECT NAME="performer_id" class="tfield">';
	echo '<OPTION VALUE="0"';
	if ($default=="0") {
		echo ' selected';
	}
	echo '>[Do not transfer]</OPTION>';	
	while ($prow=mysql_fetch_array($presult)) {
		echo '<OPTION VALUE="'.$prow['pid'].'"';
		if ($prow['pid']==$default) {
			echo ' selected';
		}
		echo '>'.$prow['pname'].'</OPTION>';
	}
	echo '</SELECT>';
}	

function disp_album_selection($default) {
	$pqry="SELECT * FROM album";
	$presult=execute_sql($pqry,0,10000000,$nr);
	echo '<SELECT NAME="album_id" class="tfield">';
	echo '<OPTION VALUE="0"';
	if ($default=="0") {
		echo ' selected';
	}
	echo '>[Do not transfer]</OPTION>';	
	while ($prow=mysql_fetch_array($presult)) {
		echo '<OPTION VALUE="'.$prow['aid'].'"';
		if ($prow['aid']==$default) {
			echo ' selected';
		}
		echo '>'.$prow['aname'].'</OPTION>';
	}
	echo '</SELECT>';
}	
		

// Editing:
if ($edit=="track") {
	$qry="SELECT * FROM track WHERE id='".$id."' LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
}
if ($edit=="performer") {
	$qry="SELECT * FROM performer WHERE pid='".$id."' LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
}		
if ($edit=="album") {
	$qry="SELECT * FROM album WHERE aid='".$id."' LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
}	
if ($edit=="favorite") {
	$qry="SELECT * FROM favorites WHERE fname='".$id."' AND fuser='".$_SESSION['login']."' LIMIT 1";
	$result=execute_sql($qry,0,-1,$nr);
	$row=mysql_fetch_array($result);
}	
// Form setup:
headline("","Edit data","");

std_table("");
echo '<FORM NAME="edit" method="POST" action="index.php?what=edit&act=write&id='.$id.'">';
echo '<tr><td>ID:</td>';
echo '<td>'.$id;
echo '</td></tr>';
echo '<tr><td>';

if ($edit=="track") { // we're editing a single TRACK:
	echo 'Track name:</td>';
	echo '<input type="hidden" name="writewhat" value="track">';
	echo '<td><input type="text" class="tfield" name="name" value="'.$row['name'].'" size="80">';
	echo '</td></tr>';
	echo '<tr><td>Performer:</td><td>';
	disp_performer_selection($row['performer_id']);
	echo '</td></tr>';
	echo '<tr><td>Album:</td><td>';
	disp_album_selection($row['album_id']);
	echo '</td></tr>';
	echo '<tr><td>Year:</td>';
	echo '<td><input name="year" type="text" class="tfield" value="'.$row['year'].'">';
	echo '</td></tr>';
	echo '<tr><td>Path:</td>';
	echo '<td><input name="path" type="text" class="tfield" value="'.$row['path'].'" size="100">';
	echo '</td></tr>';
	// used in DELETE below:
	$del_btn=$row['name']; 
	$del_warn="you will be DELETING this track";
	$what="track";
}
if ($edit=="performer") { // we're editing the name of a PERFORMER:
	echo 'Performer name:</td>';
	echo '<input type="hidden" name="writewhat" value="performer">';	
	echo '<td><input type="text" class="tfield" name="pname" value="'.$row['pname'].'" size="100">';
	echo '</td></tr>';
	echo '<tr><td>Transfer all tracks with this performer to another performer:</td>';
	echo '<td>';
	disp_performer_selection("0");
	echo '</td></tr>';
	// used in DELETE below:
	$del_btn=$row['pname']; 
	$del_warn="you will be DELETING <b>all</b> tracks with this performer as well as <b>all albums</b>';
    echo ' where this performer is the only performer";
	$what="performerid";
}
if ($edit=="album") {
	echo 'Album name:</td>';
	echo '<input type="hidden" name="writewhat" value="album">';	
	echo '<td><input type="text" class="tfield" name="aname" value="'.$row['aname'].'" size="100">';
	echo '</td></tr>';
	echo '<tr><td>Transfer all tracks from this album to another album:</td>';
	echo '<td>';
	disp_album_selection("0");
	echo '</td></tr>';
	// used in DELETE below:
	$del_btn=$row['aname'];	
	$del_warn="you will be DELETING this album";
	$what="albumid";
}		
if ($edit=="favorite") {
	echo 'Favorite list name:</td>';
	echo '<input type="hidden" name="writewhat" value="favorite">';	
	echo '<td><input type="text" class="tfield" name="favoritelistname" value="'.$row['fname'].'" size="100">';
	echo '</td></tr>';
	$del_btn=$row['fname'];
	$del_warn="you will be DELETING this favorite list";
	$what="favorite";
}

echo '<tr><td colspan="5"><hr ALIGN="CENTER" color="#abcdef"></td></tr>';
// 0.3.2: Translate the submit button's text:
echo '<tr><td colspan="5" align="center"><input type="submit" class="tfield" value="'.xlate("Save & continue").'"';
echo ' name="submit"></td></tr>';
echo '<tr><td colspan="5"><hr ALIGN="CENTER" color="#abcdef"></td></tr>';
$btn="Delete ".$del_btn;
echo '<tr><td colspan="5" align="center">';
echo '<p class="note">Warning, if you click on the link below, '.$del_warn.'.<br>Only data in the';
echo ' <b>database</b> will be deleted. Not the physical music-file(s)';
echo '<br><a href="delete.php?what='.$what.'&id='.$id.'&jsb=3">';
// 0.3.3: "missing translation":
echo '<img src="./icons/mnu_arr.gif" border="0"> '.xlate("Delete").' '.$del_btn.'</a><br>';
echo '</td></tr>';
echo '</FORM></table>';


?>	
