<?
if (!isset($_SESSION['login'])) {
    header("login.php");
    exit;
}

require("sql.php");
require("set_td_colors.php");
require("disp.php");

$qry="SELECT * FROM favorites WHERE fuser='".$_SESSION['login']."'";
$qry.=" AND fname='".$special."' AND track_id>'0' ORDER BY fid";
$result=execute_sql($qry,$start,$count,$num_rows);

headline($what,$special,$special);
// special options: delete playlist
std_table("");
echo '<tr><td>';
echo '<a href="play_action.php?act=playall&what=favoriteid&id='.$special.'">';
echo '<img src="./icons/mnu_arr.gif" border="0">'.xlate($playtext.' all tracks from');
echo ' <b>'.$special.'</b></a>&nbsp&nbsp';
// 0.3.2: Remove duplicates
echo '<a href="delete.php?what=duplicates_favorite&id='.$special.'"><img src="./icons/mnu_arr.gif" border="0">';
echo xlate('Remove duplicate entries').':<b>'.$special.'</b></a>';
//
echo '</td></tr></table>';

require("tbl_header.php");
std_table("");
echo '<th align="left"><p>'.xlate("Performer").'</th>';
echo '<th align="left"><p>'.xlate("Title").'</th>';
echo '<th align="left"><p>'.xlate("Album").'</th>';
echo '<th align="left"><p>'.xlate("Year").'</th>';
echo '<th align="left">'.xlate("Duration").'</th>';
if ($_SESSION['disp_last_played']=="1") {
	echo '<th align="right">'.xlate("Last played").'</th>';
}
if ($_SESSION['disp_times_played']=="1") {
	echo '<th align="right">'.xlate("Played").'</th>';
}
echo '<th> </th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	
	$qry2="SELECT id,performer_id,album_id,name,year, duration, last_played, times_played FROM track WHERE id=".$row['track_id'];
	$result2=execute_sql($qry2,0,1,$nr);
	$row2=mysql_fetch_array($result2);
	$perf=get_performer_name($row2['performer_id']);
	add_performer_link($perf,$row2['performer_id']);
	add_play_link("play",$row2['id'],$row2['name']);
	
	// This is getting complicated....
	$qry3="SELECT * FROM album WHERE aperformer_id=".$row2['performer_id'];
	$qry3.=" AND aid=".$row2['album_id'];
	$result3=execute_sql($qry3,0,1,$nr);
	$row3=mysql_fetch_array($result3);
	add_album_link($row3['aname'],$row3['aid']);	

	add_year_link($row2['year'],$row2['year']);

	echo '<td>'.$row2['duration'].'</td>';

	if ($_SESSION['disp_last_played']=="1") {
		echo '<td align="right">'.mydate($row2['last_played']).'</td>';
	}
	if ($_SESSION['disp_times_played']=="1") {
		echo '<td align="right">'.$row2['times_played'].'</td>';
	}		

	echo '<td align="right"><a href="delete.php?what=favoriteid&id='.$row['fid'].'">';
	echo '['.xlate("Delete").']</a></td>';

	echo '</tr>';
}		

require("page_numbers.php");
?>