<?
session_start();
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}
	
parse_str($_SERVER["QUERY_STRING"]);
/*
if ($what=="album") {
	if ($set=="0" || $set=="1") {
		$_SESSION['disp_perf_albums_on']=$set;
	}
}

if ($what=="track") {
	if ($set=="0" || $set=="1") {
		$_SESSION['disp_perf_track_on']=$set;
	}
}

if ($what=="letter") {
	if ($set=="0" || $set=="1") {
		$_SESSION['show_letters']=$set;
	}
}
	
if ($what=="ids") {
	if ($set=="0" || $set=="1") {
		$_SESSION['show_ids']=$set;
	}
}
*/

// 0.3.3:
if ($what=="filter_tracks") {
    $_SESSION['filter_tracks']=$set;
    $_SESSION['new_start']="0";
}
//
		
echo '<script type="text/javascript" language="javascript">'; echo "history.go(-1);";
echo '</script>';  
?>
		
