<?
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require("sql.php");
require("set_td_colors.php");
require("disp.php");

$qry='SELECT track.id, track.performer_id, track.album_id, track.track_no, track.name, ';
$qry.='track.duration, track.year, track.path, track.last_played, track.times_played, performer.pid, ';
$qry.='performer.pname, album.aid, album.aperformer_id FROM track,performer,album ';
$qry.="WHERE track.album_id='$special' AND album.aid='$special' AND ";
$qry.='performer.pid=album.aperformer_id ';
if ($order_by!='') {
	$qry.=" ORDER BY $order_by $dir ";
}		
$result=execute_sql($qry,$start,$count,$num_rows);

// do some SQL (headline)
$qry="SELECT * FROM album WHERE album.aid=".$special;
$header_result=execute_sql($qry,0,1,$nr);
$header_row=mysql_fetch_array($header_result);

headline($what,$header_row['aname'],'');
// make special options: play/enqueue all from current album.
$text='<img src="./icons/mnu_arr.gif" border="0">'.xlate($playtext.' all tracks from');
$text.=' <b>'.$header_row['aname'].'</b>';
std_table($tdalt);
echo '<tr><td>';
echo '<a href="play_action.php?act=playall&what=albumid&id='.$special.'">'.$text.'</a> ';
if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) {
	add2fav_link(xlate('Add album to favorite list').' <b>'.$_SESSION['favoritelistname'].'</b>','?what=albumid&id='.$special);
}	
echo '</td></tr></table>';
//


if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
std_table("");
require("tbl_header.php");
tbl_header("albumid","#","left","track.track_no",$order_by,$dir,$newdir,$count,'&special='.$special);
tbl_header("albumid",$d_performer,"left","performer.pname",$order_by,$dir,$newdir,$count,'&special='.$special);
tbl_header("albumid",xlate("Title"),"left","track.name",$order_by,$dir,$newdir,$count,'&special='.$special);
tbl_header("albumid",xlate("Duration"),"left","track.duration",$order_by,$dir,$newdir,$count,'&special='.$special);
tbl_header("albumid",xlate("Year"),"left","track.year",$order_by,$dir,$newdir,$count,'&special='.$special);
if ($_SESSION['disp_last_played']=="1") {
	tbl_header("albumid",xlate("Last played"),"right","track.last_played",$order_by,$dir,$newdir,$count,'&special='.$special);
}
if ($_SESSION['disp_times_played']=="1") {
	tbl_header("albumid",xlate("Played"),"right","track.times_played",$order_by,$dir,$newdir,$count,'&special='.$special);
}
echo '<th> </th>';
// 0.3.0:
$last_performer="";
$last_performer_ok=1;

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	
	echo '<td>'.$row['track_no'].'</td>';
	get_performer_name_track($row['performer_id'],$special,$perf_name,$perf_id);
	if (($perf_name!=$last_performer) && ($last_performer!="")) {
		$last_performer_ok=0;
	} else {
		if ($last_performer=="") {
			$last_performer=$perf_name;
		}
	}						
	add_performer_link($perf_name,$perf_id);
	add_play_link("play",$row['id'],$row['name']);
	echo '<td>'.$row['duration'].'</td>';
	add_year_link($row['year'],$row['year']);
	if ($_SESSION['disp_last_played']=="1") {
		echo '<td align="right">'.mydate($row['last_played']).'</td>';
	}
	if ($_SESSION['disp_times_played']=="1") {
		echo '<td align="right">'.$row['times_played'].'</td>';
	}		
	echo '<td align="right">';
	if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) {	// 0.2.4
		add2fav_link('','?what=track&id='.$row['id']);
	}	
	echo '</td>';
	
	print "</tr> \n";
}
echo '</table>';	

include("page_numbers.php");

// 0.3.0: Album art using Amazon Web Services (AWS)
// First, construct the 'amazon_string' (what to look for).
// It can either be on the format "Perfomer - Album Name.jpg" or just "Album Name.jpg".
$amazon_string="";
if ($last_performer_ok==1) {
	$amazon_string=$last_performer.' - ';
}	
$amazon_string.=$header_row['aname'];
// Second, check if the isn't there and we don't have an AWS-key:
if (!file_exists('./covers/'.$amazon_string.'.jpg')&& ($amazon_key!="")) {
	include("./amazon/amazon.php"); // if we don't have the cover, but we have a key: search for a cover
} else {
	echo '<table><tr><td align="center">';
	echo '<img src="./covers/'.$amazon_string.'.jpg" border="0">';
	echo '</td></tr>';
    // for admin's: offer options to clear/"blank" the cover displayed:
    if ($_SESSION['admin']=="1") {
        echo '<tr><td align="right">&nbsp<br>&nbsp<br><a href="delete.php?what=cover&id='.$amazon_string.'">';
        echo '<img src="./icons/mnu_arr.gif" border="0"">Delete this cover and look up a new cover</a>&nbsp&nbsp';
        echo '<a href="delete.php?what=cover&id='.$amazon_string.'&replace=true">';
        echo '<img src="./icons/mnu_arr.gif" border="0">Delete this cover and use a blank cover instead</a>';
        echo '</td></tr>';
    }
    echo '</table>';
}
?>
