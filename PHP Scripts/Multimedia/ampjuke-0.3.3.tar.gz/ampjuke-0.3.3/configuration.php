<?
/*
get_configuration()
Gets a configuration value from db.php:
*/
function get_configuration($item) {
	$item='$'.$item;
	$handle=fopen("./db.php", "r");
	$found=0;
	$ret="";
	while (!feof($handle)) {
		$buffer=fgets($handle, 8192);
		$i=0;
		while ($found==0 && $i<=strlen($buffer)) {
			$tmp=explode("=", $buffer);
			if (strlen($tmp[0])>1) {
				if ($tmp[0]==$item) {
					$ret=rtrim($tmp[1]);
					$ret=ltrim($ret);
					$ret=str_replace(";","",$ret);
					$ret=str_replace('"','',$ret);
					$found=1;
					$i=strlen($buffer);
				}
			}
			$i++;
		}		
	}
	fclose($handle);
	return $ret;
}	

?>
