<?
require("make_header.php");

if (!isset($id) || ($id=="")) {
	echo 'You must specify something to delete.';
} else {
	$qry="";
	require("sql.php");
	if ($what=="track") {
		$qry='DELETE FROM track WHERE id='.$id;
		$result=execute_sql($qry,0,-1,$nr);
	}	
	if ($what=="albumid") {
		$qry='DELETE FROM album WHERE aid='.$id;
		$result=execute_sql($qry,0,-1,$nr);
		$qry='DELETE FROM track WHERE album_id='.$id;
		$result=execute_sql($qry,0,-1,$nr);
	}
	if ($what=="performerid") {
		$qry='DELETE FROM performer WHERE pid='.$id;
		$result=execute_sql($qry,0,-1,$nr);
		$qry='DELETE FROM track WHERE performer_id='.$id;
		$result=execute_sql($qry,0,-1,$nr);
		$qry='DELETE FROM album WHERE aperformer_id='.$id;
		$result=execute_sql($qry,0,-1,$nr);
	}
	if ($what=="yearid") {
		$qry='DELETE FROM track WHERE year='.$id;
		$result=execute_sql($qry,0,-1,$nr);
	}	
	if ($what=="favoriteid") {
		$qry="DELETE FROM favorites WHERE fid=".$id;
		$qry.=" AND fuser='".$_SESSION['login']."'";
		$result=execute_sql($qry,0,-1,$nr);
	}
	if ($what=="favorite") {
		$qry="DELETE FROM favorites WHERE fname='".$id."'";
		$qry.=" AND fuser='".$_SESSION['login']."'";
		$result=execute_sql($qry,0,-1,$nr);
	}	
	if ($what=="queue") {
		$qry="DELETE FROM queue WHERE user_name='".$_SESSION['login']."'";
		$result=execute_sql($qry,0,-1,$nr);
	}
	if ($what=="queueid") {
		$qry="DELETE FROM queue WHERE user_name='".$_SESSION['login']."' AND qid=".$id;
		$result=execute_sql($qry,0,-1,$nr);
	}		
	if ($what=="cache") {
		require("db.php");
		$cmd="rm -f ".$music_tmp_dir."*";
		exec($cmd);
		// 0.2.5: Re-create the index.php file
		$handle=fopen($music_tmp_dir."index.php", "w");
		fwrite($handle, '<? header("Location: ../index.php?what=welcome"); ');
		fwrite($handle, '?');
		fwrite($handle, '>');
		fclose($handle);
	}		
    if ($what=="cover") {
        $cmd='rm -f ./covers/"'.$id.'.jpg"';
		exec($cmd);
		if (isset($replace)) {
            $cmd='cp ./covers/_blank.jpg ./covers/"'.$id.'.jpg"';
            exec($cmd);
        }
    }
    // 0.3.2: Remove Duplicates
    // Queue:
    if ($what=="duplicates_queue") {
        // Get user's tracks in the queue table:
        $qry="SELECT * FROM queue WHERE user_name='".$_SESSION['login']."'";
        $result=execute_sql($qry,0,-1,$nr);
        // Delete user's tracks from the queue table:
		$qry="DELETE FROM queue WHERE user_name='".$_SESSION['login']."'";
		$r=execute_sql($qry,0,-1,$nr);
        // Trim it:
        $n=0;
        while ($row=mysql_fetch_array($result)) {
            $input[$n]=$row['track_id'];
            $n++;
        }
        $new=array_unique($input);
        // Put the trimmed array back into the queue table:
        $n=0;
        while ($n<=count($new)-1) {
            $qry="INSERT INTO queue (user_name, track_id) ";
            $qry.="VALUES ('".$_SESSION['login']."', ".$new[$n].")";
            $res=execute_sql($qry,0,-1,$nr);
            $n++;
        }
     }
     // Favorite:
     if ($what=="duplicates_favorite") {
        $qry="SELECT * FROM favorites WHERE fuser='".$_SESSION['login']."'";
        $qry.=" AND fname='".$id."' AND fid>0";
        $result=execute_sql($qry,0,-1,$nr);

		$qry="DELETE FROM favorites WHERE fname='".$id."'";
		$qry.=" AND fuser='".$_SESSION['login']."' AND fid>0";
		$r=execute_sql($qry,0,-1,$nr);
        // Trim it:
        $n=0;
        while ($row=mysql_fetch_array($result)) {
            $input[$n]=$row['track_id'];
            $n++;
        }
        $new=array_unique($input);
        // Put the trimmed array back into the queue table:
        $n=0;
        while ($n<=count($new)-1) {
            $qry="INSERT INTO favorites (fuser, fname, track_id) ";
            $qry.="VALUES ('".$_SESSION['login']."', '".$id."', ".$new[$n].")";
            $res=execute_sql($qry,0,-1,$nr);
            $n++;
        }
     }


}

if (isset($jsb)) {
	echo '<script type="text/javascript" language="javascript">'; echo "history.go(-2);";
	echo '</script>';  
}	
echo '<script type="text/javascript" language="javascript">'; echo "history.go(-1);";
echo '</script>';  

?>
</body>
</html>
			
