<?
session_start();
$ok=0;
if (isset($_SESSION['login'])) { $ok++; }
if (isset($_SESSION['passwd'])) { $ok++; }
if (isset($_SESSION['lang'])) { $ok++; }
if ($ok!=3) { 
//require('get_configuration.php');
//$h=get_configuration('base_dir');
session_destroy();
header("Location: $base_http_prog_dir/login.php"); exit; }
?>
