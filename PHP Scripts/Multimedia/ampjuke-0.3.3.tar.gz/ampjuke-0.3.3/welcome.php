<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("disp.php");
require("set_td_colors.php");

std_table('');
echo '<tr><td align="center">';
echo '<img src="./icons/ampjuke176x62.jpg" border="0"></td>';
echo '<tr><td align="center">';
echo xlate("Welcome").': <b>'.$_SESSION['login'].'</b><br>';
echo xlate("Last login").': <b>'.$_SESSION['msg'].'</b><br>';
echo xlate("IP-address").': <b>'.$_SERVER['REMOTE_ADDR'].'</b><br>';
echo '</td></tr>';
echo '</table>';

// SQL, used later
$qry="SELECT aid FROM album";
$result=execute_sql($qry,0,1000000,$max_albums);
$qry="SELECT pid FROM performer";
$result=execute_sql($qry,0,1000000,$max_performers);
// 0.3.3: Get rid of that annoying "one too many number of performers":
$max_performers=$max_performers-1;
//
$qry="SELECT id FROM track";
$result=execute_sql($qry,0,1000000,$max_tracks);
$qry="SELECT id FROM user";
$result=execute_sql($qry,0,1000000,$max_users);

// facts:
std_table('');
echo '<th colspan="4" align="left"><p><img src="icons/mnu_arr.gif" border="0">AmpJuke '.xlate("facts").':</th>';
fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
echo '<td>'.xlate("Number of users").':<b>'.$max_users.'</b></td>';
echo '<td>'.xlate("Number of albums").':<b>'.$max_albums.'</b></td>';
echo '<td>'.xlate("Number of performers").':<b>'.$max_performers.'</b></td>';
echo '<td>'.xlate("Number of tracks").':<b>'.$max_tracks.'</b></td>';
echo '</tr></table>';

// latest 10...
// albums:
std_table('');
echo '<th colspan="2" align="left"><p><img src="icons/mnu_arr.gif" border="0">'.xlate("Latest 10 albums added");
echo ':</td>';
$qry="SELECT aid, aname, pid, pname FROM album, performer WHERE ((album.aperformer_id=performer.pid)) ORDER BY album.aid DESC";
$result=execute_sql($qry,0,10,$num_rows);
echo '<tr><td><b>'.$d_album.'</td><td><b>'.$d_performer.'</td></tr>';
while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	add_album_link($row['aname'],$row['aid']);
	add_performer_link($row['pname'],$row['pid']);
	print "</tr> \n";
}
echo '</td></tr></table>';
// performers:
std_table('');
echo '<th colspan="2" align="left"><p><img src="icons/mnu_arr.gif" border="0">'.xlate("Latest 10 performers added");
echo ':</th>';
$qry="SELECT pid, pname FROM performer WHERE pid>1 ORDER BY pid DESC";
$result=execute_sql($qry,0,10,$num_rows);
while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	add_performer_link($row['pname'],$row['pid']);
	print "</tr> \n";
}
echo '</table>';	

?>
