<?
// loginvalidate.php: validate login+password
// init.
session_start();
require("db.php");

$connection=mysql_connect($db_host,$db_user,$db_password) or die('Could not connect.');
mysql_select_db($db_name) or die('Could not select database !');

$user=$HTTP_POST_VARS['login'];
$pw=$HTTP_POST_VARS['password'];
// make request
$result=mysql_query("SELECT * FROM user WHERE name='$user' AND password='$pw'") or die('Could not select.');
$num_rows=mysql_num_rows($result);
$row=mysql_fetch_array($result);

if ($num_rows==1) { // then we know we have a winner, - setup some stuff for later use:
	// "static" settings (from the db):
	$_SESSION['login']=$user; // who is it we're dealing with ? (username)
	$_SESSION['lang']=$row['lang']; // language
	$_SESSION['passwd']=$row['password']; // 
	$_SESSION['count']=$row['count']; // items/pages
	$_SESSION['tdnorm']=$row['tdnorm']; // colors
	$_SESSION['tdalt']=$row['tdalt']; // colors
	$_SESSION['tdhighlight']=$row['tdhighlight']; // colors
	$_SESSION['bodycol']=$row['bodycol']; // colors
	$_SESSION['enqueue']=$row['enqueue']; // enqueue/play tracks (0|1)
	$_SESSION['disp_last_played']=$row['disp_last_played']; // show when tracks  was last played (0|1)
	$_SESSION['disp_times_played']=$row['disp_times_played']; // show how many times a track has been played (0|1)
	// "dynamic" settings (ie. not stored in the database...):
	$_SESSION['show_letters']="1"; // should maybe be in the $row[...]-stuff ?
	$_SESSION['show_ids']="1"; // should maybe be in the $row[..]-stuff ?
	$_SESSION['favoritelistname']=""; // the favoritelist we're working on
    $_SESSION['msg']=$row['last_login'];
	$_SESSION['admin']=$row['admin']; // is this an admin ? (0|1)
    $_SESSION['filter_tracks']="0"; // 0.3.3: 0=All; 1=Tracks w. Albums; 2=Tracks wo. albums
	exec("date +%d-%m-%Y",$d);
	exec("date +%T",$t);
	$now=$d[0].' '.$t[0];
	$qry="UPDATE user SET last_ip='".$_SERVER['REMOTE_ADDR']."', last_login='".$now."'";
	$qry.=" WHERE name='".$_SESSION['login']."'";
	require("sql.php");
	$result=execute_sql($qry,0,-1,$nr);
	header("Location: index.php?what=welcome");
} else { // wrong user/passwd, just redisplay login...
	header("Location: login.php");
}


?>
