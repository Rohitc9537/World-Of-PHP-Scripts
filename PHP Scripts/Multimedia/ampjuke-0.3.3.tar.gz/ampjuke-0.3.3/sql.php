<?php
/*
execute_sql:
The SQL "wrapper".
If $count=-1 there will not be returned any $num_rows
*/
function execute_sql($qry,$start,$count,&$num_rows) {
include('db.php');
$connection=mysql_connect($db_host,$db_user,$db_password) or die('SQL: Could not connect.');
mysql_select_db($db_name) or die('SQL: Could not select database !');
$result=mysql_query($qry);
if ($count!=-1) { // = we want to delete
	$num_rows=mysql_num_rows($result); 
	$qry.=" LIMIT $start,$count"; 
	$result=mysql_query($qry); 
}	
mysql_close();	
return $result;
}

?>
