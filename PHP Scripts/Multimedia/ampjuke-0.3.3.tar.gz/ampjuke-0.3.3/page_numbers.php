<?
// page numbers, ONLY possible AFTER SQL has been exec.:
/*
if ($what=="search") {
	echo '<table><tr><td align="center"><b>'.$num_rows.'</b> matches found searching for <b>'.$limit;
	echo '</b> within <b><i>'.$within.'</i></b>';
	echo '</td></tr></table>';
}	
*/
print '<table><tr>';
print '<td align="center">';
$ob=$order_by;
$total_pages=round($num_rows/$count);
$tp=$num_rows/$count;
if ($tp-$total_pages>0) { $total_pages++; }
$current_page=round($start/$count)+1;
$disp_pages=10;
$first_page=round($current_page-($disp_pages/2));
$last_page=round($current_page+($disp_pages/2));
if ($current_page>=$last_page) { $first_page=$current_page-$disp_pages; }
if ($current_page>=$first_page) { $last_page=$current_page+$disp_pages; }
if ($first_page<1) { $first_page=1; $last_page=$disp_pages; }
if ($last_page>$total_pages) { $last_page=$total_pages; }

$pref='<a href="index.php?what='.$what;
$pref.="&order_by=$ob&dir=$dir&sorttbl=$sorttbl&pagesel=$pagesel&special=$special";
$tp=$start-$count;
if ($tp<0) { $tp=0; }
$tn=$start+$count;
if ($tn>$num_rows) { $tn=$num_rows; }
$prev_link=$pref.'&start='.$tp.'&count='.$count.'&limit='.$limit;
$next_link=$pref.'&start='.$tn.'&count='.$count.'&limit='.$limit;

if ($current_page>1) { 
	echo $prev_link.'"><--</a>  ';
}
$tmp_page=$first_page;

while ($disp_pages>=0 && $tmp_page<=$total_pages) { //changed from $disp_pages>=-1 @ 23/07/05/MHI
	$tmp_start=($tmp_page*$count)-$count;
	if ($tmp_page<>$current_page) {
		echo $pref.'&start='.$tmp_start.'&count='.$count.'&limit='.$limit.'">'.$tmp_page.'</a> '; 
	} else { echo "<b> [$tmp_page] </b>"; }
	$disp_pages--; $tmp_page++;
	print "\n";
}

if ($current_page<$total_pages) { 
	echo $next_link.'">--></a>';
	if ($disp_pages==-1) { echo ' <i>('.$total_pages.' '.xlate("pages in total").')</i>';	} // changed from $disp_pages==-2 @ 23/07/05/MHI
} 

?>
</td></tr></table>
</body></html>
