<?
session_start();
$ok=0;
if (isset($_SESSION['login'])) { $ok++; }
if (isset($_SESSION['passwd'])) { $ok++; }
if ($ok!=2) { 
session_destroy();
header("Location: login.php"); 
exit; 
}
echo '<html><head>';
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//'.$_SESSION['lang'].'">';
// Set the appropriate Character Encoding based on what's in 'lang':
$enc="ISO-8859-1"; // "Western" - applies to most (all?) countries in western europe - this is default
echo '<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />';
echo '<link rel="stylesheet" type="text/css" href="./ampstyles.css">';

// VALIDATE/SET URL-parameters:
parse_str($_SERVER["QUERY_STRING"]);
if (!isset($start)) {
	$start=0;
}
if (!isset($count)) {
	$count=$_SESSION['count'];
}	
if (!isset($what)) {
	$what="welcome";
}		
if (!isset($order_by)) {
	$order_by="";
}	
if (!isset($dir)) {
	$dir="ASC";
}
if (!isset($special)) {
	$special="";
}
if (!isset($limit)) {
	$limit='';		
}
if (!isset($sorttbl)) {
	$sorttbl='';
}	
if (!isset($pagesel)) {
	$pagesel=session_id();
}	
// 0.3.3:
if (isset($filter_tracks)) { // we want to FILTER the tracks displayed
    $_SESSION['filter_tracks']=$filter_tracks;
}
$filter_tracks=$_SESSION['filter_tracks'];
if (isset($_SESSION['new_start'])) { // start somewhere else wo. regard to what the URL-parameter is:
    $start=$_SESSION['new_start']; // set 'start'...
    unset($_SESSION['new_start']); // ...just once, so we don't get stuck !
}
//

// used as "global" within scripts:
$playtext="Play";
if ($_SESSION['enqueue']=="1") { $playtext="Queue"; }
$tdnorm=$_SESSION['tdnorm'];
$tdalt=$_SESSION['tdalt'];
$tdhighlight=$_SESSION['tdhighlight'];
$version="0.3.3";
require("translate.php");
$d_track=xlate("Track"); 
$d_performer=xlate("Performer");
$d_album=xlate("Album");
$d_year=xlate("Year");
$d_favorites=xlate("Favorites");
$d_queue=xlate("Queue");
$d_random_play=xlate("Random play");
$d_settings=xlate("Settings");
$d_search=xlate("Search");
$d_logout=xlate("Logout");
$d_admins_options=xlate("Admin's options");
$d_scan_music=xlate("Scan music...");
$d_user_adm=xlate("User adm...");
$d_configuration=xlate("Configuration...");
$d_cache=xlate("Cache");
$d_clear_cache=xlate("Clear cache");
?>
<title>AmpJuke...and YOUR hits keep on coming</title>
</head>
<body>
<table border="1" cellspacing="0" cellpadding="0" rules="rows">
<tr>
<td valign="top" width="10%">
<br>
<a href="index.php?what=welcome">
<img src="./icons/ampjuke88x31.jpg" border="0"></a>
<br><br>&nbsp
<a href="index.php?what=track&start=0&dir=DESC&order_by=track.id&sorttbl=track">
<img src="./icons/mnu_arr.gif" border="0"><? echo $d_track ?></a>
<br><br>&nbsp
<a href="index.php?what=performer&start=0&dir=ASC&order_by=performer.pname&sorttbl=performer">
<img src="./icons/mnu_arr.gif" border="0"><? echo $d_performer ?></a> 
<br><br>&nbsp
<a href="index.php?what=album&start=0&dir=ASC&order_by=album.aname&sorttbl=album">
<img src="./icons/mnu_arr.gif" border="0"><? echo $d_album ?></a> 
<br><br>&nbsp
<a href="index.php?what=year&start=0&dir=DESC&order_by=track.year">
<img src="./icons/mnu_arr.gif" border="0"><? echo $d_year ?></a>
<br><br>&nbsp
<a href="index.php?what=favorite">
<img src="./icons/mnu_arr.gif" border="0" alt="Favorites" title="Favorites"><? echo $d_favorites ?></a>
<br><br>&nbsp
<a href="index.php?what=queue">
<img src="./icons/mnu_arr.gif" border="0" alt="Queue" title="Queue"><? echo $d_queue ?></a>
<br><br>&nbsp
<a href="index.php?what=random&act=setup">
<img src="./icons/mnu_arr.gif" border="0" alt="Random play" title="Random play"><? echo $d_random_play ?></a>
<br><br>&nbsp
<a href="index.php?what=settings">
<img src="./icons/mnu_arr.gif" border="0" alt="Settings" title="Settings"><? echo $d_settings ?></a>
<br>&nbsp
<form name="search" method="POST" action="index.php?what=search&start=0&dir=ASC&sorttbl=track&order_by=track.name">
&nbsp&nbsp<img src="./icons/mnu_arr.gif" border="0" alt="Search" title="Search"><? echo $d_search ?>:
<input type="text" class="tfield" size="15" name="search">
</form>
<br>&nbsp
<a href="logout.php">
<img src="./icons/mnu_arr.gif" border="0"><? echo $d_logout ?></a>
<br>
<?
/* Recursive example below. Not used due to users reported errors.
function dskspace($dir)
{
   $s = stat($dir);
   $space = $s["blocks"]*512;
   if (is_dir($dir))
   {
     $dh = opendir($dir);
     while (($file = readdir($dh)) !== false)
       if ($file != "." and $file != "..")
           $space += dskspace($dir."/".$file); 
     closedir($dh);
   }
	return $space;
} 
*/
function dskspace($dir,$max_hours) { // 0.3.0: Now includes automatically deletion of 'tmp' files:
	$space=0;
	$now=date("U");
	if (is_dir($dir)) {
		$dh=opendir($dir);
		while (($file=readdir($dh)) != false) {
			if ($file!="." && $file!=".." && $file!="index.php") {
				$space += filesize($dir.$file);
				if (filemtime($dir.$file)) {
                    $diff=$now-filemtime($dir."/".$file);
                    $diff=$diff/(60*60); // convert to hours
                    if ($diff>$max_hours) { // 0.3.0: remove file if it's too old
                		$cmd='rm -f "'.$dir.$file.'"';
                		exec($cmd);
                	}
                }
			}
		}
	}
	closedir($dh);
	return $space;
}				
include("db.php");
$space=dskspace($music_tmp_dir,$max_hours);

// admin's options:
if (($_SESSION['admin']=="1") && ($what=="welcome")) {
	echo '<br><br><div class="note">';
	echo $d_admins_options.":<br><br>";
	echo '<a href="scan.php?act=rescan"><img src="./icons/mnu_arr.gif" border="0"> '. $d_scan_music.'</a><br><br>';
	echo '<a href="index.php?what=users&act=disp"><img src="./icons/mnu_arr.gif" border="0"> ';
    echo $d_user_adm.'</a><br><br>';
	echo '<a href="scan.php?act=configure"><img src="./icons/mnu_arr.gif" border="0"> '.$d_configuration.'</a><br><br>';
//    $space=dskspace($music_tmp_dir,$max_hours);
    echo 'Cache:'.round($space/1048576,0).' MB.<br>'; // 1048576 = 1MB
    echo '<a href="delete.php?id=something&what=cache"><img src="./icons/mnu_arr.gif" border="0"> ';
    echo $d_clear_cache.'</a><br><br>';
} // if user=admin



echo '</td><td bgcolor="'.$_SESSION['bodycol'].'" valign="top">';
?>
