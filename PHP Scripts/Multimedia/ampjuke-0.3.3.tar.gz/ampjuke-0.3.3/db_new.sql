<?
$c_album="CREATE TABLE album (
  aid int(11) NOT NULL auto_increment,
  aperformer_id int(11) NOT NULL default '0',
  aname text NOT NULL,
  PRIMARY KEY  (aid),
  FULLTEXT KEY aname (aname)
)";

$c_favorites="CREATE TABLE favorites (
  fid bigint(20) NOT NULL auto_increment,
  fuser varchar(40) NOT NULL default '',
  fname varchar(40) NOT NULL default '',
  track_id int(11) NOT NULL default '0',
  PRIMARY KEY  (fid)
)";
 
$c_performer="CREATE TABLE performer (
  pid int(11) NOT NULL auto_increment,
  pname text NOT NULL,
  PRIMARY KEY  (pid),
  FULLTEXT KEY pname (pname)
)";
 
$c_queue="CREATE TABLE queue (
  qid bigint(20) NOT NULL auto_increment,
  user_name text NOT NULL,
  track_id bigint(20) NOT NULL default '0',
  PRIMARY KEY  (qid)
)"; 

$c_track="CREATE TABLE track (
  id int(11) NOT NULL auto_increment,
  performer_id int(11) default NULL,
  album_id int(11) default NULL,
  track_no smallint(6) default NULL,
  name text NOT NULL,
  duration varchar(6) default NULL,
  last_played varchar(20) default NULL,
  times_played int(11) NOT NULL default '0',
  year varchar(4) default NULL,
  path text,
  PRIMARY KEY  (id),
  FULLTEXT KEY name (name)
)";
 
$c_user="CREATE TABLE user (
  id int(11) NOT NULL auto_increment,
  name text NOT NULL,
  password text NOT NULL,
  last_login varchar(40) NOT NULL default '',
  last_ip varchar(40) NOT NULL default '',
  admin tinytext NOT NULL,
  lang char(2) NOT NULL default '',
  count mediumint(9) NOT NULL default '0',
  enqueue char(1) default '0',
  tdnorm varchar(7) NOT NULL default '#cfcfcf',
  tdalt varchar(7) NOT NULL default '#dfdfdf',
  tdhighlight varchar(7) NOT NULL default '#abcdef',
  bodycol varchar(7) NOT NULL default '#fafafa',
  disp_last_played char(1) default '1',
  disp_times_played char(1) default '1',
  PRIMARY KEY  (id)
)";
?>
