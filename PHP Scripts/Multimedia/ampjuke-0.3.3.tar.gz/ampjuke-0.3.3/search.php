<? // 0.3.3: This code was rewritten in order to avoid the "famous" POST-warning in the browser
if ($limit=="") {
  	if (isset($_POST['search'])) {
		$limit=$_POST['search'];
		$_SESSION['last_search']=$_POST['search'];
	} else {	
		$limit=$_SESSION['last_search'];
	}	
	require("configuration.php");
	require("db.php");
    $loc=$base_http_prog_dir.'/index.php?what=search&start=0&dir=ASC&sorttbl=track&order_by=track.name&limit='.$limit;
    header("Location: $loc");
} else {
    require("disp_track.php");

echo '<br>';

    require("disp_performer.php");

echo '<br>';

    require("disp_album.php");
}
?>
