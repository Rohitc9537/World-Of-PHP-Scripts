<?
/*
function write_playlist_entry($no,$handle,$name,$title,$duration,$tmpdir) {
	fwrite($handle, "File$no=$tmpdir".$name.chr(13).chr(10));
	fwrite($handle, "Title$no=$title".chr(13).chr(10));
	fwrite($handle, "Length$no=$duration".chr(13).chr(10));
}	
*/

function js_back($x) {
	echo '<script type="text/javascript" language="javascript">'; echo "history.go(-1);";
	echo '</script>';  
}

session_start();

// play_action.php: NEW version !
parse_str($_SERVER["QUERY_STRING"]);
require("disp.php");
require("db.php");
require("sql.php");
$user=$_SESSION['login']; // name of playlist incl. secs. since 01-01-1970


if ($act=="play") { // we just want to play/enqueue ONE track RIGHT now:
	$qry="SELECT * FROM track WHERE id=".$id;
	$result=execute_sql($qry,0,1,$nr);
	$row=mysql_fetch_array($result);
	if ($_SESSION['enqueue']=="0") { // play the stuff right away:
		$file=$row['path'];
		$name=set_name($row['performer_id'],$row['name'],$row['album_id']);
		cpy_file($file,$name,$music_tmp_dir);
		$handle=fopen("./tmp/".$user.".m3u", "w");
		$item=split(":",$row['duration']);
		$s=$item[1] + ($item[0]*60);
		write_m3u($handle,1,$s,$name,$base_http_prog_dir.'/tmp/'.$name);
		fclose($handle);
		update_stats($id);
		$loc=$base_http_prog_dir."/tmp/".$user.".m3u?id=".date("U"); // date-stuff is included in order to prevent caching-"tihngies" to just repeat previous/current playlist
		header("Location: $loc");
	} else { // enqueue is NOT=0 -> place them in the queue:
		$qry="INSERT INTO queue VALUES ('','".$_SESSION['login']."',".$row['id'].")";
		$result=execute_sql($qry,0,-1,$nr);
		js_back(1);
	}			
}	


if ($act=="playall") { // we want to play "all" of something
	$number=1;
	$handle=fopen("./tmp/".$user.".m3u", "w");
	if ($what=="albumid") {
		$qry="SELECT * FROM track WHERE album_id=".$id." ORDER BY track_no ASC";
	}	
	if ($what=="performerid") {
		$qry="SELECT * FROM track WHERE performer_id=".$id;
	}	
	if ($what=="yearid") {
		$qry="SELECT * FROM track WHERE year=".$id;
	}
					
	if ($what=="albumid" || $what=="performerid" || $what=="yearid") {
		$result=execute_sql($qry,0,1000000,$nr);
		while ($row=mysql_fetch_array($result)) {
			if ($_SESSION['enqueue']==0) { // play tracks right away:
				$file=$row["path"];
				$name=set_name($row['performer_id'],$row['name'],$row['album_id']);
				cpy_file($file,$name,$music_tmp_dir);
				$item=split(":",$row['duration']);
				$s=$item[1] + ($item[0]*60);
				write_m3u($handle,1,$s,$name,$base_http_prog_dir.'/tmp/'.$name);
				update_stats($row['id']);
				$number++;
			} else { // "enqueue" is NOT 0 -> put them in the queue:
				$qry2="INSERT INTO queue VALUES ('','".$_SESSION['login']."',".$row['id'].")";
				$result2=execute_sql($qry2,0,-1,$nr);
			}	
		}
	} // albumid || performerid || yearid

	if ($what=="favoriteid" || $what=="queue") {
		if ($what=="favoriteid") {
			$qry2="SELECT * FROM favorites WHERE fname='".$id."' AND fuser='".$_SESSION['login']."'";  
		}			
		if ($what=="queue") {
			$qry2="SELECT * FROM queue WHERE user_name='".$_SESSION['login']."' ORDER BY qid";
		}
		$result2=execute_sql($qry2,0,1000000,$nr);
		while ($row2=mysql_fetch_array($result2)) {
			if ($_SESSION['enqueue']=="0" || $what=="queue") { // play tracks right away. The queue can only be played, not queued (...):
				$qry="SELECT id,path,album_id,performer_id,name,duration FROM track WHERE id=".$row2['track_id'];
				$result=execute_sql($qry,0,1,$nr);
				$row=mysql_fetch_array($result);
				$file=$row["path"];
				$name=set_name($row['performer_id'],$row['name'],$row['album_id']);
				cpy_file($file,$name,$music_tmp_dir);
				$item=split(":",$row['duration']);
				$s=$item[1] + ($item[0]*60);
				write_m3u($handle,1,$s,$name,$base_http_prog_dir.'/tmp/'.$name);
				update_stats($row['id']);
				$number++;
			} else { // enqueue is NOT=0 -> put 'em in the queue:	
				$qry3="INSERT INTO queue VALUES ('','".$_SESSION['login']."',".$row2['track_id'].")";
				$result3=execute_sql($qry3,0,-1,$nr);
			}
		}
	} // favoriteid || queue

	if ($_SESSION['enqueue']=="0" || $what=="queue") { // yes: send the .m3u file right away:	
		$number--;
		fclose($handle);
		$loc=$base_http_prog_dir."/tmp/".$user.".m3u?id=".date("U"); // date-stuff is included in order to prevent caching-"tihngies" to just repeat previous playlist
		header("Location: $loc");
	} else { // no: we're just putting stuff in the q., step back:
		js_back(1);
	}		

} // playall	

/*
if ($act=="switch") { // we want to switch some option of some kind...currently only one...
	if ($what=="enqueue") { // switch play/queue option:
		$val="0";
		if ($_SESSION['enqueue']=="0") { $val="1"; }
		$_SESSION['enqueue']=$val;
		$qry="UPDATE user SET enqueue='".$val."' WHERE name='".$_SESSION['login']."' LIMIT 1";
		$result=execute_sql($qry,0,-1,$nr);
	}
	js_back(1);
}		
*/
?>
