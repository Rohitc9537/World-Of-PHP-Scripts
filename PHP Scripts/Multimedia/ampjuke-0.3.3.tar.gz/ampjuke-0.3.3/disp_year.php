<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("disp.php");
require("set_td_colors.php");
$qry="SELECT DISTINCT year FROM track";
if ($order_by!="") {
	$qry.=" ORDER BY $order_by $dir ";
}	
$result=execute_sql($qry,$start,$count,$num_rows);

$l="";
if ($limit=="") { $l.=xlate('All'); }
headline($what,'',$limit.$l.'</i> <br>'.xlate("Matches").':<i>'.$num_rows.'</i>'); 
if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
require("tbl_header.php");
echo '</table>';
std_table('');
tbl_header("year",xlate("Year"),"left","track.year",$order_by,$dir,$newdir,$count,'');
echo '<th align="right"><p>'.xlate("Tracks").'</th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	echo '<td><a href="index.php?what=yearid&start=0&order_by=track.year&special='.$row['year'].'&limit=">'.$row['year'].'</td>';
	$qry2="SELECT id FROM track WHERE year='".$row['year']."'";
	$result2=execute_sql($qry2,0,1000000,$nrows2);
	$row2=mysql_fetch_array($result2);
	$nrows2=mysql_num_rows($result2);
	echo '<td align="right">'.$nrows2.'</td>';
	print "</tr> \n";
}
echo '</table>';	

require("page_numbers.php");
?>
