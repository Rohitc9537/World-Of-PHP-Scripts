README.TXT for AmpJuke.

Are you looking for...

...licence: Check licence.txt found in the download.

...detailed installation/upgrade example: Check http://www.ampjuke.org/download.php

...FAQ's: Check http://www.ampjuke.org/faq.php

...your language: Check http://www.ampjuke.org/translate/

...quick&dirty INSTALLATION: Read on below :-)

README.TXT for AmpJuke.

Are you looking for...

...licence: Check licence.txt found in the download.

...detailed installation/upgrade example: Check http://www.ampjuke.org/download.php

...FAQ's: Check http://www.ampjuke.org/faq.php

...your language: Check http://www.ampjuke.org/translate/

...quick&dirty INSTALLATION: Read on below :-)

1. Download AmpJuke.

2. Extract the files in the .gz-file and possibly FTP the contents to your webserver.

3. Within the directory where ampjuke is, change permissions as follows:
chmod 777 tmp
chmod 777 db*.*
chmod 777 covers
It is also recommended that you change permissions on the directory where AmpJuke is installed.
If AmpJuke is installed in /usr/local/apache2/htdocs/ampjuke then you 
should CHMOD 777 /usr/local/apache2/htdocs/ampjuke.

4. Open a browser and point it to: http://your-server/ampjuke-directory/install.php

5. Follow the onscreen instructions by entering the fields in the form.
Hints/tips:
- If it is the first time you're installing AmpJuke, check the boxes: "Create en empty database" and 
"Create empty tables within the database".

- The "Directory to place music temporarily" must be accessible from your browser, but 
the actual value should be the absolute path on the server.
An example: Your Apache's configuration has "Doc_root" set to "/var/www" and you installed AmpJuke in "/var/www/ampjuke".
The "correct" value for "Directory to place music temporarily" would then be: /var/www/ampjuke/tmp/ ...remember the last slash :)

- The "Base" directory is where your music actually is found (absolute path, no trailing slash).

- The "HTTP-Location" is (with the prvious example in mind): http://your-server/ampjuke 
...once all is completed, click "Save & continue".

6. A confirmation is displayed together with steps needed in order to import your music files. 
Follow these steps to finish the installation & start selection of and listening to your music. 
Important: There is an option to ANALYZE your data. 
It should only be done AFTER you have something in the database.

If you encounter any problems in relation to this, please check the FAQ-section (http://www.ampjuke.org/faq.php)
Good luck using AmpJuke !
