<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	

require("sql.php");
require("set_td_colors.php");
require("disp.php");

$qry="SELECT * FROM queue WHERE user_name='".$_SESSION['login']."' AND track_id>'0'";
$qry.=" ORDER BY qid";
$result=execute_sql($qry,$start,$count,$num_rows);

headline($what,'The Queue','');
// special options: delete playlist
std_table($tdalt);
echo '<tr><td>';
if ($num_rows>0) { // we have something in the queue, - display the options:
	echo '<a href="play_action.php?act=playall&what=queue">';
	echo '<img src="./icons/mnu_arr.gif" border="0">'.xlate("Play all tracks from").' '.xlate("The queue").'</a>&nbsp&nbsp';
	echo '<a href="delete.php?what=queue&id='.session_id().'">';
	echo '<img src="./icons/mnu_arr.gif" border="0">'.xlate("Delete").' '.xlate("The queue").'</a>&nbsp&nbsp';
	// 0.3.2: Offer to remove duplicates
    echo '<a href="delete.php?what=duplicates_queue&id='.session_id().'"><img src="./icons/mnu_arr.gif" border="0">';
    echo xlate('Remove duplicate entries').'</a>';
    //

	
} else { // we don not have anything in the queue...
	echo xlate('There are no tracks in the queue').'.';
}		
echo '</td></tr></table>';

require("tbl_header.php");
std_table("");
echo '<th align="left"><p>'.xlate("Performer").'</th>';
echo '<th align="left"><p>'.xlate("Title").'</th>'; // 0.3.2: Previously: "Name"
echo '<th align="left"><p>'.xlate("Album").'</th>';
echo '<th align="left"><p>'.xlate("Year").'</th>';
if ($_SESSION['disp_last_played']=="1") {
	echo '<th align="right">'.xlate("Last played").'</th>';
}
if ($_SESSION['disp_times_played']=="1") {
	echo '<th align="right">'.xlate("Played").'</th>';
}

echo '<th> </th>';

while ($row=mysql_fetch_array($result)) {
	fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
	
	$qry2="SELECT id,performer_id,album_id,name, year, duration, last_played,";
    $qry2.=" times_played FROM track WHERE id=".$row['track_id'];
	$result2=execute_sql($qry2,0,1,$nr);
	$row2=mysql_fetch_array($result2);
	$perf=get_performer_name($row2['performer_id']);
	add_performer_link($perf,$row2['performer_id']);
	echo '<td>'.$row2['name'].'</td>';	
	// get the name of the album:
	$qry3="SELECT * FROM album WHERE aid=".$row2['album_id']." LIMIT 1";
	$result3=execute_sql($qry3,0,-1,$nr);
	$row3=mysql_fetch_array($result3);
	add_album_link($row3['aname'],$row3['aid']);	

	add_year_link($row2['year'],$row2['year']);

	if ($_SESSION['disp_last_played']=="1") {
		echo '<td align="right">'.mydate($row2['last_played']).'</td>';
	}
	if ($_SESSION['disp_times_played']=="1") {
		echo '<td align="right">'.$row2['times_played'].'</td>';
	}		

	echo '<td align="right"><a href="delete.php?what=queueid&id='.$row['qid'].'">';
	echo '['.xlate("Delete").']</td>';

	echo '</tr>';
}		

// Move/copy option:
if ($num_rows>0) {
	disp_favorite_lists($_SESSION['login'],'1');
}

require("page_numbers.php");
?>