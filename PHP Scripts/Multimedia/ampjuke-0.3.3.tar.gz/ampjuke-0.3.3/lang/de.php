<?
// German Language file for Ampjuke
// Add to lang/language.txt:
// DE;Deutch
// Version: 1.0 Date: 20-Oct-2005
// by Joachm Werner, http://www.diggin-data.de
		switch ($key) {
			case "Track": $ret="Song"; break;
			case "Tracks": $ret="St�cke"; break;
			case "Performer": $ret="K�nstler"; break;
			case "Performers": $ret="K�nstler"; break;
			case "Album": $ret="Album"; break;
			case "Albums": $ret="Alben"; break;
			case "Year": $ret="Jahr"; break;
			case "Favorites": $ret="Favoriten"; break;
			case "Favorite list": $ret="Favoriten-Liste"; break;
			case "Queue": $ret="Abspiel-Liste"; break;
			case "The queue": $ret="Abspiel-Liste"; break;
			case "Random play": $ret="Zufallsmodus"; break;
			case "Settings": $ret="Einstellungen"; break;
			case "Search": $ret="Suche"; break;
			case "Logout": $ret="Abmelden"; break;
			case "Admin's options": $ret="Admin-Einstellungen"; break;
			case "Scan music..."; $ret="Musik scannen..."; break;
			case "User adm..."; $ret="Benutzer-Verwaltung..."; break;
			case "Configuration..."; $ret="Konfiguration..."; break;
			case "Clear cache": $ret="Cache leeren"; break;
			case "Welcome": $ret="Willkommen"; break;
			case "facts": $ret="Fakten"; break;
			case "Number of users": $ret="Anzahl der Benutzer"; break;
			case "Number of albums": $ret="Anzahl der Alben"; break;
			case "Number of performers": $ret="Anzahl der K�nstler"; break;
			case "Number of tracks": $ret="Anzahl der Songs"; break;
			case "Latest 10 albums added": $ret="10 zuletzt hinzugef�gte Alben"; break;
			case "Latest 10 performers added": $ret="10 zuletzt hinzugef�gte K�nstler"; break;
			case "Track list": $ret="Song-Liste"; break;
			case "All": $ret="Alle"; break;
			case "Matches": $ret="Treffer"; break;
			case "Jump to": $ret="Gehe zu"; break;
			case "Title": $ret="Titel"; break;
			case "Duration": $ret="Dauer"; break;
			case "Last played": $ret="Zuletzt gespielt"; break;
			case "Played": $ret="Gespielt"; break;
			case "pages in total": $ret="Seiten gesamt"; break;
			case "Play all tracks with": $ret="Alle St�cke spielen mit"; break;
			case "Play all tracks from": $ret="Alle St�cke spielen von"; break;
			case "Queue all tracks with": $ret="Alle St�cke in Liste mit"; break;
			case "Queue all tracks from": $ret="Alle St�cke in Liste von"; break;
			case "Appears on": $ret="Erschienen auf"; break;
			case "Add all tracks to favorite list": $ret="Alle St�cke zu Favoriten hinzuf�gen"; break;
			case "Add to favorite": $ret="Zu Favoriten hinzuf�gen"; break;
			case "Add album to favorite list": $ret="Album zu Favoriten hinzuf�gen"; break;
			case "Search results": $ret="Suchergebnisse"; break;
			case "Personal settings": $ret="Meine Einstellungen"; break;
			case "Play tracks from": $ret="St�cke abspielen von"; break;
			case "Play tracks from these year(s)": $ret="St�cke dieses Jahres abspielen";break;
			case "Number of tracks to select": $ret="Anzahl St�cke zum Ausw�hlen"; break;
			case "Play & display options": $ret="Abspiel- und Anzeigeeinstellungen"; break;
			case "When a track is selected": $ret="Wenn ein St�ck gew�hlt ist"; break;
			case "Put it in the queue": $ret="In die Abspiel-Liste"; break;
			case "Play it immediately": $ret="Jetzt abspielen"; break;
			case "Number of items per page": $ret="Anzahl Eintr�ge pro Seite"; break;
			case "Display when a track was played last time": $ret="Anzeigen, wann ein St�ck zuletzt abgespielt wurde"; break;
			case "Display how many times a track has been played": $ret="Anzeigen, wie oft ein St�ck abgespielt wurde"; break;
			case "Display ID numbers": $ret="ID-Nummern anzeigen"; break;
			case "Show letters (the 'Jump to' option)": $ret="Buchstaben anzeigen ('Gehe zu'-Einstellung)"; break;
			case 'Pick a "normal" color': $ret='Eine "normale" Farbe ausw�hlen'; break;
			case 'Pick an "alternative" color': $ret='Eine "alternative" Farbe ausw�hlen'; break;
			case 'Pick the "highlight" color': $ret='Eine Hervorhebungs-Farbe ausw�hlen'; break;
			case "Pick the background color": $ret="Eine Hintergrund-Farbe ausw�hlen"; break;
			case "Colors": $ret="Farben"; break;
			case "Click here to pick/change": $ret="Hier klicken, um auszuw�hlen"; break;
			case "Create new": $ret="Neu erstellen"; break;
			case "Administrator": $ret="Administrator"; break;
			case "Last login": $ret="Letzte Anmeldung"; break;
			case "IP-address": $ret="IP-adresse"; break;
			case "Username": $ret="Benutzername"; break;
			case "Password": $ret="Kennword"; break;
			case "Create new": $ret="Neu erstellen"; break;
			case "Other options": $ret="Andere Einstellungen"; break;
			case "Language": $ret="Sprache"; break;
			case "Delete": $ret="L�schen"; break;
			case "Edit": $ret="Bearbeiten"; break;
			case "Copy the queue to the favorite list": $ret="Abspiel-Liste zu Favoriten kopieren"; break;
			case "Select a favorite list": $ret="Eine Favoriten-Liste w�hlen"; break;
			case "There are no tracks in the queue": $ret="Keine St�cke in der Abspiel-Liste"; break;
            case "Are you sure": $ret="Sind sie sicher?"; break;
            case "Save & continue": $ret="Speichern & weiter"; break;
            case "Yes": $ret="Jah"; break;
            case "No": $ret="Nein"; break;
// 0.3.3: *New* in this release, please translate yourself:
            case "Filter": $ret="Filter"; break;
            case "Tracks only on albums": $ret="Tracks only on albums"; break;
            case "Tracks not on any album": $ret="Tracks not on any album"; break; //
//

		} // switch
?>
