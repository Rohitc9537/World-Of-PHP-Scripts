<?
// Turkish Language file for Ampjuke
// Version: 1.0 Date: 22-Nov-2005
// by: Mehmet Akif EKER, http://www.oksohom.com
		switch ($key) {
			case "Track": $ret="Par�a"; break;
			case "Tracks": $ret="Par�alar"; break;
			case "Performer": $ret="Sanatkar"; break;
			case "Performers": $ret="Sanatkarlar"; break;
			case "Album": $ret="Alb�m"; break;
			case "Albums": $ret="Alb�mler"; break;
			case "Year": $ret="Y�l"; break;
			case "Favorites": $ret="Favoriler"; break;
			case "Favorite list": $ret="Favori Liste"; break;
			case "Queue": $ret="S�ra"; break;
			case "The queue": $ret="S�ra"; break;
            case "Random play": $ret="Rasgele �al"; break;
			case "Settings": $ret="Ayarlar"; break;
			case "Search": $ret="Arama"; break;
			case "Logout": $ret="��k��"; break;
			case "Admin's options": $ret="Admin Ayarlar�"; break;
			case "Scan music..."; $ret="M�zik Tara..."; break;
			case "User adm..."; $ret="Kullan�c� Admin..."; break;
			case "Configuration..."; $ret="Ayaralar..."; break;
			case "Clear cache": $ret="Cokileri Temizle"; break;
			case "Welcome": $ret="Ho�geldiniz"; break;
			case "facts": $ret="Olaylar"; break;
			case "Number of users": $ret="Kullan�c� Say�lar�"; break;
			case "Number of albums": $ret="Alb�m Say�lar�"; break;
			case "Number of performers": $ret="Sanatkar Say�lar�"; break;
			case "Number of tracks": $ret="Par�a Say�lar�"; break;
			case "Latest 10 albums added": $ret="Eklenen Son 10 Alb�m"; break;
			case "Latest 10 performers added": $ret="Eklenen Son 10 Sanatkar"; break;
			case "Track list": $ret="Par�a Listesi"; break;
			case "All": $ret="Hepsi"; break;
            case "Matches": $ret="E�le�tirmeler"; break;
			case "Jump to": $ret="Atla"; break;
			case "Title": $ret="Ba�l�k"; break;
			case "Duration": $ret="S�re"; break;
			case "Last played": $ret="Son �al�nan"; break;
			case "Played": $ret="�al�nan"; break;
			case "pages in total": $ret="Sayfa -Toplam-"; break;
			case "Play all tracks with": $ret="B�t�n par�alarla birlikte �al"; break;
			case "Play all tracks from": $ret="B�t�n par�alarla birlikte"; break;
			case "Queue all tracks with": $ret="B�t�n Par�alarla Birlikte S�rala"; break;
			case "Queue all tracks from": $ret="B�t�n Par�alarla Birlikte"; break;
			case "Appears on": $ret="G�z�ken Liste"; break;
			case "Add all tracks to favorite list": $ret="B�t�n par�alar� favori listene ekle"; break;
			case "Add to favorite": $ret="Favori Listene Ekle"; break;
			case "Add album to favorite list": $ret="Alb�m� favori listene ekle"; break;
			case "Search results": $ret="Arama Sonu�lar�"; break;
			case "Personal settings": $ret="Kullan�c� Ayarlar�"; break;
			case "Play tracks from": $ret="Par�alara �al"; break;
			case "Play tracks from these year(s)": $ret="Par�alar� Bu y�l(lar)la �al";break;
			case "Number of tracks to select": $ret="Se�ti�iniz Par�a Say�s�"; break;
			case "Play & display options": $ret="�alma&G�sterme Ayarlar�"; break;
			case "When a track is selected": $ret="Par�a Se�ildi�i Zaman"; break;
			case "Put it in the queue": $ret="S�raya Al"; break;
			case "Play it immediately": $ret="�abuk �al"; break;
			case "Number of items per page": $ret="Sayfa Ba��na Par�a Say�s�"; break;
			case "Display when a track was played last time": $ret="Son �al�nan Par�a Oldu�u Zaman G�ster"; break;
			case "Display how many times a track has been played": $ret="Par�an�n S�resini G�ster"; break;
			case "Display ID numbers": $ret="Id Numaralar�n� G�ster"; break;
			case "Show letters (the 'Jump to' option)": $ret="Yaz�lar� G�ster"; break;
			case 'Pick a "normal" color': $ret='Normal Renk Kullan'; break;
			case 'Pick an "alternative" color': $ret='Alternatif Renk Kullan'; break;
			case 'Pick the "highlight" color': $ret='Y�ksek Kalite Renk Kullan'; break;
			case "Pick the background color": $ret="Arka Plan Rengi Kullan"; break;
			case "Colors": $ret="Renkler"; break;
			case "Click here to pick/change": $ret="De�i�tirmek ��in T�klay�n�z"; break;
			case "Create new": $ret="Yeni Olu�tur"; break;
			case "Administrator": $ret="Admin"; break;
			case "Last login": $ret="Son Giri�"; break;
			case "IP-address": $ret="IP Adres"; break;
			case "Username": $ret="Kullan�c� Ad�"; break;
			case "Password": $ret="�ifre"; break;
			case "Create new": $ret="Create new"; break; //
			case "Other options": $ret="Di�er Ayarlar"; break;
			case "Language": $ret="Dil"; break;
			case "Delete": $ret="Sil"; break;
			case "Edit": $ret="D�zenle"; break;
			case "Copy the queue to the favorite list": $ret="S�ray� favor listene kopyala"; break;
			case "Select a favorite list": $ret="Favori Listeni Se�"; break;
			case "There are no tracks in the queue": $ret="S�rada Hi� Bir Par�a Yok"; break;
            case "Are you sure": $ret="Emin Misin?"; break;
            case "Save & continue": $ret="Kaydet"; break;
            case "Yes": $ret="Evet"; break;
            case "No": $ret="Hay�r"; break;
// 0.3.3: *New* in this release, please translate yourself:
            case "Filter": $ret="Filter"; break;
            case "Tracks only on albums": $ret="Tracks only on albums"; break;
            case "Tracks not on any album": $ret="Tracks not on any album"; break; //
//
		} // switch
?>
