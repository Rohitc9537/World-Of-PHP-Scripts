<?
switch ($key) {
case "Track": $ret="Canci�n"; break; //
case "Performer": $ret="Ejecutante"; break; //
case "Album": $ret="�lbum"; break; //
case "Year": $ret="A�o"; break; //
case "Favorites": $ret="Fijas"; break; //
case "Queue": $ret="Cola"; break; //
case "Random play": $ret="Canciones aleatorios"; break; //
case "Settings": $ret="Configuraci�n"; break; //
case "Search": $ret="Buscar"; break; //
case "Logout": $ret="Terminar la sesi�n"; break; //
case "Admin's options": $ret="Opciones de administrador"; break; //
case "Scan music...": $ret="Explorar la m�sica..."; break; //
case "User adm...": $ret="Configuraci�n de usuarios..."; break; //
case "Configuration...": $ret="Configuraci�n de administrador..."; break; //
case "Clear cache": $ret="Vaciar reserva"; break; //
case "Welcome": $ret="Bienvenidos"; break; //
case "Facts": $ret="Hechos"; break; //
case "Number of users": $ret="N�mero de usarios"; break; //
case "Number of performers": $ret="N�mero de ejecutantes"; break; //
case "Number of albums": $ret="N�mero de �lbumes"; break; //
case "Number of tracks": $ret="N�mero de canciones"; break; //
case "Latest 10 albums added": $ret="�ltimos 10 �lbumes agregado"; break; //
case "Latest 10 performers added": $ret="�ltimos 10 ejecutantes agregado"; break; //
case "Track list": $ret="Lista de canciones"; break; //
case "Albums": $ret="�lbumes"; break; //
case "Performers": $ret="Ejecutantes"; break; //
case "The queue": $ret="Reserva"; break; //
case "Search results": $ret="B�squeda resulta"; break; //
case "Personal settings": $ret="Configuraci�n personal"; break; //
case "Tracks": $ret="Canciones"; break; //
case "Favorite list": $ret="Lista de fijas"; break; //
case "Matches": $ret="Emparejamientes"; break; //
case "All": $ret="Todo"; break; //
case "Jump to": $ret="Var a"; break; //
case "pages in total": $ret="Todas p�ginas"; break; //
case "Title": $ret="T�tulo"; break; //
case "Duration": $ret="Duraci�n"; break; //
case "Last played": $ret="Canci�n previa"; break; //
case "Played": $ret="Escuchado"; break; //
case "Play all tracks with": $ret="Escuchar todas canciones con"; break; //
case "Play all tracks from": $ret="Escuchar todas canciones de"; break; //
case "Queue all tracks with": $ret="Poner en la cola todas canciones con"; break; //
case "Queue all tracks from": $ret="Poner en la cola todas canciones de"; break; //
case "Add all tracks to favorite list": $ret="Agregartodas canciones a la lista de fijas"; break; //
case "Add to favorite": $ret="Agregar a fija"; break; //
case "Add album to favorite list": $ret="Agregar �lbum a la lista de fijas"; break; //
case "Play tracks from": $ret="Escuchar canciones de"; break; //
case "Play tracks from these years": $ret="Escuchar canciones de estos a�os"; break; //
case "Number of tracks to select": $ret="N�mero de canciones para seleccionar"; break; //
case "Appears on": $ret="Aparece en"; break; //
// 0.3.3: *New* in this release, please translate yourself:
            case "Filter": $ret="Filter"; break;
            case "Tracks only on albums": $ret="Tracks only on albums"; break;
            case "Tracks not on any album": $ret="Tracks not on any album"; break; //
//
}
?>
