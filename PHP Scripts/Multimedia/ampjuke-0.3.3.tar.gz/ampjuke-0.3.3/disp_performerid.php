<?
if (!isset($_SESSION['login'])) {
	header("Location: login.php");
	exit;
}	
require("sql.php");
require("set_td_colors.php");
require("disp.php");

// get headline: performer's name:
$qry="SELECT * FROM performer WHERE performer.pid=".$special;
$header_result=execute_sql($qry,0,1,$nr);
$header_row=mysql_fetch_array($header_result);

std_table($tdalt);
echo '<tr><td>';
// play/enqueue all:
$text=xlate($playtext.' all tracks with').' '.$header_row['pname'].'</b>';
echo ' <a href="play_action.php?act=playall&what=performerid&id='.$special.'">';
echo '<img src="./icons/mnu_arr.gif" border="0">'.$text.'</a> ';
// add to favorite list:
if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) {
	add2fav_link(xlate('Add all tracks to favorite list').' <b>'.$_SESSION['favoritelistname'].'</b>','?what=performerid&id='.$special);
}	
echo '</td></tr></table>';	

// prepare album list and "also appears on..." list:
$buf='';

// album list
$alb_rows=0;
$found=0;
	// 0.2.3: "borrowed" from DISP.PHP's headline() function:
	$buf.='<table border="1" cellspacing="0" cellpadding="0" rules="rows" bgcolor="#abcdef">';
    $buf.='<tr><td colspan="5" align="center">&nbsp<br><b>';
	$buf.=xlate("Albums").' : '.$header_row['pname'];	
	$buf.='</b><br>&nbsp</td></tr><tr bgcolor="#ffffff">';
	//
	
	$buf.='<table border="1" cellspacing="0" cellpadding="1px" rules="none">';
	$buf.='<th align="left"><p>'.xlate('Name').'</p></th>';
	
	$qry="SELECT * FROM album WHERE aperformer_id=".$special;
	$qry.=" ORDER BY aname";
	$result=execute_sql($qry,0,1000000,$alb_rows);
	if ($alb_rows>0) {
		while ($row=mysql_fetch_array($result)) {
			$buf.=fancy_tr_buf($tmpcount,$tdnorm,$tdalt,$tdhighlight);
			$buf.='<td><a href="index.php?what=albumid&start=0&count='.$_SESSION['count'];
			$buf.='&special='.$row['aid'].'&order_by=track.track_no">';
			$buf.=$row['aname'].'</a></td></tr>';
		}
	}
// album list ends we will continue with:
// also appears on...
	$qry="SELECT album_id,performer_id FROM track WHERE performer_id=".$special;
	$result=execute_sql($qry,0,1000000,$nr);
	$max_count=0;
	while ($row=mysql_fetch_array($result)) {
		$a[$max_count]=$row['album_id'];
		$max_count++;
	}
	$c=0;
	$tmpcount=0; // start off w. same color in the 1st row
	if ($max_count>0) {
		while ($c<$max_count) {
			$qry="SELECT * FROM album WHERE aid=".$a[$c]." AND aperformer_id!=".$special;
			$result=execute_sql($qry,0,1,$nr);
			if ($nr==1) {
				$row=mysql_fetch_array($result); // there's only one anyway					
				$buf.=fancy_tr_buf($tmpcount,$tdnorm,$tdalt,$tdhighlight); 
				$buf.='<td><i>('.xlate("Appears on").') </i>';
				$buf.='<a href="index.php?what=albumid&start=0&count='.$_SESSION['count'];
				$buf.='&special='.$row['aid'].'&order_by=track.track_no">';
				$buf.=$row['aname'].'</a></td></tr>';
				$found=1;		
			}	
			$c++;
		}	
		$buf.='</td></tr></table>';
	}
// also appears on... ends

// print out results, if there's anything to print:
if ($found==1 || $alb_rows>=1) { 
	echo $buf;
	echo '<hr width="80%" align="center" color="#5b4fed">';
}	

// Next step: track list
	$qry="SELECT track.id, track.performer_id, track.album_id, track.track_no, ";
	$qry.="track.name, track.duration, track.year, ";
	$qry.="track.last_played, track.times_played, track.path, ";
	$qry.="performer.pid, performer.pname ";
	$qry.="FROM track,performer";
	$qry.=" WHERE ((track.performer_id='".$special."'";
	$qry.=" AND performer.pid='".$special."'))";
	// 0.2.3:
	if (!isset($order_by)) {
		$order_by="track.name";
		$dir="ASC";
	}
	//	
	if ($order_by!="") {
		$qry.=" ORDER BY $order_by $dir ";
	}
	$result=execute_sql($qry,$start,$count,$num_rows);	
	headline('',xlate('Tracks').' : '.$header_row['pname'],'','1');

	require("tbl_header.php");
	std_table('');
	if ($dir=="ASC") { $newdir="DESC"; } else { $newdir="ASC"; }
	// 0.2.3: ID's:
	if ($_SESSION['show_ids']=="1") {
		tbl_header($what,xlate("ID"),"left","track.id",$order_by,$dir,$newdir,
		$count,'limit='.$limit.'&special='.$special);
	}		
	//		
	tbl_header("performerid",xlate("Title"),"left","track.name",$order_by,$dir,$newdir,$count,"&special=".$special);
	tbl_header("performerid",xlate("Year"),"left","track.year",$order_by,$dir,$newdir,$count,"&special=".$special);
	tbl_header("performerid",xlate("Duration"),"left","track.duration",
    $order_by,$dir,$newdir,$count,"&special=".$special);
	if ($_SESSION['disp_last_played']=="1") {
		tbl_header("performerid",xlate("Last played"),"right","track.last_played",$order_by,$dir,
		$newdir,$count,'&special='.$special);
	}
	if ($_SESSION['disp_times_played']=="1") {
		tbl_header("performerid",xlate("Played"),"right","track.times_played",$order_by,$dir,
		$newdir,$count,'&special='.$special);
	}
	echo '<th></th>';

	while ($row=mysql_fetch_array($result)) {
		fancy_tr($tmpcount,$tdnorm,$tdalt,$tdhighlight);
		// 0.2.3: ID's:
		if ($_SESSION['show_ids']=="1") {
			echo '<td>';
			if ($_SESSION['admin']=="1") { // offer option to edit the track:
				echo '<a href="index.php?what=edit&edit=track&id='.$row['id'].'">'.$row['id'].'</a>';
			} else {
				echo $row['id'];
			}
			echo '</td>';	
		}
		//			
		echo '<td><a href="play_action.php?act=play&id='.$row['id'].'">'.$row['name'].'</a></td>';
		add_year_link($row['year'],$row['year']);
		echo '<td>'.$row['duration'].'</td>';
		if ($_SESSION['disp_last_played']=="1") {
			echo '<td align="right">'.mydate($row['last_played']).'</td>';
		}
		if ($_SESSION['disp_times_played']=="1") {
			echo '<td align="right">'.$row['times_played'].'</td>';
		}	
		echo '<td align="right">';
		if (isset($_SESSION['favoritelistname']) && ($_SESSION['favoritelistname']!="")) { // 0.2.4
			add2fav_link('','?what=track&id='.$row['id']);
		}	
		echo '</td>';
		print "</tr> \n";
	}
	echo '</table>';	

	include("page_numbers.php");
// track list ends

/* uncomment this, if you also want images displayed when showing a specific PERFORMER:
$amazon_string="";
$amazon_string.=$header_row['pname'];
//echo $amazon_string;
if (!file_exists('./covers/'.$amazon_string.'.jpg')) {
	include("./amazon/amazon.php");
} else {
	echo '<table border="0"><tr><td align="center">Cached<br>';
	echo '<img src="./covers/'.$amazon_string.'.jpg" border="0">';
	echo '</td></tr></table>';
}	
*/

?>
