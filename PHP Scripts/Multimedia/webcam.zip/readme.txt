== cavemonkey50's Webcam Update Script ==

This PHP script will determine if a webcam image has been updated in a set amount of time. If it has been updated, it will display the webcam image; if it hasn�t it will display other content.

== Installation ==
Open webcam.php with your favorite text editor and configure the variables at the top of the script. Then replace the three HTML spots with your specific HTML code.

== Usage ==
Call the script within a PHP page with the following line of code:

<?php readfile("http://location.to/webcam.php"); ?> 

== Version History ==
1.5 - Updated script to be more user friendly.
1.0 - Initial Release

== Credits ==
Copyright (c) 2005 Ronald Heft, Jr. (ron@cavemonkey50.com)
Released under the terms of the GNU GPL