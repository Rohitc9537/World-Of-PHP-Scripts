+---------------------------------------------------------------------------+
| Update note                                                               |
+---------------------------------------------------------------------------+
When updating from netjukebox 3.75 and earlier to netjukebox 3.76 and later.
All users will be deleted and two default user will be created:

username: admin
password: admin

username: anonymous
password: anonymous

This is really needed for the further development of netjukebox.
For the same reason all favorites will be deleted.
Sorry for the inconvenience.


+---------------------------------------------------------------------------+
| Installation                                                              |
+---------------------------------------------------------------------------+
The installation instruction can be found on:
http://www.netjukebox.nl


+---------------------------------------------------------------------------+
| Configuration                                                             |
+---------------------------------------------------------------------------+
All configuration parameters can be set in:
include/config.inc.php
