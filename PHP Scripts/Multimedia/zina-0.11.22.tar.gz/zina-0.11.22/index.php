<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * ZINA (Zina is not Andromeda)
 *
 * Zina is a graphical interface to your MP3 collection, a personal
 * jukebox, an MP3 streamer. It can run on its own, embeded into an
 * existing website, or as a Postnuke/PHPNuke/Xoops/Mambo module.
 *
 * http://www.pancake.org/zina
 * Author: Ryan Lathouwers <ryanlath@pacbell.net>
 * Support: http://sourceforge.net/projects/zina/
 * License: GNU GPL <http://www.gnu.org/copyleft/gpl.html>
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
# BY DEFAULT: username is "admin" & password is "password"
# After you login in to Zina, change your password under "Settings"

# As of version 0.11.01, all settings are described and set through the GUI,
# except:
$z_login = true; # can admin login?

# If using as a module, you'll need to set this:
# 0='None/Stand Alone' 1='PHPNuke' 2='PostNuke', 3='Xoops', 4='Mambo'
#$z_embed = 0;
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * END DEFAULT USER SETTINGS
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
$z_t1 = array_sum(explode(' ', microtime()));
@session_start();
$z_ver = "0.11.22";
$z_dir = dirname(__FILE__);
$zc = null;
setConfig($zc);
require($zc['zina_dir']."/lang/".$zc['lang'].".php");
if ($zc['lang'] != "en") {
	if ($zc['main_dir_title'] == "Artists") { $zc['main_dir_title'] = _ZARTISTS; }
	if ($zc['dir_list_txt'] == "Albums") { $zc['dir_list_txt'] = _ZALBUMS; }
	if ($zc['alt_text'] == "See Also") { $zc['alt_text'] = _ZRELATED; }
	if ($zc['ran_def'] == "Songs") { $zc['ran_def'] = _ZSONGS; }
	if ($zc['ran_def'] == "Albums") { $zc['ran_def'] = _ZALBUMS; }
	if ($zc['mm_text'] == "Multimedia") { $zc['mm_text'] = _ZMULTIMEDIA; }
}
if (!empty($zc['charset_over'])) { $z_charset = $zc['charset_over']; }

$z_self = "${_SERVER['PHP_SELF']}?";

$z_proto = "http";
if (isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') $z_proto .= "s";

if ($zc['stream_int']) {
	$z_dirname = (strlen(dirname($z_self)) == 1) ? "" : dirname($z_self);
	$z_basedir = (substr($zc['mp3_dir'], -1, 1) == "/") ? substr($zc['mp3_dir'], 0, strlen($zc['mp3_dir']) - 1): $zc['mp3_dir'];
	$z_url_base = "$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}$z_dirname/$z_basedir";
} else {
	$z_url_base = "$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}".$zc['www_path'];
}

$z_theme_dir = $zc['root_dir']."/themes"; #relative

$z_img_tmp = "<img border='0' src='${z_theme_dir}/".$zc['theme']."/images/";
$z_img_add = "${z_img_tmp}add.gif' alt='"._ZADDTO."' title='"._ZADDTO."' align='top'/>";
$z_img_del = "${z_img_tmp}delete.gif' alt='"._ZDELETE."' title='"._ZDELETE."' align='top'/>";
$z_img_down = "${z_img_tmp}download.gif' alt='"._ZDOWNLOAD."' title='"._ZDOWNLOAD."' align='top'/>";
$z_img_home = "${z_img_tmp}home.gif' alt='"._ZHOME."' title='"._ZHOME."' align='middle'/>";
$z_img_more = "${z_img_tmp}more.gif' alt='"._ZMORE."' title='"._ZMORE."' align='top'/>";
$z_img_play = "${z_img_tmp}play.gif' alt='"._ZPLAY."' title='"._ZPLAY."' align='top'/>";
$z_img_rec = "${z_img_tmp}play_rec.gif' alt='"._ZPLAYREC."' title='"._ZPLAYREC."' align='top'/>";
$z_img_rec_rand = "${z_img_tmp}play_rec_rand.gif' alt='"._ZPLAYRECRAND."' title='"._ZPLAYRECRAND."' align='top'/>";
$z_img_lofi = "${z_img_tmp}play_lofi.gif' alt='"._ZPLAYLOFI."' title='"._ZPLAYLOFI."' align='top'/>";
$z_img_pls = "${z_img_tmp}playlist.gif' alt='"._ZPLAYLISTS."' title='"._ZPLAYLISTS."' align='top'/>";
$z_img_login = "${z_img_tmp}login.gif' alt='"._ZLOGIN."' title='"._ZLOGIN."' align='top'/>";
$z_img_ren = "${z_img_tmp}rename.gif' alt='"._ZRENAME."' title='"._ZRENAME."' align='top'/>";
$z_img_new = "${z_img_tmp}new.gif' border='0' alt='"._ZNEW."' title='"._ZNEW."' align='bottom'/>";
$z_img_cfg = "${z_img_tmp}config.gif' border='0' alt='"._ZCFG."' title='"._ZCFG."' align='top'/>";
$z_img_logout = "${z_img_tmp}logout.gif' alt='"._ZLOGOUT."' title='"._ZLOGOUT."' align='top'/>";
$z_img_edit = "${z_img_tmp}edit.gif' alt='"._ZEDIT."' title='"._ZEDIT."' align='top'/>";

$z_admin = $z_play_local = false;
$z_path = isset($_GET["p"]) ? $_GET["p"] : null;
$z_songs = isset($_POST["mp3s"]) ? $_POST["mp3s"] : null;
$z_level = isset($_GET["l"]) ? $_GET["l"] : null;
$z_m = isset($_GET["m"]) ? $_GET["m"] : null;
$z_playlist = isset($_POST["playlist"]) ? $_POST["playlist"] : (isset($_GET["pl"]) ? $_GET["pl"] : null);
$z_imgsrc = isset($_GET["img"]) ? $_GET["img"] : null;

#Stoopid magic quotes
if(get_magic_quotes_gpc()) {
	$z_deslash = array('$z_path','$z_songs','$z_playlist', '$z_imgsrc');
	foreach($z_deslash as $z_var) eval("$z_var = is_array($z_var) ? array_map('stripslashes', $z_var) : stripslashes($z_var);");
	if (isset($_POST) && !empty($_POST)) {
		foreach($_POST as $z_key => $z_val) {
			$_POST[$z_key] = is_array($_POST[$z_key]) ? array_map('stripslashes', $_POST[$z_key]) : stripslashes($_POST[$z_key]);
		}
	}
}
$z_cur_dir = $zc['mp3_dir']."/$z_path";

#Stoopid Apache2/Win32
$z_rawutf = (stristr($_SERVER["SERVER_SOFTWARE"], "Apache/2.") && strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? true : false;
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Postnuke/PHPnuke support
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#TODO: better security
if ($zc['embed'] > 0 && $z_level != "6" && $z_level != "10") {
	#pnuke vars: $admin / $user / $this_name
	if ($zc['embed'] == 1) { #PHPNUKE
		if (!eregi("modules.php", $_SERVER["PHP_SELF"]) ) { die ("You can't access this file directly..."); }
		require_once("mainfile.php");
		if (is_admin($admin)) {
			$z_admin = true;
		} elseif ($zc['pn_users']) {
			if (!is_user($user)) { Header("Location: modules.php?name=Your_Account"); }
		}
	} elseif ($zc['embed'] == 2) { #POSTNUKE
		if (!defined("LOADED_AS_MODULE")) { die ("You can't access this file directly..."); }
		if ($zc['pn_users']) { if(!pnUserLoggedIn()) { pnRedirect("user.php"); } }
		if (pnSecAuthAction(0, "Zina::", "::", ACCESS_ADMIN)) { $z_admin = true; }
	} elseif ($zc['embed'] == 3) { #XOOPS
		$z_sess = session_encode();
		session_destroy();
		include_once "../../mainfile.php";
		session_decode($z_sess);
		if ($xoopsUser && $xoopsUser->isAdmin($xoopsModule->mid())) { $z_admin = true; }
	} elseif ($zc['embed'] == 4) { #MAMBO
		if (isset($_GET['option'])) $z_self .= "option=".$_GET['option']."&";
		if (isset($_GET['Itemid'])) $z_self .= "Itemid=".$_GET['Itemid']."&";
		if ($zc['pn_users']) {
			if ($my->gid < 1) { header("Location: index.php?option=com_login"); exit; }
		}
		if ($acl->acl_check('administration', 'edit', 'users', $my->usertype, 'components', 'all')
			|| $acl->acl_check('administration', 'edit', 'users', $my->usertype, 'components', 'com_zina')) {
			$z_admin = true;
		}
	}

	if ($zc['embed'] <= 2) { #P-NUKE
		$this_name = $GLOBALS['name'];
		$z_self = "${z_self}name=$this_name&op=modload&file=index&";
	}
	$z_login = false;
}

if ($zc['cat_split']) {
	$z_cp = isset($_GET['page']) ? htmlentities($_GET['page']) : 1;
	#TODO: &amp; fucks up song url
	$z_self .= "page=$z_cp&";
}

if ($zc['wmp']) {
	if ($zc['wmp_force']) {
		$z_asx = true;
		$z_wmp = "";
	} else {
		$z_asx = (isset($_GET["asx"]) && $_GET["asx"] == 1);
			$z_tmp = "<a href='{$z_self}p=".getURLencodedPath($z_path);
		if ($z_asx) {
			$zc['stream_extinf'] = false;
			$z_wmp = "$z_tmp'>${z_img_tmp}wmp_on.gif' alt='"._ZWMPOFF."' title='"._ZWMPOFF."' align='top'/></a>&nbsp;";
			$z_self .= "asx=1&"; #TODO: &
		} else {
			$z_wmp = "$z_tmp&amp;asx=1'>${z_img_tmp}wmp_off.gif' alt='"._ZWMPON."' title='"._ZWMPON."' align='top'/></a>&nbsp;";
		}
	}
} else {
	$z_wmp = "";
	$z_asx = false;
}

$z_self_raw = "${z_self}p=".getURLencodedPath($z_path);

$z_home = "<a href='$z_self'>$z_img_home</a>";

if ($zc['genres']) {
	$z_img_genres = "${z_img_tmp}genres.gif' alt='"._ZGENRES."' title='"._ZGENRES."' align='middle'/>";
	$z_home = "$z_home&nbsp;<a href='${z_self}l=14'>$z_img_genres</a>";
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * MAIN
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
if (strstr($zc['adm_ips'], $_SERVER["REMOTE_ADDR"])) { $z_admin = true; }

if ($_SERVER["SERVER_ADDR"] == $_SERVER["REMOTE_ADDR"] || $zc['pos']) {
	if ($zc['local_path'] || $zc['pos']) {
		$z_url_base = $zc['mp3_dir'];
		$z_play_local = true;
	}
	$z_admin = ($z_admin | $zc['loc_is_adm']);
} else {
	if (strstr($z_path,"..")) { die(_NOTALLOWED); } #TODO: make opt?
}

if (isset($_SESSION['z_adm']) && $_SESSION['z_adm'] == true) { $z_admin = true; }

if ($z_admin) {
	$z_img_regen = "${z_img_tmp}regen.gif' border='0' alt='"._ZREGEN."' title='"._ZREGEN."' align='top'/>";
	$z_img_regen_g = "${z_img_tmp}regen_genres.gif' border='0' alt='"._ZREGENGENRES."' title='"._ZREGENGENRES."' align='top'/>";
	$z_lang = getSettings("other");
	$zc_url = "<a href='${z_self_raw}&amp;l=20'>$z_img_cfg</a>&nbsp;".
		"<a href='${z_self_raw}&amp;l=26&amp;m=1' onClick='return(confirm(\"${z_lang['regen']}\"))'>$z_img_regen</a>&nbsp;";
		if ($zc['genres']) {
			$zc_url .= "<a href='${z_self_raw}&amp;l=26&amp;m=2' onClick='return(confirm(\"${z_lang['regen_genre']}\"))'>$z_img_regen_g</a>&nbsp;";
		}
} else {
	$zc_url = "";
}
if ($z_login) {
	$z_login_url = "<a href='${z_self_raw}&amp;l=";
	$z_login_url .= ($z_admin) ? "99'>$z_img_logout</a>&nbsp;" : "9&amp;e=&nbsp;'>$z_img_login</a>&nbsp;";
} else {
	$z_login_url = "";
}

if (!$z_admin && $zc['cron'] && !empty($zc['cron_options'])) { timeCheck($zc['cron_options']); }

switch ($z_level) {
	case "3" : # CUSTOM PLAYLISTS
		$z_mode = isset($_GET["z"]) ? $_GET["z"] : null;

		if ($z_admin || $zc['session_pls']) {
			switch ($z_mode) {
				Case "1" : # View
					pageViewEditPlaylist ($z_playlist, $z_path);
					break;
				Case "2" : # Add New Playlist
					if (!$z_admin) { $z_playlist = "zina_session_playlist"; }
					if ($z_playlist == "new_zina_list") {
						pageGeneric("newplaylist",_ZNEWPLS, $z_songs);
					} else {
						writeCustomPlaylist($z_songs, "a", "_zina_$z_playlist.m3u");
						if (empty($z_path)) {
							$z_redir = "l=3&z=1&pl=".rawurlencode($z_playlist);
						} else {
							$z_redir = "p=".getURLencodedPath($z_path);
						}
						header("Location: $z_self$z_redir"); exit;
					}
					break;
				Case "3" : # Add Custom Title
					if ($z_admin) {
						writeCustomPlaylist($z_songs, "w", str_replace("/"," - ",$z_path).".m3u", true);
						header("Location: ${_SERVER['HTTP_REFERER']}"); exit;
					}
					break;
				Case "4" : # Update Playlist
					$z_order = isset($_POST["order"]) ? $_POST["order"] : null;
					if (!$z_admin) { $z_playlist = "zina_session_playlist"; }
					writeCustomPlaylist(getReorderedPlaylist($z_songs, $z_order), "w", "_zina_$z_playlist.m3u");
					pageViewEditPlaylist($z_playlist, $z_path);
					break;
				Case "5" : # Delete Playlist
					if ($z_admin) {
						deleteCustomPlaylist($z_playlist);
						header("Location: ${z_self}l=3&z=1"); exit;
					}
					break;
				Case "6" : # Rename Playlist
					if ($z_admin) {
						$z_playlist_new = isset($_POST["playlist_new"]) ? $_POST["playlist_new"] : "";
						pageGeneric("renameplaylist", _ZNEWPLS, $z_playlist, $z_playlist_new);
					}
					break;
				default :
					die(_ZNOTVALID);
			}
		} else { # NOT ADMIN
			if ($z_mode == "1") {
				pageViewEditPlaylist ($z_playlist, $z_path);
			} else {
				die(_ZNOTVALID);
			}
		}
		break;
	Case "4" : # SEARCH
		if ($zc['search']) { pageSearchResults($_POST["type"], $_POST["search"]); }
		break;
	Case "6" : # Return resampled MP3 (see settings)
		#Use: index.php?l=6&p=FILE
		if ($zc['resample']) { sendResampledMP3($z_path); }
		break;
	Case "7" : # return resized image
		if ($zc['res_dir_img'] || $zc['res_sub_img']) {
			$z_imgarr = array(0 => 'dir', 1 => 'sub');
			$z_it = isset($_GET["it"]) ? $_GET["it"] : null;
			$z_tmp = (preg_match("/^missing.*?\.jpg$/i",$z_imgsrc)) ? $zc['zina_dir']."/themes/".$zc['theme']."/images" : $zc['mp3_dir'];
			#$z_path == text, $z_m == color
			eval('sendImageResized("$z_tmp/$z_imgsrc", $zc["res_'.$z_imgarr[$z_it].'_x"], $zc["res_'.$z_imgarr[$z_it].'_qual"], $z_path, $z_m);');
			exit;
		}
		break;
	Case "8" : # RETURN PLAYLISTS
		$z_num = isset($_POST["n"]) ? $_POST["n"] : null;
		$z_lofi = isset($_GET["lf"]) ? $_GET["lf"] : false;
		$z_cus = isset($_GET["c"]) ? $_GET["c"] : false;
		if (!isset($z_m)) {$z_m = isset($_POST["m"]) ? $_POST["m"] : null; }
		if (is_numeric($z_m) && intval($z_m) >= 0 && intval($z_m) <= 10) {
			$z_use_cache = array(0 => '', 1 => 'Cached');
			$z_eval = array(
				'sendTitlePlaylist($z_path, false, $z_lofi);', # 0
				'sendSongPlaylist($z_path);', # 1
				'sendTitlePlaylist($z_path, true, $z_lofi);', # 2
				'sendCustomPlaylist($z_playlist, $z_lofi);', # 3
				'sendRandom'.$z_use_cache[$zc['cache']].'($z_num,"t",$z_lofi, true, null, $z_playlist);', # 4
				'sendRandom'.$z_use_cache[$zc['cache']].'($z_num,"s",$z_lofi, true, null, $z_playlist);', # 5
				'sendSongPlaylistResampled($z_path);',# 6
				'sendSelectedSongs($z_songs, $z_lofi);',# 7
				'sendSelectedCompressed($z_songs, $z_lofi);', # 8
				'sendSelectedCompressedDir($z_path, $z_cus, $z_lofi);', # 9
				'sendRandom'.$z_use_cache[$zc['cache']].'(0,"s",$z_lofi,$z_cus,$z_path);', # 10
			);
			eval($z_eval[$z_m]);
		}
		break;
	Case "9": # LOGIN
		if ($z_login) {
			$z_un = isset($_POST["un"]) ? $_POST["un"] : null;
			$z_up = isset($_POST["up"]) ? $_POST["up"] : null;
			$z_e = isset($_GET["e"]) ? $_GET["e"] : null;

			if (!empty($z_e)) {
				pageGeneric("login", _ZLOGIN, $z_un, $z_e);
			} else {
				if (checkPwd($z_un, $z_up)) {
					$_SESSION['z_adm'] = true;
					$z_redirect = "p=".getURLencodedPath($z_path);
				} else {
					$_SESSION['z_adm'] = false;
					$z_redirect = "l=9&e=".rawurlencode(_ZBADLOGIN);
				}
				header("Location: $z_self$z_redirect");
			}
		}
		break;
	Case "10" : # internal streaming
		if ($zc['stream_int']) { streamItem($z_path); }
		break;
	Case "11" : # return img
		if ($zc['stream_int'] && preg_match("/\.(".$zc['ext_graphic'].")$/i", $z_imgsrc)) {
			$z_tmp = (preg_match("/^missing.*?\.jpg$/i",$z_imgsrc)) ? $zc['zina_dir']."/themes/".$zc['theme']."/images" : $zc['mp3_dir'];
			@ob_end_clean();
			readfile("$z_tmp/$z_imgsrc");
			exit;
		}
		break;
	Case "12" : # download mp3
		if ($zc['stream_int'] && $zc['download'] && preg_match("/\.(".$zc['ext_mus'].")$/i", $z_path)) {
			header("Content-Type: application/force-download");
			header("Content-Disposition: inline; filename=\"".basename($z_path))."\"";
			header("Cache-control: private"); #IE seems to need this.
			$z_tmp = fopen($zc['mp3_dir']."/$z_path",'rb');
			while (!feof($z_tmp)) { echo fread($z_tmp,1048576); }
		}
		break;
	Case "13" : # Genre Listing
		#z_playlist = genre
		if ($zc['genres']) {
			pageSearchResults('g', $z_playlist);
		}
		break;
	Case "14" : # Genres
		if ($zc['genres']) { pageGeneric("genres",_ZGENRES); }
		break;
	Case "20" : # CFG
		if ($z_admin) { pageGeneric("cfg", _ZCFG); }
		break;
	Case "21": # CFG POST
		if ($z_admin) {
			writeConfig();
			header("Location: ${z_self_raw}");
		}
		break;
	Case "22": # EDIT WINDOW
		#z_m 1=dir 2=alt 3=song 4=mm
		#z_playlist = song
		if ($z_admin) { pageGeneric("blurb", "", $z_m, $z_playlist); }
		break;
	Case "23":
		if ($z_m == 1) {
			$z_file = $zc['dir_file'];
		} elseif ($z_m == 2) {
			$z_file = $zc['alt_file'];
		} elseif ($z_m == 3 || $z_m == 4) { # Song or MM
			$z_file = $z_playlist;
		} else { die(_ZERROR); }

		$z_songs = preg_replace("/(|\r)/","",$z_songs);

		$z_text_file = "$z_cur_dir/$z_file";
		if ($z_admin && is_writeable($z_cur_dir)) {
			if (!empty($z_songs)) {
				$fp = fopen($z_text_file, "w");
				fwrite($fp,$z_songs);
				fclose($fp);
			} else {
				if (file_exists($z_text_file)) unlink($z_text_file);
			}
			pageMain($z_path);
		}
		break;
	Case "24": # PLAY MM
		if ($zc['mm']) { pageGeneric("mm", "", $z_path); }
		break;
	Case "25" : # download MM
		if ($zc['stream_int'] && $zc['mm'] && $zc['mm_down'] && preg_match("/\.(".$zc['mm_ext'].")$/i", $z_path, $z_ext)) {
			eval("\$z_tmp = array(".$zc['mm_types'].");");
			header("Content-Type: ".$z_tmp[$z_ext[1]]['mime']);
			header("Content-Disposition: inline; filename=\"".basename($z_path))."\"";
			header("Cache-control: private"); #IE seems to need this.
			$z_tmp = fopen($zc['mp3_dir']."/$z_path",'rb');
			while (!feof($z_tmp)) { echo fread($z_tmp,1048576); }
		}
		break;
	Case "26" : # regen
		if ($z_admin) {
			if ($z_m == 1) {
				writeRandomCache("s", true);
			} elseif ($z_m ==2) {
				writeGenreCache(true);
			}
		}
		pageMain($z_path);

		break;
	Case "99": # logout
		session_unregister('z_adm');
		unset($_SESSION['z_adm']);
		header("Location: $z_self_raw");
		break;
	default : # MAIN PAGE
		pageMain($z_path);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * PAGE FUNCTIONS (GUI/display stuff)
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function pageMain($path) {
	global $z_self, $z_self_raw, $z_home, $z_img_down, $z_img_play, $z_img_lofi,
		$z_img_edit, $z_admin, $z_login_url, $zc_url, $z_cur_dir, $zc, $z_img_rec,
		$z_img_rec_rand, $z_wmp;

	$path_raw = $text = $image = $title = $play_txt = $down_txt = $c_pls_url = "";
	$images_found = 0;
	$category = $custom_pls = $lofi = false;
	$c_pls_arr = null;

	$dir_write = ($z_admin && is_writeable($z_cur_dir)) ? true : false;

	if (file_exists("$z_cur_dir/".$zc['cat_file'])) {
		$subdir_images = false;
		$category = true;
		$width = $zc['cat_width'];
	} else {
		$subdir_images = $zc['subdir_images'];
		$width = $zc['width'];
	}
	if (substr($width,-1) != "%") { $width = "${width}px"; }

	if (file_exists("$z_cur_dir/".$zc['dir_file'])) {
		$text .= nl2br(implode('',file("$z_cur_dir/".$zc['dir_file'])));
	}
	if ($dir_write) {
		$text .= "&nbsp;<a href='${z_self_raw}&amp;l=22&amp;m=1'>$z_img_edit</a>";
	}
	if ($zc['alt_dirs']) {
		$alt_images = 0;
		$alt_file = "$z_cur_dir/".$zc['alt_file'];
		if (file_exists($alt_file)) {
			$alts = file($alt_file);
			$alt_found = true;
		} else {
			$alt_found = false;
		}
	} else {
		$alt_found = false;
	}
	$various = ($zc['various'] && file_exists("$z_cur_dir/".$zc['various_file'])) ? true : false;

	$tmpl = getTemplate("main");
	$tmpl = tmpDelSec($tmpl,"SEC-GENERIC");

	# NAVIGATION
	$nav = $z_home;
	if (!empty($path)) {
		htmlNav($path, $nav, $path_raw, $title, $dir_current);
	} else {
		$title = $dir_current = $zc['main_dir_title'];
	}
	$html_title = formatTitle($dir_current);
	$t_amg = ($zc['amg']) ? htmlAMG($html_title) : "";
	if (!$zc['nav']) $nav = "&nbsp;";

	$arr = getDir($path, $images_found, $category, $subdir_images);
	if (!empty($arr['subdirs'])) {
		$dirs_found = true;
		$dir_num = sizeof($arr['subdirs']);
	} else {
		$dirs_found = false;
	}

	$files_found = (!empty($arr['files']));

	# Play Text
	if ($zc['low'] && ($zc['resample'] || $arr['lofi'])) { $lofi = true; }

	# Recursive Play & Random
	$t_play_rec = "";
	$pr_beg = "<a class='z_play' href='$z_self_raw&amp;l=8&amp;m=10&amp;c=";
	if ($zc['play_rec'] && $dirs_found && $dir_num > 1) {
		$t_play_rec .= "${pr_beg}0'>$z_img_rec</a> &nbsp;";
	}

	if ($zc['play_rec_rand'] && ($files_found || $dirs_found)) {
		$t_play_rec .= "${pr_beg}1'>$z_img_rec_rand</a> &nbsp;";
	}

	# Custom Playlist
	if ($files_found) {
		$url_begin = "<a href='$z_self_raw";
		if ($zc['play']) {
			$url_play = "$url_begin&amp;l=8&amp;m=0' class='z_play'>";
			$play_txt = "$url_play$z_img_play</a> &nbsp;";
		}
		if ($lofi) { $play_txt .= "$url_begin&amp;l=8&amp;m=0&amp;lf=true'>$z_img_lofi</a>&nbsp;&nbsp;&nbsp;"; }
		if ($zc['play']) { $play_txt .= "$t_play_rec${url_play}"._ZPLAY."</a>"; }
		if ($zc['play'] || $lofi || $zc['cmp_sel']) { $play_txt .= "&nbsp;<span class='z_play'>$html_title</span><br /><br />"; }
		if ($zc['download'] && $zc['cmp_sel']) { $down_txt = "$url_begin/.lp&amp;l=8&amp;m=9&amp;c=0'>$z_img_down</a> &nbsp;"; }
		$t_play_rec = "";
	}

	$c_pls = $zc['cache_dir']."/".str_replace("/"," - ",$path).".m3u";

	if ($zc['cache'] && file_exists($c_pls)) {
		$custom_pls = true;
		$c_pls_url = "";
		$c_pls_arr = file($c_pls);
		foreach ($c_pls_arr as $key => $value) { $c_pls_arr[$key] = rtrim($value); }
		if ($zc['download'] && $zc['cmp_sel']) { $c_pls_url .= "$url_begin/.lp&amp;l=8&amp;m=9&amp;c=1'>$z_img_down</a> &nbsp;"; }
		if ($zc['play']) { $c_pls_url .= "$url_begin&amp;l=8&amp;m=2'>$z_img_play</a> &nbsp;"; }
		if ($lofi) { $c_pls_url .= "$url_begin&amp;l=8&amp;m=2&amp;lf=true'>$z_img_lofi</a> &nbsp; "; }
		if ($zc['play']) { $c_pls_url .= "$url_begin&amp;l=8&amp;m=2'>"._ZPLAY." <i>$html_title</i> ("._ZCUSTOM.")</a><br /><br />"; }
	}

	if (!$category && (!empty($arr['images']) || $zc['dir_img_missing'])) {
		$image = htmlImage($arr['images'][0], $path, $title, 'dir', false, 'align="left"');
		if ($zc['dir_imgs']  && sizeof($arr['images']) > 1) {
			$tmp = "<script type='text/javascript'>function nextImage() { i++; if (i > zImages.length - 1) i = 0; document.getElementById('zImage').src = zImages[i]; }; var i=0; zImages=new Array(";
			foreach($arr['images'] as $img) {
				$tmp .= '"'.str_replace("&amp;","&",htmlImage($img, $path, $title, 'dir', true)).'",';
			}
			$tmp = substr($tmp,0,-1);
			$image = "$tmp);</script><a href='JavaScript:nextImage();'>$image</a>";
		}
	}
	$tmpl = str_replace('{$pagetitle}', $title, $tmpl);
	$tmpl = str_replace('{$htmltitle}', $title, $tmpl);
	$tmpl = str_replace('{$width}', $width, $tmpl);
	$tmpl = str_replace('{$login}', $z_login_url, $tmpl);
	$tmpl = str_replace('{$admin_cfg}', $zc_url, $tmpl);
	$tmpl = str_replace('{$wmp}', $z_wmp, $tmpl);
	$tmpl = str_replace('{$searchform}', htmlSearchForm(), $tmpl);
	$tmpl = str_replace('{$randomplay}', htmlRandom(), $tmpl);
	$tmpl = str_replace('{$dirimg}', $image, $tmpl);
	$tmpl = str_replace('{$dirblurb}', $text, $tmpl);
	$tmpl = str_replace('{$dirdown}', $down_txt, $tmpl);
	$tmpl = str_replace('{$dirplay}', "$play_txt$t_play_rec$c_pls_url", $tmpl);

	if ($category) {
		$tmpl = tmpDelSec($tmpl,"SEC-DIR");
		$tmpl = tmpDelSec($tmpl,"SUBDIRS");
		$tmpl = tmpDelSec($tmpl,"ALT");
		$tmpl = tmpDelSec($tmpl,"YEAR");
		$tmpl = tmpDelSec($tmpl,"GENRE");

		if ($zc['cat_split']) {
			global $z_cp;
			$tmp = htmlPages($z_cp, $dir_num);
			$cstart = ($z_cp - 1) * $zc['cat_pp'];
			if ($cstart > $dir_num) {
				$cstart = 0;
				$z_cp = 1;
			}
			$arr['subdirs'] = array_slice($arr['subdirs'], $cstart, $zc['cat_pp'] );
			$tmpl = str_replace('{$cs_pages}', $tmp['pages'], $tmpl);
			$tmpl = str_replace('{$cs_back}', $tmp['b'], $tmpl);
			$tmpl = str_replace('{$cs_forward}', $tmp['f'], $tmpl);
		} else {
			$tmpl = tmpDelSec($tmpl,"CAT-SPLIT");
		}

		$tmpl = str_replace('{$category}', htmlCategory($arr['subdirs']), $tmpl);
	} else { # Not Category
		$tmpl = tmpDelSec($tmpl,"SEC-CAT");
		$dir_list = $list = false;
		$n1 = $n2 = 0;

		if ($zc['dir_list'] && $dirs_found) {
			$dir_list = $list = true;
			$tmpl = str_replace('{$subdirs_text}', $zc['dir_list_txt'], $tmpl);
			$n1arr = htmlDirList($arr['subdirs']);
			$n1 = $n1arr['num'];
			$tmpl = str_replace('{$subdirs_list}', $n1arr['list'], $tmpl);
		} else {
			$tmpl = tmpDelSec($tmpl,"SUB-LIST");
			$tmpl = tmpDelSec($tmpl,"AMG");
		}

		if ($zc['alt_dirs'] && $dir_write) {
			$dir_list = true;
			$tmpl = str_replace('{$alt_text}', $zc['alt_text']."&nbsp;<a href='${z_self_raw}&amp;l=22&amp;m=2'>$z_img_edit</a>", $tmpl);
		} elseif($alt_found) {
			$tmpl = str_replace('{$alt_text}', $zc['alt_text'], $tmpl);
		} else {
			$tmpl = tmpDelSec($tmpl,"ALT-TITLE");
		}

		if ($alt_found) {
			foreach($alts as $alt) {
				$alt = rtrim($alt);
				$arr2[$alt]['image'] = getDirImage($zc['mp3_dir']."/$alt", $alt_images);
				$arr2[$alt]['lofi'] = 1;
				if ($zc['low_lookahead']) { $arr2[$alt]['lofi'] = getSubDirLofi($zc['mp3_dir']."/$alt"); }
			}
			if ($zc['dir_list']) {
				$dir_list = $list = true;
				$n2arr = htmlDirList($arr2);
				$n2 = $n2arr['num'];
				$tmpl = str_replace('{$alt_list}', $n2arr['list'], $tmpl);
			} else {
				$tmpl = tmpDelSec($tmpl,"ALT-LIST");
			}
		} else {
			$tmpl = tmpDelSec($tmpl,"ALT-LIST");
		}

		if ($dir_list) {
			if ($list && $zc['playlists']) {
				$type = ($n1 + $n2 > 0) ? "l a x p q v" : "l x p q v";
				$list_opts = htmlPlaylistFormElements('dirs', $title, $type);
				$tmpl = str_replace('{$subdirs_list_form_opts}', $list_opts, $tmpl);
				$pls_beg = "name='dirs' method='post' action='${z_self}p=$path_raw'";
			} else {
				$pls_beg = "";
				$tmpl = tmpDelSec($tmpl,"DIRLIST-OPTS");
			}
			$tmpl = str_replace('{$subdirs_list_form}', $pls_beg, $tmpl);
		} else {
			$tmpl = tmpDelSec($tmpl,"LIST");
		}

		if ($zc['subdir_images']) {
			if ($images_found > 0 || ($zc['subdir_img_missing'] && $dirs_found)) {
				$tmpl = str_replace('{$subdirs_text}', $zc['dir_list_txt'], $tmpl);
				$tmpl = str_replace('{$subdir_images}', htmlDirImages($arr['subdirs']), $tmpl);
			} else {
				$tmpl = tmpDelSec($tmpl,"SUBDIRS");
			}
			if ($zc['alt_images'] && $alt_found && ($alt_images > 0 || $zc['subdir_img_missing'])) {
				$tmpl = str_replace('{$alt_images}', htmlDirImages($arr2), $tmpl);
			} else {
				$tmpl = tmpDelSec($tmpl,"ALT");
			}
		} else {
			$tmpl = tmpDelSec($tmpl,"SUBDIRS");
			$tmpl = tmpDelSec($tmpl,"ALT");
		}
	}
	$tmpl = str_replace('{$amgsearch}', $t_amg, $tmpl);
	$tmpl = str_replace('{$nav}', $nav, $tmpl);

	if ($files_found) {
		if ($zc['dir_year'] || $zc['dir_genre']) {
			$di = getDirInfo($path);
			$tmpl = ($zc['dir_year'] && !empty($di['year'])) ? str_replace('{$year}', $di['year'], $tmpl) : tmpDelSec($tmpl,"YEAR");
			if ($zc['dir_genre']) {
				$g = ($zc['genres']) ? "<a href='${z_self_raw}&amp;l=13&amp;pl=".rawurlencode($di['genre'])."' class='z_genre'>${di['genre']}</a>" : $di['genre'];
				$tmpl = str_replace('{$genre}', $g, $tmpl);
			} else {
				$tmpl = tmpDelSec($tmpl,"GENRE");
			}
		} else {
			$tmpl = tmpDelSec($tmpl,"YEAR");
			$tmpl = tmpDelSec($tmpl,"GENRE");
		}
		$tmpl = str_replace('{$songs_text}', _ZSONGS, $tmpl);
		htmlSongs($tmpl, substr($path_raw,0 , -1), $arr['files'], $custom_pls, $c_pls_arr, $lofi, $various, $dir_write);
	} else {
		#TODO: redundancy with above
		if($zc['dir_genre_look'] && $dirs_found) {
			$di = getDirInfo(key($arr['subdirs']));
			$g = ($zc['genres']) ? "<a href='${z_self_raw}&l=13&amp;pl=".rawurlencode($di['genre'])."' class='z_genre'>${di['genre']}</a>" : $di['genre'];
			$tmpl = str_replace('{$genre}', $g, $tmpl);
		} else {
			$tmpl = tmpDelSec($tmpl,"GENRE");

		}
		$tmpl = tmpDelSec($tmpl,"SEC-SONGS");
		$tmpl = tmpDelSec($tmpl,"YEAR");
	}
	if ($zc['mm'] && !empty($arr['mm'])) {
		$tmpl = str_replace('{$mm_text}', $zc['mm_text'], $tmpl);
		htmlMM($tmpl, $arr['mm'], $dir_write);
	} else {
		$tmpl = tmpDelSec($tmpl,"SEC-MULTIMEDIA");
	}

	doModule($tmpl);
}

function pageSearchResults($type, $term) {
	global $z_home, $z_self, $z_admin, $zc, $z_login_url, $zc_url;

	$tmpl = getTemplate("main");
	#TODO: somehow use pageGeneric? create pageSong?
	$tmpl = tmpDelSec($tmpl,"SEC-CAT");
	$tmpl = tmpDelSec($tmpl,"SEC-DIR");
	$tmpl = tmpDelSec($tmpl,"SUBDIRS");
	$tmpl = tmpDelSec($tmpl,"ALT");
	$tmpl = tmpDelSec($tmpl,"SEC-GENERIC");
	$tmpl = tmpDelSec($tmpl,"SEC-MULTIMEDIA");
	$tmpl = tmpDelSec($tmpl,"YEAR");
	$tmpl = tmpDelSec($tmpl,"GENRE");
	$width = $zc['width'];
	if (substr($width,-1) != "%") { $width = "${width}px"; }
	$tmpl = str_replace('{$width}', $width, $tmpl);
	$tmpl = str_replace('{$nav}', $z_home, $tmpl);
	$tmpl = str_replace('{$login}', $z_login_url, $tmpl);
	$tmpl = str_replace('{$admin_cfg}', $zc_url, $tmpl);
	$tmpl = str_replace('{$wmp}', "", $tmpl);
	$tmpl = str_replace('{$randomplay}', htmlRandom(), $tmpl);

	if ($type == 'g') {
		$page = $term;
		$tmpl = str_replace('{$searchform}', htmlGenreForm($term), $tmpl);
		$array = getGenres('');
		$found = $array[$term];
		$typefun = array(
			'g' => array('lp' => '/.lp', 'url' => '', 'ft' => '$ft = formatTitle($part);')
			);
	} else {
		$page = _ZSEARCHRESULTS;
		$tmpl = str_replace('{$searchform}', htmlSearchForm($type,$term), $tmpl);
		if(!empty($term)) {
			$searchfun = array(
				'a' => '$found = searchDir($term);',
				's' => '$found = searchFiles($term);'
			);
			$typefun = array(
				'a' => array('lp' => '/.lp', 'url' => '', 'ft' => '$ft = formatTitle($part);'),
				's' => array('lp' => '', 'url' => '&amp;l=8&amp;m=1', 'ft' => '$ft = formatSongTitle($part);')
			);
			eval($searchfun[$type]);
		}
	}
	$tmpl = str_replace('{$pagetitle}', $page, $tmpl);
	$tmpl = str_replace('{$htmltitle}', $page, $tmpl);

	$checkbox = (($z_admin && $zc['cache']) || $zc['session_pls']);
	$html = "";
	if (!empty($found)) {
		$tmpl = tmpDelSec($tmpl,"SONGHEADER");
		$tmpl = str_replace('{$songs_form_opts}', "name='sresults' method='post' action='${z_self}z=1'", $tmpl);
		$num = sizeof($found);
		$temp_section = tmpGetSect($tmpl, "SONGROW");
		$temp_section = tmpDelSec($temp_section,"SONGINFO");
		$temp_section = str_replace('{$song_blurb}',"", $temp_section);
		$i = 0;
		for($j=0; $j < $num; $j++) {
			$temp_song = $temp_section;
			$title = $ppath = $slash = $surl = "";
			$dir = rtrim($found[$j]);
			$temp_song = str_replace('{$row}', $i, $temp_song);
			$song_opts = ($checkbox) ? "<input type='checkbox' name='mp3s[]' value='".getURLencodedPath($dir).$typefun[$type]['lp']."'/>" : "";
			$temp_song = str_replace('{$song_opts}', $song_opts, $temp_song);

			$arr = explode("/", $dir);
			$num2 = sizeof($arr);
			for ($m=0; $m < $num2; $m++) {
				$part = $arr[$m];
				if ($ppath != "") { $ppath = "$ppath/"; $slash = " / ";}
				$ppath .= $part;
				if ($m == $num2 - 1) {
					$surl = $typefun[$type]['url'];
					eval($typefun[$type]['ft']);
					if ($type == "a" || $zc['play']) {
						$ft = "<a href='${z_self}p=".getURLEncodedPath($ppath)."$surl' class='z_song$i'>$ft</a>";
					}
				} else {
					$ft = "<a href='${z_self}p=".getURLEncodedPath($ppath)."$surl' class='z_song$i'>".formatTitle($part)."</a>";
				}
				$title .= "$slash$ft";
			}

			$temp_song = str_replace('{$song_title}', $title, $temp_song);
			$html .= $temp_song;
			$i = ++$i % 2;
		}
		$tmpl = tmpDelSec($tmpl,"SONGROW",$html);
		$t_so = ($zc['playlists']) ? htmlPlaylistFormElements('sresults') : "&nbsp;";
		$tmpl = str_replace('{$row}',$i, $tmpl);
		$tmpl = str_replace('{$so_check}', "&nbsp;", $tmpl);
		$tmpl = str_replace('{$so_select}', "&nbsp;", $tmpl);
		$tmpl = str_replace('{$so_playlist}',$t_so, $tmpl);
	} else {
		$tmpl = tmpDelSec($tmpl,"SONGROW","<tr><td></td></tr>");
		$tmpl = tmpDelSec($tmpl,"SONGROWOPT","<tr><td></td></tr>");
		$tmpl = str_replace('{$songs_form_opts}', "action=''", $tmpl);
		$html = _ZNOTFOUND.": '".htmlentities($term)."'";
		$tmpl = str_replace('{$songs_text}', $html, $tmpl);
	}
	doModule($tmpl);
}

function pageViewEditPlaylist ($playlist, $path) {
	global $z_img_ren, $z_img_play, $z_self, $z_home, $z_img_del,
		$z_img_more, $z_admin, $z_login_url, $zc_url, $zc;

	$filename = $zc['cache_dir']."/_zina_$playlist.m3u";
	$url_play = "<a href='${z_self}l=8&amp;m=3&amp;pl=";

	$sp = false;
	if($zc['session_pls'] && $playlist == "zina_session_playlist") {
		if (isset($_SESSION['z_sp'])) {
			$songs = explode("\n",$_SESSION['z_sp']);
			unset($songs[sizeof($songs) - 1]);
			$sp = true;
		}
	}
	#TODO: used in multiple places???
	$tmpl = getTemplate("main");
	$tmpl = tmpDelSec($tmpl,"SEC-CAT");
	$tmpl = tmpDelSec($tmpl,"SEC-DIR");
	$tmpl = tmpDelSec($tmpl,"SUBDIRS");
	$tmpl = tmpDelSec($tmpl,"ALT");
	$tmpl = tmpDelSec($tmpl,"SEC-SONGS");
	$tmpl = tmpDelSec($tmpl,"SEC-MULTIMEDIA");
	$tmpl = tmpDelSec($tmpl,"GENHEADER");
	$tmpl = tmpDelSec($tmpl,"YEAR");
	$tmpl = tmpDelSec($tmpl,"GENRE");
	$width = $zc['width'];
	if (substr($width,-1) != "%") { $width = "${width}px"; }
	$tmpl = str_replace('{$width}', $width, $tmpl);
	$tmpl = str_replace('{$nav}', $z_home, $tmpl);
	$tmpl = str_replace('{$login}', $z_login_url, $tmpl);
	$tmpl = str_replace('{$admin_cfg}', $zc_url, $tmpl);
	$tmpl = str_replace('{$wmp}', "", $tmpl);
	$tmpl = str_replace('{$searchform}', htmlSearchForm(), $tmpl);
	$html = "";
	if ($sp || file_exists($filename)){ # Edit Playlist
		#TODO: use SONGROW???
		$searchform = "<form name='viewedit' method='post' action='${z_self}p=$path'>".
			htmlPlaylistFormElements('viewedit', $playlist, "l x p q v d")."</form>";
		$tmpl = str_replace('{$pagetitle}', _ZVIEWEDITPLS, $tmpl);
		$tmpl = str_replace('{$htmltitle}', _ZVIEWEDITPLS, $tmpl);
		$tmpl = str_replace('{$randomplay}', $searchform, $tmpl);

		if (!$sp) { $songs = file($filename); }
		$url_play .= rawurlencode($playlist)."'>";

		if (sizeof($songs) > 0) {
			$i = 0; #color
			$j = 1; #order

			$tmpl = str_replace('{$gen_form_opts}', "name='form01' action='${z_self}l=3&amp;p=$path'", $tmpl);
			$html .= "<tr><td colspan='3'>";
			if ($sp) {
				$sp_perc = round(strlen($_SESSION['z_sp']) / $zc['sp_len'] * 100, 1);
				$html .= "<span class='z_playlist_title'>"._ZSESSIONPLS."</span> ($sp_perc% full)";
			} else {
				$html .= "<span class='z_playlist_title'>$playlist "._ZPLAYLIST."</span>";
			}
			$html .= "<br /><br /></td></tr>";

			foreach($songs as $song) {
				$slash = $ppath = "";
				$song = rtrim($song);
				$arr = explode("/", $song);
				$num = sizeof($arr);
				$html .= "<tr class='z_row$i'><td align='center' nowrap='nowrap'>&nbsp;<input type='checkbox' name='mp3s[]' value='".getURLencodedPath($song)."' checked='checked' />&nbsp;</td>".
					"<td><input type='text' name='order[]' value='$j' size='2' class='z_form_textbox'/></td><td width='100%'>";
				#TODO: similiar to searchResults
				for ($m=0; $m < $num; $m++) {
					$part = $arr[$m];
					if ($ppath != "") { $ppath = "$ppath/"; $slash = " / ";}
					$ppath .= $part;
					if ($m == $num - 1) {
						if (preg_match("/\.(".$zc['ext_mus'].")$/i", $song) || ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $song))) {
							$surl = '&amp;l=8&amp;m=1';
							$ft = formatSongTitle($part);
							if ($zc['play']) {
								$ft = "<a href='${z_self}p=".getURLEncodedPath($ppath)."$surl' class='z_song$i'>$ft</a>";
							}
						} elseif ($part == ".lp") {
							continue;
						}
					} else {
						$ft = "<a href='${z_self}p=".getURLEncodedPath($ppath)."' class='z_song$i'>".formatTitle($part)."</a>";
					}
					$html .= "$slash$ft";
				}
				$html .= "&nbsp;</td></tr>";
				$i = ++$i % 2; $j++;
			}

			$tmpl = str_replace('{$gen_rows}', $html, $tmpl);
			$html = "<tr><td colspan='3'><input type='hidden' name='playlist' value='$playlist'/>";
			if (($z_admin && $zc['cache']) || ($zc['session_pls'] && $playlist == "zina_session_playlist")) {
				$html .= "<input type='submit' value='"._ZUPDATE."' onClick=\"SubmitForm('form01','&amp;z=4');\"/>";
			}
			$html .= "</td></tr>";
			$tmpl = str_replace('{$gen_row_opts}', $html, $tmpl);
		}
	} else { # View Playlists
		$tmpl = str_replace('{$pagetitle}', _ZPLAYLISTS, $tmpl);
		$tmpl = str_replace('{$htmltitle}', _ZPLAYLISTS, $tmpl);
		$tmpl = str_replace('{$randomplay}', htmlRandom(), $tmpl);
		$playlists = getCustomPlaylists();
		if ($zc['session_pls']) {
			if (empty($playlists)) {
				$playlists[] = "zina_session_playlist";
			} else {
				array_unshift($playlists, "zina_session_playlist");
			}
		}
		if (!empty($playlists)) {
			$i = 0;
			$delreg = ($z_admin && $zc['cache'] && $playlist != _ZSESSIONPLS);
			foreach($playlists as $playlist) {
				$pl = rawurlencode($playlist);
				if ($zc['session_pls'] && $playlist == "zina_session_playlist") {
					$playlist = _ZSESSIONPLS;
				}
				$html .= "<tr class='z_row$i'><td>";
				if ($zc['play']) { $html .= "$url_play$pl'>$z_img_play</a> &nbsp;"; }
				$html .= "<a href='${z_self}l=3&amp;z=1&amp;pl=$pl'>$z_img_more</a> &nbsp;";
				if ($delreg) {
					$html .= "<a href='${z_self}l=3&amp;z=5&amp;pl=$pl'>$z_img_del</a> &nbsp;".
						"<a href='${z_self}l=3&amp;z=6&amp;pl=$pl'>$z_img_ren</a> &nbsp;";
				}
				$html .= "<a href='${z_self}l=3&amp;z=1&amp;pl=$pl' class='z_song$i'>$playlist</a></td></tr>";
				$i = ++$i % 2;
			}
			$tmpl = str_replace('{$gen_form_opts}', "action=''", $tmpl);
			$tmpl = str_replace('{$gen_rows}', $html, $tmpl);
			$tmpl = str_replace('{$gen_row_opts}', "<tr><td></td></tr>", $tmpl);
		} else {
			$html = "<tr><td align=center>"._ZSORRYNOPLS."</td></tr>";
			$tmpl = str_replace('{$gen_form_opts}', "action=''", $tmpl);
			$tmpl = str_replace('{$gen_rows}', $html, $tmpl);
			$tmpl = str_replace('{$gen_row_opts}', "<tr><td></td></tr>", $tmpl);
		}
	}
	doModule($tmpl);
}

function pageGeneric($page, $title, $v1="", $v2="", $v3="") {
	global $z_home, $z_self, $z_self_raw, $zc;

	$tmpl = getTemplate("main");
	$tmpl = tmpDelSec($tmpl,"SEC-CAT");
	$tmpl = tmpDelSec($tmpl,"SEC-DIR");
	$tmpl = tmpDelSec($tmpl,"SUBDIRS");
	$tmpl = tmpDelSec($tmpl,"ALT");
	$tmpl = tmpDelSec($tmpl,"SEC-SONGS");
	$tmpl = tmpDelSec($tmpl,"SEC-MULTIMEDIA");
	$tmpl = tmpDelSec($tmpl,"GENHEADER");
	$tmpl = tmpDelSec($tmpl,"YEAR");
	$tmpl = tmpDelSec($tmpl,"GENRE");
	$width = $zc['width'];
	$t_nav = $z_home;

	$html = $form_opts = $row_opts = $login = $adm_cfg = $searchform = $randomplay = "";

	switch($page) {
		Case "newplaylist":
			#$v1 = $songs
			$form_opts = "action='${z_self}l=3&amp;z=2'";
			$html = "<tr><td>"._ZPLSNAME.": <input name='playlist' type='text' size='25' maxlength='30'/>&nbsp;".
				"<input type='submit' value='"._ZSUBMIT."'/></td></tr>";

			if (sizeof($v1) != 0) {
				sort($v1);
				foreach ($v1 as $song) {
					$html .= "<input type=hidden name='mp3s[]' value=\"$song\"/>";
				}
			}
			break;
		Case "renameplaylist":
			#$v1=old, $v2=new
			$error = "";
			$new = rtrim($v2);

			if (!empty($new)) {
				if (renamePlaylist($v1, $new)) {
					header("Location: ${z_self}l=3&z=1"); exit;
				} else { $error = _ZCANTRENAME; }
			}
			$form_opts = "action='${z_self}l=3&amp;z=6'";
			$html = "<tr><td><b>$error</b></td></tr>".
				"<tr><td>"._ZRENAME." '$v1'"._ZPLAYLIST.": <input name='playlist_new' type='text' size='25' maxlength='30' value='$new'/>".
				"<input type='submit' value='"._ZSUBMIT."'/><input type='hidden' name='playlist' value='$v1'/></td></tr>";
			break;
		Case "login":
			#$$v1=un, $v2=error
			$form_opts = "name='login' action='$z_self_raw&amp;l=9'";
			$html = "<tr><td colspan='2'><h3>$v2</h3></td></tr>".
				"<tr><td>"._ZUSERNAME.":</td><td><input type='text' name='un' value='$v1'/></td></tr>".
				"<tr><td>"._ZPASSWORD.":</td><td><input type='password' name='up'/></td></tr>".
				"<tr><td>&nbsp;</td><td><input type='submit' value='"._ZLOGIN."'/></td></tr>";
				$html .= "<script type='text/javascript'>document.login.un.focus()</script>";
			break;
		Case "cfg":
			global $z_dir;
			$form_opts = "action='${z_self_raw}&amp;l=21'";
			$html = "<tr><td colspan='2'><a name='top'></a><b>Notes</b>:<ul><li>'$z_dir/zina.ini.php' should not be world writeable in a production/shared server environment.".
				"<li>Currently, there is no error checking on this page!".
				"<li>GUI quickly converted from former textfile:  Not all settings are intuitive.</ul></td></tr>".
				htmlCfg($width)."<tr><td></td><td><input type='Submit' value='"._ZUPDATE."'/></td></tr>";
			break;
		Case "blurb":
			global $z_cur_dir;
			#v1=type v2=song
			$pl = $html = "";
			$lang = getSettings("other");
			if ($v1 == 1) {
				$label = $title = $lang['dir_text'];
				$file = $zc['dir_file'];
			} elseif ($v1 == 2) {
				$cats = getSettings("cat");
				$html .= "<tr><td colspan='2'>".$cats[75]['d']."</td></tr>";

				$dir_cache = $zc['cache_dir']."/_dir_cache.dat";

				if ($zc['cache'] && file_exists($dir_cache)) {
					$dirs = file($dir_cache);
					if (!empty($dirs)) {
						$html .= "<tr><td></td><td align='center'><select size='10' multiple name='sel1'>";
						foreach($dirs as $d) {
							$d = rtrim($d);
							$html .= "<option value=\"$d\">$d</option>";
						}
						$html .= "</select><br /><br /><input type='Button' onClick='AddElements(this.form.mp3s, this.form.sel1);' value='"._ZADDTO."'></td></tr>";
					}
				}

				$label = $title = $cats[75]['t'];
				$file = $zc['alt_file'];
			} elseif ($v1 == 3) {
				$label = $title = formatSongTitle($v2);#$lang['song_text'];
				$file = preg_replace("/\.(".$zc['ext_mus'].")$/i", ".txt", $v2);
				if ($zc['fake']) $file = preg_replace("/\.(".$zc['fake_ext'].")$/i", ".txt", $file);
				if ($zc['remote']) $file = preg_replace("/\.(".$zc['remote_ext'].")$/i", ".txt", $file);
				$pl = "&amp;pl=".getURLencodedPath($file);
			} elseif ($v1 == 4) {
				$label = $title = formatTitle($v2);
				$file = "$v2.txt";
				$pl = "&amp;pl=".getURLencodedPath($file);
			} else { die(_ZERROR); }

			if (file_exists("$z_cur_dir/$file")) {
				$text = implode('', file("$z_cur_dir/$file"));
			} else {
				$text = "";
			}

			$form_opts = "action='$z_self_raw&amp;l=23&amp;m=$v1$pl'";
			$html .= "<tr><td valign='top'>$label:</td><td><textarea name='mp3s' cols='70' rows='20' wrap='virtual'>".htmlentities($text)."</textarea></td></tr>";
			$row_opts = '<tr><td></td><td align="center"><input type="Submit" value="'._ZSUBMIT.'"/></td></tr>';
			break;
		Case "cfgerr":
			#v1 = cfg, v2 = file
			$html = "<tr><td><p>"._ZCACHEDIR." '$v2'.<br/>".
				"2. <a href='${z_self_raw}'>"._ZCLICK."</a></p>".
				"<form><textarea cols='80' rows='5'>$v1</textarea></form></td></tr>";
			break;
		Case "genres":
			global $z_login_url, $zc_url;
			$width = $zc['cat_width'];
			$login = $z_login_url;
			$adm_cfg = $zc_url;
			$searchform = htmlSearchForm();
			$randomplay = htmlRandom();
			$html .= htmlGenres();
			break;
		Case "mm":
			#v1 = z_path
			$path_raw = "";
			htmlNav($v1, $t_nav, $path_raw, $title, $dir_current);
			$t = getTemplate("video");
			preg_match("/\.(".$zc['mm_ext'].")$/i", $v1, $exts);
			eval("\$mm_types = array(".$zc['mm_types'].");");
			$sect = tmpGetSect($t, $mm_types[$exts[1]]['p']);
			$sect = str_replace('{$width}', "435", $sect);
			$sect = str_replace('{$height}', "340", $sect);
			$html = str_replace('{$src}', "file:///${zc['mp3_dir']}/$v1", $sect);
			break;
		default:
			$html = "<tr><td>whoops</td></tr>";
			break;
	}
	$tmpl = str_replace('{$nav}', $t_nav, $tmpl);
	$tmpl = str_replace('{$pagetitle}', $title, $tmpl);
	$tmpl = str_replace('{$htmltitle}', $title, $tmpl);
	if (substr($width,-1) != "%") { $width = "${width}px"; }
	$tmpl = str_replace('{$width}', $width, $tmpl);
	$tmpl = str_replace('{$login}', $login, $tmpl);
	$tmpl = str_replace('{$admin_cfg}', $adm_cfg, $tmpl);
	$tmpl = str_replace('{$wmp}', "", $tmpl);
	$tmpl = str_replace('{$searchform}', $searchform, $tmpl);
	$tmpl = str_replace('{$randomplay}', $randomplay, $tmpl);

	$tmpl = str_replace('{$gen_form_opts}', $form_opts, $tmpl);
	$tmpl = str_replace('{$gen_rows}', $html, $tmpl);
	$tmpl = str_replace('{$gen_row_opts}', $row_opts, $tmpl);
	doModule($tmpl);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * HTML functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function htmlHeader($module = false) {
	global $z_charset, $z_theme_dir, $zc;
	$theme_dir = "$z_theme_dir/".$zc['theme'];
	$a = "<meta http-equiv='Content-Type' content='text/html; charset=$z_charset' />".
		"<link rel='shortcut icon' href='$theme_dir/zina.ico' />".
		"<link rel='stylesheet' href='$theme_dir/index.css' type='text/css' />";

	$b = "<link rel='stylesheet' href='$theme_dir/common.css' type='text/css' />".
		"<script type='text/javascript' src='".$zc['root_dir']."/zina.js'></script>";
	return ($module) ? $b : "$a$b";
}

function doModule(&$tmpl) {
	global $zc;
	$tmpl = str_replace('{$BeNiceToZina}', htmlZina(), $tmpl);
	if ($zc['html_space']) $tmpl = preg_replace("/>\s*</s","><",$tmpl);

	if ($zc['embed'] == 0) {
		$tmpl = str_replace('{$htmlhead}', htmlHeader(), $tmpl);
		echo $tmpl;
	} else {
		$tmpl = preg_replace("/<!DOCTYPE.*?<body.*?>/si", htmlHeader(true), $tmpl);
		$tmpl = preg_replace("/<\/body>.*/si","", $tmpl);
		#POSTNUKE=2, PHPNUKE=1
		if ($zc['embed'] == 1 || $zc['embed'] == 2) {
			include("header.php");
			global $bgcolor1, $bgcolor2, $bgcolor4;
			$bgc02 = ($type == 1) ? $bgcolor4 : $bgcolor2;
			OpenTable();
			echo "$tmpl<style type='text/css'>.z_row0 { background-color:$bgcolor1; }.z_row1 { background-color:$bgc02; }</style>";
			CloseTable();
			include("footer.php");
		} elseif ($zc['embed'] == 3) { #XOOPS
			global $xoopsUser, $xoopsLogger, $xoopsConfig;
			include_once XOOPS_ROOT_PATH."/header.php";
			echo $tmpl;
			include_once XOOPS_ROOT_PATH."/footer.php";
		} elseif ($zc['embed'] == 4) { #MAMBO
			echo $tmpl;
		}
	}
}

function htmlZina() {
	global $z_ver, $z_t1;
	$time = " (".round((array_sum(explode(' ', microtime())) - $z_t1),3)."s)";
	return "<a class='z_foot' title='Zina' href='http://www.pancake.org/zina/'>Zina v.$z_ver$time</a>";
}

function htmlPages($current, $num) {
	global $z_img_tmp, $z_self_raw, $zc;
	$img_back = "${z_img_tmp}back.gif' alt='"._ZSTART."' title='"._ZSTART."' align='middle'/>";
	$img_back_un = "${z_img_tmp}back_un.gif' alt='' align='middle'/>";
	$img_forward = "${z_img_tmp}forward.gif' alt='"._ZEND."' title='"._ZEND."' align='middle'/>";
	$img_forward_un = "${z_img_tmp}forward_un.gif' alt='' align='middle'/>";
	$self = preg_replace("/page=\d&/", "", $z_self_raw);

	if ($num > 0 && $num > $zc['cat_pp']) {
		$total = ceil($num/$zc['cat_pp']);
		$pages = "<span class='z_pages'>";
		for($i=1; $i <= $total; $i++) {
			$pages .= ($current == $i) ? "<b>$i</b> &middot; " : "<a href=\"${self}&amp;page=$i\" class=\"z_pages\">$i</a> &middot; ";
		}
		$arr['b'] = ($current != 1) ? "<a href=\"$self&amp;page=1\" class=\"z_pages\">${img_back}</a>" : $img_back_un;
		$arr['f'] = ($current == $total) ? $img_forward_un : "<a href=\"$self&amp;page=$total\" class=\"z_pages\">${img_forward}</a>";
		$arr['pages'] = substr($pages,0,-9)."</span>";
	} else { $arr = null; }
	return $arr;
}

function htmlCategory($dirs) {
	global $z_self, $z_img_new, $zc;
	if (empty($dirs)) return "<tr><td></td></tr>";
	$cat_cols = $zc['cat_cols'];
	$row = 0;
	$items = sizeof($dirs);
	$rows_in_col = ceil($items/$cat_cols);
	if ($rows_in_col < $cat_cols) { $cat_cols = ceil($items/$rows_in_col); }
	$col_width = round(100 / $cat_cols);
	$now = time();
	$diff = $zc['new_time']*60*60*24;

	$html = "<tr>";
	$i = 0;
	foreach ($dirs as $subdir => $opts) {
		if ($row == 0) {
			$class = ($cat_cols != ++$i) ? ' class="z_artistcols"' : '';
			$html .= "<td$class valign='top' nowrap='nowrap' width='$col_width%'>";
		}
		if ($zc['new_highlight'] && ($now - $opts['mtime'] < $diff)) {
			if ($zc['new_img']) {
				$new_end = $z_img_new;
				$new_beg = "";
			} else {
				$new_beg = $zc['new_beg'];
				$new_end = $zc['new_end'];
			}
		} else {
			$new_beg = $new_end = "";
		}

		$title = formatTitle(basename($subdir));
		if (strlen($title) > $zc['cat_trunc']) {
			$ht = " title=\"$title\"";
			$title = substr($title,0,$zc['cat_trunc'])."...";
		} else {
			$ht = "";
		}

		$html .= "<a class='z_artist' href='${z_self}p=".rawurlencode($subdir)."' $ht>$new_beg$title$new_end</a><br />";
		$row = ++$row % $rows_in_col;
		if ($row == 0) { $html .= "</td>"; }
	}
	if ($row != 0) $html .= "</td>";
	$html .= "</tr>";
	return $html;
}

#TODO: combine with htmlCategories
function htmlGenres() {
	global $z_self, $zc;

	$cat_cols = $zc['cat_cols'];
	$row = 0;
	$genres = getGenres('s');
	$items = sizeof($genres);
	$rows_in_col = ceil($items/$cat_cols);
	if ($rows_in_col < $cat_cols) { $cat_cols = ceil($items/$rows_in_col); }
	$col_width = round(100 / $cat_cols);

	$html = "<tr>";
	$i = 0;
	foreach ($genres as $g) {
		if ($row == 0) {
			$class = ($cat_cols != ++$i) ? ' class="z_artistcols"' : '';
			$html .= "<td$class valign='top' nowrap='nowrap' width='$col_width%'>";
		}
		$html .= "<a class='z_artist' href='${z_self}l=13&amp;pl=".rawurlencode($g)."'>".
			strTruncate($g,"...",$zc['cat_trunc'])."</a><br />";

		$row = ++$row % $rows_in_col;
		if ($row == 0) { $html .= "</td>"; }
	}
	if ($row != 0) $html .= "</td>";
	$html .= "</tr>";
	return $html;
}

function htmlDirList($subdirs) {
	global $z_self, $z_img_play, $z_img_lofi, $z_img_more, $z_admin,
		$z_img_down, $z_img_new, $zc;

	$now = time();
	$diff = $zc['new_time']*60*60*24;
	$num = 0;
	$dir_list_len = $zc['dir_list_len'];
	if ($zc['low']) { $dir_list_len -= 2; }
	$html = "";
	$checkbox = ($z_admin || ($zc['playlists'] && $zc['session_pls']));
	foreach ($subdirs as $subdir => $opts) {
		$dir_len = $dir_list_len;
		$dir = false;
		$image = $opts['image'];
		$new_beg = $new_end = "";
		if (substr($subdir, -1) == "/") {
			$dir = true;
			$subdir = substr($subdir, 0, -1);
		}

		$path_raw = getURLencodedPath($subdir);

		$href = "<a href='${z_self}p=$path_raw";
		if (!$dir) {
			if ($zc['download'] && $zc['cmp_sel']) { $html .= "$href/.lp&amp;l=8&amp;m=9&amp;c=0'>$z_img_down</a> &nbsp;"; }
			if ($zc['play']) { $html .= "$href&amp;l=8&amp;m=0'>$z_img_play</a> &nbsp;"; }
			if ($zc['low'] && ($zc['resample'] || $opts['lofi'])) { $html .= "$href&amp;l=8&amp;m=0&amp;lf=true'>$z_img_lofi</a> &nbsp;"; }
			if ($checkbox) { $html .= "<input type='checkbox' name='mp3s[]' value='$path_raw/.lp'/> &nbsp;"; }
			$num++;
			if ($zc['new_highlight'] && isset($opts['mtime']) && ($now - $opts['mtime'] < $diff)) {
				$dir_len -= 5;
				if ($z_img_new) {
					$new_end = $z_img_new;
				} else {
					$new_beg = $zc['new_beg'];
					$new_end = $zc['new_end'];
				}
			}
		}
		$title = formatTitle(basename($subdir));
		if (strlen($title) > $dir_len) {
			$ht = " title=\"$title\"";
			$title = substr($title,0,$dir_len)."...";
		} else {
			$ht = "";
		}
		$html .= "$href'$ht>$new_beg$title$new_end</a><br />";
	}
	$arr['num'] = $num;
	$arr['list'] = $html;
	return $arr;
}

function htmlDirImages($subdirs) {
	global $z_self, $zc;

	$wt = 0;
	$col_width = round(100 / $zc['subdir_cols']);
	if ($zc['subdir_center']) {
		$align[0] = "center";
		$align[$zc['subdir_cols'] - 1] = "center";
	} else {
		$align[0] = "left";
		$align[$zc['subdir_cols'] - 1] = "right";
	}

	for($i=1; $i < $zc['subdir_cols'] - 1; $i++) { $align[$i] = "center"; }
	$first = 1;
	$html = "";
	foreach($subdirs as $subdir => $opts) {
		if ($wt==0) {
			if ($first) {
				$html .= "<tr>";
				$first = false;
			} else {
				$html .= "</tr><tr>";
			}
		}
		if (substr($subdir, -1) == "/") { $subdir = substr($subdir, 0, -1); }
		$title = formatTitle(basename($subdir));

		if (!empty($opts['image']) || $zc['subdir_img_missing']) {
			$html .= "<td width='$col_width%' align='${align[$wt]}' valign='top'>".
				"<a href='${z_self}p=".getURLencodedPath($subdir)."'>".htmlImage($opts['image'], $subdir, $title, 'sub');

			if ($zc['subdir_img_cap']) { $html .= "<br /><div class='z_img_cap'>$title</div>"; }
			$html .= "</a></td>";
		} else { $wt--; }

		if ($wt==$zc['subdir_cols']) { $html .= "</tr>"; }
		$wt = ++$wt % $zc['subdir_cols'];
	}

	if ($wt <> 0 ) {
		for ($i = $wt; $i < $zc['subdir_cols']; $i++) { $html .= "<td width='$col_width%'>&nbsp;</td>"; }
	}
	$html .= "</tr>";
	return $html;
}

function htmlImage($image, $path, $title, $type, $url=false, $att="") {
	global $z_self, $zc;
	if ($type == 'dir') {
		$it = 0;
		$css = "z_dir_image";
		$id=" id='zImage' ";
	} else { #subdir
		$type= 'sub';
		$it = 1;
		$css = "z_subdir_image";
		$id = '';
	}

	$t = "";
	if (empty($image)) {
		$path_raw = "";
		$image = "missing_$type.jpg";
		if ($zc[$type.'_img_txt']) {
			$t = "&amp;p=".rawurlencode($title)."&amp;m=".$zc["${type}_img_txt_color"];
		}
		$miss = true;
	} else {
		$miss = false;
		$path_raw = (!empty($path)) ? getURLencodedPath2($path)."/" : "";
	}

	if ($zc["res_${type}_img"] && preg_match("/\.(".$zc['res_in_types'].")$/i", $image)) {
		$img_src = "${z_self}l=7&amp;it=$it&amp;img=$path_raw$image$t";
	} elseif ($zc['stream_int']) {
		$img_src = "${z_self}l=11&amp;img=$path_raw$image";
	} else { #NORMAL
		if ($miss) {
			global $z_theme_dir;
			$img_src = "$z_theme_dir/".$zc['theme']."/images/$image";
		} else {
			$img_src = $zc['www_path']."/$path_raw$image";
		}
	}
	return ($url) ? $img_src : "<img src=\"$img_src\"${id}border='0' class='$css' $att alt=\"$title\" title=\"$title\" />";
}

function htmlSongs(&$tmpl, $path_raw, $songs, $custom_pls = false, $c_pls_arr = null, $lofi = false, $various, $dir_write) {
	global $z_url_base, $z_self, $z_img_play, $z_img_lofi, $z_img_down,
		$z_admin, $z_img_new, $z_img_edit, $z_self_raw, $zc;

	$i = 0;
	$check_boxes = false;
	$now = time();
	$diff = $zc['new_time']*60*60*24;

	if (($z_admin && $zc['cache']) || ($zc['playlists'] && $zc['session_pls']) || $zc['play_sel'] || $zc['cmp_sel']) {
		$check_boxes = true;
	}
	$tmpl = str_replace('{$songs_form_opts}', "name='songs' method='post' action='${z_self}p=$path_raw'", $tmpl);

	$temp_section = tmpGetSect($tmpl, "SONGROW");
	$html = "";

	foreach ($songs as $song => $opts) {
		$temp_song = $temp_section;
		$valign = ($opts['blurb']) ? "valign='top'" : "";
		$song_raw = getURLencodedPath($song);
		$song_title = formatSongTitle(basename($song));
		$temp_song = str_replace('{$row}', $i, $temp_song);
		$temp_song = str_replace('{$valign}', $valign, $temp_song);
		$t_blurb = ($dir_write) ? "${opts['blurb']} <a href='${z_self_raw}&amp;pl=".getURLencodedPath(basename($song))."&amp;l=22&amp;m=3'>$z_img_edit</a>" : $opts['blurb'];
		$temp_song = str_replace('{$song_blurb}', $t_blurb, $temp_song);
		$t_song_opts = "";
		$remote = false;

		if ($zc['fake'] && isset($opts['fake'])) {
			$fi = ($zc['mp3_info']) ? "<td colspan='4'>&nbsp;</td>" : "";
			$temp_song = tmpDelSec($temp_song,"SONGINFO", $fi);
			$t_song_title = preg_replace("/\.(".$zc['fake_ext'].")$/i","",$song_title);
		} else {
			$url_play = $url_end = "";

			if ($zc['mp3_info'] || $zc['mp3_id3']) {
				if ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $song)) {
					$mp3 = new remoteFile($zc['mp3_dir']."/$song", $zc['mp3_info'], $zc['mp3_id3']);
					$remote = true;
				} else {
					$mp3 = new mp3($zc['mp3_dir']."/$song", $zc['mp3_info'], $zc['mp3_id3'], $zc['mp3_info_faster']);
				}
			}

			if ($check_boxes) {
				$checked = ($custom_pls && in_array($song, $c_pls_arr)) ? " checked='checked'" : "";
				$t_song_opts .= "<input type='checkbox' name='mp3s[]' value='$song_raw'$checked /> &nbsp; ";
			} else {
				$t_song_opts .= "&nbsp;";
			}

			if ($zc['download']) {
				if ($remote) {
					if (isset($mp3->download)) $t_song_opts .= "<a href='".$mp3->download."'>$z_img_down</a> &nbsp;&nbsp; ";
				} else {
					$surl = ($zc['stream_int']) ? "${z_self}l=12&amp;p=$song_raw" : "$z_url_base/".getURLencodedPath2($song);
					$t_song_opts .= "<a href='$surl'>$z_img_down</a> &nbsp;&nbsp; ";
				}
			}

			if ($zc['play']) {
				$url_play = "<a href='${z_self}l=8&amp;p=$song_raw&amp;m=1' class='z_song$i'>";
				$url_end = "</a>";
				$t_song_opts .= "$url_play$z_img_play</a> &nbsp;";
			}
			if ($zc['low']) {
				$tmp = "&nbsp;<a href='${z_self}l=8&amp;p=";
				if (isset($opts['lofi'])) {
					$t_song_opts .= "$tmp".preg_replace("/\.(".$zc['ext_mus'].")$/i", $zc['low_suf'].".$1", $song_raw).
						"&amp;m=1'>$z_img_lofi</a> &nbsp;";
				} elseif($zc['resample'] && preg_match("/\.(".$zc['ext_enc'].")$/i", $song)) {
					$t_song_opts .= "$tmp$song_raw&amp;m=6'>$z_img_lofi</a> &nbsp;";
				}
			}
			if ($zc['new_highlight'] && isset($opts['mtime']) && ($now - $opts['mtime'] < $diff)) {
				if ($zc['new_img']) {
					$new_end = $z_img_new;
					$new_beg = "";
				} else {
					$new_beg = $zc['new_beg'];
					$new_end = $zc['new_end'];
				}
			} else {
				$new_beg = $new_end = "";
			}

			$t_song_title = "$url_play$new_beg";
			if ($zc['mp3_id3'] && $mp3->tag) {
				if ($various && !empty($mp3->artist)) $t_song_title .= "$mp3->artist - ";
				$t_song_title .= $mp3->title;
			} else {
				$t_song_title .= $song_title;
			}
			$t_song_title .= "$new_end$url_end";
			if ($zc['mp3_info']) {
				if ($mp3->info == 1) {
					$t_time = $mp3->time;
					$t_bitrate = "$mp3->bitrate kbps";
					$t_frequency = round($mp3->frequency/1000,1). " kHz";
					$t_size = sprintf("%.2f", round($mp3->filesize/1000000,2))." Mb";
				} else {
					$t_size = (!$remote) ? sprintf("%.2f", round($mp3->filesize/1000000,2))." Mb" : "&nbsp;";
					$t_time = $t_bitrate = $t_frequency = "&nbsp;";
				}
				$temp_song = str_replace('{$song_time}', $t_time, $temp_song);
				$temp_song = str_replace('{$song_bitrate}', $t_bitrate, $temp_song);
				$temp_song = str_replace('{$song_frequency}', $t_frequency, $temp_song);
				$temp_song = str_replace('{$song_size}', $t_size, $temp_song);
			} else {
				$temp_song = tmpDelSec($temp_song,"SONGINFO");
			}
		}
		$temp_song = str_replace('{$song_title}', $t_song_title, $temp_song);
		$temp_song = str_replace('{$song_opts}', $t_song_opts, $temp_song);
		$html .= $temp_song;
		$i = ++$i % 2;
	}
	$tmpl = tmpDelSec($tmpl,"SONGROW",$html);

	$t_so_check = $t_so_sel = $t_so_pls = "";
	if ($z_admin && $zc['cache']) {
		$submit = ($custom_pls) ? _ZUPDATECUSTOM : _ZCREATECUSTOM;
		$t_so_check .= "<input type='submit' value='$submit ' onClick=\"SubmitForm('songs','&amp;l=3&amp;z=3',false);\"/>";
	}

	if ($check_boxes) {
		$t_so_check .= "&nbsp; "._ZCHECK.": &nbsp;<a href='javascript:void 0;' onclick=\"CheckBoxes('songs',true);\">"._ZALL."</a> | ".
			"<a href='javascript:void 0;' onclick=\"CheckBoxes('songs',false);\">"._ZNONE."</a>";

		if ($zc['play_sel'] || $zc['cmp_sel']) {
			$url_beg2 = " &nbsp; <a href=\"javascript:CheckIt('songs',";
			$t_so_sel .= _ZSELECTED.": ";
			$err = _ZERR_SEL;
			if ($zc['play'] && $zc['play_sel']) { $t_so_sel .= "$url_beg2'${z_self}l=8&amp;m=7',true,'$err');\">$z_img_play</a>"; }
			if ($lofi) { $t_so_sel .= "$url_beg2'${z_self}l=8&amp;m=7&amp;lf=true',true,'$err');\">$z_img_lofi</a>"; }
			if ($zc['download'] && $zc['cmp_sel']) { $t_so_sel .= "$url_beg2'&amp;l=8&amp;m=8',false,'$err');\">$z_img_down</a>"; }
		}
	}

	$t_so_pls = ($zc['playlists']) ? htmlPlaylistFormElements('songs') : "&nbsp;";
	$tmpl = str_replace('{$row}',$i, $tmpl);
	$tmpl = str_replace('{$so_check}',$t_so_check, $tmpl);
	$tmpl = str_replace('{$so_select}',$t_so_sel, $tmpl);
	$tmpl = str_replace('{$so_playlist}',$t_so_pls, $tmpl);
}

function htmlNav($path, &$nav, &$path_raw, &$title, &$dir_current) {
	global $z_self;
	$tmp = explode("/",$path);

	$tmp_size = sizeof($tmp);
	for ($i = 0; $i < $tmp_size; $i++) {
		if ($path_raw != "") { $path_raw = "$path_raw/"; }
		$path_raw .= rawurlencode($tmp[$i]);
		$title .= formatTitle($tmp[$i]).": ";
		if ($i != $tmp_size - 1) {
			$nav .= "&nbsp;<a href='${z_self}p=$path_raw' class='z_nav'>${tmp[$i]}</a> :";
		}
		$dir_current = $tmp[$i];
	}
	$path_raw = empty($path_raw) ? "" : "$path_raw/";
	$title = substr($title, 0, -2);
	if (substr($nav, -1, 1) == ":") $nav = substr($nav,0,-1);
}

function htmlMM(&$tmpl, $songs, $dir_write) {
	global $z_url_base, $z_self, $z_img_play, $z_img_down, $z_img_tmp,
		$z_admin, $z_img_new, $z_img_edit, $z_self_raw, $zc, $z_theme_dir, $z_play_local;

	$img_play = "${z_img_tmp}play_video.gif' alt='"._ZPLAY."' title='"._ZPLAY."' align='top'/>";
	$i = 0;
	$now = time();
	$diff = $zc['new_time']*60*60*24;

	eval("\$mm_types = array(".$zc['mm_types'].");");
	$temp_section = tmpGetSect($tmpl, "MMROW");
	$html = "";
	$local = ($_SERVER["SERVER_ADDR"] == $_SERVER["REMOTE_ADDR"]);

	foreach ($songs as $song => $opts) {
		$temp_song = $temp_section;
		$valign = ($opts['blurb']) ? "valign='top'" : "";
		$song_raw = getURLencodedPath($song);
		$song_title = formatSongTitle(basename($song));
		$temp_song = str_replace('{$mmrow}', $i, $temp_song);
		$temp_song = str_replace('{$valign}', $valign, $temp_song);
		$t_blurb = ($dir_write) ? "${opts['blurb']} <a href='${z_self_raw}&amp;pl=".getURLencodedPath(basename($song))."&amp;l=22&amp;m=4'>$z_img_edit</a>" : $opts['blurb'];
		$temp_song = str_replace('{$mm_blurb}', $t_blurb, $temp_song);
		$t_song_opts = "";
		$remote = false;
		$url_play = $url_end = "";
		preg_match("/\.(".$zc['mm_ext'].")$/i", $song, $exts);

		if ($zc['mm_down']) {
			$surl = ($zc['stream_int']) ? "${z_self}l=25&amp;p=$song_raw" : "$z_url_base/".getURLencodedPath2($song);
			$t_song_opts .= "<a href='$surl'>${z_img_tmp}mm/".
				"${exts[1]}.gif' alt='"._ZDOWNLOAD."' title='"._ZDOWNLOAD."' align='top'/></a> &nbsp;&nbsp; ";
		}
		if ($local && isset($mm_types[$exts[1]]['p'])) {
			$url_play = "<a href='${z_self}l=24&amp;p=$song_raw&amp;m=1' class='z_song$i'>";
			$url_end = "</a>";
			$t_song_opts .= "$url_play$img_play</a> &nbsp;";
		}
		if ($zc['new_highlight'] && isset($opts['mtime']) && ($now - $opts['mtime'] < $diff)) {
			if ($zc['new_img']) {
				$new_end = $z_img_new;
				$new_beg = "";
			} else {
				$new_beg = $zc['new_beg'];
				$new_end = $zc['new_end'];
			}
		} else {
			$new_beg = $new_end = "";
		}

		$t_song_title = "$url_play$new_beg$song_title$new_end$url_end";

		$temp_song = str_replace('{$mm_title}', $t_song_title, $temp_song);
		$temp_song = str_replace('{$mm_opts}', $t_song_opts, $temp_song);
		$html .= $temp_song;
		$i = ++$i % 2;
	}
	$tmpl = tmpDelSec($tmpl,"MMROW",$html);
}

#TODO: move
class remoteFile {
	function remoteFile($file, $info=false, $tag=false) {
		$this->tag = $this->info = $this->filesize = 0;

		$arr = get_meta_tags($file);
		$this->url = $arr['url'];
		$this->download = isset($arr['download']) ? $arr['download'] : null;

		if ($info) {
			if (isset($arr['time'])) {
				$this->time = $arr['time'];
				$this->filesize = isset($arr['filesize']) ? $arr['filesize'] : 0;
				$this->bitrate = isset($arr['bitrate']) ? $arr['bitrate'] : 0;
				$this->frequency = isset($arr['frequency']) ? $arr['frequency'] : 0;
				$this->info = 1;
			}
		}
		if ($tag) {
			if (isset($arr['title'])) {
				$this->title = $arr['title'];
				$this->artist = isset($arr['artist']) ? $arr['artist'] : "";
				$this->album = isset($arr['album']) ? $arr['album'] : "";
				$this->year = isset($arr['year']) ? $arr['year'] : "";
				$this->genre = isset($arr['genre']) ? $arr['genre'] : "";
				$this->tag = 1;
			}
		}
	}
}

function htmlCfg($width) {
	$fields = getSettings("cfg");
	$cats = getSettings("cat");
	$titles = getSettings("titles");
	$other = getSettings("other");
	$ret = getHtmlForm($fields);

	$html = $nav = "";
	foreach($ret as $cat=>$arr) {
		$nav .= "<a href='#$cat'>".$cats[$cat]['t']."</a> | ";
		$html.= "<tr><td colspan='2'><a name='$cat'></a><div class='z_cfg_cat' style='width:$width;'>".
			"<span class='z_cfg_left'>".$cats[$cat]['t']."</span><span class='z_cfg_right'><a href='#top' class='z_cfg_r_txt'>".$other['top']."</a></span></div><br style='clear:both;'/>".$cats[$cat]['d']."</td></tr>";
		if ($cat == 120) {
			$html.= "<tr><td colspan='2'>X: <select><option selected>${other['forref']}</option>";
			$tf = array(1=>_ZTRUE, 0=>_ZFALSE);
			foreach($fields as $field) {
				if (isset($field['opts']) && $field['opts'] == $tf) {
					$html .= "<option>${field['id']} &nbsp; (${titles[$field['id']]})</option>";
				}
			}
			$html.= "</select></td></tr>";
		}
		foreach($arr as $opt) {
			$html .= "<tr><td valign='top'>".$titles[$opt['name']].":</td><td valign='top'>".$opt['value']."</td></tr>";
		}
	}
	$nav = substr($nav,0,-3);
	return "<tr><td colspan='2'>$nav</td></tr>$html";
}

function htmlPlaylistFormElements($form, $playlist_sel = "", $type = "l a x p q v") {
	global $z_self, $z_img_play, $z_img_more, $z_img_add, $z_img_del,
		$z_img_pls, $z_img_lofi, $z_admin, $zc;

	$options = explode(" ", $type);
	$playlists = getCustomPlaylists();

	if (!$z_admin && (empty($playlists) && !$zc['session_pls'])) return "";
	$tmp = "<a href=\"javascript:SubmitForm('$form',";
	$tmp1 = "<a href=\"javascript:CheckIt2('$form',";
	$sess = (isset($_SESSION['z_sp']) && strlen($_SESSION['z_sp']) > 0) ? 1 : 0;
	$error = _ZERR_NOPLS;
	$error1 = _ZERR_NOTHING;

	$elements = array(
		'd' => "$tmp'&amp;l=3&amp;z=5',false);\">$z_img_del</a>&nbsp;",
		'a' => "$tmp1'&amp;l=3&amp;z=2',false, '$error1', $sess, 'add');\">$z_img_add</a>&nbsp;",
		'v' => "$tmp'&amp;l=3&amp;z=1',false);\">$z_img_more</a>&nbsp;",
		'p' => "$tmp1'&amp;l=8&amp;m=3&amp;lf=0',false,'$error', $sess);\">$z_img_play</a>&nbsp;",
		'q' => "$tmp1'&amp;l=8&amp;m=3&amp;lf=true',false,'$error', $sess);\">$z_img_lofi</a>&nbsp;",
		'l' => "<a href='${z_self}l=3&amp;z=1'>$z_img_pls</a>&nbsp;",
		'x' => '<select class="z_form_select" name="playlist">'
		);

	if (!$zc['play']) { $elements['p'] = ""; }

	if (!$z_admin || !$zc['cache']) {
		$elements["d"] = "";
		if (!$zc['session_pls']) $elements["a"] = "";
	}
	if (!$zc['low']) { $elements["q"] = ""; }

	if ($z_admin && strstr($type,"a") && $zc['cache']) {
		$elements["x"] .= '<option value="new_zina_list"> - '._ZNEWPLS.' - </option>';
	}

	if ($zc['session_pls']) {
		$elements["x"] .= '<option value="zina_session_playlist"> - '._ZSESSIONPLS.' - </option>';
	}

	if (!empty($playlists)) {
		foreach($playlists as $playlist) {
			$selected = ($playlist == $playlist_sel) ? " selected='selected'" : "";
			$elements["x"] .= "<option value=\"$playlist\"$selected>".strTruncate($playlist,"...",15)."</option>";
		}
	}
	$elements["x"] .= "</select>&nbsp;";
	$html = "";
	foreach($options as $option) {
		$html .= $elements[$option];
	}
	return $html;
}

function htmlSearchForm($type="", $term="") {
	global $z_self, $z_img_more, $zc;

	if ($zc['search']) {
		$selected = array("a" => null, "s" => null);
		$selected[$type] = " selected='selected'";

		return "<form name='sform' method='post' action='${z_self}l=4' class='z_small'>".
			"<input name='search' type='text' size='10' class='z_form_textbox' value='$term'/><select name='type' class='z_form_select'>".
			"<option value='a'$selected[a]>"._ZART_TIT."</option><option value='s'$selected[s]>"._ZSONG."</option></select>".
			"&nbsp;<a href='javascript:document.sform.submit();'>$z_img_more</a></form>".
			"<script type='text/javascript'>document.sform.search.focus();</script>";
	} else {
		return "&nbsp;";
	}
}

function htmlGenreForm($g) {
	global $zc, $z_img_more, $z_self;
	$html = "";
	if ($zc['genres']) {
		$html = "<form name='sform' method='post' action='${z_self}l=13' class='z_small'>".
			"<select class='z_form_select' name='playlist' onchange='this.form.submit();'>";
		$genres = getGenres('s');
		foreach($genres as $genre) {
			$sel = ($genre == $g) ? " selected='selected'" : "";
			$html .= "<option value=\"$genre\"$sel>$genre</option>";
		}
		$html .= "</select>&nbsp;<a href='javascript:document.sform.submit();'>$z_img_more</a></form>";
	}
	return $html;
}

function htmlRandom() {
	global $z_self, $z_img_lofi, $z_img_play, $zc;
	$form = "";

	if ($zc['play'] && $zc['random']) {
		$r_type = array(4 => _ZALBUMS,5 => _ZSONGS);

		$all = $zc['cache'] ? "<option value='0'>"._ZALL : "";
		$low = "";
		if ($zc['low']) {
			$low = "&nbsp;<a href=\"javascript:SubmitForm('random','${z_self}l=8&amp;lf=true', true);\">$z_img_lofi</a>";
		}
		$form = "<form class='z_small' name='random' method='post' action='${z_self}'>"._ZRANDOM.": ".
			"<select class='z_form_select' name='n'>";
		foreach($zc['ran_opts'] as $option) {
			$selected = "";
			if ($option == $zc['ran_opts_def']) $selected = " selected='selected'";
			$form .= "<option value='$option'$selected>";
			$form .= ($option != 0) ? $option : _ZALL;
			$form .= "</option>";
		}
		$form .= "</select><select class='z_form_select' name='m'>";
		foreach($r_type as $key => $type) {
			$selected = "";
			if ($type == $zc['ran_def']) $selected = " selected='selected'";
			$form .= "<option value='$key'$selected>$type</option>";
		}
		$form .= "</select>";

		if ($zc['genres']) {
			$genres = getGenres('s');
			$form .= "<select class='z_form_select' name='playlist'><option value='zina' selected>"._ZALL."</option>";
			foreach($genres as $genre) {
				$form .= "<option value='$genre'>".strTruncate($genre,"...",20)."</option>";
			}
			$form .= "</select>";
		}

		$form .= "&nbsp;<a href=\"javascript:SubmitForm('random','${z_self}l=8',true);\">$z_img_play</a>$low</form>";
	}
	return $form;
}

function htmlAMG($text="") {
	return "<form action='http://www.allmusic.com/cg/amg.dll' method='post' target='AMG'>".
		"<input type='hidden' name='P' value='amg'/>".
		"<input class='z_form_textbox' type='text' name='sql' size='15' maxlength='30' value=\"$text\"/>".
		"<select name='opt1' class='z_form_select'><option value='1'>"._ZARTISTS."</option><option value='2'>"._ZALBUMS."</option><option value='3'>"._ZSONGS."</option></select>".
		"<input type='submit' class='z_small' value='AMG'/></form>";
}

function formatSongTitle($song) {
	global $zc;
	$tmp = preg_replace("/\.(".$zc['ext_mus'].")$/i","",preg_replace($zc['song_regex'],"",rtrim($song)));
	if ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $tmp)) {
		$tmp = preg_replace("/\.(".$zc['remote_ext'].")$/i","",$tmp);
	}
	return str_replace($zc['song_srch'],$zc['song_repl'],$tmp);
}

function formatTitle($title) {
	global $zc;
	$tmp = preg_replace($zc['dir_regex'],"",rtrim($title));
	return str_replace($zc['dir_srch'],$zc['dir_repl'],$tmp);
}

function strSortIgnore($a, $b) {
	global $zc;
	return strnatcasecmp(preg_replace("/^(".$zc['dir_si_str'].") /i",'',$a), preg_replace("/^(".$zc['dir_si_str'].") /i",'',$b));
}

function strTruncate($str, $replace, $length) {
	return (strlen($str) > $length) ? substr($str,0,$length).$replace : $str;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * GET functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function getDir($dir, &$images_found, $category, $subdir_images) {
	global $zc;
	$subdirs = $files = $images = $text = $mm = null;
	$lofi_found = false;
	$low_look = ($zc['low_lookahead'] && !$category);

	$fdir = $zc['mp3_dir']."/$dir";
	$d = dir($fdir) or die(_ZERROR);
	if (!empty($dir)) { $dir = "$dir/"; }

	while($entry = $d->read()) {
		if ($entry == "." || $entry == "..") { continue; }
		$path = "$dir$entry";
		$cdir = "$fdir/$entry";
		if (is_dir($cdir) && substr($entry,0,1) != $zc['dir_skip']) {
			$subdirs[$path]['lofi'] = true;
			if ($subdir_images) {
				$subdirs[$path]['image'] = getDirImage($cdir, $images_found);
			} else {
				$subdirs[$path]['image'] = null;
			}
			if ($low_look) { $subdirs[$path]['lofi'] = getSubDirLofi($cdir); }
			if ($zc['new_highlight']) { $subdirs[$path]['mtime'] = filemtime($cdir); }
		} else {
			if (preg_match("/\.(".$zc['ext_mus'].")$/i", $entry)) {
				if ($zc['low'] && preg_match("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", $entry)) {
						$path = preg_replace("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", ".$2", $path);
						$lofi_found = true;
						$files[$path]['lofi'] = 1;
				} else {
					$song_blurb = null;
					if ($zc['song_blurbs']) {
						$sbfile = "$fdir/".preg_replace("/\.(".$zc['ext_mus'].")$/i", ".txt", $entry);
						if (file_exists($sbfile)) { $song_blurb = implode("", file($sbfile)); }
					}
					$files[$path]['blurb'] = $song_blurb;
				}
				if ($zc['new_highlight']) { $files[$path]['mtime'] = filemtime($cdir); }
			} elseif (preg_match("/\.(".$zc['ext_graphic'].")$/i", $entry)) {
				$images[] = rawurlencoder($entry);
			} elseif ($zc['fake'] && preg_match("/\.(".$zc['fake_ext'].")$/i", $entry)) {
				$song_blurb = null;
				if ($zc['song_blurbs']) {
					$sbfile = "$fdir/".preg_replace("/\.(".$zc['fake_ext'].")$/i", ".txt", $entry);
					if (file_exists($sbfile)) { $song_blurb = implode("", file($sbfile)); }
				}
				$files[$path]['blurb'] = $song_blurb;
				$files[$path]['fake'] = 1;
			#TODO: looks amazingly like fake above!
			} elseif ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $entry)) {
				$song_blurb = null;
				if ($zc['song_blurbs']) {
					$sbfile = "$fdir/".preg_replace("/\.(".$zc['remote_ext'].")$/i", ".txt", $entry);
					if (file_exists($sbfile)) { $song_blurb = implode("", file($sbfile)); }
				}
				$files[$path]['blurb'] = $song_blurb;
			#TODO: looks amazingly like fake above!
			} elseif ($zc['mm'] && preg_match("/\.(".$zc['mm_ext'].")$/i", $entry)) {
				$song_blurb = null;
				if ($zc['song_blurbs']) {
					$sbfile = "$fdir/$entry.txt";
					if (file_exists($sbfile)) { $song_blurb = implode("", file($sbfile)); }
				}
				$mm[$path]['blurb'] = $song_blurb;
				if ($zc['new_highlight']) { $mm[$path]['mtime'] = filemtime($cdir); }
			}
		}
	}
	$d->close();

	if (!empty($subdirs)) {
		($zc['dir_sort_ignore']) ? uksort($subdirs, "strSortIgnore") : uksort($subdirs, "strnatcasecmp");
	}
	if (!empty($files)) { uksort($files, "strnatcasecmp"); }
	return array('subdirs'=>$subdirs, 'files'=>$files , 'text'=>$text, 'images'=>$images, 'lofi'=>$lofi_found, 'mm'=>$mm);
}

function getHtmlForm(&$fields) {
	global $zc;
	$i = 0;
	foreach($fields as $field) {
		$name = $field['id'];
		$type = $field['type'];
		$value = ($field['def'] == $zc[$name]) ? $field['def'] : $zc[$name];
		$item = "";
		switch($type) {
			Case "textarea":
				$item = "<textarea name='$name' cols='50' rows='8'>$value</textarea>";
				break;
			Case "radio":
				foreach($field['opts'] as $key=>$val) {
					$checked = '';
					if ($value == $key) { $checked = ' checked="checked"'; }
					$item .= "<input type='radio' name='$name' value=\"$key\"$checked /> $val ";
				}
				break;
			Case "check":
				$value = (is_null($value)) ? 'X' : $value;
				foreach($field['opts'] as $key=>$val) {
					$checked = '';
					if (strstr('$value', "$key")) { $checked = ' checked="checked"';}
					$item .= "<input type='checkbox' name='$name' value=\"$key\"$checked /> $val ";
				}
				break;
			Case "text":
				$len = 30;
				if(!empty($value)) {
					if (is_array($value)) { $value = implode(",",$value); }
					$tmp = strlen($value);
					if($tmp < $len) { $len = $tmp+2; }
				}
				$item = "<input type='text' name='$name' value=\"$value\" size='$len' />";
				break;
			Case "select":
				$tmp = $value;
				if (is_array($field['opts'])) {
					$opts = $field['opts'];
				} else {
					eval("\$opts = ".$field['opts'].";");
				}
				$item = "<select name='$name'>";
				foreach($opts as $key=>$val) {
					$sel = '';
					if ($value == $key) { $sel = ' selected="selected"'; }
					$item .= "<option value=\"$key\"$sel>$val</option>";
				}
				$item .= "</select>";
				break;
			Case "password":
				$ret[$field['c']][$i]['name'] = "old_pwd";
				$ret[$field['c']][$i]['value'] = "<input type='password' name='adm_pwd_old' />";
				$i++;
				$ret[$field['c']][$i]['name'] = "adm_pwd";
				$ret[$field['c']][$i]['value'] = "<input type='password' name='adm_pwd' />";
				$i++;
				$name = "con_pwd";
				$item = "<input type='password' name='adm_pwd_con' />";
				break;
			Default:
				die(_ZERROR);
				break;
		}
		$ret[$field['c']][$i]['name'] = $name;
		$ret[$field['c']][$i]['value'] = $item;
		$i++;
	}
	return $ret;
}

function getDirInfo($path) {
	global $zc;
	$d = dir($zc['mp3_dir']."/$path") or die(_ZERROR);
	$genre = $year = "";

	while($entry = $d->read()) {
		if (!is_dir($entry)) {
			if (preg_match("/\.(".$zc['ext_mus'].")$/i", $entry)) {
				$mp3 = new mp3($zc['mp3_dir']."/$path/$entry", false, true, true, $zc['dir_genre']);
			} elseif ($zc['remote'] && preg_match("/\.(".$zc['mm'].")$/i", $entry)) {
				$mp3 = new remoteFile($zc['mp3_dir']."/$path/$entry", false, true);
			} else {
				continue;
			}
			if ($mp3->tag) {
				if (!empty($mp3->year)) $year = $mp3->year;
				if (!empty($mp3->genre)) $genre = $mp3->genre;
			} else {
				$genre = "Unknown";
			}
			break;
		}
	}
	$d->close();
	return array('year' => $year, 'genre' => $genre);
}

function getSubDirLofi($path) {
	global $zc;
	$d = dir($path);
	$lofi = 0;

	while($entry = $d->read()) {
		if (!is_dir($entry) && preg_match("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", $entry)) {
			$lofi = 1;
			break;
		}
	}
	$d->close();
	return $lofi;
}

function getDirImage($path, &$images_found) {
	global $zc;
	$cover = null;
	if (is_dir($path)) {
		$s = dir($path);
		while($file = $s->read()) {
			$cover = null;
			if (preg_match("/\.(".$zc['ext_graphic'].")$/i", $file)) {
				$cover = rawurlencoder($file);
				$images_found++;
				break;
			}
		}
		$s->close();
	}
	return $cover;
}

function getTitlePlaylist($path, $custom = false, $low = false) {
	return getPlaylist(getSongs($path, true, $custom, $low), $low);
}

function getSongURL($file) {
	global $z_self, $z_url_base, $zc, $z_proto;
	if ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $file)) {
		$rem = new remoteFile($zc['mp3_dir']."/$file", false, false);
		return $rem->url."\n";
	} elseif ($zc['stream_int']) {
		global $z_asx;
		if ($z_asx) {
			$at = getFileArtistTitle(rawurldecode($file));
			return "<entry><title>$at</title><ref href=\"$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}${z_self}l=10&p=".rawurlencode($file)."\"><STARTTIME VALUE='00:00:00.0' /></ref></entry>\n";
		} else {
			$playlist = ($zc['stream_extinf']) ? "#EXTINF:-1,".getFileArtistTitle(rawurldecode($file))."\n" : "";
			return "${playlist}$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}${z_self}l=10&p=".rawurlencode($file)."\n";
		}
	} else {
		return "$z_url_base/".getURLencodedPath2($file)."\n";
	}
}

#TODO: note getSongURL???
function getSongResampledURL($song) {
	global $z_self, $zc, $z_asx, $z_proto;
	$url = "$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}${z_self}l=6&p=".rawurlencode($song);
	if ($z_asx) {
		$at = getFileArtistTitle(rawurldecode($song));
		return "<entry><title>$at</title><ref href=\"$url\"><STARTTIME VALUE='00:00:00.0' /></ref></entry>\n";
	}
	$playlist = ($zc['stream_extinf']) ? "#EXTINF:-1,".getFileArtistTitle(rawurldecode($song))."\n" : "";

	return "${playlist}$z_proto://".$zc['auth']."${_SERVER['HTTP_HOST']}${z_self}l=6&p=".rawurlencode($song)."\n";
}

function getURLencodedPath($path) {
	$path_raw = "";
	$tmp = explode("/",$path);

	$tmp_size = sizeof($tmp);
	for ($i = 0; $i < $tmp_size; $i++) {
		$path_raw .= rawurlencode($tmp[$i]);
		if ($i != $tmp_size - 1) { $path_raw = "$path_raw/"; }
	}
	return $path_raw;
}
function rawurlencoder($i) {
	global $z_rawutf;
	return ($z_rawutf) ? rawurlencode(utf8_encode($i)) : rawurlencode($i);
}

#For XP/Apache2
function getURLencodedPath2($path) {
	$path_raw = "";
	$tmp = explode("/",$path);

	$tmp_size = sizeof($tmp);
	for ($i = 0; $i < $tmp_size; $i++) {
		$path_raw .= rawurlencoder($tmp[$i]);
		if ($i != $tmp_size - 1) { $path_raw = "$path_raw/"; }
	}
	return $path_raw;
}

function getSongs($path, $sort = true, $custom = false, $low = false) {
	global $zc;
	$songs = $songs2 = null;
	$dir = $zc['mp3_dir']."/$path";

	if (!is_dir($dir)) { die("getSongs: '$dir' is not a valid dir."); }

	$d = dir($dir);

	while($entry = $d->read()) {
		if (!is_dir("$entry")) {
			if (preg_match("/\.(".$zc['ext_mus'].")$/i", $entry) || ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $entry))) {
				if ($zc['low'] && preg_match("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", $entry)) {
					$entry = preg_replace("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", ".$2", $entry);
					$songs[$entry]['lofi'] = 1;
				} else {
					$songs[$entry][] = null;
				}
			}
		}
	}
	$d->close();

	if (!empty($songs)) {
		$c_pls_file = $zc['cache_dir']."/".str_replace("/", " - ", $path).".m3u";
		if ($custom && $zc['honor_custom'] && file_exists($c_pls_file)) {
			$songs2 = file($c_pls_file);
			foreach ($songs2 as $key => $value) {
				$value = rtrim($value);
				$songs2[$key] = $value;
				if ($low && isset($songs[basename($value)]['lofi'])) {
					$songs2[$key] = preg_replace("/\.(".$zc['ext_mus'].")$/i", $zc['low_suf'].".$1", $value);
				}
			}
		} else {
			foreach($songs as $key => $value) {
				if ($low && isset($value['lofi'])) {
					$songs2[] = "$path/".preg_replace("/\.(".$zc['ext_mus'].")$/i", $zc['low_suf'].".$1", $key);
				} else {
					$songs2[] = "$path/$key";
				}
			}
		}
		if ($sort) { natcasesort($songs2); }
	}
	return $songs2;
}

function getPlaylist($songs, $low, $c_pls = false) {
	global $z_url_base, $z_play_local, $zc;
	$playlist = null;
	if (!empty($songs)) {
		if ($zc['pos'] || $z_play_local) {
			foreach($songs as $song) {
				$song = rtrim($song);
				if (preg_match("/\.lp$/i", $song)) {
					$song = preg_replace("/\.lp$/i", "", $song);
					$custom = $zc['honor_custom'] ? getTitlePlaylist($song, true, $low) : null;
					$playlist .= empty($custom) ? getTitlePlaylist($song, false, $low) : $custom;
				} else {
					$playlist .= "$z_url_base/".rawurldecode($song)."\n";
				}
			}
		} else { # NOT POS
			$pls_end = "";
			global $z_asx;
			if ($zc['stream_int'] && $z_asx) {
				$playlist .= "<ASX VERSION=\"3.0\">\n<title>"._ZPLAYLIST."</title>\n";
				$pls_end = "</ASX>";
			}
			if ($zc['stream_extinf']) $playlist .= "#EXTM3U\n";
			foreach($songs as $song) {
				$song = rtrim($song);
				if (preg_match("/\.lp$/i", $song)) {
					if ($low && !$c_pls) $song = preg_replace("/\.lp$/i", "", $song);
					$song = preg_replace("/\.lp$/i", "", $song);
					$custom = $zc['honor_custom'] ? getTitlePlaylist($song, true, $low) : null;
					$playlist .= empty($custom) ? getTitlePlaylist($song, false, $low) : $custom;
				} elseif (preg_match("/^http:\/\//i", $song)) {
					$playlist .= "$song\n";
				} elseif ($low) {
					$song_lofi = rawurldecode(preg_replace("/(\.".$zc['ext_mus'].")$/i", $zc['low_suf']."$1", $song));
					$song_dec = rawurldecode($song);

					if ($c_pls && file_exists($zc['mp3_dir']."/$song_lofi")) {
						$playlist .= getSongURL($song_lofi);
					} elseif (preg_match("/(".$zc['low_suf'].")\.(".$zc['ext_mus'].")$/i", $song)) {
						$playlist .= getSongURL($song_dec);
					} elseif($zc['resample'] && preg_match("/\.(".$zc['ext_enc'].")$/i", $song_dec)) {
						$playlist .= getSongResampledURL($song_dec);
					} else {
						$playlist .= getSongURL($song_dec);
					}
				} else {
					#TODO:
					$playlist .= getSongURL(rawurldecode($song));
				}
			}
			$playlist .= $pls_end;
		}
	}
	return $playlist;
}

function getCustomPlaylists() {
	global $zc;
	$custom_playlists = null;

	if (file_exists($zc['cache_dir'])) {
		$d = dir($zc['cache_dir']);

		while($entry = $d->read()) {
			if (substr($entry,0,6) == "_zina_" && preg_match("/\.m3u$/i", $entry) ) {
				$entry = preg_replace("/^_zina_/i","",$entry);
				$custom_playlists[] = preg_replace("/\.m3u$/i","",$entry);
			}
		}
		$d->close();

		if (!empty($custom_playlists)) { natcasesort($custom_playlists); }
	}
	return $custom_playlists;
}

function getReorderedPlaylist($z_songs, $order) {
	$new = $neworder = null;

	$count = sizeof($z_songs);
	if ($count == 0) { return null; }

	for ($i = 0; $i < $count; $i++){
		if ($order[$i] == 0) continue; # 0 == delete
			$new[$order[$i]][] = $z_songs[$i];
	}
	ksort($new);
	$z_songs = null;

	foreach($new as $neworder) {
		foreach($neworder as $song) { $z_songs[] = $song; }
	}
	return $z_songs;
}

function getDirsWithMusic($path = "") {
	global $zc;
	$subdirs = $slash = "";
	$file = false;
	if (!empty($path)) $slash = "/";

	@set_time_limit($zc['timeout']);
	$d = dir($zc['mp3_dir']."$slash$path");
	while($entry = $d->read()) {
		if ($entry == "." || $entry == "..") { continue;}
		if (is_dir($zc['mp3_dir']."$slash$path/$entry") && substr($entry,0,1) != $zc['dir_skip']) {
			$subdirs .= getDirsWithMusic("$path$slash$entry");
		} elseif (!$file && (preg_match("/\.(".$zc['ext_mus'].")$/i", $entry) ||
			($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $entry)))) {
			$subdirs .= "$path\n";
			$file = true;
		}
	}
	$d->close();

	return $subdirs;
}

function getGenreDirs(&$arr, $path = "") {
	global $zc;

	$slash = "";
	$file = false;
	if (!empty($path)) $slash = "/";

	@set_time_limit($zc['timeout']);
	$d = dir($zc['mp3_dir']."$slash$path");
	while($entry = $d->read()) {
		if ($entry == "." || $entry == "..") { continue;}
		if (is_dir($zc['mp3_dir']."$slash$path/$entry") && substr($entry,0,1) != $zc['dir_skip']) {
			getGenreDirs($arr, "$path$slash$entry");
		} elseif (!$file) {
			if (preg_match("/\.(".$zc['ext_mus'].")$/i", $entry)) {
				$mp3 = new mp3($zc['mp3_dir']."/$path/$entry", false, true, true, true);
			} elseif ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $entry)) {
				$mp3 = new remoteFile($zc['mp3_dir']."/$path/$entry", false, true);
			} else {
				continue;
			}
			$genre = ($mp3->tag) ? $mp3->genre : "Unknown";
			$arr[$genre][] = $path;
			$file = true;
		}
	}
	$d->close();
}

function getGenres($type = "") {
	global $zc;

	$cache = $zc['cache_dir']."/_genre${type}_cache.dat";
	if (!file_exists($zc['cache_dir']."/_genre_cache.dat")) { writeGenreCache(); }
	return unserialize(implode("",file($cache)));
}

function getFileArtistTitle($file) {
	global $zc;
	if ($zc['mp3_id3']) {
		if ($zc['remote'] && preg_match("/\.(".$zc['remote_ext'].")$/i", $file)) {
			$mp3 = new remoteFile($zc['mp3_dir']."/$file", false, true);
		} else {
			$mp3 = new mp3($zc['mp3_dir']."/$file", false, true, true);
		}
		if ($mp3->tag) return "$mp3->artist - $mp3->title";
	}

	$x = explode("/", $file);
	$len = sizeof($x);
	$song = formatSongTitle($x[$len - 1]);
	if ($len > 2) {
		return formatTitle($x[$len - 3])." - $song";
	} elseif (!empty($x[$len-2])) {
		return formatTitle($x[$len - 2])." - $song";
	} else {
		return $song;
	}
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * SEND functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function sendResponse($content) {
	global $zc, $z_asx;
	if ($zc['pos']) {
		$tmpfname = tempnam("/tmp", "zina-");
		$handle = fopen($tmpfname, "w");
		fwrite($handle, $content);
		fclose($handle);
		if (file_exists("$tmpfname.m3u")) { unlink("$tmpfname.m3u"); }
		rename($tmpfname, "$tmpfname.m3u");
		if ($zc['pos_kill']) { exec($zc['pos_kill_cmd']); }
		$pos_cmd = $zc['pos_cmd'];
		eval("\$pos_cmd = \"$pos_cmd\";");
		if ($zc['pos_hack']) { session_write_close(); }
		exec($pos_cmd);
		#sleep(2);
		#unlink("$tmpfname.m3u");
		header("Location: ${_SERVER['HTTP_REFERER']}");
	} else {
		if ($zc['other_media_types']) {
			$play_ext = null;
			eval("\$media_types = array(".$zc['m_types'].");");
			$content = preg_replace("#.*?://(.*\.)(".$zc['ext_mus'].")(\n|$)#ie", "\$media_types[strtolower('$2')][\"proto\"].\"://\".'$1'.'$2'.'$3'", $content);
			preg_match_all("/\.(".$zc['ext_mus'].")(\n|$)/i", $content, $ext);
			foreach($ext[1] as $e) { @$play_ext[$e]++; }
			if (sizeof($play_ext) > 1) { arsort($play_ext); }
			$pls_ext = $media_types[strtolower(key($play_ext))]['ext'];
			header("Content-type: ".$zc['media_playlist'][$pls_ext]);
			header("Content-Disposition: inline; filename=playlist.$pls_ext");
		} else {
			if ($z_asx) {
				header("Content-type: application/vnd.ms-asx");
				header("Content-Disposition: inline; filename=playlist.asx");
			} else {
				header("Content-type: audio/mpegurl");
				header("Content-Disposition: inline; filename=playlist.m3u");
			}
		}
		header("Cache-control: private"); #IE seems to need this.
		echo $content;
	}
	exit;
}

function sendSongPlaylist ($path) {
	global $z_url_base, $z_play_local, $zc, $z_asx;
	if ($zc['pos'] || $z_play_local) {
		sendResponse("$z_url_base/$path\n");
	} else {
		if ($zc['stream_int'] && $z_asx) {
			sendResponse("<ASX VERSION=\"3.0\">\n<title>".formatSongTitle(basename($path))."</title>\n".getSongURL($path)."</ASX>");
		} else {
			$playlist = ($zc['stream_int'] && $zc['stream_extinf']) ? "#EXTM3U\n" : "";
			sendResponse($playlist.getSongURL($path));
		}
	}
}

function sendSongPlaylistResampled ($song) {
	sendResponse(getSongResampledURL($song));
}

function sendTitlePlaylist ($path, $custom, $low = false) {
	sendResponse(getTitlePlaylist($path, $custom, $low));
}

function sendSelectedSongs($songs, $low = false) {
	sendResponse(getPlaylist($songs, $low, true));
}

function sendCustomPlaylist($pls_name, $low) {
	global $zc;
	$songs = null;

	if($zc['session_pls'] && $pls_name == "zina_session_playlist") {
		if (isset($_SESSION['z_sp'])) {
			$songs = explode("\n",$_SESSION['z_sp']);
			unset($songs[sizeof($songs) - 1]);
		}
	} else {
		if ($pls_name != "new_zina_list") {
			$filename = $zc['cache_dir']."/_zina_".str_replace("/"," - ",$pls_name).".m3u";
			$songs = file($filename);
		}
	}
	sendResponse(getPlaylist($songs, $low, true));
}

function sendRandom($num, $type, $low, $rand = true, $path = null) {
	$playlist = null;

	@set_time_limit($zc['timeout']);
	$array = explode("\n",trim(getDirsWithMusic($path)));

	if ($type == "s") {
		$dirs = $array;
		$array = null;
		foreach ($dirs as $dir) {
			$array = array_merge($array, getSongs(rtrim($dir,"\r\n"), false, false, false));
		}
	}
	$total = sizeof($array);
	if ($num == 0 || $num > $total) { $num = $total; }

	if ($rand) o_shuffle($array);

	if ($type == "t") {
		for($i = 0; $i < $num; $i++) {
			$playlist .= getTitlePlaylist(rtrim($array[$i]), false, $low);
		}
	} else {
		$playlist = getPlaylist(array_slice($array,0,$num), $low);
	}
	sendResponse($playlist);
}

#TODO: rename, i.e. also does recurisve non-random
function sendRandomCached($num, $type, $low, $rand = true, $path = null, $genre = null) {
	global $zc;

	$playlist = null;
	if ($zc['genres'] && !empty($genre) && $genre != 'zina') {
		$array = getGenres('');
		$array = $array[$genre];
		if ($type == "s") {
			$file = $zc['cache_dir']."/_file_cache.dat";
			if ($low) { $file = preg_replace("/(\.dat)$/i", $zc['low_suf']."$1", $file); }
			$files = file($file);
			$a = array();
			foreach($array as $p) { $a = array_merge($a, array_values(preg_grep(":^$p:", $files))); }
			$array = $a;
		}
	} else { # normal
		$file = $zc['cache_dir']."/_dir_cache.dat";

		writeRandomCache($type, false, $low);
		if ($type == "s") {
			$file = $zc['cache_dir']."/_file_cache.dat";
			if ($low) { $file = preg_replace("/(\.dat)$/i", $zc['low_suf']."$1", $file); }
		}

		$array = file($file);
		if (!empty($path)) { # dir recursive
			$array = array_values(preg_grep(":^".quotemeta($path).":", $array));
		}
	}

	$total = sizeof($array);
	if ($num == 0 || $num > $total) { $num = $total; }
	if ($rand) o_shuffle($array);

	if ($type == "t") {
		for($i = 0; $i < $num; $i++) {
			$custom = $zc['honor_custom'] ? getTitlePlaylist(rtrim($array[$i]), true, $low) : null;
			$playlist .= empty($custom) ? getTitlePlaylist(rtrim($array[$i]), false, $low) : $custom;
		}
	} elseif ($type == "s") {
		$playlist = getPlaylist(array_slice($array,0,$num), $low);
	}
	sendResponse($playlist);
}

function streamItem ($path) {
	global $zc;

	$file = $zc['mp3_dir']."/$path";
	preg_match("/\.(".$zc['ext_mus'].")$/i", $path, $exts);
	eval("\$media_types = array(".$zc['m_types'].");");

	@set_time_limit(0);

	$icy = getFileArtistTitle($path);

	# phpnuke uses ob_gzhandler
	if ($zc['embed'] == 1 || $zc['embed'] == 4) { while(@ob_end_clean()); }

	$in = fopen($file, "rb");
	header("ICY 200 OK");
	header("icy-name: $icy");
	header("Connection: close");
	header("Content-type: ".$media_types[strtolower($exts[1])]['type']);
	header("Content-Disposition: filename=$icy");
	header("Content-Length: ".filesize($file) );

	$headers = @getallheaders();
	if (isset($headers['Range'])) {
		fseek($in, preg_replace('/[^0-9]+/','',$headers['Range']));
	}
	fpassthru($in);
	exit;
}

function sendResampledMP3 ($path) {
	global $zc;
	$file = "\"".$zc['mp3_dir']."/$path\"";
	if (preg_match("/\.(".$zc['ext_enc'].")$/i", $path, $exts)) {
		eval("\$enc_arr = array(".$zc['enc_arr'].");");
		$enc = $enc_arr[$exts[1]]['enc'];
		$opts = $enc_arr[$exts[1]]['opts'];
		$output = $enc_arr[$exts[1]]['output'];
		$icy = getFileArtistTitle($path);

		# phpnuke uses ob_gzhandler
		if ($zc['embed'] == 1 || $zc['embed'] == 4) { while(@ob_end_clean()); }

		header("ICY 200 OK");
		header("icy-name: $icy");
		header("Content-type: $output");
		header("Content-Disposition: filename=".basename($path));
		header("Connection: close");
		passthru("$enc $opts $file");
		exit;
	} else { die(_ZERROR); }
}

function sendSelectedCompressedDir($dir, $custom, $low) {
	$dir = preg_replace("/\/\.lp$/i", "", $dir);
	$songs = getSongs($dir, true, $custom, $low);
	sendSelectedCompressed($songs, $low);
}

function sendSelectedCompressed($songs, $lofi = false) {
	global $zc;
	#TODO: lowfi, baby
	if ($zc['cmp_sel']) {
		$files = null;

		if ($zc['cmp_int']) {
			$archive = new zipfile;

			foreach ($songs as $song) {
				$file = $zc['mp3_dir']."/".rawurldecode($song);
				$file_size = filesize($file);
				$fp = fopen($file, "rb");
				$file_data = fread($fp, $file_size);
				fclose($fp);

				$archive->add_file($file_data,$file);
				unset($file_data);
			}
			header("Content-type: application/zip");
			header("Content-Disposition: inline; filename=selectedmusic.zip");
			echo $archive->file();

		} else { # external
			foreach ($songs as $song) {
				$files .= "\"".$zc['mp3_dir']."/".rawurldecode($song)."\" ";
			}
			header("Content-type: ".$zc['cmp_mime']);
			header("Content-Disposition: inline; filename=selectedmusic.".$zc['cmp_ext']);
			passthru($zc['cmp_pgm']." ".$zc['cmp_set']." $files");
		}
	}
	exit;
}

function sendImageResized($source, $new_x, $quality, $txt = null, $clr_str = "0,0,0") {
	global $zc;
	$types = array(1 => 'gif', 2 => 'jpeg', 3 => 'png', 7 => 'tiff', 8 => 'tiff');

	$info = getimagesize($source);
	$org_x = $info[0];
	$org_y = $info[1];
	$org_type = $types[$info[2]];
	eval('$org_image = imagecreatefrom'.$org_type.'($source);');
	$res_out_type = $zc['res_out_type'];

	if (!$zc['res_out_x_lmt'] || $org_x > $new_x) {
		$new_y = intval($org_y * $new_x / $org_x);
		$new_image = @imagecreatetruecolor($new_x, $new_y);
		if (!$new_image) { $new_image = imagecreate($new_x, $new_y); }

		if(!@imagecopyresampled($new_image, $org_image, 0, 0, 0, 0, $new_x, $new_y, $org_x, $org_y)) {
			imagecopyresized($new_image, $org_image, 0, 0, 0, 0, $new_x, $new_y, $org_x, $org_y);
		}
	} else {
		$res_out_type = $org_type;
		$new_image = $org_image;
		$new_x = $org_x;
		$new_y = $org_y;
	}
	if (!empty($txt)) {
		$txt = wordwrap($txt, $zc['img_txt_wrap'], "\r\n");
		$box = imagettfbbox($zc['img_txt_font_size'], 0, $zc['img_txt_font'], $txt);
		$tmp = explode(",",$clr_str);
		$color = imagecolorallocate($new_image, $tmp[0], $tmp[1], $tmp[2]);
		$bx = $box[2] - $box[0];
		$by = $box[5] - $box[3];
		$vert = 2 + (substr_count($txt, "\r\n") * .5);
		$txt_x = ($new_x - $bx)/2;
		$txt_y = ($new_y - $by)/$vert;
		imagettftext($new_image, $zc['img_txt_font_size'], 0, $txt_x, $txt_y, $color, $zc['img_txt_font'], $txt);
	}
	Header("Content-type: image/$res_out_type");
	eval('image'.$res_out_type.'($new_image,"",$quality);');

	@imagedestroy($new_image);
	@imagedestroy($org_image);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * WRITE/UPDATE/DELETE functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function writeRandomCache($type = "t", $force = false, $low = false) {
	global $zc;
	@set_time_limit($zc['timeout']);

	$files = null;
	$cache_file = $zc['cache_dir']."/_dir_cache.dat";

	if ($type == "s") {
		writeRandomCache("t", $force);
		$cache_file = $zc['cache_dir']."/_file_cache.dat";
		if ($low) { $cache_file = preg_replace("/(\.dat)$/i", $zc['low_suf']."$1", $cache_file); }
	}

	if (file_exists($cache_file) && !$force) {
		$cache_life = ($zc['cache_limit'] * 86400); #days
		$lastmtime = 0;
		$now = time();

		$lastmtime = filemtime($cache_file);
		if ($now - $lastmtime < $cache_life) return false;
	}

	if ($type == "s") {
		$dirs = file($zc['cache_dir']."/_dir_cache.dat");
		foreach ($dirs as $dir) {
			$files .= implode("\n",getSongs(rtrim($dir,"\r\n"), false, $zc['honor_custom'], $low))."\n";
		}
	} else {
		$files = getDirsWithMusic();
	}

	$fp = fopen ($cache_file, "w");
	fwrite($fp,$files);
	fclose($fp);

	return true;
}

function writeGenreCache($force = false) {
	global $zc;
	@set_time_limit($zc['timeout']);

	$files = null;
	$cache_file = $zc['cache_dir']."/_genre_cache.dat";

	if (file_exists($cache_file) && !$force) {
		$cache_life = ($zc['cache_limit'] * 86400); #days
		$lastmtime = 0;
		$now = time();

		$lastmtime = filemtime($cache_file);
		if ($now - $lastmtime < $cache_life) return false;
	}

	getGenreDirs($gd);
	uksort($gd,"strnatcasecmp");
	$genre = serialize($gd);

	$fp = fopen($cache_file, "w");
	fwrite($fp,$genre);
	fclose($fp);

	$cache_file = $zc['cache_dir']."/_genres_cache.dat";
	$genres = serialize(array_keys($gd));
	$fp = fopen($cache_file, "w");
	fwrite($fp,$genres);
	fclose($fp);
}

function writeCustomPlaylist($songs, $type, $filename, $title = false) {
	global $zc;
	$playlist = null;
	$filename = $zc['cache_dir']."/$filename";

	if (!empty($songs)) {
		foreach($songs as $song) { $playlist .= rawurldecode($song)."\n"; }
	}

	if($zc['session_pls'] && strstr($filename,"zina_session_playlist")) {
		global $z_mode;
		if ($z_mode == 4) { #update
			$_SESSION['z_sp'] = $playlist;
		} else {
			if (!isset($_SESSION['z_sp'])) $_SESSION['z_sp'] = null;
			if (strlen($_SESSION['z_sp']) + strlen($playlist) < $zc['sp_len']) {
				$_SESSION['z_sp'] .= $playlist;
			}
		}
	} else {
		$fh = fopen ($filename, $type);
		fwrite($fh,$playlist);
		fclose($fh);
	}

	if ($title && empty($songs) && file_exists($filename)) { unlink($filename); }
}

function deleteCustomPlaylist($pls_name) {
	global $zc;
	if ($pls_name != "new_zina_list") {
		$filename = $zc['cache_dir']."/_zina_$pls_name.m3u";
		if (file_exists($filename)) { unlink($filename); }
	}
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * SEARCH functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function searchDir($term) {
	global $zc;
	$found = null;
	$dir_cache = $zc['cache_dir']."/_dir_cache.dat";

	if ($zc['cache'] && file_exists($dir_cache)) {
		$dirs = file($dir_cache);
	} else {
		$dirs = explode("\n",trim(getDirsWithMusic()));
	}

	if (!empty($dirs)) {
		foreach ($dirs as $dir) { if (stristr($dir, $term)) { $found[] = $dir; } }
	}
	return $found;
}

function searchFiles($term) {
	global $zc;
	$found = null;

	$file_cache = $zc['cache_dir']."/_file_cache.dat";
	if ($zc['cache'] && file_exists($file_cache)) {
		$files = file($file_cache);
	} else {
		$files[] = null;
		$dirs = explode("\n",trim(getDirsWithMusic()));
		foreach ($dirs as $dir) {
			$files = array_merge($files, getSongs(rtrim($dir,"\r\n"), false, $zc['honor_custom'], false));
		}
	}

	if (!empty($files)) {
		foreach ($files as $file) {
			if (stristr(basename($file), $term)) {
				if (preg_match("#/.*?$term.*?(\n|$)#i",$file)) {
					$found[] = $file;
				}
			}
		}
	}
	return $found;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * MISC functions
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function checkPwd($un, $up) {
	global $zc;
	if (preg_match("/^\{(.*?)\}/", $zc['adm_pwd'], $matches) == 1) {
		if ($matches[1] == "md5") {
			$len = 16;
		} elseif ($matches[1] == "sha1") {
			$len = 20;
		} else {
			die("checkPwd 1");
		}
		$hash = base64_decode(substr($zc['adm_pwd'], strlen($matches[0])));
		$new_hash = pack("H*", $matches[1]($up.substr($hash,$len)));
		return ($zc['adm_name'] == $un && substr($hash,0,$len) == $new_hash);
	} else {
		die("checkPwd 2");
	}
}

function getPasswordHash($password) {
	$z_hash = (function_exists("sha1")) ? "sha1" : "md5";
	$salt = substr(pack("H*", $z_hash( substr(pack('h*', $z_hash(mt_rand())), 0, 8) . $password)), 0, 4);
	return '{'.$z_hash.'}'.base64_encode( pack("H*", $z_hash($password.$salt)) .$salt);
}

function renamePlaylist($old, $new) {
	global $zc;
	$new = rtrim($new);
	$filename = $zc['cache_dir']."/_zina_$new.m3u";

	if ($new == "") { return false; }
	if ($new == $old) { return true; }
	if (file_exists($filename)) { return false; }
	if(!rename($zc['cache_dir']."/_zina_$old.m3u", $filename)) { return false; }

	return true;
}

function timeCheck($cron) {
	global $zc;
	$now = getdate();
	#$now = getdate(mktime ( 8, 45, 0, 12, 29, 2003));
	$n[0] = $now['wday']; # 0-6; 0 = sun
	$n[1] = $now['mon'];  # 1-12
	$n[2] = $now['mday']; # 0-31
	$n[3] = ($now['hours'] * 60) + $now['minutes']; #0-23:0-59

	foreach($cron as $feature=>$crontabs) {
		foreach($crontabs as $crontab) {
			$res = cronCheck($crontab, $n);
			eval('$_SESSION[\'zc\'][\''.$feature.'\'] = $res;');
			if ($res) break;
		}
	}
}

#crontab = "WDAY MON MDAY HH:MM";
function cronCheck($crontab, $now) {
	$tab = explode(" ",$crontab);
	$size = sizeof($tab);
	if ($size != 4) die("bad!");

	for($i=0; $i<4; $i++) {
		$cur = $tab[$i];
		$n = $now[$i];
		if($cur[0] == "*") continue;

		if(strpos($cur,",") !== false) { #multi
			$multi = explode(",",$cur);
			if (!in_array($n, $multi)) return false;
		} elseif (strpos($cur,"-") !== false) { #range
			$range = explode("-",$cur);
			if ($i == 3) {
				$hm = explode(":",$range[0]);
				$r0 = ($hm[0] * 60) + $hm[1];
				$hm = explode(":",$range[1]);
				$r1 = ($hm[0] * 60) + $hm[1];
			} else {
				$r0 = $range[0];
				$r1 = $range[1];
			}
			if ($r0 < $r1) {
				if($n < $r0 || $n > $r1) return false;
			} else {
				if($n < $r0 && $n > $r1) return false;
			}
		} else { #single
			if ($n != $cur) return false;
		}
	}
	return true;
}

function o_shuffle(&$array){
	if (!isset($randinit)){
		srand((double) microtime() * 1000000);
		static $randinit = 1;
	}
	$last = count($array);
	while ($last > 0){
		$last--;
		$random = rand(0, $last);
		$temp = $array[$random];
		$array[$random] = $array[$last];
		$array[$last] = $temp;
	}
	return 1;
}

function debug($x, $exit = false, $phpinfo = false) {
	echo "<pre>";
	print_r($x);
	echo "</pre>";
	if ($phpinfo) { phpinfo(32); }
	if ($exit) { exit; }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * MP3/OGG file info and tags
 *
 * hacked pretty heavily from...
 * MP3::Info by Chris Nandor <http://sf.net/projects/mp3-info/>
 * class.id3.php by Sandy McArthur, Jr. <http://Leknor.com/code/>
 * getID3() [ogg stuff] by James Heinrich <http://www.silisoftware.com>
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
class mp3 {
	function mp3($file, $info=false, $tag=false, $faster=true, $genre = false) {
		$this->file = $file;
		$this->tag = 0;
		$this->info = 0;
		$this->faster = $faster;
		#TODO: get fh once???

		if (stristr(substr($file,-3),'mp3')) {
 			if ($info) $this->getMP3Info();
			if ($tag) $this->getID3Tag($genre);
		} elseif (stristr(substr($file,-3),'ogg')) {
			if ($info || $tag) $this->getOgg($info, $tag);
		} else {
			$this->getBadInfo();
		}
	}
	function getID3Tag($genre) {
		$this->tag = 0;
		$v2h = null;

		if (!($fh = fopen($this->file, 'rb'))) { return 0; }

		$v2h = $this->getV2Header($fh);

		if (!empty($v2h) && !($v2h->major_ver < 2)) {
			$hlen = 10; $num = 4;

			if ($v2h->major_ver == 2) { $hlen = 6; $num = 3; }

			$off = 10; #TODO ext_header?
			$size = null;
			#ALBUM: 2 TAL, 3 TALB
			$map = array(
				'2' => array('TT2'=>'title',  'TP1' =>'artist', 'TYE' =>'year', 'TCO' =>'genre'),
				'3' => array('TIT2'=>'title', 'TPE1'=>'artist', 'TYER'=>'year', 'TCON'=>'genre')
				);
			$fs = sizeof($map[2]);
			$this->title = $this->artist = null;

			while($off < $v2h->tag_size) {
				$arr = $id = null;
				$found = 0;
				fseek($fh, $off);
				$bytes = fread($fh, $hlen);
				if (preg_match("/^([A-Z0-9]{".$num."})/", $bytes, $arr)) {
					$id = $arr[0];
					$size = $hlen;
					$bytes = array_reverse(unpack("C$num",substr($bytes,$num,$num)));
					for ($i=0; $i<($num - 1); $i++) {
						$size += $bytes[$i] * pow(256,$i);
					}
				} else { break; }
				fseek($fh, $off + $hlen);
				if ($size > $hlen) {
					$bytes = fread($fh, $size - $hlen);
					if (isset($map[$v2h->major_ver][$id])) {
						$this->$map[$v2h->major_ver][$id] = trim($bytes);
						$this->tag = 1;
						$this->tag_version = "ID3v2.".$v2h->major_ver;
						#TODO: UTF-8???
						#if (isset($this->artist)) $this->artist = utf8_encode($this->artist);
						#$this->title = utf8_encode($this->title);
						if (++$found == $fs) { break; }
					}
				}
				$off += $size;
			}
		}
		#if v2 not found look for v1
		if (!$this->tag) {
			if (fseek($fh, -128, SEEK_END) == -1) { return 0; }
			$tag = fread($fh, 128);

			if (substr($tag,0,3) == "TAG") {
				if ($tag[125] == Chr(0) and $tag[126] != Chr(0)) {
					$format = 'a3TAG/a30title/a30artist/a30album/a4year/a28comment/x1/C1track/C1genre';
					$this->tag_version = "ID3v1.1";
				} else {
					$format = 'a3TAG/a30title/a30artist/a30album/a4year/a30comment/C1genre';
					$this->tag_version = "ID3v1";
				}
				$id3tag = unpack($format, $tag);
				foreach ($id3tag as $key => $value) {
					$this->$key = trim($value);
				}
				unset($this->TAG);
				$this->tag = 1;
			}
		}
		fclose($fh);

		if ($genre) {
			$genres = array(
0   => 'Blues',
1   => 'Classic Rock',
2   => 'Country',
3   => 'Dance',
4   => 'Disco',
5   => 'Funk',
6   => 'Grunge',
7   => 'Hip-Hop',
8   => 'Jazz',
9   => 'Metal',
10  => 'New Age',
11  => 'Oldies',
12  => 'Other',
13  => 'Pop',
14  => 'R&B',
15  => 'Rap',
16  => 'Reggae',
17  => 'Rock',
18  => 'Techno',
19  => 'Industrial',
20  => 'Alternative',
21  => 'Ska',
22  => 'Death Metal',
23  => 'Pranks',
24  => 'Soundtrack',
25  => 'Euro-Techno',
26  => 'Ambient',
27  => 'Trip-Hop',
28  => 'Vocal',
29  => 'Jazz+Funk',
30  => 'Fusion',
31  => 'Trance',
32  => 'Classical',
33  => 'Instrumental',
34  => 'Acid',
35  => 'House',
36  => 'Game',
37  => 'Sound Clip',
38  => 'Gospel',
39  => 'Noise',
40  => 'Alternative Rock',
41  => 'Bass',
42  => 'Soul',
43  => 'Punk',
44  => 'Space',
45  => 'Meditative',
46  => 'Instrumental Pop',
47  => 'Instrumental Rock',
48  => 'Ethnic',
49  => 'Gothic',
50  => 'Darkwave',
51  => 'Techno-Industrial',
52  => 'Electronic',
53  => 'Pop-Folk',
54  => 'Eurodance',
55  => 'Dream',
56  => 'Southern Rock',
57  => 'Comedy',
58  => 'Cult',
59  => 'Gangsta',
60  => 'Top 40',
61  => 'Christian Rap',
62  => 'Pop/Funk',
63  => 'Jungle',
64  => 'Native US',
65  => 'Cabaret',
66  => 'New Wave',
67  => 'Psychadelic',
68  => 'Rave',
69  => 'Showtunes',
70  => 'Trailer',
71  => 'Lo-Fi',
72  => 'Tribal',
73  => 'Acid Punk',
74  => 'Acid Jazz',
75  => 'Polka',
76  => 'Retro',
77  => 'Musical',
78  => 'Rock & Roll',
79  => 'Hard Rock',
80  => 'Folk',
81  => 'Folk-Rock',
82  => 'National Folk',
83  => 'Swing',
84  => 'Fast Fusion',
85  => 'Bebob',
86  => 'Latin',
87  => 'Revival',
88  => 'Celtic',
89  => 'Bluegrass',
90  => 'Avantgarde',
91  => 'Gothic Rock',
92  => 'Progressive Rock',
93  => 'Psychedelic Rock',
94  => 'Symphonic Rock',
95  => 'Slow Rock',
96  => 'Big Band',
97  => 'Chorus',
98  => 'Easy Listening',
99  => 'Acoustic',
100 => 'Humour',
101 => 'Speech',
102 => 'Chanson',
103 => 'Opera',
104 => 'Chamber Music',
105 => 'Sonata',
106 => 'Symphony',
107 => 'Booty Bass',
108 => 'Primus',
109 => 'Porn Groove',
110 => 'Satire',
111 => 'Slow Jam',
112 => 'Club',
113 => 'Tango',
114 => 'Samba',
115 => 'Folklore',
116 => 'Ballad',
117 => 'Power Ballad',
118 => 'Rhytmic Soul',
119 => 'Freestyle',
120 => 'Duet',
121 => 'Punk Rock',
122 => 'Drum Solo',
123 => 'Acapella',
124 => 'Euro-House',
125 => 'Dance Hall',
126 => 'Goa',
127 => 'Drum & Bass',
128 => 'Club-House',
129 => 'Hardcore',
130 => 'Terror',
131 => 'Indie',
132 => 'BritPop',
133 => 'Negerpunk',
134 => 'Polsk Punk',
135 => 'Beat',
136 => 'Christian Gangsta Rap',
137 => 'Heavy Metal',
138 => 'Black Metal',
139 => 'Crossover',
140 => 'Contemporary Christian',
141 => 'Christian Rock',
142 => 'Merengue',
143 => 'Salsa',
144 => 'Trash Metal',
145 => 'Anime',
146 => 'Jpop',
147 => 'Synthpop',
255 => 'Unknown'
);
			if ($this->tag && !empty($this->genre)) {
				$g = (preg_match("/\((.*?)\)/",$this->genre, $match)) ? $match[1] : ucfirst($this->genre);
				if (isset($genres[$g])) $g = $genres[$g];
			} else {
				$g = "Unknown";
			}
			$this->genre = $g;
		}
		return $this->tag;
	}

	function getMP3Info() {
		$file = $this->file;

		if (! ($f = fopen($file, 'rb')) ) { return false; }

		$this->filesize = filesize($file);
		$frameoffset = 0;
		$total = 4096;

		if ($frameoffset == 0) {
			if ($v2h = $this->getV2Header($f)) {
				$total += $frameoffset += $v2h->tag_size;
				fseek($f, $frameoffset);
			} else {
				fseek($f, 0);
			}
		}

		if ($this->faster) {
			do {
				while (fread($f,1) != Chr(255)) { // Find the first frame
					if (feof($f)) { return false; }
				}
				fseek($f, ftell($f) - 1); // back up one byte
				$frameoffset = ftell($f);
				$r = fread($f, 4);

				$bits = decbin($this->unpackHeader($r));

				if ($frameoffset > $total) { return $this->getBadInfo(); }
			} while (!$this->isValidMP3Header($bits));
		} else { #more accurate with some VBRs
			$r = fread($f, 4);
			$bits = decbin($this->unpackHeader($r));

			while (!$this->isValidMP3Header($bits)) {
				if ($frameoffset > $total) { return $this->getBadInfo(); }
				fseek($f, ++$frameoffset);
				$r = fread($f, 4);
				$bits = decbin($this->unpackHeader($r));
			}
		}

		#$this->bits = $bits;
		$this->header_found = $frameoffset;
		$this->vbr = 0;
		$vbr = $this->getVBR($f, $bits[12], $bits[24] + $bits[25], $frameoffset);
		fclose($f);

		#TODO: vbr file size

		if ($bits[11] == 0) {
			$mpeg_ver = "2.5";
			$bitrates = array(
				'1' => array(0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 0),
				'2' => array(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0),
				'3' => array(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0),
				);
		} else if ($bits[12] == 0) {
			$mpeg_ver = "2";
			$bitrates = array(
				'1' => array(0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 0),
				'2' => array(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0),
				'3' => array(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0),
				);
		} else {
			$mpeg_ver = "1";
			$bitrates = array(
				'1' => array(0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 0),
				'2' => array(0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 0),
				'3' => array(0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0),
				);
		}

		$layers = array(array(0,3), array(2,1),);
		$layer = $layers[$bits[13]][$bits[14]];
		if ($layer == 0) return $this->getBadInfo();

		$bitrate = 0;
		if ($bits[16] == 1) $bitrate += 8;
		if ($bits[17] == 1) $bitrate += 4;
		if ($bits[18] == 1) $bitrate += 2;
		if ($bits[19] == 1) $bitrate += 1;
		if ($bitrate == 0) return $this->getBadInfo();

		$this->bitrate = $bitrates[$layer][$bitrate];

		$frequency = array(
			'1' => array(
				'0' => array(44100, 48000),
				'1' => array(32000, 0),
				),
			'2' => array(
				'0' => array(22050, 24000),
				'1' => array(16000, 0),
				),
			'2.5' => array(
				'0' => array(11025, 12000),
				'1' => array(8000, 0),
				),
			 );
		$this->frequency = $frequency[$mpeg_ver][$bits[20]][$bits[21]];
		$mfs = $this->frequency / ($bits[12] ? 144000 : 72000);
		if ($mfs == 0) return $this->getBadInfo();
		$frames = (int)($vbr && $vbr['frames'] ? $vbr['frames'] : $this->filesize / $this->bitrate / $mfs);

		if ($vbr) {
			$this->vbr = 1;
			if ($vbr['scale']) $this->vbr_scale = $vbr['scale'];
			$this->bitrate = (int)($this->filesize / $frames * $mfs);
			if (!$this->bitrate) return $this->getBadInfo();
		}

		$s = -1;
		if ($this->bitrate != 0) {
			$s = ((8*($this->filesize))/1000) / $this->bitrate;
		}

		$this->time = sprintf('%.2d:%02d',floor($s/60),floor($s-(floor($s/60)*60)));
		$this->info = 1;
	}

	function getV2Header($fh) {
		fseek($fh, 0);
		$bytes = fread($fh, 3);

		if ($bytes != 'ID3') return false;

		#$bytes = fread($fh, 3);
		#get version
		$bytes = fread($fh, 2);
		$ver = unpack("C2",$bytes);
		$h->major_ver = $ver[1];
		$h->minor_ver = $ver[2];

		#get flags
		$bytes = fread($fh, 1);

		#get ID3v2 tag length from bytes 7-10
		$tag_size = 10;
		$bytes = fread($fh, 4);
		$temp = array_reverse(unpack("C4", $bytes));
		for($i=0; $i<=3; $i++) {
			$tag_size += $temp[$i] * pow(128,$i);
		}
		$h->tag_size = $tag_size;

		return $h;
	}

	function getVBR($fh, $id, $mode, &$offset) {
		$offset += 4;

		if ($id) {
			$offset += $mode == 2 ? 17 : 32;
		} else {
			$offset += $mode == 2 ? 9 : 17;
		}

		$bytes = $this->Seek($fh, $offset);

		if ($bytes != "Xing") return 0;

		$bytes = $this->Seek($fh, $offset);

		$vbr['flags'] = $this->unpackHeader($bytes);

		if ($vbr['flags'] & 1) {
			$bytes = $this->Seek($fh, $offset);
			$vbr['frames'] = $this->unpackHeader($bytes);
		}

		if ($vbr['flags'] & 2) {
			$bytes = $this->Seek($fh, $offset);
			$vbr['bytes'] = $this->unpackHeader($bytes);
		}

		if ($vbr['flags'] & 4) {
			$bytes = $this->Seek($fh, $offset, 100);
		}

		if ($vbr['flags'] & 8) {
			$bytes = $this->Seek($fh, $offset);
			$vbr['scale'] = $this->unpackHeader($bytes);
		} else {
			$vbr['scale'] = -1;
		}

		return $vbr;
	}

	function isValidMP3Header($bits) {
		if (strlen($bits) != 32) return false;
		if (substr_count(substr($bits,0,11),'0') != 0) return false;
		if ($bits[16] + $bits[17] + $bits[18] + $bits[19] == 4) return false;
		return true;
	}

	function getOgg($info, $tag) {
		$fh = fopen($this->file, 'rb');

		// Page 1 - Stream Header
		$h = null;
		if (!$this->getOggHeader($fh, $h)) { return $this->getBadInfo(); }

		if ($info) {
			$this->filesize = filesize($this->file);

			$data = fread($fh, 23);
			$offset = 0;

			$this->frequency = implode('',unpack('V1', substr($data, 5, 4)));
			$bitrate_average = 0;

			if (substr($data, 9, 4) !== chr(0xFF).chr(0xFF).chr(0xFF).chr(0xFF)) {
				$bitrate_max = implode('',unpack('V1', substr($data, 9, 4)));
			}
			if (substr($data, 13, 4) !== chr(0xFF).chr(0xFF).chr(0xFF).chr(0xFF)) {
				$bitrate_nominal = implode('',unpack('V1', substr($data, 13, 4)));
			}
			if (substr($data, 17, 4) !== chr(0xFF).chr(0xFF).chr(0xFF).chr(0xFF)) {
				$bitrate_min = implode('',unpack('V1', substr($data, 17, 4)));
			}
		}

		if ($tag) {
			// Page 2 - Comment Header
			if (!$this->getOggHeader($fh, $h)) { return $this->getBadInfo(); }
			$data = fread($fh, 16384);
			$offset = 0;
			$vendorsize = implode('',unpack('V1', substr($data, $offset, 4)));
			$offset += (4 + $vendorsize);
			$totalcomments = implode('',unpack('V1', substr($data, $offset, 4)));
			$offset += 4;

			for ($i = 0; $i < $totalcomments; $i++) {
				$commentsize = implode('',unpack('V1', substr($data, $offset, 4)));
				$offset += 4;
				$commentstring = substr($data, $offset, $commentsize);
				$offset += $commentsize;
				$comment = explode('=', $commentstring, 2);
				$comment[0] = strtolower($comment[0]);
				$this->$comment[0] = $comment[1];
			}
			$this->tag_version = "ogg";
			$this->tag = 1;
		}

		if ($info) {
			// Last Page - Number of Samples
			fseek($fh, max($this->filesize - 16384, 0), SEEK_SET);
			$LastChunkOfOgg = strrev(fread($fh, 16384));
			if ($LastOggSpostion = strpos($LastChunkOfOgg, 'SggO')) {
				fseek($fh, 0 - ($LastOggSpostion + strlen('SggO')), SEEK_END);
				if (!$this->getOggHeader($fh, $h)) { return $this->getBadInfo(); }
				$samples = $h->pcm;
				$bitrate_average = ($this->filesize * 8) / ($samples / $this->frequency);
			}

			if ($bitrate_average > 0) {
				$this->bitrate = $bitrate_average;
			} else if (isset($bitrate_nominal) && ($bitrate_nominal > 0)) {
				$this->bitrate = $bitrate_nominal;
			} else if (isset($bitrate_min) && isset($bitrate_max)) {
				$this->bitrate = ($bitrate_min + $bitrate_max) / 2;
			}

			$this->bitrate = (int) ($this->bitrate / 1000);
			$s = -1;
			if (isset($this->bitrate)) {
				$s = (float) (($this->filesize * 8) / $this->bitrate / 1000);
			}
			$this->time = sprintf('%.2d:%02d',floor($s/60),floor($s-(floor($s/60)*60)));
			$this->info = 1;
		}
		return true;
	}

	function getOggHeader(&$fh, &$h) {
		$baseoffset = ftell($fh);
		$data = fread($fh, 16384);
		$offset = 0;
		while ((substr($data, $offset++, 4) != 'OggS')) {
			if ($offset >= 10000) { return FALSE; }
		}

		$offset += 5;
		$h->pcm = implode('',unpack('V1', substr($data, $offset)));
		$offset += 20;
		$segments = implode('',unpack('C1', substr($data, $offset)));
		$offset += ($segments + 8);
		fseek($fh, $offset + $baseoffset, SEEK_SET);

		return true;
	}

	function getBadInfo() {
		$this->time = $this->bitrate = $this->frequency = 0;
		$this->filesize = filesize($this->file);
		return false;
	}

	function Seek($fh, &$offset, $n = 4) {
			fseek($fh, $offset);
			$bytes = fread($fh, $n);
			$offset += $n;
			return $bytes;
	}

	function unpackHeader($byte) {
		return implode('', unpack('N', $byte));
	}
}

#	Internal compression of files via PHP zlib extension
#	This is most likely based on class zipfile by Eric Mueller <www.themepark.com>
class zipfile {
	var $datasec = array();
	var $rootdir = array();
	var $offset	= 0;

	function add_file($data,$name) {
		#$name	= str_replace('\\', '/', $name);
		$name	= basename($name);
		$ctime = getdate();
		$ctime = preg_replace("/(..){1}(..){1}(..){1}(..){1}/","\\x\\4\\x\\3\\x\\2\\x\\1",dechex(($ctime['year']-1980<<25)|($ctime['mon']<<21)|($ctime['mday']<<16)|($ctime['hours']<<11)|($ctime['minutes']<<5)|($ctime['seconds']>>1)));
		eval('$ctime = "'.$ctime.'";');

		$crc = crc32($data);
		$nlength	= strlen($data);
		$zdata = gzcompress($data,0);
		$zdata = substr(substr($zdata,0,strlen($zdata) - 4),2);
		$clength = strlen($zdata);

		$this->datasec[] = "\x50\x4b\x03\x04\x14\x00\x00\x00\x08\x00$ctime".pack('V',$crc).pack('V',$clength).pack('V',$nlength).pack('v',strlen($name)).pack('v',0).$name.$zdata.pack('V',$crc).pack('V',$clength).pack('V',$nlength);
		$this->rootdir[] = "\x50\x4b\x01\x02\x00\x00\x14\x00\x00\x00\x08\x00$ctime".pack('V',$crc).pack('V',$clength).pack('V',$nlength).pack('v',strlen($name)).pack('v',0).pack('v',0).pack('v',0).pack('v',0).pack('V',32).pack('V',$this->offset).$name;
		$this->offset = strlen(implode('',$this->datasec));
	}

	function file() {
		$data	= implode('',$this->datasec);
		$ctrldir	= implode('',$this->rootdir);
		return $data.$ctrldir."\x50\x4b\x05\x06\x00\x00\x00\x00".pack('v',sizeof($this->rootdir)).pack('v',sizeof($this->rootdir)).pack('V',strlen($ctrldir)).pack('V',strlen($data))."\x00\x00";
	}
}
#TODO: move
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * TEMPLATE
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function getTemplate($t) {
	global $zc;
	$theme = $zc['theme'];

	if (!isset($_SESSION['zt'][$theme][$t]) || (isset($_GET['r']) && $_GET['r'] == 1)) {
		$tmpl = $_SESSION['zt'][$theme][$t] = implode("",file($zc['zina_dir']."/themes/$theme/template-$t.html"));
	} else {
		$tmpl = $_SESSION['zt'][$theme][$t];
	}
	return $tmpl;
}

function tmpDelSec($tmpl, $sect, $repl="") {
	return preg_replace("/(<!--z-beg:$sect-->.*?<!--z-end:$sect-->)/s", $repl ,$tmpl);
}

function tmpGetSect($tmpl, $sect) {
	if (preg_match("/<!--z-beg:$sect-->(.*?)<!--z-end:$sect-->/si",$tmpl, $match)) return $match[1];
}

function getThemes() {
	global $zc;
	$dir = $zc['zina_dir']."/themes";
	$d = dir($dir) or die("getThemes: Dir no exist");
	while($entry = $d->read()) {
		if ($entry == "." || $entry == "..") { continue; }
		$opts[$entry] = $entry;
	}
	$d->close();
	return $opts;
}

function getLanguages() {
	global $zc;
	$lang = getSettings("lang");

	$dir = $zc['zina_dir']."/lang";
	$d = dir($dir) or die ("getLanguages: dir no exist");
	while($entry = $d->read()) {
		if ($entry == "." || $entry == "..") { continue; }
		$base = basename($entry,".php");
		$opts[$base] = (isset($lang[$base])) ? $lang[$base] : $base;
	}
	$d->close();
	asort($opts);
	return $opts;
}

#TODO: move
function writeConfig() {
	global $z_dir, $zc;
#TODO: make sure posting from server same as file...
#TODO: error checking/feedback
	$fields = getSettings("cfg");
	$config = "<?php\n";
	$diff = false;
	foreach($fields as $field) {
		$name = $field['id'];
		if ($_POST[$name] != $field['def']) {
			if ($name == 'adm_pwd') {
				if ($_POST['adm_pwd'] == $_POST['adm_pwd_con']
						&& checkPwd($zc['adm_name'], $_POST['adm_pwd_old'])) {
					$config .= "\$adm_pwd = \"".getPasswordHash($_POST['adm_pwd'])."\";\n";
					$diff = true;
				} else { continue; }
			} else {
				if ($name == 'main_dir_title' && $_POST[$name] == _ZARTISTS) continue;
				if ($name == 'dir_list_txt' && $_POST[$name] == _ZALBUMS) continue;
				if ($name == 'alt_text' && $_POST[$name] == _ZRELATED) continue;
				if ($name == 'ran_def' && ($_POST[$name] == _ZSONGS || $_POST[$name] == _ZALBUMS)) continue;
				$config .= "\$$name = \"".  preg_replace("/(|\n|\r)/","",trim($_POST[$name]))."\";\n";
				$diff = true;
			}
		}
	}

	$config .= "?>";
	$file = "$z_dir/zina.ini.php";

	if ((file_exists($file) && is_writeable($file)) || is_writeable($z_dir)) {
		if (!$diff && file_exists($file)) {
			unlink($file);
		} else {
			$fp = fopen($file, "w") or die(_ZERROR);
			fwrite($fp,$config);
			fclose($fp);
		}
	} else {
		pageGeneric("cfgerr",_ZERROR, $config, $file);
		exit;
	}
}

function setConfig(&$cfg) {
	global $z_dir, $z_embed, $z_login;
	$settings = getSettings("cfg");
	$tmpfname = '$tmpfname'; #backwards compat hack
	@include("$z_dir/zina.ini.php");
	foreach($settings as $arr) {
		$cfg[$arr['id']] = isset($$arr['id']) ? $$arr['id'] : $arr['def'];
		if ($arr['id'] == 'media_types') $def_mt = $arr['def'];
	}

	$cfg['cache_dir'] = $cfg['zina_dir']."/cache";
	if (!is_dir($cfg['mp3_dir'])) {
		echo "<h3>mp3_dir is not a directory, setting to '$z_dir'</h3>";
		$cfg['mp3_dir'] = $z_dir;
	}
	if ($cfg['stream_int'] || !preg_match("#^${_SERVER['DOCUMENT_ROOT']}#i",$cfg['mp3_dir'])) {
		$cfg['stream_int'] = true;
	} else {
		$cfg['www_path'] = preg_replace("#^${_SERVER['DOCUMENT_ROOT']}#i", "", $cfg['mp3_dir']);
	}
	eval("\$enc_arr = array(".$cfg['enc_arr'].");");
	$cfg['ext_enc'] = implode("|",array_keys($enc_arr));

	$cfg['m_types'] = ($cfg['other_media_types']) ? $cfg['media_types'] : $def_mt;

	eval("\$media_types = array(".$cfg['m_types'].");");
	$cfg['ext_mus'] = implode("|",array_keys($media_types));

	eval("\$cfg['media_playlist'] = array(".$cfg['media_pls'].");");
	$cfg['ran_opts'] = explode(",", $cfg['ran_opts']);
	$cfg['auth'] = ($cfg['apache_auth'] && isset($_SERVER['PHP_AUTH_USER'])) ? $_SERVER['PHP_AUTH_USER'].":".$_SERVER['PHP_AUTH_PW']."@" : "";

	if ($cfg['mm']) {
		eval("\$tmp = array(".$cfg['mm_types'].");");
		$cfg['mm_ext'] = implode("|",array_keys($tmp));
	}

	if ($cfg['cron']) {
		$opts = explode("|", $cfg['cron_opts']);
		$cron_opts = "";
		foreach($opts as $opt) {
			$cron_opts .= '$cfg["cron_options"]'."$opt;";
		}
		#TODO: still necessary?
		unset($cfg['cron_options']);
		#TODO
		#session_unregister('zt');
		eval($cron_opts);
	}
	if (isset($z_embed)) $cfg['embed'] = $z_embed;
}

function getSettings($type = "") {
	#v=validation = array(0=>'None', 1=>'Not Empty', 2=>'Numeric'); #???
	#type=text,textarea,radio,select,hidden,none

	if ($type == "lang") {
		return array('nl'=>'Dutch', 'it'=>'Italian', 'cn'=>'Chinese (Traditional)', 'zh-cn'=>'Chinese (Simplified)',
			'fr'=>'French', 'da'=>'Danish', 'bg'=>'Bularian', 'hr'=>'Croatian', 'il'=>'Hebrew',
			'eu'=>'Basque', 'ru'=>'Russian [UTF-8]', 'rukoi'=>'Russian [KOI8-R]', 'ruwin'=>'Russian [Windows-1251]',
			'no'=>'Norwegian', 'tr'=>'Turkish', 'hu'=>'Hungarian', 'sk'=>'Slovakian', 'se'=>'Swedish',
			'ca'=>'Catalan', 'br'=>'Brazilian', 'al'=>'Albanian', 'ro'=>'Romanian', 'fi'=>'Finnish', 'en'=>'English',
			'de'=>'German', 'es'=>'Spanish', 'el'=>'Greek', 'kn'=>'Kannada', 'id'=>'Bahasa Indonesia', 'jp'=>'Japanese',
			'ms'=>'Malay', 'pt'=>'Portuguese', 'et'=>'Estonian', 'sl'=>'Slovenian'
		);
	} elseif ($type == "cfg") {
		global $z_dir, $zc;
		$dir = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? str_replace("\\",'/',$z_dir) : $z_dir;
		$dr_len = strlen($_SERVER['DOCUMENT_ROOT']);
		$root_dir = ($dr_len < strlen("$dir/_zina")) ? str_replace('\\','/',substr("$dir/_zina", $dr_len)) : "";

		if (isset($zc['lang'])) {
			$l_songs = _ZSONGS;
			$l_albums = _ZALBUMS;
			$l_none = _ZNONE;
			$tf = array(1=>_ZTRUE, 0=>_ZFALSE);
		} else {
			$tf = $l_songs = $l_albums = $l_none = "";
		}

		return array(
			array('c'=>5, 'id'=>'mp3_dir', 'type'=>'text', 'def'=>"$dir/music", 'v'=>1 ),
			array('c'=>5, 'id'=>'zina_dir', 'type'=>'text', 'def'=>"$dir/_zina", 'v'=>1 ),
			array('c'=>5, 'id'=>'root_dir', 'type'=>'text', 'def'=>$root_dir, 'v'=>1 ),
			array('c'=>5, 'id'=>'lang', 'type'=>'select', 'opts'=>'getLanguages()', 'def'=>'en', 'v'=>0 ),
			array('c'=>5, 'id'=>'charset_over', 'type'=>'text', 'def'=>'', 'v'=>0 ),

			array('c'=>5, 'id'=>'theme', 'type'=>'select', 'opts'=>'getThemes()', 'def'=>'zina-light', 'v'=>1 ),
			array('c'=>5, 'id'=>'embed', 'type'=>'select', 'opts'=>array(0=>$l_none,1=>'PHPNuke',2=>'PostNuke',3=>'Xoops',4=>'Mambo'), 'def'=>0 ),
			array('c'=>5, 'id'=>'pn_users', 'type'=>'radio', 'opts'=>$tf, 'def'=>0 ),

			array('c'=>5, 'id'=>'width', 'type'=>'text', 'def'=>'725', 'v'=>2 ),
			array('c'=>5, 'id'=>'main_dir_title', 'type'=>'text', 'def'=>'Artists', 'v'=>0 ),

			array('c'=>5, 'id'=>'play', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'play_sel', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'play_rec', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>5, 'id'=>'play_rec_rand', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'nav', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'search', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'download', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'amg', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>5, 'id'=>'random', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>5, 'id'=>'ran_def', 'type'=>'select', 'opts'=>array('Songs'=>$l_songs, 'Albums'=>$l_albums), 'def'=>'Songs', 'v'=>0 ),
			array('c'=>5, 'id'=>'ran_opts', 'type'=>'text', 'def'=>'1,5,10,25,50,0', 'v'=>0 ),
			array('c'=>5, 'id'=>'ran_opts_def', 'type'=>'text', 'def'=>25, 'v'=>2 ),
			array('c'=>5, 'id'=>'honor_custom', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>5, 'id'=>'cache', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>1 ),
			array('c'=>5, 'id'=>'cache_limit', 'type'=>'text', 'def'=>7, 'v'=>2) ,
			array('c'=>5, 'id'=>'timeout', 'type'=>'text', 'def'=>120, 'v'=>2 ),
			array('c'=>5, 'id'=>'ext_graphic', 'type'=>'text', 'def'=>'jpg|gif|png|jpeg', 'v'=>1 ),
			array('c'=>5, 'id'=>'local_path', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>5, 'id'=>'html_space', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>65, 'id'=>'genres', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),

			array('c'=>85, 'id'=>'adm_pwd', 'type'=>'password', 'def'=>'{md5}jtM+aM68CE1F38JDDGnhOT5302s=', 'v'=>1 ),
			array('c'=>85, 'id'=>'adm_name', 'type'=>'text', 'def'=>'admin', 'v'=>0 ),
			array('c'=>85, 'id'=>'loc_is_adm', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>85, 'id'=>'adm_ips', 'type'=>'text', 'def'=>'', 'v'=>0 ),
			array('c'=>85, 'id'=>'apache_auth', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),

			array('c'=>15, 'id'=>'stream_int', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>1) ,
			array('c'=>15, 'id'=>'stream_extinf', 'type'=>'radio', 'opts'=>$tf, 'def'=>0 ),

			array('c'=>90, 'id'=>'playlists', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>90, 'id'=>'session_pls', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>90, 'id'=>'sp_len', 'type'=>'text', 'def'=>5000, 'v'=>2 ),
			array('c'=>90, 'id'=>'wmp', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>90, 'id'=>'wmp_force', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),

			array('c'=>10, 'id'=>'dir_img_missing', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_file', 'type'=>'text', 'def'=>'index.txt', 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_imgs', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_year', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_genre', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_genre_look', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_skip', 'type'=>'text', 'def'=>'_', 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_regex', 'type'=>'text', 'def'=>'/^[0-9][0-9][ ]?-[ ]?/i', 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_srch', 'type'=>'text', 'def'=>'_', 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_repl', 'type'=>'text', 'def'=>' ', 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_sort_ignore', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>10, 'id'=>'dir_si_str', 'type'=>'text', 'def'=>'the|a', 'v'=>0 ),

			array('c'=>35, 'id'=>'cat_file', 'type'=>'text', 'def'=>'zina_category', 'v'=>1 ),
			array('c'=>35, 'id'=>'cat_width', 'type'=>'text', 'def'=>'725', 'v'=>2 ),
			array('c'=>35, 'id'=>'cat_cols', 'type'=>'text', 'def'=>4, 'v'=>2 ),
			array('c'=>35, 'id'=>'cat_trunc', 'type'=>'text', 'def'=>25, 'v'=>2 ),
			array('c'=>35, 'id'=>'cat_split', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>35, 'id'=>'cat_pp', 'type'=>'text', 'def'=>90, 'v'=>2 ),

			array('c'=>25, 'id'=>'dir_list', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>1 ),
			array('c'=>25, 'id'=>'dir_list_txt', 'type'=>'text', 'def'=>'Albums', 'v'=>0 ),
			array('c'=>25, 'id'=>'dir_list_len', 'type'=>'text', 'def'=>24, 'v'=>2 ),

			array('c'=>30, 'id'=>'subdir_images', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),
			array('c'=>30, 'id'=>'subdir_cols', 'type'=>'text', 'def'=>3, 'v'=>2 ),
			array('c'=>30, 'id'=>'subdir_center', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>30, 'id'=>'subdir_img_cap', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>30, 'id'=>'subdir_img_missing', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>20, 'id'=>'new_highlight', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>1 ),
			array('c'=>20, 'id'=>'new_time', 'type'=>'text', 'def'=>14, 'v'=>2 ),
			array('c'=>20, 'id'=>'new_img', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>1 ),
			array('c'=>20, 'id'=>'new_beg', 'type'=>'text', 'def'=>'', 'v'=>0 ),
			array('c'=>20, 'id'=>'new_end', 'type'=>'text', 'def'=>'', 'v'=>0 ),

			array('c'=>75, 'id'=>'alt_dirs', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>75, 'id'=>'alt_images', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>75, 'id'=>'alt_file', 'type'=>'text', 'def'=>'zina_alt', 'v'=>0 ),
			array('c'=>75, 'id'=>'alt_text', 'type'=>'text', 'def'=>'See Also', 'v'=>0 ),

			array('c'=>40, 'id'=>'mp3_info', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>1 ),
			array('c'=>40, 'id'=>'mp3_info_faster', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>1 ),
			array('c'=>40, 'id'=>'mp3_id3', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),

			array('c'=>40, 'id'=>'song_regex', 'type'=>'text', 'def'=>'/^.*[0-9][0-9][ _]?-[ _]?/i', 'v'=>0 ),
			array('c'=>40, 'id'=>'song_srch', 'type'=>'text', 'def'=>'_', 'v'=>0 ),
			array('c'=>40, 'id'=>'song_repl', 'type'=>'text', 'def'=>' ', 'v'=>0 ),
			array('c'=>40, 'id'=>'song_blurbs', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>45, 'id'=>'various', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>45, 'id'=>'various_file', 'type'=>'text', 'def'=>'zina_various', 'v'=>0 ),

			array('c'=>50, 'id'=>'fake', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>50, 'id'=>'fake_ext', 'type'=>'text', 'def'=>'fake', 'v'=>0 ),

			array('c'=>55, 'id'=>'remote', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>55, 'id'=>'remote_ext', 'type'=>'text', 'def'=>'rem', 'v'=>0 ),

			array('c'=>70, 'id'=>'low', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>70, 'id'=>'low_suf', 'type'=>'text', 'def'=>'.lofi', 'v'=>0 ),
			array('c'=>70, 'id'=>'low_lookahead', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),

			array('c'=>80, 'id'=>'resample', 'type'=>'radio', 'opts'=>$tf, 'def'=>0 ),
			array('c'=>80, 'id'=>'enc_arr', 'type'=>'textarea', 'def'=>"'mp3' => array('enc' => 'lame', 'opts' => '--mp3input -f -b56 --lowpass 12.0 --resample 22.05 - <', 'output' => 'audio/mpeg'),".
				"'wav' => array('enc' => 'lame', 'opts' => '-f -b56 --lowpass 12.0 --resample 22.05 - <', 'output' => 'audio/mpeg'),"),

			array('c'=>95, 'id'=>'res_in_types', 'type'=>'text', 'def'=>'jpg|jpeg|png', 'v'=>0 ),
			array('c'=>95, 'id'=>'res_out_type', 'type'=>'text', 'def'=>'jpeg', 'v'=>0 ),
			array('c'=>95, 'id'=>'res_dir_qual', 'type'=>'text', 'def'=>75, 'v'=>2 ),
			array('c'=>95, 'id'=>'res_dir_img', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>95, 'id'=>'res_dir_x', 'type'=>'text', 'def'=>300, 'v'=>2 ),
			array('c'=>95, 'id'=>'res_sub_qual', 'type'=>'text', 'def'=>75, 'v'=>2 ),
			array('c'=>95, 'id'=>'res_sub_img', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>95, 'id'=>'res_sub_x', 'type'=>'text', 'def'=>200, 'v'=>0 ),
			array('c'=>95, 'id'=>'res_out_x_lmt', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>95, 'id'=>'dir_img_txt', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>95, 'id'=>'dir_img_txt_color', 'type'=>'text', 'def'=>'255,255,255', 'v'=>0 ),
			array('c'=>95, 'id'=>'sub_img_txt', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>95, 'id'=>'sub_img_txt_color', 'type'=>'text', 'def'=>'0,0,0', 'v'=>0 ),
			array('c'=>95, 'id'=>'img_txt_wrap', 'type'=>'text', 'def'=>20, 'v'=>2 ),
			array('c'=>95, 'id'=>'img_txt_font', 'type'=>'text', 'def'=>'C:\WINNT\Fonts\arial.ttf', 'v'=>0 ),
			array('c'=>95, 'id'=>'img_txt_font_size', 'type'=>'text', 'def'=>12, 'v'=>2 ),

			array('c'=>105, 'id'=>'cmp_sel', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>105, 'id'=>'cmp_int', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>105, 'id'=>'cmp_pgm', 'type'=>'text', 'def'=>'C:\cygwin\bin\zip', 'v'=>0 ),
			array('c'=>105, 'id'=>'cmp_ext', 'type'=>'text', 'def'=>'zip', 'v'=>0 ),
			array('c'=>105, 'id'=>'cmp_set', 'type'=>'text', 'def'=>'-0 -j -', 'v'=>0 ),
			array('c'=>105, 'id'=>'cmp_mime', 'type', 'type'=>'text', 'def'=>'application/zip', 'v'=>0 ),

			array('c'=>110, 'id'=>'pos', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>110, 'id'=>'pos_hack', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>110, 'id'=>'pos_cmd', 'type'=>'text', 'def'=>'bgrun.exe C:\Progra~1\Winamp\winamp.exe $tmpfname.m3u >NUL', 'v'=>0 ),
			array('c'=>110, 'id'=>'pos_kill', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>110, 'id'=>'pos_kill_cmd', 'type'=>'text', 'def'=>'killall mpg123', 'v'=>0 ),

			array('c'=>115, 'id'=>'other_media_types', 'type'=>'radio', 'opts'=>$tf, 'def'=>0 ),
			array('c'=>115, 'id'=>'media_types', 'type'=>'textarea', 'def'=>"'mp3' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'audio/mpeg'), 'ogg' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'application/x-ogg'), 'wav' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'audio/x-wav'), 'wma' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'audio/x-ms-wma'),"),
			array('c'=>115, 'id'=>'media_pls', 'type'=>'textarea', 'def'=>"'m3u' => 'audio/mpegurl', 'ram' => 'audio/x-pn-realaudio', 'asx' => 'video/x-ms-asf',"),

			array('c'=>60, 'id'=>'mm', 'type'=>'radio', 'opts'=>$tf, 'def'=>0, 'v'=>0 ),
			array('c'=>60, 'id'=>'mm_text', 'type'=>'text', 'def'=>'Multimedia', 'v'=>0 ),
			array('c'=>60, 'id'=>'mm_types', 'type'=>'textarea', 'def'=>"'avi'=>array('mime'=>'video/msvideo','p'=>'WMP'), 'mpg'=>array('mime'=>'video/mpeg','p'=>'WMP'), 'mpeg'=>array('mime'=>'video/mpeg','p'=>'WMP'), 'asf'=>array('mime'=>'video/x-ms-asf','p'=>'WMP'), 'wmv'=>array('mime'=>'video/x-ms-wmv','p'=>'WMP'), 'mov'=>array('mime'=>'video/quicktime','p'=>'QT'), 'pdf'=>array('mime'=>'application/pdf')", 'v'=>0 ),
			array('c'=>60, 'id'=>'mm_down', 'type'=>'radio', 'opts'=>$tf, 'def'=>1, 'v'=>0 ),

			array('c'=>120, 'id'=>'cron', 'type'=>'radio', 'opts'=>$tf, 'def'=>0 ),
			array('c'=>120, 'id'=>'cron_opts', 'type'=>'textarea', 'def'=>""),
		);
	} elseif ($type == "cat" || $type == "titles" || $type = "other") {
		global $zc;
		$lang_file = $zc['zina_dir']."/lang-cfg/".$zc['lang'].".php";
		if (file_exists($lang_file)) {
			require($lang_file);
		} else {
			require($zc['zina_dir']."/lang-cfg/en.php");
		}
		if ($type == "cat") return $cats;
		elseif ($type == "titles") return $titles;
		elseif ($type == "other") return $other;
	}
}
?>
