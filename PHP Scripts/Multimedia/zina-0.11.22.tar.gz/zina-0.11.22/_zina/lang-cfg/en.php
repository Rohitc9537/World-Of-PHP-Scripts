<?php
# Zina config: English by Ryan
$titles = array(
	'mp3_dir'=>'Music Directory (full path)<br>(Windows use forward slash, e.g. F:/music)',
	'zina_dir'=>'Zina Files Directory (full path)<br>(Windows use forward slash, e.g. F:/_zina)',
	'root_dir'=>'Zina Files Directory (relative path)',
	'lang'=>'Language',
	'charset_over'=>'Override language character set',
	'theme'=>'Theme',
	'embed'=>'Embedded',
	'pn_users'=>'Post/PHPnuke logged in users only',
	'width'=>'Zina width',
	'main_dir_title'=>'Title of Main Directory',
	'play'=>'Show option to "play"',
	'play_sel'=>'Show option to "play selected"',
	'play_rec'=>'Show option to "play recursive"',
	'play_rec_rand'=>'Show option to "play recursive random"',
	'nav'=>'Show navigation',
	'search'=>'Show search form',
	'download'=>'Show download icon',
	'amg'=>'Show AMG search box',
	'genres'=>'Genre functionality',
	'playlists'=>'Playlist functionality (other options depend on this)',
	'session_pls'=>'Allow user to have session playlist',
	'wmp'=>'Show an option to use .asx files instead (WMP)',
	'wmp_force'=>'Only return .asx files (WMP).  Requires previous set to true',
	'sp_len'=>'Max length of session playlist',
	'random'=>'Show play random option',
	'ran_def'=>'Default random selected',
	'ran_opts'=>'Random Number Options',
	'ran_opts_def'=>'Default random number "selected"',
	'honor_custom'=>'Have random play use custom playlists',
	'cache'=>'Use Cache (cache dir must be writeable by web server)',
	'cache_limit'=>'Cache life (in days)',
	'timeout'=>'Script timeout (in seconds)',
	'ext_graphic'=>'Extensions of graphic files',
	'local_path'=>'Use local paths when running Zina locally', 
	'html_space'=>'Remove white space between HTML tags', 
	'adm_name'=>'Administrator user name', 
	'loc_is_adm'=>'If running on local machine, user is admin', 
	'adm_ips'=>'If remote IP is found in this string, remote user is admin', 
	'apache_auth'=>'Append Apache user:password to playlist urls', 
	'stream_int'=>'Stream internally', 
	'stream_extinf'=>'Add #EXTINF Artist - Title info to playlists', 
	'dir_file'=>'Name of blurb file for directories', 
	'dir_imgs'=>'If multiple directory images, let clicking on image rotate through them', 
	'dir_year'=>'Show album year (based on ID3 tag)', 
	'dir_genre'=>'Show album genre (based on ID3 tag)', 
	'dir_genre_look'=>'Show genre on a artist page by looking at an album genre (based on ID3 tag)', 
	'dir_skip'=>'Dirs with this prefix are not displayed', 
	'dir_regex'=>'Regex that cleans up sub-directory names', 
	'dir_srch'=>'String to search for in directory title', 
	'dir_repl'=>'String to replace', 
	'dir_img_missing'=>'Show a "missing directory" image', 
	'dir_sort_ignore'=>'Ignore string at beginning of directory name for sorting purposes', 
	'dir_si_str'=>'String to ignore', 
	'cat_file'=>'Name of file that makes a directory a "category"', 
	'cat_width'=>'Category Width', 
	'cat_cols'=>'Number of columns on a "category" page', 
	'cat_trunc'=>'Length of text to truncate after', 
	'cat_split'=>'Split category page into different pages', 
	'cat_pp'=>'Number of items per split page (prettier if a multiple of category colums)', 
	'dir_list'=>'Display sub-directory listing', 
	'dir_list_txt'=>'Title of sub-directory listing', 
	'dir_list_len'=>'Truncate long sub-directory names', 
	'subdir_images'=>'Display sub-directory images', 
	'subdir_center'=>'Center sub-directory images', 
	'subdir_cols'=>'Number of columns for sub-directory images', 
	'subdir_img_cap'=>'Display sub-dir name below sub-dir image', 
	'subdir_img_missing'=>'Show a "missing sub-dir" image', 
	'new_highlight'=>'Highlight new files and directories', 
	'new_time'=>'Highlight within how many days?', 
	'new_img'=>'Use theme image', 
	'new_beg'=>'Prefixed string', 
	'new_end'=>'Suffixed string', 
	'alt_dirs'=>'Alternate/Related Directories',
	'alt_images'=>'Display Alternate/Related Directories Images',
	'alt_file'=>'Filename that contains list',
	'alt_text'=>'Text heading',
	'mp3_info'=>'Get filesize, length, kpbs, time from mp3 files?', 
	'mp3_info_faster'=>'Get mp3 info faster (slightly less accurate)', 
	'mp3_id3'=>'Use ID3v1/2 song titles (if they exist)', 
	'song_regex'=>'If no ID3 tags, this regex cleans up song titles', 
	'song_srch'=>'String to search for in song title', 
	'song_repl'=>'String to replace', 
	'song_blurbs'=>'Check for song blurb (named same as mp3, but with .txt instead)', 
	'various'=>'Display "Artist - Title" as song title (needs ID3 tags)', 
	'various_file'=>'Name of file to make a directory list as "Artist - Title"', 
	'fake'=>'Look for "fake" songs', 
	'fake_ext'=>'Fake file extension', 
	'remote'=>'Look for "remote" songs', 
	'remote_ext'=>'Remote file extension', 
	'low'=>'Look for second (lower quality) mp3 with following suffix', 
	'low_suf'=>'Suffix for lo-fi mp3 name[suffix].ext; e.g. "song.lofi.mp3"', 
	'low_lookahead'=>'Lofi Lookahead: Try only if resample is false, Lofi is true and not all directories have lofi files', 
	'resample'=>'Resample', 
	'enc_arr'=>'Encoding program', 
	'res_in_types'=>'Input resize types (supported by YOUR configuration)', 
	'res_out_type'=>'Output resize type (supported by YOUR configuration)', 
	'res_dir_qual'=>'JPEG quality (1=worst/100=best)', 
	'res_dir_img'=>'Directory images', 
	'res_dir_x'=>'Directory scale to width (pixels)', 
	'res_sub_qual'=>'JPEG quality (1=worst/100=best)', 
	'res_sub_img'=>'Subdirectory images', 
	'res_sub_x'=>'Subdir scale to width (pixels)', 
	'res_out_x_lmt'=>'Only rescale if orig width > rescale width', 
	'dir_img_txt'=>'Write directory title on missing image', 
	'dir_img_txt_color'=>'Directory text color (RGB)', 
	'sub_img_txt'=>'Write subdir title on missing image', 
	'sub_img_txt_color'=>'Subdir text color (RGB)', 
	'img_txt_wrap'=>'Wrap long text at this character', 
	'img_txt_font'=>'Full path to TrueType font', 
	'img_txt_font_size'=>'Font Size', 
	'cmp_sel'=>'Download selected songs as compressed file', 
	'cmp_int'=>'Compression via internal PHP zlib module', 
	'cmp_pgm'=>'Compression program (full path)', 
	'cmp_ext'=>'Compressed file extension', 
	'cmp_set'=>'Compression program options', 
	'cmp_mime'=>'Compressed file mime-type', 
	'pos'=>'Play on server', 
	'pos_hack'=>'mpg123 hack (try if using and having problems)', 
	'pos_cmd'=>'Play on server command', 
	'pos_kill'=>'Kill (necessary on linux/unix systems)', 
	'pos_kill_cmd'=>'Kill command', 
	'other_media_types'=>'Other media types', 
	'media_types'=>'Media types', 
	'media_pls'=>'Media playlists', 
	'cron'=>'Time based functionality', 
	'cron_opts'=>'Time based options', 
	'old_pwd'=>'Old Password',
	'adm_pwd'=>'New Password',
	'con_pwd'=>'Confirm Password',
	'mm'=>'Look for Other Non-Music Media Types',
	'mm_types'=>'Other Non-Music Media Types',
	'mm_down'=>'Allow Download',
	'mm_text'=>'Section Heading',
);

$cats = array(
	5=>array('t'=>"General",
		'd'=>""
		),
	10=>array('t'=>"Directories",
		'd'=>""
		),
	15=>array('t'=>"Stream internally",
		'd'=>""
		),
	20=>array('t'=>"Highlight new directories",
		'd'=>"Based on file modification time.  Might incur a performance penalty.  If not using theme image, you may specify a custom HTML prefix and/or suffix."
		),
	25=>array('t'=>"Subdirectory Listing",
		'd'=>""
		),
	30=>array('t'=>"Subdirectory Images (usually album covers)",
		'd'=>""
		),
	35=>array('t'=>"Directory as Category",
		'd'=>"List directories in a column format.  Good for main directory or any directory with lots of sub-directories."
		),
	40=>array('t'=>"Music Files",
		'd'=>""
		),
	45=>array('t'=>"'Artist - Title' Song Titles",
		'd'=>"Makes songs in a directory display 'Artist - Title' song titles (needs ID3 option).  Good for soundtracks and various artist directories."
		),
	50=>array('t'=>"Fake Files",
		'd'=>"Want to have a song listed but that's not there? Create a file in a songs directory with 'Fake file extension', e.g: 04 - Song Number Four.fake"
		),
	55=>array('t'=>"Remote Files",
		'd'=>"Want to include a song on another server? Create a file in the directory named like the song title with the 'Remote file extension', e.g. 02 - Remote Song.rem".
		"<p>File Format: HTML meta tags where name=url,download,artist,album,title,filesize,bitrate,frequency,time,year,genre<p>File must end in &lt;/head&gt;".
		"<p>Simplest example: ".htmlentities("<meta name='url' content='http://www.somesite.com/somesong.mp3'></head>")
		),
	60=>array('t'=>"Non-Music Media",
		'd'=>"List and/or allow download of non-music media types.  Types should have a graphic file in THEMES/images/mm. <p>If using song blurbs, you can have blurb file with the same name as the file with a .txt extension added. <p>EXPERIMENTAL: If running Zina locally, 'p' allows file to be played embedded in Zina via WMP or QT or add a selection to THEMES/templates-video.html."
		),
	65=>array('t'=>"Genres",
		'd'=>'Genre functionality (based on ID3 tags).  Cache must be enabled.  First generation is automatic, then you have to generate it manually by clicking on the icon when logged in'),
	70=>array('t'=>"Low Fidelity File Options",
		'd'=>""
		),
	75=>array('t'=>'Alternative/Related Directories',
		'd'=>"Will look for a file in the directory with 'Filename' which contains a list of alternative directories the format: DIR/DIR (the names of existing directories).
		Add a trailing slash (e.g. DIR/DIR/) for directories without songs (i.e. other Artists). 
		It will then show those directories on the artist page under '"._ZRELATED."'"
		),
	80=>array('t'=>"Automatic Down/Re-sampling",
		'd'=>"WARNING: using this will most like bring your server to its knees.
But if you want to use it anyway, you will need an external encoder like LAME <http://www.mp3dev.org/mp3/> which can take input from stdin and output to stdout.
Requires Low Fidelity setting"
		),
	85=>array('t'=>"Authentication",
		'd'=>""
		),
	90=>array('t'=>"Playlists",
		'd'=>""
		),
	95=>array('t'=>"Dynamic Image Resizing",
		'd'=>"Needs PHP compiled with GD library: http://us3.php.net/manual/en/ref.image.php
			Make sure GD is functioning without Zina.  Resize types must only contain formats supported by YOUR setup.
			<P>NOTE: I cannot support Apache/PHP/GD config questions."
		),
	100=>array('t'=>"TODO",
		'd'=>""
		),
	105=>array('t'=>"Download selected files as one compressed file",
		'd'=>"Requires an external cmd line compression program like zip or gzip, or php zlib module.
		Will put a strain on your server."
		),
	110=>array('t'=>"Play on Server",
		'd'=>'Play songs on the server Zina runs on as opposed to playing on the browser\'s machine.
		<p><b>Windows/WinAmp</b> (You will most likely need http://www.jukkis.net/bgrun/bgrun.exe)
		<br>Command example: bgrun.exe C:\Progra~1\Winamp\winamp.exe $tmpfname.m3u >NUL
		<p><b>Linux/mpg123</b>
		<br>Command example: /usr/bin/mpg123 -q --list $tmpfname.m3u 0 1> /dev/null 2>&1 &
		<p><b>OS/2</b> and eCS try using Z! http://dink.org/z/
		<br>Command example: z.exe -p $tmpfname.m3u >NUL'
		),
	115=>array('t'=>"Media Types",
		'd'=>"Default setting: mp3,ogg,wav,wma using .m3u playlists via http protocol.
		<p>To enable other media types, set 'Other Media Types' to true and add a new line.  
		<p>Some examples:
		<br>'mid' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'audio/midi'),
		<br>'ra' => array('ext' => 'ram', 'proto' => 'http', 'type' => 'audio/x-pn-realaudio'),
		<br>'wma' => array('ext' => 'asx', 'proto' => 'mms', 'type' => 'audio/x-ms-wma'),
		<br>'ra' => array('ext' => 'ram', 'proto' => 'rtsp', 'type' => 'audio/vnd.rn-realaudio'),"
		),
	120=>array('t'=>"Time Based Functionality",
		'd'=>"(new in 10.0.17, not fully tested)
		<p>Any feature that is set 'true' or 'false' can be optionally set to work 
		during certain time periods using 'cron'-like syntax.
		<br>NOTE: will override true/false settings. won't affect admin.</p>
		<br><code>['X'][] = 'TIME'</code>  
		<br>Use a '|' between settings.
		<br>X = setting (See drop down below)
		<br>TIME = 'WDAY MON MDAY HH:MM' (where...WDAY=0-6, with 0=Sunday; MON=1-12; MDAY=1-31; HH:MM=0-23:0-59)
		<br>'*' matches all; use comma between multiple values, a hyphen to indicate range
		<br>Example 1: Would show play icon all the time (totally pointless)
		<br><code>['play'][] = '* * * *'</code>
		<br>Example 2: Would show download icon between 10pm and 6am everyday...
		<br><code>['download'][] = '* * * 22:00-6:00'</code>
		<br>Example 3: Would show download icon Monday thru Friday during Jan, Mar, May for the first 15 days between 8am and 5pm)
		<br><code>['download'][] = '1-5 1,3,5 1-15 8:00-17:00'</code>
		<br>Example 4: Would show download icon between Midnight and 6am M-F and all day Sat & Sun
		<br><code>['download'][] = '* * * 0:00-6:00'|['download'][] = '6-0 * * *'</code>"
		),
	125=>array('t'=>"TODO",
		'd'=>""
		),
);
$other = array(
	'forref'=>"FOR REFERENCE ONLY: NOT ALL THESE OPTIONS MAKE SENSE",
	'song_text'=>'Song Text',
	'dir_text'=>'Directory Text',
	'regen'=>"This will regenerate the cache.\\n\\nIt could take a while.\\n\\nAre your sure you want to do this?",
	'regen_genre'=>"This will regenerate the GENRE cache.\\n\\nIt could take a while.\\n\\nAre your sure you want to do this?",
	'top'=>'Top',
	);
?>
