<?php 
# Zina config: German by Ingo Maurer 
$titles = array( 
	'mp3_dir'=>'Musik Verzeichnis (kompletter Pfad)<br>(Windows benutzt den Schr�gstrich, z.B. F:/_zina)', 
	'zina_dir'=>'Zina Dateiverzeichnis (absoluter Pfad)<br>(Windows benutzt den Schr�gstrich, z.B. F:/_zina)', 
	'root_dir'=>'Zina Dateiverzeichnis (relativer Pfad)', 
	'lang'=>'Sprachauswahl', 
	'charset_over'=>'Andere Zeichenumsetztabelle angeben', 
	'theme'=>'Erscheinungsbild', 
	'embed'=>'Zina eingebunden', 
	'pn_users'=>'Post/PHPnuke nur f�r angemeldete Benutzer', 
	'width'=>'Breite f�r alle Seiten', 
	'main_dir_title'=>'�berschrift des Hauptverzeichnisses', 
	'play'=>'"Anh�ren" anzeigen', 
	'play_sel'=>'"Markierte anh�ren" anzeigen', 
	'play_rec'=>'"Rekursiv anh�ren" anzeigen', 
	'play_rec_rand'=>'"Zuf�llig rekursiv abspielen" anzeigen', 
	'nav'=>'Navigation anzeigen', 
	'search'=>'Suche aktivieren', 
	'download'=>'Download-Symbol anzeigen', 
	'amg'=>'AMG Suche aktivieren', 
	'genres'=>'Genre Funktion', 
	'playlists'=>'Funktion Wiedergabeliste (Andere Optionen h�ngen hiervon ab)', 
	'session_pls'=>'Erlaube Benutzer eine Wiedergabeliste', 
	'wmp'=>'.asx Dateien anstatt .wmp benutzen', 
	'wmp_force'=>'Nur .asx (WMP) Dateien zur�ckgeben. Dazu muss vorherige Option auf "an" gesetzt werden', 
	'sp_len'=>'Maximale l�nge der Wiedergabeliste', 
	'random'=>'"Zuf�lliges abspielen von" aktivieren', 
	'ran_def'=>'Standardauswahl', 
	'ran_opts'=>'Angabe der Auswahlm�glichkeiten (Komma trennt)', 
	'ran_opts_def'=>'Standardeintrag von "Zuf�lliges abspielen von"', 
	'honor_custom'=>'"Zuf�lliges Abspielen von" auch von eigenen Widergabelisten?', 
	'cache'=>'Cache benutzen (Cache-Verzeichnis muss Schreibrechte f�r den Web-Server haben)', 
	'cache_limit'=>'Cache "Lebensdauer" (in Tagen)', 
	'timeout'=>'Skript Timeout (in Sekunden)', 
	'ext_graphic'=>'Dateityp der Bilddateien (Dateisuffixe durch "|" trennen; kein Punkt)', 
	'local_path'=>'Lokale Pfade benutzen, wenn Zina lokal verwendet wird', 
	'html_space'=>'Entfernen von "white space" zwischen HTML-tags?', 
	'adm_name'=>'Benutzername des Admininistrator', 
	'loc_is_adm'=>'Wenn Zina auf einem lokalen Rechner l�uft, ist der Benutzer automtisch Admin', 
	'adm_ips'=>'Wenn von dieser IP-Adresse zugegriffen wird, ist der Benutzer automatisch Admin', 
	'apache_auth'=>'F�r Apache Web-Server: Einf�gen von "user:password" in Wiedergabelisten-URLs',  
	'stream_int'=>'Interner Stream', 
	'stream_extinf'=>'Hinzuf�gen von #EXTINF (K�nstler/Interpret - Titel) Info in Wiedergabelisten', 
	'dir_file'=>'Name der Textdatei, die in Verzeichnissen angezeigt werden soll', 
	'dir_imgs'=>'Durch anklicken eines Bildes das n�chste Bild im selben Verzeichnis anzeigen (falls vorhanden)?', 
	'dir_year'=>'Zeige Jahr des Albums (basierend auf ID3 tags)', 
	'dir_genre'=>'Zeige Genre des Albums (basierend auf ID3 tags)', 
	'dir_genre_look'=>'Anzeigen des Genre in einer K�nstler/Interpreten Seite aufgrund des Album-Genre (basierend auf ID3 tag)', 
	'dir_skip'=>'Verzeichnisse mit diesem Vorzeichen werden nicht angezeigt', 
	'dir_regex'=>'Regul�rer Audruck, der bestimmte Zeichen in Unterverzeichnissen "bereinigt"', 
	'dir_srch'=>'Nach angegebenen Zeichen suchen (innerhalb von Verzeichnissen)', 
	'dir_repl'=>'...und durch dieses Zeichen ersetzen (Leerzeichen m�glich)', 
	'dir_img_missing'=>'Anzeigen, wenn kein Bild  im Verzeichnis vorhanden ist?', 
	'dir_sort_ignore'=>'Zeichen, die beim Sortieren nicht ber�cksichtigt werden sollen aktivieren', 
	'dir_si_str'=>'Angabe des Zeichens/der Zeichen ("|" trennt)', 
	'cat_file'=>'Name der Datei, die aus einem Verzeichnis eine "Kategorie" macht', 
	'cat_width'=>'Gr��e der Breite', 
	'cat_cols'=>'Anzahl der Spalten in einer "Kategorie" Seite', 
	'cat_trunc'=>'Maximale L�nge des Textes nach dem "..." angezeigt wird', 
	'cat_split'=>'Aufteilen in verschiedene Seiten', 
	'cat_pp'=>'Anzahl der Eintr�ge pro Seite (sieht besser aus, wenn sehr viele Spalten angeziegt werden sollen)', 
	'dir_list'=>'Anzeige von Unterverzeichnissen', 
	'dir_list_txt'=>'Name der Unterverzeichnisse', 
	'dir_list_len'=>'Abk�rzen von langen Unterverzeichnisnamen (ab Zeichen:)', 
	'subdir_images'=>'Bilder in Unterverzeichnissen anzeigen', 
	'subdir_center'=>'Zentrieren von Bildern in Unterverzeichnissen', 
	'subdir_cols'=>'Anzahl der Spalten von Bildern in Unterverzeichnissen', 
	'subdir_img_cap'=>'Anzeige des Unterverzeichnisnamens unterhalb des jeweiligen Bildes', 
	'subdir_img_missing'=>'Anzeige eines fehlenden Bildes in einem Unterverzeichnis', 
	'new_highlight'=>'Neue Dateien und Verzeichnisse extra kennzeichnen', 
	'new_time'=>'Anzeigedauer (in Tagen)?', 
	'new_img'=>'Soll ein Symbol angezeigt werden',
	'new-img-name'=>'Name der Datei (Datei muss im Verzeichnis THEMES\images) stehen)',  
	'new_beg'=>'Textangabe vor der Datei/Verzeichnis', 
	'new_end'=>'Textangabe nach der Datei/Verzeichnis', 
	'alt_dirs'=>'Alternative/Verwandte Verzeichnisse', 
	'alt_images'=>'Anzeige von Bildern in Alternativen/Verwandten Verzeichnissen', 
	'alt_file'=>'Dateiname der die Eintr�ge beinhaltet', 
	'alt_text'=>'�berschrift', 
	'mp3_info'=>'Sollen Spieldauer (MM:SS.), kbps, Frequenz und Dateigr��e von MP3 Dateien angezeigt werden?', 
	'mp3_info_faster'=>'Schnelleres errechnen der MP3 Information (nicht ganz genau)', 
	'mp3_id3'=>'Verwenden von ID3v1/2 Liedtiteln (falls vorhanden)', 
	'song_regex'=>'Ist kein ID3 tag vorhanden, wird durch diesen regul�ren Ausdruck der Liedtitel "bereinigt"', 
	'song_srch'=>'Zeichen, nach dem im Liedtitel gesucht werden soll', 
	'song_repl'=>'...und durch dieses Zeichen ersetzt wird', 
	'song_blurbs'=>'Zus�tzliche Informationen unterhalb des Liedtitels? (Gleicher Dateiname, wie MP3 Datei, als Suffix aber .txt!)', 
	'various'=>'Anzeigen von "K�nstler/Interpret - Titel" als Liedtitel (ID3 tag muss daf�r vorhanden sein)', 
	'various_file'=>'Name der Datei, um aus einem Verzeichnis die Anzeige "Artist - Titel" zu machen', 
	'fake'=>'Suche nach Platzhalter f�r Lieder', 
	'fake_ext'=>'Dateisuffix, um Platzhalter f�r Lieder zu definieren', 
	'remote'=>'Nach "entfernten" Liedern suchen', 
	'remote_ext'=>'Dateisuffix f�r "entfernte" Lieder', 
	'low'=>'Suchen einer zweiten MP3 Datei (geringere Qualit�t) mit folgender Dateiendung:', 
	'low_suf'=>'Dateiendung f�r Lo-Fi MP3 Datei Name_der_Datei.[suffix].ext; bsp. "lied.lofi.mp3":', 
	'low_lookahead'=>'Lo-Fi nur dann, wenn resample "aus", Lo-Fi "an" und nicht alle Unterverzeichnisse Lo-Fi Dateien haben', 
	'resample'=>'Resample', 
	'enc_arr'=>'Programm zum Encodieren', 
	'res_in_types'=>'Bildtyp(en), deren Gr��e angpasst werden soll (von IHRER Konfiguration abh�ngig)', 
	'res_out_type'=>'Bildtyp nach Gr��enanpassung (von IHRER Konfiguration abh�ngig)', 
	'res_dir_qual'=>'JPEG Qualit�t (1=schlecht/100=sehr gut)', 
	'res_dir_img'=>'Verzeichnisbilder', 
	'res_dir_x'=>'Angabe der Gr��e der Bilder in Verzeichnissen (in Pixel)', 
	'res_sub_qual'=>'JPEG Qualit�t (1=schlecht/100=sehr gut)', 
	'res_sub_img'=>'Unterverzeichnisbilder', 
	'res_sub_x'=>'Angabe der Gr��e der Bilder in Unterverzeichnissen (in Pixel)', 
	'res_out_x_lmt'=>'Nur dann Gr��e anpassen, wenn Originalbreite gr��er neuer breite ist', 
	'dir_img_txt'=>'Angabe des Verzeichnisse bei fehlendem Bild?', 
	'dir_img_txt_color'=>'Textfarbe des Verzeichnisses (RGB)', 
	'sub_img_txt'=>'Angabe des Unterverzeichnisse bei fehlendem Bild?', 
	'sub_img_txt_color'=>'Farbe des Unterverzeichnisses (RGB)', 
	'img_txt_wrap'=>'Wortumbruch bei xx Zeichen', 
	'img_txt_font'=>'Kompleter Pfad zu einer TrueType Schriftart', 
	'img_txt_font_size'=>'Schriftgr��e', 
	'cmp_sel'=>'Download von ausgew�hlten Dateien als eine komprimierte Datei', 
	'cmp_int'=>'Komprimierung mit internem PHP Zlib Modul', 
	'cmp_pgm'=>'Vollst�ndiger Pfad zum Komprimierungsprogrammes', 
	'cmp_ext'=>'Dateisuffix der komprimierten Datei ', 
	'cmp_set'=>'Parameter f�r Komprimierungsprogramm', 
	'cmp_mime'=>'Komprimierter Datei MIME-Typ', 
	'pos'=>'Vom Server abspielen', 
	'pos_hack'=>'MPG123 "Umgehung" (wenn Probleme auftreten, bitte versuchen)', 
	'pos_cmd'=>'Befehlsfolge, um auf dem Server abzuspielen', 
	'pos_kill'=>'Kill (Notwendig auf Linux/Unix Systemen)', 
	'pos_kill_cmd'=>'Kill Anweisung', 
	'other_media_types'=>'Andere Mediadateien', 
	'media_types'=>'Mediadateien', 
	'media_pls'=>'Arten von Wiedergabelisten', 
	'cron'=>'Funktionen zeitabh�ngig steuern', 
	'cron_opts'=>'Parameter', 
	'old_pwd'=>'Altes Passwort', 
	'adm_pwd'=>'Neues Passwort', 
	'con_pwd'=>'Passwort best�tigen', 
	'mm'=>'Andere Mediatypen ber�cksichtigen', 
	'mm_types'=>'Andere Mediatypen', 
	'mm_down'=>'Download erlauben', 
	'mm_text'=>'�berschrift', 
); 

$cats = array(
	5=>array('t'=>"Allgemein",
		'd'=>""
		),
	10=>array('t'=>"Verzeichnisse",
		'd'=>""
		),
	15=>array('t'=>"Interner Stream",
		'd'=>""
		),
	20=>array('t'=>"Neu angelegte Verzeichnisse extra anzeigen",
		'd'=>"Basierend auf Zeitpunkt von Datei�nderungen.  K�nnte zu einem Laufzeitfehler f�hren. Wenn Symbol anzeigen 'aus', sollten Sie ggf. eine eigene HTML prefix oder suffix verwenden."
		),
	25=>array('t'=>"Unterverzeichnisse",
		'd'=>""
		),
	30=>array('t'=>"Unterverzeichnisbilder (Normalerweise Album-Covers)",
		'd'=>""
		),
	35=>array('t'=>"Verzeichnis als 'Kategorie'",
		'd'=>"Listet Verzeichnisse im Spaltenformat auf. Eignet sich gut f�r Hauptverzeichnisse oder f�r andere Verzeichnisse mit sehr vielen Unterverzeichnissen."
		),
	40=>array('t'=>"Musikdateien",
		'd'=>""
		),
	45=>array('t'=>"'K�nstler/Interpreten - Titel' als Liedtitel",
		'd'=>"Zeigt Lieder in einem Verzeichnis als 'K�nstler/Interpret - Titel' an (ben�tigt ID3 Option).  Eignet sich gut f�r Soundtracks und 'Various Artists' Verzeichnisse."
		),
	50=>array('t'=>"Platzhalter f�r Liedtitel",
		'd'=>"Sie m�chten ein Lied anzeigen, das sie (noch) nicht haben? Erstellen Sie in einem Liedverzeichnis eine Datei mit dem Liednamen und der Dateiendung f�r 'Platzhalter f�r Liedtitel'; z.B. 04_-_Lied_Nummer_Vier.<b>fake</b>"
		),
	55=>array('t'=>"'Entfernte' Dateien",
		'd'=>"Sie m�chten Lieder einbinden, die auf eine anderen Server sind? Erstellen Sie eine Datei in einem Verzeichnis mit dem Namen des Liedtitels und dem angegebenen Dateisuffix, z.B. 02_-_Remote_Song.rem".
		"<p>Dateiformat: HTML meta tags wobei name=url,download,artist,album,title,filesize,bitrate,frequency,time,year,genre<p>Datei muss enden mit &lt;/head&gt;".
		"<p>Einfaches Beispiel: ".htmlentities("<meta name='url' content='http://www.somesite.com/somesong.mp3'></head>")
		),
	60=>array('t'=>"Nicht-Musik Dateien",
		'd'=>"Anzeigen und/oder erlauben des Downloads von Nicht-Musik Dateien.  Die Dateitypen sollten ein Symbol in THEMES/images/mm haben. <p>Wenn Sie 'zus�tzliche Informationen unterhalb der Liedtitel' verwenden, k�nnen Sie eine Textdatei mit dem selben Namen anlegen (Dateisuffix muss *.txt sein)<p>BETA: Wenn Zina lokal l�uft, erlaubt die Angabe von 'p', Dateien innerhalb von Zina abzuspielen mit WMP oder QT; oder f�gen Sie eine Selektionsm�glichkeit in THEMES/templates-video.html hinzu."
		),
	65=>array('t'=>"Genre",
		'd'=>'Genre Funktion (basierend auf ID3 tags).  Cache muss aktiviert sein.  Das erstmalige Erstellen l�uft automatisch, danach m�ssen Sie eine manuelle Aktualisierung vornehmen, indem Sie auf das entsprechende Symbol klicken, wenn Sie eingeloggt sind'), 
	70=>array('t'=>"Low-Fidelity Dateioptionen", 
		'd'=>""
		),
	75=>array('t'=>'Alternative/Verwandte Verzeichnisse',
		'd'=>"Sucht nach einer Datei in einem Verzeichnis, die eine weitere Liste von alternativen Verzeichnissen beinhaltet. Format ist: DIR/DIR (Name von existierenden Verzeichnissen). 
		F�gen Sie an das Ende einen '/' hinzu (z.B. DIR/DIR/) f�r Verzeichnisse ohne Lieder (z.B. andere K�nstler/Interpreten). 
		Dann wird dieses Verzeichnis als '"._ZRELATED."' angezeigt." 
		), 
	80=>array('t'=>"Automatisches Down/Re-sampling",
		'd'=>"WARNUNG: Die Benutzung kann Ihren Server in die Knie zwingen.
Wenn Sie diese Funktion trotzdem verwenden wollen, ben�tigen Sie ein externes Programm zum enkodieren, wie bspw. LAME <http://www.mp3dev.org/mp3/>, dass Eingabe von 'stdin' und Ausgabe von 'stdout' unterst�tzt.
Ben�tigt aktivierte Low-Fidelity Datei Optionen"
		),
	85=>array('t'=>"Authentifikation",
		'd'=>"�ndern des Passwortes und Admin-Name, sowie Einstellen anderer Admin Funktionen"
		),
	90=>array('t'=>"Wiedergabelisten",
		'd'=>""
		),
	95=>array('t'=>"Dynamisches anpassen der Bildgr��en",
		'd'=>"Ben�tigt PHP compiliert mit GD Bibliothek: http://us3.php.net/manual/en/ref.image.php
			Stellenn Sie sicher, dass GD ohne Zina funktioniert.  Die zu �ndernden Dateisuffixe d�rfen nur IHRE eigenen Einstellungen verwenden.
			<P>BEMERKUNG: Ich kann keine Hilfe bei Apache/PHP/GD Konfigurationsfragen leisten!"
		),
	100=>array('t'=>"TODO",
		'd'=>""
		),
	105=>array('t'=>"Download von ausgew�hlten Dateien als eine komprimierte Datei",
		'd'=>"Ben�tigt ein externes Dateikomprimierungsprgramm wie bspw. Zip oder Gzip, oder das PHP Zlib Modul.
		Verwenden dieser Funktion wird Ihren Server stark belasten."
		),
	110=>array('t'=>"Auf dem Server abspielen",
		'd'=>'Spielt die Lieder auf dem Server ab, anstatt auf dem Browser.
		<p><b>Windows/WinAmp</b> (Sie werden http://www.jukkis.net/bgrun/bgrun.exe ben�tigen)
		<br>Beispiel f�r die Kommandozeile: bgrun.exe C:\Progra~1\Winamp\winamp.exe $tmpfname.m3u >NUL
		<p><b>Linux/mpg123</b>
		<br>Beispiel f�r die Kommandozeile: /usr/bin/mpg123 -q --list $tmpfname.m3u 0 1> /dev/null 2>&1 &
		<p><b>OS/2</b> und <b>eCS</b>: Probieren Sie Z! (http://dink.org/z/)
		<br>Beispiel f�r die Kommandozeile (ggf. vollst�ndiger Pfad): z.exe -p $tmpfname.m3u >NUL'
		),
	115=>array('t'=>"Andere Dateiarten",
		'd'=>"Standardeinstellung: MP3, OGG, WAV, WMA verwenden *.m3u Wiedergabelisten per http.
		<p>Um andere Dateiarten abzuspielen, aktivieren Sie 'Andere Mediadateien' und f�gen eine neue Zeile hinzu.  
		<p>Einige Beispiele:
		<br>'mid' => array('ext' => 'm3u', 'proto' => 'http', 'type' => 'audio/midi'),
		<br>'ra' => array('ext' => 'ram', 'proto' => 'http', 'type' => 'audio/x-pn-realaudio'),
		<br>'wma' => array('ext' => 'asx', 'proto' => 'mms', 'type' => 'audio/x-ms-wma'),
		<br>'ra' => array('ext' => 'ram', 'proto' => 'rtsp', 'type' => 'audio/vnd.rn-realaudio'),"
		),
	120=>array('t'=>"Funktionen zeitabh�ngig steuern",
		'd'=>"(neu seit 10.0.17, noch nicht abschlie�end getestet)
		<p>Jede Funktion, die aktiviert ('an') oder deaktiviert ('aus') ist, kann f�r eine bestimmte Zeitdauer aktiviert werden. Format ist wie bei 'cron' Funktion.
		<br>BEMERKUNG: Diese Funktion �berschreibt an/aus Einstellungen. Dies betrifft nicht den Admin.</p>
		<p><b>FORMAT</b>:
		<br><code>['X'][] = 'ZEIT'</code>  
		<br>Das '|' Zeichen trennt unterschiedliche Bereiche.
		<br>
		<br>X = Einstellungen (Siehe Klappbox weiter unten)
		<br>ZEIT = 'WOCHENTAG MONAT TAG HH:MM' (WOCHENTAG=0-6, beginnt mit 0=Sonntag; MONAT=1-12; TAG=1-31; HH:MM=00-23:0-59)
		<br>'*' alle Zeiten; Komma trennt verschiedene Werte, ein Bindestrich einen Bereich (von-bis)
		<br>
		<br><b>Beispiel 1</b>: Zeigt immer das 'Anh�ren' Symbol (v�llig unn�tige Einstellung)
		<br><code>['play'][] = '* * * *'</code>
		<br><b>Beispiel 2</b>: Zeigt das Download Symbol zwischen 22:00 und 06:00 Uhr jeden Tag.
		<br><code>['download'][] = '* * * 22:00-6:00'</code>
		<br><b>Beispiel 3</b>: Zeigt das Download Symbol Montags bis Freitags, f�r die ersten 15 Tage in den Monaten Januar, M�rz und Mai,<br> zwischen 08:00 und 17:00 Uhr
		<br><code>['download'][] = '1-5 1,3,5 1-15 8:00-17:00'</code>
		<br><b>Beispiel 4</b>: Zeigt das Download Symbol zwischen Mitternacht und 06:00 Uhr, Montags bis Freitags und ganzt�gig Samstags und Sonntags
		<br><code>['download'][] = '* * * 0:00-6:00'|['download'][] = '6-0 * * *'</code>"
		),
	125=>array('t'=>"TODO",
		'd'=>""
		),
);
$other = array(
	'forref'=>"NUR F�R REFERENZZWECKE: NICHT ALLE EINSTELLUNGEN MACHEN AUCH SINN",
	'song_text'=>'Liedtext',
	'dir_text'=>'Verzeichnistext',
	'regen'=>"Cache wird erneuert.\\n\\nDas kann eine Weile dauern.\\n\\nM�chten Sie das wirklich jetzt machen?",
	'regen_genre'=>"GENRE Cache wird erneuert.\\n\\nDas kann eine Weile dauern.\\n\\nM�chten Sie das wirklich jetzt machen?",
	'top'=>'nach oben',
	);
?>
