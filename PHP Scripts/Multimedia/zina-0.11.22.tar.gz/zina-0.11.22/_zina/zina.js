function SubmitForm(form, a, replace) { 
	if (replace) {
		document.forms[form].action = a; 
	} else {
		document.forms[form].action = document.forms[form].action + a; 
	}
	document.forms[form].submit();
}

function CheckBoxes(form, v){
	for (var i=0; i < document.forms[form].elements.length; i++) {
		var j = document.forms[form].elements[i];
		if (j.type == "checkbox") { j.checked = v; }
	}
}

function CheckIt(form, a, replace, error) {
	var checks = 0;
	for (var i=0; i < document.forms[form].elements.length; i++) {
		var j = document.forms[form].elements[i];
		if (j.type == "checkbox" && j.checked) { checks = 1; break; }
	}
	if (checks == 0) {
		alert(error);
	} else {
		SubmitForm(form, a, replace);
	}
}

function CheckIt2(form, a, replace, error, sess, type) {
	var i = document.forms[form].playlist.selectedIndex;
	var j = document.forms[form].playlist.options[i].value;
	var err = 0;
	if (type == "add") {
		err = 1;
		for (var i=0; i < document.forms[form].elements.length; i++) {
			var j = document.forms[form].elements[i];
			if (j.type == "checkbox" && j.checked) { err = 0; break; }
		}
	} else { //play/lofi
		if(j == "new_zina_list") {
			err = 1;
		} else if (j == "zina_session_playlist" && sess == 0 ) {
			err = 1;
		}
	}
	if (err == 1)
		alert(error)
	else
		SubmitForm(form, a, replace);

}

function AddElements(f,x){
	var i;
	for(i=0;i < x.length; i++) {
		if (x.options[i].selected) {
			f.value += x.options[i].value +"\n";
		}
	}
}
