INSERT INTO `currentdj_settings` VALUES (2, 'Display how DJ was set', '0');
