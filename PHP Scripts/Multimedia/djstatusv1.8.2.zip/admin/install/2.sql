CREATE TABLE `currentdj_settings` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `setting` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;