* *****************************************************************************
* XMMS Script / Readme.txt
* Copyright (C) 2004-2005 chaoscontrol.org
* *****************************************************************************

 Contents:

	1. Introduction
	2. Requirements
	3. Installation
	4. Troubleshooting


* *****************************************************************************
* 1. Introduction
* *****************************************************************************

What's it do? In a nutshell, it grabs the currently playing song from XMMS, 
updoads it via FTP to your webserver so you can add a "Now playing..." feature 
to your site or blog.

More specifically, each time XMMS changes songs, it launches xmms.php which 
takes the song information (from the MP3's ID3 tag) and dumps it to an ASCII 
text file (xmms.info). The script then proceeds to FTP the xmms.info file to
a server for use.

XMMS script is distributed under the GNU General Public License (GPL). See 
license.txt for more information.


* *****************************************************************************
* 2. Requirements
* *****************************************************************************

 - XMMS w/Song Change plugin 
 - php (localy and on web server)
 - Unix-like OS (aka Linux, BSD, etc)
 - FTP
 - Web Server


* *****************************************************************************
* 3. Installation
* *****************************************************************************

1. Copy XMMS.php and xmms.info to a directory of your choice.
2. Edit the variables in xmms.php to your liking.
3. Make xmms.php executable: chmod +x xmms.php
4. Make xmms.info writable (if it isn't already): chmod +w xmms.info
5. Launch XMMS -- Goto Options/Preferences/General Plugins
6. Select 'Song Change', click 'Configure'.
7. Enter the path to 'xmms.php' <space> %s% in the command box. Example: /home/g0dzuki/scripts/xmms.php "%s"
8. Click 'OK' and Check 'Enable Plugin'.
9. Edit then add the following to your web site where you want the information to appear:

	<?php

	// ** Edit $songfile ot the correct path of xmms.info **
	$songfile = "path/to/xmms.info"; 

	$time_now = mktime(date("H"),date("i"),date("s"),date("m"),date("d"),date("Y"));
	$last_mod = @filemtime($songfile);

	if ($time_now - 1800 < $last_mod) {				
		@include("$songfile");
	} else { 		
		// ** This is what gets sent to the browser, edit at will **
		echo "<i>No MP3s Playing</i>";
	}
			
	?>

10. Rename the page you copied the above code to to *.php Example: index.html to index.php
11. Play a song in XMMS and check your website. ;)


* *****************************************************************************
* 4. Troubleshooting
* *****************************************************************************

Nothing showing up on your website except "No MP3s Playing"? Try these:

	- Make sure you edited xmms.php for the username, password, file locations, etc...
	- Make sure you edited the cut-n-paste code above to have the correct file location of xmms.info
	- Make sure the upload directory on your web/FTP server is writable
	- Make sure xmms.php is executable
	- Check your local copy of xmms.info, see if it's being created
	- Make sure you configured the Song Change plugin properly
	- Try running xmms.php from the shell ($ php path_to/xmms.php), see if it has any errors
	- By default, /usr/bin/php is where the php binary path is set to, change the path in xmms.php if yours is something else

Still not working?
	
	- support@chaoscontrol.org
	- http://forums.chaoscontrol.org

