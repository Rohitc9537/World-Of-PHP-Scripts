#!/usr/bin/php

<?php

/** 
 * *****************************************************************************
 * XMMS Script
 * Copyright (C) 2004-2005 chaoscontrol.org
 * *****************************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * *****************************************************************************
 * xmms.php
 * version: 1.0.1
 * Coded by: chris@chaoscontrol.org
 * Created: 
 * Updated: 10/19/2005
 * *****************************************************************************
 */ 


/** 
 * *****************************************************************************
 * Set Variables - Edit these to fit your needs
 * *****************************************************************************
 */ 

	// ** location where xmms.php will update/create the xmms.info file **
	$localfile = "/home/g0dzuki/scripts/xmms.info";

	// ** location of xmms.info on the ftp/web server **
	$remotefile	= "/www/xmms.info";

	// ** FTP Server Address **
	$ftpserver = "ftp.yourserver.com";
	
	// ** Username and password used to access the FTP server **
	$ftpuser = "username";
	$ftppass =	"password";

/** 
 * *****************************************************************************
 * Get MP3 from XMMS and create/update xmms.info
 * *****************************************************************************
 */ 

	$mp3 = $argv[1];

	if ($mp3 != "%s") {

		$fp = fopen($localfile, 'w');
		fwrite($fp, $mp3);
		fclose($fp);

	}

/** 
 * *****************************************************************************
 * Upload xmms.info to the FTP server
 * *****************************************************************************
 */ 

	$connect = ftp_connect($ftpserver); 
	$login = ftp_login($connect, $ftpuser, $ftppass); 

	ftp_pasv ($connect, true) ;
	$upload = ftp_put($connect, $remotefile, $localfile, FTP_ASCII); 
	ftp_close($connect);

?>