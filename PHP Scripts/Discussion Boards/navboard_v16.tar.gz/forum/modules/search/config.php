<?php
//search module
$moduleconfig['mainpage']="search.php"; //relative to module folder
$moduleconfig['active']="yes";
$moduleconfig['adminpage']="admin.php";
?>