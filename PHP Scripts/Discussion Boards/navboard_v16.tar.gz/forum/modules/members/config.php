<?php
//members module
$moduleconfig['mainpage']="members.php"; //relative to module folder
$moduleconfig['active']="yes"; //module active?
$moduleconfig['adminpage']="admin.php";
?>