<?php

$replacements["{tableheader}"]='
<table width="100%" height=1 cellspacing=0 cellpadding=4 class="table">
';

?>
