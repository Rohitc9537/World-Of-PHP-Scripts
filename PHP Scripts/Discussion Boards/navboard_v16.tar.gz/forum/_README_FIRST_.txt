README 2.6.0
-----------------

NOTE: If you used navboard
before this version the 
upgrade script needs to be run!
See documentation/upgrades.txt
for how to do this

THEMES: Themes made for versions
below 2.6.0 will NOT work for
this version

For more details see documentation