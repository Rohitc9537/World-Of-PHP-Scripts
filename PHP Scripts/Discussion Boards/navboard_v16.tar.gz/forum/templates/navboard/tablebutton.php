<?php $template='

<table width="100%" cellspacing=2 cellpadding=0>
<tr>
<td>

<table width=80 cellspacing=0 cellpadding=2 class="tablebutton">
<tr>
<td align="center">
<span class="tablebuttonfont">
$content
</span>
</td>
</tr>
</table>

</td>
</tr>
</table>

'; ?>
