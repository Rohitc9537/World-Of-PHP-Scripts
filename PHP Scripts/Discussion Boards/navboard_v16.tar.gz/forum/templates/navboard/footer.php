<?php $template='

{tableheader}
<tr>
 <td width="100%" class="tableheadercell">

 <table width="100%" border="0" cellspacing="0" cellpadding="0">
 <tr>
 <td align="left">
 <span class="textheader">
 <b>Information</b>
 </span>
 </td>
 </tr>
 </table>

 </td>
 </tr>

<tr>
<td width="100%" class="tablecell1">

<table width="100%" border="0" cellspacing="0" cellpadding="0">

<tr>
<td width="60%" align="left">
<span class="textsmall">

$content[online]

</span>
</td>

<td width="40%" align="right">
<span class="textsmall">

$content[newpms]

</span>
</td>
</tr>
</table>

</td>
</tr>

<tr>
<td height="0" class="tablecell2">

<table width="100%" border="0" cellspacing="0" cellpadding="0">

<tr>
<td height="0" width="30%" align="left">
<span class="textsmall">
$content[navigation]
</span>
</td>


<td height="0" width="70%" align="right">
<span class="textsmall">
$content[login]
</span>
</td>

</tr>
</table>

</td>
</tr>

<tr>
<td class="tablecell1">

<table width="100%" border="0" cellspacing="0" cellpadding="0">

<tr>

<td width="33%" align="left">
<span class="textsmall">
$content[credits]
</span>
</td>

<td width="33%" align="center">
<span class="textlarge">
$content[contact]
</span>
</td>

<td width="34%" valign="top" align="right">
<span class="textsmall">
$content[stats]
</span>
</td>
</tr>

</table>

</td>
</tr>

</table>

'; ?>
