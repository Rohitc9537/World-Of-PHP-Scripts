<?
header("location:bbs/install.php");
exit();
?>