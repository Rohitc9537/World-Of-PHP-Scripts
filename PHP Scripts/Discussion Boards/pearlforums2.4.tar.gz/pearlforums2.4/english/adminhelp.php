<? 

function getHelpText(){
	global $Document,$GlobalSettings,$Language;
	
	$contents = <<<EOF
	
EOF;
	return $contents;
	
}
?>
