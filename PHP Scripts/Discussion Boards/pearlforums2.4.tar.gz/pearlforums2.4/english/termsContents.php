<? 

function getContents(){	
	$contents=<<<EOF
<TABLE WIDTH="95%">
<TR>
	<TD CLASS="TDPlain"><BR/><BR/>
	Put your custom <STRONG>Terms of use</STRONG> here (english/termsContents.php)
	<BR/><BR/>
	<BR/><BR/>
	<BR/><BR/>
	</TD>
</TR>
</TABLE>
EOF;
	return $contents;	
}
?>
