Installation:

Please have your database connection details ready and run the install.php file.
Don't forget to give write permissions to the settings.php and smileys/smileys.js
files.

Required mySQL Connection Details:

1) Database Name
2) Username
3) Password
4) Host (default:localhost)

For support and other info, please visit http://www.pearlinger.com