<?php

$lang['Rebuild_search'] = 'Reindexeer Zoeken';
$lang['Rebuild_search_desc'] = 'Door deze functie zal ieder bericht op je .premodded/phpBB geindexeerd worden, door de zoektabellen te herbouwen. Dit proces kan lang in beslag nemen, ga in de tussentijd NIET weg van/uit deze pagina, totdat dit proces voltooid is.';
$lang['Post_limit'] = 'Bericht limiet';
$lang['Time_limit'] = 'Tijd limiet';
$lang['Refresh_rate'] = 'Vernieuw mate';

$lang['Next'] = 'Volgende';
$lang['Finished'] = 'Voltooien';

?>