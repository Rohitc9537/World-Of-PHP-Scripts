<?php
//***************************************************************************//
//                                                                           //
//  Copyright (c) 2004-2005 Jonathon J. Freeman                              //
//  All rights reserved.                                                     //
//                                                                           //
//  This program is free software. You may use, modify, and/or redistribute  //
//  it under the terms of the OvBB License Agreement v2 as published by the  //
//  OvBB Project at www.ovbb.org.                                            //
//                                                                           //
//***************************************************************************//

	$aPostIcons[0]['title'] = '';
	$aPostIcons[0]['filename'] = 'space.png';

	$aPostIcons[1]['title'] = 'Post';
	$aPostIcons[1]['filename'] = 'post_icon1.png';

	$aPostIcons[2]['title'] = 'Arrow';
	$aPostIcons[2]['filename'] = 'post_icon2.png';

	$aPostIcons[3]['title'] = 'Light Bulb';
	$aPostIcons[3]['filename'] = 'post_icon3.png';

	$aPostIcons[4]['title'] = 'Exclamation';
	$aPostIcons[4]['filename'] = 'post_icon4.png';

	$aPostIcons[5]['title'] = 'Question';
	$aPostIcons[5]['filename'] = 'post_icon5.png';

	$aPostIcons[6]['title'] = 'Cool';
	$aPostIcons[6]['filename'] = 'post_icon6.png';

	$aPostIcons[7]['title'] = 'Smile';
	$aPostIcons[7]['filename'] = 'post_icon7.png';

	$aPostIcons[8]['title'] = 'Mad';
	$aPostIcons[8]['filename'] = 'post_icon8.png';

	$aPostIcons[9]['title'] = 'Sad';
	$aPostIcons[9]['filename'] = 'post_icon9.png';

	$aPostIcons[10]['title'] = 'Grin';
	$aPostIcons[10]['filename'] = 'post_icon10.png';

	$aPostIcons[11]['title'] = 'Embarrassed';
	$aPostIcons[11]['filename'] = 'post_icon11.png';

	$aPostIcons[12]['title'] = 'Wink';
	$aPostIcons[12]['filename'] = 'post_icon12.png';

	$aPostIcons[13]['title'] = 'Thumbs Down';
	$aPostIcons[13]['filename'] = 'post_icon13.png';

	$aPostIcons[14]['title'] = 'Thumbs Up';
	$aPostIcons[14]['filename'] = 'post_icon14.png';
?>