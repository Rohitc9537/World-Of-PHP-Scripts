<?php
//***************************************************************************//
//                                                                           //
//  Copyright (c) 2004-2005 Jonathon J. Freeman                              //
//  All rights reserved.                                                     //
//                                                                           //
//  This program is free software. You may use, modify, and/or redistribute  //
//  it under the terms of the OvBB License Agreement v2 as published by the  //
//  OvBB Project at www.ovbb.org.                                            //
//                                                                           //
//***************************************************************************//

	$aCensored[] = array('bastard', '*******');
	$aCensored[] = array('bitch', '*****');
	$aCensored[] = array('cock', '****');
	$aCensored[] = array('cum', '***');
	$aCensored[] = array('cunt', '****');
	$aCensored[] = array('damn', '****');
	$aCensored[] = array('fuck', '****');
	$aCensored[] = array('hell', '****');
	$aCensored[] = array('nigger', '******');
	$aCensored[] = array('piss', '****');
	$aCensored[] = array('shit', '****');
?>