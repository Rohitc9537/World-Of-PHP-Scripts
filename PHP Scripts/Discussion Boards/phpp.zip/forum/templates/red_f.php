</div>
<div id="footerbar"></div>
<div class="shadow"><img src="gfx/blank.gif" width="1" height="1" alt="*"/></div>
<div id="footer">Design � 2004 <a href="http://www.i-produce.co.uk" target="_blank">i-produce</a>. Powered by <a href="http://www.php-post.co.uk" target="_blank">PHP-Post</a> <? include "ver.php"; ?>.</div>
</div>
</body>
</html>