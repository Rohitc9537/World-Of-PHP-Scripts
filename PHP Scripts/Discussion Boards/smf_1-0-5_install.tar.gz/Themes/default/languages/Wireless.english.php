<?php
// Version: 1.0; Wireless

$txt['wireless_error_home'] = 'Board index';

$txt['wireless_options'] = 'Additional options';
$txt['wireless_options_login'] = 'Login';
$txt['wireless_options_logout'] = 'Logout';

$txt['wireless_navigation'] = 'Navigation';
$txt['wireless_navigation_up'] = 'Up one level';
$txt['wireless_navigation_next'] = 'Next page';
$txt['wireless_navigation_prev'] = 'Previous page';
$txt['wireless_navigation_index'] = 'Message Index';
$txt['wireless_navigation_topic'] = 'Back to topic';

?>