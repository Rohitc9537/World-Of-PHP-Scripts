<?php
/*
** sCssBoard, an extremely fast and flexible CSS-based message board system
** Copyright (CC) 2005 Elton Muuga
**
** This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike License. 
** To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/2.0/ or send 
** a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
*/
?>

<div class='catheader' style='padding:5px; margin-left:auto; margin-right:auto; text-align:center;'>&nbsp; <strong><a href='?act=admin-home'>Admin CP</a></strong></div>

<table width='100%' border='0' cellpadding='0' cellspacing='2'>
<tr>
	<td class='topic_stat_hd' width='50%' height='25' align='center'><a href='?act=admin-general'>Board Configuration</a></td>
	<td class='topic_stat_hd' width='50%' height='25' align='center'><a href='?act=admin-forums'>Categories/Forums</a></td>
	<!--<td class='topic_stat_hd' width='33%' height='25' align='center'><a href='?act=admin-home'>Notes</a></td>-->
</tr>
</table>
