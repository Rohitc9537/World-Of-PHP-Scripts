<br /><br /> <br /><br />
<b>BBCode</b><br /><br />

[b] <strong>Strong</strong> [/b]<br />
[i] <em>Emphasis</em> [/i]<br />
[u] <u>Underline</u> [/u]<br /><br />

[url=#] <a href='http://www.google.com' target='_blank'>Link</a> [/url]<br />
[img] Image [/img]<br /><br />

[quote] Quote [/quote]