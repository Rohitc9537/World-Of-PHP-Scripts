<?php

// This is just an example config. The install script will generate a correct
// version of this file when you install PunBB. This file is here merely as a
// backup if the working version is somehow lost or corrupted.

$db_type = 'blabla';
$db_host = 'blabla';
$db_name = 'blabla';
$db_username = 'blabla';
$db_password = 'blabla';
$db_prefix = '';
$p_connect = false;

$cookie_name = 'punbb_cookie';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'asdf1234';	// Make up your own secret seed here

define('PUN', 1);