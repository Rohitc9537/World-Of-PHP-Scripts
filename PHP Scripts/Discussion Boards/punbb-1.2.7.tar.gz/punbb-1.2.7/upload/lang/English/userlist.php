<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Find and sort users',
'User search info'		=>	'Enter a username to search for and/or a user group to filter by. The username field can be left blank. Use the wildcard character * for partial matches. Sort users by name, date registered or number of posts and in ascending/descending order.',
'User group'			=>	'User group',
'No of posts'			=>	'No. of posts',
'All users'				=>	'All'

);
