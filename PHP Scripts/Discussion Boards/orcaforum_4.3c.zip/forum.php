<?php

require "orca/of_lang_en.php";
include "orca/of_head.php";

?><html>
<head>
  <title><?php echo $fData['pagetitle']; ?></title>
  <link rel="stylesheet" type="text/css" href="orca/of_style.css" />

  <style type="text/css">

body {
  background-color:#ffffff;
  font:normal 100% Arial,sans-serif;
}

  </style>
</head>
<body>

<?php include "orca/of_body.php"; ?>

</body>
</html>