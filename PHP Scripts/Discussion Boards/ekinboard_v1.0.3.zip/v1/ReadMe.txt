----------------------------------

EKINboard by EKINdesigns

----------------------------------
Version: 1.0.3
Homepage: www.ekinboard.com
----------------------------------

     First of all everyone at EKINboard would like to thank you for you interest in our script.  We
would like to promise you that EKINboard will always be free and opensource.

     There is one main reason why we are so different from all the other board scripts out there and
that is because we take your ideas into consideration.  We allow you to practically design it.  After
all, you guys are the ones who keep us arround.

     These first few releases may contian some bugs.  Please report any of them that you might find
immediatly so that we can get it fixed as soon as possible.

 - EKINboard Staff

----------------------------------
FRESH INSTALL
----------------------------------

1. Unzip all the contents of the file into a folder.
2. Upload all the files to your server.
3. Run the install/index.php file to install the EKINboard.

NOTE: If you would like EKINborad Installer to automatically configure your db_info.php file to your
settings than CHMOD db_info.php to 777.  Otherwise you will need to manually configure it.

	--------------------------
	db_info.php Configuration
	--------------------------

	Replace <{db_host}> with your database host.  Usually 'localhost'.
	Replace <{db_user}> with your database username.
	Replace <{db_pass}> with your database password.
	Replace <{db_name}> with your database name.

----------------------------------
UPDATE TO v1.0.3
----------------------------------

1. Unzip all the contents of the file into a folder.
2. Upload and replace all the files in the zip folder to your server.
3. Run the install/update.php file and follow the directions.