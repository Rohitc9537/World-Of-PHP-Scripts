<?PHP
// You will need to edit the 4 connection variables if the installer doesn't automatically do it for you.  Replace everything inside the ' ' with the value.

// Your mySQL database host (usually 'localhost')
$db_host = '<{$db_host}>';

// Your mySQL database username
$db_user = '<{$db_user}>';

// Your mySQL database password
$db_pass = '<{$db_pass}>';

// Your mySQL database name
$db_name = '<{$db_name}>';

?>