<?php

if ($_userlevel != 3) {

    die("<center><span class=red>You need to be an admin to access this page!</span></center>");

}

?>

<table width=90%>

<tr><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/general_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=general">General Settings</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/online_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=online">Online Users</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/rules_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=rules">Forum Rules</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/template_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=template">Board Template</a></td></tr></table>

</td><td></td></tr><tr><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/cat_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=categories">Manage Categories</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/forums_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=forums">Manage Forums</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/mod_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=moderators">Manage Moderators</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/users_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=users">Manage Users</a></td></tr></table>

</td></tr><tr><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/ads_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=ads">Manage Ads</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/wordfilter_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=wordfilter">Word Filters</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/rssfeeds_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=rss">RSS Feeds</a></td></tr></table>

</td><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/help_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=help">Help</a></td></tr></table>

</td></tr><tr><td width=150 class=contentmain>

<table width=100%><tr><td align=center height="100%"><img src="images/about_img.gif" border=0 alt=""></td></tr><tr><td align=center><a href="index.php?page=about">About EKINboard</a></td></tr></table>

</td><td width=150 class=contentmain>
</table>