<?php
$banlist=array(

"shit",
"shite",
"fuck",
"fucking",
"dick",
"cock",
"cunt",
"arse",
"bollocks",
"crap",
"piss",
"bastard",
"wanker",
"twat"

);
?>