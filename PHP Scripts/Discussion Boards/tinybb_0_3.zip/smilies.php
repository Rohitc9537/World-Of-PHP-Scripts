<?php
$smilies=array("cool", "cry", "dblwink", "grin", "ill", "innocent", "sad", "shock", "smile", "soso", "straight", "tongue", "wink");
?>