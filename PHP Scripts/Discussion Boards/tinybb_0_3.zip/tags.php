<?php
$allowedtags="<a><br><b><i><p><u>";
$allowedtagshtml=htmlentities($allowedtags);
?>