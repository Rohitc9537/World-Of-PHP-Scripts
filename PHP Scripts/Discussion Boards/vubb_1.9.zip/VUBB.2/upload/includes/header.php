<?php
/*
Copyright 2005 VUBB
*/
// get the menu running
menu();

get_template('header');
?>