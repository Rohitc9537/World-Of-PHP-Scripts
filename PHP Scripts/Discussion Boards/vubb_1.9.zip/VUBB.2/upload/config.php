<?php
database_connect('localhost','user_name','password','database_name');
?>