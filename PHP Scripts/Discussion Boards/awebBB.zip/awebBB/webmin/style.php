<style type="text/css">
<!--
body {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px; background-color: white; }
table {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px;}
a:link { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:visited { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:active { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:hover { font-family: verdana; font-size: 11px; color: blue; text-decoration: underline; }
div.boxxy {position: absolute; display: block; width: 300px; padding: 0px; margin-bottom: 2px; margin-right: 2px; margin-left: 202px; margin-top: 168px; border: 1px solid gray; background-color: white;}
div.boxtext {position: absolute; display: block; height:18px padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: 211px; margin-top: 162px; background-color: white;}
div.tbord {border-left: 1px solid gray; border-top: 1px solid gray; border-bottom: 1px solid gray; background-color: white;}
//-->
</style>	