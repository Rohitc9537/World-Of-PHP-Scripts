<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 TRANSITIONAL//EN">
<html>

	<head>
		<title>aWebBB Administration Section</title>
<style type="text/css">
<!--
body {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px; background-color: white; }
table {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px;}
a:link { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:visited { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:active { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }a:hover { font-family: verdana; font-size: 11px; color: blue; text-decoration: underline; }
div.navbox {position: absolute; display: block; width: 110px; padding: 0px; margin-bottom: 2px; margin-right: 2px; margin-left: 2px; margin-top: 58px; border: 1px solid gray; background-color: white;}
div.normbox {position: absolute; display: block; width: 580px; padding: 2px; margin-bottom: 2px; margin-right: 2px; margin-left: 118px; margin-top: 58px; border: 1px solid gray; background-color: white;}
div.navtitle {position: absolute; display: block; padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: 11px; margin-top: 52px; background-color: white;}
div.tbord {position: absolute; width: 700px; margin-left: 2px; margin-top: 2px; border: 1px solid #006666; background-color: #006655; text-align: center;}
//-->
</style>
	</head>
	<body>
<div class="tbord"><font color="white" size="6">aWebBB Administration</font></div>
<div class="navbox"><br>
&nbsp;&nbsp;<i>Main:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="../index.php">View Forum</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?=$_SERVER['PHP_SELF'];?>?mode=logout">Logout</a><br><br>
&nbsp;&nbsp;<i>Users:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="manage_users.php">Manage Users</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="new_user.php">New User</a><br><br>
&nbsp;&nbsp;<i>Categories:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="list_cat.php">List All</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="new_cat.php">New</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit_cat.php">Edit</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="remove_cat.php">Remove</a><br><br>
&nbsp;&nbsp;<i>Threads / Posts:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit_post.php">Edit Posts</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="remove_post.php">Remove Posts</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="mod_thread.php">Modify Threads</a><br><br>
&nbsp;&nbsp;<i>Site Settings:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="pref_edit.php">Preferences</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="menu_edit.php">Menu Items</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="ad_edit.php">Ads</a><br><br>
&nbsp;&nbsp;<i>External Links:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.labs.aweb.com.au">aWebBB Labs</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:yougotmail@gmail.com">Support</a><br><br>
</div>
<div class="navtitle">
&nbsp;<b>Navigation</b>&nbsp;</div>
<div class="normbox">