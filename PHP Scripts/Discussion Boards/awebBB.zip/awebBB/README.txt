//////////////////////////////////////////////////////////////////////////
/////////////////                  aWebBB               //////////////////
//////////////////////////////////////////////////////////////////////////
============================================
INSTALL

1. Edit the value in config.php to suit your MySQL DB
2. point your browser to 
	www.yourdomain.com/awebBB/webmin/install.php
	OR for upgrade:
	www.yourdomain.com/awebBB/webmin/upgrade.php
3. Enjoy your new forum, and please leave the link back
	to aWeb labs on the forum so others may benefit
	from this script as well.  


============================================
VERSION 1.2

Version 1.2 brings substantial advantages in both forum administration and usability.  This version also fixes many bugs and minor errors as well as includes some new features:
	a] Quick insert of smilies and html, smilies are converted into 		images when displayed.
	b] Improved Statistics and account settings pages / sections.
 	c] Improves Web Administration panel with a new GUI
	d] Ability to insert ads in pages at three targeted positions
The quick links in the page footer go to the WebMin section and the Green checkmark (if is latest version) or Red exclamation point (new versions available) go to the aWebBB web-page.

============================================
VERSION 1.1

This release fixes a few bugs in the from the first release
and adds some new features including a better reply system,
Included avatars, more customizable options, plus more
Check out our site for more detail

============================================
VERSION 1.0

This is the first release of the aWebBB a php and mysql
forum originally developed for www.eduslice.com and
is now being released under the GNU GPL.  
aWebBB features a simple easy to use forum with an 
administration panel that lets you control almost all
aspects of your forum.
Expect future versions, check out www.labs.aweb.com.au

============================================
LICENSE

aWebBB is licensed under the GNU General Public
License available at: 
	http://www.gnu.org/copyleft/gpl.html
In using awebBB you agree to the terms and conditions
set forward in the General Public License.  

============================================
LAST MODIFIED ON JAN. 26, 2005
