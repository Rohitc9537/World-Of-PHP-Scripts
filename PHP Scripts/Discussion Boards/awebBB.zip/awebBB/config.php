<?php 
$db_host = "localhost"; // Host, usually 'localhost'
$db_user = "user";  //DB username
$db_pass = "pass"; //DB password
$db_name = "awebBB"; //DB Name
?>
