<?php

$dbhost = "localhost";		// adresa serveru	// server address
$dbusername = "";		// jm�no u�ivatele	// user name
$dbname = "";			// jm�no datab�ze	// database name
$dbpassword = ""; 		// heslo u�ivatele	// user password

$Con2 = mysql_connect($dbhost,$dbusername,$dbpassword);

if (!$Con2) {
  echo "Nepoda�ilo se nav�zat spojen�.\n";
  } else {
    MySQL_Select_DB("$dbname");
}

$table_prefix = "ub_";
$tblname_admin = $table_prefix.admin;
$tblname_config = $table_prefix.config;
$tblname_head = $table_prefix.head;
$tblname_topic = $table_prefix.topic;

?>