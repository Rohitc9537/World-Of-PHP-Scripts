<?php

$lang['Encoding'] = "iso-8859-2";
$lang['Administrator'] = "Administr�tor";
$lang['Home'] = "Dom�";
$lang['Settings'] = "Nastaven�";
$lang['Language'] = "Jazyk";
$lang['Theme'] = "Vzhled";
$lang['Adminemail'] = "E-mail administr�tora";
$lang['Perpage'] = "Po�et p��sp�vk� na str�nku";

$lang['Category'] = "Kategorie";
$lang['Posts'] = "P��sp�vky";
$lang['Page'] = "Strana";

$lang['Search'] = "Hled�n�";
$lang['Admin'] = "Administrace";

$lang['Name'] = "Jm�no";
$lang['Email'] = "E-mail";
$lang['Post_subject'] = "P�edm�t";
$lang['Password'] = "Heslo";

$lang['Passwordold'] = "Star� heslo";
$lang['Passwordnew'] = "Nov� heslo";
$lang['Passwordcon'] = "Potvr� nov� heslo";

$lang['Fill'] = "Nutno zadat";
$lang['Confirm'] = "Potvrdit";
$lang['Send'] = "Odeslat";
$lang['Post'] = "P��sp�vek";
$lang['Searching'] = "Hledej";
$lang['Searchenter'] = "Zadej hledan� �et�zec";

$lang['Author'] = "Autor";
$lang['Date'] = "Datum";
$lang['Back'] = "Zp�t";

$lang['Search_keyword'] = "Hledan� v�raz";
$lang['Where_search'] = "Kde hledat";
$lang['Topics_found'] = "Po�et nalezen�ch p��sp�vk�";

$lang['Delete'] = "Smazat";
$lang['Edit'] = "Editovat";
$lang['Create'] = "Vytvo�it";
$lang['Order'] = "Po�ad�";
$lang['Yes'] = "Ano";

$lang['Title'] = "N�zev";
$lang['Description'] = "Popis";

$lang['Deletesure'] = "Chce� to opravdu smazat ?";
$lang['Changename'] = "Zm�na jm�na";
$lang['Changepassword'] = "Zm�na hesla";

?>