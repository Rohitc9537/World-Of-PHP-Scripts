<?php

$lang['Encoding'] = "iso-8859-1";
$lang['Administrator'] = "Administrator";
$lang['Home'] = "Home";
$lang['Settings'] = "Settings";
$lang['Language'] = "Language";
$lang['Theme'] = "Theme";
$lang['Adminemail'] = "Administrator's e-mail";
$lang['Perpage'] = "Topics per page";

$lang['Category'] = "Category";
$lang['Posts'] = "Posts";
$lang['Page'] = "Page";

$lang['Search'] = "Search";
$lang['Admin'] = "Configure";

$lang['Name'] = "Your name";
$lang['Email'] = "E-mail";
$lang['Post_subject'] = "Subject";
$lang['Password'] = "Password";

$lang['Passwordold'] = "Old password";
$lang['Passwordnew'] = "New password";
$lang['Passwordcon'] = "Confirm new password";

$lang['Fill'] = "Must fill up";
$lang['Confirm'] = "Confirm";
$lang['Send'] = "Send";
$lang['Post'] = "Post";
$lang['Searching'] = "Search";
$lang['Searchenter'] = "Enter searched keyword(s)";

$lang['Author'] = "Author";
$lang['Date'] = "Date";
$lang['Back'] = "Back";

$lang['Search_keyword'] = "Search keyword";
$lang['Where_search'] = "Where search";
$lang['Topics_found'] = "Topics found";

$lang['Delete'] = "Delete";
$lang['Edit'] = "Edit";
$lang['Create'] = "Create";
$lang['Order'] = "Order";
$lang['Yes'] = "Yes";

$lang['Title'] = "Title";
$lang['Description'] = "Description";

$lang['Deletesure'] = "Are you sure ?";
$lang['Changename'] = "Change name";
$lang['Changepassword'] = "Change password";

?>