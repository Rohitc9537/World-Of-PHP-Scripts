<TABLE cellspacing="5" cellpadding="0">
<TR>
<TD><TABLE border="2" cellspacing="0" cellpadding="5">
<TR><TD width="70" class="vivo" align="center" onMouseOver="MenuOver(this);" onMouseOut="MenuOut(this);"><A HREF="../index.php" class="seed"><?php echo $lang[Category]; ?></A>
</TABLE>
<TD><TABLE border="2" cellspacing="0" cellpadding="5">
<TR><TD width="70" class="vivo" align="center" onMouseOver="MenuOver(this);" onMouseOut="MenuOut(this);"><A HREF="../pages/search.php" class="seed"><?php echo $lang[Search]; ?></A>
</TABLE>
<TD><TABLE border="2" cellspacing="0" cellpadding="5">
<TR><TD width="70" class="vivo" align="center" onMouseOver="MenuOver(this);" onMouseOut="MenuOut(this);"><A HREF="#pridejpost" class="seed"><?php echo $lang[Post]; ?></A>
</TABLE>
</TABLE>