<SCRIPT LANGUAGE="JavaScript">
<!--

function MenuOver(element)
{
	if(element.style){
		element.style.backgroundColor='#BB0033';
		element.style.cursor='hand';
	};
};

function MenuOut(element)
{
	if(element.style) element.style.backgroundColor='#990033';
};

window.defaultStatus="UKiBoard";

//-->
</SCRIPT>