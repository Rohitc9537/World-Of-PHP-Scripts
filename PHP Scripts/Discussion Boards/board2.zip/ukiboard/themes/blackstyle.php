<SCRIPT LANGUAGE="JavaScript">
<!--

function MenuOver(element)
{
	if(element.style){
		element.style.backgroundColor='#FF9900';
		element.style.cursor='hand';
	};
};

function MenuOut(element)
{
	if(element.style) element.style.backgroundColor='#FFCC00';
};

window.defaultStatus="UKiBoard";

//-->
</SCRIPT>