<SCRIPT LANGUAGE="JavaScript">
<!--

function MenuOver(element)
{
	if(element.style){
		element.style.backgroundColor='#0099CC';
		element.style.cursor='hand';
	};
};

function MenuOut(element)
{
	if(element.style) element.style.backgroundColor='#006699';
};

window.defaultStatus="UKiBoard";

//-->
</SCRIPT>