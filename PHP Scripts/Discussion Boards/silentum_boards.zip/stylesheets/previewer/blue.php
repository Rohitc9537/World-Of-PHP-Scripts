<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<!-- blue.php copyright 2005 "HyperSilence" -->
<head>
<link rel="stylesheet" href="../../stylesheets/blue.css" type="text/css" />
<title>Stylesheet Previewer</title>
</head>
<body>
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
	<? include("top.php") ?>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
		<td style="text-align: center"><span class="heading">blue</span></td>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" class="table" style="width: 95%">
	<tr>
		<td class="heading1" colspan="2"><span class="heading">.heading1</span></td>
	</tr>
	<tr>
		<td class="heading2" colspan="2"><span class="heading">.heading2</span></td>
	</tr>
	<tr>
		<td class="heading3" colspan="2"><span class="heading">.heading3</span></td>
	</tr>
	<tr>
		<td class="one"><span class="normal"><strong><ins>Link/Visited Link</ins></strong></span></td>
		<td class="one"><span class="normal" style="color: #3366bb"><strong>Active/Hover Link</strong></span></td>
	</tr>
	<tr>
		<td class="two" style="width: 50%"><span class="normal">.two</span></td>
		<td class="one" style="width: 50%"><span class="normal">.one</span></td>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" style="text-align: center; width: 95%">
	<tr>
		<td><input class="button" type="submit" value="Button" /></td>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
	<? include("bottom.php") ?>
	</tr>
</table>
</object>
</body>
</html>