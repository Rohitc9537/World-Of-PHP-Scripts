<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<!-- previewer.php copyright 2005 "HyperSilence" -->
<head>
<link rel="stylesheet" href="../../stylesheets/blue.css" type="text/css" />
<title>Stylesheet Previewer</title>
</head>
<body>
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
	<? include("top.php") ?>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
		<td style="text-align: center"><span class="normal"><strong>Choose a stylesheet above to preview.</strong></span></td>
	</tr>
</table>
</object><br />
<object>
<table align="center" cellspacing="0" style="width: 95%">
	<tr>
	<? include("bottom.php") ?>
	</tr>
</table>
</object>
</body>
</html>