	<td colspan="2" style="text-align: center"><span class="normal"><a href="javascript:window.close();">Close This Window</a><br /></span></td>
