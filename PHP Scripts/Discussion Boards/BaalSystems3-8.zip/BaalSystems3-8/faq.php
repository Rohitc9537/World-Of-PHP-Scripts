<?php
include("common.php");

?>
<html>
<head>
<title>Baal Smart Form</title>
<LINK href="incl/style2.css" rel=stylesheet>
</head>
<body bgcolor="<?=$bgcolor;

?>">
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width=500>
  <TBODY>
    <TR>
      <TD class=q><TABLE border=0 cellPadding=5 cellSpacing=1 width="100%">
          <TBODY>
            <TR class=c>
              <TD><TABLE cellPadding=1 cellSpacing=0 width="100%">
                  <TBODY>
                    <TR>
                      <TD noWrap><SPAN class=c>FAQ</SPAN></TD>
                      <TD noWrap align="middle"><SPAN class=c><a href="javascript:history.back();" style="COLOR: #ffffff" title="back">BACK</a></SPAN></TD>
                    </TR>
                  </TBODY>
                </TABLE></TD>
            </TR>
            <TR class=a>
              <TD><TABLE cellSpacing=6 width="100%">
                  <TBODY>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>Why cann't I login?</b></li>
                        <div>Have you registered? Seriously, you must register in order to log in. </div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>Why do I need to register at all?</b></li>
                        <div>You may not have to -- whether you need to register in order to post messages. However, registration will give you access to additional features.</div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>I registered but cannot log in!</b></li>
                        <div>First check that you are entering the correct username and password. </div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>How do I post a topic in a forum?</b></li>
                        <div>Easy -- click the relevant button on either the forum or topic screens. You may need to register before you can post a message. </div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>How do I delete a post?</b></li>
                        <div>Unless you are the admin you can only delete posts. </div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>What are Administrators?</b></li>
                        <div>Administrators are people assigned the highest level of control over the entire BaalSmartForm. These people can control all facets of BaalSmartForm operation which include creating usergroups,delete usergroups,delete topics, etc. Back to top </div></TD>
                    </TR>
                    <TR>
                      <TD align=left colspan=2 ><LI><b>What are users?</b></li>
                        <div>Users are individuals.They have the power to reply to the existing topics and post new discusion.</div></TD>
                    </TR>
                  </TBODY>
                </TABLE></TD>
            </TR>
          </TBODY>
        </TABLE></TD>
    </TR>
  </TBODY>
</TABLE>
<p align="center">CopyRight 2004 <br>
  <a href="http://baalsystems.com">Baal Portal Software</a><br>
</p>
</body>
</html>
