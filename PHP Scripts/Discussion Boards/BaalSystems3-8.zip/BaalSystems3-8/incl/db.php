<?php
    $db=array(
              "host"=>"192.168.0.5",
              "user"=>"root",
              "pass"=>"slammer",
              "dbname"=>"Baal"
             );
                
    $tableprefix="_";
?>