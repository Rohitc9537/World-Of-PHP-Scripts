<?php

include("header.php");

table_header("Realtime Chat");
echo ("<table border=\"0\" cellspacing=\"1\" cellpadding=\"3\" bgcolor=\"$tborder_color2\" width=\"$fwidth\" align=\"center\">
   <tr bgcolor=\"#FFFFFF\">
      <td width=\"100%\" colspan=\"1\"><font size=\"$fsmall\" face=\"$fface\" color=\"$fcolor\">lol</font></td>
   </tr>
</table>");
table_footer();

include("footer.php");

?>
