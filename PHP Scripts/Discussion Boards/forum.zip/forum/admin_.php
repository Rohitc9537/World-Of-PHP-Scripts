<?php


echo ("<form method=\"post\" action=\"\">");
table_header("");
  echo ("
<table border=\"0\" cellspacing=\"1\" cellpadding=\"3\" width=\"$fwidth\" align=\"center\" bgcolor=\"$tborder_color2\">
  <tr>
     <td  colspan=\"1\" width=\"100%\"><font size=\"$fsmall\" color=\"$fcolor\" face=\"$fface\">
      content here
    </td>
  </tr>
</table>");
table_footer();

echo ("</form>");

?>
