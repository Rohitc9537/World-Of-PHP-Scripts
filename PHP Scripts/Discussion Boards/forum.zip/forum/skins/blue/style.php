<?php

echo ("<style type=\"text/css\">

.bordercolor
{
	background-color: $tborder_color;
}

.height
{
	height: 30px;
}

.background
{
	background-image: url('$skins/table/title_bg.gif');
}

.backgroundtm
{
	background-image: url('$skins/table/tm.gif');
}

.backgroundbm
{
	background-image: url('$skins/table/bm.gif');
}
.backgroundtm2
{
	background-image: url('$skins/table/tm2.gif');
}

.backgroundbm2
{
	background-image: url('$skins/table/bm2.gif');
}

.subnav1
{
	background-image: url('$skins/other/subnav_top.jpg');
	height: 31px;
}
.subnav2
{
	background-image: url('$skins/other/subnav_bottom.jpg');
	height: 31px;
}


input {

border: 1px solid #0000BB;
font-family: Verdana;
text-decoration: none;
background-color: $tbackground1;
color: #339933;

}

textarea {

border: 1px solid #0000BB;
font-family: Verdana;
font-weight: bold;
background-color: $tbackground1;
color: #339933;

}

</style>");

?>
