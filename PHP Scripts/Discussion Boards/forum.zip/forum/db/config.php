<?php

$f_version = "1.1ALPHA";
$dbfile = "db/file.db";
$dbuser = "Admin";
$dbpass = "admin";
$title = "your sites title";
$width = "720";
$fwidth = "650";
$bgcolor = "#AAAAAA";
$hrcolor = "#00BB00";
$skins = "skins/blue";
$lingo_file = "language/english.txt";
$allow_register = "true";
$core_signup = "false";
$announcement = "Welcome, Thanks for installing and using MyAtom Forum, Your username is <b>Admin</b> and your password is <b>admin</b>, do note that the username and password fields are case sencitive. Get as much help as you wish from my-spb.net support forums.";
$fface = "Verdana";
$fsmall = "1";
$fmedium = "2";
$fcolor = "#000000";
$fcfade = "#0000BB";
$ftitle = "#DDDDDD";
$fsubtitle = "#DDDD00";
$tborder_color = "#BED4EF";
$tborder_color2 = "#000000";
$tbackground1 = "#EEEEEE";
$tbackground2 = "#DDDDDD";
$tbackground3 = "#FFFFFF";
$cadmin = "#00bb00";
$cmember = "#0000bb";
$a = "Modify Configuration";
$pfdate = "dS F, Y";


?>
