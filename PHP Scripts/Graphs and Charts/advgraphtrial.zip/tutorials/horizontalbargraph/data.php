<?php

/* ------------------------------------------------------------------ */
/*                                                                    */
/* This data script is a very simply little script which              */
/* outputs the data for the graph.                                    */
/*                                                                    */
/* In a real implementation this script would be expanded to first    */
/* acquire the data from another source ( series of files or database */
/* tables) and then output the calculated data.                       */
/*                                                                    */
/* ------------------------------------------------------------------ */


print "data1series1: 150\n";
print "data2series1: 100\n";
print "data3series1: 130\n";
print "data4series1: -40\n";
print "data5series1: -150\n";
print "data6series1: 35\n";

print "data1series2: 456.98\n";
print "data2series2: 374.38\n";
print "data3series2: 473.39\n";
print "data4series2: 343.45\n";
print "data5series2: 123.98\n";
print "data6series2: 429.38\n";


?>