<?php

/**
 * Fichero basico de configuracion de la aplicacion.
 * El resto de la configuracion (persistencia, logging, presentacion, etc) se hace
 * a traves de ficheros XML.
 */

/** URL's */
define('CONF_CONTEXT_PATH', '/tests');

/** Directorios */
define('CONF_DIR_MOLINS', 'c:\\inam\\htdocs\\molins');

?>
