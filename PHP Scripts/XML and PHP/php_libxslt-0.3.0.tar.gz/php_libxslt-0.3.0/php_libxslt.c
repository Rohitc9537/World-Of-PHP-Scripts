/* PHP libxslt extension                                                     *
 * Copyright 2003 - 2004 Alexander Mayrhofer <axelm-php@nona.net>            *
 * See COPYING for the status of this software                               *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           * 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.	                             *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program; if not, write to the Free Software               *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */


/* include standard header */
#include "php.h"
#include "php_config.h"
/* configure output */
#include "config.h"

/* includes for libxml/xslt */
#include <libxml/xmlversion.h>
#include <libxml/xmlmemory.h>
#include <libxml/debugXML.h>
#include <libxml/HTMLtree.h>
#include <libxslt/xslt.h>
#include <libxslt/xsltInternals.h>
#include <libxslt/transform.h>
#include <libxslt/xsltutils.h>

/* extern variables */
extern int xmlLoadExtDtdDefaultValue;

/* declaration of functions to be exported */
ZEND_FUNCTION(libxslt_transform);

/* compiled function list so Zend knows what's in this module */
zend_function_entry libxslt_functions[] =
{
    ZEND_FE(libxslt_transform, NULL)
    {NULL, NULL, NULL}
};

/* compiled module information */
zend_module_entry libxslt_module_entry = {
    STANDARD_MODULE_HEADER,
    "libxslt transformation module",      /* extension name */
    libxslt_functions,  /* extension function list */
    NULL,               /* extension-wide startup function */
    NULL,               /* extension-wide shutdown function */
    NULL,               /* per-request startup function */
    NULL,               /* per-request shutdown function */
    NULL,               /* information function */
    "0.3.0",            /* extension version number (string) */
    STANDARD_MODULE_PROPERTIES
};

/* implement standard "stub" routine to introduce ourselves to Zend */
#if COMPILE_DL_PHP_LIBXSLT
ZEND_GET_MODULE(libxslt)
#endif

/* implement function that is meant to be made available to PHP */
ZEND_FUNCTION(libxslt_transform)
{
    /* two parameters: xmlstring (XML-Doc) and xslstring (stylesheet) 
     * optional third parameter: parameter hash */
    char *xmlstring, *xslstring;
    uint xmllen, xsllen;
    zval *argparams;
    zval **argparam;
    
    /* libxml/xslt stuff */
    xsltStylesheetPtr style = NULL;
    xmlDocPtr xsl, xml, res;
    char **params;
    uint parampos;
    xmlOutputBufferPtr outbuf;
    HashPosition pos;
    char *param_name, *param_value;
    ulong param_name_num; /* for numeric params */
    uint param_name_length, param_value_length;

    argparams = NULL;
 
    switch (ZEND_NUM_ARGS()) {
        case 2: 
            if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", 
		&xmlstring, &xmllen, &xslstring, &xsllen) != SUCCESS) {
		zend_error(E_ERROR, "Failed to fetch XML and XSL string arguments");
	    }
	    break;
	case 3:
	    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssa",
			&xmlstring, &xmllen, &xslstring, &xsllen, &argparams) 
			!= SUCCESS) {
		zend_error(E_ERROR, "Failed to fetch arguments (hint: parameters must be given as hash)");
       	    }
	    break;
	default:
	    WRONG_PARAM_COUNT;
	    break;
    }

    /* prepare parameters array */
    if (argparams) {
        params = (char**)emalloc(2*(zend_hash_num_elements(Z_ARRVAL_P(argparams))+1)*sizeof(char*));
        if (!params) {
            zend_error(E_ERROR, "Failed to allocate memory for parameters");
        }
        params[0] = NULL;
        parampos = 0;
        zend_hash_internal_pointer_reset_ex(Z_ARRVAL_PP(&argparams), &pos);
        while (zend_hash_get_current_data_ex(Z_ARRVAL_PP(&argparams), (void**)&argparam, &pos) == SUCCESS) {
    	    if(Z_TYPE_PP(argparam) != IS_STRING) {
	        zend_error(E_WARNING, "Parameter value is not a string, skipping");
	        zend_hash_move_forward_ex(Z_ARRVAL_PP(&argparams), &pos);
	        continue;
       	    }
            if(zend_hash_get_current_key_ex(Z_ARRVAL_PP(argparam), &param_name, &param_name_length, &param_name_num, 1, &pos) != HASH_KEY_IS_STRING) {
	        zend_error(E_WARNING, "Parameter key is not a string, skipping");
	        zend_hash_move_forward_ex(Z_ARRVAL_PP(&argparams), &pos);
	        continue;
    	    }
  	    params[parampos++] = param_name; 
	    params[parampos++] = Z_STRVAL_PP(argparam); 
	    zend_hash_move_forward_ex(Z_ARRVAL_PP(&argparams), &pos);
        }
	params[parampos] = NULL;
    } else {
	params = (char**)emalloc(2*sizeof(char*));
	params[0] = NULL;
    }

    xmlInitParser();
    xmlSubstituteEntitiesDefault(1);
    xmlLoadExtDtdDefaultValue = 1;
    xsl = xmlParseMemory(xslstring, xsllen);
    
    style = xsltParseStylesheetDoc(xsl);
    xml = xmlParseMemory(xmlstring, xmllen);
    res = xsltApplyStylesheet(style, xml, params);
    if (params) {
        efree(params);
    }
    if (res) {
       outbuf = xmlAllocOutputBuffer(NULL);
       xsltSaveResultTo(outbuf, res, style);
       xmlOutputBufferFlush(outbuf);
       RETVAL_STRINGL(outbuf->buffer->content, outbuf->buffer->use, 1);
       xmlOutputBufferClose(outbuf);
       xmlFreeDoc(res);
       if (xml) {
           xmlFreeDoc(xml);
       }
       if (style) {
           xsltFreeStylesheet(style);
       }
       xsltCleanupGlobals();
       xmlCleanupParser();
       xmlMemoryDump();
       return;
   }
   else {
       RETURN_STRING(xmlstring,1);
   }
}

