<?

dl('php_libxslt.so');

$xml = file_get_contents('hello.xml');
$xsl = file_get_contents('hello-param.xsl');

$params['TestParam'] = "'Example Value'";

print libxslt_transform($xml, $xsl, $params);

?>
