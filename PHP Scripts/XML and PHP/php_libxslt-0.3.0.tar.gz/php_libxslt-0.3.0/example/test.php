<?

dl('php_libxslt.so');
$xml = file_get_contents('hello.xml');
$xsl = file_get_contents('hello.xsl');
print libxslt_transform($xml, $xsl);

?>
