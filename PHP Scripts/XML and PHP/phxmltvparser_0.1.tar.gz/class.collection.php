<?php

	class collection
	{
		var $idxMax;
		var $idxAct;
		var $arrData;

				
		function collection()
		{
			$this->arrData = array();
			$this->idxMax = -1;
			$this->idxAct = 0;
		}
		
		function getFirst()
		{
			$this->idxAct = 0;
			
			if ($this->idxAct <= $this->idxMax)
				return($this->arrData[$this->idxAct]);
			else
				return(NULL);
		}
		
		function getNext()
		{
			$this->idxAct++;
			
			if ($this->idxAct <= $this->idxMax)
				return($this->arrData[$this->idxAct]);
			else
				return(NULL);
		}
		
		
		function add($data)
		{
			if(!is_null($data)) {
				if(array_search($data, $this->arrData) === FALSE) {
					//echo "($data)<br>";
					$this->idxMax++;
					
					$this->arrData[$this->idxMax] = $data;
				}
			}
		}
		
		function sort($sOption = SORT_STRING)
		{
			sort($this->arrData, $sOption);
		}
		
}
?>