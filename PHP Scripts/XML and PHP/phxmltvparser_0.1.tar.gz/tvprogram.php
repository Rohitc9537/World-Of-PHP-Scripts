<?php

	include "class.phxmltvparser.php";
	include "class.collection.php";
	include_once "phxpconfig.php";
	include "tvprogram.css";
	
	
	function getLink($prgItem)
	{
		$title = $prgItem->title;
		$title = eregi_replace('�', 'ae', $title); 
		$title = eregi_replace('�', 'oe', $title); 
		$title = eregi_replace('�', 'ue', $title); 
		$title = eregi_replace('�', 'ss', $title); 
		
		$title =ucwords($title);  //ucase first letter
		
		$title = eregi_replace("[^a-z0-9_]","",$title);		//strip all special chars
		
		$paras = '&chan=' . $prgItem->channel;
		$paras .= '&date=' . $prgItem->date;
		$paras .= '&start=' . htmlspecialchars($prgItem->formatStartTime());
		$paras .= '&stop=' . htmlspecialchars($prgItem->formatStopTime());
		$paras .= '&title=' . $title;
		
		$call = '<A class="prg_title" href="' . PRG_CALL . $paras . '" name="record" target="blank">' . $prgItem->title . '</A>';
	
		return($call);
	}
	
/*	
	// view ordered by channel
	
	function dump($prgObj, $date, $catFilter)
	{
		echo '<div class="prg_date">' . substr($date,6,2) . '.' . substr($date,4,2) . '</div>'; 
		
		
		echo "<table>";
		
		foreach ($prgObj->arrData as $channel => $arrItems) {
			echo "<tr>";
			
			echo '<td class="prg_channel">';
			echo "$channel<br>";
			echo "</td>";
			
			foreach ($arrItems as $start => $item) {
				if(strlen($catFilter) > 0)
					$hit = eregi($catFilter, $item->category);
				else
					$hit = true;
				
			
				if($hit)
				{
					echo '<td class="prg_cell">';
					
					$title = $item->title;
					$title = eregi_replace('�', 'ae', $title); 
					$title = eregi_replace('�', 'oe', $title); 
					$title = eregi_replace('�', 'ue', $title); 
					$title = eregi_replace('�', 'ss', $title); 
					
					$title =ucwords($title);  //ucase first letter
					
					$title = eregi_replace("[^a-z0-9_]","",$title);		//strip all special characters
					
					$paras = '&chan=' . $channel;
					$paras .= '&date=' . $item->date;
					$paras .= '&start=' . htmlspecialchars($item->formatStartTime());
					$paras .= '&stop=' . htmlspecialchars($item->formatStopTime());
					$paras .= '&title=' . $title;
					
					$call = '<A class="prg_title" href="neu.php?action=show' . $paras . '" name="record" target="blank">' . $item->title . '</A>';
					
					echo $call . "<br>";
					echo '<div class="prg_subtitle">' . $item->subtitle . '</div>';
					echo '<div class="prg_extra_data">';
					echo $item->formatStartTime() . "-" . $item->formatStopTime() . "<br>";
					echo $item->category ;
					echo '</div>';
					
					echo '<div class="prg_desc">';
					echo $item->desc;
					echo '</div>';
					
					echo "</td>";
				}
			}
			
			echo "</tr>";
			
			
		}
		
		echo "</table>";
	}
	
*/
	
	
//===================================================================================================================================================
//--- main function ---
//===================================================================================================================================================

	$xml = xml_parser_create();
	$xtvp = new PHxmltvParser;
	
	//$xtvp->setDate($date);
	
	xml_set_object($xml, $xtvp);
	xml_set_element_handler($xml, 'start_element', 'end_element');
	xml_set_character_data_handler($xml, 'character_data');
	xml_parser_set_option($xml, XML_OPTION_CASE_FOLDING, false);
	
//	$file = "../programm.xml";
	$file = "test.xml";

	$fp = fopen($file, 'r') or die("unable to open file!");
	
	while($data = fread($fp, 4096)) {
		xml_parse($xml, $data, feof($fp)) or die("unable to parse data!");
	}
	
	fclose($fp);
	
	xml_parser_free($xml);
	
	//------------------------
	$PrgDataObj = $xtvp->getPrgDataObj();
	//dump($PrgDataObj, $date, $catFilter);
	
	$channels = new collection;
	$dates = new collection;
	$categories = new collection;
	
	//echo "$PrgDataObj->idxMax<br>";
	$prgitem = $PrgDataObj->getFirst();
	
	while(!is_null($prgitem)) {
		$channels->add($prgitem->channel);
		$dates->add($prgitem->date);
		$categories->add($prgitem->category);
		
		$prgitem = $PrgDataObj->getNext();
	}
	
	$channels->sort();
	$dates->sort();
	$categories->sort();
	$PrgDataObj->orderByDateTime();
	
	echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">';
	
	
//---- Category combo
	echo '<SELECT name="cboCateg">';
	echo '<option>' . OPT_ALL . '</option>';
		
	$categ = $categories->getFirst();
	
	while(!is_null($categ)) {
		if($_POST['cboCateg'] == $categ)
			echo '<option selected>' . $categ . '</option>';
		else
			echo '<option>' . $categ . '</option>';
		
		$categ = $categories->getNext();
	}
	echo '</SELECT>';

//---- Date combo
	echo '<SELECT name="cboDate">';
	echo '<option>' . OPT_ALL . '</option>';
		
	$dat = $dates->getFirst();
	
	while(!is_null($dat)) {
		if($_POST['cboDate'] == $dat)
			echo '<option selected>' . $dat . '</option>';
		else
			echo '<option>' . $dat . '</option>';
		
		$dat = $dates->getNext();
	}
	echo '</SELECT>';
	
	
//---- End Formular
		
	echo '<input type="submit" value="' . CPT_SEARCH_BTN . '" name="search">';
	
	echo '</form>';
	echo "<br>";
	
	if(strlen($_POST['search']) > 0) {
		echo '<table width="100%">';
		
		$dat = $dates->getFirst();
		
		while(!is_null($dat)) {
			if($dat  == $_POST['cboDate'] || $_POST['cboDate']  == OPT_ALL) {
			
				$prgitem = $PrgDataObj->getFirst();
			
				echo '<tr>';
				echo '<td colspan="3" class="prg_cell_date">' . $prgitem->formatDate($dat) . '</td>';
				echo '</tr>';
				
				while(!is_null($prgitem)) {
					if($prgitem->date  == $dat && ($prgitem->category  == $_POST['cboCateg'] || $_POST['cboCateg']  == OPT_ALL)) {
						echo '<tr class="prg_row_info">';
						
						echo '<td class="prg_channel">' . $prgitem->channel . '</td>';
						echo '<td class="prg_time">' . $prgitem->formatStartTime() . '-' . $prgitem->formatStopTime() . '</td>';
						
						echo '<td>';
						
						echo '<span class="prg_titel">' . getLink($prgitem) . '</span>';
						
						if(strlen($prgitem->subtitle) > 0)
							echo '<span class="prg_subtitle">' . $prgitem->subtitle . '</span>';
						
						if(strlen($prgitem->episode) > 0)
							echo '<span class="prg_episode">' . EPISODE . ' ' . $prgitem->episode . '</span>';
						
						echo '<div class="prg_categorie">' . $prgitem->category . '</div>';
						echo '<div class="prg_desc">' . $prgitem->desc . '</div>';
						
						echo '</td>';
					
						echo '</tr>';
					} // IF Categories
					
					$prgitem = $PrgDataObj->getNext();
				} // WHILE prgitem
			} // IF Dates
				
			$dat = $dates->getNext();
		
		} // WHILE Dates
		
		echo '</table>';
	} // IF Post
?>