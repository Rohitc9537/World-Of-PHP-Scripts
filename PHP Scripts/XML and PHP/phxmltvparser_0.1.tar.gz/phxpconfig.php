<?php
	define(PHXP_VERSION, "0.1");								//version information
	define(OPT_ALL, "--- Alle ---");						//combo item to select ALL results
	define(EPISODE, "Teil");										//label for episode
	define(CPT_SEARCH_BTN, "Suchen");						//caption for search button
	define(PRG_CALL, "../neu.php?action=show");	//which script should be called if you click on a title
	define(PARSER_LANG, "de");									//some tags have a lang attribute, set this to your prefered language

	
//this function translates channel ids to channel names
	function getChanName($id)
	{
		switch($id) {
			case "C3sat.de":
				$name = "3Sat";
				break;
		
			case "ard.de":
				$name = "ARD";
				break;
		
			case "arte-tv.com":
				$name = "arte";
				break;
				
			case "C3.br-online.de":
				$name = "BR";
				break;
				
			case "kabel1.de":
				$name = "Kabel1";
				break;
			
			case "mtv.de":
				$name = "MTV";
				break;
			
			case "mtv2.de":
				$name = "MTV2";
				break;
			
			case "n24.de":
				$name = "N24";
				break;
			
			case "ndr.de":
				$name = "N3";
				break;
			
			case "C2.orf.at":
				$name = "ORF2";
				break;
			
			case "phoenix.de":
				$name = "Phoenix";
				break;
				
			case "prosieben.de":
				$name = "Pro7";
				break;
			
			case "rtl.de":
				$name = "RTL";
				break;
			
			case "rtl2.de":
				$name = "RTL2";
				break;
				
			case "sat1.de":
				$name = "Sat1";
				break;
			
			case "superrtl.de":
				$name = "SuperRTL";
				break;
			
			case "tvm.de":
				$name = "TVM";
				break;
			
			case "viva.tv":
				$name = "VIVA";
				break;
			
			case "vivaplus.tv":
				$name = "VIVAPLUS";
				break;
			
			case "vox.de":
				$name = "VOX";
				break;
			
			case "wdr.de":
				$name = "WDR";
				break;
			
			case "zdf.de":
				$name = "ZDF";
				break;

//--- these are for test.xml only
			case "bbc2.bbc.co.uk":
				$name = "bbc2";
				break;
			
			case "channel4.com":
				$name = "channel4";
				break;
//---------------------------------
							
			default:
				$name = "!! unknown !!";
				break;
			
		}
		
		return($name);
	}

?>