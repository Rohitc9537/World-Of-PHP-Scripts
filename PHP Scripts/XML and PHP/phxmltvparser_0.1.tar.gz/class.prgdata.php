<?php
	include("class.prgitem.php");

	class prgdata
	{
		var $idxMax;
		var $idxAct;
		var $arrData;
		var $actItem;
		
		
		
		function prgdata()
		{
			$this->arrData = array();
			$this->idxMax = -1;
			$this->idxAct = 0;
		}
		
		function getFirst()
		{
			$this->idxAct = 0;
			
			if ($this->idxAct <= $this->idxMax)
				return($this->arrData[$this->idxAct]);
			else
				return(NULL);
		}
		
		function getNext()
		{
			$this->idxAct++;
			
			if ($this->idxAct <= $this->idxMax)
				return($this->arrData[$this->idxAct]);
			else
				return(NULL);
		}
		
		
		function addPrgData($channel, $date, $start, $stop)
		{
			$this->idxMax++;
			
			$this->arrData[$this->idxMax] = new prgitem;
			
			$this->actItem = &$this->arrData[$this->idxMax];
			
			$this->actItem->channel = $channel;
			$this->actItem->start = $start;
			$this->actItem->stop = $stop;
			$this->actItem->date = $date;
		}
		
		
		
		function setTitle($value)
		{
			$this->actItem->title .= $value;
		}

		function setSubTitle($value)
		{
			$this->actItem->subtitle .= $value;
		}
		
		
		function setDesc($value)
		{
			$this->actItem->desc .= $value;
		}
		
		
		
		function setCategory($value)
		{
			$this->actItem->category .= $value;
		}
		
		function setEpisode($value)
		{
			$this->actItem->episode .= $value;
		}
		
		function cmpDateTime($a, $b)
		{
			if (($a->date . $a->start) == ($b->date . $b->start)) {
					return 0;
			}
			return (($a->date . $a->start) < ($b->date . $b->start)) ? -1 : 1;
		}
		
		function orderByDateTime()
		{
			usort($this->arrData, array("prgdata", "cmpDateTime"));
		}
}
?>