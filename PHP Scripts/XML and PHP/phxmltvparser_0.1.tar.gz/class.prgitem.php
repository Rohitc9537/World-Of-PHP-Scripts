<?php

class prgitem
{
	var $channel;
	var $date;
	var $start;
	var $stop;
	var $title;
	var $subtitle;
	var $desc;
	var $category;
	var $episode;
	
	function formatStartTime()
	{
		return(substr($this->start, 0, 2) . ":" . substr($this->start, 2, 2));
	}

	function formatStopTime()
	{
		return(substr($this->stop, 0, 2)  . ":" . substr($this->stop, 2, 2));
	}

	function formatDate($date)
	{
		if(!isset($date))
			$date = $this->date;
		
		return(substr($date, 6, 2) . "." . substr($date, 4, 2) . "." . substr($date, 0, 4));
	}
	
}

?>