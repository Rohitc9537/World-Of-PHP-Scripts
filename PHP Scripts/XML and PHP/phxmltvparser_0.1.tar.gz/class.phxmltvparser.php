<?php
include "class.prgdata.php";
include_once "phxpconfig.php";

class PHxmltvParser
{
	var $prgs;
	var $tag;
	var $attr;
	var $wntdDate;
	var $start;
	var $date;
	
	
	function PHxmltvParser()
	{
		$this->prgs = new prgdata;	
	}
	
	function getPrgDataObj()
	{
		return($this->prgs);
	}
	
	function setDate($strVal) {
		$this->wntdDate = $strVal;
	}
	
	function getTime($strDateTime)
	{
		return(substr($strDateTime, 8, 4));
	}
	
	function getDate($strDateTime)
	{
		return(substr($strDateTime, 0, 8));
	}
	
	function isDateWanted($date) {
		if(isset($this->wntdDate)) {
			if($date == $this->wntdDate)
				return(true);
			else
				return(false);
		}
		else {
			return(true);
		}
	}
	
	
//--------------------------------------------------------------------------------------------------------------------------------------	
//--- the parser --------

	
	function start_element($parser, $tag, $attributes)
	{
		$this->tag = $tag;
		
		switch($tag) {
			case "programme":
				$this->start = $this->getTime($attributes['start']);
				$this->date = $this->getDate($attributes['start']);
		
				if($this->isDateWanted($this->date)) {
					$channel = getChanName($attributes['channel']);
				
					$this->prgs->addPrgData($channel, $this->date, $this->start, $this->getTime($attributes['stop']));
				}
				break;
			
			case "title":
				$this->attr = $attributes;
				break;
			
			case "sub-title":
				$this->attr = $attributes;
				break;
			
			case "category":
				$this->attr = $attributes;
				break;
			
			case "desc":
				$this->attr = $attributes;
				break;
		}
	}
	
	
	
	function end_element($parser, $tag)
	{
	
	}

	
	
	function character_data($parser, $data)
	{
		if($this->isDateWanted($this->date)) {
			if(strlen(trim($data)) > 0) {
				
				switch($this->tag) {
					case "title":
						if($this->attr['lang'] == PARSER_LANG) {
								$this->prgs->setTitle($data);
						}
						break;
				
					case "sub-title":
						if($this->attr['lang'] == PARSER_LANG) {
								$this->prgs->setSubTitle($data);
						}
						break;
						
					case "category":
						if($this->attr['lang'] == PARSER_LANG) {
								$this->prgs->setCategory($data);
						}
						break;
					
					case "desc":
						if($this->attr['lang'] == PARSER_LANG) {
								$this->prgs->setDesc($data);
						}
						break;
				
					case "episode-num":
						$this->prgs->setEpisode($data);
						break;
				}
			}
		}
	}

//--- End Parser -----------	
//--------------------------------------------------------------------------------------------------------------------------------------	

}
?>