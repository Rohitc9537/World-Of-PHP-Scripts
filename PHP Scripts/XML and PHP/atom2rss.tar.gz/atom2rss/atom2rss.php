<?php
header ("Content-type: text/xml");
define ("ATOM", "http://www.easyhttp.com/jad/feed/atom.xml");
define ("RSS", "/tmp/rss.xml");


new converter;
class converter
{
	var $headers	= array ();
	var $contents	= array ();
	
	function converter ()
	{
		register_shutdown_function (array(&$this, "build"));
		$handler = domxml_open_mem (implode ("", file (ATOM)));
		$channel = $handler->get_elements_by_tagname ("feed");
		$headers = $channel[0]->child_nodes ();
		foreach ($headers as $header) {
			$info[$header->tagname] = $header->get_content ();
			$attribute = $header->attributes ();
			if (($attribute[0]->name == "href") && ($attribute[1]->value == "alternate")) {
				$this->headers['site'] = $attribute[0]->value;
			}
		}
		$this->headers['title'] = (strlen ($info['title']) == 0) ? " - " : $info['title'];
		$this->headers['description'] = (strlen ($info['tagline']) == 0) ? " - " : $info['tagline'];
		unset ($info);
		
		$items = $handler->get_elements_by_tagname ("entry");
		foreach ($items as $item) {
			$childs = $item->child_nodes ();
			foreach ($childs as $child) {
				$info[$child->tagname][] = $this->innerxml ($child);
				$attribute = $child->attributes ();
				if (($attribute[0]->name == "href") && ($attribute[1]->value == "alternate")) {
					$link[] = $attribute[0]->value;
				}
			}
		}
		for ($i = 0; $i < count ($info['title']); $i++) {
			$this->contents[$i]['title'] = $info['title'][$i];
			$this->contents[$i]['link'] = $link[$i];
			$this->contents[$i]['content'] = ($info['content'][$i] != "") ? $info['content'][$i] : 
$info['summary'][$i];
			$this->contents[$i]['date'] = $info['modified'][$i];	
		}
		unset ($info);
	}
	
	function innerxml ($node)
	{
		$innerXML = null;
		foreach ($node->child_nodes () as $child) {
			if ($child->node_type () == XML_TEXT_NODE) {
				$innerXML.= $child->node_value ();
			} else if ($child->node_type () == XML_ELEMENT_NODE) {
				$innerXML.= "<" . $child->node_name ();
				if ($attribnodes = $child->attributes ()) {
					foreach ($attribnodes as $attribnode) {
						$innerXML.= sprintf (" %s=\"%s\"",
									$attribnode->node_name (),
									$attribnode->node_value ());
					}
				}   
				$innerxml = $this->innerxml ($child);
				if (empty ($innerxml) && !$attribnodes) {
					$innerXML.= " />";
				} else {
					$innerXML.= sprintf (">%s</%s>", $innerxml, $child->node_name ());
				}
			}
		}
		return $innerXML;
	}

	function build ()
	{
		$doc = domxml_new_doc ("1.0");
		$rss = $doc->append_child ($doc->create_element ("rss"));
		$rss->set_attribute ("version", "2.0");
		
		$channel = $rss->append_child ($doc->create_element ("channel"));
		
		$title = $channel->append_child ($doc->create_element ("title"));
		$content = $doc->create_text_node ($this->headers['title']);
		$title->append_child ($content);
		
		$link = $channel->append_child ($doc->create_element ("link"));
		$content = $doc->create_text_node ($this->headers['site']);
		$link->append_child ($content);
		
		$description = $channel->append_child ($doc->create_element ("description"));
		$content = $doc->create_text_node ($this->headers['description']);
		$description->append_child ($content);

		for ($i = 0; $i < count ($this->contents); $i++) {
			$item = $channel->append_child ($doc->create_element ("item"));

			$title = $channel->append_child ($doc->create_element ("title"));
			$content = $doc->create_text_node ($this->contents[$i]['title']);
			$title->append_child ($content);
			$item->append_child ($title);

			$link = $channel->append_child ($doc->create_element ("link"));
			$content = $doc->create_text_node ($this->contents[$i]['link']);
			$link->append_child ($content);
			$item->append_child ($link);

			$pubDate = $channel->append_child ($doc->create_element ("pubDate"));
			$content = $doc->create_text_node ($this->contents[$i]['date']);
			$pubDate->append_child ($content);
			$item->append_child ($pubDate);

			$description = $channel->append_child ($doc->create_element ("description"));
			$content = $doc->create_text_node ($this->contents[$i]['content']);
			$description->append_child ($content);
			$item->append_child ($description);
		}
		printf ("%s", $doc->dump_mem (true, "UTF-8"));
		$handler = fopen (RSS, "w");
		fwrite ($handler, $doc->dump_mem (true, "UTF-8"));
		fclose ($handler);
	}
}
?>
