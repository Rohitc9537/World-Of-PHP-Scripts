<?php 

// Author: PHPFront.com � 2005
// License: Free (GPL)
//
// Version: 1.1
//
// Created: 8.12.2005 
//
// More information and downloads 
// available at http://www.PHPFront.com
//
// #### admincp/templates.php ####




$header = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html>
<head>
<title>Fpoll v1.1 AdminCP</title>
<link rel="stylesheet" href="css.css" media="all"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="en-us" />
</head>
<body>


<h2>Fpoll v1.1</h2>




<a href="index.php">Home</a> | <a href="new.php">New poll</a> | <a href="options.php">Options</a> | <a href="login.php?do=kill"><strong>Logout</strong></a>
<hr />
<br />';

$login_header = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html>
<head>
<title>Fpoll v1.1 AdminCP</title>
<link rel="stylesheet" href="css.css" media="all"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="en-us" />
</head>
<body>


<h2>Fpoll v1.1</h2>




<hr />
<br />';



$footer = '<br /><br /><hr /><div style="text-align: center;">&copy 2005 Fpoll v1.1 (<a href="http://www.phpfront.com">PHPfront.com</a>) </div></body>
</html>';

?>
