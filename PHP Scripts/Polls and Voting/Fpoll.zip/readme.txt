README.TXT

Fpoll v1.1 by PHPFront.com

-----------------------
Upload fpoll folder to your root directory
Edit config.php located in your admincp to correspond with your mysql details
Run install.php

To include the poll in your site simply add ...


           include("Fpoll/poll.php");


 inside any of your php files.




Support: admin@phpfront.com
www.phpfront.com