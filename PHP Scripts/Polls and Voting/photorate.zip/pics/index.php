<?
Header("Location: ../");
exit;
?>