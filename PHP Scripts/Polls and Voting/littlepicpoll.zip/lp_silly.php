<html>
<head>
<title>Little Poll Test Facility</title>
<basefont size="2" face="Verdana">
</head>
<body bgcolor="#000000" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF">
<center>
<br>
<h1>The Amazing Little Poll Silly Page</h1>
<br>
<br>
<table border=0 width=400 bgcolor=#FFFFFF>
	<tr>
    	<td><font size=2 color=#000000>
        	<strong>What the F*ck??</strong>
        </td>
    </tr>
    <tr>
        <td bgcolor="#000000">
            <font size="2" color="#FFFFFF">
            <br>
            <blockquote>
			This page allows you to see what happens if you return to the
			poll site after visting another link. Mainly to check whether the
			cookies work. Not so silly afterall, huh!
            </blockquote></td>
    </tr>
    <tr>
        <td bgcolor="#000000">
            <font size="2" color="#FFFFFF">
     		<blockquote><br>
          	<a href="lp_test.php">Link back to the test facility</a>
          	</blockquote>
        </td>
    </tr>
</table>
</center>



</body>
</html>