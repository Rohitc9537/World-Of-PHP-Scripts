<?php

/* ***************************** */
/* LANGUAGE STRINGS FOR PHPVOTER */
/* ***************************** */

$lang['vote_button'] = "R�sta";
$lang['onevote'] = "r�st";
$lang['votes'] = "r�ster";
$lang['result_saved'] = "Ditt resultat har nu sparats.<br />\n";
$lang['createvote'] = "Skapa/�ndra en omr�stning";
$lang['question'] = "Fr�gan";
$lang['alreadyvoted'] = "Du har redan r�stat p� den aktuella fr�gan.";
$lang['viewresults'] = "Visa resultat";
$lang['noip'] = "Din browser skickade inte med IP-nummer s� din r�st har inte sparats.<br />\n";
$lang['notactive'] = "<h1>Tyv�rr!</h1>\nDen fr�gan �r inte l�ngre aktiv s� det g�r inte att r�sta p� den.\n";
$lang['activequestion'] = "<b>Aktuell fr�ga:</b><br />\n";
$lang['totalvoters'] = "<br />Totalt antal r�stande: ";
$lang['info'] = <<<ENDSTRING
Dessa omr�stningar �r synnerligen ovetenskapliga och dess enda uppgift
�r att ge en indikation p� vad bes�karna p� www.rollspel.nu tycker i
olika fr�gor. Alla f�r skicka in fr�gor till <a
href="mailto:red@rollspel.nu">oss</a> s� l�gger vi upp nya med j�mna
mellanrum. Tycker ni inte om de alternativ som finns att v�lja p� s�
�r det inte mycket att g�ra �t f�rutom att ni kan skicka in egna fr�gor. 
<br /><br />
Vi f�rbeh�ller oss r�tten att refusera inskickade fr�gor utan att
beh�va motivera orsaken.
<br /><br />
ENDSTRING;
$lang['sorry'] = "Tyv�rr";
$lang['no_votes'] = "Inga r�ster";
$lang['no_votes_in_db'] = "Det finns inga r�ster i databasen.";
$lang['no_active_vote'] = "Det finns ingen aktiv omr�stning.";
$lang['error_header'] = "Ett fel har uppst�tt";
$lang['admin_menu'] = "PHPVoter Administrationsmeny";
$lang['admin_list'] = "Lista alla omr�stningar";
$lang['admin_create'] = "Skapa en ny omr�stning";
$lang['admin_list_header'] = "Lista �ver omr�stningar";
$lang['voteid'] = "ID";
$lang['question'] = "Fr�ga";
$lang['date'] = "Datum";
$lang['state'] = "Typ";
$lang['answers'] = "Fr�gor";
$lang['voters'] = "R�ster";
$lang['function'] = "Funktion";
$lang['inactive'] = "Inaktiv";
$lang['active'] = "Aktiv";
$lang['unfinished'] = "Opublicerad";
$lang['deleted'] = "Raderad";
$lang['showvote'] = "Visa/�ndra";
$lang['admin_show_vote'] = "Visa/�ndra en omr�stning";
$lang['admin_voter_list'] = "Lista �ver r�ster";
$lang['IP'] = "IP";
$lang['voterid'] = "ID";
$lang['answer'] = "Svar";
$lang['delete'] = "Ta bort";
$lang['change'] = "�ndra";
$lang['choice_id'] = "ID";
$lang['admin_delete_question'] = "Ta bort denna fr�ga";
$lang['admin_change_question'] = "�ndra denna fr�ga";
$lang['admin_vote_question'] = "R�sta p� denna fr�ga";
$lang['admin_set_this_active'] = "G�r denna fr�ga aktiv";
$lang['admin_return'] = "Tillbaka till administrationsmenyn";
$lang['identifier_deleted'] = "IP borttaget";
$lang['votes_updated'] = "Antalet r�ster har justerats.";
$lang['votes_not_updated'] = "R�stantalet har inte justerats d� typ av r�st inte sparas i databasen.";
$lang['vote_activated'] = "Denna omr�stning har aktiverats.";
$lang['one_active_vote'] = "Endast en aktiv omr�stning �r till�ten, alla andra aktiva omr�stningar har gjorts inaktiva.";
$lang['question_deleted'] = "Den valda fr�gan har tagits bort.";
$lang['voters_deleted'] = "Listan �ver r�stare har ocks� tagits bort.";
$lang['comment'] = "Kommentar till fr�gan (visas vid komplett lista och p� resultatsidan)";
$lang['savequestion'] = "Spara fr�ga / L�gg till extra svar";
$lang['new_answer'] = "Ny";
$lang['save_question'] = "Spara/�ndra omr�stningen";
$lang['answer_deleted'] = "Svaret har raderats";
$lang['question_updated'] = "Omr�stningen har uppdaterats";
$lang['error_incorrect_values'] = "Ett eller flera v�rden var felaktigt ifyllda, inget har sparats.";
$lang['error_access_denied'] = "Tilltr�de nekas!";
$lang['publish'] = "Publiceringsdatum";
$lang['information'] = "Information";
$lang['admin_menu'] = "Meny";
$lang['no_voters'] = "Det �r ingen som har svarat p� denna fr�ga �nnu.";
$lang['question_state'] = "Fr�gans status: ";
$lang['question_comment'] = "Kommentar till fr�gan: ";
$lang['vote_on_question'] = "R�sta p� en fr�ga";
$lang['set_active_vote'] = "Fr�ga aktiverad";
$lang['error_sql_query'] = "SQL-fr�ga";
$lang['error_sql'] = "Det blev ett SQL-fel";
$lang['error_notemplate'] = "Kunde inte hitta mallfilen till denna sida.";

?>
