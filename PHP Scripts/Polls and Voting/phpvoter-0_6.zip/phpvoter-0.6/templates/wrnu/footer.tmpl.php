<?php

$template_content = <<<ENDSTRING
        <!-- End of middle field -->
		</FONT>
                <BR><BR>
             </TD>
             <TD WIDTH=10>
                <IMG SRC="/images/trans.gif" BORDER=0 WIDTH="10" HEIGHT="2" ALT="">
             </TD>
          </TR>
                </TABLE>
        </TD>


        <TD VALIGN="top" WIDTH="169" HEIGHT="267">
        
	<!-- Beginning of right field -->
        
	<FONT SIZE="-1" FACE="helvetica, arial">
        {$tmplarr['oldquestions']}
	</FONT>
        
	<!-- End of right field -->
        
	</TD>
</TR>
</TABLE>

</BODY>
</HTML>
ENDSTRING;

?>