<?php

$template_content = <<<ENDSTRING
</font>
</body>
</html>
ENDSTRING;

?>