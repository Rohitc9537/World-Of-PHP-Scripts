FunGL: Survey Poll Software
CopyRight 2005
6-18-2005
Version 1.1
http://funGL.com or http://funGL/Download/ for documentation.
---------------------------------------------------------------
This software CopyRight 2005 FunGL organization.
Failure to comply with the Terms of Service below will result in prosecution under the maximum extent of the law.

This software cannot be resold or used to create profit.
This software may not be re-distributed. 
You may not charge for the use of the FunGL Software.
You may not use the FunGL software to directly complete with FunGL.com
You may not change this software in any way and then resell it. 
You may not hold FunGL or Associates liable for the use of this software.
You may not remove or alter any copyright notices, or alter or remove any links from the software to the FunGL.com site.
By download and or using the software you agree to these terms.
_________________________________________________________________

To install, unzip, place files on your web server.

allow temporary write access to config.php

run /install/index.php

Delete or Change permissions to secure /install/


If for some reason you are having problems and cannot get the software to work, you may just want to use our free
version http://fungl.com.

For more details view http://fungl.com/download/