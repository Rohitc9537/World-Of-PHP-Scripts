<li><a href="?page=project" class="nav">Projects</a></li>
<li><a href="?page=users" class="nav">Users</a></li>
<li><a href="?page=account" class="nav">Account</a></li>
<li><a href="?page=home&amp;action=logout" class="nav">Logout</a></li>
