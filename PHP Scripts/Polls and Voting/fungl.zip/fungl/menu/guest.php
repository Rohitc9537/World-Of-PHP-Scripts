<li><a href="?page=home" class="nav">Home</a></li>
<li><a href="?page=signup" class="nav">Signup</a></li>
<li><a href="?page=login" class="nav">Login</a></li>
