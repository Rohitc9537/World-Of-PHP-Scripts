<div class="rightbox">
	<h2>Help</h2>
	<h2>Create question</h2>
	Click the <b>Create&nbsp;question</b> link just below the headline to create a new question.<br/>
	<br/>

	<h2>Polls</h2>
	<b>Action links</b><br/>
	<b>Edit:</b> edit the question text.<br/>
	<b>Delete:</b> delete the question.<br/>	
</div>