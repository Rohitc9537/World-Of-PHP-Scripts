<div class="rightbox">
	<h2>Help</h2>
	<h2>Create project</h2>
	Click the <b>Create&nbsp;project</b> link just below the headline to create a new project.<br/>
	<br/>
	<b>Title:</b> The name of the project, is only shown here<br/>
	<b>Site:</b> The site that you will use the project on, is only shown here<br/>
	</p>
	<h2>Projects</h2>
	<b>Action links</b><br/>
	<b>Edit:</b> edit the name and the site of the project.<br/>
	<b>Edit polls:</b> edit the polls assosiated with the project.<br/>
	<b>Delete:</b> delete the project, this will also delete all assosiated polls and data<br/>
	<b>Show code:</b> show the code you need to copy/paste to your site to show the polls.<br/>
	</p>
</div>