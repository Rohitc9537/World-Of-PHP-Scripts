<div class="rightbox">
	<h2>Help</h2>
	<p><b>Username</b><br/>
	The username must only contain a-z, 0-9, - and _ characters.
	</p>
	<p><b>Email</b><br/>
	The email must be valid, we use the email to send you your account information and status messages about the system.
	</p>
</div>