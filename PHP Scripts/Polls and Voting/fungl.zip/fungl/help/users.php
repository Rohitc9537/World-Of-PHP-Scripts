<div class="rightbox">
	<h2>Help</h2>
	<p>You can't edit or delete any user with higher level that you self.</p>
	<p>When any user is changed the change will be mailed to the user.
	IE. if the you change the email and password of a user the new password will be 
	mailed to the user on the mail account present.</p>
</div>