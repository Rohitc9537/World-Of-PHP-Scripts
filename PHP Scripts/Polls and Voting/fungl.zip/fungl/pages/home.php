<h1>What is FunGL?</h1>

FunGL is a polling software that makes it possible to have a poll on your own website.<br/>
<br/>
All you need to do is copy/paste a small amount of html code into your website.<br/>
<br/>
Features:<br/>
<ul>
    <li>Up to 15 questions in each polls</li>
    <li>Organize your polls in projects.</li>
    <li>Manage polls in projects</li>
    <li>Create an unlimited amout of polls and projects</li>
    <li>Make projects that automaticaly switch the polls in a pattern defined by you</li>
</ul>
<br/>
<a href="?page=signup">Signup now!</a> its free.
   