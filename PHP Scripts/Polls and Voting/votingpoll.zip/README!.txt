Network-13 Voting Poll!
=======================

Requirements:

1 MySQL Database is required

Installation:

(1) Extract all files
(2) Upload all files to your webserver preferably to a sub directory called votingpoll
(3) CHMOD the directory to 777
(4) Once all files have been uploaded, Run install.php
(5) Fill out all fields in install.php
(6) Once setup is complete goto admin.php and login

http://network-13.com



