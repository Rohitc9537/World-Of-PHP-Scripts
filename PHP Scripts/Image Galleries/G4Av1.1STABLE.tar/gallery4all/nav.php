<?php 
include 'inc/config.db.php';
require 'inc/config.inc.php';
include 'inc/functions.inc.php';
include 'inc/functions.html.php';
show_gallery();
/** random pictures block **/
/*
$max - number of pictures to display
$width - the width of the table
*/
//html_random_pic_block($max='3', $width='100');
?>
