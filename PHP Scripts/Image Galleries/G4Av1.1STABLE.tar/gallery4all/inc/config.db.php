<?php
/*
Config file for connecting to MySQL
*/
$db_user=''; //MySQL username that has priviledges to database
$db_parola=''; //MySQL password
$db_host='localhost'; //localhost or the host of the MySQL server
$db_database='gallery4all'; //name of the database

$conn=@mysql_connect($db_host, $db_user, $db_parola) or die("Cannot connect to MySQL");
@mysql_select_db($db_database, $conn) or die("Cannot select database <i>".$db_database."</i>");
?>
