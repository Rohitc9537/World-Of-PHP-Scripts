<?php
###########
#Constante#
###########

//BEGIN general settings variables
define('_EMAIL_ADMIN', 'webmaster@linuxpress.ro'); //admin@google.ro
define('_URL_ABSOLUT_SITE', 'http://gallery4all.sourceforge.net/demo/'); //ex. http://www.my_site.ro/gallery4all/ with the trailing slash
define('_DIRECTOR_UPLOAD', '/home/gallery4all/htdocs/demo/images/'); //usr/local/htdocs/images/ with trailing slash
define('_DIRECTOR_UPLOAD_MARE', '/home/gallery4all/htdocs/demo/images/big/'); // /usr/local/htdocs/images/big/ with trailing slash
define('_WIDTH_POZA', '100'); //100  (in pixeli)
define('_WIDTH_TABLE', '45%'); //450 (pixels) or 90%
define('_ALIGN_TABLE', 'center'); //center , left, right
define('_NR_POZE_PER_PAG', '8'); //4x4=16 4x2=8 pics per page
define('_DIRECTOR_WEB_POZE_MICI', _URL_ABSOLUT_SITE.'images/'); // images/ with trailing slash
define('_DIRECTOR_WEB_ICONS', _DIRECTOR_WEB_POZE_MICI.'icons'); //icons
define('_DIRECTOR_WEB_POZE_MARI', _DIRECTOR_WEB_POZE_MICI.'big/'); // big/ with trailing slash
define('_FOLDER_ADMIN', _URL_ABSOLUT_SITE.'adm/'); // adm/ , admin/ , secretadmin123/ with trailing slash
define('_GD_LIBRARIES_VERSION', '1'); //set 1 if you are using 1.x and 2 if you are using 2.x (default 1)
//END general settings variables

################################
####BEGIN EXPERIMENTAL AREA#####
################################
/*
this is the experimental part. 
if you modify nothing happens (yet)
*/
############
#SQL tables#
############
#WARNING: THIS IS STILL EXPERIMENTAL!!
//begin variabile nume tabele
define('_SQL_TABLE_CATEGORIES', 'galerie_categorii');
define('_SQL_TABLE_PICS', 'galerie_poze');
//end variabile nume tabele

################################
######END EXPERIMENTAL AREA#####
################################
//BEGIN url special settings
##############################
/*
if you leave the default value 0 you will get standard urls like
nav.php?galerie_categorii_id=2&go=1&name=landscapes.
if you want your gallery to 'look' pretty or you want short urls
modify the value to 1.
NOTICE: if you change the value you must have mod_rewrite engine enabled in Apache.
if you change the value in static settings to any url (eg. mygallery.php) you need
to change that in .htaccess file in order to make mod_rewrite work.
this time you will get nice urls like: nav_2_1_landscapes.html
*/
define('_URL_REWRITE', 0);
##############################
#static settings##############
##############################
define('_URL_NAV', 'nav.php');
//begin urls from administration area
define('_URL_ADMIN', '');
//end urls from administration area
##############################
#url-uri dinamice#############
##############################
if(_URL_REWRITE==0){
define('_URL_NAV_CATEG', _URL_NAV.'?'._SQL_TABLE_CATEGORIES.'_id=%d&go=%d&name=%s');
define('_URL_NAV_POZE', _URL_NAV.'?'._SQL_TABLE_PICS.'_id=%d&name=%s');
} else {
define('_URL_NAV_CATEG', 'nav_%d_%d_%s.html');
define('_URL_NAV_POZE', 'poza_%d_%s.html');
}
##############################
//END url special settings
?>