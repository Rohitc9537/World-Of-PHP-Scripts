<?php
/** BEGIN cleaning up urls for mod_rewrite **/
function url_cleanup($url){
$unwanted_chars=array('#', '.', '"', '\'', ',', ' ', '$');
$replacing_chars=array('-', '', '', '', '', '-', '-');
$url=strtolower($url);
$url=str_replace($unwanted_chars, $replacing_chars, $url);
return $url;
}
/** END cleaning up urls for mod_rewrite **/
function show_gallery(){
  if(isset($_GET[""._SQL_TABLE_CATEGORIES."_id"])){
  show_list_category_pictures($galerie_categorii_id=(int)$_GET[""._SQL_TABLE_CATEGORIES."_id"]);
  } elseif(isset($_GET[""._SQL_TABLE_PICS."_id"])) {
  show_picture_detail($galerie_poze_id=(int)$_GET[""._SQL_TABLE_PICS."_id"]);
  } else {
  show_list_category_menu();
  }
}
  function menu_level2($parent) 
  { 
    if (isset($parent)) 
    { 
      $query = "SELECT "._SQL_TABLE_CATEGORIES."_id,
	  				   "._SQL_TABLE_CATEGORIES."_parent,
					   "._SQL_TABLE_CATEGORIES."_nume
	  		    FROM "._SQL_TABLE_CATEGORIES." 
	  			WHERE "._SQL_TABLE_CATEGORIES."_parent = ".$parent."
				ORDER BY "._SQL_TABLE_CATEGORIES."_nume"; 
				//echo '<font color=red>'.$query.'</font>';
    } 

    if (mysql_num_rows(mysql_query($query))==0) 
     echo '';
    else 
    { 
	$result = mysql_query($query);
      while ($row = mysql_fetch_array($result)) 
      { 
	  
/* BEGIN verify if a category has pictures in it */
$sql_cat_pic=@mysql_query("SELECT COUNT("._SQL_TABLE_PICS."_id) FROM "._SQL_TABLE_PICS."
						  WHERE "._SQL_TABLE_CATEGORIES."_id=".$row[""._SQL_TABLE_CATEGORIES."_id"]."")
						  or die(mysql_error());
						  $nr_cat_pics=@mysql_result($sql_cat_pic, 0);
/* END verify if a category has pictures in it */ 

		?>
		<img src="<?php echo _DIRECTOR_WEB_ICONS; ?>/folder_open_mic.gif">
		<?php if($nr_cat_pics>0){ ?>
		<a href="./<?php printf(_URL_NAV_CATEG, $row[""._SQL_TABLE_CATEGORIES."_id"], 1, url_cleanup($url=$row[""._SQL_TABLE_CATEGORIES."_nume"])); ?>">
		<?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]); ?>
		</a>
		<?php } else {
		echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]);
		} ?> 
		<?php

        $sub_query = "SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_parent,
							 "._SQL_TABLE_CATEGORIES."_nume 
					  FROM "._SQL_TABLE_CATEGORIES." 
					  WHERE "._SQL_TABLE_CATEGORIES."_parent = " . $row[""._SQL_TABLE_CATEGORIES."_id"] . " 
					  LIMIT 0, 1"; 
        if ($sub_result =  mysql_query ($sub_query)) 
        { 
           menu_level2($row[""._SQL_TABLE_CATEGORIES."_id"]); 
        } 
      } 
    } 
  }

  function menu_level($parent, $indent) 
  { 
    if (isset($parent)) 
    { 
      $query = "SELECT "._SQL_TABLE_CATEGORIES."_id,
	  				   "._SQL_TABLE_CATEGORIES."_parent,
					   "._SQL_TABLE_CATEGORIES."_nume
	  		    FROM "._SQL_TABLE_CATEGORIES." 
	  			WHERE "._SQL_TABLE_CATEGORIES."_parent = ".$parent."
				ORDER BY "._SQL_TABLE_CATEGORIES."_nume"; 
    } 

    if (mysql_num_rows(mysql_query($query))==0) 
      echo '';
    else 
    { 
	$result = mysql_query($query);
      while ($row = mysql_fetch_array($result)) 
      { 

        echo "<a href='./"._URL_NAV."?"._SQL_TABLE_CATEGORIES."_id=" . $row[""._SQL_TABLE_CATEGORIES."_id"] . "'>"; 
		echo "<div style='text-indent:  ".$indent." ; font-weight: bold'>".stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"])."</a></div>"; 
		

        $sub_query = "SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_parent,
							 "._SQL_TABLE_CATEGORIES."_nume 
					  FROM "._SQL_TABLE_CATEGORIES." 
					  WHERE "._SQL_TABLE_CATEGORIES."_parent = " . $row[""._SQL_TABLE_CATEGORIES."_id"] . " 
					  LIMIT 0, 1"; 
        if ($sub_result =  mysql_query ($sub_query)) 
        { 
          $sub_indent = $indent + 10; 
          menu_level($row[""._SQL_TABLE_CATEGORIES."_id"], $sub_indent); 
        } 
      } 
    } 
  }
function admin_html_list_galerie_categorii(){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
								 "._SQL_TABLE_CATEGORIES."_nume
						  FROM "._SQL_TABLE_CATEGORIES."
						  ORDER BY "._SQL_TABLE_CATEGORIES."_parent ASC")
						  or die(mysql_error());
while($row=mysql_fetch_array($sql_sel)){
echo '<a href="./browse_categorii.php?'._SQL_TABLE_CATEGORIES.'_id='.(int)$row[""._SQL_TABLE_CATEGORIES."_id"].'">'.stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]).'</a><br>';
}
}
function html_dropdown_galerie_categorii2($galerie_categorii_id){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_nume 
					  FROM "._SQL_TABLE_CATEGORIES."
					  ORDER BY "._SQL_TABLE_CATEGORIES."_parent ASC")
					  or die(mysql_error());
$sql_sel2=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
							  "._SQL_TABLE_CATEGORIES."_nume
						  FROM "._SQL_TABLE_CATEGORIES."
						  WHERE "._SQL_TABLE_CATEGORIES."_id='".(int)$galerie_categorii_id."'
						  LIMIT 1")
						  or die(mysql_error());
$row2=mysql_fetch_array($sql_sel2);
echo '<select name="'._SQL_TABLE_CATEGORIES.'_id">';
echo '<option value="'.(int)$row2[""._SQL_TABLE_CATEGORIES."_id"].'" selected>'.$row2[""._SQL_TABLE_CATEGORIES."_nume"].'</option>';
echo '<option value="0">TOP</option>';
while($row=mysql_fetch_array($sql_sel)){
echo '<option value="'.(int)$row[""._SQL_TABLE_CATEGORIES."_id"].'">'.$row[""._SQL_TABLE_CATEGORIES."_nume"].'</option>';
}
echo '</select>';
}
function html_dropdown_galerie_categorii(){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_parent,
							 "._SQL_TABLE_CATEGORIES."_nume
						  FROM "._SQL_TABLE_CATEGORIES."
						  ORDER BY "._SQL_TABLE_CATEGORIES."_parent ASC")
						  or die(mysql_error());
echo '<select name="'._SQL_TABLE_CATEGORIES.'_id">';
echo '<option value="0">TOP</option>';
while($row=mysql_fetch_array($sql_sel)){
if($row[""._SQL_TABLE_CATEGORIES."_parent"]==0){
echo '<option value="'.(int)$row[""._SQL_TABLE_CATEGORIES."_id"].'">['.stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]).']</option>';
} else {
echo '<option value="'.(int)$row[""._SQL_TABLE_CATEGORIES."_id"].'">'.stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]).'</option>';
}
}
echo '</select>';
}
/*************************************************************************/
/**********************BEGIN resize pictures******************************/
/*************************************************************************/
//JPEG function 
function thumb_jpeg($image_name) 
{ 
    global $source_path; 
    global $destination_path; 

    global $new_width; 
    global $new_height; 

    /** check if version of gd **/
	if(_GD_LIBRARIES_VERSION==1){
	$destimg=imagecreate($new_width,$new_height) 
	or die("Cannot create the picture. Check if you have GD libraries installed."); 
	} else {
	$destimg=imagecreatetruecolor($new_width, $new_height) 
			or die("Cannot create the picture. Check if you configured the right version of GD");
    }
	 /** end **/
	$srcimg=imagecreatefromjpeg($source_path.$image_name) or die("Problem In opening Source Image"); 

    ImageCopyResized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg)) or die("Problem In resizing"); 

    ImageJPEG($destimg,$destination_path.$image_name) or die("Problem In saving");
} 

//PNG function 
function thumb_png($image_name) 
{ 
    global $source_path; 
    global $destination_path; 

    global $new_width; 
    global $new_height; 

    $destimg=ImageCreate($new_width,$new_height) or die("Problem In Creating image"); 

    $srcimg=ImageCreateFromPNG($source_path.$image_name) or die("Problem In opening Source Image"); 

    ImageCopyResized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg)) or die("Problem In resizing"); 

    ImagePNG($destimg,$destination_path.$image_name) or die("Problem In saving"); 
}
/*************************************************************************/
/**********************END resize pictures******************************/
/*************************************************************************/
?>