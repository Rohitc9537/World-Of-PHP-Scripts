<?php
/****function for displaying random pictures in a block****/

function html_random_pic_block($max='3', $width='100%'){
/** number of pics **/
$sql_count=mysql_query("SELECT COUNT("._SQL_TABLE_PICS."_id)
				  FROM "._SQL_TABLE_PICS."")
				  or die(mysql_error());
$max_pics=mysql_result($sql_count, 0);
/** starting loop **/
for($i=1;$i<=$max;$i++){

$galerie_poze_id=rand(1, $max_pics);

$sql=mysql_query("SELECT "._SQL_TABLE_PICS."_id,
						 "._SQL_TABLE_CATEGORIES."_id,
						 "._SQL_TABLE_PICS."_nume,
						 "._SQL_TABLE_PICS."_file
				  FROM "._SQL_TABLE_PICS."
				  WHERE "._SQL_TABLE_PICS."_id='".$galerie_poze_id."'
				  LIMIT 1")
				  or die(mysql_error());

$row=mysql_fetch_array($sql);
$sql_c=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
						   "._SQL_TABLE_CATEGORIES."_nume,
						   "._SQL_TABLE_CATEGORIES."_descriere
					FROM "._SQL_TABLE_CATEGORIES."
					WHERE "._SQL_TABLE_CATEGORIES."_id='".$row[""._SQL_TABLE_CATEGORIES."_id"]."'")
					or die(mysql_error());
$row_c=mysql_fetch_array($sql_c);
/** html **/
?>
<table width="<?php echo $width; ?>"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><div align="center"><a href="./<?php printf(_URL_NAV_POZE, (int)$row[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$row[""._SQL_TABLE_PICS."_nume"])); ?>"><img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$row[""._SQL_TABLE_PICS."_file"]; ?>" alt="<?php echo stripslashes($row[""._SQL_TABLE_PICS."_nume"]); ?>" hspace="0" vspace="3" border="0" align="absmiddle"></a></div></td>
  </tr>
  <tr>
    <td><div align="center"><a href="./<?php printf(_URL_NAV_POZE, (int)$row[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$row[""._SQL_TABLE_PICS."_nume"])); ?>"><?php echo stripslashes($row[""._SQL_TABLE_PICS."_nume"]); ?></a><br>(<?php echo stripslashes($row_c[""._SQL_TABLE_CATEGORIES."_nume"]); ?>)</div></td>
  </tr>
</table>
<?php
/** html **/

}//for
					
}//function
/****END function for displaying random pictures in a block****/
?>
<?php
function show_list_category_menu(){ ?>

<table width="<?php echo _WIDTH_TABLE; ?>"  border="0" cellspacing="0" cellpadding="3" align="<?php echo _ALIGN_TABLE; ?>">
  <tr> 
    <td colspan="4"><strong>Menu categories</strong></td> 
  </tr> 
<tr> 
<? 
$sql = "SELECT "._SQL_TABLE_CATEGORIES."_id,
			   "._SQL_TABLE_CATEGORIES."_parent,
			   "._SQL_TABLE_CATEGORIES."_nume,
			   "._SQL_TABLE_CATEGORIES."_descriere 
		FROM "._SQL_TABLE_CATEGORIES."
		WHERE "._SQL_TABLE_CATEGORIES."_parent='0'
		"; 
$execute = mysql_query($sql);
$numrows = mysql_num_rows($execute);

$counter = 0; 
$increment = 1; 
for ($i=0; $i <$numrows; $i++) 
{ 
    $rs = mysql_fetch_array($execute); 
    $counter = $counter + $increment; 
    //echo $counter;
/* BEGIN verify if a category has pictures in it */
$sql_cat_pic=@mysql_query("SELECT COUNT("._SQL_TABLE_PICS."_id) FROM "._SQL_TABLE_PICS."
						  WHERE "._SQL_TABLE_CATEGORIES."_id=".$rs[""._SQL_TABLE_CATEGORIES."_id"]."")
						  or die(mysql_error());
						  $nr_cat_pics=@mysql_result($sql_cat_pic, 0);
/* END verify if a category has pictures in it */ 
    if ($counter == 5) 
    { 
// close the last row and start a new row 
    $counter = 1; 
?> 
</tr> 
<tr> 
    <td align="center">
	<img src="<?php echo _DIRECTOR_WEB_ICONS; ?>/folder_open.gif" width="24" height="23" border="0">
	<?php if($nr_cat_pics>0){ ?>
	<a href="./<?php printf(_URL_NAV_CATEG, $rs[""._SQL_TABLE_CATEGORIES."_id"], 1, url_cleanup($url=$rs[""._SQL_TABLE_CATEGORIES."_nume"])); ?>">
	<b><?php echo stripslashes($rs[""._SQL_TABLE_CATEGORIES."_nume"]); ?></b>
	</a>
	<?php } else { ?>
	<b><?php echo stripslashes($rs[""._SQL_TABLE_CATEGORIES."_nume"]); ?></b>
	<?php } ?>
	<br>
	<?php menu_level2($parent=$rs[""._SQL_TABLE_CATEGORIES."_id"]); ?></td> 
<? 
    } 
    else 
    { 
// add another coloumn 
?> 
    <td align="center">
	<img src="<?php echo _DIRECTOR_WEB_ICONS; ?>/folder_open.gif" width="24" height="23" border="0">
	<?php if($nr_cat_pics>0){ ?>
	<a href="./<?php printf(_URL_NAV_CATEG, $rs[""._SQL_TABLE_CATEGORIES."_id"], 1, url_cleanup($url=$rs[""._SQL_TABLE_CATEGORIES."_nume"])); ?>">
	<b><?php echo stripslashes($rs[""._SQL_TABLE_CATEGORIES."_nume"]); ?></b>
	</a>
	<?php } else { ?>
	<b><?php echo stripslashes($rs[""._SQL_TABLE_CATEGORIES."_nume"]); ?></b>
	<?php } ?>
	<br>
	<?php menu_level2($parent=$rs[""._SQL_TABLE_CATEGORIES."_id"]); ?></td> 
<?     
} 
}   
?> 
</tr> 
</table>
<?php
@mysql_free_result();
}//function
?>
<?php function show_picture_detail($galerie_poze_id){
$sql_p=mysql_query("SELECT "._SQL_TABLE_PICS."_id,
						 "._SQL_TABLE_CATEGORIES."_id,
						 "._SQL_TABLE_PICS."_nume,
						 "._SQL_TABLE_PICS."_descriere,
						 "._SQL_TABLE_PICS."_file,
						 "._SQL_TABLE_PICS."_width,
						 "._SQL_TABLE_PICS."_height,
						 "._SQL_TABLE_PICS."_filesize,
						 "._SQL_TABLE_PICS."_data,
						 "._SQL_TABLE_PICS."_hits
				  FROM "._SQL_TABLE_PICS."
				  WHERE "._SQL_TABLE_PICS."_id='".$galerie_poze_id."'
				  AND "._SQL_TABLE_PICS."_status='1'
				  LIMIT 1")
				  or die(mysql_error());
$row_p=mysql_fetch_array($sql_p);
//begin contorizare hit
$sql_ch=mysql_query("UPDATE "._SQL_TABLE_PICS." SET
					 "._SQL_TABLE_PICS."_hits="._SQL_TABLE_PICS."_hits+1
					 WHERE "._SQL_TABLE_PICS."_id=".(int)$row_p[""._SQL_TABLE_PICS."_id"]."")
					 or die(mysql_error());
//end contorizare hit
?>
<table width="<?php echo _WIDTH_TABLE; ?>"  border="0" cellspacing="3" cellpadding="3" align="<?php echo _ALIGN_TABLE; ?>">
  <tr>
    <td>View picture details - <?php echo stripslashes($row_p[""._SQL_TABLE_PICS."_nume"]); ?></td>
  </tr>
  <tr>
    <td><div align="center">
	<a href="<?php echo _DIRECTOR_WEB_POZE_MARI.$row_p[""._SQL_TABLE_PICS."_file"]; ?>"><img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$row_p[""._SQL_TABLE_PICS."_file"]; ?>" alt="<?php echo stripslashes($row_p[""._SQL_TABLE_PICS."_nume"]); ?>" border="0"></a><br>
      <font size="1"><a target="_blank" href="<?php echo _DIRECTOR_WEB_POZE_MARI.$row_p[""._SQL_TABLE_PICS."_file"]; ?>">Click here to enlarge </a></font>
    </div></td>
  </tr>
  <tr>
    <td><font size="2"><?php echo stripslashes($row_p[""._SQL_TABLE_PICS."_descriere"]); ?></font></td>
  </tr>
  <tr>
    <td><b>Hits:</b> <?php echo $row_p[""._SQL_TABLE_PICS."_hits"]; ?><br>
	<b>Disk size:</b> <?php echo number_format($row_p[""._SQL_TABLE_PICS."_filesize"]); ?> bytes<br>
	<b>Pic size:</b> <?php echo $row_p[""._SQL_TABLE_PICS."_width"].'x'.$row_p[""._SQL_TABLE_PICS."_height"]; ?>
	<b>Date:</b> <?php $data_ora=explode(' ', $row_p[""._SQL_TABLE_PICS."_data"]); echo $data_ora[0]; ?><br>
	<b>Hour:</b> <?php echo $data_ora[1]; ?></td>
  </tr>
  <tr>
    <td><div align="right"><a href="javascript:history.back()">&lt;&lt; Go back</a></div></td>
  </tr>
</table>

<?php } ?>

<?php function show_list_category_pictures($galerie_categorii_id){ 
$sql_sel_cat=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_nume,
								 "._SQL_TABLE_CATEGORIES."_descriere
						  FROM "._SQL_TABLE_CATEGORIES."
						  WHERE "._SQL_TABLE_CATEGORIES."_id='".$galerie_categorii_id."'
						  LIMIT 1")
						  or die(mysql_error());
$row_cat=mysql_fetch_array($sql_sel_cat);
?>
<table width="<?php echo _WIDTH_TABLE; ?>"  border="0" cellspacing="0" cellpadding="3" align="<?php echo _ALIGN_TABLE; ?>">
  <tr> 
    <td colspan="4"><strong>View pictures - <?php echo stripslashes($row_cat[""._SQL_TABLE_CATEGORIES."_nume"]); ?></strong></td> 
  </tr> 
  <tr>
  <td colspan="4"><font size="1"><?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_descriere"]); ?></font></td>
  </tr>
<tr>
<?php 
//next - prev
if(!isset($_GET['go'])){ 
    $page = 1; 
} else { 
    $page = $_GET['go']; 
}
$max_results = _NR_POZE_PER_PAG; 
$from = (($page * $max_results) - $max_results);
//next - prev
$sql = "SELECT "._SQL_TABLE_PICS."_id,
			   "._SQL_TABLE_CATEGORIES."_id,
			   "._SQL_TABLE_PICS."_nume,
			   "._SQL_TABLE_PICS."_descriere,
			   "._SQL_TABLE_PICS."_file,
			   "._SQL_TABLE_PICS."_status 
		FROM "._SQL_TABLE_PICS."
		WHERE "._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id."
		LIMIT ".(int)$from.", ".(int)$max_results.""; 

$execute = mysql_query($sql);
$numrows = mysql_num_rows($execute);
$sql_nr = mysql_query("SELECT "._SQL_TABLE_PICS."_id,
			   "._SQL_TABLE_CATEGORIES."_id,
			   "._SQL_TABLE_PICS."_nume,
			   "._SQL_TABLE_PICS."_descriere,
			   "._SQL_TABLE_PICS."_file,
			   "._SQL_TABLE_PICS."_status 
		FROM "._SQL_TABLE_PICS."
		WHERE "._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id.""); 
//next
$total_results = mysql_num_rows($sql_nr);
//prev

$counter = 0; 
$increment = 1; 
for ($i=0; $i <$numrows; $i++) 
{ 
    $rs = mysql_fetch_array($execute); 
    $counter = $counter + $increment; 
    //echo $counter; 
    if ($counter == 5) 
    { 
// close the last row and start a new row 
    $counter = 1; 
?> 
</tr> 
<tr> 
    <td align="center">
	<a href="./<?php printf(_URL_NAV_POZE, (int)$rs[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$rs[""._SQL_TABLE_PICS."_nume"])); ?>">
	<img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$rs[""._SQL_TABLE_PICS."_file"]; ?>" border="0">
	</a><br><a href="./<?php printf(_URL_NAV_POZE, (int)$rs[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$rs[""._SQL_TABLE_PICS."_nume"])); ?>"><? echo stripslashes($rs[""._SQL_TABLE_PICS."_nume"]); ?>
	</a><br></td> 
<? 
    } 
    else 
    { 
// add another coloumn 
?> 
    <td align="center">
	<a href="./<?php printf(_URL_NAV_POZE, (int)$rs[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$rs[""._SQL_TABLE_PICS."_nume"])); ?>">
	<img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$rs[""._SQL_TABLE_PICS."_file"]; ?>" border="0">
	</a><br><a href="./<?php printf(_URL_NAV_POZE, (int)$rs[""._SQL_TABLE_PICS."_id"], url_cleanup($url=$rs[""._SQL_TABLE_PICS."_nume"])); ?>"><? echo stripslashes($rs[""._SQL_TABLE_PICS."_nume"]); ?>
	</a><br></td> 
<?     
} 
?> 
<? 
}   
?> 
</tr> 
</table>
<?php
//next - prev
$total_pages = ceil($total_results / $max_results); 
echo "<center>";
if($page > 1){ 
    $prev = ($page - 1); 
?>
<a href="<?php printf(_URL_NAV_CATEG, (int)$galerie_categorii_id, $prev, 0); ?>">&lt;&lt;Previous Page </a>&nbsp;
    <?php
} 

for($i = 1; $i <= $total_pages; $i++){ 
    if(($page) == $i){ 
        echo "$i&nbsp;"; 
        } else {
		?>
<a href="<?php printf(_URL_NAV_CATEG, (int)$galerie_categorii_id, $i, 0); ?>"><?php echo $i; ?></a>&nbsp;
<?php 
    } 
} 

if($page < $total_pages){ 
    $next = ($page + 1);
	?>
<a href="<?php printf(_URL_NAV_CATEG, (int)$galerie_categorii_id, $next, 0); ?>">Next page &gt;&gt;</a>
<?php 
} 
echo "</center>"; 
//next - prev
@mysql_free_result();
}//function

function admin_add_picture($galerie_categorii_id){ ?>

<table width="100%"  border="0" cellspacing="0" cellpadding="3">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?<?php echo _SQL_TABLE_CATEGORIES; ?>_id=<?php echo $galerie_categorii_id; ?>" method="POST" enctype="multipart/form-data">
  <tr>
    <td colspan="2"><strong>Add picture</strong></td>
  </tr>
  <tr>
    <td>Category:</td>
    <td><?php html_dropdown_galerie_categorii2($galerie_categorii_id); ?></td>
  </tr>
  <tr>
    <td width="20%">Name:</td>
    <td><input name="<?php echo _SQL_TABLE_PICS; ?>_nume" type="text" value="<?php echo stripslashes($_POST[""._SQL_TABLE_PICS."_nume"]); ?>" size="50"></td>
  </tr>
  <tr>
    <td>Long description :</td>
    <td><textarea name="<?php echo _SQL_TABLE_PICS; ?>_descriere" cols="50" rows="5"><?php echo stripslashes($_POST[""._SQL_TABLE_PICS."_descriere"]); ?></textarea></td>
  </tr>
  <tr>
    <td>Picture:</td>
    <td><input name="<?php echo _SQL_TABLE_PICS; ?>_file" type="file"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="add_picture" type="submit" value="Add picture"></td>
  </tr>
  </form>
</table>
<?php } ?>
<?php function admin_edit_picture($galerie_poze_id){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_PICS."_id,
							 "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_PICS."_nume,
							 "._SQL_TABLE_PICS."_descriere,
							 "._SQL_TABLE_PICS."_file,
							 "._SQL_TABLE_PICS."_status
					  FROM "._SQL_TABLE_PICS."
					  WHERE "._SQL_TABLE_PICS."_id='".(int)$galerie_poze_id."'
					  LIMIT 1")
					  or die(mysql_error());
$row=mysql_fetch_array($sql_sel);
 ?>
<table width="100%"  border="0" cellspacing="0" cellpadding="3">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
  <tr>
    <td colspan="3"><strong>Edit picture</strong></td>
  </tr>
  <tr>
    <td width="20%">Category:</td>
    <td colspan="2"><?php html_dropdown_galerie_categorii2($galerie_categorii_id=$row[""._SQL_TABLE_CATEGORIES."_id"]); ?></td>
  </tr>
  <tr>
    <td>Name:</td>
    <td colspan="2"><input name="<?php echo _SQL_TABLE_PICS; ?>_nume" type="text" value="<?php echo stripslashes($row[""._SQL_TABLE_PICS."_nume"]); ?>" size="50"></td>
  </tr>
  <tr>
    <td>Long description:</td>
    <td><textarea name="<?php echo _SQL_TABLE_PICS; ?>_descriere" cols="50" rows="5"><?php echo stripslashes($row[""._SQL_TABLE_PICS."_descriere"]); ?></textarea></td>
    <td><img alt="<?php echo stripslashes($row[""._SQL_TABLE_PICS."_nume"]); ?>" src="<?php echo _DIRECTOR_WEB_POZE_MICI.$row[""._SQL_TABLE_PICS."_file"]; ?>" border="0"><br>
      <font size="1">Small pic</font></td>
  </tr>
  <tr>
    <td>Picture:</td>
    <td colspan="2"><input name="<?php echo _SQL_TABLE_PICS; ?>_file" type="file"> </td>
  </tr>
  <tr>
    <td>Status:</td>
    <td colspan="2"><input name="<?php echo _SQL_TABLE_PICS; ?>_status" type="radio" value="1" <?php if($row[""._SQL_TABLE_PICS."_status"]==1){ echo 'checked'; } ?>>
      Active 
      <input name="<?php echo _SQL_TABLE_PICS; ?>_status" type="radio" value="0" <?php if($row[""._SQL_TABLE_PICS."_status"]==0){ echo 'checked'; } ?>> 
      Inactive</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><input type="hidden" value="<?php echo (int)$row[""._SQL_TABLE_PICS."_id"]; ?>" name="<?php echo _SQL_TABLE_PICS; ?>_id"></td>
    <td colspan="2"><input name="edit_picture" type="submit" value="Modify picture"></td>
  </tr>
  </form>
</table>
<?php } ?>
<?php function admin_add_category(){ ?>
<table width="100%"  border="0" cellspacing="0" cellpadding="3">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
  <tr>
    <td colspan="2"><strong>Add category</strong></td>
  </tr>
  <tr>
    <td width="20%">Name:</td>
    <td><input name="<?php echo _SQL_TABLE_CATEGORIES; ?>_nume" type="text" value="<?php echo stripslashes($_POST[""._SQL_TABLE_CATEGORIES."_nume"]); ?>" size="50"></td>
  </tr>
  <tr>
    <td>Description:</td>
    <td><textarea name="<?php echo _SQL_TABLE_CATEGORIES; ?>_descriere" cols="50" rows="5"><?php echo stripslashes($_POST[""._SQL_TABLE_CATEGORIES."_descriere"]); ?></textarea></td>
  </tr>
  <tr>
    <td>Parent category : </td>
    <td><?php html_dropdown_galerie_categorii(); ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="add_category" type="submit" value="Add category"></td>
  </tr>
  </form>
</table>
<?php } ?>
<?php function admin_edit_category($galerie_categorii_id){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_parent,
							 "._SQL_TABLE_CATEGORIES."_nume,
							 "._SQL_TABLE_CATEGORIES."_descriere,
							 "._SQL_TABLE_CATEGORIES."_status
					  FROM "._SQL_TABLE_CATEGORIES."
					  WHERE "._SQL_TABLE_CATEGORIES."_id='".(int)$galerie_categorii_id."'
					  LIMIT 1")
					  or die(mysql_error());
$row=mysql_fetch_array($sql_sel);
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="3">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
  <tr>
    <td colspan="2"><strong>Edit category</strong></td>
  </tr>
  <tr>
    <td width="20%">Name:</td>
    <td><input name="<?php echo _SQL_TABLE_CATEGORIES; ?>_nume" type="text" value="<?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]); ?>" size="50"></td>
  </tr>
  <tr>
    <td>Description:</td>
    <td><textarea name="<?php echo _SQL_TABLE_CATEGORIES; ?>_descriere" cols="50" rows="5"><?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_descriere"]); ?></textarea></td>
  </tr>
  <tr>
    <td>Parent category : </td>
    <td><?php 
	if(empty($row[""._SQL_TABLE_CATEGORIES."_parent"])){
	html_dropdown_galerie_categorii();
	} else {
	html_dropdown_galerie_categorii2($galerie_categorii_id=$row[""._SQL_TABLE_CATEGORIES."_parent"]);
	} ?></td>
  </tr>
  <tr>
    <td>Status:</td>
    <td><input name="<?php echo _SQL_TABLE_CATEGORIES; ?>_status" type="radio" value="1" <?php if($row[""._SQL_TABLE_CATEGORIES."_status"]==1){ echo 'checked'; } ?>>
Active
  <input name="<?php echo _SQL_TABLE_CATEGORIES; ?>_status" type="radio" value="0" <?php if($row[""._SQL_TABLE_CATEGORIES."_status"]==0){ echo 'checked'; } ?>>
Inactive</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input type="hidden" name="<?php echo _SQL_TABLE_CATEGORIES; ?>_id_hidden" value="<?php echo $row[""._SQL_TABLE_CATEGORIES."_id"]; ?>"></td>
    <td><input name="edit_category" type="submit" value="Edit category"></td>
  </tr>
  </form>
</table>
<?php } ?>
<?php function admin_html_list_galery_categories(){
$sql_sel=mysql_query("SELECT "._SQL_TABLE_CATEGORIES."_id,
							 "._SQL_TABLE_CATEGORIES."_parent,
							 "._SQL_TABLE_CATEGORIES."_nume,
							 "._SQL_TABLE_CATEGORIES."_descriere,
							 "._SQL_TABLE_CATEGORIES."_status
					  FROM "._SQL_TABLE_CATEGORIES."
					  ORDER BY "._SQL_TABLE_CATEGORIES."_parent ASC")
					  or die(mysql_error());
 ?>
<table width="100%"  border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td><strong>List categories</strong></td>
  </tr>
<?php while($row=mysql_fetch_array($sql_sel)){ ?>  
  <tr>
    <td>[ <b><?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]); ?></b> ] (<a href="./edit_category.php?<?php echo _SQL_TABLE_CATEGORIES; ?>_id=<?php echo $row[""._SQL_TABLE_CATEGORIES."_id"]; ?>">Edit</a>) (<a href="./list_pics.php?<?php echo _SQL_TABLE_CATEGORIES; ?>_id=<?php echo $row[""._SQL_TABLE_CATEGORIES."_id"]; ?>">View pictures </a>)<br>
    <font size="1"><?php echo stripslashes($row[""._SQL_TABLE_CATEGORIES."_nume"]); ?></font><br></td>
  </tr>
<?php } ?>
</table>
<?php } ?>
<?php function admin_list_category_pictures($galerie_categorii_id){ 
?>

<table width="100%"  border="0" cellspacing="0" cellpadding="3">
  <tr> 
    <td colspan="4"><strong>List of pictures</strong></td> 
  </tr> 
<tr>
<tr>
<td colspan="4">
<?php
$sql_check=mysql_query("SELECT COUNT(galerie_poze_id) AS nr_of_pics
						FROM galerie_poze
						WHERE galerie_categorii_id=".(int)$galerie_categorii_id."")
						or die(mysql_error());
$nr_of_pics=mysql_result($sql_check, 0);
if($nr_of_pics==0){
echo '<font color=red>You have no pictures in this category</font><br>
	  <a href="./list_categories.php">Click here</a> to go back to category listing.';
} else {
echo 'Number of pictures: '.$nr_of_pics;
}
?></td>
</tr> 
<? 
//next - prev
if(!isset($_GET['go'])){ 
    $page = 1; 
} else { 
    $page = $_GET['go']; 
}
$max_results = 8; 
$from = (($page * $max_results) - $max_results);
//next - prev
$sql = "SELECT "._SQL_TABLE_PICS."_id,
			   "._SQL_TABLE_CATEGORIES."_id,
			   "._SQL_TABLE_PICS."_nume,
			   "._SQL_TABLE_PICS."_descriere,
			   "._SQL_TABLE_PICS."_file,
			   "._SQL_TABLE_PICS."_status 
		FROM "._SQL_TABLE_PICS."
		WHERE "._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id."
		LIMIT ".(int)$from.", ".(int)$max_results.""; 

$execute = mysql_query($sql);
$numrows = mysql_num_rows($execute);
$sql_nr = mysql_query("SELECT "._SQL_TABLE_PICS."_id,
			   "._SQL_TABLE_CATEGORIES."_id,
			   "._SQL_TABLE_PICS."_nume,
			   "._SQL_TABLE_PICS."_descriere,
			   "._SQL_TABLE_PICS."_file,
			   "._SQL_TABLE_PICS."_status 
		FROM "._SQL_TABLE_PICS."
		WHERE "._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id.""); 
//next
$total_results = mysql_num_rows($sql_nr);
//prev

$counter = 0; 
$increment = 1; 
for ($i=0; $i <$numrows; $i++) 
{ 
    $rs = mysql_fetch_array($execute); 
    $counter = $counter + $increment; 
    //echo $counter; 
    if ($counter == 5) 
    { 
// close the last row and start a new row 
    $counter = 1; 
?> 
</tr> 
<tr> 
    <td align="center"><a href="./edit_picture.php?<?php echo _SQL_TABLE_PICS; ?>_id=<?php echo (int)$rs[""._SQL_TABLE_PICS."_id"]; ?>"><img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$rs[""._SQL_TABLE_PICS."_file"]; ?>" border="0"></a><br>
      <? echo $rs[""._SQL_TABLE_PICS."_nume"]; ?><br>
	<font size="1"><a href="./edit_picture.php?<?php echo _SQL_TABLE_PICS; ?>_id=<?php echo (int)$rs[""._SQL_TABLE_PICS."_id"]; ?>">Edit</a></font></td> 
<? 
    } 
    else 
    { 
// add another coloumn 
?> 
    <td align="center"><a href="./edit_picture.php?<?php echo _SQL_TABLE_PICS; ?>_id=<?php echo (int)$rs[""._SQL_TABLE_PICS."_id"]; ?>"><img src="<?php echo _DIRECTOR_WEB_POZE_MICI.$rs[""._SQL_TABLE_PICS."_file"]; ?>" border="0"></a><br>
      <? echo $rs[""._SQL_TABLE_PICS."_nume"]; ?><br>
	<font size="1"><a href="./edit_picture.php?<?php echo _SQL_TABLE_PICS; ?>_id=<?php echo (int)$rs[""._SQL_TABLE_PICS."_id"]; ?>">Edit</a></font></td> 
<?     
} 
?> 
<? 
}   
?> 
</tr> 
</table>
<?php
//next - prev
$total_pages = ceil($total_results / $max_results); 
echo "<center>";
if($page > 1){ 
    $prev = ($page - 1); 
    echo "<a href=\"./list_pics.php?"._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id."&go=".$prev."\">&lt;&lt;Inapoi</a>&nbsp;"; 
} 

for($i = 1; $i <= $total_pages; $i++){ 
    if(($page) == $i){ 
        echo "$i&nbsp;"; 
        } else { 
            echo "<a href=\"./list_pics.php?"._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id."&go=".$i."\">$i</a>&nbsp;"; 
    } 
} 

if($page < $total_pages){ 
    $next = ($page + 1); 
    echo "<a href=\"./list_pics.php?"._SQL_TABLE_CATEGORIES."_id=".(int)$galerie_categorii_id."&go=".$next."\">Inainte&gt;&gt;</a>"; 
} 
echo "</center>"; 
//next - prev
@mysql_free_result();
}//function
?>