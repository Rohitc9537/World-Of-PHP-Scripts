<?php
ob_start();
include '../inc/config.db.php';
require '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';
admin_list_category_pictures($galerie_categorii_id=(int)$_GET['galerie_categorii_id']);
ob_end_flush();
?>