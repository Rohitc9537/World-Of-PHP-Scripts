<?php require '../inc/config.inc.php'; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Gallery4All - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
 <p><strong>Gallery4All</strong><br>
   <br>
 [Categories]<br>
 <a href="./add_category.php" target="dreapta">Add category </a><br>
 <a href="./list_categories.php" target="dreapta">List/edit categories </a><br>
 <br>
 [Pictures]<br>
<a href="./add_picture.php" target="dreapta">Add picture</a></p>
 <p><a href="<?php echo _URL_ABSOLUT_SITE; ?>" target="_blank">Preview gallery</a></p>
</body>
</html>
