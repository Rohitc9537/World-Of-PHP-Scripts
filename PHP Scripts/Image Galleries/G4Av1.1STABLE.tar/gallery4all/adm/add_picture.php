<?php
ob_start();
include '../inc/config.db.php';
require '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';

if(isset($_POST['add_picture'])){

//begin post
$galerie_categorii_id=(int)$_POST['galerie_categorii_id'];
$galerie_poze_nume=$_POST['galerie_poze_nume'];
$galerie_poze_descriere=$_POST['galerie_poze_descriere'];
$galerie_poze_file=$_FILES['galerie_poze_file']['name'];
$galerie_poze_file_type=$_FILES['galerie_poze_file']['type'];
$galerie_poze_filesize=$_FILES['galerie_poze_file']['size'];
//end post
					 
//begin verif. empty
if(empty($galerie_categorii_id) ||
   empty($galerie_poze_nume) ||
   empty($galerie_poze_descriere) ||
   empty($galerie_poze_file)){
   echo '<font color=red>';
   if(empty($galerie_categorii_id)){ echo 'Nu ati selectat categoria din care sa faca parte poza.<br>'; }
   if(empty($galerie_poze_nume)){ echo 'Nu ati introdus numele pozei (descriere scurta).<br>'; }
   if(empty($galerie_poze_descriere)){ echo 'Nu ati introdus descrierea pozei.<br>'; }
   if(empty($galerie_poze_file)){ echo 'Nu ati introdus poza.<br>'; }
   echo '</font>';
   admin_add_picture($galerie_categorii_id);
   exit();
   }
//end verif. empty

//BEGIN verificari extensie
$ext=substr($galerie_poze_file, -4);
$ext=strtolower($ext);
$extensii_acceptate=array(".jpg",
							"jpeg",
							".png");
if(!in_array($ext, $extensii_acceptate)){
echo '<font color="red">Extensie poza neacceptata!</font>';
admin_add_picture($galerie_categorii_id);
exit();
}
//END verificari extensie

//begin verificare header poza
$tip_fisier_acceptat = array("image/jpg",
							 "image/jpeg",
							 "image/pjpeg",
							 "image/png");
							 
if(!in_array($galerie_poze_file_type, $tip_fisier_acceptat)){
echo '<font color=red> 
	 The file attached has an unknown extension. <br>
	 Please use the following extensions: .jpg, .jpeg, .png 
	 </font>
	 <br>';
admin_add_picture($galerie_categorii_id);
exit();
	}
//end verificare header poza

//begin modificare nume poza: stiri_categorii_id+nume_poza+data
$galerie_poze_file=str_replace(' ', '_', $galerie_poze_file);
$galerie_poze_file=str_replace('%20', '_', $galerie_poze_file);
$data_poza=date('dmy');
$galerie_poze_file=$galerie_categorii_id.'_'.$data_poza.'_'.$galerie_poze_file;
//end modificare nume poza

//begin upload poza
$director_upload = _DIRECTOR_UPLOAD_MARE;
$fisier_upload = $director_upload . $galerie_poze_file;

if (move_uploaded_file($_FILES['galerie_poze_file']['tmp_name'], $fisier_upload)){
echo '<font color=green>
	  Fac upload la fisier...
	  </font><br>';
sleep(2);
} else {
echo '<font color=red>
	  Nu pot face upload la fisier!
	  </font><br>
	  '.$_FILES['galerie_poze_file']['error'].'';
	  exit();
}
//end upload poza

//begin GD
$source_path = _DIRECTOR_UPLOAD_MARE;
$destination_path = _DIRECTOR_UPLOAD;

//get image dimentions 
      $p_size_array = @getimagesize($source_path.$galerie_poze_file) 
	  								or die('Nu pot prelua dimensiunile imaginii'); 
      $p_width = $p_size_array[0]; 
      $p_height = $p_size_array[1]; 

$new_width=_WIDTH_POZA;  //width imagine

$new_height=$new_width*$p_height/$p_width; //calculam noul width

thumb_jpeg($image_name=$galerie_poze_file); //transformam poza
echo '<font color="#999966">
	  Resizing the picture at '.$new_width.'x'.(int)$new_height.' pixels...
	  </font>
	  <br>';
sleep(2);
//end GD


//begin SQL
$insert_pic=mysql_query("INSERT INTO galerie_poze
						 (galerie_categorii_id,
						  galerie_poze_nume,
						  galerie_poze_descriere,
						  galerie_poze_file,
						  galerie_poze_width,
						  galerie_poze_height,
						  galerie_poze_filesize,
						  galerie_poze_data)
						  VALUES
						  ('".$galerie_categorii_id."',
						   '".addslashes($galerie_poze_nume)."',
						   '".addslashes($galerie_poze_descriere)."',
						   '".$galerie_poze_file."',
						   '".$p_width."',
						   '".$p_height."',
						   '".$galerie_poze_filesize."',
						   NOW())")
						   or die(mysql_error());
	if($insert_pic){
	echo '<br><font color=green><b>The picture has been succesfuly added!</b></font><br>
	<a href="'.$_SERVER['PHP_SELF'].'?galerie_categorii_id='.$galerie_categorii_id.'">Add another picture</a><br>
	<a href="./list_pics.php?galerie_categorii_id='.$galerie_categorii_id.'">Return to the parent category.</font>';
	}
//end SQL

} else {
admin_add_picture($galerie_categorii_id=(int)$_GET['galerie_categorii_id']);
}
?>