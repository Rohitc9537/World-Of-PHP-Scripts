<?php
ob_start();
include '../inc/config.db.php';
include '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';
admin_html_list_galery_categories();
ob_end_flush();
?>