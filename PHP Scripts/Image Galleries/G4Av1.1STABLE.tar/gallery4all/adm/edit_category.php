<?php
ob_start();
include '../inc/config.db.php';
include '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';

if(isset($_POST['edit_category'])){

//begin post
$galerie_categorii_id=(int)$_POST['galerie_categorii_id_hidden'];
$galerie_categorii_nume=$_POST['galerie_categorii_nume'];
$galerie_categorii_descriere=$_POST['galerie_categorii_descriere'];
$galerie_categorii_parent=(int)$_POST['galerie_categorii_id'];
$galerie_categorii_status=(int)$_POST['galerie_categorii_status'];
//end post

//verificari empty
if(empty($galerie_categorii_id) ||
   empty($galerie_categorii_nume) ||
   empty($galerie_categorii_descriere)){
   echo '<font color="red">';
   if(empty($galerie_categorii_id)){ echo '<b>Nu ati selectat categoria pe care doriti sa o editati</b><br>'; }
   if(empty($galerie_categorii_nume)){ echo 'Nu ati introdus numele categoriei.<br>'; }
   if(empty($galerie_categorii_descriere)){ echo 'Nu ati introdus descrierea categoriei.<br>'; }
   echo '</font>';
   admin_edit_category($galerie_categorii_id);
   exit();
   }
//verificari empty

$sql_edit=mysql_query("UPDATE galerie_categorii SET
						  galerie_categorii_parent='".$galerie_categorii_parent."',
						  galerie_categorii_nume='".addslashes($galerie_categorii_nume)."',
						  galerie_categorii_descriere='".addslashes($galerie_categorii_descriere)."',
						  galerie_categorii_status='".$galerie_categorii_status."'
						WHERE galerie_categorii_id='".$galerie_categorii_id."'
						LIMIT 1")
						 or die(mysql_error());
						 
	if($sql_edit){
	echo '<font color="green"> Categoria a fost editata cu succes </font><br>
	<a href="'.$_SERVER['PHP_SELF'].'?galerie_categorii_id='.$galerie_categorii_id.'">Editeaza aceasta categorie</a><br>
	<a href="./list_categories.php">Inapoi la lista cu categorii</a>';
	}

} else {
admin_edit_category($galerie_categorii_id=(int)$_GET['galerie_categorii_id']);
}
ob_end_flush();
?>