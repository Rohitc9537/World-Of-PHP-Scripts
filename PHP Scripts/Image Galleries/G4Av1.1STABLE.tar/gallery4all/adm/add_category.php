<?php
ob_start();
include '../inc/config.db.php';
include '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';

if(isset($_POST['add_category'])){

//begin post
$galerie_categorii_nume=$_POST['galerie_categorii_nume'];
$galerie_categorii_descriere=$_POST['galerie_categorii_descriere'];
$galerie_categorii_parent=(int)$_POST['galerie_categorii_id'];
//end post

//verificari empty
if(empty($galerie_categorii_nume) ||
   empty($galerie_categorii_descriere)){
   echo '<font color="red">';
   if(empty($galerie_categorii_nume)){ echo 'Nu ati introdus numele categoriei.<br>'; }
   if(empty($galerie_categorii_descriere)){ echo 'Nu ati introdus descrierea categoriei.<br>'; }
   echo '</font>';
   admin_add_category();
   exit();
   }
//verificari empty

$sql_insert=mysql_query("INSERT INTO galerie_categorii
						 (galerie_categorii_parent,
						  galerie_categorii_nume,
						  galerie_categorii_descriere)
						 VALUES
						 ('".$galerie_categorii_parent."',
						  '".addslashes($galerie_categorii_nume)."',
						  '".addslashes($galerie_categorii_descriere)."')")
						 or die(mysql_error());
						 
	if($sql_insert){
	echo '<font color="green"> Categoria a fost inserata cu succes </font><br>
	<a href="'.$_SERVER['PHP_SELF'].'">Adauga alta categorie</a><br>
	<a href="./list_categories.php">Inapoi la lista cu categorii</a>';
	}

} else {
admin_add_category();
}
ob_end_flush();
?>