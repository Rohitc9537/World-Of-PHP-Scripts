<?php
ob_start();
include '../inc/config.db.php';
require '../inc/config.inc.php';
include '../inc/functions.inc.php';
include '../inc/functions.html.php';

if(isset($_POST['edit_picture'])){

//begin post
$galerie_poze_id=(int)$_POST['galerie_poze_id']; //hidden
$galerie_categorii_id=(int)$_POST['galerie_categorii_id'];
$galerie_poze_nume=$_POST['galerie_poze_nume'];
$galerie_poze_descriere=$_POST['galerie_poze_descriere'];
$galerie_poze_status=(int)$_POST['galerie_poze_status'];
$galerie_poze_file=$_FILES['galerie_poze_file']['name'];
$galerie_poze_file_type=$_FILES['galerie_poze_file']['type'];
//end post
					 
//begin verif. empty
if(empty($galerie_poze_id) ||
   empty($galerie_categorii_id) ||
   empty($galerie_poze_nume) ||
   empty($galerie_poze_descriere)){
   echo '<font color="red">';
   if(empty($galerie_poze_id)){ echo '<b>Nu ati selectat poza pe care doriti sa o modificati.</b><br>'; }
   if(empty($galerie_categorii_id)){ echo 'Nu ati selectat categoria din care sa faca parte poza.<br>'; }
   if(empty($galerie_poze_nume)){ echo 'Nu ati introdus numele pozei (descriere scurta).<br>'; }
   if(empty($galerie_poze_descriere)){ echo 'Nu ati introdus descrierea pozei.<br>'; }
   echo '</font>';
   admin_edit_picture($galerie_poze_id);
   exit();
   }
//end verif. empty

//begin verificare extensie poza
if(!empty($galerie_poze_file)){
$tip_fisier_acceptat = array("image/jpg",
							 "image/jpeg",
							 "image/pjpeg",
							 "image/png");
							 
if(!in_array($galerie_poze_file_type, $tip_fisier_acceptat)){
echo '<font color="red"> 
	 Fisierul atasat are o extensie nepermisa. <br>
	 Va rugam atasati un fisier din urmatoarele tipuri: .jpg, .jpeg, .png 
	 </font>
	 <br>';
admin_add_picture($galerie_categorii_id);
exit();
	}
//end verificare extensie poza

//begin modificare nume poza: stiri_categorii_id+nume_poza+data
$galerie_poze_file=str_replace(' ', '_', $galerie_poze_file);
$galerie_poze_file=str_replace('%20', '_', $galerie_poze_file);
$data_poza=date('dmy');
$galerie_poze_file=$galerie_categorii_id.'_'.$data_poza.'_'.$galerie_poze_file;
//end modificare nume poza

//begin upload poza
$sql_poza_veche=mysql_query("SELECT galerie_poze_file FROM galerie_poze
							 WHERE galerie_poze_id='".$galerie_poze_id."'
							 LIMIT 1")
							 or die(mysql_error());
$nume_poza_veche=mysql_result($sql_poza_veche, 0);

$director_upload = _DIRECTOR_UPLOAD_MARE;
$director_upload_mic = _DIRECTOR_UPLOAD;
//begin stergem poza veche
@unlink($director_upload.$nume_poza_veche); //sterg poza veche mare
@unlink($director_upload_mic.$nume_poza_veche); //sterg poza veche mica
//end stergem poza veche
$fisier_upload = $director_upload . $galerie_poze_file;

if (@move_uploaded_file($_FILES['galerie_poze_file']['tmp_name'], $fisier_upload)){
echo '<font color=green>
	  Fac upload la fisier...
	  </font><br>';
sleep(2);
} else {
echo '<font color=red>
	  Nu pot face upload la fisier!
	  </font><br>';
}
//end upload poza

//begin GD
$source_path = _DIRECTOR_UPLOAD_MARE;
$destination_path = _DIRECTOR_UPLOAD;

//get image dimentions 
      $p_size_array = @getimagesize($source_path.$galerie_poze_file) 
	  								or die('Nu pot prelua dimensiunile imaginii'); 
      $p_width = $p_size_array[0]; 
      $p_height = $p_size_array[1]; 

$new_width=_WIDTH_POZA;  //width imagine

$new_height=$new_width*$p_height/$p_width; //calculam noul width

thumb_jpeg($image_name=$galerie_poze_file); //transformam poza
echo '<font color="#999966">
	  Modific poza la dimensiuni '.$new_width.'x'.(int)$new_height.' pixeli...
	  </font>
	  <br>';
sleep(2);
//end GD
} else {
$sql_poza_veche=mysql_query("SELECT galerie_poze_file FROM galerie_poze
							 WHERE galerie_poze_id='".$galerie_poze_id."'
							 LIMIT 1")
							 or die(mysql_error());
$galerie_poze_file=mysql_result($sql_poza_veche, 0);
}

//begin SQL
$edit_pic=mysql_query("UPDATE galerie_poze SET
						  galerie_categorii_id='".$galerie_categorii_id."',
						  galerie_poze_nume='".addslashes($galerie_poze_nume)."',
						  galerie_poze_descriere='".addslashes($galerie_poze_descriere)."',
						  galerie_poze_file='".$galerie_poze_file."',
						  galerie_poze_status='".$galerie_poze_status."'
					   WHERE galerie_poze_id='".$galerie_poze_id."'
					   LIMIT 1")
						   or die(mysql_error());
	if($edit_pic){
	echo '<br><font color=green><b>Poza a fost editata cu succes!</b></font><br>
	<a href="'.$_SERVER['PHP_SELF'].'?galerie_poze_id='.$galerie_poze_id.'">Editati acesta poza</a><br>
	<a href="#">Intoarcere la categoria parinte.</font>';
	}
//end SQL

} else {
admin_edit_picture($galerie_poze_id=(int)$_GET['galerie_poze_id']);
}
?>