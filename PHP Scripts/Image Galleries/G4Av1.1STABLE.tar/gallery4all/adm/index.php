<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Administrare - Galerie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset cols="180,*" framespacing="0" frameborder="yes" border="0" bordercolor="#eeeeee">
  <frame src="index_stanga.php" name="stanga" scrolling="NO" noresize>
  <frame src="index_dreapta.php" name="dreapta">
</frameset>
<noframes>
<body>
Browserul dumneavoastra nu suport frame-uri.
</body>
</noframes>
</html>
