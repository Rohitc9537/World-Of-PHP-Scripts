# --------------------------------------------------------

#
# Table structure for table `galerie_categorii`
#

DROP TABLE IF EXISTS `galerie_categorii`;
CREATE TABLE `galerie_categorii` (
  `galerie_categorii_id` int(10) unsigned NOT NULL auto_increment,
  `galerie_categorii_parent` int(10) unsigned NOT NULL default '0',
  `galerie_categorii_nume` varchar(255) NOT NULL default '',
  `galerie_categorii_descriere` text NOT NULL,
  `galerie_categorii_status` enum('0','1') NOT NULL default '1',
  KEY `galerie_categorii_id` (`galerie_categorii_id`)
) TYPE=MyISAM ;

# --------------------------------------------------------

#
# Table structure for table `galerie_poze`
#

DROP TABLE IF EXISTS `galerie_poze`;
CREATE TABLE `galerie_poze` (
  `galerie_poze_id` int(10) unsigned NOT NULL auto_increment,
  `galerie_categorii_id` int(10) unsigned NOT NULL default '0',
  `galerie_poze_nume` varchar(255) NOT NULL default '',
  `galerie_poze_descriere` text NOT NULL,
  `galerie_poze_file` varchar(64) NOT NULL default '',
  `galerie_poze_width` int(10) unsigned NOT NULL default '0',
  `galerie_poze_height` int(10) unsigned NOT NULL default '0',
  `galerie_poze_filesize` varchar(10) NOT NULL default '',
  `galerie_poze_keywords` varchar(255) NOT NULL default '',
  `galerie_poze_hits` bigint(20) unsigned NOT NULL default '0',
  `galerie_poze_data` datetime NOT NULL default '0000-00-00 00:00:00',
  `galerie_poze_status` enum('0','1') NOT NULL default '1',
  KEY `galerie_poze_id` (`galerie_poze_id`)
) TYPE=MyISAM ;
