<?php
// this file is provided as an example. It does not modify the configuration
// as long as it remains in "tools" directory. Move it to "include"
// directory if you want to modify default configuration.

$conf['prefix_thumbnail'] = 'thumb_';
$conf['show_gt'] = true;
?>