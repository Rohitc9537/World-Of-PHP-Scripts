<?
include_once("core/core.php");
$config = new Config('config.ini.php');
$config->show_setup();
?>
