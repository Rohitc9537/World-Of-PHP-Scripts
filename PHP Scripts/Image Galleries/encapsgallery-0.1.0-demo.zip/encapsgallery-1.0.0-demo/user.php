<?include("common_head.php");?>
<center>
<!--a href="index.php">Back to forum</a-->
<?
$user->show();
?>
</center>
<?//include("index_footer.php");?>
