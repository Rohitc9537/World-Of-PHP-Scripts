<?
//include("common_head.php");
include("gallery_head.php");
$gallery->show();
include("common_foot.php");
?>