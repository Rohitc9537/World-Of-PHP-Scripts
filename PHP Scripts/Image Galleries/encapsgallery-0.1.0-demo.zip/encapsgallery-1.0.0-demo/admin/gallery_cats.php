<?
include("gallery_head.php");
//$cats->show_select();
$cats->show();
include("common_foot.php");
?>

