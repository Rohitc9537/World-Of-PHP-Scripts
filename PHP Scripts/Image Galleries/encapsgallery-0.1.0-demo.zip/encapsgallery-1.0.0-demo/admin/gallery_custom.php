<?
include("gallery_head.php");
//$cats->show_select();
$gallery->show("admin");
include("common_foot.php");
?>
