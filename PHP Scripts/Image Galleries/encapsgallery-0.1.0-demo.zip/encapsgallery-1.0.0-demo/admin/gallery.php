<?
include("gallery_head.php");
$gallery->show("admin");
include("common_foot.php");
?>

