<html>
<head>
<title>Admin</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<META content=0 http-equiv=Expires>
  <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <meta HTTP-EQUIV="Cache-Control" content="no-cache">
<link href="html/admin.css" type="text/css" rel="stylesheet">
</head>
<html>
<body >

<div align="center">
