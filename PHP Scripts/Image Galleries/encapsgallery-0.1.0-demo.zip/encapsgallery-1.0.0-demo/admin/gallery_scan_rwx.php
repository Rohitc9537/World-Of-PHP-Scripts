<?
include("gallery_head.php");
$gallery->check_updates();
//$gallery->show("admin");
include("common_foot.php");
?>

