<?
$config["theme"] = '';
//$config["pager_items_per_page"] = "4";
?>
