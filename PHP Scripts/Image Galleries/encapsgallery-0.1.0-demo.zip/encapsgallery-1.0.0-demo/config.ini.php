<?php
$config["db_host"] = "localhost";
$config["db_name"] = "test";
$config["db_user"] = "root";
$config["db_pass"] = "";
$config["db_type"] = "mysql";
$config["theme"] = "acd";
$config["pager_items_per_page"] = "10";
$config["sort"] = "new";
$config["upl_def_cat"] = "1";
$config["action"] = "config_update";
?>