<?php include("random.php"); ?>

<?php echo "<img src=\"$image_folder/$image_name\" alt=\"$image_name\" />";?>

<?php include ("$image_folder/$text_name");?>