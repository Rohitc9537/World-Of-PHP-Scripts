<?php
	// Make arrays that hold the options for the form fields (like a STATE drop-down list, or YES/NO, etc)	
	$aDay[0] = "1";
	$aDay[1] = "2";
	$aDay[2] = "3";
	$aDay[3] = "4";
	$aDay[4] = "5";
	$aDay[5] = "6";
	$aDay[6] = "7";
	$aDay[7] = "8";
	$aDay[8] = "9";
	$aDay[9] = "10";
	$aDay[10] = "11";
	$aDay[11] = "12";
	$aDay[12] = "13";
	$aDay[13] = "14";
	$aDay[14] = "15";
	$aDay[15] = "16";
	$aDay[16] = "17";
	$aDay[17] = "18";
	$aDay[18] = "19";
	$aDay[19] = "20";
	$aDay[20] = "21";
	$aDay[21] = "22";
	$aDay[22] = "23";
	$aDay[23] = "24";
	$aDay[24] = "25";
	$aDay[25] = "26";
	$aDay[26] = "27";
	$aDay[27] = "28";
	$aDay[28] = "29";
	$aDay[29] = "30";
	$aDay[30] = "31";
	
	$aMonth[0] = "January";
	$aMonth[1] = "February";
	$aMonth[2] = "March";
	$aMonth[3] = "April";
	$aMonth[4] = "May";
	$aMonth[5] = "June";
	$aMonth[6] = "July";
	$aMonth[7] = "August";
	$aMonth[8] = "September";
	$aMonth[9] = "October";
	$aMonth[10] = "November";
	$aMonth[11] = "December";
?>