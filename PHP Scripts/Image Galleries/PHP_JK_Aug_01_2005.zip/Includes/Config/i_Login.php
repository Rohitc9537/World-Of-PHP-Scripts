<?php 

	//************************************************************************************
	// This include goes in the /PHPJK/UserArea/Login.php page
	//************************************************************************************
	
	// Login/Password request email
	// 		the 1: is replaced with the users login
	//		the 2: is replaced with the users password
	//		the \n should appear as a line break in the email
	$CONF_LPemail = "Your login and password have been found!\n\n";
	$CONF_LPemail .= "Login: 1:\nPassword: 2:";
?>