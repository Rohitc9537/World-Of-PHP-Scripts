<table cellpadding=0 cellspacing=0 border=0 width=<?=$iTableWidth?>>
	<tr>
		<td bgcolor=<?=$BorderColor2?>><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=3></td>
		<td colspan=6 bgcolor=<?=$BGColor2?> width=23><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=23 Height=2></td>
		<td bgcolor=<?=$BorderColor2?>><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=3></td>
	</tr>
	<tr>
		<td bgcolor=<?=$BorderColor2?> width=1><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=2></td>
		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/ManageAccounts/' class='MediumNav2'>Manage&nbsp;Accounts</a>]</td>

		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/ADV/' class='MediumNav2'>Manage&nbsp;ADVs</a>]</td>

		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/InitialRights/' class='MediumNav2'>Initial&nbsp;Rights</a>]</td>

		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/Configurations/' class='MediumNav2'>Configurations</a>]</td>
		
		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/SiteContent/' class='MediumNav2'>Site Content</a>]</td>

		<td align=center bgcolor=<?=$BGColor2?>>[<a href='<?=$sSiteURL?>/Admin/ManageGalleries/' class='MediumNav2'>Gallery Admin -&gt;</a>]</td>
		<td bgcolor=<?=$BorderColor2?> width=1><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=2></td>
	</tr>
	<tr>
		<td bgcolor=<?=$BorderColor2?>><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=3></td>
		<td colspan=6 bgcolor=<?=$BGColor2?> width=23><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=23 Height=2></td>
		<td bgcolor=<?=$BorderColor2?>><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=3></td>
	</tr>
	<tr>
		<td bgcolor=<?=$BorderColor2?> width=1><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=1></td>
		<td colspan=6 bgcolor=<?=$BorderColor2?>><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=2 Height=1></td>
		<td bgcolor=<?=$BorderColor2?> width=1><img src='<?=$sSiteURL?>/Images/Blank.gif' Width=1 Height=1></td>
	</tr>
</table>