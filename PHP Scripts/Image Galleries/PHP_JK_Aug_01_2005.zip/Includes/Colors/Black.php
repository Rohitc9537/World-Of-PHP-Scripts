<?php
	$PageText = "FFFFFF";
	$PageBGColor = "000000";
	$PageBorder = "444444";
	$PageLinkColor = "FFFFFF";
	$PageALinkColor = "AAFFAA";
	$PageVLinkColor = "AAAAFF";
	
	$TextColor1 = "FFFFFF";
	$BGColor1 = "111111";
	$BorderColor1 = "444444";
	$LinkColor1 = "FFFFFF";
	$ALinkColor1 = "AAFFAA";
	$VLinkColor1 = "AAAAFF";
	
	$TextColor2 = "FFFFFF";
	$BGColor2 = "222222";
	$BorderColor2 = "FFFFFF";
	$LinkColor2 = "FFFFFF";
	$ALinkColor2 = "AAFFAA";
	$VLinkColor2 = "AAAAFF";
	
	$TextColor3 = "FFFFFF";
	$BGColor3 = "333333";
	$BorderColor3 = "FFFFFF";
	$LinkColor3 = "FFFFFF";
	$ALinkColor3 = "AAFFAA";
	$VLinkColor3 = "AAAAFF";

	$ErrorColor = "FFAAAA";
	$SuccessColor = "AAAAFF";
?>