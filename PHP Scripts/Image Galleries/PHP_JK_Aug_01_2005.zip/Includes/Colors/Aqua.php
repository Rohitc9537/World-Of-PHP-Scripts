<?php
	$PageText = "000000";
	$PageBGColor = "FFFFFF";
	$PageBorder = "008D88";
	$PageLinkColor = "005552";
	$PageALinkColor = "005552";
	$PageVLinkColor = "005552";
	
	$TextColor1 = "000000";
	$BGColor1 = "DBEDEC";
	$BorderColor1 = "008D88";
	$LinkColor1 = "005552";
	$ALinkColor1 = "005552";
	$VLinkColor1 = "005552";
	
	$TextColor2 = "000000";
	$BGColor2 = "95CCCA";
	$BorderColor2 = "005552";
	$LinkColor2 = "005552";
	$ALinkColor2 = "005552";
	$VLinkColor2 = "005552";
	
	$TextColor3 = "000000";
	$BGColor3 = "42908D";
	$BorderColor3 = "005552";
	$LinkColor3 = "0A2E2D";
	$ALinkColor3 = "0A2E2D";
	$VLinkColor3 = "0A2E2D";
	
	$ErrorColor = "FF6666";
	$SuccessColor = "004544";
?>