<?php
	$PageText = "000000";
	$PageBGColor = "FFFFFF";
	$PageBorder = "CCCCCC";
	$PageLinkColor = "884488";
	$PageALinkColor = "448844";
	$PageVLinkColor = "444488";
	
	$TextColor1 = "000000";
	$BGColor1 = "F5F5F5";
	$BorderColor1 = "CCCCCC";
	$LinkColor1 = "884488";
	$ALinkColor1 = "448844";
	$VLinkColor1 = "444488";
	
	$TextColor2 = "000000";
	$BGColor2 = "EEEEEE";
	$BorderColor2 = "000000";
	$LinkColor2 = "884488";
	$ALinkColor2 = "448844";
	$VLinkColor2 = "444488";
	
	$TextColor3 = "000000";
	$BGColor3 = "DDDDDD";
	$BorderColor3 = "000000";
	$LinkColor3 = "884488";
	$ALinkColor3 = "448844";
	$VLinkColor3 = "444488";
	
	$ErrorColor = "FF6666";
	$SuccessColor = "444488";
?>