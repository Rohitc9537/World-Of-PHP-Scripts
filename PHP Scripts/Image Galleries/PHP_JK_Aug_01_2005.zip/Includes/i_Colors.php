<?
	switch ($iColorScheme) {
		case 1:
			require("Colors/Black.php");
			break;
		case 2:
			require("Colors/White.php");
			break;
		case 3:
			require("Colors/Aqua.php");
			break;
		case 4:
			require("Colors/Flat_Black.php");
			break;
		case 5:
			require("Colors/Flat_White.php");
			break;
		case 6:
			require("Colors/Flat_Aqua.php");
			break;
		/* add new color scheme entries here */
	}

?>