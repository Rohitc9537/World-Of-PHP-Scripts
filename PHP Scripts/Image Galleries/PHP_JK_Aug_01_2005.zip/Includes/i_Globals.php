<?php
	// CHANGE NONE OF THESE VARIABLES
	$PHPJK_VERSION			= 1.00;
	
	$NONMEMBER_ID			= -1;

	$sPageTitle				= "";
	$sStyle					= "";
	$sHeader				= "";
	$iDomainName			= 1;
	
	$iLoginAccountUnq		= 0;
	$bHasAccount			= False;
	
	$iTextScheme			= 1;
	$aVariables				= array(0=>"",1=>"",2=>"",3=>"",4=>"",5=>"",6=>"",7=>"",8=>"",9=>"",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"");
	$aValues				= array(0=>"",1=>"",2=>"",3=>"",4=>"",5=>"",6=>"",7=>"",8=>"",9=>"",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"");
	$iTableWidth			= "671";
	$bHasADVRights			= False;	// this is set to TRUE when the user has rights to the ADV after calling ACCNT_ReturnADV, FALSE otherwise
	
	$PHPJKConnection		= 0;
	
	$iTtlNumItems			= 0;
	$iDBLoc					= 0;
	$iNumPerPage			= 10;
	
	$PUBLIC_GALLERIES	= 1;
	$PRIVATE_GALLERIES	= 2;
	
	// these two tell which thumbnail conversion component to use
	$ASPIMAGE			= 1;
	$GFL				= 2;
	
	$COLORBASED			= 1;
	$SCHEMEBASED		= 2;
	$ADMINISTRATIVE		= 3;
?>