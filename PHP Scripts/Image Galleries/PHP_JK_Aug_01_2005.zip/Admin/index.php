<?php
	Require("../Includes/i_Includes.php");
	Require("../Includes/Nav/PHP_JK_ADMIN_OPEN.php");
	Require("../Includes/Nav/PHP_JK_ADMIN_DEFAULT.php");
	Require("../Includes/Nav/PHP_JK_ADMIN_CLOSE.php");
?>