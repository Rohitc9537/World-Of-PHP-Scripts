PHP JackKnife
Full Featured PHP Image Gallery for MSSQL & MySQL
=================================================

This software is copyrighted 2004 - 2005 and licensed.

For the most complete and up to date feature list, 
FAQ, installation instructions, support forum and 
more, please visit the PHP JackKnife website at 
http://www.phpjk.com/

To use your gallery images to make money, signup 
at www.aricaur.com!

--Dean Higginbotham

=================================================
Quick Install
=================================================
1. Unzip these files into the /phpjk/ directory
	retaining the directory structure.
2. Create a database in either MYSQL or MSSQL
	for JackKnife. Create an associated database
	user and make that user the owner or admin
	of your JackKnife database
3. Run the install script by going to your
	site in a browser and following the instructions.
	The install script will be at:
	www.[your url].com/phpjk/PHPJK_Installation/
4. Change the emails sent from the system by
	editing the files within the 
	/includes/Config/ folder.
	
If you find bugs or have problems, please email
me at: dean.higginbotham@phpjk.com