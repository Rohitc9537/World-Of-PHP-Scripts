<?php
	//************************************************************************************
	//*																					*
	//*	Opening HTML.																	*
	//*																					*
	//************************************************************************************
	Function OpenPage()
	{
		?>
		<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>
		<HTML>
		<HEAD>
			<TITLE>PHPJK Installation</TITLE>
			<http-equiv='pragma' content='NO-CACHE'>
		</HEAD>
		<BODY BGCOLOR='#FFFFFF' TEXT='#000000' TOPMARGIN=10 LEFTMARGIN=10 MARGINWIDTH=0 MARGINHEIGHT=0>
			<center>
			<table width=100% border=0 cellpadding=0 cellspacing=0>
				<tr>
					<td valign=bottom>
						<a href='http://www.phpjk.com/' target='_blank'><img src = 'Images/Navigation/PHPJKLogo.gif' alt = 'PHPJK Installation' border=0></a>
					</td>
				</tr>
			</table>
			<table width=100% border=0 cellpadding=0 cellspacing=0>
				<tr>
					<td width=35><img src = 'Images/Navigation/Border_Top_Left.gif' width = 35 height = 36 border=0></td>
					<td background='Images/Navigation/Border_Top_Middle.gif' width=100%><img src = 'Images/Navigation/Blank.gif' width=2 height=36></td>
					<td width=37><img src = 'Images/Navigation/Border_Top_Right.gif' width = 37 height = 36 border=0></td>
				</tr>
			</table>
			<table width=100% border=0 cellpadding=0 cellspacing=0>
				<tr>
					<td width=35 background='Images/Navigation/Border_Left_Middle.gif'><img src = 'Images/Navigation/Blank.gif' width=35 height=36></td>
					<td valign=top width=100%>
		<?php 
	}
	//************************************************************************************


	//************************************************************************************
	//*																					*
	//*	Opening HTML.																	*
	//*																					*
	//************************************************************************************
	Function ClosePage()
	{
		?>
						</td>
						<td width=37 background='Images/Navigation/Border_Right_Middle.gif'><img src = 'Images/Navigation/Blank.gif' width=37 height=36></td>
					</tr>
				</table>
				<table width=100% border=0 cellpadding=0 cellspacing=0>
					<tr>
						<td width=35><img src = 'Images/Navigation/Border_Bottom_Left.gif' width = 35 height = 36 border=0></td>
						<td background='Images/Navigation/Border_Bottom_Middle.gif' width=100%><img src = 'Images/Navigation/Blank.gif' width=2 height=36></td>
						<td width=37><img src = 'Images/Navigation/Border_Bottom_Right.gif' width = 37 height = 36 border=0></td>
					</tr>
				</table>
			</td></tr></table>
			</center>
		</BODY></HTML>
		<?php 
	}
	//************************************************************************************
?>