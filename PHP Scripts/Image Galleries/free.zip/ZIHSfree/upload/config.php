<?php # config.php 

// Iron Muskie, Inc
// Michael J. Muff
// customer_service@iron-muskie-inc.com
// Version 1.0918
// September 2005

//**********************************************************************************************

//***Database Information***

//Database User
$DBUser='zihs_imagehost';

//Database Password
$DBPass='developer';

//Database Host
$DBHost='localhost';

//Database Name
$DBName='zihs_imagehost';

//**********************************************************************************************
?>
