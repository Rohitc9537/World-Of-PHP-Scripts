<?php # settings.php 

// Iron Muskie, Inc
// Michael J. Muff
// customer_service@iron-muskie-inc.com
// Version 1.0918
// September 2005

//**********************************************************************************************

//***Site Title***

//Page Title
$site_title='ZIHS IMAGE HOSTING';

//***Site Description***

//Page Title
$page_description='Description goes here!';

//**********************************************************************************************

//**********************************************************************************************

//***Site Title***

//Page Title
$max_file_size=524288;

//**********************************************************************************************

?>
