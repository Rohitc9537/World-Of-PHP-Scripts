<?php /* Smarty version 2.6.10, created on 2005-09-17 19:36:12
         compiled from footer.tpl */ ?>
</BODY>
</HTML>