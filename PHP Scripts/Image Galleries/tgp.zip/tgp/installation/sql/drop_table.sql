# phpMyAdmin MySQL-Dump
# version 2.5.1
# http://www.phpmyadmin.net/ (download page)
#
# --------------------------------------------------------

DROP TABLE IF EXISTS fm_tgpads;
DROP TABLE IF EXISTS fm_tgpblind;
DROP TABLE IF EXISTS fm_tgpcategories;
DROP TABLE IF EXISTS fm_tgpdead;
DROP TABLE IF EXISTS fm_tgpdeclines;
DROP TABLE IF EXISTS fm_tgpdomain;
DROP TABLE IF EXISTS fm_tgpfilter;
DROP TABLE IF EXISTS fm_tgpgalleries;
DROP TABLE IF EXISTS fm_tgpip;
DROP TABLE IF EXISTS fm_tgpoptions;
DROP TABLE IF EXISTS fm_tgppartners;
DROP TABLE IF EXISTS fm_tgppolice;
DROP TABLE IF EXISTS fm_tgppposts;
DROP TABLE IF EXISTS fm_tgptemps;



