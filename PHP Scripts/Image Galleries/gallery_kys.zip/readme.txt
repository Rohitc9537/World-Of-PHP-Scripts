
####################################################
Kys Gallery Version 1.0 (beta version) Copyright� 31/07/2003 Kyscorp.tk :::Dark Tranquility
####################################################

==================================================================================
TOS
==================================================================================
* This is a free script, to use it you have to accept the following:
- you may not remove any links to our site in it.
- you may change the layout, the colours and fonts to suit your site.
- you may redistribute it as  is without removing anything (including this readme file) or changing anything.
- you may not sell this script.
- because the program is licensed free of charge, there is no warranty for the program.
- if you appreciate this script make a  donation through Paypal.com to kouanes@planet.tn
- thanks and enjoy
==================================================================================

English:
____________________________________________________________________
--> How To Install? How to use ?

* Unzip & Upload the whole content (except Readme.txt) to a new directory on your server for instance 'gallery'.
* Edit config.inc to set your own password.
* CHMOD the folder 'gallery' and all the other folders contained in it to 755 or 777 (if it does not work).
* Login to admin.php ( with the password you chose in config.inc).
* Click on 'click here' under 'Upload New Picture' to start uploading your images and thumbnails.
* Follow the instructions.

More Support ?
____________________________________________________________________

Go to the forums: http://www.kyscorp.neoartists.net/board/index.php



####################################################
Contact us: kouanes@planet.tn or through the website http://www.kyscorp.tk
Support forums: http://www.kyscorp.neoartists.net/board/index.php
Script Written with: Scriptomania visit: http://www.scriptomania.tk
####################################################
