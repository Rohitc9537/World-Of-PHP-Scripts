<html>

<head>
<title>KyS Gallery 1.0 .:.powered by kyscorp.tk.:.</title>
<style fprolloverstyle>A:hover {color: #003366; text-decoration: none}
</style>
</head>

<body link="#0099CC" vlink="#0099CC" alink="#0099CC" text="#CECECE" bgcolor="#000000">

<p align="center">
<img border="0" src="kys_gal_header.gif" style="border: 1px dotted #CECECE" width="800" height="100"></p>

<p align="center"><style>
BODY { scrollbar-face-color: "#000000"; scrollbar-arrow-color: "#000000"; scrollbar-track-color: "#000000"; scrollbar-3dlight-color:"#333333"; scrollbar-darkshadow-color: "#333333"; }
</style>

<iframe width="800" height="100" src="thumbnails.php" name="thm" border="0" frameborder="0"> </iframe>
<iframe width="800" height="420" src="preview.php" name="pre" border="0" frameborder="0"></iframe>
</p>

<p align="center"><font face="verdana" size="1"><a href="admin.php">
<img border="0" src="admin.gif" align="right" width="48" height="20"></a><br>
Powered by <a href="http://www.kyscorp.tk">Kyscorp.tk</a> � 2000-2003<a href="http://www.kyscorp.tk"> 
Kys Gallery 1.0</a></font></p>

</body>

</html>