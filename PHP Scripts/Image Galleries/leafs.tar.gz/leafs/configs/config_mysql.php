<?
define ("database_name","");             /* database name*/
define ("user","");                     /* your user name to access database */
define ("password","");                /* your password to access database */


define("TABLE_LOGIN","album_login");               /* table login for user autenthification -don't needed default.read more in readme.txt*/  
define("TABLE_AUTOINC","album_autoinc");           /* auto inc id's needed for advanced authentification*/

define("TABLE_IMG","album_images");                /* table where are kept information about images*/
define("TABLE_CATEGORY","album_categories");       /* catgoryies for images*/
define("TABLE_KEYWORDS","album_keywords");         /* keywords to describe summary a set of images */




?>