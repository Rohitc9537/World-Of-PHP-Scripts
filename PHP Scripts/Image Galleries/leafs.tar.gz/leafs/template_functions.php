<? 

function doHead(){


	GLOBAL $currentFile;	          
   
	$infos=getInfo($currentFile.".html");	
	
	if(!isset($infos))
		$infos=getInfo($currentFile);	//normal page
	if(!isset($infos))
		$infos=getInfo("default");	//defaul page
		
	//read from lnk file, a set of informations
	$name=$infos['title'];
	echo '
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd"> 
		<html >
		<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<meta name="keywords" content="'.$infos['keywords'].'" />
		<meta name="description" content="'.$infos['description'].'" />
		<meta name="robots" content="all" />
		<title>'.$name.'</title>

		<base href="'.HTTP.'"/>
		<script type="text/javascript"></script>
	
		<style type="text/css" title="currentStyle" media="screen">
			@import "'.HTTP.'style.css";
		</style>
		
		<script type="text/javascript" src="js/cheks.js"></script>
		
		</head>';
	
}

function docontainer(){
 echo "<h3></h3>";
}

function dointro(){
 echo "<h3></h3>";
}

function dopageHeader(){
 echo "<h1><span></span></h1>
			<h2><span></span></h2>";
}

function doquickSummary(){

	GLOBAL $message;
	
	if(file_exists('htmls/categories.html')){
	
	    echo '<ul>';
		echo "<b>".$message['Categories']."</b><br>";

		include('htmls/categories.html');
	    echo ('</ul>');
	}

	//want to display links bloc
	if(LINKS==true && file_exists('blocs/links.html')){
    	    echo '<ul>';
	    echo "<b>".$message['Links']."</b>:<br>";
	
		include('modules/links.php');

	    echo '</ul>';
	}
	
}

function dopreamble(){
 
 GLOBAL $currentFile;

 //article
 $infos=getInfo($currentFile.".html"); 


 #include page 
 
 if(file_exists("pages/pg_$currentFile.php")){
         
    
	include("pages/pg_$currentFile.php");
	
 }
 
 else{
 
 	if(file_exists($infos['link'])){
		
		//you can include here an advertiser
		
	    	include($infos['link']);
		
		
	}else	//a kind of 404 error
 		echo "<center><font color='red' size='2'>page not found!</font><center>";
	}
	
 #end include page	
 echo '<br><Br>';
 
 
}

function doexplanation(){
 
}

function doparticipation(){

}

function dobenefits(){

}

function dorequirements(){

}

function dofooter(){
 
 GLOBAL $message;
 
 echo "<h3>".$message['message bottom']."</h3>";
 }
 
 
function dolinkList(){
 echo "<h3></h3>";
}

function dolinkList2(){
 echo "<h3></h3>";
}

function dolselect(){

	global $message;
	echo "<h3>".$message['login area']."</h3>";
	include("modules/user_login.php");

}



function dolarchives(){

	global $message;
	echo "<h3>".$message['Options']."</h3>";
	include("modules/menu_left.php");
 
}

function dolarc(){
 echo "<h3>larc</h3>";
}

//home link
function dolresources(){
 echo "<ul><li><a href='index.php'><b>Home</b></a></li></ul>";
}

function doextraDiv1(){
 echo "<h3></h3>";
}

?>