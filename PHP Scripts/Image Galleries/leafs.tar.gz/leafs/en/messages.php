<?


$message['Links']='Links';
$message['message bottom']="Online album";
$message['main']="<h1>Welcome</h1>Describe here in a few words, your site..";
$message['upload image']="Upload image";
$message['create category']="Create/Edit categories";
$message['login']="Login";
$message['logout']="Logout";
$message['profile']="Profile";
$message['Categories']="Categories";
$message['change pass']="Change pass";
$message['Options']="Options";
$message['login area']="Login area";

$message['Pictures categ']="Pictures categories";
$message['Note message']="Category will not appear until an administrator validate it!";
$message['No pictures found!']="No photos in this category";
$message['error login']="You don't have the permission to access this page.";

//leave it blank if not necesary

$message['main page privacy']="<br><br><font color='red'>Note</font>:<font color='#C0C0C0'>Privacy notes here, if you want to</a>";
$message['Pictures with']="Pictures:";
$message['Go to page']="Go to page";
$message['Category']="Category";
$message['Image']="Image";
$message['Upload image']="Upload image";
$message['Keywords']="keywords <font color='#C0C0C0'>(separated with space or ,)</font>";
$message['Description']="Short description";
$message['Required']="*Note:Required fields";

//for upload

$message['Validate note']="Image will appear on the site after an administrator  validate it";
$message['Note']="Note:";
$message['bad keyword']="Please complete the required fields.Don\'t use obscene words!";
$message['bad image']="Accepted images are gif and jpg,and size: ".@allowed_width."x".@allowed_height." pixels";
$message['Upload succes']="Image succesfuly uploaded.Thank you!<br><a href='index.php'>Main page</a>";

$message['Main page message']="Your main message here.Describe site in a few words...";

?>