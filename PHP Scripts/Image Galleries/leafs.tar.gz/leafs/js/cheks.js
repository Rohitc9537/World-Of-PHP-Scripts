function checkUncheckAll(theElement,name) {

      var theForm = document.frm, z = 0;
       while (theForm[z].type!=''){
		if(theForm[z].type == 'checkbox' && theForm[z].name != 'checkall' && theForm[z].name != name) {

	       theForm[z].checked = theElement.checked;
		}
       	z++;
	     }
}
	
