<?


class MySql{

	var $database_name;
	var $user;
	var $password;
	var $handle;

	
	function MySql($database_name,$user,$password){
		
		$this->database_name=$database_name;
		$this->user=$user;
		$this->password=$password;
	}
	
	
	function Connect(){
		$this->handle = mysql_connect("localhost", $this->user,$this->password) or die(mysql_error());
		@mysql_select_db($this->database_name,$this->handle);
			
		return $this->handle;
		
	}
	
	function Query($sql){
	
		$result = @mysql_query($sql,$this->handle);	
		return $result;
	}
	
	function Close(){
		@mysql_close($this->handle);
	}
}

?>
