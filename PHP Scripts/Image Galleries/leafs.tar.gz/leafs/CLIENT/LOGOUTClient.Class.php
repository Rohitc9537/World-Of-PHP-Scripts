<?
 

require_once('nusoap.php');
require_once('../configs/settings.php');

class CLOGOUTClient{

	var $client;        //obiect soap-client
		
	function Connect($address){
	
		$this->client = new soapclient($address);
		
	}
	
	function Close(){
		unset($this->client);		
	}

	
	function SendLogout($user){
	
		$param = array("user"=>$user);
		               			
		$namespace="urn:xmethods-BNSendLogout";
	
		$result = $this->client->call('SendLogout',$param,$namespace);
		
						
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else							
				return $result;
	
		
	}
}

?>			