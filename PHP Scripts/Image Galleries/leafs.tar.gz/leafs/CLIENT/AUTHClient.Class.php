<?
/*********************************************
  Axiologic CLIENT SERVER
  ********************************************
  Copyright  2004 - 2005 by Axiologic Team
  http://www.axiologic.com

  $Version: 1.0
  $Date: 2005/07/1 
**********************************************/

require_once('nusoap.php');
require_once('../configs/config_mysql.php');
require_once('../configs/settings.php');
require_once('../Class/MySql.Class.php');


#
#Obiect Token 
#
class CToken{
	var $RO;                          
	var $http;                        
	var $id;                          
	var $day;                 
	var $md5;                 
	
	function CToken($id,$day){	
		    
		$this->id=$id;
		$this->day=$day;
		$this->http=base64_encode(HTTTP);
		$this->RO=$this->randomstring(32);
		$this->Calculate_md5();
			
	}
	function set($RO,$md5){	
		    		
		$this->RO=$RO;
		$this->md5=$md5;
			
	}
	function Calculate_md5(){
		$this->md5=md5($this->RO.base64_encode(HTTTP).($this->id).$this->day.TCS);
	}
	
	
	function ReturnAll(){
		return $this->RO.$this->http.$this->id.$this->day.$this->md5;
	}
	
	function randomstring($length) {
		$random = rand(1,20000);
   
		$string = md5($random);
   
		$output = substr($string,0,$length);

		return $output;
	}
	
	
}

class CAUTHClient{

	var $client;        //obiect soap-client
	var $objToken;      
	var $objTS;         
	
	function Generate_ID(){
	
		$db=new MySql(database_name,user,password);
		$db->Connect(); 

		$sql="select id,valid_date from ".TABLE_AUTOINC."";
		$result=$db->Query($sql);
	
		$r=mysql_fetch_array($result);	
		$id=$r["id"];
		$date=$r["valid_date"];
		
		$curr_date=date("Y-m-d");		
		$date_mysql=date("Y-m-d H:i");		
		
		
		if(empty($date)){
			
			$sql="insert into ".TABLE_AUTOINC." values('0','$date_mysql')";
			$result=$db->Query($sql);
			$id=0;
			
		}else{		
		
			if($curr_date>$date)
				$id=0;			
				
			else		
				$id++;
				
		
			$sql="update ".TABLE_AUTOINC." set id='$id'";
			$result=$db->Query($sql);
			
			$sql="update ".TABLE_AUTOINC." set valid_date='$curr_date'";
			$result=$db->Query($sql);
		}
		
		$day=date("d");
	
		$db->Close();
					
		return array("id"=>$id,"day" =>$day);		
		
		
	}
		
	function Verify(){
	
		
		$param = array("RO" => $this->objToken->RO,"http"=>$this->objToken->http,"id"=>$this->objToken->id,"day"=>$this->objToken->day,"md5"=>$this->objToken->md5);		
			
		
		$namespace="urn:xmethods-BNVerify";
	
	
		
		$result = $this->client->call('Verify',$param,$namespace);
					
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else {
				#
				#TC accepted
				#													
				
				return $this->Verify_TS($result["RO"],base64_decode($result["http"]),$result["id"],$result["day"],$result["md5"]);
				
				}
				
		
	}
	
	
	function CAUTHClient(){
	
		$result=$this->Generate_ID();		
		
		$this->objToken=new CToken($result["id"],$result["day"]);
		// call server
		$this->client = new soapclient(SERVER);
		
	}
	
	
	function Close(){
		unset($this->client);		
	}

	
	function Verify_TS($RO,$http,$id,$day,$md5){
	
		
		$this->TS=new CToken($id,$day);
		$this->TS->set($RO,$md5);		
		
		
		
		if($this->objToken->id<$id || $day!=$this->objToken->day || strcmp($http,HTTTP)!=0)
		return false;
				
		$md5_Client=md5($RO.base64_encode(HTTTP).$id.$day.TCS);
		
		if(strcmp($md5_Client,$md5)==0)	{		
			return true;						
			}
			else 		
				return false;				
					
	}
	
	function getField($id,$field_name,$type){
	
	
		$param = array("id" => $id,"field_name"=>$field_name,"type"=>$type);
	
		$namespace="urn:xmethods-BNgetField";
	
		$result = $this->client->call('getField',$param,$namespace);
	
					
		if (isset($fault)) {
				print "Error: ". $fault;
				return false;
		} else	
			return $result["field"];
		 
	
		
	}
	
	function Validate_Passwd($N,$P,&$urls,&$permissions){
	
		$result=$this->Generate_ID();		
		$this->objToken=new CToken($result["id"],$result["day"]);		
		
			    
		$param = array("N" => $N,
		               "P"=>md5($N.md5($P).TCS),
		               "C_RO"=>$this->objToken->RO,
		               "C_http"=>$this->objToken->http,
		               "C_id"=>$this->objToken->id,
		               "C_day"=>$this->objToken->day,
		               "C_md5"=>$this->objToken->md5);
		               
			
		$namespace="urn:xmethods-BNValidate_Passwd";
	
	
		$result = $this->client->call('Validate_Passwd',$param,$namespace);
		
					
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else				
				if(strcmp($result["TC"],md5($this->objToken->ReturnAll().TCS))==0)		
					if(strcmp(md5($result["permissions"].$this->objToken->ReturnAll().TCS),$result["pmd5"])==0){
					
						$result["permissions"]=trim($result["permissions"]);
						$p=explode(" ",$result["permissions"]);
						
						$j=0;
						$i=0;
						while($i<count($p)){							
							$urls[$j]=$p[$i];
							$permissions[$j++]=$p[$i+1];							
							$i=$i+2;							
						}
						
						return true;	
					}
		return false;
		}
			
		
 	
}

?>			