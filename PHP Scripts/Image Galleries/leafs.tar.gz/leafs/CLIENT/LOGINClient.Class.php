<?
  

require_once('nusoap.php');
require_once(PATH.'configs/config_mysql.php');


class CLOGINClient{

	var $client;        //obiect soap-client
	
	
	function Connect($address){
	
	
	
		$this->client = new soapclient($address);
		
	}
	
	
	function Close(){
		unset($this->client);		
	}

	
	
	function WhoIsUser($key){
	
		$param = array("key"=>$key);
		               			
		$namespace="urn:xmethods-BNWhoIsUser";
	
		$result = $this->client->call('WhoIsUser',$param,$namespace);
		
						
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else							
				return $result;
	
		
	}
	
	function SendLogin($user,$key){
	
	    
		$param = array("user"=>$user,"key"=>$key);
		
		               			
		
		$namespace="urn:xmethods-BNSendLogin";
	
		$result = $this->client->call('SendLogin',$param,$namespace);
		
						
		if (isset($fault)) {
			print "Error: ". $fault;
			return false;
			} 
			else							
				return $result;
	
		
	}
	
}

?>			