<?php

 include("configs/settings.php");
 
 if(LOGIN_TYPE=="advanced"){
 
    include_once("includes/functions.php");
    
    include_once(PATH."Class/MySql.Class.php");
    include_once(PATH."CLIENT/LOGINClient.Class.php");
 
 ?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
 <html>
	<head>

		<meta http-equiv="Pragma" content="no-cache">
		<style type="text/css">
		body {
		margin-left: 0px;
		margin-top: 0px;
		margin-right: 0px;
		margin-bottom: 0px;
		background-color: #FFFFFF;
		}	
	
		</style>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
		<title></title>
	</head>
	
	
 <body> 
  <?	
 	
	$key=@$_GET['key'];

	$usr=User($key);

	if(empty($usr)){
	
	$c=new CLOGINClient();
	
		
	$c->Connect(SERVER);
	$result=$c->WhoIsUser($key);	
	$user=$result["user"];
	

	$c->Close();

	if(!empty($user)){
	
	  
		$db=new MySql(database_name,user,password);
		if($db->Connect()){
			$sql="delete from ".TABLE_LOGIN." where user='$user'";
			$db->Query($sql);
		
			$sql="insert into ".TABLE_LOGIN." values('$user','$key')";
			$db->Query($sql);
			
			$db->Close();
			
			$perm=trim($result["permissions"]);	
		
			$p=explode(" ",$perm);
			$url=array();
			$permissions=array();
							
			$j=$i=0;
			while($i<count($p)){							
					$url[$j]=$p[$i];
					$permissions[$j++]=$p[$i+1];							
				
					$i=$i+2;							
			}	
			
			setPermissions($url,$permissions);
			$_SESSION['user_ax']=$user;
		}else
			die("Login module temporaly unavaible");
		
		
	    }
	}
		
}
		
 
if(empty($user)){
 ?>		
 	 <div id="lselect" align='left'>
		<form action="modules/login.php" method="post">
				Id:<br>
				<input type="text" name="id" size="18"/>
				Parola:<br>
				<input type="password" name="pass" size="18"/><br>	
				<input type="submit" value="Login"/><br> 
				<?

				if(LOGIN_TYPE=="advanced"){
				?>
				<a  href="<? echo NEW_USER_LINK;?>" target="_blank">New user</a><br>
				<a  onClick="javascript:parent.location='<? echo FORGOT_PASS; ?>'" href='#'>I forgot my password</a>
				<?
				}else
				    echo "<br>Only for admin</b>";
				?>
								    
	   
		</form>
		
	    </div>
	
	 <?
	 
	 }else{
	 ?>
	 <div id="lselect" align='left'>
	 <?
	 include("modules/menu_welcome.php");
	 ?>
	 </div>
	 <?
	 }
	 ?>

 
</body>
</html>
