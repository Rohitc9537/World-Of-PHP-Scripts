<?

require_once("../configs/settings.php");
require_once(FULL_PATH."Class/MySql.Class.php");


function DoLogout($user){

	$db=new Mysql(database_name,user,password);
	$db->Connect();	

	$sql="Delete from ".TABLE_LOGIN." where user='$user'";
	@$db->Query($sql);
	$h=fopen("aa","w");
	fwrite($h,"da");
	fclose($h);
		
	$db->Close();
	
}


function Update_Emails($email,$action){

	$db=new Mysql(database_name,user,password);
	$db->Connect();	

	$result=1;
	if($action==0){ //sterge
		$sql="Delete from ".TABLE_SPAM." where email='$email'";
		if(!@$db->Query($sql))
			$result=0;
	}else{
		$sql="insert into  ".TABLE_SPAM." values('$email')";
		if(!@$db->Query($sql))
			$result=0;
	}

	$db->Close();
	return $result;
}


function GetUser($key){

	$db=new Mysql(database_name,user,password);
	$db->Connect();	

	$sql="select user from ".TABLE_LOGIN." where key='$key'";
	$result=@$db->Query($sql);
	$r=@mysql_fetch_array($result);
	$result=$r['user'];		
	$db->Close();
	return $result;
}




?>