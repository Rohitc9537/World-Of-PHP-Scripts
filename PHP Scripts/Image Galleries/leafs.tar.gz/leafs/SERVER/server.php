<?php
/*********************************************
  Axiologic
  ********************************************
  Copyright 2005 by Axiologic Team
  http://www.axiologic.com

  SOAP SERVER
  
  $Version: 1.0
  $Date: 2005/07/1 
**********************************************/

require_once("functions.php");

require_once('nusoap.php');


function WhoIsKey($key){
	return array( "result"  =>GetUser($key));
    
}
    
function SendLogout($user){
	
	return array( "result"  =>DoLogout($user));
    
}



function Update($email,$action) {

	
    
}



$server = new soap_server;

$server->register('Update');
$server->register('WhoIsKey');
$server->register('SendLogout');
$fault = $server->fault('soap:Server','',$error);


$server->service($HTTP_RAW_POST_DATA);
?>
