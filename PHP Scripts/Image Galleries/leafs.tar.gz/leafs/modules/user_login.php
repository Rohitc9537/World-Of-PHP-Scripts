<ul>
<?


    GLOBAL $message;


    if(empty($_SESSION['user_ax'])){
    
        
	    if(!file_exists("htmls/users") && LOGIN_TYPE=="default"){		
	    
		    echo "<li><a href='".HTTP."index.php?page=change_pass'><blink>Create pass</blink></a></li>";
		    
	    }else{	
	
    		echo "<li><a href='index.php?page=login'>".$message['login']."</a></li>";
	    
	    }
    }else{
     
	     echo "
	      <li>Welcome ".$_SESSION['user_ax']."</li>
	      <li><a href='modules/logout.php'>".$message['logout']."</a></li>
	     "; 
	     
	     if(LOGIN_TYPE=="advanced"){
	     
	        echo "				
    	    	  <li><a target='_blank' href='".PROFILE_LINK."' >".$message['profile']."</a></li>
		  <li><a target='_blank' href='".FORGOT_PASS."'>".$message['change pass']."</a></li>
	      	
		";
	     }
   }    	
	
?>

</ul>