<?
GLOBAL $message;
?>

<ul>
	<?
	
	if(getPermissions(HTTTP)=="Admin" || getPermissions("HTTTP")=="Moderator")
		include("modules/menu_admin.php");
	
	
	if(ALLOW_PUBLISH==true || getPermissions(HTTTP)=="Admin"){
	
	?>
	
	<li>
	<a href='index.php?page=new_image'>&raquo;<? echo $message['upload image']; ?></a>
	</li>
	<li>
	<a href='index.php?page=categ'>&raquo;<? echo $message['create category'];?></a>		
	</li>
	
	<?
	}
	?>
	
</ul>
