<?
session_start();
?>
<script>
function go(where){
parent.location=where;
}
</script>
<center>
<? echo "<br>Welcome</b> ".$user."";?><br>
You are already logged.
</center>

