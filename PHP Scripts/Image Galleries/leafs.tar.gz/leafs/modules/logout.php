<?
session_start();
?>

<html>
<font color='blue'>Logout</b> in progress..</font><br>

<?
require("../configs/settings.php");
require("../configs/config_mysql.php");

if(LOGIN_TYPE=="advanced"){
	
    require("../Class/MySql.Class.php");
    require("../CLIENT/LOGOUTClient.Class.php");
    require("../includes/functions.php");

    $user=$_SESSION['key'];


    $db=new MySql(database_name,user,password);
    $db->Connect();

    $sql="delete from ".TABLE_LOGIN." where user='$user' and user_key=''";
    $db->Query($sql);


#
#Trimitere comanda la axiologic sa faca logout
#

    if(!empty($user)){
	$c=new CLOGOUTClient();		
	$c->Connect(SERVER);
	$c->SendLogout($user);	
	$c->Close();
    }
}

$_SESSION['key']='';
$_SESSION['user_ax']='';
$_SESSION['url[0]']='';
$_SESSION['Permissions[0]']='';

?>



<script>
function redirect(where){
location=where
}
</script>

<body onload='redirect("<? echo HTTP; ?>")'>
<?
if(LOGIN_TYPE=="advanced"){
//making logout from main server
?>
<iframe width='0' height='0' src='<? echo SERVER_HTTP; ?>logoutServer.php?key=<? echo $_SESSION['key']; ?>'>a</iframe>
<?
}
?>

</html>
