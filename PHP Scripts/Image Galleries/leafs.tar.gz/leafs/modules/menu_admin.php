

<li><a href='index.php?page=change_pass'>&raquo;Change password</a></li>
<li><a href='index.php?page=google'>&raquo;Image Query/Edit</a></li>
<li><a href='index.php?page=generate_images'>&raquo;Generate images</a></li>
<li><a href='index.php?page=generate_links'>&raquo;Generate keyw links</a></li>
<?
if(ALLOW_PUBLISH==true){
?>
<li><a href='index.php?page=validate'>&raquo;Validate items</a></li>
<?
}
?>

