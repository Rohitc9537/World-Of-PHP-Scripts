<?
session_start();
require("../configs/settings.php");
require("../includes/functions.php");
require("../Class/MySql.Class.php");

$id=$_POST['id'];
$password=$_POST['pass'];

if(LOGIN_TYPE=="default"){

    $file=file("../htmls/users");
    preg_match("'(.*):(.*)'",$file[0],$match);
    $id_file=$match[1];
    $pass_file=$match[2];
    
    
    if($id==$id_file && 
	crypt($password,substr($password,0,2))==$pass_file){
    
        $_SESSION['user_ax']=$id;
        $_SESSION['Urls[0]']=HTTTP;
        $_SESSION['Permissions[0]']="Admin";
    }else
	$err=true;
    
}else{

    require("../CLIENT/AUTHClient.Class.php");
    require("../CLIENT/LOGINClient.Class.php");

	$c=new CAUTHClient();

	if($c->Verify())
	
		if($c->Validate_passwd($id,$password,$url,$perm)){		
			setPermissions($url,$perm);			
			$_SESSION["user_ax"]=$id;	
			$_SESSION["key"]=md5(rand(1,10000).rand(1,10000));	
			
					
			//introducere in tabela cu useri logati specifica fiecarui site-cea locala
			$db=new MySql(database_name,user,password);
			@$db->Connect();
			if($db->handle){
			
			$sql="delete from ".TABLE_LOGIN." where user='$id'";
			$db->Query($sql);
		
			$sql="insert into ".TABLE_LOGIN." values('$id','".$_SESSION['key']."')";
			$db->Query($sql);
		
			$db->Close();
			
			
			
			#
			#send data to main server to authenticate
			#
			$c=new CLOGINClient();	
			$c->Connect(SERVER);
			$result=$c->SendLogin($id,$_SESSION['key']);	
			$c->Close();
			}
			else echo "Please try again later.Server full";
		
						
			}else
				$err=0;
}
				
			
			
if(!empty($err))	    
	$where=HTTP."index.php?err=1";
	else
	     $where=HTTP;
	     

?>
<html>
<head>
 <meta http-equiv="Pragma" content="no-cache">
<script>
	  function redirect(where){
 	  parent.location=where;
}
</script>		
</head>
<body onLoad="redirect('<? echo $where;?>')">
<font color='blue'>Login in progress..</font>
<?
if(LOGIN_TYPE=="advanced"){
?>
    <iframe width='1' height='1' src='<? echo SERVER_HTTP;?>loginServer.php?key=<? echo $_SESSION['key'];?>&rand=<? echo rand(1,1000); ?>'>iframe</iframe>
<?
}
?>
</body>
</html>

