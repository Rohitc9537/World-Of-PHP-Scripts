<?php
   doHead();
?>

<body id="css-zen-gardennn" > 

<div id="container">
	

	<div id="intro">
	
	
	<div id="white">
       		
		</div>
		
		<div id="pageHeader">
    		<?php
               		dopageHeader();
           	 ?>
		</div>

		
		
		<div id="quickSummary">
       		<?php
		       doquickSummary();
		   ?>
		</div>
		
		<div id="preamble">

		<?php
                 dopreamble();
             	?>
	
		</div>			
</div>



<div id="supportingText">
		
		<div id="explanation">	
       		<?php
               	 	doexplanation();
            	?>
		</div>


		<div id="participation">
		
       		<?php
              		doparticipation();
           	 ?>            
		</div>

		<div id="benefits">
		
       		<?php
                	dobenefits();
            	?>
		</div>



	  <div id="requirements">
       		<?php
                	dorequirements();
           	 ?>
		</div>
		
		
		<div id="footer">

      		<?php
               		dofooter();
            	?>
 	     
		</div>

		

	</div>


	<div id="linkList">
		<div id="linkList2">
			<div id="lselect">
           		<?php
                      		dolselect();
                	?>
			</div>

			<div id="larchives">
       		   	<?php
			      dolarchives();
                	?>
			</div>

			<div id="lresources">
       	    		<?php
                    		dolresources();
                	?>
			</div>
		</div>
	</div>


	

</div>



<div id="extraDiv1"><span></span></div><div id="extraDiv2"><span></span></div><div id="extraDiv3"><span></span></div>
<div id="extraDiv4"><span></span></div><div id="extraDiv5"><span></span></div><div id="extraDiv6"><span></span></div>

</body>

</html>

