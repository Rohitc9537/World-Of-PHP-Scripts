<?

include("../configs/config_mysql.php");
include("../configs/settings.php");
include("../Class/MySql.Class.php");

$db=new MySql(database_name,user,password);

$db->Connect();

if($db->handle){

$sql="CREATE TABLE ".TABLE_AUTOINC." (id int(8),valid_date datetime)";
if ($db->Query($sql))
 echo "Table ".TABLE_AUTOINC." <font color='green'>created<font><br>";
	else 
	echo "Table ".TABLE_AUTOINC." <font color='red'>failed</font><br>";



$sql="CREATE TABLE ".TABLE_IMG." (
		    id int(8) NOT NULL auto_increment,
		    id_keyword int(8) default NULL,
		    image text,
	            id_categ int(8) default NULL,
		    public int(2) default NULL,
		    description text,
	    	    creator text,
	    	    PRIMARY KEY  (id)
		    )";
		    
if ($db->Query($sql))
 echo "Table ".TABLE_IMG." <font color='green'>created<font><br>";
	else 
	echo "Table ".TABLE_IMG." <font color='red'>failed</font><br>";

		    
		    
$sql="CREATE TABLE ".TABLE_CATEGORY." (
		  id int(8) NOT NULL auto_increment,
	          name text,
	          description text,
		  public int(2) default NULL,
		  creator text,
		  PRIMARY KEY  (id)
		  )";
		  
if ($db->Query($sql))
 echo "Table ".TABLE_CATEGORY." <font color='green'>created<font><br>";
	else 
	echo "Table ".TABLE_CATEGORY." <font color='red'>failed</font><br>";

			    

$sql="CREATE TABLE ".TABLE_KEYWORDS." (
	  id int(8) NOT NULL auto_increment,
	  keywords text,
          public int(2) default NULL,
          PRIMARY KEY  (id)
          )";
	  
if ($db->Query($sql))
 echo "Table ".TABLE_KEYWORDS." <font color='green'>created<font><br>";
	else 
	echo "Table ".TABLE_KEYWORDS." <font color='red'>failed</font><br>";
	
	
	
$sql="CREATE TABLE ".TABLE_LOGIN." (
      user varchar(255) default NULL,
      user_key varchar(255) default NULL      
      )";
      
if ($db->Query($sql))
 echo "Table ".TABLE_LOGIN." <font color='green'>created<font><br>";
	else 
	echo "Table ".TABLE_LOGIN." <font color='red'>failed</font><br>";
      
}
else
    echo "Error connecting to mysql.Please check user/password!";
    
    

?>