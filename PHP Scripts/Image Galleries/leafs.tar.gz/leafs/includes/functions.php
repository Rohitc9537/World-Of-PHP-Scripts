<?

//genereaza pentru un keyword pagina cu imagini
function GenerateHTMLKeywords($id,$db){

	//$db=new MySql(database_name,user,password);
	//$db->Connect();

	GLOBAL $message;
	
	if(!file_exists("htmls/keywords"))
		if(!mkdir("htmls/keywords"))
		    die("htmls directory must have permissions rights");
	
	

	$result=$db->Query("Select * from ".TABLE_KEYWORDS." where id='$id' and public=1");
	$r=mysql_fetch_arraY($result);
	$name=$r['keywords'];
	$file_name=convert($name).".html";

	$items=array();
	$result=$db->Query("Select * from ".TABLE_IMG."  where id_keyword='$id' and public=1");
	
	while($r=mysql_fetch_array($result)){
		$items[]=$r;
	}
	
	$title_h1=explode(",",$name);
	//start generate
	$i=0;
	$content='<h1>'.ucfirst($title_h1[0])." - ".count($items).' pictures</h1><table class="table_keywords" >';
	
	//display items (2 columns)				
	while(true){
			if($i>=count($items))break;
			
			if($i<count($items)){
			
				if(empty($items['creator']))
					$creator="<div class='creator'><b>Added by</b>:<span>admin</span></div>";
					else
					$creator="<div class='creator'><b>Added by</b>:".$items[$i]['creator']."</div>";
					
				list($width, $height, $type, $attr) = getimagesize("htmls/images/".$items[$i]['image']);
				
				switch($type){
					case 1:$img_type="Gif";break;
					case 2:$img_type="Jpg";break;
					default:$img_type="Unknown";
				}
				
				$content.="
				<tr>
				    <td style='border-bottom:dotted #AAAAAA;border-width: 1px;' valign='top'>
				    <img src='".HTTP."htmls/images/".$items[$i]['image']."' border='0' alt='".$name."'/>
				    <bR>
					$creator
				    <div class='info'>
				    <b>Type</b>:".$img_type."<br>
				    <b>Size:</b>".$width."x".$height."<br>
				    <i>".$items[$i]['description']."</i>
				    <?
						if(getPermissions('".HTTTP."')=='Admin' || getPermissions('".HTTTP."')=='Moderator'){
						echo \"<Br><a href='index.php?page=delete_img&id=".$items[$i]['id']."'><img src='css_img/imgd.png' border='0'/></a>\";
						}
						?>
				    </div>
					<bR></td>";
				
			}
			
			$i++;
			
			if($i<count($items)){
			
				if(empty($items['creator']))
					$creator="<div class='creator'><b>Added by</b>:<span>admin</span></div>";
					else
					$creator="<div class='creator'><b>Added by</b>:".$items[$i]['creator']."</div>";
					
				list($width, $height, $type, $attr) = getimagesize("htmls/images/".$items[$i]['image']);
				
				switch($type){
					case 1:$img_type="Gif";break;
					case 2:$img_type="Jpg";break;
					default:$img_type="Unknown";
				}
				
				$content.="
				
				    <td style='border-bottom:dotted #AAAAAA;border-width: 1px;' valign='top'>
				    <img src='".HTTP."htmls/images/".$items[$i]['image']."' border='0' alt='".$name."'/>
				    <bR>
					$creator
				    <div class='info'>
				    <b>Type</b>:".$img_type."<br>
				    <b>Size:</b>".$width."x".$height."<br>				    
				    <i>".$items[$i]['description']."</i>				    
				     <?
						if(getPermissions('".HTTTP."')=='Admin' || getPermissions('".HTTTP."')=='Moderator'){
						echo \"<Br><a href='index.php?page=delete_img&id=".$items[$i]['id']."'><img src='css_img/imgd.png' border='0'/></a>\";
						}
					?>
				    </div>
					<bR>					
					</td></tr>";
				
			}
			else
				$content.="<td>&nbsp;</td><tr>";
				
			$i++;
	
	}
	$content.="</table>";
	
	
		       
	$h=@fopen("htmls/keywords/".$file_name,"w");
	if($h)
		fwrite($h,$content);
			else 
				echo "Error writing file";
				
	fclose($h);
	
	
	
				
	$info="
		start 
		link='htmls/keywords/".$file_name."'		
		title='".$message['Pictures with']." ".$name."' 
		description='".$message['Pictures with']." $name'
		keywords='$name'
		type='page_keywords'
		image='-'
		id='".$r['id']."'
		end
	    ";
		       
		$hinfo=fopen("htmls/links/".$file_name.".lnk","w");
		fwrite($hinfo,$info);
		fclose($hinfo);
	

}

function getInfo($link){//afla informatia pentru un link 
    
    //lunkurile cu article
    if(file_exists("htmls/links/$link.lnk")){

    
		$content=file_get_contents("htmls/links/$link.lnk");

		$pattern="/start\s+link='(.*?)'\s+title='(.*?)'\s+description='(.*?)'\s+keywords='(.*?)'\s+type='(.*?)'\s+image='(.*?)'\s+id='(.*?)'\s+end/is";
		
		
		preg_match_all($pattern,$content,$matches);

		
	    return array("link"=>$matches[1][0],"title"=>$matches[2][0],"description"=>$matches[3][0],"keywords"=>$matches[4][0],"type"=>$matches[5][0],"image"=>$matches[6][0],"id"=>$matches[7][0]);
	    }
    else
    //linkuri scrise de mana
    if(file_exists("blocs/links.cfg")){
	$content.=file_get_contents("blocs/links.cfg");
	

	
	
    $pattern="/start\s+link='(.*?)'\s+title='(.*?)'\s+description='(.*?)'\s+keywords='(.*?)'\s+type='(.*?)'\s+image='(.*?)'\s+end/is";
    if(preg_match_all($pattern,$content,$matches)){
    
	for($i=0;$i<count($matches[1]);$i++)
	
	    
	    
	    
	    if(strcmp(trim("htmls/$link"),trim($matches[1][$i]))==0 || strcmp(trim("blocs/$link"),trim($matches[1][$i]))==0 || strcmp(trim("$link"),trim($matches[1][$i]))==0){
	    
	    
	    
	    return array("link"=>$matches[1][$i],"title"=>$matches[2][$i],"description"=>$matches[3][$i],"keywords"=>$matches[4][$i],"type"=>$matches[5][$i],"image"=>$matches[6][$i]);
	    }
    }
    
    }
	return NULL;
    
    

    
}

//htmls relating links
function GenerateRelating(){

	$db=new MySql(database_name,user,password);
	$db->Connect();
	
	$result=$db->Query("select * from ".TABLE_CATEGORY."  where public=1 order by name asc");

	
	while($r=mysql_fetch_array($result)){
	
		
		$name=$r['name'];

		$id=$r['id'];
		$description=$r['description'];
	
	
	    //links with keywords-generarea linkurilor cu k  pt categ respectiva
	    $res=$db->Query("Select * from ".TABLE_KEYWORDS."  order by keywords ASC");
		
		if(isset($__items))
		foreach($__items as $letter=>$items){
			unset($__items[$letter]);
			
		}
		$__items=array();
		while($rr=@mysql_fetch_array($res)){
		
		
				$result1=$db->Query("Select count(*) as c from ".TABLE_IMG."  where id_keyword=".$rr['id']." and public='1' and id_categ='$id'");			
				$r1=mysql_fetch_array($result1);
				$c=$r1['c'];
		
				
				//categ respectiva imagini cu aceste  keyworduri pe litere
				if($c>0){
				
					$__items[strtoupper($rr['keywords'][0])][]=$rr;
					
				}
				
			}
				
	
		$i=0;
		$content_links="";
		$items=array();
		$letter="";
		foreach($__items as $letter=>$items){
		$content_links.="<h4>[$letter]</h4>";
		$i=0;
		while(true){
		
					if($i>=count($items))break;
				
					
					if($i<count($items)){
						$content_links.="<a href='".convert($items[$i]['keywords']).".html'>".$items[$i]['keywords']."</a><br>";
						GenerateHTMLKeywords($items[$i]['id'],$db);
						}
						
					
					$i++;
	
		}
		
		}
		
		$links=convert($name);
		$hc=fopen("htmls/$links.html","w");
		fwrite($hc,$content_links);
		fclose($hc);
			
		
	//end keywords

	}
	
	$db->Close();

}


//


function GenerateMainPage(){

	$content_links="";
	
	if(!file_exists("htmls/links"))
		if(!mkdir("htmls/links"))
		    die("htmls must have permissions rights");

	$db=new MySql(database_name,user,password);
	$db->Connect();
	GLOBAL $message;
	
	$result=$db->Query("select * from ".TABLE_CATEGORY."  where public=1 order by name asc");
	
	$content="<table border='0' align='left' width='100%'>
        <tr>
           <td width='80%' valign='top'>
	   ".$message['main']."
	    <br><h3>".$message['Pictures categ']."</h3>
              <table border='0' align='left' valign='top' width='100%'>";
	
	while($r=@mysql_fetch_array($result)){
	
		
		$name=$r['name'];
		
		$id=$r['id'];
		$description=$r['description'];
		
		
		$result_count=$db->Query("select count(*) as c from ".TABLE_IMG."  where public=1 and id_categ='$id' ");
		$r_count=mysql_fetch_array($result_count);
		$no_count=$r_count['c'];

		
		$file_name=convert($name);
		
		$content.="<tr><td><a href='".$file_name."_1.html' title='$description'><b>$name</b></a> (<b>$no_count</b> pictures)- <font color='blue'>".$r['description']."</font></td></tr>";

		$content_links.="<li>&raquo;<a href='".$file_name."_1.html' title='$description'>$name</a></li>";
		
		//htmls page for categ with images
		$content_img=
		$result1=$db->Query("select * from ".TABLE_IMG."  where public=1 and id_categ=".$r['id']."");	
		while($r1=mysql_fetch_array($result1)){
		
		}
		

	}
	
	$content.="</table><Br>".$message['main page privacy']."</td>
	<td valign='top'></td></tr></table><br clear='all'>";
	
	$h=fopen("htmls/main_page.html","w");
	fwrite($h,$content);
	fclose($h);

	$h=fopen("htmls/categories.html","w");
	fwrite($h,$content_links);
	fclose($h);
	
	
	
	
	
	
	
	
	
	$db->Close();

}



function GenerateImages(){

	GLOBAL $message;

	$db=new MySql(database_name,user,password);
	$db->Connect();
	
	$result=$db->Query("select * from ".TABLE_CATEGORY."  where public='1' order by name asc");
	

	
	while($r=@mysql_fetch_array($result)){
		
		$name=$r['name'];
		$id=$r['id'];
		$description=$r['description'];
		
		$file_name=convert($name);
		
		
		
		$result1=$db->Query("select * from ".TABLE_IMG."  where public='1' and id_categ=".$r['id']."");	
		
		$no=mysql_num_rows($result1);
	
		$i=0;
		$pages=1;
		$no_pages=round($no/40);
		if($no_pages%40>0)
			$no_pages++;

		$col=1;
		echo "for $name:$no pictures<br>";
	
		$content=top_page($name." (".$no.") pictures");
	
		
		
		
		while($r1=mysql_fetch_array($result1)){
		
		
			$result2=$db->Query("select * from ".TABLE_KEYWORDS."  where id=".$r1['id_keyword']." and public='1'");	
			$r2=mysql_fetch_array($result2);
			$keywords=$r2['keywords'];
			
			$description=$r1['description'];
			if(empty($description))
				$description=$keywords;
				
			list($width, $height, $type, $attr) = getimagesize("htmls/images/".$r1['image']);
				
			switch($type){
					case 1:$img_type="Gif";break;
					case 2:$img_type="Jpg";break;
					default:$img_type="Unknown";
			}
			
			if(empty($r1['creator']))
					$creator="<div class='creator'><b>Added by</b>:<span>admin</span></div>";
					else
					$creator="<div class='creator'><b>Added by</b>:".$r1['creator']."</div>";
			$dollar="$";
			//4 columns
			if($col==1){
				$content.="
				<tr>
				    <td valign='top' class='categ'>
				       <img src='htmls/images/".$r1['image']."' alt='$keywords' /><br>$creator				    
						<div class='info'>
						<i>$description</i><br>
						<b>Type</b>:".$img_type."<br>
						<b>Size:</b>".$width."x".$height."
						<?
						if(getPermissions('".HTTTP."')=='Admin' || getPermissions('".HTTTP."')=='Moderator'){
						echo \"<Br><a href='index.php?page=delete_img&id=".$r1['id']."'><img src='css_img/imgd.png' border='0'/></a>\";
						}
						?>
						</div>
						<bR>
				    </td>";
				$col++;				
			}else
				if($col==2 || $col==3 ){
				$content.="
					<td valign='top' class='categ'>
						<img src='htmls/images/".$r1['image']."' alt='$keywords'/><br>$creator
						<div class='info'>
						<i>$description</i><br>
						<b>Type</b>:".$img_type."<br>
						<b>Size:</b>".$width."x".$height."
						<?
						if(getPermissions('".HTTTP."')=='Admin' || getPermissions('".HTTTP."".HTTTP."')=='Moderator'){
						echo \"<Br><a href='index.php?page=delete_img&id=".$r1['id']."'><img src='css_img/imgd.png' border='0'/></a>\";
						}
						?>
						</div>
						<bR>
					</td>";
				$col++;
				
				}else if($col==4){
				$content.="
					<td valign='top' class='categ'>
						<img src='htmls/images/".$r1['image']."' alt='$keywords'/><br>$creator				    
						<div class='info'>
						<i>$description</i><br>
						<b>Type</b>:".$img_type."<br>
						<b>Size:</b>".$width."x".$height."
						<?
						if(getPermissions('".HTTTP."')=='Admin' || getPermissions('".HTTTP."')=='Moderator'){
						echo \"<br><a href='index.php?page=delete_img&id=".$r1['id']."'><img src='css_img/imgd.png' border='0'/></a>\";
						}
						?>
						</div>
						<bR>	
					</td>
					
				</tr>
				
				";
				$col=1;				
				$i++;
				}
				
		
		
			if($i==10){
			
			
				$h=fopen("htmls/".$file_name."_".$pages.".html","w");
				
				//htmls informations
						
				$info="
				start 
				link='htmls/".$file_name."_".$pages.".html'		
				title='".$r['name']."' 
				description='".$r['description']."'
				keywords='".$r['name']."'
				type='category'
				image='-'
				id='".$r['id']."'
				end
		       		 ";
		       
				$hinfo=fopen("htmls/links/".$file_name."_".$pages.".html.lnk","w");
				fwrite($hinfo,$info);
				fclose($hinfo);
				
				//end generate
				
				
				
				
				if($no_pages>1 && $pages<$no_pages){
					$pages++;
					$link_next_page="<a href='".$file_name."_".$pages.".html'>Next page</a><Br>";
					}else
					$link_next_page="";
					
					
				$content.="
				</table>
				</td>
				<td valign='top'>				
					<?	

					if(file_exists('htmls/".convert($name).".html'))
						include('htmls/".convert($name).".html');
					?>												
				</td>
				</tr>
				</table>
				<Br clear='all'>
				$link_next_page
				".$message['Go to page']."<br>
				<select id='mySelect' onChange='doS()'>
				<option value='0'>--</option>";
			
				for($j=1;$j<=$no_pages;$j++){
					$content.="<option value='".$file_name."_".$j."'>$j</option>";
				}
			
				$content.="</select>";
				$i=0;
				fwrite($h,$content);
				fclose($h);
				
			
				
				 
				
				//init
				$content=top_page($name." (".$no.") pictures");
				$i=0;
				
			}
		
		
		
		}
		
		//resutl cate au mai ramas
		if($i>0 || ($i==0 && $col>1)){
						
				
				$h=fopen("htmls/".$file_name."_".$pages.".html","w");
				
				//generate informations
						
				$info="
				start 
				link='htmls/".$file_name."_".$pages.".html'		
				title='".$r['name']."' 
				description='".$r['description']."'
				keywords='".explode(",",$r['name'])."'
				type='category'
				image='-'
				id='".$r['id']."'
				end
		      		  ";
		       
				$hinfo=fopen("htmls/links/".$file_name."_".$pages.".html.lnk","w");
				fwrite($hinfo,$info);
				fclose($hinfo);
				
				//end generate
				
				
				
		
				if($no_pages>1 && $pages<$no_pages){
					$pages++;
					
					$link_next_page="<a href='".$file_name."_".$pages.".html'>Next page</a><Br>";
					}else
					{
					$link_next_page="<a href='".$file_name."_".($pages-1).".html'>Previous page</a><Br>";
					
					}
					
				
				$content.="
				</table>
				</td>
					<td valign='top'>				
					<?
					if(file_exists('htmls/".convert($name).".html'))
					include('htmls/".convert($name).".html');
					?>												
					</td>
				</tr>
				</table>
				<br>
				<Br clear='all'>
				$link_next_page
				<b>".$message['Go to page']."</b>:<br>
				<select id='mySelect' onChange='doS()'>
				<option value='0'>--</option>";
			
				for($j=1;$j<=$no_pages;$j++){
					$content.="<option value='".$file_name."_".$j."'>$j</option>";
				}
			
				$content.="</select>";
				$i=0;
				fwrite($h,$content);
				fclose($h);
				
			
				
				 
				
				//init
				$content=top_page();
				$i=0;
		
		}
		if($no==0){
			$h=fopen("htmls/".$file_name."_".$pages.".html","w");
			fwrite($h,"<h1>".$message['No pictures found!']."</h1>");
			fclose($h);
				
		}
		
		
		

	}
	
	
	$db->Close();

}






function top_page($what=""){

return "
	
		<script type=\"text/javascript\">
		function doS(){
		var x=document.getElementById(\"mySelect\")
		if(x.options[x.selectedIndex].value!='0'){
			var link=x.options[x.selectedIndex].value+'.html'
			location=link
		}
		}
		</script>
		
		<h1>$what</h1>
		

		<table class='categ_main_table' valign='top'><tr><td>
		<table class='categ_second_table' valign='top'>

";

}

function convert($str){

	$from=array("(",")","'","?",":",",",";","!");
	$to=array("","","","","","","","");
	
	
	$str=str_replace($from,$to,$str);
	$str=preg_replace("'\s+'","_",$str);
	return $str;

}

function simple_clean($str){

				$from=array("&quot;",
				"&amp;",
				"\"",
				"'",
				"-",
				":",
				"!",
				"?",
				"%",
				'"',
				",",
				"&",
				"/",
				"$",
				"\xAB",
				"\xBB",
				"quot;",				
				"<br>",
				"<br >",
				"(",")",
				"A",
				"A",
				"A\xEF\xBF\xBD",
				"\x93",
				"\x94",
				"\xC2");
				$to=array("","","","","","","","","","","","","","","","","","","","","","","","","","");
				return str_replace($from,$to,$str);
				
}

###################################################################################################
function SpecialChars($str){

define("tz",0);define("Tz",1);define("AM",2);define("aM",3);define("IM",4);define("iM",5);define("A_",6);define("a_",7);define("Sh",8);define("sh",9);
define("icirc",10);

$r["unicode"][tz]="\xC5\xA3";$r["unicode"][Tz]="\xC5\xA2";$r["unicode"][AM]="\xC3\x82";$r["unicode"][aM]="\xC3\xA2";$r["unicode"][IM]="\xC3\x8E";
$r["unicode"][iM]="\xC3\xAE";$r["unicode"][A_]="\xC4\x82";$r["unicode"][a_]="\xC4\x83";$r["unicode"][Sh]="\xC5\x9E";$r["unicode"][sh]="\xC5\x9F";
$r["unicode"][icirc]="i";

/* latin 2*/

$r["latin2"][tz]="\xFE";$r["latin2"][Tz]="\xDE";$r["latin2"][AM]="\xC2";$r["latin2"][aM]="\xE2";$r["latin2"][IM]="\xCE";
$r["latin2"][iM]="\xEE";$r["latin2"][A_]="\xC3";$r["latin2"][a_]="\xE3";$r["latin2"][Sh]="\xAA";$r["latin2"][sh]="\xBA";
$r["latin2"][icirc]="i";

/* Latin 1 */

$r["latin1"][tz]="t";$r["latin1"][Tz]="T";$r["latin1"][AM]="\xC2";$r["latin1"][aM]="\xE2";$r["latin1"][IM]="\xCE";
$r["latin1"][iM]="\xEE";$r["latin1"][A_]="A";$r["latin1"][a_]="a";$r["latin1"][Sh]="S";$r["latin1"][sh]="s";
$r["latin1"][icirc]="i";

/* fara diactiritce */

$r["normal"][tz]="t";$r["normal"][Tz]="T";$r["normal"][AM]="A";$r["normal"][aM]="a";$r["normal"][IM]="I";
$r["normal"][iM]="i";$r["normal"][A_]="A";$r["normal"][a_]="a";$r["normal"][Sh]="S";$r["normal"][sh]="s";
$r["normal"][icirc]="i";

$str=str_replace($r['unicode'],$r['normal'],$str);
$str=str_replace($r['latin2'],$r['normal'],$str);

$str=str_replace("\xEF\xBF\xBD","",$str);
$str=str_replace("\xEF\xBF\xBD\xEF\xBF\xBD","",$str);



return $str;

}



function User($key){
	$db=new MySql(database_name,user,password);
	$db->Connect();
	
	$r=@mysql_fetch_array($db->Query("select user from ".TABLE_LOGIN." where user_key='".$key."'"));
	$db->Close();
	
	
	
	return $r['user'];
}


function getPermissions($url){
	$i=0;
	$perm='';
	while(true){
	
		$u=@$_SESSION['Urls['.$i.']'];
				
		if(!empty($u)){
			
			if(strcmp($url,"http://".$u."/")==0 || strcmp($url,$u)==0 || strcmp($url,$u."/")==0 )
				return 
					@$_SESSION['Permissions['.$i.']'];
			
			if(strcmp($u,"all")==0)
				$perm=@$_SESSION['Permissions['.$i.']'];
						
					
		}else
			break;
		
		$i++;
	}
	
	
	
	return $perm;
}

function setPermissions($url,$perm){


	for($i=0;$i<count($url);$i++){
		$_SESSION['Urls['.$i.']']=$url[$i];
		$_SESSION['Permissions['.$i.']']=$perm[$i];
	
	}

	
}

function session_check($type="3") {

	$redirect=false;
	
	$usr=$_SESSION['user_ax'];
	
	if(empty($usr))
			$redirect=true;
			
	if(strcmp($type,"0")==0)//admin
		if(strcmp(getPermissions(HTTTP),"Admin")!=0)
			$redirect=true;
			
	if(strcmp($type,"1")==0)//moderator
		if(strcmp(getPermissions(HTTTP),"Moderator")!=0)
			$redirect=true;
			
	if(strcmp($type,"2")==0)//User
		if(strcmp(getPermissions(HTTTP),"User")!=0)
			$redirect=true;
			
	if(strcmp($type,"01")==0)//ADmin si moderator
		if(strcmp(getPermissions(HTTTP),"Moderator")!=0 && strcmp(getPermissions(HTTTP),"Admin")!=0)			
			$redirect=true;
	
	
		
	if($redirect){
				echo "
				<script language='javascript'>
				location.href='index.php?page=error_login';
				</script>
				";
				exit();
	}
          
}




 

function Clean($str)
	{

		$from = array("s", "S", "t", "T", ", ", ", ", "a", "A","\xBA","\xE3","\xE2","\xDE","\xFE","\xAA","\xCE","\xEE","A\xEF\xBF\xBD");
		$to  = array("s", "S", "t", "T", "i", "I", "a", "A", "a", "A","s","a","a","T","t","S","I","i","");

		$newstr = str_replace($from, $to, $str);
		return $newstr;
	}




?>
