<?
if(ALLOW_PUBLISH==true && USER_LOGIN==true && LOGIN_TYPE=="advanced")
    session_check();
    else
    if(ALLOW_PUBLISH==false)
    session_check("0");
    

GLOBAL $message;

//save

$step=@$_POST['step'];

if(!file_exists("htmls/images"))
    if(!@mkdir('htmls/images'))
	die("<Center>htmls directry must have write perimissions<center>");
	



$db=new MySql(database_name,user,password);
$db->Connect(); 


if($step!="step_save"){

		
$result=$db->Query("Select * from ".TABLE_CATEGORY." where public=1 order by name asc");
		
	
$select="<select name='categ'>";
	while($r=@mysql_fetch_array($result))
		$select.="<option value='".$r['id']."'>".$r['name']."</option>";
		
$select.="</select>";
		
echo "
	<h1>".$message['Upload image']."</h1>
	<form action='index.php' enctype=\"multipart/form-data\" method='post'>
	         <font color='red'>*</font>".$message['Image'].":<br>
	         <input name='image' type='file' value=''/>
	         <br><br>
	         <font color='red'>*</font>".$message['Category'].":<br>
	         
	         $select
	         <br>
	         <font color='red'>*</font>".$message['Keywords'].":<br>
	         <input type='text' name='keywords' size='30'/>
	         <br>
	         
	         ".$message['Description'].":<br>
	         <input type='text' name='description' size='30'/>
	         <br>
	         
	            
	         <input type='submit' value='ok'/>
	         
	         
	         <input type='hidden' value='new_image' name='page'/>
	         <input type='hidden' value='step_save' name='step'/>
	</form>
	<br>
	<br>
	<font color='red'>".$message['Required']."</font><br>
	";
	if(getPermissions(HTTTP)!="Admin")
	echo "
    	<font color='#C0C0C0'>".$message['Validate note']."</font>
	
	";
	
}else{
//save
		$keywords=@$_POST['keywords'];
		$description=@$_POST['description'];
		$category=@$_POST['categ'];
		
		
		
		$bad=false;
		//tesing keyword
		if(empty($keywords) || badwords($keywords) || badwords($description) || badwords($category) || empty($category) )
		{
		echo "
		<script>
		alert('".$message['bad keyword']."');
		location='index.php?page=new_image'
		</script>
		";
		$bad=true;
		}
		
		
		
		list($width, $height, $type, $attr) = @getimagesize($_FILES['image']['tmp_name']);
		
		//testing image
		
		if(ALLOW_PUBLISH==true)
		if (!( ($width<=allowed_width) && ($height<=allowed_height) ))
		{
		echo "
		<script>
		alert('".$message['bad image']."');
		location='index.php?page=new_image'
		</script>
		";
		$bad=true;
		}
		
		
		
		if(!$bad){
		if(!empty($_FILES['image']['tmp_name'])){

					$uploaddir = 'htmls/images/';
					$img_name=convert($keywords);
					
					
					if($type==1)
						$ext=".gif";
						else
						$ext=".jpg";
				
					
					
					$hold=$img_name;
					if(file_exists("htmls/images/$img_name".$ext)){
						while(1){
							$img_name=$hold.rand(1,1000).$ext;
							if(!file_exists("htmls/images/$img_name"))
								break;
						}
							
					}else
					$img_name=$img_name.$ext;
					
					
					
					
										
					$uploadfile = $uploaddir . "".$img_name;
					@move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile);				

					$imginfo = getimagesize($uploadfile);		
											

		}else{
			echo "
			<script>
			alert('".$message['bad image']."');
			location='index.php?page=new_image'
			</script>
			";
			$bad=true;
			}
			
			
			if(!$bad){
			$sql="select * from ".TABLE_KEYWORDS." where keywords='$keywords'";
			$result=$db->Query($sql);
			
			$r=@mysql_fetch_array($result);
			$id=$r['id'];
			
			
			//nu mai este deja -just inserted new keywords and image
			if(empty($id)){
				
				//inserted as not public-must be validated
				
				if(getPermissions(HTTTP)=="Admin" || getPermissions(HTTTP)=="Moderator")
				$public=1;
				else
					$public=0;	
				
				$sql="Insert into ".TABLE_KEYWORDS." values(0,'$keywords','$public')";
				$result=$db->Query($sql);
				
				
				
				//getting id
				$sql="select id from ".TABLE_KEYWORDS." where keywords='$keywords'";
				$result1=$db->Query($sql);
				if($result1){
					$r=@mysql_fetch_array($result1);
					$id=$r['id'];
				}
				
				//getting id
				$sql="insert into ".TABLE_IMG." values(0,'$id','$img_name','$category','$public','$description','".$_SESSION['user_ax']."')";
				$result2=$db->Query($sql);
				if($result2){
					$r=@mysql_fetch_array($result2);
					$id=$r['id'];
				}
				
				
				
				if($result && $result1 && $result2){
					echo $message['Upload succes'];
				}else
					echo "An error was occured.Please try again later.";
				
			
			}//end inserted
		
		
			else{
			//update
			
			//getting id
				$sql="select id from keywords where keywords='$keywords'";
				$result1=$db->Query($sql);
				if($result1){
					$r=@mysql_fetch_array($result1);
					$id=$r['id'];
				}
				
				if(getPermissions(HTTTP)=="Admin" || getPermissions(HTTTP)=="Moderator")
				$public=1;
				else
					$public=2;	
				
				//getting id
				$sql="insert into assoc_imgs values(0,'$id','$img_name','$category','$public','$description','".$_SESSION['user_ax']."')";
				$result2=$db->Query($sql);
				if($result2){
					$r=@mysql_fetch_array($result2);
					$id=$r['id'];
				}
				
				
				
				if($result && $result1 && $result2){
					echo $message['Upload succes'];
				}else
					echo "An error was occured.Please try again later.";
			
				
			
			}
		}//bad else
		}//bad
		
		
	}//else
		
	
$db->Close();
function badwords($str){


	/*complete with forbidden words */
	$items=array(
	"sucks",
	"fuck",
	"fucked",
	"fucking",
	);
	
	$words=preg_split("/[\s,]+/",$str);
	foreach($words as $word)
		if(in_array($word,$items))
			return true;
			
	return false;
	
	

}

?>