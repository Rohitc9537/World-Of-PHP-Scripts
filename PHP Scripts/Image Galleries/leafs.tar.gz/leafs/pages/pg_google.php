<?

$str=@$_POST['str'];


$db=new MySql(database_name,user,password);
	
$db->Connect();

$items=array();
$result=$db->Query("Select * from ".TABLE_KEYWORDS." order by keywords asc");
$select="<select name='k'>";
	$select.="<option value='' selected></option>";
	
while($r=mysql_fetch_array($result)){

	$select.="<option value='".$r['id']."'>".$r['keywords']."</option>";
	
}
$select.="</select>";


$items=array();
$result=$db->Query("Select * from ".TABLE_CATEGORY." order by name asc");
$select_c="<select name='cat'>";
while($r=mysql_fetch_array($result)){

	$select_c.="<option value='".$r['id']."'>".$r['name']."</option>";
	
}
$select_c.="</select>";




if(empty($str)){
/*form*/
		echo
		
		'	
		<form action="index.php" method="post">
		<input type="hidden" name="page" value="google"/>
		<table align="center" width="600px" style="border-bottom:solid #AAAAAA;border-width: 2px;">
			<tr>
				<td>
					<h1>Image query</h1>
				</td>
			</tr>
			<tr>
				<td style="border-top:solid #AAAAAA;border-width: 2px;"> 				
				Google search:
				</td>
			</tr>
			<tr>
				<td>
				<input type="text" name="str" size="50"/><br>
				Keywords:<br>
				<input type="text" name="key" size="50"/><br>
				<font color="grey">Keywords that represents the picture(s)<br>
				<b> eg: keyword1 keyword2,keyword3</font>
				<br>
				You can add to the following keywords :<br>
				'.$select.'
				<br>

				<br>
				Belongs to category:<br>
				'.$select_c.'
				<br>
				Description:<br>
				<input type="text" name="description" size="50"/><br>
				
				<font color="grey">If you choose "an existing keyword, leave blank keywords field.</font><br>
				
				
				<br>
				<font color="orange">Display first</font>  
				<select name="r">
					<option value="20">1</option>
					<option value="40">2</option>
					<option value="60">3</option>
					<option value="80">4</option>
					<option value="100">5</option>
					<option value="120">6</option>
					<option value="140">7</option>
					<option value="160">8</option>
					<option value="170">9</option>
					<option value="180">10</option>
				</select>
				<b>pages</b><br>
				<input type="submit" value="Ok"/>
						
				</td>
			</tr>
			</table>
			</form>
			<br>			
		';
		$db=new MySql(database_name,user,password);
		
		$db->Connect();
		
		$result=$db->Query("Select * from ".TABLE_KEYWORDS." order by keywords ASC");
		
		$___items=array();
		while($r=mysql_fetch_array($result)){
		
				$__items[strtoupper($r['keywords'][0])][]=$r;
				}
				
		$i=0;
		$content='
		
		<table align="center" width="600px" style="border-bottom:solid #AAAAAA;border-width: 2px;">
			<tr>
				<td colspan="2" style="border-bottom:solid #AAAAAA;border-width: 2px;">
					<h1>Edit keywords</h1>
				</td>
			</tr>';
		if(count($__items)>0)
		foreach($__items as $letter=>$items){
		$content.="<tr><td align='center' colspan='2' style='border-bottom:solid grey;border-width: 1px;'><font color='green'><h3>$letter</h3></font></td></tr>";
		$i=0;
		while(true){
					if($i>=count($items))break;
				$content.="<tr>";
					
					if($i<count($items)){
						$content.="<td><a href='index.php?page=images&id=".$items[$i]['id']."'>".$items[$i]['keywords']."</a>&nbsp;<font color='grey' size='-1'>(<a style='color:grey;' href='index.php?page=delete&id=".$items[$i]['id']."'>delete</a>)</font></td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
					$i++;
					
					if($i<count($items)){
						$content.="<td><a href='index.php?page=images&id=".$items[$i]['id']."'>".$items[$i]['keywords']."</a>&nbsp;<font color='grey' size='-1'>(<a style='color:grey;' href='index.php?page=delete&id=".$items[$i]['id']."'>delete</a>)</font></td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
						
						
					$i++;
					
						
				$content.="</tr>";
			
		}
		
		}
		$content.="</table>";
		echo $content;
		
		
		
		
		
		
}else{

	/*parse*/

	$r=@$_POST['r'];
	
	
	$imgs=array();
	$s=@$_POST['key'];
	$k=@$_POST['k'];
	$description=@$_POST['description'];
	$cat=@$_POST['cat'];
	$s=str_replace("\"","",$s);
	
	$str=preg_replace("/\s+/","+",$str);
	$str=str_replace("\"","%22",$str);
	

	
	for($j=0;$j<$r;$j+=20){
		$address="http://images.google.ro/images?q=$str&imgsz=small%7Cmedium%7Clarge%7Cxlarge&svnum=10&hl=ro&lr=&start=$j&sa=N";
		
		
		parseGoogle(getRequest("",$address));

	}


	echo "
	<form action='index.php' method='post'>
	<input type='hidden' value='save' name='page'/>
	<input type='hidden' value='$s' name='keywords'/>
	<input type='hidden' value='$k' name='k'/>
	<input type='hidden' value='$description' name='description'/>
	<input type='hidden' value='$cat' name='cat'/>
	<center><input type='submit' value='Save'/></center>
	<table border='0' align='center' style='border-bottom:solid #AAAAAA;border-width: 1px;'>";
		display();
	echo "</table>
	<br>
	<center><input type='submit' value='Save'/></center>
	</form>";

}


function getRequest($proxy,$url){

   $user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";

   $ch = curl_init();
   
   curl_setopt($ch, CURLOPT_TIMEOUT, 15);
   curl_setopt($ch, CURLOPT_HEADER, 1);
   curl_setopt($ch, CURLOPT_HTTPGET,1);   
   curl_setopt($ch, CURLOPT_URL,$url);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_HTTP_VERSION,'CURL_HTTP_VERSION_1_1' );  
   
   if(!empty($proxy))
	curl_setopt($ch,CURLOPT_PROXY,$proxy);
	
   curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);

    
    $retrievedhtml = curl_exec($ch);
    
    return $retrievedhtml;
}
    
  


function parseGoogle($str){

	GLOBAL $imgs;
	$p="'<td[^>]*>\s*(<a.*?>)\s*<img\s+src=([^\s]*)\s+[^>]*>\s*</a>\s*</td>'si";
	preg_match_all($p,$str,$match);
	
	for($i=0;$i<count($match[2]);$i++){
		$imgs[2][]=$match[2][$i];
		$imgs[1][]=$match[1][$i];
	}
	
	

}

/*afiseaza tabel cu imaginile pe 4 coloane*/
function display($cols=6){
	
	GLOBAL $imgs;
	
	$i=0;
	while(true){
	
	echo "<tr>";
	
	$j=$i;
	while($j<$i+$cols && $j<count($imgs[2])){
		
		if(!empty($imgs[2][$j])){				
			echo "<td align='center' valign='bottom'>
					".$imgs[1][$j]."<img src='http://www.google.ro".$imgs[2][$j]."' border='1'/></a><br>				
					<input type='checkbox' value='".$imgs[2][$j]."' name='check[]'/>Add
					</td>
				";
		
	
		}
		$j++;
	}
	
	echo "</tr>";
	$i=$j;
				
	if($i>=count($imgs[2]))break;
			
	}
	
	

}


?>
