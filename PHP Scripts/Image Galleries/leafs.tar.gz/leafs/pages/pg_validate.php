<?

session_check("01");


$db=new MySql(database_name,user,password);
	
$db->Connect();


$publics=@$_POST['publics'];
$del=@$_POST['del'];


if(isset($publics)){
	$i=0;
	foreach($publics as $value){

		preg_match("'([0-9]+)-([0-9]+)'",$value,$matches);
		$id=$matches[1];
		$public=$matches[2];
		if($public==1){
			$result=$db->Query("update ".TABLE_KEYWORDS." set public='$public' where id='$id'");
			if($result)
				$i++;
		}
	
	}
	if($i>0)
		echo "<blink>$i items are public now</blink>";
}



if(isset($del)){
	$i=0;
	foreach($del as $value){

		preg_match("'([0-9]+)-([0-9]+)'",$value,$matches);
		$id=$matches[1];
		$delete=$matches[2];
		if($delete==1){
			$result=$db->Query("delete from ".TABLE_KEYWORDS." where id='$id'");
			
			if(!$result)
				echo "Error deleting keyword";
			
			$result=$db->Query("select * from ".TABLE_IMG." where id_keyword='$id'");
			//delete fizic images
			while($r=mysql_fetch_array($result)){
				$image=$r['image'];
				if(!(@unlink("htmls/images/$image")))
					echo "Could not delete $image";
			}
			
			
			$result=$db->Query("delete from ".TABLE_IMG." where id_keyword='$id'");
			if(!$result)
				echo "Error deleting images from db";
			
			$i++;	
			}
				
	
	
	}
	if($i>0)
		echo "<br><blink>$i items deleted</blink>";
}





		$result=$db->Query("Select * from ".TABLE_KEYWORDS." where public='0' order by keywords ASC ");
		
		$___items=array();
		$count_k=0;
		while($r=mysql_fetch_array($result)){
				$count_k++;
				$__items[strtoupper($r['keywords'][0])][]=$r;
				}
				
				
		
		//imaginile care au nevoie de validare..tre sa le afisez keywordu
		//2 sunt de user..1 publice..0 folosite si de today
		$result=$db->Query("Select id_keyword from ".TABLE_IMG." where public='0'");
		$count=0;
		while($r=mysql_fetch_array($result)){
				$count++;
				$result1=$db->Query("Select * from ".TABLE_KEYWORDS." where id='".$r['id_keyword']."' and public=1");
				$r1=mysql_fetch_array($result1);
				$is=false;
				if(@count($__items[strtoupper($r1['keywords'][0])])>0)
				foreach($__items[strtoupper($r1['keywords'][0])] as $item)				
					if($item['keywords']==$r1['keywords'])
					{
						$is=true;
						break;
					}
					
				if(!$is && !empty($r1['keywords']))
						$__items[strtoupper($r1['keywords'][0])][]=$r1;
				
				
				}
						
				
		$i=0;
		$content='
		<form action="index.php" method="post">
		<input type="hidden" value="validate" name="page"/>
		<input type="hidden" value="save" name="step"/>
		
		<table align="center" width="800px" style="border-bottom:solid #AAAAAA;border-width: 2px;">
			<tr>
			
				<td colspan="2" style="border-bottom:solid #AAAAAA;border-width: 2px;">
					<h1>'.$count_k.' kewywords and..  </h1>
					<h3>'.$count.' images need validation</h3>
				</td>
				
			</tr>
			
			<tr>
			
				<td colspan="2" style="border-bottom:solid #AAAAAA;border-width: 2px;" align="left">
					<input type="submit" value="Apply"/>
				</td>
				
			</tr>
			';
		if(isset($__items))
		foreach($__items as $letter=>$items){
		$content.="<tr><td align='center' colspan='2' style='border-bottom:solid grey;border-width: 1px;'><font color='green'><h3>$letter</h3></font></td></tr>";
		$i=0;
		while(true){
		
				
		
					if($i>=count($items))break;
					
					$select="<select name='publics[]'>";
					
						$select.="<option value='".$items[$i]['id']."-2'>Make public?</option>";					
						if($items[$i]['public']==1)
						$select.="<option value='".$items[$i]['id']."-1' selected>yes</option>";
						else
						$select.="<option value='".$items[$i]['id']."-1'>yes</option>";
						
						$select.="<option value='".$items[$i]['id']."-0'>no</option>";
					$select.="</select>";
					
					$select_delete="<select name='del[]'>";
						$select_delete.="<option value='0-2'>Delete?</option>";
						$select_delete.="<option value='".$items[$i]['id']."-0'>no</option>";
						$select_delete.="<option value='".$items[$i]['id']."-1'>yes</option>";
					$select_delete.="</select>";
					
					
					$content.="<tr>";
					
					if($i<count($items)){
						$content.="<td><a href='index.php?page=images&id=".$items[$i]['id']."'>".$items[$i]['keywords']."</a>&nbsp;$select&nbsp;$select_delete</td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
					$i++;
					
					if($i<count($items)){
						$content.="<td><a href='index.php?page=images&id=".$items[$i]['id']."'>".$items[$i]['keywords']."</a>&nbsp;$select&nbsp;$select_delete</td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
						
						
					$i++;
					
						
				$content.="</tr>";
			
		}
		
		}
		$content.='
		
			<tr>
			
				<td colspan="2" style="border-bottom:solid #AAAAAA;border-width: 2px;" align="left">
					<input type="submit" value="Apply"/>
				</td>
				
			</tr>
		</table>
		
		
		</form>
		';
		echo $content;
		



?>
