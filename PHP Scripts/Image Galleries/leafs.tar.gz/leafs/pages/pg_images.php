<?

session_check("01");

$id=@$_GET['id'];




$db=new MySql(database_name,user,password);
		
$db->Connect();
		
$edit=@$_POST['edit'];
$cat=@$_POST['cat'];

if(empty($edit)){

$result=$db->Query("Select * from ".TABLE_KEYWORDS." where id='$id'");
$r=mysql_fetch_arraY($result);
$name=$r['keywords'];

$items=array();
$result=$db->Query("Select * from ".TABLE_IMG."  where id_keyword='$id'");
while($r=mysql_fetch_array($result)){
	$items[]=$r;
}

$i=0;
echo '
<form action="index.php" method="post" name="frm">
<input type="hidden" name="edit" value="edit"/>
<input type="hidden" name="page" value="images"/>
<input type="hidden" name="id" value="'.$id.'"/>
<input type="hidden" name="cat" value="'.$cat.'"/>
<table align="center" width="600px" style="border-bottom:solid #AAAAAA;border-width: 2px;">
			<tr>
				<td colspan="2" >
					<h1>Editeaza keywords ('.$name.')</h1>
					<input type="text" name="keyword" value="'.$name.'" size="50"/>
					<input type="submit" value="Save modifcations"/>
					<br>
					
					<br>	
					<a href="javascript:history.go(-1)">Back</a>	
							
					
				</td>
			</tr>';
		  

		$result=$db->Query("Select * from ".TABLE_CATEGORY);
		while($r=mysql_fetch_array($result)){
			$categs[]=$r;
		
		}


		//categoria
		// o selectez in functie de categ primului item
		$select="
		Category:<br>
		<select name='categ'>";	
				
		foreach($categs as $r){
			
			if($items[0]['id_categ']==$r['id'])
				$select.="<option value='".$r['id']."' selected>".$r['name']."</option>";
					else
				$select.="<option value='".$r['id']."'>".$r['name']."</option>";
					
			}
		
		$select.='</select>';	


		  $content="<tr>
		  <td style='border-top:solid #AAAAAA;border-width: 2px;' colspan='2'>
					    
		  <Br>
		  With
		  <input type=\"checkbox\" name=\"checkall\" onclick=\"checkUncheckAll(this,'check[]');\"/>selected<br>
		  <input type='submit' value='apply this action:'/>
		  <select name='action'>
			<option value='public'>Make public</option>
			<option value='private'>Make private</option>
			<option value='delete'>Delete</option>
			<option value='category'>Set selected category</option>
		  </select>
		  <br>
		  
		  $select
		  <Br>
		  <br>
		  </td></tr>";
			
		
		
		
		
		
					
		while(true){
				if($i>=count($items))break;
				
				$result=$db->Query("Select * from ".TABLE_CATEGORY." where id='".$items[$i]['id_categ']."'");
				$r=mysql_fetch_array($result);				
				$categ_id=$r['id'];
													
				if($items[$i]["public"]==1)
					$public=1;
					else
					$public=0;
				
				//public
				
				if($public==1){					
					$is_public="<font color='green'>Public</font>";
				}
				else{
					$is_public="Not public";
					}
								
				$hidden="				
				<input type='hidden' value='".$items[$i]['id']."' name='hiddens[]' />";
				
				
				
				$categ_name=$r['name'];
				$categ_id=$r['name'];
								
			
				
				if(!empty($items[$i]['description']))							
									$description=$items[$i]['description'];
									else
									$description="";
				//end description
				
				
    				//creator start					
				if(empty($items[$i]['creator']))
								$creator="<b>Creator</b>:-";
								else
									$creator="<b>Creator</b>:".$items[$i]['creator'];
				//end creator
									
				$content.="<tr>";
					
					if($i<count($items)){
						$content.="<td style='border-bottom:dotted #AAAAAA;border-width: 1px;'><img src='htmls/images/".$items[$i]['image']."'/>&nbsp;<font color='grey' size='-1'>
						<Br>
						<input type='checkbox' value='".$items[$i]['image']."' name='selected_items[]'/><br>
						$is_public<br>						
						<i>
						Description</i><br>
						<input type='text' name='descriptions[]' value='$description' size='36'/><Br>
						$creator<bR>						
						<Br>
						$hidden
						</td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
					$i++;
				
					
					
						
				if(@$items[$i]["public"]==1)
					$public=1;
					else
					$public=0;
				
				//public				
				if($public==1){
					
					$is_public="<font color='green'>Public</font>";
				
				}
				else{
					$is_public="Not public";
					
					}
				
				
				
			
				$hidden="				
				<input type='hidden' value='".@$items[$i]['id']."' name='hiddens[]' />";
				
						
				$result=$db->Query("Select * from ".TABLE_CATEGORY." where id='".@$items[$i]['id_categ']."'");
				$r=mysql_fetch_array($result);				
				$categ_id=$r['id'];
				
								
				if(!empty($items[$i]['description']))								
									$description=$items[$i]['description'];
									else
									$description="";
				//end description
				
				
				//creator start					
				if(empty($items[$i]['creator']))
								$creator="<b>Creator</b>:-";
								else
									$creator="<b>Creator</b>:".$items[$i]['creator'];
				//end creator
					
					
					
					if($i<count($items)){
						$content.="<td style='border-bottom:dotted #AAAAAA;border-width: 1px;'><img src='http://www.ro.today-news.info/pictures/images/".$items[$i]['image']."'/>&nbsp;<font color='grey' size='-1'>
						<br>
						<input type='checkbox' value='".@$items[$i]['image']."' name='selected_items[]'/><br>
						$is_public<br>						
						<i>
						Description</i><br>
						<input type='text' name='descriptions[]' value='$description' size='36'/><br>
						$creator<br>
						
						<br>
						$hidden
						</td>";
						
					}else
						$content.="<td>&nbsp</td>";
						
						
						
					$i++;
					
						
				$content.="</tr>";
			
		}
		
		$content.="<tr><td><a href='javascript:history.go(-1)'>Back</a></td><td align='right'><input type='submit' value='Apply actions'/></td></tr>";
		
		
		$content.="</table>
		</form>";
		echo $content;
		}
		
else{
	$n=$_POST['keyword'];
	$id=$_POST['id'];
	$selected_items=@$_POST['selected_items'];	
	$categ=$_POST['categ'];
	$action=$_POST['action'];
	$descriptions=$_POST['descriptions'];
	$hiddens=$_POST['hiddens'];
	
	
	
	
	$db->Query("update ".TABLE_KEYWORDS." set keywords='$n' where id='$id'");	
	
	if($action=="delete" && isset($selected_items))
	foreach($selected_items as $image){
		$db->Query("delete from ".TABLE_IMG." where image='$image'");
		//chmod("images/$image",0777);
		if(!@unlink("images/$image"))
			echo "<center><font color='red'>Warning!Could not delete file $image</font></center>";
	}
	
	
	
	if($action=="public" && isset($selected_items)){
	
		//mai intai se fac not public, pt ca in select mi se transmite numai ce am selectat.
		foreach($hiddens as $id){
		
			$db->Query("update ".TABLE_IMG." set public='0' where id='$id'");
				
		}
		foreach($selected_items as $image){
			
			$db->Query("update ".TABLE_IMG." set public='1' where image='$image'");
				
		}
	
	}


	if($action=="private" && isset($selected_items)){
	
		//mai intai se fac not public, pt ca in select mi se transmite numai ce am selectat.
		foreach($hiddens as $id){
		
			$db->Query("update ".TABLE_IMG." set public='1' where id='$id'");
				
		}
		foreach($selected_items as $image){
			
			$db->Query("update ".TABLE_IMG." set public='0' where image='$image'");
				
		}
	
	}

	
	//update description

	foreach($hiddens as $location=>$id){
		
		$descriptions[$location]=stripslashes($descriptions[$location]);
		
		$db->Query("update ".TABLE_IMG." set description='".$descriptions[$location]."' where id='$id'");
				
	}
	
	
	
	//setare categorie
	if($action=="category" && isset($selected_items))
	foreach($selected_items as $id){
		
		$db->Query("update ".TABLE_IMG." set id_categ='$categ' where image='$id'");
				
	}
	
	echo "
	<center>
	<blink>Modified</blink><br>
	<a href='javascript:history.go(-1)'>Go back</a>
	</center>
	";
		
	
	
	
}	

$db->Close();	
		
	