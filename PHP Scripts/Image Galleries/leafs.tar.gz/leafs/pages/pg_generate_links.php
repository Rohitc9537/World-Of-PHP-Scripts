<?
session_check("01");
GLOBAL $message;
GenerateRelating();

echo "<blink>Relating links generated</blink>";
?>