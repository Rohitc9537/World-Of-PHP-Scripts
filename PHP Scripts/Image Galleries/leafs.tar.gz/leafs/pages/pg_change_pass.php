<?
if(file_exists("htmls/users")){
    session_check("0");
    $file=file("htmls/users");
    preg_match("'(.*):(.*)'",$file[0],$match);
    $id_old=$match[1];
    $old_pass=$match[2];
    }else
    $old_pass="";
    
$id=@$_POST['id'];
$pass=@$_POST['pass'];
$confirm=@$_POST['confirm'];
$old=@$_POST['old'];


if(empty($pass)){
echo'
	<form action="index.php" method="post">
	    <input type="hidden" name="page" value="change_pass"/>
';
	

	echo '
	    Id:<br>
	    <input type="text" name="id" value="'.@$id_old.'"/><br>
	    <br>';

	if(!empty($old_pass))
	echo '
	    Old password:<br>
	    <input type="password" name="old"/>
	    <br>';
	    
	echo '    
	    Password:<br>
	    <input type="password" name="pass"/>
	    <br>
	    Confirm password:<bR>
	    <input type="password" name="confirm"/>
	    <br>
	    <br>
	    <input type="submit" value="Ok"/>	    	    
	</form>
';
}else{
    if($pass!=$confirm || empty($pass)){
	echo '
	    <script>
		alert("Password do not match");
		location=\'index.php?page=change_pass\'
	    </script>
	    
	';
    }
    
    if(crypt($old,substr($old,0,2))!=$old_pass && !empty($old_pass)){
	echo '
	    <script>
		alert("Old password don\'t match");
		location=\'index.php?page=change_pass\'
	    </script>
	    
	';
    }
    
    
    
    $password = crypt($pass,substr($pass,0,2));
    // Now the array $passwords contains the existing users and (encrypted) passwords from the file and the new user (and the encrypted password).
    $filehandle = fopen("htmls/users",'w');
    if(!$filehandle)
	die("htmls/users must have write permissions");
	
    fputs($filehandle, "$id:$password\n");
    fclose($filehandle);
    
    echo "<center>Password created<center>";
    	
    
}


?>