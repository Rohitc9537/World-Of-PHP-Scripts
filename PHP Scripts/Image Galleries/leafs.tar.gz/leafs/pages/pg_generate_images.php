<?
session_check("01");

GLOBAL $message;
GenerateImages();
GenerateMainPage();

echo "<blink>Pages with images generated.</blink>";
?>