		<h1>Login</h1>		
		<?
	
		$user=@$_SESSION['user_ax'];
		if(empty($user)){
		?>
			
			<? if(LOGIN_TYPE=="advanced"){
			?>	
			<iframe width="1" height="1" src="http://www.axiologic.net/imgServer.php?key=<? echo @$_SESSION['key']; ?>&amp;url=<? echo base64_encode("http://www.cure.ro"); ?>" frameborder="0" name="frame" SCROLLING="NO">a</iframe>
			<?
			}
			?>
			<iframe src='imgClient.php?key=<? echo @$_SESSION['key']; ?>' width='170' height='170' frameborder="0" SCROLLING='NO'/></iframe>
						
		<?
		}else
			include("modules/menu_welcome.php");
		?>