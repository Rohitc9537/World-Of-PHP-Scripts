<?




$db=new MySql(database_name,user,password);
		
$db->Connect();

$id=$_GET['id'];


			$result=$db->Query("delete from keywords where id='$id'");
			
			if(!$result)
				echo "Error deleting keyword";
			
			$result=$db->Query("select * from assoc_imgs where id_keyword='$id'");
			//delete fizic images
			while($r=mysql_fetch_array($result)){
				$image=$r['image'];
				if(!(@unlink("images/$image")))
					echo "Could not delete $image";
			}
			
			
			$result=$db->Query("delete from assoc_imgs where id_keyword='$id'");
			if(!$result)
				echo "Error deleting images from db";
			
			$i++;	
			


$db->Close();

	echo "
	<center>
	<blink>Deleted</blink><br>
	<a href='javascript:history.go(-1)'>Inapoi</a>
	</center>
	";

?>