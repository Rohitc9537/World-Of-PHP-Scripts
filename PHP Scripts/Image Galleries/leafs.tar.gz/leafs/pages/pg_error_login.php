<?

GLOBAL $message;

echo $message['error login'];
?>