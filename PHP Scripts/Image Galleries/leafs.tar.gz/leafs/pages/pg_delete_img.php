<?

session_check("01");


$db=new MySql(database_name,user,password);
	
$db->Connect();

$id=$_GET['id'];


	    
	    
$result=$db->Query("select * from ".TABLE_IMG."  where id='$id'");

$r=mysql_fetch_array($result);
						
$image=$r['image'];

	    if(!(@unlink("htmls/images/$image")))
			echo "Could not delete $image";
								    
						    
									    
$result=$db->Query("delete from ".TABLE_IMG." where id='$id'");
	if(!$result)
        	echo "Error deleting images from db";
    
															    
														
														
$db->Close();
												
echo "
	<center>
	    <blink>Deleted</blink><br>
	    <a href='javascript:history.go(-1)'>Inapoi</a>
	</center>
";

GenerateImages();
																		?>