<?
if(ALLOW_PUBLISH==true && USER_LOGIN==true && LOGIN_TYPE=="advanced")
    session_check();
    else
    if(ALLOW_PUBLISH==false)
        session_check("0");
    

//save

$db=new MySql(database_name,user,password);
$db->Connect();


GLOBAL $message;


$category=@$_GET['category'];
$description=@$_GET['description'];

$action=@$_GET['action'];

$submit="Add";

//delete
if($action=='delete'){
	
	$id=$_GET['id'];
	
	$sql="delete from ".TABLE_CATEGORY." where id='$id'";
	if($db->Query($sql))
		echo "<font color='red'>Deleted</font>.";
		else
			echo "Failed";
	

}
//edit
if($action=='edit'){

	$id=$_GET['id'];
	
	$sql="select *  from ".TABLE_CATEGORY." where id='$id'";
	
	$result=$db->Query($sql);
	
	$r=mysql_fetch_array($result);
	$category=$r['name'];
	$description=$r['description'];
		
	$submit="Modify";	
	
}


//make public
if($action=='public'){

	$id=$_GET['id'];
	
	$sql="update ".TABLE_CATEGORY." set public=1 where id='$id'";
	
	$result=$db->Query($sql);
	
	echo "<blink>Category is now public</blink>";
	
}



//make not public
if($action=='nopublic'){

	$id=@$_GET['id'];
	
	$sql="update ".TABLE_CATEGORY." set public=0 where id='$id'";
	
	$result=$db->Query($sql);
	
	echo "<blink>Category is no more public</blink>";
	
}



if(!empty($category) && empty($action)){
	
	$mode_edit=@$_GET['mode_edit'];

	if(empty($mode_edit)){

	$sql="select count(*) as result from ".TABLE_CATEGORY." where name='$category'";
	

	$result=$db->Query($sql);
	
	if(!$result)
	    echo "Db error.Make sure that you executed the install script!";

	$r=mysql_fetch_array($result);

	$result=$r["result"];

	if($result==0){
	
	
			if(getPermissions(HTTTP)=="Admin" || getPermissions(HTTTP)=="Moderator")
			    $public=1;
		    else 			
				$public=0;
	
			$sql="insert into ".TABLE_CATEGORY." values(0,'$category','$description','$public','".$_SESSION['user_ax']."')";
			@$db->Query($sql);
			echo "<center><font color='green'>Catgory inserted.<a href='index.php?page=categ'>Back</a></font></center>";
			GenerateMainPage();
			
	}else
	
	
	echo "<font color='red'>This category already exists</font>";
	}
	else
	{
	
		$sql="update ".TABLE_CATEGORY." set name='$category' where id='$mode_edit'";
		$db->Query($sql);
	
		$sql="update ".TABLE_CATEGORY." set description='$description' where id='$mode_edit'";
		$db->Query($sql);
		
		echo "<font color='green'>Category updated.<a href='index.php?page=categ'>Back</a></font>"; 
		GenerateMainPage();
	
	
	}
	
	
	
}else{
		
?>



<h1>New Category</h1>

<form action="index.php" method="get">
	<input type='hidden' value='categ' name='page'/>

	<b>Enter category:</b><br><br>
	<input type="text" name="category" value="<? echo $category; ?>"maxlength="255" size="25"/><br>
	<br>
	Description:<br>	
	<input type="text" name="description" value="<? echo $description; ?>" maxlength="255" size="25"/><br><br>
	<input type="submit" value="<? echo $submit; ?>"/>
	<?
	if($submit=="Modify"){
		$id=$_GET['id'];
		echo "<input type='hidden' name='mode_edit' value='$id'/>";
		}
	?>

</form>
<?
	//for admins&moderator display tools
	
	if(getPermissions(HTTTP)=="Admin" || getPermissions(HTTTP)=="Moderator" ){
	
	$sql="select * from ".TABLE_CATEGORY."";
	
	$result=$db->Query($sql);
	echo "<table border='0' width='90%' cellpadding='0'>
	<tr>
		<th align='left' style=\"background-color:#E3E1E1;border:1px solid black;\">
			Name
		</th>
		<th align='left' style=\"background-color:#C0C0C0;border:1px solid black;\">
			Description
		</th>
		<th align='left' style=\"background-color:#E3E1E1;border:1px solid black;\">
			Edit
		</th>
		<th align='left' style=\"background-color:#E3E1E1;border:1px solid black;\">
			Delete
		</th>
		<th align='center' style=\"background-color:#C0C0C0;border:1px solid black;\">
			Public
		</th>
		<th align='left' style=\"background-color:#E3E1E1;border:1px solid black;\">
			Created by
		</th>
	</tr>";
	while($r=@mysql_fetch_array($result)){
	
					$public=$r['public'];
					$creator=$r['creator'];
					
					if($public!=1){
					
						$display_public='&nbsp;<i><font color="red">not public</font></i>(<a href="index.php?page=categ&id='.$r['id'].'&action=public">make public</a>)';
						
					}
					else{
					
						$display_public="&nbsp;<i><font color='green'>public</font></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(<a href='index.php?page=categ&action=nopublic&id=".$r["id"]."'>make not</a>)";
						
					}
		echo "<tr>
					<td  align='left' style=\"background-color:#E3E1E1;\">
					<b>".$r['name']."</b>
					</td>
					<td  align='left' style=\"background-color:#C0C0C0;\">
					".$r['description']."
					</td>
					<td  align='left' style=\"background-color:#E3E1E1;\">
					<a href='index.php?page=categ&action=edit&id=".$r['id']."'>+</a>
					</td>
					<td  align='left' style=\"background-color:#E3E1E1;\">
					<a href='index.php?page=categ&action=delete&id=".$r['id']."'><font color='red'>x</font></a>
					</td>
					<td  align='left' style=\"background-color:#C0C0C0;\">
					$display_public
					</td>
					<td  align='left' style=\"background-color:#E3E1E1;\">
					&nbsp;$creator
					</td>
			  </tr>";
	}
	echo "</table>";
	
	}
	else{
	    
	    
	    if(getPermissions(HTTTP)!="Admin")
        	    echo "
	    	    <font color='red'><b>".$message['Note']."</b></font>".$message['Note message'];
	}
		
	
	
}
	$db->Close();
?>
