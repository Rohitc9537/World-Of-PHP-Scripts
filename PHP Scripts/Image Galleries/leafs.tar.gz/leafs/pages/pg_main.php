<?
GLOBAL $message;

if(file_exists("htmls/main_page.html")){

    include("htmls/main_page.html");
    
    }else{
	echo "<center>Main page isn't generated yet. Go to admin option, and choose Generate main page, or add some catgory to your album</center>";
    }
	
    

?>
