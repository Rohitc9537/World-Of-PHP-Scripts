<?
session_check("01");

$checks=$_POST['check'];
$keywords=$_POST['keywords'];
$id=trim($_POST['k']);
$cat=trim($_POST['cat']);
$description=trim($_POST['description']);

if(!file_exists("htmls/images"))
		@mkdir("htmls/images");

if(count($checks)>0){

	$db=new MySql(database_name,user,password);
	$db->Connect();
	
	
	
	$sql="select count(*) as no from ".TABLE_KEYWORDS." where keywords='$keywords'";
	$result=$db->Query($sql);
		
	$r=mysql_fetch_array($result);
	
	if($r['no']==0 || (!empty($id))){
	
	
	
	if(empty($id)){
		
		
		$sql="Insert into ".TABLE_KEYWORDS." values(0,'$keywords','1')";
		$db->Query($sql);

		$sql="select max(id) as max from ".TABLE_KEYWORDS."";
		$result=$db->Query($sql);
			
		$r=mysql_fetch_array($result);
			
		$id=$r['max'];
	}
	
	
	

	$step=0;
	foreach($checks as $check){
		
		//reading image 
		$handle = fopen("http://www.google.ro".$check, "rb");
		$contents = '';
		if($handle)
		while (!feof($handle)) {
		$contents .= fread($handle, 8192);
		}
		fclose($handle);
		
		$img_name=convert($keywords);
					
					
	
			
		$hold=$img_name;
		if(file_exists("htmls/images/$img_name.jpg")){
				while(1){
					$img_name=$hold.rand(1,1000).".jpg";
					if(!file_exists("htmls/images/$img_name"))
						break;
					}
						
		}else 
			$img_name=$img_name.".jpg";



		$filename=$img_name;
		$h=fopen("htmls/images/$filename","w");
		fwrite($h,$contents);
		fclose($h);
		
		

		$sql="Insert into ".TABLE_IMG." values(0,'$id','".$filename."','$cat','1','$description','".$_SESSION['user_ax']."')";
		if($db->Query($sql))
			echo "<center>Image $filename succesfuly inserted</center><br>";
		else
			 echo "error:".mysql_error();
		$step++;
		
		
	
	}
	
	GenerateImages();

		echo "<center><font color='green'><blink>Saved</blink></font><br><a href='javascript:history.go(-2)'>Back</a></center>";	
	
	}else
		echo "<center><font color='green'><blink>Keyword already exists</blink></font><br><a href='javascript:history.go(-2)'>back</a></center>";	
    
  
  $db->Close();
	
}



?>