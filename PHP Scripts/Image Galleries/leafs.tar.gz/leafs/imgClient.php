<?php
 session_start();
 include("../configs/settings.php");  
 include("../functions/functions.php");
 include_once("../Class/MySql.Class.php");
  ?>
 <html>
 <head>
 <meta http-equiv="Pragma" content="no-cache">
 <style>
body {
		margin-left: 0px;
		margin-top: 0px;
		margin-right: 0px;
		margin-bottom: 0px;
		background-color:#FFFFFF;
		}	
a{
	color: green;
	display:;
	font: 12px Arial, Helvetica, sans-serif;	
	display: inline;
	height: 5px;
	position: relative;
	text-decoration: none;
	margin: 0px;
	padding: 0px;
}
 </style>
 </head>
 <body>
 Please wait..
 <?	

  
 $key=$_GET['key'];


 
 echo "	
		<script>
			location='iframeClient.php?&key=".$key."'
		</script>
		";


	 ?>
	 
</body>
</html>
