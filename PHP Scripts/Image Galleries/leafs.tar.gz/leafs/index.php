<?php
session_start();


include("template_functions.php");
include("includes/functions.php");

require "configs/settings.php";
require "configs/config_mysql.php";
require "Class/MySql.Class.php";

//advanced login mode

if(LOGIN_TYPE=="advanced"){

    $db=new MySql(database_name,user,password);

    if(@$db->Connect()){

	if(empty($_SESSION['user_ax'])){
	    $sql="select user from ".TABLE_LOGIN." where user_key='".$_SESSION['key']."'";
    	    $result=$db->Query($sql);
	    if($result){
        	    $r=mysql_fetch_array($result);
		    $db->Close();	    
	    
                    //create random key for authentification	    
		    if(empty($r['user'])){
			$_SESSION['key']=md5(rand(1,10000).rand(1,10000));
	            }
	    }else{
		$email=EMAIL;
		if(!empty($email))
			sendError($email,mysql_error());
		}
	} 
    }
}
	


$currentFile=@$_GET['page'];

if(empty($currentFile))
$currentFile=@$_POST['page'];

if(empty($currentFile))
	$currentFile='main';
	
	
	
if(file_exists(LANG."/messages.php")){

	include(LANG."/messages.php");
	
	}else{
	
    	    die("<center>There is no language set, or the directory ".LANG." doesn't exist");
	    
	}

include("template.php");

if(@$_GET['err']==1)
    echo '
    <script>
	alert("Invalid user/password");
    </script>
    ';    
    
?>


