<link href="gallery.css" rel="stylesheet" type="text/css">
<?php
include("thumbs.php");
gallery("./images",5,150,150,1);
?>