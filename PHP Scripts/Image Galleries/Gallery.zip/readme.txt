PHP Dinamic Gallery

Author: Alessio Glorioso
e-mail: aleglori@gmail.com

use of the code it is completely free;

The author wishes that whichever improvement, change or the insertion in some other site are brought back to its address email that in any case remains the reference of the author.

- Guide -
1) include the file thumbs.php in the page in which the gallery is wanted to be created

2) recall the function gallery , that require this five parameters:
	a)directory of the originals images;
	b)number of images to visualize for every row;
	c)the maximum width in px of the thumbnails;
	d)the maximum height in px of the thumbnails;
	e)flag that it concurs to make to visualize the images resized also of 75% and of 50% respect the original;
3) Enjoy!

reference the attached example in index.php;

- Warning! -
To work, the script require PHP 4 with GD2 graphical library;

Script tested and working with following browser:
Firefox 1.0+
Opera 8
Internet Explorer 5.5+