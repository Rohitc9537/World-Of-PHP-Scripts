/*******************
  Copyright (c) 2004-2005 TinyWebGallery
  written by Michael Dempfle
  TWG version: 1.3c
********************/

LisezMoi - TinyWebgallery v1.3c

Merci d'aller sur le site Internet (Installation) pour avoir la documentation cpmpl�te (en Anglais)!

www.tinywebgallery.de.vu

De quoi avez vous besoin
-------------

php >= 4.3.0, gdlib > 2.0 et quelques jolies images.

Installation
------------

1. Extraire l'archive dans un r�pertoire
2. Adaptez le fichier config.php � vos besoins (vous pouvez le modifier � tout moment - Je vous recommande de le faire plus tard ;).
3. Copiez TWG sur le r�pertoire de votre serveur Internet.
4. Changez les permissions des r�pertoires 'cache', 'counter', 'xml' en 777 (chmod 777). 
   Vous devriez trouver la commande chmod (ou une fonction �quivalente) quelque part dans votre client FTP. 
   v�rifiez le 'howto' 1 (s�curit�) pour avoir une version plus s�re de TWG!
5. D�marrez TWG en demandant index.php.

-  Si vous avez des erreurs - v�rifiez si vous avez correctment d�fini les permissions d'acc�s aux r�pertoires. 
   Sur la page Internet il y a une FAQ et quelques 'howtos' (en anglais) - il est souhaitable de s'y reporter.
   Si TWG ne fonctionne toujours pas, vous pouvez contacter l'auteur sur le forum ou par courriel (en Anglais ou en Allemand).
-  Si les galeries de d�monstration fonctionnent vous pouvez copier vos images dans un r�pertoire situ� dans le r�pertoire 'pictures'.
   (Et effacer mes galeries  ;) - effacez/changez le fichier folder*.txt aussi!)
   TWG cache (stocke) beaucoup de fichiers. Merci de fermer votre navigateur pour mettre � jour le r�pertoire de cache.
-  Si vous voulez aider TWG merci de renvoyer l'ascenseur, cliquez sur une publicit� quelconque  du site Internet ou votez pour TWG (les liens sont sur le site Internet).
-  Si tout fonctionne parfaitement, allez sur le site et lisez les "howto's". 
   Il y a beaucoup de possibilit�s d'utiliser TWG de mani�re plus efficace. 

Si vous faites des changements de dimensions d'images dans le fichier config.php, vous devrez effacer les images situ�es dans le r�prtoire 'cache'.

Configuration
-------------

L'essentiel de ce que vous pouvez configurer dans TWG est d�crit dans l'aide et dans les 'howtos' 
(Lisez les - il y a beaucoup de choses que vous n'esp�riez pas!)
Si vous voulez modifier le script: N'h�sitez pas! Mais assurez vous que vous avez un lien vers la page Internet de TWG quelque part.

Amusez vous bien,

Michael Dempfle (tinywebgallery ( a t ) mdempfle . de)

www.tinywebgallery.de.vu