This folder has 2 modules for the great CMS Joomla/Mambo
Please go to http://www.joomla.de

- To integrate the whole gallery inside an iframe (I use the user1 areafor this on my layouts ;).)
- To display a random image (with slideshow function!)

The Modules where tested with Joomla 1.0.3 and 1.0.4
Just use the Joomla installer to install the modules.
By default they point to the TWG demo!

The component zip is a readme how to integrate TWG with the wrapper coming with Joomla!.

Have fun using TWG inside Joomla/Mambo.

/Michael