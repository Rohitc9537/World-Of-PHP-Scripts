To be able to save the smilies in the filesystem the follwing letters are exchanged:

: -> a
\ -> b
/ -> c
* -> d
| -> e
? -> f

Therefore you cannot use a,b,c,d,e (small letters for smilies !)

images that does contain an - are treated as duplicated and are not shown in the popup on the website.
Only the first 12 valid entries are shown there - but he rest is translated if present.