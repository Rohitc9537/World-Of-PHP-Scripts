The pictures folder ($basedir) of this two config files is "../pictures" 
- if you use these configs please change this back to "pictures".  
The htm files can be copied into the main directory. See the howto's.   
-  
The .htaccess file is an example how to protect your files. 
Change the domain in the file and copy the file to the 
directory you want to protect. 
Please do not ask me about details about how to use the htacess 
file properly. Ask google or wikipedia or... There are many good explanations out there. 
-  
the are some style sheet in this folder. The name is a short description how they look like 
rename the one you want to test to style.css an copy it in a album folder (dont't overwrite  
the main style.css in the main folder !) or use it as my_style.css for all albums (read howto 9) -  
