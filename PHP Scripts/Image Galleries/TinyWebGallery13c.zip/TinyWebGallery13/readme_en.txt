/*******************
  Copyright (c) 2004-2005 TinyWebGallery
  written by Michael Dempfle
  TWG version: 1.3c
********************/

Readme - TinyWebgallery v1.3c

Please go to the web site (Installation) for the full english documentation!

www.tinywebgallery.de.vu

What you need
-------------

php >= 4.3.0, gdlib > 2.0 and some nice pictures.

Installation
------------

1. Extract the archive to a directory
2. Adapt the config.php to your needs (you can change this anytime - I recommend to do his later ;).
3. Copy TWG to your web server.
4. Change the permissions of cache, counter, xml to 777 (chmod 777). 
   You should be able to find chmod somewhere in your FTP client. 
   check howto 1 to make TWG more secure later!
5. Start TWG by calling index.php.

-  If you get any errors - please check if you have set the permissions right. 
   On the web page is a FAQ and a some howtos - check them.
   If TWG still does not work just contact me (forum or email).
-  If the demo gallery works you can copy your images into the pictures directory.
   (And delete mine ;) - delete/change the folder*.txt too!)
   TWG does lots of caching. Please close your browser to refresh the cache.
-  If you want to support TWG please give feedback, click on some ad's on the website or
   vote for TWG (links are on the website).
-  If everything is running please go to the website and read the howto's. 
   There are many posibilities, to use TWG better and more effective. 

If you make any changes at file sizes in the config.php you have to delete the images
in the cache directory.

Configuration
-------------

The most stuff you can configure in TWG is described in the help and the howtos 
(Read them - there is lots of stuff you don't expect!)
If you want to modify the script: Go ahead. But please make sure that you have 
a link to the TWG homepage somewhere.

Have fun,

Michael Dempfle (tinywebgallery ( a t ) mdempfle . de)

www.tinywebgallery.de.vu