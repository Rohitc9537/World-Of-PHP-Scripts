
|Sgal 2
|(c)Adrian Wisernig 2005
|For help or more scripts go to:               
|http://www.statc.net                                          
You can use this script for free as long as you don't remove the Powered by Sgal link at the bottom of the gallery pages.
Updates in this version:
-xml based captions
-thumbnails created dynamicly(less bandwidth used).
-captions retrieved in a much more efficent way.
-when image is deleted so is caption.
-better looking display.
Instructions for Instalation:
1)Upload the folder.
2) Make sure permissions to folder are 777.
3)Run install.php and delete it after.
4)Upload all images using admin.php or directly into the images folder.
5)Enjoy.

For support or to report bugs  email: ajay@statc.net
