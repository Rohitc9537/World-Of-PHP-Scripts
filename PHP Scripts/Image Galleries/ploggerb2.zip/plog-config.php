<?php
// this is the file used to connect to your database.
// you must change these values in order to run the gallery.
define("PLOGGER_DB_HOST","");
define("PLOGGER_DB_USER","");
define("PLOGGER_DB_PW","");
define("PLOGGER_DB_NAME","");
?>
