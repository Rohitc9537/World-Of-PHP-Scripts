

1.) Upload all your files into your chosen directory.
2.) Remove the sample images and replace them with your own.
3.) Open up config.php and change the values for the max width and max height.
4.) Open up config.php and change the display method to 1 for proportional or 2 for fixed.
5.) If the "fixed" display method is chosen, alter the Fixed Position in the config.php file
6.) Alter the num_rows and num_cols variables to suit your needs
7.) View index.php