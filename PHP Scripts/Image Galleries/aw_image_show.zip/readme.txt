Aw Image Show

Unzip, upload to server. Aw Images Show was created for active worlds tv station owners to sort 
through a directory of images and output to a text file as an array or have the 
images names displayed line by line to be compatable with the awdigie program 
or other tv scripts. 

Features: Filter images by image size, file size, image type or the modified date.
In the list of images you may define weather to show the images properties or not, define the how many 
horizontal images should be on a line, and show only results from the filterd settings or not.

Created by Pineriver
http://vmist.net/activeworlds/awscripts/