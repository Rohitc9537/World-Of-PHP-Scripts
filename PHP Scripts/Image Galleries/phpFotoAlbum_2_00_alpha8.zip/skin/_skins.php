<?php
/*
****************************************
*   DEFINICE SKIN� / SKIN DEFINITION   *
****************************************
 $skin[$dir] = $name;
   "$dir"
    - Adres��, kde je skin um�st�n
	- Skin directory
   "$name"
    - Zobrazovan� jm�no skinu
	- Skin name
*****************************************
*/
$skin["default"]="default";
$skin["lite"]="lite";
?>