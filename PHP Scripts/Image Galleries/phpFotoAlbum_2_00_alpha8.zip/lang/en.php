<?php
    ///////////////////////////////////////////////////////
   //            phpFotoAlbum2 language file            //
  //                        ---> EN <---              //
 //      made by FILYA (����)      filia@inbox.ru   //
/////////////////////////////////////////////////////
$content_type="<meta http-equiv=\"content-type\" content=\"text/xhtml; charset=windows-1251\" />\n";
$content_language="<meta http-equiv=\"content-language\" content=\"en\" />\n";
$str["date_format"]="d.m.Y H:i:s";

$str["menu_show"]="View as";
$str["menu_show_list"]="List";
$str["menu_show_thumb"]="Thumbnails";

$str["menu_sort"]="Sort by";
$str["menu_sort_name"]="Name";
$str["menu_sort_type"]="Type";
$str["menu_sort_time"]="Time";
$str["menu_slideshow"]="slideshow";
$str["menu_setup"]="Setup";

$str["menu_asc"]="Ascending";
$str["menu_desc"]="Descending";

$str["menu2_prev"]="Previous";
$str["menu2_next"]="Next";
$str["menu2_up"]="[ BACK ]";
$str["menu2_exit"]="Exit";

$str["dir"]="Folder";
$str["list_root"]="[ . ]";
$str["list_up"]="[ .. ]";
$str["list_unknown"]="-???-";
$str["count"]="Total folders: %1, total files: %2 (%3)";

$str["setup"]="Setup";
$str["setup_skin"]="Skin:";
$str["setup_lang"]="Language:";
$str["setup_res"]="Resolution:";
$str["setup_quality"]="Quality:";
$res["orig"]="original";
$res["640x480"]="small (640x480)";
$res["800x600"]="average (800x600)";
$res["1024x768"]="large (1024x768)";
$res["1280x1024"]="extra (1280x1024)";
$str["setup_submit"]="Submit";

$str["download_full_res"]="Download in full resultion.";

$str["error_working"]="This function can't be done ...";
$str["error_dir"]="Wrong address !!!";
$str["error_listing"]="Wrong listing method ...";
?>