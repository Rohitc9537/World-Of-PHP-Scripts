<?php
/*
*****************************************
*          LANGUAGE DEFINITION          *
*****************************************
 $lang[$dir] = $name;
   "$dir"
    - Soubor,ve kter�m je definice jazyka um�st�na
	- Language file name
   "$name"
    - Zobrazovan� jm�no
	- Language name
******************************************
*/
$lang["en"]="English";
$lang["cz"]="Czech";
?>