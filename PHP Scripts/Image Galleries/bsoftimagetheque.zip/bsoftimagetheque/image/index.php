<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body class="defaultpage" onload="javascript:window.location='../index.php';">
<script language="JavaScript" type="text/javascript">
window.location="../index.php";
</script>
</body>
</html>