<?

// top title of home page
$textintrohaut = "BSoftImageTheque Demo";

// bottom text of home page
$textintrobas = "Choose what you want from the top menu";

// the name of the top menu title
$topic1 = "Browse by category : ";
$topic2 = "Browse by iptc keyword : ";


// number of pic per topic page
$PnimapageTH = 30;

// number of pic per page
$Pnimapage = 30;

// the iptc keyword (IPTC Keyword search is case sensitive!)
// don't forget to increase the first number th[X][]
$th[0][0] = "nuit";  // keyword name in picture
$th[0][1] = "By Night";  // name for printing on home page
$th[1][0] = "NB";  
$th[1][1] = "Black & White";  
$th[2][0] = "jour";  
$th[2][1] = "By Day";  
$th[3][0] = "jardin";  
$th[3][1] = "Garden";  

?>