<?php

/**
 * End of template. Footer.
 * 
 * @package template 
 */

echo <<<HEREDOC
<!-- face_end BEGIN -->
<address>Powered by <a href="http://yapig.sourceforge.net" title="Yet Another PHP Image Gallery">YaPig</a> V$VERSION</address>
</body>
<!-- face_end END -->
</html>
HEREDOC;

?>      	
	
