<?php

/**
 * This module adds a comment file in  $gid_dir . $gid . "_" .$phid file
 *
 * Each File will have this format if $SEPARATOR=":";
 *
 *     title:author:date:email:web:message\n
 *
 * if a message contains "\n" character, it will be replaced with "<br />"
 *
 * The variables receives by the form (POST):
 * 
 * -> integer $gid  the gid of the gallery
 * -> interger $phid  the phid of the image
 * -> string $tit title of the comment
 * -> string $author author name 
 * -> string $mail comment authoer email
 * -> string $web comment author web
 * -> string $msg comment itself
 * 
 * @package user 
 */

/**
 * Includes config file and common functions files
 */
include('config.php');
include('functions.php');


/**
 * Logs some information about the person who makes the comment
 *
 * This information will be stored in a file whith this format:
 *
 *  date <Separator> author <separator> IP <separator> Browser
 *
 * @global $SEPARATOR used to separate fields
 * @global $REMOTE_ADDR remote IP
 * @global $HTTP_USER_AGENT browser string
 *
 */

function logger($LOG, $aut) {
   global $SEPARATOR,$_SERVER;

   if (($fp=@fopen($LOG,"a+"))==NULL) {
      return(false);
   }
    $fecha=date("M d, Y H:i:s",time());
    $linea= $fecha . $SEPARATOR . $aut . $SEPARATOR . 
      $_SERVER['REMOTE_ADDR'] . $SEPARATOR . $_SERVER['HTTP_USER_AGENT'];
    //Debug Lines
    //echo "<br /> linea logger: " . $linea;
    fputs($fp, $linea . "\r\n");
    fclose($fp);
} //end log


// ############################ MAIN PROGRAM #################

$gid=$_GET['gid'];
$phid=$_GET['phid'];


$tit=$_POST['tit'];
$aut=$_POST['aut'];
$mail=$_POST['mail'];
$web=$_POST['web'];
$msg=$_POST['msg'];

//Check arguments in form. gid and phid are required.
if (!is_int((int)$gid) || !is_int((int)$phid)) {
  error(_y("Incorrect add comment form"));
}
//Now check required arguments
$error=false;

if ( ((!isset($tit))||(strlen($tit)==0))&&$REQ_IN_COMMENTS['title'] ){
    template('face_begin');
    warning(_y("Title field required"));
    $error=true;
}
if ( ((!isset($aut))||(strlen($aut)==0))&&$REQ_IN_COMMENTS['author'] ){
    if (!error) template('face_begin');
    warning(_y("Author field required"));
    $error=true;
}
if ( ((!isset($mail))||(strlen($mail)==0))&&$REQ_IN_COMMENTS['email'] ){
   if (!error) template('face_begin');
    warning(_y("Email field required"));
    $error=true;
}
if ( ((!isset($web))||(strlen($web)==0))&&$REQ_IN_COMMENTS['web'] ){
    if (!error) template('face_begin');
    warning(_y("Website field required"));
    $error=true;
}
if ( ((!isset($msg))||(strlen($msg)==0))&&$REQ_IN_COMMENTS['comment'] ){
    if (!error) template('face_begin');
    warning(_y("Comment field required"));
    $error=true;
}

if($error){
    error(_y("Some required fields were not filled in."));
}

if (!($dir=get_data($GID_DIRS, $gid))) error("Gallery does not exist.");

$gid_dir= $BASE_DIR . $dir;

$comments_file= $gid_dir . $gid . "_" . intval($phid);

if(!($fp=@fopen($comments_file,"a+")))
  error ("Comment file error.");

  //We add the date to post.
  $_POST['date']=date("M d, Y H:i:s",time());
  $linea=construct_comment_line($_POST);

if (filesize($comments_file)==0) {
    fputs($fp,$linea);
}
  else {
    fputs($fp,"\r\n" . $linea);
  }

// echo $linea . "<br />";//debug Line
  fclose($fp);
  logger ($SECURE_DIR . "messages.log", $aut);

//Stats

add_listed_visit($gid_dir . $PHID_COMMENTS, $phid);

//Prepare variables to Show Message


$D_TITLE=htmlspecialchars($tit);
$D_AUTHOR=htmlspecialchars($aut);;
$D_MAIL=htmlspecialchars($mail);;
$D_WEB=htmlspecialchars($web);
$D_MESSAGE=htmlspecialchars($msg);
$D_REFRESH_URL="view.php?gid=$gid&phid=$phid";



$I_THANKS=_y("Thank you for your contribution");
$I_ADDED=_y('Added this comment');
$I_TITLE=_y('Title');
$I_AUTHOR=_y('Author');
$I_EMAIL=_y('Email');
$I_WEB=_y('Website');
$I_MESSAGE=_y('Comment');
$I_IF_NOT_REFRESHED=_y('If the page is not automatically refreshed.');
$I_PRESS_HERE=_y('Press here');




include ($TEMPLATE_DIR . "thanks_comment.php");

$I_GALLERY=_y("Gallery");
include($gid_dir . $GID_INFO_FILE);
$D_GALLERY=$gid_info['title'];
$D_LINK= $_SERVER['HTTP_REFERER'];
$D_UA=$_SERVER["HTTP_USER_AGENT"];
$D_IP=$_SERVER["REMOTE_ADDR"];
//this file contains $mail_content variable. 
include($TEMPLATE_DIR . "mail_comment.php");

$subject=_y('[Yapig comment] ') . $tit;

//Mail content if possible
if ($MAIL_ON_COMMENT && ($ADMIN_EMAIL!=$DEFAULT_EMAIL)) {
    if (is_array($ADMIN_EMAIL)) {
	foreach ($ADMIN_EMAIL as $email)
	  $to.= $email. ',';
    }
    else $to=$ADMIN_EMAIL;
    
    mail($to,$subject, $mail_contents);
     //echo "<h1>Mail Sent! $to</h1>"; //Debug Line
}


?>
