author-artem kalinchuk
website-http://hostrs.com
email-artem9@gmail.com
questions? go here > http://hostrs.com/forum/index.php
demo > http://hostrs.com/picphp/index.php

-------------------------------------------------------------------------------
1.Open config.php, and change the variables $HOST, $DBNAME, $DBUSER, $DBPASS -> to connect to the mysql database.
2.save changes.
3.Change the permissions of the folder 'pictures' to read/write/execute(If its ftp, you can just right click on it and click properties).
4.Open setup.php in your web browser, follow the instructions, after the setup is complete, delete setup.php.

-------------------------------------------------------------------------------

if you have any questions you can email me at artem9@gmail.com or post in the forum.