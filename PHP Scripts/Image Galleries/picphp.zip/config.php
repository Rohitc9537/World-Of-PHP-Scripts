<?php
$DBHOST = "localhost";   //mysql host name
$DBUSER = "";            //database username
$DBPASS = "";            //database password
$DBNAME = "";            //database name
require("dbconnection.php");
?>