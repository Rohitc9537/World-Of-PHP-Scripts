<?php
echo "<br><br><br><br><center>";
echo "<table border=2 bordercolor=red><tr><td><img src=pictures/" . $_GET['id'] . "></td></tr></table>";
echo "</center>";
?>