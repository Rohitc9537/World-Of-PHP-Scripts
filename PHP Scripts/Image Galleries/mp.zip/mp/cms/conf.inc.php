<?php

/* applicaiton-wide configurations */
$urlRoot = 'http://www.riceball.com/';

?>
