<? include('j_oocms.inc.php'); ?>
<? include('nav.inc.php'); ?>
<h1>areas</h1>
<ul>
	<li><a href=gallery.php>Gallery</a></li>
</ul>

<? include('nav.inc.php'); ?>
