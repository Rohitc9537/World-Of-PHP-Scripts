<div align=center style="background-color: silver; padding: 8px;">
<a href=index.php>Home</a>
::
<a href=gallery.php>Gallery</a>
</div>
