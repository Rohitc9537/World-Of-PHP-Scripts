Installation: 
1. Upload all files and folders
2. CHMOD ImgUpload main directory to 0777
3. CHMOD mysql_data.db.php to 0777
4. Run the installer and select normal mode

Alternative Installation:
If you are expierencing problems with the normal installer, do the following:
1. Open mysql_data.db.php in a text editor and fill out the information as required.
2. Upload all files and folders
3. CHMOD ImgUpload main directory to 0777
4. CHMOD mysql_data.db.php to 0777
5. Run the installer and select alternative mode


Error report:
If you find any other errors or bugs with ImgUpload, please report them to darthsidious666@gmail.com

Credits:
Template: gsvnet01 | zeonfx.com
Coder: hellscythe | hellscythe.net
