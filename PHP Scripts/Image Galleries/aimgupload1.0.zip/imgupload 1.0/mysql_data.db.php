<?php
$mysqluser = ""; // mysql username
$mysqlpass = ""; // mysql password
$mysqlhost = ""; // mysql host
$mysqldb = ""; // mysql database
?>