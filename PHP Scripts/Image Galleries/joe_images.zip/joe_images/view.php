<?php
require "config_connect_functions.php";

headerPrint();
viewPhotos("4", "1", "1", "");
footerPrint();

?>