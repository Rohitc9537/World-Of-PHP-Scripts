<?php
//******************************//
//     PhotoAlbum Lang file     //
//         ---> CZ <---         //
//******************************//
define("pa_charse", "windows-1250");
define("pa_lang_code", "cs");
define("pa_date_format", "d.m.Y H:i:s");
// TEXTy
define("pa_txt_loading", "Aplikace se na��t�, pros�m po�kejte...<br /><br /><small>(Pro spr�vnou funk�nost aplikace je nutn� povolit JavaScript)</small>");
define("pa_txt_loading_dir", "Na��t�m obsah adres��e...");
define("pa_txt_no_images_in_dir", "V adres��i nejsou ��dn� obr�zky.");
define("pa_txt_yes", "ano");
define("pa_txt_no", "ne");
define("pa_txt_slideshow", "SLIDESHOW");
define("pa_txt_slideshow_is_disabled", "Slideshow je zak�z�na nastaven�m fotogalerie.");
define("pa_txt_slideshow_time", "Interval mezi obr�zky");
define("pa_txt_slideshow_time_depend_on_conn_speed", "tento �as se m��e prodlou�it v z�vislosti na rychlosti p�ipojen� k internetu.");
define("pa_txt_slideshow_fullscreen", "Zobrazit p�es celou obrazovku");
define("pa_txt_slideshow_start", "spustit");
define("pa_txt_slideshow_stop", "zastavit");
define("pa_txt_imginfo", "OBR�ZEK");
define("pa_txt_lang", "JAZYK");
define("pa_txt_about", "O APLIKACI");
define("pa_txt_fullscreen", "cel� obrazovka");
define("pa_txt_date", "datum");
define("pa_txt_author", "autor");
define("pa_txt_file_size", "velikost");
define("pa_txt_image_resultion", "rozli�en�");
define("pa_txt_image_link", "Trval� odkaz na obr�zek");

define("pa_txt_image_exif_camera", "fotoapar�t");
define("pa_txt_image_exif_exposure_time", "doba expozice");
define("pa_txt_image_exif_fnumber", "clona");
define("pa_txt_image_exif_focal_length", "ohniskov� vzd�lenost");
define("pa_txt_image_exif_iso", "citlivost (ISO)");
define("pa_txt_image_exif_flash", "blesk");

define("pa_txt_homepage", "v�ce informac� naleznete na");
define("pa_txt_close_window", "ZAV��T OKNO");
define("pa_txt_poweredby", "Pou��v�");
define("pa_txt_select_lang", "Zvolte si jazyk");
?>