; singapore secret configuration file <http://singapore.sourceforge.net>
;
; <?php die("The contents of this file are hidden"); ?>
;
; these options are hidden from web users

[SQL]
;
; settings relevant to all the SQL backends. 
; You may ignore these if you are not using this backend.
;

sql_user = 
sql_pass = 