
<div id="footer"><p>
  <?php echo $sg->allRightsReserved() ?>
  <br />
  <?php echo $sg->poweredByVersion() ?> 
  <?php echo $sg->scriptExecTimeText() ?>
</p></div>

</body>
</html>
