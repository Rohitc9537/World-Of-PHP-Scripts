
<div id="footer"><p>
  <?php echo $sg->allRightsReserved(); ?>
  <?php echo $sg->copyrightMessage(); ?>
  <br />
  <?php echo $sg->poweredByVersion(); ?> 
  <?php echo $sg->scriptExecTimeText(); ?> |
  <?php echo $sg->adminLink(); ?>
</p></div>

</body>
</html>
