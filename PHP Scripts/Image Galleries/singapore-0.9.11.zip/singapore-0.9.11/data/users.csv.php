<?php die("The contents of this file are hidden"); ?>username,md5(pass),permissions,group(s),email,name,description,stats,
admin,5f4dcc3b5aa765d61d8327deb882cf99,1024,"","","Administrator","Default administrator account",""
guest,5f4dcc3b5aa765d61d8327deb882cf99,0,"","","Guest","Restricted use account for guests who do not have a user account",""
