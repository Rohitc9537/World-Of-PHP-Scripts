iScramble
---------

iScramble homepage: http://www.z-host.com/php/iscramble


COPYRIGHT/LICENSE NOTICE
------------------------

Copyright 2003 Ian Willis. All rights reserved.

This script is free to use. A small donation
would be much appreciated and encourage me to put more effort into developing
iScramble and other scripts further. For more information on making a donation, please visit the
following web page:

     http://www.z-host.com/php/iscramble/donate.php

This script may be edited/changed as long as you don't remove any copyright
statements. By using this script you agree to take full responsibility for it.
Ian Willis and Z-Host are in no way accountable for any damage caused.

Reselling or distributing this code without prior written consent is expressly
forbidden.
