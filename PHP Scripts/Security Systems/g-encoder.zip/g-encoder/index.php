<?php
header("Location: g-encoder.php");
?>