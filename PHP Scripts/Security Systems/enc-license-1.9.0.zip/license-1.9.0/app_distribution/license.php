<?php 
## +-----------------------------------------------------------------------+
## | BTT-License [TM] :.:.: License Distribution                   		   |
## +-----------------------------------------------------------------------+
## | Copyright (c)1998 - 2005 BTT Scripts Inc.				               |
## +-----------------------------------------------------------------------+
## | This source file is subject to the BTT Scripts Inc. End User License  |
## | Agreement (EULA), that is bundled with this package in the file       |
## | LICENSE, and is available at through the world-wide-web at            |
## | http:
## | If you did not receive a copy of the BTT Scripts Inc. license and are |
## | unable to obtain it through the world-wide-web, please send a note    |
## | to license@btt-scripts.com so we can email you a copy immediately.    |
## +-----------------------------------------------------------------------+
## | Authors: BTT Scripts Inc. <bttsoft@btt-scripts.com>     			   |
## | Support: http:
## | Questions? bttsupport@btt-scripts.com                                 |
## +-----------------------------------------------------------------------+
## | BTT, BTT-Crypt, BTT-Support, BTT-Bill, BTT-Web, BTT-Panel, BTT-Bugs,  |
## | BTT-News , BTT-AdCenter , BTT-LiveOnline , BTT-License, and BTT-Faq   |
## | are trademarks of BTT Scripts Inc. BTT Scripts is a subdivision of    |
## | BTT-Hosting Inc. All rights reserved and enforced.                    | 
## +-----------------------------------------------------------------------+
## [EDIT AND ENTER THE LICENSE INFORMATION RECEIVED]
## -------------------------------------------------
$licCode = '60N706463A-8484146037-Q6P0776606-QP7N6R81P9-66Q13084Q9';
$licName = 'Demo User';
$licDomain = 'demo.com';
$licCompany = 'Demo User Inc.';
$licDatabase = 'no database';
$digital1 = 'B8E00E72F8';
$digital2 = '-418050816';
$digital3 = 'MTNiNzhlNTk3Nz';
$digital4 = '1646b795efee1a';
$digital5 = '390d7be346fe0b';

?>