<?
## This is your License Key copy this
## and save as license.php
$licCode = "2130S6N60A-N4643068S9-26S1S09636-Q4NN8O9O3P-S750499N4S";
$licName = "Cindy A Neeley";
$licDomain = "btt-scripts.com";
$licCompany = "BTT-Scripts Inc.";
$licDatabase = "license";
$digital1 = "6FC84888F7";
$digital2 = "1301148504";
$digital3 = "NDJmYjMzMWFiNW";
$digital4 = "582ecd37775c16";
$digital5 = "73e1be4a4a1e1e";

?>