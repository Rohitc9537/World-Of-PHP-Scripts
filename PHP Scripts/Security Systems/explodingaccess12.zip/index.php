<?php include('restrict.php');?>
<HTML>
<BODY>
Hey there, welcome to the restricted area, you must have logged in else you couldn't see this!!
</BODY>
</HTML>