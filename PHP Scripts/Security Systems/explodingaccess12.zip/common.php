<?php // common.php

function error($msg) {    
	?>
	<html>
	<head>    
	<script language="JavaScript">    
	<!--        
		alert("<?=$msg?>");        
		history.back();    
	//-->    
	</script>    
	</head>    
	<body>    
	</body>    
	</html>    
	<?    
	exit;
}
?>