// -----------------------------------------------------------------------------
//
// phpFaber CMS v.1.0
// Copyright(C), phpFaber LLC, 2004-2005, All Rights Reserved.
// E-mail: products@phpfaber.com
//
// All forms of reproduction, including, but not limited to, internet posting,
// printing, e-mailing, faxing and recording are strictly prohibited.
// One license required per site running phpFaber CMS.
// To obtain a license for using phpFaber CMS, please register at
// http://www.phpfaber.com/i/products/cms/
//
// 09:03 PM 08/21/2005
//
// -----------------------------------------------------------------------------

Module: GeoIP
Version: 1.0

This module lookups the country by IP Address.

To download a free GeoIP Standard Country database, go to
http://maxmind.com/download/geoip/database/

or just download this file:
http://www.maxmind.com/download/geoip/database/GeoIP.dat.gz

And then extract this file here:
/cms_main/modules/GeoIP/templates/GeoIP.dat
