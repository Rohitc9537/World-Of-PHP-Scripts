A uselful script that takes ip of the user and returns to the user, from which country he belongs to.
Requires no database.