
------------------------------------------------------------------------------
  PHP .NAME WHOIS SCRIPT v1.0
------------------------------------------------------------------------------

 Freelance Web Developer and  PHP, Perl and Javascript programming
Web:  www.stevedawson.com
Written by Steve Dawson   

-------------------------------------------------------------------------------
  INSTALLATION
-------------------------------------------------------------------------------

This PHP Whois works only for the .name extension which is run
by the Global Name Registry. www.nic.name
To use the script as is, call it by copying and pasting the following code
into your page:

<?PHP include"namesearch.php"; ?>

CUSTOM INSTALLATION:
If you would like this script installed seamlessly into your existing website
contact me at www.stevedawson.com with your requirements.

-------------------------------------------------------------------------------
  About the .NAME Extention
-------------------------------------------------------------------------------

A .name domain can follow either of these formats:
firstname.lastname.name or lastname.firstname.name

You can also use your initials or nicknames instead of your first names.
More info can be found at www.nic.name

THIS SCRIPT IS AS IS. UNDER NO CIRCUMSTANCES CAN I BE HELD
RESPONSIBLE FOR ANYTHING TO DO WITH THIS SCRIPT OR ANYTHING
ELSE THAT HAPPENS IN THIS WORLD.

###########  END ##############