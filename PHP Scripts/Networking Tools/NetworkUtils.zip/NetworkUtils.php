<html>

<head>
<title>Network Utils</title>
</head>

<body bgcolor="#FFFFFF" link="#0000FF" vlink="#800080" alink="#FF0000">


<form method="POST" action="NetworkUtilsResults.php" name="WhoisSubmit">
  <div align="center"><center><table border="1" cellpadding="5" cellspacing="0" width="80%"
  bordercolor="#FFFFFF" bgcolor="#eaeaff">
    <tr>
      <td width="50%" align="right"><font face="Arial" size="2">Select a Whois server</font></td>
      <td width="50%"><select name="D1" size="1">
        <option value="whois.alabanza.com">whois.alabanza.com</option>
        <option value="whois.compuserve.com">whois.compuserve.com</option>
        <option value="whois.discount-domain.com">whois.discount-domain.com</option>
        <option value="dns411.com">dns411.com</option>
        <option value="whois.domaindiscover.com">whois.domaindiscover.com</option>
        <option value="whois.domainpeople.com">whois.domainpeople.com</option>
        <option value="whois.easyspace.com">whois.easyspace.com</option>
        <option value="whois.enom.com">whois.enom.com</option>
        <option value="whois.geektools.com">whois.geektools.com</option>
        <option value="whois.ibm.com">whois.ibm.com</option>
        <option value="whois.internetnamesww.com">whois.internetnamesww.com</option>
        <option value="whois.names4ever.com">whois.names4ever.com</option>
        <option value="whois.namesecure.com">whois.namesecure.com</option>
        <option value="whois.networksolutions.com" selected>whois.networksolutions.com</option>
        <option value="whois.pacbell.com">whois.pacbell.com</option>
        <option value="whois.register.com">whois.register.com</option>
        <option value="whois.registrars.com">whois.registrars.com</option>
        <option value="whois.sunquest.com">whois.sunquest.com</option>
        <option value="whois.berkeley.edu">whois.berkeley.edu</option>
        <option value="www.binghamton.edu">www.binghamton.edu</option>
        <option value="finger.caltech.edu">finger.caltech.edu</option>
        <option value="csufresno.edu">csufresno.edu</option>
        <option value="csuhayward.edu">csuhayward.edu</option>
        <option value="csus.edu">csus.edu</option>
        <option value="whois.cwru.edu">whois.cwru.edu</option>
        <option value="cc.fsu.edu">cc.fsu.edu</option>
        <option value="directory.gatech.edu">directory.gatech.edu</option>
        <option value="gettysburg.edu">gettysburg.edu</option>
        <option value="gmu.edu">gmu.edu</option>
        <option value="whois.dfci.harvard.edu">whois.dfci.harvard.edu</option>
        <option value="hmc.edu">hmc.edu</option>
        <option value="indiana.edu">indiana.edu</option>
        <option value="nii.isi.edu">nii.isi.edu</option>
        <option value="whois.isi.edu">whois.isi.edu</option>
        <option value="whois.messiah.edu">whois.messiah.edu</option>
        <option value="whois.rsmas.miami.edu">whois.rsmas.miami.edu</option>
        <option value="mit.edu">mit.edu</option>
        <option value="directory.msstate.edu">directory.msstate.edu</option>
        <option value="vax2.winona.msus.edu">vax2.winona.msus.edu</option>
        <option value="info.nau.edu">info.nau.edu</option>
        <option value="whois.ncsu.edu">whois.ncsu.edu</option>
        <option value="nd.edu">nd.edu</option>
        <option value="earth.njit.edu">earth.njit.edu</option>
        <option value="vm1.nodak.edu">vm1.nodak.edu</option>
        <option value="austin.onu.edu">austin.onu.edu</option>
        <option value="ph.orst.edu">ph.orst.edu</option>
        <option value="osu.edu">osu.edu</option>
        <option value="whois.oxy.edu">whois.oxy.edu</option>
        <option value="info.psu.edu">info.psu.edu</option>
        <option value="whois.cc.rochester.edu">whois.cc.rochester.edu</option>
        <option value="whitepages.rutgers.edu">whitepages.rutgers.edu</option>
        <option value="whois.sdsu.edu">whois.sdsu.edu</option>
        <option value="stanford.edu">stanford.edu</option>
        <option value="camis.stanford.edu">camis.stanford.edu</option>
        <option value="stjohns.edu">stjohns.edu</option>
        <option value="sunysb.edu">sunysb.edu</option>
        <option value="whois.bcm.tmc.edu">whois.bcm.tmc.edu</option>
        <option value="whois.ubalt.edu">whois.ubalt.edu</option>
        <option value="directory.ucdavis.edu">directory.ucdavis.edu</option>
        <option value="uchicago.edu">uchicago.edu</option>
        <option value="ucsd.edu">ucsd.edu</option>
        <option value="weber.ucsd.edu">weber.ucsd.edu</option>
        <option value="cgl.ucsf.edu">cgl.ucsf.edu</option>
        <option value="whois.uh.edu">whois.uh.edu</option>
        <option value="whois.umass.edu">whois.umass.edu</option>
        <option value="lookup.umd.edu">lookup.umd.edu</option>
        <option value="umn.edu">umn.edu</option>
        <option value="ns.unl.edu">ns.unl.edu</option>
        <option value="whois.upenn.edu">whois.upenn.edu</option>
        <option value="x500.utexas.edu">x500.utexas.edu</option>
        <option value="netlib2.cs.utk.edu">netlib2.cs.utk.edu</option>
        <option value="whois.virginia.edu">whois.virginia.edu</option>
        <option value="whois.wfu.edu">whois.wfu.edu</option>
        <option value="wisc.edu">wisc.edu</option>
        <option value="wpi.wpi.edu">wpi.wpi.edu</option>
        <option value="ibc.wustl.edu">ibc.wustl.edu</option>
        <option value="vm1.hqadmin.doe.gov">vm1.hqadmin.doe.gov</option>
        <option value="wp.doe.gov">wp.doe.gov</option>
        <option value="llnl.gov">llnl.gov</option>
        <option value="x500.arc.nasa.gov">x500.arc.nasa.gov</option>
        <option value="x500.gsfc.nasa.gov">x500.gsfc.nasa.gov</option>
        <option value="whois.hq.nasa.gov">whois.hq.nasa.gov</option>
        <option value="x500.ivv.nasa.gov">x500.ivv.nasa.gov</option>
        <option value="whois.jpl.nasa.gov">whois.jpl.nasa.gov</option>
        <option value="x500.jsc.nasa.gov">x500.jsc.nasa.gov</option>
        <option value="larc.nasa.gov">larc.nasa.gov</option>
        <option value="whois.larc.nasa.gov">whois.larc.nasa.gov</option>
        <option value="x500.msfc.nasa.gov">x500.msfc.nasa.gov</option>
        <option value="x500.ssc.nasa.gov">x500.ssc.nasa.gov</option>
        <option value="x500.wstf.nasa.gov">x500.wstf.nasa.gov</option>
        <option value="x500.nasa.gov">x500.nasa.gov</option>
        <option value="wp.nersc.gov">wp.nersc.gov</option>
        <option value="whois.nic.gov">whois.nic.gov</option>
        <option value="seda.sandia.gov">seda.sandia.gov</option>
        <option value="whois.nic.mil">whois.nic.mil</option>
        <option value="whois.nrl.navy.mil">whois.nrl.navy.mil</option>
        <option value="whois.6bone.net">whois.6bone.net</option>
        <option value="whois.abuse.net">whois.abuse.net</option>
        <option value="whois.aco.net">whois.aco.net</option>
        <option value="whois.apnic.net">whois.apnic.net</option>
        <option value="whois.arin.net">whois.arin.net</option>
        <option value="whois.aunic.net">whois.aunic.net</option>
        <option value="whois.awregistry.net">whois.awregistry.net</option>
        <option value="whois.cary.net">whois.cary.net</option>
        <option value="whois.corenic.net">whois.corenic.net</option>
        <option value="whois.crsnic.net">whois.crsnic.net</option>
        <option value="whois.cw.net">whois.cw.net</option>
        <option value="wp.es.net">wp.es.net</option>
        <option value="whois.hinet.net">whois.hinet.net</option>
        <option value="ds.internic.net">ds.internic.net</option>
        <option value="whois.internic.net">whois.internic.net</option>
        <option value="whois.ja.net">whois.ja.net</option>
        <option value="whois.krnic.net">whois.krnic.net</option>
        <option value="whois.lac.net">whois.lac.net</option>
        <option value="companies.mci.net">companies.mci.net</option>
        <option value="whois.nameit.net">whois.nameit.net</option>
        <option value="whois.netnames.net">whois.netnames.net</option>
        <option value="whois.nomination.net">whois.nomination.net</option>
        <option value="whois.nsiregistry.net">whois.nsiregistry.net</option>
        <option value="whois.oleane.net">whois.oleane.net</option>
        <option value="whois.opensrs.net">whois.opensrs.net</option>
        <option value="pcdc.net">pcdc.net</option>
        <option value="whois.ra.net">whois.ra.net</option>
        <option value="whois.ripe.net">whois.ripe.net</option>
        <option value="whois.ripn.net">whois.ripn.net</option>
        <option value="whois.thnic.net">whois.thnic.net</option>
        <option value="whois.twnic.net">whois.twnic.net</option>
        <option value="whois.dhs.org">whois.dhs.org</option>
        <option value="whois.morris.org">whois.morris.org</option>
        <option value="whois.nic.ac">whois.nic.ac</option>
        <option value="whois.nic.am">whois.nic.am</option>
        <option value="whois.nic.as">whois.nic.as</option>
        <option value="wp.tuwien.ac.at">wp.tuwien.ac.at</option>
        <option value="whois.risc.uni-linz.ac.at">whois.risc.uni-linz.ac.at</option>
        <option value="whois.wu-wien.ac.at">whois.wu-wien.ac.at</option>
        <option value="archie.au">archie.au</option>
        <option value="whois.connect.com.au">whois.connect.com.au</option>
        <option value="whois.adelaide.edu.au">whois.adelaide.edu.au</option>
        <option value="whois.monash.edu.au">whois.monash.edu.au</option>
        <option value="uwa.edu.au">uwa.edu.au</option>
        <option value="sserve.cc.adfa.oz.au">sserve.cc.adfa.oz.au</option>
        <option value="whois.kuleuven.ac.be">whois.kuleuven.ac.be</option>
        <option value="whois.belnet.be">whois.belnet.be</option>
        <option value="whois.registro.br">whois.registro.br</option>
        <option value="whois.camosun.bc.ca">whois.camosun.bc.ca</option>
        <option value="whois.canet.ca">whois.canet.ca</option>
        <option value="whois.cdnnet.ca">whois.cdnnet.ca</option>
        <option value="whois.queensu.ca">whois.queensu.ca</option>
        <option value="ac.nsac.ns.ca">ac.nsac.ns.ca</option>
        <option value="whois.unb.ca">whois.unb.ca</option>
        <option value="panda1.uottawa.ca">panda1.uottawa.ca</option>
        <option value="dvinci.usask.ca">dvinci.usask.ca</option>
        <option value="whois.usask.ca">whois.usask.ca</option>
        <option value="phys.uvic.ca">phys.uvic.ca</option>
        <option value="whois.uwo.ca">whois.uwo.ca</option>
        <option value="whois.nic.cc">whois.nic.cc</option>
        <option value="whois.nic.ch">whois.nic.ch</option>
        <option value="whois.nic.ck">whois.nic.ck</option>
        <option value="whois.nic.cl">whois.nic.cl</option>
        <option value="whois.cnnic.net.cn">whois.cnnic.net.cn</option>
        <option value="whois.ci.ucr.ac.cr">whois.ci.ucr.ac.cr</option>
        <option value="whois.cuni.cz">whois.cuni.cz</option>
        <option value="whois.mff.cuni.cz">whois.mff.cuni.cz</option>
        <option value="www.fce.vutbr.cz">www.fce.vutbr.cz</option>
        <option value="gopher.fme.vutbr.cz">gopher.fme.vutbr.cz</option>
        <option value="whois.fee.vutbr.cz">whois.fee.vutbr.cz</option>
        <option value="whois.vutbr.cz">whois.vutbr.cz</option>
        <option value="whois.fh-koeln.de">whois.fh-koeln.de</option>
        <option value="whois.fzi.de">whois.fzi.de</option>
        <option value="hermes.informatik.htw-zittau.de">hermes.informatik.htw-zittau.de</option>
        <option value="whois.nic.de">whois.nic.de</option>
        <option value="whois.th-darmstadt.de">whois.th-darmstadt.de</option>
        <option value="whois.tu-chemnitz.de">whois.tu-chemnitz.de</option>
        <option value="whois.uni-regensburg.de">whois.uni-regensburg.de</option>
        <option value="whois.uni-c.dk">whois.uni-c.dk</option>
        <option value="whois.ut.ee">whois.ut.ee</option>
        <option value="whois.eunet.es">whois.eunet.es</option>
        <option value="whois.dit.upm.es">whois.dit.upm.es</option>
        <option value="cs.hut.fi">cs.hut.fi</option>
        <option value="oulu.fi">oulu.fi</option>
        <option value="vtt.fi">vtt.fi</option>
        <option value="whois.nic.fr">whois.nic.fr</option>
        <option value="whois.nordnet.fr">whois.nordnet.fr</option>
        <option value="whois.univ-lille1.fr">whois.univ-lille1.fr</option>
        <option value="whois.hknic.net.hk">whois.hknic.net.hk</option>
        <option value="whois.registry.hm">whois.registry.hm</option>
        <option value="whois.iisc.ernet.in">whois.iisc.ernet.in</option>
        <option value="whois.ncst.ernet.in">whois.ncst.ernet.in</option>
        <option value="isgate.is">isgate.is</option>
        <option value="isgate3.isnet.is">isgate3.isnet.is</option>
        <option value="pgebrehiwot.iat.cnr.it">pgebrehiwot.iat.cnr.it</option>
        <option value="dsa.nis.garr.it">dsa.nis.garr.it</option>
        <option value="whois.nic.it">whois.nic.it</option>
        <option value="whois.nic.mx">whois.nic.mx</option>
        <option value="whois.aist-nara.ac.jp">whois.aist-nara.ac.jp</option>
        <option value="whois-server.l.chiba-u.ac.jp">whois-server.l.chiba-u.ac.jp</option>
        <option value="whois.hiroshima-u.ac.jp">whois.hiroshima-u.ac.jp</option>
        <option value="gopher.educ.cc.keio.ac.jp">gopher.educ.cc.keio.ac.jp</option>
        <option value="whois.cc.keio.ac.jp">whois.cc.keio.ac.jp</option>
        <option value="whois.cc.uec.ac.jp">whois.cc.uec.ac.jp</option>
        <option value="whois.yamanashi.ac.jp">whois.yamanashi.ac.jp</option>
        <option value="whois.nic.ad.jp">whois.nic.ad.jp</option>
        <option value="www.orions.ad.jp">www.orions.ad.jp</option>
        <option value="whois.domain.kg">whois.domain.kg</option>
        <option value="sorak.kaist.ac.kr">sorak.kaist.ac.kr</option>
        <option value="whois.nic.or.kr">whois.nic.or.kr</option>
        <option value="whois.domain.kz">whois.domain.kz</option>
        <option value="whois.nic.li">whois.nic.li</option>
        <option value="whois.nic.lk">whois.nic.lk</option>
        <option value="www.restena.lu">www.restena.lu</option>
        <option value="whois.nic.mm">whois.nic.mm</option>
        <option value="www.nic.mx">www.nic.mx</option>
        <option value="condor.dgsca.unam.mx">condor.dgsca.unam.mx</option>
        <option value="domain-registry.nl">domain-registry.nl</option>
        <option value="whois.norid.no">whois.norid.no</option>
        <option value="whois.nic.nu">whois.nic.nu</option>
        <option value="whois.canterbury.ac.nz">whois.canterbury.ac.nz</option>
        <option value="directory.vuw.ac.nz">directory.vuw.ac.nz</option>
        <option value="waikato.ac.nz">waikato.ac.nz</option>
        <option value="whois.patho.gen.nz">whois.patho.gen.nz</option>
        <option value="whois.domainz.net.nz">whois.domainz.net.nz</option>
        <option value="whois.rcp.net.pe">whois.rcp.net.pe</option>
        <option value="whois.icm.edu.pl">whois.icm.edu.pl</option>
        <option value="whois.elka.pw.edu.pl">whois.elka.pw.edu.pl</option>
        <option value="whois.ia.pw.edu.pl">whois.ia.pw.edu.pl</option>
        <option value="whois.dns.pt">whois.dns.pt</option>
        <option value="dsa.fccn.pt">dsa.fccn.pt</option>
        <option value="chalmers.se">chalmers.se</option>
        <option value="kth.se">kth.se</option>
        <option value="whois.nic-se.se">whois.nic-se.se</option>
        <option value="sics.se">sics.se</option>
        <option value="whois.nic.net.sg">whois.nic.net.sg</option>
        <option value="whois.nic.sh">whois.nic.sh</option>
        <option value="whois.uakom.sk">whois.uakom.sk</option>
        <option value="whois.nic.st">whois.nic.st</option>
        <option value="whois.adamsnames.tc">whois.adamsnames.tc</option>
        <option value="whois.nic.tj">whois.nic.tj</option>
        <option value="whois.tonic.to">whois.tonic.to</option>
        <option value="whois.metu.edu.tr">whois.metu.edu.tr</option>
        <option value="whois.seed.net.tw">whois.seed.net.tw</option>
        <option value="whois.iii.org.tw">whois.iii.org.tw</option>
        <option value="src.doc.ic.ac.uk">src.doc.ic.ac.uk</option>
        <option value="whois.lut.ac.uk">whois.lut.ac.uk</option>
        <option value="whois.nic.uk">whois.nic.uk</option>
        <option value="dsa.shu.ac.uk">dsa.shu.ac.uk</option>
        <option value="whois.state.ct.us">whois.state.ct.us</option>
        <option value="info.cnri.reston.va.us">info.cnri.reston.va.us</option>
        <option value="whois.frd.ac.za">whois.frd.ac.za</option>
        <option value="whois.und.ac.za">whois.und.ac.za</option>
        <option value="whois.co.za">whois.co.za</option>
      </select></td>
    </tr>
    <tr>
      <td width="50%" align="right"><font face="Arial" size="2">Domain Name</td>
      <td width="50%"><input type="text" name="T1" size="30"></td>
    </tr>
    <tr>
      <td width="100%" align="center" colspan="2"><input type="submit" value="Whois"
      name="B1"></td>
    </tr>
  </table>
  </center></div>
</form>

<form method="POST" action="NetworkUtilsResults.php" name="IPLookupSubmit">
  <div align="center"><center><table border="1" cellpadding="5" cellspacing="0" width="80%"
  bordercolor="#FFFFFF" bgcolor="#eaeaff">
    <tr>
      <td width="50%" align="right"><font face="Arial" size="2">Host Name</td>
      <td width="50%"><input type="text" name="T1" size="30"></td>
    </tr>
    <tr>
      <td width="100%" align="center" colspan="2"><input type="submit" value="IP Lookup"
      name="B1"></td>
    </tr>
  </table>
  </center></div>
</form>

<form method="POST" action="NetworkUtilsResults.php" name="HostNameLookupSubmit">
  <div align="center"><center><table border="1" cellpadding="5" cellspacing="0" width="80%"
  bordercolor="#FFFFFF" bgcolor="#eaeaff">
    <tr>
      <td width="50%" align="right"><font face="Arial" size="2">IP Address</td>
      <td width="50%"><input type="text" name="T1" size="30"></td>
    </tr>
    <tr>
      <td width="100%" align="center" colspan="2"><input type="submit" value="Host Name Lookup"
      name="B1"></td>
    </tr>
  </table>
  </center></div>
</form>
</body>
</html>
