

PCM.- PHP CRASH MONITOR Ver. 1.1

http://www.acquamexico.com/pcm/

PCR monitorea la actividad de tus servidores.
Creando alarmas visuales, sonoras y mensajes de correo al administrador.


Author: Manlio F. Tapia Trigos - mtapia@acquamexico.com

Apreciaria me escribieras si haces cualquier modificacion a este script.


Insrucciones para la instalacion se encuentran en el archivo INSTALL.txt


Los bugs encontrados se marcan en el archivo BUGS.txt.
Si encuentras alguno mas te agradeceria me escribas un mail a mtapia@acquamexico.com

Copyright 2003 (C) Manlio F. Tapia Trigos
Software Licenciado bajo GNU General Public License.  
Ver gpl.txt.

 