<?PHP

	$ERR["UNABLE_TO_OUTPUT"]		= "Unable to output: ";
	$ERR["FILE_DOESNOT_EXSIT"]		= "This file does not exist: ";
	$ERR["FUNCTION_DOESNOT_EXIST"]	= "This function does not exist: ";
	$ERR["GD2_NOT_CREATED"]			=	"GD2 is installed, function ImageCreateTruecolor() exists, but image is not created";
	$ERR["IMG_NOT_CREATED"]			=	"Image is not created ImageCreate(). {GD2 suppor is OFF}";
	$ERR["GD2_UNAVALABLE"]			=	"You specified to use GD2, but not all GD2 functions are present.";
	$ERR["GD2_NOT_RESIZED"]			=	"GD2 is installed, function ImageCopyResampled() exists, but image is not resized";
	$ERR["IMG_NOT_RESIZED"]			=	"Image was not resized. {GD2 suppor is OFF}";
	$ERR["UNKNOWN_OUTPUT_FORMAT"]	=	"This image format cannot bu output: ";
	$ERR["NO_IMAGE_FOR_OUTPUT"]		=	"Image you are trying to output does not exist. ";
	$ERR["IMG_NOT_SUPPORTED"]		=	"Can not create image. Sorry, this image type is not supported yet.";
?>