<?
include("../class.Thumbnail.php");
$tn_image = new Thumbnail("sample.jpg", 300, 0, 0);
$tn_image->show();
?>

