<?
include("../class.Thumbnail.php");
$tn_image = new Thumbnail("sample.jpg", 0, 0, 25);
$tn_image->save("tn_sample.jpg");
?>

