<?
include("../class.Thumbnail.php");
$tn_image = new Thumbnail("sample.jpg", 0, 200, 0);
$tn_image->show();
?>

