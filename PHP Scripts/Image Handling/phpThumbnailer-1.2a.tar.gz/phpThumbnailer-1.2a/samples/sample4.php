<?
include("../class.Thumbnail.php");
$tn_image = new Thumbnail("sample.jpg", 300, 100, 0);
$tn_image->show();
?>

