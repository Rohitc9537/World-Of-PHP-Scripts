<?

/*
        NewsReader: NewsReader library
                    biblioteka NewsReadera
        Copyright (C) 1999, 2000:
                    Jaros�aw Sygitowicz <gwido@linuxnews.pl>,
                    Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */

require("libs/nnrp-interface.php");

/* Outputs author of the post - with link mailto: added*/
function print_author($curr)
{
	$retval = author("__simple__", $curr, $curr);
   echo stripslashes($retval["header"][0]);
}

/* Outputs subject of the post */
function print_subject()
{
   $retval = subject(0);
	echo $retval["header"][0];
}

/* Outputs subject of the message without the trainling Re: */
function print_topic()
{
   $retval = subject(0, "__topic__");
	echo $retval["header"][0];
}

/* Prints the posting date */
function print_date()
{
   $retval = post_date();
	echo $retval["header"][0];
}

/* This function prints the formatted message body */
function print_body($fixed, $author2)
/* cs - socket descriptor
 * post_nr - message number
 * fixed - indicates whether body should be printed using fixed font:
           0 - variable width font, signature with fixed font
			  1 - fixed width font, include leading <pre> and trailing </pre>
			  2 - pure text (fixed width, but no <pre> tags) with '> ' added before each line, no signature
			  else - same as 0
 */
{
	$msg = msg_body();
	if ($fixed == 1) echo "<pre>\n$msg</pre>\n";
	else {
	  $body_a = preg_split("/^-- /m", $msg);
	  $body = array_shift($body_a);
	  if ($fixed == 2) {
		  include("config/config.inc");
		  $body = preg_replace("/^/m", "> ", $body);
		  echo $header.$body;
	  } else {
		  /* The signature will be printed 'as it is' - using fixed font */
		  $sig = implode("-- ", $body_a);
		  /* Any '<' and '>' are illegel unless they delimit a tag */
		  $body = ereg_replace("<", "&lt;", $body);
		  $body = ereg_replace(">", "&gt;", $body);
		  /* Try to format the text. But it seems not to make a sense. Another try will be to give user a choice: to use a fixed font or to use a variable width font */
		  $body = ereg_replace("  ", "&nbsp;&nbsp;", $body);
		  $body = ereg_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $body);
		  /* Break the lines */
		  $body = ereg_replace("\n", "<br>\n", $body);
		  /* Make hyperlinks from blablabla@blebleble.com, http://blebleble.com, ftp://blebleble.com */
		  $body = eregi_replace("([a-z0-9\-\_\$\.]+\@([a-z0-9\-]+\.)+[a-z0-9\-\_]+)",
									  "<a href=\"mailto:\\0\">\\0</a>", $body);
		  $body = eregi_replace("((http|ftp)\:\/\/([a-z0-9\-\_]+(\.|\/|\/\~|\-))+[a-z0-9\-\_\=\?\/]+)",
									  "<a href=\"\\0\">\\0</a>", $body);
		  echo stripslashes($body);
		  if ($sig) echo "<pre>\n-- ".$sig."</pre>\n";
	  }
	}
}

/* Builds the thread tree: to be rewritten */
function print_thread($last, $first)
/* cs		- socket descriptor
 * post_nr	- message number
 * last  - last message to be cecked
 * first - first message to be checked
 * group - group name
 */
{
   global $post_nr;
   global $group;

	include("config/config.inc");
	/* References for the current post */
	$aux = references($post_nr, $post_nr);
	$refs = $aux["header"][0];
	echo "<tr bgcolor=\"$lightbg\"><td colspan=2 nowrap>&nbsp;&nbsp;\n";
	echo "<img src=\"images/shim.gif\" align=top width=1 height=20 border=0 alt=\"\">";
	/* Message-ID for the first in the thread message */
	if (($refs == "(none)") || ($refs == "")) {
		/* Current message is first in the thread */
		$aux = message_id($post_nr, $post_nr);
		$id = $aux["header"][0];
		$refs = "";
		$first_nr = $post_nr;
	} else {
		/* First id in references is the id for the first in the thread */
		$refs = ereg_replace("\(none\) ", "", $refs);
		$ids = split(" ", $refs);
		$id = $ids[0];
		$first_msg = message_id($last, $first, "__none__", $id);
		if ($first_msg["nr"][0]) $first_nr = $first_msg["nr"][0];
		else {
		  $first_nr = $post_nr;
		  $aux = message_id($post_nr, $post_nr);
		  $id = $aux["header"][0];
		}
	}
	$fauthor = author("__simple__", $first_nr, $first_nr);
	$fsubject = subject(0, "__full__", $first_nr, $first_nr);
	$fdate = post_date($first_nr, $first_nr);
	if ($first_nr == $post_nr) echo "<font color=\"#ff0000\">*</a>";
	echo "<a href=\"article.php?group=".urlencode($group)."&post_nr=$first_nr\">";
	echo "$MESSAGE 1";
	echo "</a>";
	if ($first_nr == $post_nr) echo "<font color=\"#ff0000\">*</a>";
	echo "&nbsp;&nbsp;</td><td nowrap>&nbsp;&nbsp;\n";
	echo stripslashes($fauthor["header"][0]);
	echo "&nbsp;&nbsp;</td><td nowrap>&nbsp;&nbsp;\n";
	echo $fdate["header"][0];
	echo "&nbsp;&nbsp;</td></tr>\n";
	$thread = references($last, $first, "__none__", "*$id*");
	$nrs = Array(sizeof($thread["nr"]));
	$mid = Array();
	$child = Array();
	$neighbour = Array();
	$printed = Array();
	$mid[0] = $id;
	$child[0] = 0;
	$neighbour[0] = 0;
	$printed[0] = 1;
	for ($k = sizeof($thread["nr"])-1, $i = 0; $k >= 0; $i++, $k--) {
		// Message number
		$nrs[$i+1] = $thread["nr"][$k];
		// Message-ID
		$aux = message_id($nrs[$i+1],$nrs[$i+1]);
      $mid[$i+1] = $aux["header"][0];
		$child[$i+1] = 0;
		$neighbour[$i+1] = 0;
		$printed[$i+1] = 0;
		$refers[$i+1] = $thread["header"][$k];
		// Check all messages from References
		$aux = explode(" ", $thread["header"][$k]);
		for ($j = sizeof($aux) - 1; $j >= 0; $j--) {
			$pos = find_pos($aux[$j], $mid);
			if ($pos != -1) break;
		}
		if ($child[$pos]) {
			$tmp = $child[$pos];
			while ($neighbour[$tmp] > 0) $tmp = $neighbour[$tmp];
			$neighbour[$tmp] = $i+1;
		} else {
			$child[$pos] = $i+1;
		}
	}
	// Some of chidren of the root may not be in the right place
	// ...
	$upper_level = Array();
	$upper_level[0] = 0;
	if (sizeof($thread["nr"])) print_thread2(1, 0, $nrs, $child, $neighbour,
	                1, $upper_level);
}

/* Prints the thread */
function print_thread2($i, $nr, $nrs, $child, $neighbour,
                      $level, $upper_level)
/* i - current post (currently printed position in the tree) number
 * nr - number of the message in the thread
 * 3 next variables are thread tree
 * nrs - table of the message numbers
 * child - table of children
 * neighour - table of the neigbours
 * cs - socket descriptor
 * post_nr - current post (body shown) number (to be marked)
 * group - group name
 * level - level in the thread tree of the current post
 * upper_level - array of higher level messages left to print
 */
{
   global $post_nr;
   global $group;

	include("config/config.inc");
	while ($i) {
			if ($neighbour[$i]) $upper_level[$level] = 1;
			else $upper_level[$level] = 0;
			if ($nr % 2) $bg = $lightbg;
			else $bg = $darkbg;
			echo "<tr bgcolor=\"$bg\"><td colspan=2 nowrap>&nbsp;&nbsp;\n";
			for ($j = 0; $j < $level; $j++) {
				if ($upper_level[$j]) echo "<img src='images/vert.gif' align=top width=10 height=20 border=0 alt=\"|\">";
				else echo "<img src='images/shim.gif' align=top width=10 height=20 border=0 alt=\" \">";
			}
			if ($neighbour[$i]) {
				echo "<img src=\"images/2corn.gif\" align=top width=10 height=20 border=0 alt=\"+\">\n";
			} else {
				echo "<img src=\"images/corn.gif\" align=top width=10 height=20 border=0 alt=\"+\">\n";
			}
			$cnrs = $nrs[$i];
			$auth = author("__simple__", $cnrs, $cnrs);
			$subj = "$MESSAGE ".($i+1);
			$dat = post_date($cnrs, $cnrs);
			if ($cnrs == $post_nr) echo "<font color=\"#ff0000\">*</a>";
			echo "<a href=\"article.php?group=".urlencode($group)."&post_nr=".$cnrs."\">";
			echo $subj;
			echo "</a>";
			if ($cnrs == $post_nr) echo "<font color=\"#ff0000\">*</a>";
			echo "&nbsp;&nbsp;</td><td nowrap>&nbsp;&nbsp;\n";
			echo $auth["header"][0];
			echo "&nbsp;&nbsp;</td><td nowrap>&nbsp;&nbsp;\n";
			echo $dat["header"][0];
			echo "&nbsp;&nbsp;</td></tr>\n";
			if ($child[$i]) $nr = print_thread2($child[$i], $nr + 1, $nrs,
                                            $child, $neighbour,
                                            $level+1, $upper_level);
			else $nr++;
			$i = $neighbour[$i];
	}
	return $nr;
};

/* Function for displaying in show_headers.php. Returns the lowest number of the displayed message. */
function print_headers($count, $headers, $tablesize)
/* cs - connection descriptor
 * group - group name
 * last - last message to print
 * count - number of messages to print
 * headers - array of the headers to print
 * tablesize - number of columns in the table
 */
{
   global $post_nr;
   global $group;

   include("config/config.inc");
   if ($tablesize > sizeof($headers)) $colspan = " colspan=".($tablesize - sizeof($headers) + 1);
	else $colspan = "";
	echo "<tr bgcolor=\"$themecolor\">\n";
	$hdrs = Array(sizeof($headers));
	for ($i = 0; $i < sizeof($headers); $i++) {
	   echo "<td";
		if (($i == 0) && $colspan) echo $colspan;
		echo ">&nbsp;&nbsp;<b>";
		echo $headers[$i];
		echo "</b></td>\n";
		/* FIXME: it's very, very bad... */
		$aux = $headers[$i];
		if ($aux == $AUTHOR) $hdrs[$i] = author("__simple__", $post_nr, $post_nr - 10 + 1);
		else if ($aux == $SUBJECT) $hdrs[$i] = subject(50, "__full__", $post_nr, $post_nr - 10 + 1);
		else if ($aux == $DATE) $hdrs[$i] = post_date($post_nr, $post_nr - 10 + 1);
		else $hdrs[$i] = 0;
	}
	echo "</tr>\n";
	echo "<td colspan=$tablesize><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
	for ($j = 0; $j < sizeof($hdrs[1]["header"]); $j++) {
	   echo "<tr ";
		if ($j % 2) echo "bgcolor=\"$lightbg\">\n";
		else echo "bgcolor=\"$darkbg\">\n";
	   for ($i = 0; $i < sizeof($headers); $i++) {
		  echo "<td";
		  if ($i == 0) echo $colspan;
		  echo ">&nbsp;&nbsp;";
		  if ($headers[$i] == $SUBJECT) echo "<a href=\"article.php?group=$group&post_nr=".$hdrs[$i]["nr"][$j]."\">";
		  echo $hdrs[$i]["header"][$j];
		  if ($headers[$i] == $SUBJECT) echo "</a>";
		  echo "&nbsp;&nbsp;</td>\n";
		}
		echo "</tr>\n";
	}
	return array_pop($hdrs[0]["nr"]);
}

/* Function for displaying in show_threads.php */
function print_topics($last, $first, $count, $headers, $tablesize)
/* cs - socket descriptor
 * group - group name
 * curr - number of the current message
 * last - last message to check
 * first - first message to check
 * count - number of the messages to output
 * headers - array of the headers to output
 * tablesize - number of columns in the table
 */
{
   global $group;

	include("config/config.inc");
	if ($tablesize > sizeof($headers)) $colspan = " colspan=".($tablesize - sizeof($headers) + 1);
	else $colspan = "";
	echo "<tr bgcolor=\"$themecolor\">\n";
	$hdrs = Array(sizeof($headers));
	$nrs = empty_references($first, $count);
	for ($i = 0; $i < sizeof($headers); $i++) {
		echo "<td";
		if (($i == 0) && $colspan) echo $colspan;
		echo ">&nbsp;&nbsp;<b>";
		echo $headers[$i];
		echo "</b></td>\n";
		$hdrs[$i] = Array(sizeof($nrs));
		/* FIXME: it's very, very bad... */
		if ($headers[$i] == $AUTHOR) {
			for ($j = 0; $j < sizeof($nrs); $j++) {
		      $hdrs[$i][$j] = author("__simple__", $nrs[$j], $nrs[$j]);
			}
		} else if ($headers[$i] == $SUBJECT) {
			for ($j = 0; $j < sizeof($nrs); $j++) {
            $hdrs[$i][$j] = subject(50, "__topic__", $nrs[$j], $nrs[$j]);
			}
		} else if ($headers[$i] == $DATE) {
			for ($j = 0; $j < sizeof($nrs); $j++) {
            $hdrs[$i][$j] = post_date($nrs[$j], $nrs[$j]);
			}
		} else $hdrs[$i] = 0;
	}
	echo "</tr>\n";
	echo "<td colspan=$tablesize><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
	for ($j = 0; $j < sizeof($nrs); $j++) {
	   $c = count_messages_in_thread($nrs[$j]) + 1;
	   echo "<tr ";
		if ($j % 2) echo "bgcolor=\"$lightbg\">\n";
		else echo "bgcolor=\"$darkbg\">\n";
	   for ($i = 0; $i < sizeof($headers); $i++) {
		  echo "<td";
		  if ($i == 0) echo $colspan;
		  echo ">&nbsp;&nbsp;";
		  if ($headers[$i] == $SUBJECT) echo "[ $c ]&nbsp;<a href=\"article.php?group=$group&post_nr=".$nrs[$j]."\">";
		  echo $hdrs[$i][$j]["header"][0];
		  if ($headers[$i] == $SUBJECT) echo "</a>";
		  echo "&nbsp;&nbsp;</td>\n";
		}
		echo "</tr>\n";
	}
	return $nrs[sizeof($nrs)-1];
}

/* This function prints last messages in the newsgroups matching a template. */
function print_groups_headers($template, $count)
/* cs - socket descriptor
 * template - a template for the newsgroup name
 * count    - number of the messages to print
 */
{
   include("config/config.inc");
   /* 1. First let's get all newsgroups matching $template */
	$groups = get_groups($template);
   /* 2. For each newsgroup let's get $count last messages */
	$messages = Array();
	for ($i = 0; $i < sizeof($groups["name"]); $i++) {
	  $last = $groups["last"][$i];
	  /* This is not required but IMHO it's good-style programming :-)))) */
	  $first = ($groups["count"][$i] < $count) ? $last - $groups["count"][$i] + 1 : $last - $count + 1;
	  select_group($groups["name"][$i]);
	  $messages[$i] = subject(50, "__full__", $last, $first);
	}
   /* 3. Now we'll print the fetched info in 2 columns */
	echo "<table border=0>\n";
	for ($i = 0; $i < sizeof($groups["name"]); $i++) {
	  if (!($i % 2)) echo "<tr>";
	  echo "<td>\n";
	  echo "<table border=0 width=100% cellspacing=0 cellpadding=0>\n<tr bgcolor=\"$themecolor\"><td colspan=2 align=center>\n<b>";
	  echo $groups["name"][$i];
	  echo " (".$groups["count"][$i].")";
	  echo "</b></td></tr>\n<tr bgcolor=\"$lightbg\"><td colspan=2>\n<ul>\n";
	  for ($j = 0; $j < $count; $j++) {
		echo "<li>";
		if (sizeof($messages[$i]["nr"]) > 0) {
			echo "<a href=\"article.php?group=";
			echo $groups["name"][$i];
			echo "&post_nr=";
			echo $messages[$i]["nr"][$j];
			echo "\">";
			echo $messages[$i]["header"][$j];
			echo "</a>\n";
		}
	  }
	  echo "</ul>\n</td></tr>\n<tr bgcolor=\"$themecolor\"><td align=left>\n";
	  echo "&nbsp;<a href=\"show_threads.php?group=";
	  echo $groups["name"][$i];
	  echo "&post_nr=0\">";
	  echo "<i>$THREADS</i>";
	  echo "</a></td>\n<td align=right>\n";
	  echo "<a href=\"show_headers.php?group=";
	  echo $groups["name"][$i];
	  echo "&post_nr=0\">";
	  echo "<i>$NEXT</i>";
	  echo "</a>&nbsp;</td></tr>\n</table>\n";
	  echo "</td>\n";
	  if ($i % 2) echo "</tr>\n";
	}
}

/* This function prints filtered messages in the newsgroup. */
function print_filtered_headers($template, $last, $count, $search_header)
/* cs - socket descriptor
 * group - group name
 * template - a template for the subject
 * first - number of the first message to search
 * last - number of the last message to search
 * count    - number of the messages to print
 */
{
   global $first_post;
   global $group;

	include("config/config.inc");
   if ($search_header == "subject") {
      $subjects = subject(0, "__full__", $last, $first_post, $count, "*$template*");
      $authors = array(sizeof($subjects["nr"]));
      $h = $subjects;
   } else {
      $authors = author("__simple__", $last, $first_post, $count, "*$template*");
      $subjects = array(sizeof($authors["nr"]));
      $h = $authors;
   }
   $dates = array(sizeof($h["nr"]));
   for ($i = 0; $i < sizeof($h["nr"]); $i++) {
      if ($search_header == "subject") {
         $aux = author("__simple__", $h["nr"][$i], $h["nr"][$i]);
         $authors["nr"][$i] = $aux["nr"][0];
         $authors["header"][$i] = $aux["header"][0];
      } else {
         $aux = subject(0, "__full__", $h["nr"][$i], $h["nr"][$i]);
         $subjects["nr"][$i] = $aux["nr"][0];
         $subjects["header"][$i] = $aux["header"][0];
      }
      $aux = post_date($h["nr"][$i], $h["nr"][$i]);
      $dates["nr"][$i] = $aux["nr"][0];
      $dates["header"][$i] = $aux["header"][0];
   }
	echo "<tr bgcolor=\"$themecolor\"><td colspan=2>$SUBJECT</td><td>$AUTHOR</td><td>$DATE</td></tr>";
	echo "<td colspan=4><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
	for ($j = 0; $j < sizeof($subjects["nr"]); $j++) {
		echo "<tr ";
		if ($j % 2) echo "bgcolor=\"$lightbg\">\n";
		else echo "bgcolor=\"$darkbg\">\n";
		echo "<td colspan=2>";
		echo "&nbsp;<a href=\"article.php?group=$group&post_nr=".$subjects["nr"][$j]."\">";
		echo $subjects["header"][$j];
		echo "</a>";
		echo "&nbsp;&nbsp;</td>\n";
		echo "<td>";
		echo $authors["header"][$j];
		echo "&nbsp;&nbsp;</td>\n";
		echo "<td>";
		echo $dates["header"][$j];
		echo "&nbsp;&nbsp;</td>\n";
		echo "</tr>\n";
	}
	return $subjects["nr"][sizeof($subjects["nr"])-1];
}

function nr_post($msg, $HTTP_USER_AGENT, $REMOTE_ADDR)
{
   return nnrp_post($msg, $HTTP_USER_AGENT, $REMOTE_ADDR);
}


function print_rss_headers($count)
{
   global $post_nr;
   global $group;

   $hdrs = subject(0, "__full__", $post_nr, $post_nr - $count);
   for ($i = 0; $i < sizeof($hdrs["nr"]); $i++) {
      echo "<item>\n";
      echo "<title>".$hdrs["header"][$i]."</title>\n";
      echo "<link>http://newsreader.linuxnews.pl/article.php?group=$group&post_nr=".$hdrs["nr"][$i]."</link>\n";
      echo "</item>\n";
   }
}

function print_stats($first, $last)
{
	$stats = array();
	$retval = author("__plain__", $last, $first);
	for ($i = 0; $i < sizeof($retval["nr"]); $i++) {
		$email = get_email($retval["header"][$i]);
		$name  = remove_email($retval["header"][$i]);
		$count[$email]++;
		$names[$email] = $name;
	}
	arsort($count);
	$i = 1;
	while (list($email, $val) = each($count)) {
		echo "<item>\n";
		echo "<title>".$names[$email]." $val post�w</title>\n";
		echo "</item>\n";
		$i++;
	}
}

?>
