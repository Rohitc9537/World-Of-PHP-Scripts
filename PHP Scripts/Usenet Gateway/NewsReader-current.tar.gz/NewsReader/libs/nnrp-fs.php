<?

/*
        NewsReader: NNRP library extension for filesystem
                    Rozszerzenie biblioteki NNRP dla systemu plik�w
        Copyright (C) 1999, 2000:
                    Jaros�aw Sygitowicz <gwido@linuxnews.pl>,
                    Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */

/* Returns the header $header of the $post matching the $pattern */
function xpat_fs($group, $post, $date, $header, $pattern)
{
   include("config/config.inc");

   $g = explode(".", $group);
   $group_path = implode("/", $g);
   $d = explode("_", $date);
   $date_path = implode("/", $d);
   if (!file_exists($archive_path."/".$group_path."/".$date_path."/".$post)) return $retval;
   $fh = fopen($archive_path."/".$group_path."/".$date_path."/".$post, "r");
   $notfound = 1;
   $retval = array(2);
   $retval["nr"] = $post;
   $retval["header"] = "";
   while ($notfound) {
      $line = fgets($fh, 1024);
      if (ereg("^$", $line)) break;
      if (ereg("^$header: ", $line)) {
         $hdr = substr($line, sizeof($header)+2);
         if (ereg("$pattern", $hdr)) {
            $retval["header"] = substr($line, sizeof($header)+2);
            $notfound = 0;
         }
      }
   }
   fclose($fh);
   return $retval;
}

/* Returns the header $header of the $post */
function xhdr_fs($group, $post, $date, $field)
{
   include("config/config.inc");

   $g = explode(".", $group);
   $group_path = implode("/", $g);
   $d = explode("_", $date);
   $date_path = implode("/", $d);
   if (!file_exists($archive_path."/".$group_path."/".$date_path."/".$post)) return false;
   $fh = fopen($archive_path."/".$group_path."/".$date_path."/".$post, "r");
   $notfound = 1;
   $retval = array(2);
   $retval["nr"] = $post;
   $retval["header"] = "";
   while ($notfound) {
      $line = fgets($fh, 1024);
      if (ereg("^\n$", $line)) break;
      if (ereg("^$field: ", $line)) {
         $retval["header"] = substr($line, strlen($field)+2);
         $notfound = 0;
      }
   }
   fclose($fh);
   return $retval;
}

function xover_fs($group, $post, $date)
{
   include("config/config.inc");

   $g = explode(".", $group);
   $group_path = implode("/", $g);
   $d = explode("_", $date);
   $date_path = implode("/", $d);
   $retval = Array();
   $retval["nr"] = $post;
   if (!file_exists($archive_path."/".$group_path."/".$date_path."/".$post)) return $retval;
   $fh = fopen($archive_path."/".$group_path."/".$date_path."/".$post, "r");
   while (1) {
      $line = fgets($fh, 1024);
      if (ereg("^$", $line)) break;
      if (ereg("^From: ", $line)) $header = "from";
      else if (ereg("^Subject: ", $line)) $header = "subject";
      else if (ereg("^Date: ", $line)) $header = "date";
      else if (ereg("^Message-ID: ", $line)) $header = "msgid";
      else if (ereg("^References: ", $line)) $header = "references";
      else if (ereg("^Xref: ", $line)) $header = "xref";
      else if (ereg("^Lines: ", $line)) $header = "lines";
      else break;
      $retval["headers"][$header] = substr($line, sizeof($header)+2);
   }
   close($fh);
   return $retval;
}

function body_fs($group, $post, $date)
{
   include("config/config.inc");

   $g = explode(".", $group);
   $group_path = implode("/", $g);
   $d = explode("_", $date);
   $date_path = implode("/", $d);
   $retval = "";
   if (!file_exists($archive_path."/".$group_path."/".$date_path."/".$post)) return $retval;
   $fh = fopen($archive_path."/".$group_path."/".$date_path."/".$post, "r");
   $header = 1;
   /* skip header */
   while ($header) {
      $line = fgets($fh, 1024);
      if (ereg("^\n$", $line)) $header = 0;
   }
   while ($line = fgets($fh, 1024)) {
      $retval = $retval.$line;
   }
   fclose($fh);
   return $retval;
}

?>
