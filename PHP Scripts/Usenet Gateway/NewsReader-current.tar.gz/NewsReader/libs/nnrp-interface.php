<?

/*
        NewsReader: NNRP library interface
                    Interfejs do biblioteki NNRP
        Copyright (C) 1999, 2000:
                    Jaros�aw Sygitowicz <gwido@linuxnews.pl>,
                    Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */

require("libs/nnrp.php");
require("libs/nnrp-fs.php");

/* Returns an array of the header fields and the message numbers */
function header_field($field, $last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
/* cs		- socket descriptor
 * field	- name of the field (without the color)
 * first	- first number of the message to get
 * last		- last number of the message to get
 */
{
   global $first_post;
   global $last_post;
   global $group;
   global $date;
   global $post_nr;

   if ($last == "__none__") $last = $post_nr;
   if ($first == "__none__") $first = $post_nr;

   /* $count == "__none__" implies $first != "__none__"
    * otherwise it's an error */
   if ($count == "__none__") { $count = 1; $current_last = $last; $current = $first; }
   else { $current_last = $last; $current = $last - $count; }

   if ($last_post < $last) $last = $last_post;

   $retval = array("nr", "header");
   $retval["nr"] = array();
   $retval["header"] = array();

   $aux = 1;

   while (($count > 0) || ($aux == 1)) {
      if ($current < $first) break;
      if ($first_post > $current) {

        $retval1 = array("nr", "header");
	$retval1["nr"] = array();
	$retval1["header"] = array();
        $retval2 = array("nr", "header");
	$retval2["nr"] = array();
	$retval2["header"] = array();

        /* Take these from the archive */
        for ($i = $current; $i < $first_post && $i <= $last; $i++) {
           /* Distinct XPAT i XHDR */
           if ($pattern == "__none__") $aux = xhdr_fs($group, $i, $date, $field);
           else $aux = xpat_fs($group, $i, $date, $field, $pattern);
           if ($aux) {
              array_unshift($retval1["nr"], $aux["nr"]);
              array_unshift($retval1["header"], $aux["header"]);
           }
        }

        /* The rest can be taken from the newsserver */
        /* Distinct XPAT i XHDR */
	if ($count - sizeof($retval1["nr"]) > 0) {
	        if ($pattern == "__none__") $retval2 = xhdr($field, $first_post, $current_last);
        	else $retval2 = xpat($field, $first_post, $current_last, $pattern);
	}

        /* Join both tables - newser posts should be at the beginning */
        $retvaltmp = array("nr", "header");
	$retvaltmp["nr"] = array();
	$retvaltmp["header"] = array();

        $retval["nr"] = array_merge($retval2["nr"], $retval1["nr"]);
        $retval["header"] = array_merge($retval2["header"], $retval1["header"]);

        $current_last = $current - 1;
        $current = $current - $count;
        $count = $count - sizeof($retvaltmp["nr"]);

        $retval["nr"] = array_merge($retval["nr"], $retvaltmp["nr"]);
        $retval["header"] = array_merge($retval["header"], $retvaltmp["header"]);

      /* Everything can be get from the newsserver */
      } else {
        if ($pattern == "__none__") $retvaltmp = xhdr($field, $current, $current_last);
        else $retvaltmp = xpat($field, $current, $current_last, $pattern);

        $current_last = $current - 1;
        $current = $current - $count;
        $count = $count - sizeof($retvaltmp["nr"]);

        $retval["nr"] = array_merge($retval["nr"], $retvaltmp["nr"]);
        $retval["header"] = array_merge($retval["header"], $retvaltmp["header"]);

      }
      $aux = 0;
	}

   return $retval;
}

function header_fields($field_array, $last = "__none__", $first = "__none__", $count = "__none__")
{
   global $first_post;
   global $last_post;
   global $group;
   global $date;
   global $post_nr;

   if ($last == "__none__") $last = $post_nr;
   if ($first == "__none__") $first = $post_nr;

   /* $count == "__none__" implies $first != "__none__"
    * otherwise it's an error */
   if ($count == "__none__") $count = 0;
   else { $current_last = $last; $current = $last - $count; }

   if ($last_post < $last) $last = $last_post;

   $retval = array("nr", "headers");
   $retval["nr"] = array();
   $retval["headers"] = array();

   while ($count > 0) {
      if ($first_post > $current) {
        $retval1 = array("nr", "headers");

        /* Take these from the archive */
        for ($i = $current; $i < $first_post; $i++) {

           /* Distinct XPAT i XHDR */
           $aux = xover_fs($group, $field, $date, $i);

           if ($aux) {
              array_unshift($retval1["nr"], $aux["nr"]);
              array_unshift($retval1["headers"], $aux["headers"]);
           }
        }

        /* The rest can be taken from the newsserver */
        /* Distinct XPAT i XHDR */
        $retval2 = xover($field, $first_post, $current_last);

        /* Join both tables - newser posts should be at the beginning */
        $retvaltmp = array("nr", "headers");
        $retval["nr"] = array_merge($retval2["nr"], $retval1["nr"]);
        $retval["headers"] = array_merge($retval2["headers"], $retval1["headers"]);

        $current_last = $current - 1;
        $current = $current - $count;
        $count = $count - sizeof($retvaltmp["nr"]);

        $retval["nr"] = array_merge($retval["nr"], $retvaltmp["nr"]);
        $retval["headers"] = array_merge($retval["headers"], $retvaltmp["headers"]);

      /* Everything can be get from the newsserver */
      } else {

        $retvaltmp = xover($field, $current, $current_last);

        $current_last = $current - 1;
        $current = $current - $count;
        $count = $count - sizeof($retvaltmp["nr"]);

        $retval["nr"] = array_merge($retval["nr"], $retvaltmp["nr"]);
        $retval["headers"] = array_merge($retval["headers"], $retvaltmp["headers"]);

      }
	}

   return $retval;
}

/********************************
 *** Interface to the library ***
 ********************************/

/* Returns ready to print, html coded author of the post: <a href=mailto:name@domain.name>real name</a> */
function author($type = "__simple__", $last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
{
	$retval = header_field("From", $last, $first, $count, $pattern);
   for ($i = 0; $i < sizeof($retval["nr"]); $i++) {
      if ($type == "__simple__") $retval["header"][$i] = decode_author($retval["header"][$i]);
      else if ($type == "__plain__") $retval["header"][$i] = plain_author($retval["header"][$i]);
      else $retval["header"][$i] = remove_email($retval["header"][$i]);
   }
	return $retval;
}

/* Returns ready to print message subject in HTML form */
function subject($length, $mode = "__full__", $last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
/* cs		- socket descriptor
 * post_nr	- message number
 * length   - maximal length of the returned string
 */
{
	$retval = header_field("Subject", $last, $first, $count, $pattern);
   for ($i = 0; $i < sizeof($retval["nr"]); $i++) {
      $retval["header"][$i] = decode_subject($retval["header"][$i]);
      if ($length && (strlen($retval["header"][$i]) > $length)) {
         $retval["header"][$i] = substr($retval["header"][$i], 0, $length)."...";
      }
      if ($mode == "__topic__") $retval["header"][$i] = eregi_replace("^((re|odp): )+", "", $retval["header"][$i]);
   }
   return $retval;
}

/* Returns the message date in the following format: dd month yyyy tz, hh:mm:ss */
function post_date($last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
/* cs		- socket descriptor
 * post_nr	- message_number
 */
{
	$retval = header_field("Date", $last, $first, $count, $pattern);
	return $retval;
}

/* Returns the message body in 8bit form */
function msg_body()
/* cs		- socket descriptor
 * post_nr	- message number
 */
{
	global $group;
	global $date;
	global $post_nr;
	global $first_post;

	$aux = header_field("Content-Transfer-Encoding");
	$encoding = $aux["header"][0];
	if ($post_nr < $first_post) {
		if (eregi("quoted-printable", $encoding)) $retval = my_quoted_printable_decode2(body_fs($group, $post_nr, $date));
		else if (eregi("base64", $encoding)) $retval = base64_decode(body_fs($group, $post_nr, $date));
		else $retval = body_fs($group, $post_nr, $date);
	} else {
		if (eregi("quoted-printable", $encoding)) $retval = my_quoted_printable_decode2(body($post_nr));
		else if (eregi("base64", $encoding)) $retval = base64_decode(body($post_nr));
		else $retval = body($post_nr);
	}
	return cp1250toiso88592($retval);
}

/* Returns field Newsgroups from the post header */
function newsgroups()
/* cs		- socket descriptor
 * post_nr	- message number
 */
{
   return header_field("Newsgroups");
}

/* Returns references of the post */
function references($last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
/* cs		- socket descriptor
 * post_nr	- message number
 */
{
   $retval = header_field("References", $last, $first, $count, $pattern);
   for ($i = 0; $i < sizeof($retval["nr"]); $i++)
      if (ereg("^(none)$", $retval["header"][$i])) $retval["header"][$i] = "";
	return $retval;
}

/* Returns posts with empty references (used for finding first_in_the_thread) */
function empty_references($first, $count)
/* cs		- socket descriptor
 * post_nr	- message number
 * first - first post to search
 * count - number of the posts to return
 */
{
   global $post_nr;

	$curr = $post_nr;
	$retval = Array();

	while (($curr >= $first) && (sizeof($retval) < $count)) {
		$min = $curr - $count;
		if ($min < 0) $min = 0;
//		$aux = xpat("References", $curr, $min, "__none__", "[^<]*");
		$aux = references($curr, $min, "__none__", "[^<]*");
//		$aux = xpat("References", $curr, $min, "__none__", "(none)");
//		$aux = xhdr("References", $curr, $min, "__none__");
		$aux2 = Array();
		for ($i = sizeof($aux["nr"]) - 1; $i >= 0; $i--) {
//		  if (ereg("^\(none\)", $aux["header"][$i]))
		  array_push($aux2, $aux["nr"][$i]);
		  if ((sizeof($retval) + sizeof($aux2)) >= $count) break;
		}
		for ($i = sizeof($aux2) - 1; $i >=0; $i--) {
			array_push($retval, $aux2[$i]);
		}
		$curr = $min - 1;
	}
	return $retval;
};

/* Returns message id */
function message_id($last = "__none__", $first = "__none__", $count = "__none__", $pattern = "__none__")
/* cs		- socket descriptor
 * post_nr	- message number
 */
{
   return header_field("Message-ID", $last, $first, $count, $pattern);
}

/* Finds the position in the array of the pattern */
function find_pos($pat, $arr)
/* $pat - pattern
 * $arr - array of the stings
 */
{
	for ($i = 0; $i < sizeof($arr); $i++) {
		if ($pat == $arr[$i]) return $i;
	}
	return -1;
}

/* Returns the number of the messages in the thread */
function count_messages_in_thread($curr)
/* cs - socket descriptor
 * post_nr - first in the thread post number
 * last - potentially last message in the thread
 */
{
	global $last_post;
	global $first_post;

 	$id = message_id($curr, $curr);
	$idv = $id["header"][0];
	$arr = references($last_post, $curr - 10, "__none__", "$idv*");
	return sizeof($arr["nr"]);
}

function nnrp_post($msg, $HTTP_USER_AGENT, $REMOTE_ADDR)
{
   return post($msg, $HTTP_USER_AGENT, $REMOTE_ADDR);
}

function select_group($group)
{
   return group($group);
}


?>
