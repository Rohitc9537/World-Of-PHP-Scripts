<?php

/*
        NewsReader: NNRP library
                    biblioteka NNRP
        Copyright (C) 1999, 2000:
                    Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                    Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */

require("libs/encoding.php");

/* Opens connection to newsserver. Returns socket descriptor. */
function nnrp_connect()
{
	include("config/config.inc");
	$cs = fsockopen($nnrp_server, $port);
	/* FIXME: parse the output from newsserver */
	if ($cs) $response = fgets($cs, 128);
	return $cs;
}

/* Selects usenet group. Returns group information: array with two fields - first, last */
function group($group)
/* cs		- socket descriptor
 * group	- usenet group name
 */
{
   global $cs;

	fwrite($cs, "MODE READER\r\n");
	/* FIXME: parse this response */
	$response = fgets($cs, 128);
	fwrite($cs, "GROUP $group\r\n");
	/* FIXME: parse the respone and in case of the failure return some error */
	$ginfo = fgets($cs, 1024);
	$ginfos = explode(" ", $ginfo);
	$retval = Array();
	$retval["first"] = $ginfos[2];
	$retval["last"] = $ginfos[3];
	return $retval;
}

/* Sends XHDR command to the news server.
   Retval is an array with two fields: nr and header
   Each of these is an array of strings. Both have the same size.
 */
function xhdr($field, $first, $last)
/* cs		- socket descriptor
 * field	- header field name
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 */
{
   global $cs;

	fputs($cs, "XHDR $field $first-$last\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["header"] = Array();
	$response = fgets($cs, 128);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode(" ", $line);
			array_unshift($retval["nr"], $split[0]);
			array_shift($split);
			$line = implode(" ", $split);
			array_unshift($retval["header"], $line);
		}
	}
	return $retval;
}

/* Sends XHDR command to the news server.
   Retval is an array with two fields: nr and header
   Each of these is an array of strings. Both have the same size.
 */
function xhdr2($field, $nr_array)
/* cs		- socket descriptor
 * field	- header field name
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 */
{
   global $cs;

	$nrs = implode(",", $nr_array);
	fputs($cs, "XHDR $field $nrs\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["header"] = Array();
	$response = fgets($cs, 128);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode(" ", $line);
			array_unshift($retval["nr"], $split[0]);
			array_shift($split);
			$line = implode(" ", $split);
			array_unshift($retval["header"], $line);
		}
	}
	return $retval;
}

/* Sends XPAT command to the news server.
   Retval is an array with two fields: nr and header
   Each of these is an array of strings. Both have the same size.
 */
function xpat($field, $first, $last, $pattern)
/* cs		- socket descriptor
 * field	- header field name
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 * pattern	- pattern to find
 */
{
   global $cs;

	fputs($cs, "XPAT $field $first-$last $pattern\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["header"] = Array();
	$response = fgets($cs, 128);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode(" ", $line);
			array_unshift($retval["nr"], $split[0]);
			array_shift($split);
			$line = implode(" ", $split);
			array_unshift($retval["header"], $line);
		}
	}
	return $retval;
}

/* Sends XPAT command to the news server.
   Retval is an array with two fields: nr and header
   Each of these is an array of strings. Both have the same size.
 */
function xpat2($field, $nr_array, $pattern)
/* cs		- socket descriptor
 * field	- header field name
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 * pattern	- pattern to find
 */
{
   global $cs;

   $nrs = implode(",", $nr_array);
	fputs($cs, "XPAT $field $nrs $pattern\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["header"] = Array();
	$response = fgets($cs, 128);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode(" ", $line);
			array_unshift($retval["nr"], $split[0]);
			array_shift($split);
			$line = implode(" ", $split);
			array_unshift($retval["header"], $line);
		}
	}
	return $retval;
}

/* Sends XOVER command to the news server.
   Retval is an array with the followong fields: nr, subject, author, time, msgid, references, size, lines, xref.
   Each of these is an array of strings. Both have the same size.
 */
function xover($first, $last)
/* cs		- socket descriptor
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 */
{
   global $cs;

	fputs($cs, "XOVER $first-$last\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["subject"] = Array();
	$retval["author"] = Array();
	$retval["time"] = Array();
	$retval["msgid"] = Array();
	$retval["references"] = Array();
	$retval["size"] = Array();
	$retval["lines"] = Array();
	$retval["xref"] = Array();
	$response = fgets($cs, 1024);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode("\t", $line);
			array_unshift($retval["nr"], $split[0]);
			array_unshift($retval["subject"], $split[1]);
			array_unshift($retval["author"], $split[2]);
			array_unshift($retval["time"], $split[3]);
			array_unshift($retval["msgid"], $split[4]);
			array_unshift($retval["references"], $split[5]);
			array_unshift($retval["size"], $split[6]);
			array_unshift($retval["lines"], $split[7]);
			array_unshift($retval["xref"], $split[8]);
		}
	}
	return $retval;
}

/* Sends XOVER command to the news server.
   Retval is an array with the followong fields: nr, subject, author, time, msgid, references, size, lines, xref.
   Each of these is an array of strings. Both have the same size.
 */
function xover2($nr_array)
/* cs		- socket descriptor
 * first	- number of the first message to parse
 * last		- number of the last message to parse
 */
{
   global $cs;

   $nrs = implode(",", $nr_array);
	fputs($cs, "XOVER $nrs\r\n");
	$retval = Array();
	$retval["nr"] = Array();
	$retval["subject"] = Array();
	$retval["author"] = Array();
	$retval["time"] = Array();
	$retval["msgid"] = Array();
	$retval["references"] = Array();
	$retval["size"] = Array();
	$retval["lines"] = Array();
	$retval["xref"] = Array();
	$response = fgets($cs, 1024);
	/* ensure that command finished with success */
	if (ereg("^221", $response)) {
		while ($line = fgets($cs, 1024)) {
			$line = chop($line);
			if ($line == ".") break;
			$split = explode("\t", $line);
			array_unshift($retval["nr"], $split[0]);
			array_unshift($retval["subject"], $split[1]);
			array_unshift($retval["author"], $split[2]);
			array_unshift($retval["time"], $split[3]);
			array_unshift($retval["msgid"], $split[4]);
			array_unshift($retval["references"], $split[5]);
			array_unshift($retval["size"], $split[6]);
			array_unshift($retval["lines"], $split[7]);
			array_unshift($retval["xref"], $split[8]);
		}
	}
	return $retval;
}

/* Posts a message to newsgroups. On success returns 1, on failure - 0. */
function post($msg, $agent, $host)
/* cs		- socket descriptor
 * msg		- structure which contains all header fields and body of the message:
	+ From
	+ Newsgroups
	+ Cc
	+ Followup-to
	+ References
	+ Subject
 */
{
   global $cs;

	include("config/config.inc");
	fwrite($cs, "POST\r\n");
	$response = fgets($cs, 128);
	/* ensure that we have right to write */
	if (ereg("^340", $response)) {
		/* prepare the fields to post */
		/* 1. Header fields can be either pure ascii or quoted
		      printable or base64. 8bit coding in header is illegal */
		/* Remove relevant slashes */
		$msg["From"] = stripslashes($msg["From"]);
		$msg["Email"] = stripslashes($msg["Email"]);
		$msg["Cc"] = stripslashes($msg["Cc"]);
		$msg["Subject"] = stripslashes($msg["Subject"]);
		/* Change the encoding to ISO standard */
		$msg["From"] = cp1250toiso88592($msg["From"], $charset);
		$msg["Cc"] = cp1250toiso88592($msg["Cc"], $charset);
		$msg["Subject"] = cp1250toiso88592($msg["Subject"], $charset);
		/* Encode 8bit to base64 form */
		$msg["From"] = encode_base64($msg["From"]);
		$msg["Cc"] = encode_base64($msg["Cc"]);
		$msg["Subject"] = encode_base64($msg["Subject"]);

		/* 2. We will send body as 8bit encoded */
		$msg["Body"] = stripslashes($msg["Body"]);
		$msg["Body"] = cp1250toiso88592($msg["Body"], $charset);

		$msg["References"] = trim($msg["References"]);

		/* As everything is properly encoded post the message */
		fwrite($cs, "From: ".$msg["Email"]." (".$msg["From"].")\n");
		fwrite($cs, "Newsgroups: ".$msg["Newsgroups"]."\n");
		if ($msg["Cc"])
			fwrite($cs, "Cc: ".$msg["Cc"]."\n");
		fwrite($cs, "Organization: ".$organization."\n");
		fwrite($cs, "Sender: ".$sender."\n");
		fwrite($cs, "Content-Type: text/plain; charset=".$charset."\n");
		fwrite($cs, "Content-Transfer-Encoding: 8bit\n");
		if ($msg["References"])
			fwrite($cs, "References: ".$msg["References"]."\n");
		fwrite($cs, "User-Agent: ".$useragent."\n");
		fwrite($cs, "X-Remote-User-Agent: ".$agent."\n");
		fwrite($cs, "X-Remote-Host: ".$host."\n");
		fwrite($cs, "Subject: ".$msg["Subject"]."\n");
		fwrite($cs, "\n".$msg["Body"]."\n$footer\r\n.\r\n");

		$response = fgets($cs, 128);
		if (ereg("^240", $response)) return 1;
		else return 0;
	} else {
		return 0;
	}
}

/* Lists groups aviable on the newsserver. Returns an array of group names,
   number of the messages in the group and last message number. */
function get_groups($template)
/* cs		- socket descriptor
 * template	- template for the newsgroup name
 */
{
   global $cs;

	$retval = Array();
	$retval["name"] = Array();
	$retval["count"] = Array();
	$retval["last"] = Array();
	fputs($cs, "LIST\r\n");
	$response = fgets($cs, 128);
	/* ensure that there was no error */
	/* FIXME: parse the output to get the meaning of the fields.
	   Default is: GROUP HIGH LOW FLAGS */
	if (ereg("^215", $response)) {
		while ($line = fgets($cs, 128)) {
			$line = chop($line);
			if ($line == ".") break;
			if (!ereg("^control", $line) &&
			    !ereg("^junk", $line) &&
			    !ereg("^to ", $line)) {
				if (!$template || ereg($template, $line)) {
				$fields = explode(" ", $line);
				$count = ($fields[1] >= $fields[2] ? $fields[1] - $fields[2] + 1 : 0);
				array_push($retval["name"], $fields[0]);
				array_push($retval["count"], $count);
				array_push($retval["last"], $fields[1]);
				}
			}
		}
	}
	return $retval;
}

/* Returns the body of the message. */
function body($post_nr)
/* cs		- socket descriptor
 * post_nr	- the number of the message
 */
{
   global $cs;

	fwrite($cs, "BODY $post_nr\r\n");
	$response = fgets($cs, 128);
	$retval = "";
	if (ereg("^222", $response)) {
		while ($line = fgets($cs, 1024)) {
			$end = chop($line);
			if ($end == ".") break;
			$retval = $retval.$line;
		}
	}
	return $retval;
}

?>
