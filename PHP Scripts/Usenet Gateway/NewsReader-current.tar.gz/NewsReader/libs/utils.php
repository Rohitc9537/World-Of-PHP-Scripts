<?

/*
        NewsReader: funkcje pomocnicze
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more
        details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */    


function my_error($txt, $url)
{
   include("config/config.inc");
   echo "<center>\n<table width=\"80%\" border=0 cellspacing=0 cellpadding=0>\n";
   echo "<tr align=\"center\">\n";
   echo "<td bgcolor=\"$infobgcolor\">";
   echo "<font color=\"$errorcolor\">$ERROR</font>";
   echo "</td>\n</tr>\n";
   echo "<tr>\n<td>$txt</td>\n</tr>";
   echo "<tr>\n";
   echo "<td align=\"center\">\n";
   echo "<a href=\"$url\">$BACK</a>\n";
   echo "</td>\n</tr>\n</table>\n</center>\n";
}


function my_OK($txt, $url)
{
   include("config/config.inc");
   echo "<center>\n<table width=\"80%\" border=0 cellspacing=0 cellpadding=0>\n";
   echo "<tr align=\"center\">\n";
   echo "<td bgcolor=\"$infobgcolor\">";
   echo "<font color=\"$OKcolor\">OK</font>";
   echo "</td>\n</tr>\n";
   echo "<tr>\n<td>$txt</td>\n</tr>";
   echo "<tr>\n";
   echo "<td align=\"center\">\n";
   echo "<a href=\"$url\">$BACK</a>\n";
   echo "</td>\n</tr>\n</table>\n</center>\n";
}


function news_error($url, $email)
{
   my_error($NEWS_ERROR, $url);
}


function news_OK($url)
{
   my_OK($NEWS_OK, $url);
}


?>
