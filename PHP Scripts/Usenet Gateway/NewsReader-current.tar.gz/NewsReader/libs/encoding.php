<?

if (!defined("_ENCODING_PHP_")):
define("_ENCODING_PHP_", 1);
/* PHP `quoted_printable_decode` function does not work properly:
   it should convert '_' characters into ' '. */
function my_quoted_printable_decode($string)
{
	$string = ereg_replace("_", " ", $string);
	return quoted_printable_decode($string);
}

/* Remove '=' at the end of the lines. `quoted_printable_decode` doesn't do it. */
function my_quoted_printable_decode2($string)
{
	$string = quoted_printable_decode($string);
	return preg_replace("/\=\n/", "", $string);
}

function decode_base64($string)
{
	$string = ereg_replace("'", "\'", $string);
	$string = preg_replace("/\=\?(.*?)\?b\?(.*?)\?\=/ieU", "base64_decode('\\2')", $string);
	return $string;
}

function decode_qp($string)
{
	$string = ereg_replace("'", "\'", $string);
	$string = preg_replace("/\=\?(.*?)\?q\?(.*?)\?\=/ieU", "my_quoted_printable_decode('\\2')", $string);
	return $string;
}

function encode_base64($string)
{
   include("config/config.inc");
   $ebit = 0;
	for ($i = 0; $i < strlen($string); $i++) {
	   if (Ord(substr($string, $i, 1)) > 127) {
		   $ebit = 1;
			break;
	   }
	}
	if ($ebit) return "=?$charset?b?".base64_encode($string)."?=";
	else return $string;
}

function cp1250toascii($string)
{
   $string = cp1250toiso88592($string);
   return iso88592toascii($string);
}

function iso88592toascii($string)
{
   $string = strtr($string, "����ʣ�Ӧ������󶿼", "asACELNOSZZacelnoszz");
   return $string;
}

function cp1250toiso88592($string)
{
   $string = strtr($string, "���������������䢘��", "����ʣ�Ӧ������󶿼");
   return $string;
}

/********************************
 *** Interface to the library ***
 ********************************/

/* Returns plain author of the post */
function plain_author($author)
/* author	- author of the post in core version
 */
{
	/* Decode from qp or base64 form */
	if (preg_match("/\=\?(.*?)\?b\?/i", $author)) $author = decode_base64($author);
	if (preg_match("/\=\?(.*?)\?q\?/i", $author)) $author = decode_qp($author);
	return $author;
}

/* Returns ready to print, html coded author of the post: <a href=mailto:name@domain.name>real name</a> */
function decode_author($author)
/* author	- author of the post in core version
 */
{
	/* Decode from qp or base64 form */
	if (preg_match("/\=\?(.*?)\?b\?/i", $author)) $author = decode_base64($author);
	if (preg_match("/\=\?(.*?)\?q\?/i", $author)) $author = decode_qp($author);
	/* Extract real name and e-mail address */
	/* According to RFC???? the From field can have one of three formats:
		1. Real Name <name@domain.name>
		2. name@domain.name (Real Name)
		3. name@domain.name
	 */
	/* 1st case */
	if (eregi("(.*) <([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+)>", $author, $regs)) {
		$email = $regs[2];
		$name = $regs[1];
	/* 2nd case */
	} else if (eregi("([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+) \((.*)\)", $author, $regs)) {
		$email = $regs[1];
		$name = $regs[2];
	/* 3rd case - it's broken line */
	} else if (eregi("<([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+)>", $author, $regs)) {
		$email = $regs[1];
		$name = $regs[1];
	/* 4th case - it's broken line */
	} else if (eregi("\(([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+)\)", $author, $regs)) {
		$email = $regs[1];
		$name = $regs[1];
	/* 5th case */
	} else {
		$email = $author;
	}
	if ($name == "") $name = $email;
	$name = eregi_replace("^\"(.*)\"$", "\\1", $name);
	/* Create return string */
	$retval = "<a href=\"mailto:$email\">$name</a>";
	return cp1250toiso88592($retval);
}

/* Returns author of the post */
function remove_email($author)
/* author	- author of the post in core version
 */
{
	/* Decode from qp or base64 form */
	if (preg_match("/\=\?(.*?)\?b\?/i", $author)) $author = decode_base64($author);
	if (preg_match("/\=\?(.*?)\?q\?/i", $author)) $author = decode_qp($author);
	/* Extract real name and e-mail address */
	/* According to RFC???? the From field can have one of three formats:
		1. Real Name <name@domain.name>
		2. name@domain.name (Real Name)
		3. name@domain.name
	 */
	/* 1st case */
	if (eregi("(.*) <([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+)>", $author, $regs)) {
		$name = $regs[1];
	/* 2nd case */
	} else if (eregi("([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+) \((.*)\)", $author, $regs)) {
		$name = $regs[2];
	/* 3rd case */
	} else {
		$name = $author;
	}
	/* Create return string */
	return cp1250toiso88592($name);
}

function get_email($author)
{
	/* Decode from qp or base64 form */
	if (preg_match("/\=\?(.*?)\?b\?/i", $author)) $author = decode_base64($author);
	if (preg_match("/\=\?(.*?)\?q\?/i", $author)) $author = decode_qp($author);
	/* Extract real name and e-mail address */
	/* According to RFC???? the From field can have one of three formats:
		1. Real Name <name@domain.name>
		2. name@domain.name (Real Name)
		3. name@domain.name
	 */
	/* 1st case */
	if (eregi("(.*) <([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+)>", $author, $regs)) {
		$name = $regs[2];
	/* 2nd case */
	} else if (eregi("([-a-z0-9\_\$\+\.]+\@[-a-z0-9\_\.]+[-a-z0-9\_]+) \((.*)\)", $author, $regs)) {
		$name = $regs[1];
	/* 3rd case */
	} else {
		$name = $author;
	}
	/* Create return string */
	return $name;
}

function decode_subject($subject)
/* subject	- subject of the post in core version
 */
{
	/* Decode from qp or base64 form */
	if (preg_match("/\=\?(.*?)\?b\?/i", $subject)) $subject = decode_base64($subject);
	if (preg_match("/\=\?(.*?)\?q\?/i", $subject)) $subject = decode_qp($subject);
	return cp1250toiso88592($subject);
}
endif;
?>
