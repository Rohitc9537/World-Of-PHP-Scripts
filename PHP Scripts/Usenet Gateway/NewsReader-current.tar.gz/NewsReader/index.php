<html>
  <head>
    <title>News Reader</title>
<?
include("config/config.inc");
echo "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=$charset\">\n";
?>
  <style type="text/css">
  <!--
<?
echo "    body { color: $fontcolor; background: $bgcolor; }\n";
echo "    td { color: $fontcolor; }\n";
echo "    a { color: $fontcolor; text-decoration: none; }\n";
?>
//-->
  </style>
  </head>

  <body>

  <table border=0 cellspacing=0 cellpadding=0>
    <tr>
<?
echo "      <td bgcolor=\"$themecolor\" width=40>\n";
?>
        &nbsp;
      </td>
      <td>
        <img src="images/yaur1.png" width=160 height=70 alt="Yet Another Usenet Reader" border=0>
      </td>
      <td valign=bottom>
        <a href="http://linuxnews.pl/"><img src="images/ln.png" alt="<? echo $LINUXNEWS; ?>" border=0></a>
      </td>
    </tr>
  </table>

  <br><br clear=all>
  <br>

  <table border=0 cellspacing=0 cellpadding=0>
    <tr><td colspan=2>
      <a href="info.php"><h3>1. <? echo $ABOUT; ?></h3></a>
    </td></tr>
    <tr><td colspan=2>
      <h3>2. News Reader OnLine</h3>
    </td></tr>
    <tr><td><img src="images/shim.gif" border=0 width=20 height=1></td><td>
      <a href="main.php"><h4>2.1 <? echo $SHOW_ALL_GROUPS; ?></h4></a>
    </td></tr>
    <tr><td><img src="images/shim.gif" border=0 width=20 height=1></td><td>
		<form method=GET action="main.php">
      <h4>2.2 <? echo $SHOW_GROUPS_CONTAINING; ?></h4>
		<input name="template" value="" size=10 maxlength=10>
		</form>
    </td></tr>
  </table>
  </body>

</html>
