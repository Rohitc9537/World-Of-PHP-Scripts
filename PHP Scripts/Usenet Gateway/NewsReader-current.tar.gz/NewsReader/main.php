<?

/*

        NewsReader
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more
        details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.

 */

include("config/config.inc");
require("libs/nr.php");
require("libs/utils.php");
include("include/HTMLHeader.inc");

?>

  <h3><? echo $AVIABLE_GROUPS; ?>:</h3>
  <center>
  <table width=90% border=0 cellspacing=0 cellpadding=4>
<?

  $cs = nnrp_connect();
  if ($cs)
	  print_groups_headers($template, 10);
?>
  </table>
  </center>

<?
include("include/HTMLTail.inc");
?>
