<?

/*
        NewsReader
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more
        details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */    


include("config/config.inc");
require("libs/nr.php");
require("libs/utils.php");
include("include/HTMLHeader.inc");

	$cs = nnrp_connect();

	if ($cs) {
		$gi = group($group);
		$last_post = $gi["last"];
		$first_post = $gi["first"];
		echo "<h3>News Reader OnLine</h3>\n";
		echo "<form method=POST action=\"send.php\">\n";
		echo "<center>\n";
		echo "<table border=0 cellspacing=1 cellpadding=2><tr bgcolor=\"$fontcolor\"><td>\n";
		echo "<table width=\"100%\" border=0 cellspacing=0 cellpadding=0>\n";
		echo "<tr bgcolor=\"$themecolor\">\n";
		echo "<td><br><b><font size=\"+1\">&nbsp;$GROUP:</font></b><br><br></td>\n";
		echo "<td><br><b><font size=\"+1\" color=\"$bgcolor\">&nbsp;&nbsp;<i>$group</i></font></b><br><br></td>\n";
		echo "<td align=right><br>[&nbsp;<u>$REPLY2</u>&nbsp;]&nbsp;&nbsp;&nbsp;<br><br></td>\n";
		echo "</tr>\n<tr bgcolor=\"$themecolor\">\n";
		echo "<td colspan=3 align=right><font color=\"$warningcolor\">$SEND_WARNING</font><br><br></td>\n";
		echo "</tr>\n";
		if ($post_nr == 0) { $post_nr = $last_post; }
		if ($post_nr > $last_post) { $post_nr = $last_post; }
		if ($post_nr < $first_post) { $post_nr = $first_post; }
		$aux = newsgroups();
      $news = $aux["header"][0];
		$aux = references();
      $ref = $aux["header"][0];
		$aux = message_id();
      $msgid = $aux["header"][0];
		$aux = author("__noemail__", $post_nr, $post_nr);
      $author2 = $aux["header"][0];
		if ($ref && $ref != "(none)") {
		   $newref = "$ref $msgid";
		} else {
			$newref = $msgid;
		}
		echo "<tr bgcolor=\"$fontcolor\">\n";
		echo "<td colspan=3><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
		echo "<tr bgcolor=\"$darkbg\">\n<td>&nbsp;&nbsp;<b>$AUTHOR:</b>&nbsp;&nbsp;</td>\n<td colspan=2><input type=\"text\" size=40 name=\"author\" value=\"$defauthor\"></td></tr>\n";
		echo "<tr bgcolor=\"$darkbg\">\n<td>&nbsp;&nbsp;<b>$EMAIL:</b>&nbsp;&nbsp;</td>\n<td colspan=2><input type=\"text\" size=40 name=\"email\" value=\"$defemail\"></td></tr>\n";
		echo "<tr bgcolor=\"$darkbg\">\n<td>&nbsp;&nbsp;<b>$SUBJECT:</b>&nbsp;&nbsp;</td>\n<td colspan=2><input type=\"text\" size=40 name=\"subject\" value=\"Re: ";
		print_topic();
		echo "\"></td></tr>\n";
//		echo "<tr bgcolor=\"$darkbg\">\n<td>&nbsp;&nbsp;<b>$NEWSGROUPS:</b>&nbsp;&nbsp;</td>\n<td colspan=2><input type=\"text\" size=40 name=\"newsgroups\" value=\"$group\"></td></tr>\n";
//		echo "<tr bgcolor=\"$darkbg\">\n<td>&nbsp;&nbsp;<b>$FUT:</b>&nbsp;&nbsp;</td>\n<td colspan=2><input type=\"text\" size=40 name=\"followup\"></td></tr>\n";
		echo "<tr bgcolor=\"$lightbg\">\n<td valign=top>&nbsp;&nbsp;<b>$BODY:</b>&nbsp;&nbsp;</td>\n";
		echo "<td colspan=2><textarea cols=75 rows=10 wrap=\"physical\" name=\"body\">\n";
		print_body(2, stripslashes($author2));
		echo "</textarea></td></tr>\n";
		echo "<tr bgcolor=\"$fontcolor\" valign=middle>\n";
		echo "<td colspan=3><img src=\"/images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
		echo "<tr bgcolor=\"$themecolor\" valign=middle>\n";
		echo "<td colspan=3 align=center><br>\n";
		echo "<input type=\"submit\" value=\"$SEND\">\n";
		echo "<br><br></td></tr></table>\n";
		echo "</td></tr></table>\n";
		echo "<input type=\"hidden\" name=\"newsgroups\" value=\"$group\">\n";
		echo "<input type=\"hidden\" name=\"references\" value=\"$newref\">\n";
		echo "<input type=\"hidden\" name=\"group\" value=\"$group\">\n";
		echo "</form>\n";
	} else {
		news_error("index.php",$admin);
	}

include("include/HTMLTail.inc");

?>
