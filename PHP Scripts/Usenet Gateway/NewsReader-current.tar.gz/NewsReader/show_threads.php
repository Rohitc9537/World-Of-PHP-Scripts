<?

/*
        NewsReader
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more
        details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */    

include("config/config.inc");
require("libs/nr.php");
require("libs/utils.php");
include("include/HTMLHeader.inc");

        $cs = nnrp_connect();
	
	if ($cs) {
	        $gi = group($group);
		$last_post = $gi["last"];
		$first_post = $gi["first"];
		echo "<h3>NewsReader OnLine</h3>\n";
		echo "<center>\n";
		echo "<table border=0 cellspacing=1 cellpadding=2>\n<tr bgcolor=\"$fontcolor\"><td>\n";
		echo "<table width=\"100%\" border=0 cellspacing=0 cellpadding=0>\n";
                echo "<tr bgcolor=\"$themecolor\">\n";
                echo "<td colspan=4><form method=\"GET\" action=\"show_filtered.php\">\n";
                echo "<input type=\"hidden\" name=\"group\" value=\"$group\">\n";
                echo "<input type=\"hidden\" name=\"post_nr\" value=\"$post_nr\">\n";
                echo "&nbsp;&nbsp<small><font color=\"$fontcolor\"><b>$SEARCHTEXT </b></font>";
                echo "<input type=text name=pattern size=20>";
      echo "<select name=\"search_header\"><option value=\"subject\">$SUBJECT<option value=\"author\">$AUTHOR</select></small>";
                echo "\n</td>\n</tr>";
                echo "<tr bgcolor=\"$fontcolor\">\n";
	        echo "<td colspan=4><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
        	echo "<tr bgcolor=\"$themecolor\">\n";
	        echo "<td><br><b><font size=\"+1\">&nbsp;$GROUP:&nbsp;&nbsp;&nbsp;</font></b><br><br></td>";
		echo "<td><br><b><font size=\"+1\" color=\"$bgcolor\"><i>$group</i>&nbsp;&nbsp;&nbsp;</font></b><br><br></td>\n";
		echo "<td colspan=2 align=right><br>[&nbsp;<a href=\"show_headers.php?group=".urlencode($group)."&post_nr=$post_nr\"><u>$SHOW_HEADERS</u></a>&nbsp;]&nbsp;&nbsp;<br><br></td>\n";
		echo "</tr>\n<tr bgcolor=\"$themecolor\">\n";
		echo "<td colspan=4 align=right>[&nbsp;<a href=\"new.php?group=".urlencode($group)."\"><u>$SEND_NEW_MESSAGE</u></a>&nbsp;]&nbsp;&nbsp;<br><br></td>\n";
		echo "</tr>\n";
		if ($post_nr == 0) { $post_nr = $last_post; }
		if ($post_nr > $last_post) { $post_nr = $last_post; }
		if ($post_nr < $first_post) { $post_nr = $first_post; }
		$l = $post_nr;
		if ($post_nr > $first_post + 15) { $f = $post_nr - 15; }
		else { $f = $first_post - 1; }
		$f1 = $f + 1;
        	echo "<tr bgcolor=\"$fontcolor\">\n";
	        echo "<td colspan=4><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
		if ($last_post >= $first_post) {
			$headers = Array();
			array_push($headers, $SUBJECT);
			array_push($headers, $AUTHOR);
			array_push($headers, $DATE);
			$f = print_topics($last_post, $first_post, 15, $headers, 4) - 1;
		}
        	echo "<tr bgcolor=\"$fontcolor\">\n";
	        echo "<td colspan=4><img src=\"images/shim.gif\" width=1 height=1 border=0 alt=\"\"></td>\n</tr>\n";
        	echo "<tr bgcolor=\"$themecolor\" valign=middle>\n";
	        echo "<td colspan=4 align=right><br>\n";
	
		if ($f >= $first_post) {
			echo "[&nbsp;<a href=\"show_threads.php?group=".urlencode($group)."&post_nr=$f\"><u>$PREVIOUS</u></a>&nbsp;]&nbsp;&nbsp;&nbsp;";
		} else {
			echo "&nbsp";
		}
		echo "<br><br></td></tr></table></td></tr></table>\n";
	} else {
		news_error("index.php",$admin);
	}

	include("include/HTMLTail.inc");

?>
