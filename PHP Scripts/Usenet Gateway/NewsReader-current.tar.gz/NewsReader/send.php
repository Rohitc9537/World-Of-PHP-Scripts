<?

/*
        NewsReader
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <jsygitow@elka.pw.edu.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more
        details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.
 */    


$tm = time() + 31536000;
setcookie("defauthor", $author, $tm);
setcookie("defemail", $email, $tm);

include("config/config.inc");
require("libs/nr.php");
require("libs/utils.php");
include("include/HTMLHeader.inc");

$cs = nnrp_connect();
if ($cs) {
	$ginfo = group($group);

	if (strlen($author) > 0) {
		$from = "$email ($author)";
	} else {
		$from = $email;
	}
	$msg = Array();
	$msg["From"] = $author;
	$msg["Email"] = $email;
	$msg["Newsgroups"] = $newsgroups;
	$msg["Cc"] = $cc;
	$msg["Followup-to"] = $fut;
	$msg["References"] = $references;
	$msg["Subject"] = $subject;
	$msg["Body"] = $body;
//	if (post($msg, $HTTP_USER_AGENT, $REMOTE_ADDR)) {
//	   news_OK("show_headers.php?group=".urlencode($group)."&post_nr=0");
//	} else {
//	   news_error("show_headers.php?group=".urlencode($group)."&post_nr=0", $admin);
//	}	
?>
Z przykro�ci� zawiadamiamy, �e wysy�anie wiadomo�ci na newsy przy pomocy
NewsReadera zosta�o wstrzymane do odwo�ania.
<?

} else {
	news_error("index.php", $admin);
}

include("include/HTMLTail.inc");

?>
