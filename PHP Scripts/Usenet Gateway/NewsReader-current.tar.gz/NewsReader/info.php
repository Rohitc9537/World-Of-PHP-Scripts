<html>
	<head>
	<title>News Reader - info</title>
<?
include("config/config.inc");
echo "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=$charset\">\n";
?>
  <style type="text/css">
  <!--
<?
echo "    body { color: $fontcolor; background: $bgcolor}\n";
echo "    td { color: $fontcolor; }\n";
echo "    a { color: $fontcolor; text-decoration: none; }\n";
?>
//-->
  </style>
  </head>

  <body>

  <table border=0 cellspacing=0 cellpadding=0>
    <tr>
<?
echo "      <td bgcolor=\"$themecolor\" width=40>\n";
?>
        &nbsp;
      </td>
      <td>
        <img src="images/yaur1.png" width=160 height=70 alt="Yet Another Usenet Reader" border=0>
      </td>
      <td valign=bottom>
	<a href="http://linuxnews.pl/"><img src="images/ln.png" alt="<? echo $LINUXNEWS; ?>" border=0></a>
      </td>
    </tr>
  </table>
  <br><br clear=all>
  <br>

<h3>Download</h3>

<p align=justify>
The current CVS version is <b>
<?
include("VERSION");
?>
</b>. The current release is
<b>1.0</b>. You should expect upgrades very soon.

<p align=justify>
The recommended method to get the News Reader is to get it from our CVS tree.
I am assuming that you have already cvs package installed on your system and
the binary is called 'cvs'.

<p align=justify>
First, set the CVSROOT environment variable. For bash:

<pre>
prompt:# export CVSROOT=:pserver:cvs@urtica.linuxnews.pl:/home/cvs
</pre>

<p align=justify>
Now, login to the CVS server:

<pre>
prompt:# cvs login
[ use 'cvs' as a password ]
</pre>

<p align=justify>
Now, you can get the most recent version of the News Reader:

<pre>
prompt:# cvs co NewsReader
</pre>

<p align=justify>
or if you already have the sources you can update your version:

<pre>
prompt:# cd ./NewsReader
prompt:# cvs update
</pre>

<p align=justify>
Now, you have News Reader on your system. You should edit config/config.inc
file and then you will be ready to use the News Reader on your WWW pages.

<p align=justify>
The WWW interface to the CVS tree is aviable via <a href=http://urtica.linuxnews.pl/cgi-bin/cvsweb.cgi>http://urtica.linuxnews.pl/cgi-bin/cvsweb.cgi</a>.

<p align=justify>
The tar.gz package is aviable from:
<a href="http://urtica.linuxnews.pl/~pkot/NewsReader-current.tar.gz">http://urtica.linuxnews.pl/~pkot/NewsReader-current.tar.gz</a>.

<p align=justify>
ChangeLog is aviable from:
<a href="http://urtica.linuxnews.pl/~pkot/ChangeLog">http://urtica.linuxnews.pl/~pkot/ChangeLog</a>.

<p align=justify>
The mailing list address is <a href="mailto:newsreader@linuxnews.pl">newsreader@linuxnews.pl</a>.
You can subscribe to this list by sending a message with a word 'subscribe'
in its body to the address: <a href="mailto:newsreader-request@linuxnews.pl">newsreader-request@linuxnews.pl</a>.

<p align=justify>
NewsReader is released under <a href="COPYING">GNU General Public License</a>.

  </body>

</html>
