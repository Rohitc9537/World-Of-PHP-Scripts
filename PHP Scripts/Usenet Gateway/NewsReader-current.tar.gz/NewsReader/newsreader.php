<?
/*
//    newsreader.php
//
//    Version:    2.0
//
//    Author:        Kalle Kiviaho - kivi@chl.chalmers.se
//    LinuxNews Hack: Jarek Sygitowicz - gwido@linuxnews.pl
//    Small cleanups: Pawe� Kot - pkot@linuxnews.pl 
//    Lastmod:    2000-09-15
//    Homepage:    http://swamp.chl.chalmers.se/backends/
//    Homepage:    http://newsreader.linuxnews.pl
//
//    This is an PHP include of SSI file
//
//    PHP:
//    <?
//    include("newsreader.php");
//    ?>
//
//    SSI:
//    <!--#include virtual="newsreader.php" -->
//
//    Feel free to modify the code and e-mail me fixes as you see
//    them fit...
//
*/

//    Customize as you like it
// $group = "pl.comp.os.linux"; odkomentuj to i dodaj swoja grupe jesli nie 
//                              mozesz uzywac parametrow przy wywolywanie 
//                            skryptu.


$link_postfix =    "<br>\n";
$cache_file   =    "/tmp/newsreader.$group.cache";
$cache_time   =    360;
$max_items    =    10;

//    End of customizations

$backend    =    "http://newsreader.linuxnews.pl/rss.php?group=$group";
$items      =    0;
$time       =    split(" ", microtime());

if ( (!(file_exists($cache_file))) ||
     ((filectime($cache_file) + $cache_time - $time[1]) < 0) ||
     (!(filesize($cache_file))) ) {

    $fpread = fopen($backend, 'r');
    $fpwrite = fopen($cache_file, 'w');

    while(! feof($fpread) ) {

        $buffer = ltrim(Chop(fgets($fpread, 256)));

        if (eregi("<item>", $buffer) && ($items < $max_items)) {
            $title = ltrim(Chop(fgets($fpread, 256)));
            $url = ltrim(Chop(fgets($fpread, 256)));

            $title = eregi_replace( "<title>", "", $title );
            $title = eregi_replace( "</title>", "", $title );
            $url = eregi_replace( "<link>", "", $url );
            $url = eregi_replace( "</link>", "", $url );

            fputs($fpwrite, "<li type=\"square\"><a href=\"$url\">$title</a>$link_postfix</li>");

            $items++;
        }

    }
    fclose($fpread);
    fclose($fpwrite);
}
printf("<ul>");
include($cache_file);
printf("</ul>");
?>
