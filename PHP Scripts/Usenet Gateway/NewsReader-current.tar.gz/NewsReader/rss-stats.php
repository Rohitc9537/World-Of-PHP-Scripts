<?

/*

        NewsReader
        Copyright (C) 1999, 2000:
                Jaros�aw Sygitowicz <gwido@linuxnews.pl>,
                Pawe� Kot <pkot@linuxnews.pl>

        Released under the terms of the GNU GPL, see file COPYING for more details.
        Rozpowszechnianie na warunkach GPL, szczeg�y w pliku COPYING.

 */

echo "<?xml version=\"1.0\" encoding=\"iso-8859-2\"?>
<!DOCTYPE rss PUBLIC \"-//Netscape Communications//DTD RSS 0.91//EN\"
                \"http://my.netscape.com/publish/formats/rss-0.91.dtd\">
<rss version=\"0.91\">
<channel>
<title>NewsReader OnLine</title>
<link>http://newsreader.linuxnews.pl</link>
<description>Statystyki Usenetu: $group</description>
<language>pl</language>
<image>
  <title>NewsReader</title>
  <url>http://newsreader.linuxnews.pl/images/yaur.png</url>
  <link>http://newsreader.linuxnews.pl</link>
  <description>Yet Another Usenet Reader</description>
</image>
";

require "libs/nr.php";
$cs = nnrp_connect();

if ($cs) {
   $gi = group($group);
   $last_post = $gi["last"];
   $first_post = $gi["first"];
   $post_nr = $last_post;
	if (!$count) $count = 1000;
	if ($last_post - $count > $first_post) $first_post = $last_post - $count;
   print_stats($first_post, $last_post);
}

echo "</channel>
</rss>
";