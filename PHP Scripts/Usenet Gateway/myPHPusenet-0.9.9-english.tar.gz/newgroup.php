#!/usr/local/bin/php -q

<?

	include("conf.inc.php");

	$groupname = $GLOBALS[newsgroup];
	$mode = $GLOBALS[mode];

	@mysql_connect($hostname, $username, $password) OR DIE ("Could not connect");
	@mysql_select_db("$database") OR DIE ("Could not open database");

	$db_ng_name = ereg_replace("\.","_", $groupname);


if ($mode == "insert" || $mode == "Insert" || $mode == "INSERT") {

	$insert_struct = "CREATE TABLE $db_ng_name (id mediumint unsigned NOT NULL auto_increment, from_name varchar(50), from_email varchar(50), subject varchar(150), date date, body text NOT NULL, basename mediumint unsigned, PRIMARY KEY (id), KEY $db_ng_name"."_subject (subject) KEY $db_ng_name"."_from_name (from_name), KEY $db_ng_name"."_from_email (from_email) )";
	$insert = MYSQL_QUERY($insert_struct);
	PRINT "Structure Created...\n";

	$insert_control = "INSERT INTO last VALUES ('$db_ng_name',1)";
	$runit = MYSQL_QUERY($insert_control);
	PRINT "Control table updated...\n";

}

elseif ($mode == "remove" || $mode == "delete" || $mode == "drop") {

	$delete_table = "DROP TABLE $db_ng_name";
	$drop = MYSQL_QUERY($delete_table);
	PRINT "Table removed...\n";

	$delete_control = "DELETE FROM last WHERE (newsgroup LIKE '$db_ng_name')";
	$runit = MYSQL_QUERY($delete_control);
	PRINT "Control table updated...\n";

}

elseif ($mode == "reset") {

	$reset_table = "DELETE FROM $db_ng_name";
	$reset = MYSQL_QUERY($reset_table);
	PRINT "Table reset...\n";

	$reset_control = "UPDATE last SET last.last = '1' WHERE (newsgroup LIKE '$db_ng_name')";
	$runit = MYSQL_QUERY($reset_control);
	PRINT "Control table updated...\n";

}

elseif ($mode == "index") {

	$seperator = "_";

	$dbase = $db_ng_name;
	$index = $db_ng_name .=$seperator .=$column;

	$make_index = "CREATE index $index ON $dbase($column)";
	$runit = MYSQL_QUERY($make_index);
	PRINT "Indexs created...\n";

}

else {
	echo "Syntax:\n\n\rnewgroup.sh [mode] [news.group]\n\n\rWhere newsgroup is one of these:\n\n\rinsert - inserts newsgroup\n\rdelete - deletes newsgroup\n\rreset - resets newsgroup\n\rindex column - makes an index\n";

}

?>
