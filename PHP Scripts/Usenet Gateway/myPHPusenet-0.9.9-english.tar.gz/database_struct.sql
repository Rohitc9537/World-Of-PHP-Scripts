# MySQL dump 8.6
#
# Host: localhost    Database: news
#--------------------------------------------------------
# Server version	3.23.20-beta-log

#
# Table structure for table 'auth'
#

CREATE TABLE auth (
  realname varchar(70),
  username varchar(20),
  password varchar(20),
  type varchar(10)
);

#
# Table structure for table 'last'
#

CREATE TABLE last (
  newsgroup varchar(50),
  last int(5)
);

#
# Table structure for table 'stats'
#

CREATE TABLE stats (
  results int(5),
  exec_time double(16,4),
  ip_nr varchar(60)
);
