<?

$hostname = "localhost"; 		/* MySQL hostname */
$username = "";				/* MySQL username */
$password = "";				/* MySQL password */
$database = "news";			/* MySQL database */

$server = "news.netimages.com";		/* NNTP-server hostname */

$email = "martin@nitro.dk";		/* The email address the daily report gets sent to */

$subject = "News-parser report";	/* subject of the daily report */

$logname = "log.txt";			/* Filename of the log-file */

?>
