<?

$groups[1] = "comp.os.linux.announce";
$groups[2] = "comp.os.linux";

?>
