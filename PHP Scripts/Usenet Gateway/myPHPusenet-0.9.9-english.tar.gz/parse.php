#!/usr/local/bin/php -q

<?

include("conf.inc.php");


@mysql_connect($hostname, $username, $password) OR DIE ("Could not connect to the database with these values:\n\n\t\$hostname:\t\t$hostname\n\t\$username:\t\t$username\n\t\$password:\t\t$password\n");



$dirname = $group;

########################################################################
# NNTP-code
########################################################################


IF ($argc == 1) {
	echo "Wrong parameters";
	exit;
}

ELSEIF ($argc == 4) {
	$server = $argv[1];
	$group = $argv[2];
	$postnr = $argv[3];
}

$fp = fsockopen("$server", 119);
set_socket_blocking($fp, true);
$response = fgets($fp, 256);
fputs("$fp", "GROUP $group\n");
$gruppe = fgets($fp, 1024);
fputs($fp, "ARTICLE $postnr\n");
fputs($fp, "QUIT\n");

while(!feof($fp) ) {

	$contents = $contents . (fgets($fp, 4096) );

}

$post = split("\n", $contents);
$size = sizeof($post);
$n = 0;
fclose($fp);

$range = split(" ", $gruppe);

$range_start = $range[2];
$range_end = $range[3];


########################################################################
# NNTP-code end
########################################################################

	$j = 1;
        $body_found = 0;
        while ($body_found == 0) {
                IF (ereg("^Newsgroups: ", $post[$j]) ) {
                        $body_start = $j;
                        $body_found = 1;
                        break;
                }
                ELSE {
			IF ($j > 1024) {
						break;
			}
                        $j++;
                }
        }

$newsgroup_raw = split(":", $post[$j]);

############################################
$newsgroup = trim($newsgroup_raw[1]);      #
############################################

$db_name = ereg_replace("\.", "_", "$newsgroup");

IF (ereg("\,", $db_name) ) {
	PRINT "Cant insert crossposts yet...\n";
	exit();
}

@mysql_select_db("$database") OR DIE ("Couldnt select the database:\t $database");

$finddupe_query = "SELECT basename FROM $db_name WHERE basename = $postnr";

$finddupe_run = MYSQL_QUERY($finddupe_query);


IF ($finddupe_result = @MYSQL_RESULT($finddupe_run,0,basename) ) {
	PRINT "$postnr is already in $db_name\n";
	exit;
}



	$j = 1;
        $body_found = 0;
        while ($body_found == 0) {
                IF (ereg("^From: ", $post[$j]) ) {
                        $body_start = $j;
                        $body_found = 1;
                        break;
                }
                ELSE {
			IF ($j > 1024) {
						break;
			}
                        $j++;
                }
        }


$from_raw = split("From:", $post[$j]);

IF (ereg("<", $from_raw[1]) ) {

        $from_name_find1 = explode("<", $from_raw[1]);
        $from_name_find = ($from_name_find1[0]);
}

ELSEIF (ereg("\(", $from_raw[1]) ) {

        $from_name_find2 = explode("(", $from_raw[1]);
        $from_name_find1 = explode(")", $from_name_find2[1]);
        $from_name_find = $from_name_find1[0];
}

ELSE {
        $from_name_find = $from_raw[1];
}

##########################################################
$from_name = addslashes(ucwords(trim($from_name_find))); #
##########################################################

IF (ereg("@", $from_raw[1]) ) {

        IF (ereg("\(", $from_raw[1]) ) {
                $from_email_find1 = explode("(", $from_raw[1]);
                $from_email_find = trim($from_email_find1[0]);

        }
        ELSEIF (ereg("<", $from_raw[1]) ) {
                $from_email_find2 = explode("<", $from_raw[1]);
                $from_email_find1 = explode(">", $from_email_find2[1]);
                $from_email_find = trim($from_email_find1[0]);
        }


        ELSE {
                $from_email_find = trim($from_raw[1]);
        }
}

ELSEIF (ereg("^Reply-To: ", $post[$j]) ) {

	$j = 1;
        $body_found = 0;
        while ($body_found == 0) {
                IF (ereg("^Reply-To: ", $post[$j]) ) {
                        $body_start = $j;
                        $body_found = 1;
                        break;
                }
                ELSE {
			IF ($j > 1024) {
						break;
			}
			ELSE {
                        $j++;
			}
                }
        }
}



$from_email_raw = split("Reply-To:", $post[$j]);


$from_email = addslashes(trim($from_email_raw[1]));


IF (ereg("@", $from_email) ) {

	$email = trim($from_email);
}

ELSEIF (ereg("@", $from_email_find) ) {

	$email = trim($from_email_find);
}

ELSE {

	$email = trim($from_email);
}

	$j = 1;
        $body_found = 0;
        while ($body_found == 0) {
                IF (ereg("^Subject: ", $post[$j]) ) {
                        $body_start = $j;
                        $body_found = 1;
                        break;
                }
                ELSE {
			IF ($j > 1024) {
						break;
			}
                        $j++;
                }
        }

$subject_raw = split("Subject:", $post[$j]);
$subject_trimmed = trim($subject_raw[1]);

###########################################
$subject = addslashes($subject_trimmed);  #
###########################################

	$j = 1;
        $body_found = 0;
        while ($body_found == 0) {
                IF (ereg("^Date: ", $post[$j]) ) {
                        $body_start = $j;
                        $body_found = 1;
                        break;
                }
                ELSE {
			IF ($j > 1024) {
						break;
			}
                        $j++;
                }
        }


$date_raw = split(":", $post[$j]);

$date_day = split(" ", $date_raw[1]);

IF (ereg("(Mon|Tue|Wed|Thu|Fri|Sat|Sun)", $date_raw[1]) ) {

        IF ($date_day[3] == "Jan") {$date_maaned = 01;};
        IF ($date_day[3] == "Feb") {$date_maaned = 02;};
        IF ($date_day[3] == "Mar") {$date_maaned = 03;};
        IF ($date_day[3] == "Apr") {$date_maaned = 04;};
        IF ($date_day[3] == "May") {$date_maaned = 05;};
        IF ($date_day[3] == "Jun") {$date_maaned = 06;};
        IF ($date_day[3] == "Jul") {$date_maaned = 07;};
        IF ($date_day[3] == "Aug") {$date_maaned = 08;};
        IF ($date_day[3] == "Sep") {$date_maaned = 09;};
        IF ($date_day[3] == "Oct") {$date_maaned = 10;};
        IF ($date_day[3] == "Nov") {$date_maaned = 11;};
        IF ($date_day[3] == "Dec") {$date_maaned = 12;};

        $date = "$date_day[4]-$date_maaned-$date_day[2]";
}

ELSEIF (ereg("(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)", $date_raw[1]) ) {

        IF ($date_day[2] == "Jan") {$date_maaned = "01";};
        IF ($date_day[2] == "Feb") {$date_maaned = "02";};
        IF ($date_day[2] == "Mar") {$date_maaned = "03";};
        IF ($date_day[2] == "Apr") {$date_maaned = "04";};
        IF ($date_day[2] == "May") {$date_maaned = "05";};
        IF ($date_day[2] == "Jun") {$date_maaned = "06";};
        IF ($date_day[2] == "Jul") {$date_maaned = "07";};
        IF ($date_day[2] == "Aug") {$date_maaned = "08";};
        IF ($date_day[2] == "Sep") {$date_maaned = "09";};
        IF ($date_day[2] == "Oct") {$date_maaned = "10";};
        IF ($date_day[2] == "Nov") {$date_maaned = "11";};
        IF ($date_day[2] == "Dec") {$date_maaned = "12";};

        $date = "$date_day[3]-$date_maaned-$date_day[1]";
}


$j = 1;
$body_found = 0;

while ($body_found == 0) {

	IF (ereg("Xref: ", $post[$j]) ) {
		$body_start = $j++;
		$body_found = 1;
		break;
	}
	ELSE {
			IF ($j > 512) {
						break;
			}
		$j++;
	}
}

$e = 1;
$body_found_end = 0;

while ($body_found_end == 0) {

	IF (ereg("^205 ", $post[$e]) ) {
		$body_end = $e--;
		$body_found_end = 1;
		break;
	}
	ELSE {
			IF ($e > 1024) {
						break;
			}
		$e++;
	}
}


$isdupe = "SELECT basename FROM $database WHERE (basename LIKE '$postnr')";
$isdupe_query = MYSQL_QUERY($isdupe);
$fundet = @MYSQL_NUMROWS($isdupe_query);

IF ($fundet > 0) {
	PRINT "The file: $file is already in the database!, Aborting\n";
	exit();
}

IF ($from_name == "" && $from_email_find == "" && $subject == "" && $date == "" && $body == "") {
	PRINT "Not a valid post, aborting...\n";
	exit();
}

$name = addslashes($from_name);



while ($j < $e ) {
	$body2 = addslashes($post[$j]);
	$newline = "\n";
	$body.= $body2.= $newline;
	$j++;
}

$query = "INSERT INTO $db_name (id,from_name,from_email,subject,date,body,basename) VALUES ('','$from_name','$from_email_find','$subject','$date','$body','$postnr')";

$query2 = "UPDATE last SET last.last = $postnr WHERE newsgroup = '$db_name'";

MYSQL_QUERY($query);
MYSQL_QUERY($query2);

MYSQL_CLOSE();

$printecho = ereg_replace("_",".", "$db_name");

echo "$printecho: $subject";

?>
