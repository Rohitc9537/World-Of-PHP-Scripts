#!/bin/sh

export mode=$1
export newsgroup=$2
export column=$3

./newgroup.php
