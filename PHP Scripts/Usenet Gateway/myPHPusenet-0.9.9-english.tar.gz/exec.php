#!/usr/local/bin/php -q

<?

$start = gettimeofday();

include("conf.inc.php");
include("newsgroups.inc.php");

@mysql_connect($hostname, $username, $password) OR DIE ("Could not connect");
@mysql_select_db("$database") OR DIE ("Could not open database");

$i = 0;
$j = 0;

while($i < sizeof($groups) ) {

        $fp = fsockopen("$server", 119);
        set_socket_blocking($fp, true);
        $response = fgets($fp, 256);
        fputs("$fp", "GROUP $groups[$i]\n");
        $gruppe = fgets($fp, 1024);
	$range = split(" ", $gruppe);
	$range_start = $range[2];
	$range_end = $range[3];

	$db_ng_name[$i] = ereg_replace("\.","_", $groups[$i]);

	$query1 = "UPDATE last SET last.last = '$range_end' WHERE newsgroup = '$db_ng_name[$i]'";
	$query2 = "SELECT last FROM last WHERE (newsgroup LIKE '$db_ng_name[$i]')";
	$runit2 = MYSQL_QUERY($query2);
	$result = @MYSQL_RESULT($runit2,0,last);

	IF (@MYSQL_NUMROWS($runit2) == 1) {

	$range_start = $result;

		while($range_start < $range_end) {
		
			system("parse.php $server $groups[$i] $range_start");

			$range_start++;
			$j++;
		
			}

		}

	ELSE {
		PRINT "No new posts in $groups[$i]\n";
	}

	$runit1 = MYSQL_QUERY($query1);

	$i++;
}

$tables = MYSQL_LIST_TABLES($database);
$k = 0;

WHILE ($k < MYSQL_NUM_ROWS ($tables)) {
	$area_names[$k] = MYSQL_TABLENAME ($tables, $k);
	$query = "SELECT count(*) AS total_nr FROM $area_names[$k]";
	$q_string = @MYSQL_QUERY($query);
	$fundet = @MYSQL_RESULT($q_string,0,total_nr);
	
	$total += $fundet;
	$k++;
}


$date = date("d");
$month = date("F");
$shortmonth = date("M");
$year = date("Y");
$hour = date("H");
$min = date("i");
$sec = date("s");

$end =  gettimeofday();

$exec_time = number_format( (($end["sec"] + $end["usec"]/1000000) - ($start["sec"] + $start["usec"]/1000000)), 3);

$contents = "Hi!\n\nThe newsparser was run $date $month $year at $hour:$min:$sec, and it inserted $j posts in the\ndatabasen, there are now $total posts in the \n\nDatabase the update took $exec_time seconds.\n\n-- \n\nYours Truly.\n\tmyPHP usenet";

mail("$email", "$subject", "$contents", "From:$USER@$HOSTNAME\nReply-To: martin@nitro.dk");

$fp = fopen($logname, "a") or die ("Could not open logfile");
$logmess = "$shortmonth $date $hour:$min:$sec the newsparser inserted $j posts, there are now $total total\n";
$write = fputs($fp, $logmess);
fclose($fp);

?>
