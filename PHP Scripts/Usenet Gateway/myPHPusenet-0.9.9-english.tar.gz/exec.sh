#!/bin/sh

export server=$1
export newsgroup=$2
export msgnr=$3

./parse.php

exit 0
