#!/bin/sh
# handles headers
# usage : nget_download [group] [process #] [delay in seconds]

NDIR=/nntp
NGETHOME=$NDIR/.nget5
NLOG=$NDIR/logs
export NGETHOME

rm -f $NDIR/process-$2.log
sleep $3

nice -n 15 /usr/local/bin/nget --tries 1 -g$1 2>&1 > $NDIR/process-$2.log
#nice -n 15 /usr/bin/nget --host host3 --tries 1 -g$1 2>&1 > $NDIR/process-$2.log
echo HEADERDONE_$1 >> $NDIR/process-$2.log

# logging
cat $NDIR/process-$2.log | sed "s/^.*\[1K\cM//g" | sed "s/[\r\n]//g" > $NLOG/headers_`date +%y-%m-%d_%H-%M-%S`_p$2_$1.log
