#!/bin/sh
# handles downloads (not incomplete files yet)
# usage : nget_download [group] [messageid] [process #] [downloadID] [delay in seconds]
#
# <Make it check that all 4 commands are passed>

NDIR=/nntp
NGETHOME=$NDIR/.nget5
NLOG=$NDIR/logs
export NGETHOME

rm -f $NDIR/process-$3.log
sleep $5

# -Di will make it retrieve incomplete posts, -dfIM will make it ignore dupes and incompletes

nice -n 15 /usr/local/bin/nget -Di --tries 1 --text ignore --makedirs yes --path $NDIR/files/$1 --temppath $NDIR/temp --no-autopar -G$1 -R "messageid $2 ==" > $NDIR/process-$3.log 2>&1

echo DOWNLOADDONE_$4 >> $NDIR/process-$3.log

# logging
cat $NDIR/process-$3.log | sed "s/^.*\[1K\cM//g" | sed "s/[\r\n]//g" > $NLOG/dl_`date +%y-%m-%d_%H-%M-%S`_p$3.log
