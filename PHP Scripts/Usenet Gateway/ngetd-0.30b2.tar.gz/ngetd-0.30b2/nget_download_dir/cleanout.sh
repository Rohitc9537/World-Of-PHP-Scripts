rm -f /nntp/.nget5/alt.binaries.* /nntp/logs/* /nntp/temp/* /nntp/process-?.log /nntp/.nget5/*.gz
