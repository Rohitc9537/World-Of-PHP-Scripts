<?

	set_time_limit(10*60);		// 10 min
	//error_reporting(E_ALL);	// see every single little 'error'
	
	require_once 'config.php';									// load config file
	require_once $cfg["DIRS_WEB"] . 'gui/gui_functions.php';	// general functions.
	
	// start session
	header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');

	session_cache_limiter('nocache');
	session_start();
	
	$render_time = array();
	list($usec, $sec) = explode(' ', microtime()); $render_time['total'] = ((float)$usec + (float)$sec);
	
/* ---------------------------------------------------------------------------
	Initalization.
	----------------------------------------------------------------------- */
	flush();
	
	require_once $cfg["DIRS_WEB"] . 'daemon/class_db_control.php';			// db class
	$class_db = new db_control($cfg);
	
	require_once $cfg["DIRS_WEB"] . 'daemon/class_groups_control.php';		// using groups
	$ngetgroups = new groups_control();
	// set internal classes
	$ngetgroups->class_db = new db_control($cfg);
	// init
	$ngetgroups->groups_control_init();
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE><? echo $nget_version; ?></TITLE>
<LINK rel="stylesheet" href="css/<? $sql = 'SELECT css FROM nget_backbone'; $class_db->query_db($sql); $row = $class_db->sql_results(); echo $row['css']; ?>" type="text/css">
<SCRIPT language="JavaScript1.2" src="js/nget.js" type="text/javascript"></script>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache; charset=iso-8859-1">
<META NAME="robots" CONTENT="noindex, nofollow">
<?
	// refresh content when viewing certain pages
	if ((($_GET['v'] == 'logs') || ($_GET['v'] == 'settings')) && ($cfg['GUI_REFRESH_LOGS'] != 0)) {
		echo "<META HTTP-EQUIV='refresh' CONTENT='" . $cfg['GUI_REFRESH_LOGS'] . "'>\n";
	}
?>
</HEAD>
<BODY>
<DIV CLASS='topPadding'><?

	topmenu_item('posts', $lang['index']['posts']);
	topmenu_item('queue', $lang['index']['queue']);
	topmenu_item('groups', $lang['index']['groups']);
	topmenu_item('grouptypes', $lang['index']['grouptypes']);
	topmenu_item('blacklists', $lang['index']['blacklists']);
	topmenu_item('wishlists', $lang['index']['wishlists']);
	topmenu_item('junk', $lang['index']['junk']);
	topmenu_item('stats', $lang['index']['stats']);
	topmenu_item('settings', $lang['index']['settings']);
	topmenu_item('logs', $lang['index']['logs']);
	topmenu_item('help', $lang['index']['help']);
	topmenu_item('about', $lang['index']['about']);

	// draw refreshing iframe for realtime daemon monitoring
	if (($_GET['v'] != 'fg') && ($cfg['GUI_REFRESH_DAEMON_STATS'] != 0)) {
		echo '<iframe height="11" width="110" scrolling="No" src="gui_speed.php" frameborder="0"' .
			' STYLE="border: 0px; margin: 0px; padding: 0px;"></iframe>';
	}
	echo '</DIV>';
	
/* ---------------------------------------------------------------------------
	Viewing posts.
   ------------------------------------------------------------------------ */
	if (($_GET['v'] == 'posts') || ($_GET['v'] == 'fg')) {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_posts.php';
/* ---------------------------------------------------------------------------
	Viewing the download queue.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'queue') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_queue.php';
/* ---------------------------------------------------------------------------
	Edit groups.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'groups') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_groups.php';
/* ---------------------------------------------------------------------------
	Edit group types.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'grouptypes') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_grouptypes.php';
/* ---------------------------------------------------------------------------
	Blacklists
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'blacklists') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_blacklists.php';
/* ---------------------------------------------------------------------------
	Blacklists
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'wishlists') {
		//require_once $cfg["DIRS_WEB"] . 'gui_wishlists.php';
		echo '<BR>Coming soon.';
/* ---------------------------------------------------------------------------
	Statistics.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'stats') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_stats.php';
/* ---------------------------------------------------------------------------
	Controlling the daemon, viewing daemon parameters.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'settings') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_daemon_control.php';	
/* ---------------------------------------------------------------------------
	Viewing the daemon logs.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'logs') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_log.php';
/* ---------------------------------------------------------------------------
	Viewing help.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'help') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_help.php';
/* ---------------------------------------------------------------------------
	Purge junk posts.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'junk') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_junk.php';
/* ---------------------------------------------------------------------------
	Viewing the about page.
   ------------------------------------------------------------------------ */
	} elseif ($_GET['v'] == 'about') {
		require_once $cfg["DIRS_WEB"] . 'gui/gui_about.php' ;
	}
/* ---------------------------------------------------------------------------
	Moves all selected posts into the download queue for the daemon
	to process.
   ------------------------------------------------------------------------ */
	if ($_POST['posts_downloadselectedfiles'] || $_POST['posts_downloadimmediately']) {
		// combine all keys by value, and then parse through all the dl ones
		$items = 0;
		if ($posts = $_POST['posts'] ) {
			while ($onepost = array_pop($posts)) {
				// the backend fills in all the extra information necessary, just dump the post_IDs/file_groups_IDs
				// if not a filegroup
				if (preg_match("/^P\d+$/", $onepost)) {
					$onepost = preg_replace("/^P(\d+)$/", "$1", $onepost);
					if ($_POST['posts_downloadimmediately']) {
						$sql = 'UPDATE download SET download_custom_position=download_custom_position+1 ' .
							'WHERE download_custom_position > 0 AND download_status != 2';
						$class_db->write_db($sql);
						$sql = 'INSERT INTO download (download_post_ID, download_status, download_custom_position) VALUES ("' . $onepost . '", 99, 1)';
					} else {
						$sql = 'INSERT INTO download (download_post_ID, download_status) VALUES ("' . $onepost . '", 99)';
					}
					$class_db->write_db($sql);
					$items++;
				} elseif (preg_match("/^P\d+F\d+$/", $onepost)) {
					$onepost = preg_replace("/^P\d+F(\d+)$/", "$1", $onepost);
					if ($_POST['posts_downloadimmediately']) {
						$sql = 'UPDATE download SET download_custom_position=download_custom_position+1 ' .
							'WHERE download_custom_position > 0 AND download_status != 2';
						$class_db->write_db($sql);
						$sql = 'INSERT INTO download (download_file_group_ID, download_status, download_custom_position) VALUES ("' . $onepost . '", 99, 1)';
					} else {
						$sql = 'INSERT INTO download (download_file_group_ID, download_status) VALUES ("' . $onepost . '", 99)';
					}
					$class_db->write_db($sql);
					$items++;
				}
			}
		}
		if ($items > 0) {
			echo '<BR> ' . $items . ' ' . $lang['index']['selecteditemshavebeenqueued'];
		}
	}
?>
</BODY>
</HTML>