<?
	// view queue
	
	// if showing all files or not
	if ((int)$_GET["showqueued"] == 1) {
		$_SESSION["dl_show_queue"] = true;
	} elseif (!$_SESSION["dl_show_queue"] || ((int)$_GET["showqueued"] == 2)) {
		$_SESSION["dl_show_queue"] = false;
	}
	if ((int)$_GET["showdl"] == 1) {
		$_SESSION["dl_show_downloaded"] = true;
	} elseif (!$_SESSION["dl_show_downloaded"] || ((int)$_GET["showdl"] == 2)) {
		$_SESSION["dl_show_downloaded"] = false;
	}

	
	// process actions
	if ($_POST['queue_pause'] || $_POST['queue_unpause'] || $_POST['queue_pauseall'] || 
		$_POST['queue_unpauseall'] || $_POST['queue_movetotop'] || $_POST['queue_cancel'] ||
		$_POST['queue_cancelallqueued'] || $_POST['complete_requeue'] || $_POST['complete_requeueattop'] ||
		$_POST['complete_requeueandpause'] || $_POST['complete_clear'] || $_POST['complete_clearalldownloaded']) {
		
		$tmpa = $_POST["queued"];
		
		// queued
		if (($_POST['queue_pause']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_status=4" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if ($_POST['queue_pauseall']) {
			$sql = "UPDATE download SET download_status=4" .
				" WHERE download_status = 0";
			$class_db->write_db($sql);
		}
		if (($_POST['queue_unpause']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_status=0" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if ($_POST['queue_unpauseall']) {
			$sql = "UPDATE download SET download_status=0" .
				" WHERE download_status = 4";
			$class_db->write_db($sql);
		}
		if (($_POST['queue_movetotop']) && (count($tmpa))) {
			$sql = "UPDATE download SET download_custom_position=download_custom_position+1" .
				" WHERE download_custom_position > 0";
			$class_db->write_db($sql);
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_custom_position = 1" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if (($_POST['queue_cancel']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "DELETE FROM download" .
					" WHERE download_id=" . $tmp . " AND (download_status = 0 OR download_status = 4)";
				$class_db->write_db($sql);
			}			
		}
		if ($_POST['queue_cancelallqueued']) {
			$sql = "DELETE FROM download" .
				" WHERE download_status = 0 OR download_status = 4";
			$class_db->write_db($sql);
		}
		// completed
		if (($_POST['complete_requeue']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_status = 0, download_custom_position = 0, download_retry = 0" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if (($_POST['complete_requeueattop']) && (count($tmpa))) {
			$sql = "UPDATE download SET download_custom_position=download_custom_position+1" .
				" WHERE download_custom_position > 0". " AND download_status != 2";
			$class_db->write_db($sql);
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_status = 0, download_custom_position = 1, download_retry = 0" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if (($_POST['complete_requeueandpause']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "UPDATE download SET download_status = 4, download_custom_position = 0, download_retry = 0" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if (($_POST['complete_clear']) && (count($tmpa))) {
			while ($tmp = array_pop($tmpa)) {
				$sql = "DELETE FROM download" .
					" WHERE download_id=" . $tmp . " AND download_status != 2";
				$class_db->write_db($sql);
			}
		}
		if ($_POST['complete_clearalldownloaded']) {
			$sql = "DELETE FROM download" .
				" WHERE download_status = 1 OR (download_status >= 10 AND download_status <= 16)";
			$class_db->write_db($sql);
		}
	}
	
	// put stats in an iframe so dont have to refresh page	
	echo "<IFRAME height='120' width='100%' scrolling='No' src='gui_speed.php?pg=lg' frameborder='0' class='queueIframe'></iframe><BR>";
	
	// draw actual items
	$sql = '(SELECT *, UNIX_TIMESTAMP(download_date) AS dldate FROM download' .
		' WHERE download_status = 2' .
		' ORDER BY download_date ASC)' .
		' UNION' .
		'(SELECT *, UNIX_TIMESTAMP(download_date) AS dldate FROM download' .
		' WHERE download_custom_position > 0 AND (download_status=0 OR download_status = 4)' .
		' ORDER BY download_custom_position ASC, download_post_time ASC)' .
		' UNION' .
		'(SELECT *, UNIX_TIMESTAMP(download_date) AS dldate FROM download' .
		' WHERE download_custom_position = 0 AND (download_status=0 OR download_status = 4)' .
		' ORDER BY download_post_time ASC)' .
		' UNION' .
		' (SELECT *, UNIX_TIMESTAMP(download_date) AS dldate FROM download' .
		' WHERE download_status != 0 AND download_status != 2 AND download_status != 4 AND download_status != 99' .
		' ORDER BY download_date DESC)';
	$class_db->query_db($sql);
	
	$tmpa = array(
		0 =>  $lang['queue']['queue_error0'],
		1 =>  $lang['queue']['queue_error1'],
		2 =>  $lang['queue']['queue_error2'],
		4 =>  $lang['queue']['queue_error4'],
		10 => $lang['queue']['queue_error10'],
		11 => $lang['queue']['queue_error11'],
		12 => $lang['queue']['queue_error12'],
		13 => $lang['queue']['queue_error13'],
		14 => $lang['queue']['queue_error14'],
		15 => $lang['queue']['queue_error15'],
		16 => $lang['queue']['queue_error16'],
		17 => $lang['queue']['queue_error17']
		);
	$previous = null;
	$arr["id_count"] = 1;
	
	/*
	if (((strtotime("now") > (strtotime(date('Y-m-d ', time()) . " " . $cfg["DOWNLOAD_START_TIME"]))) && 
		(strtotime("now") < (strtotime(date('Y-m-d ', time()) . " " . $cfg["DOWNLOAD_END_TIME"])))) &&
		$cfg["DOWNLOAD_START_TIME"]) {
		echo "Current time : " . date("h:i:s", time()) . " - " .
			"Downloading times restricted to " . $cfg["DOWNLOAD_START_TIME"] . " to " . $cfg["DOWNLOAD_END_TIME"] . "<BR><BR>";
	}
	*/
	
	echo "<FORM NAME='queueForm' METHOD='POST' ACTION='index.php?v=queue'>\n";
	//echo "<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%'>\n";
	echo "<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%' class='queueTable'>\n";
		echo "<TR><TD STYLE='padding:0; margin:0'><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%'><TR>" .
			"<TD CLASS='topLine queueCol1'>" . $lang['queue']['title_dateadded'] . "</TD>" .
			"<TD CLASS='topLine queueCol2'>" . $lang['queue']['title_status'] . "</TD>" .
			"<TD CLASS='topLine queueCol3'>" . $lang['queue']['title_size'] . "</TD>" .
			"<TD CLASS='topLine queueCol4'>" . $lang['queue']['title_subject'] . "</TD>" .
			"</TR></TABLE></TD></TR>\n";

	$drawn = 1;
	$not_drawn = $not_drawn_paused = $not_drawn_bad = 0;
	while ($row = $class_db->sql_results()) {
		// paused and queued are gonna fight here
		if ((($previous === 0) || ($previous == 4) || ($previous == 2)) && ($previous != (int)$row["download_status"])) {
			if ((($previous === 0) || ($previous == 4)) && 
				(((int)$row["download_status"] != 0) && ((int)$row["download_status"] != 4))) {	// end of queued
				if (!$_SESSION["dl_show_queue"] && ($not_drawn > 0)) {
					echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR>' . $lang['queue']['hidingq1'] . ' ' . $not_drawn . ' ' . $lang['queue']['hidingq2'];
					if ($not_drawn_paused) {
						echo ', ' . $not_drawn_paused . ' ' . $lang['queue']['hidingpaused'];
					}
					echo '. <a href="index.php?v=queue&showqueued=1">' . $lang['queue']['viewfiles'] . '</a>.</TD></TR>';
				} elseif ($drawn > $cfg["GUI_SHOW_QUEUED"]) {
					echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR><a href="index.php?v=queue&showqueued=2">' . $lang['queue']['hideexcessivefiles'] . '</a>.</TD></TR>';
				}
				echo "<TR><TD COLSPAN=4 STYLE='padding-left: 10px;'><BR>".
					"<INPUT TYPE='SUBMIT' NAME='queue_pause' VALUE='" . $lang['queue']['button_queued_pause'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_unpause' VALUE='" . $lang['queue']['button_queued_unpause'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_pauseall' VALUE='" . $lang['queue']['button_queued_pauseall'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_unpauseall' VALUE='" . $lang['queue']['button_queued_unpauseall'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_movetotop' VALUE='" . $lang['queue']['button_queued_movetotop'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_cancel' VALUE='" . $lang['queue']['button_queued_cancel'] . "' class='inputTag inputTag_button'> ".
					"<INPUT TYPE='SUBMIT' NAME='queue_cancelallqueued' VALUE='" . $lang['queue']['button_queued_cancelallqueued'] . "' class='inputTag inputTag_button'> ".
					"<BR><BR></TD></TR>";
				$drawn = 1;
				$not_drawn = 0;
			} elseif ($previous == 2) { // end of downloading
				echo "<TR><TD>&nbsp;</TD></TR>";
			}
		}
		$previous = (int)$row["download_status"];
		if ((((int)$row["download_status"] == 0) || ((int)$row["download_status"] == 4)) && 
			(!$_SESSION["dl_show_queue"]) && ($drawn > $cfg["GUI_SHOW_QUEUED"])) {
			// draw nothing
			$not_drawn++;
			if ((int)$row["download_status"] == 4) {
				$not_drawn_paused++;
			}
		} elseif (((int)$row["download_status"] != 0) && ((int)$row["download_status"] != 4) && 
			(!$_SESSION["dl_show_downloaded"]) && ($drawn > $cfg["GUI_SHOW_DOWNLOADED"])) {
			// draw nothing
			$not_drawn++;
			if ((int)$row["download_status"] >= 10) {
				$not_drawn_bad++;
			}
		} else {
			echo "<TR><TD ID='t" . $arr["id_count"] . "' ";
			if ((int)$row["download_status"] != 2) {
				echo highlight_rows($arr["id_count"]);
			}
			echo " STYLE='padding:0; margin:0'><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%'><TR><TD CLASS='fileLine queueCol1'>" .
				"<INPUT TYPE='checkbox' name='queued[]' value='" . $row["download_ID"] . "' ID='c" . $arr["id_count"] . "' STYLE='display: none;'>";
			echo date("Y-m-d H:i:s", $row["dldate"]) . "</TD><TD CLASS='fileLine queueCol2";
			// status
			if ((int)$row["download_status"] >= 10) {
				// error
				echo " queueError'>";
			} else {
				echo " queueOk'>";
			}
			echo $tmpa[(int)$row["download_status"]] . "</TD><TD CLASS='fileLine queueCol3'>";
			// size
			if ((int)$row["download_size"] < (10*1024*1024)) {
				// under 10 meg
				echo round((int)$row["download_size"] / 1024) . "Kb";
			} else {
				// over 10 meg
				echo round((int)$row["download_size"] / (1024*1024), 1) . "M";
			}
			echo "</TD><TD CLASS='fileLine queueCol4'>" . post_highlight_filename($row["download_subject"], $row["download_filename"]);
			// subject
			//echo " " . htmlspecialchars($row["download_subject"]);
			
			echo "</TD></TR></TABLE></TD></TR>\n";
			$arr["id_count"]++;
		}
		if ((int)$row["download_status"] != 2) {
			$drawn++;
		}
	}
	if (($previous === 0) || ($previous === 4)) {
		// if last thing listed was 'queued'
		if (!$_SESSION["dl_show_queue"] && ($not_drawn > 0)) {
			echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR>' . $lang['queue']['hidingq1'] . ' ' . $not_drawn . ' ' . $lang['queue']['hidingq2'];
			if ($not_drawn_paused) {
				echo ', ' . $not_drawn_paused . ' ' . $lang['queue']['hidingpaused'];
			}
			echo '. <a href="index.php?v=queue&showqueued=1">' . $lang['queue']['viewfiles'] . '</a>.</TD></TR>';
		} elseif ($drawn > $cfg["GUI_SHOW_QUEUED"]) {
			echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR><a href="index.php?v=queue&showqueued=2">' . $lang['queue']['hideexcessivefiles'] . '</a>.</TD></TR>';
		}
		echo "<TR><TD COLSPAN=4 STYLE='padding-left: 10px;'><BR>".
			"<INPUT TYPE='SUBMIT' NAME='queue_pause' VALUE='" . $lang['queue']['button_queued_pause'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_unpause' VALUE='" . $lang['queue']['button_queued_unpause'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_pauseall' VALUE='" . $lang['queue']['button_queued_pauseall'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_unpauseall' VALUE='" . $lang['queue']['button_queued_unpauseall'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_movetotop' VALUE='" . $lang['queue']['button_queued_movetotop'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_cancel' VALUE='" . $lang['queue']['button_queued_cancel'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='queue_cancelallqueued' VALUE='" . $lang['queue']['button_queued_cancelallqueued'] . "' class='inputTag inputTag_button'> ".
			"</TD></TR>";
	} elseif ($arr["id_count"] > 1) {
		// completed downloads were last listed
		if (!$_SESSION["dl_show_downloaded"] && ($not_drawn > 0)) {
			echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR>' . $lang['queue']['hidingc1'] . ' ' . $not_drawn . ' ' . $lang['queue']['hidingc2'];
			if ($not_drawn_bad) {
				echo ', ' . $not_drawn_bad . ' ' . $lang['queue']['hidingdownloadproblems'];
			}
			echo '. <a href="index.php?v=queue&showdl=1">' . $lang['queue']['viewfiles'] . '</a>.</TD></TR>';
		} elseif ($drawn > $cfg["GUI_SHOW_DOWNLOADED"]) {
			echo '<TR><TD COLSPAN=4 STYLE="padding-left: 10px;"><BR><a href="index.php?v=queue&showdl=2">' . $lang['queue']['hideexcessivefiles'] . '</a>.</TD></TR>';
		}
		echo "<TR><TD COLSPAN=4 STYLE='padding-left: 10px;'><BR>".
			"<INPUT TYPE='SUBMIT' NAME='complete_requeue' VALUE='" . $lang['queue']['button_comp_requeue'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='complete_requeueattop' VALUE='" . $lang['queue']['button_comp_requeueattop'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='complete_requeueandpause' VALUE='" . $lang['queue']['button_comp_requeueandpause'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='complete_clear' VALUE='" . $lang['queue']['button_comp_clear'] . "' class='inputTag inputTag_button'> ".
			"<INPUT TYPE='SUBMIT' NAME='complete_clearalldownloaded' VALUE='" . $lang['queue']['button_comp_clearalldownloaded'] . "' class='inputTag inputTag_button'> ".
			"</TD></TR>";
	}
	echo "</FORM></TABLE><BR>";
	
	
?>