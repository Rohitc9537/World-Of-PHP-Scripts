<?
// throw all this into CSS!!!! no more 10px 20px <B> bullshit, add colors etc
// do in a better flat-file format (XML/XSLT?), more condusive to quickly editing
?>
<DIV STYLE="padding-left: 20%; padding-right: 20%">
<BR>
<B>POSTS</B><BR><BR>
<DIV STYLE="margin-left: 10px">
	Group :<BR>
	<DIV STYLE="margin-left: 20px">
	Perform search on an individual group.</DIV><BR>
	
	Group Type :<BR>
	<DIV STYLE="margin-left: 20px">
	Perform search on multiple groups catagorized by 'group types'.</DIV><BR>
	
	Sorting Method :<BR>
	<DIV STYLE="margin-left: 20px">
	Group - sort by groups.<BR>
	Subject - sort by subject line of the post.<BR>
	Time - sort by time the file was posted.<BR>
	Filename - sort by filename parsed out of the subject line. (note: not all filenames are parsed out correctly)<BR>
	Poster email - sort by poster's email.</DIV><BR>
	
	Grouping Method :<BR>
	<DIV STYLE="margin-left: 20px">
	Show all files with grouping - Show all ungrouped files along with grouped files. (default)<BR>
	Show all files without grouping - Show all files without grouping them.<BR>
	Show only groups - Show only file groups, no ungrouped files.<BR>
	Show only complete groups - Show only file groups that are considered to be complete or complete with pars/par2s.<BR>
	Show only fills - Show only file groups that are par/par2 fills.</DIV><BR>
	
	Show only new posts (within last #h#m) :<BR>
	<DIV STYLE="margin-left: 20px">
	This is caculated from the start time of the previous time headers were updated.</DIV><BR>
	
	Show posts less the ___ hours old :<BR>
	<DIV STYLE="margin-left: 20px">
	Only return individual posts or groups that contain at least one file that was posted 
	within this time limit.</DIV><BR>
	
	Min/Max Size in [KMG]byte :<BR>
	<DIV STYLE="margin-left: 20px">
	___ / ___ - min/max size of individual files or file groups. eg. 30m = 30 megabytes, 
	1.25G = 1250 megabytes, etc.</DIV><BR>
	
	Search :<BR>
	<DIV STYLE="margin-left: 20px">
	Quick MySQL search, using % as wildcards. (note: the search is wrapped in %, no need to enter) syntax info(mysql url).<BR>
	bool - MySQL boolean searching. syntax info(mysql url)<BR>
	filename - search only the estimated filename. Note: search it not wrapped in %. eg all mpg files would be %.mpg</DIV><BR>
	
	Regex Search :<BR>
	<DIV STYLE="margin-left: 20px">
	Perform a regex search on all files. this is performed AFTER a MySQL search, so using 
	both will speed up the process. more examples. regex info(url)</DIV><BR>
	
	Hide 'Garbage Posts' :<BR>
	<DIV STYLE="margin-left: 20px">
	No known file extension<BR>
	OR<BR>
	Subject is replied to & not grouped & less then 10k<BR>
	OR<BR>
	Less then 3k in size & not grouped & not known small filetype (.m3u .nfo .sfv .par .par2 .ram .nzb)<BR>
	OR<BR>
	post should be deleted timewise (purged from server)</DIV><BR>
	
	Show incomplete posts :<BR>
	<DIV STYLE="margin-left: 20px">
	Show files that are deemed 'incomplete', these will be highlighted in red.</DIV><BR>
	
	Show all crossposts :<BR>
	<DIV STYLE="margin-left: 20px">
	By default when viewing the results of multiple groups only one of crossposted files will be displayed.
	Enabling this feature will show all crossposted files.</DIV><BR>
	
	Show only blacklisted posts :<BR>
	<DIV STYLE="margin-left: 20px">
	By default all blacklisted files are not displayed in results.</DIV><BR>
	
	Hide files :<BR>
	<DIV STYLE="margin-left: 20px">
	mp3s = .mp3 .ogg .m3u<BR>
	graphics = .gif .jpg .jpeg .tif .tiff .bmp .png .psd<BR>
	text files = .txt</DIV><BR>
	
	Upper right 'Daemon Monitor' :<BR>
	<DIV STYLE="margin-left: 20px">
	Updating headers - 'H 0t 0/0 0k/s' - H = Updating headers, #t = number of threads, #/# how many groups processed, #k/s = current speed.<BR>
	Downloading - 'D 0t 0k/s xM' - D = Downloading, #t = number of threads, #k/s = current download speed, #K/M/G = number of Kilobytes/Megs/Gigs left to download.</DIV><BR>
	
	How to read the posts line [QqPpSVN #/# files NZ] :<BR>
	<DIV STYLE="margin-left: 20px">
	Q - .PAR2 sfv-style<BR>
	q - .PAR2 volumes<BR>
	P - .PAR sfv-style<BR>
	p - .PAR recovery files<BR>
	S - video sample<BR>
	V - .sfv file<BR>
	N - .nfo file<BR>
	'#/#' - (total complete files) / (total files)<BR>
	'files' - view the individual files within this group<BR>
	'NZ' - check newzbin for the nfo</DIV><BR>
	
	Tricks :<BR>
	<DIV STYLE="margin-left: 20px">
	Selecting multiple lines is done via clicking an item (effectively selected/deselecting it) holding down the 'alt' key and
	clicking the desired end of the selection. Similar to shift-clicking in windows.<BR>
	Mouseover 'files' and 'NZ' to get additional information.<BR>
	Mouseover a post's 'group' to get poster's name/email and if post was crossposted.
	</DIV><BR>
</DIV><BR>

<B>DOWNLOAD QUEUE</B><BR><BR>
	<DIV STYLE="margin-left: 10px">
	How it works :<BR>
	<DIV STYLE="margin-left: 20px">
	Selecting files works exactly like the POSTS page. </DIV><BR>
</DIV><BR>

<B>GROUPS</B><BR><BR>
	<DIV STYLE="margin-left: 10px">
	Soon :<BR>
	<DIV STYLE="margin-left: 20px">
	...</DIV><BR>
</DIV><BR>

<B>GROUP TYPES</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>BLACKLISTS</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>WISHLISTS</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>STATS</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>SETTINGS</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>DAEMON LOG</B><BR><BR>
<DIV STYLE="margin-left: 10px">
Soon :<BR>
<DIV STYLE="margin-left: 20px">
...</DIV><BR>
</DIV><BR>

<B>FAQ</B><BR><BR>
<DIV STYLE="margin-left: 10px">
	What this prog will do.<BR>
	<DIV STYLE="margin-left: 20px">
		Provide a frontend to nget and act seperately as a server. The ultimate goal of this program is to
		provide the functionality similar to popular usenet readers and remain an open-source alternative.</DIV><BR>
		
	What this prog will not do.<BR>
	<DIV STYLE="margin-left: 20px">
		It will never post files. It can also never go beyond the functionality of nget itself.</DIV><BR>
	
	Why is everything so ugly?<BR>
	<DIV STYLE="margin-left: 20px">
		I want everything working 100% with most of the intended features before I focus on optimizing the frontend. The next
		BIG step will be implementing multiserver support, this will affect every aspect of the frontend and backend. Also porting
		everything to the new and improved PHP5 will require a lot of rearranging and all-around tightening of the code.</DIV><BR>
	
	What features are planned for later versions?<BR>
	<DIV STYLE="margin-left: 20px">
		Multiserver (most popular request), wishlist, use nget's autopar function, 
		recode (plus error handling & tweaking) to PHP5.</DIV><BR>
	
	What features are not planned?<BR>
	<DIV STYLE="margin-left: 20px">
		Updating headers and downloading simultaneously. Because the way nget works it would be a mess of code to implement,
		espically with multiserver.</DIV><BR>
	
	Known snafus.<BR>
	<DIV STYLE="margin-left: 20px">
		When searching for individual files, if 'group files' is left on the individual files inside the post are not searched, 
		only the 'main' file is used. To search for individual files turn off file grouping.<BR><BR>
		
		File grouping is not 100%. It is possible files which are not related are grouped together effectively hiding them, although
		this only happens on rare occasions.</DIV><BR>
		
</DIV><BR>
</DIV>