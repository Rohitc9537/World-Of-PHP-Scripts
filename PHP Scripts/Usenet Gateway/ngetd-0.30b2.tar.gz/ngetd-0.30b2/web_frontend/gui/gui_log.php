<table width="100%" class="log" border=0><tr><td>
<?
	// view log
	$sql = "SELECT *, UNIX_TIMESTAMP(stamp) AS unix_stamp" .
		" FROM logs" .
		" ORDER BY logs_ID DESC";
		//" LIMIT 200";
	$class_db->query_db($sql);
	while ($row = $class_db->sql_results()) {
		if ($row["error"] == 1) {
			echo "<span class='logError'>" .date("Y-m-d H:i:s", $row["unix_stamp"]) . " : " . $row["message"] . "</span><BR>\n";
		} elseif ($row["warning"] == 1) {
			echo "<span class='logWarning'>" . date("Y-m-d H:i:s", $row["unix_stamp"]) . " : " . $row["message"] . "</span><BR>\n";
		} else {
			echo "<span class='logNormal'>" . date("Y-m-d H:i:s", $row["unix_stamp"]) . " : " . $row["message"] . "</span><BR>\n";
		}
	}
?>
</td></tr></table>