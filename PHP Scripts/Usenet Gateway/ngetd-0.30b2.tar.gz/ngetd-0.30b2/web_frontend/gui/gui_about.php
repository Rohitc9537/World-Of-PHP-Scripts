<?
	echo '<CENTER><BR><BR><BR>' .
		'<TABLE CELLPADDING=10 CELLSPACING=0 BORDER=0><TR><TD>' .
		'<IMG SRC="graphics/ngetdaemon_logo.gif" WIDTH=226 HEIGHT=400 BORDER=0 ALT="ngetdaemon logo">' .
		'</TD><TD CLASS="about">' .
		'<B>' . $nget_version . '</B><BR><BR>' .
		$lang['about']['written'] . '<BR>' .
		'<a href="mailto:pancus@ngetdaemon.org" class="aboutLink">pancus@ngetdaemon.org</a><BR><BR>' .
		$lang['about']['contributers'] . '<BR>' .
		'mixle (css, ideas)<BR><BR>' .
		$lang['about']['visitprojectat'] . '<BR>' .
		'<a href="http://www.ngetdaemon.org/" target="_blank" class="aboutLink">ngetdaemon.org</a>, ' .
		'<a href="http://www.ngetdaemon.org/forum/" target="_blank" class="aboutLink">' . $lang['about']['forums'] . '</a><BR>' .
		'<a href="http://freshmeat.net/projects/ngetdaemon/?topic_id=39" target="_blank" class="aboutLink">freshmeat</a>, ' .
		'<a href="http://sourceforge.net/projects/ngetdaemon/" target="_blank" class="aboutLink">sourceforge</a><BR><BR>' .
		'</TD></TR></TABLE>' .
		'</CENTER>';
?>
