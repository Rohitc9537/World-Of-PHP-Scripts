<?
/* ---------------------------------------------------------------------------
	Form functions.
   ------------------------------------------------------------------------ */

	// handles select boxes
	function draw_select_option($post_item, $comparison, $value) {
		$tmp = "<OPTION VALUE='" . $comparison . "'";
		if ($_SESSION[$post_item] == $comparison) {
			$tmp .= " selected";
		}
		$tmp .= ">" . $value . "</OPTION>\n";
		return $tmp;
	}

	// handles checkboxs, default value 1
	function draw_checkbox_option($text_descr, $form_post_name) {
		$tmp = "<INPUT TYPE='checkbox' NAME='" . $form_post_name . "' VALUE='1'";
		if ($_SESSION[$form_post_name]) {
			$tmp .= " checked";
		}
		$tmp .= " CLASS='inputTag_checkbox'> " . $text_descr . "\n";
		return $tmp;
	}
	
	// convert form posts into a useable format for forms
	function convert_form_input($text) {
		return str_replace('"', '&quot;', stripslashes($text));
	}
	
	// convert sql output into a usable format for forms
	function convert_sql_input($text) {
		return htmlspecialchars($text, ENT_QUOTES);
	}

	
/* ---------------------------------------------------------------------------
	Misc functions.
   ------------------------------------------------------------------------ */
   	
	// caculate the size of form input, output is in KB
	function caculate_size_in_kb($size) {
		if (preg_match("/K\s*$/i", $size)) {
			$multiply = 1;
		} elseif (preg_match("/M\s*$/i", $size)) {
			$multiply = 1024;
		} elseif (preg_match("/G\s*$/i", $size)) {
			$multiply = (1024*1024);
		} else {
			$multiply = 1;
		}
		$intsize = floatval(preg_replace("/^.*?([\d\.]*).*?$/", "$1", $size));
		if ($intsize > 0) {
			$intsize = $intsize * $multiply;
		} else {
			$intsize = 0;
		}
		return intval($intsize);
	}
	
	// caculate the hours from ##d##h
	function caculate_hours($phrase) {
		// input allowed to be 48h, 3d, 3d16h, 3d64h, 16 (default to hours)
		$days = $hours = 0;
		if (preg_match("/\d+d/i", $phrase)) {
			$days = (int)preg_replace("/^.*?(\d+)d.*$/i", "$1", $phrase);
		}
		if (preg_match("/\d+h/i", $phrase)) {
			// 48h
			$hours = (int)preg_replace("/^.*?(\d+)h.*$/i", "$1", $phrase);
		} elseif (!preg_match("/\d+d\d+$/i", $phrase)) {
			// 3d24 (no hours)
			$hours = (int)preg_replace("/^.*?\d+d(\d+)$/i", "$1", $phrase);
		} elseif (!preg_match("/[dh]/i", $phrase)) {
			// 36 (no hours)
			$hours = (int)preg_replace("/^.*?(\d+).*$/i", "$1", $phrase);
		}
		return (($days * 24) + $hours);
	}
	
   // convert bytes/s to k/s if necessary
	function convert_speed($bytes_per_sec) {
		if ($bytes_per_sec <= 4096) {
			return $bytes_per_sec . "b/s";
		} else {
			return number_format(round(($bytes_per_sec / 1024), 1),1) . "k/s";
		}	
	}
	
	function topmenu_item($name, $title) {
		echo "<a href='index.php?v=" . $name . "' CLASS='";
		if ($_GET["v"] == $name) {
			echo "currentButton ";
		}
		echo "topButtons'>" . $title . "</a>";
		echo "<SPAN CLASS='buttonSpace'> </SPAN>";
	}
	
	
/* ---------------------------------------------------------------------------
	Next four functions control crossposting by storing the xpost id 
	in an array.
   ------------------------------------------------------------------------ */
	
	function add_xpost_id($postid) {
		global $xpost_array;
		if ($postid > 0) {
			$xpost_array[$postid] = 1;
		}
	}
	// ...
	function add_file_xpost_id($postid) {
		global $file_xpost_array;
		if ($postid > 0) {
			$file_xpost_array[$postid] = 1;
		}
	}
	// ...
	function check_xpost_id($postid) {
		global $xpost_array;
		//minor speedup
		if ($postid == 0) {
			return false;
		} else {
			if ($xpost_array[$postid]) {
				return true;
			} else {
				return false;
			}
		}
	}
	// ...
	function check_file_xpost_id($postid) {
		global $file_xpost_array;
		//minor speedup
		if ($postid == 0) {
			return false;
		} else {
			if ($file_xpost_array[$postid]) {
				return true;
			} else {
				return false;
			}
		}
	}

/* ---------------------------------------------------------------------------
	Following functions control drawing the posts onscreen.
   ------------------------------------------------------------------------ */
	
	// highlight the estimated filename and return the value converted into html-friendly format
	function post_highlight_filename($subject, $filename) {
		return str_replace(htmlspecialchars($filename), 
			"<SPAN CLASS='fileName'>".htmlspecialchars($filename)."</SPAN>", 
			htmlspecialchars($subject));
	}

	// make imdb references clickable
	function post_highlight_imdb($subject, $id_count) {
		// imdb - http://www.imdb.com/title/tt0116778/ : IMDB 1234567 : tt1234567 : 0123456
		return preg_replace("/(http:\/\/\w*\.imdb\.com\/title\/tt|IMDB\s*|tt|[^\d]|^)(0\d{6})([^\d]|$)/i",
			"$1<a href='http://www.imdb.com/title/tt$2' target='_blank'" .
			" onclick=\"itemSelectRow(event, " . $id_count . ")\">$2</a>$3", $subject);
	}
	
	// make ftd referances clickable
	function post_highlight_ftd($subject, $id_count) {
		// http://nfo.ftd.nu/?id=123456 
		return preg_replace("/(http:\/\/nfo\.ftd\.nu\/\?id=|nfo\.ftd\.nu\/\?id=|ftdnl[^\d]{0,3}|ftd[^\d]{0,3}|#[ ]?)(\d{5,7})/i",
			"$1<a href='http://nfo.ftd.nu/?id=$2' target='_blank'" .
			" onclick=\"itemSelectRow(event, " . $id_count . ")\">$2</a>", $subject);
	}
	
	// make ftd referances clickable
	function post_highlight_ftn($subject, $id_count) {
		// http://www.ftnforum.nl/viewtopic.php?t=13350
		return preg_replace("/(http:\/\/www\.ftnforum\.nl\/viewtopic\.php\?t=|ftn[ ]?)(\d{5})/i",
			"$1<a href='http://www.ftnforum.nl/viewtopic.php?t=$2' target='_blank'" .
			" onclick=\"itemSelectRow(event, " . $id_count . ")\">$2</a>", $subject);
	}
	
	// fix when idiots think their being cute by putting the titles in backwards
	// <<< fix this up later, too many variations are being missed...
	function post_reverse_titles($subject) {
		// s.d.r.a.w.k.c.a.B > Backwards
//		if (preg_match("/([a-z0-9\.]+[A-Z][ \.]){2,20}([a-z0-9]+[A-Z])[^a-zA-Z0-9]/", $subject)) {
			// 1. select all the offending text
			$text = preg_replace("/^.*([a-z0-9\.]{2,50}[A-Z] ?){2,50}[^a-zA-Z0-9].*$/", "$1", $subject);
			echo "$subject ::: $text <BR>";
			$orgtext = $text;
			// 2. remove all fluff (.'s etc
			$text = preg_replace("/[\.]/", "", $text);
			// 3. reverse letters
			$text = strrev($text);
			// 4. fix spacing
			$text = preg_replace("/([a-z0-9])([A-Z])/", "$1 $2", $text);
			// 5. add <span title='old text'>new text</span>
			//return preg_replace("/".$orgtext."/", "<span style='font-weight: bolder;' title='".$textorg."'>".$text."</span>", $subject);
			return $subject;
//		} else {
//			return $subject;
//		}
	}
	
	// convert size to a readable format
	// $base is what $size needs to be divided by to get it into kb format (eg. 1024 if $size is in bytes)
	function post_convert_size($size, $base) {
		// initial conversion
		$size = round($size / $base);
		
		if ($size < (2*1024)) {
			// under 2 megs
			return (string)$size . "K";
		} elseif ($size < (10*1024)) {
			// under 10 megs
			return (string)number_format(round($size / 1024, 1), 1, ".", "") . "M";
		} elseif ($size < (2*1024*1024)) {
			// under 2 gigs
			return (string)round($size / 1024) . "M";
		} else {
			// over 2 gigs
			return (string)number_format(round($size / (1024*1024), 2), 2, ".", "") . "Gb";
		}
	}
	
	// return the time in a readable format
	function post_time($post_time) {
		//return date("m-d H:i", strtotime($post_time)) . " (" . post_time_elapsed($post_time) . ")";
		return date("m-d H:i", strtotime($post_time));
	}
	// return the time relative to the current time
	function post_time_elapsed($post_time) {
		// maximum time to stop drawing in hours, minimum 24 and should be a multiple of 24
		$maxhours = 24;
		if (floor((time() - strtotime($post_time)) / (60*60*$maxhours)) > 0) {
			// in daysHours (if over maxhours)
			return floor((time() - strtotime($post_time)) / (60*60*24)) . "d" . 
				substr("0" . (string)floor(((time() - strtotime($post_time)) / (60*60)) % 24), -2) . "h";
		} elseif (floor((time() - strtotime($post_time)) / (60*60)) > 0) {
			// in hoursMin (if over 1 hour)
			return floor((time() - strtotime($post_time)) / (60*60)) . "h" . 
				substr("0" . (string)floor(((time() - strtotime($post_time)) / 60) % 60), -2) . "m";
		} else {
			// in min (less then 1 hour)
			return (string)floor(((time() - strtotime($post_time)) / 60) % 60) . "min";
		}
	}
	
	// return completion code
	function post_completion_code($code, $pars, $blocks) {
		global $lang;
		
		$alt_size = false;
		if ($code == 5) { $completion_code = $lang['functions']['code5'];
			// account for if par&par2s
			if ($pars > 0) {
				$alt_size = (string)$pars . ' ' . $lang['functions']['code5_pars'];
			} elseif ($blocks > 0) {
				$alt_size = (string)$blocks . ' ' . $lang['functions']['code5_blocks'];
			}
		} elseif ($code == 11) { $completion_code = $lang['functions']['code11'];
		} elseif ($code == 12) { $completion_code = $lang['functions']['code12'];
		} elseif ($code == 13) { $completion_code = $lang['functions']['code13'];
		} elseif ($code == 14) { $completion_code = $lang['functions']['code14'];
		} elseif ($code == 21) { $completion_code = $lang['functions']['code21'];
		} elseif ($code == 22) { $completion_code = $lang['functions']['code22'];
		} elseif ($code == 23) { $completion_code = $lang['functions']['code23'];
		} elseif ($code == 24) { $completion_code = $lang['functions']['code24']; 
		} elseif ($code == 30) { $completion_code = $lang['functions']['code30']; }
		
		return array($completion_code, $alt_size);
	}
	
	// draw the file/file group
	function post_draw_row($arr) {
		// globals
		global $cfg;
		
		if ($arr["single_file"] == true) {
			$css = "fileLine";
		} else {
			$css = "groupLine";
		}
		
		$css2 = "";
		if ($arr["post_bad"] > 0) {
			$css2 = "badFileBkg";
			$css = "badFile " . $css;
		}
		if ($arr["post_downloaded"] > 0) {
			$css2 = "downloaded";
		}

		// wrap a table inside a cell so the mouseovers are SUBSTANTIALLY faster (opposed to changing each individual cell)
		//>>> see if I can shove this in the first TD only??
		echo "<TR><TD ID='t" . $arr["id_count"] . "' CLASS='" . $css2 . "'>" .
			"<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%'><TR>";
			
		echo "<TD CLASS='".$css." widthCol1' " . highlight_rows($arr["id_count"]) . ">" .
			"<INPUT TYPE='checkbox' name='posts[]' value='" . $arr["checkbox_value"] . "'" . 
			" ID='c" . $arr["id_count"] . "' STYLE='display: none;'>" .
			$arr["subject"] . $arr["showfiles"] . "</TD>\n";
		
		if ($arr["alt_size"]) {
			echo "<TD CLASS='".$css." widthCol2' " . highlight_rows($arr["id_count"]) . ">" . $arr["alt_size"] . "</TD>\n";
		} else {
			echo "<TD CLASS='".$css." widthCol2' " . highlight_rows($arr["id_count"]) . ">" . $arr["size"] . "</TD>\n";
		}
		
		// highlight files that are 'old'
		if (floor((time() - strtotime($arr["realtime"])) / 60) >= $cfg["POSTS_OLD_TIME"]) {
			echo "<TD CLASS='oldFile ".$css." widthCol3' " . highlight_rows($arr["id_count"]) . ">" . $arr["time"] . "</TD>\n";
		} else {
			echo "<TD CLASS='".$css." widthCol3' " . highlight_rows($arr["id_count"]) . ">" . $arr["time"] . "</TD>\n";
		}
		
		//echo "<TD CLASS='".$css." widthCol4' " . highlight_rows($arr["id_count"]) . ">" . $arr["group"] . "</TD>\n";
		echo "<TD CLASS='".$css." widthCol4' " . highlight_rows($arr["id_count"]) . ">" .
			"<span title='" . $arr["extra"] . "'>" . $arr["group"] . "</span>" .
			"<a href='http://www.newzbin.com/browse/group/p/" . $arr["groupname"] . "/' onclick=\"itemSelectRow(event, " . $arr["id_count"] . ")\" target='_blank' CLASS='postLink'>*</a></TD>\n";
		echo "<TD CLASS='".$css." widthCol5' " . highlight_rows($arr["id_count"]) . ">" . $arr["completion_code"] . "</TD>\n";
		echo "</TR></TABLE></TD></TR>\n";
		
	}
	
	// for pretty JS goodness
	function highlight_rows($check_id) {
		return "onmouseover=\"highlightRow(" . $check_id . ", true)\"" .
		 	" onmouseout=\"highlightRow(" . $check_id . ", false)\"" .
		 	" onclick=\"itemSelectRow(event, " . $check_id . ")\"";
	}
?>