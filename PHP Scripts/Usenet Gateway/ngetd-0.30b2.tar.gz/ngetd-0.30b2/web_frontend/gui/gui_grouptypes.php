<?
		
		// process post
		//>>> still need sqlfiendly
		
		// simply updating
		if ($_POST["update"]) {
			while ($tmp = array_shift($_POST["groupids"])) {
				$sql = "UPDATE group_type SET" .
					" group_type_name = '" . $_POST["groupname_" . $tmp] . "'," .
					" group_type_method = '" . $_POST["groupmethod_" . $tmp] . "'" .
					" WHERE group_type_id = " . $tmp;
				$class_db->write_db($sql);
			}
			// refresh
			$ngetgroups->groups_control_init();
		
		// deleting a group (keep code above moving a group)
		} elseif ($_POST["move"] && ($_POST["groupmove"] == "delete")) {
			$tmp = array_shift(array_keys($_POST["move"]));
			// cannot delete 'root' group
			if ($tmp > 1) {
				// everything below it now points to what that was pointing to
				$sql = "SELECT * FROM group_type WHERE group_type_ID = " . $tmp;
				$class_db->query_db($sql);
				while ($row = $class_db->sql_results()) {
					// all groups that used to point to this also point to the previous
					$sql = "UPDATE groups SET group_type = " .$row["group_type_parent_ID"] .
						" WHERE group_type = " . $tmp;
					$class_db->write_db($sql);
					
					$sql = "UPDATE group_type SET group_type_parent_ID = " . $row["group_type_parent_ID"] .
						" WHERE group_type_parent_ID = " . $tmp;
					$class_db->write_db($sql);
				}

				// finally delete it
				$sql = "DELETE FROM group_type WHERE group_type_ID = " . $tmp;
				$class_db->write_db($sql);
				// refresh
				$ngetgroups->groups_control_init();
			}

		// moving a group
		} elseif ($_POST["move"] && $_POST["groupmove"]) {
			$tmp = array_shift(array_keys($_POST["move"]));
			// cannot move a node into its own leaf nodes and cannot copy into itself
			$tmpa = $ngetgroups->get_group_type_assoc_array($tmp);
//>>> figure this out better later
			//if (!in_array($tmp, $tmpa["groupid"]) && 
			if ($tmp != $_POST["groupmove"]) {	
				$sql = "UPDATE group_type SET" .
					" group_type_parent_ID = " . $_POST["groupmove"] .
					" WHERE group_type_ID = " . $tmp;
				$class_db->write_db($sql);
				// refresh
				$ngetgroups->groups_control_init();
			}
		
		// adding a group
		} elseif ($_POST["newgroup"]) {
			if ($_POST["newgroupname"] && $_POST["newgroupmethod"] && $_POST["groupmove"]) {
				$sql = "INSERT INTO group_type" .
					" (group_type_name, group_type_method, group_type_parent_ID) VALUES" .
					" ('" . $_POST["newgroupname"] . "'," .
					" " . $_POST["newgroupmethod"] . "," .
					" " . $_POST["groupmove"] . ")";
				$class_db->write_db($sql);
				// refresh
				$ngetgroups->groups_control_init();
			}
		}

		// get groups array
		$tmpa = $ngetgroups->get_group_type_tree_array();

		echo "<BR><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>";
		echo "<FORM NAME='x' ACTION='index.php?v=grouptypes' METHOD='POST'>\n";
		
		while (count($tmpa) > 0) {
			$tmpb = array_shift($tmpa);

			echo "<TR><TD CLASS='groups'>";
			echo str_repeat(" -", (((int)$tmpb["depth"] - 1) * 1)) . str_repeat("&nbsp;", (((int)$tmpb["depth"] - 1) * 1));
			//echo draw_select_option("opt_group_type", $tmpb["groupid"], $tmpb["groupname"]);	// and subject
			echo "<INPUT TYPE='radio' NAME='groupmove' VALUE='" . $tmpb["groupid"] . "'>";
			echo "<INPUT TYPE='hidden' NAME='groupids[]' VALUE='" . $tmpb["groupid"] . "'>";
			echo "<INPUT TYPE='text' SIZE=20 NAME='groupname_" . $tmpb["groupid"] . "' VALUE='" . $tmpb["groupname"] . "' CLASS='inputTag_input inputTag'> ";
			echo "</TD><TD CLASS='groups'>";
			echo "<SELECT SIZE=1 NAME='groupmethod_" . $tmpb["groupid"] . "' CLASS='inputTag_select inputTag'>\n";
			echo "<OPTION VALUE='1'";
			if ((int)$tmpb["groupmethod"] == 1) {
				echo " selected";
			}
			echo ">" . $lang['grouptypes']['nomp3s'] . "</OPTION>\n";
			echo "<OPTION VALUE='2'";
			if ((int)$tmpb["groupmethod"] == 2) {
				echo " selected";
			}
			echo ">" . $lang['grouptypes']['inclmp3s'] . "</OPTION>\n";
			echo "</SELECT> ";
			
			echo "</TD><TD CLASS='groups'>";
			echo "<INPUT TYPE='submit' NAME='move[" . $tmpb["groupid"] . "]' VALUE='" . $lang['grouptypes']['button_movegrouptype'] . "' CLASS='inputTag_button inputTag'>";
			echo "</TD></TR>\n";
		}
		echo "<TR><TD COLSPAN=3 CLASS='groups'>";
		echo "<INPUT TYPE='radio' NAME='groupmove' VALUE='delete'> " . $lang['grouptypes']['deletegroupinsteadofmoving'] . ".<BR><BR>\n";
		echo "</TD></TR>";
		
		echo "<TR><TD CLASS='groups'>";
		echo "<INPUT TYPE='text' SIZE=20 NAME='newgroupname' CLASS='inputTag_input inputTag'> ";
		echo "</TD><TD CLASS='groups'>";
		echo "<SELECT SIZE=1 NAME='newgroupmethod' CLASS='inputTag_select inputTag'><OPTION VALUE='1'>" . $lang['grouptypes']['nomp3s'] . "</OPTION><OPTION VALUE='2'>" . $lang['grouptypes']['inclmp3s'] . "</OPTION></SELECT> ";
		echo "</TD><TD CLASS='groups'>";
		echo "<INPUT TYPE='submit' NAME='newgroup' VALUE='" . $lang['grouptypes']['button_addgrouptype'] . "' CLASS='inputTag_button inputTag'>\n";
		echo "</TD></TR>";
		
		echo "<TR><TD COLSPAN=3 CLASS='groups'>";
		echo "<BR><INPUT TYPE='submit' NAME='update' VALUE='" . $lang['grouptypes']['button_savegrouptypes'] . "' CLASS='inputTag_button inputTag'>\n";
		echo "</TD></TR>";
				
		echo "</FORM>";
		echo "</TABLE><BR><BR>";
?>