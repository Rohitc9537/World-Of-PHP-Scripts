<?

	// process post
	if ($_POST["update_groups"]) {
		$sql = "UPDATE groups SET group_active = 0, group_active_onetime = 0";
		$class_db->write_db($sql);
		$arr_group_active = null;
		$arr_group_onetime = null;
		$tmpa = $_POST["groupid"];
		while ($group = (int)array_pop($tmpa)) {
			// edit and dump into corresponding arrays
			if ((int)$_POST["groupactive_" . $group] == 1) {
				$arr_group_active .= " group_ID = " . $group . " OR";
			}
			if ((int)$_POST["grouponetime_" . $group] == 1) {
				$arr_group_onetime .= " group_ID = " . $group . " OR";
			}
			if ($_POST["groupname_" . $group] && $_POST["groupabv_" . $group] && $_POST["grouptype_" . $group]) {
				$sql = "UPDATE groups" .
					" SET group_name = '" . $_POST["groupname_" . $group] . "'," .
					" group_abv = '" . $_POST["groupabv_" . $group] . "'," .
					" group_type = " . (int)$_POST["grouptype_" . $group] .
					" WHERE group_ID = "  . $group;
				$class_db->write_db($sql);
			}
		}
		if ($arr_group_active) {
			$sql = preg_replace("/^(.*) OR/", "$1", "UPDATE groups SET group_active = 1 WHERE" . $arr_group_active);
			$class_db->write_db($sql);
		}
		if ($arr_group_onetime) {
			$sql = preg_replace("/^(.*) OR/", "$1", "UPDATE groups SET group_active_onetime = 1 WHERE" . $arr_group_onetime);
			$class_db->write_db($sql);
		}
	} elseif ($_POST["delete_groups"]) {
		$tmpa = $_POST["del"];
		$sql = "DELETE FROM groups WHERE";
		$sql2 = "DELETE FROM posts WHERE";
		while ($group = (int)array_pop($tmpa)) {
			$sql .= " group_ID = " . $group . " OR";
			$sql2 .= " post_group = " . $group . " OR";
		}
		$sql = preg_replace("/^(.*) OR/", "$1", $sql);
		$sql2 = preg_replace("/^(.*) OR/", "$1", $sql2);
		$class_db->write_db($sql);
		$class_db->write_db($sql2);
	} elseif ($_POST["add_group"]) {
		if ($_POST["new_group_name"] && $_POST["new_group_abv"]) {
			$sql = "INSERT INTO groups" .
				" (group_name, group_abv, group_active, group_active_onetime, group_type) VALUES (" .
				"'" . $_POST["new_group_name"] . "', " . 
				"'" . $_POST["new_group_abv"] . "', " .
				(int)$_POST["new_group_active"] . ", " .
				(int)$_POST["new_group_active_onetime"] . ", " .
				(int)$_POST["new_group_type"] . ")";
			$class_db->write_db($sql);
		}
	}
	
	// draw interface
	$sql = "SELECT * FROM groups ORDER BY group_name";
	$class_db->query_db($sql);
	echo "<BR><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n";
	echo "<FORM NAME='groups' ACTION='index.php?v=groups' METHOD='POST'>\n";
	// get this just once to improve speed considerably
	$tmpx = $ngetgroups->get_group_type_tree_array();
	while ($row = $class_db->sql_results()) {
		echo "<TR>\n" .
			"<TD CLASS='groups'><INPUT TYPE='hidden' NAME='groupid[]' VALUE='" . $row["group_ID"] . "'>" .
			$lang['groups']['delete'] . " <INPUT TYPE='checkbox' NAME='del[]' VALUE='" . $row["group_ID"] . "'></TD>\n" .
			"<TD CLASS='groups'><INPUT TYPE='text' SIZE=35 NAME='groupname_" . $row["group_ID"] . "' VALUE='" . $row["group_name"] . "' CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'><INPUT TYPE='text' SIZE=20 NAME='groupabv_" . $row["group_ID"] . "' VALUE='" . $row["group_abv"] . "' CLASS='inputTag_input inputTag'></TD>\n";
		
		echo "<TD CLASS='groups'>" . $lang['groups']['lastupdate'] . ": ";
		if ($row["group_last_update"]) {
			//echo post_time($row["group_last_update"]);
			echo post_time_elapsed($row["group_last_update"]);
		} else {
			echo $lang['groups']['never'];
		}
		echo "</TD>\n";
		
		echo "<TD CLASS='groups'>" . $lang['groups']['active'] . ": <INPUT TYPE='CHECKBOX' NAME='groupactive_" . $row["group_ID"] . "' VALUE='1'";
		if ((int)$row["group_active"] == 1) {
			echo " checked";
		}
			
		echo "></TD>\n";
		
		echo "<TD CLASS='groups'>" . $lang['groups']['onetime'] . ": <INPUT TYPE='CHECKBOX' NAME='grouponetime_" . $row["group_ID"] . "' VALUE='1'";
		if ((int)$row["group_active_onetime"] == 1) {
			echo " checked";
		}
		echo "></TD>\n";
		
		echo "<TD CLASS='groups'>" . $lang['groups']['type'] . ": <SELECT NAME='grouptype_" . $row["group_ID"] . "' SIZE='1' CLASS='inputTag_select inputTag'>";
		// get groups array
		$tmpa = $tmpx;
		while (count($tmpa) > 0) {
			$tmpb = array_shift($tmpa);
			$tmpb["groupname"] = str_repeat(" -", (((int)$tmpb["depth"] - 1) * 1)) . str_repeat("&nbsp;", (((int)$tmpb["depth"] - 1) * 1)) . $tmpb["groupname"];
			echo "<OPTION VALUE='" . $tmpb["groupid"] . "'";
			if ($row["group_type"] == $tmpb["groupid"]) {
				echo " selected";
			}
			echo ">" . $tmpb["groupname"] . "</OPTION>\n";
		}
		echo "</SELECT></TD>\n";
		
		echo "</TR>\n";
	}
	echo "<TR>\n" .
		"<TD CLASS='groups' COLSPAN=2><INPUT TYPE='SUBMIT' NAME='delete_groups' VALUE='" . $lang['groups']['button_delete'] . "' CLASS='inputTag_button inputTag'></TD></TR>\n";
	echo "<TR><TD></TD>" .
		"<TD CLASS='groups'><INPUT NAME='new_group_name' TYPE='TEXT' SIZE=35 CLASS='inputTag_input inputTag'></TD>\n" .
		"<TD CLASS='groups'><INPUT NAME='new_group_abv' TYPE='TEXT' SIZE=20 CLASS='inputTag_input inputTag'></TD>\n" .
		"<TD></TD>\n" .
		"<TD CLASS='groups'>" . $lang['groups']['active'] . ": <INPUT NAME='new_group_active' TYPE='CHECKBOX' VALUE='1'></TD>\n" .
		"<TD CLASS='groups'>" . $lang['groups']['onetime'] . ": <INPUT NAME='new_group_active_onetime' TYPE='CHECKBOX' VALUE='1'></TD>\n";
		echo "<TD CLASS='groups'>" . $lang['groups']['type'] . ": <SELECT NAME='new_group_type' SIZE='1' CLASS='inputTag_select inputTag'>";
		// get groups array
		$tmpa = $tmpx;
		while (count($tmpa) > 0) {
			$tmpb = array_shift($tmpa);
			$tmpb["groupname"] = str_repeat(" -", (((int)$tmpb["depth"] - 1) * 1)) . str_repeat("&nbsp;", (((int)$tmpb["depth"] - 1) * 1)) . $tmpb["groupname"];
			echo "<OPTION VALUE='" . $tmpb["groupid"] . "'>" . $tmpb["groupname"] . "</OPTION>\n";
		}
		echo "</SELECT>&nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE='SUBMIT' NAME='add_group' VALUE='" . $lang['groups']['button_addgroup'] . "' CLASS='inputTag_button inputTag'></TD>\n";
		echo "</TR>\n";
	
	echo "</TABLE>\n";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='update_groups' VALUE='" . $lang['groups']['button_savegroups'] . "' CLASS='inputTag_button inputTag'></FORM><BR><BR>";
?>