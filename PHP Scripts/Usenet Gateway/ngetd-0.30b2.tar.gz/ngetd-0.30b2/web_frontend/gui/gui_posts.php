<?
	if ($_GET['v'] != 'fg') {
		// put all posts into session var
		$tmpa = array('opt_group', 'opt_group_type', 'opt_sort', 'opt_show_bad_posts', 'opt_show_xposts', 'opt_hide_jpg', 'opt_hide_mp3s',
			'opt_hide_txt', 'opt_only_new', 'opt_mintime', 'opt_maxtime', 'opt_minsize', 'opt_maxsize', 'opt_search_bool', 'opt_search_filename',
			'opt_grouping', 'opt_search', 'opt_regex_search', 'opt_show_blacklisted_posts', 'opt_hide_garbage_posts', 'pseudo');
		//<<< remove pseudo when real wishlist is implemented
		if ($_POST['posts_options']) {
			while ($tmp = array_shift($tmpa)) {
				$_SESSION[$tmp] = $_POST[$tmp];
			}
		}
		
	//	echo "<div style='position:absolute; top:0px; left:0px; z-index:2; width:350px; visibility:hidden; background-color: #666666; padding: 8px; border: 3px solid black;' id=help align=justify>";
	//	echo "Help";
	//	echo "</DIV>";
		
		// keep <form embedded between <table and <tr, keep IE from putting its own special twist on everything
		echo "<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%' CLASS='viewPostsTable'>".
			"<FORM NAME='options' METHOD='POST' ACTION='index.php?v=posts'>" .
			"<TR><TD CLASS='viewPostsText widthPosts1' valign='top'>";
	
		echo $lang['posts']['group'] . ' : ';
		echo "<SELECT NAME='opt_group' SIZE='1' onchange='if (document.options.opt_group.value != 0) { document.options.opt_group_type.value = 1; }' CLASS='inputTag_select inputTag'>";
		echo "<OPTION VALUE='0'>" . $lang['posts']['group_allgroups'] . "</OPTION>";
		// loop through rest of groups
		$group_type_posts = array();
		while ($ngetgroups->get_current_group()) {
			// remove all 'zero' groups
			if ((int)$ngetgroups->get_specific_group_posts($ngetgroups->get_current_group()) > 0) {
				$tmp = $ngetgroups->get_current_group_name() . "&nbsp;&nbsp;(" . $ngetgroups->get_specific_group_posts($ngetgroups->get_current_group()) . ")";
				echo draw_select_option("opt_group", $ngetgroups->get_current_group(), $tmp);
				// record number of posts in each group to an array
				$group_type_posts[$ngetgroups->get_current_group_type()] += (int)$ngetgroups->get_specific_group_posts($ngetgroups->get_current_group());
			}
			$ngetgroups->get_next_group();
		}
		echo '</SELECT><BR>';
		
		echo $lang['posts']['grouptype'] . ' : ';
		echo "<SELECT NAME='opt_group_type' SIZE='1' onchange='if (document.options.opt_group_type.value != 1) { document.options.opt_group.value = 0; }' CLASS='inputTag_select inputTag'>";
		// get groups array
		$tmpa = $ngetgroups->get_group_type_tree_array();
		while (count($tmpa) > 0) {
			$tmpb = array_shift($tmpa);
			// caculate how many posts in each group
			$tmpc = $ngetgroups->get_group_type_assoc_array($tmpb["groupid"]);
			$tmp = 0;
			while (count($tmpc) > 0) {
				$tmpd = array_shift($tmpc);
				$tmp += (int)$group_type_posts[$tmpd["groupid"]];
			}
			// remove all 'zero' groupings
			if ($tmp > 0) {
				$tmpb["groupname"] = str_repeat(" -", (((int)$tmpb["depth"] - 1) * 1)) . str_repeat("&nbsp;", (((int)$tmpb["depth"] - 1) * 1)) . $tmpb['groupname'] . "&nbsp;&nbsp;(" . $tmp . ')';
				echo draw_select_option('opt_group_type', $tmpb['groupid'], $tmpb['groupname']);	// and subject
			}
		}
		echo '</SELECT><BR>';
		
		echo $lang['posts']['sortingmethod'] . ' : ';
		echo "<SELECT name='opt_sort' size='1' CLASS='inputTag_select inputTag'>\n";
		// note the group flag must be kept in all options to keep all sorted crossposts in one group
		echo draw_select_option('opt_sort', 'g,s,t', $lang['posts']['sortingmethod_group'] . ', ' . $lang['posts']['sortingmethod_subject']);	// and time
		echo draw_select_option('opt_sort', 'g,t', $lang['posts']['sortingmethod_group'] . ', ' . $lang['posts']['sortingmethod_time']);
		echo draw_select_option('opt_sort', 'g,f,p', $lang['posts']['sortingmethod_group'] . ', ' . $lang['posts']['sortingmethod_filename']);	// and poster email
		echo draw_select_option('opt_sort', 'g,p,s', $lang['posts']['sortingmethod_group'] . ', ' . $lang['posts']['sortingmethod_posteremail']);	// and subject
		echo draw_select_option('opt_sort', 's,t,g', $lang['posts']['sortingmethod_subject']);	// and time
		echo draw_select_option('opt_sort', 't,s,g', $lang['posts']['sortingmethod_time']);	// and subject
		echo draw_select_option('opt_sort', 'f,p,g', $lang['posts']['sortingmethod_filename'] . ', ' . $lang['posts']['sortingmethod_posteremail']);	// and poster email
		echo '</SELECT><BR>';
		
		echo $lang['posts']['groupingmethod'] . ' : ';
		echo "<SELECT name='opt_grouping' size='1' CLASS='inputTag_select inputTag'>\n";
		echo draw_select_option('opt_grouping', 'default', $lang['posts']['groupingmethod_showallfileswithgrouping']);
		echo draw_select_option('opt_grouping', 'do_not_group', $lang['posts']['groupingmethod_showallfileswithoutgrouping']);
		echo draw_select_option('opt_grouping', 'only_groups', $lang['posts']['groupingmethod_showonlygroups']);
		echo draw_select_option('opt_grouping', 'only_complete', $lang['posts']['groupingmethod_showonlycompletegroups']);
		echo draw_select_option('opt_grouping', 'only_fills', $lang['posts']['groupingmethod_showonlyfills']);
		echo '</SELECT><BR>';
		
		echo "<BR><INPUT TYPE='SUBMIT' name='posts_options' value='" .  $lang['posts']['button_search'] . "' CLASS='inputTag_button inputTag'>";
		
		echo "</TD><TD CLASS='viewPostsText widthPosts2' valign='top'>";
		
		$sql = 'SELECT * FROM nget_backbone';
		$class_db->query_db($sql);
		$row = $class_db->sql_results();
		$last_autoupdate = $row['last_autoupdate'];
		// add server lag time and covert back into 'post_time_elapsed' usable format
		$last_autoupdate = date('Y-m-d H:i:s', strtotime($last_autoupdate) - ($cfg['SERVER_LAG'] * 60));
		$tmp = '(within last ' . post_time_elapsed($last_autoupdate) . ')';
		$class_db->free_query();
		
		echo draw_checkbox_option($lang['posts']['showonlynewposts'] . ' ' . $tmp , 'opt_only_new') . '<BR>';
		
		echo $lang['posts']['minmaxage'] . ' : ' .
			"<INPUT TYPE='TEXT' NAME='opt_mintime' SIZE=5 MAXLENGTH=7 VALUE=\"" . convert_form_input($_SESSION['opt_mintime']) . "\" CLASS='inputTag_input inputTag'> / " .
			"<INPUT TYPE='TEXT' NAME='opt_maxtime' SIZE=5 MAXLENGTH=7 VALUE=\"" . convert_form_input($_SESSION['opt_maxtime']) . "\" CLASS='inputTag_input inputTag'> " . $lang['posts']['minmaxage_ex'] . "<BR>";
			
		echo $lang['posts']['minmaxsize'] . ' : ' .
			"<INPUT TYPE='TEXT' NAME='opt_minsize' SIZE=5 MAXLENGTH=7 VALUE=\"" . convert_form_input($_SESSION['opt_minsize']) . "\" CLASS='inputTag_input inputTag'> / " .
			"<INPUT TYPE='TEXT' NAME='opt_maxsize' SIZE=5 MAXLENGTH=7 VALUE=\"" . convert_form_input($_SESSION['opt_maxsize']) . "\" CLASS='inputTag_input inputTag'> " . $lang['posts']['minmaxsize_ex'] . "<BR>";
			
		echo $lang['posts']['search'] . " : <INPUT TYPE='TEXT' SIZE=20 MAXLENGTH=255 NAME='opt_search' VALUE=\"" . convert_form_input($_SESSION['opt_search']) . "\" CLASS='inputTag_input inputTag'> " .
			draw_checkbox_option($lang['posts']['search_boolean'], 'opt_search_bool') .
			draw_checkbox_option($lang['posts']['search_filename'], 'opt_search_filename') . '<BR>';
		echo $lang['posts']['regexsearch'] . " : <INPUT TYPE='TEXT' SIZE=30 MAXLENGTH=255 NAME='opt_regex_search' VALUE=\"" . convert_form_input($_SESSION['opt_regex_search']) . "\" CLASS='inputTag_input inputTag'><BR>";

		echo "</TD><TD CLASS='viewPostsText widthPosts3' valign='top'>";
		
		echo draw_checkbox_option($lang['posts']['hidegarbageposts'], 'opt_hide_garbage_posts') . '<BR>';
		echo draw_checkbox_option($lang['posts']['showincompleteposts'], 'opt_show_bad_posts') . '<BR>';
		echo draw_checkbox_option($lang['posts']['showallcrossposts'], 'opt_show_xposts') . '<BR>';
		echo draw_checkbox_option($lang['posts']['showonlyblacklistedposts'], 'opt_show_blacklisted_posts') . '<BR>';
		echo $lang['posts']['hidefiles'] . ' : ';
		echo draw_checkbox_option($lang['posts']['hidemp3s'], 'opt_hide_mp3s') . ' ';
		echo draw_checkbox_option($lang['posts']['hidegraphics'], 'opt_hide_jpg') . ' ';
		echo draw_checkbox_option($lang['posts']['hidetextfiles'], 'opt_hide_txt') . '<BR>';
		echo draw_checkbox_option($lang['posts']['pseudowishlist'], 'pseudo') . '<BR>';
		require_once $cfg["DIRS_WEB"] . 'pseudo_wishlist.php';
		//$tmp = "onmouseover=\"this.style.cursor='pointer'; this.style.borderBottom='1px #FF0000 dashed'\" onmouseout=\"this.style.borderBottom='none'\" onclick=\"options.opt_search.value='';";
		
		// SHOW ONLY WISHLIST - when ready
		
		echo '</TD></FORM></TR></TABLE>';	
		
		// make things at least appear responsive
		flush();
	}
	
	if ($_POST['posts_options'] || ($_GET['v'] == 'fg')) {
	
		// vars
		$xpost_array = array();
		$file_xpost_array = array();
		
		// make select only return values needed
		if ($_POST['opt_grouping'] == 'do_not_group') {
			$sql_select = 'SELECT * FROM posts';
		} else {
			$sql_select = 'SELECT * FROM posts' .
				' LEFT JOIN file_groups ON file_groups.file_post_first_ID=posts.post_ID';
		}
		$sql_select .= ' LEFT JOIN groups ON groups.group_ID = posts.post_group';
		
		// show only file groups or not
		if (($_POST['opt_grouping'] != 'do_not_group') && ($_GET['v'] != 'fg')) {
			$sql_where = ' WHERE (';
			if (($_POST['opt_grouping'] == 'only_groups') || $_POST['opt_show_only_complete'] || ($_POST['opt_grouping'] == 'only_fills')) { 
				$sql_where .= 'posts.file_group != 0 AND';
			} else { 
				$sql_where .= 'posts.file_group = 0 OR';
			}
			$sql_where .= ' file_groups.file_post_first_ID=posts.post_ID)';
		} else {
			$sql_where = ' WHERE 1';
		}
		
		// hide bad posts
		if (!$_POST['opt_show_bad_posts'] && ($_GET['v'] != 'fg')) {
			$sql_where .= ' AND posts.post_bad=0';
		}
		
		// show only blacklisted posts or hide them by default
		if (!$_POST['opt_show_blacklisted_posts']) {
			$sql_where .= ' AND posts.post_blacklisted=0';
		} else {
			$sql_where .= ' AND posts.post_blacklisted=1';
		}
		
		// hide mp3s/text files/graphics
		if ($_POST['opt_hide_mp3s']) {
			$sql_where .= ' AND posts.post_est_filename_ext != ".mp3"' .
				' AND posts.post_est_filename_ext != ".ogg"' .
				' AND posts.post_est_filename_ext != ".m3u"';
		}
		if ($_POST['opt_hide_txt']) {
			$sql_where .= ' AND posts.post_est_filename_ext != ".txt"';
		}
		if ($_POST['opt_hide_jpg']) {
			$sql_where .= ' AND posts.post_est_filename_ext != ".gif"' .
				' AND posts.post_est_filename_ext != ".jpg"' .
				' AND posts.post_est_filename_ext != ".jpeg"' .
				' AND posts.post_est_filename_ext != ".tif"' .
				' AND posts.post_est_filename_ext != ".tiff"' .
				' AND posts.post_est_filename_ext != ".bmp"' .
				' AND posts.post_est_filename_ext != ".png"' .
				' AND posts.post_est_filename_ext != ".gif"';
		}
		
		// show specific group/grouptype or all groups
		if ((int)$_POST['opt_group_type'] > 1) {
			$tmpa = $ngetgroups->get_group_type_assoc_array((int)$_POST['opt_group_type']);
			//echo '<PRE>'; print_r($tmpa); echo '</PRE>';
			$sql_where .= ' AND (';
			while (count($tmpa) > 0) {
				$tmpb = array_shift($tmpa);
				$sql_where .= 'groups.group_type=' . $tmpb['groupid'] . ' OR ';
			}
			$sql_where = preg_replace("/ OR $/", ")", $sql_where);
		} elseif ((int)$_POST['opt_group'] > 0) {
			$sql_where .= ' AND posts.post_group=' . $_POST['opt_group'];
		}
		
		// show only complete groups
		if ($_POST['opt_grouping'] == 'only_complete') {
			$sql_where .= ' AND (file_groups.file_complete=11 OR file_groups.file_complete=12 OR file_groups.file_complete=13 ' .
				' OR file_groups.file_complete=21 OR file_groups.file_complete=22 OR file_groups.file_complete=23)';
		} elseif ($_POST['opt_grouping'] == 'only_fills') {
			// show only fills
			$sql_where .= ' AND file_groups.file_complete=5';
		}
		/* elseif ($_POST['opt_minsize'] || $_POST['opt_maxsize']) {
			// if min/max values, hide fills
			$sql_where .= ' AND file_groups.file_complete != 5';
		}*/
		
		// Size restrictions
		//<<< make it filter out pars?
		if (($_POST['opt_grouping'] == 'only_groups') || ($_POST['opt_grouping'] == 'only_complete')) {
			// apply size limits to file groups
			if ($_POST['opt_minsize']) {
				$sql_where .= ' AND file_groups.file_total_size >= ' . ((int)caculate_size_in_kb($_POST['opt_minsize']));
			}
			if ($_POST['opt_maxsize']) {
				$sql_where .= ' AND file_groups.file_total_size <= ' . ((int)caculate_size_in_kb($_POST['opt_maxsize']));
			}
		} elseif ($_POST['opt_grouping'] == 'default') {
			// apply size limits to file and groups
			if ($_POST['opt_minsize']) {
				$sql_where .= ' AND ((posts.post_bytes >= ' . ((int)caculate_size_in_kb($_POST['opt_minsize']) * 1024) . 
					' AND posts.file_group = 0)' .
					' OR (file_groups.file_total_size >= ' . ((int)caculate_size_in_kb($_POST['opt_minsize'])) . '))';
			}
			if ($_POST['opt_maxsize']) {
				$sql_where .= ' AND ((posts.post_bytes <= ' . ((int)caculate_size_in_kb($_POST['opt_maxsize']) * 1024) .
					' AND posts.file_group=0)' .
					' OR (file_groups.file_total_size <= ' . ((int)caculate_size_in_kb($_POST['opt_maxsize'])) . '))';
			}
		} elseif ($_POST['opt_grouping'] == 'do_not_group') {
			// apply limits to only files
			if ($_POST['opt_minsize']) {
				$sql_where .= ' AND posts.post_bytes >= ' . ((int)caculate_size_in_kb($_POST['opt_minsize']) * 1024);
			}
			if ($_POST['opt_maxsize']) {
				$sql_where .= ' AND posts.post_bytes <= ' . ((int)caculate_size_in_kb($_POST['opt_maxsize']) * 1024);
			}
		}

		// Time
		if ($_POST['opt_only_new'] && ($_POST['opt_grouping'] == 'do_not_group')) {
			$sql_where .= ' AND posts.post_time >= "' . date('Y-m-d H:i:s', strtotime($last_autoupdate)) . '"';
		} elseif ($_POST['opt_only_new'] && ($_POST['opt_grouping'] != 'do_not_group')) {		
			$sql_where .= ' AND (posts.post_time >= "' . date('Y-m-d H:i:s', strtotime($last_autoupdate)) . '"' .
				' OR file_date_newest >= "' . date('Y-m-d H:i:s', strtotime($last_autoupdate)) . '")';
		} elseif (($_POST['opt_mintime'] || $_POST['opt_maxtime']) && ($_POST['opt_grouping'] == 'do_not_group')) {
			if ($_POST['opt_mintime']) {
				$sql_where .= ' AND posts.post_time <= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_mintime'])*60*60))) . '"';
			}
			if ($_POST['opt_maxtime']) {
				$sql_where .= ' AND posts.post_time >= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_maxtime'])*60*60))) . '"';
			}
		} elseif (($_POST['opt_mintime'] || $_POST['opt_maxtime']) && ($_POST['opt_grouping'] != 'do_not_group')) {	
			if ($_POST['opt_mintime']) {
				$sql_where .= ' AND (posts.post_time <= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_mintime'])*60*60))) . '"' .
					' OR file_date_newest <= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_mintime'])*60*60))) . '")';
			}
			if ($_POST['opt_maxtime']) {
				$sql_where .= ' AND (posts.post_time >= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_maxtime'])*60*60))) . '"' .
					' OR file_date_newest >= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_POST['opt_maxtime'])*60*60))) . '")';
			}
		}
		
		if ($_POST['opt_search'] && $_POST['opt_search_bool']) {
			// MySQL MATCH .. BOOLEAN search
			if ($_POST['opt_search_filename']) {
				$sql_where .= ' AND MATCH posts.post_est_filename AGAINST ("'. 
					//preg_replace("/'/", "\\'", stripslashes($_POST["opt_search"])) . "' IN BOOLEAN MODE)";
					$class_db->sql_friendly_post($_POST["opt_search"]) . '" IN BOOLEAN MODE)';
			} else {
				$sql_where .= ' AND MATCH posts.post_subject AGAINST ("'. 
					//preg_replace("/'/", "\\'", stripslashes($_POST["opt_search"])) . "' IN BOOLEAN MODE)";
					$class_db->sql_friendly_post($_POST['opt_search']) . '" IN BOOLEAN MODE)';
			}
		} elseif ($_POST['opt_search']) {
			if ($_POST['opt_search_filename']) {
				$sql_where .= ' AND posts.post_est_filename LIKE "' . 
					$class_db->sql_friendly_post($_POST['opt_search']) . '"';
			} else {
				$sql_where .= ' AND posts.post_subject LIKE "%' . 
					$class_db->sql_friendly_post($_POST['opt_search']) . '%"';
			}
		}
		
		// if showing an individual file group
		if ($_GET['v'] == 'fg') {
			$sql_where .= ' AND file_group = ' . (int)$_GET['n'];
		}
		
		$tmp = array(
			'g' => 'groups.group_name',
			'p' => ' posts.post_est_poster_email', 
			'f' => ' posts.post_est_filename', 
			't' => ' posts.post_time DESC', 
			's' => ' posts.post_subject' );
		if ($_GET['v'] == 'fg') {
			$sql_order = 'ORDER BY ' . strtr('f,s,t', $tmp);
		} else {
			$sql_order = 'ORDER BY ' . strtr($_POST['opt_sort'], $tmp);
		}

		$sql = $sql_select . ' ' . $sql_where . ' ' . $sql_order;
		//echo $sql. '<BR><BR>';
		list($usec, $sec) = explode(' ', microtime()); $render_time['mysql'] = ((float)$usec + (float)$sec);
		$class_db->query_db($sql);
		list($usec, $sec) = explode(' ', microtime()); $render_time['mysql'] = ((float)$usec + (float)$sec) - $render_time['mysql'];

		
		echo "<FORM NAME='selection' METHOD='POST' ACTION='index.php'>\n";
		echo "<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%' class='postTable'>\n";
		echo "<TR><TD><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH='100%'><TR>" .
			"<TD CLASS='topLine widthCol1'>" . $lang['posts']['title_subject'] . "</TD>" .
			"<TD CLASS='topLine widthCol2'>" . $lang['posts']['title_size'] . "</TD>" .
			"<TD CLASS='topLine widthCol3'>" . $lang['posts']['title_date'] . "</TD>" .
			"<TD CLASS='topLine widthCol4'>" . $lang['posts']['title_group'] . "</TD>" .
			"<TD CLASS='topLine widthCol5'>" . $lang['posts']['title_complete'] . "</TD>" .
			"</TR></TABLE></TD></TR>\n";
		$id_count = 1;
		
		while ($row = $class_db->sql_results()) {
			
			// more responsive. force output every fifty lines
			if (($id_count % 50) == 0) { flush(); }
			
			$tmp = true;
			// if regex searching
			if ($_POST['opt_regex_search'] || $_POST['pseudo']) {
				// if regex is typed in wrong, then nothing is drawn
				if (!$_POST['pseudo']) {
					$tmp = @preg_match(stripslashes($_POST['opt_regex_search']), $row['post_subject']);
				} else {
					$tmp = @preg_match($pseudowishlist, $row['post_subject']);
				}
			}
			if ($tmp) {	
				// hide garbage posts
				if ($_POST['opt_hide_garbage_posts']) {
					if (!$row['post_est_filename_ext'] ||					// 1. if no known file extension
						(preg_match("/^Re:/i", $row['post_subject']) &&		// 2. subject is replied to
						!$row['file_group'] &&								//    and not grouped
						((int)$row['post_bytes'] < (1024*10))) ||			//    and less then 10k
						(((int)$row['post_bytes'] < (1024*3)) && 			// 3. less then 3k in size
						!$row['file_group'] &&								//    and not grouped
						!preg_match("/\.(m3u|nfo|sfv|par|par2|ram|nzb)$/i", $row['post_est_filename_ext'])) ||	// and not a typical small file
						(floor((time() - strtotime($row['post_time'])) / 60) >= $cfg['POSTS_DELETE_TIME'])) {	// 4. post should be deleted timewise
						$tmp = false;
					}
				}
			}
			
			if ($tmp) {
				// if an individual file
				if ((((int)$row['file_group'] == 0) || ($_GET['v'] == 'fg') || ($_POST['opt_grouping'] == 'do_not_group')) && 
					(!check_xpost_id($row['post_xpost']) ||	$_POST['opt_show_xposts'])) {
					// add to list of xposted files
					add_xpost_id($row['post_xpost']);
					// subject
					$subject = post_highlight_filename($row['post_subject'], $row['post_est_filename']);
					$subject = post_highlight_imdb($subject, $id_count);
					$subject = post_highlight_ftd($subject, $id_count);
					$subject = post_highlight_ftn($subject, $id_count);
					//$subject = post_reverse_titles($subject);
					/* <<<DEBUG
					//$subject = '('.$row['post_xpost'].'|'.$row['file_group'].')'.$subject;
					$subject .= '<BR>' . htmlspecialchars($row['post_subject_ripped']) . '<B> # </B>' .
						htmlspecialchars($row['post_est_poster_email']) . '<B> # </B>' .
						htmlspecialchars($row['post_est_filename']);
					//*/
					
					$showfiles = '';
					if (($row['post_est_filename_ext'] == '.nfo') && $row['post_est_filename']) {
						$showfiles = " <SPAN CLASS='showFiles'>[<a href=" .
						"'http://www.newzbin.com/search/query/p/?q=" . $row["post_est_filename"] . "&Category=-1&searchFP=n'" .
						" target='_blank' onclick=\"itemSelectRow(event, " . $id_count . ")\" CLASS='postLink'>" . $lang['posts']['posts_newzbin'] . "</a>]";
					}
					
					// value for the checkbox
					$checkbox_value = 'P' . $row['post_ID'];
					
					// include 'extra' information
					$extra = $lang['posts']['posts_poster'] . ': ' . $row['post_est_poster_name'] . ' (' . $row['post_est_poster_email'] . ')';
					//'server: ' . $row['post_server'];
					
					if ((int)$row['post_xpost'] > 0) {
						$extra .= ', ' . $lang['posts']['posts_crossposted'];
					}
					$extra = preg_replace("/'/", "", $extra);
									
					post_draw_row( array( 
						'checkbox_value' => $checkbox_value,
						'id_count' => $id_count++,
						'post_bad' => (int)$row['post_bad'],
						'post_downloaded' => (int)$row['post_downloaded'],
						'subject' => $subject,
						'size' => post_convert_size($row['post_bytes'], 1024),
						'alt_size' => false,
						'time' => post_time_elapsed($row['post_time']),
						'realtime' => $row['post_time'],
						'group' => $ngetgroups->get_specific_group_name_abv((int)$row['post_group']),
						'groupname' => $ngetgroups->get_specific_group_name((int)$row['post_group']),
						'extra' => $extra,
						'showfiles' => $showfiles,
						'completion_code' => '&nbsp;',
						'single_file' => true
						));

				// if a file group
				} elseif (((int)$row['file_group'] != 0) && ($_POST['opt_grouping'] != 'do_not_group') && 
					(!check_file_xpost_id($row['file_xpost']) || $_POST['opt_show_xposts'])) {
					
					// add to list of xposted file groups/files
					add_xpost_id($row['post_xpost']);
					add_file_xpost_id($row['file_xpost']);

					$subject = post_highlight_filename($row['file_post_first'], $row['post_est_filename']);
					$subject = post_highlight_imdb($subject, $id_count);
					$subject = post_highlight_ftd($subject, $id_count);
					$subject = post_highlight_ftn($subject, $id_count);
					//$subject = post_reverse_titles($subject);
					//$subject = '('.$row['post_xpost'].'|'.$row['file_group'].')'.$subject;
					
					// value for the checkbox
					$checkbox_value = 'P' . $row['post_ID'];
					if ($row['file_post_first_ID']) {
						$checkbox_value .= 'F' . $row['file_group_ID'];
					}
					
					// completion codes
					list($completion_code, $alt_size) = post_completion_code((int)$row['file_complete'],
						(int)$row['file_number_par'], (int)$row['file_blocks_par2']);
						
					// draw the files link to show individual files inside a file group
					$showfiles = " <SPAN CLASS='showFiles'>[";
					if ((int)$row['file_complete'] == 30) {
						// if an MP3 group
						if ((int)$row['file_parts'] > 0) { 
							$showfiles .= $row['file_parts_total'] . ' ';
						}
					} else {
						// add additional statistics
						if ((int)$row['file_complete'] != 5) {
							// if not a par fill
							$tmp = null;
							if ((int)$row['file_post_nfo_ID'] > 0) { $tmp .= 'N'; }			// includes a .nfo
							if ((int)$row['file_post_sample_ID'] > 0) { $tmp .= 'S'; }		// includes a sample clip
							if ((int)$row['file_post_par_ID'] > 0) { $tmp .= 'P'; }			// includes a .par
							if ((int)$row['file_number_par'] > 0) { $tmp .= 'p'; }			// full par files
							if ((int)$row['file_post_par2_ID'] > 0) { $tmp .= 'Q'; }		// includes a .par2
							if ((int)$row['file_blocks_par2'] > 0) { $tmp .= 'q'; }			// par2 blocks
							if ((int)$row['file_post_sfv_ID'] > 0) { $tmp .= 'V'; }			// includes a .sfv
							if ($tmp) { $showfiles .= $tmp . ' '; }
						}
						if ((int)$row['file_parts'] > 0) { 
							$showfiles .= $row['file_parts'] . '/' . $row['file_parts_total'] . ' ';
						} elseif ((int)$row['file_zips'] > 0) { 
							$showfiles .= $row['file_zips'] . '/' . $row['file_zips_total'] . ' '; 
						}
					}
					//<<< hacky way of when clicking on 'files' it counteracts the clicking inside a td event
					$showfiles .= "<a href='index.php?v=fg&n=" . $row['file_group'] . 
						"' target='_blank' onclick=\"itemSelectRow(event, " . $id_count . ")\" title=' ";
					//$showfiles .= "<span onclick=\"window.open('index.php?v=fg&n=" . $row["file_group"] . "', null, null); itemSelectRow(event, " . $id_count . ")\" STYLE=\"color: #FF0000\" onmouseover=\"this.style.color='#ff6666'; this.style.cursor='pointer';\" onmouseout=\"this.style.color='#ff0000'\" title=' ";
					if (((int)$row['file_number_par'] > 0) && ((int)$row['file_blocks_par2'] > 0)) {
						$showfiles .= $lang['posts']['posts_parfiles'] . ':' . $row['file_number_par'] . '   ' . $lang['posts']['posts_par2blocks'] . ':' . $row['file_blocks_par2'];
					} elseif ((int)$row['file_number_par'] > 0) {
						$showfiles .= $lang['posts']['posts_parfiles'] . ':' . $row['file_number_par'];
					} elseif ((int)$row['file_blocks_par2'] > 0) {
						$showfiles .= $lang['posts']['posts_par2blocks'] . ':' . $row['file_blocks_par2'];
					} else {
						$showfiles .= $lang['posts']['posts_nopars'];
					}
					//$showfiles .= '   Poster:' . $row['post_poster'];
					$showfiles .= " ' CLASS='postLink'>" . $lang['posts']['posts_files'] . "</a>";
					//$showfiles .= " '>files</span>";
					// if includes .nfo, put a link to newzbin
					if ((int)$row['file_post_nfo_ID'] > 0) {
						$sql = 'SELECT * FROM posts WHERE post_id = ' . $row['file_post_nfo_ID'];
						$class_db->query_db2($sql);
						$row2 = $class_db->sql_results2();
						$class_db->free_query2();
						//$class_db->free_query2();
						$showfiles .= " <a href=" .	"'http://www.newzbin.com/search/query/p/?q=" . 
							$row2['post_est_filename'] . "&Category=-1&searchFP=n'" .
							" target='_blank' onclick=\"itemSelectRow(event, " . $id_count . ")\" title=' " .
							$row2['post_est_filename'] . " ' CLASS='postLink'>" . $lang['posts']['posts_newzbin'] . "</a>";
					}
					$showfiles .= ']</SPAN>';
					
					// include 'extra' information
					$extra = $lang['posts']['posts_poster'] . ': ' . $row['post_est_poster_name'] . ' (' . $row['post_est_poster_email'] . ')';
					//'server: ' . $row['post_server'];
					
					if ((int)$row['post_xpost'] > 0) {
						$extra .= ', ' . $lang['posts']['posts_crossposted'];
					}
					$extra = preg_replace("/'/", "", $extra);
					
					post_draw_row( array( 
						'checkbox_value' => $checkbox_value,
						'id_count' => $id_count++,
						'post_bad' => (int)$row['post_bad'],
						'post_downloaded' => (int)$row['post_downloaded'],
						'subject' => $subject,
						'size' => post_convert_size((int)$row['file_total_size'], 1),
						'alt_size' => $alt_size,
						'time' => post_time_elapsed($row['file_date_oldest']),
						'realtime' => $row['file_date_oldest'],
						'group' => $ngetgroups->get_specific_group_name_abv((int)$row['post_group']),
						'groupname' => $ngetgroups->get_specific_group_name((int)$row['post_group']),
						'extra' => $extra,
						'showfiles' => $showfiles,
						'completion_code' => $completion_code,
						'single_file' => false
						));
						
				}
			}	// if regex search 
		}
				
		$class_db->free_query();
		echo '</TABLE>' .
			//"&nbsp;<a href='#' onclick='window.scroll(0,0); return null;'>top</a>" .
			"<span onclick='window.scroll(0,0); return false;' onmouseover=\"this.style.cursor='pointer';\" STYLE='color: #FF0000; margin-left: 5px'>" . $lang['posts']['posts_top'] . "</span>" .
			"<BR><BR>&nbsp;&nbsp;<INPUT TYPE='SUBMIT' NAME='posts_downloadselectedfiles' VALUE='" . $lang['posts']['button_downloadselectedfiles'] . "' CLASS='inputTag_button inputTag'>" .
			"&nbsp;&nbsp;<INPUT TYPE='SUBMIT' NAME='posts_downloadimmediately' VALUE='" . $lang['posts']['button_downloadimmediately'] . "' CLASS='inputTag_button inputTag'>" .
			"</FORM><BR>";
		
		list($usec, $sec) = explode(' ', microtime()); $render_time['total'] = ((float)$usec + (float)$sec) - $render_time['total'] - $render_time['mysql'];
		echo "<DIV STYLE='margin-bottom:4px; text-align:right; margin-right: 10px;' class='RendertimeNormal'>" .
		$lang['posts']['posts_rendertime'] . ":<SPAN class='RendertimeNumbers'>" . round($render_time["total"],4) . "</SPAN>sec " .
		$lang['posts']['posts_mysql'] . ":<SPAN class='RendertimeNumbers'>" . round($render_time["mysql"],4) . "</SPAN>sec</DIV>";

	}
?>
