<?
	// post :: do the sql statement based on the criteria, the update the group post counts
	// actually just make this be able to delete a ton of posts for any reason, fuck we can even make it call the
		// routine to regroup the files if we wish (? can be done on one group without having to do them all?)
	// make option down the road to save these settings and have them automatically applied when updating/reloading
		// like a hardcore blacklist
	
	// put all posts into session var
	$tmpa = array('jp_groupname', 'jp_minsize', 'jp_maxsize', 'jp_poststart', 'jp_postend', 'jp_purgecomplete',
		'jp_purgecompletegrouped', 'jp_purgeincomplete', 'jp_purgeincompletegrouped', 'jp_fileextension',
		'jp_postsubject', 'jp_poster', 'jp_purgexposted');
	if ($_POST['submit']) {
		while ($tmp = array_shift($tmpa)) {
			$_SESSION[$tmp] = $_POST[$tmp];
		}
	}
		
	if (($_POST['submit'] == $lang['junk']['button_purgeposts']) || ($_POST['submit'] == $lang['junk']['button_testpurge'])) {
		// if regroup == true then the group must be 'regrouped'
		$regroup = false;
		$xposted = false;
		if ($_POST['submit'] == $lang['junk']['button_purgeposts']) {
			$sql = 'DELETE FROM posts';
		} elseif ($_POST['submit'] == $lang['junk']['button_testpurge']) {
			$sql = 'SELECT * FROM posts';
		}
		$sql2 = null;
		if ($_SESSION['jp_groupname'] != 'ALL') {
			$sql2 .= ' post_group = ' . $class_db->sql_friendly_post($_SESSION['jp_groupname']);
		}
		if ($_SESSION['jp_minsize']) {
			// minimum size
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_bytes >= ' . ((int)caculate_size_in_kb($_SESSION['jp_minsize']) * 1024);
		}
		if ($_SESSION['jp_maxsize']) {
			// maximum size
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_bytes <= ' . ((int)caculate_size_in_kb($_SESSION['jp_maxsize']) * 1024);
		}
		if ($_SESSION['jp_poststart']) {
			// start time of the posts
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_time <= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_SESSION['jp_poststart'])*60*60))) . '"';
		}
		if ($_SESSION['jp_postend']) {
			// end time of the posts
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_time >= "' . date('Y-m-d H:i:s', (time() - (caculate_hours($_SESSION['jp_postend'])*60*60))) . '"';
		}
		if ($_SESSION['jp_purgexposted']) {
			// delete xposted files
			$xposted = true;
		} else {
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_xpost = 0';
		}
		$sql3 = null;
		if ($_SESSION['jp_purgecomplete']) {
			// purge 'complete' ungrouped posts
			$sql3 .= ' (post_bad = 0 AND file_group = 0)';
		}
		if ($_SESSION['jp_purgecompletegrouped']) {
			// purge 'complete' grouped posts
			$regroup = true;
			if ($sql3) {
				$sql3 .= ' OR';
			}
			$sql3 .= ' (post_bad = 0 AND file_group > 0)';
		}
		
		if ($_SESSION['jp_purgeincomplete']) {
			// purge 'incomplete' ungrouped posts
			if ($sql3) {
				$sql3 .= ' OR';
			}
			$sql3 .= ' (post_bad = 1 AND file_group = 0)';
		}
		if ($_SESSION['jp_purgeincompletegrouped']) {
			// purge 'incomplete' grouped posts
			$regroup = true;
			if ($sql3) {
				$sql3 .= ' OR';
			}
			$sql3 .= ' (post_bad = 1 AND file_group > 0)';
		}
		if ($sql3 && $sql2) {
			$sql2 .= ' AND (' . $sql3 . ' )';
		} elseif ($sql3) {
			$sql2 .= ' (' . $sql3 . ' )';
		}
		if ($_SESSION['jp_fileextension']) {
			// start time of the posts
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_est_filename_ext = "';
			// must start with a period
			if (preg_match("/^\./", $_SESSION['jp_fileextension'])) {
				$sql2 .= $class_db->sql_friendly_post($_SESSION['jp_fileextension']) . '"';
			} else {
				$sql2 .= '.' . $class_db->sql_friendly_post($_SESSION['jp_fileextension']) . '"';
			}
		}
		if ($_SESSION['jp_postsubject']) {
			// start time of the posts
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_subject LIKE "' . $class_db->sql_friendly_post($_SESSION['jp_postsubject']) . '"';
		}
		if ($_SESSION['jp_poster']) {
			// start time of the posts
			if ($sql2) {
				$sql2 .= ' AND';
			}
			$sql2 .= ' post_est_poster_email LIKE "' . $class_db->sql_friendly_post($_SESSION['jp_poster']) . '"';
		}
		if ($sql2) {
			$sql = $sql . " WHERE" . $sql2;
		}
		//echo $sql . '<BR>';
		if ($_POST['submit'] == $lang['junk']['button_purgeposts']) {
			set_time_limit(3*60*60);	// 3 hours max runtime now. should suit everyone.
			echo '<BR>' . $lang['junk']['deletingposts'] . '.<BR>';
			flush();
			$class_db->write_db($sql);
			echo $lang['junk']['purgingdeleted1'] . ' <B>' . mysql_affected_rows() . '</B> ' . $lang['junk']['purgingdeleted2'] . '.<BR>';
			if (mysql_affected_rows() > 0) {
				if ($regroup) {
					echo $lang['junk']['regrouping'] . '.<BR>';
					flush();
					require_once($cfg["DIRS_WEB"] . 'daemon/class_group_process.php');
					$class_group = new group_process($cfg);
					$class_group->class_db = new db_control($cfg);
					$class_group->process_filegroups($class_db->sql_friendly_post($_SESSION['jp_groupname']), $ngetgroups->get_specific_group_method((int)$_SESSION['jp_groupname']));
				}
				if ($xposted) {
					echo $lang['junk']['redetectingcrossposts'] . '.<BR>';
					flush();
					require_once($cfg["DIRS_WEB"] . 'daemon/class_xpost_process.php');
					$class_xpost = new xpost_process($cfg);
					$class_xpost->class_db = new db_control($cfg);
					$class_xpost->detect_xpost_files();
				}
				echo $lang['junk']['recountingpostsingroups'] . '.<BR>';
				flush();
				require_once($cfg["DIRS_WEB"] . 'daemon/class_post_process.php');
				$class_pproc = new post_process($cfg);
				$class_pproc->class_db = new db_control($cfg);
				$class_pproc->update_good_posts($class_db->sql_friendly_post($_SESSION['jp_groupname']));
				echo $lang['junk']['postsdeleted'] . '.<BR>';
			}
		} elseif ($_POST['submit'] == $lang['junk']['button_testpurge']) {
			echo '<BR>' . $lang['junk']['caculating'] . '.<BR>';
			flush();
			$class_db->query_db($sql);
			echo $lang['junk']['purgingwilldelete1'] . ' <B>' . mysql_num_rows($class_db->dbquery) . '</B> ' . $lang['junk']['purgingwilldelete2'] . '.<BR>';
		}
	}
	
	echo '<BR>' . $lang['junk']['junkpostcleaning'] . '.<BR><BR>';
	echo '<FORM NAME="x" ACTION="index.php?v=junk" METHOD="POST">';
	
	// group
	echo $lang['junk']['group'] . ' <SELECT SIZE=1 NAME="jp_groupname" CLASS="inputTag_select inputTag">';
	while ($ngetgroups->get_current_group()) {
		$tmp = $ngetgroups->get_current_group_name() . "&nbsp;&nbsp;(" . $ngetgroups->get_specific_group_posts($ngetgroups->get_current_group()) . ")";
		echo draw_select_option('jp_groupname', $ngetgroups->get_current_group(), $tmp);
		$ngetgroups->get_next_group();
	}
	echo '</SELECT><BR>';
	
	// max/min size
	echo $lang['junk']['minimumsize'] . ' <INPUT TYPE="TEXT" SIZE=4 NAME="jp_minsize" VALUE="' . convert_form_input($_SESSION["jp_minsize"]) . '" CLASS="inputTag_input inputTag"> ' . $lang['junk']['sizes'] . '<BR>';
	echo $lang['junk']['maximumsize'] . ' <INPUT TYPE="TEXT" SIZE=4 NAME="jp_maxsize" VALUE="' . convert_form_input($_SESSION["jp_maxsize"]) . '" CLASS="inputTag_input inputTag"> ' . $lang['junk']['sizes'] . '<BR>';
	
	// start to end time
	echo $lang['junk']['newestpost'] . ' <INPUT TYPE="TEXT" SIZE=4 NAME="jp_poststart" VALUE="' . convert_form_input($_SESSION["jp_poststart"]) . '" CLASS="inputTag_input inputTag"> ' . $lang['junk']['dates'] . '<BR>';
	echo $lang['junk']['oldestpost'] . ' <INPUT TYPE="TEXT" SIZE=4 NAME="jp_postend" VALUE="' . convert_form_input($_SESSION["jp_postend"]) . '" CLASS="inputTag_input inputTag"> ' . $lang['junk']['dates'] . '<BR>';
	
	// complete/incomplete & grouped/ungrouped
	echo $lang['junk']['completeposts'] . ' : ' ;
	echo draw_checkbox_option($lang['junk']['completeposts_ungrouped'], 'jp_purgecomplete');
	echo ' ' . draw_checkbox_option($lang['junk']['completeposts_grouped'], 'jp_purgecompletegrouped') .'<BR>';
	echo $lang['junk']['incompleteposts'] . ' : ' ;
	echo draw_checkbox_option($lang['junk']['completeposts_ungrouped'], 'jp_purgeincomplete');
	echo ' ' . draw_checkbox_option($lang['junk']['completeposts_grouped'], 'jp_purgeincompletegrouped') .'<BR>';
	echo $lang['junk']['crossposting'] . ' : ' ;
	echo draw_checkbox_option($lang['junk']['includexposted'], 'jp_purgexposted') . '<BR>';
	// file extension
	echo $lang['junk']['fileextension'] . ' <INPUT TYPE="TEXT" SIZE=7 NAME="jp_fileextension" VALUE="' . convert_form_input($_SESSION["jp_fileextension"]) . '" CLASS="inputTag_input inputTag"> ' . $lang['junk']['fileextension_note'] . '<BR>';
	//' - Regex <INPUT TYPE="CHECKBOX" NAME="jp_filenameregex" VALUE="1"> <BR>';
	
	// subject
	echo $lang['junk']['postsubject'] . ' <INPUT TYPE="TEXT" SIZE=7 NAME="jp_postsubject" VALUE="' . convert_form_input($_SESSION["jp_postsubject"]) . '" CLASS="inputTag_input inputTag"><BR>';
	//'- Regex <INPUT TYPE="CHECKBOX" NAME="jp_subjectregex" VALUE="1"><BR>';
	
	// poster
	echo $lang['junk']['posteremail'] . ' <INPUT TYPE="TEXT" SIZE=7 NAME="jp_poster" VALUE="' . convert_form_input($_SESSION["jp_poster"]) . '" CLASS="inputTag_input inputTag"><BR>';
	//'- Regex <INPUT TYPE="CHECKBOX" NAME="jp_posterregex" VALUE="1"><BR>';
	
	// buttons
	echo '<BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="' . $lang['junk']['button_purgeposts'] . '" CLASS="inputTag_button inputTag">' .
		' <INPUT TYPE="SUBMIT" NAME="submit" VALUE="' . $lang['junk']['button_testpurge'] . '" CLASS="inputTag_button inputTag">' .
		' <INPUT TYPE="RESET" NAME="reset" VALUE="' . $lang['junk']['button_resetvalues'] . '" CLASS="inputTag_button inputTag"></FORM><BR>';
	
	// Legend
	echo $lang['junk']['legend1'] . '<BR>';
	echo $lang['junk']['legend2'] . '<BR>';
	echo $lang['junk']['legend3'] . '<BR>';
		
?>