<?
	// quickly update daemon
	
	
	if ($_POST["statsform"]) {
		if ($_POST["daemonstatus"] == "normal") { 
			$sql = "stop_everything = 0, stop_downloading = 0";
		} elseif ($_POST["daemonstatus"] == "stop_everything") { 
			$sql = "stop_everything = 1, stop_downloading = 0"; 
		} elseif ($_POST["daemonstatus"] == "stop_downloading") { 
			$sql = "stop_everything = 0, stop_downloading = 1"; 
		} else {
			$sql = "stop_everything = 0, stop_downloading = 0";
		}
		
		if ($_POST["headers"] == "normal") { 
			$sql .= ", one_time_update = 0, update_now = 0, refresh_db = 0";
		} elseif ($_POST["headers"] == "update_now") { 
			$sql .= ", one_time_update = 0, update_now = 1, refresh_db = 0"; 
		} elseif ($_POST["headers"] == "one_time_update") { 
			$sql .= ", one_time_update = 1, update_now = 0, refresh_db = 0"; 
		} elseif ($_POST["headers"] == "refresh_db") { 
			$sql .= ", one_time_update = 0, update_now = 0, refresh_db = 1";
		} else {
			$sql .= ", one_time_update = 0, update_now = 0, refresh_db = 0";
		}
		
		if ($_POST["autoupdate"] == "disabled") { 
			$sql .= ", stop_autoupdate = 1";
		} elseif ($_POST["autoupdate"] == "enabled") { 
			$sql .= ", stop_autoupdate = 0";
		} else {
			$sql .= ", stop_autoupdate = 1";
		}
		
		if ($_POST["daemoncontrol"] == "normal") { 
			$sql .= ", shutdown_daemon = 0"; 
		} elseif ($_POST["daemoncontrol"] == "restart_daemon") { 
			$sql .= ", shutdown_daemon = 1"; 
		} elseif ($_POST["daemoncontrol"] == "shutdown_daemon") { 
			$sql .= ", shutdown_daemon = 2"; 
		} else {
			$sql .= ", shutdown_daemon = 0"; 
		}
		
		$sql = "UPDATE nget_backbone SET " . $sql;
		$class_db->write_db($sql);
		
		if ($_POST['hardcore_cleardaemonlogs']) { 
			$sql = "DELETE FROM logs";
			$class_db->write_db($sql);
			echo $lang['settings']['daemonlogsdeleted'] . ".<BR><BR>";
		} elseif ($_POST['hardcore_cleardownloadqueue']) { 
			$sql = "DELETE FROM download";
			$class_db->write_db($sql);
			echo $lang['settings']['downloadqueuedeleted'] . ".<BR><BR>";
		} elseif ($_POST['hardcore_deleteallposts']) { 
			$sql = "DELETE FROM posts";
			$class_db->write_db($sql);
			$sql = "DELETE FROM file_groups";
			$class_db->write_db($sql);
			$sql = "DELETE FROM file_crossposts";
			$class_db->write_db($sql);
			$sql = "DELETE FROM file_crossposts_group";
			$class_db->write_db($sql);
			echo $lang['settings']['postsdeleted'] . ".<BR><BR>";
		}
	} elseif ($_POST["startdaemon"] == $lang['settings']['button_startdaemon']) { 
		// restart the daemon if not running
		exec( $cfg["DIRS_WEB"] . 'run.sh');
	}

	if ($_POST['css']) {
		$sql = 'UPDATE nget_backbone SET css = "' . $_POST['css'] . '"';
		$class_db->write_db($sql);
	}

	if (((int)exec('pidof php_ngetd') == 0) && ($_POST["startdaemon"] != $lang['settings']['button_startdaemon'])) {
		echo "<FORM NAME='startdaemonform' METHOD='POST' ACTION='index.php?v=settings'>" .
			"<BR><INPUT TYPE='SUBMIT' NAME='startdaemon' VALUE='" . $lang['settings']['button_startdaemon'] . "' CLASS='settingsButtons inputTag_button inputTag'><BR>" .
			"</FORM>";
	}
	
	$sql = "SELECT * FROM nget_backbone";
	$class_db->query_db($sql);
	$row = $class_db->sql_results();
	$class_db->free_query();
	
	echo $lang['settings']['currentlyupdating'] . " : ";
	if ($row["currently_updating"] == 1) { echo "yes"; } else { echo "no"; }
	echo "<BR>";
	echo $lang['settings']['currentstatus'] . " : " . $row["current_status"];
	echo "<BR>";
	
	echo $lang['settings']['currentautoupdate'] . " : " . $row["current_autoupdate"];
	echo "<BR>";
	echo $lang['settings']['lastautoupdate'] . " : " . $row["last_autoupdate"];
	echo "<BR>";
	echo $lang['settings']['autoupdatetime'] . " : " . $row["autoupdate_time"];
	echo "<BR>";
	echo $lang['settings']['deletepostsolderthen1'] . " : " . $cfg["POSTS_DELETE_TIME"] . " " . $lang['settings']['deletepostsolderthen2'];
	echo "<BR><BR>";

	$js = " onclick='this.form.submit()'";

	// change css

	echo $lang['settings']['changestylesheet'] . ":<BR>";

	echo "<FORM NAME='update' METHOD='POST' ACTION='index.php?v=settings'>";
	
	echo '<input type="radio" name="css" value="nget_black.css"' . $js;
	if ($row['css'] == 'nget_black.css') { echo ' checked'; }
	echo '> ' . $lang['settings']['changestylesheet_defaultblack'] . '<BR>';
	echo '<input type="radio" name="css" value="nget_nzb.css"' . $js;
	if ($row['css'] == 'nget_nzb.css') { echo ' checked'; }
	echo '> ' . $lang['settings']['changestylesheet_newzbin'] . '<BR>';
	echo '<input type="radio" name="css" value="nget_greenscale.css"' . $js;
	if ($row['css'] == 'nget_greenscale.css') { echo ' checked'; }
	echo '> ' . $lang['settings']['changestylesheet_greenscale'] . '<BR>';
	echo '<input type="radio" name="css" value="nget_gallina.css"' . $js;
	if ($row['css'] == 'nget_gallina.css') { echo ' checked'; }
	echo '> ' . $lang['settings']['changestylesheet_gallina'] . '<BR>';
	echo $lang['settings']['refreshforresultsafter'] . '</form><BR>';

	echo "<FORM NAME='update' METHOD='POST' ACTION='index.php?v=settings'>";
	echo "<INPUT TYPE='hidden' NAME='statsform' VALUE='1'>";

	echo $lang['settings']['daemonstatus'] . ":<BR>";
	
	echo "<INPUT TYPE='radio' name='daemonstatus' value='normal'";
	if (($row["stop_everything"] == 0) && ($row["stop_downloading"] == 0)) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['daemonstatus_daemonenabled'] . '<BR>';
	
	echo "<INPUT TYPE='radio' name='daemonstatus' value='stop_everything'";
	if ($row["stop_everything"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['daemonstatus_stopalldaemonactivities'] . '<BR>';
	
	echo "<INPUT TYPE='radio' name='daemonstatus' value='stop_downloading'";
	if ($row["stop_downloading"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['daemonstatus_stopdownloading'] . '<BR>';
	
	
	echo '<BR><BR>' . $lang['settings']['updateheaders'] . ':<BR>';
	
	echo "<INPUT TYPE='radio' name='headers' value='normal'";
	if (($row["one_time_update"] == 0) && ($row["update_now"] == 0) && ($row["refresh_db"] == 0)) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['updateheaders_idle'] . '<BR>';

	echo "<INPUT TYPE='radio' name='headers' value='update_now'";
	if ($row["update_now"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['updateheaders_updatenow'] . '<BR>';
	
	echo "<INPUT TYPE='radio' name='headers' value='one_time_update'";
	if ($row["one_time_update"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['updateheaders_onetimeupdate'] . '<BR>';
	
	echo "<INPUT TYPE='radio' name='headers' value='refresh_db'";
	if ($row["refresh_db"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['updateheaders_refreshdb'] . '<BR>';

	
	echo '<BR><BR>' . $lang['settings']['autoupdatingheaders'] . ':<BR>';
	
	echo "<INPUT TYPE='radio' name='autoupdate' value='enabled'";
	if ($row["stop_autoupdate"] == 0) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['autoupdatingheaders_enabled'] . ' (' . $row["autoupdate_time"] . ')<BR>';

	echo "<INPUT TYPE='radio' name='autoupdate' value='disabled'";
	if ($row["stop_autoupdate"] == 1) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['autoupdatingheaders_disabled'] . '<BR>';
	
	
	echo '<BR><BR>' . $lang['settings']['daemoncontrol'] . ':<BR>';
	
	echo "<INPUT TYPE='radio' name='daemoncontrol' value='normal'";
	if ($row["shutdown_daemon"] == 0) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['daemoncontrol_normaloperation'] . '<BR>';
	
	//echo "<INPUT TYPE='radio' name='daemoncontrol' value='restart_daemon'";
	//if ($row["shutdown_daemon"] == 1) { echo " checked"; }
	//echo $js . '> ' . $lang['settings']['daemoncontrol_restartdaemon'] . '<BR>';
	
	echo "<INPUT TYPE='radio' name='daemoncontrol' value='shutdown_daemon'";
	if ($row["shutdown_daemon"] == 2) { echo " checked"; }
	echo $js . '> ' . $lang['settings']['daemoncontrol_shutdowndaemon'] . '<BR>';
	
/*	echo "Stop Everything : ";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Stop Everything' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Enable Everything' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	
	echo "Stop Autoupdate : ";
	if ($row["stop_autoupdate"] == 1) { echo "enabled"; } else { echo "disabled"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Stop AutoUpdate' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Enable AutoUpdate' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	
	echo "Stop Downloading : ";
	if ($row["stop_downloading"] == 1) { echo "enabled"; } else { echo "disabled"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Stop Downloading' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Enable Downloading' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";

	echo "Onetime Update : ";
	if ($row["one_time_update"] == 1) { echo "on"; } else { echo "off"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='One-Time Update' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Disable One-Time Update' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	
	echo "Update Now : ";
	if ($row["update_now"] == 1) { echo "on"; } else { echo "off"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Update Now' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Disable Update Now' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	
	echo "Refresh DB : ";
	if ($row["refresh_db"] == 1) { echo "on"; } else { echo "off"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Refresh DB' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Disable Refresh DB' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	
	echo "Restart Daemon : ";
	if ($row["shutdown_daemon"] == 0) { echo "no"; 
		} elseif ($row["shutdown_daemon"] == 1) { echo "restart";
		} elseif ($row["shutdown_daemon"] == 2) { echo "shutdown"; }
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Default Daemon' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Restart Daemon' CLASS='settingsButtons inputTag_button inputTag'>";
	echo "<BR><INPUT TYPE='SUBMIT' NAME='upd' VALUE='Shutdown Daemon' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
*/
	echo '<BR><BR>';
	echo "<INPUT TYPE='SUBMIT' NAME='hardcore_cleardaemonlogs' VALUE='" . $lang['settings']['button_cleardaemonlogs'] . "' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	echo "<INPUT TYPE='SUBMIT' NAME='hardcore_cleardownloadqueue' VALUE='" . $lang['settings']['button_cleardownloadqueue'] . "' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";
	echo "<INPUT TYPE='SUBMIT' NAME='hardcore_deleteallposts' VALUE='" . $lang['settings']['button_deleteallposts'] . "' CLASS='settingsButtons inputTag_button inputTag'><BR><BR>";

	echo "</FORM>";

	/*
	// These are dated now, will be updated in the future
	echo "CONFIG VARIABLES<BR>";
	echo "Cache file lines : " . $cfg["CACHE_INCR"] . "<BR>";
	echo "Location of header download script : " . $cfg["PROG_HEADER"] . "<BR>";
	echo "Location of post download script : " . $cfg["PROG_DOWNLD"] . "<BR>";
	echo "Location of process logs : " . $cfg["LOG_FILE"] . "<BR>";
	echo "Location of web content : " . $cfg["DIRS_WEB"] . "<BR>";
	echo "Location of nget cache directory : " . $cfg["DIRS_CACHE"] . "<BR>";
	echo "Location of nget temp directory : " . $cfg["DIRS_TEMP"] . "<BR>";
	echo "Location of nget logging directory : " . $cfg["DIRS_LOG"] . "<BR>";
	echo "Location of nget download directory : " . $cfg["DIRS_DOWNLOAD"] . "<BR>";
	echo "Location of .ngetrc : " . $cfg["DIRS_CONFIG"] . "<BR>";
	echo "Concurrent header connections to usenet server : " . $cfg["CONCURRENT_HEADERS"] . "<BR>";
	echo "Concurrent download connections to usenet server : " . $cfg["CONCURRENT_DOWNLOADS"] . "<BR>";
	echo "Retrys for headers downloads : " . $cfg["MAX_RETRY_HEADERS"] . "<BR>";
	echo "Delay between each retry : " . $cfg["RETRY_HEADERS_DELAY"] . "<BR>";
	echo "Retrys for posts downloads : " . $cfg["MAX_RETRY_DOWNLOADS"] . "<BR>";
	echo "Delay between each retry : " . $cfg["RETRY_DOWNLOADS_DELAY"] . "<BR>";
	echo "Use ngets -autopar feature : " . $cfg["AUTOPAR_DOWNLOADS"] . "<BR>";
	echo "Daemon polling interval : " . $cfg["DAEMON_POLLING_INTERNAL"] . "<BR>";
	echo "When a post is considered old : " . $cfg["POSTS_OLD_TIME"] . "<BR>";
	echo "What a post is forcibaly deleted : " . $cfg["POSTS_DELETE_TIME"] . "<BR>";
	echo "Enable Blacklists : " . $cfg["ENABLE_BLACKLISTS"] . "<BR>";
	echo "Enable Wishlists : " . $cfg["ENABLE_WISHLISTS"] . "<BR>";
	echo "Enable Junk Flood detection : " . $cfg["ENABLE_REMOVE_JUNK_FLOODS"] . "<BR>";
	echo "Include incomplete posts in header count : " . $cfg["INCOMPLETES_IN_HEADERS"] . "<BR>";
	echo "Include incomplete posts when caculating size for a file group : " . $cfg["INCOMPLETES_IN_SIZE"] . "<BR>";
	echo "Refresh 'view download queue' and 'view daemon log' pages in seconds : " . $cfg["GUI_REFRESH_LOGS"] . "<BR>";
	echo "Refresh onscreen daemon statistics in seconds : " . $cfg["GUI_REFRESH_DAEMON_STATS"] . "<BR>";
	echo "Style sheet for GUI : " . $cfg["GUI_CSS"] . "<BR>";
	echo "Enable jpgraph functions : " . $cfg["ENABLE_JPGRAPH"] . "<BR>";
	echo "When the log should be trimmed, in minutes : " . $cfg["DAEMON_LOG_DELETE_TIME"] . "<BR>";
	echo "Logging Verbosity (0-5) : " . $cfg["DAEMON_LOGGING_VERBOSITY"] . "<BR>";
	echo "Enable saving of nget output into the log dir for each invocation : " . $cfg["ENABLE_NGET_LOGGING"] . "<BR>";
	echo "<BR>";
	*/
?>