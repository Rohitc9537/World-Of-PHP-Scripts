<?
	if ($_POST["generate"]) {
		echo '<BR>' . $lang['stats']['generatingnewgraphs'] . '.';
		flush();
		$db_assoc = array();
		$groups = array( 
			"goodposts" => array(), 		// ["goodposts"][group number]
			"badposts" => array(),		
			"totalposts" => array(),
			"grouped" => array(),
			"grouped_xpost" => array(),
			"ungrouped" => array(),
			"ungrouped_xpost" => array(),
			"groupname" => array() );
		$total = array( 
			"goodposts" => array(), 		// ["goodposts"][posting hour]
			"badposts" => array() );
		
		//<<< add to the config sections
		$graph_incr = 60;		// graph every x minutes (max 60 or divide evenly into 60: 30,20,15,10,5)
		$graph_interval = 72;	// draw text interval every x increments

		// max time to allow post in, round to minutes
		$maxtime = time();
		$maxtime = ($maxtime - ($maxtime % 60) - ($cfg["POSTS_DELETE_TIME"] * 60));
	
		// populate arrays with group info
		$sql = "SELECT * FROM groups ORDER BY group_name";
		$class_db->query_db($sql);
		$groupid = 0;
		while ($row = $class_db->sql_results()) {
			$db_assoc[$row["group_ID"]] = $groupid;
			$groups["groupname"][$groupid] = $row["group_abv"] . " ";
			$groupid++;
		}
		$groupid--;
		
		// prepare all arrays to make jpgraph happy
		$xaxis = array();
		for ($i=0; $i <= floor($cfg["POSTS_DELETE_TIME"] / $graph_incr); $i++) {
			if (($i % (60 / $graph_incr)) == 0) {
				$xaxis[$i] = ($i / (60 / $graph_incr));
			   	if (($xaxis[$i] % 24) == 0)	{
					$xaxis[$i] = ($xaxis[$i] / 24) . "d";
				} else {
					$xaxis[$i] .= 'h';
				}
				
			} else {
				$xaxis[$i] = "";
			}
			$total["badposts"][$i] = 0;
			$total["goodposts"][$i] = 0;
		}
		for ($i=0; $i <= $groupid; $i++) {
			$groups["badposts"][$i] = 0;
			$groups["goodposts"][$i] = 0;
			$groups["totalposts"][$i] = 0;
			$groups["grouped"][$i] = 0;
			$groups["grouped_xpost"][$i] = 0;
			$groups["ungrouped"][$i] = 0;
			$groups["ungrouped_xpost"][$i] = 0;
		}
	
		//$sql = "SELECT * FROM posts";
		// this should keep it from eating excessive amounts of memory
		$i = 0;
		do {
			$sql = "SELECT * FROM posts LIMIT " . ($cfg['SQL_BATCH'] * $i++) . ", " . $cfg['SQL_BATCH'];
			//$sql = "SELECT * FROM posts LIMIT 15001";
			$class_db->query_db($sql);
			while ($row = $class_db->sql_results()) {
				if (strtotime($row["post_time"]) > $maxtime) {
					$posttime = (floor($cfg["POSTS_DELETE_TIME"] / $graph_incr) - floor((strtotime($row["post_time"]) - $maxtime) / ($graph_incr*60)));
					// good&bad posts
					if ($row["post_bad"] == 1) {
						$groups["badposts"][$db_assoc[$row["post_group"]]]++;
						$total["badposts"][$posttime]++;
					} else {
						$groups["goodposts"][$db_assoc[$row["post_group"]]]++;
						$total["goodposts"][$posttime]++;
					}
					// total posts
					$groups["totalposts"][$db_assoc[$row["post_group"]]]++;
					$total["totalposts"]++;
					// crossposts
					if ($row["post_xpost"] > 0) {
						// crossposted
						if ($row["file_group"] > 0) {
							// and grouped
							$groups["grouped_xpost"][$db_assoc[$row["post_group"]]]++;
							$total["grouped"]++;
						} else {
							// not grouped
							$groups["ungrouped_xpost"][$db_assoc[$row["post_group"]]]++;
							$total["ungrouped"]++;
						}
					} else {
						// not crossposted
						if ($row["file_group"] > 0) {
							// and grouped
							$groups["grouped"][$db_assoc[$row["post_group"]]]++;
							$total["grouped"]++;
						} else {
							// not grouped
							$groups["ungrouped"][$db_assoc[$row["post_group"]]]++;
							$total["ungrouped"]++;
						}
					}				
				}
			}
		echo "."; flush();
		//<<< This is hacky to reference directly
		} while (mysql_num_rows($class_db->dbquery) == $cfg['SQL_BATCH']);
		
		// hide empty groups
		$moveback = 0;
		foreach($groups['totalposts'] as $key => $value) {
			if (($value > 0) && ($key > $moveback)) {
				$groups["badposts"][$moveback] = $groups["badposts"][$key];
				$groups["goodposts"][$moveback] = $groups["goodposts"][$key];
				$groups["totalposts"][$moveback] = $groups["totalposts"][$key];
				$groups["grouped"][$moveback] = $groups["grouped"][$key];
				$groups["grouped_xpost"][$moveback] = $groups["grouped_xpost"][$key];
				$groups["ungrouped"][$moveback] = $groups["ungrouped"][$key];
				$groups["ungrouped_xpost"][$moveback] = $groups["ungrouped_xpost"][$key];
				$groups["groupname"][$moveback] = $groups["groupname"][$key];
				$moveback++;
			}
			if ((($value > 0) && ($key > ($moveback - 1))) || ($value == 0)) {
				unset($groups["badposts"][$key]);
				unset($groups["goodposts"][$key]);
				unset($groups["totalposts"][$key]);
				unset($groups["grouped"][$key]);
				unset($groups["grouped_xpost"][$key]);
				unset($groups["ungrouped"][$key]);
				unset($groups["ungrouped_xpost"][$key]);
				unset($groups["groupname"][$key]);
			} else {
				$moveback++;
			}
		}
		
		require_once $cfg["DIRS_WEB"] . 'jpgraph/jpgraph.php';
		require_once $cfg["DIRS_WEB"] . 'jpgraph/jpgraph_line.php';
		require_once $cfg["DIRS_WEB"] . 'jpgraph/jpgraph_bar.php';
		
		// chart of bad files/hour - for detecting usenet provider hiccups
		$graph = new Graph(1000,200,"gif");
		$graph->SetScale("textint",0,0,0,floor($cfg["POSTS_DELETE_TIME"] / $graph_incr));
		
		$graph->SetBackgroundGradient("#000020","#0000A0",GRAD_HOR,BGRAD_PLOT);		// set background of plot to gradient
		$graph->SetFrame(true,'black');					// frame around whole plot is black
		$graph->SetMarginColor('black');				// black surrounding plot
		$graph->img->SetMargin(60,50,30,30);
		$graph->img->SetAntiAliasing();
	
		$graph->tabtitle->Set(' ' . $lang['stats']['postsovertime'] . ' ' );
		$graph->tabtitle->SetFont(FF_ARIAL,FS_BOLD,8);
		
		$graph->xaxis->title->Set("hours old");
		$graph->xaxis->title->SetColor("white");
		$graph->xaxis->SetTickLabels($xaxis);
		$graph->xaxis->SetTextTickInterval(((60 / $graph_incr) * $graph_interval), 0);		// draw tick label every x intervals
		//$graph->xaxis->SetTextLabelInterval(((60 / $graph_incr) * $graph_interval));
		$graph->xaxis->SetColor("#AAAAFF", "white");
		$graph->xaxis->SetTickSide(SIDE_DOWN);			// only draw the ticks facing down
		//$graph->xaxis->scale->SetGrace(2,0); 			// pad right by 2%
		$graph->xaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		
		//$graph->yaxis->title->Set("# of posts");
		//$graph->yaxis->title->SetColor("white");
		$graph->yaxis->SetColor("#AAAAFF", "white");
		$graph->yaxis->SetTickSide(SIDE_LEFT);			// only draw ticks facing left
		$graph->yaxis->scale->SetGrace(5,0); 			// pad top by 10%
		$graph->yaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->ygrid->SetColor("#AAAAFF");				// yaxis grid color
		
		$b1plot = new LinePlot($total["goodposts"]);
		$b1plot->SetFillColor("green"); // Fill color
		$b1plot->SetLegend(@floor((array_sum($total["goodposts"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['good'] . " (" . array_sum($total["goodposts"]) . ")");
			
		$b2plot = new LinePlot($total["badposts"]);
		$b2plot->SetFillColor("red"); // Fill color
		$b2plot->SetLegend(@floor((array_sum($total["badposts"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['bad'] . " (" . array_sum($total["badposts"]) . ")");
		$ab1plot = new AccLinePlot(array($b1plot,$b2plot)); 
		
		// Setup the legend box colors and font
		$graph->legend->SetColor('white','navy@0.1');
		$graph->legend->SetFillColor('navy@0.3');
		$graph->legend->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->legend->SetShadow('black',1);
		$graph->legend->SetPos(0,0,'right','top');
		
		$graph->Add($ab1plot);
		
		$txt=new Text(date("F j, g:i a"));
		$txt->Pos(5,40);
		$txt->SetAngle(90);
		$txt->SetColor("white");
		$txt->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->AddText($txt);

		$graph->Stroke($cfg["DIRS_WEB"] . "graphs/posts_time.gif");	// write to this file.
	
		
		// chart of bad files/group - see if individual groups are naughty
		$graph = new Graph(1000,500,"gif");
		$graph->SetScale("textint",0,0,0,0);
		
		$graph->SetBackgroundGradient("#000020","#0000A0",GRAD_HOR,BGRAD_PLOT);		// set background of plot to gradient
		$graph->SetFrame(true,'black');					// frame around whole plot is black
		$graph->SetMarginColor('black');				// black surrounding plot
		$graph->img->SetMargin(60,50,30,130);
		$graph->img->SetAntiAliasing();
	
		$graph->tabtitle->Set(' ' . $lang['stats']['postsbygroup'] . ' ' );
		$graph->tabtitle->SetFont(FF_ARIAL,FS_BOLD,8);
		
		//$graph->xaxis->title->Set("hours old");
		//$graph->xaxis->title->SetColor("white");
		$graph->xaxis->SetTickLabels($groups["groupname"]);
		$graph->xaxis->SetLabelAngle(90);
		$graph->xaxis->SetColor("#AAAAFF", "white");
		$graph->xaxis->SetTickSide(SIDE_DOWN);			// only draw the ticks facing down
		//$graph->xaxis->scale->SetGrace(2,0); 			// pad right by 2%
		$graph->xaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		
		$graph->yaxis->SetColor("#AAAAFF", "white");
		$graph->yaxis->SetTickSide(SIDE_LEFT);			// only draw ticks facing left
		$graph->yaxis->scale->SetGrace(10,0); 			// pad top by 10%
		$graph->yaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->ygrid->SetColor("#AAAAFF");				// yaxis grid color
		
		$b1plot = new BarPlot($groups["goodposts"]);
		$b1plot->SetFillColor("green"); // Fill color
		$b1plot->SetLegend($lang['stats']['good']);
		
		$b2plot = new BarPlot($groups["badposts"]);
		$b2plot->SetFillColor("red"); // Fill color
		$b2plot->SetLegend($lang['stats']['bad']);
		
		//$b1plot->value->Show(); $b2plot->value->Show();
		//$b1plot->value->SetFormat('%d'); $b2plot->value->SetFormat('%d');
		//$b1plot->value->SetColor("white"); $b2plot->value->SetColor("white");
		//$b1plot->SetWidth(0.9);	$b2plot->SetWidth(0.9);
		//$gbplot = new GroupBarPlot(array($b1plot,$b2plot));
		$acplot = new AccBarPlot(array($b1plot,$b2plot));
		$acplot->SetWidth(0.7);
		
		// Setup the legend box colors and font
		$graph->legend->SetColor('white','navy@0.1');
		$graph->legend->SetFillColor('navy@0.3');
		$graph->legend->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->legend->SetShadow('black',1);
		$graph->legend->SetPos(0,0,'right','top');
		
		$graph->Add($acplot);
		
		$txt=new Text(date("F j, g:i a"));
		$txt->Pos(5,40);
		$txt->SetAngle(90);
		$txt->SetColor("white");
		$txt->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->AddText($txt);
		
		$graph->Stroke($cfg["DIRS_WEB"] . "graphs/posts_group.gif");	// write to this file.
		
		
		// chart of filegroups/group
		$graph = new Graph(1000,500,"gif");
		$graph->SetScale("textint",0,0,0,0);
		
		$graph->SetBackgroundGradient("#000020","#0000A0",GRAD_HOR,BGRAD_PLOT);		// set background of plot to gradient
		$graph->SetFrame(true,'black');					// frame around whole plot is black
		$graph->SetMarginColor('black');				// black surrounding plot
		$graph->img->SetMargin(60,50,30,130);
		$graph->img->SetAntiAliasing();
	
		$graph->tabtitle->Set(' ' . $lang['stats']['groupingbygroup'] . ' ' );
		$graph->tabtitle->SetFont(FF_ARIAL,FS_BOLD,8);
		
		//$graph->xaxis->title->Set("hours old");
		//$graph->xaxis->title->SetColor("white");
		$graph->xaxis->SetTickLabels($groups["groupname"]);
		$graph->xaxis->SetLabelAngle(90);
		$graph->xaxis->SetColor("#AAAAFF", "white");
		$graph->xaxis->SetTickSide(SIDE_DOWN);			// only draw the ticks facing down
		//$graph->xaxis->scale->SetGrace(2,0); 			// pad right by 2%
		$graph->xaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		
		$graph->yaxis->SetColor("#AAAAFF", "white");
		$graph->yaxis->SetTickSide(SIDE_LEFT);			// only draw ticks facing left
		$graph->yaxis->scale->SetGrace(10,0); 			// pad top by 10%
		$graph->yaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->ygrid->SetColor("#AAAAFF");				// yaxis grid color
		
		$b1plot = new BarPlot($groups["grouped"]);
		$b1plot->SetFillColor("darkseagreen1"); // Fill color
		$b1plot->SetLegend(@floor((array_sum($groups["grouped"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['grouped'] . " (" . array_sum($groups["grouped"]) . ")");
			
		$b2plot = new BarPlot($groups["grouped_xpost"]);
		$b2plot->SetFillColor("darkseagreen3"); // Fill color
		$b2plot->SetLegend(@floor((array_sum($groups["grouped_xpost"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['groupedxposted'] . " (" . array_sum($groups["grouped_xpost"]) . ")");
			
		$b3plot = new BarPlot($groups["ungrouped"]);
		$b3plot->SetFillColor("gold1"); // Fill color
		$b3plot->SetLegend(@floor((array_sum($groups["ungrouped"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['ungrouped'] . " (" . array_sum($groups["ungrouped"]) . ")");
			
		$b4plot = new BarPlot($groups["ungrouped_xpost"]);
		$b4plot->SetFillColor("goldenrod3"); // Fill color
		$b4plot->SetLegend(@floor((array_sum($groups["ungrouped_xpost"]) / $total["totalposts"]) * 100) . "%" . 
			" " . $lang['stats']['ungroupedxposted'] . " (" . array_sum($groups["ungrouped_xpost"]) . ")");
	
		$acplot = new AccBarPlot(array($b4plot,$b3plot,$b2plot,$b1plot));
		
		$acplot->SetWidth(0.7);
		
		// Setup the legend box colors and font
		$graph->legend->SetColor('white','navy@0.1');
		$graph->legend->SetFillColor('navy@0.3');
		$graph->legend->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->legend->SetShadow('black',1);
		$graph->legend->SetPos(0,0,'right','top');
		
		$graph->Add($acplot);
		
		$txt=new Text(date("F j, g:i a"));
		$txt->Pos(5,40);
		$txt->SetAngle(90);
		$txt->SetColor("white");
		$txt->SetFont(FF_ARIAL,FS_NORMAL,8);
		$graph->AddText($txt);
		
		$graph->Stroke($cfg["DIRS_WEB"] . "graphs/xposts_group.gif");	// write to this file.
	}
	
	echo "<BR><BR><img src='graphs/posts_time.gif' border=0 ALT='" . $lang['stats']['postsovertime'] . "'><BR><BR>";
	echo "<img src='graphs/posts_group.gif' border=0 ALT='" . $lang['stats']['postsbygroup'] . "'><BR><BR>";
	echo "<img src='graphs/xposts_group.gif' border=0 ALT='" . $lang['stats']['groupingbygroup'] . "'><BR><BR>";
	echo "<FORM action='index.php?v=stats' method='post'><INPUT type='submit' name='generate' value='" . $lang['stats']['generatenewgraphs'] . "' CLASS='inputTag_button inputTag'></FORM><BR>";
?>
