<?
	//<<< quick n dirty, needs purdying up
	// write changes to db
	if (($_POST['blacklists_delete']) && $_POST['del']) {
		while ($tmp = array_pop($_POST['del'])) {
			$sql = 'DELETE FROM blacklist WHERE blacklist_ID = ' . $tmp;
			$class_db->write_db($sql);
		}
	} elseif (($_POST['blacklists_savechanges']) && $_POST['id']) {
		while ($tmp = array_pop($_POST['id'])) {
			$sql = 'UPDATE blacklist SET ' .
				'blacklist_regex="' . $class_db->sql_friendly_post($_POST['subjectregex_'.$tmp]) . '", ' .
				'blacklist_filename_regex="' . $class_db->sql_friendly_post($_POST['filenameregex_'.$tmp]) . '", ' .
				'blacklist_sql="' . $class_db->sql_friendly_post($_POST['subject_'.$tmp]) . '", ' .
				'blacklist_filename_sql="' . $class_db->sql_friendly_post($_POST['filename_'.$tmp]) . '" ' .
				'WHERE blacklist_ID = ' . $tmp;
			$class_db->write_db($sql);
		}
	} elseif (($_POST['blacklists_addnew']) && 
		($_POST['subjectregex'] || $_POST['filenameregex'] || $_POST['subject'] || $_POST['filename'])) {
		$sql = 'INSERT INTO blacklist (blacklist_regex, blacklist_filename_regex, blacklist_sql, blacklist_filename_sql) VALUES (' .
			'"' . $class_db->sql_friendly_post($_POST['subjectregex']) . '", ' .
			'"' . $class_db->sql_friendly_post($_POST['filenameregex']) . '", ' .
			'"' . $class_db->sql_friendly_post($_POST['subject']) . '", ' .
			'"' . $class_db->sql_friendly_post($_POST['filename']) . '")';
		$class_db->write_db($sql);
	}

	// draw db
	echo "<BR><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0><FORM NAME='x' ACTION='index.php?v=blacklists' METHOD='POST'>\n";
	$sql = 'SELECT * FROM blacklist ORDER BY blacklist_ID';
	$class_db->query_db($sql);
	$results = 0;
	while ($row = $class_db->sql_results()) {
		echo "<TR><TD CLASS='groups'><INPUT TYPE='hidden' NAME='id[]' VALUE='" . $row["blacklist_ID"] . "'>" . $lang['blacklists']['delete'] . " <INPUT TYPE='checkbox' NAME='del[]' VALUE='" . $row["blacklist_ID"] . "'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['subjectregex'] . " <INPUT TYPE='text' SIZE=20 NAME='subjectregex_" . $row["blacklist_ID"] . "' VALUE=\"" . convert_sql_input($row["blacklist_regex"]) . "\" CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['filenameregex'] . " <INPUT TYPE='text' SIZE=20 NAME='filenameregex_" . $row["blacklist_ID"] . "' VALUE=\"" . convert_sql_input($row["blacklist_filename_regex"]) . "\" CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['subject'] . " <INPUT TYPE='text' SIZE=20 NAME='subject_" . $row["blacklist_ID"] . "' VALUE=\"" . convert_sql_input($row["blacklist_sql"]) . "\" CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['filename'] . " <INPUT TYPE='text' SIZE=20 NAME='filename_" . $row["blacklist_ID"] . "' VALUE=\"" . convert_sql_input($row["blacklist_filename_sql"]) . "\" CLASS='inputTag_input inputTag'></TD>\n" .
			"</TR>\n";
		$results++;
	}
	if ((int)$results > 0) {
		echo "<TR><TD><BR></TD></TR>\n";
		echo "<TR><TD align=right><INPUT TYPE='submit' NAME='blacklists_delete' VALUE='" . $lang['blacklists']['button_delete'] . "' CLASS='inputTag_button inputTag'><BR></TD><TD COLSPAN=3></TD>" .
			"<TD align=right><INPUT TYPE='submit' NAME='blacklists_savechanges' VALUE='" . $lang['blacklists']['button_savechanges'] . "' CLASS='inputTag_button inputTag'></TD></TR>\n";
		echo "<TR><TD><BR></TD></TR>\n";
	}
	echo "<TR><TD CLASS='groups'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['subjectregex'] . " <INPUT TYPE='text' SIZE=20 NAME='subjectregex' VALUE='' CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['filenameregex'] . " <INPUT TYPE='text' SIZE=20 NAME='filenameregex' VALUE='' CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['subject'] . " <INPUT TYPE='text' SIZE=20 NAME='subject' VALUE='' CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'>" . $lang['blacklists']['filename'] . " <INPUT TYPE='text' SIZE=20 NAME='filename' VALUE='' CLASS='inputTag_input inputTag'></TD>\n" .
			"<TD CLASS='groups'><INPUT TYPE='submit' NAME='blacklists_addnew' VALUE='" . $lang['blacklists']['button_addnew'] . "' CLASS='inputTag_button inputTag'></TD>\n" .
			"</TR>\n";
	echo "</FORM></TABLE>\n";

?>