<?
class post_process {

	// externally set classes
	var $class_db;					// db class
	var $class_cache;				// cachefile class
	
	// static
	var $__POSTS_DELETE_TIME;
	var $__INCOMPLETES_IN_HEADERS;
	
	// externally set variables
	var $file_ext;					// allowable file extensions
	
	// post vars
	var $post_subject;				// post subject
		// subject is split into...
	var $post_subject_ripped;		// condensed version for later and quicker 'grouping' of posts
	var $post_est_filename;			// estimated filename
	var $post_est_filename_ext;		// estimated filename extension
	var $post_est_part;				// estimated part posted
	var $post_est_totalparts;		// estimated total parts
		//...
	var $post_poster;				// the poster
		// poster is split into...
	var $post_est_poster_email;		// estimated poster email
	var $post_est_poster_name;		// estimated poster name
		//...
	var $post_messageid;			// post messageid
	var $post_time;					// timestamp on last part posted
	var $post_parts;				// number of parts req. for complete post
	var $post_parts_found;			// number of parts found
	var $post_bytes;				// estimated number of bytes for each file
	var $post_server;				// server where post is located
	var $post_bad;					// if post_parts_found < post_parts then post_bad=1
	var $post_group;				// which group post is from
	
	var $post_lines;				// not saved, but used for estimating if yenc or uuencode compression
	
	// previous post (used to prevent an duplicate posting of the same incomplete file, according to the nget cache)
	var $prev_post_subject;
	var $prev_post_poster;
	var $prev_post_bad;

	
	function post_process(&$cfg) {
		// init
		$this->__POSTS_DELETE_TIME = $cfg['POSTS_DELETE_TIME'];
		$this->__INCOMPLETES_IN_HEADERS = $cfg['INCOMPLETES_IN_HEADERS'];
		$this->reset_vars();
	}
	
	function reset_vars() {
		// set previous post info
		$this->prev_post_subject = $this->post_subject;
		$this->prev_post_poster = $this->post_poster;
		$this->prev_post_bad = $this->post_bad;
		
		// reset stats
		$this->post_subject = '';
		$this->post_subject_ripped = '';
		$this->post_est_filename = '';
		$this->post_est_filename_ext = '';
		$this->post_est_part = 0;
		$this->post_est_totalparts = 0;
		$this->post_poster = '';
		$this->post_est_poster_email = '';
		$this->post_est_poster_name = '';
		$this->post_messageid = '';
		$this->post_time = 0;
		$this->post_parts = 0;
		$this->post_parts_found = 0;
		$this->post_bytes = 0;
		$this->post_lines = 0;
		$this->post_server = 0;
		$this->post_bad = 0;
		$this->post_group = 0;
	}
	
	// process specific cache file
	function process_cache($group_name, $group_number) {

		// delete all filegroups that include files from this group
		$sql = 'DELETE FROM file_groups ' .
			'USING file_groups, posts ' .
			'WHERE posts.file_group = file_groups.file_group_ID AND posts.post_group = ' . $group_number;
		$this->class_db->write_db($sql);
		// delete all previous posts from posts table
		$sql = 'DELETE FROM posts WHERE post_group = ' . $group_number;
		$this->class_db->write_db($sql);
		
		// init cache file
		$this->class_cache->cache_file_init($group_name);
		
		if ($this->class_cache->is_cache_file_ready()) {
			// start processing until EOF
			do {
				// reset all post vars for processing new group
				$this->reset_vars();
				// set group number
				$this->post_group = $group_number;
	
				$line_file = $this->class_cache->read_next_line();
				// begin parsing
				if ((preg_match("/^\d+\t0\t/", $line_file)) && !preg_match("/^(\-\d+|0)\t/", $line_file)) {
					$tmpa = NULL;
					$tmpa = split("\t", $line_file);
					// supposed number of parts in post
					$this->post_parts = (int)$tmpa[0];
					// subject line
					$this->post_subject = $tmpa[2];
					// poster email/name
					$this->post_poster = $tmpa[3];
					// if the start of a new file 
					$line_posts = $this->class_cache->read_next_line();
					if (preg_match("/^<.*?>$/", $line_posts)) {
						//next line(s) are <email@address>
						do {
							$line_posts = $this->class_cache->read_next_line();
						} while (preg_match("/^<.*?>$/", $line_posts) && !$this->class_cache->cache_eof());
					}
					// if not starting with '.' then ignore file and continue on
					if (preg_match("/^\.$/", $line_posts) && !$this->class_cache->cache_eof()) {
						do {
							$line_posts = $this->class_cache->read_next_line();
							// first line - part#, time, messageid
							if (preg_match("/^\.$/", $line_posts)) {
								// if two dots in a row, then no more parts
								break;
							}
							$tmpa = NULL;
							$tmpa = split("\t", $line_posts);
							// keep time and messageid from first detected post
							if (!$this->post_messageid) {
								// what time file was posted
								$this->post_time = (int)$tmpa[1];
								// messageid for uniquely identifying post when downloading
								$this->post_messageid = $tmpa[2];
							}
							
							$line_posts = $this->class_cache->read_next_line();
							//second line - server#, serverid, bytes, lines
							$tmpa = NULL;
							$tmpa = split("\t", $line_posts);
							// add up the bytes
							$this->post_bytes += (int)$tmpa[2];
							// add up number of parts
							$this->post_parts_found++;
							// set server id
							$this->post_server = (int)$tmpa[0];
							// add to total # of lines
							$this->post_lines += (int)$tmpa[3];
							
							$line_posts = $this->class_cache->read_next_line();
							//third line - should be .\n
						} while (!$this->class_cache->cache_eof() && preg_match("/^\.$/", $line_posts));
					}
					
					// process everything ripped out of the cache
					$this->post_process_full();
					
					// 1. gets array of expecting values (table field names must match local variable names)
					// 2. parse though variable names and return values in same order
					// 3. send back to be written to the db
					if ($this->valid_post()) {
						// if this file isn't an incomplete duplicate of the previous post then continue
						if (($this->prev_post_subject != $this->post_subject) ||
							($this->prev_post_poster != $this->post_poster) ||
							($this->post_bad == 0)) {
								$this->class_db->table_write_array(($this->assoc_variables($this->class_db->table_insert_array('posts'))), 'posts');
							}
					}
				}
			} while (!$this->class_cache->cache_eof());
			// clear out the cache, free some mem
			$this->class_cache->clear_cache();
			// flush out remaining posts
			$this->class_db->table_write_array('flush', 'posts');
		}
		//update number of 'good posts' to groups table
		$this->update_good_posts($group_number);
	}
	
	function post_process_full() {
			$this->process_filename();
			$this->process_filename_ext();
			$this->process_est_parts();
			$this->process_time();
			$this->process_email_addr();
			$this->process_estimated_size();
			$this->process_subject_rip();
			$this->process_completeness_check();
			$this->process_set_date_added();
	}
	
	function process_filename() {
		// parse the est. filename out of the subject
		// check if the filename is encapsulated nicely eg. "filename.xxx" or the lesser used <filename.xxx>
		if (preg_match("/[\"\<][^\"\<]*?".$this->file_ext."[\"\>]/i", $this->post_subject)) {
			$this->post_est_filename = 
				preg_replace("/^.*[\"\<]([^\"\<]*".$this->file_ext.")[\"\>].*$/i", "$1", $this->post_subject);
		}
		// will not do anymore filename parsing, it is too sketchy to guess anything else
	}
	
	function process_filename_ext() {
		// parse the est. filename extension
		if ($this->post_est_filename) {
			$this->post_est_filename_ext = 
				strtolower(preg_replace("/^.*(".$this->file_ext.")$/i", "$1", $this->post_est_filename));
		} elseif (preg_match("/^.*\S{2,}".$this->file_ext."([ \)\"].*)?$/i", $this->post_subject)) {
			// only finding two letters before the file extension may be too little
			$this->post_est_filename_ext = 
				strtolower(preg_replace("/^.*\S{2,}(".$this->file_ext.")(?:[ \)\"\>].*)?$/i", "$1", $this->post_subject));
		} elseif (preg_match("/^.*[\w\d](\.mp3|\.m3u|\.ogg|\.wma)([ \)\"].*)?$/i", $this->post_subject)) {
			// allow lenience on mp3s and such
			//<<< experiment with this for a bit
			$this->post_est_filename_ext = 
				strtolower(preg_replace("/^.*[\w\d](\.mp3|\.m3u|\.ogg|\.wma)(?:[ \)\"\>].*)?$/i", "$1", $this->post_subject));
		}
	}
	
	function process_est_parts() {
		// parse the est. filepart / filepart for this file
		// [##/##] | File/Part 030 of 134 | 05 of 61 | .part34.rar | xxx.r58 | 
		if (preg_match("/[\[\s\<]\d+\/\d+[\]\s\>]/", $this->post_subject)) {
			$this->post_est_part = (int)preg_replace("/^.*[\[\s\<](\d+)\/\d+[\]\s\>].*$/", "$1", $this->post_subject);
			$this->post_est_totalparts = (int)preg_replace("/^.*[\[\s\<]\d+\/(\d+)[\]\s\>].*$/", "$1", $this->post_subject);
		} elseif (preg_match("/(file|part)\s?\d+\s?of\s?\d+/i", $this->post_subject)) {
			$this->post_est_part = (int)preg_replace("/^.*(?:file|part)\s?(\d+)\s?of\s?\d+.*$/i", "$1", $this->post_subject);
			$this->post_est_totalparts = (int)preg_replace("/^.*(?:file|part)\s?\d+\s?of\s?(\d+).*$/i", "$1", $this->post_subject);
		} elseif (preg_match("/\d+\s?of\s?\d+/i", $this->post_subject)) {
			$this->post_est_part = (int)preg_replace("/^.*(\d+)\s?of\s?\d+.*$/i", "$1", $this->post_subject);
			$this->post_est_totalparts = (int)preg_replace("/^.*\d+\s?of\s?(\d+).*$/i", "$1", $this->post_subject);
		} elseif (preg_match("/\.part\d+\.rar/i", $this->post_subject)) {
			$this->post_est_part = (int)preg_replace("/^.*\.part(\d+)\.rar.*$/i", "$1", $this->post_subject);
		} elseif (preg_match("/\S{5,}\.r\d{2,3}/i", $this->post_subject)) {
			$this->post_est_part = (int)preg_replace("/^.*\S{5,}\.r(\d{2,3}).*$/i", "$1", $this->post_subject);
		}
	}
		
	function process_time() {
		// change time to mysql usuable format
		$tmpa = localtime($this->post_time);
		//("Y-m-d H:i:s")
		$this->post_time = ($tmpa[5]+1900).'-'.($tmpa[4]+1).'-'.$tmpa[3].' '.$tmpa[2].':'.$tmpa[1].':'.$tmpa[0];
	}
	
	function process_email_addr() {
		// rip out fake email address & make the (name) thing too
		$this->post_est_poster_email = preg_replace("/^\s*(.*?)\s*\(.*\)$/", "$1", $this->post_poster);
		$this->post_est_poster_name = preg_replace("/^.*[\(<](.*?)[\)>].*$/", "$1", $this->post_poster);
	}
	
	function process_estimated_size() {
		// yenc is approx 3-4%, uuencode is 30-40% (www.yenc.org)
		if ($this->post_lines > 0) {
			if (preg_match("/yenc/i", $this->post_subject) || (($this->post_bytes / $this->post_lines) > 100)) {
				// yenc in the subject || yenc lines are traditionally over 100 bytes
				$this->post_bytes = round($this->post_bytes / 1.035);
			} else {
				// default to uuencoded
				$this->post_bytes = round($this->post_bytes / 1.35);
			}
		}
	}
	
	function process_subject_rip() {
		// make subject_ripped, which should have all the junk ripped out for easier sorting and grouping
		$this->post_subject_ripped = $this->post_subject;
		// remove - yenc
		$this->post_subject_ripped = preg_replace("/yenc/i", "", $this->post_subject_ripped);
		// remove - [##/##] and (##/##)
		$this->post_subject_ripped = preg_replace("/[\[\(\{]\s*\d+\s*\/\s*\d+\s*[\]\)\}]/i", "", $this->post_subject_ripped);
		// remove - file ## of ## and file #/# and ##/##
		$this->post_subject_ripped = preg_replace("/(file|files|part|disk|disks|day)?\s*\d+\s*(of|0f|af)\s*\d+/i", "", $this->post_subject_ripped);
		$this->post_subject_ripped = preg_replace("/(file|files|part|disk|disks|day)\s*\d+\s*\/\s*\d+/i", "", $this->post_subject_ripped);
		$this->post_subject_ripped = preg_replace("/(^|\s+)\d+\s*\/\s*\d+(\s+|$)/i", " ", $this->post_subject_ripped);
		// remove parts - (*/##)
		$this->post_subject_ripped = preg_replace("/\(\*\/\d+\)/", "", $this->post_subject_ripped);
		// remove size - 1000000 bytes
		$this->post_subject_ripped = preg_replace("/\d+(\.\d+)?\s*(bytes|mbytes|kb|megs|meg)/i", "", $this->post_subject_ripped);
		$this->post_subject_ripped = preg_replace("/\d\d0{6,7}/i", "", $this->post_subject_ripped);
		$this->post_subject_ripped = preg_replace("/\s+\d+\s*(b|k)$/i", "", $this->post_subject_ripped);
		// remove useless crc-thing
		$this->post_subject_ripped = preg_replace("/ [a-f\d]{8}\s*$/", "", $this->post_subject_ripped);
		// remove ALL useless sizes from end of subject
		$this->post_subject_ripped = preg_replace("/ -?\d{3,}$/i", "", $this->post_subject_ripped);
		
		// KEEP THIS LAST AND IN THIS ORDER
		// remove " - "
		$this->post_subject_ripped = preg_replace("/ - /", " ", $this->post_subject_ripped);
		// remove useless chars (traditionally non-filename)
		//<<< " removed
		$this->post_subject_ripped = preg_replace("/[\*\<\>!@#\$%^`~\']/", "", $this->post_subject_ripped);
		// remove multiple spaces
		$this->post_subject_ripped = preg_replace("/\s+/", " ", $this->post_subject_ripped);
		// remove leading/trailing spaces and other junk off end
		//<<< " removed
		$this->post_subject_ripped = preg_replace("/^\s*(.*?)(?:\s+[-\[\]\']*)?\s*$/", "$1", $this->post_subject_ripped);
	}
	
	function process_completeness_check() {
		// est. if file is good or bad
		if ($this->post_parts_found < $this->post_parts) {
			$this->post_bad = 1;
		} else {
			$this->post_bad = 0;
		}
	}

	function process_set_date_added() {
		// timestamp of when this was added to db for caculating 'new posts'
		$this->post_date_added = date('Y-m-d H:i:s');
	}

	function valid_post() {
		// decides whether or not to write post to db
		// if valid filename extension or at least one part found...
		if ($this->post_est_filename_ext || ($this->post_parts_found > 0)) {
			// check if post meets date requirements
			if (strtotime($this->post_time) > (time() - ($this->__POSTS_DELETE_TIME * 60))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	function update_good_posts($group_number) {
		//update number of 'good posts' to groups table
		if ($this->__INCOMPLETES_IN_HEADERS) {
			$sql='SELECT COUNT(*) AS result ' .
				' FROM posts' .
				' WHERE post_group=' . $group_number;
		} else {
			$sql='SELECT COUNT(*) AS result ' .
				' FROM posts' .
				' WHERE post_bad=0 AND post_group=' . $group_number;
		}
		$this->class_db->query_db($sql);
		$row = $this->class_db->sql_results();
		$this->class_db->free_query();
		$sql = 'UPDATE groups' .
			' SET group_posts=' . $row['result'] . 
			' WHERE group_ID=' . $group_number;
		$this->class_db->write_db($sql);
	}
	
	//<<< needs a centralized locale
	// updating the db using local variables
	// (two/three step process)
	function assoc_variables($tmp) {
		$tmpa = array();
		foreach($tmp as $value) {
			array_push($tmpa, $this->{$value});
		}
		return $tmpa;
	}
	
}
?>