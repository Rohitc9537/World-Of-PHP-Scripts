<?
// used in both the backend and frontend

class groups_control {
	
	// externally set classes
	var $class_db;				// db class
	
	// vars
	var $groups_array;			// all info held in the db dumped into an assoc array (faster then probing db constantly)
	var $current_group;			// the current group being operated on ($groups_array index value)
	var $total_groups;			// total groups avaliable
	
	// special vars used in recursive functions
	var $group_type;			// used only for reference
	var $group_type_array;		// array of groups in topdown order designed for use in a select box
	
	
	
	function groups_control() {
		// init
		// cannot load immediately, needs the class_db set
	}
	
	function groups_control_init() {
		$this->repopulate_groups();
		$this->set_first_group();
	}
	
	// read sql and load into an assoc array
	function repopulate_groups() {
		/// make a chart of what this should look like
		$this->groups_array = array();
		$this->group_type = array();
		$this->group_type_array = array();
		$this->current_group = null;
		$this->total_groups = 0;

		// step 1 - groups
		$sql = 'SELECT * FROM groups' .
			' LEFT JOIN group_type ON groups.group_type = group_type.group_type_ID' .
			' ORDER BY group_name ASC';
		$this->class_db->query_db($sql);
		while ($row = $this->class_db->sql_results()) {
			foreach($row as $key => $value) {
				// only use string values, not int
				if (is_string($key)) { $this->groups_array[(int)$row['group_ID']][$key] = $value; }
			}
			$this->total_groups++;
		}
		$this->class_db->free_query();
		
		// step 2 - group_type
		//<<< assoc functions (is_subset_of_grouptype(), get_array_of_grouptypes())
		$sql = 'SELECT * FROM group_type ORDER BY group_type_name ASC';
		$this->class_db->query_db($sql);
		while ($row = $this->class_db->sql_results()) {
			array_push($this->group_type, 
				array('id' => (int)$row['group_type_ID'],
					'parentid' => (int)$row['group_type_parent_ID'],
					'method' => (int)$row['group_type_method'],
					'name' => $row['group_type_name']));
		}
		$this->class_db->free_query();
		// called when needed
		//$this->set_group_type_tree_array(1, 1);
	}

	// Rescusive function for creating tree-order array
	function set_group_type_tree_array($seed, $depth) {
		// dump this value at end of array
		for ($i=0; $i <= (count($this->group_type)-1); $i++) {
			if ($this->group_type[$i]['id'] == $seed) {
				array_push($this->group_type_array, array(
					'groupid' => (int)$this->group_type[$i]['id'], 
					'groupname' => $this->group_type[$i]['name'],
					'groupmethod' => (int)$this->group_type[$i]['method'],
					'depth' => $depth));
			}
		}
		// scan array for value, then descend if found
		for ($i=0; $i <= (count($this->group_type)-1); $i++) {
			if ($this->group_type[$i]['parentid'] == $seed) {
				$this->set_group_type_tree_array($this->group_type[$i]['id'], ($depth + 1));
			}
		}
	}
	
	// returns the array
	function get_group_type_tree_array() {
		// caculate from root
		return $this->get_group_type_assoc_array(1);
	}
	
	// returns all subgroups from specified id
	function get_group_type_assoc_array($groupid) {
		$this->group_type_array = array();
		$this->set_group_type_tree_array($groupid, 1);
		return $this->group_type_array;
	}
	
	// Functions for dealing with groups in ascending order
	
	//return first group
	function set_first_group() {
		$tmp = array_keys($this->groups_array);
		$this->current_group = (int)$tmp[0];
	}
	
	// return the current group
	function get_current_group() {
		return $this->current_group;
	}

	// return the groups full name
	function get_current_group_name() {
		return $this->groups_array[$this->current_group]['group_name'];
	}
	
	// return the groups abbrevation
	function get_current_group_name_abv() {
		return $this->groups_array[$this->current_group]['group_abv'];
	}

	// return the groups full name
	function get_current_group_type() {
		return $this->groups_array[$this->current_group]['group_type'];
	}
	
	// move to the next active group, return null if done
	function get_next_group() {
		reset($this->groups_array);
		while ($tmp = key($this->groups_array)) {
			if ($tmp == $this->current_group) {
				$tmp = next($this->groups_array);
				$this->current_group = (int)$tmp['group_ID'];
			}
			next($this->groups_array);
		}
	return $this->current_group;
	}

	function is_group_active() {
		if ($this->groups_array[$this->current_group]['group_active'] == 1) {
			return true;
		} else {
			return false;
		}
	}

	function is_group_active_onetime() {
		if ($this->groups_array[$this->current_group]['group_active_onetime'] == 1) {
			return true;
		} else {
			return false;
		}
	}

	// Functions for dealing with specific groups
	
	// get name of group
	function get_specific_group_name($groupid) {
		return $this->groups_array[$groupid]['group_name'];
	}

	// get abbrevation of group
	function get_specific_group_name_abv($groupid) {
		return $this->groups_array[$groupid]['group_abv'];
	}
	
	// get posts in groups
	function get_specific_group_posts($groupid) {
		return $this->groups_array[$groupid]['group_posts'];
	}
	
	// get group type
	function get_specific_group_type($groupid) {
		return $this->groups_array[$groupid]['group_type'];
	}

	// get group method
	function get_specific_group_method($groupid) {
		return $this->groups_array[$groupid]['group_type_method'];
	}

	// return total number of groups
	function get_total_groups() {
		return $this->total_groups;
	}
	
}
?>