<?
class db_control {

	// static
	var $__DBHOST;			// address
	var $__DBNAME;			// database name
	var $__DBUSER;			// db username
	var $__DBPASS;			// db password
	var $__DBMULTI;			// how many multiple inserts to perform at once (less db pounding / faster)
	
	// db vars
	var $dblink;
	var $dbselect;
	var $dbquery;
	var $dbquery2;
	var $dbwrite;
	
	// db 'queuing' for multiple inserts
	var $dbmultiple;
	var $dbmultiple_num;
	
	// table variables
	var $table_posts_fields;
	var $table_groups_fields;
	var $table_group_type_fields;
	var $table_file_groups_fields;
	
	function db_control(&$cfg) {
		// init	
		// set all internal variables
		$this->__DBHOST = $cfg['DBHOST'];
		$this->__DBNAME = $cfg['DBNAME'];
		$this->__DBUSER = $cfg['DBUSER'];
		$this->__DBPASS = $cfg['DBPASS'];
		$this->__DBMULTI = $cfg['DBMULTI'];

		$this->dblink = mysql_connect($this->__DBHOST, $this->__DBUSER, $this->__DBPASS)
			or die('Could not connect');
		$this->dbselect = mysql_select_db($this->__DBNAME)
			or die('Could not select database');
		
		$this->dbmultiple_num = 0;
			
		// setup table fields (0=normal, 1=unique/autoincrement/timestamp(read, no write))
		$this->table_posts_fields = array(
			'post_ID' => 1,
			'post_subject' => 0,
			'post_subject_ripped' => 0,
			'post_est_filename' => 0,
			'post_est_filename_ext' => 0,
			'post_est_part' => 0,
			'post_est_totalparts' => 0,
			'post_poster' => 0,
			'post_est_poster_email' => 0,
			'post_est_poster_name' => 0,
			'post_messageid' => 0,
			'post_time' => 0,
			'post_parts' => 0,
			'post_parts_found' => 0,
			'post_bytes' => 0,
			'post_server' => 0,
			'post_bad' => 0,
			'post_date_added' => 0,
			'file_group' => 1,
			'post_group' => 0 );
		
		$this->table_file_groups_fields = array(
			'file_group_ID' => 1,
			'file_post_first' => 0,
			'file_number_par' => 0,
			'file_blocks_par2' => 0,
			'file_total_size' => 0,
			'file_post_nfo_ID' => 0,
			'file_complete' => 0,
			'file_parts' => 0,
			'file_parts_total' => 0,
			'file_post_first_ID' => 0,
			'file_post_sample_ID' => 0,
			'file_post_par_ID' => 0,
			'file_post_par2_ID' => 0,
			'file_post_sfv_ID' => 0, 
			'file_zips' => 0, 
			'file_zips_total' => 0, 
			'file_date_newest' => 0, 
			'file_date_oldest' => 0	);
		
		$this->table_file_crossposts_fields = array(
			'file_crossposts_ID' => 1,
			'post_ID_1' => 0,
			'post_ID_2' => 0,
			'post_ID_3' => 0,
			'post_ID_4' => 0,
			'post_ID_5' => 0,
			'post_ID_6' => 0,
			'post_ID_7' => 0,
			'post_ID_8' => 0,
			'post_ID_9' => 0,
			'post_ID_10' => 0 );
			
		$this->table_file_crossposts_group_fields = array(
			'file_crossposts_group_ID' => 1,
			'file_group_ID_1' => 0,
			'file_group_ID_2' => 0,
			'file_group_ID_3' => 0,
			'file_group_ID_4' => 0,
			'file_group_ID_5' => 0,
			'file_group_ID_6' => 0,
			'file_group_ID_7' => 0,
			'file_group_ID_8' => 0,
			'file_group_ID_9' => 0,
			'file_group_ID_10' => 0 );
			
		$this->table_download_fields = array(
			'download_ID' => 1,
			'download_date' => 1,
			'download_custom_position' => 0,
			'download_post_ID' => 0,
			'download_file_group_ID' => 0,
			'download_status' => 0,
			'download_wishlist_ID' => 0,
			'download_messageid' => 0,
			'download_filename' => 0,
			'download_group' => 0,
			'download_size' => 0,
			'download_subject' => 0,
			'download_post_time' => 0,
			'download_retry' => 0 );

	}

	// return array of insert-able values. expecting internal variables will match
	// (one/three step process)
	function table_insert_array($table_name) {
		$tmp = 'table_' . $table_name . '_fields';
		if (isset($this->{$tmp})) {
			// if var exists
			$tmpa = array();
			foreach($this->{$tmp} as $key => $value) {
				if ($value == 0) {
					array_push($tmpa, $key);
				}
			}
			return $tmpa;
		} else {
			// else typo and return nothing
			return false;
		}
	}
	
	// return array of select-able values.
	function table_select_array($table_name) {
		$tmp = 'table_' . $table_name . '_fields';
		if (isset($this->{$tmp})) {
			// if var exists
			$tmpa = array();
			foreach($this->{$tmp} as $key => $value) {
				array_push($tmpa, $key);
			}
			return $tmpa;
		} else {
			// else typo and return nothing
			return false;
		}
	}

	// write array base on table passed
	// (three/three step process)
	function table_write_array($write_array, $table_name) {
		$tmp = 'table_' . $table_name . '_fields';
		if (isset($this->{$tmp})) {
			// if var exists
			if ($write_array == 'flush') {
				// flush out remaining posts
				$this->dbmultiple_num = $this->__DBMULTI;
				$sql2 = '';
			} else {
				$sql2 = '(';
				foreach($write_array as $value) {
					$sql2 .=  '"' . $this->sql_friendly($value) . '", ';
				}
				$sql2 = preg_replace("/^(.*?), $/", "$1", $sql2);
				$sql2 .= '),';
				$this->dbmultiple_num++;
			}
			if ($this->dbmultiple_num == $this->__DBMULTI) {
				$sql = 'INSERT INTO ' . $table_name . ' (';
				foreach($this->{$tmp} as $key => $value) {
					if ($value == 0) {
						$sql .= "$key, ";
					}
				}
				$sql = preg_replace("/^(.*?), $/", "$1", $sql);
				$sql .= ') VALUES ';
				$sql .= $this->dbmultiple . $sql2;
				$sql = preg_replace("/^(.*?),$/", "$1", $sql);
				// check in case of rare chance nothing pending when flushed
				if ($this->dbmultiple || $sql2) {
					$this->write_db($sql);
				}
				$this->dbmultiple_num = 0;
				$this->dbmultiple = '';
			} else {
				// add on the end of multiple insert
				$this->dbmultiple .= $sql2;
			}
		}
	}
	
	// update posts table to flag files already used
	function table_update_posts($files_used_array, $post_group) {
		// UPDATE posts SET file_group=### WHERE post_ID=## AND post_ID=## etc...
		$sql = 'UPDATE posts SET file_group=' . $post_group . ' WHERE ';
		while ($tmp = array_pop($files_used_array)) {
			$sql .= 'post_ID=' . $tmp . ' OR ';
		}
		$sql = preg_replace("/^(.*?) OR $/i", "$1", $sql);
		$this->write_db($sql);
		//echo $sql . '<BR>';
	}
	
	// used for query statements (select)
	function query_db($sql) {
		// keep this here incase something can be optimized/fixed
		$this->dbquery = mysql_query($sql)
			or die("Cannot query the database.<br>SQL:$sql" . mysql_error());
		//echo $sql . "<BR>";
	}

	// used for query statements (select)
	function query_db2($sql) {
		// keep this here incase something can be optimized/fixed
		$this->dbquery2 = mysql_query($sql)
			or die("Cannot query the database.<br>SQL:$sql" . mysql_error());
		//echo $sql . '<BR>';
	}
	
	// make text inserts 'db friendly'
	function sql_friendly($text) {
		//return preg_replace("/([\\\\|'|\"])/", "\\\\$1", $text);
		return preg_replace("/([\\\\|\"])/", "\\\\$1", $text);
	}
	
	// make text inserts 'db friendly' from posts
	function sql_friendly_post($text) {
		//return preg_replace("/([\\\\|'])/", "\\\\$1", stripslashes($text));
		return preg_replace("/([\\\\|\"])/", "\\\\$1", stripslashes($text));
	}
	
	// used for writing to db (insert/update/delete)
	function write_db($sql) {
		//<<< add microtime here
		$this->dbwrite = mysql_query($sql)
			or die("Cannot query the database.<br>SQL:$sql" . mysql_error());
		//echo $sql . '<BR>';
	}
	
	// return sql results
	function sql_results() {
		return mysql_fetch_array($this->dbquery);
	}
	
	// return sql results
	function sql_results2() {
		return mysql_fetch_array($this->dbquery2);
	}
	
	// optimize table
	function optimize_table($table) {
		$this->query_db('OPTIMIZE TABLE ' . $table);
	}
	
	// free up some mem
	function free_query() {
		mysql_free_result($this->dbquery);
	}
	
	// free up some mem
	function free_query2() {
		mysql_free_result($this->dbquery2);
	}
	
	// set status in nget_backbone table for telling gui to stop and wait for the headers to finish
	function set_currently_updating($bool) {
		if ($bool) {
			$sql = 'UPDATE nget_backbone SET currently_updating = 1';
		} else {
			$sql = 'UPDATE nget_backbone SET currently_updating = 0';
		}
		$this->write_db($sql);
	}
	
	// set what the backend is currently doing in nget_backbone table
	function set_current_status($status) {
		$this->event_logging($status, 0, 0);
		$status = $this->sql_friendly($status);
		$sql = 'UPDATE nget_backbone SET current_status = "' . $status . '"';
		$this->write_db($sql);
	}
	
	// add all info to logs
	function event_logging($message, $warning, $error) {
		$message = $this->sql_friendly($message);
		$sql = 'INSERT INTO logs (message, warning, error) VALUES ("'. $message . '", ' . $warning . ', ' . $error . ')';
		$this->write_db($sql);
	}
	
}
?>