<?
class xpost_process {

	// externally set classes
	var $class_db;			// db class
	
	// static
	//var $__SQL_BATCH;
	var $__LANG;			// language translations
	
	// match field names in file_crossposts table
	var $post_ID_1;
	var $post_ID_2;
	var $post_ID_3;
	var $post_ID_4;
	var $post_ID_5;
	var $post_ID_6;
	var $post_ID_7;
	var $post_ID_8;
	var $post_ID_9;
	var $post_ID_10;
	
	// match field names in file_crossposts_group table
	var $file_group_ID_1;
	var $file_group_ID_2;
	var $file_group_ID_3;
	var $file_group_ID_4;
	var $file_group_ID_5;
	var $file_group_ID_6;
	var $file_group_ID_7;
	var $file_group_ID_8;
	var $file_group_ID_9;
	var $file_group_ID_10;
	
	function xpost_process(&$cfg) {
		// init
		$this->reset_vars();
		//$this->__SQL_BATCH = $cfg['SQL_BATCH'];
		$this->__LANG = $cfg['lang'];
	}
	
	function reset_vars() {
		for ($i=1; $i<=10; $i++) {
			$this->{'post_ID_' . $i} = 0;
			$this->{'file_group_ID_' . $i} = 0;
		}
	}
	
	// detect crossposting at the file level
	function detect_xpost_files() {
		// reset everything
		$this->reset_vars();
		
		// clear table
		$sql = 'TRUNCATE file_crossposts';
		$this->class_db->write_db($sql);
		
		// array to hold up to ten crossposts of one file
		$post_array = array();
		// true/false if new xpost is detected
		$xpost = false;
		///$sqlinc = 0;
		///do {
			$sql = 'SELECT post_subject, post_poster, post_group, post_ID'.
				' FROM posts' .
				' ORDER BY post_poster ASC, post_subject ASC, post_group ASC';
				///' LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
			$this->class_db->query_db($sql);
			// previous result to compare against
			///if (!$prevpost) {
				$prevpost = $this->class_db->sql_results();
			///}
			while ($post = $this->class_db->sql_results()) {
				if (($post['post_subject'] == $prevpost['post_subject']) &&
					($post['post_poster'] == $prevpost['post_poster']) &&
					($post['post_group'] !== $prevpost['post_group'])) {
						if (!$xpost) {
							$xpost = true;
							array_push($post_array, $prevpost['post_ID']);
						}
						array_push($post_array, $post['post_ID']);
				} elseif ($xpost) {
					$xpost = false;
					$this->xpost_write_db($post_array, 'file_crossposts', 'post_ID_');
					$this->xpost_update_posts('file_crossposts_ID', 'file_crossposts', 'post_ID_1', 'posts', 'post_xpost', 'post_ID');
					$post_array = array();
					$this->reset_vars();
				}
				$prevpost = $post;
			}
		///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
		
		// have to account for if the records end and a match has already started
		if ($xpost) {
			$this->xpost_write_db($post_array, 'file_crossposts', 'post_ID_');
			$this->xpost_update_posts('file_crossposts_ID', 'file_crossposts', 'post_ID_1', 'posts', 'post_xpost', 'post_ID');
		}
	}
	
	// detect crossposting at the file groups level
	function detect_xpost_filegroups() {
		// reset everything
		$this->reset_vars();
		$sql = 'TRUNCATE file_crossposts_group';
		$this->class_db->write_db($sql);
		// array to hold up to ten crossposts of one file
		$post_array = array();
		// true/false if new xpost is detected
		$xpost = false;
		
		$sql = 'SELECT file_post_first, file_group_ID'.
			' FROM file_groups' .
			' ORDER BY file_post_first ASC';
		$this->class_db->query_db($sql);
		// previous result to compare against
		$prevpost = $this->class_db->sql_results();
		
		while ($post = $this->class_db->sql_results()) {
			if ($post['file_post_first'] == $prevpost['file_post_first']) {
					if (!$xpost) {
						$xpost = true;
						array_push($post_array, $prevpost['file_group_ID']);
					}
					array_push($post_array, $post['file_group_ID']);
			} elseif ($xpost) {
				$xpost = false;
				$this->xpost_write_db($post_array, 'file_crossposts_group', 'file_group_ID_');
				$this->xpost_update_posts('file_crossposts_group_ID', 'file_crossposts_group', 'file_group_ID_1', 'file_groups', 'file_xpost', 'file_group_ID');
				$post_array = array();
				$this->reset_vars();
			}
			$prevpost = $post;
		}
		
		// have to account for if the records end and a match has already started
		if ($xpost) {
			$this->xpost_write_db($post_array, 'file_crossposts_group', 'file_group_ID_');
			$this->xpost_update_posts('file_crossposts_group_ID', 'file_crossposts_group', 'file_group_ID_1', 'file_groups', 'file_xpost', 'file_group_ID');
		}
	}
	
	// write to db
	function xpost_write_db($post_array, $table, $prefix) {
		
		for ($i=1; $i<=10; $i++) {
			if (count($post_array) !== 0) {
				$tmp = array_pop($post_array);
				$this->{$prefix . $i} = $tmp;
			}
		}
		$this->class_db->table_write_array(($this->assoc_variables($this->class_db->table_insert_array($table))), $table);
		// flush out
		$this->class_db->table_write_array('flush', $table);
	}

	// update posts to reflect crossposting reference
	function xpost_update_posts($sel_field, $sel_table, $sel_from, $upd_table, $upd_field, $upd_where) {
		
		$sql = 'SELECT ' . $sel_field . ' FROM ' . $sel_table . ' WHERE ' . $sel_from . '=' . $this->{$sel_from};
		$this->class_db->query_db2($sql);
		$row = $this->class_db->sql_results2();
		$tmp = $row[$sel_field];
		$this->class_db->free_query2();
		$sql = 'UPDATE ' . $upd_table . ' SET ' . $upd_field . '=' . $tmp . ' WHERE ';
		for ($i=1; $i<=10; $i++) {
			if ($this->{$upd_where . '_' . $i} !== 0) {
				$sql .= $upd_where . '=' . $this->{$upd_where . '_' . $i} . ' OR ';
			}
		}
		$sql = preg_replace("/^(.*) OR $/", "$1", $sql);
		$this->class_db->write_db($sql);
	}
	
/* ---------------------------------------------------------------------------
	Remove bad post floods.
   ------------------------------------------------------------------------ */
	
   function delete_bad_floods($group) {
		// prepare
		$poster = null;
		$bad_posts = 0;
		$good_posts = 0;
		$delete = array();
	
	   	///$sqlinc = 0;
		///do {
			$sql = 'SELECT * FROM posts' .
				' WHERE post_group = ' . $group . 
				' ORDER BY post_est_poster_email, post_time';
				///' LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
			$this->class_db->query_db($sql);
			while ($row = $this->class_db->sql_results()) {
				if ($row['post_est_poster_email'] != $poster) {
					if ((($bad_posts >= 25) && ($good_posts == 0)) || (($bad_posts >= 50) && ($good_posts <= 2))) {
						array_push($delete, $poster);
					}
					// reset
					$poster = $row['post_est_poster_email'];
					$bad_posts = 0;
					$good_posts = 0;
				} else {
					if ((int)$row['post_bad'] == 0) {
						$good_posts++;
					} else {
						$bad_posts++;
					}
				}
			}
		///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
		// check final post
		if ((($bad_posts >= 25) && ($good_posts == 0)) || (($bad_posts >= 50) && ($good_posts <= 2))) {
			array_push($delete, $poster);
		}
		if (count($delete) > 0) {
			$sql = 'DELETE FROM posts WHERE post_group=' . $group . ' AND (';
			while (count($delete) > 0) {
				$sql .= ' post_est_poster_email="' . $this->class_db->sql_friendly(array_pop($delete)) . '" OR';
			}
			$sql = preg_replace("/(.*) OR$/", "$1)", $sql);
			$this->class_db->write_db($sql);
			$this->class_db->event_logging($this->__LANG['xpost']['removedjunkfloods'] . ', ' . mysql_affected_rows() . ' ' . $this->__LANG['xpost']['posts'], 0, 0);
		}
	}
	
/* ---------------------------------------------------------------------------
	Process blacklists.
   ------------------------------------------------------------------------ */

	function update_blacklists() {
		// clear previous blacklisted files
		$sql = 'UPDATE posts SET post_blacklisted = 0 WHERE post_blacklisted = 1';
		$this->class_db->write_db($sql);
		
		// array for SQL-only blacklisting
		$array_sql_only = array();
		$array_sql_filename_only = array();
		// array for regex blacklisting
		$array_sql_filename_regex = array();
		$array_sql_regex = array();
		// array of post ids to update
		$array_post_ids = array();
		
		$sql = 'SELECT * FROM blacklist ORDER BY blacklist_ID';
		$this->class_db->query_db($sql);
		while ($row = $this->class_db->sql_results()) {
			if ($row['blacklist_sql']) {
				array_push($array_sql_only, $row['blacklist_sql']);
			} elseif ($row['blacklist_filename_sql']) {
				array_push($array_sql_filename_only, $row['blacklist_filename_sql']);
			} elseif ($row['blacklist_regex']) {
				array_push($array_sql_regex, $row['blacklist_regex']);
			} elseif ($row['blacklist_filename_regex']) {
				array_push($array_sql_filename_regex, $row['blacklist_filename_regex']); 
			}
		}
		$this->class_db->free_query();
		
		// first do the sql-only searches
		if (count($array_sql_only) > 0) {
			$sql = 'UPDATE posts SET post_blacklisted = 1 WHERE';
			while ($tmp = array_pop($array_sql_only)) {
				$sql .= ' post_subject LIKE "%' . $this->class_db->sql_friendly($tmp) . '%" OR';
			}
			$sql = preg_replace("/(.*?) OR$/", "$1", $sql);
			$this->class_db->write_db($sql);
		}
		if (count($array_sql_filename_only) > 0) {
			$sql = 'UPDATE posts SET post_blacklisted = 1 WHERE';
			while ($tmp = array_pop($array_sql_filename_only)) {
				$sql .= ' post_est_filename LIKE "%' . $this->class_db->sql_friendly($tmp) . '%" OR';
			}
			$sql = preg_replace("/(.*?) OR$/", "$1", $sql);
			$this->class_db->write_db($sql);
		}
		
		// do regex searches
		if ((count($array_sql_filename_regex) > 0) || (count($array_sql_regex) > 0)) {
			///$sqlinc = 0;
			///do {
				$sql = 'SELECT post_ID, post_subject, post_est_filename FROM posts ';
					///' LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$this->class_db->query_db($sql);
				while ($row = $this->class_db->sql_results()) {
					$tmp = false;
					
					$i = 0;
					while ($array_sql_filename_regex[$i]) {
						if (preg_match($array_sql_filename_regex[$i++], $row['post_est_filename'])) {
							$tmp = true;
						}
					}
					
					$i = 0;
					while ($array_sql_regex[$i]) {
						if (preg_match($array_sql_regex[$i++], $row['post_subject'])) {
							$tmp = true;
						}
					}
					
					if ($tmp == true) {
						array_push($array_post_ids, $row['post_ID']);
					}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			
			$this->class_db->free_query();
			if (count($array_post_ids) > 0) {
				$sql = 'UPDATE posts SET post_blacklisted = 1 WHERE ';
				while ($tmp = array_pop($array_post_ids)) {
					$sql .= ' post_ID = ' . $tmp . ' OR';
				}
				$sql = preg_replace("/(.*?) OR$/", "$1", $sql);
				$this->class_db->write_db($sql);
			}
		}
	}

/* ---------------------------------------------------------------------------
	Process downloads.
   ------------------------------------------------------------------------ */

	function update_downloads() {
		// clear previous downloads
		$sql = 'UPDATE posts SET post_downloaded = 0 WHERE post_downloaded = 1';
		$this->class_db->write_db($sql);
		
		$sql = 'SELECT post_ID FROM posts, download WHERE download.download_messageid = posts.post_messageid';
		$this->class_db->query_db($sql);
		while ($row = $this->class_db->sql_results()) {
			if ((int)$row['post_xpost'] > 0) {
			// if crossposted
				$sql = 'SELECT * FROM file_crossposts WHERE file_crossposts_ID = ' . $row['post_xpost'];
				$this->class_db->query_db2($sql);
				$row2 = $this->class_db->sql_results2();
				$this->class_db->free_query2();
				$sql = 'UPDATE posts SET post_download = 1 WHERE ';
				for ($i=1; $i <= 10; $i++) {
					if ((int)$row2['post_ID_' . $i] > 0) {
						$sql .= 'post_ID = ' . $row2['post_ID_' . $i] . ', ';
					}
				}
				$sql = preg_replace("/^(.*?), $/", "$1", $sql);
			} else {
			// not crossposted
				$sql = 'UPDATE posts SET post_downloaded = 1 WHERE post_ID = ' . $row['post_ID'];
			}
			$this->class_db->write_db($sql);
		}
		$this->class_db->free_query();
	}

	
	//<<< needs a centralized locale
	// updating the db using local variables
	// (two/three step process)
	function assoc_variables($tmp) {
		$tmpa = array();
		foreach($tmp as $value) {
			array_push($tmpa, $this->{$value});
		}
		return $tmpa;
	}
	
}