<?
class group_process {
	
	// externally set classes
	var $class_db;			// db class
	
	// externally set variables
	var $file_ext_video;	// video file extensions
	
	// static
	var $__INCOMPLETES_IN_SIZE;
	///var $__SQL_BATCH;
	
	// post specific
	var $previous_row;		// holds the previous row returned by db, for comparing to current row
	var $current_row;		// current row retrieved
	var $previous_post;		// holds useful info on the previous post
	var $current_post;		// holds useful info on the current post
	
	// local running info
	var $found_rars;		// single-dim. array of which rars found (null=empty, 1=found)
							// note: rar=0, r00=1, r01=2, etc...
	var $found_pars;		// single-dim. array of which pars found (null=empty, 1=found)
							// note: p00=0, p01=1, p02=2, etc...
	var $found_zips;		// single-dim. array of which zips found (null=empty, 1=found)
							// note: either by number of by single letter
	var $found_files;		// list of files used in 'group'
	var $found_par2s;		// how many par2 found
	var $found_par2_blks;	// how many 'blocks' of a par2 file found
	var $found_sample;		// if a 'sample' file (usually video related) is found, row dumped in here
	var $found_nfo;			// if an nfo is found, row dumped in here
	var $found_sfv;			// '' sfv
	var $found_par;			// '' par
	var $found_par2;		// '' par2
	var $found_mp3s;		// number of mp3s found
	var $found_first;		// the earliest post is dumped here, incase no nfo for title name
	var $found_size;		// total size for all files
	var $found_date_newest;	// newest date for posted file
	var $found_date_oldest;	// oldest date for posted file
	var $found_bad_posts;	// count how many bad posts found
	var $group_ready;		// true/false for group ready to write to db
	
	// match field names in file_groups table
	var $file_post_first;
	var $file_post_first_ID;
	var $file_post_nfo_ID;
	var $file_post_sample_ID;
	var $file_post_par_ID;
	var $file_post_par2_ID;
	var $file_post_sfv_ID;
	var $file_number_par;
	var $file_blocks_par2;
	var $file_total_size;
	var $file_parts;
	var $file_parts_total;
	var $file_zips;
	var $file_zips_total;
	var $file_complete;
	var $file_date_newest;
	var $file_date_oldest;
		//...
	var $post_file_group;	// array for updating posts group with which files are used

	function group_process(&$cfg) {
		//init
		$this->reset_vars();
		$this->__INCOMPLETES_IN_SIZE = $cfg['INCOMPLETES_IN_SIZE'];
		///$this->__SQL_BATCH = $cfg['SQL_BATCH'];
	}
	
	function reset_vars() {
		$this->previous_row = array();
		$this->current_row = array();
		$this->previous_post = array();
		$this->current_post = array();
		$this->found_files = array();
		$this->found_rars = array();
		$this->found_pars = array();
		$this->found_zips = array();
		$this->found_par2s = 0;
		$this->found_par2_blks = 0;
		$this->found_sample = array();
		$this->found_nfo = array();
		$this->found_sfv = array();
		$this->found_par = array();
		$this->found_par2 = array();
		$this->found_mp3s = 0;
		$this->found_first = array();
		$this->found_size = 0;
		$this->found_date_newest = '';
		$this->found_date_oldest = '';
		$this->found_bad_posts = array();
		$this->group_ready = false;
	}
	
	function rotate_vars() {
		// when moving to the next post
		$this->previous_row = $this->current_row;
		$this->previous_post = $this->current_post;
		$this->current_row = array();
		$this->current_post = array();
		$this->group_ready = false;
	}
	
	function rotate_vars_keep_previous() {
		// keep the previous post because the current one is similar but no good
		//$this->previous_row = $this->current_row;
		//$this->previous_post = $this->current_post;
		$this->current_row = array();
		$this->current_post = array();
		$this->group_ready = false;		
	}
	
	function rotate_new_vars() {
		// when a new post is located, prepare all vars
		$this->previous_row = $this->current_row;
		$this->previous_post = $this->current_post;
		$this->current_row = array();
		$this->current_post = array();
		$this->found_files = array();
		$this->found_rars = array();
		$this->found_pars = array();
		$this->found_zips = array();
		$this->found_par2s = 0;
		$this->found_par2_blks = 0;
		$this->found_sample = array();
		$this->found_nfo = array();
		$this->found_sfv = array();
		$this->found_par = array();
		$this->found_par2 = array();
		$this->found_mp3s = 0;
		$this->found_first = array();
		$this->found_size = 0;
		$this->found_date_newest = '';
		$this->found_date_oldest = '';
		$this->found_bad_posts = array();
		$this->group_ready = false;
	}
	
	function process_filegroups($group_number, $group_method) {
		
		//INSTEAD make it scan for mp3s ONLY first (ext=.mp3) and process that
		// then make it scan for the rest where the files are not part of a xpost-group...
		// + make mp3 scanning also join nfo/m3u/sfv
		
		if ($group_method == 2) {
			// STEP 0.1 - Process only mp3s
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_mp3_sql_one($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_mp3_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			
			$this->class_db->free_query();
			// process final file
			$this->method_mp3_process(null);
			if ($this->group_ready) {
				$this->update_post_groups();
			}
			
			// STEP 0.2 - Process only mp3s
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_mp3_sql_two($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_mp3_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
				// process final file
				$this->method_mp3_process(null);
				if ($this->group_ready) {
					$this->update_post_groups();
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			$this->class_db->free_query();
		}
		
		if (($group_method == 1) || ($group_method == 2)) {
			// STEP 1.1 - Filename oriented grouping (most precise method)
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_filename_sql_one($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_filename_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			$this->class_db->free_query();
			// process final file
			$this->method_filename_process(null);
			if ($this->group_ready) {
				$this->update_post_groups();
			}
			
			// STEP 1.2 - Filename oriented grouping (most precise method)
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_filename_sql_two($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_filename_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			$this->class_db->free_query();
			// process final file
			$this->method_filename_process(null);
			if ($this->group_ready) {
				$this->update_post_groups();
			}
			
			// STEP 2.1 - Subject oriented grouping (educated guessing), sort by poster
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_guess_sql_one($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_guess_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			$this->class_db->free_query();
			// process final file
			$this->method_guess_process(null);
			if ($this->group_ready) {
				$this->update_post_groups();
			}
			
			// STEP 2.2 - Subject oriented grouping (educated guessing), sort by subject
			$this->reset_vars();
			///$sqlinc = 0;
			///do {
				///$limit = 'LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
				$limit = '';
				$this->class_db->query_db($this->method_guess_sql_two($group_number, $limit));
				while ($row = $this->class_db->sql_results()) {
					$this->method_guess_process($row);
						if ($this->group_ready) {
							$this->update_post_groups();
						}
				}
			///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			$this->class_db->free_query();
			// process final file
			$this->method_guess_process(null);
			if ($this->group_ready) {
				$this->update_post_groups();
			}
		}
	}
	
	// update posts.post_group to reflect which files belong to which file_groups
	function update_post_groups() {
		//<<< this is somewhat hacky. oh well.
		// update file_groups
		$this->class_db->table_write_array(($this->assoc_variables($this->class_db->table_insert_array('file_groups'))), 'file_groups');
		$this->class_db->table_write_array('flush', 'file_groups');
		//$sql = "SELECT file_group_ID FROM file_groups WHERE file_post_first='".preg_replace("/'/", "\\'", $this->file_post_first)."' AND file_post_first_ID=".$this->file_post_first_ID;
		$sql = 'SELECT file_group_ID FROM file_groups WHERE file_post_first_ID='.$this->file_post_first_ID;
		$this->class_db->query_db2($sql);
		$row = $this->class_db->sql_results2();
		$tmp = $row['file_group_ID'];
		// free up mem
		$this->class_db->free_query2();
		// update post_group
		$this->class_db->table_update_posts($this->post_file_group, $tmp);
	}
	
/* ---------------------------------------------------------------------------
	process mp3s
   ------------------------------------------------------------------------ */

	function method_mp3_sql_one($group_number, $limit) {
   		return 'SELECT * FROM posts' .
			' WHERE file_group = 0 AND post_group = ' . $group_number . ' AND' .
			" (post_est_filename_ext = '.mp3' OR post_est_filename_ext = '.nfo' OR post_est_filename_ext = '.m3u' OR post_est_filename_ext = '.sfv' OR post_est_filename_ext = '.ogg' OR post_est_filename_ext = '.jpg')" .
			' ORDER BY post_est_poster_email ASC, post_est_filename ASC, posts.post_time ASC ' . $limit;
	}
   	
	function method_mp3_sql_two($group_number, $limit) {
		return 'SELECT * FROM posts' .
			' WHERE file_group = 0 AND post_group = ' . $group_number . ' AND' .
			" (post_est_filename_ext = '.mp3' OR post_est_filename_ext = '.nfo' OR post_est_filename_ext = '.m3u' OR post_est_filename_ext = '.sfv' OR post_est_filename_ext = '.ogg' OR post_est_filename_ext = '.jpg')" .
			' ORDER BY post_subject_ripped ASC, post_est_filename ASC, posts.post_time ASC ' . $limit;
	}
   
   
	function method_mp3_process($row) {
		// new row
		$this->current_row = $row;
		$this->current_post = array();
		if (is_array($row)) {
			
			//<<< This needs further tightening, too much is getting through...
			//<<< should make this a two or three pass thing. Should also look for part/parts from the [##/##]
			//<<< it appears all the stoopid shit people add to the subject is what is killing it...
			//<<< such as number files "01. shit.mp3" or "01_shit_shit.mp3"
			//<<< just write a quick prog to show all subjects & whats ripped for what this thing is doing...
			//if (($this->current_row["post_est_filename"] !== "") && 
			//	(strstr($this->current_row["post_subject_ripped"], $this->current_row["post_est_filename"]))) {
				// if est. filename is found within subject (subject isnt ripped apart too much)
			//	$this->current_post["subject_mp3"] = 
			//		str_replace($this->current_row["post_est_filename"], "", $this->current_row["post_subject_ripped"]);
			//} else
			if (($this->current_row['post_est_filename'] !== '') && 
				(strstr($this->current_row['post_subject_ripped'], preg_replace("/[\*\<\>!@#\$%^`~\']/", '', $this->current_row['post_est_filename'])))) {
				// if est. filename is found within subject
				// + remove special chars that would be ripped out [\*\<\>!@#\$%^`~\']
				$this->current_post['subject_mp3'] = 
					str_replace(preg_replace("/[\*\<\>!@#\$%^`~\']/", '', $this->current_row['post_est_filename']), '', $this->current_row['post_subject_ripped']);
			} elseif ($this->current_row['post_est_filename'] !== '') {
				$this->current_post['subject_mp3'] = 
					preg_replace("/\"[^\"]{5,}\.(mp3|ogg|nfo|m3u|sfv)\"/i", '', $this->current_row['post_subject_ripped']);
			} else {
				$this->current_post['subject_mp3'] = 
					preg_replace("/(track)?\d{2,3}[ _-]{1,3}.{3,70}?\.(mp3|ogg|nfo|m3u|sfv)/i", '', $this->current_row['post_subject_ripped']);
				//$this->current_post["subject_mp3"] = preg_replace("/(track)?\d{2}.{3,70}?\.mp3/i", "", $this->current_row["post_subject_ripped"]);
			}
			if (strlen($this->current_post['subject_mp3']) <= 4) {
				// if length after removing .mp3 is larger then 4 chars (if the subject wasn't just the filename)
				$this->current_post['subject_mp3'] = $this->current_row['post_subject_ripped'];
			}
		}
		
		if ($this->previous_row['post_subject']) {
		
			if (($this->previous_row['post_subject'] == $this->current_row['post_subject']) &&
				($this->previous_row['post_poster'] == $this->current_row['post_poster'])) {
				// if the exact same subject or same filename by the same poster then drop one of them, preferably the bad one
				if ((int)$this->previous_row['post_bad'] == 1) {
					// keep current
					$this->rotate_vars();
				} elseif ((int)$this->current_row['post_bad'] == 1) {	
					// keep previous
					$this->rotate_vars_keep_previous();
				} elseif ($this->previous_row['post_time'] > $this->current_row['post_time']) {
					// keep previous if newer post (more likely the working repost)
					$this->rotate_vars_keep_previous();
				} else {
					// otherwise keep current
					$this->rotate_vars();
				}
			} elseif ($this->previous_post['subject_mp3'] == $this->current_post['subject_mp3']) {
				// the previous post matchs the current one, so the previous one's stats are ripped
				$this->method_guess_rec_stats();
				if (($this->current_row['post_est_filename_ext'] == '.mp3') || ($this->current_row['post_est_filename_ext'] == '.ogg')) {
					$this->found_mp3s++;
				}
				// rotate vars but keep statistics
				$this->rotate_vars();
			} else {
				// new post, so finish processing the last one.
				$this->method_guess_rec_stats();
				$this->prepare_db_vars();
				$this->rotate_new_vars();
				// set the variable flag to write db
				if ($this->file_complete > 0) {
					// only if considered a 'group'
					$this->group_ready = true;
				}
			}
		} else {
			// set first 'previous_row'
			$this->rotate_vars();
		}
	}
	
	
/* ---------------------------------------------------------------------------
	process by 'filename', meaning when the filename can be determined
	and all processing is based on it.
   ------------------------------------------------------------------------ */
	
	// when scanning for similarities by "filename"
	function method_filename_sql_one($group_number, $limit) {
		return 'SELECT * FROM posts' .
			' WHERE post_est_filename != "" AND post_group = ' . $group_number . ' AND post_xpost = 0 AND file_group = 0' .
			' ORDER BY post_est_poster_email ASC, post_est_filename ASC, posts.post_time ASC ' . $limit;
	}
	//<<< is this one overkill??
	function method_filename_sql_two($group_number, $limit) {
		return 'SELECT * FROM posts' .
			' WHERE post_est_filename != "" AND post_group = ' . $group_number . ' AND post_xpost = 0 AND file_group = 0' .
			' ORDER BY post_est_filename ASC, post_est_poster_email ASC, posts.post_time ASC ' . $limit;
	}

	function method_filename_process($row) {
		// new row
		$this->current_row = $row;
		$this->current_post = array();
		if (is_array($row)) {
			// rip apart filenames for comparing to previous posts
			if (preg_match("/\.part\d{0,4}\.vol\d{1,4}\+\d{1,4}\.par2$/i", $this->current_row['post_est_filename'])) {
				// .part00.vol031+27.PAR2
				$full_ext = "\\.part\\d{0,4}\\.vol\\d{1,4}\\+\\d{1,4}\\.par2";
			} elseif (preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2$/i", $this->current_row["post_est_filename"])) {
				// .vol031+27.PAR2
				$full_ext = "\\.vol\\d{1,4}\\+\\d{1,4}\\.par2";
			} elseif (preg_match("/\.part\d{0,4}\.(rar|par2|par|rev|sfv|[rp\d]\d\d)$/i", $this->current_row["post_est_filename"])) {
				// rar/par has .partxxx in it
				$full_ext = "\\.part\\d{0,4}\\.(rar|par2|par|rev|sfv|[rp\\d]\\d\\d)";
			} elseif (preg_match("/\.(rar|ace|par2|par|rev|sfv|[rcps\d]\d\d)$/i", $this->current_row["post_est_filename"])) {
				// rar/ace/par/par2/.r##/.c##/.p##/.s##/.###
				$full_ext = "\\.(rar|ace|par2|par|rev|sfv|[rcps\\d]\\d\\d)";
			} elseif (preg_match("/[\.-_]sample".$this->file_ext_video."$/i", $this->current_row["post_est_filename"])) {
				// video samples
				$full_ext = "[\\.-_]sample".$this->file_ext_video;
			} elseif (preg_match("/\.zip$/i", $this->current_row["post_est_filename"])) {
				// zips (either 1-9, 01-99, a-z as .zip prefix)
				$full_ext = "([a-z]|\\d{1,2})\\.zip";
			} else {
				// change to regex-friendly
				$full_ext = "\\" . $this->current_row["post_est_filename_ext"];
			}
			$this->current_post['tight_filename'] = 
				preg_replace("/".$full_ext."$/i", "", $this->current_row["post_est_filename"]);
		}
		
		if ($this->previous_row['post_subject']) {
		
			if (($this->previous_row['post_subject'] == $this->current_row['post_subject']) ||
				(($this->previous_row['post_est_filename'] == $this->current_row['post_est_filename']) &&
				($this->previous_row['post_poster'] == $this->current_row['post_poster']))) {
				// if the exact same subject or same filename by the same poster then drop one of them, preferably the bad one
				if ((int)$this->previous_row['post_bad'] == 1) {
					// keep current
					$this->rotate_vars();
				} elseif ((int)$this->current_row['post_bad'] == 1) {	
					// keep previous
					$this->rotate_vars_keep_previous();
				} elseif ($this->previous_row['post_time'] > $this->current_row['post_time']) {
					// keep previous if newer post (more likely the working repost)
					$this->rotate_vars_keep_previous();
				} else {
					// otherwise keep current
					$this->rotate_vars();
				}
			} elseif ($this->previous_post['tight_filename'] == $this->current_post['tight_filename']) {
				// the previous post matchs the current one, so the previous one's stats are ripped
				$this->method_filename_rec_stats();
				// rotate vars but keep statistics
				$this->rotate_vars();
			} else {
				// new post, so finish processing the last one.
				$this->method_filename_rec_stats();
				$this->prepare_db_vars();
				$this->rotate_new_vars();
				// set the variable flag to write db
				if ($this->file_complete > 0) {
					// only if considered a 'group'
					$this->group_ready = true;
				}
			}
		} else {
			// set first 'previous_row'
			$this->rotate_vars();
		}
	}
	
	function method_filename_rec_stats() {
		//<<< does not compensate if file was posted twice... ? leave duplicate posts in ?
		// .rev files are grouped, but since there is no real standard for naming them, they have no special group
		
		// add the postID to an array for later setting file as 'used'
		array_push($this->found_files, (int)$this->previous_row['post_ID']);
		
		// only rars and zips to filesize
		if (preg_match("/\.part\d+\.rar$/i", $this->previous_row['post_est_filename'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[(int)preg_replace("/.*?\.part(\d+)\.rar$/i", "$1", $this->previous_row['post_est_filename'])] = 1;
				if ($this->__INCOMPLETES_IN_SIZE) {
					$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
				}
			} else {
				$this->found_rars[(int)preg_replace("/.*?\.part(\d+)\.rar$/i", "$1", $this->previous_row['post_est_filename'])] = 1;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.(rar|ace)$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[-1] = 2; 
				if ($this->__INCOMPLETES_IN_SIZE) {
					$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
				}
			} else {
				$this->found_rars[-1] = 2;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.[rcs\d]\d{2,}$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[(int)preg_replace("/\.[rcs\d](\d+)$/i", "$1", $this->previous_row['post_est_filename_ext']) + 1] = 2;
				if ($this->__INCOMPLETES_IN_SIZE) {
					$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
				}
			} else {
				$this->found_rars[(int)preg_replace("/\.[rcs\d](\d+)$/i", "$1", $this->previous_row['post_est_filename_ext']) + 1] = 2;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.p\d{2,}$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_pars[(int)preg_replace("/\.p(\d+)$/i", "$1", $this->previous_row['post_est_filename_ext'])] = 1;
			}
		} elseif (preg_match("/\.part\d{0,4}\.vol\d{1,4}\+\d{1,4}\.par2$/i", $this->previous_row['post_est_filename'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_par2_blks += (int)preg_replace("/.*?\.part\d{0,4}\.vol\d{1,4}\+(\d{1,4})\.par2$/i", "$1", $this->previous_row['post_est_filename']);
				$this->found_par2s++;
			}
		} elseif (preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2$/i", $this->previous_row['post_est_filename'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_par2_blks += (int)preg_replace("/.*?\.vol\d{1,4}\+(\d{1,4})\.par2$/i", "$1", $this->previous_row['post_est_filename']);
				$this->found_par2s++;
			}
		} elseif (preg_match("/\.sample".$this->file_ext_video."$/i", $this->previous_row['post_est_filename'])) {
			// video samples 
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_sample = $this->previous_row['post_ID'];
			}
		} elseif ($this->previous_row['post_est_filename_ext'] == '.zip') {
			// handle zips
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[preg_replace("/^.*?([a-z]|[1-9]\d?)\.zip$/i", "$1", $this->previous_row['post_est_filename'])] = 3;
				if ($this->__INCOMPLETES_IN_SIZE) {
					$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
				}
			} else {
				$this->found_zips[preg_replace("/^.*?([a-z]|[1-9]\d?)\.zip$/i", "$1", $this->previous_row['post_est_filename'])] = 3;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} else {
			// just add the size
			if (((int)$this->previous_row['post_bad'] == 0) || ($this->__INCOMPLETES_IN_SIZE)) {
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		}
		
		if ((int)$this->previous_row['post_bad'] == 0) {

			// check/update 'first found'
			if (!$this->found_first['post_est_filename'] || 
				(preg_match("/\.part0{0,3}1\.rar$/i", $this->previous_row['post_est_filename']) ||
				(preg_match("/\.(rar|ace)$/i", $this->previous_row['post_est_filename']) &&
				!preg_match("/\.part\d+\.rar$/i", $this->previous_row['post_est_filename'])))) {
				// oh if only php could do lookbehinds with variable lengths...
				// if empty or the first possible rar
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.p(ar2|\d+)$/i", $this->found_first['post_est_filename']) && 
				(preg_match("/\.par$/i", $this->previous_row['post_est_filename']) ||
				preg_match("/\.vol\d+\+\d+\.(?!par2)$/i", $this->previous_row['post_est_filename']))) {
				// if a par is chosen, then choose first possible par
				$this->found_first = $this->previous_row;
		//	} elseif (!preg_match("/\.[rc\d](ar|\d+)$/i", $this->found_first['post_est_filename']) &&
		//		preg_match("/\.[rc\d](ar|\d+)$/i", $this->previous_row['post_est_filename'])) {
			} elseif (!preg_match("/\.(rar|[rcs]\d+|\d{3,}|ace)/i", $this->found_first['post_subject_ripped']) &&
				preg_match("/\.(rar|[rcs]\d+|\d{3,}|ace)/i", $this->previous_row['post_subject_ripped'])) {
				// if anything but rar/ace is chosen, then replace with rar/ace
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.part\d+\.rar$/i", $this->previous_row['post_est_filename']) &&
				(((int)preg_replace("/^.*\.part(\d+)\.rar$/i", "$1", $this->found_first['post_est_filename'])) > 
				((int)preg_replace("/^.*\.part(\d+)\.rar$/i", "$1", $this->previous_row['post_est_filename'])))) {
				// .part##.rar, use smaller part
				$this->found_first = $this->previous_row;
			} elseif (!preg_match("/\.part\d+\.rar$/i", $this->previous_row['post_est_filename']) && 
				!preg_match("/\.rar$/i", $this->found_first['post_est_filename']) && 
				(((int)preg_replace("/^.*\.[rcs](\d+)$/i", "$1", $this->found_first['post_est_filename'])) >
				((int)preg_replace("/^.*\.[rcs](\d+)$/i", "$1", $this->previous_row['post_est_filename'])))) {
				// .r##, use smaller part
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.zip$/i", $this->found_first['post_est_filename']) &&
				preg_match("/\.zip$/i", $this->previous_row['post_est_filename']) &&
				((preg_replace("/^.*?([a-z]|\d{1,2})\.zip$/i", "$1", $this->found_first['post_est_filename'])) > 
				(preg_replace("/^.*?([a-z]|\d{1,2})\.zip$/i", "$1", $this->previous_row['post_est_filename'])))) {
				// .zip
				$this->found_first = $this->previous_row;
			}
			
			// the majority of files will not be the following, small speedup
			if (preg_match("/^\.(nfo|sfv|par|par2)$/", $this->previous_row['post_est_filename_ext'])) {
				
				// found nfo
				if ($this->previous_row['post_est_filename_ext'] == '.nfo') {
					$this->found_nfo = $this->previous_row['post_ID'];
				}
				
				// found sfv
				if ($this->previous_row['post_est_filename_ext'] == '.sfv') {
					$this->found_sfv = $this->previous_row['post_ID'];
				}
				
				// found par
				if ($this->previous_row['post_est_filename_ext'] == '.par') {
					$this->found_par = $this->previous_row['post_ID'];
				}
				
				// found par2
				if (($this->previous_row['post_est_filename_ext'] == '.par2') && 
				!preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2$/i", $this->previous_row['post_est_filename'])) {
					$this->found_par2 = $this->previous_row['post_ID'];
				}
				
			}
	
			// find newest
			if (!$this->found_date_newest || ($this->found_date_newest < $this->previous_row['post_time'])) {
				$this->found_date_newest = $this->previous_row['post_time'];
			}
	
			//find oldest
			if (!$this->found_date_oldest || ($this->found_date_oldest > $this->previous_row['post_time'])) {
				$this->found_date_oldest = $this->previous_row['post_time'];
			}
		}
	}

/* ---------------------------------------------------------------------------
	Process by 'subject', when the filename cannot be determined. This makes
	an educated guess at grouping all the files.
	
	Although the code is *almost* identical, it is kept seperate to keep the
	code cleaner.
   ------------------------------------------------------------------------ */
	
	// when scanning for similarities by "filename"
	function method_guess_sql_one($group_number, $limit) {
		return 'SELECT * FROM posts' .
		' WHERE post_est_filename = "" AND post_est_filename_ext != "" AND file_group = 0 AND post_group = ' . $group_number . ' AND post_xpost = 0' .
		' ORDER BY post_est_poster_email ASC, post_subject_ripped ASC, post_est_filename_ext ASC ' . $limit;
		// poster email, time?
	}
	
	// when scanning for similarities by "filename"
	function method_guess_sql_two($group_number, $limit) {
		return 'SELECT * FROM posts' .
		' WHERE post_est_filename = "" AND post_est_filename_ext != "" AND file_group = 0 AND post_group = ' . $group_number . ' AND post_xpost = 0' .
		' ORDER BY post_subject_ripped ASC, post_est_poster_email ASC, post_est_filename_ext ASC ' . $limit;
	}
	
	function method_guess_process($row) {
		// new row
		$this->current_row = $row;
		$this->current_post = array();
		if (is_array($row)) {
			// rip apart filenames for comparing to previous posts
			if (preg_match("/\.part\d{0,4}\.vol\d{1,4}\+\d{1,4}\.par2/i", $this->current_row['post_subject_ripped'])) {
				// .part00.vol031+27.PAR2
				$full_ext = "\\.part\\d{0,4}\\.vol\\d{1,4}\\+\\d{1,4}\\.par2";
			} elseif (preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2/i", $this->current_row['post_subject_ripped'])) {
				// .vol031+27.PAR2
				$full_ext = "\\.vol\\d{1,4}\\+\\d{1,4}\\.par2";
			} elseif (preg_match("/\.part\d{0,4}\.(rar|par2|par|rev|sfv|[rp\d]\d\d)/i", $this->current_row['post_subject_ripped'])) {
				// rar/par has .partxxx in it
				$full_ext = "\\.part\\d{0,4}\\.(rar|par2|par|rev|sfv|[rp\\d]\\d\\d)";
			} elseif (preg_match("/\.(rar|ace|par2|par|rev|sfv|[rcps\d]\d\d)/i", $this->current_row['post_subject_ripped'])) {
				// rar/ace/par/par2/.r##/.c##/.p##/.s##/.###
				$full_ext = "\\.(rar|ace|par2|par|rev|sfv|[rcps\\d]\\d\\d)";
			//<<< make it get the 'movie' ones, keep the list of file extension in a centralized location somewhere/somehow
			} elseif (preg_match("/[\.-_]sample".$this->file_ext_video."/i", $this->current_row['post_subject_ripped'])) {
				// video samples
				$full_ext = "[\\.-_]sample".$this->file_ext_video;
			} elseif (preg_match("/\.zip/i", $this->current_row['post_subject_ripped'])) {
				// zips (either 1-9, 01-99, a-z as .zip prefix)
				$full_ext = "([a-z]|\\d{1,2})\\.zip";
			} else {
				// change to regex-friendly
				$full_ext = "\\" . $this->current_row['post_est_filename_ext'];
			}
			$this->current_post['tight_subject'] = preg_replace("/".$full_ext."/i", "", $this->current_row['post_subject_ripped']);
		}
		
		if ($this->previous_row['post_subject']) {
			if ($this->previous_row['post_subject'] == $this->current_row['post_subject']) {
				// if the exact same subject then drop one of them, preferably the bad one
				if ((int)$this->previous_row['post_bad'] == 1) {
					// keep current
					$this->rotate_vars();
				} elseif ((int)$this->current_row['post_bad'] == 1) {	
					// keep previous
					$this->rotate_vars_keep_previous();
				} elseif ($this->previous_row['post_time'] > $this->current_row['post_time']) {
					// keep previous if newer post (more likely the working repost)
					$this->rotate_vars_keep_previous();
				} else {
					// otherwise keep current
					$this->rotate_vars();
				}
			} elseif ($this->previous_post['tight_subject'] == $this->current_post['tight_subject']) {
				// the previous post matchs the current one, so the previous one's stats are ripped
				$this->method_guess_rec_stats();
				// rotate vars but keep statistics
				$this->rotate_vars();
			} else {
				// new post, so finish processing the last one.
				$this->method_guess_rec_stats();
				$this->prepare_db_vars();
				$this->rotate_new_vars();
				// set the variable flag to write db
				if ($this->file_complete > 0) {
					// only if considered a 'group'
					$this->group_ready = true;
				}
			}
		} else {
			// set first 'previous_row'
			$this->rotate_vars();
		}
	}

	function method_guess_rec_stats() {
		// add the postID to an array for later setting file as 'used'
		array_push($this->found_files, (int)$this->previous_row['post_ID']);
		
		// only rars and zips to filesize
		if (preg_match("/\.part\d+\.rar/i", $this->previous_row['post_subject_ripped'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[(int)preg_replace("/.*?\.part(\d+)\.rar.*$/i", "$1", $this->previous_row['post_subject_ripped'])] = 1;
			} else {
				$this->found_rars[(int)preg_replace("/.*?\.part(\d+)\.rar.*$/i", "$1", $this->previous_row['post_subject_ripped'])] = 1;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.(rar|ace)$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[-1] = 2;
			} else {
				$this->found_rars[-1] = 2;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.[rcs\d]\d{2,}$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[(int)preg_replace("/\.[rcs\d](\d+)$/i", "$1", $this->previous_row['post_est_filename_ext']) + 1] = 2;
			} else {
				$this->found_rars[(int)preg_replace("/\.[rcs\d](\d+)$/i", "$1", $this->previous_row['post_est_filename_ext']) + 1] = 2;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} elseif (preg_match("/\.p\d{2,}$/i", $this->previous_row['post_est_filename_ext'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_pars[(int)preg_replace("/\.p(\d+)$/i", "$1", $this->previous_row['post_est_filename_ext'])] = 1;
			}
		} elseif (preg_match("/\.part\d{0,4}\.vol\d{1,4}\+\d{1,4}\.par2/i", $this->previous_row['post_subject_ripped'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_par2_blks += (int)preg_replace("/.*?\.part\d{0,4}\.vol\d{1,4}\+(\d{1,4})\.par2.*$/i", "$1", $this->previous_row['post_subject_ripped']);
				$this->found_par2s++;
			}
		} elseif (preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2/i", $this->previous_row['post_subject_ripped'])) {
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_par2_blks += (int)preg_replace("/.*?\.vol\d{1,4}\+(\d{1,4})\.par2.*$/i", "$1", $this->previous_row['post_subject_ripped']);
				$this->found_par2s++;
			}
		} elseif (preg_match("/\.sample".$this->file_ext_video."/i", $this->previous_row['post_subject_ripped'])) {
			//<<<(store the file extensions in one location somehow)
			// video samples 
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_sample = $this->previous_row['post_ID'];
			}
		} elseif ($this->previous_row['post_est_filename_ext'] == '.zip') {
			// handle zips
			if ((int)$this->previous_row['post_bad'] == 1) {
				$this->found_bad_posts[preg_replace("/^.*?([a-z]|[1-9]\d?)\.zip.*$/i", "$1", $this->previous_row['post_subject_ripped'])] = 3;
			} else {
				$this->found_zips[preg_replace("/^.*?([a-z]|[1-9]\d?)\.zip.*$/i", "$1", $this->previous_row['post_subject_ripped'])] = 3;
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		} else {
			// just add the size
			if ((int)$this->previous_row['post_bad'] == 0) {
				$this->found_size += round((int)$this->previous_row['post_bytes'] / 1024);
			}
		}
		
		if ((int)$this->previous_row['post_bad'] == 0) {

			// check/update 'first found'
			if (!$this->found_first['post_subject_ripped'] || 
				(preg_match("/\.part0{0,3}1\.rar/i", $this->previous_row['post_subject_ripped']) ||
				(preg_match("/\.(rar|ace)/i", $this->previous_row['post_subject_ripped']) &&
				!preg_match("/\.part\d+\.rar/i", $this->previous_row['post_subject_ripped'])))) {
				// oh if only php could do lookbehinds with variable lengths...
				// if empty or the first possible rar
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.p(ar2|\d+)/i", $this->found_first['post_subject_ripped']) && 
				(preg_match("/\.par/i", $this->previous_row['post_subject_ripped']) ||
				preg_match("/\.vol\d+\+\d+\.(?!par2)/i", $this->previous_row['post_subject_ripped']))) {
				// if a par is chosen, then choose first possible par
				$this->found_first = $this->previous_row;
		//	} elseif (!preg_match("/\.[rc\d](ar|\d+)/i", $this->found_first['post_subject_ripped']) &&
		//		preg_match("/\.[rc\d](ar|\d+)/i", $this->previous_row['post_subject_ripped'])) {
			} elseif (!preg_match("/\.(rar|[rcs]\d+|\d{3,}|ace)/i", $this->found_first['post_subject_ripped']) &&
				preg_match("/\.(rar|[rcs]\d+|\d{3,}|ace)/i", $this->previous_row['post_subject_ripped'])) {
				// if anything but rar/ace is chosen, then replace with rar/ace
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.part\d+\.rar/i", $this->previous_row['post_subject_ripped']) &&
				(((int)preg_replace("/^.*\.part(\d+)\.rar.*$/i", "$1", $this->found_first['post_subject_ripped'])) > 
				((int)preg_replace("/^.*\.part(\d+)\.rar.*$/i", "$1", $this->previous_row['post_subject_ripped'])))) {
				// .part##.rar, use smaller part
				$this->found_first = $this->previous_row;
			} elseif (!preg_match("/\.part\d+\.rar/i", $this->previous_row['post_subject_ripped']) && 
				!preg_match("/\.rar/i", $this->found_first['post_subject_ripped']) && 
				(((int)preg_replace("/^.*\.[rc](\d+).*$/i", "$1", $this->found_first['post_subject_ripped'])) >
				((int)preg_replace("/^.*\.[rc](\d+).*$/i", "$1", $this->previous_row['post_subject_ripped'])))) {
				// .r##, use smaller part
				$this->found_first = $this->previous_row;
			} elseif (preg_match("/\.zip/i", $this->found_first['post_subject_ripped']) &&
				preg_match("/\.zip/i", $this->previous_row['post_subject_ripped']) &&
				((preg_replace("/^.*?([a-z]|\d{1,2})\.zip.*$/i", "$1", $this->found_first['post_subject_ripped'])) > 
				(preg_replace("/^.*?([a-z]|\d{1,2})\.zip.*$/i", "$1", $this->previous_row['post_subject_ripped'])))) {
				// .zip
				$this->found_first = $this->previous_row;
			}
			
			// the majority of files will not be the following, small speedup
			if (preg_match("/^\.(nfo|sfv|par|par2)$/", $this->previous_row['post_est_filename_ext'])) {
			
				// found nfo
				if ($this->previous_row['post_est_filename_ext'] == '.nfo') {
					$this->found_nfo = $this->previous_row['post_ID'];
				}
				
				// found sfv
				if ($this->previous_row['post_est_filename_ext'] == '.sfv') {
					$this->found_sfv = $this->previous_row['post_ID'];
				}
				
				// found par
				if ($this->previous_row['post_est_filename_ext'] == '.par') {
					$this->found_par = $this->previous_row['post_ID'];
				}
				
				// found par2
				if (($this->previous_row['post_est_filename_ext'] == '.par2') && 
				!preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2/i", $this->previous_row['post_subject_ripped'])) {
					$this->found_par2 = $this->previous_row['post_ID'];
				}
			
			}
			
			// find newest
			if (!$this->found_date_newest || ($this->found_date_newest < $this->previous_row['post_time'])) {
				$this->found_date_newest = $this->previous_row['post_time'];
			}
	
			//find oldest
			if (!$this->found_date_oldest || ($this->found_date_oldest > $this->previous_row['post_time'])) {
				$this->found_date_oldest = $this->previous_row['post_time'];
			}	
		}
	}
	
/* ---------------------------------------------------------------------------
	Prepare all db variables before writing to db.
   ------------------------------------------------------------------------ */
	
	function prepare_db_vars() {
		//<<< this code works but is kinda loopy, needs cleaning up
		// this does all the processing to get the db vars ready for writing
		
		// if more then one .rar or one .rar and one or more bad .rars found
		if ((count($this->found_rars) > 1) || 
			((count($this->found_rars) == 1) && (count($this->found_bad_posts) >= 1) &&	(count($this->found_zips) == 0))) {
			// caculate number of rars found
			$goodposts = $this->found_rars;
			$tmpa = array_count_values($this->found_rars);
			$this->file_parts = (int)$tmpa[1] + (int)$tmpa[2];
			$this->found_rars = array_keys($this->found_rars);
			sort($this->found_rars, SORT_NUMERIC);
			$tmpgood = (int)array_pop($this->found_rars);	// highest
			$tmp = $tmpgood;
			if ($tmp == -1) {
				// only one rar was posted
				$tmp = 1;
			} elseif ($goodposts[-1] == 2) {
				// starts from a .rar, so add one to the total
				$tmp++;
			} elseif (($goodposts[-1] == 0) && ($goodposts[1] == 0) && ($goodposts[2] == 2)) {
				// starts from 01 (if all posts are good this works, otherwise found_bad_posts corrects it)
				$tmp--;
			}
			if (count($this->found_bad_posts) > 0) {
				// if bad posts found
				$badposts = $this->found_bad_posts;
				$this->found_bad_posts = array_keys($this->found_bad_posts);
				sort($this->found_bad_posts, SORT_NUMERIC);
				$tmpbad = (int)array_pop($this->found_bad_posts);	// highest
				// extra compensation for .r## style posts
				if (((int)$goodposts[-1] == 2) || ((int)$badposts[-1] == 2)) {
					// .r## type, starts at .rar
					$tmpbad++;
				} elseif (((int)$tmpa[2] > 0) &&
					((int)$goodposts[-1] == 0) && ((int)$badposts[-1] == 0) && 
					((int)$goodposts[1] == 0) && ((int)$badposts[1] == 0) &&
					(((int)$goodposts[2] == 2) || ((int)$badposts[2] == 2))) {
					// .r## type, not including .rar/.r00 (either being uploaded in a wierd order or posts being deleted off server)
					$tmpbad--;
				}
				// fix up good posts
				if (($goodposts[-1] == 0) && ($badposts[-1] == 2)) {
					$tmp++;
				}
				// set the corrected value
				if ($tmpbad > $tmpgood) {
					$tmp = $tmpbad;
				}
			}
			$this->file_parts_total = (int)$tmp;	// really we can only calculate based on the highest file posted...
		} else {
			$this->file_parts = 0;
			$this->file_parts_total = 0;
		}
		
		if ((count($this->found_zips) > 1) || 
			((count($this->found_zips) == 1) && (count($this->found_bad_posts) >= 1) &&	(count($this->found_rars) == 0))) {
			// caculate number of zips found
			//print_r($this->found_zips);
			$tmpa = array_count_values($this->found_zips);
			$this->file_zips = (int)$tmpa[3];
			$this->found_zips = array_keys($this->found_zips);
			sort($this->found_zips, SORT_REGULAR);
			$tmp = array_pop($this->found_zips);	// highest number&letter
			if (preg_match("/^[a-z]$/i", $tmp)) {
				// a-z method
				$tmpz = $tmp;
				for ($i=1; $i<=26; $i++) {
					if (chr(96 + $i) == $tmpz) {
						$tmp = $i;
					}
				}
			} elseif (preg_match("/^\d{1,2}$/i", $tmp)) {
				// 1-9 or 01-99 method (compensates if 40-44 is detected because of the filename)
				$tmp = $tmp - (int)array_shift($this->found_zips) + 1;
			}
			if (count($this->found_bad_posts) > 0) {
				// if bad posts found
				$this->found_bad_posts = array_keys($this->found_bad_posts);
				sort($this->found_bad_posts, SORT_REGULAR);
				$tmpbad = array_pop($this->found_bad_posts);	// highest
				if (preg_match("/^[a-z]$/i", $tmpbad)) {
					// a-z method
					$tmpz = $tmpbad;
					for ($i=1; $i<=26; $i++) {
						if (chr(96 + $i) == $tmpz) {
							$tmpbad = $i;
						}
					}
				} elseif (preg_match("/^\d{1,2}$/i", $tmpbad)) {
					// 1-9 or 01-99 method (compensates if 40-44 is detected because of the filename)
					$tmpbad = $tmpbad - (int)array_shift($this->found_bad_posts) + 1;
				}
				if ($tmpbad > $tmp) { 
					// if bad file is higher
					$tmp = $tmpbad;
				}
			}
			$this->file_zips_total = (int)$tmp;
		} else {
			$this->file_zips = 0;
			$this->file_zips_total = 0;
		}
		
		$tmpa = array_count_values($this->found_pars);
		$this->file_number_par = (int)$tmpa[1];
		$this->file_blocks_par2 = (int)$this->found_par2_blks;
		$this->file_total_size = (int)$this->found_size;
		// title of the 'grouping'
		$this->file_post_first = $this->found_first['post_subject'];
		// links to special files in the 'grouping'
		$this->file_post_first_ID = (int)$this->found_first['post_ID'];
		$this->file_post_nfo_ID = (int)$this->found_nfo;
		$this->file_post_sample_ID = (int)$this->found_sample;
		$this->file_post_par_ID = (int)$this->found_par;
		$this->file_post_par2_ID = (int)$this->found_par2;
		$this->file_post_sfv_ID = (int)$this->found_sfv;
		$this->file_date_newest = $this->found_date_newest;
		$this->file_date_oldest = $this->found_date_oldest;
		
		// caculate completeness
		// 0 = unknown/not-applicable
		// 5 = fill post only (par/par2 with no rars/zips)
		///RARS
		// 11 = complete
		// 12 = complete WITH pars
		// 13 = incomplete but contains par2s (cannot tell until downloaded)
		// 14 = incomplete
		///ZIPS
		// 21 = complete
		// 22 = complete WITH pars
		// 23 = incomplete but contains par2s (cannot tell until downloaded)
		// 24 = incomplete
		/// MP3s
		// 30 = mp3s
		
		if ($this->found_mp3s > 1) {
			$this->file_complete = 30;
			$this->file_parts = $this->found_mp3s + 1;
			$this->file_parts_total = $this->file_parts;
		} elseif (($this->file_parts_total == 0) && ($this->file_zips_total == 0) && (($this->file_number_par > 1) || ($this->found_par2s > 1))) {
			$this->file_complete = 5;
		} elseif (($this->file_parts == $this->file_parts_total) && ($this->file_parts_total > 1)) {
			$this->file_complete = 11;
		} elseif ((($this->file_parts_total - $this->file_parts) <= $this->file_number_par) && ($this->file_parts_total > 1)) {
			$this->file_complete = 12;
		} elseif (($this->file_parts < $this->file_parts_total) && ($this->file_blocks_par2 > 0) && ($this->file_parts_total > 1)) {
			$this->file_complete = 13;
		} elseif (($this->file_parts < $this->file_parts_total) && ($this->file_parts_total > 1) && ($this->file_parts > 1)) {
			$this->file_complete = 14;
		} elseif (($this->file_zips == $this->file_zips_total) && ($this->file_zips_total > 1)) {
			$this->file_complete = 21;
		} elseif ((($this->file_zips_total - $this->file_zips) <= $this->file_number_par) && ($this->file_zips_total > 1)) {
			$this->file_complete = 22;
		} elseif (($this->file_zips < $this->file_zips_total) && ($this->file_blocks_par2 > 0) && ($this->file_zips_total > 1)) {
			$this->file_complete = 23;
		} elseif (($this->file_zips < $this->file_zips_total) && ($this->file_zips_total > 1) && ($this->file_zips > 1)) {
			$this->file_complete = 24;
		} else {
			$this->file_complete = 0;
		}

		// updating posts group
		$this->post_file_group = $this->found_files;

	}
	
	//<<< needs a centralized locale
	// updating the db using local variables
	// (two/three step process)
	function assoc_variables($tmp) {
		$tmpa = array();
		foreach($tmp as $value) {
			array_push($tmpa, $this->{$value});
		}
		return $tmpa;
	}
	
}
?>