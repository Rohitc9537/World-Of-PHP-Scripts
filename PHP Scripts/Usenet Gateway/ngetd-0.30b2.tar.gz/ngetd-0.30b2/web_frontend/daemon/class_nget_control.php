<?
class nget_control {
	
	// externally set classes
	var $class_db;			// db class
	
	// static
	var $__PROG_HEADER;		// full path
	var $__PROG_DOWNLD;		// full path
	var $__LOG_FILE;		// log filename prefix (where nget output is dumped)
	var $__CONCURRENT;		// how many concurrent ngets to have running (how many connections allowed) - changes on the fly
	var $__MAX_RETRY_HEADERS;		// how many times to retry downloading headers
	var $__MAX_RETRY_DOWNLOADS;		// how many times to retry downloading posts
	var $__RETRY_HEADERS_DELAY;		// delay in seconds between retrying header download
	var $__RETRY_DOWNLOADS_DELAY;	// delay in seconds between retrying post download
	///var $__SQL_BATCH;		// max rows
	var $__LANG;				// language translations
	
	// vars
	var $nget_status;		// array of what each instance of nget is doing, and therefore how to monitor it
							// $nget_status[job #]['status'] = current status of job # (defined in function set_process)
							// $nget_status[job #]['group_id'] = groupid corresponding to job
							// $nget_status[job #]['group_name'] = groupname corresponding to job
	var $nget_finished;		// array of finished group_ids
	
	// download table
	var $download_custom_position;
	var $download_post_ID;
	var $download_messageid;
	var $download_file_group_ID;
	var $download_filename;
	var $download_group;
	var $download_status;
	var $download_wishlist_ID;
	var $download_size;
	var $download_subject;
	var $download_post_time;
	var $download_retry;
	
	
	function nget_control(&$cfg) {
		// init
		// set all internal variables
		$this->__PROG_HEADER = $cfg['PROG_HEADER'];
		$this->__PROG_DOWNLD = $cfg['PROG_DOWNLD'];
		$this->__LOG_FILE = $cfg['LOG_FILE'];
		$this->__CONCURRENT = $cfg['CONCURRENT_DOWNLOADS'];		// defaults to downloads
		$this->__MAX_RETRY_HEADERS = $cfg['MAX_RETRY_HEADERS'];
		$this->__MAX_RETRY_DOWNLOADS = $cfg['MAX_RETRY_DOWNLOADS'];
		$this->__RETRY_HEADERS_DELAY = $cfg['RETRY_HEADERS_DELAY'];
		$this->__RETRY_DOWNLOADS_DELAY = $cfg['RETRY_DOWNLOADS_DELAY'];
		$this->__LANG = $cfg['lang'];
		///$this->__SQL_BATCH = $cfg['SQL_BATCH'];
		
		$this->nget_status = array();
		$this->nget_finished = array();
	}
	

	/* -------------- set max connections for header/download server allowances ----------- */
	
	function set_concurrent($con) {
		if ((int)$con > $this->__CONCURRENT) {
			for ($i = $this->__CONCURRENT; $i <= (int)$con; $i++) {
				// reset new positions
				$this->reset_process($i);
			}
		}
		$this->__CONCURRENT = (int)$con;
	}
	
	
	/* -------------- nget status controls (internal) ----------- */
	
	// if there is an opening (1 to $__CONCURRENT) then return value, otherwise return false
	function get_unused_process() {
		$tmp = false;
		for ($i=$this->__CONCURRENT; $i >= 1; $i--) {
			if ($this->is_unused_process($i)) {
				$tmp = $i;
			}
		}
		return $tmp;
	}

	// returns true or false if a process is avaliable
	function is_unused_process($process) {
		if ($this->get_process($process)) {
			return false;
		} else {
			return true;
		}
	}
	
	// returns true or false if any processes avaliable
	function is_unused_processes() {
		if ($this->get_unused_process()) {
			return true;
		} else {
			return false;
		}
	}
	
	// returns true if any processes running, otherwise false
	function is_active_processes() {
		$tmp = false;
		for ($i=1; $i <= $this->__CONCURRENT; $i++) {
			if (!$this->is_unused_process($i)) {
				$tmp = true;
			}
		}
		return $tmp;
	}
		
	// set an open process to a specified status (called by the function doing the processing)
	function set_process($process, $status, $groupnumber, $groupname, $downloadid) {
		// statuses : 0-unused, 1-updating headers, 2-downloading
		if ($this->is_unused_process($process)) {
			$this->nget_status[$process]['status'] = $status;
			$this->nget_status[$process]['group_id'] = $groupnumber;
			$this->nget_status[$process]['group_name'] = $groupname;
			$this->nget_status[$process]['downloadid'] = $downloadid;
			return true;
		} else {
			return false;
		}
	}
	
	// reset process to 'unused'
	function reset_process($process) {
		$this->nget_status[$process]['status'] = 0;
		$this->nget_status[$process]['group_id'] = 0;
		$this->nget_status[$process]['group_name'] = '';
		$this->nget_status[$process]['downloadid'] = 0;
		$this->nget_status[$process]['group_retry'] = 0;
		$this->nget_status[$process]['messageid'] = '';
	}
	
	// return what process is doing if running, otherwise false
	function get_process($process) {
		// keep everything pointing here
		if ($this->nget_status[$process]['status'] == 0) {
			return false;
		} else {
			return $this->nget_status[$process]['status'];
		}
	}
	
	// return groupid of process, otherwise false
	function get_process_groupid($process) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			return $this->nget_status[$process]['group_id'];
		}
	}

	// return groupname of process, otherwise false
	function get_process_groupname($process) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			return $this->nget_status[$process]['group_name'];
		}
	}
	
	// return downloadid of process, otherwise false
	function get_process_downloadid($process) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			return $this->nget_status[$process]['downloadid'];
		}
	}
	
	// return group_retry of process, otherwise false
	function get_process_groupretry($process) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			return $this->nget_status[$process]['group_retry'];
		}
	}
	
	// set group_retry
	function set_process_groupretry($process, $retry) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			$this->nget_status[$process]['group_retry'] = (int)$retry;
			return true;
		}
	}
	
	// return group_retry of process, otherwise false
	function get_process_messageid($process) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			return $this->nget_status[$process]['messageid'];
		}
	}
	
	// set group_retry
	function set_process_messageid($process, $messageid) {
		// keep everything pointing here
		if (!$this->get_process($process)) {
			return false;
		} else {
			$this->nget_status[$process]['messageid'] = $messageid;
			return true;
		}
	}
	
/* ------------- nget functions (external) ------------------ */

	// check active processes to see which have finished
	//<<< this needs the code *tightened* and to read nget better! always know when '1 error' etc

	function check_active_processes() {
		for ($i=1; $i <= $this->__CONCURRENT; $i++) {
			if (!$this->is_unused_process($i)) {
				if ($this->get_process($i) == 1) {
					// header download
					$logarray = null;
					//exec('tail -n 1 '.$this->__LOG_FILE.$i.'.log 2>/dev/null', $logarray);
					exec('tail -c 4000 '.$this->__LOG_FILE.$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 1 2>/dev/null', $logarray);
					if (preg_match("/^HEADERDONE_".$this->get_process_groupname($i)."$/", $logarray[0])) {
						
						$scan = array(array());
						$j = 0;
						$scan[$j]['grep'] = '>> 411 No Such Group';
						$scan[$j]['regex'] = '/411 No Such Group/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_nosuchgroup'];
						$j++;
						$scan[$j]['grep'] = '>> 400 Too Many Connections';
						$scan[$j]['regex'] = '/400 Too Many Connections/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_toomanyconnections'];
						$j++;
						$scan[$j]['grep'] = 'timeout reached';
						$scan[$j]['regex'] = '/(sock_read|make_connection) timeout reached/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_timeout'];
						$j++;
						$scan[$j]['grep'] = 'no servers queried successfully';
						$scan[$j]['regex'] = '/no servers queried successfully/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_connectionproblem'];
						$j++;
						$scan[$j]['grep'] = 'ERRORS: 1 group';
						$scan[$j]['regex'] = '/ERRORS: 1 group/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_unknownerror'];
						$j++;
						$scan[$j]['grep'] = 'Daily limit exceeded';
						$scan[$j]['regex'] = '/>> 501 .*? Daily limit exceeded/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_downloadlimitexceeded'];
						$j++;
						$scan[$j]['grep'] = 'authentication required';
						$scan[$j]['regex'] = '/>> 480 authentication required/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_headers_authentationrequired'];
						
						$problem = false;
						for ($k=0; $k <= $j; $k++) {
							if ($problem == false) {	// if we already haven't found something, prevent multiple errors
								$logarray = null;	
								//exec("grep -i '" . $scan[$k]['grep'] . "' ".$this->__LOG_FILE.$i.'.log | tail -n 1', $logarray);
								exec('tail -c 4000 '.$this->__LOG_FILE.$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep -i "' . $scan[$k]['grep'] . '" | tail -n 1 2>/dev/null', $logarray);
								if (preg_match($scan[$k]['regex'], $logarray[0])) {
									// error occured, try again
									$problem = true;
									if ($this->get_process_groupretry($i) >= $this->__MAX_RETRY_HEADERS) {
										$this->class_db->event_logging($scan[$k]['error'] . ', ' . $this->__LANG['control']['maxretrysexceededon'] . ' ' . $this->get_process_groupname($i).'.', 0, 1);
										$this->reset_process($i);
										sleep($this->__RETRY_HEADERS_DELAY);
									} elseif ($scan[$k]['retry'] == 0) {
										$this->class_db->event_logging($scan[$k]['error'] . ', ' . $this->__LANG['control']['erroron'] . ' ' . $this->get_process_groupname($i).'.', 0, 1);
										$this->reset_process($i);
										sleep($this->__RETRY_HEADERS_DELAY);
									} else {
										$this->class_db->event_logging($scan[$k]['error'] . ' ' . $this->__LANG['control']['on'] . ' ' . $this->get_process_groupname($i) . '. ' . $this->__LANG['control']['requeuing'], 1, 0);
										$groupid = $this->get_process_groupid($i);
										$groupname = $this->get_process_groupname($i);
										$groupretry = $this->get_process_groupretry($i) + 1;
										$this->reset_process($i);
										$this->refresh_headers($groupid, $groupname, $groupretry);
									}
								}
							}
						}
								
						// everything is good
						if ($problem == false) {
							// finished ok
							array_push($this->nget_finished, $this->get_process_groupid($i));
							$this->reset_process($i);
						}
					}
				} elseif ($this->get_process($i) == 2) {
					// file download
					//<<< make it calc speed/ % complete / etc...
					$logarray = null;
					//exec('tail -n 1 '.$this->__LOG_FILE.$i.'.log 2>/dev/null', $logarray);
					exec('tail -c 4000 '.$this->__LOG_FILE.$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 1 2>/dev/null', $logarray);
					if (preg_match("/^DOWNLOADDONE_".$this->get_process_downloadid($i)."$/", $logarray[0])) {

						// array[0][grep] = what to grep for
						// array[0][regex] = what to regex from the grep
						// array[0][retry] = 1=retry / 0=error(giveup)
						// array[0][error] = 'This happened' for Deamon log
						// array[0][code] = error code for db
						// note: order is important!
						$scan = array(array());
						$j = 0;
						$scan[$j]['grep'] = 'bad reply 423: 423 No Such Article In Group';
						$scan[$j]['regex'] = '/bad reply 423: 423 No Such Article In Group/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_articlepurged'];
						$scan[$j]['code'] = 14;
						$j++;
						$scan[$j]['grep'] = '>> 400 Too Many Connections';
						$scan[$j]['regex'] = '/400 Too Many Connections/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_toomanyconnections'];
						$scan[$j]['code'] = 11;
						$j++;
						$scan[$j]['grep'] = 'timeout reached';
						$scan[$j]['regex'] = '/(sock_read|make_connection) timeout reached/i';		// sockstuff.cc
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_timeout'];
						$scan[$j]['code'] = 12;
						$j++;
						$scan[$j]['grep'] = '(gethostbyname:';			// sockstuff.cc
						$scan[$j]['regex'] = '/gethostbyname:/i';
						$scan[$j]['retry'] = 1;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_connectionproblem'];
						$scan[$j]['code'] = 15;
						$j++;
						// keep this second last. In case dling incomplete files then it will just properly say 'decoding error'
						$scan[$j]['grep'] = 'ERRORS: 1 decode';
						$scan[$j]['regex'] = '/ERRORS: 1 decode/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_decodingerror'];
						$scan[$j]['code'] = 13;
						$j++;
						// download limit exceeded
						$scan[$j]['grep'] = 'Daily limit exceeded';
						$scan[$j]['regex'] = '/>> 501 .*? Daily limit exceeded/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_downloadlimitexceeded'];
						$scan[$j]['code'] = 16;
						$j++;
						// authentication required
						$scan[$j]['grep'] = 'authentication required';
						$scan[$j]['regex'] = '/>> 480 authentication required/i';
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_authenticationrequired'];
						$scan[$j]['code'] = 17;
						$j++;
						// keep this at end, general catch-all
						$scan[$j]['grep'] = 'ERRORS:';
						$scan[$j]['regex'] = '/^ERRORS:.*(\d+ decode|\d+ path|\d+ user|\d+ retrieve|\d+ grouplist|\d+ autopar\d+ other\d+ fatal)/i'; 	// status.cc
						$scan[$j]['retry'] = 0;
						$scan[$j]['error'] = $this->__LANG['control']['error_download_retrieveerror'];
						$scan[$j]['code'] = 10;
						
						$problem = false;
						
						for ($k=0; $k <= $j; $k++) {
							if ($problem == false) {	// if we already haven't found something, prevent multiple errors
								$logarray = null;
								//exec("grep -i '" . $scan[$k]['grep'] . "' ".$this->__LOG_FILE.$i.'.log | tail -n 1', $logarray);
								exec('tail -c 4000 '.$this->__LOG_FILE.$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep -i "' . $scan[$k]['grep'] . '" | tail -n 1 2>/dev/null', $logarray);
								if (preg_match($scan[$k]['regex'], $logarray[0])) {
									// check max-retrys
									$problem = true;
									$sql = 'SELECT download_retry FROM download' .
										' WHERE download_ID = ' . $this->get_process_downloadid($i);
									$this->class_db->query_db($sql);
									$row = $this->class_db->sql_results();
									$this->class_db->free_query();
									if (($scan[$k]['retry'] == 0) || ((int)$row['download_retry'] >= $this->__MAX_RETRY_DOWNLOADS)) {
										// set download status to 'error' and move on
										$this->class_db->event_logging($scan[$k]['error'] . ', ' . $this->__LANG['control']['erroronnumber'] . $this->get_process_downloadid($i), 0, 1);
										$sql = 'UPDATE download' .
											' SET download_status = ' . $scan[$k]['code'] . ', download_custom_position = 0, download_date = now()' .
											' WHERE download_ID = ' . $this->get_process_downloadid($i);
										$this->class_db->write_db($sql);
										if ($k == 13) {
											// set downloaded status when downloading known incomplete files with a 'decoding error'
											$sql = 'UPDATE posts' .
												' SET post_downloaded = 1' .
												' WHERE post_messageid = "' . $this->class_db->sql_friendly($this->get_process_messageid($i)) . '"' .
												' AND post_bad = 1';
											$this->class_db->write_db($sql);
										}
										array_push($this->nget_finished, $this->get_process_groupid($i));
										$this->reset_process($i);
									} else {
										// retry
										$this->class_db->event_logging($scan[$k]['error'] . ', ' . $this->__LANG['control']['redownloadingnumber'] . $this->get_process_downloadid($i), 1, 0);
										// reset status and try again
										$sql = 'UPDATE download' .
											' SET download_status = 0, download_retry = download_retry + 1, download_date = now()' .
											' WHERE download_ID = ' . $this->get_process_downloadid($i);
										$this->class_db->write_db($sql);
										$this->reset_process($i);
									}
								}
							}
						}
							
						// everything is good
						if ($problem == false) {
							// nget finished
							// set status for download
							$sql = 'UPDATE download' .
								' SET download_status = 1, download_custom_position = 0, download_date = now()' .
								' WHERE download_ID = ' . $this->get_process_downloadid($i);
							$this->class_db->write_db($sql);
							// set status for post
							$sql = 'UPDATE posts' .
								' SET post_downloaded = 1' .
								' WHERE post_messageid = "' . $this->class_db->sql_friendly($this->get_process_messageid($i)) . '"';
							$this->class_db->write_db($sql);
							array_push($this->nget_finished, $this->get_process_groupid($i));
							$this->reset_process($i);
						}
					}
				}
			}
		}
		if (count($this->nget_finished) > 0) {
			return array_shift($this->nget_finished);
		} else {
			return false;
		}

	}
	
	// refresh headers
	function refresh_headers($groupnumber, $groupname, $retry) {
		//refresh headers for a given group
		if ($process = $this->get_unused_process()) {
			$this->set_process($process, 1, $groupnumber, $groupname, false);
			if ((int)$retry > 0) {
				// if this is being retried
				$this->set_process_groupretry($process, $retry);
				system($this->__PROG_HEADER . ' ' . $groupname . ' ' . $process . ' ' . $this->__RETRY_HEADERS_DELAY . ' >/dev/null 2>&1 &');
			} else {
				system($this->__PROG_HEADER . ' ' . $groupname . ' ' . $process . ' 0 >/dev/null 2>&1 &');
			}
		} else {
			return false;
		}
	}

	// download first queued file in download table
	function download_queued_file() {
		//<<< consider using ngets builtin functionality in testing and completing downloads in relation to par/par2 files
		// get first avaliable download
		if ($process = $this->get_unused_process()) {
			$sql = '(SELECT * FROM download' .
				' WHERE download_status = 0 AND download_custom_position > 0' .
				' ORDER BY download_custom_position ASC, download_post_time ASC)' .
				' UNION ' .
				' (SELECT * FROM download' .
				' WHERE download_status = 0 AND download_custom_position = 0' .
				' ORDER BY download_post_time ASC)' .
				' LIMIT 1';
			$this->class_db->query_db($sql);
			$row = $this->class_db->sql_results();
			$this->class_db->free_query();
			if ($row['download_group']) {
				// get group name
				$sql = 'SELECT group_name FROM groups WHERE group_ID = ' . $row['download_group'];
				$this->class_db->query_db($sql);
				$tmp = $this->class_db->sql_results();
				$this->class_db->free_query();
				$groupname = $tmp['group_name'];
				$this->set_process($process, 2, 0, $row['download_group'], $row['download_ID']);
				$this->set_process_messageid($process, $row['download_messageid']);
				
				// remove <> regex chars and escape $ for ngets regex-fun
				$messageid = preg_replace("/([\<\>])/", "", $row['download_messageid']);
				$messageid = preg_replace("/[\$]/", "\\\\$", $messageid);
				$messageid = "'" . $messageid . "'";
				
				// retrys pause for a few seconds
				if ((int)$row['download_retry'] > 0) {
					$retry = $this->__RETRY_DOWNLOADS_DELAY;
				} else {
					$retry = 0;
				}
				system($this->__PROG_DOWNLD . ' ' . $groupname . ' ' . $messageid . ' ' . 
					$process . ' ' . $this->get_process_downloadid($process) . ' ' . $retry . ' >/dev/null 2>&1 &');
				// set status for download
				$sql = 'UPDATE download SET download_status = 2, download_custom_position = 0 WHERE download_ID = ' . $row['download_ID'];
				$this->class_db->write_db($sql);
				return $row['download_filename'];
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	// process queued filegroups into a list of files with estimated required pars+nfos etc.
	function process_dl_filegroups() {
		// array of posts to add
		$posts = array();
		// array of filegroups to delete
		$groups = array();
		$sql = 'SELECT * FROM download' .
			' WHERE download_file_group_ID > 0 AND download_status = 99';
		$this->class_db->query_db($sql);
		if (mysql_num_rows($this->class_db->dbquery)) {
			while ($row = $this->class_db->sql_results()) {
				array_push($groups, $row['download_file_group_ID']);
				// queue the oldest first
				$sql = 'SELECT * FROM file_groups' .
					' WHERE file_group_ID = ' . $row['download_file_group_ID'] .
					' ORDER BY file_date_oldest ASC';
				$this->class_db->query_db2($sql);
				// save filegroup stats
				$filegroup = $this->class_db->sql_results2();
				$this->class_db->free_query2();
				// queue the oldest files first
				///$sqlinc = 0;
				///do {
					$sql = 'SELECT * FROM posts' .
						' WHERE file_group = ' . $filegroup['file_group_ID'] . ' AND post_bad = 0' .
						' ORDER BY post_time ASC';
						///' LIMIT ' . ($this->__SQL_BATCH * $sqlinc++) . ", " . $this->__SQL_BATCH;
					$this->class_db->query_db2($sql);
					// go through all related files and decide which to queue
					$pars = array();
					while ($row2 = $this->class_db->sql_results2()) {
						if ($filegroup['file_complete'] == 5) {	// 5 = par fill, download everything
							array_push($posts, $row2['post_ID']);
						} elseif ((preg_match("/^\.p\d{2,3}$/i", $row2['post_est_filename_ext'])) && ($row2['post_ID'] !== $filegroup['file_post_par_ID'])) {
							// if a normal par file, not the sfv-type one
							array_push($pars, $row2['post_ID']);
						} elseif (($row2['post_est_filename_ext'] !== '.par2') && ($row2['post_ID'] !== $filegroup['file_post_sample_ID'])) {
							// and if not a par2/sample then add it
							array_push($posts, $row2['post_ID']);
						} elseif (($row2['post_est_filename_ext'] == '.par2') && (!preg_match("/\.vol\d{1,4}\+\d{1,4}\.par2$/i",$row2['post_est_filename']))) {
							// add the sfv-style par2
							array_push($posts, $row2['post_ID']);
						}
					}
					
					$this->class_db->free_query2();
					if ($filegroup['file_complete'] == 12) {	// 12 = rars complete WITH pars
						for ($i=1; $i <= ($filegroup['file_parts_total'] - $filegroup['file_parts']); $i++) {
							if (count($pars) > 0) {
								array_push($posts, array_pop($pars));
							}
						}
					} elseif ($filegroup['file_complete'] == 22) {	// 22 = zips complete WITH pars
						for ($i=1; $i <= ($filegroup['file_zips_total'] - $filegroup['file_zips']); $i++) {
							if (count($pars) > 0) {
								array_push($posts, array_pop($pars));
							}
						}
					}
				///} while (mysql_num_rows($this->class_db->dbquery) == $this->__SQL_BATCH);
			}
			$this->class_db->free_query();
			// insert chosen files into download queue
			// reset db vars
			$this->download_custom_position = 0;
			$this->download_messageid = '';
			$this->download_file_group_ID = 0;
			$this->download_filename = '';
			$this->download_subject = '';
			$this->download_group = '';
			$this->download_status = 99;	// status = 99 for further processing
			$this->download_size = 0;
			$this->download_wishlist_ID = 0;
			$this->download_post_time = '';
			$this->download_retry = 0;
			
			while (count($posts) > 0) {
				// take off the top to get oldest file
				$this->download_post_ID = array_shift($posts);
				$this->class_db->table_write_array(($this->assoc_variables($this->class_db->table_insert_array('download'))), 'download');
			}
			// flush at the end
			$this->class_db->table_write_array('flush', 'download');
			// clear out the filegroups
			$sql = 'DELETE FROM download WHERE ';
			while (count($groups) > 0) {
				$sql .= 'download_file_group_ID = ' . array_pop($groups) . ' OR ';
			}
			$sql = preg_replace("/^(.*?) OR $/", "$1", $sql);
			$this->class_db->write_db($sql);
		}
	}
	
	// set all the required information to process downloads
	function process_dl_files() {
		$sql = 'SELECT * FROM download' .
			' WHERE download_post_ID > 0 AND download_status = 99';
		$this->class_db->query_db($sql);
		while ($row = $this->class_db->sql_results()) {
			$sql = 'SELECT * FROM posts' .
				' WHERE post_ID = ' . $row['download_post_ID'];
			$this->class_db->query_db2($sql);
			$post = $this->class_db->sql_results2();
			$this->class_db->free_query2();
			if ($post['post_messageid']) {
				$sql = 'UPDATE download SET ' .
					' download_messageid = "' . $this->class_db->sql_friendly($post['post_messageid']) . '",' .
					' download_filename = "' . $this->class_db->sql_friendly($post['post_est_filename']) . '",' .
					' download_subject = "' . $this->class_db->sql_friendly($post['post_subject']) . '",' .
					' download_post_time = "' . $post['post_time'] . '",' .
					' download_size = ' . $post['post_bytes'] . ',' .
					' download_status = 0,' .
					' download_group = ' . $post['post_group'] . 
					' WHERE download_ID = ' . $row['download_ID'];
			} else {
				// something screwed up, so set status to 98 so the daemon will ignore it
				$sql = 'UPDATE download SET'
					.' download_status = 98' .
					' WHERE download_ID = ' . $row['download_ID'];
			}
			$this->class_db->write_db($sql);
		}
		$this->class_db->free_query();
		
		// delete duplicate downloads where the file has not been downloaded yet, but allows files to be downloaded repeatedly
		//<<< this apparently only works in mysql4
		$sql = 'DELETE download FROM download, download AS download2' .
			' WHERE download.download_messageid = download2.download_messageid' .
			' AND (download.download_status=0 OR download.download_status=2 OR download.download_status=4)' .
			' AND (download2.download_status=0 OR download2.download_status=2 OR download2.download_status=4)' .
			' AND download2.download_ID < download.download_ID';
		$this->class_db->write_db($sql);
	}

	//<<< needs a centralized locale
	// updating the db using local variables
	// (two/three step process)
	function assoc_variables($tmp) {
		$tmpa = array();
		foreach($tmp as $value) {
			array_push($tmpa, $this->{$value});
		}
		return $tmpa;
	}
	
}
?>