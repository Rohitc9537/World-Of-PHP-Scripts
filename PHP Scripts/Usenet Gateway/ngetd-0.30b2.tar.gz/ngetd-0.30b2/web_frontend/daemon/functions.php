<?

	// caculate the microtime differences
	function microtime_diff($a,$b) {
		list($a_micro, $a_int)=explode(' ',$a);
		list($b_micro, $b_int)=explode(' ',$b);
		if ($a_int>$b_int) {
			return ($a_int-$b_int)+($a_micro-$b_micro);
		} elseif ($a_int==$b_int) {
			if ($a_micro>$b_micro) {
				return ($a_int-$b_int)+($a_micro-$b_micro);
			} elseif ($a_micro<$b_micro) {
				return ($b_int-$a_int)+($b_micro-$a_micro);
			} else {
				return 0;
			}
		} else { // $a_int<$b_int
			return ($b_int-$a_int)+($b_micro-$a_micro);
		}
	}
	
	function get_file_ext() {
		// build file extension regex
		$file_ext = "\\.(";
		// compressed
		$file_ext .= "rar|[rcs]\\d{2,3}|\\d{3}|ace|zip";
		// linux
		$file_ext .= "|rpm|tar|gz|bz";
		// sfv/parity
		$file_ext .= "|par|p\\d{2,3}|par2|rev|sfv";
		// ISOs
		//$file_ext .= "|iso|bin|cue|nrg|ccd|img";
		// audio
		$file_ext .= "|mp3|m3u|wma|ogg|wav";
		// video
		$file_ext .= "|avi|asf|wmv|mpg|mpeg|qt|mov|ra|ram|vob";
		// ebook - txt|doc|rtf kept out
		$file_ext .= "|pdf|lit|ps|chm";
		// graphics
		$file_ext .= "|gif|jpg|jpeg|tif|tiff|bmp|png|psd";
		// misc
		$file_ext .= "|nfo|nzb";
		// end
		$file_ext .= ")";
		
		return $file_ext;
	}
	
	function get_file_ext_video() {
		// video
		$file_ext = "\\.(avi|asf|wmv|mpg|mpeg|qt|mov|ra|ram)";
	
		return $file_ext;
	}
	
?>
