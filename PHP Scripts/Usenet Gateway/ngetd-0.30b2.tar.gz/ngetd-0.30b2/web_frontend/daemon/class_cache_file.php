<?
class cache_file {

	// static
	var $__DIRS_CACHE;		// local cache dir, need trailing /
	var $__LANG;			// language translations
	
	// internal
	var $group_name;		// current group cache file being parsed
	var $file_handle;		// file handle

	function cache_file(&$cfg) {
		// init
		// set all internal variables
		$this->__DIRS_CACHE = $cfg['DIRS_CACHE'];
		$this->__LANG = $cfg['lang'];
	}
	
	function cache_file_init($group) {
		$this->group_name = $group;
		$this->cache_file_reset();
	}
	
	// get cache file info
	function cache_file_reset() {
		// reset stats
		$this->clear_cache();
		// open file pointer
		if (is_readable($this->__DIRS_CACHE . $this->group_name . ',cache.gz')) {
			$this->file_handle = gzopen($this->__DIRS_CACHE . $this->group_name.',cache.gz', 'r');
		}
	}
	
	// handling the returning of output
	function read_next_line() {
		// change annoying chars at the source.
		return strtr(preg_replace("/[\r\n]/", "", gzgets($this->file_handle, 2000)), 
			$this->__LANG['cache']['from'],	$this->__LANG['cache']['to']);
	}
	
	function clear_cache() {
		if ($this->file_handle) {
			gzclose($this->file_handle);
			$this->file_handle = null;
			clearstatcache();
		}
	}
	
	function cache_eof() {
		// return true/false if at end of file/reading error
		if ($this->file_handle) {
			return gzeof($this->file_handle);
		} else {
			return true;
		}
	}
	
	function is_cache_file_ready() {
		if ($this->file_handle) {
			return true;
		} else {
			return false;
		}
	}

}
?>