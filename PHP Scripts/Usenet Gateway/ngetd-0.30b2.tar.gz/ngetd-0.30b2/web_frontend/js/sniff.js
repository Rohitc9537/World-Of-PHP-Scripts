var nn4 = (document.layers) ? true : false
var ie = (document.all) ? true : false
var dom = (document.getElementById && !document.all) ? true : false

function browser(id){
  if(nn4) {
  path = document.layers[id]
  }
  else if(ie) {
  path = document.all[id]
  }
  else {
  path = document.getElementById(id)
  }
return path  //return the path to the css layer depending on which browser is looking at the page
}

function hideLayer(id){
var layer = browser(id) // call browser sniffing function, assign variable name to returned value
   if(nn4){
   layer.style.display='none';
   //layer.visibility = "hidden"
   }
   else {
   layer.style.display='none';
   //layer.style.visibility = "hidden"
   }
}

function showLayer(id){
var layer = browser(id) // call browser sniffing function, assign variable name to returned value
   if(nn4){
   layer.style.display = ""
   }
   else {
   layer.style.display = ""
   }
}