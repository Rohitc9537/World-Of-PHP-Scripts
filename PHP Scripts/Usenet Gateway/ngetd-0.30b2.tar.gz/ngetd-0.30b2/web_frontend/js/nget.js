	// this code needs some tweaking. everything works but getElementById is simply too slow...

	// global
	var lastClicked = 0;
	var currentClicked = 0;
	
	
	// when an item is alt-clicked, it sets all values in between
	// current and previous selection to the last clicked value (selected/unselected)
	function itemSelectRow(event, itemClicked) {
		lastClicked = currentClicked;
		currentClicked = itemClicked;
		if ((lastClicked > 0) && event.altKey) {
			// ignore when checking on the same one twice
			var tmp = document.getElementById('c' + lastClicked).checked;
			if (lastClicked < currentClicked) {
				for (var i = lastClicked; i <= currentClicked; i++) {
					document.getElementById('c' + i).checked = tmp;
					highlightSelected(i); 
				}
			} else if (lastClicked > currentClicked) {
				for (var i = lastClicked; i >= currentClicked; i--) {
					document.getElementById('c' + i).checked = tmp;
					highlightSelected(i);
				}
			}
			highlightRow(currentClicked, true);
		} else {
			// otherwise just check/uncheck the box
			document.getElementById('c' + currentClicked).checked = !document.getElementById('c' + currentClicked).checked;
			highlightSelected(currentClicked);
			highlightRow(currentClicked, true);
		}
	}
	
	
	// change the style when mouseover/mouseoff a row, keeping all previous styles
	function highlightRow(element, applyStyle) {
		var re = /(overRow *|postSelectedOnRow *)/g;
		var tmp = document.getElementById("t" + element).className.replace(re, "");
		if (applyStyle && document.getElementById('c' + element).checked) {
			tmp = "postSelectedOnRow " + tmp;
		} else if (applyStyle) {
			tmp = "overRow " + tmp;
		}
		document.getElementById("t" + element).className = tmp;
	}

	function highlightSelected(element) {
		var re = /(postSelectedOffRow *|overRow *)/g;
		var tmp = document.getElementById("t" + element).className.replace(re, "");
		if (document.getElementById('c' + element).checked) {
			tmp = "postSelectedOffRow " + tmp;
		}
		document.getElementById("t" + element).className = tmp;
	}
