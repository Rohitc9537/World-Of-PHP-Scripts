<?
	
	// display simple stats on daemon activities
	require_once 'config.php';					// config file
	require_once $cfg['DIRS_WEB'] . 'daemon/class_db_control.php';	// db class
	$class_db = new db_control($cfg);
	
	// start session
	session_cache_limiter('nocache');
	session_start();
	
	// check if changing refresh
	if ($_GET['refreshswitch']) {
		if (!$_SESSION['gui_refresh'] || ($_SESSION['gui_refresh'] == $cfg["GUI_REFRESH_DAEMON_STATS_SLOW"])) {
			$_SESSION['gui_refresh'] = $cfg['GUI_REFRESH_DAEMON_STATS'];
		} else {
			$_SESSION['gui_refresh'] = $cfg['GUI_REFRESH_DAEMON_STATS_SLOW'];
		}
		if (!$_SESSION['queue_refresh'] || ($_SESSION['queue_refresh'] == $cfg["GUI_REFRESH_QUEUE_STATS_SLOW"])) {
			$_SESSION['queue_refresh'] = $cfg['GUI_REFRESH_QUEUE_STATS'];
		} else {
			$_SESSION['queue_refresh'] = $cfg['GUI_REFRESH_QUEUE_STATS_SLOW'];
		}
	} elseif (!$_SESSION['gui_refresh'] || !$_SESSION['queue_refresh']) {
		$_SESSION['gui_refresh'] = $cfg['GUI_REFRESH_DAEMON_STATS'];
		$_SESSION['queue_refresh'] = $cfg['GUI_REFRESH_QUEUE_STATS'];
	}
	
	// if stopping a process
	if ($_POST['stop']) {
		$i = (int)$_POST['stop'];
		if (($i >= 1) && ($i <= $cfg['CONCURRENT_HEADERS'])) {
			$logarray = null;
			exec('head -c 10000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep " << GROUP " | tail -n 1 2>/dev/null', $logarray);
			$updgroup = preg_replace("/^.*GROUP ([\w\.-]*).*?$/i", "$1", $logarray[0]);
			if ($updgroup) {
				exec('kill `ps axf | grep "\/nget " | grep "' . $updgroup . '" | grep -v "grep " | awk \'{print $1}\'`');
			}
		}
	}
	
	echo '<HTML><HEAD>';
	if ($_GET['pg'] == 'lg') {
		// main section of 'download queue' page
		require_once $cfg['DIRS_WEB'] . 'gui/gui_functions.php';
		if ($cfg['GUI_REFRESH_DAEMON_STATS'] > 0) {
			//echo '<META HTTP-EQUIV="refresh" CONTENT="' . $cfg['GUI_REFRESH_QUEUE_STATS'] . '">';
			echo '<META HTTP-EQUIV="refresh" CONTENT="' . $_SESSION['queue_refresh'] . ';URL=gui_speed.php?pg=lg">';
		}
		echo '<LINK rel="stylesheet" href="css/';
		$sql = 'SELECT css FROM nget_backbone'; $class_db->query_db($sql); $row = $class_db->sql_results(); echo $row['css'];
		echo '" type="text/css">';	//>>> too much overhead loading full stylesheet??
		echo '</HEAD><BODY CLASS="def">';
		echo "<DIV STYLE='padding: 5px 0 0 5px;'><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 CLASS='downloads'>\n";
		echo '<FORM name="ngetcontrol" method="POST" action="gui_speed.php?pg=lg"><INPUT type="hidden" name="stop" value="">';
		flush();
		// show current download speeds
		$all_current_speed = $all_total_speeds = 0;
	
		$sql = 'SELECT * FROM nget_backbone';
		$class_db->query_db($sql);
		$row = $class_db->sql_results();
		$class_db->free_query();
		//if (((int)$row['one_time_update'] == 1) || ((int)$row['update_now'] == 1)) {
		if ((int)$row['currently_updating'] == 1) {
			// updating headers
			$all_total_speeds = 0;
			for ($i=1; $i <= $cfg['CONCURRENT_HEADERS']; $i++) {
				// check if finished
				$logarray = $matches = null;
				$memused = $swapused = 0;
				exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 1 2>/dev/null', $logarray);
				if (preg_match("/^saving cache/", $logarray[0])) {
					$matches = array();
					$matches[1] = 100;
					$matches[2] = 0;
					$logarray = null;
					exec('head -c 10000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep " << GROUP " | tail -n 1 2>/dev/null', $logarray);
					$updgroup = preg_replace("/^.*GROUP ([\w\.-]*).*?$/i", "$1", $logarray[0]);
					// get memory used
					$logarray = null;
					exec('ps hv -p `pidof nget` 2>/dev/null | grep "' . $updgroup . '" | sed -r \'s/^[\t ]*([^\t ]+[\t ]+){6}([0-9]+)[\t ]+([0-9]+)[\t ]+.*$/\2:\3/\'', $logarray);
					if (preg_match("/^\d+:\d+$/", $logarray[0])) {
						$swapused = (int)preg_replace("/^(\d+):(\d+)$/", "$1", $logarray[0]);
						$memused = (int)preg_replace("/^(\d+):(\d+)$/", "$2", $logarray[0]);
					}
					$updgroup .= " - _sc_";
				 } elseif (preg_match("/^Flushing headers/", $logarray[0])) {
					$matches = array();
					$matches[1] = $matches[2] = 0;
					$logarray = null;
					exec('head -c 10000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep " << GROUP " | tail -n 1 2>/dev/null', $logarray);
					$updgroup = preg_replace("/^.*GROUP ([\w\.-]*).*?$/i", "$1", $logarray[0]);
					// get memory used
					$logarray = null;
					exec('ps hv -p `pidof nget` 2>/dev/null | grep "' . $updgroup . '" | sed -r \'s/^[\t ]*([^\t ]+[\t ]+){6}([0-9]+)[\t ]+([0-9]+)[\t ]+.*$/\2:\3/\'', $logarray);
					if (preg_match("/^\d+:\d+$/", $logarray[0])) {
						$swapused = (int)preg_replace("/^(\d+):(\d+)$/", "$1", $logarray[0]);
						$memused = (int)preg_replace("/^(\d+):(\d+)$/", "$2", $logarray[0]);
					}
					$updgroup .= " - _fh_";
				} elseif (!preg_match("/^HEADERDONE_/", $logarray[0])) {
					// get group name being updated
					$logarray = null;
					exec('head -c 10000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep " << GROUP " | tail -n 1 2>/dev/null', $logarray);
					$updgroup = preg_replace("/^.*GROUP ([\w\.-]*).*?$/i", "$1", $logarray[0]);
					// get memory used
					$logarray = null;
					exec('ps hv -p `pidof nget` 2>/dev/null | grep "' . $updgroup . '" | sed -r \'s/^[\t ]*([^\t ]+[\t ]+){6}([0-9]+)[\t ]+([0-9]+)[\t ]+.*$/\2:\3/\'', $logarray);
					if (preg_match("/^\d+:\d+$/", $logarray[0])) {
						$swapused = (int)preg_replace("/^(\d+):(\d+)$/", "$1", $logarray[0]);
						$memused = (int)preg_replace("/^(\d+):(\d+)$/", "$2", $logarray[0]);
					}
					// get speed and percentage done
					$logarray = null;
					exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep "Retrieving headers" | tail -n 1 2>/dev/null', $logarray);
					//														 [1] [ 2 ]    [3]
					//Retrieving headers 22943802-23009451 : 3888/9709/9710  40% 80486B/s 25s (1/1/2)
					//preg_match("/^Retrieving headers \d+-\d+ : \d+\/\d+\/\d+ *(\d+)% (\d+)B\/s \d+s.*$/i", $logarray[0], $matches);
					preg_match("/\s(\d+)%\s+(\d+)B\/s\s+([dhms\d]*)/i", $logarray[0], $matches);
					//<<< testing.
				/*	if (((int)$matches[1] == 0) && ((int)$matches[2] > 0) && preg_match("/^.*?\r.*?\r.*$/", $tmp)) {
						// if we caught nget right in the middle a drawing a line, go back one. it should just repeat the last value.
						$tmp = preg_replace("/^(?:.*\r)?([^\r]*?)\r[^\r]*$/", "$1", $logarray[0]);
						preg_match("/ (\d+)% +(\d+)B\/s ([dhms\d]*)/", $tmp, $matches);
					}
				*/
				// 1 = percent, 2 = speed, 3 = time remaining
				} else {
					// header update done
					$matches = array();
					$matches[1] = 100;
					$matches[2] = 0;
				}
				echo '<TR><TD>' . $lang['speed']['thread'] . ' #' . $i . ' : </TD>';
				if (preg_match("/ - _(sc|fh)_/", $updgroup)) {
					$updgroup = preg_replace("/ - _sc_/", " - " . $lang['speed']['savingcache'] . '...', $updgroup);
					$updgroup = preg_replace("/ - _fh_/", " - " . $lang['speed']['flushingheaders'] . '...', $updgroup);
					echo '<TD COLSPAN=5>&nbsp;' . $updgroup;
					if ($memused && $swapused) {
						echo ' ( ' . round($swapused / 1024) . 'Mb ' . $lang['speed']['virtual'] . ' ~ ' . round($memused / 1024) . 'Mb ' . $lang['speed']['memory'] . ' )';
					}
					echo '</TD></TR>';
				} elseif ((int)$matches[1] == 100 || !$matches[2]) { 
					// if completed, dont bother showing anything
					$matches[2] = 0;
					echo '<TD>&nbsp;' . $lang['speed']['unused'] . '</TD></TR>';
				} else {
					echo '<TD>&nbsp;' . $lang['speed']['currentspeed'] . ' ( <SPAN class="queueHighlight">' . convert_speed_mini($matches[2]) . '</SPAN> ),</TD>' .
						'<TD>&nbsp;' . $updgroup . ',</TD>' . 
						'<TD>&nbsp;' . $lang['speed']['complete'] . ' (&nbsp;</TD>' .
						'<TD>' . drawDownloadMeter($matches[1]) . '</TD>' .
						'<TD>&nbsp;&nbsp;' . $matches[3] . ' ' . $lang['speed']['remaining'];
					if ($memused && $swapused) {
						echo ', ' . round($swapused / 1024) . 'Mb ' . $lang['speed']['virtual'] . ' ~ ' . round($memused / 1024) . 'Mb ' . $lang['speed']['memory'];
					}
					echo '&nbsp;)</TD>';
					if ((int)$_POST['stop'] == $i) {
						echo '<TD>&nbsp;( ' . $lang['speed']['cancelling'] . ' )</TD>';
					} else {
						echo '<TD>&nbsp;( <a href="#" onclick="ngetcontrol.stop.value=' . $i . '; ngetcontrol.submit();">' . $lang['speed']['cancel'] . '</a> )</TD>';
					}
					
					echo '</TR>' . "\n";
				}
				$all_total_speeds += $matches[2];
				flush();
			}
			echo '</FORM></TABLE></DIV><BR>' . "\n";
			echo $lang['speed']['totalcurrentspeed'] . ' : ( <SPAN class="queueHighlight">' . convert_speed_mini($all_total_speeds) . '</SPAN> )<BR><BR>' . "\n";
		} else {
			// downloading
			for ($i=1; $i <= $cfg['CONCURRENT_DOWNLOADS']; $i++) {
				$logarray = null;
				exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 10 2>/dev/null', $logarray);
				// reset vars for next thread
				$current_speed = $total_speed =	$total_samples = $current_part = $total_parts = 0;
				$xfer_complete = $decoding = false;
				
				for ($j=9; $j >= 0; $j--) {
					//        [1] [2]                            [3] [ 4 ]
					//6003728 (11/48): 1280/2544L 167363/331528B 50% 33472B/s 4s 0/1 6m11s
					///preg_match("/^\s*\d+\s*\((\d+)\/(\d+)\):\s*\d+\/\d+L\s*\d+\/\d+B\s*(\d+)%\s*(\d+)B\/s\s*[\dms]+\s*\d\/\d\s*[\dms]+\s*$/i", $logarray[$j], $matches);
					preg_match("/^\s*\d+\s*\((\d+)\/(\d+)\):\s*\d+\/\d+L\s*\d+\/\d+B\s*(\d+)%\s*(\d+)B\/s\s*[\dms]+\s*\d\/\d\s*[\dms]+.*$/i", $logarray[$j], $matches);
					// [1] = part on, [2] = parts total, [3] = percent of part downloaded, [4] = speed B/s
					
					if (($current_speed == 0) && $matches[4]) {
						$current_speed = (int)$matches[4];
						$current_part = (int)$matches[1];
						$total_parts = (int)$matches[2];
					}
					if ($matches[3]) {
						$total_speed += (int)$matches[4];
						$total_samples++;
					}
					if ((($current_part == $total_parts) && ($total_parts > 0) && ((int)$matches[3] == 100)) || 
						(preg_match("/^DOWNLOADDONE_/", $logarray[$j]))) {
						// if download is complete then download speed = 0
						$current_speed = $total_speed =	$total_samples = $current_part = $total_parts = 0;
						$xfer_complete = true;
						$decoding = false;
						break;
					} elseif ((preg_match("/^\.?uu_msg.*$/i", $logarray[$j])) || 
						(preg_match("/^\.\.+$/i", $logarray[$j]))) {
						$current_speed = $total_speed =	$total_samples = $current_part = $total_parts = 0;
						$decoding = true;
						break;
					}
				}
				flush();
				// write a function for the 'divide by zero' shit
				echo '<TR><TD>';
				echo $lang['speed']['thread'] . ' #' . $i . ' : ';
				echo '</TD><TD>&nbsp;';
				if ((($total_samples == 0) && !$decoding && !$flushing) || $xfer_complete ) {
					echo $lang['speed']['unused'] . '</TD></TR>';
				} else {
					if ($decoding) {
						echo $lang['speed']['decoding'] . '...</TD>';
					} elseif ($flushing) {	
						echo $lang['speed']['flushingheaders'] . '...</TD>';
					} else {
						echo $lang['speed']['currentspeed'] . ' ( <SPAN class="queueHighlight">'.convert_speed_mini($current_speed).'</span> ),' .
							'</TD><TD>&nbsp;' .
							$lang['speed']['averagespeed'] . ' ( '.convert_speed_mini(@round($total_speed / $total_samples)) . ' ),' .
							'</TD><TD>&nbsp;' . $lang['speed']['complete'] . ' (&nbsp;' .
							'</TD><TD>' . 
							drawDownloadMeter(@round(($current_part / $total_parts)*100)) . 
							'</TD><TD>&nbsp;)</TD>';
					}
						echo '</TR>';
				}
				$all_current_speed += $current_speed;
				$all_total_speeds += @round($total_speed / $total_samples);
			}
			echo '</TABLE><BR>' . "\n";
			flush();
			echo ' ' . $lang['speed']['totalcurrentspeed'] . ' ( <SPAN class="queueHighlight">'.convert_speed_mini($all_current_speed).'</span> ),' .
				' ' . $lang['speed']['totalaveragespeed'] . ' ( '.convert_speed_mini($all_total_speeds).' )<BR>' . "\n";
				
			// show total left to download
			$sql = 'SELECT ROUND(SUM(download_size) / 1024) AS totalsize, COUNT(*) AS files_downloading' .
				' FROM download' .
				' WHERE download_status = 0 OR download_status = 2 OR download_status = 4';
			$class_db->query_db($sql);
			$row = $class_db->sql_results();
			echo $lang['speed']['lefttodownload1'] . ' : <SPAN class="queueHighlight">';
			if ((int)$row['totalsize'] < (10*1024)) {
				// under 10 meg
				echo (int)$row['totalsize'] . ' Kb';
			} else {
				// over 10 meg
				echo round(((int)$row['totalsize'] / 1024), 1) . ' Mb';
			}
			echo '</span> ' . $lang['speed']['lefttodownload2'] . ' ' . $row['files_downloading'] . ' ' . $lang['speed']['lefttodownload3'] . ', ';
			// show hard drive space left
			exec('df --block-size=1M ' . $cfg['DIRS_DOWNLOAD'] . ' | grep "/dev/"', $tmp);
			$free = (int)preg_replace("/^\/dev\/\w+\s+[\w\.]+\s+[\w\.]+\s+([\w\.]+).*$/", "$1", $tmp[0]);
			echo '<SPAN class="queueHighlight">' . $free . ' Mb</span> ' . $lang['speed']['free'] . '.<BR>';
			// time remaining
			echo ' ' . $lang['speed']['approxtimeremaining'] . ': <SPAN class="queueHighlight">' .
				post_time_elapsed('-' . (string)@round(((int)$row['totalsize'] / @round(($all_total_speeds / 1024), 0)),0) . ' seconds') . 
				'</SPAN>.<BR><BR>' . "\n";
			echo '</DIV>';
		}
		flush();

	} else {
		require_once $cfg['DIRS_WEB'] . 'gui/gui_functions.php';
		echo '<LINK rel="stylesheet" href="css/';
		$sql = 'SELECT css FROM nget_backbone'; $class_db->query_db($sql); $row = $class_db->sql_results(); echo $row['css'];
		echo '" type="text/css">';	//>>> too much overhead loading full stylesheet??
		if ($cfg['GUI_REFRESH_DAEMON_STATS'] > 0) {
			//echo '<META HTTP-EQUIV="refresh" CONTENT="' . $cfg['GUI_REFRESH_DAEMON_STATS'] . '">';
			echo '<META HTTP-EQUIV="refresh" CONTENT="' . $_SESSION['gui_refresh'] . ';URL=gui_speed.php">';
		}
		echo '</HEAD><BODY class="status">';
		flush();
		// controlling refresh
		echo '<span onclick="location.href=\'gui_speed.php?refreshswitch=1\'" TITLE="' . $lang['speed']['iframe_changerefresh1'] . ' ' . $_SESSION['gui_refresh'] . ' & ' . $_SESSION['queue_refresh'] . ' ' . $lang['speed']['iframe_changerefresh2'] . ')">';
		if ((int)exec('pidof php_ngetd') == 0) {
			echo $lang['speed']['iframe_daemonoffline'];
			flush();
		} else {
			// show current download speeds
			$sql = 'SELECT * FROM nget_backbone';
			$class_db->query_db($sql);
			$row = $class_db->sql_results();
			if ((int)$row['refresh_db'] == 1) {
				echo $lang['speed']['iframe_refreshingdb'];
				flush();
			} elseif ((int)$row['shutdown_daemon'] > 0) {
				echo $lang['speed']['iframe_killingdaemon'];
				flush();
			} elseif ((int)$row['stop_everything'] == 1) {
				echo $lang['speed']['iframe_daemonstopped'];
				flush();
			} elseif ((int)$row['currently_updating'] == 1) {
				$sql = 'SELECT message FROM logs WHERE warning=0 AND error=0 ORDER BY logs_ID DESC LIMIT 100';
				$class_db->query_db($sql);
				$oneline = null;
				while (($row = $class_db->sql_results()) && !$oneline) {
					if (preg_match("/(Update Now|One Time Update|Refreshing DB) complete/i", $row['message'])) {
						$oneline = $lang['speed']['iframe_updateheaders'];
					} elseif (preg_match("/\(\d+\/\d+\)/", $row['message'])) {
						$oneline = preg_replace("/^.*?\((\d+)\/(\d+)\).*$/", "$1/$2", $row['message']);
						$total_speed = 0;
						$total_samples = 0;
						for ($i=1; $i<=$cfg['CONCURRENT_HEADERS']; $i++) {
							//Retrieving headers 22943802-23009451 : 3888/9709/9710  40% 80486B/s 25s (1/1/2)
							$logarray = null;
							exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 1 2>/dev/null', $logarray);
							if (!preg_match("/^HEADERDONE_/", $logarray[0])) {
								$logarray = null;
								exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | grep "Retrieving headers" | tail -n 1 2>/dev/null', $logarray);
								//preg_match("/^Retrieving headers +\d+-\d+ +: +\d+\/\d+\/\d+ *(\d+)% +(\d+)B\/s.*/", $logarray[0], $matches);
								//														 [1] [ 2 ]    [3]
								//Retrieving headers 22943802-23009451 : 3888/9709/9710  40% 80486B/s 25s (1/1/2)
								//preg_match("/^Retrieving headers \d+-\d+ : \d+\/\d+\/\d+ *(\d+)% (\d+)B\/s \d+s.*$/i", $logarray[0], $matches);
								preg_match("/\s(\d+)%\s+(\d+)B/", $logarray[0], $matches);
								//<<< testing.
							/*	if (((int)$matches[1] == 0) && ((int)$matches[2] > 0) && preg_match("/^.*?\r.*?\r.*$/", $tmp)) {
									// if we caught nget right in the middle a drawing a line, go back one. it should just repeat the last value.
									$tmp = preg_replace("/^(?:.*\r)?([^\r]*?)\r[^\r]*$/", "$1", $logarray[0]);
									preg_match("/ (\d+)% +(\d+)B/", $tmp, $matches);
								}
							*/
								//preg_match("/^Retrieving headers \d+-\d+ : \d+\/\d+\/\d+ *(\d+)% (\d+)B\/s \d+s.*$/i", $logarray[0], $matches);
								// 1 = percent, 2 = speed
								if (((int)$matches[1] < 100) && $matches[2]) {
									$total_speed += (int)$matches[2];
									$total_samples++;
								}
							}
						}
						$oneline = 'H ' . $total_samples . 't ' . $oneline . ' ' . (string)convert_speed_mini($total_speed);
					}
				}
				if (!$oneline) {
					echo $lang['speed']['iframe_updateheaders'];
				} else {
					echo $oneline;
				}
				flush();
			} else {
				// check sql first before pounding log files
				if ($row['stop_downloading'] == 1) {
					$paused = true;
				} else {
					$paused = false;
				}
				$sql = 'SELECT ROUND(SUM(download_size) / 1024) AS totalsize, COUNT(*) AS files_downloading' .
					' FROM download' .
					' WHERE download_status = 0 OR download_status = 2 OR download_status = 4';
				$class_db->query_db($sql);
				$row = $class_db->sql_results();
				if ((int)$row['files_downloading'] > 0) {
					if (((int)$row['files_downloading'] > 0) && $paused) {
						// if downloads are waiting in the queue and downloading is paused
						$oneline = $lang['speed']['iframe_paused'] . ' ';
					} else {
						// if downloads waiting in the queue
						$all_current_speed = $all_total_speeds = $threads = 0;
						for ($i=1; $i <= $cfg['CONCURRENT_DOWNLOADS']; $i++) {
							$logarray = null;
							exec('tail -c 4000 '.$cfg['LOG_FILE'].$i.'.log | sed -r \'s/^.*\cM//g\' | sed -r \'s/[\r\n]//g\' | tail -n 10 2>/dev/null', $logarray);
							// reset vars for next thread
							$current_speed = $current_part = $total_parts = 0;
							//$total_speed = 0;
							//$total_samples = 0;
							$xfer_complete = false;
							
							for ($j=9; $j >= 0; $j--) {
								//        [1] [2]                            [3] [ 4 ]
								//6003728 (11/48): 1280/2544L 167363/331528B 50% 33472B/s 4s 0/1 6m11s
								//preg_match("/^\s*\d+\s*\((\d+)\/(\d+)\):\s*\d+\/\d+L\s*\d+\/\d+B\s*(\d+)%\s*(\d+)B\/s\s*[\dms]+\s*\d\/\d\s*[\dms]+\s*$/i", $logarray[$j], $matches);
								preg_match("/^\s*\d+\s*\((\d+)\/(\d+)\):\s*\d+\/\d+L\s*\d+\/\d+B\s*(\d+)%\s*(\d+)B\/s\s*[\dms]+\s*\d\/\d\s*[\dms]+.*$/i", $logarray[$j], $matches);
								// [1] = part on, [2] = parts total, [3] = percent of part downloaded, [4] = speed B/s
								if (($current_speed == 0) && ($matches[4]) && (!$xfer_complete)) {
									$current_speed = (int)$matches[4];
									$current_part = (int)$matches[1];
									$total_parts = (int)$matches[2];
								}
								/*if ($matches[3] && (!$xfer_complete)) {
									$total_speed += (int)$matches[4];
									$total_samples++;
								}*/
								if (($current_part == $total_parts) && ($total_parts > 0) && ((int)$matches[3] == 100)) {
									// if download is complete then download speed = 0
									$current_speed = 0;
									break;
								}
							}
							// write a function for the 'divide by zero' shit
							$all_current_speed += $current_speed;
							if ($current_speed > 0) {
								$threads++;
							}
						}
						
						$oneline = $threads . 't  ' . (string)convert_speed_mini($all_current_speed) . ' ';
					}
					
					// show total left to download
					
					//echo 'Left to download : ';
					if ((int)$row['totalsize'] < (1000)) {
						// under 1000k
						$oneline .= (string)$row['totalsize'] . 'K';
					} elseif ((int)$row['totalsize'] < (1024*1000)) {
						// under 1000 megs
						$oneline .= (string)round(((int)$row['totalsize'] / 1024)) . 'M';
					} else {
						// in gigabytes
						$oneline .= (string)round(((int)$row['totalsize'] / (1024*1024)), 1) . 'G';
					}
			
					echo 'D ' . $oneline;
				} else {
					echo $lang['speed']['iframe_daemonidle'];
				}
				flush();
			}
		}
		echo '</span>';
	}
	echo '</BODY></HTML>';
	
	// convert to k/s
	function convert_speed_mini($bytes_per_sec) {
		// dialup users may want it displayed in bytes
//		if ($bytes_per_sec <= 4096) {
//			return $bytes_per_sec . 'b/s';
//		} else {
			return round($bytes_per_sec / 1024) . 'k/s';
//		}	
	}
	
	//<<< control these colors via style sheets
	function drawDownloadMeter($percent) {
		return '<TABLE CELLPADDING=0 CELLSPACING=0 class="downloadMeter"><TR>' .
			'<TD style="width:' . (int)$percent . '%;" class="downloadMeterDownloaded"></TD>' .
			'<TD style="width:' . (100 - (int)$percent) . '%;" class="downloadMeterRemaining"></TD>' .
			'</TR></TABLE>';
	}

?>
