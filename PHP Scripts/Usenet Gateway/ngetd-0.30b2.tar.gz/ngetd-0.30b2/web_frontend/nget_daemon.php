<?

	// ngetdaemon daemon. This is not to be accessed via apache! Start from the command line.

	set_time_limit(0);			// no time limit for daemon
	
	require_once 'config.php';											// config file
	require_once $cfg["DIRS_WEB"] . 'daemon/functions.php';				// simple functions
	require_once $cfg["DIRS_WEB"] . 'daemon/class_post_process.php';	// processing of info taken from the cache file
	require_once $cfg["DIRS_WEB"] . 'daemon/class_cache_file.php';		// handling of the cache file
	require_once $cfg["DIRS_WEB"] . 'daemon/class_db_control.php';		// handling of all db functions
	require_once $cfg["DIRS_WEB"] . 'daemon/class_group_process.php';	// processing of 'file_groups'
	require_once $cfg["DIRS_WEB"] . 'daemon/class_groups_control.php';	// handling of groups
	require_once $cfg["DIRS_WEB"] . 'daemon/class_xpost_process.php';	// processing of crossposting and other processing functions
	require_once $cfg["DIRS_WEB"] . 'daemon/class_nget_control.php';	// handling of nget program
	$cfg['lang'] = &$lang;												// append language array
	
	$ngetdb = new db_control($cfg);

/* ---------------------------------------------------------------------------
	Initialize classes.
   ------------------------------------------------------------------------ */
	// nget control
	$ngetcontrol = new nget_control($cfg);
	// set internal classes
	$ngetcontrol->class_db = new db_control($cfg);
  
 	// using groups
	$ngetgroups = new groups_control();
	// set internal classes
	$ngetgroups->class_db = new db_control($cfg);
	
	// processing of post vars
	$ngetpp = new post_process($cfg);
	// set internal classes
	$ngetpp->class_db = new db_control($cfg);
	$ngetpp->class_cache = new cache_file($cfg);
	// set internal variables
	$ngetpp->file_ext = get_file_ext();
   
	// processing of 'file groups'
	$ngetfilegroups = new group_process($cfg);
	// set internal classes
	$ngetfilegroups->class_db = new db_control($cfg);
	// set internal variables
	$ngetfilegroups->file_ext_video = get_file_ext_video();
	
	// process crossposting in groups
	$ngetxpost = new xpost_process($cfg);
	// set internal classes
	$ngetxpost->class_db = new db_control($cfg);
	
/* ---------------------------------------------------------------------------
	Start the daemon.
   ------------------------------------------------------------------------ */
	
   	// sanity check
	$ngetdb->event_logging($cfg['lang']['daemon']['performingsanitycheck'], 0, 0);
	// set all 'currently downloading' files to 'unknown'
	$sql = 'UPDATE download SET download_status = 10 WHERE download_status = 2';
	$ngetdb->write_db($sql);
	// reset 'updating' flag
	$sql = 'UPDATE nget_backbone SET currently_updating = 0';
	$ngetdb->write_db($sql);
	// trim logs/downloads and set when trimmed
	trim_logs();
	$logs_trimmed = time();
	// optimize tables
	$ngetdb->optimize_table('blacklist, download, file_crossposts, file_crossposts_groups, file_groups, group_type, groups, logs, nget_backbone, posts, wishlist');
	// status
	$ngetdb->set_current_status($cfg['lang']['daemon']['ngetdaemonstarted']);
	
	do {
		// refresh groups arrays from db
		$ngetgroups->groups_control_init();

		// check hourly if logs/downloads need trimming
		if (($logs_trimmed + 3600) < time()) {
			trim_logs();
			$logs_trimmed = time();
		}
		
		// poll db
		$sql = 'SELECT * FROM nget_backbone';
		$ngetdb->query_db($sql);
		$nget_backbone = $ngetdb->sql_results();
		$ngetdb->free_query();
		
		// check for queued downloads
		$sql = 'SELECT COUNT(*) AS files FROM download' .
			' WHERE (download_file_group_ID != 0 AND (download_status != 4 OR download_status = 99)) OR' .
			'(download_post_ID != 0 AND (download_status = 0 OR download_status = 99))';
		$ngetdb->query_db($sql);
		$row = $ngetdb->sql_results();
		$dl_files = (int)$row['files'];
		$ngetdb->free_query();
		if ($dl_files > 0) {
			// if filegroups, then process them into files, files+nfo+pars etc.
			$ngetcontrol->process_dl_filegroups();
			// check and prepare new downloads
			$ngetcontrol->process_dl_files();
		}

		// PRIORITY : stop_everything / refresh db / update_now / one_time_update / downloading queued files / autoupdate

/*		if ((int)$nget_backbone['shutdown_daemon'] == 1) {
		// restart immediately
			$ngetdb->set_current_status($cfg['lang']['daemon']['restartingdaemon']);
			$sql = 'UPDATE nget_backbone SET shutdown_daemon = 0';
			$ngetdb->write_db($sql);
			exit();
	//	} elseif ((int)$nget_backbone['shutdown_daemon'] == 2) {
*/		if ((int)$nget_backbone['shutdown_daemon'] == 2) {
		// shutdown immediately
			$ngetdb->set_current_status($cfg['lang']['daemon']['shuttingdowndaemon']);
			$sql = 'UPDATE nget_backbone SET shutdown_daemon = 0';
			$ngetdb->write_db($sql);
			exit();
		} elseif ((int)$nget_backbone['stop_everything'] !== 1) {
		// check to see if 'stop_everything' is flagged
		
			if ((int)$nget_backbone['refresh_db'] == 1) {
				// refresh all tables
				// status
				$ngetdb->set_current_status($cfg['lang']['daemon']['refreshingdb']);
				$ngetdb->set_currently_updating(true);
				$tmpa = array();
				// clear out tables completly
				$sql = 'TRUNCATE posts';
				$ngetdb->write_db($sql);
				$sql = 'TRUNCATE file_groups';
				$ngetdb->write_db($sql);
				$ngetgroups->set_first_group();
				while ($ngetgroups->get_current_group()) {
					// update headers
					process_header_update($ngetgroups->get_current_group());
					$ngetgroups->get_next_group();
				}
				// process blacklists
				process_blacklists();
				// process crossposting
				process_crossposts();
				// process downloads
				process_downloads();
				// update all group stats
				update_group_stats();
				// reset refresh db flag
				$sql = 'UPDATE nget_backbone SET refresh_db=0';
				$ngetdb->write_db($sql);
				// status
				$ngetdb->set_currently_updating(false);
				$ngetdb->set_current_status($cfg['lang']['daemon']['refreshingdbcomplete']);
			
			} elseif ((int)$nget_backbone['update_now'] == 1) { 
			// check if 'update_now' is flagged, if so update all groups immediately
				// status
				$ngetdb->set_current_status($cfg['lang']['daemon']['updatinggroupsupdatenow']);
				$ngetdb->set_currently_updating(true);
				$ngetdb->event_logging($cfg['lang']['daemon']['pruningoldheaders'], 0, 0);
				// prune old headers/downloads, necessary for removing dated posts from rarely updated groups
				$sql = 'DELETE FROM posts' .
					' WHERE post_time < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['POSTS_DELETE_TIME'] * 60))) . '"';
				$ngetdb->write_db($sql);
				$sql = 'DELETE FROM download' .
					' WHERE download_date < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['POSTS_DELETE_TIME'] * 60))) . '"';
				$ngetdb->write_db($sql);
				// update last_autoupdate when starting
				$sql = 'UPDATE nget_backbone SET last_autoupdate=current_autoupdate, current_autoupdate = NOW()';
				$ngetdb->write_db($sql);
				// check each group and see if active
				$tmpa = array();
				$ngetgroups->set_first_group();
				while ($ngetgroups->get_current_group()) {
					if ($ngetgroups->is_group_active() || $ngetgroups->is_group_active_onetime()) {
						array_push($tmpa, $ngetgroups->get_current_group());
					}
					$ngetgroups->get_next_group();
				}
				queue_header_update($tmpa);
				// reset one time groups
				$sql = 'UPDATE groups SET group_active_onetime=0';
				$ngetdb->write_db($sql);
				// update all group stats
				update_group_stats();
				// reset update now flag
				$sql = 'UPDATE nget_backbone SET update_now=0';
				$ngetdb->write_db($sql);
				// status
				$ngetdb->set_currently_updating(false);
				$ngetdb->set_current_status($cfg['lang']['daemon']['updatenowcomplete']);

			} elseif ((int)$nget_backbone['one_time_update'] == 1) { 
			// check if certain groups are to be updated immediately
				// status
				$ngetdb->set_current_status($cfg['lang']['daemon']['updatinggroupsonetime']);
				$ngetdb->set_currently_updating(true);
				// this will have to check each group and see which have the autoupdate flag
				$tmpa = array();
				$ngetgroups->set_first_group();
				while ($ngetgroups->get_current_group()) {
					if ($ngetgroups->is_group_active_onetime()) {
						array_push($tmpa, $ngetgroups->get_current_group());
					}
					$ngetgroups->get_next_group();
				}
				queue_header_update($tmpa);
				$sql = 'UPDATE groups SET group_active_onetime=0';
				$ngetdb->write_db($sql);
				// update all group stats
				update_group_stats();
				// reset one time groups
				$sql = 'UPDATE nget_backbone SET one_time_update=0';
				$ngetdb->write_db($sql);
				// status
				$ngetdb->set_currently_updating(false);
				$ngetdb->set_current_status($cfg['lang']['daemon']['onetimeupdatecomplete']);
				
			} elseif (($dl_files > 0) && ((int)$nget_backbone['stop_downloading'] == 0) &&
				(((strtotime('now') > (strtotime(date('Y-m-d ', time()) . ' ' . $cfg['DOWNLOAD_START_TIME']))) && 
				(strtotime('now') < (strtotime(date('Y-m-d ', time()) . ' ' . $cfg['DOWNLOAD_END_TIME'])))) ||	
				!$cfg['DOWNLOAD_START_TIME'])) {
			//check to see if pending downloads
				// throw a file in the queue, then re-poll. don't go too crazy too fast or get 'too many connections'...
				$ngetcontrol->check_active_processes();
				if ($ngetcontrol->is_unused_processes()) {
					$tmp = $ngetcontrol->download_queued_file();
					if ($tmp) {
						$ngetdb->event_logging($cfg['lang']['daemon']['downloadingfile'] . ' - ' . $tmp, 0, 0);
					} else {
						// no filename
						$ngetdb->event_logging($cfg['lang']['daemon']['downloadingfile'] . $tmp, 0, 0);
					}
				}
			
			} elseif ($ngetcontrol->is_active_processes()) {
				// active processes, monitor and release them
				$ngetcontrol->check_active_processes();
				
			} elseif ((int)$nget_backbone['stop_autoupdate'] == 0) { 
			// autoupdate check
				// if last autoupdate was more then 24hrs ago || last autoupdate was before _time today && it's after _time now
				if (((strtotime($nget_backbone['current_autoupdate']) + (24*60*60)) < time()) ||
					((strtotime($nget_backbone['current_autoupdate']) < strtotime(date('Y-m-d', time()) . ' ' . $nget_backbone['autoupdate_time'])) &&
					(time() > strtotime(date('Y-m-d', time()) . ' ' . $nget_backbone['autoupdate_time'])))) {
					// status
					$ngetdb->set_current_status($cfg['lang']['daemon']['updatinggroupsautoupdate']);
					$ngetdb->set_currently_updating(true);
					$ngetdb->event_logging($cfg['lang']['daemon']['pruningoldheaders'], 0, 0);
					// prune old headers/downloads, necessary for removing dated posts from rarely updated groups
					$sql = 'DELETE FROM posts' .
						' WHERE post_time < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['POSTS_DELETE_TIME'] * 60))) . '"';
					$ngetdb->write_db($sql);
					$sql = 'DELETE FROM download' .
						' WHERE download_date < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['POSTS_DELETE_TIME'] * 60))) . '"';
					$ngetdb->write_db($sql);
					// update last_autoupdate when starting
					$sql = 'UPDATE nget_backbone SET last_autoupdate=current_autoupdate, current_autoupdate = NOW()';
					$ngetdb->write_db($sql);
					// this will have to check each group and see if active
					$tmpa = array();
					$ngetgroups->set_first_group();
					while ($ngetgroups->get_current_group()) {
						if ($ngetgroups->is_group_active() || $ngetgroups->is_group_active_onetime()) {
							array_push($tmpa, $ngetgroups->get_current_group());
						}
						$ngetgroups->get_next_group();
					}
					queue_header_update($tmpa);
					// update all group stats
					update_group_stats();
					// reset one time groups
					$sql = 'UPDATE groups SET group_active_onetime=0';
					$ngetdb->write_db($sql);
					// status
					$ngetdb->set_currently_updating(false);
					$ngetdb->set_current_status($cfg['lang']['daemon']['autoupdatecomplete']);
				}
			}
		}
		
		sleep($cfg['DAEMON_POLLING_INTERNAL']);		// poll everything every x seconds
		
	} while (1);	// end of all-encompassing do statement.


	// controls the queuing functions in class_nget_control, downloads via nget and updates into mysql simultaneously
	function queue_header_update($group_id_array) {
		// set globals
		global $ngetcontrol;
		global $ngetdb;
		global $ngetgroups;
		global $cfg;
		
		// set statuses
		$ngetdb->event_logging($cfg['lang']['daemon']['updatingheaders'], 0, 0);
		$total_groups = count($group_id_array);
		// change number of concurrent connections allowed
		$ngetcontrol->set_concurrent($cfg['CONCURRENT_HEADERS']);
		$unprocessed = array();
		
		while ((count($group_id_array) > 0) || $ngetcontrol->is_active_processes()) {
			// build a queue of unprocessed groups to be processed
			while ($tmp = $ngetcontrol->check_active_processes()) {
				array_push($unprocessed, $tmp);
			}
			// fill up all possible slots for downloading headers
			while (($ngetcontrol->is_unused_processes()) && (count($group_id_array) > 0)) {
				$tmp = array_shift($group_id_array);
				// status
				$ngetdb->event_logging($cfg['lang']['daemon']['queuinggroup'] . ' - ' . $ngetgroups->get_specific_group_name($tmp) .
					' (' . ($total_groups - count($group_id_array)) . '/' . $total_groups . ')', 0, 0);
				$ngetcontrol->refresh_headers($tmp, $ngetgroups->get_specific_group_name($tmp), 0);
			}
			// after all queues are 'emptied' and filled back up, process a waiting group
			if (count($unprocessed) > 0) {
				// check return ids, if one exists then process that group. only do one at a time before requeueing
				$tmp = array_shift($unprocessed);
				process_header_update($tmp);
				// set date for last updated (kept here so refreshing db won't change last header refresh)
				$sql = 'UPDATE groups SET group_last_update = now() WHERE group_ID=' . $tmp;
				$ngetdb->write_db($sql);
			}
			
			sleep($cfg['DAEMON_POLLING_INTERNAL']);	// poll everything every x seconds
		}
		
		// complete queue of unprocessed groups to be processed
		while ($tmp = $ngetcontrol->check_active_processes()) {
			array_push($unprocessed, $tmp);
		}
		// downloading headers is complete, finish processing of cache files
		while ($tmp = array_shift($unprocessed)) {
			process_header_update($tmp);
			// set date for last updated (kept here so refreshing db won't change last header refresh)
			$sql = 'UPDATE groups SET group_last_update = now() WHERE group_ID=' . $tmp;
			$ngetdb->write_db($sql);
		}
		
		// process blacklists
		process_blacklists();
		// process crossposting
		process_crossposts();
		// process downloads
		process_downloads();
		
		// reset back to default
		$ngetcontrol->set_concurrent($cfg['CONCURRENT_DOWNLOADS']);
	}
	
	// update stats for all groups
	function update_group_stats() {
		global $ngetgroups;
		global $ngetpp;
		global $ngetdb;
		global $cfg;
		
		$ngetgroups->set_first_group();
		while ($ngetgroups->get_current_group()) {
			// update number of good posts
			$ngetpp->update_good_posts($ngetgroups->get_current_group());
			$ngetgroups->get_next_group();
		}
		// status
		$ngetdb->event_logging($cfg['lang']['daemon']['groupstatsrefreshed'], 0, 0);
	}
	
	// process posts after header update
	function process_header_update($group_number) {
		// set globals
		global $ngetpp;
		global $ngetfilegroups;
		global $ngetgroups;
		global $ngetxpost;
		global $ngetdb;
		global $cfg;
		
		// status
		$ngetdb->event_logging($cfg['lang']['daemon']['processingpostsongroup'] . ' - ' . $ngetgroups->get_specific_group_name($group_number), 0, 0);
		// process posts
		$ngetpp->process_cache($ngetgroups->get_specific_group_name($group_number), $group_number);
		// wipe out bad post floods
		if ($cfg['ENABLE_REMOVE_JUNK_FLOODS']) {
			$ngetxpost->delete_bad_floods($group_number);
		}
		// sorts posts into groups
		$ngetfilegroups->process_filegroups($group_number, $ngetgroups->get_specific_group_method($group_number));
	}
	
	function process_crossposts() {
		// set globals
		global $ngetxpost;
		global $ngetdb;
		global $cfg;
		
		// status
		$ngetdb->event_logging($cfg['lang']['daemon']['processingcrossposting'], 0, 0);
		// detect crossposts
		$ngetxpost->detect_xpost_files();
		// detect crossposts in groups
		$ngetxpost->detect_xpost_filegroups();
		// optimize all tables since overhead seems to sneak in everywhere
		$ngetdb->optimize_table('blacklist, download, file_crossposts, file_crossposts_groups, file_groups, group_type, groups, logs, nget_backbone, posts, wishlist');
	}
	
	function process_blacklists() {
		// set globals
		global $ngetxpost;
		global $ngetdb;
		global $cfg;
		
		if ($cfg['ENABLE_BLACKLISTS']) {
			// status
			$ngetdb->event_logging($cfg['lang']['daemon']['processingblacklists'], 0, 0);
			$ngetxpost->update_blacklists();
		}
	}
	
	function process_downloads() {
		// set globals
		global $ngetxpost;
		global $ngetdb;
		global $cfg;
		
		// status
		$ngetdb->event_logging($cfg['lang']['daemon']['processingdownloads'], 0, 0);
		$ngetxpost->update_downloads();
	}
	
	function trim_logs() {
		// set globals
		global $ngetdb;
		global $cfg;
		
		// trim daemon logs
		$sql = 'DELETE FROM logs ' .
			' WHERE stamp < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['DAEMON_LOG_DELETE_TIME'] * 60))) . '"';
		$ngetdb->write_db($sql);
		// trim download queue
		$sql = 'DELETE FROM download ' .
			' WHERE download_post_time < "' . date('Y-m-d H:i:s', (time() - ((int)$cfg['POSTS_DELETE_TIME'] * 60))) . '"';
		$ngetdb->write_db($sql);
	}
?>