<?

	# Just a large regex
	$pseudowishlist = "/(";
	#food
	$pseudowishlist .= "i.like.food|food.is.good";
	#cheese
	$pseudowishlist .= "|juicy.burger|juicy.fries";
	$pseudowishlist .= ")/i";
		
?>
