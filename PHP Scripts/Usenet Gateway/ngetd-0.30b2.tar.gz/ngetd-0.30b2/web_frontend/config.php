<?

	// current version of ngetdaemon
	$nget_version = "ngetdaemon v0.30b2";
	
// options commented out have not yet been implemented

	$cfg = array();
	// Database settings
	$cfg["DBHOST"] = "localhost";				// address
	$cfg["DBNAME"] = "ngetdaemon";				// database name
	$cfg["DBUSER"] = "nget";					// db username
	$cfg["DBPASS"] = "nget";					// db password
	$cfg["DBMULTI"] = 250;						// how many multiple inserts to perform at once (less db pounding / faster)
	$cfg["SQL_BATCH"] = 20000;					// how many rows to return at once, only affects gui>stats page (keep from filling memory)
	
	// Directories
	$cfg["PROG_HEADER"] = "/nntp/nget_headers.sh";	// bash script for updating headers
	$cfg["PROG_DOWNLD"] = "/nntp/nget_download.sh";	// bash script for downloading posts
	$cfg["LOG_FILE"] = "/nntp/process-";		// log filename prefix (where nget output is dumped)
	// leave trailing slash for following
	$cfg["DIRS_WEB"] = "/home/sites/ngetdaemon/";	// where nget is installed for apache
	$cfg["DIRS_CACHE"] = "/nntp/cache/";		// nget caching dir (where headers are saved)
//	$cfg["DIRS_TEMP"] = "/nntp/temp/";		// nget temp dir (where posts are temporairly stored when downloaded before decoding)
//	$cfg["DIRS_LOG"] = "/nntp/logs/";			// where nget output is logged if $cfg["ENABLE_NGET_LOGGING"] is set
	$cfg["DIRS_DOWNLOAD"] = "/nntp/files/";	// where all downloads are stored
//	$cfg["DIRS_CONFIG"] = "/nntp/.nget5/";	// where .ngetrc file is stored, also where nget stores it's list of what has been downloaded

	// choose language
	require_once($cfg["DIRS_WEB"] . 'languages/lang_english.php');
	//require_once($cfg["DIRS_WEB"] . 'languages/lang_french.php');

	// Usenet provider settings
	$cfg["CONCURRENT_HEADERS"] = 1;				// how many concurrent header downloads to have running (how many connections allowed)
	$cfg["CONCURRENT_DOWNLOADS"] = 2;			// how many concurrent post downloads to have running (how many connections allowed)
	$cfg["SERVER_LAG"] = 90;					// in minutes, approximately how old the 'newest' downloaded headers are
	
	// daemon/nget control
	$cfg["MAX_RETRY_HEADERS"] = 5;				// how many times to retry downloading headers before giving up
	$cfg["RETRY_HEADERS_DELAY"] = 20;			// pause in seconds between tries
	$cfg["MAX_RETRY_DOWNLOADS"] = 5;			// how many times to retry downloading posts before giving up
	$cfg["RETRY_DOWNLOADS_DELAY"] = 20;			// pause in seconds between tries
//	$cfg["AUTOPAR_DOWNLOADS"] = true;			// use nget's built-in method for testing and completing downloads
	$cfg["DAEMON_POLLING_INTERNAL"] = 3;		// seconds to wait before repolling the DB for something to do
	$cfg["DOWNLOAD_START_TIME"] = false;		// start and end time for when daemon downloads files, set start time to false to disable
	$cfg["DOWNLOAD_END_TIME"] = "08:00:00";		// must be in 24hr clock (midnight = "00:00:00", noon = "12:00:00") 
	
	// Header control
	$cfg["POSTS_OLD_TIME"] = 60 * 24 * 35;		// when a post is marked as 'old', in minutes
	$cfg["POSTS_DELETE_TIME"] = 60 * 24 * 45;	// when a post should be deleted, in minutes - both for predicting retention
	$cfg["ENABLE_BLACKLISTS"] = true;			// enable processing of blacklists
//	$cfg["ENABLE_WISHLISTS"] = true;			// enable processing of wishlists
	$cfg["ENABLE_REMOVE_JUNK_FLOODS"] = true;	// remove all posts from a poster who uploaded a large amount of only incomplete files
	$cfg["INCOMPLETES_IN_HEADERS"] = false;		// include incomplete posts in header count
	$cfg["INCOMPLETES_IN_SIZE"] = true;			// include incomplete posts when caculating size for a file group
//	$cfg["INCLUDE_INCOMPLETES"] = false;		// when downloading file groups, download incompletes as well (still calc pars for incompletes)

	// GUI options
	$cfg["GUI_REFRESH_LOGS"] = 60;				// in seconds, refresh 'view download queue' and 'view daemon log' pages, 0 disables
	$cfg["GUI_REFRESH_DAEMON_STATS"] = 5;		// in seconds, refresh onscreen daemon statistics iframe (top right of screen), 0 disables
	$cfg["GUI_REFRESH_DAEMON_STATS_SLOW"] = 60;	// click on 'daemon stats' iframe to change between speeds
	$cfg["GUI_REFRESH_QUEUE_STATS"] = 10;		// in seconds, refresh transfer stats on 'download queue' iframe, 0 disables
	$cfg["GUI_REFRESH_QUEUE_STATS_SLOW"] = 120;	// click on 'daemon stats' iframe to change between speeds
	//$cfg["GUI_CSS"] = "nget_black.css";		// style sheet for GUI (unused as of 0.26)
//	$cfg["ENABLE_JPGRAPH"] = true;				// disable jpgraphing if you do not want this feature/do not have installed
	$cfg["GUI_SHOW_QUEUED"] = 10;				// number of queued files to show on 'download queue' page, rest will be hidden
	$cfg["GUI_SHOW_DOWNLOADED"] = 10;			// number of downloaded files to show on 'download queue' page, rest will be hidden

	// logging
	$cfg["DAEMON_LOG_DELETE_TIME"] = 60 * 72;	// when the log should be trimmed, in minutes
//	$cfg["DAEMON_LOGGING_VERBOSITY"] = 1;		// 0-3, decide what is logged or not later...
//	$cfg["ENABLE_NGET_LOGGING"] = true;			// enable saving of nget output into the log dir for each invocation

?>
