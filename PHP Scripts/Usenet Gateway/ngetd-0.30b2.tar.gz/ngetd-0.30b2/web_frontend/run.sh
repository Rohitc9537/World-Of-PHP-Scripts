#!/bin/sh
#kill `pidof php_ngetd`
NGETD=/home/sites/ngetdaemon

killall php_ngetd 2>&1 >/dev/null
nice -n 15 $NGETD/php_ngetd $NGETD/nget_daemon.php > $NGETD/test.log 2>&1 &

