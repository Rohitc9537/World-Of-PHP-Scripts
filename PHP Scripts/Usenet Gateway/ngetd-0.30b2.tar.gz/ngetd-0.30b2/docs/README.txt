0. Requirements

Apache 1.3.x / 2.x 
PHP 4.3.4+ / 5.x, will need to compile with '--with-zlib --with-mysql', and '--with-gd --with-ttf --with-freetype-dir=[freetype dir]' to use jpgraph
MySQL 4.0.11a-gamma+ (untested for earlier versions, but version 4+ is a must)
nget 0.27+
jpgraph (optional)


1. About ngetd

The whole point of this program was to make a way of perusing and downloading from usenet remotely, and to do it quickly and efficiently. Updating and sorting of all headers is done with one click. The strongest feature is that posts are grouped together in 'file groups', meaning a post consisting of 100 files is compacted into one line and determined if complete, incomplete, par fills, etc. There are no pretty buttons, animations, etc. Everything is designed to be as little strain on bandwidth as possible. 


2. How to works

When the nget_daemon is started, it continously polls the MySQL DB waiting for something to do. This is how the GUI controls the daemon. Using nget (nget.sourceforge.net) as it's backend, it downloads headers and then parses nget's cache files and dumps the information into a MySQL database. Downloading and parsing of headers are done in parallel to minimize time spent waiting. All processing is done in this step so when searching the headers there is no additional overhead, only on MySQL. Downloading is also controlled through nget. Archive-type files and mp3s are grouped, graphic files are not grouped.


3. Installation

1. get jpgraph (http://www.aditus.nu/jpgraph/), copy the contents of dir 'src' to negtd web dir 'jpgraph'. You can delete the examples folder within.
2. edit config.php and set your dirs
3. edit nget_download.sh & nget_headers.sh to your dirs
4. make graphs dir writable by apache
5. make link to php executable in web dir, 'ln -s `which php` php_ngetd', this will be for the future init.d script.
6. create the db 'mysqladmin create ngetdaemon' to whichever name you specify in config.php, then 'mysql [tablename] < ngetd.sql'
7. start with 'su apache -c ./run.sh' , chanage apache to www or whwtaver permissions you have it running under. This way it can be
restarted from the GUI and keep the same permissions on the files it creates.
8. Point your browser to the GUI and go

Remember that most problems you initially encounter with installing and running nget is permissions. Make sure you have .ngetrc working and all permissions are set properly. It may be a good idea to make a nget user/group to sandbox the whole process.

To save some space you can make a bash script in cron.hourly as such:
/usr/sbin/tmpwatch -m 60 /nntp/cache /nntp/logs /nntp/temp
change 60 to whatever the retention time of your server is.


4. CSS and JavaScript

The color scheme is controlled entirely by stylesheets. All javascript is in nget.js, it has been tested with IE6, MOZ1.6, Firefox1.0 . I have NO intention of making it work with anything else (eg. Netscape 4, Opera)


5. Credit

I downloaded ngetcgi, read the code, didn't try it. Downloaded ngetw, couldn't get it to fully work in about twenty minutes, gave up, read the code for some ideas. Started writing my own...

