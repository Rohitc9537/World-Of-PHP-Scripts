ALTER TABLE download ADD INDEX polling (download_file_group_ID, download_post_ID, download_status);
ALTER TABLE download ADD INDEX guiqueue1 (download_status, download_date);
ALTER TABLE download ADD INDEX guiqueue2 (download_custom_position, download_status, download_post_time);