# phpMyAdmin SQL Dump
# version 2.5.7
# http://www.phpmyadmin.net
#

# --------------------------------------------------------

#
# Table structure for table `group_type`
#

CREATE TABLE `group_type` (
  `group_type_ID` int(11) NOT NULL auto_increment,
  `group_type_name` tinytext NOT NULL,
  `group_type_method` smallint(6) NOT NULL default '0',
  `group_type_parent_ID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`group_type_ID`)
) TYPE=MyISAM AUTO_INCREMENT=45 ;

#
# Dumping data for table `group_type`
#

INSERT INTO `group_type` VALUES (1, 'Everything', 1, -1),
(2, 'Audio & Video', 1, 1),
(3, 'Video', 1, 2),
(4, 'Movies', 1, 3),
(5, 'DivX', 1, 4),
(6, 'DVD', 1, 4),
(7, 'SVCD', 1, 4),
(8, 'VCD & MPEG', 1, 4),
(9, 'XViD', 1, 4),
(10, 'Television', 1, 3),
(11, 'Cartoons', 1, 10),
(12, 'Sitcoms', 1, 10),
(13, 'Anime', 1, 3),
(14, 'Audio', 2, 2),
(15, 'Music', 2, 14),
(16, 'Punk', 2, 15),
(17, 'Heavy Metal', 2, 15),
(18, 'Spoken Word', 2, 14),
(19, 'Software', 1, 1),
(20, 'Games', 1, 19),
(21, 'ISO', 1, 20),
(22, 'Rips', 1, 20),
(23, 'Applications', 1, 19),
(24, 'ISO', 1, 23),
(25, '0day', 1, 23),
(26, 'Multimedia', 1, 23),
(27, 'Audio', 1, 23),
(28, 'Linux', 1, 23),
(29, 'ISO', 1, 19),
(30, 'Ebook', 1, 1),
(31, 'Technical', 1, 30),
(32, 'Emulation', 1, 20),
(33, 'Kidstuff', 1, 1),
(34, 'Games', 1, 33),
(35, 'Movies', 1, 33),
(36, 'Comedy', 1, 10),
(37, 'Horror', 1, 10),
(38, 'Misc', 2, 1),
(40, 'Bootlegs', 2, 15),
(41, 'Full Albums', 2, 15),
(42, 'Classical', 2, 15),
(43, 'Warez', 1, 33),
(44, 'Documentaries', 1, 4);

