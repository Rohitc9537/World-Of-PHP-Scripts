-- MySQL dump 9.07
--
-- Host: localhost    Database: ngetbooty
---------------------------------------------------------
-- Server version	4.0.11a-gamma

--
-- Table structure for table 'blacklist'
--

CREATE TABLE blacklist (
  blacklist_ID int(11) NOT NULL auto_increment,
  blacklist_regex tinytext,
  blacklist_filename_regex tinytext,
  blacklist_sql tinytext,
  blacklist_filename_sql tinytext,
  PRIMARY KEY  (blacklist_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'blacklist'
--

INSERT INTO blacklist VALUES (1,NULL,NULL,NULL,'Eminem');

--
-- Table structure for table 'download'
--

CREATE TABLE download (
  download_ID int(11) NOT NULL auto_increment,
  download_custom_position int(11) NOT NULL default '0',
  download_post_ID int(11) NOT NULL default '0',
  download_messageid tinytext,
  download_file_group_ID int(11) NOT NULL default '0',
  download_filename tinytext,
  download_subject tinytext,
  download_group int(11) default '0',
  download_status smallint(6) NOT NULL default '0',
  download_wishlist_ID int(11) NOT NULL default '0',
  download_date timestamp(14) NOT NULL,
  download_post_time datetime NOT NULL default '0000-00-00 00:00:00',
  download_size bigint(20) NOT NULL default '0',
  download_retry smallint(6) NOT NULL default '0',
  PRIMARY KEY  (download_ID),
  KEY polling (download_file_group_ID,download_post_ID,download_status),
  KEY guiqueue1 (download_status,download_date),
  KEY quiqueue2 (download_custom_position,download_status,download_post_time)
) TYPE=MyISAM;

--
-- Dumping data for table 'download'
--


--
-- Table structure for table 'file_crossposts'
--

CREATE TABLE file_crossposts (
  file_crossposts_ID int(11) NOT NULL auto_increment,
  post_ID_1 int(11) NOT NULL default '0',
  post_ID_2 int(11) NOT NULL default '0',
  post_ID_3 int(11) NOT NULL default '0',
  post_ID_4 int(11) NOT NULL default '0',
  post_ID_5 int(11) NOT NULL default '0',
  post_ID_6 int(11) NOT NULL default '0',
  post_ID_7 int(11) NOT NULL default '0',
  post_ID_8 int(11) NOT NULL default '0',
  post_ID_9 int(11) NOT NULL default '0',
  post_ID_10 int(11) NOT NULL default '0',
  PRIMARY KEY  (file_crossposts_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'file_crossposts'
--


--
-- Table structure for table 'file_crossposts_group'
--

CREATE TABLE file_crossposts_group (
  file_crossposts_group_ID int(11) NOT NULL auto_increment,
  file_group_ID_10 int(11) NOT NULL default '0',
  file_group_ID_1 int(11) NOT NULL default '0',
  file_group_ID_2 int(11) NOT NULL default '0',
  file_group_ID_3 int(11) NOT NULL default '0',
  file_group_ID_4 int(11) NOT NULL default '0',
  file_group_ID_5 int(11) NOT NULL default '0',
  file_group_ID_6 int(11) NOT NULL default '0',
  file_group_ID_7 int(11) NOT NULL default '0',
  file_group_ID_8 int(11) NOT NULL default '0',
  file_group_ID_9 int(11) NOT NULL default '0',
  PRIMARY KEY  (file_crossposts_group_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'file_crossposts_group'
--


--
-- Table structure for table 'file_groups'
--

CREATE TABLE file_groups (
  file_group_ID int(11) NOT NULL auto_increment,
  file_post_first tinytext,
  file_number_par smallint(6) NOT NULL default '0',
  file_blocks_par2 smallint(6) NOT NULL default '0',
  file_total_size int(11) NOT NULL default '0',
  file_post_nfo_ID int(11) NOT NULL default '0',
  file_complete smallint(6) NOT NULL default '0',
  file_parts smallint(6) NOT NULL default '0',
  file_parts_total smallint(6) NOT NULL default '0',
  file_post_first_ID int(11) NOT NULL default '0',
  file_post_sample_ID int(11) NOT NULL default '0',
  file_post_par_ID int(11) NOT NULL default '0',
  file_post_par2_ID int(11) NOT NULL default '0',
  file_post_sfv_ID int(11) NOT NULL default '0',
  file_zips smallint(6) NOT NULL default '0',
  file_zips_total smallint(6) NOT NULL default '0',
  file_date_newest datetime default NULL,
  file_date_oldest datetime default NULL,
  file_xpost int(11) NOT NULL default '0',
  PRIMARY KEY  (file_group_ID),
  KEY file_post_first_ID (file_post_first_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'file_groups'
--


--
-- Table structure for table 'group_type'
--

CREATE TABLE group_type (
  group_type_ID int(11) NOT NULL auto_increment,
  group_type_name tinytext NOT NULL,
  group_type_method smallint(6) NOT NULL default '0',
  group_type_parent_ID int(11) NOT NULL default '0',
  PRIMARY KEY  (group_type_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'group_type'
--

INSERT INTO group_type VALUES (1,'Everything',1,-1);
INSERT INTO group_type VALUES (2,'Audio & Video',1,1);
INSERT INTO group_type VALUES (3,'Video',1,2);
INSERT INTO group_type VALUES (4,'Movies',1,3);
INSERT INTO group_type VALUES (5,'DivX',1,4);
INSERT INTO group_type VALUES (6,'DVD',1,4);
INSERT INTO group_type VALUES (7,'SVCD',1,4);
INSERT INTO group_type VALUES (8,'VCD & MPEG',1,4);
INSERT INTO group_type VALUES (9,'XViD',1,4);
INSERT INTO group_type VALUES (10,'Television',1,3);
INSERT INTO group_type VALUES (11,'Cartoons',1,10);
INSERT INTO group_type VALUES (12,'Sitcoms',1,10);
INSERT INTO group_type VALUES (13,'Anime',1,3);
INSERT INTO group_type VALUES (14,'Audio',2,2);
INSERT INTO group_type VALUES (15,'Music',2,14);
INSERT INTO group_type VALUES (16,'Punk',2,15);
INSERT INTO group_type VALUES (17,'Heavy Metal',2,15);
INSERT INTO group_type VALUES (18,'Spoken Word',2,14);
INSERT INTO group_type VALUES (19,'Software',1,1);
INSERT INTO group_type VALUES (20,'Games',1,19);
INSERT INTO group_type VALUES (21,'ISO',1,20);
INSERT INTO group_type VALUES (22,'Rips',1,20);
INSERT INTO group_type VALUES (23,'Applications',1,19);
INSERT INTO group_type VALUES (24,'ISO',1,23);
INSERT INTO group_type VALUES (25,'0day',1,23);
INSERT INTO group_type VALUES (26,'Multimedia',1,23);
INSERT INTO group_type VALUES (27,'Audio',1,23);
INSERT INTO group_type VALUES (28,'Linux',1,23);
INSERT INTO group_type VALUES (29,'ISO',1,19);
INSERT INTO group_type VALUES (30,'Ebook',1,1);
INSERT INTO group_type VALUES (31,'Technical',1,30);
INSERT INTO group_type VALUES (32,'Emulation',1,20);
INSERT INTO group_type VALUES (33,'Kidstuff',1,1);
INSERT INTO group_type VALUES (34,'Games',1,33);
INSERT INTO group_type VALUES (35,'Movies',1,33);
INSERT INTO group_type VALUES (36,'Comedy',1,10);
INSERT INTO group_type VALUES (37,'Horror',1,10);
INSERT INTO group_type VALUES (38,'Misc',2,1);
INSERT INTO group_type VALUES (40,'Bootlegs',2,15);
INSERT INTO group_type VALUES (41,'Full Albums',2,15);
INSERT INTO group_type VALUES (42,'Classical',2,15);

--
-- Table structure for table 'groups'
--

CREATE TABLE groups (
  group_ID int(11) NOT NULL auto_increment,
  group_name tinytext NOT NULL,
  group_abv tinytext NOT NULL,
  group_type smallint(6) NOT NULL default '0',
  group_posts int(11) NOT NULL default '0',
  group_last_update datetime default NULL,
  group_active smallint(6) NOT NULL default '0',
  group_active_onetime smallint(6) NOT NULL default '0',
  group_desc tinytext,
  PRIMARY KEY  (group_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'groups'
--

INSERT INTO groups VALUES (1,'alt.binaries.test','ab.test',0,0,'2004-01-01 00:00:00',0,0,'');

-- Table structure for table 'logs'
--

CREATE TABLE logs (
  logs_ID bigint(20) NOT NULL auto_increment,
  stamp timestamp(14) NOT NULL,
  message tinytext NOT NULL,
  warning smallint(6) NOT NULL default '0',
  error smallint(6) NOT NULL default '0',
  PRIMARY KEY  (logs_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'logs'
--


--
-- Table structure for table 'nget_backbone'
--

CREATE TABLE nget_backbone (
  currently_updating smallint(6) NOT NULL default '0',
  current_status tinytext NOT NULL,
  stop_autoupdate smallint(6) NOT NULL default '0',
  stop_downloading smallint(6) NOT NULL default '0',
  stop_everything smallint(6) NOT NULL default '0',
  one_time_update smallint(6) NOT NULL default '0',
  update_now smallint(6) NOT NULL default '0',
  current_autoupdate datetime default NULL,
  last_autoupdate datetime default NULL,
  autoupdate_time time default NULL,
  refresh_db smallint(6) NOT NULL default '0',
  shutdown_daemon int(11) NOT NULL default '0',
  `css` varchar(255) NOT NULL default 'nget_black.css'
) TYPE=MyISAM;

--
-- Dumping data for table 'nget_backbone'
--

INSERT INTO nget_backbone VALUES (0,'New Install.',1,0,0,0,0,'2004-01-01 12:00:00','2004-01-01 12:00:00','12:00:00',0,0,'nget_black.css');

--
-- Table structure for table 'posts'
--

CREATE TABLE posts (
  post_ID int(11) NOT NULL auto_increment,
  post_subject tinytext NOT NULL,
  post_subject_ripped tinytext NOT NULL,
  post_est_filename tinytext,
  post_est_filename_ext varchar(10) default NULL,
  post_est_part smallint(6) NOT NULL default '0',
  post_est_totalparts smallint(6) NOT NULL default '0',
  post_poster tinytext,
  post_est_poster_email tinytext,
  post_est_poster_name tinytext,
  post_time datetime NOT NULL default '0000-00-00 00:00:00',
  post_parts smallint(6) NOT NULL default '0',
  post_parts_found smallint(6) NOT NULL default '0',
  post_bytes int(11) NOT NULL default '0',
  post_server smallint(6) NOT NULL default '0',
  post_bad smallint(6) NOT NULL default '0',
  post_date_added datetime NOT NULL default '0000-00-00 00:00:00',
  file_group int(11) NOT NULL default '0',
  post_group int(11) NOT NULL default '0',
  post_xpost int(11) NOT NULL default '0',
  post_messageid tinytext,
  post_blacklisted smallint(6) NOT NULL default '0',
  post_downloaded smallint(6) NOT NULL default '0',
  UNIQUE KEY post_ID (post_ID),
  KEY index_messageid (post_messageid(24))
) TYPE=MyISAM;

--
-- Dumping data for table 'posts'
--


--
-- Table structure for table 'wishlist'
--

CREATE TABLE wishlist (
  wishlist_ID int(11) NOT NULL auto_increment,
  wishlist_subject text,
  wishlist_subject_regex text,
  wishlist_filename_regex tinytext,
  wishlist_group_ID int(11) NOT NULL default '0',
  wishlist_group_type_ID int(11) NOT NULL default '0',
  wishlist_autodownload smallint(6) NOT NULL default '0',
  wishlist_descr tinytext,
  PRIMARY KEY  (wishlist_ID)
) TYPE=MyISAM;

--
-- Dumping data for table 'wishlist'
--


