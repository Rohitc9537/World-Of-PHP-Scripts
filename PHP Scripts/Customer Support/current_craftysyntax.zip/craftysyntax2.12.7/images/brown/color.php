<?php
  $color_background="ECECE4";
  $color_alt1 = "D1D1BD";
  $color_alt2 = "DBDBCC";    
  $color_alt3 = "D1D1BD";  
  $color_alt4 = "EAEAE1";
?>