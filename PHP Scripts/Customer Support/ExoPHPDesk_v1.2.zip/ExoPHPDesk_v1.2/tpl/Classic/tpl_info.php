<?php

// << -------------------------------------------------------------------- >>
// >> EXO Classic Template Configuration File
// >>
// >> TPL_INFO . PHP File - Template Configuration File
// >> Edited  : 16 December, 2003
// >>
// << -------------------------------------------------------------------- >>

// CHAT WINDOW SIZE CONFIGURATION - ADMIN/STAFF
$cwin_height = "300";
$cwin_width = "800";

// CHAT WINDOW SIZE CONFIGURATION - Members
$mwin_height = "500";
$mwin_width = "500";


?>