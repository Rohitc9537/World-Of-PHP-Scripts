<HTML>
<HEAD>
<meta http-equiv=Content-Type content="text/html;  charset=ISO-8859-1">
<TITLE>asc</TITLE>
</HEAD>
<BODY>

<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 HEIGHT="60" WIDTH="120" id="status" ALIGN="" border="0">
 <PARAM NAME=movie VALUE="status.swf"> 
 <PARAM NAME=menu VALUE=false> 
 <PARAM NAME=quality VALUE=High> <PARAM NAME=bgcolor VALUE=#ffffff> 
	<param name="salign" value="TL">
	<param name="scale" value="NoBorder">
	<EMBED src="status.swf" menu=false quality=High bgcolor=#ffffff  NAME="status" ALIGN=""
 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer" salign="TL" width="120" height="60" scale="NoBorder"></EMBED>
</OBJECT>


</BODY>
</HTML>