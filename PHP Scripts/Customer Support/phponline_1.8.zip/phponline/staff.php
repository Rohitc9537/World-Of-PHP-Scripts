<HTML>
<HEAD>
<meta http-equiv=Content-Type content="text/html;  charset=ISO-8859-1">
<TITLE>phpOnline - Admin Area</TITLE>
</HEAD>
<BODY bgcolor="#FFFFFF">
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 WIDTH="550" HEIGHT="370" id="as" ALIGN="">
 <PARAM NAME=movie VALUE="as.swf"> <PARAM NAME=quality VALUE=High> 
	<PARAM NAME=bgcolor VALUE=#ece9d8> 
	<EMBED src="as.swf" quality=High bgcolor=#ece9d8 WIDTH="550" HEIGHT="370" NAME="as" ALIGN=""
 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
</OBJECT>
</BODY>
</HTML>