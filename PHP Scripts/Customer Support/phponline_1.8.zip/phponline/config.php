<?php

$DBHost = 'localhost';
$DBUsername = 'youraccountusername_yourdefinedusername';
$DBPassword = 'yourpassword';
$DBDatabase = 'youraccountname_livesupport';

?>