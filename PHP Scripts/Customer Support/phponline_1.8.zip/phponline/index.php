<?php
include_once('noca.php');
include_once('rcq.php');

include('client.php');

?>