<?php


$CCode = $HTTP_COOKIE_VARS['ocode'];

if($CCode == "")
{
	$CCode = time() . rand(111111,999999);
	setcookie("ocode", $CCode, time()+31536000);
}

?>

<HTML>
<HEAD>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name="Description" content="Live Customer Support, Free live support, free 24x7 live customer support">
<TITLE>phpOnline - Live Customer Support</TITLE>
</HEAD>

<BODY bgcolor="#F8F8F8" topmargin="0" leftmargin="0">

<!-- URL's used in the movie-->
<!-- 
http://phponline.dayanahost.com/ 
-->
<!-- text used in the movie-->
<!-- 
phpOnline
Live Customer Support
Free Online Support 
-->
<!--Please wait while we redirect you to a costomer service representative-->

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber3" height="100%">
  <tr>
    <td width="100%" align="center">

<table border="0" cellpadding="0" style="border-collapse: collapse" bordercolor="#111111" width="100" id="AutoNumber1">
  <tr>
    <td width="100%">
    <img border="0" src="images/cs2_r2_c2.gif" width="517" height="43"></td>
  </tr>
  <tr>
    <td width="100%">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
      <tr>
        <td width="11">
        <img border="0" src="images/cs2_r3_c2.gif" width="17" height="230"></td>
        <td align="center"><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 WIDTH="477" HEIGHT="230" id="cs" ALIGN="">
 <PARAM NAME=movie VALUE="cs.swf"> <PARAM NAME=quality VALUE=High> 
          <PARAM NAME=bgcolor VALUE=FFFFFF>
          <param name="_cx" value="12621">
          <param name="_cy" value="6085">
          <param name="FlashVars" value="-1">
          <param name="Src" value="cs.swf">
          <param name="WMode" value="window">
          <param name="Play" value="-1">
          <param name="Loop" value="-1">
          <param name="SAlign" value>
          <param name="Menu" value="0">
          <param name="Base" value>
          <param name="AllowScriptAccess" value="always">
          <param name="Scale" value="ShowAll">
          <param name="DeviceFont" value="0">
          <param name="EmbedMovie" value="0">
          <param name="SWRemote" value>
          <EMBED src="cs.swf" menu=false quality=high scale=noborder wmode="window" bgcolor=#FFFFFF  WIDTH="477" HEIGHT="230" NAME="cs" ALIGN=""
 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT>
        </td>
        <td width="15">
        <img border="0" src="images/cs2_r3_c4.gif" width="23" height="230"></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="100%">
    <img border="0" src="images/cs2_r4_c2.gif" width="517" height="26"></td>
  </tr>
</table>

    <p><font face="Verdana" size="1">phpOnline has designed and provided by <a href="http://www.dayanahost.com/" target="_blank">Dayana Host</a><br>If you are interested to have a customer support system like this,<br>Please visit <a target="_blank" href="http://phponline.dayanahost.com">
    http://phponline.dayanahost.com</a></font></td>
  </tr>
</table>

</BODY>
</HTML>