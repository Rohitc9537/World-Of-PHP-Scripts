<?
	$mysql_host 	= '';
	$mysql_db 	= '';
	$mysql_user 	= '';
	$mysql_passwd 	= '';
	$mysql_prefix	= '';
?>
