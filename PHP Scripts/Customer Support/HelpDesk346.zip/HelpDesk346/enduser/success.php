<?php
	echo "User Created Successfully";
?>
<br/>
<a href="../">Return to the Main Page</a>