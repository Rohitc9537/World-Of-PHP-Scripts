<img src="images/main-banner-help-desk.jpg" alt="Help Desk Software, Customer Support First" width="547" height="198" border="0" usemap="#Map2"> 
<map name="Map2">
  <area shape="rect" coords="2,145,66,197" href="../hdUserReportproblem.php">
          <area shape="rect" coords="78,149,159,194" href="../helpDeskAccessAllCalls.php">
          <area shape="rect" coords="169,146,275,198" href="../DataAccessSearch.php">
          <area shape="rect" coords="291,149,367,186" href="../ocm-first.php">
          <area shape="rect" coords="377,148,444,196" href="./">
          <area shape="rect" coords="452,147,545,193" href="../DataAccess.php">
        </map>