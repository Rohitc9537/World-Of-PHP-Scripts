Menu: <a href="../index.php">Main Help Desk Page</a> <a href="index.php">Knowledge 
Base Main Page</a> <a href="../reportproblem.php">Open New Ticket</a>
