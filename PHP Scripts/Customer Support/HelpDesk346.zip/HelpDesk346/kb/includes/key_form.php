<table cellpadding="0" cellspacing="0" border="0">
<form method="post" action="key_getresults.php">
	<tr><th align="left">
		Enter a List of Keywords (Sperate with Commas):
	</td></tr>
	<tr><td>
		<textarea name="keys" cols="40" rows="7"></textarea><br/>
		<input type="checkbox" name="includeFiles" value="1" />Search Associated Filenames
	</td></tr>
	<tr><td align="center">
		<input type="submit" name="submit" value="Submit" class="button" />
	</td></tr>
</form>
</table>