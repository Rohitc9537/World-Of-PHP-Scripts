<?php
 
				$server =  'db66b.pair.com';

				$database = 'appstest_11';

				$databaseName = 'appstest_test';

				$databasePassword = 'Just4today!';

				$databasePrefix = 'jdjgreen_';

				define('DB_PREFIX', 'jdjgreen_');

?>