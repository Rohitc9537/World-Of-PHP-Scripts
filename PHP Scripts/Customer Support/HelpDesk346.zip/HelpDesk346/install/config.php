<?php
 
				$server =  '';

				$database = '';

				$databaseName = '';

				$databasePassword = '';

				$databasePrefix = '';

				define('DB_PREFIX', '');

				define('DB_HOST', '');

				define('DB_UNAME', '');

				define('DB_DBNAME', '');

				define('DB_PASS', '');
			?>