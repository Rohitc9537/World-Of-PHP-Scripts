<?php
             $server =  'ServerIPorDNS-NAME goes here';

             $database = 'DatabaseUserNameGoesHere';

             $databaseName = 'DataBaseNameGoesHere';

             $databasePassword = 'UserPasswordGoesHere';

			?>
        