<?php
//
// Project: Help Desk support system
// Description: Admin Main page
//

// File to redirect to
$index_page = "admin_summary.php";
header("Location: $index_page");

?>