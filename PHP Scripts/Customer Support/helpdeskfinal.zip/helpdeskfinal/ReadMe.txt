Readme
Software Version 1.1
CopyRight 2005
http://simplehelpdesk.com

CopyRight
This software is held under a limited license extend to you as an end user.  
The following actions are prohibited par the Terms of Service of this Copy Righted Software. Failure to comply will result in prosecution under the maximum extent of the U.S. and International law.

You are not authorized to redistribute this software.  
This software is not authorized to be resold or used to create direct profit. 
You may NOT change this software in any way and then resell it. 
You may not hold simplehelpdesk or Associates liable for the use of this software.
By download and or using the software you agree to these terms.

---

To use the software you will need to have php_flag magic_quotes_gpc On in your php.ini or .htaccess file.

If you are on a shared hosting account, and do not have access to your php.ini just upload the .htaccess file in this zip file.
If you have problems with your web server displaying web pages correctly after uploading the .htaccess file, just delete the file.
If you can make the configuration change in your php.ini, there is no need to upload the .htacess file.

To install do the follwoing:

make sure these files or folders have write access:

/includes/config.php
/attachments  *folder

Run: /helpdeskfinal/install/index.php

After you are done installing Lock down the permissions on /includes/config.php and remove or secure the install folder.


Then login to the help desk and begin use.

see http://simplehelpdesk.com for updates.
