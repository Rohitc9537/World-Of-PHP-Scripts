<?php  
// format and output date
$the_date = date("M d Y");
// print $the_date;
// print "<br/>Welcome to a PHP-enabled site!";
$browser=substr(trim($HTTP_USER_AGENT),0,4);
echo $browser;
?>

