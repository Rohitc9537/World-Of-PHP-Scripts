<style type="text/css">
body{background-color:#ffffff;margin:0}
body,td,th{font-family:Arial;color:#000000;font-size:9pt}
input,select{font-family:Arial;font-size:9pt}
tr{background-color:#ececec}
th{background-color:#3366CC;color:#ffffff}
A{color:#000080}
A:hover{color:#ff0000}
table{border:0}
#1,#3,#5,#7,#9,#11,#13,#15,#17,#19,#21{background-color:#cccccc}
</style>

<script for=r event=onmouseover>
this.style.backgroundColor='#ccccff';
</script>

<script for=r event=onmouseout>
this.style.backgroundColor='#ececec';
</script>
