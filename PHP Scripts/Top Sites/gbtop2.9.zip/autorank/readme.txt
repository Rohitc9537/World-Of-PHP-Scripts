Upgrade from Autorank and Autorank Pro

- Backup database from autorank admin page
- Copy database file data.txt from cgi-bin directory to main html directory of your toplist
- Install GB Top and activate setting 'Use Site ID'
- Upload fromautorank.php file to main html directory in binary mode and run it
- Upload rankem.cgi file to autorank cgi-bin directory and chmod it to 755