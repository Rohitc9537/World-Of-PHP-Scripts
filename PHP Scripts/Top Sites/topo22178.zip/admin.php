<?php
//
//  admin.php
//  rev001
//  PHP v4.2+
//

//----------------------------------------------------------------
// REDIRECCION A modes/admin/html.php
//----------------------------------------------------------------
echo "<script>document.location.href='index.php?m=admin&s=html';</script>";

?>