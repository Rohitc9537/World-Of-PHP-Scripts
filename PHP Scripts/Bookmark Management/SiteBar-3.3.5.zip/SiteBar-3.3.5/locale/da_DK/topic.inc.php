<?php

$topic = array
(
'100' => 'Tips',
'101' => 'Træk & slip',
'103' => 'Værktøjslinie funktioner',
'200' => 'Kommandoer',
'210' => 'Sessions styring',
'220' => 'Installation & vedligeholdelse',
'230' => 'Konto vedligeholdelse',
'240' => 'Bruger vedligeholdelse',
'250' => 'Gruppe vedligeholdelse',
'260' => 'Mappe operationer',
'270' => 'Henvisnings operationer',
'300' => 'Teknisk information',
'302' => 'Sikkerheds mekanisme',
'303' => 'Udseende',
'304' => 'Forfattere',
'305' => 'Migration',
);

?>
