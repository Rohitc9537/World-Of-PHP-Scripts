<?php

$info = array
(
    'language' => 'Dansk',
    'author' => 'Bent Jensen',
    'url' => 'mailto:bent@kiya.dk',
);

?>