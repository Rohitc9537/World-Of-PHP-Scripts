<?php

$topic = array
(
'100' => 'Kullanım İpuçları',
'101' => 'Sürükle ve Bırak',
'103' => 'Araç Çubuğu İşlevleri',
'200' => 'Komutlar',
'210' => 'Oturum Yönetimi',
'220' => 'Yükleme ve Ayarlar',
'230' => 'Hesap Yönetimi',
'240' => 'Kullanıcı Yönetimi',
'250' => 'Grup Yönetimi',
'260' => 'Klasör İşlemleri',
'270' => 'Bağlantı İşlemleri',
'300' => 'Teknik Bilgi',
'302' => 'Güvenlik Mekanizması',
'303' => 'Kabuklar(Skins)',
'304' => 'Yazarlar',
'305' => 'Taşıma',
);

?>
