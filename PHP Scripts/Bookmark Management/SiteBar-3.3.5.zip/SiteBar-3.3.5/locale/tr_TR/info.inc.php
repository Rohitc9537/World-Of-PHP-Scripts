<?php

$info = array
(
    'language' => 'Türkçe',
    'author' => 'Aydin Coskuner',
    'url' => 'mailto:iaydinc@yahoo.com',
);

?>