<?php

$info = array
(
    'language' => '한국말',
    'author' => 'Yang Seok-Ho',
    'url' => 'mailto:javanese@naver.com',
);

?>