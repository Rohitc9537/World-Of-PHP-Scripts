<?php

$info = array
(
    'language' => 'Català',
    'author' => 'Andreu Escudero',
    'url' => 'mailto:lemon@canuda.net',
);

?>