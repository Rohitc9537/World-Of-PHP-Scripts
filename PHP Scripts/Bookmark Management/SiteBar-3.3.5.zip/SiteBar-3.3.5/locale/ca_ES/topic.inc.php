<?php

$topic = array
(
'100' => 'Consells d&#39;ús',
'101' => 'Drag & Drop',
'103' => 'Funcions de la barra d&#39;eines',
'200' => 'Comandes',
'210' => 'Administració de sessió',
'220' => 'Instalació i manteniment',
'230' => 'Administració de comptes',
'240' => 'Administració d&#39;usuaris',
'250' => 'Administració de grups',
'260' => 'Operacions de carpeta',
'270' => 'Operacions d&#39;enllaç',
'300' => 'Informació tècnica',
'302' => 'Mecanismes de seguretat',
'303' => 'Skins',
'304' => 'Escriptors',
'305' => 'Migració',
);

?>
