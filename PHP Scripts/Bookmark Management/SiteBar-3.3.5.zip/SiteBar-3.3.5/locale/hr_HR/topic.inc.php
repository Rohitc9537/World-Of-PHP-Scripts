<?php

$topic = array
(
'100' => 'Savjeti za korištenje',
'101' => 'Drag & Drop',
'103' => 'Funkcije toolbara',
'200' => 'Zadaci',
'210' => 'Upravljanje sessionima',
'220' => 'Instalacija i održavanje',
'230' => 'Upravljanje accountima',
'240' => 'Upravljanje korisnicima',
'250' => 'Upravljanje grupama',
'260' => 'Operacije s folderima',
'270' => 'Operacije s linkovima',
'300' => 'Tehnički podaci',
'302' => 'Sigurnosni mehanizam',
'303' => 'Izgled',
'304' => 'Writers',
'305' => 'Preseljenje',
);

?>
