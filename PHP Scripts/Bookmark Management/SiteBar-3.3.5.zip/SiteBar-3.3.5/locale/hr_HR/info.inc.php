<?php

$info = array
(
    'language' => 'Hrvatski',
    'authors' => array
    (
        'Igor Kraljić'=> 'http://igor.kraljic.info',
    ),
);

?>