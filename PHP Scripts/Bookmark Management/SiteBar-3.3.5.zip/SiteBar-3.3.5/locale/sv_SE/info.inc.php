<?php 

$info = array
(
    'language' => 'Svenska',
    'author' => 'Mats Bergsten',
    'url' => 'http://www.bergsten.net/mats/',
);

?>
