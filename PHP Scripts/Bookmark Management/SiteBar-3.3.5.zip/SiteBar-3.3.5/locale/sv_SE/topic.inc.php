<?php

$topic = array
(
'100' => 'Användartips',
'101' => 'Drag & Släpp',
'103' => 'Verktygsfunktioner',
'200' => 'Kommandon',
'210' => 'Sessionshantering',
'220' => 'Installation & Underhåll',
'230' => 'Kontohantering',
'240' => 'Användarhantering',
'250' => 'Grupphantering',
'260' => 'Mappoperationer',
'270' => 'Länkoperationer',
'300' => 'Teknisk Information',
'302' => 'Säkerhetsmekanism',
'303' => 'Utseende',
'304' => 'Skärmskrivare',
'305' => 'Överföring',
);

?>
