<?php

$info = array
(
    'language' => 'हिन्दी',
    'author' => 'Puneet Madaan',
    'url' => 'mailto:puneetmadaan@netscape.net',
);

?>