<?php

$topic = array
(
'100' => 'Brukstips',
'101' => 'Dra & Slipp',
'103' => 'Funksjoner for verktøyrad',
'200' => 'Kommandoer',
'210' => 'Sesjonshåndtering',
'220' => 'Installasjon & Vedlikehold',
'230' => 'Kontohåndtering',
'240' => 'Brukerhåndtering',
'250' => 'Gruppehåndtering',
'260' => 'Mappefunksjoner',
'270' => 'Lenkefunksjoner',
'300' => 'Teknisk info',
'302' => 'Sikkerhetsmekanisme',
'303' => 'Drakter',
'304' => 'Skribenter',
'305' => 'Migrering',
);

?>
