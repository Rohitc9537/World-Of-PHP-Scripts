<?php

$info = array
(
    'language' => 'Norsk Bokmål',
    'author' => 'Torkill Bruland',
    'url' => 'mailto:torkar-b@online.no',
);

?>