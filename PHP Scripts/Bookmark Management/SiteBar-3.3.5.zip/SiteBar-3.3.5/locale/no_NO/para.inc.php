<?php

$para = array();

$para['integrator::welcome'] = <<<_P
Velkommen til SiteBar Integrering. Her kan du legge inn SiteBars Online Bokmerker som panel i din nettleser, og få mest mulig ut av SiteBar. Du finne bla. også bookmarklet for kjapt å legge inn nye bokmerker - mens du surfer.
_P;

$para['integrator::header'] = <<<_P
SiteBar er utviklet for å fungere med de fleste standard nettlesere som støtter javascript og cookies. Tabellen nedenfor viser nettlesere som er testet og som virker med SiteBar. Velg din nettleser, og følg instruksjonene nedenfor.
_P;

$para['integrator::usage_opera'] = <<<_P
OBS! Husk å krysse av for "Vis Menyikon" i dine brukerinnstillinger. I nettleseren Opera må du venstre+klikker på menyikonet for å få opp menyene. Etter at du har lagt inn SiteBars som panel i Opera og bokmerkeprogrammet vises i panelet i Opera: Logg inn, gå inn i dine brukerinnstillinger, og krysse av for "Vis Menyikon". Ellers vil du ikke få opp de konteksmenyene som du håndtere dine bokmerker med.  Årsaken er at Opera ikke støtter <a href="http://en.wikipedia.org/wiki/XSLT">XSLT</a>. Operabrukere anbefales også å skru av XSLT i SiteBars brukerinnstillinger.
_P;

$para['integrator::hint'] = <<<_P
Klikk over på navnet på din nettleser for å få veiledningen i hvordan du integrerer SiteBar i din nettleser. <a href="http://brablc.com/mailto?o">Meld fra</a> hvis du har verifisert andre nettlesere/platformer.
_P;

$para['integrator::hint_window'] = <<<_P
Vanlig lenke. Klikk på denne for å åpner SiteBar i nettleserens vindu. MERK! Siden SiteBar
er laget for å vises i et panel er dette en løsning bare for brukere som bruker
eldre nettlesere som ikke har panel.
_P;

$para['integrator::hint_dir'] = <<<_P
SiteBar kan nå også vises som en tradisjonell emnekatalog, ved siden av å
kunne vises som et filtre. I denne visningen vises en og en mappe samt
beskrivelsen for hver lenke i mappa. For å kunne bruke denne visningen
må nettleseren din støtte <a href="http://en.wikipedia.org/wiki/XSLT">XSLT</a>.
_P;

$para['integrator::hint_popup'] = <<<_P
Bruke denne bookmarkletten* hvis du har en gammel nettleser uten sidepanel.
Den vil åpne SiteBar i et sprettopp-vindu, på lignende måte som i et panel.
OBS! Virker ikke hvis nettleseren din blokkere sprettoppvinduer.
_P;

$para['integrator::hint_addpage'] = <<<_P
Bruk denne bookmarkleten* for å ta bokmerke av den siden du viser i nettleseren
din direkte. Når du legge den opp på verktøylinja di. Klikker du på den når
du vil legge inn en lenke til den i dine SiteBar bokmerkesamling. Du får
da opp et sprettoppvindu som automatisk er fyllt med URL og detaljene
fra den viste siden.
_P;

$para['integrator::hint_bookmarklet'] = <<<_P
<i>* <a href="http://en.wikipedia.org/wiki/Bookmarklet">Bookmarklet</a> (også kalt favlet) er et bokmerke / favoritt med et spesiell kode. Den fungerer som en snarvei for raskere å legge inn nye bokmerker i SiteBar. Klikk og dra Bookmarkleten - den du finner i tabellen overfor - opp på vertøyfeltet under menylinja i nettleseren din. (Du må vise Lenker (MSIE), Bookmarks toolbar (FireFox), eller personlig verktøylinje (Opera) for å lenka.). Når du vil legge til en nettside, klikker du bare på dette bokmerket, så vil den spesielle koden hente opp lenkeinformasjon, slik at det for deg bare er å velge mappe, normal, og klikke ok.</i>
_P;

$para['integrator::hint_search_engine'] = <<<_P
Legger til SiteBar Bokmerkesøk i ditt websøkefelt. Tillater søking i SiteBar-bokmerker uten å måtte åpne SiteBar først.
_P;

$para['integrator::hint_sitebar'] = <<<_P
Tillegg utviklet spesielt for SiteBar. Tillater deg å åpne alla lenkene i en mappe i hver sin arkfane, og andre nyttige funksjoner. Bruk menyen "View/Toolbar/Customize" for å legge SiteBar-ikoner inn på verktøylinja.
[<a href="http://sitebarsidebar.mozdev.org/">Projektsidan</a>]
_P;

$para['integrator::hint_sidebar'] = <<<_P
Oppretter et bokmerke som senere kan klikkes på for å åpen SiteBar-panelet.
_P;

$para['integrator::hint_booksync'] = <<<_P
Last ned tillegg for synkronisering av bokmerker. Start Firefox på nytt, åpne FireFox Tilleggshåndtering (Extension manager) og sett protokollen (remote file settings protocol) til <strong>HTTP</strong>, vert <strong>%s</strong> og søkebanen <strong>%s</strong>. For tiden fungerer kun synkronisering fra SiteBar til Firefox synkronisering.
_P;

$para['integrator::hint_livebookmarks'] = <<<_P
Last ned hele mappestrukturen i dine SiteBar online bokmerker, til en fil. Importer denne filen til dine bokmerker. Hver av mappene funker nå som Live Bookmark. Det vil si at på denne måten vil dine bokmerker bli integrert blandt dine andre bokmerker, mens mappeinnholdet vil funke online - nedlastet fra SiteBar. Om en mappe har undermapper, vil innholdet i mappa vises i mappa @Content.
_P;

$para['integrator::hint_mozlinker'] = <<<_P
Last ned og installer <a href="http://sourceforge.net/projects/mozlinker/">tillegget</a> (OBS! Det tillegget kan ikke deinstalleres). En ny meny kalt "MozLinker" vil vises i din nettlesers meny. Bruk undermenyen "Config..." og legg til enten en ny meny eller en ny verktøylinje (toolbar). Som ressurs-URL kan du bruke URL-en fra lenka "MozLinker Extension" på venstre side.
_P;

$para['integrator::hint_sidebar_mozilla'] = <<<_P
Legger inn SiteBar som sidepanel [sidebar]. Dette panelet kan vises/skjules med [F9]. OBS! Hvis SiteBar ikke lastes ned i panelet innen for en gitt tidsramme, vil Mozilla ikke kunne vise den. Du anbefales å åpne SiteBar i hovedvinduet i nettleseren din og å mellomlagre lenkeikoner (favicons) i webleseren, eller rett og slett å slå av visning av lenkeikoner i dine "Brukerinnstillinger".
_P;

$para['integrator::hint_hotlist'] = <<<_P
En lenke til SiteBar vil vises i bokmerkepanelet [Hotlistpanel]. Ett klikk på den vil åpne SiteBar i Operas sidepanel.
_P;

$para['integrator::hint_install'] = <<<_P
Installerer SiteBar til IE's Explorer-felt og kontekstmeny. Siden dette krever endring i registeret må du starte maskinen på nytt for å se alle funksjonene. Hvis du ikke har fulle rettigherer kan noen av funksjonene ikke bli installert.<br> Du åpner SiteBars i Explorer-feltet fra menylinja. Velg Vis/Explorer-felt (View/Explorer Bar). Eller legg til SiteBar som en knapp på verktøylinja slik: På menylinja, velg <b>Verktøylinjer</b> på <b>Vis</b>-menyen. Velg deretter <b>Tilpass</b>. Finn fram til SiteBar i høyre felt og velg legg til.
_P;

$para['integrator::hint_uninstall'] = <<<_P
Avinstallerer SiteBar fra verkttøyfeltet (se over).
_P;

$para['integrator::hint_searchbar'] = <<<_P
For deg som mangler privilegier for å få installert SiteBar i Explorer-feltet. Bruk denne bookmarklett*. Den åpner SiteBar midlertidig i MSIEs Explorer-felt.
_P;

$para['integrator::hint_maxthon_sidebar'] = <<<_P
Last ned en plugin (med forhåndsinnstilt URL). Arkivet må pakkes ut til mappa "C:\Program Files\Maxthon\Plugin". Etter at du starter opp på nytt, har du et nytt valg i Explorer-feltet.
_P;

$para['integrator::hint_maxthon_toolbar'] = <<<_P
Last ned en plugin (med forhåndsinnstilt URL). Arkivet må pakkes ut til mappa "C:\Program Files\Maxthon\Plugin". Etter ommstart vil et nytt ikon vises i verktøyfeltet Plugin. Klikk på dette ikonet så blir aktiv nettside lagt til SiteBar.
_P;

$para['integrator::hint_gentoo'] = <<<_P
Kjør kommandoen <strong>emerge sitebar</strong> for å installere SiteBar-pakka.
_P;

$para['integrator::hint_debian'] = <<<_P
Kjør kommandoen <strong>apt-get install sitebar</strong> for å installere SiteBar-pakka.
_P;

$para['integrator::hint_phplm'] = <<<_P
"PHP Layers Menu" er et meget effektivt hierarkisk menysystem for dynamiska nettsider (DHTML) som sparer båndbredde ved å behandle data på tjeneren, og ikke hos klienten (PHP). SiteBar kan mate den med bokmerker i en korrekt struktur. Hvis det på din tjener er tillatt for fopen å åpne eksterne filer, vil følgende kode laste fil med korrekt struktur:
<tt>
LayersMenu::setMenuStructureFile('%s')
</tt>
_P;

$para['integrator::copyright3'] = <<<_P
Copyright � 2003-2005 <a href='http://brablc.com/'>Ondřej Brablc</a> og <a href='http://sitebar.org/team.php'>SiteBar-teamet</a>. Support <a href='http://sitebar.org/forum.php'>forum</a> og <a href='http://sitebar.org/bugs.php'>bug</a>-sporing.
_P;

$para['command::welcome'] = <<<_P
%s, velkommen til SiteBar!
%s
<p>
SiteBar betjenes via kontekstmenyer som vises ved å høyreklikke på en mappe eller lenke.
Hvis din nettleser ikke støtter høyreklikk, prøv å Ctrl-klikke eller slå på "Vis menyikon"
i dine Brukerinstillinger. Då vises et menyikon foran alle mapper og lenker, og du kan da åpne kontekstmenyene ved å klikke på dette ikonet.
<p>
For mer info om SiteBar, klikk "Hjelp" på bunn av SiteBar.
<p>
Du har allerede blitt logget inn.
_P;

$para['command::signup_verify'] = <<<_P
<p>
For å aktivere din SiteBar-konto må du verifisere
at epostadressen du oppga er din.
<p>
Du motta straks en epost med en lenke. Klikk
på den for å verifisere.
_P;

$para['command::signup_approve'] = <<<_P
<p>
Før du kan bruke din SiteBar-konto må en administrator
godkjenne den.
<p>
Når den er godkjent, vil du motta en epostmelding om det.
_P;

$para['command::signup_verify_approve'] = <<<_P
<p>
For å aktivere din konto må du verifisere at
epostadressen du oppga er din. Dernest må en
administrator godkjenne den.
<p>
Du motta straks en epost med en lenke for å
verifisere epostadressen. Klikk på den for å
verifisere. Din konto blir så aktivert såsnart
en administrator godkjenner den. Når det skjer
blir du varslet pr epost.
_P;

$para['command::account_approved'] = <<<_P
Din SiteBar-konto er godkjent. Du logger deg
inn ved bruk av epostadressen %s.

--
SiteBar-installasjonen finner du her %s.
_P;

$para['command::account_rejected'] = <<<_P
Din SiteBar-konto med epostadressen er avvist
--
SiteBar-installasjonen finner du her %s.
_P;

$para['command::account_deleted'] = <<<_P
Administrator har slettet din inaktive konto 
med epostadressen %s.

-- 
SiteBar-installasjonen ved %s.
_P;

$para['command::reset_password'] = <<<_P
Det er bedt om en fornyelse av passordet for din SiteBar-konto med epostadressen "%s".

Hvis det er du som har bedt om dette, og du virkelig ønsker å fornyet passordet,
klikk på følgende lenke:
    %s


--
SiteBar-installasjonen finner du her %s.
_P;

$para['command::contact'] = <<<_P
Melding:

%s


--
SiteBar-installasjon %s.
_P;

$para['command::contact_group'] = <<<_P
Gruppe: %s
Melding:

%s


--
SiteBar-installasjon %s.
_P;

$para['command::delete_account'] = <<<_P
<h3>Vil du virkelig slette din konto?</h3>
Det finnes ikke noen måte å gjøre om på denne endringen!<p>
Alle dine trær vil bli overført til systemets administrator.
_P;

$para['command::email_link_href'] = <<<_P
<p>Send epost via din standard
<a href='mailto:?subject=Websted: %s&body=Jeg har funnet et websted som du kan være interessert i.
 Ta en kikk på: %s
 --
 Sendt deg via SiteBar %s
 Åpen kildekode bokmerketjener http://sitebar.org'>epostklient</a>
_P;

$para['command::email_link'] = <<<_P
Jeg har funnet et websted som du kansje er interessert i.
Ta en kikk på:

    "%s" %s

%s

--
Sendt deg via SiteBar %s
Bokmerketjener i åpen kildekode http://sitebar.org
_P;

$para['command::verify_email'] = <<<_P
Du har forespurt om epost-validering som tillater deg å delta i
grupper med automatisk deltakelse med "regular expressions" og
som tillater deg å bruke SiteBars epostfunksjoner.

Vennligst klikk på følgende lenke for å verifisere din epost:
    %s
_P;

$para['command::verify_email_must'] = <<<_P
Du har tegnet deg for en SiteBar-konto. Du må verifisere
den oppgitte epostadressen før du kan bruke kontoen.

Klikk på følgende lenke for å verifisere din epostadresse:
    %s
_P;

$para['command::export_bk_ie_hint'] = <<<_P
Internet Explorer har støtte for å importere og eksportere bokmerker i filformatet for Netscapes bokmerker. Men fila må være i Windows standard tegnkoding. UTF-8 fungerer ikke.<br>
_P;

$para['command::import_bk_ie_hint'] = <<<_P
Bokmerker i Internet Explorer kan eksportere til filformatet for Netscapes bokmerker fra menylinja
i menyen "Fil/Importer og Eksporter ...".
Den eksporterte fila har imidlertid den tegnkode som du har på din Windows-innstallasjon - vennligst
velg denne tegnkoden (encoding), når du importerer fila, Standardverdien UTF-8 fungerer ikke.<br>
_P;

$para['command::noiconv'] = <<<_P
<br>
Tegnkode-konvertering er ikke installert på denne SiteBar-tjeneren. Kun UTF-8 og ISO-8859-1 er støttet.
<br>
_P;

$para['command::security_legend'] = <<<_P
Rights:
L<strong>e</strong>s,
<strong>L</strong>egg til,
<strong>M</strong>odifiser
<strong>S</strong>lett,
<strong>R</strong>ens,
<strong>T</strong>illat
_P;

$para['command::purge_cache'] = <<<_P
<h3>Vil du virkelig fjerne alle favikoner fra mellomlageret?</h3>
_P;

$para['command::tooltip_respect'] = <<<_P
Send epost kun hvis bruker har tillatt det.
_P;

$para['command::tooltip_to_verified'] = <<<_P
Sen epost bare til verifiserte adresser.
_P;

$para['command::tooltip_allow_contact'] = <<<_P
Tillat admin å bli kontaktet av anonym bruker.
_P;

$para['command::tooltip_allow_custom_search_engine'] = <<<_P
Hvis dette ikke tillates, vil alle brukere bruke søkemaskinen som er satt i dette skjemaet, og vil ikke kunne modifisere den.
_P;

$para['command::tooltip_allow_sign_up'] = <<<_P
Tillat brukere tilgang til registreringsskjemaet i SiteBar
_P;

$para['command::tooltip_comment_impex'] = <<<_P
Vis kommandoer for import og eksport av lenkebeskrivelser.
_P;

$para['command::tooltip_personal_mode'] = <<<_P
Skru på en SiteBar-modus for installasjon for enkeltbruker.
_P;

$para['command::tooltip_allow_user_trees'] = <<<_P
La brukere opprette ekstra trær.
_P;

$para['command::tooltip_allow_user_tree_deletion'] = <<<_P
La brukerne slette deres eksisterende trære.
_P;

$para['command::tooltip_allow_user_groups'] = <<<_P
La brukere opprette sine egne grupper. I motsatt fall vil bare admin ha dette privilegiet.
_P;

$para['command::tooltip_use_conv_engine'] = <<<_P
Bruk konverteringsmotor (vanligvis en PHP-ekstensjon) for å konvertere sider med forskjellige koding - viktig for import og eksport av bokmerker.  Kan føre til blank skjerm på noen installasjoner dog.
_P;

$para['command::tooltip_use_compression'] = <<<_P
Sider sendt med SiteBar kan komprimeres for å spare båndbredde. Komprimering blir bare brukt mot nettlesere som støtter det.
_P;

$para['command::tooltip_use_mail_features'] = <<<_P
I tilfelle denne PHP-installasjonen tillater bruk av "mail"-funksjonen - så kan epost-egenskaper settes på.
_P;

$para['command::tooltip_use_outbound_connection'] = <<<_P
Noen funksjoner (favicon cache) krever tilgang til fjernadresser fra din tjener.
_P;

$para['command::tooltip_users_must_be_approved'] = <<<_P
Brukere må godkjennes av admin før de kan bruke SiteBar.
_P;

$para['command::tooltip_users_must_verify_email'] = <<<_P
Brukere må verifisere epostadressen før de kan bruke SiteBar
_P;

$para['command::tooltip_show_logo'] = <<<_P
Vis logo øverst - kan slås av for trege verter, eller kan brukes for avertering.
_P;

$para['command::tooltip_show_statistics'] = <<<_P
Vis noe statistikk (ytelse) i panelet.
_P;

$para['command::tooltip_allow_anonymous_export'] = <<<_P
Skru på direkte nedlastng av bokmerke eller feed for anonym bruker. Kan omgås hvis bruker vet hvordan URL-er dannes!
_P;

$para['command::tooltip_use_favicon_cache'] = <<<_P
Favikoner lastes ned til tjeneren til databasecacheen og sendes på forespørsel fra klienter. Øker trafikken og setter fart i favikon-cacheen ved å redusere antallet tjenere du har tilkobling til.
_P;

$para['command::tooltip_max_icon_cache'] = <<<_P
FIFO-stack. De eldste ikoner kasseres fra systemet - brukes for å kontrollere størrelsen på cacheen.
_P;

$para['command::tooltip_max_icon_size'] = <<<_P
Maks tillatt størrelse på ikon i byte.
_P;

$para['command::tooltip_default_folder'] = <<<_P
Neste gang du bruker bookmarklet vil denne mappa være satt som standard.
_P;

$para['command::tooltip_private'] = <<<_P
Ignorer private lenker ved eksport. Private lenker blir altid ignorert for andre brukere enn eieren.
_P;

$para['command::tooltip_novalidate'] = <<<_P
Ikke valider denne lenka - til bruk på intranet-lenker eller lenker som har problemer med validering.
_P;

$para['command::tooltip_is_dead_check'] = <<<_P
Denne lenka bestod ikke validering. Du vil kanskje fortsatt beholde den som aktiv.
_P;

$para['command::tooltip_subfolders'] = <<<_P
Valider denne mappa rekursivt med alle undermapper.
_P;

$para['command::tooltip_ignore_recently'] = <<<_P
Ikke test lenker som nylig er testet - brukes for gjentatt validering når en tidligere ikke ble avsluttet.
_P;

$para['command::tooltip_discover_favicons'] = <<<_P
Analyser siden og finn favikoner (snarveisikoner) som mangler.
_P;

$para['command::tooltip_delete_favicons'] = <<<_P
Slett favikon-URL-er fra lenker hvis faviko er ugyldig - bruk dette med forsiktighet.
_P;

$para['command::tooltip_rename'] = <<<_P
Ved import, gi nytt navn til alle duplikatlenker slik at alt lastes.
_P;

$para['command::tooltip_hits'] = <<<_P
Rut alle klikk og lenker via SiteBar-tjeneren for å generere brukerstatistikk.
_P;

$para['command::tooltip_subdir'] = <<<_P
Eksporter alle lenker og mapper rekursivt.
_P;

$para['command::tooltip_flat'] = <<<_P
Eksporter lenkene som om de var i en mappe.
_P;

$para['command::tooltip_cmd'] = <<<_P
Legg til de viktigste kommandoene i Sitebar for gjøre det lettere å logge inn.
_P;

$para['sitebar::users_must_verify_email'] = <<<_P
Denne SiteBar-installasjonen krever epost-verifikasjon.
Hvis du ikke verifiserer din epost, blir kontoen du opprettet slettet.
_P;

$para['usermanager::auto_verify_email'] = <<<_P
Din epostadresse passer med regler for automatisk deltakelse i
følgede lukkede gruppe(r):
    %s.

For å godkjenne ditt medlemsskap, må din epostadresse verifiseres.
Vennligst klikk på følgende lenke for å verifisere den:
    %s
_P;

$para['usermanager::signup_info'] = <<<_P
Bruker "%s" <%s> har registrert seg på din SiteBar-installasjon %s.
_P;

$para['usermanager::signup_info_verified'] = <<<_P
Brukeren "%s" <%s> tegnet seg for konto på din SiteBar-installasjon ved %s.
Brukeren har allerede verifisert sin epostadresse.
_P;

$para['usermanager::signup_approval'] = <<<_P
Bruker "%s" <%s> tegnet seg på din SiteBar-installation ved %s.

Godkjenn konto:
    %s

Avvis konto:
    %s

Se ventende brukere:
    %s
_P;

$para['usermanager::signup_approval_verified'] = <<<_P
Brukeren "%s" <%s> tegnet seg for konto på din SiteBar-installasjon ved %s.
Brukeren har allerede verifisert sin epostadresse.

Godkjenn konto:
    %s

Avvis konto:
    %s

Se ventende brukere:
    %s
_P;

$para['hook::statistics'] = <<<_P
Røtter {roots_total}.
Mapper {nodes_shown}/{nodes_total}.
Lenker {links_shown}/{links_total}.
Brukere {users}.
Grupper {groups}.
SQL-spørringer {queries}.
DB/Total tid {time_db}/{time_total} sec ({time_pct}%).
_P;

?>
