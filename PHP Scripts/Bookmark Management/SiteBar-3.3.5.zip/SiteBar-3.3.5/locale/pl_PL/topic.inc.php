<?php

// Force commit

$topic = array
(
'100' => 'Informacje o użytkowaniu',
'101' => 'Przeciągnij i upuść',
'103' => 'Funkcje paska narzędzi',
'200' => 'Polecenia',
'210' => 'Zarządzanie sesjami',
'220' => 'Instalacja i utrzymanie',
'230' => 'Zarządzanie kontami',
'240' => 'Zarządzanie użytkownikami',
'250' => 'Zarządzanie grupami',
'260' => 'Operacje na katalogach',
'270' => 'Operacje na linkach',
'300' => 'Informacje techniczne',
'302' => 'Mechanizm zabezpieczeń',
'303' => 'Skórki',
'304' => 'Twórcy',
'305' => 'Migracja',
);

?>
