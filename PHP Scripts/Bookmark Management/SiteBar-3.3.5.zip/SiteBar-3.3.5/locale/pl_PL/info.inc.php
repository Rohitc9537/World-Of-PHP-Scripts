<?php

// Force commit

$info = array
(
    'language' => 'Polski',
    'author' => 'Maciek Sujkowski',
    'url' => 'mailto:msuj@idea.net.pl',
);

?>