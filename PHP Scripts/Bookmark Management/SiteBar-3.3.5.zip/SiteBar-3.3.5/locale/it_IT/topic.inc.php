<?php

$topic = array
(
'100' => 'Informazioni sull&#39;utilizzo',
'101' => 'Copia e incolla',
'103' => 'Funzioni della barra strumenti',
'200' => 'Comandi',
'210' => 'Gestione sessioni',
'220' => 'Installazione e manutenzione',
'230' => 'Gestione account',
'240' => 'Gestione utenti',
'250' => 'Gestione gruppi',
'260' => 'Gestione cartelle',
'270' => 'Gestione collegamenti',
'300' => 'Informazioni tecniche',
'302' => 'Meccanismi di sicurezza',
'303' => 'Skins',
'304' => 'Scrittori',
'305' => 'Migrazione',
);

?>
