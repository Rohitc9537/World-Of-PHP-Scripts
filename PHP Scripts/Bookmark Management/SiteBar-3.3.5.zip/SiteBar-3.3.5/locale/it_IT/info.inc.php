<?php

$info = array
(
    'language' => 'Italiano',
    'author' => 'Claudio Passon',
    'url' => 'mailto:cpasson@wooow.it',
    'co-authors' => 'Andrea Borgia',
);

?>