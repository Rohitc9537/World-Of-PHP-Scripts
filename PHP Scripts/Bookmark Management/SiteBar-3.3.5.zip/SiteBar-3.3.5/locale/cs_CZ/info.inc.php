<?php

$info = array
(
    'language' => 'Česky',
    'authors' => array
    (
        'Ondřej Brablc'=> 'http://brablc.com/',
    ),
);

?>