<?php

$topic = array
(
'100' => 'Návod k použití',
'101' => 'Chyť a upusť',
'103' => 'Funkce nástrojové lišty',
'200' => 'Příkazy',
'210' => 'Správa seance',
'220' => 'Instalace a údržba',
'230' => 'Uživatelské nastavení',
'240' => 'Správa uživatelů',
'250' => 'Správa skupin',
'260' => 'Operace se složkami',
'270' => 'Operace s odkazy',
'300' => 'Technické informace',
'302' => 'Bezpečnostní mechanismus',
'303' => 'Témata',
'304' => 'Generátory výstupu',
'305' => 'Stěhování',
);

?>
