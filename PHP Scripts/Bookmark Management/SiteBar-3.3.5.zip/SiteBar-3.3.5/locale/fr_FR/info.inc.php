<?php

$info = array
(
    'language' => 'Français',
    'authors' => array
    (
        'Renaud Rakotomalala' => 'http://renaud.rakotomalala.com/',
        'Stephane Schitter' => 'http://sourceforge.net/sendmessage.php?touser=381345/',
    ),
);

?>