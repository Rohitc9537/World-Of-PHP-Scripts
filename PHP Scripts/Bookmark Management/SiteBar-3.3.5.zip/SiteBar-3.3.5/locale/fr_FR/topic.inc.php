<?php

$topic = array
(
'100' => 'Astuce d&#39;utilisation',
'101' => 'Saisir & déposer',
'103' => 'Fonctions de la barre d&#39;outils',
'200' => 'Commandes',
'210' => 'Gestion des sessions',
'220' => 'Installation & maintenance',
'230' => 'Gestion des comptes',
'240' => 'Gestions des utilisateurs',
'250' => 'Gestion des groupes',
'260' => 'Opérations sur les dossiers',
'270' => 'Opérations sur les liens',
'300' => 'Informations techniques',
'302' => 'Système de sécurité',
'303' => 'Thèmes',
'304' => 'Générateurs',
'305' => 'Migration',
);

?>
