<?php

$info = array
(
    'language' => '繁體中文', //Chinese traditional characters (TW+HK)
    'authors' => array
    (
        'Chung-Ruei Huang' => 'mailto:crhuang@gmail.com',
        'Sam Liu' => 'mailto:samliu@gmail.com',
        'Henry Wong' => 'mailto:melink@users.sourceforge.net',
    ),
    'aliases' => array('zh_HK'),
);

?>
