<?php

$info = array
(
    'language' => 'Lietuviškai',
    'author' => 'Linas Gricius',
    'url' => 'mailto:linasg@users.sourceforge.net',
);

?>