<?php

$topic = array
(
'100' => 'Pasiūlymai naudojimuisi',
'101' => 'Drag & Drop',
'102' => 'Nuorodų talpinimas',
'103' => 'Įrankių juostos funkcijos',
'200' => 'Komandos',
'210' => 'Sesijų kontrolė',
'220' => 'Įdiegimas & Palaikymas',
'230' => 'Pasyrų tvarkymas',
'240' => 'Vartotojų tvarkymas',
'250' => 'Grupių tvarkymas',
'260' => 'Darbas su katalogais',
'270' => 'Darbas su nuorodomis',
'300' => 'Techninė informacija',
'301' => 'Suderinamumas',
'302' => 'Saugumo mechanizmas',
'303' => 'Odos',
);

?>
