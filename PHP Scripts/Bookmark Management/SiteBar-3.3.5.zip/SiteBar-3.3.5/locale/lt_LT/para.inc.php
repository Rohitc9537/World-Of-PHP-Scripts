<?php

$para = array();

$para['index::tip'] = <<<_P
Pasinaudokite šiuo puslapiu, kad galėtumėt pasileisti ar įdiegti SiteBar nuorodų serverį. rekomenduojama įtraukti vieną iš pateiktų nuorodų su "*" ženkleliu šalia į savo nuorodų sarašą naršyklėje, bet ne šį puslapį. Šį puslapį atversite paspaudę SiteBar lange ant viršuje esančio logotipo.
_P;

$para['index::any_browser'] = <<<_P
Pasinaudoti <a title="SiteBar" href="%s/sitebar.php">SiteBar</a>* šiame lange - ar atidaryti jį naujame lange <a title="SiteBar" href="%s">SiteBar</a>-kaip* naują naršyklės langą.
_P;

$para['index::ie_search'] = <<<_P
Laikinai <a title="SiteBar" href="javascript:void(_search=open('%s/sitebar.php','_search'))"> SiteBar</a>* naudoti kaip paieškos langą naršyklėje. <p class='comment'>Patariama naudoti, kai neužtenka teisių įdiegti prieš tai siūlytą Įdiegėją.</p>
_P;

$para['index::copyright2'] = <<<_P
Autorinės teisės � 2003,2004 <a href='http://brablc.com/'>Ondřej Brablc</a> ir <a href='http://sitebar.org/team.php'>SiteBar Team</a>. Palaikymas <a href='http://sourceforge.net/forum/forum.php?forum_id=261003'>forum</a>.
_P;

$para['command::contact'] = <<<_P
Žinutė:

%s


-- 
SiteBar serveryje %s.
_P;

$para['command::contact_group'] = <<<_P
Grupė: %s 
Žinutė: 

%s 


-- 
SiteBar serveryje %s.
_P;

$para['command::purge_cache'] = <<<_P
<h3>Ar tikrai norite pašalinti visas ikonas iš laikinos atminties?</h3>
_P;

$para['usermanager::signup_info'] = <<<_P
Vartotojas "%s" <%s> užsiregistravo Jūsų SiteBar esančiame %s.
_P;

?>
