<?php

$topic = array
(
'100' => 'Hinweise zur Verwendung',
'101' => 'Drag & Drop',
'103' => 'Funktionen der Werkzeugleiste',
'200' => 'Kommandos',
'210' => 'Sessionverwaltung',
'220' => 'Installation & Pflege',
'230' => 'Kontoverwaltung',
'240' => 'Benutzerverwaltung',
'250' => 'Gruppenverwaltung',
'260' => 'Verzeichnisoperationen',
'270' => 'Lesezeichen-Operationen',
'300' => 'Technische Informationen',
'302' => 'Sicherheitsmechanismus',
'303' => 'Designs',
'304' => 'Migration',
'305' => 'Migration',
);

?>
