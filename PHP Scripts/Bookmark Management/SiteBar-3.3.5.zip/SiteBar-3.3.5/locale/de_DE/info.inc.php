<?php

$info = array
(
    'language' => 'Deutsch',
    'authors' => array
    (
        'Gunnar Wrobel' => 'http://gunnarwrobel.de/',
        'Olaf Nöhring' => 'http://www.team-noehring.de/',
    ),
);

?>