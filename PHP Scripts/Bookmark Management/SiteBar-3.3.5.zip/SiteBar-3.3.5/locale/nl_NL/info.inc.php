<?php

$info = array
(
    'language' => 'Nederlands',
    'author' => 'Henri Wiering',
    'url' => 'mailto:henri@kixtart.nl',
    'co-authors' => 'Eric Hameleers',
);

?>