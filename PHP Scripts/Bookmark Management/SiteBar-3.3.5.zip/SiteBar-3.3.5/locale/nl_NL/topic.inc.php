<?php

$topic = array
(
'100' => 'Gebruikerstips',
'101' => 'Drag & Drop',
'102' => 'Favorieten toevoegen',
'103' => 'Werkbalk functies',
'200' => 'Commando&#39;s',
'210' => 'Sessie management',
'220' => 'Installatie & onderhoud',
'230' => 'Account beheer',
'240' => 'Gebruikers beheer',
'250' => 'Groep beheer',
'260' => 'Map instellingen',
'270' => 'Favorieten instellingen',
'300' => 'Technische info',
'301' => 'Compatibilteit',
'302' => 'Beveiligings methode',
'303' => 'Opmaken',
);

?>
