<?php 

$info = array
(
    'language' => '简体字', // Chinese simplified characters
    'author' => 'Tiger',
    'url' => 'mailto:bbs@biti.edu.cn',
);

?>