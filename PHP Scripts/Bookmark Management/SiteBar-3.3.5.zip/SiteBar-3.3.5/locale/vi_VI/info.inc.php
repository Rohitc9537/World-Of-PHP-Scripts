<?php

$info = array
(
    'language' => 'Tiếng Việt',
    'author' => 'Quang Anh',
    'url' => 'http://www.lazyanduseless.belike.net',
);

?>
