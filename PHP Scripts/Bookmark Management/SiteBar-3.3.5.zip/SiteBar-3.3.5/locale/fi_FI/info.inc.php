<?php

$info = array
(
    'language' => 'Suomi',
    'author' => 'Miika Havo',
    'url' => 'http://www.bittituki.com/'
);

?>
