<?php

$topic = array
(
    100 => 'Vinkkej&auml; k&auml;ytt&ouml;&ouml;n',
        101 => 'Ved&auml; &amp; pudota',
        102 => 'Linkkien lis&auml;ys',
        103 => 'Ty&ouml;kalurivitoiminnot',

    200 => 'Komennot',
        210 => 'Istunnonhallinta',
        220 => 'Asennus &amp; yll&auml;pito',
        230 => 'Tunnuksen hallinta',
        240 => 'K&auml;ytt&auml;j&auml;n hallinta',
        250 => 'Ryhm&auml;n hallinta',
        260 => 'Kansion asetukset',
        270 => 'Linkkeihin kohdistuvat toiminnot',

    300 => 'Tekninen tieto',
        301 => 'Yhteensopivuus',
        302 => 'Suojausmekaniikka',
        303 => 'Tyylit',
);

?>
