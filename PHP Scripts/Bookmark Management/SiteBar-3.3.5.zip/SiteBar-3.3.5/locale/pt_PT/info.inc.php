<?php
$info = array
(
    'language' => 'Português',
    'author' => 'Rui Umbelino',
    'url' => 'http://ruiumbelino.web.pt',
)
?>