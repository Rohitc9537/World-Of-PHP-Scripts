<?php

$topic = array
(
'100' => 'Uso de Dicas',
'101' => 'Arrastar & Largar',
'102' => 'Adicionar Links',
'103' => 'Funções da Barra de Ferramentas',
'200' => 'Comandos',
'210' => 'Gestão da Sessão',
'220' => 'Instalação e Manutenção',
'230' => 'Gestão da Conta',
'240' => 'Gestão do Utilizador',
'250' => 'Gestão do Grupo',
'260' => 'Operações de Pastas',
'270' => 'Operações de Links',
'300' => 'Informação Técnica',
'301' => 'Compatibilidade',
'302' => 'Mecanismo de Segurança',
'303' => 'Skins',
);

?>
