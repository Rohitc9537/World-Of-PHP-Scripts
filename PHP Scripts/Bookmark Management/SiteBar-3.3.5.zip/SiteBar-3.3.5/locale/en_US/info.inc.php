<?php 

$info = array
(
    'language' => 'English',
    'author' => 'Ondřej Brablc',
    'url' => 'http://brablc.com/'
);

?>