<?php

$topic = array
(
'100' => 'Consejos de Uso',
'101' => 'Arrastrar y soltar',
'102' => 'Añadir Enlaces',
'103' => 'Funciones de la Barra de Herramientas',
'200' => 'Comandos',
'210' => 'Administración de Sesión',
'220' => 'Instalación; Mantenimiento',
'230' => 'Cuenta de Administración',
'240' => 'Administración de Usuarios',
'250' => 'Administración de Grupos',
'260' => 'Operaciones con carpetas',
'270' => 'Operaciones con Enlaces',
'300' => 'Información Técnica',
'301' => 'Compatibilidad',
'302' => 'Mecanismo de Seguridad',
'303' => 'Skins',
);

?>
