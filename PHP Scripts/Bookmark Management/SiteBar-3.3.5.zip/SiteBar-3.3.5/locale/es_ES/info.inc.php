<?php

$info = array
(
    'language' => 'Espanol',
    'authors' => array
    (
        'Francisco Gómez González' => 'http://www.cursoshomologados.com/',
        'Juan Diego Gutiérrez Gallardo' => 'mailto:enreas@gmail.com',
    ),
);

?>
