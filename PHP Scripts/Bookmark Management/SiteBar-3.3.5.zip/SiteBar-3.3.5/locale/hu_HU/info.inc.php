<?php

$info = array
(
    'language' => 'Magyar',
    'authors' => array
    (
        'Tamás Katona' => 'mailto:tkatona@gmail.com',
        'The Documan Project' => 'http://documan.sourceforge.net/',
    ),
);

?>