<?php

/**
* This file stays here for backward compatibility with 3.2.x.
* It will be removed in version 3.4!
**/
include("index.php");

?>
