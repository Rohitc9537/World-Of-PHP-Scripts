<?php
    /**
    * This file stays here for backward compatibility with 3.3 CVS3.
    * It will be removed any time.
    **/

    include("index.php");
?>