UPDATE `sitebar_link`
   SET `url`='http://brablc.com/'
 WHERE `url`='http://brablc.com';

UPDATE `sitebar_link`
   SET `favicon` = 'http://brablc.com/favicon.ico'
 WHERE `url`='http://brablc.com/';

UPDATE `sitebar_config`
   SET `release` = '3.0';
