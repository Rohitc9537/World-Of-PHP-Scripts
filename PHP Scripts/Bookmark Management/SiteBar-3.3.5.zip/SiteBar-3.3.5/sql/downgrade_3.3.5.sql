DROP TABLE `sitebar_data`;

UPDATE `sitebar_config`
    SET `release` = '3.3.4';
