UPDATE `sitebar_config`
   SET `release` = '3.3.3';
