UPDATE `sitebar_config`
   SET `release` = '3.1.2';
