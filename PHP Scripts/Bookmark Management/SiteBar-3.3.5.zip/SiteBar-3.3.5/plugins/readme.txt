This  file  should  be  in  http://localhost/sitebar/plugins
directory. Move the whole  directory  to  achieve  this  for
proper installation.

Currently there can be only "command" and  "auth"  plugins.
That is plugins  which  change  some  commands  or  add  new
functionality  via  commands  and  plugins   for   alternate
authorization (which will usually have its  command  part  as
well).

One plugin can implement more plugin types. 

More documentation will be written if there will be  visible
interest in plugins. Currently LDAP plugin should be used as
reference for auth plugins and  mailgate  as  reference  for
command plugins.

Plugins can be downloaded from http://tinyurl.com/5j4ys .
