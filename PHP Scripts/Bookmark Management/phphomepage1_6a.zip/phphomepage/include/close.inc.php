<?
/**
 * [fr]Fichier de cl�ture de connection � la base
 * [en]File closing database conexion
 *
 * @copyright    15/11/2003
 * @since	     03/08/2001
 * @version      1.5
 * @module       connec.inc
 * @modulegroup  include
 * @package      php_homepage
 * @access	     public
 * @author       Eric BLAS <webmaster@phphomepage.net>
 */
mysql_close();
?>