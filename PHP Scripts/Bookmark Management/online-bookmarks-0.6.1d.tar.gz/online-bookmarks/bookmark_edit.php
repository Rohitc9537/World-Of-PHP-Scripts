<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$folder = set_get_folder ();
$bookmark = set_get_bookmark ();
$post_title = set_post_title ();
$post_url = set_post_url ();
$post_description = set_post_description ();

if ($post_title == "" || $post_url == "") {
	$query = sprintf ($sql_get_bookmark, $bookmark, $user);
	$bookmark_result = mysql_query ("$query") or die (mysql_error ());
	$row = mysql_fetch_object ($bookmark_result);
	require_once ("./folders.php");
	$path = & new folder;
	$query_string = "?expand=" . implode(",", $path->get_path_to_root ($folder)) . "&amp;folder=" . $folder;
	?>

	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?bookmark=" . $row->id . "&folder=" . $folder; ?>" name="bookmark_edit" method="POST">
	<p><?php echo $msg_bookmark_title; ?><br>
	<input type=text name="title" size="50" value="<?php echo $row->title; ?>"></p>
	<p><?php echo $msg_bookmark_url; ?><br>
	<input type=text name="url" size="50" value="<?php echo $row->url; ?>"></p>
	<p><?php echo $msg_bookmark_description; ?><br>
	<textarea name="description" cols="50" rows="8"><?php echo $row->description; ?></textarea></p>
	<p><a href="javascript:selectfolder('<?php echo $query_string; ?>')"><?php echo $msg_folder_select; ?></a><br>
	<?php $path->print_path ($folder); ?></p>
	<p><?php echo $msg_last_edited; ?><br>
	<?php echo $row->timestamp;?></p>

	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>
	<script>
	document.bookmark_edit.title.focus();
	</script>

	<?php
}
else {
	$query = sprintf ($sql_update_bookmark, $post_title, $post_url, $post_description, $folder, $bookmark, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}

require_once ("./footer.php");
?>