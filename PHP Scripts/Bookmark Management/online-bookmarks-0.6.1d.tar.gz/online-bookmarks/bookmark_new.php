<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$folder = set_get_folder ();
$post_title = set_post_title ();
$post_url = set_post_url ();
$post_description = set_post_description ();

if ($post_title == "" || $post_url == "") {
	require_once ("./folders.php");
	$path = & new folder;
	$query_string = "?expand=" . implode(",", $path->get_path_to_root ($folder)) . "&amp;folder=" . $folder;
	if ($post_title != "") {
		$title = $post_title;
	}
	else {
		$title = set_get_title ();
	}
	if ($post_url != "") {
		$url = $post_url;
	}
	else {
		$url = set_get_url ();
	}
	?>

	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder; ?>" name="bookmark_edit" method="POST">
	<p><?php echo $msg_bookmark_title; ?><br>
	<input type=text name="title" size="50" value="<?php echo $title; ?>"></p>
	<p><?php echo $msg_bookmark_url; ?><br>
	<input type=text name="url" size="50" value="<?php echo $url; ?>"></p>
	<p><?php echo $msg_bookmark_description; ?><br>
	<textarea name="description" cols="50" rows="8"><?php echo $post_description; ?></textarea></p>
	<p><a href="javascript:selectfolder('<?php echo $query_string; ?>')"><?php echo $msg_folder_select; ?></a><br>
	<?php $path->print_path ($folder); ?></p>

	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>
	<script>
	document.bookmark_edit.title.focus();
	</script>

	<?php
}
else {
	$query = sprintf ($sql_new_bookmark, $user, $post_title, $post_url, $post_description, $folder);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
	# I know, the following is dirty, but I found no other way to do.
	# When creating a bookmark out of the personal toolbar, there is no
	# window.opener that can be closed. Thus javascript exits with an error
	# without finishing itself (self.close()).
	echo '<script language="JavaScript">self.close();</script>';
}

require_once ("./footer.php");
?>
