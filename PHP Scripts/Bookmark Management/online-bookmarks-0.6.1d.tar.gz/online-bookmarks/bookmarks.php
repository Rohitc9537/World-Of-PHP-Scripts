<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

class bookmarks {

	var $bookmarks = array ();

	function bookmarks () {
		$user = $GLOBALS['user'];
		$this->folder = set_get_folder ();
		if (basename ($_SERVER['PHP_SELF']) == "search.php") {
			global $sql_search;
			$search = set_post_search ();
			$query = sprintf ($sql_search, $user, $search, $search, $search);
		}
		else {
			global $sql_get_bookmarks;
			$query = sprintf ($sql_get_bookmarks, $user, $this->folder);
		}

		$bookmarks_result = mysql_query ("$query") or die (mysql_error ());

		while ($row = mysql_fetch_assoc ($bookmarks_result)) {
			array_push ($this->bookmarks, $row);
		}
	}


	function display_bookmarks () {

		global $setting;
		require ("./config/config.php");

		echo '<form name="bookmarks">';
		echo "<table>\n";

		foreach ($this->bookmarks as $value) {
			echo "<tr>\n";

			# the checkbox, needed in any case
			echo '<td valign="top" width="10">';
			echo '<input type="checkbox" name="' . $value['id'] . '">';
			echo "</td>\n";

			# the bookmark image if configured to be displayed
			if ($setting['show_bookmark_icon']){
				echo '<td valign="top" width="10">';
				echo $bookmark_image;
				echo "</td>\n";
			}

			# the link, needed in any case, to be opened in new window or in originating window
			if ($setting['open_new_window']) {
				$target = ' target="_blank"';
			}
			else {
				$target = null;
			}
			echo '<td valign="top" width="100%">';
			echo '<a href="' . $value['url'] . '" title="' . $value['url'] . '"' . $target . '>' . $value['title'] . '</a>';

			# the description if configured to be displayed and if not empty
			# thanks to Tim Hogan <tlhogan22@yahoo.com>
			if ($setting['show_bookmark_description'] && $value['description'] != "") {
				echo '<div class="description">' . $value['description'] . "</div>\n";
			}				

			echo "</td>\n";

			# the date column if configured to be displayed
			if ($setting['show_column_date']) {
				echo '<td valign="top" width="10">';
				echo $value['timestamp'];
				echo "</td>\n";
			}				

			# the edit column if configured to be displayed
			if ($setting['show_column_edit']) {
				echo '<td valign="top" width="10">';
				echo '<a href="javascript:bookmarkedit(\'' . $value['id'] . '\', \'' . $value['childof'] . '\')">';
				echo $edit_image . "</a>";
				echo "</td>\n";
			}

			# the move column if configured to be displayed
			if ($setting['show_column_move']) {
				echo '<td valign="top" width="10">';
				echo '<a href="javascript:bookmarkmove(\'' . $value['id'] . '\', \'' . $_SERVER['QUERY_STRING'] . '\')">';
				echo $move_image . "</a>";
				echo "</td>\n";
			}

			# the delete column if configured to be displayed
			if ($setting['show_column_delete']) {
				echo '<td valign="top" width="10">';
				echo '<a href="javascript:bookmarkdelete(\'' . $value['id'] . '\')">';
				echo $delete_image . "</a>";
				echo "</td>\n";
			}

			echo "</tr>\n";
		}
		echo "</table></form>\n";
	}
}
?>
