<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$folder = set_get_folder ();
$noconfirm = set_get_noconfirm ();

# the root folder cannot be deleted
if ($folder == "" || $folder == "0"){
	echo $msg_no_folder_selected;	
}
else if (!$setting['confirm_delete'] || $noconfirm) {
	# lets do the deletion if the confirm variable is set to FALSE or after confirmation
	require_once ("./folders.php");
	$tree = & new folder;
	$tree->get_children ($folder);

	array_push ($tree->get_children, $folder);
	$folders = implode (",", $tree->get_children);

	# first all subfolders
	$query = sprintf ($sql_set_delete_items, "folder", $folders, $user);
	mysql_query ("$query") or die (mysql_error ());

	# of course, we want to delete all bookmarks as well
	$query = sprintf ($sql_set_delete_items, "bookmark", $folders, $user);
	mysql_query ("$query") or die (mysql_error ());

	# now the folder itself
	$query = sprintf ($sql_set_delete_folder, $folder, $user);
	mysql_query ("$query") or die (mysql_error ());

	echo '<script language="JavaScript">reloadclose()</script>';
}
else {
	# if there was no confirmation, as to _really_ delete the whole stuff
	# print the verification form
	$query = sprintf ($sql_confirm_delete_folder, $folder, $user);
	$folder_result = mysql_query ("$query") or die (mysql_error ());

	if (mysql_num_rows ($folder_result) == 0){
		die ($msg_folder_does_not_exist);
	}

	$row = mysql_fetch_object ($folder_result);
	?>

	<table border="0">
	<tr><td><?php echo $msg_folder_delete; ?></td></tr>
	<tr><td><?php echo $folder_closed . " " . $row->name; ?></td></tr>
	</table>

	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder . "&amp;noconfirm=1";?>" method="POST" name="bmdelete"></p>
	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>

	<?php
}

require_once ("./footer.php");
?>