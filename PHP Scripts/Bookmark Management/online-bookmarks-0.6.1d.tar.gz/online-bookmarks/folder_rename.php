<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$name = set_post_name ();
$folder = set_get_folder ();

if ($folder == "" || $folder == "0"){
	echo $msg_no_folder_selected;	
}
else if ($name == "") {
	$query = sprintf ($sql_get_foldername, $folder, $user);
	$folder_result = mysql_query ("$query") or die (mysql_error ());
	$row = mysql_fetch_object ($folder_result);
	?>

<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder; ?>" name="folder_rename" method="POST">
<p><?php echo $msg_folder_rename; ?><br>
<input type=text name="name" size="50" value="<?php echo $row->name; ?>"></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
</form>
<script>
document.folder_rename.name.focus();
</script>

	<?php
}
else {
	$query = sprintf ($sql_update_folder, $name, $folder, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}

require_once ("./footer.php");
?>