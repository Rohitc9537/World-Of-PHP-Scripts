<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (!isset ($_POST['browser']) || $_POST['browser'] == "" ||
         ($_POST['browser'] != "netscape" &&
          $_POST['browser'] != "opera" &&
          $_POST['browser'] != "IE")) {

	# header.php is included here, because we want to print 
	# plain text when exporting bookmarks, so that browsers
	# can handle results better. header.php is needed only to
	# display html.
	require_once ("./header.php");

	$folder = set_GET_folder();

	# get the browser type for default setting below if possible
	if( eregi ("opera", $_SERVER['HTTP_USER_AGENT'])) {
		$default_browser = "opera";
	}
	else if(eregi("msie", $_SERVER['HTTP_USER_AGENT'])) {
		$default_browser = "IE";
	}
	else{
		$default_browser = "netscape";
	}
?>

<h1><?php echo $title; ?></h1>
<a href="./">[<b><?php echo $msg_online_bookmarks; ?></b>]</a><br><br>

<form enctype="multipart/form-data" action="<?php echo $_SERVER['SCRIPT_NAME'];?>" method="POST">
  <table valign="top">
    <tr>
      <td width="<?php echo $column_width_folder?>">
        Export Bookmarks to Browser:
      </td>
      <td width="<?php echo $column_width_folder?>">
        <select name="browser">
          <option value="IE"<?php if ($default_browser=="IE") {echo " selected"; } ?>>Internet Explorer</option>
          <option value="netscape"<?php if ($default_browser=="netscape") {echo " selected"; } ?>>Netscape / Mozilla</option>
          <option value="opera"<?php if ($default_browser=="opera") {echo " selected"; } ?>>Opera .adr</option>
        </select>
      </td>
    </tr>

    <tr>
      <td>
        Folder to export:
      </td>
      <td>
	<?php
	require_once ("./folders.php");
	$tree = & new folder;
	$tree->make_tree (0);
	$tree->print_tree ();
	?>
      </td>
    </tr>

    <tr>
      <td>
        <input type="hidden" name="folder" value="<?php echo $folder; ?>">
        <input type="submit" value="Export">
      </td>
      <td>
      </td>
    </tr>
  </table>
</form>

<?php
}

else{
	# instead of header.php we include main.php to ensure correct variables and authentication
	require ("./main.php");

	$browser = $_POST['browser'];

	if (!isset ($_POST['folder']) || $_POST['folder'] == "") {
		$folder = 0;
	}
	else if (!is_numeric ($_POST['folder'])) {
		$folder = 0;
	}
	else{
		$folder = $_POST['folder'];
	}

	if ($browser == "netscape" || $browser == "IE") {
		echo "<!DOCTYPE NETSCAPE-Bookmark-file-1>\n";
		echo "<TITLE>Bookmarks</TITLE>\n";
		echo "<H1>Bookmarks</H1>\n";
		echo "<DL><p>\n";
		$export = & new export;
		$export->make_tree ($folder);
		echo "</DL><p>\n";
	}
	else if ($browser == "opera") {
		echo "<pre>\n";
		echo "Opera Hotlist version 2.0\n";
		echo "Options: encoding = utf8, version=3\n\n";
		$export = & new export;
		$export->make_tree ($folder);
		echo "</pre>\n";
	}
}

class export {
	function export () {
		# collect the folder data
		require_once ("./folders.php");
		$this->tree = & new folder;
		$this->tree->folders[0] = array ('id' => 0, 'childof' => null, 'name' => $GLOBALS['setting']['root_folder_name']);

		$this->counter = 0;
		$this->browser = $_POST['browser'];
		$user = $GLOBALS['user'];

		# collect the bookmark data
		$query = sprintf ($GLOBALS['sql_get_all_bookmarks'], $user);
		$bookmarks_result = mysql_query ("$query") or die (mysql_error ());
		while ($row = mysql_fetch_assoc ($bookmarks_result)) {
			if (!isset ($this->bookmarks[$row['childof']])) {
				$this->bookmarks[$row['childof']] = array ();
			}
			array_push ($this->bookmarks[$row['childof']], $row);
		}
	}

	function make_tree ($id) {
		if (isset ($this->tree->children[$id])) {
			$this->counter++;
			foreach ($this->tree->children[$id] as $value) {
				$this->print_folder ($value);
				$this->make_tree ($value);
				$this->print_folder_close ();
			}
			$this->counter--;
		}
		$this->print_bookmarks ($id);
	}


	function print_folder ($folder) {
		$spacer = str_repeat ("    ", $this->counter); 
		if ($this->browser == "netscape") {
			echo $spacer . "<DT><H3>" . $this->tree->folders[$folder]['name'] . "</H3>\n";
			echo $spacer . "<DL><p>\n";
		}
		else if ($this->browser == "IE") {
			echo $spacer . '<DT><H3 FOLDED ADD_DATE="">' . $this->tree->folders[$folder]['name'] . "</H3>\n";
			echo $spacer . "<DL><p>\n";
		}
		else if ($this->browser == "opera") {
			echo "#FOLDER\n";
			echo "\tNAME=" . $this->tree->folders[$folder]['name'] . "\n\n";
		}
	}

	function print_folder_close () {
		$spacer = str_repeat ("    ", $this->counter); 
		if ($this->browser == "netscape" || $this->browser == "IE"){
			echo $spacer . "</DL><p>\n";
		}
		else if ($this->browser == "opera"){
			echo "-\n\n";
		}
	}

	function print_bookmarks ($folder) {
		$spacer = str_repeat ("    ", $this->counter); 
		if (isset ($this->bookmarks[$folder])) {
			foreach ($this->bookmarks[$folder] as $value) {
				if ($this->browser == "netscape") {
					echo $spacer . '    <DT><A HREF="' . $value['url'] . '">' . $value['title'] . "</A>\n";
					if ($value['description'] != "") {
						echo $spacer . '    <DD>' . $value['description'] . "\n";
					}
				}
				else if ($this->browser == "IE") {
					echo $spacer . '    <DT><A HREF="' . $value['url'] . '" ADD_DATE="" LAST_VISIT="" LAST_MODIFIED="">' . $value['title'] . "</A>\n";
					# unfortunately description for bookmarks in MS Internet Explorer is not supported.
					# thats why we just ignore the output of the description here.
				}
				else if ($this->browser == "opera") {
					echo "#URL\n";
					echo "\tNAME=" . $value['title'] . "\n";
					echo "\tURL=" . $value['url'] . "\n";
					if ($value['description'] != "") {
						# opera cannot handle the \r\n character, so we fix this.
						$description = str_replace ("\r\n", " ", $value['description']);
						echo "\tDESCRIPTION=" . $description . "\n\n";
					}
				}
			}
		}
	}
}

?>
