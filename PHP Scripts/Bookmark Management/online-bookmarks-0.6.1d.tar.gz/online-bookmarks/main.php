<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

require_once ("./messages/language.php");

############################# misc #############################

###
### checks and purges the JavaScript given 1_2_3 list (there
### must be only digits) and returns a comma separated 
### string with the correct format to use in sql queries
###

function set_bmlist ($bmlist){
	$expand = array_unique (explode ("_", $bmlist));
	foreach ($expand as $key => $value) {
		if ($value == "" || !is_numeric ($value)) {
			unset ($expand[$key]);
		}
	}
	return implode (", ", $expand);
}

############################# GET #############################

###
### purges and defines the $_GET['folder'] variable
### 
function set_get_folder () {
	if (!isset ($_GET['folder']) || $_GET['folder'] == "" || !is_numeric($_GET['folder'])) {
		$folder = 0;
	}
	else {
		$folder = $_GET['folder'];
	}
	return $folder;
}

###
### purges and defines the $_GET['expand'] variable
###
function purge_expand_list () {
	if (!isset ($_GET['expand']) || $_GET['expand'] == "") {
		$expand = array();
	}
	else {
		$expand = array_unique (explode (",", $_GET['expand']));
		foreach ($expand as $key => $value) {
			if ($value == "" || !is_numeric ($value)) {
				unset ($expand[$key]);
			}
		}
	}
	return $expand;
}

###
### purges and defines the $_GET['bookmark'] variable
###
function set_get_bookmark () {
	if (!isset ($_GET['bookmark']) || $_GET['bookmark'] == "" || !is_numeric($_GET['bookmark'])) {
		$bookmark = "";
	}
	else {
		$bookmark = $_GET['bookmark'];
	}
	return $bookmark;
}

###
### purges and defines the $_GET['title'] variable
###
function set_get_title () {
	if (!isset ($_GET['title']) || $_GET['title'] == "") {
		$title = "";
	}
	else {
		$title = $_GET['title'];
	}
	return $title;
}

###
### purges and defines the $_GET['url'] variable
###
function set_get_url () {
	if (!isset ($_GET['url']) || $_GET['url'] == "") {
		$url = "";
	}
	else {
		$url = $_GET['url'];
	}
	return $url;
}

##
## defines the $_GET['bmlist'] variable
##
function set_get_bmlist (){
	if (!isset ($_GET['bmlist']) || $_GET['bmlist'] == ""){
		return "";
	}
	else {
		$_GET['bmlist'] = htmlentities ($_GET['bmlist'], ENT_QUOTES);
	}
	return trim ($_GET['bmlist']);
}

##
## defines the $_GET['noconfirm'] variable
##
function set_get_noconfirm (){
	if (!isset ($_GET['noconfirm']) || $_GET['noconfirm'] == ""){
		return FALSE;
	}
	else {
		return TRUE;
	}
}

############################# POST #############################

###
### purges and defines the $_POST['title'] variable
###
function set_post_title () {
	if (!isset ($_POST['title']) || $_POST['title'] == "") {
		$title = "";
	}
	else {
		$title = $_POST['title'];
	}
	return trim (htmlentities ($title, ENT_QUOTES));
}

###
### purges and defines the $_POST['url'] variable
###
function set_post_url () {
	if (!isset ($_POST['url']) || $_POST['url'] == "") {
		$url = "";
	}
	else {
		$url = $_POST['url'];
	}
	return trim (htmlentities ($url, ENT_QUOTES));
}

###
### purges and defines the $_POST['description'] variable
###
function set_post_description () {
	if (!isset ($_POST['description']) || $_POST['description'] == "") {
		$description = "";
	}
	else {
		$description = $_POST['description'];
	}
	return trim (htmlentities ($description, ENT_QUOTES));
}

###
### purges and defines the $_POST['bookmarks'] variable
###
function set_post_bookmarks () {
	if (!isset ($_POST['bookmarks']) || $_POST['bookmarks'] == "") {
		$bookmarks = "";
	}
	else {
		$bookmarks = $_POST['bookmarks'];
	}
	return trim (htmlentities ($bookmarks, ENT_QUOTES));
}

###
### purges and defines the $_POST['name'] variable
###
function set_post_name () {
	if (!isset ($_POST['name']) || $_POST['name'] == "") {
		$name = "";
	}
	else {
		$name = $_POST['name'];
	}
	return trim (htmlentities ($name, ENT_QUOTES));
}

###
### purges and defines the $_POST['sourcefolder'] variable
###
function set_post_sourcefolder () {
	if (!isset ($_POST['sourcefolder']) || $_POST['sourcefolder'] == "") {
		$sourcefolder = "";
	}
	else {
		$sourcefolder = $_POST['sourcefolder'];
	}
	return trim (htmlentities ($sourcefolder, ENT_QUOTES));
}

###
### purges and defines the $_POST['search'] variable
###
function set_post_search () {
	if (!isset ($_POST['search']) || $_POST['search'] == "") {
		$search = "";
	}
	else {
		$search = $_POST['search'];
	}
	return trim (htmlentities ($search, ENT_QUOTES));
}

?>
