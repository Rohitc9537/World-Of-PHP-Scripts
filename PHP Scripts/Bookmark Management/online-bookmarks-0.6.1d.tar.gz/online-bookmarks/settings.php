<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

if (isset ($_POST['setting_root_folder_name'])) {
	$setting = array (
		'language'			=> check_var ("setting_language"),
		'root_folder_name'		=> check_var ("setting_root_folder_name"),
		'column_width_folder'		=> check_num_var ("setting_column_width_folder"),
		'column_width_bookmark'		=> check_num_var ("setting_column_width_bookmark"),
		'table_height'			=> check_num_var ("setting_table_height"),
		'confirm_delete'		=> check_bol_var ("setting_confirm_delete"),
		'open_new_window'		=> check_bol_var ("setting_open_new_window"),
		'show_bookmark_description'	=> check_bol_var ("setting_show_bookmark_description"),
		'show_bookmark_icon'		=> check_bol_var ("setting_show_bookmark_icon"),
		'show_column_date'		=> check_bol_var ("setting_show_column_date"),
		'show_column_edit'		=> check_bol_var ("setting_show_column_edit"),
		'show_column_move'		=> check_bol_var ("setting_show_column_move"),
		'show_column_delete'		=> check_bol_var ("setting_show_column_delete"),
		'fast_folder_minus'		=> check_bol_var ("setting_fast_folder_minus"),
		'fast_folder_plus'		=> check_bol_var ("setting_fast_folder_plus"),
		'fast_symbol'			=> check_bol_var ("setting_fast_symbol"),
		'simple_tree_mode'		=> check_bol_var ("setting_simple_tree_mode"),
	);

	$query =  "UPDATE user SET ";
	$query .= "language			= '" . $setting['language'] . "', ";
	$query .= "root_folder_name		= '" . $setting['root_folder_name'] . "', ";
	$query .= "column_width_folder		= '" . $setting['column_width_folder'] . "', ";
	$query .= "column_width_bookmark	= '" . $setting['column_width_bookmark'] . "', ";
	$query .= "table_height			= '" . $setting['table_height'] . "', ";
	$query .= "confirm_delete		= '" . $setting['confirm_delete'] . "', ";
	$query .= "open_new_window		= '" . $setting['open_new_window'] . "', ";
	$query .= "show_bookmark_description	= '" . $setting['show_bookmark_description'] . "', ";
	$query .= "show_bookmark_icon		= '" . $setting['show_bookmark_icon'] . "', ";
	$query .= "show_column_date		= '" . $setting['show_column_date'] . "', ";
	$query .= "show_column_edit		= '" . $setting['show_column_edit'] . "', ";
	$query .= "show_column_move		= '" . $setting['show_column_move'] . "', ";
	$query .= "show_column_delete		= '" . $setting['show_column_delete'] . "', ";
	$query .= "fast_folder_minus		= '" . $setting['fast_folder_minus'] . "', ";
	$query .= "fast_folder_plus		= '" . $setting['fast_folder_plus'] . "', ";
	$query .= "fast_symbol			= '" . $setting['fast_symbol'] . "', ";
	$query .= "simple_tree_mode		= '" . $setting['simple_tree_mode'] . "' ";
	$query .= "WHERE username 		= '" . $user . "'";

	mysql_query ("$query") or die (mysql_error ());
}

function check_bol_var ($varname) {
	if ($_POST[$varname] == 0) {
		return 0;
	}          
	else {
		return 1;
	}
}

function check_num_var ($varname) {
	if (!is_numeric ($_POST[$varname])) {
		return 280;
	}
	else if ($_POST[$varname] < 100) {
		return 100;
	}
	else if ($_POST[$varname] > 800) {
		return 800;
	}
	else {
		return $_POST[$varname];
	}
}

function check_var ($varname) {
	if (!isset ($_POST[$varname]) || $_POST[$varname] == "") {
		$var = "";
	}
	else {
		$var = htmlentities($_POST[$varname], ENT_QUOTES);
	}
	return trim ($var);
}

function print_languages () {
	$handler = opendir("./messages");
	while ($dir = readdir ($handler)) {
		if (is_dir ("./messages/$dir") && $dir != "." && $dir != "..") {
			if ($dir == $GLOBALS['setting']['language']) {
				echo "<option selected>" . $dir . "</option>\n";
			}
			else {
				echo "<option>" . $dir . "</option>\n";
			}
		}
	}
}

?>

<h1>Settings of <?php echo $user; ?></h1>

<a href="./">[<b><?php echo $msg_online_bookmarks; ?></b>]</a><br><br>

<form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="POST">
<table>
	<tr>
		<td>Language</td>
		<td>
			<select name="setting_language">
<?php print_languages (); ?>
			</select>
		</td>
	</tr>
	
	<tr>
		<td>Name of the root folder</td>
		<td>
			<input type="text" name="setting_root_folder_name" value="<?php echo $setting['root_folder_name']; ?>">
			(Preview)
		</td>
	</tr>

	<tr>
		<td>The width in pixels of the folder column</td>
		<td>
			<input type="text" name="setting_column_width_folder" value="<?php echo $setting['column_width_folder']; ?>" size="5">
			(Preview)
		</td>
	</tr>

	<tr>
		<td>The width in pixels of the bookmark column</td>
		<td>
			<input type="text" name="setting_column_width_bookmark" value="<?php echo $setting['column_width_bookmark']; ?>" size="5">
			(Preview)
		</td>
	</tr>

	<tr>
		<td>The min height in pixels of the main table</td>
		<td>
			<input type="text" name="setting_table_height" value="<?php echo $setting['table_height']; ?>" size="5">
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Confirm deletions of bookmarks an folders</td>
		<td>
			<select name="setting_confirm_delete">
			<option value="0" <?php if ($setting['confirm_delete'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['confirm_delete'] == 1) {echo "selected";}?>>Yes</option>
			</select>
		</td>
	</tr>

	<tr>
		<td>Open a new window when clicking a bookmark</td>
		<td>
			<select name="setting_open_new_window">
			<option value="0" <?php if ($setting['open_new_window'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['open_new_window'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the bookmarks description in the overview</td>
		<td>
			<select name="setting_show_bookmark_description">
			<option value="0" <?php if ($setting['show_bookmark_description'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_bookmark_description'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the bookmarks icon</td>
		<td>
			<select name="setting_show_bookmark_icon">
			<option value="0" <?php if ($setting['show_bookmark_icon'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_bookmark_icon'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the column with the change date</td>
		<td>
			<select name="setting_show_column_date">
			<option value="0" <?php if ($setting['show_column_date'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_column_date'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the column to edit a bookmark</td>
		<td>
			<select name="setting_show_column_edit">
			<option value="0" <?php if ($setting['show_column_edit'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_column_edit'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the column to move a bookmark</td>
		<td>
			<select name="setting_show_column_move">
			<option value="0" <?php if ($setting['show_column_move'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_column_move'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Show the column to delete a bookmark</td>
		<td>
			<select name="setting_show_column_delete">
			<option value="0" <?php if ($setting['show_column_delete'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['show_column_delete'] == 1) {echo "selected";}?>>Yes</option>
			</select>
			(Preview)
		</td>
	</tr>

	<tr>
		<td>Collaps tree when clicking on folder icon</td>
		<td>
			<select name="setting_fast_folder_minus">
			<option value="0" <?php if ($setting['fast_folder_minus'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['fast_folder_minus'] == 1) {echo "selected";}?>>Yes</option>
			</select>
		</td>
	</tr>

	<tr>
		<td>Expand tree when clicking on folder icon</td>
		<td>
			<select name="setting_fast_folder_plus">
			<option value="0" <?php if ($setting['fast_folder_plus'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['fast_folder_plus'] == 1) {echo "selected";}?>>Yes</option>
			</select>
		</td>
	</tr>

	<tr>
		<td>Select folder when clicking on plus/minus symbol</td>
		<td>
			<select name="setting_fast_symbol">
			<option value="0" <?php if ($setting['fast_symbol'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['fast_symbol'] == 1) {echo "selected";}?>>Yes</option>
			</select>
		</td>
	</tr>

	<tr>
		<td>Allways open just one tree</td>
		<td>
			<select name="setting_simple_tree_mode">
			<option value="0" <?php if ($setting['simple_tree_mode'] == 0) {echo "selected";}?>>No</option>
			<option value="1" <?php if ($setting['simple_tree_mode'] == 1) {echo "selected";}?>>Yes</option>
			</select>
		</td>
	</tr>

	<tr>
		<td></td>
		<td>
			<input type="submit" value="Apply">
		</td>
	</tr>
</table>
</form>

Preview:<br>

<table valign="top" border="0" style="border: 1px black dashed">

  <tr>
    <td width="<?php echo $setting['column_width_folder']; ?>">
      <img src="./images/spacer.gif" alt="" width="<?php echo $setting['column_width_folder']; ?>" height="0"><br>
    </td>
    <td width="<?php echo $setting['column_width_bookmark']; ?>">
      <img src="./images/spacer.gif" alt="" width="<?php echo $setting['column_width_bookmark']; ?>" height="0"><br>
    </td>
    <td></td>
  </tr>
  
  <tr>
    <td>
      <?php echo $plus . $folder_closed . " " . $setting['root_folder_name'] ?>
    </td>
    <td>
      <table>
        <tr>
          <td valign="top" width="10"><input type="checkbox"></td>
<?php

	# the bookmark image if configured to be displayed
	if ($setting['show_bookmark_icon']){
		echo '<td valign="top" width="10">';
		echo $bookmark_image;
		echo "</td>\n";
	}

	# the link, needed in any case, to be opened in new window or in originating window
	if ($setting['open_new_window']) {
		$target = ' target="_blank"';
	}
	else {
		$target = null;
	}
	echo '<td valign="top" width="' . $setting['column_width_bookmark'] . '">' . "\n";
	echo '<a href="http://www.frech.ch/online-bookmarks/" title="http://www.frech.ch/online-bookmarks/"' . $target . '>This is an example link</a>' . "\n";

	# the description if configured to be displayed and if not empty
	# thanks to Tim Hogan <tlhogan22@yahoo.com>
	if ($setting['show_bookmark_description']) {
		echo '<div class="description">here come any meaningfull description to be displayed in the overview. You can disable this as well if you want to. Do this by disable the setting above or by just ignoring the description table as well blah blah ...</div>' . "\n";
	}				

	echo "</td>\n";

	# the date column if configured to be displayed
	if ($setting['show_column_date']) {
		echo '<td valign="top" width="10">';
		echo "02.02.2005";
		echo "</td>\n";
	}				

	# the edit column if configured to be displayed
	if ($setting['show_column_edit']) {
		echo '<td valign="top" width="10">';
		echo $edit_image . "</a>";
		echo "</td>\n";
	}

	# the move column if configured to be displayed
	if ($setting['show_column_move']) {
		echo '<td valign="top" width="10">';
		echo $move_image . "</a>";
		echo "</td>\n";
	}

	# the delete column if configured to be displayed
	if ($setting['show_column_delete']) {
		echo '<td valign="top" width="10">';
		echo $delete_image . "</a>";
		echo "</td>\n";
	}

?>

        </tr>
      </table>

    </td>
    <td><img src="./images/spacer.gif" alt="" width="0" height="<?php echo $setting['table_height']; ?>"></td>
  </tr>
</table>

<br>
Drag the following link to the link bar / hotlist of your browser. This will generate a button that allows you to add the currently visited homepage to online-bookmarks with just one click. The title and URL of the corresponding homepage will be suggested.<br>
<b>--> <a href="javascript:bmadd=window.open('<?php if (isset ($_SERVER["HTTPS"])) {echo "https://";} else {echo "http://";} echo $_SERVER["SERVER_NAME"] . (dirname ($_SERVER["SCRIPT_NAME"])=="/"?"":dirname($_SERVER["SCRIPT_NAME"])); ?>/bookmark_new.php?title=' + escape(document.title) + '&url=' + escape(document.location), 'bmadd','toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50');bmadd.focus();">bookmark</a> <--</b><br><br>

<br>
<span style="font:italic 10pt Verdana"><a href="http://www.frech.ch/online-bookmarks/" target="_blank">online-bookmarks</a> by stefan frech</span>

<?php
require_once ("./footer.php");
?>
