<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$search = set_post_search ();

if ($search == ""){
	?>

	<body>
	<form action="<?php echo $_SERVER['SCRIPT_NAME'];?>" name="edit_search" method="POST">
	<p><?php echo $msg_search_string; ?><br>
	<input type=text name="search" size="50" value=""></p>
	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>

	<script>
		document.edit_search.search.focus();
	</script>

	<?php
}
else {
	?>

<script language="JavaScript"><!--
var bookmarks =
[
    [null, '<b><?php echo $msg_bookmarks; ?></b>', null, null, null,
        [null, '<?php echo $msg_move; ?>', 'javascript:bookmarkmove(checkselected(),\'<?php echo $_SERVER['QUERY_STRING']; ?>\')'],
        [null, '<?php echo $msg_delete; ?>', 'javascript:bookmarkdelete(checkselected())'],
        [null, '<?php echo $msg_toggle_selection; ?>', 'javascript:togglebox()'],
    ],
];
--></script>

	<?php
	echo '<div id="bm"><b>' . $msg_search_results . '</b></div>';
	require_once ("./bookmarks.php");
	$bookmarks = & new bookmarks;
	$bookmarks->display_bookmarks ();
	?>
	<br>
	<input type="button" value="<?php echo $msg_search_new; ?>" onClick="self.location.href='<?php echo $_SERVER['SCRIPT_NAME']; ?>'">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	<script language="JavaScript"><!--
		cmDraw('bm', bookmarks, 'hbr', cmThemeOffice, 'ThemeOffice');
	--></script>
	<?php
}

require_once ("./footer.php");
?>
