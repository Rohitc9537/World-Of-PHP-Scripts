<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$folder = set_get_folder ();
?>

<h1><?php echo $title;?></h1>

<script language="JavaScript"><!--
var folderstools =
[
    [null, '<b><?php echo $msg_folder; ?></b>', null, null, null,
        [null, '<?php echo $msg_new; ?>', 'javascript:foldernew(\'<?php echo $folder; ?>\')'],
        [null, '<?php echo $msg_rename; ?>', 'javascript:folderrename(\'<?php echo $folder; ?>\')'],
        [null, '<?php echo $msg_move; ?>', 'javascript:foldermove(\'<?php echo $folder; ?>\',\'<?php echo $_SERVER['QUERY_STRING']; ?>\')'],
        [null, '<?php echo $msg_delete; ?>', 'javascript:folderdelete(\'<?php echo $folder; ?>\')'],
        [null, '<?php echo $msg_collaps_all; ?>', '<?php echo $_SERVER['SCRIPT_NAME']; ?>'],
    ],
    [null, '<b><?php echo $msg_tools; ?></b>', null, null, null,
        [null, '<?php echo $msg_search; ?>', 'javascript:search()'],
        [null, '<?php echo $msg_import; ?>', './import.php'],
        [null, '<?php echo $msg_export; ?>', './export.php?<?php echo $_SERVER['QUERY_STRING']; ?>'],
        [null, '<?php echo $msg_trash; ?>', 'javascript:trash()'],
        [null, 'Settings', './settings.php'],
    ],
];

var bookmarks =
[
    [null, '<b><?php echo $msg_bookmarks; ?></b>', null, null, null,
        [null, '<?php echo $msg_new; ?>', 'javascript:bookmarknew(\'<?php echo $folder; ?>\')'],
        [null, '<?php echo $msg_edit; ?>', 'javascript:bookmarkedit(checkselected(),\'<?php echo $folder; ?>\')'],
        [null, '<?php echo $msg_move; ?>', 'javascript:bookmarkmove(checkselected(),\'<?php echo $_SERVER['QUERY_STRING']; ?>\')'],
        [null, '<?php echo $msg_delete; ?>', 'javascript:bookmarkdelete(checkselected())'],
        [null, '<?php echo $msg_toggle_selection; ?>', 'javascript:togglebox()'],
    ],
];
--></script>

<table valign="top" style="border: 1px #8C867B solid" cellpadding="0" cellspacing="0">

  <tr class="menu">
    <td style="padding:4px; border-bottom:1px #8C867B solid"><div id="ft" class="menu"></div><img src="./images/spacer.gif" alt="" width="<?php echo $setting['column_width_folder']; ?>" height="0"></td>
    <td style="padding:4px; border-bottom:1px #8C867B solid"><div id="bm" class="menu"></div><img src="./images/spacer.gif" alt="" width="<?php echo $setting['column_width_bookmark']; ?>" height="0"></td>
    <td style="border-bottom:1px #8C867B solid">&nbsp;</td>
  </tr>

  <tr>
    <td valign="top" width="<?php echo $setting['column_width_folder']; ?>" style="padding-top: 10px">
      <div class="folder">
	<?php
	require_once ("./folders.php");
	$tree = & new folder;
	$tree->make_tree (0);
	$tree->print_tree ();
	?>
      </div>
    </td>
    <td valign="top" width="<?php echo $setting['column_width_bookmark']; ?>">
	<?php
	require_once ("./bookmarks.php");
	$bookmarks = & new bookmarks;
	$bookmarks->display_bookmarks ();
	?>
    </td>
    <td>
      <img src="./images/spacer.gif" alt="" width="1" height="<?php echo $setting['table_height']; ?>">
    </td>
  </tr>

</table>

<script language="JavaScript"><!--
cmDraw ('ft', folderstools, 'hbr', cmThemeOffice, 'ThemeOffice');
cmDraw('bm', bookmarks, 'hbr', cmThemeOffice, 'ThemeOffice');
--></script>

<br><span style="font:italic 10pt Verdana"><a href="http://www.frech.ch/online-bookmarks/" target="_blank">online-bookmarks</a> 
<?php @readfile ("./VERSION"); ?> by stefan frech</span>

<?php
require_once("./footer.php");
?>
