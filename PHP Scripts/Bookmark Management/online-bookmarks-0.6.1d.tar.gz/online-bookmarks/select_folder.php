<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once("./header.php");

$folder = set_get_folder ();

?>

<script language="JavaScript">
<!--
function setfolder () {
  var path = window.opener.document.URL;
  searchstring = /(folder=[0-9]*)/gi;
  result = searchstring.test(path);

  if(result == false) {
    urlparams = window.opener.location.search;
    if (urlparams == "") {
      result = path + "?folder=<?php echo $folder; ?>";
    }
    else {
      result = path + "&folder=<?php echo $folder; ?>";
    }
  }
  else {
    result = path.replace (searchstring,"folder=<?php echo $folder; ?>");
  }
  window.opener.location = result;
  window.close();
}
//-->
</script>

<p><?php echo $msg_folder_select;?></p>
<p><?php
require_once ("./folders.php");
$tree = & new folder;
$tree->make_tree (0);
$tree->print_tree ();
?></p>
<p><a href="javascript:foldernew('<?php echo $folder; ?>')"><?php echo $folder_closed ;?> <?php echo $msg_folder_new; ?></a></p>
<input type="button" value="<?php echo $msg_ok; ?>" onClick="setfolder()">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="window.close()">

<?php
require_once("./footer.php");
?>
