<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$name = set_post_name ();
$folder = set_get_folder ();

if ($name == "") {
?>

<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder; ?>" name="folder_new" method="POST">
<p><?php echo $msg_folder_new_name; ?><br>
<input type=text name="name" size="50" value=""></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
</form>
<script>
document.folder_new.name.focus();
</script>

<?php
}
else {
	$query = sprintf ($sql_new_folder, $folder, $name, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}

require_once ("./footer.php");
?>