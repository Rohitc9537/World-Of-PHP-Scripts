<?php
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
## All symbols below could actually be something else than a gif.
## It is also possible to replace these values by some ascii stuff.
## The symbol for the closed folder
$folder_closed = '<img src="./images/folder.gif" border="0" alt="" align="middle">';

## The symbol for the opened folder
$folder_opened = '<img src="./images/folder_open.gif" border="0" alt="" align="middle">';

## The symbol for a bookmark
$bookmark_image = '<img src="./images/bookmark_image.gif" align="middle" border="0" alt="">';

## The symbol for the plus sign of a collapsed folder tree
$plus = '<img src="./images/plus.gif" align="middle" border="0" alt="">&nbsp;';
#$plus = '<span class="symbol">+&nbsp;</span>';

## The symbol for the minus sign of a expanded folder tree
$minus = '<img src="./images/minus.gif" align="middle" border="0" alt="">&nbsp;';
#$minus = '<span class="symbol">-&nbsp;</span>';

## Set "neutral" to something similar as "plus" and "minus", so it fits the tree width
$neutral = '<img src="./images/spacer.gif" border="0" alt="" width="13" height="1">&nbsp;';
#$neutral = '<span class="symbol">&nbsp;&nbsp;</span>';

## The symbol to edit a bookmark
$edit_image = '<img src="./images/edit.gif" align="middle" border="0" alt="' . $msg_edit . '">';
#$edit_image = 'e';

## The symbol to move a bookmark
$move_image = '<img src="./images/move.gif" align="middle" border="0" alt="' . $msg_move . '">';
#$move_image = 'm';

## The symbol to delete a bookmark
$delete_image = '<img src="./images/delete.gif" align="middle" border="0" alt="' . $msg_delete . '">';
#$delete_image = 'd';

## The delimiter that should be used when displaying a path
#$delimiter = " >> ";
$delimiter = "/";

?>
