<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

require_once ("./config/config.php");
require_once ("./sql/queries.php");

function db_connect () {
	$server = 'localhost';	# this is the place where your MySQL Server is found.
	$user = 'bookmarkmgr';	# the user that connects to it ...
	$pw = 'password';	# ... and its password.
	$db = 'bookmarks';	# in this database are the online-bookmarks stored.

	$link = mysql_connect ($server, $user, $pw)
	or die ("no connection to server");
	if ($link && mysql_select_db ("$db")) {
		return ($link);
	}
	else {
		return (FALSE);
	}
}

?>
