<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");
require_once ("./folders.php");

$name = set_post_name ();
$folder = set_get_folder ();
$sourcefolder = set_post_sourcefolder ();
$tree = & new folder;
$parents = $tree->get_path_to_root ($folder);

if ($sourcefolder == "") {
	?>
	
	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder . "&expand=" . $_GET['expand'];?>" method="POST" name="movefolder">
	<p><?php echo $msg_folder_move_to; ?></p>
	<?php
	$tree->make_tree (0);
	$tree->print_tree ();
	?>
	<br>
	<input type="hidden" name="sourcefolder">
	<p><a href="javascript:foldernew('<?php echo $folder; ?>')"><?php echo $folder_closed ;?> <?php echo $msg_folder_new; ?></a></p>
	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>
	<script type="text/javascript">
		document.movefolder.sourcefolder.value = self.name;
	</script>

	<?php
}
else if ($sourcefolder == $folder) {
	echo '<script language="JavaScript">self.close();</script>';
}
else if (in_array ($sourcefolder, $parents)){
	echo $msg_cannot_move_folder;
}
else if ($sourcefolder != "" && $sourcefolder != $folder){
	$query = sprintf ($sql_move_folder, $folder, $sourcefolder, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}

require_once ("./footer.php");
?>