<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once("./messages/language.php");
?>

function reloadclose (){
  window.opener.location.reload();
  self.close();
}

function bookmarknew(folder) {
    bookmark_new = window.open("./bookmark_new.php?folder=" + folder, "bookmarknew","toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
}

function bookmarkedit(bookmark, folder) {
  if (bookmark==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_edit = window.open("./bookmark_edit.php?bookmark=" + bookmark + "&folder=" + folder, "bookmarkedit","toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function bookmarkmove(bmlist, url) {
  if (bmlist==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_move = window.open("./bookmark_move.php?" + url, bmlist, "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function bookmarkdelete(bmlist) {
  if (bmlist==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_delete = window.open("./bookmark_delete.php?bmlist=" + bmlist, "bookmarkdelete", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function foldernew(folder) {
  folder_new = window.open("./folder_new.php?folder=" + folder, "foldernew", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
}

function folderrename(folder) {
  if (folder=="" || folder=='0'){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_rename = window.open("./folder_rename.php?folder=" + folder, "folderrename", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
  }
}

function foldermove(folder, url) {
  if (folder=="" || folder=='0'){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_move = window.open("./folder_move.php?" + url, folder, "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function folderdelete(folder) {
  if (folder=="" || folder=="0"){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_delete= window.open("./folder_delete.php?folder=" + folder, "folderdelete", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
  }
}

function selectfolder(url) {
  select_folder = window.open("./select_folder.php" + url, "selectfolder", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=150,top=150");
}

function search() {
  search_item = window.open("./search.php", "search", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=400,left=50,top=50");
}

function trash() {
  trash_window = window.open("./trash.php", "trash", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=400,left=50,top=50");
}

function checkselected(){
var i;
var parameter='';
  for ( i = 0; i < window.document.forms['bookmarks'].elements.length; i++) {
    if (window.document.forms['bookmarks'].elements[i].checked == true) {
      parameter = parameter + window.document.forms['bookmarks'].elements[i].name + "_";
    }
  }
  result=parameter.replace(/_$/,"");
  return result
}

/* This function is from the following location:
   http://www.squarefree.com/bookmarklets/
*/
function togglebox(){
  function toggle(box){
    temp=box.onchange;
    box.onchange=null;
    box.checked=!box.checked;
    box.onchange=temp;
  }

  var x,k,f,j;
  x=document.forms;

  for (k=0; k<x.length; ++k){
    f=x[k];
    for (j=0;j<f.length;++j){
      if (f[j].type.toLowerCase() == "checkbox"){
        toggle(f[j]);
      }
    }
  }
}
