<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

# if no post has occured, print all bookmarks in the trash
if (!isset($_POST['item']) || count ($_POST['item']) == 0) {
}
else if (count ($_POST['item']) > 0 && isset($_POST['restore'])) {
	$bmlist = implode (",", $_POST['item']);
	$query = sprintf ($sql_restore, $bmlist, $user);
	mysql_query ("$query") or die (mysql_error ());
}
else if (count ($_POST['item']) > 0 && isset ($_POST['delete'])) {
	$bmlist = implode(",", $_POST['item']);
	$query = sprintf ($sql_delete, $bmlist, $user);
	mysql_query ("$query") or die (mysql_error ());
}

$query = sprintf ($sql_get_deleted, $user);
$bookmarks = mysql_query ("$query") or die (mysql_error ());

?>

<p><?php echo $msg_trash; ?></p>
<a href="javascript:togglebox()">Toggle Selection</a>
<form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" name="trash" method="POST">
<?php
while ($bookmark_list = mysql_fetch_object ($bookmarks)) {
	echo '<input type="checkbox" name="item[]" value="' . $bookmark_list->id . '">';
	if ($setting['show_bookmark_icon']){
		echo " " . $bookmark_image;
	}
	echo " " . $bookmark_list->title . "<br>\n";
}
?>
<br><br>
<input type="submit" value="<?php echo $msg_restore; ?>" name="restore">
<input type="submit" value="<?php echo $msg_delete; ?>" name="delete">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="reloadclose()">
</form>

<?php
require_once("./footer.php");
?>

