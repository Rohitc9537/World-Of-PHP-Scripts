<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$folder = set_get_folder ();
$post_bookmarks = set_post_bookmarks ();

if ($post_bookmarks == "") {
	?>
	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?folder=" . $folder; ?>" method="POST" name="bookmarksmove">
	<p><?php echo $msg_bookmark_move_to; ?></p>
	<?php
	require_once ("./folders.php");
	$tree = & new folder;
	$tree->make_tree (0);
	$tree->print_tree ();
	?>
	<input type="hidden" name="bookmarks">
	<p><a href="javascript:foldernew('<?php echo $folder; ?>')"><?php echo $folder_closed . " " . $msg_folder_new; ?></a></p>
	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>

	<script type="text/javascript">
	document.bookmarksmove.bookmarks.value = self.name;
	</script>
	<?php
}
else if ($folder == "") {
	echo $msg_no_destination_folder;
}
else {
	$bm_list = set_bmlist ($post_bookmarks);
	$query = sprintf ($sql_move_bookmarks, $folder, $bm_list, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}

require_once ("./footer.php");
?>