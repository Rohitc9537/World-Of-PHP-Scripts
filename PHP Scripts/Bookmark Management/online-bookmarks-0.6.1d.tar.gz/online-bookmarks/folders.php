<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

class folder {

	function folder () {
		$user = $GLOBALS['user'];
		global $setting, $sql_get_folders;
		$query = sprintf ($sql_get_folders, $user);
		$folders_result = mysql_query ("$query") or die (mysql_error ());

		while ($row = mysql_fetch_assoc ($folders_result)) {
			$this->folders[$row['id']] = $row;
			if (!isset ($this->children[$row['childof']])) {
				$this->children[$row['childof']] = array ();
			}
			array_push ($this->children[$row['childof']], $row['id']);
		}

		$this->folder = set_get_folder ();
		$this->tree = array ();
		$this->get_children = array ();
		$this->level = 0;

		if ($setting['simple_tree_mode']) {
			$this->expand = $this->get_path_to_root ($this->folder);
		}
		else {
			$this->expand = purge_expand_list ();
		}
	}

	# assembles the tree
	function make_tree ($id) {
		if (isset ($this->children)){
			$this->level++;
			foreach ($this->children[$id] as $value) {
				$this->tree[$value]['level'] = $this->level;
				$this->tree[$value]['id'] = $value;
				$this->tree[$value]['name'] = $this->folders[$value]['name'];
				# check for children
				if (isset ($this->children[$value])) {
					if (in_array ($value, $this->expand)) {
						$this->tree[$value]['symbol'] = "minus";
						$this->make_tree ($value);
					}
					else {
						$this->tree[$value]['symbol'] = "plus";
					}
				}
				else {
					$this->tree[$value]['symbol'] = "";
				}
			}
			$this->level--;
		}
	}

	# draws the tree
	function print_tree () {
		require ("./config/config.php");
		global $setting;

		# the following if condition has been disabled. could be enabled to
		# allow the "show_root_folder" function.
		#if ($show_root_folder) {
			$root_folder = array (
				'level' => 0,
				'id' => 0,
				'name' => $setting['root_folder_name'],
				'symbol' => null,
			);
			array_unshift ($this->tree, $root_folder);
		#}

		foreach ($this->tree as $value) {

			# this is the begining of the line that shows a folder
			# with the symbol (plus, minus or neutral)
			$spacer = '<div style="margin-left:' . $value['level'] * 20 . 'px;">';
			echo $spacer;

			if ($value['id'] == $this->folder) {
				$folder_name = '<span class="active">' . $value['name'] . '</span>';
				$folder_image = $folder_opened;
			}
			else {
				$folder_name = $value['name'];
				$folder_image = $folder_closed;
			}

			if ($value['symbol'] == "plus" || $value['symbol'] == "minus") {
				if ($value['symbol'] == "plus") {
					$symbol = $plus;
					$expand_s = $this->add_to_expand_list ($value['id']);
					if ($setting['fast_folder_plus']) {
						$expand_f = $expand_s;
					}
					else {
						$expand_f = $this->expand;
					}
				}
				else if ($value['symbol'] == "minus") {
					$symbol = $minus;
					$expand_s = $this->remove_from_expand_list ($value['id']);
					if ($setting['fast_folder_minus'] && $value['id'] == $this->folder) {
						$expand_f = $expand_s;
					}
					else {
						$expand_f = $this->expand;
					}
				}
				if ($setting['fast_symbol']) {
					$folder = $value['id'];
				}
				else {
					$folder = $this->folder;
				}
				# this prints the symbol (plus or minus) with its appropriate link
				echo '<a href="' . $_SERVER['SCRIPT_NAME'] . '?expand=' . implode(",", $expand_s);
				echo '&amp;folder=' . $folder . '">' . $symbol . '</a>';
			}
			else {
				$symbol = $neutral;
				$expand_f = $this->expand;
				echo $symbol;
			}

			# this prints the folder name with its appropriate link
			echo '<a href="' . $_SERVER['SCRIPT_NAME'] . '?expand=' . implode(",", $expand_f);
			echo '&amp;folder=' . $value['id'] . '">' . $folder_image . " " . $folder_name . '</a>';
			# and this is the end of the line
			echo "</div>\n";
		}
	}

	###
	### removes a value from the expand list
	###
	function remove_from_expand_list ($id){
		$expand = $this->expand;
		foreach ($expand as $key => $value) {
			if ($value == $id) {
				unset ($expand[$key]);
			}
		}
		return $expand;
	}

	###
	### adds a value to the expand list
	###
	function add_to_expand_list ($id){
		$expand = $this->expand;
		array_push ($expand, $id);
		return $expand;
	}

	###
	### returns an array containing all folder id's from
	### a given folder up to the root folder
	###
	function get_path_to_root ($id) {
		$path = array ();
		while ($id > 0) {
			array_push ($path, $id);
			if (!isset ($this->folders[$id])) {
				die ("possible inconsistency in folder database at folder #$id");
			}
			else {
				$id = $this->folders[$id]['childof'];
			}
		}
		return $path;
	}

	###
	### prints a path
	###
	function print_path ($id) {
		global $setting;
		$parents = $this->get_path_to_root ($id);
		$parents = array_reverse ($parents);
		# the following if condition has been disabled. could be enabled to
		# allow the "show_root_folder" function.
		#if ($GLOBALS['show_root_folder']){
			echo $GLOBALS['delimiter'] . $setting['root_folder_name'];
		#}
		foreach ($parents as $value) {
			echo $GLOBALS['delimiter'] . $this->folders[$value]['name'];
		}
	}

	###
	### returns an array containing all folder id's that 
	### are children from a given folder
	###
	function get_children ($id) {
		if (isset ($this->children[$id])) {
			foreach ($this->children[$id] as $value) {
				array_push ($this->get_children, $value);
				$this->get_children ($value);
			}
		}
	}
}

?>
