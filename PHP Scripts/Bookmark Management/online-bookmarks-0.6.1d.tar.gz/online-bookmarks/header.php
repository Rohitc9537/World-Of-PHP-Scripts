<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

require ("./main.php");

# set the $title variable
$scriptname = basename ($_SERVER['SCRIPT_NAME']);

if ($scriptname == "bookmark_new.php"){
	$title = $msg_title_bookmark_new;
}
else if ($scriptname == "bookmark_delete.php"){
	$title = $msg_title_bookmark_delete;
}
else if ($scriptname == "bookmark_edit.php"){
	$title = $msg_title_bookmark_edit;
}
else if ($scriptname == "bookmark_move.php"){
	$title = $msg_title_bookmark_move;
}
else if ($scriptname == "folder_new.php"){
	$title = $msg_title_folder_new;
}
else if ($scriptname == "folder_delete.php"){
	$title = $msg_title_folder_delete;
}
else if ($scriptname == "folder_rename.php"){
	$title = $msg_title_folder_rename;
}
else if ($scriptname == "folder_move.php"){
	$title = $msg_title_folder_move;
}
else if ($scriptname == "export.php"){
	$title = $msg_title_export_bookmarks;
}
else if ($scriptname == "import.php"){
	$title = $msg_title_import_bookmarks;
}
else if ($scriptname == "trash.php"){
	$title = $msg_trash;
}
else if ($scriptname == "search.php"){
	$title = $msg_title_search;
}
else if ($scriptname == "select_folder.php"){
	$title = $msg_folder_select;
}
else{
	$title = $msg_title . $user;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <!--
    online-bookmarks by Stefan Frech,
    to be found at http://www.frech.ch/online-bookmarks/
     -->
    <title><?php echo $title; ?></title>
    <meta http-equiv="content-type" content="text/html; charset=<?php echo $charset;?>">
    <meta http-equiv="expires" content="0">
    <link rel="stylesheet" type="text/css" href="./style.css">
    <script src="functions.php" type="text/javascript"></script>

<?php
if ($scriptname == "index.php" || $scriptname == "search.php" || $scriptname == "") {
	?>
	<SCRIPT LANGUAGE="JavaScript" SRC="./menu/menu.js"></SCRIPT>
	<LINK REL="stylesheet" HREF="./menu/theme.css" TYPE="text/css">
	<SCRIPT LANGUAGE="JavaScript" SRC="./menu/theme.js"></SCRIPT>
	<?php
}
?>

  </head>

<body bgcolor="#ffffff">
