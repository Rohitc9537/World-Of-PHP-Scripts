<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

function display_login () {
	Header ("WWW-Authenticate: Basic realm=\"online-bookmarks\"");
	Header ("HTTP/1.0 401 Unauthorized");
	echo "login failed";
	exit;
}

if (!isset ($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] == "") {
	display_login ();
}
else{
	$user = addslashes ($_SERVER['PHP_AUTH_USER']);
	$pw = md5 ($_SERVER['PHP_AUTH_PW']);
	require_once ("./config/connect.php");
	db_connect ();
	$query = sprintf ($sql_get_username, $user, $pw);
	$result = mysql_query ("$query") or die (mysql_error ());
	
	if (mysql_num_rows ($result) == 0) {
		display_login ();
	}
	else {
		$setting = mysql_fetch_assoc ($result);

		# how about a little security?
		unset ($setting['password']);
	}
}

?>
