<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");
$folder = set_GET_folder();

echo "<h1>$title</h1>\n";
echo '<a href="./">[<b>' . $msg_online_bookmarks . '</b>]</a><br><br>' . "\n";

if (!isset ($_FILES['importfile']['tmp_name']) || $_FILES['importfile']['tmp_name'] == null){
	# get the browser type for default setting below if possible
	if( eregi ("opera", $_SERVER['HTTP_USER_AGENT'])){
		$default_browser = "opera";
	}
	else{
		$default_browser = "netscape";
	}

?>

<form enctype="multipart/form-data" action="<?php echo $_SERVER['SCRIPT_NAME'];?>" method="post">
  <table valign="top" border="0">
    <tr>
      <td>
        from Browser:
      </td>
      <td>
        <select name="browser">
          <option value="netscape"<?php if ($default_browser=="netscape"){echo " selected";} ?>>Netscape / Mozilla / IE</option>
          <option value="opera"<?php if ($default_browser=="opera"){echo " selected";} ?>>Opera .adr</option>
        </select>
      </td>
    </tr>

    <tr>
      <td>
        select File:
      </td>
      <td>
        <input type="file" name="importfile">
      </td>
    </tr>

    <tr>
      <td>
        Destination Folder:
      </td>
      <td>
	<?php
	require_once ("./folders.php");
	$tree = & new folder;
	$tree->make_tree (0);
	$tree->print_tree ();
	?>      </td>
    </tr>

    <tr>
      <td>
      </td>
      <td>
        <p><a href="javascript:foldernew('<?php echo $folder; ?>')"><?php echo $folder_closed ;?> <?php echo $msg_folder_new; ?></a></p>
      </td>
    </tr>

    <tr>
      <td>
        <input type="hidden" name="folder" value="<?php echo $folder; ?>">
        <input type="submit" value="Import">
      </td>
      <td>
      </td>
    </tr>

  </table>
</form>

<?php
}
else{
	if(!isset($_POST['browser']) || $_POST['browser'] == ""){
		die ("no browser selected");
	}

	if (!isset ($_POST['folder']) || $_POST['folder'] == "") {
		$folder = 0;
	}
	else if (!is_numeric ($_POST['folder'])) {
		$folder = 0;
	}
	else{
		$folder = $_POST['folder'];
	}

	$import = & new import;

	if ($_POST['browser'] == "opera") {
		$import->import_opera ();
	}
	else if ($_POST['browser'] == "netscape") {
		$import->import_netscape ();
	}

	echo "$import->count_folders folders and ";
	echo "$import->count_bookmarks bookmarks imported";
}

class import {
	function import () {
		# open the importfile
		$this->fp = fopen ($_FILES['importfile']['tmp_name'], "r");
		if ($this->fp == null){
			die ("Failed to open file");
		}

		$this->count_folders = 0;
		$this->count_bookmarks = 0;

		$this->parent_folder = $GLOBALS['folder'];
		$this->current_folder = $this->parent_folder;
		
		$this->folder_depth = array ();

		$this->sql_new_folder = $GLOBALS['sql_new_folder'];
		$this->sql_new_bookmark = $GLOBALS['sql_new_bookmark'];
		$this->user = $GLOBALS['user'];
	}

	function import_opera () {
		while (!feof ($this->fp)) {
			$line = trim (fgets ($this->fp, 4096));
			$line = htmlentities ($line, ENT_QUOTES);

			# a folder has been found
			if ($line == "#FOLDER"){
				$item = "Folder";
			}
			# a bookmark has been found
			else if($line == "#URL"){
				$item = "Bookmark";
			}
			# if a line starts with NAME= ...
			else if (substr ($line, 0, strlen("NAME=")) == "NAME=") {
				$line = substr ($line, strlen ("NAME="));
				# ... depending on the value of "$item" we assign the name to
				# either folder or bookmark.
				if ($item == "Folder") {
					$this->name_folder = $line;
				}
				else if ($item == "Bookmark") {
					$this->name_bookmark = $line;
				}
			}
			# only bookmarks can have a description or/and an url.
			else if (substr ($line, 0, strlen ("DESCRIPTION=")) == "DESCRIPTION=") {
				$this->description = substr ($line, strlen ("DESCRIPTION="));
			}
			else if (substr ($line, 0, strlen ("URL=")) == "URL=") {
				$this->url = substr ($line, strlen ("URL="));
			}
			# process the corresponding item, if there is an empty line found
			else if ($line == "") {
				if (isset ($item) && $item == "Folder") {
					$this->folder_new ();
					unset ($item);
				}
				else if (isset ($item) && $item == "Bookmark") {
					$this->bookmark_new ();
					unset ($item);
				}
			}
			# this indicates, that the folder is being closed
			else if ($line == "-") {
				$this->folder_close ();
			}
		}
	}

	function import_netscape () {
		while (!feof ($this->fp)){
			$line = trim (fgets ($this->fp, 4096));

			# a folder has been found
			if (ereg ("<DT><H3", $line)) {
				$this->name_folder = htmlentities (ereg_replace ("^( *<DT><[^>]*>)([^<]*)(.*)", "\\2", $line), ENT_QUOTES);
				$this->folder_new ();
			}
			# a bookmark has been found
			else if (ereg("<DT><A", $line)){
				$this->name_bookmark = htmlentities (ereg_replace ("^( *<DT><[^>]*>)([^<]*)(.*)", "\\2", $line), ENT_QUOTES);
				$this->url = htmlentities (ereg_replace ("([^H]*HREF=\")([^\"]*)(\".*)", "\\2", $line), ENT_QUOTES);
				$this->description = null;
				$this->bookmark_new ();
			}
			# this indicates, that the folder is being closed
			else if ($line == "</DL><p>") {
				$this->folder_close ();
			}
		}
	}

	function folder_new () {
		if (!isset ($this->name_folder)) {
			$this->name_folder == "";
		}
		$query = sprintf ($this->sql_new_folder, $this->current_folder, $this->name_folder, $this->user);
		mysql_query ("$query") or die (mysql_error ());
		$this->current_folder = mysql_insert_id ();
		array_push ($this->folder_depth, $this->current_folder);
		unset ($this->name_folder);
		$this->count_folders++;
	}

	function bookmark_new () {
		if (!isset ($this->name_bookmark)) {
			$this->name_bookmark = "";
		}
		if (!isset ($this->url)) {
			$this->url = "";
		}
		if (!isset ($this->description)) {
			$this->description = "";
		}
		$query = sprintf ($this->sql_new_bookmark, $this->user, $this->name_bookmark, $this->url, $this->description, $this->current_folder);
		mysql_query ("$query") or die (mysql_error ());
		unset ($this->name_bookmark, $this->url, $this->description);
		$this->count_bookmarks++;
	}

	function folder_close () {
		if (count ($this->folder_depth) <= 1) {
			$this->folder_depth = array ();
			$this->current_folder = $this->parent_folder;
		}
		else{
			# remove the last folder from the folder history
			unset ($this->folder_depth[count ($this->folder_depth) - 1]);
			$this->folder_depth = array_values ($this->folder_depth);
			# set the last folder to the current folder
			$this->current_folder = $this->folder_depth[count ($this->folder_depth) - 1];
		}
	}
}

require_once("./footer.php");
?>
