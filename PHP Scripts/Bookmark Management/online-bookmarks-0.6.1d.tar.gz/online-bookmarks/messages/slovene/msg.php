<?php

$msg_online_bookmarks=          "online zaznamki";
$msg_title=			"online zaznamki osebe ";
$msg_path=			"Ti si tukaj: ";
$msg_search=		 	"Išči";
$msg_folder=			"Mapa";
$msg_refresh=			"Osveži";
$msg_close_all=			"Zapri vse";
$msg_bookmarks=			"Zaznamek";
$msg_rename=			"Preimenuj";
$msg_edit=			"Uredi";
$msg_move=			"Premakni";
$msg_delete=			"Izbriši";
$msg_restore=			"Obnovi";
$msg_new=			"Nov(a)";
$msg_move_selected=		"Premakni izbrane";
$msg_delete_selected=		"Izbriši izbrane";
$msg_folder_rename=		"Novo ime";
$msg_folder_new=		"Nova mapa";
$msg_folder_new_name=		"Ime";
$msg_folder_move_to=		"Premakni mapo v:";
$msg_folder_delete=		"Izbriši to mapo?";
$msg_folder_select=             "Izberi/Spremeni mapo";
$msg_no_destination_folder=	"Ni izbrane mape";
$msg_no_folder_selected=	"Ni izbrane mape";
$msg_folder_does_not_exist=	"Mapa ne obstaja";
$msg_cannot_move_folder=	"Mape se ne da premakniti v lastno podmapo";
$msg_bookmark_new=		"Nov zaznamek";
$msg_bookmark_title=		"Naslov";
$msg_bookmark_url=		"Internetni naslov";
$msg_bookmark_description=	"Opis";
$msg_bookmark_move_to=		"Premakni zazanamke:";
$msg_bookmark_delete=		"Izbriši zaznamke?";
$msg_bookmark_not_selected=	"Noben zaznamek ni izbran";
$msg_sql_error=			"Napaka SQL";
$msg_ok=			" V redu ";
$msg_cancel=			" Prekliči ";
$msg_last_edited=		"Nazadnje spremenjen";
$msg_trash=			"Smeti";
$msg_tools=			"Orodja";
$msg_collaps_all=		"Podri vse";
$msg_toggle_selection=		"Preklopi izbiro";

$msg_title_bookmark_delete=     "Izbriši zaznamek";
$msg_title_bookmark_edit=       "Uredi zaznamek";
$msg_title_bookmark_move=       "Premakni zaznamek";
$msg_title_bookmark_new=	"Nov zaznamek";
$msg_title_folder_delete=       "Izbriši mapo";
$msg_title_folder_move=         "Premakni mapo";
$msg_title_folder_new=          "Nova mapa";
$msg_title_folder_rename=       "Preimenuj mapo";
$msg_title_export_bookmarks=	"Izvozi zaznamke";
$msg_title_import_bookmarks=	"Uvozi zaznamke";

$msg_title_search=              "Išči";
$msg_search_string=             "Išči";
$msg_search_results=		"Rezultat iskanja";
$msg_search_new=		"Novo iskanje";
$msg_import=			"Uvozi";
$msg_export=			"Izvozi";

$charset="utf-8";

?>
