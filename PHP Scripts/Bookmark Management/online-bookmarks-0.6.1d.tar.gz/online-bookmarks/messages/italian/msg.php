<?php

$msg_online_bookmarks=          "segnalibri";
$msg_title=            "i segnalibri di ";
$msg_path=            "Voi siete qui: ";
$msg_search=             "Cerca";
$msg_folder=            "Cartella";
$msg_refresh=            "Aggiorna";
$msg_close_all=            "Chiudi tutto";
$msg_bookmarks=            "Bookmark";
$msg_rename=            "Rinomina";
$msg_edit=            "Modifica";
$msg_move=            "Sposta";
$msg_delete=            "Cancella";
$msg_restore=                   "Restore";
$msg_new=            "Nuovo";
$msg_move_selected=        "Sposta i selezionati";
$msg_delete_selected=        "Cancella i selezionati";
$msg_folder_rename=        "Nuovo nome";
$msg_folder_new=        "Nuova cartella";
$msg_folder_new_name=        "Nome";
$msg_folder_move_to=        "Sposta la cartella in:";
$msg_folder_delete=        "Cancello questa cartella?";
$msg_folder_select=             "Seleziona/Cambia cartella";
$msg_no_destination_folder=    "Cartella di destinazione non selezionata";
$msg_no_folder_selected=    "Nessuna cartella selezionata";
$msg_folder_does_not_exist=    "Questa cartella non esiste";
$msg_cannot_move_folder=    "Una cartella non puo' essere spostata in una sua sottocartella";
$msg_bookmark_new=        "Nuovo segnalibro";
$msg_bookmark_title=        "Titolo";
$msg_bookmark_url=        "Homepage";
$msg_bookmark_description=    "Descrizione";
$msg_bookmark_move_to=        "Sposta segnalibro in:";
$msg_bookmark_delete=        "Cancello questi segnalibri?";
$msg_bookmark_not_selected=    "Nessun segnalibro selezionato";
$msg_sql_error=            "errore SQL";
$msg_ok=            " OK ";
$msg_cancel=            " Annulla ";
$msg_last_edited=        "Modificato";
$msg_trash=            "Cestino";
$msg_tools=                     "Tools";
$msg_collaps_all=               "Collaps All";
$msg_toggle_selection=          "Toggle Selection";

$msg_title_bookmark_delete=     "Cancella Segnalibro";
$msg_title_bookmark_edit=       "Modifica Segnalibro";
$msg_title_bookmark_move=       "Sposta Segnalibro";
$msg_title_bookmark_new=    "Nuovo Segnalibro";
$msg_title_folder_delete=       "Cancella cartella";
$msg_title_folder_move=         "Sposta cartella";
$msg_title_folder_new=          "Nuova cartella";
$msg_title_folder_rename=       "Rinomina cartella";
$msg_title_export_bookmarks=    "Export Bookmarks";
$msg_title_import_bookmarks=    "Import Bookmarks";

$msg_title_search=              "Cerca";
$msg_search_string=             "Cerca elemento";
$msg_search_results=        "Risultati della ricerca";
$msg_search_new=        "Nuova ricerca";
$msg_import=        "Importa";
$msg_export=                    "Export";

$charset="iso-8859-2";

?>
