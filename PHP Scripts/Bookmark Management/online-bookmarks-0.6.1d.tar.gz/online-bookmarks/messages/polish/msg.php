<?php

//polish language translation for online-bookmarks
// 2004 Andrzej Rabiczko (franc-x@gazeta.pl)
// GPL

$msg_online_bookmarks=          "Zak�adki online";
$msg_title=			"Zak�adki u�ytkownika ";
$msg_path=			"Jeste� tutaj: ";
$msg_search=		 	"Szukaj";
$msg_folder=			"Folder";
$msg_refresh=			"Od�wie�";
$msg_close_all=			"Zamknij wszystko";
$msg_bookmarks=			"Zak�adki";
$msg_rename=			"Zmie� nazw�";
$msg_edit=			"Edytuj";
$msg_move=			"Przenie�";
$msg_delete=			"Skasuj";
$msg_restore=			"Przywr��";
$msg_new=			"Nowy";
$msg_move_selected=		"Przenie� zaznaczone";
$msg_delete_selected=		"Skasuj zaznaczone";
$msg_folder_rename=		"Nowa nazwa";
$msg_folder_new=		"Nowy folder";
$msg_folder_new_name=		"Nazwa";
$msg_folder_move_to=		"Przenie� folder do:";
$msg_folder_delete=		"Skasowa� ten folder?";
$msg_folder_select=             "Wybierz/Zmie� folder";
$msg_no_destination_folder=	"Nie wybrano docelowego folderu";
$msg_no_folder_selected=	"Nie wybrano folderu";
$msg_folder_does_not_exist=	"Folder nie istnieje";
$msg_cannot_move_folder=	"Folder nie mo�e by� przeniesiony w g��b swoich w�asnych folder�w";
$msg_bookmark_new=		"Nowa zak�adka";
$msg_bookmark_title=		"Tutu�";
$msg_bookmark_url=		"Strona domowa";
$msg_bookmark_description=	"Opis";
$msg_bookmark_move_to=		"Przenie� zak�adki do:";
$msg_bookmark_delete=		"Skasowa� te zak�adki?";
$msg_bookmark_not_selected=	"Nie wybrano �adnych zak�adek";
$msg_sql_error=			"B��d SQL";
$msg_ok=			" OK ";
$msg_cancel=			" Anuluj ";
$msg_last_edited=		"Zmodyfikowany";
$msg_trash=			"�mietnik";
$msg_tools=			"Narz�dzia";
$msg_collaps_all=		"Zwi� wszystkie";
$msg_toggle_selection=		"Odwr�� zaznaczenie";

$msg_title_bookmark_delete=     "Skasuj zak�adki";
$msg_title_bookmark_edit=       "Edytuj zak�adki";
$msg_title_bookmark_move=       "Przenie� zak�adki";
$msg_title_bookmark_new=	      "Nowa zak�adka";
$msg_title_folder_delete=       "Skasuj folder";
$msg_title_folder_move=         "Przenie� folder";
$msg_title_folder_new=          "Nowy folder";
$msg_title_folder_rename=       "Zmie� nazw� folderu";
$msg_title_export_bookmarks=	"Eksportuj zak�adki";
$msg_title_import_bookmarks=	"Importuj zak�adki";

$msg_title_search=              "Szukaj";
$msg_search_string=             "Szukaj";
$msg_search_results=		"Wyniki wyszukiwania";
$msg_search_new=		"Nowe wyszukiwanie";
$msg_import=			"Importuj";
$msg_export=			"Eksportuj";

$charset="iso-8859-2";

?>

