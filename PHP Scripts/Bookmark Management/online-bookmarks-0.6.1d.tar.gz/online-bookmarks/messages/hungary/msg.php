<?php

$msg_online_bookmarks=          "online k�nyvjelz�k";
$msg_title="online k�nyvjelz�k: ";
$msg_path="Itt vagy: ";
$msg_search= "Keres�s";
$msg_folder="Mappa";
$msg_refresh="Friss�t�s";
$msg_close_all="�sszes becsuk�sa";
$msg_bookmarks="K�nyvjelz�";
$msg_rename="�tnevez�s";
$msg_edit="Szerkeszt�s";
$msg_move="�thelyez�s";
$msg_delete="T�rl�s";
$msg_restore=                   "Restore";
$msg_new="�j";
$msg_move_selected="Kijel�ltek �thelyez�se";
$msg_delete_selected="Kijel�ltek t�rl�se";
$msg_folder_rename="�j n�v";
$msg_folder_new="�j mappa";
$msg_folder_new_name="N�v";
$msg_folder_move_to="A mappa �thelyez�se:";
$msg_folder_delete="Let�r�ljem ezt a mapp�t?";
$msg_folder_select=             "V�lasszon/v�ltoztasson mapp�t";
$msg_no_destination_folder="Nincsen kiv�lasztva c�l mappa";
$msg_no_folder_selected="Nincsen mappa kiv�lasztva";
$msg_folder_does_not_exist="A mappa nem l�tezik";
$msg_cannot_move_folder="A mapp�t nem lehet elmozgatni egyik almapp�j�ba sem";
$msg_bookmark_new="�j k�nyvjelz�";
$msg_bookmark_title="N�v";
$msg_bookmark_url="URL";
$msg_bookmark_description="Le�r�s";
$msg_bookmark_move_to="Mozgassa a k�nyvjelz�ket ide:";
$msg_bookmark_delete="Let�r�ljem ezeket a k�nyvjelz�ket?";
$msg_bookmark_not_selected="Nincsen k�nyvjelz� kijel�lve";
$msg_sql_error="SQL hiba";
$msg_ok=" OK ";
$msg_cancel=" M�gsem ";
$msg_last_edited="V�ltoztatva";
$msg_trash="Kuka";
$msg_tools="Eszk�z�k";
$msg_collaps_all="Minden �sszecsuk�sa";
$msg_toggle_selection="Kijel�l�s v�ltoztat�sa";

$msg_title_bookmark_delete=     "K�nyvjelz�k t�rl�se";
$msg_title_bookmark_edit=       "K�nyvjelz� szerkeszt�se";
$msg_title_bookmark_move=       "K�nyvjelz� mozgat�sa";
$msg_title_bookmark_new="�j k�nyvjelz�";
$msg_title_folder_delete=       "Mappa t�rl�se";
$msg_title_folder_move=         "Mappa mozgat�sa";
$msg_title_folder_new=          "�j mappa";
$msg_title_folder_rename=       "Mappa �tnevez�se";
$msg_title_export_bookmarks="K�nyvjelz�k export�l�sa";
$msg_title_import_bookmarks="K�nyvjelz�k import�l�sa";

$msg_title_search=              "Keres�s";
$msg_search_string=             "Keres�s";
$msg_search_results="Keres�s eredm�nye";
$msg_search_new="�j keres�s";
$msg_import="Import�l�s";
$msg_export="Export�l�s";

$charset="iso-8859-2";

?>
