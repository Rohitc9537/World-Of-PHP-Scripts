<?php

$msg_online_bookmarks=          "online-bookmarks";
$msg_title=			"marcadores-bookmarks de ";
$msg_path=			"Estas en: ";
$msg_search=			"Buscar";
$msg_folder=			"Carpeta";
$msg_refresh=			"Actualizar";
$msg_close_all=			"Cerrar todos";
$msg_bookmarks=			"Marcador";
$msg_rename=			"Renonmbrar";
$msg_edit=			"Editar";
$msg_move=			"Mover";
$msg_delete=			"Borrar";
$msg_restore=                   "Restore";
$msg_new=			"Nuevo";
$msg_move_selected=		"Mover seleccionados";
$msg_delete_selected=		"Borrar seleccionados";
$msg_folder_rename=		"Nuevo nombre";
$msg_folder_new=		"Nueva carpeta";
$msg_folder_new_name=		"Nombre";
$msg_folder_move_to=		"Mover carpeta a:";
$msg_folder_delete=		"Borrar esta carpeta?";
$msg_folder_select=             "Seleccionar/Cambiar carpeta";
$msg_no_destination_folder=	"No ha seleccionado Carpeta de destino";
$msg_no_folder_selected=	"No ha seleccionado carpeta";
$msg_folder_does_not_exist=	"La carpeta no existe";
$msg_cannot_move_folder=	"Una carpeta no puede moverse a una de sus propias subcarpetas";
$msg_bookmark_new=		"Nuevo Marcador";
$msg_bookmark_title=		"Titulo";
$msg_bookmark_url=		"Inicio";
$msg_bookmark_description=	"Descripcion";
$msg_bookmark_move_to=		"Mover marcador a:";
$msg_bookmark_delete=		"Borrar este marcador?";
$msg_bookmark_not_selected=	"No ha seleccionado ningun marcador";
$msg_sql_error="		Error SQL";
$msg_ok=			" OK ";
$msg_cancel=			" Cancelar ";
$msg_last_edited=		"Modificado";
$msg_trash=                     "Basura";
$msg_tools=                     "Tools";
$msg_collaps_all=               "Collaps All";
$msg_toggle_selection=          "Toggle Selection";

$msg_title_bookmark_delete=     "Borrar Marcadores";
$msg_title_bookmark_edit=       "Editar Marcadores";
$msg_title_bookmark_move=       "Mover Marcadores";
$msg_title_bookmark_new=	"Nuevo Marcador";
$msg_title_folder_delete=       "Borrar Carpeta";
$msg_title_folder_move=         "Mover Carpeta";
$msg_title_folder_new=          "Nueva Carpeta";
$msg_title_folder_rename=       "Renombrar Carpeta";
$msg_title_export_bookmarks=    "Export Bookmarks";
$msg_title_import_bookmarks=    "Import Bookmarks";

$msg_title_search=              "Buscar";
$msg_search_string=             "Buscar marcador";
$msg_search_results=		"Resultados de busqueda";
$msg_search_new=		"Nueva busqueda";
$msg_import=                    "Import";
$msg_export=                    "Export";

$charset="iso-8859-2";

?>
