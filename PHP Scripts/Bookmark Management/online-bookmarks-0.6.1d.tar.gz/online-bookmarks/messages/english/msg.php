<?php

$msg_online_bookmarks=          "online-bookmarks";
$msg_title=			"online-bookmarks of ";
$msg_path=			"You are here: ";
$msg_search=		 	"Search";
$msg_folder=			"Folder";
$msg_refresh=			"Refresh";
$msg_close_all=			"Close all";
$msg_bookmarks=			"Bookmark";
$msg_rename=			"Rename";
$msg_edit=			"Edit";
$msg_move=			"Move";
$msg_delete=			"Delete";
$msg_restore=			"Restore";
$msg_new=			"New";
$msg_move_selected=		"Move selected";
$msg_delete_selected=		"Delete selected";
$msg_folder_rename=		"New name";
$msg_folder_new=		"New folder";
$msg_folder_new_name=		"Name";
$msg_folder_move_to=		"Move folder to:";
$msg_folder_delete=		"Delete this folder?";
$msg_folder_select=             "Select/Change folder";
$msg_no_destination_folder=	"No destination Folder selected";
$msg_no_folder_selected=	"No folder selected";
$msg_folder_does_not_exist=	"Folder does not exist";
$msg_cannot_move_folder=	"A folder cannot be moved to one of its own subfolders";
$msg_bookmark_new=		"New bookmark";
$msg_bookmark_title=		"Title";
$msg_bookmark_url=		"Homepage";
$msg_bookmark_description=	"Description";
$msg_bookmark_move_to=		"Move bookmarks to:";
$msg_bookmark_delete=		"Delete these bookmarks?";
$msg_bookmark_not_selected=	"No bookmarks selected";
$msg_sql_error=			"SQL error";
$msg_ok=			" OK ";
$msg_cancel=			" Cancel ";
$msg_last_edited=		"Modified";
$msg_trash=			"Trash";
$msg_tools=			"Tools";
$msg_collaps_all=		"Collapse All";
$msg_toggle_selection=		"Toggle Selection";

$msg_title_bookmark_delete=     "Delete Bookmarks";
$msg_title_bookmark_edit=       "Edit Bookmark";
$msg_title_bookmark_move=       "Move Bookmarks";
$msg_title_bookmark_new=	"New Bookmark";
$msg_title_folder_delete=       "Delete folder";
$msg_title_folder_move=         "Move folder";
$msg_title_folder_new=          "New folder";
$msg_title_folder_rename=       "Rename folder";
$msg_title_export_bookmarks=	"Export Bookmarks";
$msg_title_import_bookmarks=	"Import Bookmarks";

$msg_title_search=              "Search";
$msg_search_string=             "Search item";
$msg_search_results=		"Search results";
$msg_search_new=		"New search";
$msg_import=			"Import";
$msg_export=			"Export";

$charset="iso-8859-1";

?>
