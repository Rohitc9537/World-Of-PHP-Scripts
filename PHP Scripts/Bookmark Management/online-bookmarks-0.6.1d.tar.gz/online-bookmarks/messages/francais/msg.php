<?php

$msg_online_bookmarks=          "online-bookmarks";
$msg_title=			"online-bookmarks de ";
$msg_path=			"Vous &ecirc;tes ici&nbsp;: ";
$msg_search=		 	"Recherche";
$msg_folder=			"Dossier";
$msg_refresh=			"Rafraichir";
$msg_close_all=			"Tout fermer";
$msg_bookmarks=			"Signet";
$msg_rename=			"Renommer";
$msg_edit=			"Editer";
$msg_move=			"D&eacute;placer";
$msg_delete=			"Supprimer";
$msg_restore=			"Restore";
$msg_new=			"Nouveau";
$msg_move_selected=		"D&eacute;placer la section";
$msg_delete_selected=		"Supprimer la s&eacute;lection";
$msg_folder_rename=		"Nouveau nom";
$msg_folder_new=		"Nouveau dossier";
$msg_folder_new_name=		"Nom";
$msg_folder_move_to=		"D&eacute;placer le dossier vers:";
$msg_folder_delete=		"Vraiment supprimer ce dossier ?";
$msg_folder_select=             "Changer le dossier ";
$msg_no_destination_folder=	"Aucun dossier de destination indiqu&eacute;";
$msg_no_folder_selected=	"Aucun dossier s&eacute;lectionn&eacute;";
$msg_folder_does_not_exist=	"Le dossier n'existe pas";
$msg_cannot_move_folder=	"Un dossier ne peut &ecirc;tre d&eacute;plac&eacute; dans l'un de ses sous-dossiers";
$msg_bookmark_new=		"Nouveau signet";
$msg_bookmark_title=		"Titre";
$msg_bookmark_url=		"Page d'accueil";
$msg_bookmark_description=	"Description";
$msg_bookmark_move_to=		"D&eacute;placer les signets vers&nbsp;:";
$msg_bookmark_delete=		"Vraiment supprimer ces signets&nbsp;?";
$msg_bookmark_not_selected=	"Aucun signet s&eacute;lectionn&eacute;";
$msg_sql_error=			"Erreur SQL";
$msg_ok=			" OK ";
$msg_cancel=			" Annuler ";
$msg_last_edited=		"Modifi&eacute;";
$msg_trash=                     "Corbeille";
$msg_tools=                     "Tools";
$msg_collaps_all=               "Collaps All";
$msg_toggle_selection=          "Toggle Selection";

$msg_title_bookmark_delete=     "Supprimer les signet";
$msg_title_bookmark_edit=       "Editer les signets";
$msg_title_bookmark_move=       "D&eacute;placer les signets";
$msg_title_bookmark_new=	"Nouveau signet";
$msg_title_folder_delete=       "Supprimer un dossier";
$msg_title_folder_move=         "D&eacute;placer un dossier";
$msg_title_folder_new=          "Nouveau dossier";
$msg_title_folder_rename=       "Renommer un dossier";
$msg_title_export_bookmarks=    "Export Bookmarks";
$msg_title_import_bookmarks=    "Import Bookmarks";

$msg_title_search=              "Recherche";
$msg_search_string=             "Chercher un &eacute;l&eacute;ment";
$msg_search_results=		"R&eacute;sultat de recherche";
$msg_search_new=		"Nouvelle recherche";
$msg_import=                    "Import";
$msg_export=                    "Export";

$charset="iso-8859-2";

?>

