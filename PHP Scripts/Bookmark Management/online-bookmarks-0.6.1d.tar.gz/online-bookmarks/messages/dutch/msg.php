<?php

$msg_online_bookmarks=          "online-favorieten";
$msg_title="online-favorieten van ";
$msg_path="Je bent hier: ";
$msg_search= "Zoeken";
$msg_folder="Map";
$msg_refresh="Vernieuwen";
$msg_close_all="Alles sluiten";
$msg_bookmarks="Snelkoppeling";
$msg_rename="Hernoemen";
$msg_edit="Wijzigen";
$msg_move="Verplaatsen";
$msg_delete="Verwijderen";
$msg_restore="Terugzetten";
$msg_new="Nieuw";
$msg_move_selected="Geselecteerde verplaatsen";
$msg_delete_selected="Geselecteerde verwijderen";
$msg_folder_rename="Nieuwe naam";
$msg_folder_new="Nieuwe map";
$msg_folder_new_name="Naam";
$msg_folder_move_to="Verplaats map naar:";
$msg_folder_delete="Deze map verwijderen?";
$msg_folder_select=             "Andere map selecteren";
$msg_no_destination_folder="Geen doelmap geselecteerd";
$msg_no_folder_selected="Geen map geselecteerd";
$msg_folder_does_not_exist="De map bestaat niet";
$msg_cannot_move_folder="Een map kan niet naar een van de eigen submappen worden verplaatst";
$msg_bookmark_new="Nieuwe snelkoppeling";
$msg_bookmark_title="Titel";
$msg_bookmark_url="Link";
$msg_bookmark_description="Omschrijving";
$msg_bookmark_move_to="Verplaats snelkoppelingen naar:";
$msg_bookmark_delete="Deze snelkoppelingen verwijderen?";
$msg_bookmark_not_selected="Geen snelkoppelingen geselecteerd";
$msg_sql_error="SQL error";
$msg_ok=" OK ";
$msg_cancel=" Annuleren ";
$msg_last_edited="Aangepast op:";
$msg_trash="Prullenbak";
$msg_tools="Extra";
$msg_collaps_all="Alle mappen sluiten";
$msg_toggle_selection="Selectie Inverteren";

$msg_title_bookmark_delete=     "Snelkoppelingen Verwijderen";
$msg_title_bookmark_edit=       "Snelkoppelingen Wijzigen";
$msg_title_bookmark_move=       "Snelkoppelingen Verplaatsen";
$msg_title_bookmark_new="Nieuwe Snelkoppeling";
$msg_title_folder_delete=       "Map Verwijderen";
$msg_title_folder_move=         "Map Verplaatsen";
$msg_title_folder_new=          "Nieuwe Map";
$msg_title_folder_rename=       "Map Hernoemen";
$msg_title_export_bookmarks="Snelkoppelingen Exporteren";
$msg_title_import_bookmarks="Snelkoppelingen Importeren";

$msg_title_search=              "Zoeken";
$msg_search_string=             "Zoek snelkoppeling";
$msg_search_results="Zoekresultaten";
$msg_search_new="Nieuwe Zoekopdracht";
$msg_import="Importeren";
$msg_export="Exporteren";

$charset="iso-8859-1";

?>
