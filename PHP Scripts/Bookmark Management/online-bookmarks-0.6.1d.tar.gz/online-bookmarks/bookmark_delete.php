<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
require_once ("./header.php");

$get_bmlist = set_get_bmlist ();
$bmlist = set_bmlist ($get_bmlist);

if ($bmlist == ""){
	echo $msg_bookmark_not_selected;	
}
else if (!$setting['confirm_delete'] || (isset ($_GET['noconfirm']) && $_GET['noconfirm'] == '1')){
	$query = sprintf ($sql_set_delete_bookmarks, $bmlist, $user);
	mysql_query ("$query") or die (mysql_error ());
	echo '<script language="JavaScript">reloadclose();</script>';
}
else {
	$query = sprintf ($sql_confirm_delete_bookmarks, $bmlist, $user);
	$bookmarks = mysql_query ("$query") or die (mysql_error ()); ?>
	<p><?php echo $msg_bookmark_delete ?></p>
	<table border="0">
	<?php
	while ($bookmark_list = mysql_fetch_object ($bookmarks)){
		echo "<tr><td>";
		if ($setting['show_bookmark_icon']){
			echo $bookmark_image;
		}
		echo " " . $bookmark_list->title . "</td></tr>\n";
	}
	?>
	</table>
	<br>
	<form action="<?php echo $_SERVER['SCRIPT_NAME'] . "?bmlist=" . $get_bmlist . "&amp;noconfirm=1";?>" method="POST" name="bmdelete">
	<input type="submit" value="<?php echo $msg_ok; ?>">
	<input type="button" value="<?php echo $msg_cancel; ?>" onClick="self.close()">
	</form>
	<?php
}

require_once ("./footer.php");
?>
