<?php
/*
 * This file is part of the online-bookmarks project,
 * which you can find here:
 * http://www.frech.ch/online-bookmarks/
 *
 * This software is released under the General Public License
 * More detailes in the file 'GPL.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 */
if (basename ($_SERVER['SCRIPT_NAME']) == basename (__FILE__)) {
	die ("no direct access allowed");
}

###
### collection of sql queries
###
$sql_get_username =		"SELECT * FROM user WHERE username = '%s' AND password = '%s'";
$sql_get_folders =		"SELECT id, childof, name FROM folder WHERE user = '%s' AND deleted != '1' ORDER BY 'name'";
$sql_get_bookmarks = 		"SELECT title, url, description, DATE_FORMAT(date,'%%d.%%m.%%Y') AS timestamp, childof, id 
				 FROM bookmark 
				 WHERE user = '%s' 
				 AND childof = '%d' 
				 AND deleted != '1' 
				 ORDER BY 'title'";
$sql_get_bookmark =		"SELECT title, url, description, DATE_FORMAT(date,'%%d.%%m.%%Y') AS timestamp, childof, id 
				 FROM bookmark 
				 WHERE id = '%d' 
				 AND user = '%s' 
				 AND deleted != '1'";
$sql_get_all_bookmarks =	"SELECT title, url, description, childof, id
				 FROM bookmark 
				 WHERE user = '%s' 
				 AND deleted != '1'";
$sql_update_bookmark = 		"UPDATE bookmark set title = '%s', url = '%s', description = '%s', childof = '%d'
				 WHERE id='%d'
				 AND user = '%s'";
$sql_new_bookmark = 		"INSERT INTO bookmark (user, title, url, description, childof)
				 values ('%s', '%s', '%s', '%s', '%d')";
$sql_move_bookmarks =		"UPDATE bookmark SET childof = '%d' WHERE id IN (%s) AND user = '%s'";
$sql_confirm_delete_bookmarks =	"SELECT title, id FROM bookmark WHERE id IN (%s) AND user = '%s' AND deleted != '1'";
$sql_set_delete_bookmarks =	"UPDATE bookmark set deleted='1' WHERE id IN (%s) AND user = '%s' AND deleted != '1'";
$sql_new_folder = 		"INSERT INTO folder (childof, name, user) values ('%d', '%s', '%s')";
$sql_get_foldername = 		"SELECT name FROM folder WHERE id = '%d' AND user='%s' AND deleted!='1'";
$sql_update_folder = 		"UPDATE folder SET name = '%s' WHERE id = '%d' AND user = '%s'";
$sql_move_folder = 		"UPDATE folder SET childof = '%d' WHERE id = '%d' AND user = '%s'";
$sql_confirm_delete_folder = 	"SELECT name FROM folder WHERE id = '%d' AND user = '%s' AND deleted != '1'";
$sql_set_delete_folder = 	"UPDATE folder set deleted = '1' WHERE id = '%d' AND user='%s'";
$sql_set_delete_items =		"UPDATE %s set deleted = '1' WHERE childof IN (%s) AND user = '%s'";
$sql_search =                   "SELECT title, url, description, DATE_FORMAT(date,'%%d.%%m.%%Y') AS timestamp, childof, id
				 FROM bookmark
				 WHERE user = '%s'
				 AND deleted != '1'
				 AND (description LIKE ('%%%s%%') OR url LIKE ('%%%s%%') OR title LIKE ('%%%s%%'))";
$sql_restore =			"UPDATE bookmark SET deleted = '0', childof = '0' WHERE id IN (%s) AND user = '%s' AND deleted = '1'";
$sql_delete =			"DELETE from bookmark WHERE id IN (%s) AND user = '%s' AND deleted = '1'";
$sql_get_deleted =		"SELECT id, title FROM bookmark WHERE user = '%s' AND deleted = '1'";




?>
