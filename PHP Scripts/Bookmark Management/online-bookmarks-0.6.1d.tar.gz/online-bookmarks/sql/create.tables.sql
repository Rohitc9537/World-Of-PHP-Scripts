CREATE TABLE bookmark (
  user char(20) NOT NULL default '',
  title char(70) NOT NULL default '',
  url char(200) NOT NULL default '',
  description char(200) default NULL,
  private enum('0','1') default NULL,
  date timestamp(14) NOT NULL,
  childof int(11) NOT NULL default '0',
  id int(11) NOT NULL auto_increment,
  deleted enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (id),
  FULLTEXT KEY title (title,url,description)
) TYPE=MyISAM;

CREATE TABLE folder (
  id int(11) NOT NULL auto_increment,
  childof int(11) NOT NULL default '0',
  name char(70) NOT NULL default '',
  user char(20) NOT NULL default '',
  deleted enum('0','1') NOT NULL default '0',
  UNIQUE KEY id (id)
) TYPE=MyISAM;

CREATE TABLE user (
  username char(50) NOT NULL default '',
  password char(50) NOT NULL default '',
  language char(20) NOT NULL default '',
  root_folder_name char(50) NOT NULL default 'My Bookmarks',
  column_width_folder smallint(3) NOT NULL default '220',
  column_width_bookmark smallint(3) NOT NULL default '320',
  table_height smallint(3) NOT NULL default '220',
  confirm_delete enum('0','1') NOT NULL default '1',
  open_new_window enum('0','1') NOT NULL default '1',
  show_bookmark_description enum('0','1') NOT NULL default '0',
  show_bookmark_icon enum('0','1') NOT NULL default '0',
  show_column_date enum('0','1') NOT NULL default '0',
  show_column_edit enum('0','1') NOT NULL default '1',
  show_column_move enum('0','1') NOT NULL default '1',
  show_column_delete enum('0','1') NOT NULL default '1',
  fast_folder_minus enum('0','1') NOT NULL default '0',
  fast_folder_plus enum('0','1') NOT NULL default '1',
  fast_symbol enum('0','1') NOT NULL default '1',
  simple_tree_mode enum('0','1') NOT NULL default '0',
  UNIQUE KEY id (username)
) TYPE=MyISAM;
