<?
include("include/xmlhttp.js");
include("include/xmlhttp.php");
include("include/functions.php");
include("include/functions.js");

echo "<HEAD>";
//echo "<link rel=stylesheet href=include/dbgrid.css type='text/css'>";
echo "<TITLE>DBGrid</title>";
echo "</head>";

echo "<html></html>";
echo "<body bgcolor=#ffffff>";

switch ($_GET['f'])
	{
	case "deletechecked":
		DBGridDeleteChecked(strtoupper($_POST['grid']),$_POST['deleterow'],$_POST['deletecol']);
		unset($_GET['f']);
		break;
 	case "movecolleft":
		DBGridMoveColLeft(strtoupper($_GET['grid']),$_GET['col']);
		unset($_GET['f']);
		break;
	case "movecolright":
		DBGridMoveColRight(strtoupper($_GET['grid']),$_GET['col']);
		unset($_GET['f']);
		break;
	case "addrow":
		DBGridAddRow(strtoupper($_GET['grid']));
		unset($_GET['f']);
		break;
	case "addcolumn":
		DBGridAddColumn(strtoupper($_GET['grid']));
		unset($_GET['f']);
		break;
	case "newgrid":
		if (CreateDBGridTable(strtoupper($_GET['gridname']),strtoupper($_GET['gridname'])))
			{
			$_GET['grid'] = $gridname;
			}
		else
			{
			unset($_GET['grid']);
			}
		break;
	case "renamegrid":
		if (RenameDBGridTable(strtoupper($_GET['grid']),strtoupper($_GET['newgridname'])))
			{
			$_GET['grid'] = $newgridname;
			}
		break;
	case "deletegrid":
		$deleteconfirm=1;
		break;
	case "deletegridconfirm":
		DeleteDBGridTable(strtoupper($_GET['grid']));
		unset($_GET['grid']);
		break;
	case "exporttab":
		DBGridExport(strtoupper($_GET['grid']),'tab');
		break;

	}

CreateDBGridDatabase();

// List the available grids
$grids = ListDBGridTables();
echo "<b><font size=2>Select Grid: </font></b>";
for ($i=0;$i<=sizeof($grids) -1;$i++)
	{
	echo "<font size=2 color=orange>[<a href='" . $_SERVER['PHP_SELF'] . "?grid=" . strtoupper($grids[$i]) . "'>" . strtoupper($grids[$i]) . "</a>]</font>";
	}
echo "<p>";

// If we have been passed $grid, display it.
if (isset($_GET['grid']))
	{
	echo "<form action='" . $_SERVER['PHP_SELF'] . "'><input type=hidden name=f value='newgrid'><input type=text size=20 name=gridname><input type=submit value='New Grid'></form>";
	echo "<form action='" . $_SERVER['PHP_SELF'] . "'><input type=hidden name=f value='renamegrid'><input type=hidden name=grid value='". $_GET['grid'] ."'><input type=text size=20 name=newgridname><input type=submit value='Rename ". strtoupper($_GET['grid']) . "'></form>";
	echo "<a href='" . $_SERVER['PHP_SELF'] . "?f=addrow&grid=". $_GET['grid'] ."'>Add Row</a> | ";
	echo "<a href='" . $_SERVER['PHP_SELF'] . "?f=addcolumn&grid=". $_GET['grid'] ."'>Add Column</a> | ";
	if ($deleteconfirm==1)
		{
		echo "<a href='" . $_SERVER['PHP_SELF'] . "?f=deletegridconfirm&grid=". $_GET['grid'] ."'>Delete [confirm] " . strtoupper($_GET['grid']) . "</a> | ";
		}
	else
		{
		echo "<a href='" . $_SERVER['PHP_SELF'] . "?f=deletegrid&grid=". $_GET['grid'] ."'>Delete " . strtoupper($_GET['grid']) . "</a> | ";
		}
	echo "<a href='export.php?grid=". $_GET['grid'] ."&type=tab'>Export Tab Delimited</a>";
	echo "<hr>";
	echo "<b>Grid: <font color=orange size=4><b>[" . strtoupper($_GET['grid']) . "]</font></b><p>";
	PrintDBGrid($_GET['grid'],$_GET['orderby']);
	}
else
	{
	echo "<form action='" . $_SERVER['PHP_SELF'] . "'><input type=hidden name=f value='newgrid'><input type=text size=20 name=gridname><input type=submit value='New Grid'></form>";
	echo "<hr>";
	ListDBGridTables();
	}


echo "</body>";
?>
