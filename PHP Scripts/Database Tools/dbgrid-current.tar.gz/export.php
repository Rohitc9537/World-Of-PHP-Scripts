<?
include("include/functions.php");
header("Content-type: application/binary");
$filename = "exporttab.txt";
$header="Content-Disposition: attachment; filename=".$filename.";";
header($header );
header("Content-Transfer-Encoding: binary");
DBGridExport($_GET['grid'],$_GET['type']);
?>
