<?
// Update the DB to set the grid value that was changed
$db = sqlite_open("data/DBGridDB.db");
$gridpos_array = explode("x",$_GET['gridpos']);
$sql = "update " . $_GET['grid'] . " set ". $gridpos_array[0] . "='" . urlencode($_GET['gridval']) . "' where ROWID=" . trim($gridpos_array[1]) . "";
$q = sqlite_query($db,$sql);
sqlite_close($db);
echo stripslashes(urldecode($_GET['gridval']));
?>
