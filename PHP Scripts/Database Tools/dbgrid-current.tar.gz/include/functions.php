<?
/*  DBGrid v0.3
    File: functions.php
    Last Modified: 05/04/2005
    Author: Robert Thompson
    Summary: This script contains all of the functions necessary for the dbgrid application to function */

function CreateDBGridDatabase()
	{
	// Creates the main DBGrid database which stores all of the DBGrid tables.
	if (file_exists("data/DBGridDB.db"))
		{
		//DBGridMessage("DBGrid Database Already Exists, skipping creation");
		}
	else
		{
		$db_name='data/DBGridDB.db';
		$db=new SQLiteDatabase($db_name, 0666, $error);
		if ($error) exit($error);
		//DBGridMessage("Created DBGrid Database");
		}
	}

function CheckDBGridName($name)
	{
	if (!ereg('[^[:space:]a-zA-Z0-9_]{1,}',$name))
		{
		if (!is_numeric(substr($name,0,1)))
			{
			return (true);
			}
		}
	else
		{
		return (false);
		}
	}

function CreateDBGridTable($DBGridName,$DBGridTitle)
	{

	// Creates the SQLite table that supports the DBGrid
	$DBGridName = str_replace(" ","_",$DBGridName);

	if (CheckDBGridName($DBGridName)==false)
		{
		DBGridError("Name must be alphanumeric and cannot begin with a number.");
		return (false);
		}

	if (sqlite_table_exists($DBGridName))
		{
		DBGridError("Grid $DBGridName already exists.");
		return (false);
		}

	$db = sqlite_open("data/DBGridDB.db");
	$q="PRAGMA table_info($DBGridName)";
	$r=sqlite_query($db,$q);
	if (sqlite_num_rows($r)!=2)
		{
   		if (!sqlite_query($db,"
       	   		CREATE TABLE $DBGridName (
			col0 varchar(255)
			)")
   			);
		DBGridAddColumn($DBGridName);
		DBGridAddRow($DBGridName);
		DBGridAddRow($DBGridName);
		//DBGridMessage("Table $DBGridName Created");
		return (true);
		}
	else
		{
		DBGridMessage("Table Already Exists");
		return (false);
		}
	return (false);
	}

function DeleteDBGridTable($DBGridName)
	{
	// Deletes a DBGrid SQLite DBGrid table
	if (file_exists("data/DBGridDB.db"))
		{
	        $db = sqlite_open("data/DBGridDB.db");
		$sql = "drop table " . $DBGridName;
		$q = sqlite_query($db,$sql);
		if ($error) exit($error);
		}
	else
		{
		}
	}

function RenameDBGridTable($DBGridName,$newDBGridName)
	{
	// Renames a DBGrid SQLite DBGrid table
	$newDBGridName = str_replace(" ","_",$newDBGridName);

	if (CheckDBGridName($newDBGridName)==false)
		{
		DBGridError("New name must be alphanumeric and cannot begin with a number.");
		return (false);
		}

	if (sqlite_table_exists($newDBGridName))
		{
		DBGridError("Grid $newDBGridName already exists.");
		return (false);
		}

	if (file_exists("data/DBGridDB.db"))
		{
        	$db = sqlite_open("data/DBGridDB.db");
		$sql = "SELECT ROWID,* FROM sqlite_master";
		$q = sqlite_query($db,$sql);
		$r = sqlite_fetch_all($q, SQLITE_ASSOC);

		// Find the creation SQL for this table

		for ($i=0;$i<=sizeof($r);$i++)
			{
			if ($r[$i][tbl_name] == $DBGridName)
				{
				$createsql = $r[$i][sql];
				}
			}

		$createnewsql = str_replace($DBGridName,$newDBGridName,$createsql);
		// Create the new table
		$q = @sqlite_query($db,$createnewsql);

		// Copy old table contents
		$copysql  = "INSERT INTO $newDBGridName SELECT * from $DBGridName";
		$q = @sqlite_query($db,$copysql);

		// Check to make sure the new table exists, if not, backout
		if (sqlite_table_exists($newDBGridName))
			{
			DeleteDBGridTable($DBGridName);
			return (true);
			}
		else
			{
			DBGridError("Table Rename Failed.");
			return (false);
			}
		}
	return (false);
	}

function DBGridAddColumn($DBGridName)
	{
	include('include/altertable.php');
	// Adds a column to the SQLite DBGrid table
	// Returns an array of all of the DBGrid Tables.
        $db = sqlite_open("data/DBGridDB.db");

	// Determine the maximum column that is in the table
	$sql = "SELECT sql FROM
   		(SELECT * FROM sqlite_master UNION ALL
	         SELECT * FROM sqlite_temp_master)
                 where name='". $DBGridName ."' AND type!='meta'
                 ORDER BY type DESC, name";

	$q = sqlite_query($db,$sql);
	$r = sqlite_fetch_all($q, SQLITE_ASSOC);

	$columns = array();
	for ($i=0;$i<=sizeof($r);$i++)
		{
		$columnarray = explode(" ",$r[$i][sql]);

		for ($j=1;$j<=sizeof($columnarray);$j++)
			{
			if (substr(trim($columnarray[$j]),0,3) == "col")
				{
				array_push($columns,substr(trim($columnarray[$j]),3,2));
				}
			}
		}
	$maxindex = @max(array_values($columns));
	$newcolname = "col" . ($maxindex + 1);
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query("alter table $DBGridName add $newcolname varchar(255)");
	//DBGridMessage("Added Empty Column to DBGrid $DBGridName");
	}

function DBGridAddRow($DBGridName)
	{
        if (sqlite_table_exists($DBGridName))
		{
		$db = sqlite_open("data/DBGridDB.db");
		$sql = "INSERT INTO $DBGridName (col0) values ('')";
		$q = sqlite_query($db,$sql);
		}
	}

function ListDBGridTables()
	{
	// Returns an array of all of the DBGrid Tables.
        $db = sqlite_open("data/DBGridDB.db");
	$sql = "SELECT ROWID,* FROM sqlite_master";
	$q = sqlite_query($db,$sql);
	$r = sqlite_fetch_all($q, SQLITE_ASSOC);
	for ($i=0;$i<=sizeof($r) -1 ;$i++)
		{
		$alist[$i] = $r[$i][name];
		}
	return $alist;
	}

function UpdateDBGridTable($DBGridName,$col,$row,$data)
	{
        $db = sqlite_open("data/DBGridDB.db");
	$sql = "INSERT INTO $DBGridName values (";
	$q = sqlite_query($db,$sql);
	$r = sqlite_fetch_all($q, SQLITE_ASSOC);
	DBGridMessage("Updated DBGrid $DBGridName");
	}

function DBGridMessage($message)
	{
	echo $message . "<br/>";
	}

function DBGridError($message)
	{
	echo "<font color=red>" . $message . "</font><br/>";
	}

function DBGridMoveColRight($grid,$col)
	{
	// Determine the next highest column in the list of columns and switch this column with it.
	// Grab all of the field names

	include('include/altertable.php');

        $db = sqlite_open("data/DBGridDB.db");
	$sql = "SELECT rowid,* FROM $grid";
	$q = sqlite_query($db,$sql);
	$numfields = sqlite_num_fields($q);

	for ($i=0;$i<=$numfields-1;$i++)
		{
		$fieldnames[$i] = sqlite_field_name($q,$i);
		}

	// Sort the field names
	sort($fieldnames);

	// Look for our field we want to change
	$curindex = array_search($col,$fieldnames);
	$nextindex = $curindex + 1;
	$nextfield = $fieldnames[$nextindex];

	$sql = "ALTER TABLE $grid CHANGE $col temp varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);

	$sql = "ALTER TABLE $grid CHANGE $nextfield $col varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);

	$sql = "ALTER TABLE $grid CHANGE temp $nextfield varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);
	}

function DBGridMoveColLeft($grid,$col)
	{
	// Determine the next highest column in the list of columns and switch this column with it.

	// Grab all of the field names

	include('include/altertable.php');

        $db = sqlite_open("data/DBGridDB.db");
	$sql = "SELECT rowid,* FROM $grid";
	$q = sqlite_query($db,$sql);
	$numfields = sqlite_num_fields($q);

	for ($i=0;$i<=$numfields-1;$i++)
		{
		$fieldnames[$i] = sqlite_field_name($q,$i);
		}

	// Sort the field names
	sort($fieldnames);

	// Look for our field we want to change
	$curindex = array_search($col,$fieldnames);
	$nextindex = $curindex - 1;
	$nextfield = $fieldnames[$nextindex];

	$sql = "ALTER TABLE $grid CHANGE $col temp varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);

	$sql = "ALTER TABLE $grid CHANGE $nextfield $col varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);

	$sql = "ALTER TABLE $grid CHANGE temp $nextfield varchar(255)";
	$alterdb = new SQLiteDB('data/DBGridDB.db');
	$result = $alterdb->query($sql);
	}

function DBGridDeleteChecked($grid,$deleterowarray,$deletecolarray)
	{

	include('include/altertable.php');

	$deleterowarray_keys = @array_keys($deleterowarray);
	$deletecolarray_keys = @array_keys($deletecolarray);

	if (sizeof($deleterowarray)>0 && strlen($grid) > 0)
		{
	        $db = sqlite_open("data/DBGridDB.db");
		for ($i=0;$i<sizeof($deleterowarray);$i++)
			{
			$sql = "DELETE FROM $grid WHERE rowid=" . $deleterowarray_keys[$i];
			$q = sqlite_query($db,$sql);
			}
		}

	if (sizeof($deletecolarray)>0 && strlen($grid) > 0)
		{
	        $db = sqlite_open("data/DBGridDB.db");
		for ($i=0;$i<sizeof($deletecolarray);$i++)
			{
			$sql = "ALTER TABLE $grid DROP $deletecolarray_keys[$i]";
			$alterdb = new SQLiteDB('data/DBGridDB.db');
			$result = $alterdb->query($sql);
			}
		}
	unset($orderby);
	}

function PrintDBGrid($DBGridName,$orderby)
	{

	if (!sqlite_table_exists($DBGridName))
		{
		DBGridError("Table does not exist.");
		return (false);
		}


        $db = sqlite_open("data/DBGridDB.db");

	$DBGridName = str_replace(" ","_",$DBGridName);

	if (strlen($orderby)>0)
		{
		$sql2 = "SELECT rowid,* FROM $DBGridName where rowid=1";
		$qadd = sqlite_query($db,$sql2);
		$radd = sqlite_fetch_all($qadd, SQLITE_ASSOC);
		$sqladd = " where rowid>1 order by upper(" . $orderby . ")";
		//print_r($radd);
		}

	$sql = "SELECT rowid,* FROM $DBGridName" . $sqladd;
	$q = sqlite_query($db,$sql);
	$numrows = sqlite_num_rows($q);
	$numfields = sqlite_num_fields($q);

	$r = sqlite_fetch_all($q, SQLITE_ASSOC);

	if (isset($radd))
		{
		$r = array_merge($radd,$r);
		}

	//echo "<form name=grid action='" . $_SERVER['PHP_SELF'] . "?f=deletechecked' method=POST>";
echo "<form name=grid action='" . $_SERVER['PHP_SELF'] . "?f=deletechecked&grid=". $_GET['grid'] ."' method=POST>";
//	echo "<form name=grid action='' method=POST>";
	echo "Server Status<br>";
	echo "<input type=text size=40 name=status disabled style='font-family:monospace;font-weight:normal;border:1px solid #cccccc;padding:0px 1px 0px 1px'><p>";
	echo "<table border=0 cellpadding='0' cellspacing='1' bgcolor='#ffffff'>";

	$rowcount=0;

	foreach ($r as $entry)
		{
		// Output Rows
		echo "<tr>";

		for ($i=1;$i<=$numfields-1;$i++)
			{
			$currname = sqlite_field_name($q,$i);
			$fieldnames[$i] = $currname;
			}

		sort($fieldnames);
		$fieldnames[0] = "rowid";

		for ($j=1;$j<=$numfields-2;$j++)
			{
			// Output Columns
			$fieldname = $fieldnames[$j];
			if ($j==1)
				{
				//if ($entry[rowid]>1)
				if ($rowcount>0)
					{
					// Output the delete checkboxes
					echo "<td><input type=checkbox name=deleterow[$entry[rowid]]></td>";

					// Output the row count on the left hand side.
					echo "<td><input type=text size=2 name=rowcount disabled value=$entry[rowid] style='font-family:monospace;font-weight:normal;border:1px solid #cccccc;padding:0px 1px 0px 1px'></td>";
					}
				else
					{
					echo "<td></td><td></td>";
					}
				}
			echo "<td>";
			$gridpos = $fieldname . "x" .  "$entry[rowid]";
			//echo $gridpos;

			if ($rowcount==0)
				{
				// Calculate the size of the text fields to size the input boxes

			        $sql2 = "SELECT $fieldname FROM $DBGridName";
			        $q2 = sqlite_query($db,$sql2);
			        $r2 = sqlite_fetch_all($q2, SQLITE_ASSOC);

				for ($i=0;$i<=sizeof($r2);$i++)
					{
					$sizearray[$i] = strlen(urldecode($r2[$i][$fieldname]));
					}

				$maxlength = 100;
				$arraymax = array_max($sizearray);

				if ($arraymax < $maxlength )
					{
					$textboxsize[$fieldname] = array_max($sizearray);
					}
				else
					{
					$textboxsize[$fieldname] = $maxlength;
					}

				// Output the sort/delete headers
				echo "<center>";
				if ($j>1)
					{
					echo "<a href='?f=movecolleft&grid=$DBGridName&col=$fieldname' onMouseover='showtip(this,event," . '"' . "Move Column Left" . '"' . ")'><img src='images/arrowleft.gif' border=0></a>";
					}

				echo "<input type=checkbox name=deletecol[$fieldname] style='spacing:1px 1px 1px 1px'>";
				echo "<a href='?f=order&grid=$DBGridName&orderby=$fieldname' onMouseover='showtip(this,event," . '"' . "Sort This Column" . '"' . ")'><img src='images/arrowdown.gif' border=0></a>&nbsp;";

				if ($j<$numfields-2)
					{
					echo "<a href='?f=movecolright&grid=$DBGridName&col=$fieldname' onMouseover='showtip(this,event," . '"' . "Move Column Right" . '"' . ")'><img src='images/arrowright.gif' border=0></a><br>";
					}
				echo "</center>";


				// Output the column headers
				echo "<input type=text size=". ($textboxsize[$fieldname]) . "  value='" .
str_replace('\"',"&quot;",str_replace("\'","&apos;",urldecode($entry[$fieldname]))) .
"' style='font-family:monospace;font-weight:bold;text-align:center;background-color:#cccccc;border-style:none;margin-left:1px;padding:0px 1px 0px 1px;' name='" .
$gridpos. "' size=20 onblur=gridUpdate('" . urlencode($DBGridName) . "','" . urlencode($gridpos)  . "')>";

				}
			else
				{
				// Output the grid values in input boxes
				echo "<input type=text size=". $textboxsize[$fieldname] .
"  value='" . str_replace('\"',"&quot;",str_replace("\'","&apos;",urldecode($entry[$fieldname]))) .
"' style='font-family:monospace;font-weight:normal;border:1px solid #cccccc;padding:0px 1px 0px 1px' name='" . $gridpos. "' size=20 onblur=gridUpdate('". $DBGridName . "','" . $gridpos  . "')>";

				}

			echo "</td>";
			}
		echo "</tr>\n";
		$rowcount++;
		}

	sqlite_close($db);
	echo "</table>";
	echo "<input type=submit value='Delete Checked'>";
	echo "<input type=hidden name='grid' value='". $DBGridName ."'>";
	echo "<input type=hidden name='f' value='deletechecked'>";
	echo "</form>";
	}

function array_max($arrInput = NULL) {
   if ((!is_array($arrInput)) || (!count($arrInput) > 0)) {
       return "ERR: \$arrInput is empty, or not an array.";
   }

   else {
       unset($arrTmp);

       foreach($arrInput as $key => $value) {
           if ((is_numeric($value)) || (is_int($value))) {
               $arrTmp[$key] = $value;
           }
       }

       if (is_array($arrTmp)) {
           sort($arrTmp, SORT_NUMERIC);
           return array_pop($arrTmp);
       }

       else {
           return "ERR: No numeric values found.";
       }
   }
}

function sqlite_table_exists($table)
	{
	$db = sqlite_open("data/DBGridDB.db");
	$q="PRAGMA table_info($table)";
	$r=@sqlite_query($db,$q);
	if (@sqlite_num_rows($r)>0)
		{
 		return (true);
           	}
        else
		{
         	return(false);
         	}
	}

function DBGridExport($grid,$type)
	{
	switch ($type)
        	{
	        case "tab":
			$db = sqlite_open("data/DBGridDB.db");
			$sql = "SELECT * FROM $grid";
			$q = sqlite_query($db,$sql);
			$numrows = sqlite_num_rows($q);
			$numfields = sqlite_num_fields($q);
			$r = sqlite_fetch_all($q, SQLITE_ASSOC);
			foreach ($r as $line)
				{
				foreach ($line as $col)
					{
					echo urldecode(trim($col)) . "\t";
					}
				echo "\n";
				}
	                break;
		}
	}
?>
