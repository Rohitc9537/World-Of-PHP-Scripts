<? 
if (file_exists('/tmp/lock'))
	{
	sleep(1);
	}
else
	{
	touch('/tmp/lock');
	}

?>

<script>
function gridUpdate(grid,gridval)
        {
        frm=document.forms[2];
        frm.elements['status'].value = "Updating, Please Wait..";

	// Pass the update server the value that was typed in.
        url="updateserver.php?gridval=" + frm.elements[gridval].value + "&gridpos=" + gridval + "&grid=" + grid;
        xmlhttp.open("GET",url,true);
        xmlhttp.onreadystatechange=function()
                {
                if (xmlhttp.readyState==3)
                        {
                        frm.elements[gridval].value=xmlhttp.responseText;
                        }
                };

	frm.elements['status'].value = "Field Updated";
        xmlhttp.setRequestHeader('Accept','message/x-jl-formresult');
        xmlhttp.send(null);

        return false;
	}
</script>
<?
unlink('/tmp/lock');
?>
