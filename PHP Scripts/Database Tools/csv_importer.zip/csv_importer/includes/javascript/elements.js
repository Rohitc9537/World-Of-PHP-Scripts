// ELEMENTS
var doc = document;

// Form
var _input = doc.createElement("input");
var _select = doc.createElement("select");

// Table
var _table = doc.createElement("table");
	_table.align = "center";
	_table.border = 0;
	_table.cellPadding = 4;
	_table.cellSpacing = 1;
var _tbody = doc.createElement("tbody");
var _tr = doc.createElement("tr");
var _td = doc.createElement("td");

// Other
var _a = doc.createElement("a");
var _br = doc.createElement("br");
var _div = doc.createElement("div");
var _img = doc.createElement("img");
var _p = doc.createElement("p");