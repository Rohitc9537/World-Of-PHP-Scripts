Author: Thomas Whitecotton ( admin@ciamosbase.com )
Website: http://www.simplyphp.com

Release Date:
September 18, 2005

ABOUT
-----
simplyMySQL Manager is a plug-and-play database management system that lets you perform your own SQL commands, view all tables -> fields -> entries easily, with just a click of your mouse. 
You can also export your database tables in XML format, and you can delete all exports you make.
Very easy to use interface decreases the time it takes to navigate your database.
Neatly written to be compatible with PHP 5, and backwards compatible with PHP 4, this is a wise alternative to those other clunky systems out there. 
Free download.

INSTALLATION
------------
1) Extract files to sMManager folder
2) Edit sMManager/includes/include.php so your database host, name, and login information are correct
3) Upload the sMManager folder to your server in the public_html directory (may also be called www or similar)
4) CHMOD 777 the export folder
5) Access simplyMySQL Manager by going to yourdomain.com/sMManager

NOTE: You may rename the sMManager folder if you wish, it will not affect it in any way.

PASSWORD PROTECTION
-------------------
If you wish to password protect sMManager, I recommend you setup a .htaccess file.