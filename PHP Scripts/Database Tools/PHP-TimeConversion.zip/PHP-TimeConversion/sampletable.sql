CREATE TABLE `sample_time` (
`recordid` INT( 15 ) NOT NULL AUTO_INCREMENT ,
`timestart` TIME,
`timeend` TIME,
PRIMARY KEY ( `recordid` )
);
