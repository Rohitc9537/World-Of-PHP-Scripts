<?
/**universal
 * Fichier contenant les d�finitions des images
 * @author Thomas Pequet
 * @version 1.0 
 */

// Images communes � toutes les pages
$imageLogo = '<IMG SRC="'.$rep_par_rapport_racine.'img/logo.png" WIDTH="320" HEIGHT="70" ALT="'.$nomSite.'">';
	
// Images de la page "index.xxx"
if ($page=="1") {
	$imageFleur = '<IMG SRC="'.$rep_par_rapport_racine.'img/1.gif" WIDTH="40" HEIGHT="40" ALT="Une production Thomas Pequet">';
	$imagePx = '<IMG SRC="'.$rep_par_rapport_racine.'img/2.gif" ';
}
?>