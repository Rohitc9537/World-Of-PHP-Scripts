<?
/**universal
 * Fichier contenant les param�tres de connexion � la base de donn�es
 * @author Thomas Pequet
 * @version 1.1 
 */

// Type de base de donn�es
$bdType 	= "mysql";

// Variables de connexions
$bdServeur 	= "localhost";
$bdLogin 	= "root";
$bdPassword	= "";
$bdNomBase 	= "mysql";

// Inclusion du fichier correspodant � la base de donn�es
include($rep_par_rapport_racine."lib/db/".$bdType.".php");

// Connexion � la base de donn�es
$bd = new sql_db($bdServeur, $bdLogin, $bdPassword, $bdNomBase, false);
if(!$bd -> db_connect_id)
	die("<FONT FACE=\"verdana\" SIZE=\"1\"><BR><CENTER><B style=\"color:#FFFFFF;background-color:#FF0000\">&nbsp;Erreur: la base de donn�es ne r�pond pas&nbsp;</B></FONT>");
	
// Destruction des variables maintenant inutiles
unset($bdLogin);
unset($bdPassword);
//unset($bdNomBase);
unset($bdType);
?>