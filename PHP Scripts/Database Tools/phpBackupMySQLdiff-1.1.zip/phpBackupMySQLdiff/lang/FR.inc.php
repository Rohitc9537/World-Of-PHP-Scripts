<? //***** Fran�ais ******//
/**universal
 * Fichier contenant les variables pour la traduction fran�aise du site
 *
 * @author Thomas Pequet
 * @version 1.0  
 */

// Texte commun � toutes les pages
$titre1 	= "Sauvegarde diff�rentielle des bases de donn�es MySQL en PHP";
$titre2 	= "Sauvegarde";
$titre3 	= "Restauration";

// Nom des mois
$nomMois = array(
	  	"01" => "Janvier",
	  	"02" => "F�vrier",
	  	"03" => "Mars",
	  	"04" => "Avril",
	  	"05" => "Mai",
	  	"06" => "Juin",
	  	"07" => "Juillet",																				
		"08" => "Ao�t",
		"09" => "Septembre",
		"10" => "Octobre",
		"11" => "Novembre",
		"12" => "D�cembre"
	  );
	  
$texteInfos 		= "Infos";
$texteErreurs 		= "Erreurs";
$texteTmeps 		= "Temps d'�x�cution de la page";
$texteCharger 		= "Charger";
$texteSupprimer 	= "Supprimer";

// Le texte de "index"
if ($page=="1") {
	$texte1 	= "Installer ".$nomSite;
	$texte2 	= "Sauvegarder des donn�es";
	$texte3 	= "Restaurer des donn�es";
	$texte4 	= "Pr�sentation";
	$texte5 	= "V�rification de la configuration";
	$texte6 	= "Fichier <B>##fic##</B> modifiable ?";
	$texte7 	= "Le fichier est en lecture seule";
	$texte8 	= "Le fichier n'existe pas";
	$texte9 	= "Module <B>XML</B> install� ?";
	$texte10 	= "Le module <B>XML</B> n'est pas install� dans PHP";
	$texte11 	= "Module <B>Zlib</B> install� ?";
	$texte12 	= "Le module <B>Zlib</B> n'est pas install� dans PHP";
	$texte13 	= "Installation de <B>".$nomSite."</B> dans les tables";
	$texte14 	= "S�lectionnez les tables qui seront modifi�es pour �tre compatibles avec <B>".$nomSite."</B> -> un champ <B>`TIMESTAMP`</B> sera ajout� � la fin de chaque tables s�lectionn�es pour permettre les sauvegardes diff�rentielles:";
	$texte15 	= "Tables du serveur `<B>##serveur##</B>`";
	$texte16 	= "Modifier les tables";
	$texte17 	= "Sauvegarder";
	$texte18 	= "Nom de la configuration de sauvegarde";
	$texte19 	= "Automatiser les sauvegardes";
	$texte20 	= "Il est possible d'automatiser les sauvegardes en �x�cutant la page <B>save.php</B> et en lui passant en param�tres le nom de la configuration � sauvegarder.<BR><I>Exemple:</I> php -q -f save.php \"&nomconfig=default\"<BR>Cette commande peut �tre appel�e par un <B>cron</B> ou par des services comme <B><A HREF=\"http://www.webcron.org\" TARGET=\"_blank\">webcron.org</A></B>.";
	$texte21 	= "Lancer une sauvegarde manuelle";
	$texte22 	= "Configuration de sauvegarde";
	$texte23 	= "Configuration de sauvegarde";
	$texte24 	= "Infos � sauvegarder";
	$texte25 	= "Structure et donn�es";
	$texte26 	= "Donn�es";
	$texte27 	= "Structure";
	$texte28 	= "R�pertoire de stockage";
	$texte29 	= "S�lectionnez les tables � sauvegarder parmi les diff�rentes bases";
	$texte30 	= "Format d'archivage";
	$texte31 	= "Enregistrer la configuration";
	$texte32 	= "Restaurer";
	$texte33 	= "Nom de la configuration de restauration";
	$texte34 	= "Restaurer les donn�es sauvegard�es entre le";
	$texte35 	= "au";
	$texte36 	= "Ajouter des �nonc�s \"drop table\"";
	$texte37 	= "Prot�ger les noms des tables et des champs par des \"`\"";
	$texte38 	= "Ajouter le nom de la base dans les requ�tes";
	$texte39 	= "Afficher les requ�tes SQL";
	$texte40 	= "T�l�charger un fichier contenant les requ�tes SQL";
	$texte41 	= "Configuration de restauration";
	$texte42 	= "Configuration de restauration";
	$texte43 	= "Infos � restaurer";
	$texte44 	= "S�lectionnez les tables � restaurer parmi les diff�rentes bases";
	$texte45 	= "Base de donn�es";
	$texte46 	= "<B>".$nomSite."</B> est un logiciel PHP qui permet d'effectuer des sauvegardes diff�rentielles de vos bases de donn�es <B>MySQL</B> en ne modifiant que tr�s l�g�rement vos tables.";
	$texte47 	= "Gr�ce � <B>".$nomSite."</B>, vous pourrez ne sauvegarder que les donn�es qui ont �t� modifi�es depuis la derni�re sauvegarde et ainsi gagner en place si vous sauvegardez r�guli�rement vos donn�es.";
	$texte48 	= "Les donn�es sont sauvegard�es sous forme de fichiers XML compr�ss�s dans des archives au format zip, tar, ou tar.gz.";
	$texte49 	= "Une fois vos donn�es sauvegard�es, vous pourrez restaurer vos donn�es sous forme de requ�te SQL.";
	$texte50 	= "Requ�te";
	$message1 	= "La table <B>`##base##.##table##`</B> a �t� modifi�e avec succ�s";
	$message2 	= "Le champ <B>`TIMESTAMP`</B> n'a pas pu �tre ajout� dans la table <B>`##base##.##table##`</B>. Ce champ existe peut-�tre d�j�.";
	$message3 	= "Impossible de trouver la base <B>`##base##`</B>";
	$message4 	= "La configuration <B>`##config##`</B> a �t� sauvegard�e avec succ�s";
	$message5 	= "Le fichier <B>`##fic##`</B> n'a pas �t� modifi� car ses permissions ne le permettent pas.";
	$message6 	= "La configuration <B>`##config##`</B> a �t� supprim�e avec succ�s";
}

// Le texte de "save"
if ($page=="2") {
	$message1 	= "Impossible de cr�er le r�pertoire: <B>##rep##</B>";
	$message2 	= "Impossible de trouver les param�tres de configuration dans le fichier: <B>##fic##</B>";
	$message3 	= "Impossible de se connecter � la base: <B>`##base##`</B>";
	$message4 	= "Impossible de trouver de champ <B>`TIMESTAMP`</B> dans la table: <B>`##table##`</B> (<A HREF=\"index.".$extension."?rub=install\" TARGET=\"_blank\">Voir proc�dure d'installation</A>)";
	$message5 	= "Sauvegarde de la structure de la table <B>`##table##`</B>";
	$message6 	= "Sauvegarde de <B>##nb##</B> enregistrement(s) de la table <B>`##table##`</B>";
	$message7 	= "Aucune donn�e sauvegard�e";
}

// Le texte de "restore"
if ($page=="3") {
	$texte1 	= "Structures des tables";
	$texte2 	= "Donn�es des tables";
	$message1 	= "Impossible de trouver les param�tres de configuration dans le fichier: <B>##fic##</B>";
	$message2 	= "Impossible de trouver le r�pertoire: <B>##rep##</B>";
	$message3 	= "Aucune sauvegarde de la base <B>`##base##`</B> n'a �t� trouv�e";
	$message4 	= "Aucune sauvegarde de la base <B>`##base##`</B> n'a �t� trouv�e du mois de <B>##mois## ##annee##</B>.";
	$message5 	= "Aucune sauvegarde de la table <B>`##base##.##table##`</B> n'a �t� trouv�e du mois de <B>##mois## ##annee##</B>.";
	$message6 	= "Restauration de la structure de la table <B>`##base##.##table##`</B>";
	$message7 	= "Restauration de <B>##nb##</B> enregistrements(s) de la table <B>`##base##.##table##`</B>";
	$message8 	= "Aucune structure restaur�e";
	$message9 	= "Aucune donn�e restaur�e";
}
?>