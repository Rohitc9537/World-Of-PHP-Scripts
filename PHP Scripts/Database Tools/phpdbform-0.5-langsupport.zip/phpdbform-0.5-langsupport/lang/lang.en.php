<?
define( "_LANGMAINPAGE",	"Mainpage" );
define( "_LANGWELCOME",		"Welcome" );
define( "_LANGWELCOMEMSG",	"Use the menu on the left to choose the tool you want to use." );

define( "_LANGSUBMIT",		"Submit" );
define( "_LANGDELETE",		"Delete" );
define( "_LANGLOGIN",		"Login" );
define( "_LANGLOGOUT",		"Logout" );
define( "_LANGLOGINUSER",	"Username" );
define( "_LANGPASSWORD",	"Password" );

define( "_LANGINSERTNEWRECORD",		"Insert a new record" );

define( "_LANGDATALOADDB",			"Loading data from DB" );
define( "_LANGDATALOADFORM",		"Loading data into select form" );
define( "_LANGDATAINSERT",			"Inserting data" );
define( "_LANGDATADELETE",			"Deleting data" );
define( "_LANGDATAUPDATE",			"Updating data" );

define( "_LANGERRORINVALIDLOGIN",	"Invalid login and/or password." );
define( "_LANGERRORCANTCONNECT",	"Can't connect to database" );
define( "_LANGERRORFILTER",			"*ERROR* add_filter called without using selection form" );

?>