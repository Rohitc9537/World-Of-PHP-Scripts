<?
define( "_LANGMAINPAGE",	"Startseite" );
define( "_LANGWELCOME",		"Willkommen" );
define( "_LANGWELCOMEMSG",	"Benutzen Sie bitte das Menu auf der linken Seite." );

define( "_LANGSUBMIT",		"Eintragen" );
define( "_LANGDELETE",		"L�schen" );
define( "_LANGLOGIN",		"Anmelden" );
define( "_LANGLOGOUT",		"Abmelden" );
define( "_LANGLOGINUSER",	"Benutzer" );
define( "_LANGPASSWORD",	"Passwort" );

define( "_LANGINSERTNEWRECORD",		"Neuer Eintrag" );

define( "_LANGDATALOADDB",			"Loading data from DB" );
define( "_LANGDATALOADFORM",		"Loading data into select form" );
define( "_LANGDATAINSERT",			"Inserting data" );
define( "_LANGDATADELETE",			"Deleting data" );
define( "_LANGDATAUPDATE",			"Updating data" );

define( "_LANGERRORINVALIDLOGIN",	"Ung�ltiger Benutzer oder Passswort." );
define( "_LANGERRORCANTCONNECT",	"Can't connect to database" );
define( "_LANGERRORFILTER",			"*ERROR* add_filter called without using selection form" );

?>