-- phpMyAdmin SQL Dump
-- version 2.6.2-pl1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Mardi 30 Août 2005 à 09:55
-- Version du serveur: 4.1.12
-- Version de PHP: 5.0.4
-- 
-- Base de données: `sqlmax`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `voiture`
-- 

CREATE TABLE voiture (
  id_voiture int(11) NOT NULL auto_increment,
  nom char(10) default NULL,
  `type` int(11) default NULL,
  PRIMARY KEY  (id_voiture)
) TYPE=MyISAM;

-- 
-- Contenu de la table `voiture`
-- 

INSERT INTO voiture VALUES (1, 'BMW2', 1);
INSERT INTO voiture VALUES (2, 'MERCEDESx', 2);
INSERT INTO voiture VALUES (3, 'RENAULT', 3);
INSERT INTO voiture VALUES (4, 'PEUGEOT', 3);
INSERT INTO voiture VALUES (5, 'MyCar', 2);
INSERT INTO voiture VALUES (6, 'MyCar', 2);
INSERT INTO voiture VALUES (7, 'MyCar', 2);
INSERT INTO voiture VALUES (8, 'MyCar', 2);
INSERT INTO voiture VALUES (9, 'MyCar', 2);
INSERT INTO voiture VALUES (10, 'MyCar', 2);
INSERT INTO voiture VALUES (11, 'MyCar', 2);
INSERT INTO voiture VALUES (12, 'MyCar', 2);
INSERT INTO voiture VALUES (13, 'MyCar', 2);
