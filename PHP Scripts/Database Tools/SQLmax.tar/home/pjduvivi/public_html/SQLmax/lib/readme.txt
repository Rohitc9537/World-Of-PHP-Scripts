CORE CLASSES LIBRAIRY OF SQLMAX.

class_sql is an sql abstract to allow multidatabase support
class_mysql is the mysql classes
class_cache is the class wich provide the cache system.
param_connex.php is the paramater file where you can change the general settings of the system.
