<?
/* PIERRE JEAN DUVIVIER 2004
 * contact@pjduvivier.com
 * SQLmax version v1.0
 * PARAMATERS FILES
 *
 */

// Database parameter for SQLmax


 $dbhost="localhost";
 $dbuname="root";
 $dbpass="";
 $dbname="sqlmax";
 $dbtype="MySQL";
 
 // path parameters

 define("_PATH","C:/apachefriends/xampp/htdocs/SQLmax/");   // put your absolute path to it
 define("_ABSOLUTEPATHCACHE",_PATH."/cache/");

 // Cache System parameters


 define("_CACHESYSTEM",1); // 1=YES O=NON
 define("_REFRESHTIMEQUERY",1); // REFRESH QUERIES EVERY x SECONDS.

 
?>
