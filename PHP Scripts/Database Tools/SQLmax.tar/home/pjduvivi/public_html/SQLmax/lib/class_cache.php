<?
/* PIERRE JEAN DUVIVIER 2004
 * contact@pjduvivier.com
 * SQLmax version v1.0
 * CACHE LAYER
 * If a  SQL query was not done
 * This class produce a txt file corresponding to the query (md5) and serializing the result in it
 * When the same query come back again,  we do the reverse with unserialize function
 * The cache works with the SQL LAYER and is linked to it.
 *
 */
 
class Cache
{
     function Cache($_INIT,$_CNX)
     
     /* Constructor of the class
      * Initializing the class > Table_cache is not used now
      */
     {

        $this->Init=$_INIT; // 0=NO and 1=YES
        $this->C_CNX=$_CNX;



     }


     function Cache_Exist($_QUERY,$_TABLE)

        /* Test if the cache exist. if the cache exist , extract the data and unserialize it in an array
         * Cache::Cache_Refresh make the cache refresh if the TIME for refresh came
         * the option to modify the cache refresh is in the connection.php files.
         */
     {

             $_m=md5($_QUERY);
             $_f=_ABSOLUTEPATHCACHE."/$_TABLE/$_m.txt";
             if (file_exists($_f))
             {
             $file=fopen($_f,"r+");
             $r_query="";
                while (!feof($file))
                 {
                 $r_query.=fgets($file,256);
                  }

             $rows=unserialize($r_query);  // unserialize the txt written in the txt files

             fclose($file);
             Cache::Cache_Refresh($_f);  // test if a refresh of the cache is needed
             return $rows;
             
             }
             else
             {

                  return 0;
             }
             
             

     }
     
     function Cache_Refresh($_FICHIER)

          /*
           * Make the cache refresh deleting the file
           *
           */
     {

        // See the date of the file

         $DATE_C=filectime($_FICHIER);
         
         $time=time();
         
         $DIFF=$time-$DATE_C;
         
         if ($DIFF>_REFRESHTIMEQUERY)
           {
             // Delete the file is the file is too old

               unlink($_FICHIER);
               

               
               
             //
           }

         ##
     }
     
     function Insert_cache($_QUERY,$_TABLE,$_RESULT)
     {
       /* Write the result of the QUERY in a txt file serializing it.
        * the name of the file is an MD5 of the query
        * Remember that MD5 is an unique value for an unique string.
        */
        $_m=md5($_QUERY);
        $_r=serialize($_RESULT);

        if (!(is_dir(_ABSOLUTEPATHCACHE."/$_TABLE"))) {mkdir(_ABSOLUTEPATHCACHE."/$_TABLE","0777"); } // if the folder corresponding to the table cache doesn't exist, we create it
        
        $file=fopen(_ABSOLUTEPATHCACHE."/$_TABLE/$_m.txt","w");
        fputs($file,$_r);
        fclose($file);


     }
     


}
?>
