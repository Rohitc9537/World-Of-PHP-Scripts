<?

/** Class that display information about the Class in which it is used
* Created for debug purpose
* @author manu
*
*   to use:
*   include_once('util/MonitorObject.php');
*   $truc =& new MonitorObject($this);
*/

class MonitorObject

{

  function MonitorObject($object)

  {

     print ("<h5>Class : ".get_class($object)."</h5>");
     print ("<pre>");

     print ("parent :".get_parent_class($object)."\n");

     print ("Variable :");

     print_r (get_object_vars($object));
     print ("\n");

     print ("</pre>");

  }

}


?>
