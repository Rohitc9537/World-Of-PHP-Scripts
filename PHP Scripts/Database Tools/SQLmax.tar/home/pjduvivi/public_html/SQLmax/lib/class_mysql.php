<?
/* PIERRE JEAN DUVIVIER 2004
 * contact@pjduvivier.com
 * SQLmax version v1.0
 * MYSQL DRIVER FOR SQL LAYER (class_sql.php)
 * MYSQL MANAGEMENT
 */
 
class MySQL
{
       function MySQL($_HOST,$_USER,$_PASS,$_DB,$_P)
       {
           $this->HOST=$_HOST;
           $this->USER=$_USER;
           $this->PASS=$_PASS;
           $this->DB=$_DB;
           $this->PERMANENT=$_P;
           $this->ERROR="";
       }

       function Connect()
        {
          if ($this->PERMANENT==1)
             {
               $this->CONNEX=@mysql_pconnect($this->HOST,$this->USER,$this->PASS)
               or die ($this->ERROR.="ERROR MYSQL 01 - CONNECTION NOT DONE WITH YOUR PARAMETER - class_mysql.php <br>");
             }
          else
             {
               $this->CONNEX=@mysql_connect($this->HOST,$this->USER,$this->PASS)
               or die ($this->ERROR.="ERROR MYSQL 01 - CONNECTION NOT DONE WITH YOUR PARAMETER - class_mysql.php <br>");
             }
      return $this->CONNEX;
        }
        
        function Close()
        {
            mysql_close($this->CONNEX);
        }

      function SelectDB()
       {
          $db_selected=mysql_select_db($this->DB,$this->CONNEX);
          if (!($db_selected))
          {
           $this->ERROR.="ERROR MYSQL 02 - DB $this->DB IS NOT HERE ! - class_mysql.php <br>";
           }
       }
       /* TABLE is the name of the table
        * DATA is an array : key of this array are the name of the field of the table.
        */
       
       function Insert($_TABLE,$_DATA)
       {
         $CONSTRUCT="";
           
         $IDc=mysql_query("SHOW COLUMNS FROM $_TABLE");

         if (!($IDc)) {
          $this->ERROR.="ERROR MYSQL 03 - TABLE $_TABLE doesn't exit on DATABASE $this->DB - class_mysql.php<br>";
         }

         if (@mysql_num_rows($IDc)>0)
         {


            while (list($KEY,$TYPE) = mysql_fetch_array($IDc))
                {
                if (!(isset($_DATA[$KEY])))
                {
                    $this->ERROR.="WARNING MYSQL - $KEY not present in your DATA for the TABLE $_TABLE<br>";
                }
                $CONSTRUCT.="'".$_DATA[$KEY]."',";
                }

         }
         $CONSTRUCT=substr($CONSTRUCT,0,strlen($CONSTRUCT)-1) ;


         
         @mysql_query("insert into $_TABLE VALUES($CONSTRUCT)",$this->CONNEX);
         $LAST_ID=mysql_insert_id($this->CONNEX);
         return $LAST_ID;
       }

       function Query($_QUERY)
       {

          $this->ID_QUERY=@mysql_query($_QUERY,$this->CONNEX);
          $this->ERROR.=mysql_error()."<br>";
          return $this->ID_QUERY;

       }

       function Query_Load($_QUERY)
       {

          $this->ID_QUERY=@mysql_query($_QUERY,$this->CONNEX);
          $tour=0;
          while ($this->ROW[$tour]=@mysql_fetch_array($this->ID_QUERY))
          {
           $tour++;
          }
          return $this->ID_QUERY;
          
       }
       
       function SelectN($_TABLE,$_QUERY)
       {
         $r=@mysql_query("$_QUERY",$this->CONNEX);
         $tour=0;
         while ( $this->ROW[$tour]=@mysql_fetch_array($r,$this->CONNEX))
         {
          $tour++;
         }
         return $r;
       }
       
       function fetch_array($_HANDLER)
       {
         $r=@mysql_fetch_array($_HANDLER);

         $this->ERROR.=mysql_error()."<br>";
         return $r;
       }
       
       function sql_list_fields($_TABLE)
       {
           $fields=mysql_list_fields($this->DB,$_TABLE,$this->CONNEX);
           $columns = mysql_num_fields($fields);

               for ($i = 0; $i < $columns; $i++)
                 {
                $FIELD[$i]=mysql_field_name($fields, $i) . "\n";
                   }
         return $FIELD;
       }
       
       

        
      
}


?>
