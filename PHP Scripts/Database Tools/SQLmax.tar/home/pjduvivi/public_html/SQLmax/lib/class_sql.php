<?
/* PIERRE JEAN DUVIVIER 2004
 * contact@pjduvivier.com
 * SQLmax version v1.0
 * ----------------------------------------
 * CLASS FOR SQL MANAGEMENT ] MULTIDATABASE ABSTRACT
 * SQL LAYER
 * MANAGEMENT OF ALL KIND OF DATABASE ACCESS WITH CACHE SYSTEM FOR QUERIES
 * ---------------------------------------
 * The functions are the following ones :
 * ---------------------------------------
 * Connect($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE,$TYPE,$PERMANENT) : do the connection
 * SelectDB() : make the DB selection
 * Close : close the connection
 * Insert($TABLE,$DATA) : do the insertion in a database ,$DATA is an array
 * Query($SQL) : do a direct query without cache.   $SQL is an SQL string.
 * findTableName($SQL): find the name of the table inside an select query.
 * Select($SQL) : do a select using the cache feature.$SQL is an SQL string.
 * this command return a new object $this->CNX->ROW as the result of the query
 * fetch_array(): SQL fetch array command
*/


Class SQL

{
    /*
     *  Constructor of the class SQL
     *
     *  DBHOST = Url of the database
     *  DBUSERNAME=Username for the database
     *  DBPASS    =Password for the username
     *  TYPE = MySQL, ect...
     *  PERMANENT=0 for a non permanent connection, 1 for a permanent (connect,pconnect)
     *
     */

    function SQL($_DBHOST,$_DBUSERNAME,$_DBPASS,$_DBSELECT,$_TYPE,$_PERMANENT)
    {
        $this->DB_HOST=$_DBHOST;
        $this->DB_USER=$_DBUSERNAME;
        $this->DB_PASS=$_DBPASS;
        $this->DB_BASE=$_DBSELECT;
        $this->DB_TYPE=$_TYPE;
        $this->DB_PERMANENT=$_PERMANENT;
    }
    

     /*
      * Make the connection
      */
      
    function Connect()
    {
       switch ($this->DB_TYPE)
       {
           case "MySQL":
           $this->GOOD=1;
           $this->CNX=new MySQL($this->DB_HOST,$this->DB_USER,$this->DB_PASS,$this->DB_BASE,$this->DB_PERMANENT);
           break;
           

           default :
           $this->GOOD=0;
           $this->CNX=new MySQL($this->DB_HOST,$this->DB_USER,$this->DB_PASS,$this->DB_BASE,$this->DB_PERMANENT);
           break;
       }
       if ($this->GOOD==1)
       {
       $this->CNX->Connect();
       

       }
       else
       {
        $this->CNX->ERROR.="ERROR SYSTEM - DATABASE TYPE NOT FOUND OR NOT IMPLEMENTED in class_sql.php layer";
        print $this->CNX->ERROR;
        exit;
       }
    }
    
    /*
     * After the connection made, make the DB selection.
     */
    
    function SelectDB()
    {
       $this->CNX->SelectDB();
       
        ### CREATION DU CACHE -----CACHE CREATION-------

       $this->Cache=new Cache(_CACHESYSTEM,$this->CNX);

       ### --------------------------------------------
    }
    
    /*
     * Close the selection.
     */

    function Close()
    {
        $this->CNX->Close();
    }
    
    /*
     * After the connection made, make an insert using an array DATA
     * The key of the array are the fieldname of the table $_TABLE
     */
    
    function Insert($_TABLE,$_DATA)
    {
     $this->LAST_ID=$this->CNX->Insert($_TABLE,$_DATA);
    }
    
    /*
     * Find the name of the table inside the SQL query
     */
    
    function findTableName($_SQL)
    {
        $separateur="from";
        $A=explode($separateur,$_SQL);
        $B=$A[1];
        $C=explode(" ",$B);
        $Table=trim($C[0]);
        
        return $Table;

    }
    
    /*
     *  The select method  : if you want to use the cache system
     */
    
    
    function Select($_QUERY)

     /*  this function is important because it's the heart of the system
      *  Here we see if there is an txt file with the MD5 of the query.
      *  if this txt file doesn't exist we create the file using an SQL query to retreive the data
      *  The next time an user will come it will be loaded by the txt file.
      */
      
     {

       ### Find the name of the table
       
       $_TABLE=SQL::findTableName($_QUERY);
       
       ### ------------------------------

      if ($this->Cache->Init==1)    // if the cache option is enable (see param_connex.php)
      {


          $this->CNX->ROWs=$this->Cache->Cache_Exist($_QUERY,$_TABLE);    // we look for the txt file with the md5 of the query

          if (isset($this->CNX->ROWs[0]))  // if a result is returned, it means that the files exist
           {

               $this->CNX->ROW=$this->CNX->ROWs;    // We store the result of the txt file
               $this->CNX->NB_ROWS=count($this->CNX->ROWs);


           }
           else
           {

           $this->IDc=$this->CNX->Query_Load($_QUERY);   // we do an sql query to retreive the data
           $this->Cache->Insert_Cache($_QUERY,$_TABLE,$this->CNX->ROW); // We create the txt file.

           }

      }
      else
      {

        $this->IDc=$this->CNX->SelectN($_TABLE,$_QUERY);     // if cache option is disabled we do a classic SQL query
      }
      ### --- ##
      return $this->CNX->ROW;
    }
    
    /*
     * Make a direct Query without Cache System (for update, delete, ect..)
     */

    function Query($_QUERY)
    {

      $this->IDq=$this->CNX->Query($_QUERY);
      return $this->IDq;
    }
    
    /*
     * Use fetch_array command
     */

    
    function fetch_array()
    {
      return $this->CNX->fetch_array($this->IDq);
    }
    
     /*
      * List SQL field
      */
     
    function sql_list_fields($_TABLE)
    {
      return $this->CNX->sql_list_fields($_TABLE);
    }
    

    
}
?>
