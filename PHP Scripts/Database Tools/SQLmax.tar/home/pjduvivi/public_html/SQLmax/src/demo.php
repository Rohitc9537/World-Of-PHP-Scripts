<?

/* PIERRE JEAN DUVIVIER 2004
 * contact@pjduvivier.com
 * SQLmax version v1.0
 * Demo script which demonstrate how to use the SQLmax solution
 *
 */

### Include all the librairy of SQLmax and the parameteres define file

include('../lib/param_connex.php');
include('../lib/class_cache.php');
include('../lib/class_mysql.php');
include('../lib/class_sql.php');

### Create a new SQL object

$SQL=new SQL($dbhost,$dbuname,$dbpass,$dbname,$dbtype,0);

### Make the connection
$SQL->connect();

### Do the Database selection.
$SQL->selectDB();

### Make a query using the 'Select' method wich provide cache support.

$Query="select id_voiture,nom from voiture";
$SQL->Select($Query);

### Display the result of the selection.

while (list($A,$ROW)=each($SQL->CNX->ROW))

{
      print "voiture name : $A -  ". $ROW['nom']."<br>";
}

### Close the connection

## Make an insertion using the Insert method

### To make an insertion, just use an array filled with the key of the column name of the table
### Exemple :

 $DATA['nom']="MyCar"; // Fill the 'nom' column
 $DATA['type']="2";     // fill the 'type' column
 $DATA['id_voiture']="";
 
$SQL->Insert("voiture",$DATA);
 
## Make a new insertion in the table 'voiture'
 
### Print all mysql ERROR

print "Error :";
echo"<br>";
echo $SQL->CNX->ERROR;

## Close the connection.
$SQL->close();
?>
