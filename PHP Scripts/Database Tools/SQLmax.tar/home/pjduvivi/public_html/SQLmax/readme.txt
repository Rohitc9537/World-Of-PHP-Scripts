########### SQLmax version v1.0   ############
###########    30/08/2005         ############ 
###########  Pierre Jean Duvivier ############
########### contact@pjduvivier.com ###########

1] What is SQLmax
-----------------

SQLmax is a library which provide an SQL layer with cache support (wich increase
the speed of the database access).
to help you to build safe and powerfull database access. It is written
in PHP POO. It support for the moment only MySQL but you can add other database 
switching the layer used. 

We provide three classes.

2 ] How i use it ?
------------------

To use it, just see the /src/demo.php example to understand the syntax
before you have to install /sql/SQLmax.sql sql in your Mysql database and configure the /lib/param_connex.php
file to include your connection datas.

3 ] What is the /cache folder
-----------------------------

the /cache folder is here to provide the cache support : this folder have to be writable by the script user.


4] Can i use the SQLmax layer for free ?
----------------------------------------

Yes...for any kind of commercial/non commercial use. The only thing is that you have to keep the header of each 
files inside your own production.

5 ] If i want to add an other function or a database layer (Oracle..), can i do it ?
------------------------------------------------------------------------------------

Yes..sure. and you can send me at contact@pjduvivier.com your production for integration to the project.
If you keep the header you can add/modify any functions and distribute it.

