﻿<?php
$int_fields_ar[0][0] = "Name of the field:";
$int_fields_ar[0][1] = "name_field";

$int_fields_ar[1][0] = "Label:";
$int_fields_ar[1][1] = "label_field";
$int_fields_ar[1][2] = "text";
$int_fields_ar[1][3] = "25";

$int_fields_ar[2][0] = "Field type:";
$int_fields_ar[2][1] = "type_field";
$int_fields_ar[2][2] = "select_custom";
$int_fields_ar[2][3] = "text/textarea/rich_editor/password/insert_date/update_date/date/select_single/select_multiple/select_multiple_checkbox/generic_file/image_file/ID_user/unique_ID";

$int_fields_ar[3][0] = "Content type:";
$int_fields_ar[3][1] = "content_field";
$int_fields_ar[3][2] = "select_custom";
$int_fields_ar[3][3] = "alphabetic/alphanumeric/numeric/url/email/html/phone";

$int_fields_ar[4][0] = "Field present in the search form?";
$int_fields_ar[4][1] = "present_search_form_field";
$int_fields_ar[4][2] = "select_yn";

$int_fields_ar[5][0] = "Field value shown in the results page?";
$int_fields_ar[5][1] = "present_results_search_field";
$int_fields_ar[5][2] = "select_yn";

$int_fields_ar[6][0] = "Field value shown in the details page?";
$int_fields_ar[6][1] = "present_details_form_field";
$int_fields_ar[6][2] = "select_yn";

$int_fields_ar[7][0] = "Field present in the insert/update form?";
$int_fields_ar[7][1] = "present_insert_form_field";
$int_fields_ar[7][2] = "select_yn";

$int_fields_ar[8][0] = "Is the field a required one?";
$int_fields_ar[8][1] = "required_field";
$int_fields_ar[8][2] = "select_yn";

$int_fields_ar[9][0] = "Check for duplicated entries during insert?";
$int_fields_ar[9][1] = "check_duplicated_insert_field";
$int_fields_ar[9][2] = "select_yn";


$int_fields_ar[10][0] = "Other choices allowed?";
$int_fields_ar[10][1] = "other_choices_field";
$int_fields_ar[10][2] = "select_yn";

$int_fields_ar[11][0] = "Option to include:";
$int_fields_ar[11][1] = "select_options_field";
$int_fields_ar[11][2] = "text";
$int_fields_ar[11][3] = "25";

$int_fields_ar[12][0] = "Primary key field:";
$int_fields_ar[12][1] = "primary_key_field_field";
$int_fields_ar[12][2] = "text";
$int_fields_ar[12][3] = "25";

$int_fields_ar[13][0] = "Primary key table:";
$int_fields_ar[13][1] = "primary_key_table_field";
$int_fields_ar[13][2] = "text";
$int_fields_ar[13][3] = "25";

$int_fields_ar[14][0] = "Linked fields:";
$int_fields_ar[14][1] = "linked_fields_field";
$int_fields_ar[14][2] = "text";
$int_fields_ar[14][3] = "25";

$int_fields_ar[15][0] = "Order by:";
$int_fields_ar[15][1] = "linked_fields_order_by_field";
$int_fields_ar[15][2] = "text";
$int_fields_ar[15][3] = "25";

$int_fields_ar[16][0] = "Order type:";
$int_fields_ar[16][1] = "linked_fields_order_type_field";
$int_fields_ar[16][2] = "text";
$int_fields_ar[16][3] = "25";

$int_fields_ar[17][0] = "Extra for MySQL statement:";
$int_fields_ar[17][1] = "linked_fields_extra_mysql";
$int_fields_ar[17][2] = "text";
$int_fields_ar[17][3] = "25";

$int_fields_ar[18][0] = "Search operators:";
$int_fields_ar[18][1] = "select_type_field";
$int_fields_ar[18][2] = "text";
$int_fields_ar[18][3] = "25";

$int_fields_ar[19][0] = "Prefix:";
$int_fields_ar[19][1] = "prefix_field";
$int_fields_ar[19][2] = "text";
$int_fields_ar[19][3] = "25";

$int_fields_ar[20][0] = "Default value:";
$int_fields_ar[20][1] = "default_value_field";
$int_fields_ar[20][2] = "text";
$int_fields_ar[20][3] = "25";

$int_fields_ar[21][0] = "Width (chars):";
$int_fields_ar[21][1] = "width_field";
$int_fields_ar[21][2] = "text";
$int_fields_ar[21][3] = "2";

$int_fields_ar[22][0] = "Height (chars):";
$int_fields_ar[22][1] = "height_field";
$int_fields_ar[22][2] = "text";
$int_fields_ar[22][3] = "2";

$int_fields_ar[23][0] = "Maxlength:";
$int_fields_ar[23][1] = "maxlength_field";
$int_fields_ar[23][2] = "text";
$int_fields_ar[23][3] = "4";

$int_fields_ar[24][0] = "Hint:";
$int_fields_ar[24][1] = "hint_insert_field";
$int_fields_ar[24][2] = "text";
$int_fields_ar[24][3] = "25";

$int_fields_ar[25][0] = "Separator of the options:";
$int_fields_ar[25][1] = "separator_field";
$int_fields_ar[25][2] = "text";
$int_fields_ar[25][3] = "2";
?>
