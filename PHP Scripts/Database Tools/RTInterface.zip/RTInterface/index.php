<?php

require("./classes/default.class.inc.php");

?>
