	</td>
  </tr>
</table>
   <?php showTableList();  ?>
<p class="footer" align="center"><?php global $footer_text; echo $footer_text;?></p>
</body>
</HTML>
