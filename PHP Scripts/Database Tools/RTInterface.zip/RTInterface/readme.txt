RTInterface 0.5

This is a generic php interface for mysql and it's intended for educational purpose:).
I've done this script just for learning, reading some tutorials found on the net. 
The script uses a Object Oriented model to comunicate with the db.

INSTALLATION
1 - Create your own *.class.inc in the /class dir, following the instruction in default.class.inc.php
and the example classes(Person and Message, plz delete them later :) )
2 - Change all the configuration parameters in ./inc/cfg.inc.php and (if you want) the graphics in ./inc/cfg.inc.css (css style)
3 - upload the script
4 - run the script by opening show.php:D

THE SCRIPT
You can read the comments in the scripts to understand the code. 
./classes dir contains the classes information. default.class.inc.php it's the main script file that interacts with the db.
./inc files contain the general interface functions and the configuration files.
./ files contain the html/php user interface files.

If you have any comments or suggestions please write me(webmaster@toldo.info)