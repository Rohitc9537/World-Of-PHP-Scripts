<?php require_once("./inc/header.inc.php"); ?>
<?php showTable(); ?>
<?php require_once("./inc/footer.inc.php"); ?>