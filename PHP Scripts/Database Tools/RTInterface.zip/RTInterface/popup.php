<?PHP

echo $_GET['value'];

?>