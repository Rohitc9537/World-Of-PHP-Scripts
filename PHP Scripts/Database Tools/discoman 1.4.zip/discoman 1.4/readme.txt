DiscoMan

version 1.4 du 22/05/05

Installation automatique :

1�) D�zippez le fichier discoman 1.4.zip

2�) Depuis votre navigateur, lancez le fichier <chemin d'acc�s>/install/install.php

Etape 1 :

SERVER : localhost (si vous installez le script en local) ou l'adresse de votre serveur mysql

BASE : le nom de la base � cr�er

NOM : root ou votre user

PASSWORD : n�ant ou votre mot de passe

3�) Validez pour acc�der � l'�tape 2

4�) Lancez l'application ! Vous pouvez effacer le r�pertoire install

Installation manuelle :

Si l'installation automatique a �chou�e :

1�) D�zippez le fichier discoman 1.4.zip

2�) Modifiez le fichier link.inc.php en ins�rant entre les guillemets le nom de votre serveur, le nom de votre base de donn�es, votre nom d'utilisateur et votre mot de passe.

Si vous �tes en local, par exemple :

$serveur = "localhost";
$database = "discoman"; (le nom de votre base de donn�es)
$username = "root";
$password = "";

3�) Puis, gr�ce � PhpMyadmin, ex�cutez le fichier discoman.sql

Cela aura pour effet de cr�er les tables.

4�) Rendez-vous � (si vous travaillez en local) localhost/<nom_de_votre_r�pertoire>/index.php

ou si vous travaillez sur un serveur distant : <nom_de_votre_domaine>/<nom_de_votre_r�pertoire>/index.php

Bonne utilisation !

Plus d'infos : http://www.the-mirror-of-dreams.com rubrique "scripts php"

