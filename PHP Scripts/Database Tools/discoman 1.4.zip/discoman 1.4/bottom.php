<?php

//CREDIT SUR 3EME FRAME

require("presentation.inc.php");
HAUTPAGEWEB('www.the-mirror-of-dreams.com');
CREDIT();

echo "<div align=\"center\">DiscoMan &copy; 2004 E.R. - <a href=\"http://www.the-mirror-of-dreams.com\" target=\"_blank\">www.the-mirror-of-dreams.com</a>";

BASPAGEWEB();
?>