<html>
<head>
<title>DiscoMan</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<meta name='description' content='Forums sur la musique : Frankie Goes To Hollywood, Talk Talk, Einsturzende Neubauten, Yello et le cin�ma : Emir Kusturica'>
<meta name='Keywords' content='FRANKIE GOES TO HOLLYWOOD, TALK TALK, EINSTURZENDE NEUBAUTEN, EMIR KUSTURICA, MUSIQUE, CINEMA, DISCOGRAPHIE, FILMOGRAPHIE, FGTH, FORUM'>
<meta http-equiv='expires' content='0'>
<META NAME='robots' CONTENT='index, follow'>
<meta name='revisit-after' content='7 days'>


</head>

<!--<frameset framespacing="0" border="0" frameborder="0" rows="150,415,*">-->
<frameset framespacing="0" border="0" frameborder="0" rows="124,*">
  <frame name="top" scrolling="no" noresize target="middle" src="top.php">
  <frame name="middle" scrolling="no" target="middle" src="main4.php">
  <noframes>
  <body>
  <p>This page uses frames, but your browser doesn't support them.</p>
  </body>
  </noframes>
</frameset>

</html>