<?
echo"
<meta http-equiv=\'Content-Type\' content=\'text/html; charset=iso-8859-1\'>

<meta name=\'description\' content=\'A COMPLETER\'>

<meta name=\'Keywords\' content=\'A COMPLETER\'>

<meta http-equiv=\'expires\' content=\'0\'>

<META NAME=\'robots\' CONTENT=\'index, follow\'>

<meta name=\'revisit-after\' content=\'7 days\'>";
?>