<?php //FICHIER D'AIDE

require("presentation.inc.php");

HAUTPAGEWEB('Discoman - Help');
LAYERS2();
?>

	<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">
    	<th>Aide</th>
    </table>
    <table class="Stable" border="1" style="border-color:#000000;" width="100%" cellpadding="0" cellspacing="0">
    	<tr>
        	<td>
            <a name="0"></a><b>Sommaire :</b><br><br>

            <a href="#1">Premi�re utilisation</a><br>
            <a href="#2">Gestion des artistes</a><br>
            <a href="#3">Gestion des formats</a><br>
            <a href="#4">Gestion des pays</a><br>
            <a href="#5">Gestion des enregistrements</a><br>
            <a href="#6">Gestion des utilisateurs</a><br>
            <a href="#7">Gestion des infos</a><br><br>

            <a name="1"></a><b>Premi�re utilisation :</b><br><br>

			Cr�er votre profil d'administrateur : Pour cel�, cliquez sur Connexion => Admin. Pour la 1�re connexion, le programme vous demande de saisir un nom et un mot de passe. Conservez les pr�cieusement, ils seront n�cessaires pour chaque ajout, modification, suppression d'�l�ments de la base de donn�es. Une fois le profil admin cr��, vous devez vous relogger, ce qui vous permet d'acc�der au panneau de contr�le. Pour permettre � la base de donn�es d'accepter des enregistrements, il faut obligatoirement param�trer :<br>
            - les artistes<br>
            - les diff�rents formats<br>
            - les diff�rents pays<br>
            et �ventuellement les diff�rents utilisateurs � qui vous donnerez des droits d'acc�s.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="2"></a><b>Gestion des artistes :</b><br><br>

            Connectez-vous en tant qu'admin ou utilisateur niveau 2.<br>
            Cr�ation : Cliquer sur "Ajouter". Remplir le champ nom et valider. Le nouvel artiste est ajout� � la liste.<br>
            Modification : Cliquer sur "Modifier". Choisir l'artiste � modifier. Modifiez le nom et validez.<br>
            Suppression : Cliquer sur "Supprimer". Choisir l'artiste � supprimer et cliquez sur "Supprimer". Si des enregistrements li�s � l'artiste existent, vous obtiendrez un message d'avertissement. Il convient alors d'effacer tous ces enregistrements pour pouvoir effacer l'artiste. Voir la section <a href="#5">Gestion des enregistrements</a>.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="3"></a><b>Gestion des formats :</b><br><br>

            Connectez-vous en tant qu'admin ou utilisateur niveau 2.<br>
            Cr�ation : Cliquer sur "Ajouter". Remplir le champ format (abr�viation, par ex : LP ou 12"), ainsi que la description du champ (ex : 33 tours, maxi 45 tours) et valider. Le nouveau format est ajout� � la liste existante.<br>
            Modification : Cliquer sur "Modifier". Choisir le format � modifier. Modifiez le nom ou/et la d�signation et validez.<br>
            Suppression : Cliquer sur "Supprimer". Choisir le format � supprimer et cliquer sur "Supprimer". Si des enregistrements li�s au format existent, vous obtiendrez un message d'avertissement. Il convient alors d'effacer ou modifier tous ces enregistrements pour pouvoir effacer le format. Voir la section <a href="#5">Gestion des enregistrements</a>.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="4"></a><b>Gestion des pays :</b><br><br>

            Connectez-vous en tant qu'admin ou utilisateur niveau 2.<br>
            Cr�ation : Cliquer sur "Ajouter". Remplir le nom du pays et son abr�viation (par ex : F pour France), Puis valider. Le nouveau pays est ajout� � la liste.<br>
            Modification : Cliquer sur "Modifier". Choisir le pays � modifier. Modifiez le nom ou/et la d�signation et validez.<br>
            Suppression : Cliquer sur "Supprimer". Choisir le pays � supprimer et cliquer sur "Supprimer". Si des enregistrements li�s au pays existent, vous obtiendrez un message d'avertissement. Il convient alors d'effacer ou modifier tous ces enregistrements pour pouvoir effacer le pays. Voir la section <a href="#5">Gestion des enregistrements</a>.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="5"></a><b>Gestion des enregistrements :</b><br><br>

            Connectez-vous en tant qu'admin ou utilisateur.<br>
            Cr�ation : Cliquer sur "Ajouter". Remplir :<br>
            - le nom de l'artiste en le s�lectionnant dans le menu d�roulant<br>
            - t�l�charger de une � 3 images en cliquant sur le bouton parcourir. Les formats accept�s sont jpg et gif, inf�rieurs � 300 ko. Recommandation : Une image de 400x400 pixels avec une r�solution assez faible pour un poids total d'environ 100 ko semble un bon compromis.<br>
            - S�lectionner le format<br>
            - Saisir l'ann�e de sortie<br>
            - S�lectionner le pays d'origine<br>
            - Saisir la r�f�rence<br>
            - Ajouter un �ventuel commentaire<br>
            - Saisir le ou les titres contenus sur le disque.<br>
            Puis valider.<br>
            Modification : Cliquer sur "Modifier". Choisir dans la liste d�roulante, l'artiste pour lequel vous voulez modifier des enregistrements. S�lectionnez ensuite l'enregistrement souhait� dans la liste. Modifier les �l�ments voulus et valider. Si vous ne souhaitez modifier qu'une ou plusieurs images (ajout, modification, suppression), il suffit de cliquer sur le bouton correspondant � l'image. TRES IMPORTANT : Si plusieurs images sont concern�es, il convient de raffra�chir la page entre chaque modification. Si seules les images sont modifi�es, il est inutile de valider car la modification est directement prise en compte dans la base de donn�es.<br>
            Suppression : Cliquer sur "Supprimer". Choisir dans la liste d�roulante, l'artiste pour lequel vous voulez supprimer un enregistrement. S�lectionnez ensuite l'enregistrement souhait� dans la liste et valider.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="6"></a><b>Gestion des utilisateurs :</b><br><br>

            Connectez-vous en tant qu'admin.<br>
            Cr�ation : Cliquer sur "Ajouter". Remplir le nom et s�lectionner son niveau :<br>
            - 1 : l'utilisateur peut ajouter, modifier et supprimer des enregistrements,<br>
            - 2 : l'utilisateur peut ajouter, modifier et supprimer des enregistrements, artistes, formats et pays.<br> Puis valider. Le nouvel utilisateur est ajout� � la liste.<br>
            Modification : Cliquer sur "Modifier". Choisir l'utilisateur � modifier. Modifiez son niveau et validez.<br>
            Suppression : Cliquer sur "Supprimer". Choisir l'utilisateur � supprimer et cliquer sur "Supprimer".<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>

            <a name="7"></a><b>Gestion des infos :</b><br><br>

            Se connecter en tant qu'admin.<br>
            Cr�ation : Cliquer sur "Ajouter". Saisir le sujet et le texte, �ventuellement ajouter une image (max 300 ko). Vous pouvez ajouter des balises html. Puis valider. La nouvelle info est ajout�e � la liste.<br>
            Modification : Cliquer sur "Modifier". Choisir l'info � modifier. Modifier le sujet et/ou le texte. Valider.<br>
            Suppression : Cliquer sur "Supprimer". Choisir l'info � supprimer et cliquer sur "Supprimer".<br>
            Recommandations : les images font par d�faut 200x200 pixels en affichage sur la page d'accueil. Donc ne pas s�lectionner d'images trop lourdes (100 ko devrait �tre le maximum), surtout s'il y a une image par info, afin que la page ne mette pas trop de temps � s'afficher. Ensuite, vu la taille d'affichage, une r�solution importante ne sert � rien. Afin de limiter le poids de la page, seules les 10 derni�res infos s'affichent sur la page infos. Les autres restent n�anmoins accessibles depuis le panel admin.<br><br>

        	<div align="right"><a href="#0">Retour au sommaire</a></div><br><br>
            </td>
		</tr>
    </table>
<?
BASPAGEWEB();
?>