<?
//Boutons :

$txt_fichier = "Files";
$txt_consultation = "View";
$txt_connexion = "Connection";
$txt_ajouter = "Add";
$txt_rechercher = "Search";
$txt_recents = "Lasts";
$txt_infos = "Infos";
$txt_admin = "Admin";
$txt_aide = "Help";
$txt_a_propos = "About";
$txt_recherche_rapide = "Quick search";
$txt_recherche_disco = "Search a record";
$txt_chercher = "Search";

//Libell�s de champs ou colonnes :

$txt_artistes = "Artists";
$txt_artiste = "Artist";
$txt_formats = "Formats";
$txt_format = "Format";
$txt_annees = "Years";
$txt_annee = "Year";
$txt_payss = "Countries";
$txt_pays = "Country";
$txt_refs = "R�f�rences";
$txt_ref = "R�f�rence";
$txt_com = "Comment";
$txt_titres = "Titles";
$txt_titre = "Title";
$txt_exact = "exactly";

//Textes divers :

$txt_ajouter_disque = "Add record";
$txt_le_disque = "The record";
$txt_succes = "has been added successfully.";
$txt_image = "Image";
$txt_results = "last 30 records";
$txt_no = "No result";
$txt_resultat = "Results for";
$txt_prec = "Previous page";
$txt_enregistrements = "Number of records in the database :";
?>