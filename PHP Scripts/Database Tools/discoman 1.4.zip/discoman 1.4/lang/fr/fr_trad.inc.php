<?
//Boutons :

$txt_fichier = "Fichier";
$txt_consultation = "Consultation";
$txt_connexion = "Connexion";
$txt_ajouter = "Ajouter";
$txt_rechercher = "Rechercher";
$txt_recents = "R�cents";
$txt_infos = "Infos";
$txt_admin = "Admin";
$txt_aide = "Aide";
$txt_a_propos = "A&nbsp;propos";
$txt_recherche_rapide = "Recherche rapide";
$txt_recherche_disco = "Rechercher un disque";
$txt_chercher = "Chercher";

//Libell�s de champs ou colonnes :

$txt_artistes = "Artistes";
$txt_artiste = "Artiste";
$txt_formats = "Formats";
$txt_format = "Format";
$txt_annees = "Ann�es";
$txt_annee = "Ann�e";
$txt_payss = "Pays";
$txt_pays = "Pays";
$txt_refs = "R�f�rences";
$txt_ref = "R�f�rence";
$txt_com = "Commentaire";
$txt_titres = "Titres";
$txt_titre = "Titre";
$txt_exact = "exactement";

//Textes divers :

$txt_ajouter_disque = "Ajouter disque";
$txt_le_disque = "Le disque";
$txt_succes = "a �t� ajout� avec succ�s.";
$txt_image = "Image";
$txt_results = "30 derniers enregistrements";
$txt_no = "Aucun r�sultat";
$txt_resultat = "R�sultats pour";
$txt_prec = "Page pr�cedente";
$txt_enregistrements = "Nombre d'enregistrements dans la base de donn�es :";
?>