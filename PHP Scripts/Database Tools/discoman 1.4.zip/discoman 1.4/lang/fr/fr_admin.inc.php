<?php

//libell�s noms de colonnes ou de champ
$txt_images = "Images";
$txt_image = "Image";
$txt_abrege = "Abr�g�";
$txt_admin = "Admin";
$txt_artistes = "Artistes";
$txt_artiste = "Artiste";
$txt_formats = "Formats";
$txt_format = "Format";
$txt_annees = "Ann�es";
$txt_annee = "Ann�e";
$txt_payss = "Pays";
$txt_pays = "Pays";
$txt_refs = "R�f�rences";
$txt_ref = "R�f�rence";
$txt_coms = "Commentaires";
$txt_com = "Commentaire";
$txt_titres = "Titres";
$txt_titre = "Titre";
$txt_infos = "Infos";
$txt_designations = "D�signations";
$txt_designation = "D�signation";

//divers :
$txt_nom = "Nom";
$txt_mdp = "Mot de passe";
$txt_disques = "Disques";
$txt_utils = "Utilisateurs";

//Texte d'information
$txt_saisir = "Veuillez saisir votre nom et votre mot de passe.";
$txt_choisir_artiste = "Choisissez l'artiste dont vous souhaitez modifier les enregistrements.";
$txt_choisir_artiste_eff = "Choisissez l'artiste dont vous souhaitez effacer un ou plusieurs enregistrements.";
$txt_choisir_disque = "Choisissez le disque � modifier.";
$txt_choisir_disque_sup = "Choisissez le disque � supprimer.";
$txt_choisir_artiste_maj = "Choisissez l'artiste � modifier.";
$txt_choisir_artiste_sup = "Choisissez l'artiste � supprimer.";

//textes erreurs
$txt_result_0 = "Pas de r�sultat.";
$txt_erreur_cases_vides = "Erreur : Une ou plusieurs cases ne sont pas renseign�es.";
$txt_lartiste = "L'artiste ";
$txt_enregistre = "a �t� enregistr� avec succ�s.";
$txt_fiche = "Fiche de";
$txt_maj = "mise � jour.";
$txt_attention = "Attention !";
$txt_sup_impos = "Des enregistrements contiennent des r�f�rences � cette donn�e. Suppression impossible tant que les enregistrements n'ont pas �t� modifi�s en cons�quence.";
$txt_nouveau_for = "Le nouveau format";

//libell�s en-t�tes de pages :
$txt_maj_disque = "Mise � jour enregistrements";
$txt_maj_artiste = "Mise � jour artistes";
$txt_resultat = "R�sultats pour";
$txt_suppression = "Suppression enregistrements";
$txt_ajout_art = "Ajout artistes";
$txt_sup_artist = "Suppression artistes";
$txt_ajout_for = "Ajout format";
$txt_ajout_pays = "Ajout pays";

//libell�s boutons :
$txt_raffraichir = "Raffra�chir";
$txt_envoyer = "Valider";
$txt_modifier = "Modifier";
$txt_effacer = "Supprimer";
$txt_ajouter = "Ajouter";

//Aide :
$txt_aide_01 = "Maximum : 30 caract�res avec dans l'ordre, le pr�nom puis le nom.";
$txt_aide_02 = "Maximum : 5 caract�res";
$txt_aide_03 = "Maximum : 40 caract�res";
$txt_aide_04 = "Maximum : 20 caract�res";
$txt_aide_05 = "Maximum : 3 caract�res";
?>