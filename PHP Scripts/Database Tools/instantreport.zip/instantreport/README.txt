BENRUTH INSTANT REPORT README NOTES
Copyright (c) 2004, BENRUTH SOFTWARE CONSULTANCY ( www.benruth.com )
All rights reserved.


Version 1.0
Released 13 Jul 2004
=======================
This script was born out of necessity for me. I was creating quite a few reports that are to be extracted
from MySQL datbase. Format them into a table like structure, with or without headers. And be able to view as 
HTML, download as HTML, or download as EXCEL.

All settings to generate a report can be controlled by adjusting the variables found in config.inc.php

This script helped me somewhat in having some spare time to go for a good round of fishing. I hope that it 
will aid you as it aided me.

There would not be any technical assistance on this script. However you can pop a question or so to me at my
email ( ben AT benruth DOT com ). It is good to say hi!

You could visit my website at www.benruth.com

Thank you once again!



Features-At-A-Glance
=======================
- Configurable script
- Simple table for
  - Download as EXCEL
  - Download as HTML
  - Viewing as HTML
- Extraction from MySQL database




Donations!
=======================

If somehow you think this script has helped you in some way, why not support the developer by donating any amount
to his paypal account ( ben AT benruth DOT com ). It will be very appreciated! :-)