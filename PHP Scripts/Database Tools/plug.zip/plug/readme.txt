Thank you for Downloading the Plug-Board Script!

1. Open "config.php" and edit all the varibles there.
2. Upload all files to your webserver/
3. Open http://www.yoursite.com/plug/install.php to install your database
4. Open "admin.php" in a text editor and edit your username and password in this line:

$user = "admin";
$pass = "pass";

make sure that both the username and passwords are the same.

5. Add this code to the page you want your plugboard to be on:

<iframe  src="http://www.yoursite.com/plug/plug.php" width="504" height="371" frameborder="0" scrolling=no name="I1" align="right"></iframe>

6. To delete plugs from the Plug-Board visit http://www.yourdomain.com/plug/admin.php and login using the username & password you entered above.

7. To Ban a IP login to your admin panel, next to the IP click "[Ban]". To Unban IP's you will see "[Unban]" next to the ban button, click that.


Enjoy =)

If you need any help please e-mail us: admin@plug-world.net