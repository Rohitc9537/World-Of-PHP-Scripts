<?php

if($url == "http://www.outpimp.com" || $url == "http://outpimp.com") { 

die("<font size='2' face='$face'>Your Domain has been banned<br><a href='http://$website/plug.php'>Go Back</a></font>"); }

// To ban more domains add - $url == "http://domain.com"  and  $url == "http://www.domain.com", between the brakets above.

?>




