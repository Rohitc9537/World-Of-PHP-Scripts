project_name;MySQL Commander
version;2.65
release_date;2005-08-05

author_name;Oliver K�hrig
author_email;oliver@bitesser.de

homepage_text;bitesser
homepage_link;http://www.bitesser.de