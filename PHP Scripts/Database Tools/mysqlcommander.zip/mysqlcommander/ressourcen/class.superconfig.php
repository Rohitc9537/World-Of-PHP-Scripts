<?php 
class superconfig {
	var $commander_user = "";
	var $commander_pass = "";
	var $mysql_databasename1 = "";
	var $mysql_user1 = "";
	var $mysql_password1 = "";
	var $mysql_server1 = "";
	var $mysql_databasename2 = "";
	var $mysql_user2 = "";
	var $mysql_password2 = "";
	var $mysql_server2 = "";
	var $comment_xxx_cbdcd7695b76732503e7fe8af587f9eb = "";
	var $comment_xxx_b28aae7e1d9f0f4124ca6f3a37f6d94c = "";
	var $interface_username = "";
	var $interface_password = "";
	var $list_dbase = "";
	var $not_list_dbase = "";
	var $default_seperator = "";
	var $strLineFeedCode = "";
	var $strCarriageReturnCode = "";
	var $default_sets_per_file = "";
	var $default_setTimeLimit = "";
	var $data_path = "";
	var $language = "";
	var $mysql_databasename3 = "";
	var $mysql_user3 = "";
	var $mysql_password3 = "";
	var $mysql_server3 = "";
	var $mysql_databasename4 = "";
	var $mysql_user4 = "";
	var $mysql_password4 = "";
	var $mysql_server4 = "";
	var $mysql_databasename5 = "";
	var $mysql_user5 = "";
	var $mysql_password5 = "";
	var $mysql_server5 = "";
	var $mysql_databasename6 = "";
	var $mysql_user6 = "";
	var $mysql_password6 = "";
	var $mysql_server6 = "";

	function superconfig () {
		$this->commander_user = "";
		$this->commander_pass = "";
		$this->mysql_databasename1 = "Local Server";
		$this->mysql_user1 = "root";
		$this->mysql_password1 = "";
		$this->mysql_server1 = "localhost";
		$this->mysql_databasename2 = "";
		$this->mysql_user2 = "";
		$this->mysql_password2 = "";
		$this->mysql_server2 = "";
		$this->comment_xxx_cbdcd7695b76732503e7fe8af587f9eb = "To configure more Servers scroll down";
		$this->comment_xxx_b28aae7e1d9f0f4124ca6f3a37f6d94c = "";
		$this->interface_username = "test";
		$this->interface_password = "test2";
		$this->list_dbase = "";
		$this->not_list_dbase = "";
		$this->default_seperator = "||#||";
		$this->strLineFeedCode = "##|n|##";
		$this->strCarriageReturnCode = "##|r|##";
		$this->default_sets_per_file = "1000";
		$this->default_setTimeLimit = "480";
		$this->data_path = "./data/";
		$this->language = "english";
		$this->mysql_databasename3 = "";
		$this->mysql_user3 = "";
		$this->mysql_password3 = "";
		$this->mysql_server3 = "";
		$this->mysql_databasename4 = "";
		$this->mysql_user4 = "";
		$this->mysql_password4 = "";
		$this->mysql_server4 = "";
		$this->mysql_databasename5 = "";
		$this->mysql_user5 = "";
		$this->mysql_password5 = "";
		$this->mysql_server5 = "";
		$this->mysql_databasename6 = "";
		$this->mysql_user6 = "";
		$this->mysql_password6 = "";
		$this->mysql_server6 = "";
	}// end func superconfig

} // end class superconfig

?>
