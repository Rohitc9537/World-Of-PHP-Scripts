<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_topstuff.php,v 1.1.1.1 2005/07/13 00:22:05 rochkind Exp $

function mrcs_page_top_head() {
	global $color_fg, $color_bg, $color_fg_btn, $color_bg_btn, $color_brdr_btn, $color_bg_body, $color_bg_btn_nav, $color_text;
	echo '<html>';
	echo '<head>';
	echo '<title>Mudbag</title>';
	echo '<style>';
	echo '<!--';
	echo 'a:link.pageheader {';
	echo '         color: ' . $color_fg;
	echo '}';
	echo 'a:visited.pageheader {';
	echo '         color: ' . $color_fg;
	echo '}';
	echo 'a:hover.pageheader {';
	echo '         color: #FF0000';
	echo '}';
	echo 'a:link.navbar {';
	echo '         color: ' . $color_bg;
	echo '}';
	echo 'a:visited.navbar {';
	echo '         color: ' . $color_bg;
	echo '}';
	echo 'a:hover.navbar {';
	echo '         color: red';
	echo '}';
	echo 'a:link.help {';
	echo '         color: ' . $color_fg;
	echo '}';
	echo 'a:visited.help {';
	echo '         color: ' . $color_fg;
	echo '}';
	echo 'a:hover.help {';
	echo '         color: red';
	echo '}';
	echo ".help_small { color: $color_fg; font-size: xx-small; }";
	echo ".sliver_small { color: $color_fg; font-size: 5px; }";
	echo 'div.navbar {';
	echo "
		margin-top: 4;
		margin-left: 0;
		margin-right: 0;
		margin-bottom: 4;
		";
	echo '         color: ' . COLOR_LIGHT_TEXT . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: 11px';
	echo '}';
	echo 'h1 {';
	echo '         color: ' . $color_fg . '; font-family: Verdana, Helvetica, Arial, sans-serif; font-size: medium';
	echo '}';
	echo 'h2 {';
	echo '         color: ' . $color_fg . '; font-family: Verdana, Helvetica, Arial, sans-serif; font-size: small';
	echo '}';
	echo 'hr {';
	echo '         color: ' . $color_bg . '; height=3';
	echo '}';
	echo 'p, td, li {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif; font-size: small';
	echo '}';
	echo '.xsmall {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif; font-size: small';
	echo '}';
	echo 'div.tinyfixed {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: 10px';
	echo '}';
	echo 'div.small {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: xx-small';
	echo '}';
	echo 'div.medium {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: small';
	echo '}';
	echo '.small {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: x-small';
	echo '}';
	echo '.medium {';
	echo '         color: ' . $color_text . '; font-family: Verdana, Helvetica, Arial, sans-serif;  font-size: medium';
	echo '}';
	echo 'div.hdg {';
	echo '         color: ' . COLOR_LIGHT_TEXT . '; font-family: "Verdana, Helvetica, Arial, sans-serif";  font-size: small';
	echo '}';
	echo <<<EOT

.arrow_button {
background-color: $color_bg_body ;
border-color: $color_brdr_btn ;
border-style: none;
border-width: 1;
color: $color_fg_btn ;
font-size: 9pt;
font-family: verdana;
font-style: normal;
margin: 0;
padding: 0;
}

.formButton {
background-color: $color_bg_btn ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: $color_fg_btn ;
font-size: 9pt;
font-family: verdana;
font-style: normal;
margin: 0;
padding: 0;
}

.toolbar_noop {
color: $color_bg ;
font-size: 9pt;
font-family: verdana;
font-style: normal;
margin: 0;
padding: 0;
}

.formButtonEmpty {
background-color: $color_fg ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: $color_fg_btn ;
font-size: 9pt;
font-family: verdana;
font-style: normal;
margin: 0;
padding: 0;
}

.formButtonMedium {
background-color: $color_bg_btn ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: $color_fg_btn ;
font-size: 7pt;
font-family: verdana;
font-style: normal;
}
.formButtonSmall {
background-color: $color_fg ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 0;
color: $color_bg ;
font-size: 7pt;
font-family: verdana;
font-style: normal;
}
.formButtonNav {
background-color: $color_bg_btn ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: $color_fg_btn ;
font-size: 7pt;
font-family: verdana;
font-style: normal;
padding: 0;
margin: 0;
}
.formButtonNavDisabled {
background-color: $color_bg ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: white ;
font-size: 7pt;
font-family: verdana;
font-style: normal;
padding: 0;
margin: 0;
}
.formButtonToolbar {
background-color: $color_bg_btn ;
border-color: $color_brdr_btn ;
border-style: default;
border-width: 1;
color: $color_fg_btn ;
font-size: 9pt;
font-family: verdana;
font-style: normal;
padding: 0;
margin: 0;
}
.button_bar_sep {
color: $color_bg ;
width: 800;
height: 3;
}
.toolbar_sep {
color: $color_fg ;
width: 100%;
height: 2;
}
.div_toolbar_sep {
margin-top: 0;
margin-left: 0;
margin-right: 0;
}
.nomargin_form {
margin: 0;
padding: 0;
}
.div_indent {
margin-left: 5%;
margin-right: 15%;
}
.div_full {
margin-left: 0;
margin-right: 0;
}
.div_toolbar {
margin-top: 4;
margin-left: 5;
margin-right: 5;
margin-bottom: 4;
}
.div_title {
margin-top: 8;
margin-left: 0;
margin-right: 0;
margin-bottom: 0;
padding: 0;
color: $color_fg ;
font-size: large;
font-family: Franklin Gothic Heavy, verdana, Helvetica, Arial, sans-serif;
font-style: normal;
text-align: left;
}
.FormHelp {
margin-top: 8;
margin-left: 0;
margin-right: 0;
margin-bottom: 0;
padding: 0;
color: $color_fg ;
font-size: small;
font-family: Verdana, Helvetica, Arial, sans-serif;
font-style: normal;
text-align: right;
}
.div_subtitle {
margin-top: 0;
margin-left: 0;
margin-right: 0;
margin-bottom: 4;
padding: 0;
color: $color_fg ;
font-size: medium;
font-family: Verdana, Helvetica, Arial, sans-serif;
font-style: normal;
font-weight: bold;
text-align: center;
}
DIV.page_bottom {
margin-top: 100;
margin-left: 0;
margin-right: 0;
margin-bottom: 0;
padding: 0;
color: $color_fg ;
font-size: xx-small;
text-align: center;
}

.NavArrow {
	font-size: 100%;
	margin-top: 0;
	padding: 0;
}

.NavLink {
	font-size: 100%;
	margin-top: 0;
	padding: 0;
	color: white;
}

.MessageError {
	color: red;
	font-size: medium;
}

.MessageErrorSmall {
	color: red;
	font-size: small;
}

.MessageConfirmation {
	color: green;
	font-size: medium;
}

.MessageConfirmationSmall {
	color: green;
	font-size: small;
}

.MessageInfo {
	font-size: medium;
}

.QueryEcho {
	color: teal;
}

.FieldLabel {
	font-size: xx-small;
	font-style: normal;
	font-weight: bold;
}

.FieldLabelReqMark {
	font-size: xx-small;
	font-style: normal
	font-weight: bold;
	color: red;
}

.InstrCell {
	font-size: small;
	font-style: normal;
}

.select1 {
	width: 300;
	font-family: Verdana, Helvetica, Arial, sans-serif;
	font-size: x-small;
	font-style: normal;
}

EOT;
	echo '-->';
	echo '</style>';
	echo '<!-- CSS Code by: www.mompswebdesign.com, -->';
?>
<script language="JavaScript">
	var dirty = false;

	function set_dirty() {
		dirty = true;
	}

	function set_clean() {
		dirty = false;
	}

	function cancel_ok() {
		if (dirty)
			return confirm("Are you sure you want to leave this page?\n\n" +
			  "Press OK to leave (and lose your changes) or Cancel to stay here.");
		return true;
	}

	var pdf_win;
	var pdf_os;

	function pdf_window(url, os) {
		pdf_os = os;
		pdf_win = window.open(url,
		'MudbagPDF', 'width=800,height=600,resizable,scrollbars');
		window.setTimeout("finish_window()", 50);
	}

	function finish_window() {
		if (pdf_os == "mac") {
			//pdf_win.document.body.innerHTML = "<p><b><font color='blue'>The PDF is being downloaded. It's not necessary to keep this window open.</font></b>";
			// Safari 2.0 shows PDF in window, so skip this message.
			//alert("An empty window may appear, which you can close at your convenience.");
		}
		pdf_win.focus();
	}

	// Use following function with input/text field.
	// onkeypress=\"return numeric_only(event);\"
	// From http://www.mredkj.com/tutorials/validate.html
	function numeric_only(e)
	{
		var key;
		var keychar;
		var reg;

		if(window.event) {
			// for IE, e.keyCode or window.event.keyCode can be used
			key = e.keyCode;
		}
		else if(e.which) {
			// netscape
			key = e.which;
		}
		else {
			// no event, so pass through
			return true;
		}
		if (key == 8) // BS
			return true;
		keychar = String.fromCharCode(key);
		reg = /\d/;
		return reg.test(keychar);
	}

	function onLoad_handler_common(frm) {
		if (frm != null && frm.elements != null && frm.elements[0])
			for (var i = 0; i < frm.elements.length; i++) {
				if ((frm.elements[i].tagName == 'TEXTAREA' || frm.elements[i].type == 'text')
				  && !frm.elements[i].disabled) {
					frm.elements[i].focus();
					break;
				}
}
	}

</script>
<?
	echo '</head>';
}
function mrcs_page_top_body($want_onload = false) {
	global $color_fg, $color_bg, $color_bg_body, $color_logo;

	// name of form (mb_form) is set in mbcl_base.php
	echo '<body topmargin="0" leftmargin="0" rightmargin="0" bgcolor="' . $color_bg_body . '"' .
	  ' onLoad="onLoad_handler_common(document.mb_form);' . ($want_onload ? 'onLoad_handler(document.mb_form);' : '') . '">';

	echo '<table border="0" width="100%"cellspacing="0" cellpadding="0">';
	echo '<tr bgcolor="' . $color_bg . '" >';
	echo '<td width="300" align="left"><!-- a href="index.shtml" --><img src="images/mudbag.gif" height="70" width"177" border="0" align="middle"><!-- /a -->';
	if (MB_BETA)
		echo "&nbsp;<font color='red'><b>BETA</b></font>";
	echo '</td>';
	echo '<td align="center">';
	if (nvl($_SESSION['MUDBAG_USER']->logged_in) == 1) {
		echo '<font color="' . $color_fg . '" size="-1">' . "Logged in as \"{$_SESSION['MUDBAG_USER']->login}\"" . '</font>';
	}
/*
	if (db_isset()) {
		echo '&nbsp;&nbsp;&nbsp;<font color="' . $color_fg . '" size="-1">Database "' . $_SESSION['APPDB']->dblongname . '"</font>';
	}
*/
	echo '</td>';
	echo '<td align="right"><small>';
	if (is_logged_in()) {
		if ($_SESSION['MUDBAG_USER']->admin) {
			$a = array('Admin', 'mb_admin.php');
			//echo "&nbsp;&nbsp;DBQ=" . nvl($_SESSION['mb_stat_db_query'], 0) . ":" . nvl($_SESSION['mb_stat_db_query_user'], 0);
		}
		else
			$a = array();
		button_bar_nav(array_merge(array('Account', 'mb_account.php', 'Logout', 'mb_login.php?mbp_logout=1', 'Contact Us', 'mailto:' . MB_EMAIL_CONTACT), $a));
//		echo '&nbsp;&nbsp;&nbsp;<a class="pageheader" href="signup.php">My Account</a>';
//		echo '&nbsp;&nbsp;&nbsp;<a class="pageheader" href="logout.php?new=0">Logout</a>';
//		if ($_SESSION['MUDBAG_USER']->login == 'admin') {
//			echo '&nbsp;&nbsp;&nbsp;<a class="pageheader" href="admin.php?new=0">Admin</a>';
//		}
	}
//	echo <<<EOT
//&nbsp;&nbsp;&nbsp;<a class="pageheader" href="mailto://mudbag@basepath.com">Email Webmaster</a></small>
	echo <<<EOT
</td><td>&nbsp;&nbsp;&nbsp;</td></tr>
</table>
<!--<table width="100%" cellspacing="0" cellpadding="0"><tr>
<td width="10%" height="2000" bgcolor="$color_bg">&nbsp;</td>
<td width="70%" valign="top">
-->
EOT;
}

function mrcs_page_top($want_onload = false) {
	mrcs_page_top_head();
	mrcs_page_top_body($want_onload);
}

function mrcs_page_heading($hdg, $subhdg = NULL) {
	global $page_hdg, $page_subhdg;

	$page_hdg = $hdg;
	$page_subhdg = $subhdg;
/*
	global $color_fg, $color_bg;

	//echo '<h1>' . $hdg . '</h1>';
	echo '<table width="100%" cellpadding="4" cellspacing="0" bgcolor="' . $color_fg . '"><tr><td align="left" width="25%">';
	echo '<div class="hdg">&nbsp;&nbsp;' . $hdg;
	if (isset($subhdg)) {
		die('do not use sub headings (common.php)');
		echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $subhdg;
		//echo '<table width="25%" cellpadding="5"><tr><td bgcolor="' . $color_fg . '" align="center">';
		//echo $subhdg . '</td></tr></table>';
	}
	//echo '<hr>';
	echo '</div></td>';
*/
/*
	echo '<td align="right">';
	if (db_isset()) {
		echo '<font color="' . $color_bg . '" size="-1">' . $_SESSION['APPDB']->dblongname . '</font>';
		echo '<font color="' . $color_bg . '">&nbsp;&nbsp;&bull;&nbsp;&nbsp;</font>';
		echo '<font color="' . $color_bg . '" size="-1">' . $_SESSION['APPDB']->get_role() . ' by</font>';
		echo '<font color="' . $color_bg . '">&nbsp;&nbsp;&bull;&nbsp;&nbsp;</font>';
	}
	if (is_logged_in()) {
		echo '<font color="' . $color_bg . '" size="-1">' . $_SESSION['MUDBAG_USER']->login . '</font>';
	}
	echo '&nbsp;&nbsp;&nbsp;</td>';
*/
/*
	echo '</tr>';
	echo '</table>';
*/
	//echo '<table cellspacing="0" cellpadding="20"><tr><td valign="top">';
}

function mrcs_page_toolbar($a = null, &$breadcrumbs, $help_ctx) {
	global $color_bg_page_toolbar, $page_hdg, $page_subhdg;

	echo '<table width="100%" cellpadding="0" cellspacing="0" bgcolor="' . $color_bg_page_toolbar . '">';
	echo '<tr><td align="left" width="50%">';
	//echo '<div class="hdg">';
/*
	if (is_logged_in()) {
		$a = array_merge($a, array('Update Account', 'signup.php', 'Logout', 'logout.php'));
		if ($_SESSION['MUDBAG_USER']->login == 'admin') {
			$a = array_merge($a, array('Admin', 'admin.php'));
			echo '&nbsp;&nbsp;&nbsp;<a class="pageheader" href="admin.php?new=0">Admin</a>';
		}
	}
*/
		//nav_bar($navloc);
		echo '<div class="div_toolbar">';
	if (isset($a)) {
		button_bar_class($a, "formButtonToolbar", false);
	}
//	else
//		echo '&nbsp;';	// makes for a very slight gain in height, but not enough to match toolbar
						// a problem when there is no toolbar, as breadcrumb bar doesn't have same height for some reason
						// Solution: use same class (div_toolbar) for both
//		echo '</div>';
//		//horz_rule();
	echo '</div>';
	echo '</td>';
	echo '<td align="left" width="50%">';
	if (isset($breadcrumbs))
		$breadcrumbs->Show();
	//nav_bar();
	echo '</td>';
	echo '</tr></table>';
	echo '<div class="div_indent">';
//	echo '<div class="div_title">';
//	echo $page_hdg;
//	echo '</div>';
//	  <tr><td>&nbsp;</td></tr>
	if (isset($page_hdg)) {
		show_page_heading($page_hdg, $help_ctx, $page_subhdg);
	}
}

function show_page_heading($page_hdg, $help_ctx, $page_subhdg = null) {
	echo "<table width='85%' border='0' cellspacing='0' cellpadding='0'><tr><td><span class='sliver_small'>&nbsp;</span></td></tr><tr>";
	echo "<td valign='middle'>";
	echo "<span class='div_title' height='40' valign='bottom'>$page_hdg</span>";
	echo "</td>";
	HelpExistenceTrack($help_ctx);
	echo <<<EOT
		<script language="JavaScript">

		var mb_help_ctx = '$help_ctx';

		</script>
EOT;
	if (!empty($help_ctx))
		echo "<td align='right' valign='middle'><a href='javascript:help_window(mb_help_ctx)' class='help'>Help</a><span class='help_small'> (on this page)</span></td>";
	echo "</tr></table>";
	if (!empty($page_subhdg)) {
		echo '<div class="div_subtitle">';
		echo $page_subhdg;
		echo '</div>';
	}
}


function horz_rule() {
	echo '<div class="div_toolbar_sep">';
	echo '<hr align=left class="toolbar_sep">';
	echo '</div>';
}

function nav_button($s, $url = NULL, $arrow = true) {
	global $color_bg;

	if ($arrow)
		echo '&nbsp;<span class="NavArrow">&gt;</span>&nbsp;'; // was rarr;
	if (isset($url))
		//button_bar(array($s, $url), false); // was button_bar_nav, but we want it bigger
		echo "<font color=\"$color_bg\"><a href='$url' class='navbar' onclick='return cancel_ok();'>$s</a></font>"; // dirty check
	else
		echo "<font color=\"$color_bg\">$s</font>";
		//button_bar_nav_disabled(array($s, $url));
/*
	if ($url)
		text_medium('&nbsp;&nbsp;&nbsp;&nbsp;<a class="navbar" href="' . $url . '">' . $s . '</a>');
	else
		text_medium('&nbsp;&nbsp;&nbsp;&nbsp;' . $s);
*/
}

//function nav_bar() {
//	if (!is_logged_in()) {
//		echo "<p>Not logged in.";
//		return;
//	}
//	echo '<div  class="navbar">';
//	if (preg_match('/mb_dbmain.php$/', $_SERVER['SCRIPT_FILENAME']))
//		nav_button('Home', NULL, false);
//	else {
//		nav_button('Home', 'mb_dbmain.php', false);
//		if (preg_match('/mb_dbmain.php$/', $_SERVER['SCRIPT_FILENAME']))
//			nav_button('Database: ' . $_SESSION['APPDB']->dblongname);
//		else if (db_isset($_SESSION['APPDB'])) {
//			nav_button('Database: ' . $_SESSION['APPDB']->dblongname, 'mb_dbmain.php');
//			if (preg_match('/mb_dbtable.php$/', $_SERVER['SCRIPT_FILENAME'])) {
//				if (isset($_SESSION[active_view_obj]) && isset($_SESSION[active_view_obj]->name))
//					nav_button('View: ' . $_SESSION[active_view_obj]->name);
//				else
//					nav_button('Table: ' . $_SESSION['db_table']);
//			}
//			else if (isset($_SESSION['db_table'])) {
//				nav_button('Table: ' . $_SESSION['db_table'], 'mb_dbtable.php');
//				if (isset($_SESSION['active_field'])) {
//					if (preg_match('/mb_dbfield.php$/', $_SERVER['SCRIPT_FILENAME']))
//						nav_button('Field: ' . $_SESSION['active_field']);
//					else
//						nav_button('Field: ' . $_SESSION['active_field'], 'mb_dbfield.php');
//				}
//				else if (isset($_SESSION['active_rownum'])) {
//					if (preg_match('/mb_dbtable_row.php$/', $_SERVER['SCRIPT_FILENAME']))
//						nav_button('Record');
//					else
//						nav_button('Record', 'mb_dbtable_row.php');
//				}
//				else if (isset($_SESSION[active_view_obj])) {
//					if (preg_match('/mb_dbview_addedit.php$/', $_SERVER['SCRIPT_FILENAME']))
//						if (isset($_SESSION[active_view_obj]->name))
//							nav_button('View: ' . $_SESSION[active_view_obj]->name);
//						else
//							nav_button('Add View');
//					else
//						nav_button('View: ' . $_SESSION[active_view_obj]->name, 'mb_dbtable.php');
//				}
//			}
//			else if (isset($_SESSION['managing_users'])) {
//				if (preg_match('/mb_mng_users.php$/', $_SERVER['SCRIPT_FILENAME']))
//					nav_button('Manage Users');
//				else
//					nav_button('Manage Users', 'mb_mng_users.php');
//			}
//		}
//	}
//	echo '</div>';
///*
//	if (isset($_SESSION['APPDB'])) {
//		$a[] = 'Database: ' . $_SESSION['APPDB']->dblongname;
//		$a[] = 'db_main.php';
//	if (isset($_SESSION['active_field'])) {
//		$a[] = 'Field: ' . $_SESSION['active_field'];
//		$a[] = 'db_field.php';
//	}
//	}
//	if (isset($_SESSION['active_field'])) {
//		$row_type = 'Field: ' . $_SESSION['active_field'];
//		$row_link = '';
//	}
//	else 'Table: ' . $_SESSION['active_table']
//*/
////	button_bar($a);
//		//echo "---------$navloc-----------";
//}

function mrcs_page_bottom() {
	global $color_fg, $color_bg;

	echo '</div>';
	echo '<div class="page_bottom">';
	horz_rule();
	//echo '</td></tr></table>';
	//echo '<td height="2000" bgcolorx="' . $color_bg . '">&nbsp;</td>';
	//echo '</tr></table>';
	echo 'Mudbag is a trademark of Basepath Associates.';
	echo '<br>Screens and source code &copy;2003-2005 by Basepath Associates. All rights reserved.';
	echo '</div></body></html>';
}


function show_button($label, $page) {
	echo <<<EOT
<form action="$page" method="POST"><input type="submit" value="$label"></form>
EOT;
}

function button_bar_class($a, $cls, $want_form = false, $disabled = false) {
//echo "<input type='submit' value='a'><input type='submit' value='a'>";
	if ($want_form)
		echo '<form class="nomargin_form">'; // some browsers might require buttons to be in forms
	$n = count($a);
	for ($i = 0; $i < $n; $i += 2) {
		if ($i > 0)
			echo '&nbsp;&nbsp;';
		echo '<input type="submit"';
		if ($disabled)
			echo ' disabled';
		else if ($a[$i]{0} == '^') {
			echo ' disabled';
			$a[$i] = substr($a[$i], 1);
			//echo "<span class='toolbar_noop'>" . substr($a[$i], 1) . "</span>";
			//continue;
		}
		if (strlen($a[$i + 1]) > 0)
			if ($a[$i + 1]{0} == '!')
				echo ' ' . substr($a[$i + 1], 1);
			else
				echo " onClick=\"if (cancel_ok()) window.location = '" . $a[$i + 1] . "'; return false;\"";
		echo ' class="' . $cls . '"';
		echo " value='$a[$i]'>";
	}
	if ($want_form)
		echo '</form>';
echo "\r\n";
}

function button_bar($a, $want_form = true) {
	button_bar_class($a, "formButton", $want_form);
}

function button_bar_medium($a, $want_form = true) {
	button_bar_class($a, "formButtonMedium", $want_form);
}

function button_bar_small($a, $want_form = true) {
	button_bar_class($a, "formButtonSmall", $want_form);
}

function button_bar_nav($a) {
	button_bar_class($a, "formButtonNav", false);
}

function button_bar_nav_disabled($a) {
	button_bar_class($a, "formButtonNavDisabled", false, true);
}

function button_bar_sep() {
	echo '<hr align=left class="button_bar_sep">';
}

?>
