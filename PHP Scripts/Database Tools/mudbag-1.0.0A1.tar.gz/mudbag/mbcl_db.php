<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_db.php,v 1.1.1.1 2005/07/13 00:22:06 rochkind Exp $

/*
	Handles low-level interaction with both main and application (user) databases. Addition application database
	stuff in mbcl_dbapp.php.
*/
	require('mb_config.php');
	require('mbcl_table.php');

class MB_DB {

	var $connection;

	function MB_DB() {
		$this->db_connect();
	}

	function db_connect($cond = 0, $select = 1) {
		//logger('', 'db_connect');
		$db_host = MB_HOST;
		$db_user = MB_USER;//"mudbag";
		$db_pass = MB_PASSWORD;//"riverside";//"GlenMay9981";
		$this->connection = @mysql_connect($db_host, $db_user, $db_pass);
		if ($this->connection && $select) {
			if (!@mysql_select_db(MB_DATABASE, $this->connection)) {
				echo "<p>Able to connect to My SQL (host, user, and password are OK), but not to database.";
				echo "<br>MySQL error: " . mysql_error() . " [" . mysql_errno() . "]";
				echo "<p>Make sure the parameters in setup.php are correct and that the MySQL server is running.";
				echo "<br>If the database does not yet exist, you must run install.php.";
				exit;
			}
		}
		else if (!$cond) {
			echo "<p>Unable to connect to My SQL (host, user, and/or password are wrong).";
			echo "<br>MySQL error: " . mysql_error() . " [" . mysql_errno() . "]";
			switch ($errnum = mysql_errno()) {
			case 1045:
				echo "<p>The user and/or password are probably wrong (the host is OK). Please correct them in setup.php.";
				break;
			case 2005:
				echo "<p>The host \"" . MB_HOST . "\" is probably wrong. Please correct it in setup.php.";
				break;
			case 2002:
				echo "<p>You have the host as \"localhost\", but it's probably wrong. Please correct it in setup.php.";
				break;
			default:
				; // Not sure what else to say.
			}
			exit;
		}
		return $this->connection;
	}

	function db_connect_user() {
return $this->connection;
		logger($_SESSION['MUDBAG_USER']->get_mysql_user(), 'db_connect_user');
		$connection = mysql_connect("localhost", $_SESSION['MUDBAG_USER']->get_mysql_user(), $_SESSION['MUDBAG_USER']->password)
		  or die("Unable to connect: " . $_SESSION['MUDBAG_USER']->password . mysql_error());
		if ($_SESSION['APPDB']->dbname != NULL) {
			mysql_select_db($_SESSION['APPDB']->dbname, $connection)
			  or die("Unable to select database [db_connect_user]: " . mysql_error());
		}
		return $connection;
	}

	// All calls to mysql_query come here.
	function db_query_ext($q, $connect, $cond = false) {
		global $want_db_query_echo;

		if ($want_db_query_echo)
			// user font instead of span (with class) because class definitions may not be loaded
			echo "<p><font color=\"teal\">" . htmlspecialchars($q) . "</font><p>";
		if (empty($connect))
			die("Unable to connect to Mudbag database (mbcl_db.php.db_query_ext); click <a target='_blank' href='help/err_connection.html'>here</a> for help.");
		$result = @mysql_query($q, $connect);
		if (!$result) {
			if ($cond)
				return $result;
			else
				die ("Error in query: $q. " . mysql_error() . " (" . mysql_errno() . ")" . "<p><b>fix MB_DB.db_query_ext to put this message in a queue</b>");
		}
		if (substr($q, 0, 6) == 'insert') {
			return mysql_insert_id(); // returns 0 if no auto-increment column; use "=== false" to test return value
}
		return $result;
	}

	function db_query($q, $cond = false) {
		//logger($q, 'db_query');
		// Funny business with nvl() is because we may not have a session.
		$_SESSION['mb_stat_db_query'] = nvl($_SESSION['mb_stat_db_query'], 0) + 1;
		return $this->db_query_ext($q, $this->connection, $cond);
	}

	function db_query_user($q, $cond = false) {
		//logger($q, 'db_query_user');
		// Funny business with nvl() is because we may not have a session.
		$_SESSION['mb_stat_db_query_user'] = nvl($_SESSION['mb_stat_db_query_user'], 0) + 1;
		return $this->db_query_ext($q, $this->connection, $cond);
//		return $this->db_query_ext($q, $this->db_connect_user(), $cond);
	}

	function db_query_show($title, $sql, $limit = 0, $link_col = '', $url = '', $fcn = null) {
		$this->db_query_show_ext($title, $sql, $this->connection, $limit, $link_col, $url, $fcn);
	}

	function db_query_user_show($title, $sql) {
		$this->db_query_show_ext($title, $sql, $this->connection);
//		$this->db_query_show_ext($title, $sql, $this->db_connect_user());
	}

	function db_query_show_ext($title, $sql, $connect, $limit = 0, $link_col = '', $url = '', $fcn = null) {
		$link_col = strtolower($link_col);
		if (!empty($title))
			echo "<h2>$title</h2>";
		$stmt = $this->db_query_ext($sql, $connect);
		if (mysql_numrows($stmt) == 0) {
			echo "&nbsp;&nbsp;&nbsp;&nbsp;<i>None</i>";
			return;
		}
		$tbl = new MB_Table();
		$tbl->Begin();
		$first = true;
		for ($count = 1; $row = mysql_fetch_assoc($stmt); $count++) {
			if ($limit != 0 && $count > $limit)
				break;
			if ($first) {
				$first = false;
				foreach ($row as $k => $v)
					$tbl->ColHdg($k);
				$tbl->Body();
			}
			echo "<tr>";
			foreach ($row as $k => $v) {
				if (!isset($v) || strlen($v) == 0)
					$v = '&nbsp;';
				if (strtolower($k) == $link_col)
					echo "<td><a href='$url?$link_col=$v'>$v</a></td>";
				else
					echo "<td>$v</td>";
			}
			echo "</tr>";
			if (isset($fcn)) {
				echo "<tr><td valign='top' colspan='" . count($row) . "'>";
				$fcn($this, $row);
				echo "</td></tr>";
			}
		}
		$tbl->End();
	}

	function db_query_single($sql) {
		$row = mysql_fetch_row($this->db_query($sql));
		return $row[0];
	}

	function db_run_file($file, $echo = false, $cond = false)
	{
		$f = fopen($file, 'r');
		$stmt = "";
		while ($s = fgets($f)) {
			$s = trim($s);
			if (($cp = strpos($s, "--")) !== false)
				$s = substr($s, 0, $cp);
			if (strlen($s) == 0)
				continue;
			$stmt .= $s;
			if (strstr($s, ";")) {
				if ($echo)
					echo "<br><font color='blue'>$stmt</font>";
				if (!$this->db_query($stmt, $cond))
					return false;
				$stmt = "";
			}
		}
		return true;
	}

	function db_run_file_user($file, $table = null)
	{
		$f = fopen($file, 'r');
		$stmt = '';
		while ($s = fgets($f)) {
			$s = trim($s);
			if (substr($s, 0, 2) == '--' || strlen($s) == 0)
				continue;
			$stmt = $stmt . $s;
			if (strstr($s, ";")) {
				//echo '<br>' . $stmt;
				if (isset($table))
					$stmt = str_replace("{TABLE}", $table, $stmt);
				$this->db_query_user($stmt);
				$stmt = "";
			}
		}
	}
	
	function db_log($code, $msg) {
		$this->db_query("insert into mb_log(code, msg) values('$code', '" . mysql_escape_string($msg) . "')");
		$this->db_query("commit");
	}

	function grant_owner_privileges($user_dbname) {
		return true; // We don't do this anymore.
//		logger($user_dbname, 'grant_owner_privileges');
//		$mysql_user = $_SESSION['MUDBAG_USER']->get_mysql_user();
//		$result = $this->db_query("select user from mysql.user where user = '" .
//		  $mysql_user . "'");
//		if (mysql_num_rows($result) > 1) {
//			logger("Duplicated MySQL user $mysql_user", 'ERROR MB_DB.grant_owner_privileges');
//			return false;
//		}
//		$this->db_query("grant all privileges on $user_dbname.* to '" .
//		  $_SESSION['MUDBAG_USER']->get_mysql_user() . "'@'localhost'
//		  identified by '{$_SESSION['MUDBAG_USER']->password}'");
//		return true;
	}

	function grant_nonowner_privileges($login, $role_id, $transact, &$errnum, &$errmsg) {
		return true; // We don't do this anymore.
//		$errnum = null;
//		$db = $_SESSION['APPDB']->dbmain;
//
//		switch ($role_id) {
//		case 0:
//			$priv = '[none]'; // not something passed to SQL
//		case ROLE_SEE:
//			$priv = 'SELECT';
//			break;
//		case ROLE_EDIT:
//			$priv = 'SELECT, INSERT, UPDATE, DELETE';
//			break;
//		default:
//			die('grant_nonowner_privileges -- bad role_id: ' . $role_id);
//		}
//		if ($transact)
//			$db->db_query("begin");
//		$r = $db->db_query(sprintf('revoke all on %s.* from "%s"@"localhost"',
//		  $_SESSION['APPDB']->dbname, get_mysql_user_from_login($login)), true);
//		if ($r || mysql_errno() == 1141 /* nothing to revoke */) {
//			if ($role_id > 0)
//				$r = $db->db_query(sprintf('grant %s on %s.* to "%s"@"localhost"',
//				  $priv, $_SESSION['APPDB']->dbname, get_mysql_user_from_login($login)), true);
//		}
//		if ($r) {
//			if ($transact)
//				$db->query("commit");
//			return true;
//		}
//		else {
//			$errnum = mysql_errno();
//			$errmsg = mysql_error();
//			if ($transact)
//				$db->query("rollback");
//			return false;
//		}
	}
}

class MB_DBScreen extends MB_BaseScreen {

	var $dbmain;
	var $dbapp;

	function MB_DBScreen() {
		parent::MB_BaseScreen(); // this gets us access to the session

		// If an MB_AppDB is set, take the main DB from there.
		if (db_isset()) {
			$this->dbapp = &$_SESSION['APPDB'];
			$this->dbmain = &$this->dbapp->dbmain;
			$this->dbmain->db_connect();
		}
		else {
			$this->dbmain = new MB_DB();
			unset($this->dbapp);
		}
// We now run OK without.
//		if (!isset($_SESSION['innodb_checked'])) {
//			$_SESSION['innodb_checked'] = true;
//			$row = mysql_fetch_assoc($this->dbmain->db_query("show variables like 'have_innodb'"));
//			if ($row['Value'] != "YES")
//				echo "<p><h1>WARNING: Mudbag requires MySQL with InnoDB support.</h1><p>";
//		}
	}

	function AddDBMessage() {
		switch (mysql_errno()) {
		case 1050:
			$m = "Table already exists. Please choose another name.";
			break;
		default:
			$m = "[MySQL: " . mysql_error() . "]";
		}
		$this->AddMessageError($m);
	}

	function QueryAddMessageUser($sql) {
		if ($r = $this->dbmain->db_query_user($sql, true))
			return $r;
		$this->AddDBMessage();
		return false;
	}

	function QueryAddMessage($sql) {
		if ($r = $this->dbmain->db_query($sql, true))
			return $r;
		$this->AddDBMessage();
		return false;
	}
}

?>
