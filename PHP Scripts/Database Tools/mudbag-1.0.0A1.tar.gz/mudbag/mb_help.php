<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_help.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

	extract($_GET);
	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_browser_check.php");

//	echo "<h1>Help not yet available.</h1>";
//	echo "<p>The stuff below is for development purposes.<p>";
//	echo "<h2>Help for context \"$context\"</h2>";
	if (empty($context))
		$context = "helpctx_TOC";

	$db = new MB_DB();

	$db->db_query("begin");
	$result = $db->db_query("select data1 from mb_param where tag = '$context'", true);
	if (!$result) {
		if (mysql_errno() == 1146) {
			echo "<p>Table mb_param does not exist. Are you sure Mudbag has been installed by running install.php?";
			exit;
		}
		else
			exit("MySQL error: " . mysql_error() . " [" . mysql_errno() . "]");
	}
	$row = mysql_fetch_row($result);
	if (empty($row[0]))
		$db->db_query("insert into mb_param (tag, data1) values('$context', 1)");
	else
		$db->db_query("update mb_param set data1 = " . ((int)$row[0] + 1) . " where tag = '$context'");
	$db->db_query("commit");

	switch ($context) {
	case "helpctx_mb_login~lnk_browser":
		HelpExistenceTrack("helpctx_mb_login~lnk_browser", true);
		echo <<<EOT
			<html>
			<head>
			<title>Mudbag Help</title>
			</head>
			<body>
			<img src="images/mudbag.gif"><p>
EOT;
		BrowserMsg();
		echo <<<EOT
			</body>
			</html>
EOT;
		break;
	default:
		header("Location: help/$context.php?homeonly=1");
	}

//	$db->db_query_show("", "select * from mb_param order by tag");
?>
