<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>main</title>
<link rel="stylesheet" type="text/css" href="mudbag_help.css">
<meta name="Microsoft Border" content="tb, default">
</head>

<body><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td>

<p>

<img border="0" src="images/mudbag-help.gif" width="150" height="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>
<p align="left" style="margin-top: 0; margin-bottom:0">
<font size="6" face="Arial" color="#464B73"><strong>
</strong></font></p>
<hr>

</td></tr><!--msnavigation--></table><!--msnavigation--><table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%"><tr><!--msnavigation--><td valign="top">

<p>main</p>

<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Getting Started With Mudbag</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/aboutmudbaghelp.html" target="stuff">
    About Mudbag Help</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/browsers.html" target="stuff">Browsers 
    That Work With Mudbag</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Your Account</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_register.html" target="stuff">
    Registering and Changing Account Information</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_login~main.html" target="stuff">
    Logging In</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_login~forgot.html" target="stuff">
    Forgotten Passwords</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_account~main.html" target="stuff">
    Viewing and Changing Account Information</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_account~plan_edit.html" target="stuff">
    Selecting a Plan</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_account~plan_change.html" target="stuff">
    Changing Your Plan</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_account~plan_pay.html" target="stuff">
    Paying with PayPal</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Databases</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbmain.html" target="stuff">
    Main Database Page</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbadd.html" target="stuff">
    Adding a Database</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbobj_delete~database.html" target="stuff">
    Deleting/Renaming a Database</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Tables</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_add.html" target="stuff">
    Adding a Table</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbfield~lnk_field_types.html" target="stuff">
    Field Types</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbobj_delete~table.html" target="stuff">
    Deleting/Renaming a Table</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable~edit.html" target="stuff">
    Seeing a Table's Design</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbfield.html" target="stuff">
    Adding/Changing Fields</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_reorder.html" target="stuff">
    Reordering Fields</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable~view.html" target="stuff">
    Seeing Table/View Data</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_row.html" target="stuff">
    Adding/Editing a Record</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/deletingarecord.html" target="stuff">
    Deleting a Record</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Views</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbview_addedit~lnk_intro.html" target="stuff">
    About Views</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbview_addedit.html" target="stuff">
    Adding/Changing a View</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbview_addedit~lnk_filter.html" target="stuff">
    About Filters</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbobj_delete~view.html" target="stuff">
    Deleting a View</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Reports</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report.html" target="stuff">
    Types of Reports</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~lnk_report_spec.html" target="stuff">
    Saving Report Specifications</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~tabular.html" target="stuff">
    Tabular Reports</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~record.html" target="stuff">
    Record Reports</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~label.html" target="stuff">
    Label Reports</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~email.html" target="stuff">
    Email Reports</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/changingrenamingareport.html" target="stuff">
    Changing/Renaming a Report</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbobj_delete~report.html" target="stuff">
    Deleting a Report</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Import</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~lnk_import_spec.html" target="stuff">
    Import Specifications</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~lnk_csv.html" target="stuff">
    CSV Format</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~step1.html" target="stuff">
    Step 1: Choose File to Be Imported</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~step2.html" target="stuff">
    Step 2: Specify File Layout</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~step3.html" target="stuff">
    Step 3: Specify Table Fields</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~step4.html" target="stuff">
    Step 4: Verify Import Specification</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_import~step5.html" target="stuff">
    Step 5: Perform Import</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Export</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_dbtable_export.html" target="stuff">
    Exporting a Table or View</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Users</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users~main.html" target="stuff">
    Managing Users</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users_invite~mainform.html" target="stuff">
    Adding Users By Invitation</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users_invite~getform.html" target="stuff">
    Getting Email Addresses</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users_invite~showlist.html" target="stuff">
    Reviewing Invitations</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users_login.html" target="stuff">
    Adding Users By Login</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users~btn_send.html" target="stuff">
    Sending Emails To Users</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users~btn_revoke.html" target="stuff">
    Revoking Users' Access</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_mng_users~btn_roles.html" target="stuff">
    Changing Users' Roles</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="20">
    <img src="http://gentoo/mudbag/help/icon1.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">Troubleshooting</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/err_connection.html" target="stuff">
    Connection Problems</a></font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2">
  <tr>
    <td align="right" valign="top" width="40">
    <img src="http://gentoo/mudbag/help/icon2.gif" border="0" width="16" height="16"></td>
    <td align="left"><font face="Arial" size="2">
    <a href="http://gentoo/mudbag/help/helpctx_mb_report~lnk_no_pdf.html" target="stuff">
    PDFs Don't Appear</a></font></td>
  </tr>
</table>

<!--msnavigation--></td></tr><!--msnavigation--></table><!--msnavigation--><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td>

<p align="center">&nbsp;</p>
<hr>
<p align="center"><font size="1">Mudbag is a trademark of Basepath Associates.<br>
Screens and source code �2003-2005 by Basepath Associates. All rights reserved.</font></p>

</td></tr><!--msnavigation--></table></body>

</html>