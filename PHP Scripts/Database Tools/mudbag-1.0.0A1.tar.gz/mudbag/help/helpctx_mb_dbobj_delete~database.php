<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Renaming a Database<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Renaming a Database<!-- TITLE END --></h1>
<!-- BODY START -->
<p>You access the Delete/Rename Database screen from the
<a href="helpctx_mb_dbmain.php">Mudbag Home</a> page.</p>
<p>To delete a database, you type the word &quot;yes&quot; in the Confirm field and press 
the button next to it. This is a safety precaution, because deleting a database 
destroys all the tables, views, and reports in it.</p>
<p>To rename a database, type the new name into the <i>New Name</i> field and 
press the button next to it.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>