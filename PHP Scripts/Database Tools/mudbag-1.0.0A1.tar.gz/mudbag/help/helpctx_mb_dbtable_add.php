<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Adding a Table<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Adding a Table<!-- TITLE END --></h1>
<!-- BODY START -->
<p align="left">If you're not familiar with Mudbag tables, read about Mudbag's
<a href="basic_concepts.php">Basic Concepts</a> before continuing. You access 
the Add Table screen from the <a href="helpctx_mb_dbmain.php">Mudbag Home</a> 
page.</p>
<p align="left">All you have to do is give the new table a name and press the 
button. You'll define fields for the new table as a separate step.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
