<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Paying with PayPal<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Paying with PayPal<!-- TITLE END --></h1>
<!-- BODY START -->
<p>After you've paid with PayPal, Mudbag is normally notified within a minute or 
so, and it automatically updates your account. You can review your account 
information to verify that payment has been received. Sometimes there's a delay, 
so you should wait at least 10 minutes before contacting <a href="support.php">
Mudbag support</a> about any problems that you think may have occurred.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
