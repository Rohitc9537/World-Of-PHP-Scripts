<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Registering and Changing Personal Information</title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;Registering
and Changing Personal Information</h1>
<p>When you first register or when you want to change your
personal information, you'll be shown a form where you'll enter or
change your name, address, email, and so on.</p>
<p>When you first register, you have to supply a unique user ID
(Mudbag will tell you if it's not unique) and password. Also, you may
see a field where you can name your initial database. (If no such field
is present, you can still create a database after you've logged in.)</p>
<p>If you're changing your personal information, your login can't
be changed. Type a new password (twice) if you want to change it;
otherwise, leave the password fields blank.</p>
<script language="php">require("mbbot.php");</script>
</body>
</html>
