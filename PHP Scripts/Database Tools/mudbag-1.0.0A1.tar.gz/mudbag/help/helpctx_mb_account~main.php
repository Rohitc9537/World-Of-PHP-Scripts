<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Viewing Account Information</title>
  <meta name="generator" content="Microsoft FrontPage 5.0">
  <meta name="keywords" content="">
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <meta name="Microsoft Border" content="tb, default">
</head>
<body>
<script language="PHP">require "mbtoc.php";</script>
<h1>&nbsp;Viewing
Account Information</h1>
<p>To see your account information, press the <i>Account</i>
button at the top of the screen. You'll see:</p>
<ul>
  <li>Your personal information that was entered when you
registered. Press the <i>Change Info</i> button to make changes.</li>
  <li>Details of your payment plan (or free account) and it's
limits. Press the <i>Renew or Change Plan</i> button to change your
plan or to make another payment.</li>
  <li>A summary of your recent payments, if any.</li>
</ul>
<h2>See Also</h2>
<p><a href="helpctx_mb_register.php">Registering and Changing Personal Information</a>
<br><a href="helpctx_mb_account~plan_edit.php">Selecting a Plan</a>
<br><a href="helpctx_mb_account~plan_change.php">Changing Your Plan</a>
<script language="PHP">require "mbbot.php";</script>
</body>
</html>
