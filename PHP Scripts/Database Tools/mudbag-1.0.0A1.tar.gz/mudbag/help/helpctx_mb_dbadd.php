<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Adding a Database<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Adding a Database<!-- TITLE END --></h1>
<!-- BODY START -->
<p>If you're not familiar with Mudbag databases, read about Mudbag's
<a href="basic_concepts.php">Basic Concepts</a> before continuing. You access 
the Add Database screen from the <a href="helpctx_mb_dbmain.php">Mudbag Home</a> 
page.</p>
<p>To add a new database, give it a name that's unique among the databases you 
own. (Other users' databases don't matter.)</p>
<p>If you want some sample tables (e.g., Mountains) added to the new database, 
check the box.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
