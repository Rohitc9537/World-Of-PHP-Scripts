<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Help End<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Help End<!-- TITLE END --></h1>
<!-- BODY START -->
<p>This is the end of Mudbag help. Click the Home link above to return to the beginning.
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
