<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Changing Your Plan<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Changing Your Plan<!-- TITLE END --></h1>
<!-- BODY START -->
<p>When you press the <i>Choose</i> button to choose a plan, you're taken to the 
&quot;New Plan&quot; screen so you can choose whether you want to pay monthly or yearly. 
If you're upgrading or downgrading from another plan, you'll also be told how 
much credit you'll get for payments you've already made.</p>
<p>Press the <i>Make Payment</i> button to go to a PayPal window for the actual 
payment. Once you've done that, Mudbag will be notified of your payment and will 
update your account appropriately.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>