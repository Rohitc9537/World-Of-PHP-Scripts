<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Forgotten Passwords</title>
  <meta name="generator" content="Microsoft FrontPage 5.0">
  <meta name="keywords" content="">
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <meta name="Microsoft Border" content="tb, default">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;Forgotten Passwords</h1>
<p align="left">If you're registered but you can't remember your
password, instructions for resetting your password will be emailed to
you. Enter your login and the same email address you entered when you
registered or last changed your personal information.</p>
<p align="left">When you respond the the email, you'll see a form
for you to enter your new password. Follow the instructions on that
form and then login with your new password.</p>
<p align="left">If you have any problems, you can <a href="support.php">contact</a>
Mudbag support directly.</p>
<script language="php">require("mbbot.php");</script>
</body>
</html>
