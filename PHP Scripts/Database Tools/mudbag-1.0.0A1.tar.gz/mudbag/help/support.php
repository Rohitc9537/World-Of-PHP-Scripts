<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type"
 content="text/html; charset=windows-1252">
  <title>Support</title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;Support</h1>
<p>If you have a problem you can't solve with Mudbag's help
pages, send email to:</p>
<p><a href="mailto:support@mudbag.com">support@mudbag.com</a></p>
<script language="php">require("mbbot.php");</script>
</body>
</html>
