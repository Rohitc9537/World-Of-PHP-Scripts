<?php
$mainpage = "aboutmudbaghelp.php";

$toc = array(
"!h1-Getting Started",
"aboutmudbaghelp.php" => "About Mudbag Help",
"basic_concepts.php" => "Basic Concepts",
"terms.php" => "Terms, Conditions, and Warranty",
"browsers.php" => "Browsers That Work With Mudbag",
"support.php" => "Support",
"!h1-Your Account",
"helpctx_mb_account~main.php" => "Viewing  Account Information",
"helpctx_mb_register.php" => "Registering and Changing Personal Information",
"helpctx_mb_login~main.php" => "Logging In",
"helpctx_mb_login~forgot.php" => "Forgotten Passwords",
"helpctx_mb_account~plan_edit.php" => "Selecting a Plan",
"helpctx_mb_account~plan_change.php" => "Changing Your Plan",
"helpctx_mb_account~plan_pay.php" => "Paying with PayPal",
"!h1-Databases",
"helpctx_mb_dbmain.php" => "Mudbag Home",
"helpctx_mb_dbadd.php" => "Adding a Database",
"helpctx_mb_dbobj_delete~database.php" => "Deleting/Renaming a Database",
"!h1-Tables",
"helpctx_mb_dbtable_add.php" => "Adding a Table",
"helpctx_mb_dbobj_delete~table.php" => "Deleting/Renaming a Table",
"helpctx_mb_dbtable~edit.php" => "Seeing a Table's Design",
"helpctx_mb_dbfield~lnk_field_types.php" => "Field Types",
"helpctx_mb_dbfield.php" => "Adding/Changing Fields",
"helpctx_mb_dbtable_reorder.php" => "Reordering Fields",
"helpctx_mb_dbtable~view.php" => "Seeing Table/View Data",
"helpctx_mb_dbtable_row.php" => "Adding/Editing a Record",
"deletingarecord.php" => "Deleting a Record",
"!h1-Views",
"helpctx_mb_dbview_addedit~lnk_intro.php" => "About Views",
"helpctx_mb_dbview_addedit.php" => "Adding/Changing a View",
"helpctx_mb_dbview_addedit~lnk_filter.php" => "About Filters",
"helpctx_mb_dbobj_delete~view.php" => "Deleting a View",
"!h1-Reports",
"helpctx_mb_report.php" => "Types of Reports",
"helpctx_mb_report~lnk_report_spec.php" => "Saving Report Specifications",
"helpctx_mb_report~tabular.php" => "Tabular Reports",
"helpctx_mb_report~record.php" => "Record Reports",
"helpctx_mb_report~label.php" => "Label Reports",
"helpctx_mb_report~email.php" => "Email Reports",
"changingrenamingareport.php" => "Changing/Renaming a Report",
"helpctx_mb_dbobj_delete~report.php" => "Deleting a Report",
"!h1-Import",
"about_importing.php" => "About Importing",
"helpctx_mb_dbtable_import~lnk_import_spec.php" => "Import Specifications",
"helpctx_mb_dbtable_import~lnk_csv.php" => "CSV Format",
"helpctx_mb_dbtable_import~step1.php" => "Step 1: Choose File to Be Imported",
"helpctx_mb_dbtable_import~step2.php" => "Step 2: Specify File Layout",
"helpctx_mb_dbtable_import~step3.php" => "Step 3: Specify Table Fields",
"helpctx_mb_dbtable_import~step4.php" => "Step 4: Verify Import Specification",
"helpctx_mb_dbtable_import~step5.php" => "Step 5: Perform Import",
"!h1-Export",
"helpctx_mb_dbtable_export.php" => "Exporting a Table or View",
"!h1-Users",
"helpctx_mb_mng_users~main.php" => "Managing Users",
"helpctx_mb_mng_users_invite~mainform.php" => "Adding Users By Invitation",
"helpctx_mb_mng_users_invite~getform.php" => "Getting Email Addresses",
"helpctx_mb_mng_users_invite~showlist.php" => "Reviewing Invitations",
"helpctx_mb_mng_users_login.php" => "Adding Users By Login",
"helpctx_mb_mng_users~btn_send.php" => "Sending Emails To Users",
"helpctx_mb_mng_users~btn_revoke.php" => "Revoking Users' Access",
"helpctx_mb_mng_users~btn_roles.php" => "Changing Users' Roles",
"!h1-Troubleshooting",
"err_connection.php" => "Connection Problems",
"helpctx_mb_report~lnk_no_pdf.php" => "PDFs Don't Appear",
"help_end_placeholder.php" => null
);

if ($_REQUEST['main']) {
	header("Location: $mainpage");
}
else if ($_REQUEST['toc']) {
	echo "<body style='background-color:#ECECFF;'>";
	echo "<p style='font-family:Arial;margin-left:0;margin-top:0;margin-bottom:0;text-indent:0;color:#0000CC'><b>" .
	  "Table of Contents</b>";
	echo "<small>";
	$first = true;
	foreach ($toc as $file => $hdg) {
		if ($hdg == null)
			continue;
		if (substr($hdg, 0, 4) == "!h1-") {
			if ($first)
				$first = false;
			else
				;//echo "</ul>";
			echo "<p style='font-family:Arial;margin-left:0;margin-top:4;margin-bottom:0;text-indent:0;color:white;background-color:#7A81AF'>&nbsp;" .
			  substr($hdg, 4) . "";
			//echo "<ul style='font-family:Arial;margin-left:0;margin-top:0;margin-bottom:0;text-indent:0'>";
		}
		else
			echo "<p style='margin-left:10;margin-top:0;margin-bottom:0;text-indent:-10;font-size:smaller'><a target='mbhelp_frame_right' href='$file'>$hdg</a>";
	}
	//echo "</ul>";
	echo "</small>";
	echo "</body>";
}
else {
	$f = $_SERVER['SCRIPT_NAME'];
	if (($slash = strrpos($f, '/')) === false)
		$slash = -1;
	$filename = substr($f, $slash + 1);
	if (isset($_REQUEST['dir'])) {
//var_dump($_REQUEST);
		$cur = $_REQUEST['cur'];
		switch ($dir = $_REQUEST['dir']) {
		case "prev":
		case "next":
			$file_prev = "mbtoc.php?main=1";
			$want_next = false;
			foreach ($toc as $file => $hdg) {
//echo "<br>looped to $file";
				if ($want_next && strlen($file) > 3) { // bypass headings, which have number "file names" in the array
					$go = $file;
					break;
				}
				if (strcmp($file, $cur) == 0) { // need string comparison here
//echo "<br>----$file----$cur----equal";
					if ($dir == "prev") {
						$go = $file_prev;
						break;
					}
					else
						$want_next = true;
				}
				if (strlen($file) > 3) // bypass headings
					$file_prev = $file;
			}
			//echo "<p>$go";exit;
			header("Location: $go");
			break;
		}
	}
	else {
		heading($filename);
	}
}

function heading($filename) {
	?>
<img src="images/mudbag-help.gif" border="0" height="30"
width="150">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<?
			if (!isset($_REQUEST['homeonly'])) {
	?>
<a target='mbhelp_frame_right' href="mbtoc.php?dir=prev&cur=<? echo $filename; ?>"><img src="images/back_cmp_Pixel000_back.gif" alt="Back" align="middle"
	border="0" height="20" width="100"></a>
	<?
		}
	?>
<a target='_top' href="mbhelp.html" target="_top"><img src="images/home_cmp_Pixel000_home.gif" alt="Home"
	align="middle" border="0" height="20" width="100"></a>
	<?
			if (!isset($_REQUEST['homeonly'])) {
	?>
<a target='mbhelp_frame_right' href="mbtoc.php?dir=next&cur=<? echo $filename; ?>"><img src="images/next_cmp_Pixel000_next.gif"
	alt="Next" align="middle" border="0" height="20" width="100"></a>
	<?
		}
	?>
<!-- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -->
	<?
	//echo "<small>[$filename]</small>";
	?>
	<?
}
?>