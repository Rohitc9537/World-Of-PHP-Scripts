<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->About Views<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->About Views<!-- TITLE END --></h1>
<!-- BODY START -->
<p>If you're not familiar with Mudbag views, read about Mudbag's
<a href="basic_concepts.php">Basic Concepts</a> before continuing.</p>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>