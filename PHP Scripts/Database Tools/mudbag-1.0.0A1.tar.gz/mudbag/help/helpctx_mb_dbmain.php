<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Mudbag Home</title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;Mudbag Home</h1>
<p>When you login to Mudbag, you see a summary page that shows
your databases (initially, just one) and, for the selected database,
the tables, views, and reports it contains. This is also where the <i>Home</i>
button, which appears on almost every Mudbag page, takes you.</p>
<p>Databases listed may be owned by you or by others who have
invited you to share them, in which case the owner is indicated.</p>
<p>Tables are always owned by the user who owns the database
they're in, but any user can add views or reports to a database they're
sharing, in which case the user who created the view or report is the
owner. If you're not the owner of a view or report that's listed, the
owner will be indicated.</p>
<h2>Databases</h2>
<p>To select a database, click on its name. Its tables, views,
and reports will then be shown. If you're the owner of a database, a <i>Delete/Rename</i>
button is shown next to its name.</p>
<p>Any user can press the <i>Add Database</i> button to add a
new database.</p>
<h2>Tables</h2>
<p>Click on the name of a table to view, and perhaps edit, its
data.</p>
<p>If you're the owner of&nbsp; the database that contains a
table, <i>Design</i> and <i>Delete/Rename</i> buttons appear next to
its name. <i>Design</i> let's you view, and perhaps edit, the design
of the table (e.g., its fields and their types).</p>
<h2>Views</h2>
<p>To see the data in a view, and perhaps edit it, click the view
name.</p>
<p>If you're the owner of a view, you can press the <i>Design</i>
or <i>Delete</i> buttons. (<i>Design</i> also lets you rename the
view.)</p>
<p>If you're not the owner of a view, you can press the <i>Details</i>
button to see its design, but you can't change it.</p>
<p>Any user can press the <i>Add View</i> button to add a new
view.</p>
<h2>Reports</h2>
<p>To generate an already-designed report, click on its name.</p>
<p>If you're the owner of a report, you can press the <i>Design</i>
or <i>Delete</i> buttons. (<i>Design</i> also lets you rename the
report.)</p>
<p>Any user can press the <i>Add Report</i> button to add a new
report.</p>
<h2>Other Actions</h2>
<p>The owner of a database can press the <i>Import</i> button at
the top to import data into it, or the <i>Users</i> button to manage
sharing of the database. Anyone who has access to a database can press
the <i>Export</i> button to export data from it.</p>
<h2>See Also</h2>
<p><a href="helpctx_mb_mng_users~main.php">Managing Users</a>
<br><a href="helpctx_mb_dbadd.php">Adding a Database</a>
<br><a href="helpctx_mb_dbtable_add.php">Adding a Table</a>
<br><a href="helpctx_mb_dbview_addedit~lnk_intro.php">About Views</a>
<br><a href="helpctx_mb_report.php">Types of Reports</a>
<br><a href="about_importing.php">About Importing</a>
<br><a href="helpctx_mb_dbtable_export.php">Exporting a Table or View</a>
<script language="php">require("mbbot.php");</script>
</body>
</html>
