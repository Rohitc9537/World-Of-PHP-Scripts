<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
  <meta http-equiv="CONTENT-TYPE"
 content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <title>Browsers That Work With Mudbag</title>
</head>
<body>
<script language="PHP">require "mbtoc.php";</script>
<h1>&nbsp;Browsers That Work With Mudbag</h1>
<p><font face="Arial">Mudbag works with the following browsers:</font></p>
<p>Firefox version 1 or higher<br>
Internet
Explorer version 4 or higher<br>
Safari version 1 or higher<br>
Opera
version 7 or higher<br>
Mozilla version 1 or higher</p>
<p>You have to have JavaScript (but not Java)
enabled in your browser.</p>
<p>Firefox is available for Mac OS X (but not OS 9
or lower), Linux, and Windows (98, 98SE, ME, NT 4.0, 2000, XP, and
Server 2003). </p>
<p><a href="http://www.spreadfirefox.com/?q=affiliates&amp;id=0&amp;t=70"
 target="_blank"><img
 src="http://sfx-images.mozilla.org/affiliates/Buttons/88x31/get.gif"
 name="Graphic5" alt="Get Firefox!" align="bottom" border="0"
 height="31" width="88"></a>
</p>
<p>
<script language="PHP">require("mbbot.php");</script></p>
</body>
</html>
