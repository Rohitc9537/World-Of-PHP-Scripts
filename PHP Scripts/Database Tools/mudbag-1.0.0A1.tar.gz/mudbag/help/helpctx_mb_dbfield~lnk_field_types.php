<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Field Types<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Field Types<!-- TITLE END --></h1>
<!-- BODY START -->
<p>Each Mudbag table consists of one or more fields, and each record in the 
table has data for each field.
A field has a name, a type, and usually 
other attributes that depend on its type.</p>
<h2>Available Field Types</h2>
<p>The following table shows the available field types:</p>
<table border="1" cellspacing="0" cellpadding="5" align="center">
	<thead>
	<tr bgcolor="#CCCCFF">
		<th align="left" valign='bottom'>
			Mudbag Type
		</th>
		<th align="left" valign='bottom'>
			MySQL Type
		</th>
		<th align="left" valign='bottom'>
			Description
		</th>
		<th align="left" valign='bottom'>
			On Form
		</th>
		<th align="left" valign='bottom'>
			In Import
		</th>
		<th align="left" valign='bottom'>
			Examples
		</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td valign='top'>Text</td>
		<td valign='top'>varchar(255)</td>
		<td valign='top'>Any characters up to a length of 255.</td>
		<td valign='top'>Single line of text.</td>
		<td valign='top'>Same.</td>
		<td valign='top'><small>The&nbsp;quick&nbsp;brown&nbsp;fox.</small></td>
	</tr>
	<tr>
		<td valign='top'>Memo</td>
		<td valign='top'>mediumtext</td>
		<td valign='top'>Any characters up to a length of 16MB.</td>
		<td valign='top'>Multiple lines of text.
		Line breaks are preserved and are represented by a single newline (Hex 0A).</td>
		<td valign='top'>Same, but in addition carriage returns (Hex 0D) are discarded and the two-character combination \n is replaced by a genuine newline.</td>
		<td valign='top'><small>The&nbsp;quick<br>brown&nbsp;fox.</small></td>
	</tr>
	<tr>
		<td valign='top'>Number</td>
		<td valign='top'>double</td>
		<td valign='top'>Integer or floating-point value.</td>
		<td valign='top'>Must consist of digits, optionally preceded by a minus sign, and optionally containing a decimal point.
		Exponential notation (e.g., 123e-4) is not allowed.</td>
		<td valign='top'>Same.</td>
		<td valign='top'><small>123<br>123.456</small></td>
	</tr>
	<tr>
		<td valign='top'>Money</td>
		<td valign='top'>decimal(16,4)</td>
		<td valign='top'>Integer or floating-point value representing US dollars or other currency with hundreths.</td>
		<td valign='top'>Same rules as for Number, except at most 4 decimal places are stored. On display, cents are rounded to two digits.</td>
		<td valign='top'>Same.</td>
		<td valign='top'><small>123<br>123.456</small></td>
	</tr>
	<tr>
		<td valign='top'>YesNo</td>
		<td valign='top'>bool or tinyint(1)</td>
		<td valign='top'>Truth value.</td>
		<td valign='top'>Checkbox appears on form. A 1 or 0 is stored in the database. Displayed as a Y or N.</td>
		<td valign='top'>For true, any of the following are acceptable (case insensitive):
		t, true, .true., .t., y, yes, on, 1.
		For false:
		f, false', .false., .f., n, no, off, 0.
		</td>
		<td valign='top'><small>Y<br>N</small></td>
	</tr>
	<tr>
		<td valign='top'>DateTime</td>
		<td valign='top'>datetime</td>
		<td valign='top'>Date and time, to the second.</td>
		<td valign='top'>See below for allowable date formats.</td>
		<td valign='top'>Same.</td>
		<td valign='top' nowrap><small>2005-07-04<br>2005-07-04&nbsp;16:02:40</small></td>
	</tr>
	<tr>
		<td valign='top'>Choice</td>
		<td valign='top'>enum</td>
		<td valign='top'>One of a list of choices specified when the field is created.</td>
		<td valign='top'>Drop-down control appears on the form.</td>
		<td valign='top'>Text must exactly matching one of the choices.</td>
		<td valign='top'><small>red<br>blue</small></td>
	</tr>
	</tbody>
	<tfoot>
		<td colspan="6" align="left" bgcolor="#CCCCFF">
		<small>
			The MySQL type is just to help explain the type; you can't access Mudbag data directly with MySQL. <i>On Form</i> is how you
			enter data into a Mudbag form. <i>In Import</i> is how data must be formatted in an import file.
		</small>
		</td>
	</tfoot>
</table>
<h2>Date Formats</h2>
<p>Mudbag always displays a DateTime in ISO 8601 form (YYYY-DD-MM hh:mm:ss).
This means that even if you type the date 7/4/05 into a date field, as soon as the record is saved it will be displayed as
2005-07-04 00:00:00.
The timezone is the same as whatever was input, as a timezone designator can't appear in the input.
If you want just the date part to appear in a report, you can set the width to 10 characters or fewer.
<p>The following formats are converted to DateTimes on input:
<ol>
<li>
ISO 8601 form, where the time is optional and, if present, the seconds are optional.
Delimiters in the date part can be dashes, periods, or slashes.
There must be exactly one space between the date and the time part (if present).
Hours can be 1 or 2 digits (24-hour clock), but minutes and seconds (if present) must be 2 digits.
The year must be between 1000 and 9999 inclusive.
All of the following are legal:
<blockquote>
2005-07-04
<br>2005.07.04
<br>2005/07/04
<br>2005-07-04 1:23
<br>2005-07-04 01:23
<br>2005-07-04 01:23:45
</blockquote>
<p>
AM, PM, timezone, and daylight-savings indicators aren't allowed.
<p>
This is the format you should use if you have control over the input, because it's unambiguous, language independent, and standardized.
</li>
<li>
Similar to the preceding, except that the month is a word, the day can be 1 or 2 digits,
and there can be multiple spaces between the date and the optional time.
The following month words are allowed:
january,
jan,
february,
feb,
march,
mar,
april,
apr,
may,
may,
june,
jun,
july,
jul,
august,
aug,
september,
sep,
sept,
october,
oct,
november,
nov,
december, and
dec.
For example:
<blockquote>
2005-July-04
<br>2005.July.4&nbsp;&nbsp;&nbsp;1:23
</blockquote>
</li>
<li>
Same as the preceding, except the day and the year are swapped.
For example:
<blockquote>
04-July-2005
<br>4.July.2005 1:23
</blockquote>
</li>
<li>
The commonly-used US format m/d/y is allowed (without a time), where the month and day can be 1 or 2 digits and the
year can be 2 or 4.
If the year is 2 digits and less than or equal to 30, 2000 is added to it; otherwise, 1900 is added.
This format isn't recommended, but at least the confusion for non-Americans (who are more likely to put the day first) is minimal,
since Mudbag never displays a date in this format.
</li>
</ol>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
