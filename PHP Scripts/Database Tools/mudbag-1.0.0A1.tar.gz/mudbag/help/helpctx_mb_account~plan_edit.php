<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Selecting a Plan<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Selecting a Plan<!-- TITLE END --></h1>
<!-- BODY START -->
<p>Your use of Mudbag is controlled by a plan that determines your monthly or 
yearly payment and what resources that payment entitles you to use, in terms of 
maximum number of databases and tables, maximum amount of data, and maximum 
number of emails you can send at once.</p>
<p>To see what your current plan is and what plans are available, press the <i>
Account</i> button at the top of the screen and then the <i>Renew or Change Plan</i> 
button.</p>
<p>All payments must be made through PayPal, but you have lots of options with 
PayPal, including using major credit cards. Before changing your Mudbag account 
to a paying plan, you need to set up a PayPal &quot;buyer&quot; account if you don't 
already have one. Go to <a href="http://www.paypal.com">www.paypal.com</a> to do 
that. (PayPal is part of eBay, but you can use PayPal without using eBay.)</p>
<p>Normally, you don't have to renew your current Mudbag plan because payments 
are recurring and are automatically charged each month or each year. However, if 
you've changed your credit card or made other changes that need to be reflected 
in your PayPal account, you may need to renew manually. You can also upgrade 
your plan, which you'll have to do to get more resources. It's also possible to 
downgrade your plan, in which case you'll be given credit for any remaining 
payment amount under the old plan. (But you can't downgrade from a paying plan 
to a free plan.)</p>
<h2>See Also</h2>
<p><a href="helpctx_mb_account~main.php">Viewing Account Information</a>
<br><a href="helpctx_mb_account~plan_change.php">Changing Your Plan</a>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>
