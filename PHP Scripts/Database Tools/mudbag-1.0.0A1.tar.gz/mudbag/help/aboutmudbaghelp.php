<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>About Mudbag Help</title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <meta name="Microsoft Theme" content="none, default">
  <meta name="Microsoft Border" content="tb, default">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;About Mudbag Help</h1>
<p>This collection of web pages explains the basic principles
behind Mudbag and how you can use it to organize your data, share it
with other users, and incorporate it into reports, including labels and
emails.</p>
<p>Every Mudbag feature and option is covered in these pages.* If
you have a question that you can't find the answer to, press the <i>Contact
Us</i> button at the top of any Mudbag application page to send an
email to your Mudbag administrator. You may also find additional
information on the main Mudbag site, <a href="http://www.mudbag.com/">www.mudbag.com</a>.</p>
<p>You can start by reading about Mudbag's <a href="basic_concepts.php">basic
concepts</a>.</p>
<!-- p style='width:25%;border-top:solid 1' -->
<hr align='left' style='width:25%'>
<p><small>* Except that Mudbag is still in beta, and the help is incomplete.</small>
<script language="php">require("mbbot.php");</script>
</body>
</html>
