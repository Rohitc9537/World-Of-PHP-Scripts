<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Language" content="en-us">
  <meta http-equiv="Content-Type"
 content="text/html; charset=windows-1252">
  <title>Basic Concepts</title>
  <meta name="GENERATOR" content="Microsoft FrontPage 5.0">
  <meta name="ProgId" content="FrontPage.Editor.Document">
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <meta name="Microsoft Theme" content="none, default">
  <meta name="Microsoft Border" content="tb, default">
</head>
<body>
<script language="php">
require("mbtoc.php");
</script>
<h1>&nbsp;Basic Concepts
</h1>
This page explains the basic database concepts used in Mudbag.
<h2>Tables, Records, and Fields</h2>
<p>A <i>table</i> is a named collection of data arranged into
rows,
called <i> records</i>, and columns, called <i>fields</i>, like this:</p>
<p style="margin-bottom: 2px;" align="center"><b>Students</b></p>
<div align="center">
<center>
<table style="border-collapse: collapse;" bgcolor="#ffffff" border="1"
 bordercolor="#0000ff" cellpadding="8" cellspacing="0">
  <tbody>
    <tr>
      <th><font size="2">Name</font></th>
      <th><font size="2">Birthdate</font></th>
      <th><font size="2">Sex</font></th>
      <th><font size="2">Lunch</font></th>
    </tr>
    <tr>
      <td><font size="2">Smith, Mary</font></td>
      <td><font size="2">1987-04-15</font></td>
      <td><font size="2">Female</font></td>
      <td><font size="2">Y</font></td>
    </tr>
    <tr>
      <td><font size="2">Nguyen, Joh</font></td>
      <td>&nbsp;</td>
      <td><font size="2">Male</font></td>
      <td><font size="2">Y</font></td>
    </tr>
    <tr>
      <td><font size="2">Gonzalez, Ed</font></td>
      <td><font size="2">1987-11-14</font></td>
      <td><font size="2">Male</font></td>
      <td><font size="2">N</font></td>
    </tr>
  </tbody>
</table>
</center>
</div>
<p>Each records must have exactly the same fields, although the
data
for a field might be missing, as is the case for Joh's Birthdate.
Missing
data is called <i> null</i>.</p>
<p>The number of records in a table ranges from zero (an empty
table)
to thousands. The number of fields can also be huge, but it's unusual
for
a table to have more than 20.</p>
<p>Every field has a <i>type</i>, which restricts the kind of
data
it can hold. Mudbag has these types: Text (like the Name field in the
table
shown), DateTime (like Birthdate), Choice (like Sex), YesNo (like
Lunch),
Money, Number, and Memo, for large amounts of text. (<a
 href="helpctx_mb_dbfield%7Elnk_field_types.php">More</a> on field
types.)</p>
<p>You specify the names and types of the fields when you create
a
table. You can add or delete fields later, too, and even change their
types,
even after the table contains records.</p>
<p>To add a record to a table, you use a <i>form</i>, which has
a blank
for the value of each field, like this:</p>
<p align="center"> <img src="images/form_example.gif"
 style="border: 1px inset ;" border="0" height="168" width="234"> </p>
<p align="left">Mudbag automatically makes a form for each table
and
displays it when a record is to be added or edited. Note that the Sex
field,
of type Choice, has been displayed as a drop-down list, and the Lunch
field,
of type YesNo, has been displayed as a checkbox.</p>
<p align="left">Mudbag has commands to add, rename, and delete
tables;
to add, edit, and delete records; and to add, edit (e.g., change the
type
or width), and delete fields. Additionally, you can create <i>views</i>
to, for example, change how a table is sorted or which records are
selected,
and <i>reports</i>, which allow you to print or email data from tables
or
views.</p>
<h2>Databases</h2>
<p>Tables are collected into <i>databases</i>. A database can
hold
as many tables as you want to put into it, and you can have as many
databases
as you like. (Those are the technical limits; your account plan may
limit
the number of tables and databases you'll be allowed to create.)</p>
<p>When you go to a Mudbag site and register for an account, one
database
is created for you. If you register&nbsp; in response to an emailed
invitation
to share another user's database (see next section), that's the
database
you'll start out with. In either case you can create more databases
later,
if you want.</p>
<h2>Sharing, Roles, and Users</h2>
<p>Being able to share data with other users is the main
advantage
of keeping your data in a web database, like Mudbag, rather than just
on
your desktop computer.</p>
<p>The users of a database have one of three roles:</p>
<ul>
  <li>The <i>owner</i> is the user who created the database.
Only the owner
can add or delete tables and invite other users to share them.</li>
  <li>Users who have a <i>see</i> role can look at the tables,
views, and reports in a database, and can add views and reports, but
they can't change any data.</li>
  <li>Users who have an <i>edit</i> role can do everything that
users with
a <i> see</i> role can do, and in addition they can add or edit data.
(They
can't add tables, however.)</li>
</ul>
<p>The role granted to a user applies to all the tables in a
database,
but each database has its own list of users and their roles.</p>
<h2>Views</h2>
<p>A <i>view</i> is a variation on how a table appears. Each
view specifies:</p>
<ul>
  <li>Which fields are included and in what order.</li>
  <li>Whether and how the data is sorted.</li>
  <li>Whether and how records are filtered (e.g., all students
who get lunch).</li>
</ul>
<p>Views look like tables, but the have no data of their own,
because
a view is always based on the data in a table. For example:</p>
<p style="margin-bottom: 2px;" align="center"><b>Lunch_Students</b></p>
<div align="center">
<center>
<table style="border-collapse: collapse;" bgcolor="#ffffff" border="1"
 bordercolor="#0000ff" cellpadding="8" cellspacing="0">
  <tbody>
    <tr>
      <th><font size="2">Name</font></th>
      <th><font size="2">Lunch</font></th>
    </tr>
    <tr>
      <td><font size="2">Smith, Mary</font></td>
      <td><font size="2">Y</font></td>
    </tr>
    <tr>
      <td><font size="2">Nguyen, Joh</font></td>
      <td><font size="2">Y</font></td>
    </tr>
  </tbody>
</table>
</center>
</div>
<p>We could describe this view as "take the Students table, keep
only
students who have a "Y" in the Lunch column, and show only the Name and
Lunch columns."</p>
<h2>Reports</h2>
<p>A <i>report</i> lets you display data from a table or view in
a
form that's convenient for printing. You can choose one of three
formats:</p>
<div align="center">
<center>
<table style="border-collapse: collapse;" border="0"
 bordercolor="#111111" cellpadding="10" cellspacing="0">
  <tbody>
    <tr>
      <td align="center"><b>Tabular</b></td>
      <td align="center"><img src="images/basic_4.gif" border="0"
 height="194" width="331"> </td>
    </tr>
    <tr>
      <td align="center"><b>Record</b></td>
      <td align="center"><img src="images/basic_5.gif" border="0"
 height="193" width="338"> </td>
    </tr>
    <tr>
      <td align="center"><b>Label</b>
      <p>&nbsp;</p>
      </td>
      <td align="center"><img src="images/basic_6.gif" border="0"
 height="196" width="314"> </td>
    </tr>
  </tbody>
</table>
</center>
</div>
<p>A tabular report has the data in columns, a record report has
each
record as a separate block, and a label report matches one of about 700
different Avery label formats (both US and A4 sizes).</p>
<p>You'll usually want a report that's limited to certain
columns,
sorts the data in a certain way, and filters it to include only the
records
you want. To do that, you base the report on a view, although you can
also
base a report on a table directly.</p>
<p>In addition to the three report types shown, there's a fourth
type:
email. With an email report you can send an emails to a mailing list.
The
message can be customized with a mixture of standard text and data from
records, similar to the way mail-merge works with a word-processing
program.</p>
<h2>Import and Export</h2>
<p>If you already have data in a spreadsheet or another database,
you
can import it into Mudbag by getting it out of the spreadsheet or
database
in "comma-separated value" (CSV) form and then importing it into
Mudbag.
You can choose how the fields are separated (tabs, commas, etc.), what
fields
are included, what their types are, and other characteristics of the
import.</p>
<p>Similarly, you can export the data from any Mudbag table in
CSV
form for import into another program, or just to save it as backup.</p>
<script language="php">
require("mbbot.php");
</script>
</body>
</html>
