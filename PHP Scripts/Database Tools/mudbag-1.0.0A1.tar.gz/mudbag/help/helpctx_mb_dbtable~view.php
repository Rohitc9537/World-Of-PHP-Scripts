<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title><!-- TITLE START -->Seeing Table/View Data<!-- TITLE END --></title>
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;<!-- TITLE START -->Seeing Table/View Data<!-- TITLE END --></h1>
<!-- BODY START -->
<p><i>This help page is not yet available.</i><html><head>
<!-- BODY END -->
<script language="php">require("mbbot.php");</script>
</body>
</html>