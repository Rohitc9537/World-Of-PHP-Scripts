<HR style='color:silver'>
<P ALIGN=CENTER><FONT FACE="Arial" color='silver'><FONT SIZE=1>Mudbag is a
trademark of Basepath Associates.<BR>Screens and source code
&copy;2003-2005 by Basepath Associates. All rights reserved.
<p><? echo "[$filename]"; ?>
</FONT></FONT>
<?php
?>