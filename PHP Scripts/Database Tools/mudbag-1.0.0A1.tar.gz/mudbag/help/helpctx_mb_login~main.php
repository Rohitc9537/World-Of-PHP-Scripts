<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Logging In</title>
  <meta name="generator" content="Microsoft FrontPage 5.0">
  <meta name="keywords" content="">
  <link rel="stylesheet" type="text/css" href="mudbag_help.css">
  <meta name="Microsoft Border" content="tb, default">
</head>
<body>
<script language="php">require("mbtoc.php");</script>
<h1>&nbsp;Logging In</h1>
<p>To log in to Mudbag, type your user ID and password and then
press <i>Login.</i></p>
<p>If you're not yet registered, press the <i>Register</i>
button.</p>
<p>If you're registered but you can't remember your password,
click the "Forgot your password?" link and instructions for resetting
your password will be emailed to you. If that doesn't work, you can <a
 href="mailto:support@mudbag.com?subject=Forgot%20my%20password">email</a>
Mudbag support directly.</p>
<h2>See Also</h2>
<p><a href="helpctx_mb_register.php">Registering and Changing
Personal Information</a></p>
<script language="php">require("mbbot.php");</script>
</body>
</html>
