<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_admin_user.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");

	$want_db_query_echo = false;

	class MB_AdminUser extends MB_DBScreen {

		var $want_main = false;

		function MB_AdminUser() {
			parent::MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_main":
				$this->want_main = true;
				break;
			default:
				parent::Callback($tag);
			}
		}

		function ShowForm() {
			if ($_SESSION['MUDBAG_USER']->login != "admin")
				exit("You are not the administrator.");
			if ($this->want_main)
				$this->ShowFormMain();
			else if (isset($_GET['login']))
				$this->ShowFormUser($_GET['login']);
			else
				$this->ShowFormMain();

		}

		function ShowFormMain() {
			$this->dbmain->db_query_show("Users", "select * from mb_user order by login", 0, "login", "mb_admin_user.php", 'user_detail');
			$this->dbmain->db_query_show("Transactions", "SELECT * FROM mb_paypal_txn where account_id = {$_SESSION['MUDBAG_USER']->account_id}");

		}

		function ShowFormUser($login) {
			$this->Button("btn_main", "Main User Administration Page");
			switch (nvl($_GET['option'])) {
			case "paypal":
				$this->dbmain->db_query_show("PayPal Transactions for $login", "select
					concat(ifnull(payment_date, ''), ifnull(subscr_date, '')) as \"Date\",
					txn_type,
					item_name,
					item_number,
					invoice,
					amount3,
					payment_fee,
					payment_gross,
					period3,
					recurring,
					mc_amount3,
					mc_fee,
					mc_gross,
					payment_status,
					payer_email,
					first_name,
					last_name
				  from mb_paypal_txn
				  join mb_user using(account_id)
				  where login = '$login' order by id desc");
				break;
			case "resetpassword":
				echo "<p>Click <a href='mb_admin_user.php?login=$login&option=resetpasswordgo'>here</a> to reset password.";
				break;
			case "resetpasswordgo":
				$new_password = synthesize_password();
				$this->dbmain->db_query("update mb_user set password = PASSWORD('$new_password')
				  where login = '$login'");
				echo "<p>Password has been set to \"$new_password\"";
				break;
			default:
				echo <<<EOT
					<h1>User $login</h1>
					    <a href='mb_admin_user.php?login=$login&option=resetpassword'>Reset Password</a>
					<br><a href='mb_admin_user.php?login=$login&option=paypal'>PayPal Transactions</a>
EOT;
			}
		}

	}
	$frm = new MB_AdminUser();
	$frm->SetLevelHome();
	$frm->Go(null, "User Administration", "helpctx_mb_admin_user", false, null, true, true);

function user_detail(&$db, &$row) {
	$drow = mysql_fetch_row($db->db_query("select max(unix_timestamp(updated)) from mb_log where msg = '{$row['login']}'"));
	echo "Last login: " . date("Y-m-d H:i:s", $drow[0]);
	$drow = mysql_fetch_row($db->db_query("select count(*) from mb_log where msg = '{$row['login']}' and updated >= date_sub(now(), interval 30 day)"));
	echo "<br>Logins in last 30 days: " . $drow[0];
}

?>
