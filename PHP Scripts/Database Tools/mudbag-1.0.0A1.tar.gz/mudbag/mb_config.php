<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_config.php,v 1.2 2005/07/13 04:35:53 rochkind Exp $

	if (file_exists('localsite/setup.php'))
		require('localsite/setup.php');
	else
		require('setup-missing.php');

	// Limits.
	define('MB_UPLOAD_MAX', 10000000);
	define('MB_ROW_PAGE_MAX', 20); // Default max data rows per page
	define('MB_REPORT_EXEC_TIME', 20); // Default max exec time for reports (minutes)
	define('MB_EMAIL_LIMIT', 50); // Limit on number of emails with one send
	define('MB_EXPORT_DIR', "export"); // Directory for export files
?>
