-- Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
-- Further information about Mudbag is at mudbag.com.
-- May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
-- $Id: install.sql,v 1.1.1.1 2005/07/13 00:21:56 rochkind Exp $

CREATE TABLE mb_db (
  db_id int(11) NOT NULL auto_increment,
  dbname varchar(50) NOT NULL default '',
  dblongname varchar(100) NOT NULL default '',
  PRIMARY KEY  (db_id),
  UNIQUE KEY dblongname_constraint (dbname,dblongname),
  UNIQUE KEY dbname_constraint (dbname)
) TYPE=InnoDB;

CREATE TABLE mb_param (
  tag varchar(50) NOT NULL default '',
  text varchar(200) default NULL,
  data1 int(10) default NULL,
  data2 int(10) default NULL,
  PRIMARY KEY  (tag)
) TYPE=InnoDB;

CREATE TABLE mb_sequence (
  seq int(11) NOT NULL default '0',
  tag varchar(30) NOT NULL default '0',
  PRIMARY KEY  (tag)
) TYPE=MyISAM;

CREATE TABLE mb_token (
  token_id int(11) NOT NULL auto_increment,
  login varchar(10),
  db_id int(11) NOT NULL default '0',
  when_issued datetime NOT NULL default '0000-00-00 00:00:00',
  when_redeemed datetime NOT NULL default '0000-00-00 00:00:00',
  email varchar(100) NOT NULL default '',
  role_id int(11) NOT NULL default '0',
  error tinyint(1) NOT NULL default '0',
  code int(11) NOT NULL default '0',
  PRIMARY KEY  (token_id),
  UNIQUE KEY code (code)
) TYPE=InnoDB;

CREATE TABLE mb_user (
  user_id int(40) NOT NULL auto_increment,
  login varchar(10) NOT NULL default 'xxx',
  password varchar(50) binary NOT NULL default 'xxx',
  street1 varchar(50) default NULL,
  street2 varchar(50) default NULL,
  city varchar(20) default NULL,
  state char(2) default NULL,
  zip decimal(5,0) default NULL,
  phone varchar(30) default NULL,
  email varchar(50) NOT NULL default '',
  lastname varchar(60) NOT NULL default '',
  firstname varchar(40) NOT NULL default '',
  suspended tinyint(1) default '0',
  country varchar(100) default '',
  default_db_id int(11),
  account_id int(11),
  PRIMARY KEY  (user_id),
  UNIQUE KEY login_constraint (login)
) TYPE=InnoDB;

CREATE TABLE `mb_account` (
  account_id int(11) NOT NULL auto_increment,
  sku varchar(20) NOT NULL default '',
  expire date default NULL,
  PRIMARY KEY (account_id)
) TYPE=InnoDB;

insert into mb_account (sku) values ('FREE');

CREATE TABLE mb_user_db (
  user_id int(11) NOT NULL default '0',
  db_id int(11) NOT NULL default '0',
  role_id int(11) NOT NULL default '0',
  PRIMARY KEY  (db_id,user_id)
) TYPE=InnoDB;

CREATE TABLE mb_view (
  view_id int(11) NOT NULL auto_increment,
  user_id int(11) NOT NULL default '0',
  db_id int(11) NOT NULL default '0',
  tbl varchar(20) NOT NULL default '',
  name varchar(20) NOT NULL default '',
  public tinyint(1) NOT NULL default '0',
  v1 varchar(255) NOT NULL default '',
  v2 varchar(255) NOT NULL default '',
  sql text NOT NULL,
  spec text NOT NULL,
  PRIMARY KEY (view_id),
  UNIQUE KEY name_constraint (db_id,tbl,name)
) TYPE=InnoDB;

CREATE TABLE mb_field (
 name varchar(20) NOT NULL default '',
  type enum('t','m','y','n','d','c','f') NOT NULL default 't',
  cols int(11) NOT NULL default '0',
  rows int(11) NOT NULL default '0',
  field_id int(11) NOT NULL auto_increment,
  tbl varchar(100) NOT NULL default '',
  db_id int(11) NOT NULL default '0',
  choices varchar(255) NOT NULL default '',
  req tinyint(1) NOT NULL default '0',
  seq int(11) NOT NULL default '0',
  PRIMARY KEY (field_id),
  UNIQUE KEY name_constraint (name,tbl,db_id)
) TYPE=InnoDB;

CREATE TABLE mb_importspec (
  db_id int(11) NOT NULL,
  name varchar(50) NOT NULL,
  delim char(1) not null default ',',
  quote char(1) not null default '\"',
  headings bool not null default '0',
  max_errs int(11),
  flds text,
  types text,
  tbl varchar(100),

  PRIMARY KEY (db_id, name)
) TYPE=MyISAM;

CREATE TABLE mb_reportspec (
  db_id int(11) NOT NULL,
  user_id int(11) NOT NULL default '0',
  type char(1) not null,
  name varchar(50) not null,
  show_lines bool default 1,
  is_table bool not null,
  tableview varchar(100) not null,
  template text,
  specstring text,
  text1 varchar(100),
  public bool not null default '0',

  PRIMARY KEY (db_id, name)
) TYPE=MyISAM;

CREATE TABLE mb_paypal_txn (
id int(11) NOT NULL auto_increment,
account_id int(11),
status varchar(10), -- INVALID or VERIFIED
business varchar(127), -- business@where.com
item_name varchar(127), -- Mudbag Plan 1
item_number varchar(127), -- 123456
invoice varchar(255), -- 123456
payment_date datetime, -- 12:12:18 Mar 12, 2005 PST
subscr_date datetime, -- 12:12:13 Mar 12, 2005 PST
amount3 decimal(10,2), -- 10.00
payer_email varchar(127), -- personal@barf.com
payment_fee decimal(10,2), -- 0.59
payment_gross decimal(10,2), -- 10.00
first_name varchar(64), -- Personal
last_name varchar(64), -- Sandox
period3 varchar(10), -- 1 M
mc_amount3 decimal(10,2), -- 10.00
mc_currency varchar(10), -- USD
mc_fee decimal(10,2), -- 0.59
mc_gross decimal(10,2), -- 10.00
payer_id varchar(13), -- XY2V87C3F6BBW
receiver_id varchar(13), -- JNMVCDTFKECSN
recurring tinyint(1), -- 1
subscr_id varchar(19), -- S-6RH395717X313550E
test_ipn tinyint(1), -- 1
txn_id varchar(17), -- 2BV316601X7664434
txn_type varchar(20), -- subscr_payment, subscr_signup
request text,
payment_status varchar(20),
  PRIMARY KEY  (id)
) TYPE=MyISAM;

create index mb_paypal_txn_txn_id on mb_paypal_txn (txn_id);

create table mb_log (
	id int(11) NOT NULL auto_increment,
	updated timestamp,
	code varchar(10),
	msg text,
	primary key (id)
) TYPE=MyISAM;

-- End
