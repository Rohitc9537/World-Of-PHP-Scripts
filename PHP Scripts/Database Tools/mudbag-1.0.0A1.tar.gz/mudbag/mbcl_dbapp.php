<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_dbapp.php,v 1.1.1.1 2005/07/13 00:22:07 rochkind Exp $

class MB_AppDB { // a user's database, not mudbag_main
	var $dbname, $dblongname, $db_id, $role_id, $owner;
	var $dbmain;
	var $tblpfx; // dbchg
	var $tblpfx_admin = "[NOT INITIALIZED]"; // dbchg

	function MB_AppDB() {
		$this->dbmain = new MB_DB();
		$result = $this->dbmain->db_query("select db_id from mb_db where dbname = 'Mudbag_admin'");
		$row = mysql_fetch_row($result);
		if ($row)
			$this->tblpfx_admin = $this->make_tblpfx($row[0]);
	}

	function set($dbname, $dblongname, $db_id, $role_id, $owner, $update_default_db_id = true, $user_id = null) {
		if (!isset($user_id))
			$user_id = $_SESSION['MUDBAG_USER']->user_id;
		if (!mysql_fetch_array($this->dbmain->db_query("select db_id from mb_user_db
		  where db_id = $db_id and user_id ={$user_id} and role_id = $role_id")))
			exit("You don't have permission to access this database.");
		$this->dbname = $dbname;
		$this->dblongname = $dblongname;
		$this->db_id = $db_id;
		$this->tblpfx = $this->make_tblpfx($this->db_id);
		$this->role_id = $role_id;
		$this->owner = $owner;
		if ($update_default_db_id) {
			$this->dbmain->db_query("update mb_user set default_db_id = $db_id where user_id = {$_SESSION['MUDBAG_USER']->user_id}");
			$_SESSION['MUDBAG_USER']->default_db_id = $db_id;
		}
	}

	function make_tblpfx($db_id) {
		return "mb_" . str_pad($db_id, 5, '0', STR_PAD_LEFT) . "_";
	}

	function internal_name($tbl) {
		return $this->tblpfx . $tbl;
	}

	function internal_name_admin($tbl) {
		return $this->tblpfx_admin . $tbl;
	}

	function external_name($tbl) {
		return substr($tbl, 9);
	}

	function is_set() {
		return isset($this->dblongname);
	}

	function clear() {
		$this->dbname = NULL;
		$this->dblongname = NULL;
		$this->db_id = NULL;
		$this->role_id = NULL;
		nav_clear(); // No longer clears db or field
	}

	function create($dblongname, $want_initial_table = false, &$msg) {
		if (!isset($_SESSION['MUDBAG_USER']->login))
			die('MB_AppDB.create: $_SESSION[\'MUDBAG_USER\']->login not set');
		$_SESSION['APPDB'] = &$this;
		$row = mysql_fetch_row($this->dbmain->db_query("select dbname from mb_db where dblongname = '$dblongname'"));
		if ($row) {
			$msg = "Database with the name \"$dblongname\" already exists.";
			return false;
		}
		$seq = get_name_seq_global("login_" . $_SESSION['MUDBAG_USER']->login);
		$dbname = "mudbag_U_{$_SESSION['MUDBAG_USER']->login}_$seq";
		if ($dblongname == "db_admin")
			$dbname = "Mudbag_admin";
		else
			$dbname = "mudbag_U_{$_SESSION['MUDBAG_USER']->login}_$seq";
		//$this->dbmain->db_query("create database " . $dbname); //dbchg
		//$this->dbmain->grant_owner_privileges($dbname); //dbchg
		$db_id = $this->dbmain->db_query('insert into mb_db (dbname, dblongname) values("'. $dbname .'", "' . $dblongname . '")');
		$this->dbmain->db_query('insert into mb_user_db (user_id, db_id, role_id) values(' . $_SESSION['MUDBAG_USER']->user_id . ', ' .
		  $db_id . ', ' . 1 . ')');
		if ($dbname == "Mudbag_admin")
			$this->tblpfx_admin = $this->make_tblpfx($db_id);
		// WARNING: If you make either of the above conditional, need to call mysql_errno() to see if an error was generated.
		$this->set($dbname, $dblongname, $db_id, ROLE_OWNER, $_SESSION['MUDBAG_USER']->login);
		if ($want_initial_table)
			$this->build_initial_tables();
		return true;
	}

	function build_initial_tables() {
		$table = "{$this->tblpfx}Mountains";
		$this->dbmain->db_query_user("create table $table(_rowID int auto_increment primary key) type=MyISAM");
		$f = new Field('Mountains', 'Rank', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Mountains', 'Peak', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Mountains', 'OtherName', 't');
		$f->store_new($error_number, $error_msg);
		$f = new Field('Mountains', 'Height', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Mountains', 'Country', 't');
		$f->store_new($error_number, $error_msg);
		$f = new Field('Mountains', 'Range', 'c', NULL, NULL, array("Himalaya", "Karakoram"));
		$f->store_new($error_number, $error_msg);
		$this->dbmain->db_run_file_user('install_mtns.sql', $table);

		$table = "{$this->tblpfx}AddrBook";
		$this->dbmain->db_query_user("create table $table(_rowID int auto_increment primary key) type=MyISAM");
		$f = new Field('AddrBook', 'LastName', 't', 40, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'FirstName', 't', 40);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Company', 't', 40);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Address1', 't', 40);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Address2', 't', 40);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'City', 't', 40);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'State', 't', 16);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'ZIP', 't', 5);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Country', 't', 12);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Phone1', 't', 15);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Phone2', 't', 15);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Email', 't', 30);
		$f->store_new($error_number, $error_msg);
		$f = new Field('AddrBook', 'Note', 'm', 40, 5);
		$f->store_new($error_number, $error_msg);
		$this->dbmain->db_run_file_user('install_addrbook.sql', $table);

		$this->dbmain->db_query_user("create table {$this->tblpfx}Notes(_rowID int auto_increment primary key) type=MyISAM");
		$f = new Field('Notes', 'Tag', 't', 15, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Notes', 'Text', 'm', 60, 10, null, null, 1);
		$f->store_new($error_number, $error_msg);

		$table = "{$this->tblpfx}US_Senate";
		$this->dbmain->db_query("create table $table(_rowID int auto_increment primary key) type=MyISAM");
		$f = new Field('US_Senate', 'last', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'first', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'party', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'rep_state', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'class', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'address', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'city', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'state', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'zip', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'phone', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'email', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('US_Senate', 'web', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$this->dbmain->db_run_file_user('install_Senate.sql', $table);
	}

	function get_role() {
		return role_name($this->role_id);
	}

	function get_role_id($role) { // could be class function
		switch ($role) {
		case 'own':
			return ROLE_OWNER;
			break;
		case 'see':
			return ROLE_SEE;
			break;
		case 'edit':
			return ROLE_EDIT;
			break;
		default:
			dir("bad role: " . $role);
		}
	}

	function is_owned() {
		return $this->role_id == ROLE_OWNER;
	}

	function is_readonly() {
		return $this->role_id == ROLE_SEE;
	}

	function ShowTableViewSelect($name, $selection = '', $want_views = true, $extra_option = null, $javascript = null) {
		$result1 = $this->dbmain->db_query_user("show tables like '{$this->tblpfx}%'");
		if ($want_views)
			$result2 = $this->dbmain->db_query_user("select name, view_id from mb_view
			  where db_id = $this->db_id and (public = 1 or user_id = {$_SESSION['MUDBAG_USER']->user_id})");
		echo "<select name='$name'" . ($javascript ? " onchange='$javascript' " : "") . ">";
		if (isset($extra_option))
			echo "<option value='x-$extra_option'>$extra_option</option>";
		while ($row = mysql_fetch_row($result1)) {
			$table = $this->external_name($row[0]);
			$v = "t-$table";
			$sel = ($v == $selection ? " selected " : "");
			echo "<option value='$v' $sel>Table: $table</option>";
		}
		if (isset($result2))
			while ($row = mysql_fetch_row($result2))
				if (substr($row[0], 0, 4) != 'mb_') {
					$v = "v-$row[0]";
					$sel = ($v == $selection ? " selected " : "");
					echo "<option value='$v' $sel>View: $row[0]</option>";
				}
		echo "</select>";
	}

	 // Must be run one time when Mudbag is installed on a new machine.
	 // Run by dbmain.php when admin logs in for the first time.
	function Install($plans_only = false) {
		$this->create("db_admin", false, $msg);

if (!$plans_only) {
		$table = "{$this->tblpfx}LabelSizes";
		$this->dbmain->db_query("create table $table(_rowID int auto_increment primary key)");
		$f = new Field('LabelSizes', 'vendor', 't'); // null means Avery
		if (!$f->store_new($error_number, $error_msg)) exit($error_msg);
		$f = new Field('LabelSizes', 'code', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'number_horz', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'number_vert', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'paper_size', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'mgn_left', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'mgn_top', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'gutter_horz', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'gutter_vert', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'width', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'height', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'also', 't');
		$f->store_new($error_number, $error_msg);
		$f = new Field('LabelSizes', 'units', 't');
		$f->store_new($error_number, $error_msg);
		$this->dbmain->db_run_file_user('install_LabelSizes.sql', $table);
}
set_db_from_id(1);
		$table = "{$this->tblpfx}Plans";
		$this->dbmain->db_query("create table $table(_rowID int auto_increment primary key)");
		$f = new Field('Plans', 'sku', 't', null, null, null, null, 1);
		if (!$f->store_new($error_number, $error_msg)) exit($error_msg);
		$f = new Field('Plans', 'name', 't', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'rate_month', 'n', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'rate_year', 'n', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'limit_databases', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'limit_data', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'limit_tables', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'limit_emails', 'f', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$f = new Field('Plans', 'active', 'y', null, null, null, null, 1);
		$f->store_new($error_number, $error_msg);
		$this->dbmain->db_run_file_user('install_Plans.sql', $table);
	}

	function query_tableview($is_table, $tableview_name, &$field_dict, &$err, $cond = false) {
		if ($is_table) {
			$sql = "select * from " . $this->internal_name($tableview_name);
			$field_dict = get_field_dict($tableview_name);
		}
		else {
			$v = new View($_SESSION['APPDB']->db_id);
			if (!$v->load_by_name($tableview_name)) {
				$err = 1146; // "table" not found
				return null;
			}
			$sql = $v->build_select();
			$field_dict = $v->field_dict;
		}
		return $this->dbmain->db_query_user($sql, $cond);
	}

	function get_stats(&$num_dbs, &$num_tbls, &$total_data) {
		$result_dbs = $this->dbmain->db_query("select db_id from mb_user_db
		  where user_id = {$_SESSION['MUDBAG_USER']->user_id}
		  and role_id = " .  ROLE_OWNER);
		$num_dbs = 0;
		$num_tbls = 0;
		$total_data = 0;
		while ($row = mysql_fetch_row($result_dbs)) {
			$num_dbs++;
			$tblpfx = $this->make_tblpfx($row[0]);
			$result_tbls = $this->dbmain->db_query("show table status like '$tblpfx%'");
			while ($row = mysql_fetch_assoc($result_tbls)) {
				$num_tbls++;
				$total_data += $row['Data_length'];
			}
		}
	}
}

function validate_dblongname($name, &$msg) {
	if (!preg_match('/^[A-Za-z0-9 _]{1,20}$/', $name)) {
		$msg = "Database name must be from 1 to 20 letters, digits, spaces, and underscores. Please choose another one.";
		return false;
	}
	return true;
}

function validate_dbtablename($name, &$msg, $unique_check = false) {
	if (!preg_match('/^[A-Za-z0-9_]{1,10}$/', $name) || substr($name, 0, 4) == 'mb_') {
		$msg = "Table name must be from 1 to 10 letters, digits, and underscores. Please choose another one.";
		return false;
	}
	if ($unique_check) {
		// Can't use "like" clause because it's case-sensitive.
		$result = $_SESSION['APPDB']->dbmain->db_query_user("show tables");
		while ($row = mysql_fetch_row($result))
			if (strtoupper($row[0]) == strtoupper($name)) {
				$msg = "Table named \"$name\" already exists. Please choose another name.";
				return false;
			}
	}
	return true;
}

function set_db($dbname, $dblongname, $db_id, $role_id, $owner, $update_default_db_id = true, $user_id = null) {
	nav_clear(); // No longer clears db or field
	if (!db_isset())
		$_SESSION['APPDB'] = new MB_AppDB();
	if (!isset($db_id))
		die("set_db -- db_id arg not set");
	$_SESSION['APPDB']->set($dbname, $dblongname, $db_id, $role_id, $owner, $update_default_db_id, $user_id);
	if (!isset($_SESSION['APPDB']->db_id))
		die("set_db -- db_id arg not set in db object");
}

function set_db_from_id($db_id, $user_id = null, $login = null, $db = null) {
	if (empty($db_id))
		return false;
	if (!isset($db)) {
		if (!db_isset())
			$_SESSION['APPDB'] = new MB_AppDB();
		$db = $_SESSION['APPDB']->dbmain;
	}
	if (!isset($user_id))
		$user_id = $_SESSION['MUDBAG_USER']->user_id;
	if (!isset($login))
		$login = $_SESSION['MUDBAG_USER']->login;
	$result = $db->db_query_user("select dbname, dblongname, role_id from mb_db d
	  join mb_user_db ud using(db_id) where d.db_id = $db_id and user_id = {$user_id}");
	if ($result) {
		$row = mysql_fetch_assoc($result);
		set_db($row['dbname'], $row['dblongname'], $db_id, $row['role_id'], $login, false, $user_id);
		return true;
	}
	return false;
}

function set_db_from_dblongname($dblongname) { // mostly for mbx_api.php and its derivatives
	if (!isset($db)) {
		if (!db_isset())
			$_SESSION['APPDB'] = new MB_AppDB();
		$db = $_SESSION['APPDB']->dbmain;
	}
	$row_db = mysql_fetch_row($db->db_query("select db_id from mb_db where dblongname = '{$dblongname}'"));

	if (!$row_db || !set_db_from_id($row_db[0]))

		return false;
	return true;

}

function db_isset() {
	return isset($_SESSION['APPDB']) && get_class($_SESSION['APPDB']) == 'mb_appdb' && $_SESSION['APPDB']->is_set();
}

function db_clear() {
	if (db_isset())
		$_SESSION['APPDB']->clear();
}

// Following function should only be used when sequence number has to be global, such as when
// naming databases. Otherwise, hits on the main DB server should be avoided.
function get_name_seq_global($name) {
	$result = $_SESSION['APPDB']->dbmain->db_query("select seq from mb_sequence where tag = \"$name\"");
	$row = mysql_fetch_row($result);
	if ($row) {
		$seq = $row[0] + 1;
		$_SESSION['APPDB']->dbmain->db_query("update mb_sequence set seq = $seq where tag = \"$name\"");
	}
	else {
		$seq = 1;
		$_SESSION['APPDB']->dbmain->db_query("insert into mb_sequence (tag, seq) values (\"$name\", $seq)");
		// WARNING: If you make the above conditional, need to call mysql_errno() to see if an error was generated.
	}
	return $seq;

// Following funciton hits only on the user's DB server.
}
function get_name_seq_local($name) {
	$result = $_SESSION['APPDB']->dbmain->db_query_user("select seq from mb_sequence where tag = \"$name\"");
	$row = mysql_fetch_row($result);
	if ($row) {
		$seq = $row[0] + 1;
		$_SESSION['APPDB']->dbmain->db_query_user("update mb_sequence set seq = $seq where tag = \"$name\"");
	}
	else {
		$seq = 1;
		$_SESSION['APPDB']->dbmain->db_query_user("insert into mb_sequence (tag, seq) values (\"$name\", $seq)");
		// WARNING: If you make the above conditional, need to call mysql_errno() to see if an error was generated.
	}
	return $seq;
}

/*
	Mudbag type		Char		MySQL type
	-----------		----		----------
	text			 	 t			varchar(255)
	memo			 	 m			mediumtext
	yesno			 y			bool
	money			 n			decimal(16,4)
	datetime		 	 d			datetime
	choice			 c			enum("one", "two", ...)
	number			 f			double
*/

function ShowFieldTypeSelect($name = 'mbfv_fieldtype', $sel = 't', $javascript = '') {
	echo "<select name='$name' onchange=\"$javascript\">";
	echo '<option value="t"' . ($sel == 't' ? ' selected' : '') . '>Text</option>';
	echo '<option value="m"' . ($sel == 'm' ? ' selected' : '') . '>Memo</option>';
	echo '<option value="f"' . ($sel == 'f' ? ' selected' : '') . '>Number</option>';
	echo '<option value="n"' . ($sel == 'n' ? ' selected' : '') . '>Money</option>';
	echo '<option value="y"' . ($sel == 'y' ? ' selected' : '') . '>YesNo</option>';
	echo '<option value="d"' . ($sel == 'd' ? ' selected' : '') . '>DateTime</option>';
	echo '<option value="c"' . ($sel == 'c' ? ' selected' : '') . '>Choice</option>';
	echo '</select>';
}

class Field {
	var $field_id, $name, $type, $cols, $rows, $choices, $req, $seq, $table;

	function Field($table, $n = NULL, $t = NULL, $c = NULL, $r = NULL, $ch = array(), $s = NULL, $rq = NULL, $id = NULL) {
		$this->table = $table;
		$this->name = $n;
		$this->type = $t;
		if (!isset($c) && $t == 'm')
			$this->cols = 40;
		else
			$this->cols = $c;
		if (!isset($r) && ($t == 't' || $t == 'm'))
			$this->rows = 5;
		else
			$this->rows = $r;
		$this->choices = $ch;
		$this->seq = $s;
		$this->req = $rq;
		$this->field_id = $id;
	}

	function get_array() {
		return array("name" => $this->name, "type" => $this->type, "cols" => $this->cols, "rows" => $this->rows,
		  "choices" => $this->choices_to_str(), "seq" => $this->seq, "req" => $this->req);
	}

	function put_array($d) { // leaves field_id alone
		$this->name = $d['name'];
		$this->type = $d['type'];
		$this->cols = nvl($d['cols']);
		$this->rows = nvl($d['rows']);
		$this->choices = split(', *', $d['choices']);
		$this->seq = nvl($d['seq']);
		$this->req = $d['req'];
	}

	function store_new(&$error_number, &$error_msg) {
		$db = $_SESSION['APPDB']->dbmain;
		$rtn = true;
		$db->db_query("begin");
		if (!$db->db_query_user(sprintf('insert into mb_field (
		  db_id, tbl, name, type, cols, rows, choices, seq, req) values (
		  %d, "%s", "%s", "%s", %d, %d, "%s", %d, %d)',
		  $_SESSION['APPDB']->db_id, $this->table, $this->name, $this->type,
		  $this->cols, $this->rows, $this->choices_to_str(), $this->seq, $this->req), true))
			$rtn = ($error_number = mysql_errno()) == 0;
		if ($rtn && !$db->db_query_user(sprintf('alter table %s add column %s %s',
		  $_SESSION['APPDB']->internal_name($this->table), $this->name, $this->mysql_type()), true))
			$rtn = ($error_number = mysql_errno()) == 0;
		if ($rtn)
			$db->db_query("commit");
		else {
			$error_msg = mysql_error(); // before rollback erases it
			$db->db_query("rollback");
		}
		return $rtn;
	}

	function delete() {
		if (!isset($this->table))
			die('Field.delete() -- $this->table not set');
		$db = $_SESSION['APPDB']->dbmain;
		$internal_name = $_SESSION['APPDB']->internal_name($this->table);
		$db->db_query("begin");
		$db->db_query_user("delete from mb_field where field_id = $this->field_id");
		$db->db_query_user("alter table $internal_name drop column $this->name");
		// When all the fields are gone except for _rowID, get rid of the rows.
		$result = $db->db_query("show columns from $internal_name");
		if (mysql_num_rows($result) == 1) {
			$row = mysql_fetch_array($result);
			if (strtolower($row[0]) == "_rowid")
				$db->db_query("delete from $internal_name");
		}
		$db->db_query("commit");
}

	function store_update($old_field_name) {
		$db = $_SESSION['APPDB']->dbmain;
		$db->db_query("begin");
		$db->db_query_user(sprintf('update mb_field set db_id = %d, tbl = "%s", name = "%s", type = "%s", cols = %d, rows = %d, choices = "%s", seq = %d, req = %d where field_id = %d',
						  $_SESSION['APPDB']->db_id, $this->table, $this->name, $this->type, $this->cols, $this->rows, $this->choices_to_str(), $this->seq, $this->req, $this->field_id));
		$db->db_query_user(sprintf('alter table %s change column %s %s %s',
							   $_SESSION['APPDB']->internal_name($this->table), $old_field_name, $this->name, $this->mysql_type()));
		$db->db_query("commit");
	}

	function choices_to_str($want_quotes = false) {
		$lst = '';
		if (gettype($this->choices) == 'array') {
			foreach ($this->choices as $c) {
				$c = trim($c);
				if ($want_quotes)
					$c = '"' . $c . '"';
				$lst .= $c . ", ";
			}
			$lst = substr($lst, 0, strlen($lst) - 2);
		}
		return $lst;
	}

	function valid_choice($v) {
		return valid_choice($v, $this->choices);
	}

	function mysql_type() {
		switch ($this->type) {
		case 't':
			return 'varchar(255)';
		case 'm':
			return 'mediumtext';
		case 'y':
			return 'bool';
		case 'n':
			return 'decimal(16,4)';
		case 'f':
			return 'double';
		case 'd':
			return 'datetime';
		case 'c':
			return 'enum(' . $this->choices_to_str(true) . ')'; // need UI to input this
		default:
			die("mysql_type -- bad type");
		}
	}

	function word_for_type() {
		if (!isset($this->type) || strlen($this->type) == 0)
			return '????';
		return word_for_type_static($this->type);
	}

	function format_for_display($val, $width = null) {
		switch ($this->type) {
		case 'y':
			return $val ? 'Y' : 'N';
			break;
		case 'd':
			if (isset($width) && $width <= 10)
				return substr($val, 0, 10);
			else
				return $val;
			break;
		case 'n':
			return number_format($val, 2);
		}
		return $val;
	}

}

function valid_choice($v, &$choices) {
	// Can't use in_array() because we need to be case-insensitive.
	if (isset($choices) && gettype($choices) == 'array')
		foreach ($choices as $c)
			if (strtolower($v) == strtolower($c))
				return true;
	return false;
}

function convert_to_mysql_value($field, $type, $v, &$vcvt, &$msg, $choices = null, $required = false) {
	if (isset($v))
		$v = trim($v);
	switch ($type) {
	case 'm':
		// Strip \r; replace \n with genuine newline.
		$v = str_replace('\n', "\n", str_replace('\r', '', $v));
		// fall through
	case 't':
		if (!isset($v) || $v == '')
			if ($required) {
				$msg = "Required field \"$field\" is missing a value.";
				return false;
			}
			else {
				$vcvt = null;
				return true;
			}
		$vcvt = $v;
		return true;
	case 'y':
		$s = strtolower(nvl($v, ''));
		if ($s == '') {
			if ($required) {
				$msg = "Required field \"$field\" is missing a value.";
				return false;
			}
			else {
				$vcvt = null;
				return true;
			}
		}
		switch ($s) {
		case 't':
		case 'true':
		case '.true.':
		case '.t.':
		case 'y':
		case 'yes':
		case 'on':
		case '1':
			$vcvt = 1;
			return true;
		case 'f':
		case 'false':
		case '.false.':
		case '.f.':
		case 'n':
		case 'no':
		case 'off':
		case '0':
			$vcvt = 0;
			return true;
		}
		$msg = "Invalid YesNo value for field \"$field\": $v";
		return false;
	case 'n':
	case 'f':
		if (!isset($v) || $v == '') {
			if ($required) {
				$msg = "Required field \"$field\" is missing a value.";
				return false;
			}
			else {
				$vcvt = null;
				return true;
			}
		}
		if (is_numeric($v)) {
			$vcvt = $v;
			return true;
		}
		$msg = "Invalid numeric value for field \"$field\": $v";
		return false;
	case 'd':
		if (empty($v)) {
			if ($required) {
				$msg = "Required field \"$field\" is missing a value.";
				return false;
			}
			else {
				$vcvt = null;
				return true;
			}
		}
		if (($vcvt = date_str_to_ISO8601($v)) !== false)
			return true;
		$msg = "Invalid DateTime value for field \"$field\": $v";
		return false;
	case 'c':
		if (!isset($v) || $v == '') {
			if ($required) {
				$msg = "Required field \"$field\" is missing a value.";
				return false;
			}
			else {
				$vcvt = null;
				return true;
			}
		}
		if (isset($choices) && valid_choice($v, $choices)) {
			$vcvt = $v;
			return true;
		}
		$msg = "Invalid choice value for field \"$field\": $v";
		return false;
	}
	return false;
}

function valid_number($v) {
	$v = trim($v);
	if (empty($v))
		return true;
	if ($v == '.')
		return false;
	return preg_match('/^-{0,1}\d*\.{0,1}\d*$/', $v);
}

function date_str_to_ISO8601($v) {
	$v = trim($v);
	if (empty($v))
		return null;
	if (preg_match('/^(\d{4})[-.\/](\d{2})[-.\/](\d{2})( (\d{1,2}):(\d{2})(:(\d{2})){0,1}){0,1}$/', $v, $matches)) { // 1000-01-01 to 9999-12-31
		$y = $matches[1];
		$m = $matches[2];
		$d = $matches[3];
		if ($y >= 1000 && $y <= 9999 && $m >= 1 && $m <= 12 && $d >= 1 && $d <= 31) {
			$dstr = "$y-$m-$d";
			$dateok = true;
		}
		if (isset($dateok)) {
			if (isset($matches[5])) {
				$h = $matches[5];
				$m = $matches[6];
				$s = (isset($matches[8]) ? $matches[8] : '00');
				if ($h >= 0 && $h <= 23 && $m >= 0 && $m <= 59 && $s >= 0 && $s <= 59) {
					$tstr = " $h:$m:$s";
					$timeok = true;
				}
			}
			else {
				$tstr = '';
				$timeok = true;
			}
		}
	}
	if (isset($dateok) && isset($timeok))
		return $dstr . $tstr;
	$v = strtolower($v);
	$month_map = array(
		'january' => 1,
		'jan' => 1,
		'february' => 2,
		'feb' => 2,
		'march' => 3,
		'mar' => 3,
		'april' => 4,
		'apr' => 4,
		'may' => 5,
		'may' => 5,
		'june' => 6,
		'jun' => 6,
		'july' => 7,
		'jul' => 7,
		'august' => 8,
		'aug' => 8,
		'september' => 9,
		'sep' => 9,
		'sept' => 9,
		'october' => 10,
		'oct' => 10,
		'november' => 11,
		'nov' => 11,
		'december' => 12,
		'dec' => 12
	);

	unset($y);
	unset($h);
	unset($dateok);
	unset($timeok);
	// YYYY-M-d hh:mm[:ss] where month is a word and day is 1 or 2 digits; seconds optional
	if (preg_match('/^(\d{4})[-.\/]([a-z]{3,9})[-.\/](\d{1,2})( +(\d{1,2}):(\d{2})(:(\d{2})){0,1}){0,1}$/', $v, $matches)) {
		$y = $matches[1];
		$mstr = $matches[2];
		$d = $matches[3];
	}
	else if (preg_match('/^(\d{1,2})[-.\/]([a-z]{3,9})[-.\/](\d{4})( +(\d{1,2}):(\d{2})(:(\d{2})){0,1}){0,1}$/', $v, $matches)) {
		$d = $matches[1];
		$mstr = $matches[2];
		$y = $matches[3];
	}
	// m/d/y also allowed (no time)
	// 4-digit year
	else if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $v, $matches)) {
		$m = $matches[1];
		$d = $matches[2];
		$y = $matches[3];
	}
	// 2-digit year
	else if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{2})$/', $v, $matches)) {
		$m = $matches[1];
		$d = $matches[2];
		$y = $matches[3] + 1900;
		if ($y <= 1930)
			$y += 100;
	}
	if (isset($y)) {
		$d = str_pad($d, 2, '0', STR_PAD_LEFT);
		if (isset($mstr) && isset($month_map[$mstr]))
			$m = str_pad($month_map[$mstr], 2, '0', STR_PAD_LEFT);
		if ($y >= 1000 && $y <= 9999 && $m >= 1 && $m <= 12 && $d >= 1 && $d <= 31) {
			$dstr = "$y-$m-$d";
			$dateok = true;
		}
		if (isset($dateok)) {
			if (isset($matches[5])) {
				$h = $matches[5];
				$m = $matches[6];
				$s = (isset($matches[8]) ? $matches[8] : '00');
				if ($h >= 0 && $h <= 23 && $m >= 0 && $m <= 59 && $s >= 0 && $s <= 59) {
					$tstr = " $h:$m:$s";
					$timeok = true;
				}
			}
			else {
				$tstr = '';
				$timeok = true;
			}
		}
	}
	if (isset($dateok) && isset($timeok))
		return $dstr . $tstr;
	return null;
}

function word_for_type_static($t) {
	switch ($t) {
	case 't':
		return 'Text';
	case 'm':
		return 'Memo';
	case 'y':
		return 'YesNo';
	case 'n':
		return 'Money';
	case 'f':
		return 'Number';
	case 'd':
		return 'DateTime';
	case 'c':
		return 'Choice';
	default:
		die("word_for_type_static -- bad type: " . $t);
	}
}

function get_field_names($table, $db_id = NULL) {
	if (!isset($db_id))
		$db_id = $_SESSION['APPDB']->db_id;
	$fields = array();
	$result = $_SESSION['APPDB']->dbmain->db_query_user(sprintf('select * from mb_field where db_id = %d and tbl = "%s" order by seq, field_id',
							    $db_id, $table));
	while ($row = mysql_fetch_assoc($result))
		$fields[] = $row['name'];
	return $fields;
}

function get_field_dict($table, $db_id = NULL, $get_ids = false) {
	if (!isset($table))
		die('get_field_dict() -- $table not set');
	if (!isset($db_id))
		$db_id = $_SESSION['APPDB']->db_id;
	$field_dict = array();
	$result = $_SESSION['APPDB']->dbmain->db_query_user(sprintf('select * from mb_field where db_id = %d and tbl = "%s" order by seq, field_id',
							    $db_id, $table));
	while ($row = mysql_fetch_assoc($result)) {
		if ($get_ids)
			$flist .= $row['field_id'] . ',';
		else
			$field_dict[$row['name']] = new Field($table, $row['name'], $row['type'], $row['cols'], $row['rows'],
			  split(', *', $row['choices']), $row['seq'], $row['req'], $row['field_id']);
	}
	return $field_dict;//$get_ids ? substr($flist, 0, strlen($flist) - 1) : $field_dict;
}

function get_name_from_id(&$field_dict, $id) {
	foreach ($field_dict as $fld)
		if ($fld->field_id == $id)
			return $fld->name;
	return '[' . $id . ']';
}

function get_fld_from_id(&$field_dict, $id) {
	foreach ($field_dict as $fld)
		if ($fld->field_id == $id)
			return $fld;
	return null;
}

function validate_field_name(&$frm, $name, $tag = '') {
	if (preg_match('/[\'"]/', $name)) {
		$frm->AddMessageError("Field name $tag may not contain quotes.");
		return false;
	}
	if (!preg_match('/^[A-Za-z0-9_]{1,20}$/', $name)) {
		$frm->AddMessageError("Field name $tag must be from 1 to 20 letters, digits, and underscores.");
		return false;
	}
	return true;
}

class View {
	var $field_dict, $view_id, $user_id, $name, $db_id, $table, $public, $fields, $order, $dir,
	  $filter_fields, $filter_compares, $filter_values, $filter_logop, $spec, $v1, $v2, $login;

	function View($db_id_arg, $table_arg = NULL) {
		$this->view_id = 0;
		$this->db_id = $db_id_arg;
		if (isset($table_arg))
			$this->set_table($table_arg);
	}

	function has_field($id)	{
		foreach ($this->fields as $fid)
			if ($fid == $id)
				return true;
		return false;
	}

	// Disadvantage of delete/insert is that ID keeps changing -- probably should be fixed.
	function store() {
		$_SESSION['APPDB']->dbmain->db_query("begin");
		if (isset($this->view_id))
			$_SESSION['APPDB']->dbmain->db_query_user(sprintf('delete from mb_view where view_id = %d and user_id = %d',
							  $this->view_id, $_SESSION['MUDBAG_USER']->user_id));
		$this->view_id = $_SESSION['APPDB']->dbmain->db_query_user(sprintf('insert into mb_view (user_id, db_id, tbl, name, public, spec, v1, v2) values ' .
		                                  '(%d, %d, "%s", "%s", %d, "%s", "%s", "%s")',
		                                   $_SESSION['MUDBAG_USER']->user_id, $this->db_id, $this->table, $this->name, $this->public ? 1 : 0, $this->spec, $this->v1, $this->v2));
		// WARNING: If you make the above conditional, need to call mysql_errno() to see if an error was generated.
		// And then make sure the caller can get the number and msg, not clobbered by rollback.
		$_SESSION['APPDB']->dbmain->db_query("commit");
	}

	function set_table($table) {
		$this->table = $table;
		$this->field_dict = get_field_dict($this->table, $this->db_id);
	}

	function unique_name() {
		$result = $_SESSION['APPDB']->dbmain->db_query_user(sprintf('select view_id from mb_view where name = "%s" and view_id <> %d',
									$this->name, $this->view_id));
		return mysql_num_rows($result) == 0;
	}

	function load_by_id($id, $name = null) {
		if (isset($name)) {
			$result = $_SESSION['APPDB']->dbmain->db_query_user("select * from mb_view where name = '$name'");
		}
		else {
			$this->view_id = $id;
			$result = $_SESSION['APPDB']->dbmain->db_query_user("select * from mb_view where view_id = $this->view_id");
		}
		if (mysql_num_rows($result) != 1)
			return false;
		$row = mysql_fetch_assoc($result);
		if (isset($name))
			$this->view_id = $row['view_id'];
		$this->user_id = $row['user_id'];
		// wondering where this is used -- inconvenient to get
//		$this->login = $row['login'];
unset($this->login); // should generate notice at some point if it's used
		$this->public = $row['public'];
		$this->set_table($row['tbl']);
		$this->from_spec($row['spec'], $row['v1'], $row['v2']);
		return true;
	}

	function load_by_name($name) {
		return $this->load_by_id(null, $name);
	}

	function make_temp($table) {
		$this->set_table($table);
		unset($this->fields);
		if (isset($this->field_dict))
			foreach ($this->field_dict as $fld)
				$this->fields[] = $fld->field_id;
	}

	function from_spec($spec, $v1, $v2) {
		$this->spec = $spec;
		$this->v1 = $v1;
		$this->v2 = $v2;
		unset($this->fields);
		unset($this->order);
		unset($this->dir);
		unset($this->filter_fields);
		unset($this->filter_compares);
		unset($this->filter_values);
		$part = explode(":", $spec, 2);
		$x = explode(";", $part[0]);
		$this->name = $x[0];
		$this->public = $x[1] == 'true';
		$sec = explode(";", $part[1], 3);
		$this->fields = explode(',', $sec[0]);
		$x = explode(",", $sec[1]);
		for ($i = 0; $i < count($x); $i += 2) {
			if ($x[$i] <= 0)
				continue;
			$this->order[] = $x[$i];
			$this->dir[] = $x[$i + 1];
		}
		$x = explode(",", $sec[2]);
		$cnt = count($x);
		for ($i = 0; $i < $cnt - 1; $i += 2) {
			if ($x[$i] <= 0)
				continue;
			$this->filter_fields[] = $x[$i];
			$this->filter_compares[] = $x[$i + 1];
			$s = $this->filter_values[] = ($i == 0 ? $v1 : $v2);
		}
		$this->filter_logop = ($x[$cnt - 1] == 'true' ? 'and' : 'or');
	}

	function build_select($skip = 0, $limit = -1) {
		global $want_db_query_echo;

		//$want_db_query_echo = true;

		if ($this->db_id != $_SESSION['APPDB']->db_id)
			die("View:build_select can't handle non-current DBs.");
		if (empty($this->field_dict))
			return null; // could be no fields
		$s = 'select ';
		if ($limit != -1)
			$s .= ' SQL_CALC_FOUND_ROWS ';
		$s .= ' _rowID ';
		if (!empty($this->fields)) {
			$fi = 0;
			for ($i = 0; $i < count($this->fields); $i++) {
				if ($this->fields[$i] == 0) {
					$s .= ', ';
					$s .= '_rowID';
				}
				else {
					$nm = get_name_from_id($this->field_dict, $this->fields[$i]);
					if ($nm{0} != '[') {
						$s .= ', ';
						$s .= $nm;
						$fi++;
					}
				}
			}
			if ($fi == 0)
				return null; // only _rowID
		}
		$s .= ' from ' . $_SESSION['APPDB']->internal_name($this->table);
		if (isset($this->filter_fields)) {
			$fi = 0;
			for ($i = 0; $i < count($this->filter_fields); $i++) {
				if ($this->filter_fields[$i] <= 0)
					break;
				if ($fi == 1)
					$s .= ' ' . $this->filter_logop . ' ';
				$nm = get_name_from_id($this->field_dict, $this->filter_fields[$i]);
				if ($nm{0} != '[') {
					if ($fi == 0)
						$s .= ' where ';
					$s .= "($nm " .
					  $this->filter_compares[$i] . ' "' . mysql_real_escape_string ($this->filter_values[$i]) . '")';
					$fi++;
				}
			}
		}
		$fi = 0;
		if (isset($this->order)) {
			for ($i = 0; $i < count($this->order); $i++) {
				$nm = get_name_from_id($this->field_dict, $this->order[$i]);
				if ($nm{0} != '[') {
					if ($fi == 0)
						$s .= ' order by ';
					else
						$s .= ', ';
					$s .= "$nm {$this->dir[$i]}";
					$fi++;
				}
			}
		}
		if ($fi == 0)
			$s .= " order by _rowID ";
		$s .= " limit $skip, $limit";
		return $s;
	}

	function dump() {
		echo '<p>name: ' . $this->name;

		for ($i = 0; $i < count($this->fields); $i++) {
			echo '<br>fields ' . $i . ': ' . get_name_from_id($this->field_dict, $this->fields[$i]);
		}
		for ($i = 0; $i < count($this->order); $i++) {
			echo '<br>order ' . $i . ': ' . get_name_from_id($this->field_dict, $this->order[$i]) . ' ' . $this->dir[$i];
		}
		for ($i = 0; $i < count($this->filter_fields); $i++) {
			if ($i == 1)
				echo '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $this->filter_logop;
			echo '<br>expr ' . $i . ': ' . get_name_from_id($this->field_dict, $this->filter_fields[$i]) . ' ' .
			  $this->filter_compares[$i] . ' ' . $this->filter_values[$i];
		}
	}
}

function load_new_view($id) {
	$v = new View($_SESSION['APPDB']->db_id);
	if (isset($v))
		$v->load_by_id($id);
	return $v;
}
?>
