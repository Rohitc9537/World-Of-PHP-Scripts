<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_report_block.php,v 1.1.1.1 2005/07/13 00:22:04 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require('mbcl_reportspec.php');
	require('mb_report_util.php');

	// There's a provision here to allow user to select any report of the given type to modify
	// it, or to define a new one, but this is more complicated than it needs to be and different
	// from how views are saved. So, if WANT_SELECT is false, the drop-down to select a report and
	// the associated Save button are suppressed.
	define('WANT_SELECT', false);

	$names = array('t' => 'Tabular', 'r' => 'Record', 'l' => 'Label', 'f' => 'Form Letter', 'm' => 'Email');

	class MB_ReportBlock extends MB_DBScreen {

		var $name;
		var $spec;
		var $generate = false;
		var $action_only = false;

		function MB_ReportBlock($type, &$spec_name) {
			global $names;

			parent::MB_DBScreen();
			if (!isset($_SESSION['mb_report_spec']) || !isset($spec_name) || $_SESSION['mb_report_spec']->spec_name != $spec_name)
				$_SESSION['mb_report_spec'] = new MB_ReportBlockSpec($type, $spec_name);
			$this->spec = &$_SESSION['mb_report_spec'];
			$this->name = &$names[$this->spec->type];
			if (!isset($this->name))
				$this->name = $this->spec->type;
		}

		function Callback($tag) {
			if (isset($_POST['mbfv_tableview']) && $_POST['mbfv_tableview']{0} != 'x') {
				if (isset($_POST['mbfv_spec_name']))
					$this->spec->spec_name = $_POST['mbfv_spec_name'];
				$this->spec->show_lines = nvl($_POST['mbfv_show_lines']);
				$this->spec->one_page = nvl($_POST['mbfv_one_page']);
				$this->spec->is_table = $_POST['mbfv_tableview']{0} == 't';
				$this->spec->tableview_name = substr($_POST['mbfv_tableview'], 2);
				$this->spec->label_code = $_POST['mbfv_code'];
				$this->spec->template = stripslashes(trim(nvl($_POST['mbfv_template'])));
			}
			switch ($tag) {
			case "btn_GetFields":
				$this->LoadTable();
				break;
			case "btn_SaveReport":
				$this->Generate(true);
				break;
			case "btn_Generate":
				$this->Generate();
				break;
			case "btn_Test":
				$this->Test();
				break;
			case "btn_Send":
				$this->Send();
				break;
			default:
				parent::Callback($tag);
			}
		}

		function LoadTable() {
			$this->spec->SetTable();
			switch ($this->spec->type) {
			case 'l':
				$this->spec->template = '';
				$count = 0;
				foreach ($this->spec->fields as $f) {
					if ($count++ % 3 == 0)
						$this->spec->template .= "\n";
					else
						$this->spec->template .= " ";
					$this->spec->template .= "{" . $f->name . "}";
				}
				$this->spec->template = substr($this->spec->template, 1);
				break;
			case 'r':
				$this->spec->template = '';
				foreach ($this->spec->fields as $f)
					$this->spec->template .= "$f->name{tab}{" . $f->name . "}\n";
				break;
			case 'm':
				if (count($this->spec->fields) > 0) {
					$fname_email = '';
					foreach ($this->spec->fields as $f)
						if (stristr($f->name, 'email')) {
							$fname_email = $f->name;
							break;
						}
					$this->spec->template = "To: {" . $fname_email . "}\nSubject: Type subject here\n\nReplace this sentence with the email message, using any of the fields below.\n";
					foreach ($this->spec->fields as $f)
						if ($f->name != $fname_email)
							$this->spec->template .= "{" . $f->name . "}\n";
					$this->spec->template .= "\nThis email was sent with Mudbag (www.mudbag.com, where you can build your own database for free).";
				}
				break;
			case 't':
				// Tabular reports are handled differently.
				break;
			}
		}

		function Test() {
			if (!isset($_GET['test']) && !isset($_GET['send'])) {
				if (empty($_POST['mbfv_template'])) {
					$this->AddMessageError("Choose a table or view.");
					return;
				}
				if (!empty($this->spec->spec_name))
					$this->SaveSpec($this->spec->spec_name);
			}
			if (empty($_SESSION['MUDBAG_USER']->email))
				$this->AddMessageError("Can't run test because you have no email address defined.
				  Press the Account button (at the top) to set one.");
			else if (!($result = report_query_tableview($this->spec, $errmsg)))
				$this->AddMessageError($errmsg);
			else if ($row = mysql_fetch_assoc($result))
				if (report_send_email($this->spec, $row, $_SESSION['MUDBAG_USER']->email))
					$this->AddMessageConfirmation("Email sent successfully.");
				else
					$this->AddMessageError("Failed to send email.");

			else
				$this->AddMessageError("No rows were retrieved. Make sure the table has data.");
		}

		function Send() {
			if (!isset($_GET['test']) && !isset($_GET['send'])) {
				if (empty($_POST['mbfv_template'])) {
					$this->AddMessageError("Choose a table or view.");
					return;
				}
				if (!empty($this->spec->spec_name))
					$this->SaveSpec($this->spec->spec_name);
			}
			if (!($result = report_query_tableview($this->spec, $errmsg)))
				$this->AddMessageError($errmsg);
			else if (mysql_num_rows($result) < 1)
				$this->AddMessageError("No rows were retrieved. Make sure the table has data.");
			else {
				$sent_ok = $sent_bad = 0;
				$oversend_msg = '';
				$count = 0;
				while ($row = mysql_fetch_assoc($result)) {
					if (report_send_email($this->spec, $row))
						$sent_ok++;
					else
						$sent_bad++;
					if (++$count >= MB_EMAIL_LIMIT) {
						$oversend_msg = " (Reached limit of " . MB_EMAIL_LIMIT . " emails per send.)";
						break;
					}
				}
				if ($sent_bad == 0)
					$this->AddMessageConfirmation("All $sent_ok emails sent successfully.$oversend_msg");
				else
					$this->AddMessageError("Failed to send $sent_bad emails; $sent_ok sent successfully.$oversend_msg");
			}
		}

		function Generate($save_only = false) {
			if ($this->spec->type == 't' && !isset($_POST['mbfv_field_select'])) {
				$this->AddMessageError("Choose a table or view that has at least one field.");
				return;
			}
			if (($this->spec->type == 'r' || $this->spec->type == 'l' || $this->spec->type == 'm') && empty($_POST['mbfv_template'])) {
				$this->AddMessageError("Choose a table or view.");
				return;
			}
			if (isset($_POST['mbfv_spec_name']))
				$this->spec->spec_name = $_POST['mbfv_spec_name'];
			$this->spec->is_public = isset($_POST['mbfv_public']);
			if (isset($_POST['mbfv_specstring'])) {
				$this->spec->specstring = stripslashes($_POST['mbfv_specstring']);
				$this->spec->template = stripslashes($_POST['mbfv_template']);
				$this->spec->parse_specstring($this->spec->specstring);
			}
			$spec_name_len = strlen($this->spec->spec_name);
			if ($spec_name_len > 20 || ($spec_name_len == 0 && $save_only)) {
				$this->AddMessageError("Report name must be from 1 to 20 characters.");
				return;
			}
			if (strtoupper($this->spec->spec_name) == 'DEFAULT') {
				$this->AddMessageError("Report can't be named \"Default\".");
				return;
			}
			if ($spec_name_len == 0 || $this->SaveSpec($this->spec->spec_name)) {
				if (!$save_only)
					$this->generate = true;
			}
		}

		function ShowForm() {
			if ($this->action_only)
				return;
			require("js-reorder.php");
			require("js-listchoose.php");
			echo <<<EOT
				<script language="JavaScript">

					var fields = new Array();

					function Field(name, width, alignment, heading) {
						this.name = name;
						this.width = width;
						this.alignment = alignment;
						this.heading = heading;
					}

					function fix_model(obj) { // called when order in <select> changes
						var fields_new = new Array();
						for (var i = 0; i < obj.options.length; i++)
							fields_new[i] = fields[obj.options[i].value];
						fields = fields_new;
						for (i = 0; i < obj.options.length; i++)
							obj.options[i].value = i;
					}

					function field_set_options_list(obj, do_select) {
						for (var i = 0; i < fields.length; i++) {
							var f = fields[i];
							// using innerHTML on next line instead of text causes IE 5.2.2 on OS X to hang
							obj.options[i].text = f.name + "  (" + f.width + ", " + f.alignment + ", \"" +
							  ellipses(f.heading) + "\")";
						}
						obj.focus(); // because without it Safari doesn't update select
						if (do_select && fields.length > 0)
							field_selected(obj);
					}

					function ellipses(s) {
						if (s.length > 15)
							return s.substr(0, 15) + '...';
						return s;
					}

					function field_get_data(frm) {
						var n = frm.mbfv_field_number.value
						fields[n].width = frm.mbfv_field_width.value;
						fields[n].heading = remove_special(frm.mbfv_field_heading.value);
						switch (frm.mbfv_field_alignment.selectedIndex) {
						case 0:
							fields[n].alignment = 'L';
							break;
						case 1:
							fields[n].alignment = 'C';
							break;
						case 2:
							fields[n].alignment = 'R';
						}
						field_set_options_list(frm.mbfv_field_select, false);
					}

					function remove_special(s) {
						s = s.replace(/[~`]/g, '');
						return s.replace(/"/g, "'");
					}

					function field_selected(obj) {
						if (obj.selectedIndex < 0)
							obj.selectedIndex = 0;
						var n = obj.options[obj.selectedIndex].value;
						obj.form.mbfv_field_number.value = n;
						//obj.form.mbfv_field_name.value = fields[n].name;
						document.getElementById('mbfv_field_name_id').innerHTML = fields[n].name;
						obj.form.mbfv_field_heading.value = fields[n].heading;
						obj.form.mbfv_field_width.value = fields[n].width;
						switch (fields[n].alignment) {
						case 'L':
							obj.form.mbfv_field_alignment.selectedIndex = 0;
							break;
						case 'C':
							obj.form.mbfv_field_alignment.selectedIndex = 1;
							break;
						case 'R':
							obj.form.mbfv_field_alignment.selectedIndex = 2;
						}
					}

					function tableview_selected(obj) {
						var x = document.getElementById('mbfv_tableview_changed_id');
						x.value = true;
						obj.form.submit();
					}

					function build_specstring(frm) {
						var s = get_layout_spec(frm);
						for (var i = 0; i < fields.length; i++) {
							var f = fields[i];
							s += "~" + f.name + "`" + f.width + "`" + f.alignment + "`" +
							  f.heading;
						}
						frm.mbfv_specstring.value = s;
					}

					function get_layout_spec(frm) {
						return (frm.mbfv_col_gap != null ? frm.mbfv_col_gap.value : '') + '`' +
						  (frm.mbfv_row_gap != null ? frm.mbfv_row_gap.value : '') + '`' +
						  (frm.mbfv_col_rules != null ? frm.mbfv_col_rules.checked : '') + '`' +
						  (frm.mbfv_row_rules != null ? frm.mbfv_row_rules.checked : '') + '`' +
						  frm.mbfv_font_family.value + '`' +
						  frm.mbfv_font_size.value + '`' +
						  (frm.mbfv_orientation != null ? frm.mbfv_orientation.value : '') + '`' +
						  (frm.mbfv_paper_size != null ? frm.mbfv_paper_size.value : '') + '`' +
						  (frm.mbfv_rec_per_page != null ? frm.mbfv_rec_per_page.checked : '') + '`' +
						  (frm.mbfv_hdr_pgnums != null ? frm.mbfv_hdr_pgnums.checked : '') + '`' +
						  (frm.mbfv_hdr_date != null ? frm.mbfv_hdr_date.checked : '') + '`' +
						  (frm.mbfv_title != null ? remove_special(frm.mbfv_title.value) : '');
					}

					function onLoad_handler(frm) {
						set_clean();
//						if (frm.mbfv_field_select != null)
//							field_set_options_list(frm.mbfv_field_select, true);
					}

				</script>
EOT;
			if ($this->generate) {
				echo <<<EOT
					<script language="JavaScript">

						pdf_window('mb_report_generate.php', '{$_SESSION["MUDBAG_USER"]->os}');

					</script>
EOT;
				$this->MessageInfo("The report (as a PDF) should appear in a separate window. Click " .
				  $this->HelpLink("here", "helpctx_mb_report~lnk_no_pdf") . " if it doesn't appear.");
				echo "<p>";
			}
			switch ($this->spec->type) {
			case 'l':
			case 'r':
			case 't':
			case 'm':
				$this->ShowFormForType($this->spec->type);
				break;
			default:
				echo "<p>Can't do a {$this->spec->type} report yet.";
			}
		}

		function ShowFormForType($type) {
			echo "<input type='hidden' name='mbfv_button[btn_GetFields]' id='mbfv_tableview_changed_id'>"; // used to indicate that tableview changed
			echo "<input type='hidden' name='mbfv_specstring'>";
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Name this report if you want to save it." .
			  (WANT_SELECT ?
			  ("Or, choose an existing report from the drop-down.
			  For more on saving reports, click " .
			  $this->HelpLink("here", "helpctx_mb_report~lnk_report_spec") . ".")
			  : ""));
			$result = $this->dbmain->db_query_user("select name from mb_reportspec
			  where type = '{$this->spec->type}' and db_id = {$_SESSION['APPDB']->db_id} order by name");

			echo "<table cellspacing='0' cellpadding='0'><tr><td>";
				if (WANT_SELECT) {
					$this->FieldLabel("Report", false);
					echo "<select name='mbfv_spec' onchange=\"window.location='mb_report_block.php?type={$this->spec->type}&spec=' + this.value\">";
					echo "<option value='Default'>New</option>";
					unset($selected);
					while ($row = mysql_fetch_assoc($result)) {
						if ($row['name'] == $this->spec->spec_name) {
							$existing_report = true;
							$selected = " selected ";
						}
						else
							$selected = "";
						echo "<option value=\"{$row['name']}\" $selected>{$row['name']}</option>";
					}
					echo "</select>";
					echo "</td><td>&nbsp;&nbsp;</td><td>";
				}
				$this->FieldLabel("Name", false);
				if ($this->spec->spec_name == 'Default')
					$sn = '';
				else
					$sn = $this->spec->spec_name;
				echo "<input type='text' size='20' value='$sn' name='mbfv_spec_name'" . (isset($existing_report) ? " disabled " : "") . ">";
				echo "</td><td>&nbsp;&nbsp;</td><td>";
				if (WANT_SELECT) {
					echo "</td><td>&nbsp;&nbsp;</td><td>";
					$this->Button("btn_SaveReport", "Save", null, null, "build_specstring(this.form);");
				}

			echo "</td></tr></table>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("If you want this report to be seen by all users of this
				  database, check the box. Otherwise, only you will see the report.");
				$this->FieldLabel("Public");
				echo "<input type='checkbox' name='mbfv_public'" . ($this->spec->is_public ? ' checked ' : '') . " onChange='set_dirty();'>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Choose a table or view from which to take the data.");
			$this->FieldLabel("Table or View", true);
			$this->dbapp->ShowTableViewSelect("mbfv_tableview", ($this->spec->is_table ? "t-" : "v-") . $this->spec->tableview_name,
			  true, "Choose Table or View", "tableview_selected(this)");
			$tbl->FormCellEnd();

			if ($type == 't') {
				$tbl->FormCellBegin("Each field is listed, one per column. In parentheses are
				  the width, alignment, and heading. Click on a field to change it.<p>Enter a zero for the width
				  to skip the field entirely. Use the up/down arrows to change the field order.");
				$this->FieldLabel("Fields", true);

				echo "<table cellspacing='0' cellpadding='0'><tr><td>";
					echo "<select size='8' name='mbfv_field_select'
					  onchange='btn_enable_chooser(this.form, null, this); field_selected(this);' class='select1'>";
					$fnum = 0;
					if (isset($this->spec->fields))
						foreach ($this->spec->fields as $f) {
							echo "<option value='$fnum'></option>";
							echo <<<EOT
								<script language="JavaScript">
								fields[$fnum] = new Field('$f->name', $f->width, '$f->alignment', "$f->heading");
								</script>
EOT;
							$fnum++;
						}
					echo "</select>";

				echo "</td>";
				echo "<td align='right' valign='center' width='40'>";
					//echo "&nbsp;&nbsp;";
					echo "<input type='button' name='btn_up' value='&uarr;' disabled
					  onclick='set_dirty(); move(this.form, mbfv_field_select, -1); fix_model(mbfv_field_select);'>";
					//echo "<button name='btn_up' disabled
					//  onclick='set_dirty(); move(this.form, mbfv_field_select, -1);fix_model(mbfv_field_select);'
					//  class='arrow_button'>";
					//echo "<img src='images/arrow-up.gif'>";
					//echo "</button>";
					echo "<br>&nbsp;<br>";
					//echo "&nbsp;&nbsp;";
					echo "<input type='button' name='btn_down' value='&darr;' disabled
					  onclick='set_dirty(); move(this.form, mbfv_field_select, 1); fix_model(mbfv_field_select);'>";
					//echo "<button name='btn_down' disabled
					//  onclick='set_dirty(); move(this.form, mbfv_field_select, 1);fix_model(mbfv_field_select);'
					//  class='arrow_button'>";
					//echo "<img src='images/arrow-dn.gif'>";
					//echo "</button>";
				echo "</td></tr></table>";

				echo "<input type='hidden' name='mbfv_field_number'>";
				echo "<p>";
				$this->FieldLabel("Field Name: ", false, false, false);
				echo "<b><span id='mbfv_field_name_id'></span></b>";
				//echo "<input type='text' name='mbfv_field_name' disabled size='20'>";
				echo "<p>";
				echo "<table cellspacing='0' cellpadding='0'><tr><td>";
					$this->FieldLabel("Width");
					echo "<input type='text' name='mbfv_field_width' size='3' onBlur='field_get_data(this.form);'
					  onkeypress='set_dirty(); return numeric_only(event);'>";
				echo "</td><td>&nbsp;&nbsp;</td><td>";
					$this->FieldLabel("Alignment", false, true, false);
					echo "<select name='mbfv_field_alignment' onChange='set_dirty(); field_get_data(this.form);'>";
					echo "<option value='L' " . /*($f->alignment == 'L' ? " selected " : "") .*/ ">Left</option>";
					echo "<option value='C' " . /*($f->alignment == 'C' ? " selected " : "") .*/ ">Center</option>";
					echo "<option value='R' " . /*($f->alignment == 'R' ? " selected " : "") .*/ ">Right</option>";
					echo "</select>";
				echo "</td><td>&nbsp;&nbsp;</td><td>";
					$this->FieldLabel("Heading", false, true, false);
					echo "<input type='text' name='mbfv_field_heading' size='30'
					   onkeypress='set_dirty();' onBlur='field_get_data(this.form);'>";
				echo "</td></tr></table>";
				echo <<<EOT
					<script language="JavaScript">
					field_set_options_list(document.forms[0].mbfv_field_select, true);
					btn_enable_chooser(document.forms[0], null, document.forms[0].mbfv_field_select);
					</script>
EOT;
				$tbl->FormCellEnd();
			}
			else {
				$tbl->FormCellBegin("This is the template that will be used for each record.
				  A field name in curly braces will be replaced by that field's value. " .
				  ($type == 'r' ? "The special field <i>{tab}</i> inserts a tab. " : "") .
				  "Text not in curly braces will appear literally in the output.");
				$this->FieldLabel("Template", true);
				echo "<textarea rows='6' cols='60' name='mbfv_template' onChange='set_dirty();'>" . /*stripslashes*/($this->spec->template) . "</textarea>";
				$tbl->FormCellEnd();
			}

			if ($type == 'l') {
				$tbl->FormCellBegin("Choose the label layout.");
				$this->FieldLabel("Label Code", true);
				$result = $this->dbmain->db_query("select vendor, code, number_horz, number_vert, width, height, units, also from " . $this->dbapp->internal_name_admin("LabelSizes") .
				  " order by code");
				echo "<select name='mbfv_code' onChange='set_dirty();'>";
				while ($row = mysql_fetch_assoc($result)) {
					if ($row['vendor'] == "_mb_")
						continue;
					if (empty($row['vendor']))
						$v = "Avery";
					else
						$v = $row['vendor'];
					$c = "$v {$row['code']}   ({$row['number_horz']} cols, {$row['number_vert']} rows, {$row['height']}{$row['units']} x {$row['width']}{$row['units']})";
					if (!empty($row['also']))
						$c .= " (also {$row['also']})";
					$sel = ($row['code'] == $this->spec->label_code ? " selected " : "");
					echo "<option value='{$row['code']}' $sel>$c</option>";
				}
				echo "</select>";
				$tbl->FormCellEnd();
			}
			else
				echo "<input type='hidden' name='mbfv_code' value='record_report'>";

			if ($type != 'm') {
				if ($type == 'l')
					$tbl->FormCellBegin("Choose the font and size.");
				else
					$tbl->FormCellBegin("Enter a title for the report and, if you want, modify the layout.");
				if ($type != 'l') {
					echo "<table cellspacing='0' cellpadding='0'><tr><td>";
						$this->FieldLabel("Title");
						echo "<input type='text' name='mbfv_title' size='40' value=\"" . /*stripslashes*/($this->spec->title) . "\" onChange='set_dirty();'>";
					echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("Date in Header");
						$checked = ($this->spec->hdr_date ? " checked " : "");
						echo "<input type='checkbox' name='mbfv_hdr_date' $checked onChange='set_dirty();'>";
					echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("Page Numbers in Header");
						$checked = ($this->spec->hdr_pgnums ? " checked " : "");
						echo "<input type='checkbox' name='mbfv_hdr_pgnums' $checked onChange='set_dirty();'>";
					echo "</td></tr></table>";
					echo "<table cellspacing='0' cellpadding='0'><tr><td>";
						$this->FieldLabel("Column Gap");
						echo "<input type='text' name='mbfv_col_gap' size='2' value='{$this->spec->col_gap}'
						  onkeypress='return numeric_only(event);' onChange='set_dirty();'>";
					echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("Column Rules");
						$checked = ($this->spec->col_rules ? " checked " : "");
						echo "<input type='checkbox' name='mbfv_col_rules' $checked onChange='set_dirty();'>";
					echo "</td><td>&nbsp;&nbsp;</td><td>";
						$this->FieldLabel("Row Gap");
						echo "<input type='text' name='mbfv_row_gap' size='2' value='{$this->spec->row_gap}'
						  onkeypress='return numeric_only(event);' onChange='set_dirty();'>";
					echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("Row Rules");
						$checked = ($this->spec->row_rules ? " checked " : "");
						echo "<input type='checkbox' name='mbfv_row_rules' $checked onChange='set_dirty();'>";
					echo "</td></tr></table>";
				}
				echo "<table cellspacing='0' cellpadding='0'><tr><td>";
					$this->FieldLabel("Font");
					echo "<select name='mbfv_font_family' onChange='set_dirty();'>";
					echo "<option value='Helvetica'" . ($this->spec->font_family == 'Helvetica' ? " selected " : "") . ">Helvetica/Arial</option>";
					echo "<option value='Times'" . ($this->spec->font_family == 'Times' ? " selected " : "") . ">Times</option>";
					echo "<option value='Courier'" . ($this->spec->font_family == 'Courier' ? " selected " : "") . ">Courier</option>";
					echo "</select>";
				echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
					$this->FieldLabel("Size");
					echo "<input type='text' name='mbfv_font_size' size='2' value='{$this->spec->font_size}'
					  onkeypress='return numeric_only(event);' onChange='set_dirty();'>";
				echo "</td></tr></table>";
				if ($type != 'l') {
					echo "<table cellspacing='0' cellpadding='0'><tr><td>";
						$this->FieldLabel("Orientation");
						echo "<select name='mbfv_orientation' onChange='set_dirty();'>";
						echo "<option value='P'" . ($this->spec->orientation == 'P' ? " selected " : "") . ">Portrait</option>";
						echo "<option value='L'" . ($this->spec->orientation == 'L' ? " selected " : "") . ">Landscape</option>";
						echo "</select>";
					echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("Paper Size");
						echo "<select name='mbfv_paper_size' onChange='set_dirty();'>";
						echo "<option value='Letter'" . ($this->spec->paper_size == 'Letter' ? " selected " : "") . ">Letter</option>";
						echo "<option value='Legal'" . ($this->spec->paper_size == 'Legal' ? " selected " : "") . ">Legal</option>";
						echo "<option value='A3'" . ($this->spec->paper_size == 'A3' ? " selected " : "") . ">A3</option>";
						echo "<option value='A4'" . ($this->spec->paper_size == 'A4' ? " selected " : "") . ">A4</option>";
						echo "<option value='A5'" . ($this->spec->paper_size == 'A5' ? " selected " : "") . ">A5</option>";
						echo "</select>";
					if ($type == 'r') {
						echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
						$this->FieldLabel("One Record Per Page");
						$checked = ($this->spec->rec_per_page ? " checked " : "");
						echo "<input type='checkbox' name='mbfv_rec_per_page' $checked onChange='set_dirty();'>";
					}
					echo "</td></tr></table>";
				}
				$tbl->FormCellEnd();
			}

			if ($type != 'm') {
				$tbl->FormCellBegin("Indicate whether you want outlines to show and whether you want to see just a one-page preview.");
				echo "<table cellspacing='0' cellpadding='0'><tr><td align='center'>";
					$this->FieldLabel($type == 'l' ? "Show Label Outlines" : "Show Page Outlines");
					$checked = ($this->spec->show_lines ? " checked " : "");
					echo "<input type='checkbox' name='mbfv_show_lines' $checked onChange='set_dirty();'>";
				echo "</td><td>&nbsp;&nbsp;</td><td align='center'>";
					$this->FieldLabel("One-Page Preview");
					$checked = ($this->spec->one_page ? " checked " : "");
					echo "<input type='checkbox' name='mbfv_one_page' $checked onChange='set_dirty();'>";
				echo "</td></tr></table>";
				$tbl->FormCellEnd();
			}

			if ($type == 'm') {
				$tbl->FormCellBegin("Press one of the buttons.");
				$this->Button("btn_Generate", "Preview in PDF", null, null, "build_specstring(this.form);");
				$this->ButtonSpaced("btn_Test", "Test Send", null, null, "build_specstring(this.form);");
				$this->ButtonSpaced("btn_Send", "Real Send", null, null, "build_specstring(this.form);");
			}
			else {
				$tbl->FormCellBegin("Press the <i>Generate/Save</i> button to save the report (if you've named it) and generate the PDF.");
				$this->Button("btn_Generate", "Generate/Save", null, null, "build_specstring(this.form);");
			}
			$this->ButtonSpaced(null, "Back to Reports Page", "mb_report.php");
			$tbl->FormCellEnd();
			$tbl->End();
		}

		function SaveSpec($spec_name) {
			if ($success = $this->spec->Save($this, $spec_name))
				$this->AddMessageConfirmation("Report saved.");
			return $success;
		}
	}

	// Original idea was that names for reports were only in mb_report.php, but this
	// proved unworkable.
	$frm = new MB_ReportBlock($type, $spec);
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right
//$frm->dbapp->build_std_tables(true);
	if (isset($test)) {
		$mbfv_button['btn_Test'] = true;
		$frm->action_only = true;
	}
	else if (isset($send)) {
		$mbfv_button['btn_Send'] = true;
		$frm->action_only = true;
	}
	$frm->Go(null, "$frm->name Report", "helpctx_mb_report~" . strtolower($frm->name), true);
?>
