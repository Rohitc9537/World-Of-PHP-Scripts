<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mail_sim_util.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

function mb_mail($to, $subject, $message, $additional_headers = null, $preview) {
	if (MB_MAIL_SIM || $preview) {
		$subject = str_replace("'", "\\'", str_replace("\\", "\\\\", $subject));
		$message = str_replace("'", "\\'", str_replace("\\", "\\\\", $message));
		$message = str_replace("\r", "\\r", $message);
		$message = str_replace("\n", "\\n", $message);
		echo <<<EOT
		<script language="JavaScript">


			function mail_window() {
				var w = window.open('mb_mail_sim.php?to=$to&subject=' + escape('$subject') +
				  '&message=' + escape('$message') + '&headers=' + escape('$additional_headers'),

				  'MudbagMailSim', 'width=800,height=600,resizable,scrollbars');

				w.focus();
			}

			mail_window();

		</script>
EOT;
		return true;
	}
	else
		return mail($to, $subject, $message, $additional_headers);
}

?>
