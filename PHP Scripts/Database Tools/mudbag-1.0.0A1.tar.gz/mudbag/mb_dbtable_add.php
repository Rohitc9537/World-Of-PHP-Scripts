<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable_add.php,v 1.1.1.1 2005/07/13 00:22:00 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	class MB_DBTableAdd extends MB_DBScreen {

		var $created;
		var $add_userlist;

		function MB_DBTableAdd() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			if ($tag == "add_button") {
				$this->created = true;
				$table = $_POST['table_nm'];
				if (!validate_dbtablename($table, $msg)) {
					$this->AddMessageError($msg);
					$this->created = false;
					return;
				}
				if ($this->created = $this->QueryAddMessageUser("create table {$this->dbapp->tblpfx}$table (_rowID int auto_increment primary key) type=MyISAM"))
					$this->SetActiveTable($table);
			}
		}

		function ShowForm() {
			if ($this->created) {
				$table = $_POST['table_nm'];
				$this->MessageConfirmation("Table \"$table\" has been added.");
				echo "<p>";
				echo "Press the button below to add fields to the new table.";
				echo "<p>";
				$this->Button(null, "Add Fields", "mb_dbfield.php?add=1");
			}
			else if (isset($this->add_userlist)) {
				echo "userlist add";
			}
			else {
				if (!check_limits($msg, 0, 1)) {
					$this->MessageError($msg);
					return;
				}
				$tbl = new MB_TableFormWithInstr();
				$tbl->Begin();
				$tbl->FormCellBegin("To add a table, type its name, which can be from 1 to 10 letters, digits, and underscores.");
				$nm = nvl($_POST['table_nm']);
				$this->FieldLabel("Table Name", true);
				echo "<input type=\"text\" name=\"table_nm\" value=\"$nm\">";
				$tbl->FormCellEnd();
				$tbl->FormCellBegin("Press the <i>Add</i> button to add the new table.");
				$this->Button("add_button", "Add");
				$this->ButtonSpaced(null, "Back to Database", "mb_dbmain.php");
				$tbl->FormCellEnd();
				$tbl->End();
			}
		}
	}

	$frm = new MB_DBTableAdd();
	$frm->SetActiveTable(null);
	unset($_SESSION['active_view_obj']);
	if (!db_isset())
		set_db($_GET['dbname'], $_GET['dblongname'], $_GET['db_id'], $_GET['role_id'], $_GET['owner']);
	if (isset($userlist)) {
		$frm->add_userlist = true;
		$hdg = 'Add UserList Table to Database "' . $_SESSION['APPDB']->dblongname . '" (owned by ' . $_SESSION['APPDB']->owner . ')';
	}
	else
		$hdg = 'Add Table to Database "' . $_SESSION['APPDB']->dblongname . '" (owned by ' . $_SESSION['APPDB']->owner . ')';
	$frm->Go(null/*array("Add UserList Table", "mb_dbtable_add.php?userlist=1")*/, $hdg, "helpctx_mb_dbtable_add");
?>
