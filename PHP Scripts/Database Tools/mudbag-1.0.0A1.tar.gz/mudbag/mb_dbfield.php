<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbfield.php,v 1.1.1.1 2005/07/13 00:21:59 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBField extends MB_DBScreen {

		var $another;
		var $add;
		var $saveok = false;
		var $saved_field_name;
		var $errors;
		var $cur_data;
		var $cancel_target = "mb_dbtable.php?edit=1";
		var $cancel_descr = "Table";

		function MB_DBField() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_SaveNew":
				$this->callback_action(true, false, false, false, false);
				break;
			case "btn_Save":
				$this->callback_action(false, false, false, true, false);
				break;
			case "btn_SaveNext":
				$this->callback_action(false, false, false, false, true);
				break;
			// Target for Next in button -- no callback for it.
//			case "btn_Next":
//				$this->callback_action(false, true, false, false, false);
//				break;
			case "btn_Delete":
				$this->callback_action(false, false, true, false, false);
			}
		}

		function callback_action($btn_SaveNew, $btn_Next, $btn_Delete, $btn_Save, $btn_SaveNext) {
			global $data, $want_db_query_echo;

			// Logic for btn_Next is here, but Next button doesn't result in a callback.

			unset($_SESSION['active_view_obj']); // view was based on old fields
			$data = $_POST['data'];
			$data['req'] = (nvl($data['req']) == 'on' ? 1 : 0);
			$data['choices'] = stripslashes(nvl($data['choices']));
			$data['name'] = stripslashes($data['name']);
			if (!$btn_Next && !$btn_Delete && !isset($_GET['force_delete']) && !$this->validate()) {
				$this->cur_data = &$data;
				//$data['choices'] = urlencode($data['choices']);
				//$_SESSION['bad_data'] = &$data;
				return;
//				if ($btn_SaveNew)
//					header("Location: db-field?add=1&errors=1");
//				else
//					header("Location: db-field?chg=1&errors=1");
//				exit();
			}
			$seq = 1; // not sure if we need/want this
			if ($btn_SaveNew) {
				$f = new Field($this->active_table);
				$f->put_array($data);
				if ($f->store_new($error_number, $error_msg)) {
					$this->another = true;
					$this->add = true;
					$this->saved_field_name = $f->name;
					$this->SetActiveField(null); // so it won't appear as a breadcrumb
					$this->saveok = true;
					$this->AddMessageConfirmation("Field \"$this->saved_field_name\" was saved successfully.");
				}
				else {
					$this->cur_data = &$data;
					if ($error_number == 1062)
						$this->AddMessageError("Duplicate field name. Please choose another name.");
					else
						$this->AddMessageError($error_msg);
				}
				return;
			}
			if (isset($_SESSION['active_fd']) && $this->active_field)
				$fld = &$_SESSION['active_fd'][$this->active_field];
			else
				die("mb_field.php -- {$_SESSION['active_fd']} and/or $this->active_field not set");
			if ($btn_Delete || isset($_GET['force_delete'])) { // confirmation now done in JavaScript
				$want_db_query_echo_save = $want_db_query_echo;
				$want_db_query_echo = false; // any output will prevent us from calling header()
				$fld->delete();
				$want_db_query_echo = $want_db_query_echo_save;
				$f = $this->active_field;
				$this->SetActiveField(null);
				header("Location: mb_dbtable.php?edit=1&deleteok=1&field_processed=$f");
			}
			else {
				if ($btn_Save || $btn_SaveNext) {
					$old_field_name = $fld->name;
//if ($fld->type != $data['type'])
//{echo "<br>**************type change***************";
//echo "{$fld->type}--{$data['type']}";
//}
					$fld->put_array($data);
					$want_db_query_echo_save = $want_db_query_echo;
					$want_db_query_echo = false; // any output will prevent us from calling header()
//echo "<br>doing update";
					$fld->store_update($old_field_name);
					if ($fld->name != $old_field_name)
						$_SESSION['active_fd'] = get_field_dict($this->active_table);
					$want_db_query_echo = $want_db_query_echo_save;
					$this->SetActiveField($fld->name);
					$this->saveok = true;
				}
				if ($btn_Save)
					header("Location: mb_dbtable.php?edit=1&saveok=1&field_processed=" . $this->active_field);
				else if ($btn_Next || $btn_SaveNext) {
					header("Location: mb_dbfield?next=1" . ($this->saveok ? "&saveok=1" : ""));
				}
				else
					die('db-field-action.php -- no button variables seem to be set');
			}
			die("mb_field.php.callback_action() -- fell off the end");
		}

		function validate() {
			global $data;

//			if (preg_match('/[\'"]/', $data['name'])) {
//				$this->AddMessageError("Field name may not contain quotes.");
//				return false;
//			}
//			if (!preg_match('/^[A-Za-z0-9_]{1,20}$/', $data['name'])) {
//				$this->AddMessageError("Field name must be from 1 to 20 letters, digits, and underscores.");
//				return false;
//			}
			if (!validate_field_name($this, $data['name']))
				return false;
			if (preg_match('/[\'"]/', $data['choices'])) {
				$this->AddMessageError("Choices may not contain quotes.");
				return false;
			}
			if ($data['type'] == 'c' && !preg_match('/^( *[A-Za-z0-9_]+ *,)* *[A-Za-z0-9_]+ *$/', $data['choices'])) {
				$this->AddMessageError("Comma-separated choices composed of letters, digits, and underscores are required.");
				return false;
			}
			return true;
		}

		function ShowForm() {
			echo <<<EOT
				<script language="JavaScript">

				function type_change_warning(adding) {
					if (!adding)
						alert("WARNING: Changing the field type may cause data to be irretrievably lost, " +
						  "especially changing from Text, Memo, DateTime, or Choice to Number or Money.\\n" +
						  "It's best to back up the table first by returning to the Home page and pressing Export.");
				}

				function enable_elements(frm) {
					set_dirty();
					var i, index_type, index_cols, index_rows, index_choices;
					for (i = 0; i < frm.elements.length; i++) // needed because names are not JavaScript names
						if (frm.elements[i].name == "data[type]")
							index_type = i;
						else if (frm.elements[i].name == "data[cols]")
							index_cols = i;
						else if (frm.elements[i].name == "data[rows]")
							index_rows = i;
						else if (frm.elements[i].name == "data[choices]")
							index_choices = i;
					typename = frm.elements[index_type].options[frm.elements[index_type].selectedIndex].value;
				/*
					if (typename == "m") {
						frm.elements[index_cols].value = "60";
						frm.elements[index_rows].value = "5";
					}
					else {
						frm.elements[index_cols].value = "";
						frm.elements[index_rows].value = "";
					}
					if (typename == "c")
						frm.elements[index_choices].value = "[enter choices separated by commas]";
				else
						frm.elements[index_choices].value = "";
				*/
					frm.elements[index_cols].disabled = typename != "m" && typename != "t";
					frm.elements[index_rows].disabled = typename != "m";
					frm.elements[index_choices].disabled = typename != "c";
				}

				function onLoad_handler(frm) { // enabled by true arg to mrcs_page_top()
					enable_elements(frm);
					set_clean();
				}

				</script>
EOT;

// Anything important here is either in the field instructions or in the page heading.
//				$instr = "New Field";
//				if ($this->another && !isset($_GET['errors'])) {
////					echo '<h1>Another New Field</h1>';
////					echo 'Press Cancel when you\'ve no more to add.';
//					// $instr above is OK
//				}
//				else if (isset($_GET['add'])) {
////					echo '<h1>New Field</h1>';
//					// $instr above is OK
//				}
//				else
//					$instr = "Field $this->active_field";
//				echo "<br>Instr to go somewhere: $instr";




				$this->saveok = false;
				$tbl_form = new MB_TableFormWithInstr();
				$tbl_form->Begin(60);

				$tbl_form->FormCellBegin("Enter the field name that will be used to identify the field on forms and reports.
				  It must be from 1 to 20 letters, digits, and underscores.");
				$this->FieldLabel("Field Name", true);
				$v = nvl($this->cur_data['name']);
				echo "<input type=\"text\" size=\"20\" value=\"$v\" name=\"data[name]\"
				   onChange='set_dirty();' onKeydown='set_dirty();'>";


				echo "</td><td rowspan=\"7\" valign=\"top\" xwidth=\"15%\">";
				echo "<span class=\"FieldLabel\">Existing Fields</span><p>";
				$stmt = $this->dbmain->db_query_user("show columns from " . $this->dbapp->internal_name($this->active_table));
				if (mysql_num_rows($stmt) == 0)
					echo "No fields added yet.";
				else
					while ($row = mysql_fetch_assoc($stmt))
						if ($row['Field'] != "_rowID")
							echo "{$row['Field']}<br>";
				echo "</td>";

				$tbl_form->FormCellEnd();

				$tbl_form->FormCellBegin("Choose the type of the field, which determines what kind of data it can hold. For more about
				  field types, click " .
				  $this->HelpLink("here", "helpctx_mb_dbfield~lnk_field_types") . ".");
				$this->FieldLabel("Type");
//				echo '<select name="data[type]" onchange="enable_elements(this.form);">';
//				$tp = nvl($this->cur_data['type']);
//				echo '<option value="t"' . ($tp == 't' ? ' selected' : '') . '>Text</option>';
//				echo '<option value="m"' . ($tp == 'm' ? ' selected' : '') . '>Memo</option>';
//				echo '<option value="f"' . ($tp == 'f' ? ' selected' : '') . '>Number</option>';
//				echo '<option value="n"' . ($tp == 'n' ? ' selected' : '') . '>Money</option>';
//				echo '<option value="y"' . ($tp == 'y' ? ' selected' : '') . '>YesNo</option>';
//				echo '<option value="d"' . ($tp == 'd' ? ' selected' : '') . '>DateTime</option>';
//				echo '<option value="c"' . ($tp == 'c' ? ' selected' : '') . '>Choice</option>';
//				echo '</select>';
				ShowFieldTypeSelect("data[type]", nvl($this->cur_data['type']), "type_change_warning({$this->add}); enable_elements(this.form);");
				$tbl_form->FormCellEnd();

				$tbl_form->FormCellBegin("Required fields must always have data; otherwise, data can be omitted.");
				$this->FieldLabel("Required?");
				echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" ' . (nvl($this->cur_data['req']) ? 'checked' : '') .
				  ' name="data[req]"  onChange="set_dirty();">';
				$tbl_form->FormCellEnd();

				$tbl_form->FormCellBegin("Width of typing area on entry form. Used only for Text and Memo fields.");
				$this->FieldLabel("Columns");
				echo '<input type="text" size="3" value="' . nvl($this->cur_data['cols'], 40) .
				  '" name="data[cols]" onChange="set_dirty();" onKeydown="set_dirty();">';
				$tbl_form->FormCellEnd();

				$tbl_form->FormCellBegin("Height of typing area on entry form. Used only for Memo fields.");
				$this->FieldLabel("Rows");
				echo '<input type="text" size="3" value="' . nvl($this->cur_data['rows'], 5) .
				  '" name="data[rows]" onChange="set_dirty();" onKeydown="set_dirty();">';
				$tbl_form->FormCellEnd();

				$tbl_form->FormCellBegin("Comma-separated list of choices. Used only for Choice fields.");
				$this->FieldLabel("Choices");
				echo '<input type="text" size="50" value="' . nvl($this->cur_data['choices']) .
				  '" name="data[choices]" onChange="set_dirty();" onKeydown="set_dirty();">';
				$tbl_form->FormCellEnd();

				$back_label = "Back to $this->cancel_descr";
				if (isset($this->add)) {
					$instr = "Press <i>Save to add a new field";
					if ($this->another)
						$instr .= " or <i>$back_label</i> if there are no more to add.";
					else
						$instr .= ".";
				}
				else
					$instr = "Press the appropriate button to save or delete the current field and optionally
					  navigate to the next field.";
				$tbl_form->FormCellBegin($instr);
				if (isset($this->add))
					$this->ButtonNoDirtyCheck("btn_SaveNew", "Save");
				else {
					$this->ButtonNoDirtyCheck("btn_Save", "Save");
					$this->ButtonSpacer();
					$this->ButtonNoDirtyCheck("btn_SaveNext", "Save & Next");
					$this->ButtonSpaced("btn_Next", "Next", "mb_dbfield?next=1");
					//echo "<p>";
					$this->ButtonSpaced("btn_Delete", "Delete", null, "Press OK to lose all data in the field. Press Cancel to keep the field.", null, true, false);
				}
				$this->ButtonSpaced(null, $back_label, $this->cancel_target);
				$tbl_form->FormCellEnd();

				$tbl_form->End();
		}

		function ToFirstField() {
			reset($_SESSION['active_fd']);
			$this->SetActiveField(key($_SESSION['active_fd']));
			$this->cur_data = $_SESSION['active_fd'][$this->active_field]->get_array();
		}
	}

	$frm = new MB_DBField();
	$frm->SetLevelTable(true);

	if (isset($saveok))
		$frm->saveok = true;
	if (isset($table))
		$frm->SetActiveTable($table);

	if (isset($mbfv_button['btn_SaveNext']) || isset($mbfv_button['btn_Save'])) // need a much better way to do this
		unset($next); // because the submit button for btn_SaveNext may have left it set
	if (isset($first)) {
		$frm->ToFirstField();
		$frm->CancelCallback();
	}
	else if (isset($next)) {
		$frm->CancelCallback();
		$reps = 0;
		for (reset($_SESSION['active_fd']); key($_SESSION['active_fd']) != $frm->active_field; next($_SESSION['active_fd'])) {
			if (++$reps > 500)
				die("mb_dbfield -- excessive looping");
			//echo '<br>' . key($_SESSION['active_fd']) . '--' . $frm->active_field . '<br>';
		}
//echo "<br>after iter we are at " . key($_SESSION['active_fd']);
		if (next($_SESSION['active_fd'])) {
			$frm->SetActiveField(key($_SESSION['active_fd']));
//echo "<br>next worked -- we are now at $frm->active_field";dump($mbfv_button);
			$frm->cur_data = $_SESSION['active_fd'][$frm->active_field]->get_array();
		}
		else {
//echo "<br>You've cycled back";dump($mbfv_button);
			$frm->AddMessageConfirmation("You've cycled back to the first field.");
			$frm->ToFirstField();
		}
	}
	else if (isset($add)) {
		$frm->add = true;
		$frm->SetActiveField(null);
//		if (isset($errors)) {
//			$frm->errors = true;
//			$cur_data = $_SESSION['bad_data'];
//		}
//		else
			$frm->cur_data = array();
	}
	else if (isset($_SESSION['active_fd'])) {
		if (!empty($field))
			$frm->SetActiveField($field);
		$frm->cur_data = $_SESSION['active_fd'][$frm->active_field]->get_array();
	}
	else
		die('mb_field.php -- $_SESSION[active_fd] not set');

	if (isset($cancel_target))
		$frm->cancel_target = $cancel_target;
	if (isset($cancel_descr))
		$frm->cancel_descr = $cancel_descr;
	// should no longer be needed -------    $frm->SetActiveField($_SESSION['active_field']);

	$frm->Go(null, ($frm->add ? 'Add' : 'Edit') . "  Field" .
	  ($frm->add ? "" : " \"$frm->active_field\"") .
	  " &mdash; Table: \"$frm->active_table\"", "helpctx_mb_dbfield", true);
?>
