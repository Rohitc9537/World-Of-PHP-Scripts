<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_breadcrumbs.php,v 1.1.1.1 2005/07/13 00:22:06 rochkind Exp $

define('MB_CRUMBLEVEL_HOME', 1);
define('MB_CRUMBLEVEL_DB', 2);
define('MB_CRUMBLEVEL_TABLE', 3);
define('MB_CRUMBLEVEL_FIELD', 4);

class MB_Crumb {
	var $label;
	var $value;
	var $target;

	function MB_Crumb($label, $value, $target) {
		$this->label = $label;
		$this->value = $value;
		$this->target = $target;
	}

	function ShowButton($use_target, $arrow = true, $noop = false) {
		if (isset($this->value))
			if ($this->value == "-")
				$v = "";
			else
				$v = ": $this->value";
		else
			$v = ""; // could indicate "unset" but nothing at all seems better
		if ($noop)
			echo "$this->label$v";
		else
			nav_button("$this->label$v", $use_target ? $this->target : null, $arrow); // in mb_topstuff for now
	}
}

class MB_BreadCrumbs {

	var $trail;
	var $level;

	function MB_BreadCrumbs() {
		$this->trail[MB_CRUMBLEVEL_HOME] = new MB_Crumb("Home", "-", "mb_dbmain.php");
		$this->trail[MB_CRUMBLEVEL_DB] = new MB_Crumb("Database", null, "mb_dbmain.php");
		$this->trail[MB_CRUMBLEVEL_TABLE] = new MB_Crumb("Table", null, "mb_dbtable.php");
		$this->trail[MB_CRUMBLEVEL_FIELD] = new MB_Crumb("Field", null, "mb_dbfirld.php");
	}

	function SetLevelHome() {
		$this->level = MB_CRUMBLEVEL_HOME;
	}

	function SetLevelDatabase($show_button) {
		$this->level = MB_CRUMBLEVEL_DB + ($show_button ? .5 : 0);
	}

	function SetLevelTable($show_button) {
		$this->level = MB_CRUMBLEVEL_TABLE + ($show_button ? .5 : 0);
	}

	function SetLevelField($show_button) {
		$this->level = MB_CRUMBLEVEL_FIELD + ($show_button ? .5 : 0);
	}

	function SetLabel($label) {
		$this->trail[$this->level]->label = $label;
	}

	function SetValue($value) {
		$this->trail[$this->level]->value = $value;
	}

	function SetTarget($target) {
		$this->trail[$this->level]->target = $target;
	}

	function Show() {
		echo "<div  class=\"navbar\">";
		//if ($this->level > MB_CRUMBLEVEL_HOME) {
			//$this->trail[MB_CRUMBLEVEL_HOME]->ShowButton($this->level > MB_CRUMBLEVEL_HOME, false);
			if ($this->level >= MB_CRUMBLEVEL_DB) {
				$this->trail[MB_CRUMBLEVEL_DB]->ShowButton($this->level > MB_CRUMBLEVEL_DB, false);
				if ($this->level >= MB_CRUMBLEVEL_TABLE) {
					$this->trail[MB_CRUMBLEVEL_TABLE]->ShowButton($this->level > MB_CRUMBLEVEL_TABLE);
					if ($this->level >= MB_CRUMBLEVEL_FIELD) {
						$this->trail[MB_CRUMBLEVEL_FIELD]->ShowButton($this->level > MB_CRUMBLEVEL_FIELD);
					}
				}
			}
		//}
		else if (preg_match('/mb_dbmain.php$/', $_SERVER['SCRIPT_FILENAME']) || !nvl($_SESSION['MUDBAG_USER']->logged_in))
			echo "<span class=\"formButtonEmpty\">&nbsp;</span>";
		echo "</div>";
	}
}

?>
