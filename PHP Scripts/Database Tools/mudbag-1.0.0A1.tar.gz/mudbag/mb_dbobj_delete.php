<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbobj_delete.php,v 1.1.1.1 2005/07/13 00:21:59 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBTableDelete extends MB_DBScreen {

		var $object_type;
		var $object_name;
		var $dbname;
		var $dbid;
		var $dropped;
		var $data_only = false;
		var $rename_allowed = false;

		function MB_DBTableDelete() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_delete":
				if (strtoupper($_POST['mbfv_delete_confirmation']) == "YES") {
					if ($this->object_type == "table") {
						$this->SetPageHelpCtx("helpctx_mb_dbobj_delete~table");
						$this->dbmain->db_query_user("delete from mb_field where tbl = '$this->object_name' and db_id = $this->dbid");
						$this->dbmain->db_query_user("drop table " . $this->dbapp->internal_name($this->object_name));
						$this->SetActiveTable(null);
					}
					else if ($this->object_type == "view") {
						$this->SetPageHelpCtx("helpctx_mb_dbobj_delete~view");
						$this->dbmain->db_query_user("delete from mb_view where name = '$this->object_name' and db_id = $this->dbid");
						$this->SetActiveTable(null);
					}
					else if ($this->object_type == "report") {
						$this->SetPageHelpCtx("helpctx_mb_dbobj_delete~report");
						$this->dbmain->db_query_user("delete from mb_reportspec where name = '$this->object_name' and db_id = $this->dbid");
						$this->SetActiveTable(null);
					}
					else {
						$this->SetPageHelpCtx("helpctx_mb_dbobj_delete~database");
						$this->dbmain->db_query("begin");
						$this->dbmain->db_query("delete from mb_field where db_id = $this->dbid");
						$this->dbmain->db_query("delete from mb_view where db_id = $this->dbid");
						$this->dbmain->db_query("delete from mb_reportspec where db_id = $this->dbid");
						$this->dbmain->db_query("delete from mb_user_db where db_id = $this->dbid");
						$this->dbmain->db_query("delete from mb_db where db_id = $this->dbid");
						$result = $this->dbmain->db_query_user("show tables like '{$_SESSION['APPDB']->tblpfx}%'");
						while ($row = mysql_fetch_row($result))
							$this->dbmain->db_query_user("drop table $row[0]");
						$this->SetActiveDatabase(null);
						$this->dbmain->db_query("commit");
					}
					$this->dropped = true;
				}
				else
					$this->AddMessageError("You must type \"yes\" in the field to delete the $this->object_type.");
				break;
			case "btn_delete_data":
				if (strtoupper($_POST['mbfv_delete_confirmation_data']) == "YES") {
					$this->dbmain->db_query_user("delete from " . $this->dbapp->internal_name($this->object_name));
					$this->dropped = true;
					$this->data_only = true;
				}
				else
					$this->AddMessageError("You must type \"yes\" in the field to delete the data.");
				break;
			case "btn_rename":
					if ($this->object_type == "table") {
						if (validate_dbtablename($_POST['mbfv_new_name'], $msg)) {
							$old_internal_name = $this->dbapp->internal_name($this->object_name);
							$new_internal_name = $this->dbapp->internal_name($_POST['mbfv_new_name']);
							$this->dbmain->db_query("alter table $old_internal_name rename to $new_internal_name");
							$this->SetActiveTable($new_internal_name);
							header("Location: mb_dbmain.php");
						}
						else
							$this->AddMessageError($msg);
					}
					else {
						if (validate_dblongname($_POST['mbfv_new_name'], $msg)) {
							$this->dbmain->db_query("update mb_db set dblongname = '{$_POST['mbfv_new_name']}'
							  where db_id = $this->dbid");
							$this->SetActiveDatabase($_POST['mbfv_new_name']);
							header("Location: mb_dbmain.php");
						}
						else
							$this->AddMessageError($msg);
					}
				break;
			default:
				parent::Callback($tag);
			}
		}

		function ShowForm() {
			if ($this->dropped) {
				if ($this->data_only)
					$this->MessageConfirmation("The data has been deleted.");
				else
					$this->MessageConfirmation("The $this->object_type has been deleted.");
				echo "<p>";
				if ($this->object_type == "table")
					$this->Button(null, "Back to Database", "mb_dbmain.php");
				else
					$this->Button(null, "Back to Home", "mb_dbmain.php");
			}
			else {
				$this->SetPageHelpCtx("helpctx_mb_dbobj_delete~$this->object_type");
				// It's complicated to determine who owns an object, so the UI is responsible for
				// preventing unauthorized deletion. The following test is wrong, as non-DB-owners can
				// created objects that they own.
				/*
					if (!$_SESSION['APPDB']->is_owned()) {
						// Following message should be impossible, as no button ought to take us here.
						$this->MessageError("Only the owner of the $this->object_type can delete it.");
						return;
					}
				*/
				$tbl = new MB_TableFormWithInstr();
				$tbl->Begin();

				$btn_name = "Delete " . ucfirst($this->object_type);
				$tbl->FormCellBegin("To completely delete $this->object_type \"$this->object_name\", with no way to restore it, type
				  \"yes\" and press <i>$btn_name</i>.");
				$cf = nvl($_POST['mbfv_delete_confirmation']);
				$this->FieldLabel("Confirm", true);
				echo "<input type=\"text\" name=\"mbfv_delete_confirmation\" size=\"4\" value=\"$cf\">";
				$this->ButtonSpaced("btn_delete", $btn_name);
				$tbl->FormCellEnd();

				if ($this->object_type == "table") {
					$tbl->FormCellBegin("To delete just the data in \"$this->object_name\" (keeping the empty table),
					  with no way to restore it, type
					  \"yes\" and press <i>Delete Data</i>.");
					$cf = nvl($_POST['mbfv_delete_confirmation_data']);
					$this->FieldLabel("Confirm", true);
					echo "<input type=\"text\" name=\"mbfv_delete_confirmation_data\" size=\"4\" value=\"$cf\">";
					$this->ButtonSpaced("btn_delete_data", "Delete Data");
					$tbl->FormCellEnd();
				}

				if ($this->rename_allowed) {
					$tbl->FormCellBegin("To rename $this->object_type \"$this->object_name\", type
					  the new name and press <i>Rename</i>.");
					$nn = nvl($_POST['mbfv_new_name']);
					$this->FieldLabel("New Name", true);
					echo "<input type=\"text\" name=\"mbfv_new_name\" size=\"10\" value=\"$nn\">";
					$this->ButtonSpaced("btn_rename", "Rename");
					$tbl->FormCellEnd();
				}

//				$tbl->FormCellBegin("Press the <i>Delete</i> button to delete the $this->object_type.");
//				$this->ButtonSpaced(null, "Back to Database", "mb_dbmain.php");
//				$tbl->FormCellEnd();

				$tbl->End();
			}
		}

	}

	$frm = new MB_DBTableDelete();

	if (isset($_GET['dblongname'])) {
		$row = mysql_fetch_array($frm->dbmain->db_query("select d.db_id from mb_db d
		  join mb_user_db using(db_id)
		  where dblongname = '{$_GET['dblongname']}'
		  and user_id = {$_SESSION['MUDBAG_USER']->user_id}
		  and role_id = " . ROLE_OWNER));
		if ($row)
			$frm->dbid = $row[0];
		else
			exit("You don't have permission to delete or rename this database.");
	}
	else
		$frm->dbid = $_SESSION['APPDB']->db_id;

	if (isset($table)) {
		$frm->object_type = "table";
		$frm->object_name = $table;
		$frm->SetActiveTable($table);
		$hdg = "Delete/Rename Table \"$frm->active_table\"";
		$frm->rename_allowed = true;
	}
	else if (isset($view)) {
		$frm->object_type = "view";
		$frm->object_name = $view;
		$frm->SetActiveView($view);
		$hdg = "Delete View \"$frm->active_view\"";
	}
	else if (isset($report)) {
		$frm->object_type = "report";
		$frm->object_name = $report;
		$hdg = "Delete Report \"$report\"";
	}
	else {
		$frm->object_type = "database";
		$frm->object_name = $_GET['dblongname'];
		$frm->dbname = $_SESSION['APPDB']->dbname;
		$frm->SetActiveDatabase($frm->object_name, true);
		$hdg = "Delete/Rename Database \"$frm->object_name\"";
		$frm->rename_allowed = true;
	}
	unset($_SESSION['active_rownum']);
	unset($_SESSION['edit_view']);

	$frm->Go(null, $hdg, "helpctx_mb_dbobj_delete~$frm->object_type", false, null, true, true);
?>
