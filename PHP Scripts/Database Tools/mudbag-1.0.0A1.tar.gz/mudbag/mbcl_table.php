<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_table.php,v 1.1.1.1 2005/07/13 00:22:07 rochkind Exp $

class MB_Table {

	var $body_called = false;

	function Begin($border = 1, $cellpadding = 4, $attr = '') {
		global $color_bg_table, $color_brdr_table;

		echo "<table bordercolor=$color_brdr_table bgcolor=$color_bg_table border=$border
		  cellspacing=\"0\" cellpadding=$cellpadding $attr><thead><tr>";
	}

	function ColHdgOpen($h = '&nbsp;', $center = false, $big = false, $span = 1, $nowrap = false) {
		global $color_bg_table_hdg, $color_fg_table_hdg;
		$align = '';
		$nowrap_str = ($nowrap ? " nowrap " : "");
		if ($center)
			$align = 'align="center"';
		if ($big)
			echo "<td valign=\"bottom\" $align colspan=\"$span\" $nowrap_str><b><font size=\"+1\">$h<font></b><p>";
		else
			echo "<td valign=\"bottom\" $align bgcolor=\"$color_bg_table_hdg\" colspan=\"$span\" $nowrap_str><b>
			  <font color=\"$color_fg_table_hdg\">$h<font></b>";
	}

	function ColHdg($h = '&nbsp;', $center = false, $big = false, $span = 1) {
		$this->ColHdgOpen($h, $center, $big, $span);
		echo '</td>';
	}

	function Body() {
		if (!$this->body_called) {
			$this->body_called = true;
			echo '<tr></thead><tbody>';
		}
	}

	function End() {
		$this->Body();
		echo '</tbody></table>';
	}

	function Begin2Col($hdg1, $pct1, $alg1, $hdg2, $pct2, $alg2, $border = 1, $attr = 'frame="border" rules="cols"', $sep = false) {
		global $table_2col_pct2, $table_2col_alg2, $table_sep;

		$table_sep = $sep;
		$table_2col_pct2 = $pct2;
		$table_2col_alg2 = $alg2;
		$this->Begin($border, 8, $attr);
		if (!empty($hdg1) || !empty($hdg2)) {
			$this->ColHdg($hdg1, true, true);
			if ($table_sep)
				echo "<td>&nbsp;</td>";
			$this->ColHdg($hdg2, true, true);
		}
		$this->Body();
		echo '<td width="' . $pct1 . '" align="' . $alg1 . '" valign="top">';
	}

	function Mid2Col() {
		global $table_2col_pct2, $table_2col_alg2, $table_sep;

		echo '</td>';
		if ($table_sep)
			echo "<td>&nbsp;</td>";
		echo '<td width="' . $table_2col_pct2 . '" align="' . $table_2col_alg2 . '" valign="top">';
	}

	function End2Col() {
		echo "</td>";
		$this->End();
	}

}

class MB_TableFormWithInstr extends MB_Table {

	var $pct;

	function Begin($pct = 75) {
		parent::Begin(1, 12, "xframe=\"hsides\" xrules=\"none\"");
		$this->pct = $pct;
	}

	function End($want_footnote = true) {
		parent::End();
		if ($want_footnote)
			echo "<p><span class=\"FieldLabelReqMark\">*</span> Required field";
	}

	function InstrCellBegin() {
		global $color_bg_form_instr;

		$this->Body();
		// Width is really set by image.
		echo "<tr><td valign=\"middle\" width=\"200\" bgcolor=\"$color_bg_form_instr\"><span class='InstrCell'>";
	}

	function InstrCellEnd() {
		// 1-pixel square transparent image displayed at 1x200
		echo "</span><img src=\"images/1pixtran.gif\" height=\"1\" width=\"200\">";
		echo "</td>";
	}

	function InstrCell($s) {
		$this->InstrCellBegin();
		echo $s;
		$this->InstrCellEnd();
	}

	function FormCellBegin($instr = null) {
		$this->Body();
		if (isset($instr))
			$this->InstrCell($instr);
		// Not use of "xwidth" to make width attribute ineffective
		echo "<td valign = \"middle\" xwidth=\"{$this->pct}%\">";
	}

	function FormCellEnd() {
		echo "</td></tr>";
	}
}

?>
