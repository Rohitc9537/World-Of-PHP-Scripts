<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_user.php,v 1.1.1.1 2005/07/13 00:22:07 rochkind Exp $

// Set this from MB_DB according to what user has set up.
// Accessible via $_SESSION['MUDBAG_USER']->params->???.
class MB_Params {

	var $upload_size = MB_UPLOAD_MAX;
	var $row_page_max = MB_ROW_PAGE_MAX;
	var $report_exec_time = MB_REPORT_EXEC_TIME;

};


class MB_User {
	var $login, $password /* clear text */, $firstname, $lastname, $street1, $street2, $city, $state, $zip, $country, $phone, $email,
	  $os = "[Unknown]";
	var $user_id, $logged_in;
	var $default_db_id;
	var $admin = false;
	var $params;
	var $account_id;
	var $limits_exceeded = false;



	function MB_User($logged_in = false) {

		$this->logged_in = $logged_in;
		$this->params = new MB_Params();

	}

	function from_assoc($a) {
		if (isset($a['user_id']))
			$this->user_id = $a['user_id'];
		$this->login = $a['login'];
		$this->firstname = $a['firstname'];
		$this->lastname = $a['lastname'];
		$this->street1 = $a['street1'];
		$this->street2 = $a['street2'];
		$this->city = $a['city'];
		$this->state = $a['state'];
		$this->zip = $a['zip'];
		$this->country = $a['country'];
		$this->phone = $a['phone'];
		$this->email = $a['email'];
		$this->default_db_id = $a['default_db_id'];
		$this->account_id = $a['account_id'];
	}


	function from_obj($u) {
		if (isset($u->user_id))
			$this->user_id = $u->user_id;
		$this->login = $u->login;
		$this->firstname = $u->firstname;
		$this->lastname = $u->lastname;
		$this->street1 = $u->street1;
		$this->street2 = $u->street2;
		$this->city = $u->city;
		$this->state = $u->state;
		$this->zip = $u->zip;
		$this->country = $u->country;
		$this->phone = $u->phone;
		$this->email = $u->email;
		$this->default_db_id = $u->default_db_id;
		$this->account_id = $u->account_id;
	}


	function get_mysql_user() {
		if (!isset($this->logged_in) || !isset($this->login))
			die("Not logged in.");
		return get_mysql_user_from_login($this->login);
	}

	function get_fullname() {
		$s = $this->firstname;
		if (strlen($s) > 0)
			$s = $s . ' ';
		$fn = trim($s . $this->lastname);
		if (empty($fn))
			$fn = $this->login;
		return $fn;
	}
}


//******************************* Try to put the following into a class.

function get_mysql_user_from_login($login) {
	return 'Mbag_' . $login;
}
?>
