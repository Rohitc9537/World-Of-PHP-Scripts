<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbmain.php,v 1.1.1.1 2005/07/13 00:21:59 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBMain extends MB_DBScreen {

		var $dblist;

		function MB_DBMain() {
			$this->MB_DBScreen();
		}

		function ShowForm() {
			echo <<<EOT
				<script language="JavaScript">

				function show_report(spec_name, os) {
					pdf_window("mb_report_generate.php?spec_name=" + spec_name, os);
				}

				</script>
EOT;

			if (!check_limits($limit_msg))
				echo "<table border='0' cellspacing='0' cellpadding='5' bgcolor='red'><tr><td><font color='white'>$limit_msg</font></td></tr></table>";
			$maincol_width = 250;
			$tbl_2col = new MB_Table();
			$tbl_2col->Begin2Col(null, '50%', 'center', null, '50%', 'center', 0, '', true);
			$this->show_tables_and_views_and_reports($maincol_width, count($this->dblist) > 0);
			$tbl_2col->Mid2Col();
			$this->show_databases($maincol_width, $this->dblist);
			echo "</td><tr><td>";
			if ($_SESSION['MUDBAG_USER']->login == "admin" && $this->active_database == "db_admin")
				echo "<font color='red'><b>WARNING:</b> This database contains tables used internally by Mudbag.
				  Be very careful adding or editing data, and do not change any table designs.</font>";
			echo "</td><td></td><td>";
			//echo "<span class='small'>* These are databases that other users have given you permission to access.</span>";
			$tbl_2col->End();
			if ($this->IsAdmin(true)) {
				echo '<b>(tmp) Add Database and other stuff needs to be customized for role</b><p>';
				$this->dbmain->db_query_user_show("", "show tables");
			}
		}

		function show_databases($maincol_width, &$dblist) {
			echo "<h2>&nbsp;</h2>";
			$tbl_db = new MB_Table();
			$tbl_db->Begin(0);
			//$tbl_db->ColHdg("");
			$tbl_db->ColHdg("Available Databases", false, false, 3);
			$tbl_db->Body();
			foreach ($dblist as $name => $href) {
				$had_db = true;
				$aname = explode(" ", $name, 2);
				$active = isset($this->active_database) && $aname[0] == $this->active_database;
				echo "<tr><td><span class='medium'>";
				if ($active)
					echo "&rArr;";
				else
					echo "&nbsp;";
				echo "</span></td><td width='$maincol_width'>";
				if ($active)
					echo $name;
				else
					echo "<a href='$href'>$aname[0]</a> " . nvl($aname[1]);
				echo "</td><td>";
				if (isset($aname[1]))
					echo "&nbsp;";
				else if ($aname[0] == "db_admin")
					echo "<i><font size='-2'>Can't&nbsp;delete/rename</font></i>";
				else
					button_bar_medium(array('Delete/Rename', "mb_dbobj_delete.php?db=1&dblongname=$aname[0]"), false);
				echo "</td></tr>";
			}
			if (count($dblist) == 0)
				echo "<tr><td align='center'>No databases.</td></tr>";
			$tbl_db->End();
			echo "<p>";
			$this->Button(null, 'Add Database', 'mb_dbadd.php');
		}

		function list_databases() {
			$dblist = array();
			for ($pass = 1; $pass <= 2; $pass++) {
				$result_owned = $this->dbmain->db_query("select dbname, dblongname, mb_db.db_id
				  from mb_db
				  join mb_user_db using(db_id)
				  where role_id = " . ROLE_OWNER . " and user_id = {$_SESSION['MUDBAG_USER']->user_id}
				  order by dblongname");
				$result_other = $this->dbmain->db_query("select u_other.role_id, dbname, dblongname, mb_db.db_id, login
				  from mb_db
				  join mb_user_db u_other on mb_db.db_id = u_other.db_id and u_other.role_id != " . ROLE_OWNER . "
				  join mb_user_db u_own on mb_db.db_id = u_own.db_id and u_own.role_id = " . ROLE_OWNER . "
				  join mb_user on mb_user.user_id = u_own.user_id
				  where u_other.user_id = {$_SESSION['MUDBAG_USER']->user_id}
				  order by dblongname");
				$num_rows_owned = mysql_num_rows($result_owned);
				$num_rows_other = mysql_num_rows($result_other);
				if ($_SESSION['MUDBAG_USER']->login == "admin" && $num_rows_owned == 0 && $num_rows_other == 0) {
					$db = new MB_AppDB();
					$db->Install();
					$db->create("db_sample", true, $msg);
					db_clear();
				}
				else
					break;
			}
			if ($num_rows_owned >= 1) {
				for ($i = 0; $row = mysql_fetch_assoc($result_owned); $i++) {
					if (!db_isset()) {
						set_db($row['dbname'], $row['dblongname'], $row['db_id'], ROLE_OWNER, $_SESSION['MUDBAG_USER']->login);
						$this->SetActiveDatabase($_SESSION['APPDB']->dblongname);
					}
					$dblist[$row['dblongname']] = "mb_dbmain.php?dbname={$row['dbname']}&dblongname={$row['dblongname']}" .
					  "&db_id={$row['db_id']}&role_id=" . ROLE_OWNER . "&owner={$_SESSION['MUDBAG_USER']->login}";
				}
			}
			if ($num_rows_other >= 1) {
				for ($i = 0; $row = mysql_fetch_assoc($result_other); $i++) {
					if (!db_isset()) {
						set_db($row['dbname'], $row['dblongname'], $row['db_id'], $row['role_id'], $row['login']);
						$this->SetActiveDatabase($_SESSION['APPDB']->dblongname);
					}
					$dblist["{$row['dblongname']} (owned by {$row['login']})"] = "mb_dbmain.php?dbname={$row['dbname']}&dblongname={$row['dblongname']}" .
					  "&db_id={$row['db_id']}&role_id={$row['role_id']}&owner={$row['login']}";
				}
			}
			return $dblist;
		}

		function show_tables_and_views_and_reports($maincol_width, $have_databases) {
			if (db_isset()) {
				$dbheading = "Database $this->active_database"; // (owned by {$_SESSION['APPDB']->owner})
				echo "<h2>$dbheading</h2>";
				$result = $this->dbmain->db_query_user("show tables like '{$_SESSION['APPDB']->tblpfx}%'");
				while ($row = mysql_fetch_row($result))
					if (substr($row[0], 0, 4) != 'mb_')
						$tables[] = $_SESSION['APPDB']->external_name($row[0]);
				$tbl = new MB_Table();
				$tbl->Begin(0);
				//if ($_SESSION['APPDB']->is_owned())
					$table_colspan = 1;
				//else
				//	$table_colspan = 2;
				$tbl->ColHdg('Tables', false, false, 2);
				//if ($_SESSION['APPDB']->is_owned())
				//	$tbl->ColHdg('Actions', true);
				$tbl->Body();
				$have_tables = !empty($tables);
				if ($have_tables) {
					natcasesort($tables);
					foreach ($tables as $tblname) {
						// Used to make button dependent on whether fields are there, but no longer seems a good idea.
					//$flds = mysql_num_rows($this->dbmain->db_query_user("show columns from $row[0]"));
						// _rowID will be first field in $have_flds
						echo '<tr>';
						echo "<td width='$maincol_width' colspan='$table_colspan'><a href=\"mb_dbtable.php?data=1&table=$tblname\">$tblname</a></td>";
						if ($_SESSION['APPDB']->is_owned()) {
							echo '<td align="center" nowrap>';
							//if ($flds <= 1)
							//	button_bar_medium(array("Add Fields", "mb_dbfield.php?add=1&table=$row[0]&cancel_target=mb_dbmain.php"), false);
							//else
								button_bar_medium(array("Design", "mb_dbtable.php?edit=1&table=$tblname", 'Delete/Rename', "mb_dbobj_delete.php?table=$tblname"), false);
							//echo '</td><td align="center">'; // only if 2 button varieties
							//button_bar_medium(array('Delete', "mb_dbobj_delete.php?table=$tblname"), false);
							echo '</td>';
						}
						else
							echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
						echo '</tr>';
					}
				}
				else {
					echo "<tr><td colspan='2' align='center'>No tables.";
					echo "</td></tr>";
				}
				echo "<tr><td colspan='2' align='center'>";
				if ($_SESSION['APPDB']->is_owned())
					if ($have_databases)
						$this->Button(null, "Add Table", "mb_dbtable_add.php");
					else
						echo "You have to add a database before you can add a table.";
				else
					echo "&nbsp;";
				echo "</td></tr><tr><td>&nbsp;</td></tr><tr>";
				$tbl->ColHdg('Views', false, false, 2);
				//$tbl->ColHdg('Actions', true);
				echo "</tr>";
				$result = $this->dbmain->db_query_user("select name, view_id, v.user_id, login from mb_view v
				  join mb_user using(user_id)
				  where db_id = {$_SESSION['APPDB']->db_id} and (public = 1 or v.user_id = {$_SESSION['MUDBAG_USER']->user_id})
				  order by name");
				if (mysql_num_rows($result) < 1) {
					echo "<tr><td colspan='2' align='center'>No views.</td></tr>";
				}
				else {
					while ($row = mysql_fetch_assoc($result)) {
						$owned = $row['user_id'] == $_SESSION['MUDBAG_USER']->user_id;
						$nm2 = ($owned ? "" : " (owned by {$row['login']})");
						echo '<tr>';
						echo '<td  width="$maincol_width"><a href="mb_dbtable.php?data=1&view=' . $row['view_id'] . '">' .
						  '<font sizex="-2">' . $row['name'] . '</font>' . "</a>$nm2</td>";
						echo '<td align="center" nowrap>';
						if ($owned)
							button_bar_medium(array('Design', 'mb_dbview_addedit.php?edit=1&view=' .
							  $row['view_id'], 'Delete', "mb_dbobj_delete.php?view={$row['name']}"), false);
						else
							button_bar_medium(array('Details', 'mb_dbview_addedit.php?edit=0&view=' . $row['view_id']), false);
						echo '</td>';
						echo '</tr>';
					}
				}
				echo "<tr><td colspan='2' align='center'>";
				//if ($_SESSION['APPDB']->is_owned()) can add report for non-owned tables and views
					if ($have_tables)
						$this->Button(null, "Add View", "mb_dbview_addedit.php?add=1");
					else
						echo "You have to add a table before you can add a view.";
				//else
				//	echo "&nbsp;";
				echo "</td></tr><tr><td>&nbsp;</td></tr><tr>";
				$tbl->ColHdg('Reports', false, false, 2);
				echo "</tr>";
				$result = $this->dbmain->db_query_user("select name, type, is_table, tableview, r.user_id, login from mb_reportspec r
				  join mb_user using(user_id)
				  where db_id = {$_SESSION['APPDB']->db_id} and (public = 1 or r.user_id = {$_SESSION['MUDBAG_USER']->user_id})
				  order by name");
				if (mysql_num_rows($result) < 1)
					echo "<tr><td colspan='2' align='center'>No reports.</td></tr>";
				else
					while ($row = mysql_fetch_assoc($result)) {
						$owned = $row['user_id'] == $_SESSION['MUDBAG_USER']->user_id;
						$nm2 = ($owned ? "" : " (owned by {$row['login']})");
						$s = "";//" (on " . ($row['is_table'] ? "table" : "view") . " {$row['tableview']})";
						echo '<tr>';
						echo "<td  width='$maincol_width' nowrap>";
						echo "<a href=\"javascript: show_report('{$row['name']}', '" . $_SESSION["MUDBAG_USER"]->os . "');\">";
						echo "{$row['name']}</a>{$nm2}{$s}";
						$url = "mb_report_block.php?type={$row['type']}&spec={$row['name']}";
						if ($row['type'] == 'm')
							echo " <span class='small'>
							  (<a href='$url&test=1' onclick='return confirm(\"Send one email to your address as a test?\");'>Test</a>&nbsp;
							  <a href='$url&send=1' onclick='return confirm(\"Send all emails? (You may want to preview by clicking the report name first.)\");'>Send</a>)</span>";
						echo "</td>";
						echo '<td align="center" nowrap>';
						if ($owned) {
							button_bar_medium(array("Design", $url, 'Delete', "mb_dbobj_delete.php?report={$row['name']}"), false);
						}
						else
							echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
						echo '</tr>';
					}
				echo "<tr><td colspan='2' align='center'>";
				//if ($_SESSION['APPDB']->is_owned()) can add report for non-owned tables and views
					if ($have_tables)
						$this->Button(null, "Add Report", "mb_report.php");
					else
						echo "You have to add a table before you can add a report.";
				//else
				//	echo "&nbsp;";
				echo "</td></tr>";
				$tbl->End();
				echo "<p>";
			}
			else {
				$dbheading = "(No database active)";
				echo "<h2>$dbheading</h2>";
				echo "<p>Click the button at left to add a database.";
			}
		}
	}

	$frm = new MB_DBMain();
	unset($_SESSION['active_view_obj']);
	if (isset($_GET['dbname'])) {
		set_db($_GET['dbname'], $_GET['dblongname'], $_GET['db_id'], $_GET['role_id'], $_GET['owner']);
		$frm->SetActiveDatabase($_SESSION['APPDB']->dblongname);
	}
	else {
		if (!db_isset())
			set_db_from_id($_SESSION['MUDBAG_USER']->default_db_id);
		if (isset($_SESSION['APPDB']->dblongname)) // no reason it wouldn't be
			$frm->SetActiveDatabase($_SESSION['APPDB']->dblongname);
	}
	$frm->SetActiveTable(null);
	$frm->SetActiveView(null);
	$hdg = 'Mudbag Home';
	if (db_isset())
		$frm->breadcrumbs->SetLevelDatabase(false);
	$frm->dblist = $frm->list_databases();
	if (db_isset())
		if ($_SESSION['APPDB']->is_owned())
			$toolbar = array(
			  'Import', 'mb_dbtable_import.php?spec=[new]',
			  'Export', 'mb_dbtable_export.php',
			  'Users', 'mb_mng_users.php'
			);
		else
			$toolbar = array(
			  'Export', 'mb_dbtable_export.php'
			);
	else
		$toolbar = null;
	if (isset($need_acount_info) && $need_acount_info)
		$frm->AddMessageInfo("Please press the Account button at the upper right to setup your
		  account information and change your password.");
	$frm->Go($toolbar, $hdg, "helpctx_mb_dbmain", false, null, true, true);
?>
