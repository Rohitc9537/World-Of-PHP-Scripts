<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mng_users.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");
	require("mb_mail_sim_util.php");

	$want_db_query_echo = false;

	class MB_MngUsers extends MB_DBScreen {

		var $action = "main";
		var $role_failed_logins;
		var $send_failed_logins;
		var $send_ok_msg;
		var $subject;
		var $message;

		function Callback($tag) {
			$this->action = $tag;
			$preview = false;
			switch ($tag) {
			case "main":
				break;
			case "btn_Preview":
				$preview = true;
				// fall through
			case "btn_send_go":
				$this->action_send_go($preview);
				break;
			case "btn_revoke_go":
				$this->action_revoke_go();
				break;
			case "btn_roles_go":
				$this->action_roles_go();
				break;
			default:
				if (empty($_POST['sel'])) {
					$this->AddMessageError("Please make a selection if you want to send email, revoke access, or change roles.");
					$this->action = "main";
					return;
				}
			}
		}

		function ShowForm() {
			echo <<<EOT
				<script language="JavaScript">

					function selAll(frm, _v) {
						for (var i = 0; i < frm.elements.length; i++)
						  frm.elements[i].checked= _v; // not bothering to determine if actually a checkbox
					}

				</script>
EOT;
			$this->SetPageHelpCtx("helpctx_mb_mng_users~$this->action");
			switch ($this->action) {
			case "main":
				if (db_isset()) {
					echo "<h2>Users of Database \"{$_SESSION['APPDB']->dblongname}\"</h2>";
					$tbl_2col = new MB_Table();
					$tbl_2col->Begin2Col('New Users', '25%', 'center', 'Existing Users', '75%', 'center');
					$this->Button(null, 'Add by Invitation', 'mb_mng_users_invite.php');
					echo "<p>";
					text_small("If you don't know the users' logins<br>or they don't yet have one.");
					echo "<p>";
					$this->Button(null, 'Add by Login', 'mb_mng_users_login.php');
					echo "<p>";
					text_small("If you know the users' logins.");
					$tbl_2col->Mid2Col();
					$this->show_users($_SESSION['APPDB']->dbname, $_SESSION['APPDB']->dblongname, $_SESSION['APPDB']->db_id);
					$tbl_2col->End2Col();
				}
				else
					$this->MessageError("Database not selected."); // not supposed to ever happen
				break;
			case "btn_send":
				$this->show_send_form();
				break;
			case "btn_revoke":
				$this->show_revoke_form();
				break;
			case "btn_roles":
				$this->show_role_form();
				break;
			case "btn_send_go":
				$this->MessageError("Email could not be sent to these addresses:<p>");
				$this->ShowArray(array("Login", "MySQL Error", "MySQL Error Message"), $this->send_failed_logins);
				echo "<p>";
				$this->Button("main", "Back to Manage Users");
				break;
			case "btn_roles_go":
				$this->MessageError("Errors were generated from the attempt to change roles:<p>");
				$this->ShowArray(array("Login", "MySQL Error", "MySQL Error Message"), $this->role_failed_logins);
				echo "<p>";
				$this->Button("main", "Back to Manage Users");
			}
		}

		function show_users($dbname, $dblongname, $db_id) {
			$uresult = $_SESSION['APPDB']->dbmain->db_query("select mb_user.user_id, login, firstname, lastname, email, role_id
			  from mb_db
			  join mb_user_db using(db_id)
			  join mb_user using(user_id)
			  where mb_user_db.db_id = $db_id and mb_user_db.role_id <> " . ROLE_OWNER . " order by lastname");
			$have_users = mysql_num_rows($uresult) > 0;
			if ($have_users)
				text_small('Select one or more users and then press button:<p>');
			else
				text_small('You have to add users (use buttons at left) before the buttons below become enabled.<p>');
			$this->Button("btn_send", "Send Email", null, null, null, $have_users);
			$this->ButtonSpaced("btn_revoke", "Revoke Access", null, null, null, $have_users);
			$this->ButtonSpaced("btn_roles", "Change Roles", null, null, null, $have_users);
			echo "<p>";
			$tbl = new MB_Table();
			$tbl->Begin();
			$tbl->ColHdg('User Name');
			$tbl->ColHdg('Login');
			$tbl->ColHdg('Role');
			$tbl->ColHdg('Email');
			$tbl->ColHdgOpen('Select', true, false, 1, true);
			echo '<br><input type="button" value="All" onclick="selAll(this.form, true)" class="formButtonSmall">';
			echo '&nbsp;&nbsp;<input type="button" value="None" onclick="selAll(this.form, false)" class="formButtonSmall">';
			echo '</td>';
			$tbl->Body();
			if ($have_users)
				while ($urow = mysql_fetch_assoc($uresult)) {
					echo '<tr>';
					echo '<td>' . $this->cell_nonempty($urow['firstname'] . ' ' . $urow['lastname']) . '</td>';
					echo '<td>' . $this->cell_nonempty($urow['login']) . '</td>';
					echo '<td>' . $this->cell_nonempty(role_name($urow['role_id'])) . '</td>';
					if (strlen($urow['email']) == 0)
						echo '<td>&nbsp;</td>';
					else
						echo '<td>' . $urow['email'] . '</td>';
						// 2 ways to send email are confusing
						//echo '<td><a href="mailto:' . $urow['email'] . '">' . $urow['email'] . '</a></td>';
					echo '<td align="center">' . '<input type="checkbox" name="sel[' . $urow['login'] . ':' . $urow['user_id'] . '~' . $urow['email'] . ']">' . '</td>';
					echo '</tr>' . "\n";
				}
			else
				echo "<tr><td colspan='5' align='center'>No users</td></tr>";
			$tbl->End();;
			//button_bar_sep();
			//button_bar(array('Back to Home Page', 'account-main.php'));
		}

		function cell_nonempty($s) {
			if (strlen(trim($s)) == 0)
				return '&nbsp;';
			return $s;
		}

		function show_revoke_form() {
			global $color_bg;

			$sel = $_POST['sel'];
			echo '<p>Access to database "' . $_SESSION['APPDB']->dblongname . '" will be revoked for the following users.';
			echo ' They still remain users and retain access (if they have it) to other databases.';
			echo '<p><table border=0 cellspacing=0 cellpadding=10><tr><td width="100"></td><td bgcolor="' . $color_bg . '" >';
			$firstrow = true;
			foreach ($sel as $key => $value) {
				$pos_colon = strpos($key, ':');
				$pos_tilde = strpos($key, '~');
				$u = substr($key, 0, $pos_colon);
				if (strlen($u) > 0) {
					if ($firstrow)
						$firstrow = false;
					else
						echo '<br>';
					echo $u;
					$id = substr($key, $pos_colon + 1, $pos_tilde - $pos_colon - 1);
					$userlst[] = $id;
					$loginlst[$id] = $u;
				}
			}
			echo '</td></tr></table>';
			$_SESSION['userlist'] = &$userlst;
			$_SESSION['loginlst'] = &$loginlst;
			echo "<p>";
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Press <i>Revoke</i> to revoke access.");
			$this->Button("btn_revoke_go", "Revoke");
			$this->ButtonSpaced("main", "Back to Manage Users");
			$tbl->FormCellEnd();

			$tbl->End();
		}

		function show_send_form() {
			global $color_bg;

			echo '<p>Enter your subject and message. When you press the Send button, separate emails will be sent to:<p>';
			echo '<p><table border=0 cellspacing=0 cellpadding=10><tr><td width="100"></td><td bgcolor="' . $color_bg . '" >';
			$firstrow = true;
			if (isset($_POST['sel'])) {
				$sel = $_POST['sel'];
				foreach ($sel as $key => $value) {
					$a = substr($key, strpos($key, '~') + 1);
					if (strlen($a) > 0) {
						if ($firstrow)
							$firstrow = false;
						else
							echo '<br>';
						echo $a;
						$addr[] = $a;
					}
				}
				$_SESSION['addrs'] = &$addr;
			}
			else
				foreach ($_SESSION['addrs'] as $a) {
					if ($firstrow)
						$firstrow = false;
					else
						echo '<br>';
					echo $a;
				}
			echo '</td></tr></table><p>';

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Enter the subject.");
			$this->FieldLabel("Subject", true);
			$subject = str_replace('"', "&quot;", $this->subject);
			echo "<input type='text' name='f_subj' size='50' onChange='set_dirty();' onKeydown='set_dirty();'
			  value=\"$subject\">";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Enter the message.");
			$this->FieldLabel("Message", true);
			echo "<textarea name='f_msg' rows='15' cols='50' onChange='set_dirty();' onKeydown='set_dirty();'>$this->message</textarea>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("To preview your email,
			  press <i>Preview</i>.
			  When you're ready, press <i>Send</i>.");
			$this->ButtonNoDirtyCheck("btn_Preview", "Preview");
			$this->ButtonSpacer();
			$this->ButtonNoDirtyCheck("btn_send_go", "Send");
			$this->ButtonSpaced("main", "Back to Manage Users");
			$tbl->FormCellEnd();

			$tbl->End();
		}

		function show_role_form() {
			global $color_bg;

			$sel = $_POST['sel'];
			echo '<p>Roles for database "' . $_SESSION['APPDB']->dblongname . '" will be changed for the following user(s):';
			echo '<p><table border=0 cellspacing=0 cellpadding=10><tr><td width="100"></td><td bgcolor="' . $color_bg . '" >';
			$firstrow = true;
			foreach ($sel as $key => $value) {
				$pos_colon = strpos($key, ':');
				$pos_tilde = strpos($key, '~');
				$u = substr($key, 0, $pos_colon);
				if (strlen($u) > 0) {
					if ($firstrow)
						$firstrow = false;
					else
						echo '<br>';
					echo $u;
					$id = substr($key, $pos_colon + 1, $pos_tilde - $pos_colon - 1);
					$userlst[] = $id;
					$loginlst[$id] = $u;
				}
			}
			echo '</td></tr></table>';
			$_SESSION['userlist'] = $userlst;
			$_SESSION['loginlst'] = $loginlst;
			echo "<p>";

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Choose the new role.");
			$this->FieldLabel("Role", true);
			echo "<select name='mbfv_role_id'>";
			echo "<option value=" . ROLE_SEE . ">see</option>";
			echo "<option value=" . ROLE_EDIT . ">edit</option>";
			echo "</select>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press <i>Change</i> to change the role.");
			$this->Button("btn_roles_go", "Change");
			$this->ButtonSpaced("main", "Back to Manage Users");
			$tbl->FormCellEnd();

			$tbl->End();
		}

		function action_send_go($preview) {
			$this->subject = trim(stripslashes($_POST['f_subj']));
			$this->message = stripslashes($_POST['f_msg']);
			if (empty($this->subject) || empty($this->message)) {
				$this->AddMessageError("Subject and/or Message are empty.");
				$this->action = "btn_send";
				return;
			}
			if (empty($_SESSION['MUDBAG_USER']))
				$from = MB_EMAIL_CONTACT;
			else
				$from = $_SESSION['MUDBAG_USER']->email;
			$ok_count = 0;
			foreach ($_SESSION['addrs'] as $to) {
				if (mb_mail($to, $this->subject, $this->message, "From: $from", $preview))
					$ok_count++;
				else
					$this->send_failed_logins[] = array($to, 0, "Mail not accepted for delivery.");
				if ($preview) {
					$this->action = "btn_send";
					break;
				}
			}
			if ($ok_count > 0) {
				$this->send_ok_msg = "$ok_count email(s) were " . ($preview ? "previewed" : "sent") . " successfully.";
				$this->AddMessageConfirmation($this->send_ok_msg);
				if (empty($this->send_failed_logins) && !$preview)
					$this->action = "main";
			}
		}

		function action_revoke_go() {
			revoke_users($_SESSION['userlist'], $_SESSION['loginlst']);
			$this->AddMessageConfirmation("Access revocation was successful.");
			$this->action = "main";
		}

		function action_roles_go() {
			$role_id = $_POST['mbfv_role_id'];
			foreach ($_SESSION['userlist'] as $user_id) {
				$login = $_SESSION['loginlst'][$user_id];
				if (!set_role($user_id, $login, $_SESSION['APPDB']->db_id,
				  $role_id, &$errnum, &$errmsg)) {
					$this->role_failed_logins[] = array($login, $errnum, $errmsg);
				}
			}
			if (empty($this->role_failed_logins)) {
				$this->action = "main";
				$this->AddMessageConfirmation("Roles have been changed.");
			}
			// Otherwise, we'll get a "btn_roles_go" callback to display the error info.
		}
	}

	$frm = new MB_MngUsers();
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right
	$hdg = "Manage Users";
	$frm->Go(array("Issued Invitations", "mb_mng_users_invite.php?list=1"), $hdg, "helpctx_mb_mng_users~main");
?>
