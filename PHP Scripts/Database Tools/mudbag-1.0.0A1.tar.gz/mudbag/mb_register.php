<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_register.php,v 1.1.1.1 2005/07/13 00:22:03 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");

	$want_db_query_echo = false;

/*
	Parameters:
		mbp_new: new registration (vs. update)
*/

	class UserDataForm extends MB_User {
		var $a_password;
		var $a_passrepeat;

		function UserDataForm($account_id = 1) {
			parent::MB_User();
			$this->account_id = $account_id;
		}
	}

	class MB_Register extends MB_BaseScreen {
		var $mbp_new;
		var $owner = true;
		var $user_data;
		var $missing;
		var $db;
		var $registered_ok;
		var $code;

		function MB_Register($continue) {
			parent::MB_BaseScreen($continue);
			$this->db = new MB_DB();
		}

		function ShowForm() {
			if (!isset($this->user_data))
				$this->user_data = $_SESSION['MUDBAG_USER'];
			if ($this->registered_ok)
				$this->show_confirmation_form();
			else
				$this->show_register_form($this->user_data);
		}

		function Callback($tag, $val) {
			switch ($tag) {
			case "mb_register_register":
				$this->user_data = new UserDataForm();
				$this->register_user($this->user_data);
				break;
			case "mb_register_update":
				$this->user_data = new UserDataForm($_SESSION['MUDBAG_USER']->account_id);
				$this->register_user($this->user_data);
				break;
			default:
				echo "<p>Unknown callback $tag => $val";
			}
			$this->SetActiveDatabase(null);
			$this->SetLevelHome();
		}

		function show_confirmation_form() {
			if ($this->mbp_new) {
				$this->MessageConfirmation("You are now registered as a Mudbag user.");
				echo <<<EOT
				<p>Next time you login, use the User ID "{$this->user_data->login}" and the password you entered
				  when you registered.
				<p>Press the <i>Account</i> button at the top to see (and perhaps change) your account information,
				including your limits (maximum number of databases, tables, etc.).
				<p>Press the button below to begin using Mudbag.<p>
EOT;
			}
			else {
				$this->MessageConfirmation("Your account has been updated.");
				echo "<p>Press the button below to continue using Mudbag.<p>";
			}
			$this->Button(null, "Continue", "mb_dbmain.php");
		}

		function register_user(&$user_data) {
//			$_SESSION['password'] = $_POST['Ecom_User_Password'];
//			$_SESSION['passrepeat'] = $_POST['f_passrepeat'];
			$user_data->a_password = $_POST['Ecom_User_Password'];
			$user_data->a_passrepeat = $_POST['f_passrepeat'];
			$user_data->login = $_POST['Ecom_User_ID'];
			$user_data->firstname = $_POST['firstname'];
			$user_data->lastname = $_POST['lastname'];
			$user_data->street1 = $_POST['Ecom_BillTo_Postal_Street_Line1'];
			$user_data->street2 = $_POST['Ecom_BillTo_Postal_Street_Line2'];
			$user_data->city = $_POST['Ecom_BillTo_Postal_City'];
			$user_data->state = $_POST['Ecom_BillTo_Postal_StateProv'];
			$user_data->country = $_POST['Ecom_BillTo_Telecom_CountryCode'];
			$user_data->zip = $_POST['Ecom_BillTo_Postal_PostalCode'];
			$user_data->phone = $_POST['Ecom_BillTo_Telecom_Phone_Number'];
			$user_data->email = $_POST['Ecom_BillTo_Online_Email'];

			$this->owner = (!isset($this->code) || $this->code == 0);
			if ($this->valid_signup($user_data)) {
				$this->registered_ok = true;
				if ($this->mbp_new) {
					$this->session_create($user_data);
				}
				else
					$_SESSION['MUDBAG_USER']->from_obj($user_data);
				$_SESSION['MUDBAG_USER']->password = $user_data->a_password; // clear text version
				$this->insert_data($user_data);
				if ($this->mbp_new && $this->owner) {
					$dbapp = new MB_AppDB();
					if ($dbapp->create($_POST['f_db_long'], true, $msg)) {
						$dbapp->dbmain->db_log("register", $user_data->login);
						$this->SetActiveTable($_POST['f_db_long']);
					}
					else {
						$this->AddMessageError($msg);
						$this->registered_ok = false;
					}
				}
				token_redeem($this->code, $this->db, $this);
			}
//			else {
//				//header("Location: signup.php?new=" . $new . '&code=' . $code); // something about that code
//			}
		}

		function valid_signup(&$user_data)
		{
			// Check that login is unique and has the right characters.
			$login = nvl($user_data->login);
			if ($this->mbp_new) {
				if (!preg_match('/^[A-Za-z][A-Za-z0-9]{1,9}$/', $login)) {
					$this->AddMessageError("Login must be from 1 to 10 letters and digits, starting with a letter. Please choose another one.");
					return false;
				}
				$stmt = $this->db->db_query("select user_id from mb_user where login = '$login'", true);
				if (!$stmt) {
					if (mysql_errno() == 1146) {
						echo "<p>Table mb_user does not exist. Are you sure Mudbag has been installed by running install.php?";
						exit;
					}
					else
						exit("MySQL error: " . mysql_error() . " [" . mysql_errno() . "]");
				}
				if (mysql_num_rows($stmt)) {
					$this->AddMessageError("Login already taken. Please choose another one.");
					return false;
				}
			}
			// Check that passwords match.
			if (nvl($user_data->a_password) != nvl($user_data->a_passrepeat)) {
				$user_data->a_password = $user_data->a_passrepeat = "";
				$this->AddMessageError("Passwords don't match. Please retype them.");
				return false;
			}

			// Check that password is long enough.
			if (($this->mbp_new || !empty($user_data->a_password)) && strlen($user_data->a_password) < 6) {
				$user_data->a_password = $user_data->a_passrepeat = "";
				$this->AddMessageError("Password must be at least 6 characters.");
				return false;
			}

			// Check database name
			if ($this->mbp_new && $this->owner && !validate_dblongname(nvl($_POST['f_db_long']), $msg)) {
				$this->AddMessageError($msg);
				return false;
			}

			// Check for required fields.
			if (strlen($user_data->login) == 0) {
				$this->missing[] = "Login";
			}
			if ($this->mbp_new && strlen($user_data->a_password) == 0) {
				$this->missing[] = "Password";
			}
			if (strlen($user_data->firstname) == 0) {
				$this->missing[] = "First Name";
			}
			if (strlen($user_data->lastname) == 0) {
				$this->missing[] = "Last Name";
			}
			if (strlen($user_data->street1) == 0) {
				$this->missing[] = "Street (Line 1)";
			}
			if (strlen($user_data->city) == 0) {
				$this->missing[] = "City";
			}
			if (strlen($user_data->state) == 0) {
				$this->missing[] = "State";
			}
			if (strlen($user_data->zip) == 0) {
				$this->missing[] = "ZIP";
			}
			if (strlen($user_data->country) == 0) {
				$this->missing[] = "Country";
			}
			if (strlen($user_data->phone) == 0) {
				$this->missing[] = "Phone";
			}
			if (strlen($user_data->email) == 0) {
				$this->missing[] = "Email";
			}
			if (count($this->missing) > 0)
				return false;
			return true;
		}

		function insert_data(&$user_data)
		{
			if ($this->mbp_new) {
				$_SESSION['MUDBAG_USER']->user_id =
				  $this->db->db_query("insert into mb_user (login, password, firstname, lastname, street1, street2, city, state,
				  zip, country, phone, email, account_id) values(
				  '$user_data->login',
				  PASSWORD('$user_data->a_password'),
				  '$user_data->firstname',
				  '$user_data->lastname',
				  '$user_data->street1',
				  '$user_data->street2',
				  '$user_data->city',
				  '$user_data->state',
				  '$user_data->zip',
				  '$user_data->country',
				  '$user_data->phone',
				  '$user_data->email'," .
				  ACCOUNT_ID_FREE . "
				  )", true);
				// Following was commented out in the older version, too. Not sure what's going on with roles.
			 	//$role_id = ($this->owner ? 1 : 3);
				//if ($this->owner)
				//	db_query('insert into user_db (user_id, db_id, role_id) values(' . $_SESSION['MUDBAG_USER']->user_id . ', ' .
				//	  $_SESSION['db_id'] . ', ' . $role_id . ')');
			}
			else {
				$query = "update mb_user set ";
				if ($_SESSION['MUDBAG_USER']->password != "") {
					$query .= " password = PASSWORD('{$_SESSION['MUDBAG_USER']->password}'),";
				}
				$query .= "
				  firstname = '$user_data->firstname',
				  lastname = '$user_data->lastname',
				  street1 = '$user_data->street1',
				  street2 = '$user_data->street2',
				  city = '$user_data->city',
				  state = '$user_data->state',
				  zip = '$user_data->zip',
				  country = '$user_data->country',
				  phone = '$user_data->phone',
				  email = '$user_data->email'
				  where login = '$user_data->login'";
				$this->db->db_query($query);
//				if ($_SESSION['MUDBAG_USER']->password != "")
//					$this->db->db_query("set password for '" . $_SESSION['MUDBAG_USER']->get_mysql_user() .
//					  "'@'localhost' = PASSWORD('{$_SESSION['MUDBAG_USER']->password}')");
			}
		}

		// Field names from http://www.ietf.org/rfc/rfc3106.txt
		function show_register_form(&$user_data) {
			if ($this->mbp_new) {
				echo "<h1>This is beta software! Please don't use it for anything important.</h1>";
				echo "<table border='1' cellspacing='0' cellpadding='5'><tr><td>";
				require("help/terms_text.html");
				echo "</td></tr></table>";
				echo "<h2>If you agree to the above terms and accept the warranty, please fill out the form below.</h2>";
			}
			$req_mark = "<span class=\"FieldLabelReqMark\">*</span>";
			echo <<<EOT
				<script language="JavaScript">

				function compose_db_name(userID_field, db_field) {
					//alert(userID_field.value);
					db_field.value = 'DB_' + userID_field.value;
				}

				</script>
EOT;
			$this->MessageError("The following required fields are missing:", $this->missing);

			$f_db_long = nvl($_POST['f_db_long']);
			if (empty($f_db_long))
				$f_db_long = nvl($_SESSION['APPDB']->dblongname);

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();
			if ($this->mbp_new) {
				$password_req_mark = $req_mark;
				$instr = "Enter your desired User ID and password (repeated for verification).";
			}
			else {
				$password_req_mark = "";
				$instr = "To change your password, enter it twice. Otherwise, leave these fields blank.";
			}

			$tbl->FormCellBegin($instr);
			$this->FieldLabel("User ID", true);
			echo "<input type=\"text\" size=\"12\" name=\"Ecom_User_ID\"
				value=\"" . nvl($user_data->login) . "\"" .
					($this->mbp_new ? "" : " readonly ") .
					" onChange=\"compose_db_name(Ecom_User_ID, f_db_long); set_dirty();\"
					onKeydown=\"set_dirty();\">
				<br><small>(Up to 10 letters and digits; no spaces.)</small>";
			?>
			<p><table border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><span class="FieldLabel">Password<? echo $password_req_mark; ?></span></td>
				<td>&nbsp;&nbsp;&nbsp;<span class="FieldLabel">Repeat Password<? echo $password_req_mark; ?></span></td>
			</tr>
			<tr>
				<td><input type="password" size="20" name="Ecom_User_Password"
				  <?php echo "value='" . nvl($user_data->a_password) . "'"; ?>
				  onChange='set_dirty();' onKeydown='set_dirty();'></td>
				<td>&nbsp;&nbsp;&nbsp;<input type="password" size="20" name="f_passrepeat"
				  <?php echo "value='" . nvl($user_data->a_passrepeat) . "'"; ?>
				  onChange='set_dirty();' onKeydown='set_dirty();'></td>
			</tr>
			<tr>
				<td><small>(At least 6 characters.)</small></td>
			</tr>
		</table>
			<?php
			$tbl->FormCellEnd();

			if ((!isset($this->code) || $this->code == 0) && $this->mbp_new) {
				$tbl->FormCellBegin("Name for initial database. (You can create more later.)");
				$this->FieldLabel("Database", true);
				echo "<input type=\"text\" size=\"20\" name=\"f_db_long\"
				  value=\"$f_db_long\"
				  onChange='set_dirty();' onKeydown='set_dirty();'>
				  <br><small>(Up to 20 letters, digits, and spaces.)</small>";
				$tbl->FormCellEnd();
			}

			if ($this->mbp_new)
				$instr = "Enter <b>your</b> registration information.";
			else
				$instr = "Make any changes here.";
			$instr .= "<p><small>By entering your email address, you indicate that you wish to receive emails from
				  Basepath Associates.</small>";
			$tbl->FormCellBegin($instr);
			?>
			<table>
			<tr>
				<td><table cellspacing="0" cellpadding="0">
				<tr>
				<td>First Name<? echo $req_mark; ?></td><td>&nbsp;&nbsp;&nbsp;Last Name<? echo $req_mark; ?></td>
				<tr><td>
					<input type="text" name="firstname" size="25" <?php echo " value='" . nvl($user_data->firstname) . "'"; ?>
					onChange='set_dirty();' onKeydown='set_dirty();'>
				</td><td>&nbsp;&nbsp;&nbsp;<input type="text" name="lastname" size="40" <?php echo " value='" .
				  nvl($user_data->lastname) . "'"; ?>
				  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
				</tr></table></td>
			</tr>
			<tr>
				<td>Street (Line 1)<? echo $req_mark; ?><br>
					<input type="text" size="50" name="Ecom_BillTo_Postal_Street_Line1" <?php echo " value='" .
					  nvl($user_data->street1) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
			</tr>
			<tr>
				<td>Street (Line 2)<br>
					<input type="text" size="50" name="Ecom_BillTo_Postal_Street_Line2" <?php echo " value='" .
					  nvl($user_data->street2) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
			</tr>
			<tr>
				<td>
					<table cellspacing="0" cellpadding="0">
					<tr>
						<td>City<? echo $req_mark; ?></td>
						<td>&nbsp;&nbsp;&nbsp;State<? echo $req_mark; ?></td>
						<td>&nbsp;&nbsp;&nbsp;ZIP<? echo $req_mark; ?></td>
					</tr>
					<tr>
						<td><input type="text" size="20" name="Ecom_BillTo_Postal_City" <?php echo " value='" .
						  nvl($user_data->city) . "'"; ?>
						  onChange='set_dirty();' onKeydown='set_dirty();'></td>
						<td>&nbsp;&nbsp;&nbsp;<select name="Ecom_BillTo_Postal_StateProv" onChange="set_dirty();">
							<option value="">Select One</option>
							<?php $st = nvl($user_data->state); ?>
							<option value="ns" <?php if ($st == "ns") { echo 'selected'; } ?>>[none]</option>
							<option value="AL" <?php if ($st == "AL") { echo 'selected'; } ?>>Alabama (AL)</option>
							<option value="AK" <?php if ($st == "AK") { echo 'selected'; } ?>>Alaska (AK)</option>
							<option value="AZ" <?php if ($st == "AZ") { echo 'selected'; } ?>>Arizona (AZ)</option>
							<option value="AR" <?php if ($st == "AR") { echo 'selected'; } ?>>Arkansas (AR)</option>
							<option value="CA" <?php if ($st == "CA") { echo 'selected'; } ?>>California (CA)</option>
							<option value="CO" <?php if ($st == "CO") { echo 'selected'; } ?>>Colorado (CO)</option>
							<option value="CT" <?php if ($st == "CT") { echo 'selected'; } ?>>Connecticut (CT)</option>
							<option value="DE" <?php if ($st == "DE") { echo 'selected'; } ?>>Delaware (DE)</option>
							<option value="DC" <?php if ($st == "DC") { echo 'selected'; } ?>>District of Columbia (DC)</option>
							<option value="FL" <?php if ($st == "FL") { echo 'selected'; } ?>>Florida (FL)</option>
							<option value="GA" <?php if ($st == "GA") { echo 'selected'; } ?>>Georgia (GA)</option>
							<option value="HI" <?php if ($st == "HI") { echo 'selected'; } ?>>Hawaii (HI)</option>
							<option value="ID" <?php if ($st == "ID") { echo 'selected'; } ?>>Idaho (ID)</option>
							<option value="IL" <?php if ($st == "IL") { echo 'selected'; } ?>>Illinois (IL)</option>
							<option value="IN" <?php if ($st == "IN") { echo 'selected'; } ?>>Indiana (IN)</option>
							<option value="IA" <?php if ($st == "IA") { echo 'selected'; } ?>>Iowa (IA)</option>
							<option value="KS" <?php if ($st == "KS") { echo 'selected'; } ?>>Kansas (KS)</option>
							<option value="KY" <?php if ($st == "KY") { echo 'selected'; } ?>>Kentucky (KY)</option>
							<option value="LA" <?php if ($st == "LA") { echo 'selected'; } ?>>Louisiana (LA)</option>
							<option value="ME" <?php if ($st == "ME") { echo 'selected'; } ?>>Maine (ME)</option>
							<option value="MD" <?php if ($st == "MD") { echo 'selected'; } ?>>Maryland (MD)</option>
							<option value="MA" <?php if ($st == "MA") { echo 'selected'; } ?>>Massachusetts (MA)</option>
							<option value="MI" <?php if ($st == "MI") { echo 'selected'; } ?>>Michigan (MI)</option>
							<option value="MN" <?php if ($st == "MN") { echo 'selected'; } ?>>Minnesota (MN)</option>
							<option value="MS" <?php if ($st == "MS") { echo 'selected'; } ?>>Mississippi (MS)</option>
							<option value="MO" <?php if ($st == "MO") { echo 'selected'; } ?>>Missouri (MO)</option>
							<option value="MT" <?php if ($st == "MT") { echo 'selected'; } ?>>Montana (MT)</option>
							<option value="NE" <?php if ($st == "NE") { echo 'selected'; } ?>>Nebraska (NE)</option>
							<option value="NV" <?php if ($st == "NV") { echo 'selected'; } ?>>Nevada (NV)</option>
							<option value="NH" <?php if ($st == "NH") { echo 'selected'; } ?>>New Hampshire (NH)</option>
							<option value="NJ" <?php if ($st == "NJ") { echo 'selected'; } ?>>New Jersey (NJ)</option>
							<option value="NM" <?php if ($st == "NM") { echo 'selected'; } ?>>New Mexico (NM)</option>
							<option value="NY" <?php if ($st == "NY") { echo 'selected'; } ?>>New York (NY)</option>
							<option value="NC" <?php if ($st == "NC") { echo 'selected'; } ?>>North Carolina (NC)</option>
							<option value="ND" <?php if ($st == "ND") { echo 'selected'; } ?>>North Dakota (ND)</option>
							<option value="OH" <?php if ($st == "OH") { echo 'selected'; } ?>>Ohio (OH)</option>
							<option value="OK" <?php if ($st == "OK") { echo 'selected'; } ?>>Oklahoma (OK)</option>
							<option value="OR" <?php if ($st == "OR") { echo 'selected'; } ?>>Oregon (OR)</option>
							<option value="PA" <?php if ($st == "PA") { echo 'selected'; } ?>>Pennsylvania (PA)</option>
							<option value="RI" <?php if ($st == "RI") { echo 'selected'; } ?>>Rhode Island (RI)</option>
							<option value="SC" <?php if ($st == "SC") { echo 'selected'; } ?>>South Carolina (SC)</option>
							<option value="SD" <?php if ($st == "SD") { echo 'selected'; } ?>>South Dakota (SD)</option>
							<option value="TN" <?php if ($st == "TN") { echo 'selected'; } ?>>Tennessee (TN)</option>
							<option value="TX" <?php if ($st == "TX") { echo 'selected'; } ?>>Texas (TX)</option>
							<option value="UT" <?php if ($st == "UT") { echo 'selected'; } ?>>Utah (UT)</option>
							<option value="VT" <?php if ($st == "VT") { echo 'selected'; } ?>>Vermont (VT)</option>
							<option value="VA" <?php if ($st == "VA") { echo 'selected'; } ?>>Virginia (VA)</option>
							<option value="WA" <?php if ($st == "WA") { echo 'selected'; } ?>>Washington (WA)</option>
							<option value="WV" <?php if ($st == "WV") { echo 'selected'; } ?>>West Virginia (WV)</option>
							<option value="WI" <?php if ($st == "WI") { echo 'selected'; } ?>>Wisconsin (WI)</option>
							<option value="WY" <?php if ($st == "WY") { echo 'selected'; } ?>>Wyoming (WY)</option>
						</select></td>
					<td>&nbsp;&nbsp;&nbsp;<input type="text" size="5" name="Ecom_BillTo_Postal_PostalCode"
					  <?php echo " value='" . nvl($user_data->zip) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'></td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td>
					Country<? echo $req_mark; ?><br>
					<input type="text" size="50" name="Ecom_BillTo_Telecom_CountryCode"
					  <?php echo " value='" . nvl($user_data->country) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
			</tr>
			<tr>
				<td>
					Phone<? echo $req_mark; ?><br>
					<input type="text" size="30" name="Ecom_BillTo_Telecom_Phone_Number"
					  <?php echo " value='" . nvl($user_data->phone) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
			</tr>
			<tr>
				<td>
					Email<? echo $req_mark; ?><br>
					<input type="text" size="50" name="Ecom_BillTo_Online_Email"
					  <?php echo " value='" . nvl($user_data->email) . "'"; ?>
					  onChange='set_dirty();' onKeydown='set_dirty();'>
				</td>
			</tr>
			</table>
			<?php
			$tbl->FormCellEnd();

			if ($this->mbp_new)
				$instr = "When you've filled out the form, click <i>Save</i> to submit your registration.";
			else
				$instr = "Click <i>Save</i> to update your information.";
			$tbl->FormCellBegin($instr);
			if ($this->mbp_new)
				$this->ButtonNoDirtyCheck("mb_register_register", "Save");
			else
				$this->ButtonNoDirtyCheck("mb_register_update", "Save");
			if ($this->mbp_new)
				$this->ButtonSpaced(null, "Back To Login", "mb_login.php?code={$_GET['code']}");
			else
				$this->ButtonSpaced(null, "To Mudbag Home", "mb_dbmain.php");
			$tbl->FormCellEnd();
			$tbl->End();
		}
	}

	$frm = new MB_Register(!isset($mbp_new));
	$frm->code = nvl($code);
	$frm->mbp_new = isset($mbp_new);
	$frm->Go(null, $frm->mbp_new ? "Mudbag Registration" : "Personal Information", "helpctx_mb_register", false, null, $frm->code == 0, true);

?>
