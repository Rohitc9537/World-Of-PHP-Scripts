<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable_row.php,v 1.1.1.1 2005/07/13 00:22:01 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBTableRow extends MB_DBScreen {

		var $add;
		var $correct = false;
		var $showing_view;
		var $read_only;
		var $saveok;
		var $deleteok = false;
		var $rownum;
		var $start_row;
		var $data;

		function MB_DBTableRow() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			if (substr($tag, 0, 4) == "btn_")
				$this->callback_action($tag);
			else {
				parent::Callback($tag);
				exit("debugging exit");
			}
		}

		function callback_action($tag) {
			global $want_db_query_echo;

			if ($tag == 'btn_Delete') {
				$want_db_query_echo = false; // so header() will work
				$_SESSION['APPDB']->dbmain->db_query_user('delete from ' . $_SESSION['APPDB']->internal_name($tbl) . ' where _rowID = ' . $_SESSION['active_rowid']);
				$this->deleteok = true; // potential use in case we decide later to stay here
				header("Location: mb_dbtable.php?start=$this->start_row&deleteok=1" . ($this->showing_view ? "&view={$_SESSION['active_view_obj']->view_id}" : ""));
			}
			$this->data = &$_POST['data'];
			$this->saveok = false;
			if ($tag != 'btn_Next' && !$this->ValidateAndTranslate($this->data))
				return;
			$tbl = $_SESSION['active_view_obj']->table;
			if ($_SESSION['active_rowid'] < 1) { // Save for Add Record
				if ($tag != 'btn_SaveNew')
					die('db-table-row-action.php -- no row ID but not Save btn');
				$fields = '';
				$vals = '';
				foreach ($this->data as $field => $value) {
					$fields .= ",$field";
					// No need to call mysql_real_escape_string, because POST data has quotes already escaped
					if (strlen($value) == 0)
						$vals .= ",null";
					else
						$vals .= ",'$value'";
				}
				$fields = substr($fields, 1);
				$vals = substr($vals, 1);
				$_SESSION['APPDB']->dbmain->db_query_user('insert into ' . $_SESSION['APPDB']->internal_name($tbl) . '(' . $fields . ') values (' . $vals . ')');
				$this->saveok = true;
			}
			else {
				if ($tag == 'btn_Save' || $tag == 'btn_SaveNext') {
					$asgs = '';
					foreach ($this->data as $field => $value) {
						// No need to call mysql_real_escape_string, because POST data has quotes already escaped
						if (strlen($value) == 0)
							$asgs .= ",$field=null";
						else
							$asgs .= ",$field='$value'";
					}
					$asgs = substr($asgs, 1);
//$want_db_query_echo = true;
					$_SESSION['APPDB']->dbmain->db_query_user('update ' . $_SESSION['APPDB']->internal_name($tbl) . ' set ' . $asgs . ' where _rowID = ' . $_SESSION['active_rowid']);
					$this->saveok = true;
				}
				if ($this->saveok || $tag == 'btn_Next')
					if ($tag == 'btn_Save') {
						header("Location: mb_dbtable.php?start=$this->start_row&saveok=1");
					}
					else if ($tag == 'btn_Next' || $tag == 'btn_SaveNext') {
						if ($this->saveok)
							$saveok_str = "&saveok=1";
						else
							$saveok_str = "";
						header("Location: mb_dbtable_row.php?start=$this->start_row&edit=1&rownum=" . ($_SESSION['active_rownum'] + 1) . $saveok_str);
					}
					else
						die('db-table-row-action.php -- no button variables seem to be set');
			}
		}

		function ValidateAndTranslate(&$data) {
			$flds = &$_SESSION['active_fd'];
			// Unchecked checkboxes put nothing in $data
			foreach ($flds as $field => $fld)
				if ($fld->type == 'y' && !isset($data[$field]))
					$data[$field] = 0;
			$valid = true;
			foreach ($data as $field => $value) {
				$fvalid = true;
				$fld = &$flds[$field];
				$value = trim($value);
				switch ($fld->type) {
				case 'y':
					if ($value != '0')
						$value = 1;
					else
						$value = 0;
					break;
				case 'd':
					if (empty($value))
						$value = null;
					else if ($v = date_str_to_ISO8601($value))
						$value = $v;
					else {
						$fvalid = false;
						$this->AddMessageError("Date field \"$field\" improperly formatted.");
					}
					break;
				case 'n':
				case 'f':
					if (!valid_number($value)) {
						$fvalid = false;
						$this->AddMessageError("Numeric field \"$field\" improperly formatted.");
					}
				}
				$data[$field] = str_replace("\r", "", $value); // in case browser puts CRs in
				if ($fvalid && $fld->req && strlen($value) == 0) {
					$valid = false;
					$this->AddMessageError("Field $field is required.");
				}
				if (!$fvalid)
					$valid = false;
			}
			if (!$valid)
				$this->correct = true;
			return $valid;
		}

		function ShowForm() {
			if (/*$this->created*/false) {
			}
			else {
				$this->output_script_and_style();
				if ($_SESSION['active_query'])
					$result = $_SESSION['APPDB']->dbmain->db_query_user($_SESSION['active_query']);
				else {
					$this->MessageConfirmation("Table is empty &mdash; it has no fields.");
					return;
				}
				$num_rows = mysql_num_rows($result);
				if (!$this->add && $num_rows < 1) {
					echo "<br>query={$_SESSION['active_query']}";
					$this->MessageError("Table is empty.");
				}
				else if (!$this->add && $this->rownum >= $num_rows) {
					$this->rownum--;
					$this->MessageInfo('No more rows remain.');
					echo "<p>";
					$this->Button(null, $this->showing_view ? 'Back to View' : 'Back to Table Data', "mb_dbtable.php?start=$this->start_row" . ($this->showing_view ? "&view={$_SESSION['active_view_obj']->view_id}" : ""));
				}
				else {
					if ($this->add || $this->correct || mysql_data_seek($result, $this->rownum))
						if ($this->add || $this->correct || $row = mysql_fetch_row($result)) {
							//echo '<form name="recordform" class="nomargin_form" method="POST">'; // action will be supplied by JavaScript
							echo '<p>';
							if ($this->saveok) {
								$this->MessageConfirmation("Previous row was saved successfully.");
								if ($this->add)
									echo "<p>Now there are $num_rows row(s) total.<p>";
							}
							$had_required = false;
							$tbl_form = new MB_TableFormWithInstr();
							$tbl_form->Begin();
							if ($this->add)
								$instr = "Enter the data for the new record.";
							else
								$instr = "Edit the data for the current record.";
							$tbl_form->FormCellBegin($instr);
								//$tbl = new MB_Table();
								//$tbl->Begin(0, 5);
								//$tbl->Body();
								$n = mysql_num_fields($result);
								for ($i = 0; $i < $n; $i++) {
									$meta = mysql_fetch_field($result, $i);
									if ($meta->name == '_rowID') {
										if (!$this->add && !$this->correct)
											$_SESSION['active_rowid'] = $row[$i];
										continue;
									}
									if ($this->correct)
										$v = htmlspecialchars(nvl($this->data[$meta->name]));
									else if ($this->add) {
										$_SESSION['active_rowid'] = -1;
										$v = '';
									}
									else
										$v = htmlspecialchars($row[$i]);
									//echo '<tr><td align="right" valign="top"><b>' . $meta->name . '</b></td>';
									//echo '<td valign="top">';
									$fld = $_SESSION['active_fd'][$meta->name];
									$this->FieldLabel($meta->name, $fld->req);
									if ($fld->req)
										$had_required = true;
									switch ($fld->type) {
									case 't':
									case 'n':
									case 'd':
									case 'f':
										echo '<input type="text" size="' . $fld->cols . '"' . ($this->read_only ? 'disabled' : '') .
										  ' value="' . stripslashes($v) . '" name="data[' . $meta->name . ']"' .
										  " onChange='set_dirty();' onKeydown='set_dirty();'>";
										break;
									case 'm':
//for ($k = 0; $k < strlen($v); $k++) echo "[" . ord($v{$k}) . "]";
										echo '<textarea ' . ($this->read_only ? 'disabled' : '') .
										  ' rows="' . $fld->rows . '" cols="' . $fld->cols . '" name="data[' . $meta->name . ']"' .
										  "onChange='set_dirty();' onKeydown='set_dirty();'>" . stripslashes($v) . '</textarea>';
										break;
									case 'y':
										echo '<input type="checkbox" ' . ($this->read_only ? 'disabled' : '') .
										  ($v  ? ' checked' : '') . ' name="data[' . $meta->name . ']"' .
										  " onChange='set_dirty();'>";
										break;
									case 'c':
										echo '<select ' . ($this->read_only ? 'disabled' : '') .
										  ' name="data[' . $meta->name . ']"' .
										  "onChange='set_dirty();'>";
										$nc = count($fld->choices);
										for ($j = 0; $j < $nc; $j++)
											echo '<option ' . ($v == $fld->choices[$j] ? 'selected' : '') . '>' . $fld->choices[$j] . '</option>';
										echo '</select>';
										break;
									default:
										die('db-table-row.php: unknown type');
									}

									//echo '</td></tr>';
								}
								//$tbl->End();
							$tbl_form->FormCellEnd();
								if ($this->add)
									$instr = "Press <i>Save</i> to save the new record.";
								else if ($this->read_only)
									$instr = "Press <i>Next</i> to
									  navigate to the next record.";
								else
									$instr = "Press a button to save or delete the current record and optionally
									  navigate to the next record.";
							$tbl_form->FormCellBegin($instr);
								if ($this->add)
									$this->ButtonNoDirtyCheck("btn_SaveNew", "Save");
									//echo '<input type="submit" name="btn_SaveNew" value="Save" class="formButton" onClick="set_action();">';
								else {
									if ($this->read_only)
										$this->Button("btn_Next", "Next");
									else {
										$this->ButtonNoDirtyCheck("btn_Save", "Save");
										$this->ButtonSpacer();
										$this->ButtonNoDirtyCheck("btn_SaveNext", "Save & Next");
									$this->ButtonSpaced("btn_Next", "Next");
										$this->ButtonSpaced("btn_Delete", "Delete", null, "Press OK to lose all data in the record. Press Cancel to keep the record.", null, true, false);
									}
								}
							$this->ButtonSpaced(null, $this->showing_view ? 'Back to View' : 'Back to Table Data', "mb_dbtable.php?start=$this->start_row" . ($this->showing_view ? "&view={$_SESSION['active_view_obj']->view_id}" : ""));
							if (!$this->read_only && $this->showing_view)
								echo "<p>Added or edited record won't appear in view \"{$_SESSION['active_view_obj']->name}\"<br>
								  if it doesn't meet that view's filtering conditions.";
							$tbl_form->FormCellEnd();
							$tbl_form->End($had_required);
							//echo '</form>';
						}
						else
							$this->MessageError('Can\'t fetch row data.');
					else
						$this->MessageError('Can\'t seek to row.');
				}
			}
		}

		function output_script_and_style() {
			echo <<<EOT
				<script language="JavaScript">

				function set_action() {
					document.recordform.action = "db-table-row-action.php";
				}

				function confirm_delete() {
					var myForm = document.recordform;
					if (confirm('OK to delete record?'))
						set_action();
					else
						myForm.action = '';
				}

				</script>
EOT;
		}
	}

	$frm = new MB_DBTableRow();

////////////////////////////////////////////////////////////////////////
	if (isset($rownum)) {
		$_SESSION['active_rownum'] = $rownum;
		$frm->rownum = $rownum;
	}

	$frm->read_only = $_SESSION['APPDB']->is_readonly();
	$frm->showing_view = isset($_SESSION['active_view_obj']) && isset($_SESSION['active_view_obj']->name);
	$frm->add = isset($add);
	if ($frm->add)
		$hdg = 'Add Record to Table "' . $frm->active_table . '"';
	else if ($frm->read_only)
		$hdg = 'Record in Table "' . $frm->active_table . '"';
	else
		$hdg = 'Edit Record in Table "' . $frm->active_table . '"';
	if (!$frm->read_only)
		if ($frm->add)
			$toolbar = null;
		else
			$toolbar = null;
	else
		$toolbar = null;

	$frm->SetLevelTable(true);
	$frm->start_row = nvl($start, 1);

////////////////////////////////////////////////////////////////////////

	$frm->Go($toolbar, $hdg, "helpctx_mb_dbtable_row", false, null, true, true);
?>
