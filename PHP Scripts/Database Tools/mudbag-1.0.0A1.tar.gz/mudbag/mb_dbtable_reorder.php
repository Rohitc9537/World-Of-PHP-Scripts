<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable_reorder.php,v 1.1.1.1 2005/07/13 00:22:01 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	class MB_DBTableReorder extends MB_DBScreen {


		function MB_DBTableReorder() {
			parent::MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_ReorderAction":
				$this->ReorderAction($_GET['ids']);
				break;
			default:
				parent::Callback($tag);
			}
		}

		function ShowForm() {
			require("js-reorder.php");
			echo <<<EOT
				<script language="JavaScript">
					function do_save(frm) {
						var s = "";
						var lst = frm.fldlist;

						for (i = 0; i < lst.length; i++) {
							if (i > 0)
								s += ",";
							s += lst[i].value;
						}
						frm.action = "mb_dbtable_reorder.php?ids=" + s;
					}
				</script>
EOT;
			if (!isset($_SESSION['active_fd']) || count($_SESSION['active_fd']) < 1) {
				$this->MessageError("There are no fields to reorder.");
				echo "<p>";
				$this->Button(null, "Back to Table", "mb_dbtable.php?edit=1");
				return;
			}

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Select a field and use the arrow buttons to move it up or down.
			  Repeat until you're satisfied with the order.");
			echo '<table border="0" cellspacing="0" cellpadding="4"><tr>';
			echo '<td valign="middle">';
			$this->FieldLabel("Fields");
			echo '<select name="fldlist" size="20" onChange="sel_change(this.form, fldlist);">';
			foreach ($_SESSION['active_fd'] as $fd) {
				echo '<option value="' . $fd->field_id . '">' . $fd->name . '</option>';
			}
			echo '</select>';
			echo '</td><td valign="middle" align="center" width="30">';

				echo "<input type='button' name='btn_up' disabled value='&uarr;'
				  onclick='move(this.form, fldlist, -1); set_dirty();'
				  class='arrow_button'>";
				//echo "<img src='images/arrow-up.gif'>";
				//echo "</button>";
				echo "<br>&nbsp;<br>";
				echo "<input type='button' name='btn_down' disabled value='&darr;'
				  onclick='move(this.form, fldlist, 1); set_dirty();'
				  class='arrow_button'>";
				//echo "<img src='images/arrow-dn.gif'>";
				//echo "</button>";






//			echo '<input type=button name="btn_up" value="&uarr;" disabled onclick="move(this.form, fldlist, -1); set_dirty();"' .
//			  ">";
//			echo '<p><input type=button name="btn_down" value="&darr;" disabled onclick="move(this.form, fldlist, 1); set_dirty();"' .
//			  ">";
			echo '</td>';
			echo '</tr></table>';
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press the <i>Reorder</i> button to save the reordering.");
			$this->Button("btn_ReorderAction", "Reorder", null, null, "do_save(this.form);", true, false);
			$this->ButtonSpaced(null, "Back to Table", "mb_dbtable.php?edit=1");
			$tbl->FormCellEnd();

			$tbl->End(false);
		}

		function ReorderAction($ids) {
			$a = explode(",", $ids);
			$db = $_SESSION['APPDB']->dbmain;
			$db->db_query("begin");
			$seq = 0;
			$success = true;
			foreach ($a as $fid) {
				$seq++;
				if (!($success = $db->db_query_user("update mb_field set seq = $seq where field_id = $fid", true)))
					break;
			}
			if ($success) {
				$db->db_query("commit");
				header('Location: mb_dbtable.php?edit=1&reorderok=1');
			}
			$this->AddMessageErrorDb("Reorder failed", mysql_errno(), mysql_error());
			$db->db_query("rollback"); // must follow capture of error info
		}
	}

	$frm = new MB_DBTableReorder();

	$hdg = "Reorder Fields in Table \"$frm->active_table\"";
	$frm->Go(null, $hdg, "helpctx_mb_dbtable_reorder");
?>
