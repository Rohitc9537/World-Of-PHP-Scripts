<html>
<head>
<title>Mudbag Installation</title>
</head>
<body>
<h1>Mudbag Installation</h1>
<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: install.php,v 1.1.1.1 2005/07/13 00:21:55 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

// Feature disabled -- security problem.
// Log in as admin, or if badly broken, delete tables with MySQL utility.
//	if (isset($_GET['dropall']))
//		drop_all($_GET['dropall']);

	if (!mk_export_dir())
		exit("<p>(Mudbag has not been installed.)");

	if (!($conn = @mysql_connect(MB_HOST, MB_USER, MB_PASSWORD))) {
		echo "<p>Connection failed. MySQL message: " . mysql_error();
		switch (mysql_errno()) {
		case 1251:
			$user = MB_USER;
			echo <<<EOT
				<p>You're running MySQL 4.1 or later with an older PHP, and they use
				incompatible methods for encrypting passwords. Upgrade PHP, or
				convert your MySQL password by sending this SQL to MySQL:
				<p><code>set password for '$user'@'localhost' = old_password('PPP');</code>
				<p>where PPP is the password you typed into the setup.php file earlier.
				<p>Use the mysql command or the MySQL Query Browser to enter this SQL. For example:
<code><pre>C:\>mysql -u mysqlroot -p
Enter password: *********
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 200 to server version: 4.1.9-nt

Type 'help;' or '\h' for help. Type '\c' to clear the buffer.

mysql> set password for '$user'@'localhost' = old_password('watercooler');
Query OK, 0 rows affected (0.05 sec)

mysql></pre></code>
				<p>In the example, the mysql command is logged on as user mysqlroot, which is the root user
				for this particular MySQL installation.
				<p>Then run install.php again (usually you can just refresh the browser window).
EOT;
			break;
		case 1045:
			echo "<p>You have the wrong MySQL user and/or password in the setup.php file. Fix it and
			  run install.php again (you can just refresh the browser window).";
			break;
		default:
			echo "<p>MySQL error number: " . mysql_errno();
		}
		exit;
	}
	echo "<p>You have successfully connected to MySQL. Mudbag will now build its database.";
	echo "<p>";

	if (!$result = @mysql_query("show databases like '" . MB_DATABASE . "'", $conn)) {
		echo "<p>Unable to execute 'show databases' MySQL statement.";
		echo "<p>MySQL error: " . mysql_error() . " [" . mysql_errno() . "]";
		exit;
	}
	if (!mysql_fetch_array($result) && !@mysql_query("create database `" . MB_DATABASE . "`", $conn) && mysql_errno() != 1007 /* exists */) {
		echo "<p>Unable to create MySQL database " . MB_DATABASE . ".";
		echo "<p>MySQL error: " . mysql_error() . " [" . mysql_errno() . "]";
		echo "<p>The problem may be that user '" . MB_USER . "' doesn't have permission to create databases. If so,
		  change setup.php to specify a database that already exists,
		  or grant additional privileges to that user.
		  Then run install.php again (you can just refresh the browser window).";
		exit;
	}

	$db = new MB_DB();

	echo "<small><tt>";
	if (!$db->db_run_file("install.sql", true, true)) {
		echo "</tt></small>";
		echo "<p>MySQL error: " . mysql_error() . " [" . mysql_errno() . "]";
		echo "<p>Unable to create Mudbag's MySQL system tables.";
		echo "<p>Deleting the existing Mudbag tables (if any) and creating them again from scratch
			may fix the problem.";// <br>Click <a href='install.php?dropall=1'>here</a> to do this.";
		exit;
	}
	echo "</tt></small>";

	echo "<p>Mudbag's MySQL system tables created OK.";
	$account_id = $db->db_query("insert into mb_account (sku) values('ADMIN')");
	$db->db_query("insert into mb_user (login, password, account_id) values('admin', PASSWORD('mudbag'), $account_id)");
	echo <<<EOT
	<p><font color='green'>Installation complete!</font>
	<p>You can now log into Mudbag by clicking <a href='mb_login.php'>here</a> as:
	<p>&nbsp;&nbsp;&nbsp;&nbsp;User ID: admin
	<br>&nbsp;&nbsp;&nbsp;&nbsp;Password: mudbag
	<p>You should change your password at your first opportunity by pressing the <i>Account</i> button at the top
	of the window after you've logged in.
EOT;

function mk_export_dir() {
	if (is_writable(MB_EXPORT_DIR))
		return true;
	if (file_exists(MB_EXPORT_DIR)) {
		echo "<p><font color='red'><b>ERROR:</b> Subdirectory \"" . MB_EXPORT_DIR . "\" exists but is not writable.
		  <p>You must change its permissions in order for the Export feature to work.
		  <p>Then run install.php again.</font>";
		return false;
	}
	if (@mkdir(MB_EXPORT_DIR)) {
		if (is_writable(MB_EXPORT_DIR))
			return true;
		else {
			echo "<p><font color='red'><b>ERROR:</b> Subdirectory \"" . MB_EXPORT_DIR . "\" has been created but is not writable.
			  <p>You must change its permissions in order for the Export feature to work.
			  <p>Then run install.php again.</font>";
			return false;
		}
	}
	echo "<p><font color='red'><b>ERROR:</b> Subdirectory \"" . MB_EXPORT_DIR . "\" does not exist
	  and install.php can't create it.
	  <p>You must create it, with read/write permission for any user,
	  in order for the Export feature to work.
	  Or, you can make the Mudbag home directory (where you placed the PHP files) writable by anyone,
	  and install.php will make the directory automatically.
	  <p>After you've created the directory or changed the permission on the home directory, run install.php again
	  (usually you can just refresh the browser window).
	  </font>";
	return false;
}

function drop_all($dropall) {
	switch ($dropall) {
	case 1:
		echo <<<EOT
			<p>If this isn't a new installation, deleting all Mudbag tables may
				destroy important data. Do you want to proceed?
			<p><a href='install.php?dropall=2'>Yes -- Delete all tables.</a>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='install.php?dropall=0'>No -- Keep the tables.</a>
EOT;
		exit;
	case 2:
		$db = new MB_DB();
		$result = $db->db_query("show tables like 'mb_%'");
		while ($row = mysql_fetch_row($result)) {
			echo "<br>Deleting $row[0]";
			$db->db_query("drop table $row[0]");
		}
		echo <<<EOT
			<p>All Mudbag tables have been deleted.
			Click <a href='install.php'>here</a> to proceed with the installation.
EOT;
		exit;
	default:
		echo "<p>No tables have been deleted. Installtion will now proceed.";
	}
}

?>
