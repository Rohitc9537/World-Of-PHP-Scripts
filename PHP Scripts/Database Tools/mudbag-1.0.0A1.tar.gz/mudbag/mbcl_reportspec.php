<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_reportspec.php,v 1.1.1.1 2005/07/13 00:22:07 rochkind Exp $

	define('DEFAULT_WIDTH_YESNO', 3);
	define('DEFAULT_WIDTH_NUMBER', 10);
	define('DEFAULT_WIDTH_DATETIME', 12);

	class MB_ReportField {
		var $name;
		var $width;
		var $alignment;
		var $heading;

		function MB_ReportField($name = null, $width = null, $alignment = null, $heading = null) {
			$this->name = $name;
			$this->width = $width;
			$this->alignment = $alignment;
			$this->heading = $heading;
		}

		function SetFromFld(&$fld) { // arg is field_dict element
			$this->name = $this->heading = $fld->name;
			$this->alignment = 'L';
			switch ($fld->type) {
			case 't':
			case 'm':
				$this->width = ($fld->cols == 0 ? 25 : $fld->cols);
				break;
			case 'y':
				$this->width = DEFAULT_WIDTH_YESNO;
				break;
			case 'n':
			case 'f':
				$this->width = DEFAULT_WIDTH_NUMBER;
				break;
			case 'd':
				$this->width = DEFAULT_WIDTH_DATETIME;
				break;
			case 'c':
				$w = 0;
				foreach ($fld->choices as $c)
					$w = max($w, strlen($c));
				$this->width = $w;
				break;
			default:
				trigger_error("Unknown field type: $fld->type.", E_USER_ERROR);
			}
		}
	}

	class MB_ReportBlockSpec {

		var $type;
		var $template = 'default template';
		var $specstring;
		var $is_public;
		var $is_table;
		var $tableview_name;
		var $label_code;
		var $show_lines;
		var $one_page; // not saved in spec
		var $col_gap = 2;
		var $row_gap = 2;
		var $col_rules = true;
		var $row_rules = true;
		var $rec_per_page = false;
		var $font_family = "Helvetica";
		var $font_size = 8;
		var $orientation = 'L';
		var $paper_size = 'Letter';
		var $rec_per_page = false;
		var $title = '';
		var $hdr_date = true;
		var $hdr_pgnums = true;
		var $spec_name;
		var $fields; // array of MB_ReportField
		var $field_dict;

		function MB_ReportBlockSpec($type, &$spec) {
			$this->one_page = false;
			if (isset($spec) && $spec != 'Default') {
				$this->spec_name = $spec;
				$result = $_SESSION['APPDB']->dbmain->db_query_user("select * from mb_reportspec
				  where db_id = {$_SESSION['APPDB']->db_id} and name = '$spec'" . (isset($type) ? " and type = '$type'" : ""));
				if ($row = mysql_fetch_assoc($result)) {
					$this->parse_specstring(stripslashes($row['specstring']));
					$this->type = $row['type'];
					$this->template = $row['template'];
					$this->show_lines= $row['show_lines'];
					$this->is_table = $row['is_table'];
					$this->tableview_name = $row['tableview'];
					$this->label_code = $row['text1'];
					$this->is_public = $row['public'];
				}
			}
			else {
				$this->type = $type;
				$this->spec_name = null;
				$this->template = '';
				$this->specstring = '';
				$this->show_lines = true;
				$this->is_table = true;
				$this->tableview_name = '';
				$this->label_code = '';
				$this->is_public = false;
			}
		}

		function parse_specstring($s) {
			if (empty($s))
				return;
			$fa = explode('~', $s);
			$this->fields = array();
			$first = true;
			foreach ($fa as $f) {
				if ($first) {
					$layout = $f;
					$first = false;
					// 5`5`true`true`Helvetica`10`P`Letter
					$la = explode('`', $f);
					$this->col_gap = $la[0];
					$this->row_gap = $la[1];
					$this->col_rules = ($la[2] == 'true');
					$this->row_rules = ($la[3] == 'true');
					$this->font_family = $la[4];
					$this->font_size = $la[5];
					$this->orientation = $la[6];
					$this->paper_size = $la[7];
					$this->rec_per_page = ($la[8] == 'true');
					$this->hdr_pgnums = ($la[9] == 'true');
					$this->hdr_date = ($la[10] == 'true');
					$this->title = $la[11];
				}
				else {
					$pa = explode('`', $f);
					$this->fields[] = new MB_ReportField($pa[0], $pa[1], $pa[2], $pa[3]);
				}
			}
		}

		function SetTable() {
			$this->fields = array();
			if ($this->is_table) {
				$this->field_dict = get_field_dict($this->tableview_name);
				foreach ($this->field_dict as $fld) {
					$newfld = new MB_ReportField();
					$newfld->SetFromFld($fld);
					$this->fields[] = $newfld;
				}
			}
			else {
				$v = new View($_SESSION['APPDB']->db_id);
				$v->load_by_name($this->tableview_name);
				$this->field_dict = &$v->field_dict;
				foreach ($v->fields as $fid) {
					$newfld = new MB_ReportField();
					$newfld->SetFromFld(get_fld_from_id($this->field_dict, $fid));
					$this->fields[] = $newfld;
				}
			}
		}

		function Save($frm, $spec_name) {
			$this->spec_name = $spec_name;
			// Silently overwrites.
			$frm->dbmain->db_query_user("insert into mb_reportspec (db_id, user_id, name)
			  values({$_SESSION['APPDB']->db_id}, {$_SESSION['MUDBAG_USER']->user_id}, '$spec_name')", true); // OK if it fails.
			return $frm->QueryAddMessageUser("update mb_reportspec set
				user_id = {$_SESSION['MUDBAG_USER']->user_id},
				type = '{$this->type}',
				show_lines = '" . ($this->show_lines ? 1 : 0) . "',
				is_table = '" . ($this->is_table ? 1 : 0) . "',
				tableview = '{$this->tableview_name}',
				text1 = '{$this->label_code}',
				template = '" . mysql_real_escape_string($this->template) . "',
				specstring = '" . mysql_real_escape_string($this->specstring) . "',
				public = '" . ($this->is_public ? 1 : 0) . "'
				where db_id = {$_SESSION['APPDB']->db_id} and name = '{$this->spec_name}'");
		}
	}
?>
