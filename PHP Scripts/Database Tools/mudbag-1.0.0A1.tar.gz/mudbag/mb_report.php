<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_report.php,v 1.1.1.1 2005/07/13 00:22:04 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	class MB_Report extends MB_DBScreen {

		function MB_Report() {
			parent::MB_DBScreen();
		}

		function Callback($tag) {
			parent::Callback($tag);
		}

		// Name of the report type is passed to the PHP file for that report, so we can choose the names
		// we want to use here.
		function ShowForm() {
			global $color_bg;

			echo <<<EOT
			<p>A report takes data from a table or view and displays it in a useful form.
			  <br>Click the link below for the kind of report you want.<p>
			<table border='1' cellspacing='0' cellpadding='25' bgcolor='$color_bg'>
			<tr>
				<td width='50%'>
					<a href='mb_report_block.php?type=t'><font size='+1'>Tablular</font></a><br>Data in columns.
					<p>
					<img src='images/sample_tabular_sm.png'>
				</td><td width='50%'>
					<a href='mb_report_block.php?type=r'><font size='+1'>Record</font></a><br>All fields grouped together.
					<p>
					<img src='images/sample_record_sm.png'>
				</td>
			</tr>
			<tr>
				<td>
					<a href='mb_report_block.php?type=l'><font size='+1'>Label</font></a><br>Avery or similar label sheets.
					<p>
					<img src='images/sample_label_sm.png'>
				</td><td valign='top'>
					<a href='mb_report_block.php?type=m'><font size='+1'>Email</font></a><br>Sending emails to a mailing list.
					<p>
					<img src='images/sample_email_sm.png'>
				</td>
			</tr>
			</table>




EOT;
//
//			echo "<ul>";
//			echo "<li><a href='mb_report_block.php?type=t'>Tablular</a>: Shows data in columns.
//			 <img src='images/sample_tabular_sm.png'>";
//			echo "<li><a href='mb_report_block.php?type=r'>Record</a>: Shows data record-by-record, with all fields for a
//			  record grouped together.
//			 <img src='images/sample_record_sm.png'>";
//			echo "<li><a href='mb_report_block.php?type=l'>Label</a>: For printing labels using Avery or custom layouts.
//			 <img src='images/sample_label_sm.png'>";
//			echo "<li><a href='mb_report_block.php?type=m'>Email</a>: For sending emails to a mailing list.
//			 <img src='images/sample_email_sm.png'>";
//			echo "</ul>";
//			echo "<p>To generate a report, click on the report type above. Reports (other than emails) go to a PDF document,
//			  which you view (and print, if you like) with Adobe Reader running in your browser.";
//			echo "<p>If your browser can't already display PDFs (most can), click here:&nbsp;&nbsp;
//			  <a href='http://www.adobe.com/products/acrobat/readstep2.html' target='_blank'>
//			  <img src='images/getacro.gif' align='middle'></a>";
		}
	}

	$frm = new MB_Report();
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right
	$frm->Go(null, "Reports", "helpctx_mb_report");
?>
