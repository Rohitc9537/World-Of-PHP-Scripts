<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mbcl_base.php,v 1.1.1.1 2005/07/13 00:22:06 rochkind Exp $

// This should be the very first line of PHP processed. Every files should begin with:
//		require('mbcl_base.php');

ini_set("display_errors", true); // sometimes not set as PHP default
error_reporting(E_ALL);
ini_set('auto_detect_line_endings', 1);
ini_set("error_log", "../mudbag/export/php_error_log.txt");
ini_set("log_errors", 1);

extract($_GET);
extract($_POST);
require("mb_globals.php"); // needs to be here because it defines globals
require("mbcl_dbapp.php");
require("mbcl_user.php");
require("mbcl_breadcrumbs.php");
require('mb_plan_util.php');

define('ROLE_OWNER', 1);
define('ROLE_SEE', 2);
define('ROLE_EDIT', 3);
$role_names = array(1 => "owner", 2 => 'see', 3 => 'edit');

function role_name($id) {
	global $role_names;

	return $role_names[$id];
}

function logger($s, $t = '') {
	error_log(date("r") . ': ' . $t . ' - ' . $s . "\n");
	//error_log(date("r") . ': ' . $t . ' - ' . $s . "\n", 3 /* append to file */, "/tmp/mudbag_log.txt");
}

function dump(&$v) {
	echo "<pre>";
	var_dump($v);
	echo "</pre>";
}

function nvl(&$v, $s = '') {
	return isset($v) ? $v : $s;
}

function text_small($s) {
	echo "<font size=\"-2\">$s</font>";
}

function text_medium($s) {
	echo "<font size=\"-1\">$s</font>";
}

function nav_clear() {
	//unset($_SESSION['db_table']);
	//unset($_SESSION['active_field']);
	unset($_SESSION['active_rownum']);
	unset($_SESSION['managing_users']);
}

function is_logged_in() { // in PHP5, should be class method
	return isset($_SESSION['MUDBAG_USER']) && $_SESSION['MUDBAG_USER']->logged_in;
}

class MB_Message {

	var $msg;
	var $class;

	function MB_Message($msg, $class) {
		$this->msg = $msg;
		$this->class = $class;
	}

	function Show($br) {
		if ($br)
			echo "<br>";
		echo "<span class=\"$this->class\">" . htmlspecialchars($this->msg) . "</span>";
	}


}

class MB_BaseScreen {

	var $toolbar;
	var $hdg;
	var $msgs;
	var $breadcrumbs;
	var $active_database;
	var $active_table;
	var $active_view;
	var $active_field;
	var $auto_show_message = true;
	var $skip_check_limits = false;

	function MB_BaseScreen($continue = true, $want_session = true) {
		if (substr(PHP_VERSION, 0, 1) != '4') {
			echo "<p>*** ERROR: Mudbag requires PHP Verison 4 (it does not run on 5). ***";
			exit;
		}
		$this->ClearMessages();
		if ($want_session)
			if ($continue)
				$this->session_continue();
			else {
				unset($_COOKIE['kill']); // because here's where we come on a kill
				$this->session_bridge();
			}
		else {
			session_start();
			session_destroy();
			unset($_SESSION); // just to be safe
		}

		if (isset($_SESSION['MB_ACTIVE_DATABASE']))
			$this->active_database = $_SESSION['MB_ACTIVE_DATABASE'];
		if (isset($_SESSION['MB_ACTIVE_TABLE']))
			$this->active_table = $_SESSION['MB_ACTIVE_TABLE'];
		if (isset($_SESSION['MB_ACTIVE_VIEW']))
			$this->active_view = $_SESSION['MB_ACTIVE_VIEW'];
		if (isset($_SESSION['MB_ACTIVE_FIELD']))
			$this->active_field = $_SESSION['MB_ACTIVE_FIELD'];
		if (!isset($_SESSION['MB_BREADCRUMBS']))
			$_SESSION['MB_BREADCRUMBS'] = new MB_BreadCrumbs();
		$this->breadcrumbs = &$_SESSION['MB_BREADCRUMBS'];
	}

	function SetActiveDatabase($name, $show_button = false) {
		$this->SetActiveTable(null);
		$this->SetActiveView(null);
		$_SESSION['MB_ACTIVE_DATABASE'] = $this->active_database = $name;
		$this->breadcrumbs->SetLevelDatabase($show_button);
		$this->breadcrumbs->SetValue($name);
	}

	function SetActiveTable($name, $show_button = false) {
		$this->SetActiveField(null);
		$_SESSION['MB_ACTIVE_TABLE'] = $this->active_table = $name;
		$this->breadcrumbs->SetLevelTable($show_button);
		$this->breadcrumbs->SetValue($name);
		$this->breadcrumbs->SetLabel("Table");
		unset($_SESSION['active_fd']);
	}

	function SetActiveView($name, $show_button = false) {
		$this->SetActiveField(null);
		$_SESSION['MB_ACTIVE_VIEW'] = $this->active_view = $name;
		$this->breadcrumbs->SetLevelTable($show_button);
		$this->breadcrumbs->SetValue($name);
		$this->breadcrumbs->SetLabel("View");
	}

	function SetActiveField($name, $show_button = false) {
		$_SESSION['MB_ACTIVE_FIELD'] = $this->active_field = $name;
		$this->breadcrumbs->SetLevelField($show_button);
		$this->breadcrumbs->SetValue($name);
	}

	function SetLevelHome() {
		$this->breadcrumbs->SetLevelHome();
	}

	function SetLevelDatabase($show_button = false) {
		$this->breadcrumbs->SetLevelDatabase($show_button);
	}

	function SetLevelTable($show_button = false) {
		$this->breadcrumbs->SetLevelTable($show_button);
	}

	function SetLevelField($show_button = false) {
		$this->breadcrumbs->SetLevelField($show_button);
	}

	function IsAdmin($show_bar) {
		$is_admin = $_SESSION['MUDBAG_USER']->admin;
		if ($is_admin && $show_bar)
			echo "<hr><hr><img src='images/gears.gif' height='102'><hr><hr>";
		return $is_admin;
	}

	function Go($toolbar = null, $hdg = "[Page Heading Missing]", $help_ctx, $want_onload_handler = false, $action = null,
	  $want_home = true, $skip_check_limits = false) {
		global $mbfv_button;

		HelpExistenceTrack($help_ctx);
		$this->skip_check_limits = $skip_check_limits;
		if ($want_home)
			$this->toolbar = array_merge(array(preg_match('/mb_dbmain.php$/', $_SERVER['SCRIPT_FILENAME']) ? "^Home" : "Home",
			  "mb_dbmain.php"), $toolbar);
		else
			$this->toolbar = $toolbar;
		$this->hdg = $hdg;
		if ($mbfv_button) {
			// No output prior to this in case Callback wants to call Navigate.
			foreach ($mbfv_button as $tag => $val)
				$this->Callback($tag, $val);
			//var_dump($btn_rgform);
		}
		require("mb_topstuff.php");
		mrcs_page_top($want_onload_handler); // puts out <html> and other top stuff
		mrcs_page_heading($this->hdg);
		mrcs_page_toolbar($this->toolbar, $this->breadcrumbs, $help_ctx); // sets margins
		echo <<<EOT
			<script language="JavaScript">

				function help_window(context) {
					var w = window.open('mb_help.php?context=' + context,
					'MudbagHelp', 'width=900,height=700,resizable,scrollbars,toolbar');
					w.focus();
				}

			</script>
EOT;
		$this->ShowFormOuter($action);
		mrcs_page_bottom(); // or whatever it's called
	}

	function session_continue() {
		$this->session_bridge();
		if (!is_logged_in()) {
			header("Location: mb_login.php?mbp_unauth=1");
			exit();
		}
	}

	function session_bridge() {
		session_name('Mudbag');
		if (!session_id())
			session_start();
		if (isset($_COOKIE['kill'])) {
			session_destroy();
			header("Location: mb_login.php?mbp_unauth=2");
			exit;
		}
	}

	function session_create($u = NULL) {
		$this->session_bridge();
		$_SESSION['MUDBAG_USER'] = new MB_User(true);
		if (gettype($u) == "array") {
			$_SESSION['MUDBAG_USER']->from_assoc($u);
		}
		else
			$_SESSION['MUDBAG_USER']->from_obj($u);
		logger($_SESSION['MUDBAG_USER']->login . ' logged in', 'init_session');
	}

	function ShowFormOuter($action) {
		if ($this->auto_show_message)
			$this->ShowMessages();
		if (isset($action))
			$action_str = " action='$action' ";
		else
			$action_str = "";
		echo "<form method=\"post\" name=\"mb_form\" $action_str>";
		if ($this->skip_check_limits || check_limits_quick(&$msg))
			$this->ShowForm();
		else {
			if (!isset($this->hdg))
				echo "<p>";
			$this->MessageError($msg);
		}
		echo "</form>";
	}

	function Navigate($where) {
		header("Location: $where");
	}

	function ShowForm() {
		echo "<p>MB_BaseScreen.ShowForm() - subclass responsibility";
	}

	function Callback($tag) {
		echo "<br>MB_BaseScreen.Callback($tag) [subclass responsibility]";
		dump($_POST);
		exit("Debugging exit from MB_BaseScreen.Callback($tag)");
	}

	function CancelCallback() {
		unset($GLOBALS['mbfv_button']);	// unset ineffective if declared gloabl
		unset($_POST['mbfv_button']);		// in case somebody does another extract() into a gloabl context
	}

	function Button($tag, $label, $target = null, $confirm_msg = null, $javascript = null, $enabled = true, $cancel_ok_check = true) {
		if ($cancel_ok_check)
			$cancel_ok_str = "cancel_ok()";
		else
			$cancel_ok_str = "true";
		if (isset($javascript))
			$code = $javascript;
		else {
			if ($target) {
				if ($confirm_msg)
					$code = " if ($cancel_ok_str && confirm('$confirm_msg')) ";
				else
					$code = " if ($cancel_ok_str) ";
				$code .= " window.location='$target'; return false; ";
			}
			else {
				if ($confirm_msg)
					$code = " return $cancel_ok_str && confirm('$confirm_msg');";
				else
					$code = " return $cancel_ok_str; ";
			}
		}
		$code = "onclick=\" $code \"";
		echo "<input type=\"submit\" class=\"formButton\" name=\"mbfv_button[$tag]\" value=\"" .
		  htmlspecialchars($label) . "\" $code" .
		  ($enabled ? "" : " disabled ") . ">";
	}

	function ButtonNoDirtyCheck($tag, $label, $target = null) {
		$this->Button($tag, $label, $target, null, null, true, false);
	}

	function ButtonSpacer() {
		echo "&nbsp;&nbsp;&nbsp;";
	}

	function ButtonSpaced($tag, $label, $target = null, $confirm_msg = null, $javascript = null, $enabled = true, $cancel_ok_check = true) {
		$this->ButtonSpacer();
		$this->Button($tag, $label, $target, $confirm_msg, $javascript, $enabled, $cancel_ok_check);
	}

	function FieldLabel($label, $req = false, $break = true, $para = true) {
		if ($para)
			echo "<p>";
		echo "<span class=\"FieldLabel\">$label</span>";
		if ($req)
			echo "<span class=\"FieldLabelReqMark\">*</span>";
		if ($break)
			echo "<br class=\"FieldLabelBreak\">";
	}

	function MessageWithList($msg, $class, $a = 1) {
		if ($a == 1 || !empty($a)) { // skip if $a is null or empty array; proceed if argument omitted
			echo "<div class=\"$class\">$msg";
				if (gettype($a) == "array")
					foreach ($a as $m)
						echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$m";
			echo "</div>";
		}
	}

	function MessageError($msg, $a = 1, $class = "MessageError") {
		$this->MessageWithList($msg, $class, $a);
	}

	function MessageConfirmation($msg, $a = 1, $class = "MessageConfirmation") {
		$this->MessageWithList($msg, $class, $a);
	}

	function MessageInfo($msg, $a = 1, $class = "MessageInfo") {
		$this->MessageWithList($msg, $class, $a);
	}

	function AddMessageError($msg, $class = "MessageError") {
		$this->msgs[] = new MB_Message($msg, $class);
	}

	function AddMessageErrorDb($msg, $errnum, $errmsg, $class = "MessageError") {
		$msg = "$msg [MySQL Error $errnum: $errmsg]";
		$this->msgs[] = new MB_Message($msg, $class);
	}

	function AddMessageConfirmation($msg) {
		$this->AddMessageError($msg, "MessageConfirmation");
	}

	function AddMessageInfo($msg) {
		$this->AddMessageError($msg, "MessageInfo");
	}

	function ClearMessages() {
		$this->msgs = array();
	}

	function HaveMessages() {
		return !empty($this->msgs);
	}

	function AutoShowMessage($on = true) {
		$this->auto_show_message = $on;
	}

	function ShowMessages($space_always = true) {
		if ($this->HaveMessages()) {
			echo "<p>";
			$first = true;
			$prev_class = '';
			foreach ($this->msgs as $m) {
				if (!$first && $m->class != $prev_class)
					echo "<p>";
				$prev_class = $m->class;
				$m->Show(!$first);
				$first = false;
			}
		}
		else if ($space_always)
			echo "<p>&nbsp;<span class=\"MessageError\">&nbsp;</span>"; // maintains spacing if one msg
	}

	function HelpLink($text, $context) {
		HelpExistenceTrack($context);
		return "<a href=\"javascript: void help_window('$context');\">$text</a>";
	}

	function SetPageHelpCtx($help_ctx) {
		HelpExistenceTrack($help_ctx);
		echo <<<EOT
			<script language="JavaScript">

			mb_help_ctx = '$help_ctx';

			</script>
EOT;
	}

	function SetDirty() {
		echo <<<EOT
			<script language="JavaScript">

			set_dirty();

			</script>
EOT;
	}

	function ShowArray($hdgs, $rows) {
		$tbl = new MB_Table();
		$tbl->Begin();
		foreach ($hdgs as $h)
			$tbl->ColHdg($h);
		$tbl->Body();
		foreach ($rows as $r) {
			echo "<tr>";
			foreach ($r as $v)
				echo "<td>$v</td>";
			echo "</tr>";
		}
		$tbl->End();
	}

}

function HelpExistenceTrack($help_ctx, $force_exist = false) {
	if (MB_HELP_GOTRACK && !empty($help_ctx)) {
		$exists = ($force_exist || @stat("help/$help_ctx.php") !== false);
		$db = new MB_DB();
		$db->db_query("replace mb_param (tag, data1) values('exists_{$help_ctx}', '$exists')");
	}
}

function DestroySession() { // should be a class method
	session_name('Mudbag');
	session_start();
	session_destroy();
}

?>
