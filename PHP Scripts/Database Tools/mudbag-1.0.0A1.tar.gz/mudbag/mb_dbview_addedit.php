<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbview_addedit.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBViewAddEdit extends MB_DBScreen {

		var $view;
		var $read_only;
		var $add;
		var $disabled_str;
		var $created;
		var $choose_table;

		function MB_DBViewAddEdit() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_Save":
				if (empty($_POST['mbfv_viewid'])) {
					$this->view = new View($_SESSION['APPDB']->db_id, $this->active_table);
					$_SESSION['active_view_obj'] = &$this->view;
				}
				else
					$this->view = &$_SESSION['active_view_obj'];
if (empty($this->view->db_id)) die("no db_id");
				$this->view->from_spec($_POST['mbfv_viewspec'], $_POST['mbfv_value1'], $_POST['mbfv_value2']);
				if ($this->validate_view($this->view)) {
					$this->view->store();
					$this->created = true;
					//unset($_SESSION['bad_view']);
				}
				else {
					//$_SESSION['bad_view'] = &$this->view;
				}
				//$v->dump();
				//echo '<p>' . $v->build_select();
				//header("Location: db-main.php?view_saved_ok=" . $v->name);
				break;
			case "btn_ChooseTableContinue":
				$this->SetActiveTable($_POST['mbfv_table']);
				header("Location: mb_dbview_addedit.php?add=1");
			default:
				echo "<br>callback $tag";
				dump($_POST);
				exit("debugging exit");
			}
		}

		function validate_view($v) {
			if (!preg_match('/^[A-Za-z0-9_ ]{1,20}$/', $v->name)) {

				$this->AddMessageError("View [$v->name] name must be from 1 to 20 letters, digits, underscores, and spaces. Please choose another one.");

				return false;

			}

			if (!$v->unique_name()) {
				$this->AddMessageError("View name already in use -- please choose another.");
				return false;
			}
			return true;
		}

		function ShowForm() {
			$this->output_script_and_style();
			if (isset($this->choose_table)) {
				$this->ShowChooseTableForm();
				return;
			}
			if ($this->created) {
//				$table = $_POST['table_nm'];
				// active_view_obj not set when new view is added
				$this->MessageConfirmation("View \"{$_SESSION['active_view_obj']->name}\" has been " .
				  ($this->add ? "Added" : "Edited") . ".");
				echo "<p>";
				$this->Button(null, "See View", "mb_dbtable.php?data=1&view={$_SESSION['active_view_obj']->view_id}");
				$this->ButtonSpaced(null, "Edit View Again", "mb_dbview_addedit.php?edit=1&view={$_SESSION['active_view_obj']->view_id}");
				$this->ButtonSpaced(null, "Back to Database", "mb_dbmain.php");
			}
			else {
				if (!isset($_SESSION['active_fd']))
					$_SESSION['active_fd'] = get_field_dict($this->active_table);
				if (isset($this->add) && (!isset($_SESSION['active_fd']) || count($_SESSION['active_fd']) < 1)) {
					$this->MessageError("There are no fields to base a view on.");
					return;
				}

				if (isset($_GET['rtn']) && $_GET['rtn'] = 'table') {
					$cancel_name = "Table";
					$cancel_loc = "mb_dbtable.php";
				}
				else {
					$cancel_name = "Database";
					$cancel_loc = "mb_dbmain.php";
				}

				if ($this->read_only)
					echo "<p>You can look at this view, but not change it, since you don't own the database.
					  The explanation of the steps along the left side of the form is for users who are
					  adding views to their own databases.
					  For more about views, click " . $this->HelpLink("here", "helpctx_mb_dbview_addedit~lnk_intro") . ".<p>";
				else
					echo "<p>Adding a view is more advanced that anything else in Mudbag.
					  <br>If you're new to databases, start by reading the introduction " . $this->HelpLink("here", "helpctx_mb_dbview_addedit~lnk_intro") . ".<p>";
				$tbl = new MB_TableFormWithInstr();
				$tbl->Begin();

				$tbl->FormCellBegin("<b>Step 1:</b> Name the view (or accept the default).");
					$this->FieldLabel("View Name", true);
					echo '<input type="text"'. $this->disabled_str . ' name="view_name" id="view_name_id" size="40"  value="' .
					  stripslashes($this->view->name) . '" onChange="set_dirty();" onClick="set_dirty();">';
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("<b>Step 2:</b> If you want this view to be seen by all users of this
				  database, check the box. Otherwise, only you will see the view.");
					$this->FieldLabel("Public");
					echo '<input type="checkbox"'. $this->disabled_str . ' name="view_public" id="view_public_id" ' .
					  ($this->view->public ? 'checked' : '') . ' onChange="set_dirty();" onClick="set_dirty();">';
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("<b>Step 3:</b> Choose the fields to appear in the view.
				  <p class='InstrCell'>
				  Select one or more fields (use the Ctrl or Command key for multiple selections). Then use the 4 left/right arrow
				  buttons as needed. (Experiment a bit to see what they do.)
				  <p class='InstrCell'>
				  Once you've chosen the fields, arrange them in order using the up/down arrow buttons at the right.");
					echo <<<EOT

					<TABLE border=0 bordercolorx=red cellspacing="0" cellpadding="0">

						<TBODY>

						<TR>

						<TD>
EOT;
					$this->FieldLabel("Fields in Table", false, true, true);
					echo <<<EOT

						<SELECT $this->disabled_str MULTIPLE size="12" CLASS="ViewEditSelect" NAME="avail"
						  ID="avail_id" onChange="btn_enable_chooser(this.form, avail, chosen);">
EOT;

						foreach ($_SESSION['active_fd'] as $fld)
							if (!$this->view->has_field($fld->field_id))
								echo '<option value="' . $fld->field_id . '">' . $fld->name . '</option>';
						echo <<<EOT
						</SELECT>

						</TD>

						<TD ALIGN=CENTER VALIGN=CENTER width="70">

						<INPUT TYPE="button" $this->disabled_str VALUE=">>" STYLE="{width=25;}" NAME="btnRR" onClick="javascript: moveVals(avail, chosen, 1); set_dirty(); populate_filter(this.form); return false;"><BR>

						<INPUT TYPE="button" disabled VALUE=">" STYLE="{width=25;}" NAME="btnR" onClick="javascript: moveVals(avail, chosen, 2); set_dirty(); populate_filter(this.form); return false;"><BR>

						<INPUT TYPE="button" disabled VALUE="<" STYLE="{width=25;}" NAME="btnL" onClick="javascript: moveVals(avail, chosen, 3); set_dirty(); populate_filter(this.form); return false;"><BR>

						<INPUT TYPE="button" disabled VALUE="<<" STYLE="{width=25;}" NAME="btnLL" onClick="javascript: moveVals(avail, chosen, 4); set_dirty(); populate_filter(this.form); return false;">

						</TD>

						<TD>
EOT;
					$this->FieldLabel("Fields in View", true, true, true);
					echo <<<EOT

						<SELECT $this->disabled_str size="12" cols-"100" CLASS="ViewEditSelect" NAME="chosen" onChange="btn_enable_chooser(this.form, avail, chosen);">

EOT;

						foreach ($this->view->fields as $id) {
							$nm = get_name_from_id($_SESSION['active_fd'], $id);
							if ($nm{0} != '[')
								echo '<option value="' . $id . '">' . $nm . '</option>';
						}
						echo '</select>';
						echo <<<EOT

						</TD>
EOT;
						echo '<td ALIGN=CENTER VALIGN=CENTER  width="60">';

						echo '&nbsp;&nbsp;<input type=button'. $this->disabled_str . ' name="btn_up" value="&uarr;" disabled onclick="set_dirty(); move(this.form, chosen, -1)">';

						echo '<br>&nbsp;&nbsp;<input type=button'. $this->disabled_str . ' name="btn_down" value="&darr;" disabled onclick="set_dirty(); move(this.form, chosen, 1)">';

						echo '</td></tr>';




						echo <<<EOT

						</TBODY>

					</TABLE>

EOT;
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("<b>Step 4:</b> If you want, you can sort the records in the view by choosing
				  a field in the <i>Sort By</i> drop down.
				  <p class='InstrCell'>
				  Normally, the sort is <i>ascending</i> (from lowest to highest value).
				  Or, you can choose <i>descending</i> instead.
				  <p class='InstrCell'>
				  If you want additional sorting (when values for the first sort field are equal),
				  you can specify a second and even a third sort field with the two <i>Then By</i> drop downs.");
					$this->FieldLabel("Sort By");
					$this->sort_expr('fldsel_sort1', 0);
					$this->FieldLabel("Then By");
					$this->sort_expr('fldsel_sort2', 1);
					$this->FieldLabel("Then By");
					$this->sort_expr('fldsel_sort3', 2);
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("<b>Step 5:</b> To filter the view so it includes only selected records,
				  choose a field from the <i>Filter 1</i> drop down and type a value in the box at the right. Only records whose
				  value for that field match your test will be included.
				  <p class='InstrCell'>
				  For a more complicated filter, choose a second field/value combination, and set the radio button to
				  <i>and</i> or <i>or</i>. For help on more complicated filters, click "
				  . $this->HelpLink("here", "helpctx_mb_dbview_addedit~lnk_filter") . ".");
					echo '<table width="100%"border="0"><tr>';
					echo '<td align="left">';
					$this->FieldLabel("Filter 1");
					$this->outer_expr(1);
					echo "<p><input type='radio' $this->disabled_str name='andor' id='andor_and' " .
					($this->view->filter_logop == "and" ? " checked " : "") .
					'onClick="set_dirty(); outer_andor(\'and\');">';
					echo '<label for="andor_and">and</label>';
					echo "&nbsp;&nbsp;&nbsp;";
					echo "<input type='radio' $this->disabled_str name='andor' id='andor_or' " .
					($this->view->filter_logop == "or" ? " checked " : "") .
					'onClick="set_dirty(); outer_andor(\'or\');">';
					echo '<label for="andor_or">or</label>';
					//echo '<p>';
					$this->FieldLabel("Filter 2");
					$this->outer_expr(2);
					echo '</td>';
					echo '</tr></table>';
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("<b>Step 6:</b> Press the <i>Save</i> button to save the view." .
				  ($this->read_only ? " (It's disabled, since you can't change the view.)" : ""));
				$this->Button('btn_Save', 'Save', null, null, "return do_save(this.form, '{$this->view->view_id}');", !$this->read_only);
				$this->ButtonSpaced(null, "Back to $cancel_name", $cancel_loc, null, null, true);
				$tbl->FormCellEnd();

				$tbl->End();
				echo "<input type=\"hidden\" name=\"mbfv_viewspec\">";
				echo "<input type=\"hidden\" name=\"mbfv_viewid\">";
				echo "<input type=\"hidden\" name=\"mbfv_value1\">";
				echo "<input type=\"hidden\" name=\"mbfv_value2\">";
			}
		}

		function outer_expr($seq) {
	//		echo '<table bgcolor=silver border=1 frame="box" rules="none" cellspacing="0" cellpadding="0">';
	//		echo '<tr><td>';
			$this->inner_expr($seq . 'a', $seq - 1);
	//		echo '</td></tr>';
	//		echo '<tr><td>';
	//		echo '<p class="auto_andor" id="auto_andor' . $seq . '">or</p>';
	//		echo '</td></tr>';
	//		echo '<tr><td>';
	//		inner_expr($seq . 'b');
	//		echo '</td></tr>';
	//		echo '</table>';
		}

		function inner_expr($tag, $index) {
			echo '<select'. $this->disabled_str . ' name="fldsel' . $tag . '" class="ViewEditFieldSel" onChange="set_dirty();">';
			if (isset($this->view->filter_fields[$index]))
				echo '<option selected value="' . $this->view->filter_fields[$index] . '">' . get_name_from_id($_SESSION['active_fd'], $this->view->filter_fields[$index]) .
				  '</option>';
			echo '</select>';
			echo '&nbsp;<select'. $this->disabled_str . ' name="fldop' . $tag . '" class="ViewEditOp" onChange="set_dirty();">';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '=' ? 'selected' : '') . ' value="=">=</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == 'like' ? 'selected' : '') . ' value="like">like</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '<>' ? 'selected' : '') . ' value="<>">not =</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == 'not like' ? 'selected' : '') . ' value="not like">not like</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '<' ? 'selected' : '') . ' value="<">&lt;</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '<=' ? 'selected' : '') . ' value="<=">&le;</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '>' ? 'selected' : '') . ' value=">">&gt;</option>';
			echo '<option ' . (isset($this->view->filter_compares[$index]) && $this->view->filter_compares[$index] == '>=' ? 'selected' : '') . ' value=">=">&ge;</option>';
			echo '</select>';
			echo '&nbsp;<input type="text"'. $this->disabled_str . ' name="fldval' . $tag . '" size="25" value="' . str_replace('"', '&quot;', nvl($this->view->filter_values[$index])) . '" onChange="set_dirty();" onClick="set_dirty();">';
		}

		function sort_expr($nm, $index) {
			echo '<select'. $this->disabled_str . ' name="' . $nm . '" class="ViewEditFieldSel" onChange="set_dirty();">';
			if (isset($this->view->order[$index]))
				echo '<option selected value="' . $this->view->order[$index] . '">' . get_name_from_id($_SESSION['active_fd'], $this->view->order[$index]) .
				  '</option>';
			echo '</select>';
			echo '&nbsp;<select'. $this->disabled_str . ' name="' . $nm . '_dir" onChange="set_dirty();" class="ViewEditSort">';
			echo '<option ' . (isset($this->view->dir[$index]) && $this->view->dir[$index] == 'asc' ? 'selected' : '') . ' value="asc">ascending</option>';
			echo '<option ' . (isset($this->view->dir[$index]) && $this->view->dir[$index] == 'desc' ? 'selected' : '') . ' value="desc">descending</option>';
			echo '</select>';
		}

		function output_script_and_style() {
			require("js-reorder.php");
			require("js-listchoose.php");
			echo <<<EOT
				<STYLE>

				.ViewEditSelect {

					font-size: xx-small;

				}

				<!-- some styles were omitted (e.g., TABLE) -- see the file in mudbag-old -->

				.selCellx {

					background-color:teal;

					border-style:inset;

					border-width:10px;

					border-left-color:white;

					border-top-color:white;

					border-bottom-color:black;

					border-right-color:black;

				}

				</STYLE>

				<style>
				P.auto_andor {
					font-style: bold;
					color: red;
					text-align: center;
				}

				SELECT.ViewEditFieldSel {
					width: 100;
					font-size: xx-small;

				}

				SELECT.ViewEditSort {
					width: 100;
					font-size: xx-small;

				}

				SELECT.ViewEditOp {
					width: 70;
					font-size: xx-small;

				}

				</style>
				<script language="JavaScript">

				function onLoad_handler(frm) {
					if (frm != null && frm.btnRR != null && !frm.btnRR.disabled) {
						btn_enable_chooser(frm, frm.avail, frm.chosen);
						populate_filter(frm);
					}
				}

				/* Not needed -- document.all seems to do it.
					function getElement(sId, sType)

					{

						var obj = document.getElementsByTagName(sType);

					 	for (var i=0;i < obj.length;i++)

					  	{

							var el = obj[i];
							//alert(el.getAttribute("id"));

							if (el.getAttribute("id")==sId)

							{

								return(el);

							}

					  	}

					  	return(null);

					}
				*/
					function populate_options(frm, sel) {
						var lst = frm.chosen;
						var selValue = 0;

						if (sel.selectedIndex >= 0)
							selValue = sel.options[sel.selectedIndex].value;
						sel.options.length = 0; // special operation for options array
				// Use the next two lines if above isn't universal enough.
				//		for (i = 0; i < sel.options.length; i++)

				//			sel.options[i] = null;

						sel.options[0] = new Option('', 0);
						for (i = 0; i < lst.length; i++) {
							sel.options[i + 1] = new Option(lst[i].text, lst[i].value);
							if (lst[i].value == selValue)
								sel.options[i + 1].selected = true;
						}
					}

					function populate_filter(frm) {
						var flt = frm;
						var srt = frm;
						populate_options(frm, flt.fldsel1a);
				//		populate_options(frm, flt.fldsel1b);
						populate_options(frm, flt.fldsel2a);
				//		populate_options(frm, flt.fldsel2b);
						populate_options(frm, srt.fldsel_sort1);
						populate_options(frm, srt.fldsel_sort2);
						populate_options(frm, srt.fldsel_sort3);
					}

					function do_save(frm, id) {
						if (frm.view_name.value.length == 0 || frm.view_name.value.length > 20) {
							alert("The view name must be from 1 to 20 characters.");
							return false;
						}
						if (frm.chosen.length == 0) {
							alert("You haven't chosen any fields to include.");
							return false;
						}
						if (!dirty) {
							alert("You haven't made any changes.");
							return false;
						}
						var s = frm.view_name.value + ";" + frm.view_public.checked + ":" + gather_field_list(frm) + ";" + gather_sort_order(frm) + ";" + gather_filter(frm);
						frm.mbfv_viewspec.value = s;
						frm.mbfv_viewid.value = id;
						//frm.action = "db-view-addedit-action.php?view=" + id + "&viewspec=" + s;
						return true;
					}

					function gather_field_list(frm) {
						var s = "";
						var lst = frm.chosen;

						for (i = 0; i < lst.length; i++) {
							if (i > 0)
								s += ",";
							s += lst[i].value;
						}
						return(s);
					}

					function gather_sort_order(frm) {
						return frm.fldsel_sort1.value + "," + frm.fldsel_sort1_dir.value + "," +
						  frm.fldsel_sort2.value + "," + frm.fldsel_sort2_dir.value + "," +
						  frm.fldsel_sort3.value + "," + frm.fldsel_sort3_dir.value;
					}

					function gather_filter(frm) {
						var delim = ",";

						// use of escape causes %s and other chars to be translated to URL escapes (bad)
						frm.mbfv_value1.value = /*escape*/(frm.fldval1a.value);
						frm.mbfv_value2.value = /*escape*/(frm.fldval2a.value);
						return frm.fldsel1a.value + delim + frm.fldop1a.value + delim +
						  frm.fldsel2a.value + delim + frm.fldop2a.value + delim +
						  frm.andor[0].checked;
					}



					function outer_andor(state) { // no inner and/ors to change
				//		var x1 = document.all.auto_andor1;
				//		var x2 = document.all.auto_andor2;
				//		if (state == "and") {
				//			x1.innerText = "or";
				//			x2.innerText = "or";
				//		}
				//		else {
				//			x1.innerText = "and";
				//			x2.innerText = "and";
				//		}
					}


				</script>
EOT;
		}

		function ShowChooseTableForm() {
			echo <<<EOT
				<p>A view is a way of looking at a table. When you define a view, you can choose
				what fields to show, how to sort them, and even which records to include (for example,
				all records where the City field is equal to "Boston").<p>
EOT;
			$tbl_form = new MB_TableFormWithInstr();
			$tbl_form->Begin();
			$tbl_form->FormCellBegin("Choose the table on which to base the view.");
			$result = $_SESSION['APPDB']->dbmain->db_query_user("show tables like '{$_SESSION['APPDB']->tblpfx}%'");
			while ($row = mysql_fetch_row($result))
				if (substr($row[0], 0, 4) != 'mb_')
					$tables[] = $_SESSION['APPDB']->external_name($row[0]);
			$have_tables = !empty($tables);

			if ($have_tables) {
				natcasesort($tables);
				$this->FieldLabel("Table", true);
				echo "<select name='mbfv_table'>";
				foreach ($tables as $tbl)
					echo "<option>$tbl</option>";
				echo "</select>";
			}
			else
				echo "Since views are always based on tables, you first have to add a table.
				  Press the <i>Continue</i> button, below, to do that.";
			$tbl_form->FormCellEnd();
			$tbl_form->FormCellBegin("Next, press <i>Continue</i> to define the rest of the view.");
			if ($have_tables)
				$this->Button("btn_ChooseTableContinue", "Continue");
			else
				$this->Button(null, "Continue", "mb_dbtable_add.php");
			$this->ButtonSpaced(null, 'Back to Database', 'mb_dbmain.php');
			$tbl_form->FormCellEnd();
			$tbl_form->End(true);

		}
	}

	$frm = new MB_DBViewAddEdit();

////////////////////////////////////////////////////////////////////////



	$frm->add = isset($add);
	if (isset($edit)) {
//		if (isset($_SESSION['bad_view'])) // comes from old verison of callback (action) code
//			$frm->view = &$_SESSION['bad_view'];
//		else {
			$_SESSION['active_view_obj'] = load_new_view($view);
			$frm->view = &$_SESSION['active_view_obj'];
//echo "<br>setting view {$frm->view->user_id}";
//		}
		$frm->SetActiveTable($frm->view->table);
	}
	else { // add -- initialize it just for form, not for new view
		if (isset($frm->active_table)) {
			$frm->view = new View(0);
			$frm->view->name = "{$frm->active_table}_View";
			$seq = get_name_seq_local($frm->view->name);
			if ($seq != 1)
				$frm->view->name .= $seq;
		}
		else
			$frm->choose_table = true;
	}
	$frm->read_only = ($frm->view->user_id != $_SESSION['MUDBAG_USER']->user_id) && !$frm->add;
//echo "<br>readonly = $frm->read_only {$frm->view->user_id} -- {$_SESSION['MUDBAG_USER']->user_id}";
	$frm->disabled_str = ($frm->read_only ? ' disabled ' : '');
	if (isset($frm->add))
		if (isset($frm->active_table))
			$hdg = "View of Table \"$frm->active_table\" &mdash; Design";
		else
			$hdg = "View &mdash; Design";
	else if ($frm->read_only)
		$hdg = "View \"$frm->view->name\"";
	else
		$hdg = "Edit View \"$frm->view->name\"";


////////////////////////////////////////////////////////////////////////
// if we set this temp name, it won't be updated as the user types
	$frm->SetActiveView(null); // don't used the proposed name, as it may change $frm->view->name);
	//$toolbar = $_SESSION['APPDB']->is_owned() ? array('Add Table', 'mb_dbtable_add.php', 'Manage Users', 'mb_mng_users.php') : null;


	$frm->Go(null, $hdg, "helpctx_mb_dbview_addedit", !$frm->choose_table);
?>
