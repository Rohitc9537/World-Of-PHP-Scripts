<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: js-listchoose.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

echo <<<EOT
<SCRIPT LANGUAGE="JavaScript">
<!--

function moveVals(fromObj, toObj, n) {
	if (n == 1 || n == 2) {
		var indTo = toObj.length-1;
		for (i = 0; i < fromObj.length; i++) {
			if (n==1 || fromObj.options[i].selected) {
				indTo++;
				toObj.options[indTo] = new Option(fromObj.options[i].text, fromObj.options[i].value);
			}
		}
		var lastmoved = -1;
		for (i = fromObj.length - 1; i >= 0; i--) {
			if (n==1 || fromObj.options[i].selected) {
				fromObj.options[lastmoved = i] = null;
			}
		}
		if (lastmoved >= 0 && fromObj.length > 0) {
			if (lastmoved >= fromObj.length)
				lastmoved--;
			fromObj.selectedIndex = lastmoved;
		}
	} else if (n == 3 || n == 4) {
		var indFrom = fromObj.length-1;
		for (i = 0; i < toObj.length; i++) {
			if (n==4 || toObj.options[i].selected) {
				indFrom++;
				fromObj.options[indFrom] = new Option(toObj.options[i].text, toObj.options[i].value);
			}
		}
		for (i=toObj.length-1; i>=0; i--) {
			if (n==4 || toObj.options[i].selected) {
				toObj.options[i] = null;
			}
		}
	}
	btn_enable_chooser(fromObj.form, fromObj, toObj);
}

function deleteFrom(frm) { // doesn't seem to be ever called
	for (i=0; i<document.frm.elements.length-1; i++) {
		if  (document.frm.elements[i].tagName.indexOf("SELECT") && document.frm.elements[i].id.indexOf("avail_id")) {
			alert("Cislo: "+i+" Name: "+document.frm.elements[i].tagName);
		}
	}
}

function btn_enable_chooser(frm, lst1, lst2) {
	if (!lst2)
		return;
	var sel2 = lst2.selectedIndex;
	var len2 = lst2.length;

	frm.btn_up.disabled = (sel2 <= 0);
	frm.btn_down.disabled = (sel2 < 0 || sel2 >= lst2.length - 1);

	if (lst1) {
		var sel1 = lst1.selectedIndex;
		var len1 = lst1.length;
		frm.btnLL.disabled = len2 <= 0;
		frm.btnRR.disabled = len1 <= 0;
		frm.btnL.disabled = sel2 < 0;
		frm.btnR.disabled = sel1 < 0;
	}
}

-->
</SCRIPT>
EOT;
?>
