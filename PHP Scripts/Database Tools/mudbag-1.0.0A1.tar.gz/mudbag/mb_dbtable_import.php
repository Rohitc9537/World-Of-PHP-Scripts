<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable_import.php,v 1.1.1.1 2005/07/13 00:22:01 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$ignore_str = "[ignore]";
	$new_spec_name = "[new]";
	define('MAX_ERRS_INFINITE', -1);

	class MB_ImportSpec {
		var $upload_file;
		var $delim = ',';
		var $quote = '"';
		var $has_headings = false;
		var $max_errs = 10;
		var $spec_name;
		var $table;
		var $new_table = true;
		var $fields;
		var $types;
		var $hdgs; // from import file when $has_headings is true
		var $dbmain;
		var $field_dict;
		var $char_dict;
		var $num_cols;
		var $row_sample;

		function MB_ImportSpec($dbmain, $spec = null) {
			global $new_spec_name;

			$this->dbmain = $dbmain;
			if (empty($spec) || $spec == $new_spec_name)
				$spec = "Default";
			$this->spec_name = $spec;
			$result = $this->dbmain->db_query_user("select * from mb_importspec where db_id = {$_SESSION['APPDB']->db_id} and name = '$spec'");
			if ($row = mysql_fetch_assoc($result)) { // not there if Default never saved
				$this->delim = $row['delim'];
				$this->quote = $row['quote'];
				$this->has_headings = $row['headings'];
				$this->max_errs = $row['max_errs'];
				$this->table = $row['tbl'];
				$internal_table = $_SESSION['APPDB']->internal_name($this->table);
				$result2 = $this->dbmain->db_query_user("show tables like '$internal_table'");
				$this->new_table = (mysql_num_rows($result2) == 0);
				$this->fields = explode (",", $row['flds']);
				$this->types = explode (",", $row['types']);
			}
		}

		function set_table($tbl, $want_field_dict = true) {
			if ($this->table != $tbl) {
				unset($this->fields);
				unset($this->types);
				unset($this->hdgs);
			}
			$this->table = $tbl;
			if ($want_field_dict)
				$this->field_dict = get_field_dict($this->table);
			else
				unset($this->field_dict);
		}

		function Save($frm, $spec_name) {
			$this->spec_name = $spec_name;
			$db = &$_SESSION['APPDB']->dbmain;
			$dbid = $_SESSION['APPDB']->db_id;
			// Silently overwrites.
			$db->db_query_user("insert into mb_importspec (db_id, name) values($dbid, '$spec_name')", true); // OK if it fails.
			$flds = implode(",", $this->fields);
			if (isset($this->types)) // not relevant if existing table
				$types = implode(",", $this->types);
			else
				$types = '';
			if ($frm->QueryAddMessageUser("update mb_importspec set
			  delim = '{$this->delim}',
			  quote = '{$this->quote}',
			  headings = '" . ($this->has_headings ? 1 : 0) . "',
			  max_errs = {$this->max_errs},
			  tbl = '{$this->table}',
			  flds = '$flds',
			  types = '$types'
			  where db_id = $dbid and name = '{$this->spec_name}'")) {
				//$db->db_query("commit");
				return true;
			}
			//$db->db_query("rollback");
			return false;
		}
	}

	$want_db_query_echo = false;

	class MB_DBTableImport extends MB_DBScreen {

		var $step = 1;
		var $which_form = "form_upload";
		var $spec;
		var $error_in_callback = false;
		var $import_error_count;

		function MB_DBTableImport($spec) {
			parent::MB_DBScreen();
			if (!empty($spec)) {
				//echo "<p>setting spec from POST (spec = $spec)";
				$_SESSION['mb_import_spec'] = new MB_ImportSpec($this->dbmain, $spec);
			}
			else if (!isset($_SESSION['mb_import_spec'])) {
				//echo "<p>setting spec from default";
				$_SESSION['mb_import_spec'] = new MB_ImportSpec($this->dbmain);
			}
//else echo "<p>reusing already set spec";
			$this->spec = &$_SESSION['mb_import_spec'];
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_Upload":
				if ($_FILES['mbfv_importfile']['error']) {
					if ($_FILES['mbfv_importfile']['error'] == UPLOAD_ERR_NO_FILE && empty($_FILES['mbfv_importfile']['tmp_name']))
						$this->AddMessageError("You must press the Browse/Choose File button to choose to a file to upload.");
					else
						$this->AddMessageError("Upload Error: " . $this->upload_error($_FILES['mbfv_importfile']['error']));
					//$this->error_in_callback = true;
					$this->step = 1;
					return;
				}
				$upload_dir = '/tmp/mudbag_uploads';

				@mkdir("/tmp/mudbag_uploads");
				$this->spec->upload_file = "$upload_dir/" . basename($_FILES['mbfv_importfile']['tmp_name']);
				if (!move_uploaded_file($_FILES['mbfv_importfile']['tmp_name'], $this->spec->upload_file)) {

					$this->AddMessageError("Upload Error: Unable to move file to staging directory.");
					return;
				}
				$this->spec->file = $_FILES['mbfv_importfile']['name'];
				//$this->which_form = "specification_form";
				break;
			case "btn_Next":
				// ShowForm will work with the incremented step number
				break;
			default:
				dump($_FILES);
				parent::Callback($tag);
			}
		}

		function upload_error($code) {
			$errmsg = array(
				UPLOAD_ERR_OK => "There is no error, the file uploaded with success.",

				UPLOAD_ERR_INI_SIZE => "The uploaded file exceeds the maximum of " . ini_get('upload_max_filesize'),
				//upload_max_filesize directive in php.ini.",

				UPLOAD_ERR_FORM_SIZE => "The uploaded file exceeds the your limit of {$_SESSION['MUDBAG_USER']->params->upload_size}
				  bytes. Press the Account button (at the top of the window) to see how to increase your limit.",
				// MAX_FILE_SIZE directive that was specified in the HTML form.",

				UPLOAD_ERR_PARTIAL => "The uploaded file was only partially uploaded.",

				UPLOAD_ERR_NO_FILE => "No file was uploaded.",

				UPLOAD_ERR_NO_TMP_DIR => "Missing a temporary folder. Introduced in PHP 4.3.10 and PHP 5.0.3."
			);
			return $errmsg[$code];
		}

		function ShowForm() {
			if ($this->error_in_callback)
				return;
			$nextstep = $this->step + 1;
			echo <<<EOT
				<script language="JavaScript">

				document.mb_form.action = 'mb_dbtable_import.php?step=' + $nextstep;

				function savespec_window(spec_name) {
					var w = window.open('mb_dbtable_import.php?spec_name=' + spec_name,

					'MudbagSpec', 'width=300,height=200');

					w.focus();
				}

				</script>
EOT;
			switch ($this->step) {
			case 1:
				$this->ShowFormUpload_Step_1();
				break;
			case 2:
				$this->ShowFormSpec_Step_2();
				break;
			case 3:
				$this->ShowColumChooser_Step_3();
				break;
			case 4:
				$this->ShowVerification_Step_4();
				break;
			case 5:
				$this->DoImport_Step_5();
				break;
			default:
				echo "<p>Unimplemented step: $this->step";
			}
		}

		function ShowFormUpload_Step_1() {
			global $new_spec_name;

			show_page_heading("Import Step 1: Choose File to Be Imported", "helpctx_mb_dbtable_import~step1");
			$this->ShowMessages();
			echo "<p>";

			echo <<<EOT
				<!-- The data encoding type, enctype, MUST be specified as below -->
				</form>

				<form enctype="multipart/form-data" action="mb_dbtable_import.php?step=2" method="POST" name="mb_form">
EOT;

			$tbl_form = new MB_TableFormWithInstr();
			$tbl_form->Begin();

			$tbl_form->FormCellBegin("Choose an existing import specification, or accept the default. For more on
			  import specifications, click " . $this->HelpLink("here", "helpctx_mb_dbtable_import~lnk_import_spec") . ".");
			$result = $this->dbmain->db_query_user("select name from mb_importspec
			  where db_id = {$_SESSION['APPDB']->db_id} order by name");
			$this->FieldLabel("Import Specification", false);

			echo "<select name='mbfv_spec' onchange=\"window.location='mb_dbtable_import.php?spec=' + this.value\">";

			echo "<option value='Default'>Default</option>";
			while ($row = mysql_fetch_assoc($result)) {
				if ($row['name'] == $this->spec->spec_name)
					$selected = " selected ";
				else
					$selected = "";
				echo "<option value=\"{$row['name']}\" $selected>{$row['name']}</option>";
			}
			echo "</select>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Use the <i>Browse</i> or <i>Choose File</i> button to choose the import file, which must be
			  in CSV (comma-separated values) format. Click " . $this->HelpLink("here", "helpctx_mb_dbtable_import~lnk_csv") . " for more on CSV.");
			$this->FieldLabel("File to Upload", true);
			echo "<input name='mbfv_importfile' type='file' size='70' class='formButton'>";

			echo "<input type='hidden' name='MAX_FILE_SIZE' value='{$_SESSION['MUDBAG_USER']->params->upload_size}'>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Press Next to go to the next step.");
				$this->ButtonNoDirtyCheck("btn_Upload", "Next >");
				$this->ButtonSpaced(null, 'Back to Database', 'mb_dbmain.php');
			$tbl_form->FormCellEnd();
			$tbl_form->End();
		}

		function ShowFormSpec_Step_2() {
			$in = @fopen($this->spec->upload_file, "r");
			if (!$in) {
				$this->AddMessageError("Can't open temporary uploaded file: {$this->spec->upload_file}");
				$this->step = 1;
				$this->ShowForm();
				return;
			}
			$ast = fstat($in);
			$size = $ast['size'];
			if (!check_limits($msg, 0, 0, $size)) {
				echo "<p>You're trying to import a " . round($size / 1024, 1) . " kb file.";
				$this->MessageError($msg);
				return;
			}

			if ($size == 0) {
				$this->AddMessageError("Import file \"{$this->spec->file}\" is empty.");
				$this->step = 1;
				$this->ShowForm();
				return;
			}
			show_page_heading("Import Step 2: Specify File Layout", "helpctx_mb_dbtable_import~step2");
			$this->ShowMessages();
			echo "<p>";

			$new_table_string = '[New Table]';

			echo <<<EOT
				<script language="JavaScript">

				function chose_table(obj) {
					obj.form.mbfv_newtblname.disabled = (obj.value.indexOf('$new_table_string') < 0);
					if (obj.form.mbfv_newtblname.disabled)
						obj.form.mbfv_newtblname.value = '';
					else
						obj.form.mbfv_newtblname.focus(); // probably ineffective, as we're not finished with <select> yet
				}

				</script>
EOT;

			$chars = array("," => ", (comma)", "\t" => "tab", " " => "space", ";" => "; (semicolon)", ":" => ": (colon)",
			  "-" => "- (hyphen)", "|" => "| (bar)", "/" => "/ (slash)",
			  "." => ". (period)", "~" => "~ (tilde)", "!" => "! (exclamation)",
			  "@" => "@ (at)", "#" => "# (number sign)", "$" => "$ (dollar)", "%" => "% (percent)",
			  "^" => "^ (circumflex)", "&" => "& (ampersand)", "_" => "_ (underscore)", "+" => "+ (plus)",
			  "=" => "= (equals)", "\\" => "\\ (backslash)", "<" => "< (less than)",
			  ">" => "> (greater than)", "?" => "? (question mark)", "`" => "` (accent grave)");
			$quote_chars = array('"' => "\" (double quote)", "'" => "' (single quote)");
			$no_delim = array("\1" => "none");
			$delims = array_merge(array_merge($no_delim, $chars), $quote_chars);
			$quotes = array_merge(array_merge($no_delim, $quote_chars), $chars);
			$this->spec->char_dict = &$delims;
			$tbl_form = new MB_TableFormWithInstr();
			$tbl_form->Begin();

			$tbl_form->FormCellBegin("You can import into a new table, which you can name as you choose, or into an existing table.");
			$this->FieldLabel("Import Into", true);

			$result = $this->dbmain->db_query_user("show tables like '{$_SESSION['APPDB']->tblpfx}%'");
			echo "<select name='mbfv_tbl' onchange='chose_table(this);'>";
			if ($this->spec->new_table)
				$new_selected_str = " selected ";
			else
				$new_selected_str = "";
			echo "<option value='x-$new_table_string' $new_selected_str>$new_table_string</option>";
			while ($row = mysql_fetch_row($result))
				if (substr($row[0], 0, 4) != 'mb_') {
					$external_table = $_SESSION['APPDB']->external_name($row[0]);
					if (!$this->spec->new_table && $external_table == $this->spec->table)
						$selected_str = " selected ";
					else
						$selected_str = "";
					echo "<option value='t-$external_table' $selected_str>$external_table</option>";
				}
			echo "</select>";


			$this->FieldLabel("New Table Name");
			if ($this->spec->new_table) {
				$v = $this->spec->table;
				if (empty($v))
					$v = "Table" . get_name_seq_local("Import");
				$disabled_str = "";
			}
			else {
				$v = '';
				$disabled_str = " disabled ";
			}
			echo "<input type='text' size='10' name='mbfv_newtblname' value='$v' $disabled_str>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("The delimiter, often a comma, separates fields. If you're not sure what to use, look at the
			  display of the first few lines, below.");
			$this->FieldLabel("Delimiter", true);
			echo "<select name='mbfv_delim'>";
			foreach ($delims as $c => $cstr) {
				if ($c == $this->spec->delim)
					$selected = " selected ";
				else
					$selected = "";
				echo "<option value='$c' $selected>$cstr</option>";
			}
			echo "</select>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Import fields that might contain a delimiter as an ordinary character have to be
			  quoted. Choose the quote character that the import file uses.");
			$this->FieldLabel("Quote", true);
			echo "<select name='mbfv_quote' >";
			foreach ($quotes as $c => $cstr) {
				if ($c == $this->spec->quote)
					$selected = " selected ";
				else
					$selected = "";
				echo "<option value='$c' $selected>$cstr</option>";
			}
			echo "</select>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Sometimes the first line of a CSV file contains column headings, which should not be taken
			  as data. Check the box if this is the case.");
			$this->FieldLabel("Headings?", false);
			if ($this->spec->has_headings)
				$checked = " checked ";
			else
				$checked = "";
			echo "<input type='checkbox' name='mbfv_headings' $checked>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Press Next to go on, or Back to return to the previous step.");
				$this->ButtonNoDirtyCheck(null, "< Back", "mb_dbtable_import.php?spec={$this->spec->spec_name}&step=" . ($this->step - 1)); // force it back
				$this->ButtonSpacer();
				$this->ButtonNoDirtyCheck("btn_Next", "Next >"); // let it submit the form
				$this->ButtonSpaced(null, 'Back to Database', 'mb_dbmain.php');
			$tbl_form->FormCellEnd();
			$tbl_form->End();

			echo "<p>";
		$tbl_preview = new MB_Table();
			$tbl_preview->Begin();
			$tbl_preview->ColHdg("First Few Lines of Input File");
			echo "<tr><td nowrap bgcolorx=\"{$GLOBALS['color_bg_form_instr']}\"><pre>";
			$count = 0;
			while ($s = fgets($in)) {
				if ($count > 0)
					echo "<br>";
				echo htmlspecialchars(trim($s));
				if (++$count >= 5)
					break;
			}
			rewind($in);
			echo "</pre></td></tr>";
			$tbl_preview->End();
		}

		function ShowColumChooser_Step_3() {
			global $ignore_str;

			echo <<<EOT
				<script language="JavaScript">

				function chose_type(sel) {
					if (sel.value == 'c') {
						alert("You can't create a new table with a choice field during import." +
						  " If you need a choice field, first create the table from the Database page," +
						  " and then import into the existing table.");
						sel.selectedIndex = 0;
						return false;
					}
					return true;
				}

				</script>
EOT;


			$success = true;
			if (isset($_POST['mbfv_delim'])) { // coming from form, as opposed to Back button
				$this->spec->delim = stripslashes($_POST['mbfv_delim']);
				$this->spec->quote = stripslashes($_POST['mbfv_quote']);
				$this->spec->has_headings = isset($_POST['mbfv_headings']);
				$this->spec->new_table = $_POST['mbfv_tbl']{0} != 't';
				if ($this->spec->new_table) {
					$this->spec->set_table(trim($_POST['mbfv_newtblname']), false);
					if (!validate_dbtablename($this->spec->table, $msg, true)) {
						$this->AddMessageError($msg);
						$this->step = 2;
						$this->ShowForm();
						return;
					}
				}
				else
					$this->spec->set_table(substr($_POST['mbfv_tbl'], 2));
			}
			$in = @fopen($this->spec->upload_file, "r");
			if (!$in) {
				$this->AddMessageError("Can't open temporary uploaded file: {$this->spec->upload_file}");
				$this->step = 2;
				$this->ShowForm();
				return;
			}

			// Read 10 lines to determine the column count and get the header
			$this->spec->num_cols = 0;
			unset($this->spec->hdgs);
			$count = 0;
			$max_cols_in_data = 0;
			while ($a = fgetcsv($in, 5000, $this->spec->delim, $this->spec->quote)) {
				if ($count == 0 && $this->spec->has_headings && $this->spec->new_table)
					$this->spec->hdgs = $a;
				else
					$max_cols_in_data = max($max_cols_in_data, count($a));
				if (++$count >= 20)
					break;
			}
			if (isset($this->spec->hdgs)) {
				$had_nonempty = false;
				for ($i = count($this->spec->hdgs) - 1; $i >= 0; $i--)
					if (empty($this->spec->hdgs[$i]))
						if ($had_nonempty)
							$this->spec->hdgs[$i] = "Field" . ($i + 1);
						else
							array_pop($this->spec->hdgs);
					else {
						$had_nonempty = true;
						$s = &$this->spec->hdgs[$i];
						$n = strlen($s);
						for ($j = 0; $j < $n; $j++)
							if (!ctype_alnum($s{$j}) && $s{$j} != '_')
								$s{$j} = ' ';
						$s = str_replace(' ', '', $s);
						$s = substr($s, 0, 20);
						//$this->spec->hdgs[$i] = $s;
					}
				$this->spec->num_cols = max($max_cols_in_data, count($this->spec->hdgs));
			}
			else
				$this->spec->num_cols = $max_cols_in_data;
			rewind($in);
			show_page_heading("Import Step 3: Specify Table Fields", "helpctx_mb_dbtable_import~step3");
			$this->ShowMessages();

			if ($this->spec->new_table) {
				echo "<p>Imported data will be inserted into a new table to be named \"{$this->spec->table}\".";
				if (!check_limits($msg, 0, 1)) {
					$this->MessageError($msg);
					return;
				}

				if (isset($this->spec->fields))
					echo "<p>Field names in the drop-downs were taken from the first line of the import file.";
				else
					echo "<p>Field names (\"Field1\", \"Field2\", etc.) will be used for the import.";
				echo " You can choose \"$ignore_str\" in a drop-down to ignore a column.";
				echo " (You can rename the fields of the new table after the import is completed. Click " .
				  $this->HelpLink("here", "helpctx_mb_dbfield") . " for how to do this.)";
				echo "<p>Choose the field type from the second row of drop-downs. If you want, you can use Text
				  for any or all types and change them later. However, conversions (e.g., for DateTime and Yes/No
				  fields) will be more effective if you choose the type now.";
			}
			else {
				$num_fields = count($this->spec->field_dict);
				if ($num_fields == 0) {
					$this->AddMessageError("Table \"{$this->spec->table}\" has no fields.");
					$success = false;
				}
				else {
					echo "<p>Imported data will be inserted into table \"{$this->spec->table}\".";
					echo "<p>Use the drop-downs to choose the field name for a column, or choose \"$ignore_str\" to ignore the column.";
				}
			}
			if ($success) {
				echo "<p>";
				$tbl = new MB_Table();
				$tbl->Begin();
				for ($col = 1; $col <= $this->spec->num_cols; $col++)
					$tbl->ColHdg("Column&nbsp;$col");
				$count = 0;
				$did_dropdowns = false;
				while ($a = fgetcsv($in, 5000, $this->spec->delim, $this->spec->quote)) {
					if ($count++ == 0 && $this->spec->has_headings)
						continue;
					if (!$did_dropdowns) { // first non-heading line
						$did_dropdowns = true;
						$this->spec->row_sample = $a; // need copy -- don't use &
						if (!$this->spec->new_table) {
							echo "<tr>";
							for ($col = 0; $col < $this->spec->num_cols; $col++) {
								echo "<td valign='top'>";
								echo "<select name='mbfv_fieldname[$col]'>";
								$fnum = 0;
								$selected_ignore = "";
								unset($type);
								foreach ($this->spec->field_dict as $fld) {
									if (!isset($type))
										$type = $fld->word_for_type();
									if ($fld->name{0} == '$')
										continue;
									if (!empty($this->spec->fields)) {
										$selected = ($fld->name == $this->spec->fields[$col] ? " selected " : "");
										if (nvl($this->spec->fields[$col]) == $ignore_str)
										$selected_ignore = " selected ";
									}
									else
										$selected = ($fnum == $col ? " selected " : "");
									if ($col >= $num_fields)
										$selected_ignore = " selected ";
									echo "<option $selected value='$fld->name'>$fld->name (" . $fld->word_for_type() . ")</option>";
//									if ($selected)
//										$type = $fld->word_for_type();
									$fnum++;
								}
								echo "<option $selected_ignore>$ignore_str</option>";
								echo "</select>";
//								echo "<br>$type";
								echo "</td>";
							}
							echo "</tr>";
						}
						else {
							$num_hdgs = (isset($this->spec->hdgs) ? count($this->spec->hdgs) : 0);
							for ($col = $num_hdgs; $col < $this->spec->num_cols; $col++)
								$this->spec->hdgs[$col] = "Field" . ($col + 1);
							echo "<tr>";
							$col = 0;
							foreach ($this->spec->hdgs as $h) {
								echo "<td valign='top'>";
								echo "<select name='mbfv_fieldname[$col]'>";
								echo "<option " . ($this->spec->fields[$col] == $h ? " selected " : "") . ">$h</option>";
								echo "<option " . ($this->spec->fields[$col] == $ignore_str ? " selected " : "") . ">$ignore_str</option>";
								echo "</select>";
								echo "</td>";
								$col++;
							}
							echo "</tr>";
						}
						if ($this->spec->new_table) {
							echo "<tr>";
							for ($col = 0; $col < $this->spec->num_cols; $col++) {
								echo "<td valign='top'>";
								ShowFieldTypeSelect("mbfv_fieldtype[$col]", nvl($this->spec->types[$col]), "chose_type(this);");
								echo "</td>";
							}
							echo "</tr>";
						}
					}
					if ($count > 6) {
						break;
					}
					echo "<tr>";
					$acols = 0;
					foreach ($a as $f) {
						$acols++;
						$f = trim($f); // keep this -- part of Mudbag CSV spec
						//$f = str_replace("\r", '\r', $f);
						//$f = str_replace("\n", '\n', $f);
						//$f = str_replace(' ', "&loz;", htmlspecialchars($f));
						if (empty($f) && $f != '0')
							$f = "&nbsp;";
						else
							$f = htmlspecialchars($f);
						echo "<td valign='top'>$f</td>";
					}
					for ($i = $acols; $i < $this->spec->num_cols; $i++)
						echo "<td>&nbsp;</td>";
					echo "</tr>";
				}
				echo "<tr><td align='center' colspan='{$this->spec->num_cols}'><b><i>... only first few rows shown ...</i></b></td></tr>";
				$tbl->End();
			}
			fclose($in);
			$tbl_form = new MB_TableFormWithInstr();
			$tbl_form->Begin();

			echo "<p>";
			$tbl_form->FormCellBegin("Press Next to go on, or Back to return to the previous step.");
			$this->ButtonNoDirtyCheck(null, "< Back", "mb_dbtable_import.php?step=" . ($this->step - 1)); // force it back
			if ($success) {
				$this->ButtonSpacer();
				$this->ButtonNoDirtyCheck("btn_Next", "Next >"); // let it submit the form
			}
			$this->ButtonSpaced(null, 'Back to Database', 'mb_dbmain.php');
			$tbl_form->FormCellEnd();
			$tbl_form->End();
		}

		function ShowVerification_Step_4() {
			global $ignore_str, $new_spec_name;

			if (isset($_POST['mbfv_fieldname']))
				$this->spec->fields = $_POST['mbfv_fieldname'];
			if (isset($_POST['mbfv_fieldtype']))
				$this->spec->types = $_POST['mbfv_fieldtype'];
//			else
//				unset($this->spec->types);
			$dupchk = array();
			$fnum = 0;
			foreach ($this->spec->fields as $f) {
				$fnum++;
				if ($f != $ignore_str) {
				if (!validate_field_name($this, $f, "#" . $fnum)) {
						//$this->ShowMessages();
						$this->step = 3;
						$this->ShowForm();
						return;
					}
					$dupchk[$f] = nvl($dupchk[$f], 0) + 1;
				}
			}
			$dups = '';
			foreach ($dupchk as $k => $v)
				if ($v > 1)
					$dups .= ", $k";
			$dups = substr($dups, 1);
			$success = true;
			if (!empty($dups)) {
				$this->AddMessageError("Following fields are duplicated: $dups. Each column must go into a different field (or be ignored).");
				$success = false;
			}
			if (count($dupchk) == 0) {
				$this->AddMessageError("All columns are set to be ignored. At least one column must go into a field.");
				$success = false;
			}
			if (!$success) {
				$this->step = 3;
				$this->ShowForm();
				return;
			}
			show_page_heading("Import Step 4: Verify Import Specification", "helpctx_mb_dbtable_import~step4");
			$this->ShowMessages();
			echo "<p>";

			$tbl_form = new MB_TableFormWithInstr();
			$tbl_form->Begin();

			$tbl_form->FormCellBegin("Review the import specification. If anything needs to be changed, use the Back
			  button to go back and fix it. (Also look at the Correspondence table, below.)");
			echo "<p><b>File to import:</b> {$this->spec->file}";
			echo "<br><b>Delimiter:</b> {$this->spec->char_dict[$this->spec->delim]}";

			echo "<br><b>Quote:</b> {$this->spec->char_dict[$this->spec->quote]}";

			echo "<br><b>Headings?:</b> " . ($this->spec->has_headings ? "Yes" : "No");

			echo "<br><b>Table:</b> {$this->spec->table}";
			if ($this->spec->new_table)
				echo " (new)";

			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("The import will skip lines that have errors (e.g., \"x\" for a YesNo field, or
			  a missing value for a required field). You can set the maximum number of errors; if more occur, the
			  entire import will fail.");
			$this->FieldLabel("Max Errors", false);
			if ($this->spec->max_errs == MAX_ERRS_INFINITE)
				$e = '';
			else
				$e = $this->spec->max_errs;
			echo "<input type='text' size='5' value='$e' name='mbfv_max_errs'>";
			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Type a specification name if you want to save the
			  specification for reuse in future imports.");
			$this->FieldLabel("Specification Name", false);
			if ($this->spec->spec_name == 'Default')
				$sn = '';
			else
				$sn = $this->spec->spec_name;
			echo "<input type='text' size='20' value='$sn' name='mbfv_spec_name'>";
			//$this->ButtonSpaced(null, 'Save', null, null, "savespec_window(this.form.mbfv_spec_name.value); return false;");

			$tbl_form->FormCellEnd();

			$tbl_form->FormCellBegin("Press Next to perform the import, or Back to return to the previous step.");
			$this->ButtonNoDirtyCheck(null, "< Back", "mb_dbtable_import.php?step=" . ($this->step - 1)); // force it back
			$this->ButtonSpacer();
			$this->ButtonNoDirtyCheck("btn_Next", "Next >"); // let it submit the form
			$this->ButtonSpaced(null, 'Back to Database', 'mb_dbmain.php');
			$tbl_form->FormCellEnd();

			$tbl_form->End();

			echo "<p><b>Correspondence of columns to fields:</b><br>";
			$tbl_map = new MB_Table();
			$tbl_map->Begin();
			$tbl_map->ColHdg("Column");
			$tbl_map->ColHdg("Table Field");
			$tbl_map->ColHdg("Field Type");
			$tbl_map->ColHdg("Sample Row" . (!$this->spec->has_headings ? "*" : ""));
			for ($col = 0; $col < $this->spec->num_cols; $col++) {
				echo "<tr>";
				echo "<td align='top'>" . ($col + 1) . "</td>";
				$fname = nvl($this->spec->fields[$col], "?");
				echo "<td align='top'>$fname</td>";
				if ($fname == $ignore_str)
					$ftype = "&nbsp;";
				else if ($this->spec->new_table)
//{dump($this->spec->types);
					$ftype = word_for_type_static($this->spec->types[$col]);
//}
				else
					$ftype = $this->spec->field_dict[$fname]->word_for_type();
				echo "<td align='top'>$ftype</td>";
				$sample = htmlspecialchars(nvl($this->spec->row_sample[$col]));
				if (empty($sample))
					$sample = "&nbsp;";
				echo "<td align='top'>$sample</td>";
				echo "</tr>";
			}
			$tbl_map->End();
			if (!$this->spec->has_headings)
				echo "<p>* If the Sample Row looks like headings, you should probably go back two
				  steps and check the <i>Headings</i> checkbox so the heading row won't be taken as data.";


//		echo "<br>verification step";
//		dump($_POST);
//		dump($this->spec);
		}

		function DoImport_Step_5() {
			global 	$want_db_query_echo, $ignore_str;

			$this->import_error_count = 0;
			if (empty($_POST['mbfv_max_errs']))
				$this->spec->max_errs = MAX_ERRS_INFINITE;
			else {
				$this->spec->max_errs = $_POST['mbfv_max_errs'];
				if (!is_numeric($this->spec->max_errs) || $this->spec->max_errs < 0) {
					$this->AddMessageError("Max Errors must be numeric and non-negative.");
					$this->step = 4;
					$this->ShowForm();
					return;
				}
			}
			$this->spec->spec_name = $_POST['mbfv_spec_name'];
			$spec_name_len = strlen($this->spec->spec_name);
			if ($spec_name_len > 50) {
				$this->AddMessageError("Specification name must be from 1 to 50 characters.");
				$this->step = 4;
				$this->ShowForm();
				return;
			}
			if (strtoupper($this->spec->spec_name) == 'DEFAULT') {
				$this->AddMessageError("Specification can't be named \"Default\".");
				$this->step = 4;
				$this->ShowForm();
				return;
			}
			show_page_heading("Import Step 5: Perform Import", "helpctx_mb_dbtable_import~step5");
			$this->ShowMessages();

			$success = false;
			$internal_table = $this->dbapp->internal_name($this->spec->table);
			if ($spec_name_len == 0 || $this->SaveSpec($this->spec->spec_name))
				if ($this->spec->new_table) {
					if (!check_limits($msg, 0, 1)) {
						$this->MessageError($msg);
						return;
					}

					if ($this->QueryAddMessageUser("create table $internal_table
					  (_rowID int auto_increment primary key) type=MyISAM")) {
						for ($col = 0; $col < $this->spec->num_cols; $col++) {
							if ($this->spec->fields[$col] != $ignore_str) {
								$f = new Field($this->spec->table, $this->spec->fields[$col], $this->spec->types[$col]);
								if (!$f->store_new($error_number, $error_msg)) {
									$this->AddMessageError($error_msg);
									break;
								}
							}
						}
						$success = $col >= $this->spec->num_cols;
						if ($success) {
//							$f = new Field($this->spec->table, '$ImportErrors', "y");
//							if (!$f->store_new($error_number, $error_msg)) {
//								$this->AddMessageError($error_msg);
//								$success = false;
//							}
						}
					}
					if ($success)
						$this->AddMessageConfirmation("Table created successfully.");
				}
				else {
//					if (!isset($this->spec->field_dict['$ImportErrors'])) {
//						$f = new Field($this->spec->table, '$ImportErrors', "y");
//						if (!($success = $f->store_new($error_number, $error_msg)))
//							$this->AddMessageError($error_msg);
//					}
//					else
						$success = true;
				}

////////////////////// need conversions (tricky for choices) and error reporting ///////////////////////
			if ($success) {
				$success = false;
				$in = @fopen($this->spec->upload_file, "r");
				if ($in) {
					$num_fields = count($this->spec->fields);
					$fld_str = '';
					foreach ($this->spec->fields as $f)
						if ($f != $ignore_str)
							$fld_str .= ",$f";
					$fld_str = substr($fld_str, 1); // extra comma at start
					$count = $count_success = $count_empty = 0;
					$this->dbmain->db_query("begin");
					set_time_limit(5 * 60); // 5 minutes is maybe too much
					while ($a = fgetcsv($in, 5000, $this->spec->delim, $this->spec->quote)) {
						if ($count == 0 && $this->spec->has_headings) {
							$count++;
							continue;
						}
						$ImportErrorCount = 0;
						$vstr = '';
						$n = count($a);
						$conversion_bailout = false;
						$keep_rcd = true;
						for ($col = 0; $col < $num_fields; $col++)
							if ($this->spec->fields[$col] != $ignore_str) {
								unset($choices);
								$required = false;
								if ($this->spec->new_table)
									$type = $this->spec->types[$col];
								else {
									$fld = $this->spec->field_dict[$this->spec->fields[$col]];
									$type = $fld->type;
//echo "<br>type=$type";
									if ($type == 'c')
										$choices = &$fld->choices;
//dump($choices);
									$required = $fld->req;
								}
								$rtn = $this->process_value($this->spec->fields[$col], $type, nvl($a[$col]), $col,
								  $count + 1, $v_insert, $error, $choices, $required);
								if ($error) {
									$ImportErrorCount++;
									$keep_rcd = false;
								}
								if ($rtn)
									$vstr .= ",$v_insert";
								else {
									$conversion_bailout = true;
									break;
								}
							}
						if ($conversion_bailout)
							break;
						$vstr = substr($vstr, 1);
						if ($this->spec->spec_name == "import-test")
							echo "<br>[$vstr]";
						if ($keep_rcd && !empty($vstr))
							if ($this->QueryAddMessageUser("insert into $internal_table (" . /*'$ImportErrors' . "," .*/ "$fld_str)
							  values (" . /*"$ImportErrorCount," .*/ "$vstr)"))
								$count_success++;
							else
								break;
						else if (empty($vstr)) // can't happen, since empty values are inserted as nulls
								$count_empty++;
						$count++;
					}
					$count -= ($this->spec->has_headings ? 1 : 0);
					if (!$a) {
						$success = true;
						$this->dbmain->db_query("commit");
						$this->AddMessageConfirmation("$count_success line(s) successfully imported.");
						$this->AddMessageConfirmation(($count - ($count_success + $count_empty)) . " line(s) skipped due to errors.");
						if ($count_empty)
							$this->AddMessageConfirmation("$count_empty empty line(s) skipped.");
					}
					else {
						if ($this->dbmain->db_query("rollback", true))
							$this->AddMessageInfo("No data has been imported into the table, not even from error-free lines.");
						else
							$this->AddMessageInfo("Some data has been imported into the table.");
					}
				}
				else
					$this->AddMessageError("Can't open temporary uploaded file: {$this->spec->upload_file}");
			}
			$this->ShowMessages();
			echo "<p>";
			if ($success) {
				if ($this->spec->spec_name != "import-test") {
					@unlink($this->spec->upload_file);
					$this->spec->upload_file .= " (unlinked)"; // for potential debugging
				}
			}
			else {
				$this->ButtonNoDirtyCheck(null, "< Back", "mb_dbtable_import.php?step=" . ($this->step - 1)); // force it back
				$this->ButtonSpacer();
			}

			$this->Button(null, "To Table \"{$this->spec->table}\"", "mb_dbtable.php?data=1&table={$this->spec->table}");
		}

		function process_value($fldname, $fldtype, $v, $col, $line, &$v_insert, &$error, &$choices, $required) {
			$v_insert = "null";
			if ($error = !convert_to_mysql_value($fldname, $fldtype, $v, $vcvt, $msg, $choices, $required)) {
				$this->AddMessageError("Line $line: $msg (line skipped)");
				if (++$this->import_error_count > $this->spec->max_errs && $this->spec->max_errs != MAX_ERRS_INFINITE) {
					$this->AddMessageInfo("At most {$this->spec->max_errs} errors are allowed.");
					return false;
				}
				return true;
			}
			if (isset($vcvt))
				$v_insert = "'" . mysql_real_escape_string($vcvt) . "'";
			return true;
		}

		function SaveSpec($spec_name) {
			if ($success = $this->spec->Save($this, $spec_name))
				$this->AddMessageConfirmation("Specification saved.");
			$this->ShowMessages();
			$this->ClearMessages();
			return $success;
		}
	}

	$frm = new MB_DBTableImport(nvl($spec));
	$frm->AutoShowMessage(false);

//	if (isset($spec_name)) {
//		// We are in a separate spec-saving window.
//		$frm->SaveSpec($spec_name);
//		exit;
//	}

	if (!isset($step))
		$step = 1;
	$frm->step = $step;
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right


	$frm->Go(null, null, "helpctx_mb_dbtable_import~step1");//, false, "mb_dbtable_import.php?step=" . ($step + 1));
?>
