<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_globals.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

	define('COLOR_VERYDARK', "#464B73"); // was #545B8B
	define('COLOR_DARK', "#7A81AF");
	define('COLOR_LIGHTER', "#CFD2E2"); // was #C7CBDE
	define('COLOR_VERYLIGHT', "#E0E0E0"); // should darker than COLOR_BODY_BG so table borders show
	define('COLOR_LIGHT_TEXT', "white");
	define('COLOR_BODY_BG', "white");
	$color_bg_btn_nav = COLOR_LIGHTER;
	$color_bg = COLOR_VERYLIGHT;
	$color_fg = COLOR_DARK;
	$color_text = COLOR_VERYDARK;
	$color_bg_body = COLOR_BODY_BG;
	$color_logo = $color_fg;//"#FF8000";
	$color_bg_btn = COLOR_LIGHTER;
	$color_fg_btn = COLOR_VERYDARK;
	$color_brdr_btn = $color_fg;
	$color_bg_table = $color_bg_body;
	$color_brdr_table = COLOR_VERYLIGHT;
	$color_bg_page_toolbar = COLOR_DARK;
	$color_bg_table_hdg = COLOR_LIGHTER;
	$color_fg_table_hdg = COLOR_DARK;
	$color_bg_form_instr = "#EEEEEE";
?>
