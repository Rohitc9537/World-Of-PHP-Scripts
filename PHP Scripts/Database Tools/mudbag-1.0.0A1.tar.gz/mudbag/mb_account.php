<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_account.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_Account extends MB_DBScreen {

		var $form = "main";
		var $sample_tables = true;
		var $table_plans;

		function MB_Account() {
			parent::MB_DBScreen();
			$this->table_plans = $_SESSION['APPDB']->internal_name_admin("Plans");
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_main":
				$this->form = "main";
				break;
			case "btn_plan_edit":
				$this->form = "plan_edit";
				break;
			case "btn_plan_change":
				$this->form = "plan_change";
				break;
			case "btn_plan_pay":
				$this->form = "plan_pay";
				break;
			default:
				parent::Callback($tag);
			}
		}

		function ShowForm() {
			//$this->SetPageHelpCtx("helpctx_mb_account~$this->form");
			switch ($this->form) {
			case "main":
				show_page_heading("Account Information", "helpctx_mb_account~$this->form");
				$this->ShowMessages();
				echo "<p>";
				$this->ShowForm_main();
				break;
			case "plan_edit":
				show_page_heading("Plan Selection", "helpctx_mb_account~$this->form");
				$this->ShowMessages();
				echo "<p>";
				$this->ShowForm_plan_edit();
				break;
			case "plan_change":
				show_page_heading("New Plan", "helpctx_mb_account~$this->form");
				$this->ShowMessages();
				echo "<p>";
				$this->ShowForm_plan_change();
				break;
			case "plan_pay":
				show_page_heading("Plan Payment", "helpctx_mb_account~$this->form");
				$this->ShowMessages();
				echo "<p>";
				$this->ShowForm_plan_pay();
			}
		}

		function ShowForm_main() {
			$u = &$_SESSION['MUDBAG_USER'];
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$width_left = 200;
			$tbl->FormCellBegin("This part shows your personal information. Press the button to make changes,
			  including changing your password, if you need to.");
			echo "<table border='0'>";
			echo "<tr><td align='right'><b>First Name:&nbsp;</b></td><td>$u->firstname</td></tr>";
			echo "<tr><td align='right'><b>Last Name:&nbsp;</b></td><td>$u->lastname</td></tr>";
			echo "<tr><td align='right'><b>Street (Line 1):&nbsp;</b></td><td>$u->street1</td></tr>";
			echo "<tr><td align='right'><b>Street (Line 2):&nbsp;</b></td><td>$u->street2</td></tr>";
			echo "<tr><td align='right'><b>City:&nbsp;</b></td><td>$u->city</td></tr>";
			echo "<tr><td align='right'><b>State:&nbsp;</b></td><td>$u->state</td></tr>";
			echo "<tr><td align='right'><b>ZIP:&nbsp;</b></td><td>$u->zip</td></tr>";
			echo "<tr><td align='right'><b>Country:&nbsp;</b></td><td>$u->country</td></tr>";
			echo "<tr><td align='right'><b>Phone:&nbsp;</b></td><td>$u->phone</td></tr>";
			echo "<tr><td align='right'><b>Email:&nbsp;</b></td><td>$u->email</td></tr>";
			echo "<tr><td align='right'><b>Password:&nbsp;</b></td><td><i>not shown</i></td></tr>";
			echo "<tr><td><img src=\"images/1pixtran.gif\" height=\"1\" width=\"$width_left\"></td><td></td></tr>";
			echo "</table>";
			$this->Button("null", "Change Info", "mb_register.php");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("This part shows your current plan and usage. To see what other plans are available and perhaps upgrade
			  to one of them, press the button.");
			$this->show_current_plan($width_left);
			$this->Button("btn_plan_edit", "Renew or Change Plan");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("This part shows your recent payments, if any.");
			$this->dbmain->db_query_show("Payments (up to last 10 shown)",
			  "SELECT payment_date as 'Date', item_name as 'Item', invoice as 'Code and Term', payment_gross as 'Amount' FROM mb_paypal_txn
			  where account_id = {$_SESSION['MUDBAG_USER']->account_id}
			  and status = 'VERIFIED'
			  and txn_type = 'subscr_payment'
			  order by payment_date desc
			  ", 10);
			$tbl->FormCellEnd();

			$tbl->End(false);
		}

		function ShowForm_plan_edit() {
			$u = &$_SESSION['MUDBAG_USER'];
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$width_left = 200;

			$tbl->FormCellBegin("Your current plan and usage.");
			$current_sku = $this->show_current_plan($width_left);
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("These are the plans available to you. If you change from one paying (not free) plan to another,
			  the new plan will be effective right away and you'll be credited with any unused payments you've made.");
			$result = $this->dbmain->db_query("select * from {$this->table_plans} where active = 1 order by limit_data");
			$tbl_plans = new MB_Table();
			$tbl_plans->Begin();
			$tbl_plans->ColHdg("Choice");
			$tbl_plans->ColHdg("Plan Name");
			$tbl_plans->ColHdg("Monthly Rate");
			$tbl_plans->ColHdg("Yearly Rate");
			$tbl_plans->ColHdg("Max Databases");
			$tbl_plans->ColHdg("Max Tables");
			$tbl_plans->ColHdg("Max Data");
			$tbl_plans->ColHdg("Max Emails");
			$tbl_plans->Body();
			while ($row = mysql_fetch_assoc($result)) {
				if ($row['sku'] == 'FREE' && $current_sku != 'FREE')
					continue; // can't downgrade to free
				if ($row['sku'] == 'ADMIN' && !$u->admin)
					continue;
				$rate_month = $this->get_rate_str(round($row['rate_month'], 2));
				$rate_year = $this->get_rate_str(round($row['rate_year'], 2));
				echo "<tr>";
				echo "<td><input type='radio' " . ($row['sku'] == $current_sku ? " checked " : "") .
				  "name='mbfv_plan' value='{$row['sku']}'></td>";
				echo "<td>{$row['name']}</td>";
				echo "<td>$rate_month</td>";
				echo "<td>$rate_year</td>";
				echo "<td>{$row['limit_databases']}</td>";
				echo "<td>{$row['limit_tables']}</td>";
				echo "<td>{$row['limit_data']} kb</td>";
				echo "<td>{$row['limit_emails']}</td>";
				echo "</tr>";
			}
			$tbl_plans->End();
			echo "<p>";
			$this->Button("btn_plan_change", "Choose");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press this button if you don't want to renew or change your plan now.");
			$this->Button("btn_main", "Back to Main Account Page");
			$tbl->FormCellEnd();

			$tbl->End(false);
		}

		function ShowForm_plan_change() {
			echo <<<EOT
				<script language="JavaScript">

				function pay_window(obj, sku) {
					var period = 'year';
					if (document.getElementById('period_month').checked)
						period = 'month';
					var w = window.open('mb_account_pay.php?sku=' + sku + '&period=' + period,

					'MudbagPay', 'width=900,height=700,resizable,scrollbars');

					w.focus();
				}

				</script>
EOT;
			$sku_new = $_POST['mbfv_plan'];
			if ($sku_new == 'FREE') {
				$this->MessageInfo("It's not necessary to renew the Free plan.");
				echo "<p>";
				$this->Button("btn_plan_edit", "Back to Plan Details");
				return;
			}
			//echo "<input type='hidden' name='mbfv_plan' value='$sku_new'>";
			$u = &$_SESSION['MUDBAG_USER'];
			$row_current = get_current_plan();

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$width_left = 200;

			$tbl->FormCellBegin("This is the new plan you've chosen and your current usage.");
			$row_new = $this->show_plan($width_left, $sku_new, null, false);
			$tbl->FormCellEnd();

			if ($row_new) {
				$tbl->FormCellBegin("Choose Monthly or Yearly payment at the rate shown above.");
				echo "<input type='radio' name='mbfv_period' id='period_month' value='month' checked>Monthly";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;";
				echo "<input type='radio' name='mbfv_period' id='period_year' value='year'>Yearly";
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("The information at right shows if and how you'll be credited with payments you've already made.");
				get_plan_days_left($row_new, $row_current, $days_left, $days_left_equiv);
				if (isset($days_left_equiv) && $days_left != $days_left_equiv)
					echo "You have $days_left days left on your current plan,
					  which is equivalent to $days_left_equiv days at the new rate.
					  When you make the new payment, the new expiration date will be adjusted to be $days_left_equiv days
					  from today plus the period you've selected above.";
				else
					echo " When you make the new payment, the new expiration date will be extended
					by the period you've selected above.";
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("Press the <i>Make Payment</i> to set up payments with PayPal,
				  or press <i>Back to Plan Details</i> if you don't want to change or renew your plan now.");
				$this->Button("btn_plan_pay", "Make Payment", null, null, "pay_window(this, '$sku_new');");
				$this->ButtonSpaced("btn_plan_edit", "Back to Plan Details");
				echo '<br><img src="https://www.paypal.com/en_US/i/bnr/horizontal_solution_PP.gif" border="0" alt="Solution Graphics">';
				$tbl->FormCellEnd();
			}
			else {
				$tbl->FormCellBegin("");
				echo "<font color='red'>You can't change to this plan because you're already over one or more limits.</font>";
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("Press the <i>Back to Plan Details</i> to choose a different plan.");
				$this->Button("btn_plan_edit", "Back to Plan Details");
				$tbl->FormCellEnd();
			}

			$tbl->End(false);
		}

		function ShowForm_plan_pay() {
			echo "<p>After you've closed the PayPal window, press the button below to confirm that
			  Mudbag has received your payment. If it hasn't, wait 10 min. and check again (you can use Mudbag
			  while you're waiting). If the payment still isn't shown, press <i>Contact Us</i> at the top of this
			  screen to report the problem.<p>";
			$this->Button(null, "Main Account Page", "mb_account.php");
		}

		function show_current_plan($width_left) {
			$row = get_current_plan();
			$this->show_plan($width_left, null, $row);
			return $row['sku'];
		}

		function get_rate_str($rate) {
			if ($rate < .001)
				$rate = "<i>free</i>";
			else
				$rate = "$" . $rate;
			return $rate;
		}

		function show_plan($width_left, $sku, $row = null, $want_expiration = true) {
			if (isset($sku))
				$row = get_plan($sku);
			$this->dbapp->get_stats($num_dbs, $num_tbls, $total_data);
			$total_data_kb = round($total_data / 1000, 1);
			$rate_month = round($row['rate_month'], 2);
			$expires = nvl($row['expire'], "<i>see plan description</i>");
			if ($rate_month < .001)
				$rate_month = "<i>free</i>";
			else
				$rate_month = "$" . $rate_month;
			$rate_year = round($row['rate_year'], 2);
			if ($rate_year < .001)
				$rate_year = "<i>free</i>";
			else
				$rate_year = "$" . $rate_year;
  			echo "<table border='0'>";
			echo "<tr><td align='right'><b>Plan:&nbsp;</b></td><td>{$row['name']}</td></tr>";
			echo "<tr><td align='right'><b>Monthly Rate:&nbsp;</b></td><td>$rate_month</td></tr>";
			echo "<tr><td align='right'><b>Yearly Rate:&nbsp;</b></td><td>$rate_year</td></tr>";
			if ($want_expiration)
				echo "<tr><td align='right'><b>Expiration:&nbsp;</b></td><td>$expires</td></tr>";
			echo "<tr><td align='right'><b>Max Databases:&nbsp;</b></td><td>{$row['limit_databases']} (Currently: $num_dbs)</td></tr>";
			echo "<tr><td align='right'><b>Max Tables:&nbsp;</b></td><td>{$row['limit_tables']} (Currently: $num_tbls)</td></tr>";
			echo "<tr><td align='right'><b>Max Data:&nbsp;</b></td><td>{$row['limit_data']} kb (Currently: {$total_data_kb} kb)</td></tr>";
			echo "<tr><td align='right'><b>Max Emails Per Send:&nbsp;</b></td><td>{$row['limit_emails']}</td></tr>";
			echo "<tr><td><img src=\"images/1pixtran.gif\" height=\"1\" width=\"$width_left\"></td><td></td></tr>";
			echo "</table>";

			if (check_limits($msg, 0, 0, 0, $row))
				return $row;
			else
				return null;
		}
	}

	$frm = new MB_Account();
	$frm->AutoShowMessage(false);
	$frm->SetLevelHome();
	$frm->Go(null, null, 'helpctx_mb_account~main', false, null, true, true);
?>
