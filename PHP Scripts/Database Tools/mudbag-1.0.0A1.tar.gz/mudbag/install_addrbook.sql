insert into {TABLE} (Company, Email) values
("Basepath Associates","info@mudbag.com");