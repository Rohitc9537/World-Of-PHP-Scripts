<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_admin.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");
	require("lib/browser_detection.php");


	$want_db_query_echo = false;

	class MB_Admin extends MB_DBScreen {

		var $drop_confirm = false;
		var $callback_tag = "btn_main";

		function MB_Admin() {
			parent::MB_DBScreen();
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_dropall":
				$this->drop_confirm = true;
				break;
			case "btn_dropall_really":
				$result = $this->dbmain->db_query("show tables like 'mb_%'");
				while ($row = mysql_fetch_row($result))
					$this->dbmain->db_query("drop table $row[0]");
				$this->AddMessageConfirmation("Database gone. Need to run install.php");
				break;
			case "btn_install_plans":
				$db = new MB_AppDB();
				$db->Install(true);
				break;
			default:
				$this->callback_tag = $tag;
			}
		}

		function ShowForm() {
			if ($_SESSION['MUDBAG_USER']->login != "admin")
				exit("You are not the administrator.");
			$this->Button(null, "Users", "mb_admin_user.php");
			$this->ButtonSpaced("btn_log", "Log");
			$this->ButtonSpaced("btn_mysql_status", "MySQL Status");
			$this->ButtonSpaced(null, "PHP Info", null, null, "var w = window.open('phpinfo.php', 'phpinfo', 'width=1000,height=600,resizable,scrollbars'); w.focus();");
			echo "<hr>";
			switch ($this->callback_tag) {
			case "btn_main":
				break;
			case "btn_mysql_status":
				$this->dbmain->db_query_show("MySQL Version", "show variables like 'version'");
				$this->dbmain->db_query_show("MySQL Variables", "show global variables");
				$this->dbmain->db_query_show("MySQL Status", "show status");
				break;
			case "btn_log":
				$this->dbmain->db_query_show("Log (last 5 days)",
				  "select
				  	date_format(updated, '%Y-%m-%d %T %a') as \"time\",
				  	code,
				  	msg
				  from mb_log where updated > date_sub(curdate(), interval 5 day) order by updated desc");
				break;
//			case "btn_php_info":
//				echo "<p>PHP Version: " . phpversion();
//				phpinfo();
//				break;
			default:
				parent::Callback($this->callback_tag);
			}

/////////////////////////////////////////////////////////////////////////////////

			echo "<hr>";
// 			if ($this->drop_confirm)
// 				$this->Button("btn_dropall_really", "Drop All Tables and Destroy All Data -- Really?");
// 			else
// 				$this->Button("btn_dropall", "Drop All Tables and Destroy All Data");

			$this->dbmain->db_query_show("Missing Help Files", "SELECT * FROM mb_param where tag like 'exists%' and data1 = 0 order by tag");


			$table_plans = $_SESSION['APPDB']->internal_name_admin("Plans");
			$this->dbmain->db_query_show("All Plans", "select * from {$table_plans} where active = 1");

			$this->ButtonSpaced("btn_install_plans", "Reinstall Plans");
			//db_clear();

			echo "<p>Invite URL: " . get_invite_url(0);

			echo "<p>os: {$_SESSION['MUDBAG_USER']->os}";
			echo "<p>useragent (from browser) = \"{$_SESSION['mb_useragent']}\"";
			echo "<p>useragent (from HTTP_USER_AGENT) = \"{$_SERVER['HTTP_USER_AGENT']}\"";
			echo "<pre>";

			$a = browser_detection('full');

			var_dump($a);

			$a = browser_detection('moz_version');

			var_dump($a);

			echo "<p>";

			echo "browser = " . browser_detection('browser');

			echo "<p>";

			echo "number = " . browser_detection('number');

			echo "<p>";

			echo "math_number = " . browser_detection('math_number');


			echo "<p><a href='mb_login.php?bad_browser=1'>Test Bad Browser Page</a>";

			$this->dbmain->db_query_show("User Table", "show columns from mb_user", true);
			$this->dbmain->db_query_show("User Table", "select * from mb_user order by login", true);

			$this->dbmain->db_query_show("InnoDB", "show variables like 'have_innodb'", true);
			$this->dbmain->db_query_show("All Tables", "show table status", true);

		}
	}

	$frm = new MB_Admin();
	//$frm->SetActiveDatabase(null);
	$frm->SetLevelHome();
	$frm->Go(null, "Administration", "helpctx_mb_admin", false, null, true, true);
?>
