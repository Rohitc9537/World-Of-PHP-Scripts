<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_browser_check.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

	require("lib/browser_detection.php");



	function InitBrowser() {

		global $browser_version, $browser_name;


		$browser_version = array("firefox" => 1, "ie" => 4, "saf" => 85, "op" => 7, "mozilla" => 1);
		$browser_name = array("firefox" => "Firefox", "ie" => "Internet Explorer", "saf" => "Safari",
		  "op" => "Opera", "mozilla" => "Mozilla");
//			$browser_version = array("firefox" => 1, "ie" => 4, "safari" => 1, "opera" => 7, "mozilla" => 1);
//			$browser_name = array("firefox" => "Firefox", "ie" => "Internet Explorer", "safari" => "Safari",
//			  "opera" => "Opera", "mozilla" => "Mozilla");
		// Known bad ones: Netscape 4
	}



	function CheckBrowser(&$frm) {

		global $browser_version, $browser_name;


		$test = isset($_GET['bad_browser']);
		InitBrowser();
		// Only problem with get_browser() is that it's impractical to install the spec file on each machine. Often
		// the person who installs Mudbag has no access to php.ini.
//			$browser = get_browser();
//			$b = strtolower($browser->browser);
//			$v = $browser->majorver;

		$_SESSION['MUDBAG_USER']->os = browser_detection('os');
		if ($test)
			$b_str = $b = "WebBurp";
		else {
			$b = strtolower(browser_detection('browser'));
			$b_str = ucfirst(browser_detection('s_browser'));
		}

		if ($b == 'moz') {
			$a = browser_detection('moz_version');
			$b_str = $b = strtolower($a[0]);
		}
		$v = (int)floor(browser_detection('math_number'));
		if (!empty($browser_version[$b]) && $browser_version[$b] <= $v)
			return true;
		if (isset($frm)) {
			$frm->MessageError("Mudbag may not work with your browser, which appears to be \"$b_str\" version $v.");
			echo "Click " . $frm->HelpLink("here", "helpctx_mb_login~lnk_browser") . " for details.<p>";

		}

		else

			echo "<p>Your browser appears to be \"$b_str\" version $v.";
		return false;
	}



	function BrowserMsg() {
		global $browser_version, $browser_name;



		$frm = null;
		CheckBrowser($frm);
		echo "<p>Mudbag works with the following browsers:<p>";
		foreach ($browser_version as $k => $v)
			echo "&nbsp;&nbsp;&nbsp;&nbsp;$browser_name[$k] version $v or higher<br>";
		echo <<<EOT
			<p>&nbsp;<p>Firefox is available for Mac OS X (but not OS 9 or lower), Linux, and Windows (98, 98SE, ME, NT 4.0, 2000, XP, and Server 2003).
			<p><a target='_blank' href="http://www.spreadfirefox.com/?q=affiliates&amp;id=0&amp;t=70"><img border="0" alt="Get Firefox!" title="Get Firefox!" src="http://sfx-images.mozilla.org/affiliates/Buttons/88x31/get.gif"/></a>
EOT;

	}
?>
