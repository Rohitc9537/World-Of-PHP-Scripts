<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbadd.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBAdd extends MB_DBScreen {

		var $created;
		var $sample_tables = true;

		function MB_DBAdd() {
			$this->MB_DBScreen();
		}

		function Callback($tag) {
			if ($tag == "add_button") {
				$this->sample_tables = isset($_POST['mbfv_adddb_samples']);
				if (!validate_dblongname($_POST['mbfv_adddb_nm'], $msg)) {
					$this->AddMessageError($msg);
					return;
				}

				$dbapp = new MB_AppDB();

				$this->created = $dbapp->create($_POST['mbfv_adddb_nm'], $this->sample_tables, $msg);
				if ($this->created)
					$this->SetActiveDatabase($_POST['mbfv_adddb_nm'], true);
				else
					$this->AddMessageError($msg);

			}
		}

		function ShowForm() {
			if ($this->created) {
				$db = $_POST['mbfv_adddb_nm'];
				$this->MessageConfirmation("Database \"$db\" has been added.");
				echo "<p>";
				echo "Press the button below to add a table to the new database.";
				echo "<p>";
				$this->Button(null, "Add Table", "mb_dbtable_add.php?add=1");
			}
			else {
				if (!check_limits($msg, 1, 0)) {
					$this->MessageError($msg);
					return;
				}

				$tbl = new MB_TableFormWithInstr();
				$tbl->Begin();

				$tbl->FormCellBegin("To add a database, type its name, which can be from 1 to 20 letters, digits, spaces, and underscores.");
				$nm = nvl($_POST['mbfv_adddb_nm']);
				$this->FieldLabel("Database Name", true);
				echo "<input type=\"text\" name=\"mbfv_adddb_nm\" value=\"$nm\">";
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("Do you want sample tables (e.g., AddrBook, Notes)?");
				$checked = ($this->sample_tables ? " checked " : "");
				$this->FieldLabel("Sample Tables?", false);
				echo "<input type=\"checkbox\" name=\"mbfv_adddb_samples\" $checked>";
				$tbl->FormCellEnd();

				$tbl->FormCellBegin("Press the <i>Add</i> button to create the new database.");
				$this->Button("add_button", "Add");
				$this->ButtonSpaced(null, "Back to Home Page", "mb_dbmain.php");
				$tbl->FormCellEnd();

				$tbl->End();
			}
		}
	}

	$frm = new MB_DBAdd();
	nav_clear(); // No longer clears db or field
	$hdg = "Add Database";
	$frm->Go(null, $hdg, "helpctx_mb_dbadd");
?>
