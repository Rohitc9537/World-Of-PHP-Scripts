<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: js-reorder.php,v 1.1.1.1 2005/07/13 00:21:58 rochkind Exp $

echo <<<EOT
<script language="JavaScript">
function move(frm, lst, step) {
	if (lst.length > 1) {
		var sel = lst.selectedIndex;
		var mt1 = lst[sel + step].text;
		var mt2 = lst[sel].text;
		var mv1 = lst[sel + step].value;
		var mv2 = lst[sel].value;
		lst[sel].text = mt1;
		lst[sel].value = mv1;
		lst[sel + step].text = mt2;
		lst[sel + step].value = mv2;
		lst.selectedIndex = sel + step;
	}
	sel_change(frm, lst);
}

function sel_change(frm, lst) {
	var sel = lst.selectedIndex;

	if (sel > 0)
		frm.btn_up.disabled = 0;
	else
		frm.btn_up.disabled = 1
	if (sel < lst.length - 1)
		frm.btn_down.disabled = 0;
	else
		frm.btn_down.disabled = 1;
}

</script>
<!--
	<FORM action="" method=get name="frm">
		<select name="lst" size=10 onChange="sel_change(form, lst);">
			<option value="1">aaa</option>
			<option value="2">bbb</option>
			<option value="3">ccc</option>
		</select>
		<input type=button name="btn_up" value="up" disabled onclick="move(frm, lst, -1)">
		<input type=button name="btn_down" value="down" disabled onclick="move(frm, lst, +1)">
	</form>
-->
EOT;
?>
