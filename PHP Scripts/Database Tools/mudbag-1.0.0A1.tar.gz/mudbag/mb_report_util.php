<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_report_util.php,v 1.1.1.1 2005/07/13 00:22:04 rochkind Exp $

require("mb_mail_sim_util.php");

function report_insert_fields($templ, $elim_blank_lines, &$row) {
	$templ = str_replace("\r\n", "\n", $templ);
	$templ = str_replace("\r", "", $templ);
	$count = 0;
	while (preg_match('/^(.*)\{([^{]+)\}(.*)$/s', $templ, $matches)) {
		if ($count++ > 200)
			exit("Runaway field replacement in template.");
		$f = $matches[2];
		if (strtolower($f) == "leftbrace")
			$f = "\1";
		else if (strtolower($f) == "space")
			$f = "\2";
		else if (strtolower($f) == "tab")
			$f = "\3";
		else
			$f = nvl($row[$f]); // do the formatting right here
		$templ = $matches[1] . $f . $matches[3];
	}
	$templ = str_replace("\1", "{", $templ);
	if ($elim_blank_lines)
		while (preg_match('/^(.*)\s*\n\s*\n\s*(.*)$/s', $templ, $matches))
			$templ = $matches[1] . "\n" . $matches[2];
	$templ = trim($templ);
	$templ = str_replace("\1", "{", $templ);
	$templ = str_replace("\2", " ", $templ);
	$templ = str_replace("\3", "\t", $templ);
	return $templ;
}

function report_query_tableview(&$spec, &$errmsg) {
	$result_data = $_SESSION['APPDB']->query_tableview($spec->is_table, $spec->tableview_name, $field_dict, $err, true);
	if (!$result_data) {
		if (mysql_errno() == 1146 || (mysql_errno() == 0 && $err == 1146))
			$errmsg = "This report is based on " . ($spec->is_table ? "table" : "view") . " $spec->tableview_name,
			  which no longer exists.";
		else
			$errmsg = "Database error: " . mysql_error() . " [" . mysql_errno() . "]";
		return null;
	}
	return $result_data;
}

function report_send_email(&$spec, &$row, $test_email = null) {
	$body = report_insert_fields($spec->template, false, $row);
	$abody = explode("\n", $body, 3);
	if (isset($test_email))
		$to = $test_email;
	else {
		$to = $abody[0];
		if (($n = strpos($to, ':')) !== false)
			$to = substr($to, $n + 2);
	}
	$to = trim($to);
	if (empty($to))
		return false;
	$subject = $abody[1];
	if (($n = strpos($subject, ':')) !== false)
		$subject = substr($subject, $n + 2);
	$body = trim($abody[2]);
	return mb_mail($to, $subject, $body, "From: {$_SESSION['MUDBAG_USER']->email}", false);
}

?>
