<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_respond.php,v 1.1.1.1 2005/07/13 00:22:05 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");

	class MB_MngUsersRespond extends MB_BaseScreen {

		var $bad_email_addrs;
		var $msg_part_1, $msg_part_2;
		var $get_from_table_or_view = false;
		var $role_id;
		var $valid;
		var $code;
		var $login;
		var $token_id;
		var $changed_password = false;

		function MB_MngUsersRespond() {
			parent::MB_BaseScreen(true, false); // no sesssion
		}

		function Callback($tag) {
			switch ($tag) {
			case "btn_change":
				// Check that passwords match.
				if (nvl($_POST['mbfv_password']) != nvl($_POST['mbfv_password_repeat'])) {
					$this->AddMessageError("Passwords don't match. Please retype them.");
					return;
				}

				// Check that password is long enough.
				if (strlen($_POST['mbfv_password']) < 6) {
					$this->AddMessageError("Password must be at least 6 characters.");
					return;
				}
				$this->change_password($_POST['mbfv_password']);
				$this->changed_password = true;
				$this->AddMessageConfirmation("Your password has been changed.");
				break;
			default:
				parent::Callback($tag);
			}
		}

		function change_password($password) {
			$db = new MB_DB();
			$db->db_query("update mb_user set password = PASSWORD('$password')
			  where login = '$this->login'");
			$db->db_query("update mb_token set when_redeemed = now() where token_id = {$this->token_id}");
		}

		function ShowForm() {
			if ($this->changed_password) {
				echo "<p>Click <a href='mb_login.php'>here</a> to login to Mudbag with your new password.";
			}
			else if ($this->role_id == ROLE_OWNER) {
				echo "<p>This form allows you to change the password for user ID \"$this->login\".
				  If you don't need to change the password, you may ignore this form and click
				  <a href='mb_login.php'>here</a> to login to Mudbag with your existing password.<p>";
				if ($this->valid) {
//kill code once used
					$tbl = new MB_TableFormWithInstr();
					$tbl->Begin();

					$tbl->FormCellBegin("Type your new password. (At least 6 characters.)");
					$this->FieldLabel("Password", true);
					echo "<input type='password' size='20' name='mbfv_password'>";
					$tbl->FormCellEnd();

					$tbl->FormCellBegin("For verification, type the new password again.");
					$this->FieldLabel("Password Repeat", true);
					echo "<input type='password' size='20' name='mbfv_password_repeat'>";
					$tbl->FormCellEnd();

					$tbl->FormCellBegin("Press this button to change your password.");
					$this->Button("btn_change", "Change");
					$tbl->FormCellEnd();

					$tbl->End();
				}
				else {
					$this->MessageError("You've reached this form in error.");
					echo "<p>Click <a href='mb_login.php'>here</a> to login to Mudbag.";
				}
			}
			else {
				if ($this->valid) {
					echo "<p>Thanks for responding to the invitation to share a database.
					  <p>It will be set up for you as soon as you login or register.<p>";
					$tbl = new MB_TableFormWithInstr();
					$tbl->Begin();

					$tbl->FormCellBegin("If you don't have a Mudbag login on this site, it will take only a minute or so to register.
					  Press the button at right.");
					if ($this->code == "preview")
						$this->Button(null, "Register", null, null, "alert('Preview only.'); return false;");
					else
						$this->Button(null, "Register", "mb_register.php?mbp_new=1&code={$this->code}");
					echo "<p>(It's free!)";
					$tbl->FormCellEnd();

					$tbl->FormCellBegin("If you do have a Mudbag login on this site, press the button at right to login.");
					if ($this->code == "preview")
						$this->Button(null, "Login", null, null, "alert('Preview only.'); return false;");
					else
						$this->Button(null, "Login", "mb_login.php?code={$this->code}");
					$tbl->FormCellEnd();

					$tbl->End();

					if ($this->code == "preview")
						echo "<p><b>This page is only a preview. The <i>Register</i> and <i>Login</i> buttons don't actually work.</b>";
				}
				else {
					echo <<<EOT
						<p>If you got to this page by clicking a link in
						an email, please make sure you've copied the entire URL correctly, including the entire code number that
						appears at the end of the URL.
						<p>
						The problem may be that you've already responded to the email. If so, click the link below to login.
						<p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mb_login.php">Login</a>
EOT;
				}
			}
		}

	}

	$frm = new MB_MngUsersRespond();
	DestroySession();
	if (isset($force))
		$frm->force = true;
	$frm->code = nvl($_GET['code'], -1);
	$frm->valid = (isset($frm->code) && token_valid($frm->code, $frm->role_id, $frm->login, $frm->token_id)) || isset($force);
	if ($frm->role_id == ROLE_OWNER) {
		$hdg = "Choose New Password";
		$hlpctx = "helpctx_mb_respond.choose";
	}
	else {
		$hdg = "Respond to an Invitation";
		$hlpctx = "helpctx_mb_respond.invite";
	}
	$frm->Go(null, $hdg, $hlpctx, false, null, false);
?>
