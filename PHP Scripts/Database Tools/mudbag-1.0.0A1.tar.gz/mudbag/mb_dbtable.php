<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable.php,v 1.1.1.1 2005/07/13 00:22:00 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBTable extends MB_DBScreen {

		var $edit;
		var $showing_view = false;
		var $start_row;
		var $rows_per_page;

		function MB_DBTable() {
			$this->MB_DBScreen();
		}

		function ShowForm() {
			$tbl = new MB_Table();
			$_SESSION['active_fd'] = get_field_dict($this->active_table);
			if ($this->edit) {
				$this->SetPageHelpCtx("helpctx_mb_dbtable~edit");
				echo '<h1>some words on the page would be nice here</h1>';
				if (isset($_GET['deleteok']))
					$this->MessageConfirmation("Field  \"{$_GET['field_processed']}\" has been deleted.");
				else if (isset($_GET['saveok']))
					$this->MessageConfirmation("Changes to field \"{$_GET['field_processed']}\" have been saved.");
				else if (isset($_GET['reorderok']))
					$this->MessageConfirmation("Reorder of fields was successful.");
				echo '<p>';
				if (empty($_SESSION['active_fd'])) {
						echo "<p>Table is empty &mdash; no fields have been added.
						  Press the <i>Add Field</i> button above to add some fields.";
				}
				else {
					$tbl->Begin();
					$tbl->ColHdg('');
					$tbl->ColHdg('Field Name');
					$tbl->ColHdg('Type');
					$tbl->ColHdg('Req');
					$tbl->ColHdg('Cols');
					$tbl->ColHdg('Rows');
					$tbl->ColHdg('Choices');
					$tbl->Body();
					foreach ($_SESSION['active_fd'] as $fd) {
						echo '<tr>';
						echo '<td valign="top">';
						button_bar_medium(array('Change', 'mb_dbfield.php?chg=1&field=' . $fd->name), false);
						echo '</td>';
						echo '<td valign="top">' . $fd->name . '</td>';
						echo '<td valign="top">' . $fd->word_for_type() . '</td>';
						echo '<td valign="top">' . ($fd->req ? 'Y' : 'N') . '</td>';
						if ($fd->type == 'm') {
							echo '<td valign="top">' . $fd->cols . '</td>';
							echo '<td valign="top">' . $fd->rows . '</td>';
						}
						else if ($fd->type == 't') {
							echo '<td valign="top">' . $fd->cols . '</td>';
							echo '<td valign="top">&nbsp;</td>';
						}
						else
							echo '<td valign="top">&nbsp;</td><td valign="top">&nbsp;</td>';
						$ch = $fd->choices_to_str();
						echo '<td valign="top">' . (strlen($ch) > 0 ? $ch : '&nbsp;') . '</td>';
					}
					echo '</tr>';
					$tbl->End();
				}
				if ($this->IsAdmin(true))
					$this->dbmain->db_query_user_show("", "show full columns from " . $this->dbapp->internal_name($this->active_table));
			}
			else { // we always have a view
				$this->SetPageHelpCtx("helpctx_mb_dbtable~view");
				if (isset($_SESSION['active_view_obj'])) {
					$flds = &$_SESSION['active_view_obj']->field_dict;
					if ($this->showing_view)
						$view_spec = "&view={$_SESSION['active_view_obj']->view_id}";
					else
						$view_spec = "";
					if (isset($_GET['deleteok']))
						$this->MessageConfirmation("Record has been deleted.");
					else if (isset($_GET['saveok'])) {
						$this->MessageConfirmation("Edits to record have been saved.");
						if ($this->showing_view)
							$this->MessageConfirmation("Added or edited record may not show in this view.");
					}
					$_SESSION['active_query'] = $_SESSION['active_view_obj']->build_select($this->start_row - 1, $this->rows_per_page);
					if ($_SESSION['active_query'])
						$result = $this->dbmain->db_query_user($_SESSION['active_query']);
					else {
						$this->MessageConfirmation(($this->showing_view ? "View" : "Table") . " is empty &mdash; it has no fields.");
						return;
					}
					$rows_fr = mysql_fetch_row($this->dbmain->db_query_user("select found_rows()"));
					$total_rows = $rows_fr[0];
					$nrows = mysql_num_rows($result);
					$last_row = $this->start_row + $nrows  - 1;
					if ($this->start_row > 1) {
						$this->Button(null, "<<", "mb_dbtable.php?start=1$view_spec");
						echo "&nbsp;";
						$this->Button(null, "<", "mb_dbtable.php?start=" . max(1, $this->start_row - $this->rows_per_page) . $view_spec);
						if ($nrows == 0)
							echo "<span class='xsmall'>&nbsp;&nbsp;(End)</span>";
					}
					if ($nrows > 0) {
						echo "<span class='xsmall'>&nbsp;&nbsp;Rows $this->start_row to $last_row (of $total_rows)&nbsp;&nbsp;</span>";
						if ($last_row < $total_rows) {
							$this->Button(null, ">", "mb_dbtable.php?start=" . ($last_row + 1) . $view_spec);
							echo "&nbsp;";
							$this->Button(null, ">>", "mb_dbtable.php?start=" . max(1, $total_rows - $this->rows_per_page + 1) . $view_spec);
						}
//						Displaying total rows -- don't really need what follows.
//						else
//							if ($this->start_row == 1)
//								echo "<span class='xsmall'>&nbsp;&nbsp;(All rows)</span>";
//							else
//								echo "<span class='xsmall'>&nbsp;&nbsp;(End)</span>";
					}
					echo "<p>";
					if ($nrows < 1) {
						if ($this->start_row > 1)
							$this->MessageConfirmation("No rows remain.");
						else {
							if ($this->showing_view)
								$this->MessageError("View retrieved no records.");
							else if ($_SESSION['APPDB']->is_readonly())
								$this->MessageConfirmation("Table is empty.");
							else
								$this->MessageConfirmation("Table is empty. Press <i>Add Record</i> to add a record.");
						}
					}
					else {
						$tbl->Begin();
						$tbl->ColHdg('&nbsp;');
						$n = mysql_num_fields($result);
						$rowid_field = -1;
						for ($i = 0; $i < $n; $i++) {
							$meta = mysql_fetch_field($result, $i);
							if ($meta->name == '_rowID') {
								$rowid_field = $i;
								continue;
							}
							$tbl->ColHdg($meta->name);
						}
						$tbl->Body();
						if ($rowid_field < 0 && !isset($this->showing_view))
							die("No _rowID column &mdash; possibly old table.");

						if ($_SESSION['APPDB']->is_readonly())
							$act = 'Details';
						else
							$act = 'Edit';
						$aname = array();
						for ($rownum = 0; $row = mysql_fetch_row($result); $rownum++) {
							echo '<tr>';
							echo '<td valign="top">';
							button_bar_medium(array($act, "mb_dbtable_row.php?start=$this->start_row&edit=1&rowid=" . $row[$rowid_field] . '&rownum=' . $rownum), false);
							echo '</td>';
							$n = mysql_num_fields($result);
							for ($i = 0; $i < $n; $i++) {
								if ($rownum == 0) {
									$meta = mysql_fetch_field($result, $i);
									$aname[$i] = $meta->name;
								}
								$fld = &$flds[$aname[$i]];
								if ($i == $rowid_field)
									continue;
								$val = $row[$i];
								if ($val == null)
									echo "<td valign='top'>&nbsp;</td>";
								else {
									$align = '';
									switch ($fld->type) {
									case 'y':
										$align = " align='center' ";
										break;
									case 'n':
										$align = " align='right' ";
									}
									$val = $fld->format_for_display($val);
									$val = htmlspecialchars($val);
									// tabs and spaces at start of a line get replaced by &nbsp; chars
									// m = multiline; s = dot matches all chars
									while (preg_match("/(?m)(?s)(.*^[\t]*) (.*$)/", $val, $m))
										$val = $m[1] . "\t" . $m[2];
									$val = str_replace("\t", "&nbsp;", $val);
									echo "<td $align valign='top'>" . nl2br($val) . '</td>';
								}
							}
						}
						$tbl->End();
					}
				}
				else
					$this->MessageError("Can't load view.");
			}
		}
	}

	$frm = new MB_DBTable();
	$frm->SetLevelTable();

	if (isset($table))
		$frm->SetActiveTable($table);

	if (isset($data))
		$frm->edit = false;
	else if (isset($edit))
		$frm->edit = true;
	else
		$frm->edit = $_SESSION['mb_dbtable_edit_mode'];
	$_SESSION['mb_dbtable_edit_mode'] = $frm->edit;
	unset($_SESSION['active_rownum']);
	unset($_SESSION['edit_view']);

	if ($frm->edit)
		$hdg = "Table \"$frm->active_table\" &mdash; Design";
	else {
		// not good to reuse active_view_obj, as fields may be been reordered
		$_SESSION['active_view_obj'] = new View($_SESSION['APPDB']->db_id);
		if (isset($view))
			$_SESSION['active_view_obj']->load_by_id($view);
		else
			$_SESSION['active_view_obj']->make_temp($frm->active_table);

		if (isset($_SESSION['active_view_obj']->name)) {
			$frm->SetActiveTable($_SESSION['active_view_obj']->table);
			$frm->SetActiveView($_SESSION['active_view_obj']->name);
			$hdg = "View \"$frm->active_view\"";
			$frm->showing_view = true;
		}
		else
			$hdg = "Table \"$frm->active_table\" &mdash; Data";
	}

	if ($_SESSION['APPDB']->is_owned() && !$frm->showing_view) {
		if ($frm->edit)
			$toolbar = array('Add Field', 'mb_dbfield.php?add=1',
			  'Reorder Fields', 'mb_dbtable_reorder.php', 'Table Data', 'mb_dbtable.php?data=1');
		else
			$toolbar = array('Add Record', 'mb_dbtable_row.php?add=1', 'Table Design', 'mb_dbtable.php?edit=1');
	}
	else { /* not edit (design) case */
		if ($frm->edit)
			echo '<b>ERROR: $edit set for non-owner';
		if ($_SESSION['APPDB']->is_readonly())
			$toolbar = array();
		else
			$toolbar = array('Add Record', 'mb_dbtable_row.php?add=1');
	}

	if (!isset($table))
		$table = $frm->active_table;
if (!isset($table)) echo "<br>table is not set";
	//$frm->SetActiveTable($table); // why was this commented out before?
	$frm->start_row = nvl($start, 1);
	$frm->rows_per_page = $_SESSION['MUDBAG_USER']->params->row_page_max;
	$frm->Go($toolbar, $hdg, "helpctx_mb_dbtable~view", false, null, true, !$frm->edit); // help context doesn't matter here
?>
