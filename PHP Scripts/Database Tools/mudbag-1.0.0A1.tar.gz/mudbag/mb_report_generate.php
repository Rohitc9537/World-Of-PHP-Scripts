<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_report_generate.php,v 1.1.1.1 2005/07/13 00:22:04 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require('mbcl_reportspec.php');
	require('mb_report_util.php');
	define('FPDF_FONTPATH','fpdf/font/');
	require_once('fpdf/pdf_label/PDF_Label.php');

	define('FMT_MGN_TOP', .75);
	define('FMT_MGN_BOTTOM', .75);
	define('FMT_MGN_LEFT', .75);
	define('FMT_MGN_RIGHT', .75);
	define('FMT_PAGE_WIDTH', 8.5); // determined by FMT_PAGE_FORMAT
	define('FMT_PAGE_HEIGHT', 11); // determined by FMT_PAGE_FORMAT
	define('FMT_WIDTH_YESNO', .1);
	define('FMT_WIDTH_NUMBER', .5);
	define('FMT_WIDTH_DATETIME', .5);
	define('FMT_MIN_LINE_WIDTH', 1/72/4); // .25 pt.

	new MB_DBScreen(); // just to continue the session & access the DBs -- we have no UI other than the PDF itself
	$dbapp = &$_SESSION['APPDB'];
	if (isset($spec_name))
		$_SESSION['mb_report_spec'] = new MB_ReportBlockSpec(null, $spec_name);
	$spec = &$_SESSION['mb_report_spec'];

	class PDF_Report extends FPDF {

		var $spec;
		var $font_size_header; // not in spec
		var $leading; // not in spec
		var $row_gap_scaled; // from spec, but scaled to $avg_char_width
		var $col_gap_scaled; // from spec, but scaled to $avg_char_width
		var $header_extra_vert_spacing;
		var $printable_width;
		var $printable_height;
		var $rcd_number_on_page;
		var $avg_char_width;
		var $had_hdr = false;

		function PDF_Report(&$spec) {
			$this->spec = &$spec;
			parent::FPDF($this->spec->orientation, 'in', $this->spec->paper_size);
			$this->SetDisplayMode('fullpage');
			$this->font_size_header = $this->spec->font_size;
			$this->header_extra_vert_spacing = ($this->spec->font_size / 3 / 72);
			$this->leading = $this->spec->font_size * 1.1 / 72;
			$this->cMargin = 0; // gets rid of extra space used by cell
			$this->AliasNbPages();
			if ($this->spec->orientation == 'P') {
				$pw = $this->fw; // undocumented
				$ph = $this->fh; // undocumented
			}
			else {
				$ph = $this->fw; // undocumented
				$pw = $this->fh; // undocumented
			}
			$this->printable_width = $pw - FMT_MGN_LEFT - FMT_MGN_RIGHT;
			$this->printable_height = $ph - FMT_MGN_TOP - FMT_MGN_BOTTOM;
			$this->SetFont($this->spec->font_family, '', $this->spec->font_size);
			$this->avg_char_width = $this->GetStringWidth('n');
			$this->row_gap_scaled = $this->spec->row_gap * $this->avg_char_width;
			$this->col_gap_scaled = $this->spec->col_gap * $this->avg_char_width;
			$this->SetMargins(FMT_MGN_LEFT, FMT_MGN_TOP, FMT_MGN_RIGHT);
			$this->SetAutoPageBreak(true, FMT_MGN_BOTTOM);
		}

		function Header() {
			$this->rcd_number_on_page = 0;
			$this->SetFont($this->spec->font_family, 'I', $this->spec->font_size);
			// Calculations are done for a line below the header, but it isn't actually drawn.
			$hdg_leading = $this->leading + ($this->font_size_header == $this->spec->font_size ? .03 : .02); // put line well below text
			$hdg_y = (FMT_MGN_TOP - $hdg_leading) * .67;
			$this->SetXY(FMT_MGN_LEFT, $hdg_y);
			if (empty($this->spec->title))
				$ttl = $this->spec->tableview_name;
			else
				$ttl = trim($this->spec->title);
			if ($ttl == '-')
				$ttl = '';
			$this->had_hdr = !empty($ttl);
			$this->Cell($this->printable_width, $hdg_leading, $ttl, 0, 0, 'L');
			$this->SetXY(FMT_MGN_LEFT, $hdg_y);
			if ($this->spec->hdr_date) {
				$this->Cell($this->printable_width, $hdg_leading, date('d-M-Y g:i:s A'), 0, 0, 'C');
				$this->had_hdr = true;
			}
			$this->SetXY(FMT_MGN_LEFT, $hdg_y);
			if ($this->spec->hdr_pgnums) {
				$this->Cell($this->printable_width, $hdg_leading, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'R'); // 'B' for a line
				$this->had_hdr = true;
			}
			$this->SetFont($this->spec->font_family, '', $this->spec->font_size);
			$this->SetLineWidth(FMT_MIN_LINE_WIDTH);
			if ($this->spec->show_lines) {
				$this->SetDrawColor(0x93, 0xff, 0xff);
				$this->Rect(FMT_MGN_LEFT, FMT_MGN_TOP, $this->printable_width, $this->printable_height);
				$this->SetDrawColor(0);
			}
			$this->SetXY(FMT_MGN_LEFT, FMT_MGN_TOP);
		}

		function Footer() {
		}

		function RowRule($space_before = true, $always = false) {
			if ($this->spec->row_rules || $always) {
				$yline = $this->GetY() + ($space_before ? $this->row_gap_scaled / 2 : 0);
				//if ($yline <= FMT_MGN_TOP + $this->printable_height) {
					$this->SetLineWidth(FMT_MIN_LINE_WIDTH);
					$this->Line(FMT_MGN_LEFT, $yline, FMT_MGN_LEFT + $this->printable_width, $yline);
				//}
			}
		}
	}

	class PDF_RecordReport extends PDF_Report {

		var $width_left;

		function PDF_RecordReport(&$spec) {
			parent::PDF_Report($spec);
			unset($this->width_left);
			$this->AddPage();
		}

		function Header() {
			parent::Header();
			if ($this->had_hdr)
				$this->Line(FMT_MGN_LEFT, FMT_MGN_TOP, FMT_MGN_LEFT + $this->printable_width, FMT_MGN_TOP);
			$this->SetXY(FMT_MGN_LEFT, FMT_MGN_TOP/* + $this->row_gap_scaled / 2*/);
		}

		function Footer() {
			parent::Footer();
			if ($this->spec->col_rules) {
				if (!empty($this->width_left)) {
					$x = FMT_MGN_LEFT + $this->width_left + $this->col_gap_scaled;
					$this->Line($x, FMT_MGN_TOP, $x, $this->GetY());
				}
				$this->Line(FMT_MGN_LEFT, FMT_MGN_TOP, FMT_MGN_LEFT, $this->GetY());
				$x = FMT_MGN_LEFT + $this->printable_width;
				$this->Line($x, FMT_MGN_TOP, $x, $this->GetY());
			}
		}

		function WriteRecord($s) {
			$this->rcd_number_on_page++;
			$this->AnalyzeTemplate($s);
			$ystart = $this->GetY();
			$had_tab = false;
			$xoffset = $this->col_gap_scaled / 2;
			foreach (explode("\n", $s) as $r) {
				$this->SetX(FMT_MGN_LEFT + $xoffset);
				if ($tab = strpos($r, "\t")) {
					$had_tab = true;
					$this->SetFont($this->spec->font_family, 'B', $this->spec->font_size);
					$yleft_pre = $this->GetY();
					$this->MultiCell($this->width_left, $this->leading, substr($r, 0, $tab), 0, 'R');
					$yleft_post = $this->GetY();
					$this->SetY($yleft_pre);
					$this->SetFont($this->spec->font_family, '', $this->spec->font_size);
					$r = substr($r, $tab + 1);
				}
				else
					$yleft_post = $ystart;
				if ($had_tab) {
					$w = $xoffset + $this->width_left + $this->col_gap_scaled;
					$width_right = $this->printable_width - $w;
					$this->SetX(FMT_MGN_LEFT + $w);
				}
				else
					$width_right = $this->printable_width;
				$this->MultiCell($width_right, $this->leading, $r, 0, 'L');
				$this->SetY(max($this->GetY(), $yleft_post));
			}
			return $this->GetY() - $ystart;
		}

		// Analysis to determine $width_left occurs only once, even if left content is data dependent.
		function AnalyzeTemplate($t) {
			if (isset($this->width_left))
				return;
			$this->width_left = 0;
			$this->SetFont($this->spec->font_family, 'B', $this->spec->font_size);
			foreach (explode("\n", $t) as $r)
				if ($tab = strpos($r, "\t"))
					$this->width_left = max($this->width_left, $this->GetStringWidth(substr($r, 0, $tab)));
			$this->SetFont($this->spec->font_family, '', $this->spec->font_size);
			if ($this->width_left > 0)
				$this->width_left += .005; // fudge -- roundoff error or something causes MultiCell to wrap otherwise
		}
	}

	class PDF_TabularReport extends PDF_Report {

//		var $headings;
//		var $heading;
//		var $data_template;
//		var $field_dict;
//		var $widths;
//		var $fields;

		function PDF_TabularReport(&$spec) {
//			$this->headings = $headings;
//			$this->data_template = $data_template;
//			$this->field_dict = &$field_dict;
			parent::PDF_Report($spec);
//			$this->SetColumns();
			$this->AddPage();
//dump($this->spec);exit;
//$this->SetFont("Times", '', 20);
//$this->Text(100, 100, "hello");
//$pdf->Output();exit;
		}

		function WriteRecord(&$row) {
			if (!isset($this->spec->field_dict))
				$this->spec->field_dict = get_field_dict($this->spec->tableview_name);
			$flds = $this->spec->field_dict;
			if (!isset($this->spec))
				exit('PDF_TabularReport:WriteRecord $this->spec not set');
			if (!isset($this->spec->field_dict))
				exit('PDF_TabularReport:WriteRecord $this->spec->field_dict not set');
			$this->rcd_number_on_page++;
			$ystart = $this->GetY();
			$ncols = count($this->spec->fields);
			$x = FMT_MGN_LEFT + $this->col_gap_scaled / 2;
			$ymax = $ystart = $this->GetY();
			for ($i = 0; $i < $ncols; $i++) {
				$this->SetXY($x, $ystart);
				$sf = &$this->spec->fields[$i];
				$w = $sf->width * $this->avg_char_width;
				$name = $sf->name;
//echo "<br>$name";
				$v = $flds[$name]->format_for_display(&$row[$name], $sf->width);
				if (isset($v) && $w > .005) {
					$this->MultiCell($w, $this->leading, $v, 0, $sf->alignment);
					$ymax = max($ymax, $this->GetY());
				}
				if ($w > .005)
					$x += $w + $this->col_gap_scaled;
			}
			//$this->Ln();
			$this->SetY($ymax);
			return $ymax - $ystart;
		}

		function Header() {
			parent::Header();
//$f = ''; foreach ($this->field_dict as $fld) $f .= "[$fld->name,$fld->type,$fld->cols]";
//$f = ''; for ($i = 0; $i < count($this->fields); $i++) $f .= "[{$this->fields[$i]}:{$this->widths[$i]}]";
//			$this->SetX(FMT_MGN_LEFT);
//			$this->Cell($this->printable_width, $this->leading, $f, 'B');
//			$this->Ln();
			if ($this->spec->row_rules) {
				$this->Line(FMT_MGN_LEFT, FMT_MGN_TOP, FMT_MGN_LEFT + $this->printable_width, FMT_MGN_TOP);
				$this->SetY($this->GetY() + $this->header_extra_vert_spacing);
			}
			$this->SetFont($this->spec->font_family, 'B', $this->spec->font_size);
			$ncols = count($this->spec->fields);
			$x = FMT_MGN_LEFT + $this->col_gap_scaled / 2;
			for ($i = 0; $i < $ncols; $i++) {
				$this->SetX($x);
				$w = $this->spec->fields[$i]->width * $this->avg_char_width;
				if ($w > .005) {
					$this->Cell($w, $this->leading, nvl($this->spec->fields[$i]->heading, ''), 0, 0, 'C');
					$x += $w + $this->col_gap_scaled;
				}
			}
			$this->Ln();
			$this->SetY($this->GetY() + $this->header_extra_vert_spacing);
			$this->RowRule(false, true);
			$this->SetY($this->GetY() + $this->header_extra_vert_spacing);
			$this->SetFont($this->spec->font_family, '', $this->spec->font_size);
		}

		function Footer() {
			parent::Footer();
			if ($this->spec->col_rules) {
				$ncols = count($this->spec->fields);
				$x = FMT_MGN_LEFT;
				for ($i = 0; $i < $ncols; $i++) {
					$w = $this->spec->fields[$i]->width * $this->avg_char_width;
					if ($w > .005) {
						$this->Line($x, FMT_MGN_TOP, $x, $this->GetY());
						$x += $w + $this->col_gap_scaled;
					}
				}
				$x = FMT_MGN_LEFT + $this->printable_width;
				$this->Line($x, FMT_MGN_TOP, $x, $this->GetY());
			}
		}

//		function SetColumns() {
//			$this->SetFont(FMT_FONT_FAMILY, 'B', FMT_FONT_SIZE);
//			$avg_char_width = $this->GetStringWidth('n');
//			$count = 0;
//			$templ = $this->data_template;
//			while (preg_match('/^([^{]*)\{([^{]+)\}(.*)$/s', $templ, $matches)) {
//				if ($count++ > 200)
//					generate_error("Runaway fields in template.");
//				$fname = $matches[2];
//				if ($fname != 'tab') {
//					$this->fields[] = $fname;
//					$fld = &$this->field_dict[$fname];
//					switch ($fld->type) {
//					case 't':
//					case 'm':
//						$this->widths[] = ($fld->cols == 0 ? 25 : $fld->cols) * $avg_char_width;
//						break;
//					case 'y':
//						$this->widths[] = FMT_WIDTH_YESNO;
//						break;
//					case 'n':
//					case 'f':
//						$this->widths[] = FMT_WIDTH_NUMBER;
//						break;
//					case 'd':
//						$this->widths[] = FMT_WIDTH_DATETIME;
//						break;
//					case 'c':
//						$w = 0;
//						foreach ($fld->choices as $c)
//							$w = max($w, $this->GetStringWidth($c));
//						$this->widths[] = $w;
//						break;
//					default:
//						generate_error("Unknown field type: $fld->type.");
//					}
//				}
//				$templ = $matches[3];
//			}
//			$count = 0;
//			$hdgs = $this->headings;
//			while (preg_match('/^([^{]*)\{([^{]+)\}(.*)$/s', $hdgs, $matches)) {
//				if ($count++ > 200)
//					generate_error("Runaway headings in template.");
//				$fname = $matches[2];
//				if ($fname == 'tab')
//					$this->heading[] = trim($matches[1]);
////echo "<br>$matches[1]";
//				$hdgs = $matches[3];
//			}
//			$this->heading[] = trim($hdgs);
////echo "<br>$hdgs";
//			$ncols = count($this->widths);
//			for ($i = 0; $i < $ncols; $i++)
//				$this->widths[$i] = max($this->widths[$i], $this->GetStringWidth(nvl($this->heading[$i], '')));
//			$this->SetFont(FMT_FONT_FAMILY, '', FMT_FONT_SIZE);
//		}
	}

	if (!($result_data = report_query_tableview($spec, $errmsg))) {
		echo "<p><font color='red'>$errmsg</font>";
		exit;
	}

	$data_template = $spec->template;
//dump($spec);
//echo "<br>$spec->template";exit;
	switch ($spec->type) {
	case 'l':
		$row = @mysql_fetch_assoc($dbapp->dbmain->db_query("select * from " . $dbapp->internal_name_admin("LabelSizes") .
		  " where code = '$spec->label_code'"));
		if (!$row)
			generate_error("Can't find label code \"$spec->label_code\".");

		$font_size = max(6, $spec->font_size);
		$font_size = min(15, $font_size);
		$cvt = ($row['units'] == 'mm' ? 0.0393700787 : 1);
		$label_spec = array('metric'=>'in',
		  'name'=>$row['code'],
		  'paper-size'=>$row['paper_size'],
		  'marginLeft'=>$row['mgn_left'] * $cvt,
		  'marginTop'=>$row['mgn_top'] * $cvt,
		  'NX'=>$row['number_horz'],
		  'NY'=>$row['number_vert'],
		  'SpaceX'=>$row['gutter_horz'] * $cvt,
		  'SpaceY'=>$row['gutter_vert'] * $cvt,
		  'width'=>$row['width'] * $cvt,
		  'height'=>$row['height'] * $cvt,
		  'font-size'=>$font_size);
		$pdf = new PDF_Label($label_spec, 'mm', 1, 1, $spec->show_lines, $spec->one_page);
		$pdf->Set_Font_Name($spec->font_family);
		break;
	case 'm':
//		if (!isset($_GET('email_preview')) {
//			echo <<<EOT
//				<a href="mb_
//EOT;
//		}
//		// fall through
	case 'r':
		$pdf = new PDF_RecordReport($spec);
		$pdf_pretend = new PDF_RecordReport($spec);
		break;
	case 't':
//		$a = explode("\n", $data_template);
//		$data_template = $a[1];
		$pdf = new PDF_TabularReport($spec);
		$pdf_pretend = new PDF_TabularReport($spec);
	}
	//$pdf->Open(); not an exposed FPDF function -- present in PDF_Label examples for some reason

	$nrows = 0;
	set_time_limit($_SESSION['MUDBAG_USER']->params->report_exec_time * 60);
	while ($row = mysql_fetch_assoc($result_data)) {
		$nrows++;
		$templ = report_insert_fields($data_template, $spec->type == 'l', $row); // will be empty if report type is 't'
		if ($spec->type == 'l') {
			if (!$pdf->Add_PDF_Label($templ))
				break;
		}
		else if ($spec->type == 't' || $spec->type == 'r' || $spec->type == 'm') {
			if ($spec->type == 't')
				$data = &$row;
			else
				$data = &$templ;
			$pdf_pretend->SetXY(FMT_MGN_LEFT, FMT_MGN_TOP);
			$height = $pdf_pretend->WriteRecord($data) + $pdf_pretend->row_gap_scaled;
			if ($height + $pdf->GetY() > FMT_MGN_TOP + $pdf->printable_height || ($spec->rec_per_page && $nrows > 1)) {
				if ($spec->one_page)
					break;
				$pdf->AddPage();
			}
			$pdf->SetY($pdf->GetY() + $pdf->row_gap_scaled / 2);
			$pdf->WriteRecord($data);
			$pdf->RowRule();
			$pdf->SetY($pdf->GetY() + $pdf->row_gap_scaled / 2);
		}
//			$pdf_pretend->SetXY(FMT_MGN_LEFT, FMT_MGN_TOP);
//			$height = $pdf_pretend->WriteRecord($templ) + $pdf_pretend->row_gap_scaled;
//			if ($height + $pdf->GetY() > FMT_MGN_TOP + $pdf->printable_height) {
//				if ($spec->one_page)
//					break;
//				$pdf->AddPage();
//			}
//			$pdf->SetY($pdf->GetY() + $pdf->row_gap_scaled / 2);
//			$pdf->WriteRecord($templ);
//			$pdf->RowRule();
//			$pdf->SetY($pdf->GetY() + $pdf->row_gap_scaled / 2);
//			if ($pdf->rcd_number_on_page > 0 && $spec->type == 'r')
//				$pdf->SetY($pdf->GetY() + $pdf->row_gap_scaled);
//			$pdf->WriteRecord($templ);
//			$pdf->RowRule();
//		}
	}
	$pdf->Output();

function generate_error($s) {
	exit("Mudbag error generating PDF: $s");
}

?>
