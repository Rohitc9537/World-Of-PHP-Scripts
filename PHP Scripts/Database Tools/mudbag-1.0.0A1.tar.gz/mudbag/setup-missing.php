<p><b>You must have a 'local/setup.php' file to run Mudbag.</b>
<p>Use the file setup-missing.php as a template.
<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: setup-missing.php,v 1.1.1.1 2005/07/13 00:22:07 rochkind Exp $

	exit;
?>


<?
// The following (without the error message above, of course) is what should be
// in the file 'local/setup.php':
?>

<?php
	define('MB_BETA', true);			// or false, depending on how far Mudbag has come

	// Database access.
	define('MB_HOST', 'localhost');		// usually
	define('MB_USER', 'mudbag');		// replace with the appropriate MySQL user name
	define('MB_PASSWORD', '????');		// ... and the password
	define('MB_DATABASE', 'mudbag_db');	// ... and the DB name

	// Email addresses
	define('MB_EMAIL_SUPPORT', 'support@yoursite.com');		// invitations to share a DB
	define('MB_EMAIL_CONTACT', 'contact_us@yoursite.com');	// contact-us link

	// Miscellaneous
	define('MB_MAIL_SIM', 0); // simulate email (for testing and debugging)
	define('MB_HELP_GOTRACK', 0); // track help contexts in mbcl_base.php (for development only)
?>
