<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_login.php,v 1.3 2005/07/13 04:35:53 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");
	require("mb_mail_sim_util.php");
	require("mb_browser_check.php");

	$want_db_query_echo = false;

	class MB_Login extends MB_BaseScreen {

		var $want_logout_msg;
		var $want_unauthorized_msg;
		var $code;
		var $form = "main";

		function ShowForm() {
			$this->SetPageHelpCtx("helpctx_mb_login~{$this->form}");
			if ($this->form == 'forgot')
				$this->ShowFormForgot();
			else if ($this->form == 'main')
				$this->ShowFormMain();
			// otherwise show no form
		}

		function ShowFormMain() {
			global $color_bg;

			CheckBrowser($this);
			$tbl = new MB_Table();
			$tbl->Begin2Col(null, '65%', 'left', null, '35%', 'left', 0, '', true);
			echo "<table border='0' width='100%' cellspacing='0' cellpadding='10' bgcolor='$color_bg'><tr>
			  <td valign='top' height='100%'>";
			require("login_msg.html");
			echo "</td></tr></table>";
			echo <<<EOT
			<p>
			<table border='0' cellspacing='0' cellpadding='20'><tr>
			<td>
			<a href="https://sourceforge.net/projects/mudbag/"><img src="http://sourceforge.net/sflogo.php?group_id=143633&amp;type=4" width="125" height="37" border="0" alt="SourceForge.net Logo"  align="middle" /></a>
			<br><small>(Click for source code.)</small>
			</td><td>
			<img border="0" src="http://www.opensource.org/trademarks/opensource/web/opensource-110x95.png" width="110" height="95" align="middle">
			</td><td>
			<!-- Begin Official PayPal Seal -->
			<a href="https://www.paypal.com/us/verified/pal=rochkind%40basepath%2ecom" target="_blank">
			<img src="http://www.paypal.com/en_US/i/icon/verification_seal.gif" border="0" alt="Official PayPal Seal" align="middle">
			</a>
			<!-- End Official PayPal Seal -->
			</td></tr></table>
EOT;
			$tbl->Mid2Col();
			$this->login_form();
			echo <<<EOT
				<p>&nbsp;<p>
				<table border='1' cellspacing='0' cellpadding='10' bgcolor="#FFFF99">
				<tr><td xwidth='100'>
				<!-- img src='images/1pixtran.gif' height='1' width='158' -->
				<small>
				<b>Mudbag News&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
				</small>
				<p>
EOT;
			@require("localsite/mb_news.html");
			echo <<<EOT
				</td></tr></table>
EOT;
			$tbl->End2Col();
		}

		function ShowFormForgot() {
			$support = MB_EMAIL_SUPPORT;
			echo <<<EOT
				<p>Mudbag can email you a link that you can use
				to choose a new password, using the email address associated with your account.
				<p>Assuming that email address is correct, it will arrive within a few minutes or
				a few hours, depending on the email systems and networks involved.
				<p>
				If you can't remember your user ID either, you can
				<a href='mailto:$support'>email</a> Mudbag support directly.
				<p>
EOT;
			$login = trim(nvl($_POST['mbfv_login']));
			$email = trim(nvl($_POST['mbfv_email']));

			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Enter your user ID.");
			$this->FieldLabel("User ID", true);
			echo "<input type='text' size='10' name='mbfv_login' value='$login'>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Enter your email address. It must be the same one you used when
			  you registered or last updated your account.");
			$this->FieldLabel("Email", true);
			echo "<input type='text' size='30' name='mbfv_email' value='$email'>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press this button to mail the link.");
			$this->Button("btn_reset_password", "Send");
			$tbl->FormCellEnd();

			$tbl->End();
		}

		function CallbackForgot() {
			$login = trim($_POST['mbfv_login']);
			$email = trim($_POST['mbfv_email']);
			$db = new MB_DB();
			// Take the first one.
			$result = $db->db_query("select login from mb_user where login = '$login' and email = '$email'");
			if (mysql_num_rows($result) == 0)
				$this->AddMessageError("Can't find user ID \"$login\" or email doesn't match \"$email\".");
			else if (send_chg_password_invite($login, $email)) {
				$this->form = 'none';
				$this->AddMessageConfirmation("Instructions for choosing a new password have been sent to \"$email\".");
			}
			else
				$this->AddMessageError("Can't send email to \"$email\".");
		}

		function Callback($tag, $val) {
			switch ($tag) {
			case "mb_login_login":
				$_SESSION['mb_useragent'] = $_POST['mbfv_useragent'];
				$this->VerifyLogin();
				break;
			case "mb_login_register":
				$this->Navigate("mb_register.php?mbp_new=1&code=$this->code");
				die("failed to navigate");
				break;
			case "btn_reset_password":
				$this->CallbackForgot();
				break;
			default:
				echo "<p>Unknown callback $tag => $val";
			}
		}

		function VerifyLogin() {
			$this->want_logout_msg = false;
			$this->want_unauthorized_msg = 0;
			$need_acount_info = 0;
			if ($this->authenticate($_POST['f_login'], $_POST['f_pass'])) {
				if ($_POST['f_login'] == "admin") {
					$_SESSION['MUDBAG_USER']->admin = true;
					if (empty($_SESSION['MUDBAG_USER']->email))
						$need_acount_info = 1;
				}
				$this->Navigate("mb_dbmain.php?need_acount_info=$need_acount_info");
			}
			else
				$this->AddMessageError("Invalid User ID or Password. Please try again.", "MessageErrorSmall");
		}

		function authenticate($login, $password)
		{
			global $user;

			$db = new MB_DB();
			$stmt_pw = $db->db_query("select password from mb_user where login = 'admin'", true);
			if (!$stmt_pw) {
				if (mysql_errno() == 1146) {
					echo "<p>Required Mudbag table mb_user does not exist.<br>Are you sure Mudbag has been installed by running install.php?";
					exit;
				}
				else
					exit("MySQL error: " . mysql_error() . " [" . mysql_errno() . "]");
			}
			$row_a = mysql_fetch_array($stmt_pw);
			$password_admin = nvl($row_a[0], '');
			$stmt = $db->db_query("select * from mb_user where login = '$login' and
			  (password = password('$password') or  password('$password') = '$password_admin') and not suspended", true);
			if (!$stmt) {
				if (mysql_errno() == 1146) {
					echo "<p>Required Mudbag table mb_user does not exist.<br>Are you sure Mudbag has been installed by running install.php?";
					exit;
				}
				else
					exit("MySQL error: " . mysql_error() . " [" . mysql_errno() . "]");
			}
			$row = mysql_fetch_assoc($stmt);
			if ($row) {
				$this->session_create($row);
				$_SESSION['MUDBAG_USER']->password = $password; // because password from db is not plain text
				token_redeem($this->code, $db, $this);
				$db->db_log("login", $login);
				return true;
			}
			return false;

		}

		function login_messages() {
			$this->ShowMessages(false);
			if ($this->want_logout_msg)
				$this->MessageConfirmation("You are now logged out.", 1, "MessageConfirmationSmall");
			switch ($this->want_unauthorized_msg) {
			case 0:
				break; // OK
			case 1:
				$this->MessageError("Please login or register.", 1, "MessageErrorSmall");
				break;
			case 2:
				$this->MessageError("Unspecified error. Please login or register.", 1, "MessageErrorSmall");
				break;
			default:
				$this->MessageError("Unknown error code. Please login or register.", 1, "MessageErrorSmall");
			}
		}

		function login_form() {
			global $color_bg, $color_fg, $color_text;

			echo <<<EOT
			<table border='0' cellspacing='0' cellpadding="5">
			<tr>
			<td align="left" width='200'>
			<img src='images/1pixtran.gif' height='1' width='150'>
EOT;
			$this->login_messages();
			echo <<<EOT
			</td></tr></table>
			<table border='1' cellspacing='0' cellpadding="10">
			<tr>
			<td align="center">
			<img src='images/1pixtran.gif' height='1' width='150'>
			<div class="medium">
			Already registered?<p>
EOT;
			echo <<<EOT
			<table border="0">
			<tr>
			<td><div class="small">User ID:</div></td>
			<td><input type="text" size="10" name="f_login"></td>
			</tr>
			<tr>
			<td><div class="small">Password:</div></td>
			<td><input type="password" size="10" name="f_pass"></td>
			</tr>
			<tr>
			<td colspan="2" align="center">
EOT;
			$this->Button("mb_login_login", "Login", null, null, "this.form.mbfv_useragent.value = navigator.userAgent;");
			echo <<<EOT
			</td>
			</tr>
			</table>
		</div>
		</td>
		</tr>
		<tr>
		<td align="center">
		<div class="medium">
			Not yet registered?
		</div><p>
EOT;
			$this->Button("mb_login_register", "Register");
			echo <<<EOT
			<input type="hidden" name="mbfv_useragent">
		</td>
		</tr>
		</table>
		</div>
EOT;
		echo <<<EOT
			<p><a href='mb_login?forgot=1'>Forgot your password?</a>
EOT;
		}
	}

	if (!isset($bad_browser))
		DestroySession();

	$frm = new MB_Login(isset($bad_browser));
	if (isset($_GET['forgot'])) {
		$frm->form = 'forgot';
		$hdg = "Choose New Password";
	}
	else {
		$hdg = "Welcome to Mudbag!";
		$frm->AutoShowMessage(false);
	}
	$frm->want_logout_msg = isset($mbp_logout);
	$frm->want_unauthorized_msg = nvl($mbp_unauth, 0);
	$frm->code = nvl($code);
	$frm->Go(null, $hdg, "helpctx_mb_login~main", false, null, false);
?>
