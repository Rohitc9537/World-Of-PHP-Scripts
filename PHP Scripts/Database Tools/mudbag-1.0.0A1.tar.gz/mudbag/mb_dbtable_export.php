<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_dbtable_export.php,v 1.1.1.1 2005/07/13 00:22:00 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	$want_db_query_echo = false;

	class MB_DBTableExport extends MB_DBScreen {

		var $tableview_name;
		var $is_table;
		var $export_ok = false;
		var $fname;

		function MB_DBTableExport() {
			parent::MB_DBScreen();
		}

		function Callback($tag) {
			if (isset($_POST['mbfv_tableview']) && $_POST['mbfv_tableview']{0} != 'x') {
				$this->is_table = $_POST['mbfv_tableview']{0} == 't';
				$this->tableview_name = substr($_POST['mbfv_tableview'], 2);
			}
			else
				unset($this->tableview_name);
			switch ($tag) {
			case "btn_TableSelected":
				break;
			case "btn_Export":
				if (!isset($this->tableview_name)) {
					$this->AddMessageError("Choose a table or view.");
					return;
				}
				$this->export();
				break;
			default:
				parent::Callback($tag);
			}
		}

		function export() {
			if (!is_writable(MB_EXPORT_DIR)) {
				$this->AddMessageError("Subdirectory \"" . MB_EXPORT_DIR . "\" must be writable for Export to work.");
				return;
			}
			if (!($result = $this->query_tableview($errmsg))) {
				$this->AddMessageError($errmsg);
				return;
			}
			if (mysql_num_rows($result) == 0) {
				$this->AddMessageInfo("Table or view has no records.");
				return;
			}
			//$fname = tempnam(MB_EXPORT_DIR, $_SESSION['APPDB']->tblpfx . $this->tableview_name . "_");{$_SESSION['MUDBAG_USER']->user_id}
			$this->fname = MB_EXPORT_DIR . "/{$this->tableview_name}_{$_SESSION['MUDBAG_USER']->user_id}.csv";
			if (!($out = @fopen($this->fname, "w"))) {
				$this->AddMessageError("Can't open temporary file \"$this->fname\".");
				return;
			}
			for ($row_count = 0; $row = mysql_fetch_assoc($result); $row_count++) {
				if ($row_count == 0) {
					$first_field = true;
					foreach($row as $k => $v) {
						if ($k{0} == '_')
							continue;
						if (!$first_field)
							fputs($out, ",");
						$first_field = false;
						fputs($out, "$k");
					}
					fputs($out, "\n");
				}
				$first_field = true;
				foreach($row as $k => $v) {
					if ($k{0} == '_')
						continue;
					if (!$first_field)
						fputs($out, ",");
					$first_field = false;
					if (strpos($v, ",") !== false || strpos($v, "\n") !== false)
						$v = '"' . str_replace('"', '""', $v) . '"';
					fputs($out, "$v");
				}
				fputs($out, "\n");
			}
			fclose($out);
			$this->AddMessageConfirmation("Successful export of $row_count record(s).");
			$this->export_ok = true;
		}


		function query_tableview(&$errmsg) {

			$result_data = $_SESSION['APPDB']->query_tableview($this->is_table, $this->tableview_name, $field_dict, $err, true);

			if (!$result_data) {

				if (mysql_errno() == 1146 || (mysql_errno() == 0 && $err == 1146))

					$errmsg = "This export is based on " . ($spec->is_table ? "table" : "view") . " $spec->tableview_name,

					  which no longer exists.";

				else

					$errmsg = "Database error: " . mysql_error() . " [" . mysql_errno() . "]";

				return null;

			}

			return $result_data;

		}


		function ShowForm() {
			echo <<<EOT
				<script language="JavaScript">

					function tableview_selected(obj) {
						var x = document.getElementById('mbfv_tableview_changed_id');
						if (x != null)
							x.value = true;
						obj.form.submit();
					}

				</script>
EOT;
			echo "<input type='hidden' name='mbfv_button[btn_TableSelected]' id='mbfv_tableview_changed_id'>"; // used to indicate that tableview changed
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Choose the table or view to export.");
			$this->FieldLabel("Table or View", true);
			$this->dbapp->ShowTableViewSelect("mbfv_tableview", ($this->is_table ? "t-" : "v-") . nvl($this->tableview_name),
			  true, "Choose Table or View", "tableview_selected(this)");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press the <i>Export</i> button to export the data. You'll then be able to download the data file.");
			$this->Button("btn_Export", "Export");
			$this->ButtonSpaced(null, "Back to Database", "mb_dbmain.php");
			$tbl->FormCellEnd();

			if ($this->export_ok && isset($this->fname)) {
				$tbl->FormCellBegin("To download the export file, right-click on the link at right and choose
				  \"Save Link As,\" \"Save Target As,\" \"Download Linked File,\" or something similar.");
				echo "<a href='$this->fname'>Right-Click Here</a>";
				$tbl->FormCellEnd();
			}

			$tbl->End();
		}
	}

	$frm = new MB_DBTableExport();
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right
	$frm->Go(null, "Export Table or View", "helpctx_mb_dbtable_export");
?>
