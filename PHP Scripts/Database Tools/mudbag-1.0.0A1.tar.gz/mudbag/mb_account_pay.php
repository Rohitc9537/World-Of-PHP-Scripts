<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_account_pay.php,v 1.2 2005/07/13 01:46:45 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');

	new MB_BaseScreen(); // to get session

//dump($_POST);

	$db = new MB_DB();

//echo getcwd();

//chdir("../mudbag-pay");

//echo "<br>" . getcwd();

//plan_extend($db, 6, 'MB001', 'M');

//exit;



	$sku_new = $_GET['sku'];
	$row_plan = get_plan($sku_new, $db);
	if ($_GET['period'] == 'month') {
		$rate = $row_plan['rate_month'];
		$period = 'M';

		$invoice = "$sku_new (1 Month)";
	}
	else {
		$rate = $row_plan['rate_year'];
		$period = 'Y';
		$invoice = "$sku_new (1 Year)";
	}

	$rate = round($rate, 2);

	$plan_name = "Mudbag {$row_plan['name']}";

	create_account($db);

	echo <<<EOT

		<html>

		<head>

		<title>PayPal Payment</title>

		</head>

		<body>

		<img src='images/mudbag.gif'>
EOT;
	if (MB_BETA)
		echo <<<EOT
		<p>If this were not the beta release, you could click a button on this page to go to PayPal where
		you'd have a chance to review the transaction details before authorizing payment.
		<p>But you can't make a payment or extend your plan, so close this window and return to the Mudbag window.
EOT;
	else {
		echo <<<EOT
		<p>Click the button below to go to PayPal where
		you'll have a chance to review the transaction details before authorizing payment.
		<p>After you've made the payment, close this window and return to the Mudbag window.
EOT;
	echo <<<EOT
		<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

		<!-- form action="mb_account_pay.php" method="post" -->

		<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/x-click-butcc-subscribe.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">

		<input type="hidden" name="cmd" value="_xclick-subscriptions">

		<input type="hidden" name="business" value="business@where.com">

		<input type="hidden" name="item_name" value="$plan_name">

		<input type="hidden" name="no_shipping" value="1">

		<input type="hidden" name="no_note" value="1">

		<input type="hidden" name="currency_code" value="USD">

		<input type="hidden" name="lc" value="US">

		<input type="hidden" name="a3" value="$rate">

		<input type="hidden" name="p3" value="1">

		<input type="hidden" name="t3" value="$period">

		<input type="hidden" name="src" value="1">

		<input type="hidden" name="sra" value="1">

		<input type="hidden" name="custom" value="{$_SESSION['MUDBAG_USER']->account_id}"> <!-- NOT visible to user -->

		<input type="hidden" name="invoice" value="$invoice"> <!-- visible to user -->

		<input type="hidden" name="item_number" value="$sku_new"> <!-- visible to user -->

		<input type="hidden" name="return" value="http://64.81.102.157/mudbag-pay/paypal-return.php?mudbag=1"> <!-- visible to user -->

		</form>
		</body>

		</html>

EOT;
	}

//	echo "<hr>Sandbox";
//	echo "<br>new sku = $sku_new; acount_id = {$_SESSION['MUDBAG_USER']->account_id}; rate = $rate; period = $period";



function create_account($db) {

	$u = &$_SESSION['MUDBAG_USER'];
	if ($u->account_id == ACCOUNT_ID_FREE) {

		$db->db_query("begin");
		$u->account_id = $db->db_query("insert into mb_account(sku) values('FREE')");

		//$db->db_query("insert into mb_plan_segment(account_id, sku) values($u->account_id, 'FREE')");

		$db->db_query("update mb_user set account_id = {$u->account_id}

		  where user_id = {$u->user_id}");

		$db->db_query("commit");
	}
}
?>
