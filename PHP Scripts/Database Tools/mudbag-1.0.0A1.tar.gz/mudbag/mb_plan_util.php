<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_plan_util.php,v 1.1.1.1 2005/07/13 00:22:03 rochkind Exp $

define('ACCOUNT_ID_FREE', 1);

function get_plan($sku, $db = null) {
	if (isset($_SESSION['APPDB']))
		$dbapp = &$_SESSION['APPDB'];
	else
		$dbapp = new MB_AppDB();
	if (!isset($db))
		$db = $dbapp->dbmain;
	$sql = "select * from " . $dbapp->internal_name_admin("Plans") . " where sku = '$sku'";
	$result = $db->db_query($sql);
	if (!$result)
		logit("in get_plan($sku, $db) -- query failed -- " . mysql_error());
	$row = mysql_fetch_assoc($result);
	if (!$row)
		logit("in get_plan($sku, $db) -- mysql_fetch_assoc failed -- " . mysql_error());
	return $row;
}

function get_current_plan($account_id = null, $db = null) {
	if (isset($_SESSION['APPDB']))
		$dbapp = &$_SESSION['APPDB'];
	else
		$dbapp = new MB_AppDB();
	if (!isset($db))
		$db = $dbapp->dbmain;
	$today = date('Y-m-d');
	if (!isset($account_id))
		$account_id = $_SESSION['MUDBAG_USER']->account_id;
	$row = mysql_fetch_assoc($db->db_query(
	  "select * from mb_account a
	    join " . $dbapp->internal_name_admin("Plans") . " using(sku)
	    where account_id = {$account_id}
	  "));
	return $row;
}

function get_plan_days_left(&$row_new, &$row_current, &$days_left, &$days_left_equiv) {
	if (isset($row_current['expire']))
		$days_left = ceil((strtotime($row_current['expire']) - time()) / (24 * 3600));
	else
		$days_left = 0;
	if ($row_current['sku'] == $row_new['sku'])
		$days_left_equiv = $days_left;
	else if ($days_left > 0 && $row_new['sku'] != 'FREE')
		$days_left_equiv = ceil($days_left * ($row_current['rate_month'] / $row_new['rate_month']));
	else
		$days_left_equiv = 0;
}

function plan_extend($db, $account_id, $sku, $period) {
	if ($sku == 'FREE' || $sku == 'ADMIN')
		return; // no need to extend FREE, and can't downgrade to FREE
	$today = date('Y-m-d');
	logit("plan_extend($db, $account_id, $sku, $period)");
	$row_new = get_plan($sku, $db) or logit("Can't get row_new");
	$row_current = get_current_plan($account_id, $db) or logit("Can't get row_current");
	get_plan_days_left($row_new, $row_current, $days_left, $days_left_equiv);
	$interval = ($period == 'M' ? 'month' : 'year');
	$sql = "update mb_account set sku = '$sku', expire = date_add(date_add('$today', interval $days_left_equiv day), interval 1 $interval)
	  where account_id = $account_id";
	logit($sql);
	$db->db_query($sql);
}

function logit($s) {
	static $out, $dt;

	$logfile = "logdir/mb-pay.log";
	if (!isset($out))
		$out = fopen($logfile, "a");// or die("Can't open $logfile");
	if (!isset($dt))
		$dt = date("r");
	fputs($out, "$dt: $s\n");
}

function check_limits(&$msg, $db_incr = 0, $tbl_incr = 0, $data_incr = 0, $row = null) {
	if (!isset($row))
		$row = get_current_plan();
	$_SESSION['APPDB']->get_stats($num_dbs, $num_tbls, $total_data);
	$total_data_kb = round($total_data / 1024, 1);

	$prediction = $db_incr > 0 || $tbl_incr > 0 || $data_incr > 0;
	if ($prediction)
		$would_be = " (or would be)";
	else
		$would_be = "";
	$msg = '';
	if ($num_dbs + $db_incr > $row['limit_databases'])
		$msg .= "<br>&nbsp;&nbsp;&nbsp;&nbsp;Limit of {$row['limit_databases']} databases (you have $num_dbs).";
	if ($num_tbls + $tbl_incr > $row['limit_tables'])
		$msg .= "<br>&nbsp;&nbsp;&nbsp;&nbsp;Limit of {$row['limit_tables']} tables (you have $num_tbls).";
	if ($total_data_kb + ($data_incr / 1024) > $row['limit_data'])
		$msg .= "<br>&nbsp;&nbsp;&nbsp;&nbsp;Limit of {$row['limit_data']} kb of data (you have $total_data_kb).";
	if (!empty($msg)) {
		$msg = "You are$would_be over your limits:" . $msg .
		  "<p>Delete databases, tables, or records, or press the <i>Account</i> button at the top to raise your limits.";
		$_SESSION['MUDBAG_USER']->limits_exceeded = !$prediction;
		return false;
	}
	$_SESSION['MUDBAG_USER']->limits_exceeded = false;
	return true;
}

function check_limits_quick(&$msg) {
	if (nvl($_SESSION['MUDBAG_USER']->limits_exceeded, false)) {
		$msg = "This operation isn't allowed because your limits were exceeded when they were last checked. " .
		  "Press the <i>Home</i> button to see the details and to check them again.";
		return false;
	}
	return true;
}
?>
