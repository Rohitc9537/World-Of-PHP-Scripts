<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mng_users_login.php,v 1.1.1.1 2005/07/13 00:22:03 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");

	class MB_MngUsersLogin extends MB_DBScreen {

		var $saveok = false;
		var $errors = false;
		var $added_ok;
		var $err_already;
		var $err_baduser;

		function Callback($tag) {
			if ($tag == "btn_Add")
				if ($this->add_users(stripslashes($_POST['mbfv_user_list']), $_POST['mbfv_role_id']))
					$this->saveok = true;
				else
					$this->errors = true;
			else
				parent::Callback($tag);
		}

		function ShowForm() {
//			if ($this->saveok)
//				echo "<br>saveok (tmp)";
//			if ($this->errors)
//				echo "<br>errors (tmp)";
//			echo "<br>already: "; dump($this->err_already);
//			echo "<br>bad: "; dump($this->err_baduser);
			$this->MessageConfirmation("Following users were successfully added:", $this->added_ok);
			$this->MessageError("Following users were already on the users list and do not need to be added:", $this->err_already);
			if (isset($this->err_baduser)) {
				$this->MessageError("Users listed in <i>Logins</i> box could not be added. Check that login names are correct.");
				echo "<p>";
			}

			echo "<p>";
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Type the logins of the users you want to add, one per line.");
			$this->FieldLabel("Logins (one per line)", true);
			if (isset($this->err_baduser))
				$user_list = implode("\r\n", $this->err_baduser);
			else
				$user_list = '';//don't relist the one's that worked -- nvl($_POST['mbfv_user_list']);
			echo "<textarea rows='10' cols='50' name='mbfv_user_list' onChange='set_dirty();'
			  onKeydown='set_dirty();'>$user_list</textarea>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Choose the role for the new users.");
			$this->FieldLabel("Role", true);
			echo "<select name='mbfv_role_id'>";
			echo "<option value=" . ROLE_SEE . ">see</option>";
			echo "<option value=" . ROLE_EDIT . ">edit</option>";
			echo "</select>";

			$tbl->FormCellBegin("Add to add them (needs work)");
			$this->ButtonNoDirtyCheck("btn_Add", "Add");
			$this->ButtonSpaced(null, "Back to Manage Users", "mb_mng_users.php");
			$tbl->FormCellEnd();

			$tbl->End();
		}

		function add_users($a, $role_id)
		{
			$seq = 0;
			$lines = explode("\r\n", $a);
			$bad_users = '';
			foreach ($lines as $s)
				switch (add_user($s, $role_id, $errnum, $errmsg)) { // can add role_id later
				case 0: // success
					$this->added_ok[] = $s;
					break;
				case 1:
					$this->err_already[] = $s;
//					$_SESSION['msg'][0] = 'Following users were already on the users list and do not need to be added:';
//					$_SESSION['msg'][++$seq] = '&nbsp;&nbsp;&nbsp;&nbsp;' . $s;
					break;
				case 2:
//					if ($bad_users != "")
//						$bad_users .= "\r\n";
//					$bad_users .= $s;
					$this->err_baduser[] = $s;
					break;
				case -1: // error
					$this->AddMessageError("MySQL Error $errnum: $errmsg");
					return false;
				}
//			if ($bad_users != '') {
//					if ($seq > 0)
//						$seq++;
//					$_SESSION['msg'][$seq++] = "Users listed in edit box could not be added. Check that login names are correct.";
//			}
			if (!empty($this->err_already) || !empty($this->err_baduser))
				return false;
			return true;
		}
	}

	$frm = new MB_MngUsersLogin();
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right

	$hdg = "Add Users By Login";
	$frm->Go(null, $hdg, "helpctx_mb_mng_users_login");
?>
