<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mail_sim.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $

	require("mb_globals.php");

?>

<html>
<head><title>Mudbag Mail Simulation</title></head>
<body>

<?
	$subject = htmlspecialchars(stripslashes($_GET['subject']));
	echo <<<EOT
		<h1>Mudbag Mail Preview</h1>
		<table border='1' cellspacing='0' cellpadding='10' bgcolor='$color_bg'><tr><td>
		<p>To: {$_GET['to']}
EOT;
		if (!empty($_GET['headers']))
			echo "<p>{$_GET['headers']}";
	echo <<<EOT
		<p>Subject: $subject
		</td></tr><tr><td>
EOT;
	$message = htmlspecialchars(stripslashes($_GET['message']));
	if (preg_match('/^(.*)(http:\/\/\S*)(\s.*)$/s', $message, $matches))
		echo nl2br($matches[1] . "<a target='_blank' href='{$matches[2]}'>{$matches[2]}</a>" . $matches[3]);
	else
		echo nl2br($message);
?>

</td></tr></table>
</body>
</html>
