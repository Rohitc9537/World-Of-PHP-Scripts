insert into {TABLE}(sku, name, rate_month, rate_year, limit_databases, limit_data, limit_tables, limit_emails, active) values
	('ADMIN', 'Admin', 0, 0, 1000, 1000000, 10000, 10000, 1),
	('FREE', 'Free', 0, 0, 2, 100, 10, 25, 1),
	('MB001', 'Plan 1', 5, 45, 5, 500, 25, 200, 1),
	('MB002', 'Plan 2', 15, 135, 20, 2000, 200, 1000, 1),
	('MB003', 'Plan 3', 50, 450, 100, 10000, 400, 5000, 1);
