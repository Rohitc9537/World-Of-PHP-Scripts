<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mng_users_invite.php,v 1.1.1.1 2005/07/13 00:22:03 rochkind Exp $

	require('mbcl_base.php');
	require('mbcl_db.php');
	require("mb_mng_user_util.php");
	require("mb_mail_sim_util.php");

	class MB_MngUsersInvite extends MB_DBScreen {

		var $bad_email_addrs;
		var $msg_part_1, $msg_part_2;
		var $get_from_table_or_view = false;
		var $do_list;
		var $mass_email_addrs;
		var $need_set_dirty = false;

		function MB_MngUsersInvite() {
			parent::MB_DBScreen();
			$this->msg_part_1 =
			  'You have been invited by '. $_SESSION['MUDBAG_USER']->get_fullname() . ' to register with the ' . get_product_name() .
			  ' website' .
			  ' so you can share ' .
			  'access to the "' . $_SESSION['APPDB']->dblongname .'"' . " database.\r\n\r\n" .
			  'You will need to register so you\'ll ' .
			  "have your own login and password. Click the link below to register:\r\n\r\n";
			$this->msg_part_2 = "\r\n\r\n" .
			  'If clicking the link doesn\'t open a browser window that takes you to the website, ' .
			  'copy it from the email and paste it into your browser\'s address field ' .
			  'where you normally enter URLs.';

		}

		function Callback($tag) {
			// Need to put main-form data in session variable to it can be reloaded.
			$_SESSION['mb_invite_prefix_msg'] = stripslashes(nvl($_POST['mbfv_prefix_msg']));
			$_SESSION['mb_invite_email_addrs'] = nvl($_POST['mbfv_email_addrs']);
			$preview = false;
			switch ($tag) {
			case "btn_Preview":
				$preview = true;
				// fall through
			case "btn_Send":
				$email_addrs = stripslashes($_POST['mbfv_email_addrs']);
				if ($this->send_emails($email_addrs, $_POST['mbfv_role_id'], $preview)) {
					$this->AddMessageConfirmation("Email was " . ($preview ? "previewed" : "sent") . " successfully.");
				}
				else {
					//go through to show form -- nothing special to do
				}
				break;
			case "btn_Get":
				$this->get_from_table_or_view = true;
				break;
			case "btn_GetGo":
				if (!$this->GetFormGo()) {
					$this->AddMessageError("The table or view has no data and/or no field named \"email\".");
					$this->get_from_table_or_view = true;
				}
				break;
			default:
				parent::Callback($tag);
			}
		}

		function ShowForm() {
			if ($this->need_set_dirty)
				$this->SetDirty();
			if ($this->do_list)
				$this->ShowList();
			else if ($this->get_from_table_or_view)
				$this->ShowGetForm();
			else
				$this->ShowMainForm();
		}

		function ShowMainForm() {
			$this->SetPageHelpCtx("helpctx_mb_mng_users_invite~mainform");
			$this->MessageError("Email could not be sent to the addresses listed below.", $this->bad_email_addrs);
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("If you like, you can type your own message to preceed the message shown above.");
			$this->FieldLabel("Custom Message", false);
			$prefix_msg = nvl($_SESSION['mb_invite_prefix_msg']);
			echo "<textarea rows='5' cols='40' name='mbfv_prefix_msg' onChange='set_dirty();' onKeydown='set_dirty();'>$prefix_msg</textarea>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Type the email addresses of the users you want to share the database with, one per line.
			  Or, press the <i>Get from Table/View</i> button, below.");
			$this->FieldLabel("Email Addresses (one per line)", true);
			if (isset($this->mass_email_addrs))
				$email_addrs = &$this->mass_email_addrs;
			else
				$email_addrs = nvl($_SESSION['mb_invite_email_addrs']);
			echo "<textarea rows='10' cols='30' name='mbfv_email_addrs' onChange='set_dirty();' onKeydown='set_dirty();'>$email_addrs</textarea>";
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press this button to get the email addresses from a table or view that you've previously set up.");
			$this->Button("btn_Get", "Get from Table/View");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Choose the role for the new users.");
			$this->FieldLabel("Role", true);
			echo "<select name='mbfv_role_id'>";
			echo "<option value=" . ROLE_SEE . ">see</option>";
			echo "<option value=" . ROLE_EDIT . ">edit</option>";
			echo "</select>";

			$tbl->FormCellBegin("When you've listed the addresses (you can always send more invitations later),
			  press <i>Preview</i>.
			  When you're ready, press <i>Send</i>.");
			$this->ButtonNoDirtyCheck("btn_Preview", "Preview");
			$this->ButtonSpacer();
			$this->ButtonNoDirtyCheck("btn_Send", "Send");
			$this->ButtonSpaced(null, "Back to Manage Users", "mb_mng_users.php");
			$tbl->FormCellEnd();
			$tbl->End();

		}

		function ShowGetForm() {
			$this->SetPageHelpCtx("helpctx_mb_mng_users_invite~getform");
			$tbl = new MB_TableFormWithInstr();
			$tbl->Begin();

			$tbl->FormCellBegin("Choose a table or view. Email addresses will be taken from the field named <i>Email</i>.
			  (Upper/lower case in the field name doesn't matter.)");
			$this->FieldLabel("Table or View", true);
			$_SESSION['APPDB']->ShowTableViewSelect("mbfv_tv_name");
			$tbl->FormCellEnd();

			$tbl->FormCellBegin("Press <i>Get</i> to get the email addresses.");
			$this->Button("btn_GetGo", "Get");
			$this->ButtonSpaced(null, "Back to Add by Invitation", "mb_mng_users_invite.php");
			$tbl->FormCellEnd();
			$tbl->End();
		}

		function GetFormGo() {
			//echo "<br>get email addrs from {$_POST['mbfv_tv_name']}";
			$is_table = $_POST['mbfv_tv_name']{0} == 't';
			$ident = substr($_POST['mbfv_tv_name'], 2);
//			if ($is_table)
//				$sql = "select * from $ident";
//			else {
//				$v = new View($_SESSION['APPDB']->db_id);
//				$v->load_by_name($ident);
//				$sql = $v->build_select();
//			}
//			//echo "<br>$sql";
//			$result = $_SESSION['APPDB']->dbmain->db_query_user($sql);
			$result = $_SESSION['APPDB']->query_tableview($is_table, $ident, $field_dict, $err);
			$first = true;
			$this->mass_email_addrs = '';
			while ($row = mysql_fetch_row($result)) {
				if ($first) {
					$first = false;
					for ($i = 0; $i < count($row); $i++)
						if (strtoupper(mysql_field_name($result, $i)) == "EMAIL") {
							$fieldnum = $i;
							break;
						}
					if (!isset($fieldnum))
						return false;
				}
				//echo "<br>$row[$fieldnum]";
				// and then what?
				$this->mass_email_addrs .= "$row[$fieldnum]\n";
			}
			if ($first)
				return false;
			$this->need_set_dirty = true;
			return true;
		}

		function send_emails($a, $role_id, $preview)
		{
		// no quotes or other monkey business
		// need to make sure email isn't already with us
			$seq = 0;
			$a = trim($a);
			if (empty($a)) {
				$this->AddMessageError("You must list at least one email address.");
				return false;
			}
			$lines = explode("\r\n", $a);
			foreach ($lines as $s) {
				if (!strstr($s, '@')) {
					$this->AddMessageError("One or more email addresses were missing @ symbols. No emails were sent.");
					return false;
				}
			}
			$bad_email_addrs = array();
			foreach ($lines as $s) {
				// token_issue sends the email
				$code = token_issue(null, $_SESSION['APPDB']->db_id, $s, $role_id, $this->msg_part_1, $this->msg_part_2,
				  "Invitation to access Mudbag database application", $_SESSION['mb_invite_prefix_msg'], $preview);
				if ($code != "preview" && $code == 0) {
					$this->bad_email_addrs[] = $s;
				}
				if ($preview)
					break;
			}
			return empty($this->bad_email_addrs);
		}

		function ShowList() {
			$this->SetPageHelpCtx("helpctx_mb_mng_users_invite~showlist");
			$result = $_SESSION['APPDB']->dbmain->db_query("select
			  when_issued,
			  when_redeemed,
			  dblongname,
			  email, role_id, error
			  from mb_token
			  join mb_db using(db_id)
			  where mb_db.db_id = {$_SESSION['APPDB']->db_id}");
			if (mysql_num_rows($result) < 1)
				echo "<p>No invitations have been issued. Click " . $this->HelpLink("here", "helpctx_mb_mng_users_invite") .
				  " to learn how to issue one.";
			else {
				$tbl = new MB_Table();
				$tbl->Begin();
				$tbl->ColHdg('When Issued', true);
				$tbl->ColHdg('When Redeemed', true);
				$tbl->ColHdg('Database', true);
				$tbl->ColHdg('Email', true);
				$tbl->ColHdg('Role', true);
				$tbl->ColHdg('Email Error?', true);
				$tbl->Body();
				while ($row = mysql_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>{$row['when_issued']}</td>";
					echo "<td align='center'>" . ($row['when_redeemed'] == 0 ? "Not yet" : $row['when_redeemed']) . "</td>";
					echo "<td>{$row['dblongname']}</td>";
					echo "<td>{$row['email']}</td>";
					echo "<td>" . role_name($row['role_id']) . "</td>";
					echo "<td align='center'>" . (empty($row['error']) ? "N" : "Y") . "</td>";
				}
				$tbl->End();
				echo "<p><i>Email Error</i> refers to whether email was successfully sent.
				  Mudbag doesn't know whether the email address was valid or whether the mail was actually received.";
			}
			echo "<p>";
			$this->Button(null, "Back to Manage Users", "mb_mng_users.php");
		}
	}

	$frm = new MB_MngUsersInvite();
	$frm->SetActiveDatabase($frm->active_database, true); // DB button; nothing to right
	$frm->do_list = isset($list);
	if ($frm->do_list)
		$hdg = "Issued Invitations";
	else
		$hdg = "Add Users By Invitation";
	$frm->Go(null, $hdg, "helpctx_mb_mng_users_invite~mainform");
?>
