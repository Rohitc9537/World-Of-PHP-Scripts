<?php

	// Mudbag - Copyright 2004-2005 Basepath Associates (Marc Rochkind). All rights reserved.
	// Further information about Mudbag is at mudbag.com.
	// May be used and distributed under the license in the license.htm file and at mudbag.com/doc/license.htm.
	// $Id: mb_mng_user_util.php,v 1.1.1.1 2005/07/13 00:22:02 rochkind Exp $


// Miscellaneous user and token functions -- should be in classes

function get_product_name() {
	return "Mudbag";
}

function get_invite_url($invitation_code) {
	return "http://" . $_SERVER["SERVER_NAME"] . dirname($_SERVER['PHP_SELF']) . "/mb_respond.php?code=$invitation_code";
}

// error checking and reporting
function token_issue($login, $db_id, $email, $role_id, $msg_part_1, $msg_part_2, $subj, $prefix_msg, $preview = false) {
	if ($preview)
		$code = "preview";
	else {
		if (empty($login))
			$login = $_SESSION['MUDBAG_USER']->login;
		$db = new MB_DB(); // because we may not be in a session
		$code = mt_rand (1000000000, 2000000000);
		$id = $db->db_query("insert into mb_token (login, db_id, role_id, email, code, when_issued) values(
		  '$login', $db_id , $role_id, '$email', $code, now())");
	}
	$prefix_msg = trim($prefix_msg);
	if (!empty($prefix_msg))
		$msg = stripslashes($prefix_msg) . "\r\n\r\n";
	else
		$msg = '';
	$msg .= $msg_part_1 . get_invite_url($code) . $msg_part_2;
	if (mb_mail($email, $subj, $msg, "From: " . MB_EMAIL_SUPPORT, $preview) == false && !$preview) {
		$db->db_query('update mb_token set error = 1 where token_id = ' . $id);
		return 0;
	}
	return $code;
}

function token_redeem($code, $db, &$frm) {
	if ($code == 0)
		return;

	logger($code, 'token_redeem');
	//$result = $db->db_query("select token_id, db_id, role_id from mb_token where code = $code and error <> 1 and when_redeemed = 0");
	$result = $db->db_query("select token_id, db_id, role_id from mb_token where code = $code and error <> 1 and when_redeemed = 0");
	if (mysql_num_rows($result) == 1) {
		$row = mysql_fetch_assoc($result);
		$new_role_id = $row['role_id'];
		$db->db_query('update mb_token set when_redeemed = now() where token_id = ' . $row['token_id']);
		$result2 = $db->db_query('select dbname, dblongname from mb_db where db_id = ' . $row['db_id']);
		if (mysql_num_rows($result2) == 1) {
			$row2 = mysql_fetch_assoc($result2);
			$frm->AddMessageConfirmation("Access granted to database \"{$row2['dblongname']}\"");
//			$db->db_query('grant SELECT, INSERT, UPDATE, DELETE on ' . $row2['dbname'] . '.* to "' . $_SESSION['MUDBAG_USER']->get_mysql_user() . '"@"localhost" identified by "' .
//			  $_SESSION['MUDBAG_USER']->password . '"');
			$result_u = $db->db_query('select user_id from mb_user where login = "' . $_SESSION['MUDBAG_USER']->login . '"');
			if (mysql_num_rows($result_u) < 1)
				$frm->AddMessageError("Could not locate user associated with invitation.");
			else {
				$row_u = mysql_fetch_row($result_u);
				$user_id = $row_u[0];
				$result_role = $db->db_query("select role_id from mb_user_db
				  where user_id = $user_id and db_id = {$row['db_id']}");
				if ($row_role = mysql_fetch_row($result_role)) {
					if ($row_role[0] == ROLE_SEE && $new_role_id != $row_role[0]) // "see" is the only role we update
						$db->db_query("update mb_user_db set role_id = $new_role_id
						  where user_id = $user_id and $db_id = {$row['db_id']}");
				}
				else
					$db->db_query("insert into mb_user_db (user_id, db_id, role_id) values(
					  {$_SESSION['MUDBAG_USER']->user_id}, {$row['db_id']}, $new_role_id)");
			}
		}
		else {
			$frm->AddMessageError("Could not locate database associated with invitation.");
		}
	}
	else {
		$frm->AddMessageError("Could not locate invitation in database.");
	}
}

// No session here, so we have to get the DB for ourselves.
function token_valid($code, &$role_id, &$login, &$token_id) {
	$db = new MB_DB();
	if ($code == 0)
		return 1;
	$result = $db->db_query("select token_id, login, role_id from mb_token where code = $code and error <> 1 and when_redeemed = 0");
	if (mysql_num_rows($result) == 1) {
		$row = mysql_fetch_assoc($result);
		$role_id = $row['role_id'];
		$login = $row['login'];
		$token_id = $row['token_id'];
		return true;
	}
	return false;
}

function add_user($login, $role_id = ROLE_EDIT, &$errnum, &$errmsg) {
//	global $want_db_query_echo;
//	$want_db_query_echo = false;

	$errnum = null;
	$db = $_SESSION['APPDB']->dbmain;
	$success = true;
	$result = $db->db_query("select user_id from mb_user where login = '$login'");
	if ($result) {
		if ($row = mysql_fetch_row($result)) {
			$result2 = $db->db_query(sprintf('select user_id from mb_user_db where user_id = %d and db_id = %d',
			  $row[0], $_SESSION['APPDB']->db_id));
			if (mysql_numrows($result2) > 0)
				return 1;
			$db->db_query("begin"); // will cover grant_nonowner_privileges, too
			$success = $db->db_query(sprintf('insert into mb_user_db (user_id, db_id, role_id) values(%d, %d, %d)',
			  $row[0], $_SESSION['APPDB']->db_id, $role_id));
			if ($success !== false) { // both true and 0 indicate success
				$success = $db->grant_nonowner_privileges($login, $role_id, false, $errnum, $errmsg); // no internal transaction
				$got_error_info = true;
			}
			if ($success) {
				$db->db_query("commit");
				return 0;
			}
			else {
				if (!isset($got_error_info)) {
					$errnum = mysql_errno();
					$errmsg = mysql_error();
				}
				$db->db_query("rollback");
				return -1;
			}
			return 0;
		}
	}
	return 2;
}

function revoke_users(&$user_list, &$login_list) {
	$db = $_SESSION['APPDB']->dbmain;
	foreach ($_SESSION['userlist'] as $id) {
		// Proceed whether operations succeed or not.
		$db->db_query('delete from mb_user_db where user_id = ' . $id . ' and db_id = ' . $_SESSION['APPDB']->db_id, true);
		$db->grant_nonowner_privileges($_SESSION['loginlst'][$id], 0, false, $errnum, $errmsg);
	}
}

function set_role($user_id, $login, $db_id, $role_id, &$errnum, &$errmsg) {
	$db = $_SESSION['APPDB']->dbmain;
	$db->db_query("begin");
	$success = $db->db_query("update mb_user_db set role_id = $role_id
	  where user_id = $user_id and db_id = $db_id", true);
	if ($success) {
		$success = $db->grant_nonowner_privileges($login, $role_id, false, $errnum, $errmsg); // no internal transaction
		$got_error_info = true;
	}
	if ($success) {
		$db->db_query("commit");
		return true;
	}
	else {
		if (!isset($got_error_info)) {
			$errnum = mysql_errno();
			$errmsg = mysql_error();
		}
		$db->db_query("rollback");
		return false;
	}
}

function synthesize_password() {
	$a = "abcdefghjklmnpqrstuvwxyz23456789";
	$p = "";
	for ($i = 0; $i < 8; $i++)
		$p .= $a[rand(0, strlen($a) - 1)];
	return $p;
}

// No session here, so we have to get the DB for ourselves.
function send_chg_password_invite($login, $email) {
	return token_issue($login, 0, $email, ROLE_OWNER,
	  "This email has been sent in response to a request to reset a forgotten Mudbag password. " .
	  "Click the following link to go to Mudbag to choose a new password.\r\n\r\n",
	  "\r\n\r\n(If you did not make this request or don't need to change your password, you may ignore this email.)\r\n",
	  "Instructions for changing your Mudbag password", null, false);
}

?>
