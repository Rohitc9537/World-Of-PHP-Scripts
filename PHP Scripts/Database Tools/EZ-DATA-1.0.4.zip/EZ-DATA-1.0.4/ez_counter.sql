CREATE TABLE `ez_counter` (
  `id` int(30) NOT NULL auto_increment,
   PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1;


