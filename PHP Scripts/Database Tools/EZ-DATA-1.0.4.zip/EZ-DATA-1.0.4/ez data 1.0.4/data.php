<?php
include ("includes/menu.inc");
?>

<html>
<head>
  <title>EZ-Data</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body background="images/bg.jpg" text="#000000" link="#000000" vlink="#000000" alink="#000000">
<div align="center"> 
  <?
include "includes/view_menu.inc";
include ("includes/footer.inc");
?>
</div>
<div align="center"></div>
</body>
</html>
