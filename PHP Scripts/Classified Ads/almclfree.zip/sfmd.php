<?
$ct=$_REQUEST['ct'];
$md=$_REQUEST['md'];
$page=$_REQUEST['page'];
$ed_id=$_REQUEST['ed_id'];
$ed_passw=$_REQUEST['ed_passw'];
$edit_delete=$_REQUEST['edit_delete'];
$ps_email=$_REQUEST['ps_email'];
$mds=$_REQUEST['mds'];
$onlywithphoto=$_REQUEST['onlywithphoto'];
$id=$_REQUEST['id'];
$idnum=$_REQUEST['idnum'];
$mblogin=$_REQUEST['mblogin'];
$admpassw1=$_REQUEST['admpassw1'];
$vis=$_REQUEST['vis'];
$list_id=$_REQUEST['list_id'];
$ads_rt=$_REQUEST['ads_rt'];
$ammlk=$_REQUEST['ammlk'];
$admcookpassw=$_REQUEST['admcookpassw'];
$cook_login=$_REQUEST['cook_login'];
$cook_passw=$_REQUEST['cook_passw'];
$f_login=$_REQUEST['f_login'];
$f_passw=$_REQUEST['f_passw'];
$viunvis=$_REQUEST['viunvis'];
$mbprf_login=$_REQUEST['mbprf_login'];
$mbprf_passw=$_REQUEST['mbprf_passw'];
$emltp=$_REQUEST['emltp'];
$emllogin=$_REQUEST['emllogin'];

$pm_message=$_REQUEST['pm_message'];
$pm_email=$_REQUEST['pm_email'];
$pm_subject=$_REQUEST['pm_subject'];

$userfile=$HTTP_POST_FILES['userfile']['tmp_name'];
$userfile_name=$HTTP_POST_FILES['userfile']['name'];

?>