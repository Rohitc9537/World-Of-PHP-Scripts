<?php
	/**
	 *	Jobline Component for Mambo 4.5
 	 *
	 *	Copyright (C) 2004 Olle Johansson
	 *	Distributed under the terms of the GNU General Public License
	 *	This software may be used without warrany provided and
	 *  copyright statements are left intact.
     */
function com_uninstall() {
	global $database;
	return "Jobline Successfully Uninstalled<br />
	Visit <a href=\"http://mambo.theyard.org\" target=\"blank\">Mambo at the Yard</a> for more exciting Mambo addons.";
}
?>
