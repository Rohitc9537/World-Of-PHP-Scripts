<?php
$cfgjl['version'] = "1.1.1";
$cfgjl['mailfromaddress'] = "";
$cfgjl['mailfromname'] = "";
$cfgjl['item_limit'] = "20";
$cfgjl['sort_order'] = "datedesc";
$cfgjl['publishinglimit'] = "30";
$cfgjl['termsofservice'] = "";
$cfgjl['ccfields'] = '0';
$cfgjl['useusstate'] = "1";
$cfgjl['defaultjobstatus'] = "1";
$cfgjl['emailapp'] = "0";
$cfgjl['postjobs'] = "0";
$cfgjl['newdays'] = "7";
$cfgjl['extrafields']='Start Date; Number of Openings; Population';
$cfgjl['keywordsets']='Highest finished education=No education; High School; College; University';
$cfgjl['dateformat'] = "";
$cfgjl['template'] = "default";
$cfgjl['autoapprove'] = "0";
$cfgjl['editor'] = "_jx_default";
$cfgjl['editorwidth'] = "400";
$cfgjl['editorheight'] = "200";
$cfgjl['initeditor'] = "1";
?>
