<?php
// Joblins Search addon script
// Copyright 2004 Olle Johansson
// Released under the GNU General Public License

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

// Read configuration file
include_once("$mosConfig_absolute_path/components/com_jobline/configuration.php");


?>