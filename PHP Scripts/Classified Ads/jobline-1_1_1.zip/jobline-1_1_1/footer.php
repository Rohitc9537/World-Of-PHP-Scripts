  <p><?php echo _OJ_CREATED_BY; ?>
     <font class="small"><a href="http://mambo.theyard.org" target="_blank">Olle Johansson</a></font>
	 <br />
	 <?php echo _OJ_VISIT; ?> <a href="http://mambo.theyard.org" target="blank">Mambo at the Yard</a> <?php echo _OJ_EXCITING_ADDONS; ?>
     <br />
     <font class="small"><?php echo _OJ_VERSION; ?>: <?php echo $cfgjl['version']; ?></font>
  </p>
