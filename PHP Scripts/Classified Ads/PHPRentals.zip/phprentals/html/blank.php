<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
<TITLE>lostpwd</TITLE>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 0, 0, 0, 0), L=(lostpwdLayout, 600, 158))" BGCOLOR="#FFFFFF" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>

<?
include ("".$_SERVER['DOCUMENT_ROOT']."/phprentals/includes/header.php");
?>
<CENTER>

<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=600>
                <TABLE ID="Table7" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                    <TR>
                        <TD WIDTH=600>
                            <P>&nbsp;</P>
                        </TD>
                    </TR>
                    <TR>
                        <TD VALIGN=TOP WIDTH=600>
                                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5 WIDTH=600 NOF=TI>
                                    <TR>
                                        <TD>
                                            <P ALIGN=LEFT><FONT SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">If you lost your password please use the form below to have your information emailed to you. Your password will be reset, and you will be given a new one.</FONT></P>
                                      </TD>
                                    </TR>
                                </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
<BR>
<?
include ("".$_SERVER['DOCUMENT_ROOT']."/phprentals/includes/footer.php");
?>

</BODY>
</HTML>
 