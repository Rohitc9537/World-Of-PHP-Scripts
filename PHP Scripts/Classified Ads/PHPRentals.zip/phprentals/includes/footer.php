    <TABLE CELLPADDING=0 CELLSPACING=0 WIDTH="100%" VALIGN=TOP>
        <TR>
            <TD VALIGN=TOP>
                <P>
                    <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                        <TR>
                            <TD>
                                <TABLE ID="Table1" BORDER=0 BGCOLOR="#FFFFFF" CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                    <TR VALIGN=TOP>
                                        <TD WIDTH="100%">
                                            <P>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="CENTER"></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                    <TR ALIGN=CENTER>
                                        <TD WIDTH="100%" BGCOLOR="#000099" HEIGHT=29>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5 WIDTH=612 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=CENTER><A HREF="/phprentals/index.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Home</FONT></A><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">  |&nbsp; </FONT><A HREF="/phprentals/index.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">View Listings</FONT></A><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">  |&nbsp; </FONT><A HREF="/phprentals/html/landlords.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Landlords</FONT></A><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">  |&nbsp; </FONT><A HREF="/phprentals/html/rental-register.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Register</FONT></A></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                    </TR>
                                    <TR VALIGN=TOP>
                                        <TD>
                                            <P>&nbsp;</P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH="100%">
                                            <P ALIGN=CENTER><B><FONT SIZE="-2" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Copyright 2003 Virtual Xpress All rights reserved Site Design: </FONT></B><FONT SIZE="-2" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif"></FONT><A HREF="http://www.virxpress.com"><FONT SIZE="-2" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Virtual Xpress</FONT></A></P>
                                        </TD>
                                    </TR>
                                </TABLE>
                            </TD>
                        </TR>
                    </TABLE>
            </TD>
        </TR>
    </TABLE>