<TABLE CELLPADDING=0 CELLSPACING=0 WIDTH="100%" VALIGN=TOP>
        <TR>
            <TD VALIGN=TOP>
                <P>
                    <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                        <TR>
                            <TD>
                                <TABLE ID="Table1" BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH="100%">
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#FFFFCC">
                                            <P>&nbsp;</P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH="49%">
                                            <P><IMG ID="Picture1" HEIGHT=56 WIDTH=300 SRC="/phprentals/images/logo.gif" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0 ALT=""></TD>
                                        <TD VALIGN=BOTTOM WIDTH="50%">
                                            <P ALIGN=RIGHT><B><FONT SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Property Management Software</FONT></B></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#000099" HEIGHT=20>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH=627 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P>&nbsp; <A HREF="/phprentals/index.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">View Listings</FONT></A><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif"> | </FONT><A HREF="/phprentals/landlords/index.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Landlords Only</FONT></A><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif"> | </FONT><A HREF="/phprentals/html/landlords.php"><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">Landlord Signup</FONT></A></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                    </TR>
                                </TABLE>
                            </TD>
                        </TR>
                    </TABLE>
            </TD>
        </TR>
    </TABLE>