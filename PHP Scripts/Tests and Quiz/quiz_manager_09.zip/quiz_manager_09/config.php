<?php

	  $admin_pass = "admin";


	  $db_host = "localhost";
	  $db_name = "quiz";
	  $db_user = "test";
	  $db_password = "test";

	  $tempz[form] = "templates/quiz_form_template.html";

	 $email_not_required = 1; 
	
?>