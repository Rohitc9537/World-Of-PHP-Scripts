


<b>Quiz Manager</b>
<ul>
<li><a href=docs/readme.txt>readme</a>
<li><a href=docs/tables.txt>tables</a>
<li><a href=install.php>install</a> 
<li><a href=admin.php>admin</a> (default password: admin)
</ul>
<p>

Including Quiz Form on Another Page:
<pre>
	&lt;? include "<?

	print str_replace("index.php", "", $_SERVER[REQUEST_URI]);	

	?>quiz_form.php" ?&gt;
</pre>


