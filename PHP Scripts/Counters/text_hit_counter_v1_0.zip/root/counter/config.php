<?php
// Text hit counter v1.0
$justify ="center"; //Where the script should appear on your page
$font_face = "verdana"; //The font face you want to use
$font_size = "1";    //The font size you want to use
$text_before_the_hit_number = "There have been"; //The text that appears before the number of hits
$text_after_the_hit_number = "visitors to this page"; //The text that appears after the number of hits
?>