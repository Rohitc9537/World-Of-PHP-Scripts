<?

//---------------------------------------------------------------
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//Meezerk's Advanced CowCounter - An Advanced Website Counter.
//Copyright (C) 2004  Daniel Foster  dan_software@meezerk.com
//---------------------------------------------------------------

?>
<TABLE BORDER="1" CELLSPACING="2" CELLPADDING="2">
  <TR>
    <TD NOWRAP>
      <A HREF="main.php">Counter Stats</A><BR>
      <BR>
      <A HREF="counters.php">Add/Edit Counters</A><BR>
      <BR>
      <A HREF="statsselect.php">Statistics</A><BR>
      <BR>
      <A HREF="ipignore.php">Edit Ignoring IPs</A><BR>
      <A HREF="configedit.php">Edit Configuration</A><BR>
      <BR>
      <A HREF="changepass.php">Change Password</A><BR>
      <BR>
      <A HREF="help.php">Help</A><BR>
      <BR>
      <A HREF="logout.php">Logout</A>
    </TD>
  </TR>
</TABLE>