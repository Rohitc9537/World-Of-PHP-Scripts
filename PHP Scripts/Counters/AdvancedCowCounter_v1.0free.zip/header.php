<?

//---------------------------------------------------------------
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//Meezerk's Advanced CowCounter - An Advanced Website Counter.
//Copyright (C) 2004  Daniel Foster  dan_software@meezerk.com
//---------------------------------------------------------------

?>
<HTML>
<HEAD>
  <TITLE>Welcome to the Advanced CowCounter</TITLE>
</HEAD>
<BODY BGCOLOR="#ffffff" BACKGROUND="CowSpots.gif">

<H1>
 <IMG SRC="CowLogo.gif" WIDTH="90" HEIGHT="81" ALIGN="BOTTOM">
 Advanced CowCounter
 <HR>
</H1>

<TABLE BORDER="0" CELLSPACING="10" CELLPADDING="2" WIDTH="99%">
  <TR>
    <TD VALIGN="TOP" WIDTH="1%" NOWRAP>
      <?
        include("menu.php");
      ?>
    </TD>
    <TD VALIGN="TOP">