<?
define("STATS_CONNECTION", 1); // 0 If connection is required, 1 if you have made your own connection
define("STATS_MYSQL_HOSTNAME", "localhost"); //You probably should leave this
define("STATS_MYSQL_USERNAME", ""); //MySQL Username
define("STATS_MYSQL_PASSWORD", ""); //MySQL Password
define("STATS_MYSQL_DATABASE", ""); //MySQL Database Name
define("STATS_SITE_URL", "radiantfx.com"); //Your site's url dont include http:// or www.
?>