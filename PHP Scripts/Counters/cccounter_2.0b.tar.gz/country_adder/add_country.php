<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	<title>CcCounter 2.0 - Add Country</title><link rel="stylesheet" type="text/css" href="style.css"></head>

<body>
<div class="standard"><br><b>CcCounter 2.0 - Add Country</b><br><br>
<?php
function write_to_file($file_name, $string)
{
	$file = fopen($file_name, "a");
	if (flock($file, LOCK_EX)) //acquires lock
	{
		fwrite($file, $string);
		flock($file, LOCK_UN); //releases lock
	}
	$page_counts  = $value;
	fclose($file);	
}

$option = $_GET["option"];
$name = $_POST["name"];
$tld = $_POST["tld"];
if ($option == true && $name != "" && $tld != "")
{
	require dirname(__FILE__) . "/detect_func.php";
	$array_line = 0;
	$detect_line = 0;
	$file = file (dirname(__FILE__) . "/detect_func.php");
	for ($i = 0; $i < count($file); $i ++)
	{
		if (stristr($file[$i], "\$country_type_name = array(")) $array_line = $i;
		if (stristr($file[$i], "//elseif(stristr(\$entries[\$i], \"<TLD>\")")) $detect_line = $i;
	}	
	if ($array_line != 0 && $detect_line != 0)
	{
		$new_array_line = "\$country_type_name = array(";
		for ($i = 0; $i < count($country_type_name); $i ++) $new_array_line.="\"$country_type_name[$i]\", ";
		$new_array_line.= "\"$name\");\n";
		$file [$array_line] = $new_array_line;
		
		$index = count($country_type_name); $index1 = $index+1;
		$file [$detect_line] = "\t\telseif(stristr(\$entries[\$i], \"$tld*\")) \$country_type[$index]++;
		//elseif(stristr(\$entries[\$i], \"<TLD>\")) \$country_type[$index1]++;\n";
		
		if (file_exists(dirname(__FILE__) . "/detect_func.php.bak")) unlink(dirname(__FILE__) . "/detect_func.php.bak");
		rename (dirname(__FILE__) . "/detect_func.php", dirname(__FILE__) . "/detect_func.php.bak");
		for ($i = 0; $i < count($file); $i ++) write_to_file (dirname(__FILE__) . "/detect_func.php", $file[$i]);
		
		print "Country $name has been added to the countries list. <a href=\"index.php?option=country&dir=\" class=\"link\" target=\"blank\">Control the effects of the operation.</a><br><br>
		<b><a href=\"$PHP_SELF?option=undo\" class=\"link\">Undo changes</a></b>
		<br><br>
		<b><a href=\"$PHP_SELF?option=\" class=\"link\">Add another country</a></b>
		<br><br>
		<b><a href=\"$PHP_SELF?option=delete\" class=\"link\">Delete this file (<font color=\"red\">HIGHLY RECOMMENDED</font>)</a></b>";
	}
	else print "<b>Line(s) identification did not succeed. Aborting...</b>";
}
elseif ($option == "undo")
{
	if (file_exists(dirname(__FILE__) . "/detect_func.php") && file_exists(dirname(__FILE__) . "/detect_func.php.bak"))
	{
		unlink (dirname(__FILE__) . "/detect_func.php");
		rename (dirname(__FILE__) . "/detect_func.php.bak", dirname(__FILE__) . "/detect_func.php");
		print "Backup copy successfully restored.<br><br>
		<b><a href=\"$PHP_SELF?option=\" class=\"link\">Add another country</a></b>
		<br><br>
		<b><a href=\"$PHP_SELF?option=delete\" class=\"link\">Delete this file (<font color=\"red\">HIGHLY RECOMMENDED</font>)</a></b>";
	}
	else print "<b>Could not find file or backup copy. Aborting...</b><br><br>
		<b><a href=\"$PHP_SELF?option=delete\" class=\"link\">Delete this file (<font color=\"red\">HIGHLY RECOMMENDED</font>)</a></b>";
}
elseif ($option == "delete")
{
	print "This file has been deleted successfully.";
	unlink (dirname(__FILE__) . "/add_country.php");
}
else
{
	print "This script is intented for those who want to add their own country to countries list. <br>You can add <b>one and only one country</b>, then it is very recommended <b>to delete this file for security!</b> Otherwise, everyone will be allowed to add a country!<br>If you want to rescue your old <code>detect_func.php</code>, delete the new one and rename the backup copy that will be created (<code>detect_func.php.bak</code>) to <code>detect_func.php</code>.<br><br>
	<form method=\"post\" action=\"$PHP_SELF?option=true\">
	<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr>
	<td><div class=\"standard\">Type country name (eg:Italy, France...): </td><td><input name=\"name\" size=\"20\"></input></td>
	</tr><tr>
	<td><div class=\"standard\">Type country <a href=\"http://www.iana.org/gtld/gtld.htm\" class=\"link\">TLD</a> (eg: it, fr, com...): </td><td><input name=\"tld\" size=\"20\"></input></td>
	</tr><tr><td colspan=\"2\"><br><input type=\"submit\" value=\"Add country\"></td></tr></table>
	<br><br>
	<b><a href=\"$PHP_SELF?option=delete\" class=\"link\">Delete this file (<font color=\"red\">HIGHLY RECOMMENDED</font>)</a></b>";
}
?>
</body></html>