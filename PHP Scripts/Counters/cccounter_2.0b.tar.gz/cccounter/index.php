<?php
/*********************************************************************/
/*                            CcCounter 2.0b                         */
/*  Written by Emanuele Guadagnoli - cicoandcico[at]cicoandcico.com  */
/*      Reference page: http://www.cicoandcico.com/products.php      */
/*                            License: GPL                           */
/*           To change appearance, edit *ONLY* HTML code!            */
/*********************************************************************/

require dirname(__FILE__) . "/config.php";
require dirname(__FILE__) . "/month_func.php";
include dirname(__FILE__) . "/detect_func.php";

$dir = $_GET["dir"];
$option = $_GET["option"];
$temp = str_replace("_", " - ", $dir); //smarter
$old_dir = dirname(__FILE__) . "/" . $files_dir;
if ($dir != "") $old_dir = $old_dir . $dir. "/";
$bar_up = $images_dir . $bar_up;
$bar_down = $images_dir . $bar_down;

$date_file = $old_dir . "date";
$data_file = $old_dir . $temp_file_name; //temporary file
$os_data_file = $old_dir . $os_file_name;
$browser_data_file = $old_dir . $browser_file_name;
$country_data_file = $old_dir . $country_file_name;

//*********************BEGIN HTML CODE******************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	<title>CcCounter 2.0 Statistics</title><link rel="stylesheet" type="text/css" href="style.css"></head>

<body>
<br>
<table width="99%" border="0" cellpadding="0" cellspacing="0"><tr>
	<td align="left"><a href="http://www.cicoandcico.com/products.php?option=cccounter"><img border="0" width="208" height="69" src="images/cccounter.gif" alt="CcCounter homepage"></a></td>
	</tr></table>
<!--separator--> 
	<table class="separator"><tr><td></td></tr></table>
<center>
<!--UP-BAR-->
	<table class="index" cellpadding="0" cellspacing="0">
	<tr align="center">
	<!--INDEX-->
		<td align="left" class="header"></td>
		<td class="spacer"></td>
		<td class="tab"></td>

		<td valign="middle" width="50"><?php print "<a href=\"$PHP_SELF?option=&dir=$dir\" class=\"main\">";?>All Hits</a></td>
		<td class="tab"></td>
		<td valign="middle" width="30"><?php print "<a href=\"$PHP_SELF?option=browser&dir=$dir\" class=\"main\">";?>Browsers</a></td>
		<td class="tab"></td>
		<td valign="middle" width="130"><?php print "<a href=\"$PHP_SELF?option=os&dir=$dir\" class=\"main\">";?>Operating systems</a></td>
		<td class="tab"></td>
		<td valign="middle" width="30"><?php print "<a href=\"$PHP_SELF?option=country&dir=$dir\" class=\"main\">";?>Countries</a></td>
				<td class="tab"></td>
<!--FLAGS AND FOOTER-flags differs from italian to english version-->
	<td> � </td>
		<td align="right" class="footer"></td>
</tr>
</table>
<!--MAIN TABLE-->
	<table class="main_table" cellpadding="0" cellspacing="0">
	<tr valign="top">
		<td align="center" width="19%" valign="top">
			<table class="max_table" cellpadding="0" cellspacing="0">
			<tr>
			<td height="5%" align="center" width="100%" valign="top">
					<!--*********MENU*********-->
					<table class="menu_button" cellpadding="0" cellspacing="0"><tr>
					<td align="left" height="31" width="32"><img src="images/head.png" border="0" alt=""></td>
					<td height="31" width="100%" align="center" valign="middle">
					<a class="menu_title">Menu</a></td>
					<td height="31" align="right" width="29"><img src="images/foot.png" border="0" alt=""></td>
					<td height="31" width="5"><img src="images/shadow1.gif" border="0" alt=""></td>
					</tr>
					<tr><td colspan="3">
							<table class="menu_content_table" cellspacing="0" cellpadding="1"><tr><td width="100%" valign="top">
							<table class="menu_content_table_bg" cellspacing="0" cellpadding="0"><tr><td valign="top">
							<div class="menu">
							<!--Menu body-->
							<b>CcCounter 2.0</b><ul>
							<li><?php print "<a href=\"$PHP_SELF?option=&dir=\" class=\"link\">";?>View global statistics</a></li>
							<li><?php print "<a href=\"$PHP_SELF?option=month&dir=\" class=\"link\">";?>Select a month</a></li>
							<li><a href="http://www.cicoandcico.com/products.php?option=cccounter" class="link">Visit CcCounter Homepage</a></li>
							<li><a href="http://www.cicoandcico.com/download/download.php?SortBy=1&fdir=./cccounter/" class="link">Download CcCounter</a></li>
							<li><a href="http://www.google.com/" class="link">Search the web</a></li>
							</ul>
							<b>Support</b>
							<ul><li><a href="http://www.cicoandcico.com/guestbook/sign.php" class="link">Sign CcCounter guestbook</a></li></ul>
							<b>Donations</b><br>
							CcCounter if free, but if you want to help developing you can contact me for a donation <a href="mailto:cicoandcico[at]cicoandcico.com" class="link">here</a>.<br><br><!--/Menu body-->
							</div>
							</td></tr></table>
							</td></tr></table>
					</td><td class="menu_lshadow">
					</td></tr>
					<tr><td colspan="4" height="5">
						<table class="menu_shadow" cellpadding="0" cellspacing="0"><tr>
						<td align="left" width="14"><img border="0" src="images/shadow2.gif" alt=""></td>
						<td width="100%"></td>
						<td align="right" width="15"><img border="0" src="images/shadow4.gif" alt=""></td>
						</tr></table>
					</td></tr></table>
					<!--*********/MENU*********-->
			</td></tr>
			<tr>
			<td height="5%" align="center" width="100%" valign="top">
					<!--*********MENU*********-->
					<table class="menu_button" cellpadding="0" cellspacing="0"><tr>
					<td align="left" height="31" width="32"><img src="images/head.png" border="0" alt=""></td>
					<td height="31" width="100%" align="center" valign="middle">
					<a class="menu_title">License</a></td>
					<td align="right" width="29" height="31"><img border="0" src="images/foot.png" alt=""></td>
					<td height="31" width="5"><img src="images/shadow1.gif" border="0" alt=""></td>
					</tr>
					<tr><td colspan="3">
							<table class="menu_content_table" cellspacing="0" cellpadding="1"><tr><td width="100%" valign="top">
							<table class="menu_content_table_bg" cellspacing="0" cellpadding="0"><tr><td valign="top">
							<div class="menu">
							<!--Menu body-->CcCounter is under <a href="http://www.gnu.org/licenses/gpl.txt" class="link">GPL</a> license. Sources can be freely distributed, and usage is totally free.
							<br><br><!--/Menu body-->
							</div>
							</td></tr></table>
							</td></tr></table>
					</td><td class="menu_lshadow">
					</td></tr>
					<tr><td colspan="4" height="5">
						<table class="menu_shadow" cellpadding="0" cellspacing="0"><tr>
						<td align="left" width="14"><img border="0" src="images/shadow2.gif" alt=""></td>
						<td width="100%"></td>
						<td align="right" width="15"><img border="0" src="images/shadow4.gif" alt=""></td>
						</tr></table>
					</td></tr></table>
					<!--*********/MENU*********-->
			</td></tr>
			<tr>
			<td height="85%" align="center" width="100%" valign="top">
					<!--*********MENU*********-->
					<table class="menu_button" cellpadding="0" cellspacing="0"><tr>
					<td align="left" height="31" width="32"><img src="images/head.png" border="0" alt=""></td>
					<td height="31" width="100%" align="center" valign="middle">
					<a class="menu_title">Credits</a></td>
					<td align="right" width="29" height="31"><img border="0" src="images/foot.png" alt=""></td>
					<td height="31" width="5"><img src="images/shadow1.gif" border="0" alt=""></td>
					</tr>
					<tr><td colspan="3">
							<table class="menu_content_table" cellspacing="0" cellpadding="1"><tr><td width="100%" valign="top">
							<table class="menu_content_table_bg" cellspacing="0" cellpadding="0"><tr><td valign="top">
							<div class="menu">
							<!--Menu body-->
							<b>CcCounter 2.0b</b><br><br>
							<b>Lead Programmer:</b><ul><li>Emanuele Guadagnoli</li></ul>
							<b>Feedback:</b><ul><li>The HWUpgrade Forum</li></ul>
							<b>Beta testing:</b><ul><li>Cicoandcico.com site users</li></ul>
							<br>If you want to help developing, please let me know. Programmers and beta testers would be really useful! <br><br><!--/Menu body-->
							</div>
							</td></tr></table>
							</td></tr></table>
					</td><td class="menu_lshadow">
					</td></tr>
					<tr><td colspan="4" height="5">
						<table class="menu_shadow" cellpadding="0" cellspacing="0"><tr>
						<td align="left" width="14"><img border="0" src="images/shadow2.gif" alt=""></td>
						<td width="100%"></td>
						<td align="right" width="15"><img border="0" src="images/shadow4.gif" alt=""></td>
						</tr></table>
					</td></tr></table>
					<!--*********/MENU*********-->
			</td></tr></table>
		</td>
		<td> </td>
		<td valign="top">
<table border="0" cellpadding="6" cellspacing="1" class="max_table"><tr><td valign="top">
<!--******************BODY******************-->
<div class="standard">	
<?php
//*********************END OF HTML CODE******************
function getdays()
{
	global $date_file;
	$date = getdate();
	$new_date = array($date['mday'] , $date['mon'], $date['year']);
	$old_date = file($date_file);
	$days_counter = ($new_date[2] - $old_date[2])*365; //counts days per year
	$days_counter += ($new_date[1]*30 + $new_date[0]);
	$days_counter -= ($old_date[1]*30 + $old_date[0]);
	return $days_counter + 1;
}
function show_hits($count_array, $days)
{
	global $BAR_SIZE;
	global $bar_up;
	global $bar_down;
	arsort($count_array);
	$keys = array_keys($count_array);
	$total = $count_array[$keys[0]];
	$rows = sizeof($keys) + 2;
	print "<table border = \"0\" cellpadding = \"1\" cellspacing = \"2\"><tr>
	<td></td><td align = \"center\"><div class=\"standard\"><b>Page URL</b></div></td>
	<td rowspan=\"$rows\" valign=\"top\"  width=\"5\" background=\"images/dot.gif\"></td>
	<td align = \"center\"><div class=\"menu\"><b>Counts</b></div></td>
	<td rowspan=\"$rows\" valign=\"top\"  width=\"5\" background=\"images/dot.gif\"></td>
	<td align = \"center\"><div class=\"menu\"><b>Hits per day</b></div></td>
	<td rowspan=\"$rows\" valign=\"top\"  width=\"5\" background=\"images/dot.gif\"></td>
	<td align = \"center\"><div class=\"menu\"><b>Perceptual (normalized)</b></div></td>
	</tr><tr><td height=\"5\" colspan = \"8\" background=\"images/dot.gif\"></td></tr>";
	for($i = 0; $i < sizeof($keys); $i++) 
	{
		$value = $keys[$i];
		$temp_key = str_replace("%", "/", $value);
		$width = 0;
		if ($total != 0) $width = ($BAR_SIZE * $count_array[$value]) / $total;
		$complement = $BAR_SIZE - $width;
		$rate =  $count_array[$value] / $days;
		$item = $i + 1;
		$rate = round ($rate, 2); //show only 2 numbers after dot
		print "\n<tr><td align = \"center\"><div class=\"standard\"><b>$item &nbsp</b></div></td>
		<td align = \"center\"><a href=\"/$temp_key\" class=\"link\"><b>$temp_key</b></a></td>
		<td align = \"center\"><div class=\"standard\">$count_array[$value]</div></td>
		<td align = \"center\"><div class=\"standard\">$rate</div></td>
		<td><img src=\"$bar_up\" width=\"$width\" height=\"10\"><img src=\"$bar_down\" width=\"$complement\" height=\"10\"></td></tr>";
	}
	print "</table>";
}

function show_type($NAME, $browser_type_name, $browser_data_file)
{
	global $data_file;
	global $BAR_SIZE;
	global $bar_up;
	global $bar_down;
	if (file_exists($data_file))
	{
		$entries = file($data_file);
		$browser_type = array();
		switch($NAME)
		{
		case "Browser": $browser_type = browser_detect($entries);
		break;
		case "Operating System": $browser_type = os_detect($entries);
		break;
		case "Country": $browser_type = country_detect($entries);
		break;
		}
		if (file_exists($browser_data_file)) //avoid reading from null files
		{
			$browser_type = temp_plus_perm($browser_type, $browser_data_file);
		}
	}
	else if (file_exists($browser_data_file))
	{
		$browser_type = retrieve_perm_info($browser_data_file);
	}
	$browser_type_new = array();
	for($i = 0; $i < sizeof($browser_type); $i++)
	{
		$browser_type_new[$browser_type_name[$i]] = $browser_type[$i];
	}
	arsort($browser_type_new);
	$keys = array_keys($browser_type_new);
	$rows = sizeof($keys) + 2;
	$total = $browser_type_new[$keys[0]];
	print "<table border = \"0\" cellpadding = \"1\" cellspacing = \"2\"><tr>
	<td></td><td align = \"center\"><div class=\"standard\"><b>$NAME</b></div></td>
	<td rowspan=\"$rows\" valign=\"top\"  width=\"5\" background=\"images/dot.gif\"></td>
	<td align = \"center\"><div class=\"menu\"><b>Counts</b></div></td>
	<td rowspan=\"$rows\" valign=\"top\"  width=\"5\" background=\"images/dot.gif\"></td>
	<td align = \"center\"><div class=\"menu\"><b>Perceptual (normalized)</b></div></td>
	</tr><tr><td height=\"5\" colspan = \"6\" background=\"images/dot.gif\"></td></tr>";
	for($i = 0; $i < sizeof($keys); $i++) 
	{
		$value = $keys[$i];
		$width = 0;
		if ($total != 0) $width = ($BAR_SIZE * $browser_type_new[$value]) / $total;
		$complement = $BAR_SIZE - $width;
		$item = $i + 1;
		print "\n<tr><td align = \"center\"><div class=\"standard\"><b>$item &nbsp</b></div></td>
		<td align = \"center\"><div class=\"standard\"><b>$value</b></div></td>
		<td align = \"center\"><div class=\"standard\">$browser_type_new[$value]</div></td>
		<td><img src=\"$bar_up\" width=\"$width\" height=\"10\"><img src=\"$bar_down\" width=\"$complement\" height=\"10\"></td></tr>";
	}
	print "</table>";
}

print "<b>CcCounter 2.0 usage statistics</b><br>
The following statistics are generated from CcCounter data files. You can choose to display either global statistics or monthly ones. For each period, informations about Browsers, Operating Systems and Country TLDs (see <a href=\"http://www.iana.org/gtld/gtld.htm\" class=\"link\">IANA list</a>) of your visitors are available.<br>Statistics are displayed in descending order.</div><br><center>
<table border = \"0\" cellpadding = \"0\" cellspacing = \"0\"><tr><td>
<div class=\"standard\"><a href=\"$PHP_SELF?option=";
if ($option != "month") print $option;
print "&dir=\" class=\"";
if ($dir == "" && $option != "month") print "article";
else print "link";
print "\"><b>Global Statistics</b></a> &nbsp - &nbsp
<a href=\"$PHP_SELF?option=month&dir=\" class=\"";
if ($option == "month" || $dir != "") print "article";
else print "link";
print "\"><b>Monthly Statistics</b></a>";
if ($dir != "") print " <b>(Current month: $temp)</b></div>";
print "</td></tr><tr><td>
<a href=\"$PHP_SELF?option=&dir=$dir\" class=\"";
if ($option == "") print "article";
else print "link";
print "\"><b>All Hits</b></a> &nbsp - &nbsp
<a href=\"$PHP_SELF?option=browser&dir=$dir\" class=\"";
if ($option == "browser") print "article";
else print "link";
print "\"><b>Browser Statistics</b></a> &nbsp - &nbsp
<a href=\"$PHP_SELF?option=os&dir=$dir\" class=\"";
if ($option == "os") print "article";
else print "link";
print "\"><b>Operating System Statistics</b></a> &nbsp - &nbsp
<a href=\"$PHP_SELF?option=country&dir=$dir\" class=\"";
if ($option == "country") print "article";
else print "link";
print "\"><b>Countries Statistics</b></a>
<br><br></td></tr><tr><td align=\"center\">";
	
if ($option)
{
	switch ($option)
	{
	case "browser": show_type("Browser", $browser_type_name, $browser_data_file);
	break;
	case "os": show_type("Operating System", $os_type_name, $os_data_file);
	break;
	case "country": show_type("Country", $country_type_name, $country_data_file);
	break;
	case "month":
		{
			if($_GET["dir"] == "")
			{
				print "<table border = \"0\" cellpadding = \"0\" cellspacing = \"0\"><tr><td valign=\"top\">
				<div class=\"standard\"><b>Choose month: </b></div><br></td>
				<td valign=\"top\" width=\"5\" background=\"images/dot.gif\"></td><td width=\"5\"></td>
				<td valign=\"top\">";
				$months = array();
				if ($handle = opendir($old_dir)) 
				{
					while (false !== ($file = readdir($handle))) 
					{
						$month = $file;
						$file = $old_dir . $file;
						if (is_dir($file) && $file != "." && $file != ".." && strstr($file, "_2"))
						{
							$temp_array = explode("_", $month);
							if ($temp_array[0] < 10) $temp_array[0] = "0".$temp_array[0];
							$months[$temp_array[1].$temp_array[0]] = $month;
						}
					}
				}
				arsort ($months);
				for ($j=0; $j<count($months); $j++)
				{
					$month = each($months);
					$temp = str_replace("_", " - ", $month[1]);
					print "<a href=\"$PHP_SELF?option=&dir=$month[1]\" class=\"link\"><b>";
					if (strlen($month[1]) < 7) print "&nbsp ";
					print "$temp</b></a><br>";
				}
				print "</td></tr></table>";
			}
		}
	break;
	}
}
else
{
	$count_array = count_into_vector($old_dir);
	if ($dir != "") show_hits($count_array, 30);
	else show_hits($count_array, getdays());
}
//*********************BEGIN HTML CODE******************
?>
</div><br>
<!--******************/BODY******************-->
	</td></tr></table>
	</td></tr></table>
	</td></tr><tr><td height="5"></td></tr></table>
	<table class="bottom_bar" cellpadding="0" cellspacing="0"><tr>
	<td align="left" width="13"><img border="0" src="images/head_002.png" alt=""></td>
	<td width="100%" valign="top"></td>
	<td align="right" width="8"><img border="0" src="images/foot_002.png" alt=""></td>
	<td width="10"></td>
	</tr></table>
	<table width="98%" border="0" cellpadding="0" cellspacing="0"><tr>
	<td align="left" valign="top"><div class="standard">
	</div></td>
	<td align="right" valign="top">
<a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww.cicoandcico.com"><img border="0" src="images/valid-html401.png" alt="Valid HTML 4.01!" height="31" width="88"></a>
	<a href="http://jigsaw.w3.org/css-validator/validator?uri=http://www.cicoandcico.com"><img style="border:0;width:88px;height:31px" src="images/vcss.png" alt="Valid CSS!"></a></td>
	</tr></table>
</center>
</body>
</html>
</body></html>