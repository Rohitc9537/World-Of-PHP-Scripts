<?php
/*********************************************************************/
/*                           CcCounter 2.0b                          */
/*  Written by Emanuele Guadagnoli - cicoandcico[at]cicoandcico.com  */
/*      Reference page: http://www.cicoandcico.com/products.php      */
/*                            License: GPL                           */
/*********************************************************************/

/************************** GENERAL SETTINGS *************************/

$BLOCKED_IPS = array("BLOCKED_IP#1", "BLOCKED_IP#2", "etc"); //add the IPs you want to block (eg. 127.0.0.1)

$OUTPUT = "This page has been visited <NUMBER> times. <a href=\"/cccounter/index.php\">View usage statistics</a>."; //output line. DON'T REMOVE WORD "<NUMBER>"!

//select Y below to monthly remove from list those files that are not longer counted (like moved or deleted files).
$CONTROL_DELETED_FILES = "N"; //"Y" ("Y" only) requires ROOT folder specification:
	$ROOT = ""; //your ROOT folder (like /var/www, or c:/programmi/easyphp/www). NO TRAILING SLASH AT THE END!

$BAR_SIZE = 200; //lenght of the perceptual bar in index.php

$images_dir = "images/";

$bar_up = "bar_up.gif";

$bar_down = "bar_down.gif";



/**** ADVANCED SETTINGS - DON'T EDIT UNLESS YOU KNOW WHAT YOU ARE DOING ****/

$MAX_SIZE = 20000; //max temporary file size (bytes). the standard value should be right for most people.

$files_dir = "data/"; //directory to store informations (ending slash required!)

$os_file_name = "os_info.dat"; //permanent os-relative informations file

$browser_file_name = "browser_info.dat"; //see above

$country_file_name = "country_info.dat";

$temp_file_name = "user_info.temp"; //temporary file

?>