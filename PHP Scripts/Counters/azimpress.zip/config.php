<?php
$dbserver="localhost";
$db="test";
$dbuser="root";
$dbpass="";
$dbtable="azimpression";
?>