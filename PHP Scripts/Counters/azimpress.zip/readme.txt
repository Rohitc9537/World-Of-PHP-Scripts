-----------------------------------------------------------------------------------------
---  AZIMPRESSION v1.0 by zoerb.net - Internetdienste - (c) - Alle Rechte vorbehalten ---
---		  eMail: mail@zoerb.net - Phone/Fax: 0700 ZOERBNET (96372638) 	        ---
-----------------------------------------------------------------------------------------
--- Dieses Script wurde zu �bungszwecken programmiert, es wird keinerlei Haftung f�r  ---
---     evtl. Sch�den, durch den Betrieb dieses Scriptes �bernommen. Keine Gew�hr     ---
---               f�r Bedienkomfort, Funktionalit�t und Systemintegrit�t.             ---
-----------------------------------------------------------------------------------------
---                             http://www.zoerb.net 			     		        ---
-----------------------------------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------------------------------
- Anpassen der Variabeln in config.php
- Upload der Dateien auf den Server
- Aufrufen von create_database.php -> Datenbank wird erstellt
- L�schen von create_database.php
-----------------------------------------------------------------------------------------
FERTIG !
-----------------------------------------------------------------------------------------
Zur Anzeige der PageImpressions impression.php aufrufen oder in ein beliebiges HTML-
Dokument mit <?php include ("impression.php") ?> einbinden und die Endung des 
HTML-Dokuments in .php umbenennen. ACHTUNG: Jeder Reload gilt als neue PageImpression 
und treibt den "Counter" in die H�he. Sollen nur tats�chliche Besucher (und eben nicht 
die PageImpressions) gez�hlt werden, muss das Script AZVISITOR verwendet werden.

Das Entfernen von Copyrighthinweisen aus dem Script ist untersagt!

Die Weitergabe dieses Scripts ist erw�nscht und uneingeschr�nkt gestattet.

Viel Spass
