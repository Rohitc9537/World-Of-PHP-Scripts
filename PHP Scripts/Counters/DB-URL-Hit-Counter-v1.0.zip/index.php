
<?php
print "	<HTML>
		<HEAD>
		<TITLE>DB URL Hit Counter</TITLE>
			<style>
			body, td, th, form, input, textarea, select {
				color: #000000;
				font-family: Verdana, Arial, Helvetica, sans-serif;
				font-size: 11px;
			}
			
			.copyright {
				font-family: Verdana, Arial, Helvetica, sans-serif;
				font-size: 10px;
			}
			</style>
		<BODY>";
print "	<table width='400' align='center' style='border-style: solid; border-width: 1px;' bordercolor='#992A2A' bgcolor='#F2DDDD'>
		  <tr>
			<td><strong>Error:</strong></td>
		  </tr>
		  <tr>
			<td><p>You do not have permission to view the contents of this directory. Please
			click the back button on your browser to return where you can from. You may
			view the current statistics <a href='linker.php?stats'>here</a>.</p><p>
			Powered by <a href='linker.php?url=http://www.demonboard.co.uk'>DB URL Hit Counter</a></p></td>
		  </tr>
		</table><br>";
print "	</BODY>
		</HEAD>
		</HTML>";
?>