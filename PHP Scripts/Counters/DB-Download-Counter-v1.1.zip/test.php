<HTML>
<HEAD>
<TITLE>DB Download Counter Test Script</TITLE>
</HEAD>
<BODY>

<font face="Verdana" size="2"><b>Download Counter Test</b>
<?php
include "download.php";
$download = new download( "http://www.demonboard.co.uk/scripts/dcounter/DB-Download-Counter-v1.1.zip", "DB_Download_Counter", "Click the above button to download DB Download Counter for free!" );
?>
</font>

</BODY>
</HTML>
<!---
(C) 2004 Demon Board Ltd. All Rights Reserved.
Please see Read Me.txt for more information on how to use the script!
--->