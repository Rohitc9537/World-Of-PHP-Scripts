++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+                                                                              +
+                     Silentum Counter v.1.0.3 Readme File                     +
+                                                                              +
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
0. Table of Contents
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
0. Table of Contents
1. Installation
2. Contact Information
3. Copyright Information

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
1. Installation
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
a. Unzip the files to a location you desire.
b. Add the following line of code to the very top of every page you want the
   counter on:
	<?php include("counter.php"); ?>
   Note that you may need to change the paths of the file.
c. Now where you want the counter to appear on the page, add the following
   line of code:
	<?php echo $total; ?>

You can style the counter however you like using either CSS or (X)HTML.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
2. Contact Information
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
E-mail: hypersilence@hypersilence.net
AOL Instant Messenger: HyperSilence
Support Boards: http://boards.hypersilence.net/index.php
Web Site: http://www.hypersilence.net

Also, if you want to, please rate Silentum Counter at
http://www.hotscripts.com/rate/49674.html
Feedback is always welcome.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
3. Copyright Information
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Silentum Counter is open source, meaning you may edit it as you wish, as long
as you don't remove any of the copyright notices.

Thanks for downloading and enjoy!