/*********************************************************
			This Free Script was downloaded at			
			Free-php-Scripts.net (HelpPHP.net)			
	This script is produced under the LGPL license		
		Which is included with your download.			
	Not like you are going to read it, but it mostly	
	States that you are free to do whatever you want	
				With this script!						
*********************************************************/

Marsal Simple Counter V 2.0 - Database version

This counter will read the count either uniquely or all, information is stored on
the database for a more secure and reliable count.

To use this script, place this code andwhere where you want the form to appear:
<?php @include_once("counter.php");?>

Whats been updated from V 1.0:
1) Code now uses full php implementation, no more javascript
2) Works on all browsers and systems
3) Code is much eaiser to read, understand or change

We hope that you like our script, please remember to visit us at: www.helpphp.net or free-php-scripts.net
we are ready for your questions, not only relating to this script but to coding in general.

FPS Inc.,