<?

//This variable tells CowCounter what Counter Names are avalible and what are not.  This is here so that nobody comes and starts to create their own counters using your site.  Make sure that you say here what names are valid so that CowCounter knows that its real.  These names are CASE INSENSITIVE.

$Enabled_Counters = array("CowMail", "MainPage");



?>