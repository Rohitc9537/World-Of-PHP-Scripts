<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
<p>This is  a test page for our counter, this counter can be used in text or graphics  mode.</p>
<p><strong>Instructions:</strong></p>
<p>If you do not require the count to start at 0 open the counter_data.txt file and enter the value you require.<br>
  Upload all files in the zip file as is . This will create a directory called digits with 4 sub-directories called 1 , 2 , 3 and 4.<br>
  CHMOD the counter_data.txt file to 755.
</p>
<p>To include this on a page use the following syntax</p>
<p>&lt;?php include(&quot;counter.php&quot;); ?&gt;</p>
<p><strong>Example : </strong></p>
<p>
<?php include("counter.php"); ?>
</p>
</body>
</html>
