This file was distributed with maxers stats counting script from- http://scripts.maxersmix.com 

for installation information check install.html in any reuptable browser (lynx or firefox)

This is distributed under GPL (see the file titled LICENSE for more details)

for updates and bug tracking check out http://scripts.maxersmix.com

thanks for using my script!!