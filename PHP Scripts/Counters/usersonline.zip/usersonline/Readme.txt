Script by RAZORE


Install Instructions

1) Unzip the distribution file into your http documents directory.
2) Create the MySQL Database (usually phpUseronline) with your MySQL Admin.
3) Use phpMyAdmin or other MySQL program to run the SQL file called 'sql.sql' in this folder.
4) Edit the variables in useronline.php to match your database details