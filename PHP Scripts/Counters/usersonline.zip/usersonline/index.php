<?php 
//This file shows you how to include the file in your php document.


include("online.php"); 
?>