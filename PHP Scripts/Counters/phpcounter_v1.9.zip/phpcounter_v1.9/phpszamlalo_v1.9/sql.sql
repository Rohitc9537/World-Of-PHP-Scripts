# //----------------------------------------//
# //             Php Counter v1.9           //
# //             Creator: Tivadar           //
# //              2005 september            //
# //                                        //
# //                                        //
# // E-mail: info@tivadar.tk                //
# // MSN: msn@tivadar.tk                    //
# // Web: www.tivadar.tk                    //
# //----------------------------------------//

CREATE TABLE `szamlalo` (
`szam` INT(255) default '0',
`szam_l` INT(255) default '0'
);

INSERT INTO `szamlalo` VALUES (0,0);
