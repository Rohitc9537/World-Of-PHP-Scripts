<?php include("counter.php"); ?>

<?php include("counter.txt"); ?> people visited this page