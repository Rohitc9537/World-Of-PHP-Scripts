RTCounter ver 0.1

This script is a very simple php counter that doesn't requires mysql and keeps track of 
how many unique pageviews your site has.

INSTALLATION

1. In the page where you want to run your script write the following line of code as show in index.php:
   <?php include("/path_to/counter.php"); ?> on the top of the page   
   <?php include("counter.txt"); ?> where you want to show the number of pageviews
2. Upload all files

If you have any comment or critic please write me(webmaster@toldo.info)