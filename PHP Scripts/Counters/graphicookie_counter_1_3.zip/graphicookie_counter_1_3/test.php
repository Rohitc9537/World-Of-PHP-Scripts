<?php include("counter.php"); ?>
<HTML>
<BODY>

Counter: <?php echo $gcc_hits; ?>

</BODY>
</HTML>