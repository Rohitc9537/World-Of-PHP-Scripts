ChrisCount (Free) - 1.0

Whats New?



INSTALLATION

upload files to a web directory and chmod acc to 777 (to allow read write access)

then insert a php include command on your main entry page.

Questions?

email chris@chris-s.co.uk



Usage

You may modify this script as you wish, but please leave a link to chris-s.co.uk






Chris
x


Chris-s.co.uk

