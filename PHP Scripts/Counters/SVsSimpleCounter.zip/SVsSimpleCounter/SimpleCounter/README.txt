SVs Simple Counter v1.4
(c)SecondVersion (also known as Version2) www.secondversion.com

-----SECTIONS-----
1.) Included files
2.) Installing
3.) Usage
4.) Warning
5.) Help
6.) License
------------------

1.) Included Files
- counter.php
- counter.txt
- README.txt
- TODO.txt
- CHANGELOG.txt
- If you did not get this script from my site, you may not have
- all required files, visit www.secondversion.com to download.

2.) Installing
- To install upload the counter.php and counter.txt files to your server.
- Make sure to upload the counter.php file in ASCII mode.
- CHMOD the file 'counter.txt' to 666 or 777 to make it writable.
- There is a function to automatically reset the counter.
- If you don't want the counter to be reset, open counter.php
- Find, $reset = 1; , And set to 0

3.) Usage
- To use add <?php include("counter.php"); ?> to your page where you want
- the count to be shown.
- The page it is placed on MUST be a .php page.

4.) Warning
- DO NOT EDIT ANYTHING UNLESS WHERE TOLD, IF YOU DO SO IT MAY RESULT IN 
- THE SCRIPT NOT WORKING.
- If you did not download this script off of my site, it is possible
- that you didn't receive all files.
- If so, visit www.secondversion.com to download.
- Always check back at my site for updates to the script.

5.) Help
- If you need help installing this script shoot me an email
- esizemore05@gmail.com

6.) License
- This script is provided free and as-is without warranty.
- To be able to use this script all links to my website, and all
- copyright headers must be left intact.
- You may redistribute my script as long as all files, copyrights
- and links are intact.

That's it, Enjoy!