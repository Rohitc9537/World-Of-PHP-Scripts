<?PHP include("counter/counter.php"); ?>
<html>
<head>
<title></title>
</head>
<body>
<?PHP echo "Total Visitors: $count"; ?>
</body>
</html>
