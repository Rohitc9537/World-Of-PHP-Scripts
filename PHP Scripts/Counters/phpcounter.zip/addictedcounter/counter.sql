CREATE TABLE `counter` (
`counter` INT( 20 ) DEFAULT '1' NOT NULL
) TYPE = MYISAM ;