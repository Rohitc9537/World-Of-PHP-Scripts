
####################################################
Kys Counter Version 1.0  Copyright� 31/07/2003 Kyscorp.tk :::Dark Tranquility
####################################################

==================================================================================
TOS
==================================================================================
* This is a free script, to use it you have to accept the following:
- you may not remove any links to our site in it.
- you may change the layout, the colours and fonts to suit your site.
- you may redistribute it as  is without removing anything (including this readme file) or changing anything.
- you may not sell this script.
- because the program is licensed free of charge, there is no warranty for the program.
- if you appreciate this script make a  donation through Paypal.com to kouanes@planet.tn
- thanks and enjoy
==================================================================================

How To Install ?
____________________________________________________________________

1/ Upload the whole content of this folder but the "readme" file into a folder called "counter" for instance.
2/ CHMOD this directory to 755 (or 777 if error)
3/ Run the "install.php" file and follow the instructions
4/ delete "install.php" once install is complete.
5/ Into your pages you have to insert the following code . Ex : directory is "counter"
<? include("counter/counter.php"); ?>
6/ you may subtitute our gfx by ones of your own.


More Support ?
____________________________________________________________________

Go to the forums: http://www.kyscorp.neoartists.net/board/index.php



####################################################
Contact us: kouanes@planet.tn or through the website http://www.kyscorp.tk
Support forums: http://www.kyscorp.neoartists.net/board/index.php
Script Written with: Scriptomania visit: http://www.scriptomania.tk
####################################################
