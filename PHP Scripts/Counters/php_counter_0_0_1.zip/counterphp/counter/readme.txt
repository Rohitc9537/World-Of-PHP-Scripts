---Include counter.php into your Website---
This is simple, just include it into the page, like this:
<?php include 'counter.php'; ?>

You might need to refresh the page to see your first hit!

---Does this script require anything?---
No, it only needs the 2 files, counter.php and logger.txt in order to run, note that
it's case sensitive. 

You are free to change the name of any such files, but you must leave the copyright notice 
inside counter.php or whatever name you gave it.

---I need help still---
No, problem I am here 24/7 to help you with your needs.
Contact me at software@jivenetworks.info

---Where can I recieve updates---
Updates are usually done every 2 months, so make sure you check for this scripts update every
so often. Go to: http://www.jivenetworks.info

---License Agreement---
simplePHP Count is licensed under the terms and conditions of our free to use software license: Standard Public License
You must agree to the license in order to use this software in any form.
http://www.jivenetworks.info/software/license/freeware/