
To include the number of hits into your page, copy the files hits.php and hits.txt into your website folder then add the following line of code:
<?php include 'hits.php'; ?>

Copyright (C) 2005 Abbas Alafoo

Distribution and registration:
The file is Copyrighted (c) by Abbas Alafoo. Permission for non commercial use of
"alafoo simple hits countr" is granted without fee. Permission is also granted for
non commercial redistribution of the script under the condition no changes are made
in the code nor the copyright statement.

Please send your comments, suggestions and report errors to the following Email address:
admin@website-hostings.net

Licensed under the terms of the GNU Lesser General Public License:
http://www.opensource.org/licenses/lgpl-license.php