<p>&nbsp;</p></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><div align="center"><font color="#999999" size="-2">My DataBook copyright &copy; 2003 Toby Davis All Rights Reserved</font></div></td>
  </tr>
</table>
</body>
</html>

<?php
mysql_close($CONNECT);

?>