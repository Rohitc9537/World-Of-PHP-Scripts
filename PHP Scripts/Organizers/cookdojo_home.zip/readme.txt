Cookdojo Home Edition - Web Based Version
Recipe Management Software
ver 1.12

- Before you use this program, please read /docs/term_of_use.txt first!
- Read /docs/installing.txt for manual installation. 