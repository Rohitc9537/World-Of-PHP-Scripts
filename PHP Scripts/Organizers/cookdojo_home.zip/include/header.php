<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Free Online Web Based Cooking Recipe Software</title>
<link href="style/style.css" rel="stylesheet" type="text/css">
<meta name="SOFTWARE_NAME" content="CookDojo Home Edition - Web Based Version">
<meta name="SOFTWARE_VERSION" content="1.12">
<script  type="text/javascript" language="javascript">
	function confirmLink(msg)
	{
	 	var is_confirmed = confirm(msg)
	 	return is_confirmed; 
	}
</script>
</head>

<body bgcolor="#3A6EA5">

<div align="center">
  <center>
  
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="780" id="AutoNumber1" height="100%">
    <tr>
      <td width="100%"><center><a href='../../index.php'><font color=white face=verdana size=1>Back to COOKDOJO.COM Homepage</font></a></center>
      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
        <tr>
          <td width="100%">
          <img border="0" src="images/design_01.jpg" width="780" height="27"></td>
        </tr>
        <tr>
          <td width="100%">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber3" background="images/back_1.jpg">
            <tr>
              <td width="2%">
              <img border="0" src="images/design_02.jpg" width="10" height="45"></td>

              <td width="85%"><a 
              href="index.php" onmouseover="document['home'].src='images/button/home_b.jpg'" onmouseout="document['home'].src='images/button/home_a.jpg'"><img 
              name=home alt="Home" border="0" src="images/button/home_a.jpg" width="59" height="45"></a><a 
              href="add_new.php?catID=<?php if (isset($catID)) echo $catID ?>" onmouseover="document['add'].src='images/button/add_b.jpg'" onmouseout="document['add'].src='images/button/add_a.jpg'"><img 
              name=add alt="Add new recipe" border="0" src="images/button/add_a.jpg" width="59" height="45"></a><a 
              href="index.php?add=3" onmouseover="document['search'].src='images/button/search_b.jpg'" onmouseout="document['search'].src='images/button/search_a.jpg'"><img 
              name=search alt="Search" border="0" src="images/button/search_a.jpg" width="59" height="45"></a><img border="0" src="images/limiter.jpg" width="4" height="45"><a 
              href="http://www.cookdojo.com" target=_blank onmouseover="document['web'].src='images/button/web_b.jpg'" onmouseout="document['web'].src='images/button/web_a.jpg'"><img 
              name=web alt="WebPage" border="0" src="images/button/web_a.jpg" width="59" height="45"></a><a 
              href="export.php" onmouseover="document['export'].src='images/button/export_b.jpg'" onmouseout="document['export'].src='images/button/export_a.jpg'"><img 
              name=export alt="Export to E-book" border="0" src="images/button/export_a.jpg" width="59" height="45"></a></td>
              <td width="13%" align="right">
              <a href="about.php">
              <img border="0" src="images/design_04.jpg" alt="About Cookdojo Home Edition - Web Based Version" width="81" height="45"></a></td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td width="100%">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4" bgcolor="#D8DDDF">
            <tr>
              <td width="39%">
              <a target="_blank" href="http://www.cookdojo.com">
              <img border="0" src="images/design_05.jpg" width="285" height="101" alt="CookDojo.Com - Online Cooking Recipe"></a></td>
              <td width="58%" valign="top" background="images/right_4.jpg" align=right class=h4>
              <img border="0" src="images/right_2.jpg" width="483" height="9"><br><br>
<b class="h4"><font color=#222222>dojo</font></b> <span class="dojo">[d&#7763; j&#333;]</span>
<br><font color=#222222>a place (hall / room) for practising martial art (karate, judo, aikido)</font>
</td>
              <td width="3%">
              <p align="right">
              <img border="0" src="images/right_1.jpg" width="12" height="101"></td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td width="100%">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5">
            <tr>
              <td width="33%" background="images/design_08.jpg">
              <img border="0" src="images/design_08.jpg" width="10" height="299"></td>
              <td width="33%" valign="top" bgcolor="#D8DDDF" background="images/right_4.jpg">
              <img border="0" src="images/right_4.jpg" width="758" height="2"><br>
    