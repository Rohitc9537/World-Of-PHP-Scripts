</td>
              <td width="34%" background="images/right_3.jpg">
              <img border="0" src="images/right_3.jpg" width="12" height="192"></td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td width="100%" height="28" background="images/design_10.jpg">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber6" height="100%">
            <tr>
              <td width="83%">&nbsp;</td>
              <td width="14%" align="center" class="h5"><?php echo date("M d, Y"); ?></td>
              <td width="3%">&nbsp;</td>
            </tr>
          </table>
          </td>
        </tr>
      </table><center><a href='../../index.php'><font color=white face=verdana size=1>Back to COOKDOJO.COM Homepage</font></a></center>
      </td>
    </tr>
  </table>
  
  </center>
</div>

</body>

</html>