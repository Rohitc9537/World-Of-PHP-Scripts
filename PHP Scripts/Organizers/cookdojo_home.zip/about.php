<?php
	include ('include/header.php');
	echo "<br><br><iframe id='datamain' src='about_s.php' width=755 height=195 marginwidth=0 marginheight=0 hspace=0 vspace=0 frameborder=0 scrolling=no></iframe>";
	include ('include/footer.php');
?>