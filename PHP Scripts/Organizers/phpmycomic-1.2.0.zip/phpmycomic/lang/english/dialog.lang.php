<?php

// Dialog Confirmation Box
$tpl->assign("lang_head_confirm", "Confirmation");
$lang_confirm_msg_01 = "The program settings was successfully changes!<br /><br />Returning to admin in 2 seconds";
$lang_confirm_msg_02 = "Personal settings was successfully changes!<br /><br />Returning to admin in 2 seconds";
$lang_confirm_msg_03 = "The import operation was successful!<br /><br />Returning to admin in 2 seconds";
$lang_confirm_msg_04 = "The selected issues has been deleted from database!<br /><br />Returning to admin in 2 seconds";

// Dialog Delete Box
$tpl->assign("lang_head_delete", "Deletion");
$lang_delete_msg_01 = "Are you sure you want to delete this series?<br />Deleting this series title will delete all issues related to this title";
$lang_delete_msg_02 = "Are you sure you want to delete this artist?<br />This will remove the artist link from any comic with this artist";
$lang_delete_msg_03 = "Are you sure you want to delete this issue?";
$lang_delete_msg_04 = "";
$lang_delete_msg_05 = "";
$lang_delete_msg_06 = "";

?>