<?php

$tpl->assign("lang_head_about", "About");
$tpl->assign("lang_contact", "Contact Author");
$tpl->assign("lang_license", "PhpMyComic License");
$tpl->assign("lang_theme", "Current Theme");
$tpl->assign("lang_version", "version");

?>