<?php

$tpl->assign("lang_head_artlink", "Add An Artist To Comic");
$tpl->assign("lang_comic_info", "Comic Info");
$tpl->assign("lang_add_artist", "Add");

$tpl->assign("lang_comic_name", "Comic title and issue number");
$tpl->assign("lang_comic_story", "Story title");
$tpl->assign("lang_select_artist", "Select an artist");

?>