<?php

$tpl->assign("lang_user_pass", "Username & Password");

?>