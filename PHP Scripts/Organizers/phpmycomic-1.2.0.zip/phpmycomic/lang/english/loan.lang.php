<?php

$tpl->assign("lang_head_loan", "Loan This Comic");
$tpl->assign("lang_comic_info", "Comic Info");
$tpl->assign("lang_loan_info", "Loan Info");

$tpl->assign("lang_comic_name", "Comic title and issue number");
$tpl->assign("lang_comic_story", "Story title");
$tpl->assign("lang_lend_name", "Loan this comic to");
$tpl->assign("lang_lend_notes", "Other notes");
$tpl->assign("lang_lend_date", "Loan date");
$tpl->assign("lang_lend_due", "Due return date");

$tpl->assign("lang_button_loan", "Loan");

?>