<?php

//////////////////////////////////////////////////////////////
//
//     Language:      Norwegian
//     Version:       1.2.0
//     Made by:       Endre Myrvang
//     EMail          bstar@dustrium.net
//
//////////////////////////////////////////////////////////////

$langname     = "English";

$langauthor   = "Endre Myrvang";

$langmail	  = "bstar@dustrium.net";

?>