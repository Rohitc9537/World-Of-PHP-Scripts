<?php

//////////////////////////////////////////////////////////////
//
//     Theme:         Artic Theme
//     Version:       1.2.0
//     Made by:       Endre Myrvang
//     EMail          bstar@dustrium.net
//
//     NOTES
//     This is the new Artic theme based on the 
//	   the default theme.
//
//////////////////////////////////////////////////////////////

$themename     = "Artic Theme";

$skinversion   = "1.2.0";

$themeauthor   = "Endre Myrvang";

$authormail	   = "bstar@dustrium.net";

?>