<?php

//////////////////////////////////////////////////////////////
//
//     Theme:         Default
//     Version:       1.1.6
//     Made by:       Endre Myrvang
//     EMail          bstar@dustrium.net
//
//     NOTES
//     This is the default theme for PhpMyComic. This theme
//     is included with all copies of the program
//
//////////////////////////////////////////////////////////////

$themename     = "Default";

$skinversion   = "1.1.6";

$themeauthor   = "Endre Myrvang";

$authormail	   = "bstar@dustrium.net";

?>