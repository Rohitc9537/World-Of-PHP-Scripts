<html>
<head><title>Cover View</title></head>
<body topmargin="0" leftmargin="0">

<?php print("<img src='". $_GET['image'] ."'>"); ?>

</body>
</html>