<?PHP
##########################################################################  
#                                                                        #
# Request It : Song Request System                                       #
# Version: 1.0b                                                          #
# Copyright (c) 2005 by Jonathan Bradley (jonathan@xbaseonline.com)      #   
# http://requestit.xbaseonline.com                                       #         
#                                                                        #
# This program is free software. You can redistribute it and/or modify   #
# it under the terms of the GNU General Public License as published by   #
# the Free Software Foundation; either version 2 of the License.         #
#                                                                        #
##########################################################################
?>
<?php include ("../includes/header.php") ?>
<p><img src="../images/logo.jpg"></span></p>
<p class="phpmaker" style="margin-left:70;"> SYSTEM ADMINISTRATOR SET UP </p>
<p>&nbsp;</p>
<p class="phpmaker" style="margin-left:20;">
 Admin has been set up.  Please delete the uninstall<br />
 directory.  You are are now able to proceed with <br />
 utilizing this program.</p>
<?php include ("../includes/footer.php") ?>
