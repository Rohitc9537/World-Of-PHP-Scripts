<?PHP
##########################################################################  
#                                                                        #
# Request It : Song Request System                                       #
# Version: 1.0b                                                          #
# Copyright (c) 2005 by Jonathan Bradley (jonathan@xbaseonline.com)      #   
# http://requestit.xbaseonline.com                                       #         
#                                                                        #
# This program is free software. You can redistribute it and/or modify   #
# it under the terms of the GNU General Public License as published by   #
# the Free Software Foundation; either version 2 of the License.         #
#                                                                        #
##########################################################################
?>
<p>&nbsp;</p>
<table border="0" cellspacing="0" cellpadding="0" width=330>

<tr><td class="phpmaker" align=center>
<p>&nbsp;</p>
Written and Copyright &copy 2005 <a href="http://www.xbaseonline.com">Jonathan Bradley</a>.<br />
Powered by: <a href="http://requestit.xbaseonline.com">Request It v1.0</a>
</td></tr></table>
</td></tr></table>
</body>
</html>
