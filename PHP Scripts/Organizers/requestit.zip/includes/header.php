<?PHP
##########################################################################  
#                                                                        #
# Request It : Song Request System                                       #
# Version: 1.0b                                                          #
# Copyright (c) 2005 by Jonathan Bradley (jonathan@xbaseonline.com)      #   
# http://requestit.xbaseonline.com                                       #         
#                                                                        #
# This program is free software. You can redistribute it and/or modify   #
# it under the terms of the GNU General Public License as published by   #
# the Free Software Foundation; either version 2 of the License.         #
#                                                                        #
##########################################################################
?>
<html>
<head>
	<title> [ Request us to play you a song ] </title>
	<style type="text/css">
	<!--
 	INPUT, TEXTAREA, SELECT {font-family: Verdana; font-size: xx-small;}
	.phpmaker {font-family: Verdana; font-size: xx-small;}

A {
	FONT-FAMILY:Verdana, Arial, Helvetica, sans-serif;
	COLOR: #000000; 
	TEXT-DECORATION: none
}
A:hover {
	COLOR: #000000; BACKGROUND-COLOR: 
	#c7d4ca; TEXT-DECORATION: none
}

	-->
	</style>
</head>
<body bgcolor="#FFFFFF" text="000000" leftmargin="0" topmargin="0" marginheight="0" marginwidth="0">
<table width="750" height="100%" border="0" cellspacing="0" cellpadding="10">

<tr>
<td valign=top>
