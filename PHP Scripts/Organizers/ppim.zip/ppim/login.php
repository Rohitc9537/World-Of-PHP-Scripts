<?php require("templates/header.html"); ?>
<style>
#warning {
		 font: bold 12pt tahoma;
		 color: #CC4444;
}
</style>
</head>
<body>
<?php require("templates/menu.html"); ?>
<div id="frame_middle">
	 <div id="frame_top_line">
	 </div>
	 <div id="frame_left">
<!-- ***************** Left Side  ***************** -->  


 	 </div>

<!-- ***************** Right Side  ***************** -->  
	 <div id="frame_right">
	 <div align="center">
	 <div id="lock">
	 </div>


<?php
require('login_source.php');
?>
  	 </div>
	 </div>  
</div>
</div>
<div id="frame_bottom">
</div>
<?php require('templates/footer.html');?>