pPIM - Phlatline's Personal Information Manager
Version 1.0
Version Date: December 4 2004
http://ppim.phlatline.org

Special Thanks to:
Foood for use of his icons - www.foood.net (Permision Granted)
and Michael Gonzalez for inspiring Enhanced theme with his LHA msstyle - www.enhancedlabs.com (Permision Granted)


Installation Instructions
-------------------------
1. Download pPIM.zip
2. Unzip all files with their path.
3. Upload to server.
4. Set read, write, and execute rights for the folder you uploaded the files to.
5. Run setup.php


Updates from 0.040926
---------------------
Added Simple Email Checker
Added Calendar
Added Events
Added New Theme
Changed Images (Icons) to use Foood's (Permission Granted from Foood)
Added Multiple Notes
Added Auto Check for Updates
Fixed Invalid Character in Titles Error
Fixed Invalid Character in non titles Error

