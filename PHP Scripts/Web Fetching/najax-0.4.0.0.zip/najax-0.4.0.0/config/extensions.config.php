<?php
/**
 * NAJAX Extensions Configuration file.
 *
 * This file contains the list of the installed
 * extensions.
 * 
 * @author	Stanimir Angeloff
 *
 * @package	NAJAX
 *
 * @version	0.4.0.0
 *
 */

$najaxExtensions = array();

$najaxExtensions[] = 'html';

?>