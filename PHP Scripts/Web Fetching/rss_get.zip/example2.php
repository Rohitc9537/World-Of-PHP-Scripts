<HTML>
<head> <title> My RSS Feed </title> </head>
<body>

<?

$url = "http://games.slashdot.org/games.rss"; //URL for Slashdot Games
$displayname = "Slashdot | Games"; 
$number = 3;
include 'rss_get.php';

?>

</body>
</html>