<head>
<style>
<!--
.displayname  { font-family: Verdana; color: #000080; font-weight: bold; 
               border-top: 2px solid #000000; border-bottom: 2px solid #000000 }
.update      { font-family: Comic Sans MS; font-size: 8pt; font-weight: bold; 
               border-left-style: solid; border-left-width: 1px; 
               border-right-style: solid; border-right-width: 1px; 
               border-top-width: 1px; border-bottom-width: 1px }
.headlinellink { text-decoration: none; font-family:Verdana; font-size:8pt; font-weight:bold }
:hover.headlinellink { text-decoration: none; font-size:10pt; font-family:Verdana; font-style:italic; font-weight:bold }

-->
</style>


<?
$url = "http://www.wilwheaton.net/mt/index.xml";
$displayname = "WilWheaton.net - WWdN";
$number = 10;
include "rss_get.php";
?>