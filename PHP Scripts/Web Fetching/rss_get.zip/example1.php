<HTML>
<head> <title> My RSS Feed </title> </head>
<body>

<?

include 'rss_get.php';

?>

</body>
</html>