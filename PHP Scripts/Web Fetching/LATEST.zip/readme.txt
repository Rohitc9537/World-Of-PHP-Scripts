JMan's Bedpan -- Castoff's of an Ill Mind
=========================================



Installation:
-------------

Extract the files from the ZIP archive to your webserver, and configure as necessary.



UnInstallation:
---------------

Delete the files.



Contact:
--------

E-mail: jman@bedpan.ca
Web: http://www.bedpan.ca