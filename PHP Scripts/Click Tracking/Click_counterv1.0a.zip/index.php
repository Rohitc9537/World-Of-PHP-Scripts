<?php
// *************************************************************************************************
// Title: 			PHP AGTC-Click Counter v1.0a
// Developed by: 	Andy Greenhalgh
// Email:			andy@agtc.co.uk
// Website:			agtc.co.uk
// Copyright:		2005(C)Andy Greenhalgh - (AGTC)
// Licence:			GPL, You may distribute this software under the terms of this General Public License
// *************************************************************************************************
//
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>PHP AGTC-Click Counter v1.0a</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body><table width="80%"  border="1" align="center" cellpadding="10" cellspacing="0" bordercolor="#ff9900">
<td bgcolor="#666666"> 
<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" class="header"><div align="center">
      <h3>PHP AGTC-Click Counter v1.0a</h3>
    </div></td>
  </tr> 
</table>
<table width="100%"  border="0" align="center" cellpadding="4" cellspacing="0">
  <tr>
    <td align="left" valign="top"><?php include"center.php" ?></td>
  </tr>
</table>
 </td>
</table>
<br>

<div align="center" class="smallred"><a class="smallred" href="http://www.agtc.co.uk">Copyright 2005 &copy;PHP AGTC-Click Counter v1.0a</a></div>
</body>
</html>
