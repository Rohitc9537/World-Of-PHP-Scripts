<?
// Anti Hack
if(!stristr($_SERVER["PHP_SELF"], "admin.php")) header("Location: index.html");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Fast Click SQL</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <style type="text/css"><!--
  body {font-family : Verdana, Arial, Helvetica, sans-serif;}
  -->
  </style>    
</head>
<body bgcolor="#FFFFFF" text="#000000" style="margin-top: 5px;">
<table border="0" cellpadding="2" width="80%">
  <tr>
    <td width="100%">
      <p><font size="4">Database</font></p>
      <hr>
      <p><font size="2">All the information in Fast Click SQL is stored
      in an SQL database. The Database screen provides a quick easy 
      way to access the main tables in Fast Click SQL: Links and Categories. 
      From there you can quickly add new records, change and check exists 
      records. </font></p>
      <p><font size="2">You'll also find a number of tools to help 
      keep your database in check.</font></p>
      <p>&nbsp;
    </td>
  </tr>
</table>
</body>
</html>