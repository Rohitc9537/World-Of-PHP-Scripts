<?
// Anti Hack
if(!stristr($_SERVER["PHP_SELF"], "admin.php")) header("Location: index.html");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Fast Click SQL</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <style type="text/css"><!--
  body {font-family : Verdana, Arial, Helvetica, sans-serif;}
  -->
  </style>    
</head>
<body bgcolor="#FFFFFF" text="#000000" style="margin-top: 5px;">
<table border="0" cellpadding="2" width="80%">
  <tr>
    <td width="100%">
      <p><font size="4">Configuration & Tools</font></p>
      <hr>
      <p><font size="2">Fast Click SQL is fully customizable. You 
      may set different options of it. </font></p>
      <p><font size="2">You'll also find tool means assisting to 
      configure and administer your interface, databases and 
      functions of a script.</font></p>
      <p>&nbsp;
    </td>
  </tr>
</table>
</body>
</html>