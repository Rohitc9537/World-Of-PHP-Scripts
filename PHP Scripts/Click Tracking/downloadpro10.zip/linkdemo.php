<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>LinkDemo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>This is an example download page, to demonstrate how to link to download pro supported files, and how to display their counts.</p>
<p><a href="download.php?file=1">Download my file now!</a> [<?php include("http://explodingpanda.com/test/download.php?showme=1");?>] 
Downloads so far. </p>
</body>
</html>
