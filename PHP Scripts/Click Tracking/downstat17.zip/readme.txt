---Down Stat version 1.7--- 
Downstat is a php download counter that runs on text database for files that you want to track.
Choose to have the program guarded by password and username. 
Manually, specifying a text file, or scan a directory for files to be added.
Create categories in the fly, set bandwidth limits, email hit notifications , passwords for files.
Display a download counter  for each file or whole categories any ware on your web pages!
View stats by year, month, day, hour, hosts, browsers, referral sites, or files .
No limit of downloads you can add, many features that you may tweak on a settings page. 

##Upgrading to version 1.7
If  you have used downstat 1.6 and would like to switch over to downstat 1.7 without loosing any data, download 
the  converter at http://www.vmist.net/scripts/downstat.php. 

For instructions on converting,  

Upload "convert_data.php" to where you uploaded downstat 1.7.
Run "convert_data.php", and check "Test to see if my browser and server meet the requirements"
Press the �Submit� button,.
If no errors come, select the �1.6� version. 
Press the �Submit� button

To see all of the things that are new in version 1.7, go to :
http://www.vmist.net/scripts/check_version.php?script=downstat&whatsnew

To see the manual of downstat go to :
http://www.vmist.net/scripts/downstat/manual/manual.php


- Here is what you will need to use Downstat 1.7 -
PHP
Chmod rights
Javascript 5+
Internet Explorer 
( Will not work on some servers )



******Instructions*******
1. download and unzip http://www.vmist.net/scripts/download.php?file=downstat17
2. Unzip all files in the �downstat17.zip� archive
3. Upload all files including the �downstat_art� folder
4. Give �downstat_art/database.php� read and write permissions 
5. go to admin.php in your web browser, login with the username "username" and the password 
"password" you may change this in the settings after a successful login.
( To add a file, type the file path in the place where it says "Address To File" and
press the "Add File" button. This will add the address that you have typed to the database for when a user requests the file. )

6. You will see a title appear below containing stats about the file  that
you have just added.  Clicking on the file ID in the file list will enable you to edit the parameters.

You will notice that the "Hits" will go up each time someone clicks on the download link, click on the 
�All File History� link to see all of latest downloads.

*********




Download url at http://www.vmist.net/scripts/download.php?file=downstat17

Example and homepage at http://vmist.net/scripts/downstat.php
I am not liable for anything that this script will be used for or any server damages due to miss use of these 
scripts.
If you have any questions, comments or problems you may post to the forums at 
http://www.vmist.net/scripts/EForum/index.php