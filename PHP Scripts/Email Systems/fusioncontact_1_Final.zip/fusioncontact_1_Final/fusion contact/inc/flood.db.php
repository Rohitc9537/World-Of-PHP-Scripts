<?php die("You may not access this file."); ?>
