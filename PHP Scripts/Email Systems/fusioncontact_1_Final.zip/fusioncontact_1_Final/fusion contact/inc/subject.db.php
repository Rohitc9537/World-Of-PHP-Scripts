<?php
$sub1="Question";
$sub2="Request";
$sub3="Staff Application";
$sub4="";
$sub5="";
$sub6="";
$sub7="";
$sub8="";
$sub9="";
$sub10="";
$sv1="question";
$sv2="request";
$sv3="staff app";
$sv4="";
$sv5="";
$sv6="";
$sv7="";
$sv8="";
$sv9="";
$sv10="";
?>