<?php
$template='
<table width="400" border="0" cellspacing="0" cellpadding="0">
<tr> 
<td width="60"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{fname1} 
</font></td>
<td width="340"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{field1}  
</font> </td>
</tr>
<tr> 
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{fname2} 
</font></td>
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{field2}</font></td>
</tr>
<tr> 
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">To:</font></td>
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{emails} 
</font></td>
</tr>
<tr> 
<td height="12"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">subject</font></td>
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{subjects}</font></td>
</tr>
<tr> 
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{fname8} 
</font></td>
<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{field8} 
</font></td>
</tr>
<tr> 
<td colspan="2"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">{submit}</font></div></td>
</tr>
</table>


';
?>