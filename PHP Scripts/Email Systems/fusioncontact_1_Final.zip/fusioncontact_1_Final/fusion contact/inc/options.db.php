<?php
$skin="fusionwave";
$floodtime="60";
?>