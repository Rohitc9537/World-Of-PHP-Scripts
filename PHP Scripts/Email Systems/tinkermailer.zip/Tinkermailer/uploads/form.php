<form action="mailer.php" method="post"> 
<table width="50%" border="0" cellspacing="1" class="tablestyle" cellpadding="1" align="center">
<tr><td>Name:</td>
<td><input type="text" name="name" size="50">
</td>
</tr>
<tr> 
<td>Email: </td>
<td> 
<input type="text" name="email" size="50">
</td>
</tr>
<tr> 
<td>Site Url: </td>
<td> 
<input type="text" name="siteurl" size="50">
</td>
</tr>
<tr> 
<td>Site Name: </td>
<td> 
<input type="text" name="sitename" size="50">
</td>
</tr>
<td>Comments: </td>
<td>
<textarea name="comments" cols=38 rows="7"></textarea>
</td>
</tr>
<tr><td colspan="2"><center><input type="submit" value="Submit">&nbsp;&nbsp;<input type="reset" value="Try again"></center></td></tr>
<tr><td colspan="2"><br /><center>Powered By: <a href="http://www.sugartonic.com/" target="_blank">TinkerMailer</a>. &copy 2005 <a href="http://www.sugartonic.com/" target="_blank">Sugartonic</a>.</td></tr>
</table></form>
<br />
