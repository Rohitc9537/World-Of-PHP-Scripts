<?php
// Edit the Following to fit your needs
$youremail='your email here';
$headers = "From: $name <$email>\n";
$subject= 'subject Line'; 
// Do not Edit
$message = "$comments, $siteurl, $sitename";
?>
