
 ####### #######  #   # #  # ##### ####  #   #  ##  ##### #     ##### ####
    #       #     ##  # # #  #     #   # ## ## #  #   #   #     #     #   #
    #       #     # # # ##   ##### ####  # # # ####   #   #     ##### ####
    #       #     #  ## # #  #     #   # #   # #  #   #   #     #     #   #
    #    #######  #   # #  # ##### #   # #   # #  # ##### ####  ##### #   #

//////////////// Installion //////////////////

1. Unzip the file. :-)

2. Open uploads/config.php and edit the needed information.

3. Save uploads/config.php

4. Upload form.php. mailer.php, and config.php to your server.

5. Voila! You are ready to have others send you mail.


//////////////// Including into your layout //////////////////

These is simply done with the following php snippet


<?php 
include('form.php'); 
?>
