<?php
require("lang.php");
require("include.php");
echo "<HTML><HEAD><TITLE>$cif_title</TITLE></HEAD><BODY BGCOLOR='#000000'><CENTER><FORM METHOD=POST ACTION='blockaddress.php?option=WRITE'>";
echo $modulo;
echo "</FORM></CENTER></BODY></HTML>";
?>
