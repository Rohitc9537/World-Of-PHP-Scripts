<?php 
require("lang.php");

echo "
<HTML>

<HEAD>
<TITLE>$ereminders_home_page_title</TITLE>
</HEAD>

</BODY>
<CENTER><H1>E*Reminders</H1></CENTER>
<P>
<H3>$home_page_what_this_is_q</H3>
$home_page_what_this_is_a_p1
<P>

$home_page_what_this_is_a_p2 
<P>

<H3>$home_page_can_I_see_it_q</H3>
$home_page_can_I_see_it_a<P>  

<H3>$home_page_bugs_etc_q</H3>
$home_page_bugs_etc_a<P>

<H3>$home_page_where_can_I_get_it_q</H3>
$home_page_where_can_I_get_it_a

</BODY>
</HTML>"
?>
 
