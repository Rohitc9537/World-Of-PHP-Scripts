<?php
#############################################################################
# myAgenda v1.1																#
# =============																#
# Copyright (C) 2002  Mesut Tunga - mesut@tunga.com							#
# http://php.tunga.com														#
#																			#
# This program is free software. You can redistribute it and/or modify		#
# it under the terms of the GNU General Public License as published by 		#
# the Free Software Foundation; either version 2 of the License.       		#
#############################################################################
?>
<center>
<img src="images/bos" width="1" height="2" border="0" alt=""><br>
<table border=0 cellspacing=0 cellpadding=1 width="320" bgcolor="#333333" align="center">
 <tr>
	<td>
	<table border=0 cellspacing=0 cellpadding=0 width="100%" bgcolor="#FFFFFF">
 	 <tr>
		<td>
		 <table border=0 cellpadding=2 cellspacing=2 width="100%">
		 <tr>
			<td bgcolor="#f3f3f3" align="center"><font class="small"><a href="./"><?=$GLOBALS['strHome'];?></a> | <a href="logout.php"><?=$GLOBALS['strLogout'];?></a></font></td>
	 </tr>
	</table>

	</td>
 </tr>
</table>

	</td>
 </tr>
</table>
<table width="320" border="0" cellspacing="0" cellpadding="1" align="center">
 <tr><?# please don't remove the line below?>
 	<td align="center">Copyright � 1998 - 2002 <a href="http://www.tunga.com">Mesut Tunga</a>.</td>
 </tr>
</table>
</center>
</body>
</html>