<?php
#############################################################################
# myAgenda v1.1																#
# =============																#
# Copyright (C) 2002  Mesut Tunga - mesut@tunga.com							#
# http://php.tunga.com														#
#																			#
# This program is free software. You can redistribute it and/or modify		#
# it under the terms of the GNU General Public License as published by 		#
# the Free Software Foundation; either version 2 of the License.       		#
#############################################################################

$GLOBALS['strHome'] = "Ana Sayfa";
$GLOBALS['strBack'] = "Geri";
$GLOBALS['date_format'] = "d-m-Y";
$GLOBALS['time_format'] = "H:i:s";
$GLOBALS['strAdd'] = "Ekle";
$GLOBALS['strUpdate'] = "G�ncelle";
$GLOBALS['strDelete'] = "Sil";
$GLOBALS['strName'] = "Ad";
$GLOBALS['strSurname'] = "Soyad";
$GLOBALS['strEmail'] = "Eposta";
$GLOBALS['strUsername'] = "Kullan�c� Ad�";
$GLOBALS['strPassword'] = "�ifre";
$GLOBALS['strConfirm'] = "tekrar";
$GLOBALS['strSignup'] = "Kay�t";
$GLOBALS['strLogin'] = "Giri�";
$GLOBALS['strSubmit'] = "G�nder";
$GLOBALS['strRegFree'] = "Kay�tl� kullan�c� de�ilseniz, <a href=\"register.php\"><b>buraya</b></a> t�klayarak <b>�cretsiz</b> kay�t olabilirsiniz.";
$GLOBALS['strJSUsername'] = "Kullan�c� ad�n�z� kontrol ediniz.\\nKullan�c� ad�n�z en az 4 en �ok 10\\nkarakter olamal� ve i�erisinde\\n0123456789abcdefghijklmnopqrstuvwxyz.-_\\nharici karakter i�ermemelidir!";
$GLOBALS['strJSPassword'] = "�ifrenizi kontrol ediniz.\\n�ifreniz ad�n�z en az 4\\nen �ok 10 karakter olabilir.";
$GLOBALS['strErrorWronguser'] = "Hatal� kullan�c� ad�/�ifre girdiniz";
$GLOBALS['strErrorTimeout'] = "Zaman a��m�. Tekrar giri� yap�n�z";
$GLOBALS['strErrorUnknown'] = "Bir hata olu�tu.!";


# agenda_add.php
$GLOBALS['strHaveNotes'] = "<b><u>Not:</u></b> <font color=\"#FF0000\">*</font> i�aretli tarihlerde hat�rlatmalar�n�z bulunmaktad�r.";
$GLOBALS['strAddReminder'] = "Hat�rlatma Ekle";
$GLOBALS['strEditReminder'] = "Hat�rlatma D�zenle";
$GLOBALS['strWriteNote'] = "Hat�rlatma notunuzu buraya yaz�n";
$GLOBALS['strMaxNoteChars'] = "En fazla 125 karakter";
$GLOBALS['strRemindBefore'] = "�nce uyar";
$GLOBALS['strFromMyDate'] = "ekledi�im tarihden";
$GLOBALS['strMyThisReminder'] = "Ekledi�im hat�rlatmay�";
$GLOBALS['strError'] = "Hata";
$GLOBALS['strErrorWrongDate'] = "Se�ti�iniz tarih hatal� bir tarih!";
$GLOBALS['strErrorOldDate'] = "Se�ti�iniz tarih ge�mi� bir tarih!";
$GLOBALS['strErrorLackDate'] = "Eksik tarih girdiniz!";
$GLOBALS['strJSNoNote'] = "Not k�sm�n� bo� b�rakamazs�n�z";
$GLOBALS['strJSToomuchChars'] = "125 karakterden fazla not yazamazs�n�z";
$GLOBALS['strSaveRemindOk'] = "Hat�rlatman�z kay�t edildi!";
$GLOBALS['strErrorSqlInsert'] = "Bilgileriniz kay�t edilirken bir sorun olu�tu. L�tfen bu sorunu <a href=\"mailto:$contact_mail\">$contact_mail</a> adresine iletiniz.";

# register.php
$GLOBALS['strJSEnterName'] = "Ad�n�z� giriniz";
$GLOBALS['strJSEnterSurname'] = "Soyad�n�z� giriniz!";
$GLOBALS['strJSEnterEmail'] = "Eposta adresini uygun formatta giriniz!";
$GLOBALS['strJSPasswordsNoMatch'] = "Girdi�iniz �ifreler uyu�muyor!";
$GLOBALS['strRepeate'] = "Tekrar";

$GLOBALS['strRegisterOk'] = "<b>Tebrikler!</b><p>Kayd�n�z ba�ar� ile ger�ekle�tirildi. Giri� yapmak i�in <a href=\"login.php\">buraya</a> t�klay�n�z.";
$GLOBALS['strGoLocation'] = "Geldi�iniz yere geri d�nmek i�in l�tfen <a href=\"login.php?location=$location\">t�klay�n�z</a>.";
$GLOBALS['strExistMail'] = "Girdi�iniz eposta adresi ile daha �nce kay�t olunmu�. L�tfen geri gidip farkl� bir eposta adresi giriniz.";
$GLOBALS['strExistUser'] = "Girdi�iniz kullan�c� ad� sistemimizde kay�tl�. L�tfen farkl� bir kullan�c� ad� giriniz.";
$GLOBALS['strWrongMail'] = "Girdi�iniz mail adresi (".$HTTP_POST_VARS[email].") hatal�. L�tfen geri gidip tekrar giriniz.";
$GLOBALS['strReminderUpdated'] = "Hat�rlatman�z g�ncellendi!";
$GLOBALS['strReminderDeleted'] = "Hat�rlatman�z silindi!";



$GLOBALS['strMonthnames'] = array("Ocak", "�ubat", "Mart", "Nisan", "May�s", "Haziran", "Temmuz", "A�ustos", "Eyl�l", "Ekim", "Kas�m", "Aral�k");
$GLOBALS['strWeekdays'] = array("Paz", "Pzt", "Sal", "�r�", "Pr�", "Cum", "Cmt", "Paz");

$GLOBALS['strGo'] = "Git";
$GLOBALS['strLogout'] = "��k��";
$GLOBALS['strPrevious'] = "�nceki";
$GLOBALS['strNext'] = "Sonraki";
$GLOBALS['strMailSubject'] = "Hatirlatma";
$GLOBALS['strMailHeader'] = "Sayin {contact},\n";
$GLOBALS['strMailFooter'] = "Hatirlatiriz,\n{programname}\n" . $myAgenda_url;
$GLOBALS['strConfirm'] = "Bu Kayd� Silmek �stedi�inizden Eminmisiniz ?";
$GLOBALS['strSave'] = "Kaydet";
$GLOBALS['strYes']						= "Evet";
$GLOBALS['strNo']						= "Hay�r";

$GLOBALS['strReminderDate'] = "Hatirlatma Tarihi";
$GLOBALS['strReminderNote'] = "Hatirlatma Notunuz";
$GLOBALS['strMailNextRemindDate'] = "Bir Sonraki Hatirlatma Tarihiniz";
$GLOBALS['strMailReminderSent'] = "Hatirlatmalar Gonderildi";

$GLOBALS['strRemindTypes'] = array(1 => "Hat�rlatma", "Bulu�ma", "Do�um G�n�", "Y�ld�n�m�", "Yemek", "Aktivite", "�deme", "Di�er");
$GLOBALS['strRemindRepeates'] = array(1 => "Sadece Bir Kere", "Her G�n", "Her Hafta", "Her Ay", "Her Y�l");
$GLOBALS['strRemindDays'] = array(1 => "1 G�n", "2 G�n", "3 G�n", "7 G�n");

$GLOBALS['strForgotPass'] = "�ifrenizi mi Unuttunuz?";
$GLOBALS['strSendMyPassword'] = "�ifremi G�nder";
$GLOBALS['strJSEmail'] = "E-Posta Adresini Kontrol Ediniz";
$GLOBALS['strForgotPassEmailSubj'] = "�ifreniz";
$GLOBALS['strForgotPassEmailBody'] = "Merhaba {name}\n\n�ifreniz:\n\n";
$GLOBALS['strForgotPassEmailOk'] = "�ifreniz e-posta adresinize g�nderildi.";
$GLOBALS['strForgotPassEmailError'] = "Girdi�iniz e-posta adresi veritaban�m�zda bulunamam��t�r.";
?>