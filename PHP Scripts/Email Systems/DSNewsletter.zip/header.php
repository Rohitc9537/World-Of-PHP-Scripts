<?php
include("config.php");
?>
<table width="100%" cellspacing=0 border=0 cellpadding=0>
<tr bgcolor="#679767" height="75"><td>
<font color="black" size="7"><b><center><? echo "$name"; ?></center></b></font>
</td></tr>
</table>