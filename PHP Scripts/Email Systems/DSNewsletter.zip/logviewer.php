<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>ID Search</title>
</head>

<body>
<?
include("header.php");
?>

<form action="logs.php" method="POST">
ID: <input name="id" type="text" value=""><br>
<input type="submit" value="View Log">
</form><br><br>

<?
include("footer.php");
?>
</body>
</html>

