<?php
// Catagories
$catlist = "<option>Select a catagory<option>Catagory 1<option>Catagory 2"; // List all your catagories with <option> before each
// General Config
$name = "DS Newsletter 1.0"; // Name of the newsletter
$blurb = "The best freeware newsletter script on the net!"; // A little descriptive blurb about your newsletter that will appear on the main page
$url = "dvondrake.com/newsdemo"; // URL of the site. Used for email and links. DO NOT ADD HTTP://, WWW.! If possible, use subdomains (ie. blah.blah.com instead of blah.com/blah)
$usr1 = "Dvondrake"; // Admin username
$pass1 = "banana"; // Admin password
?>
