<?php

// error_reporting(E_ALL); 

global $dbhost;
global $dbuser;
global $dbname;
global $dbpass;

$dbhost = " ";
$dbuser = " ";
$dbname = " ";
$dbpass = " ";
?>