<?php
/*
Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr http://www.yoopla.net/portailphp/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// MODULE LIENS
$Mod_Liens_PlRecent="10 Altrisiti pi� recenti";
$Mod_Liens_Top="Top 10 Altrisiti";
$Mod_Liens_form_Auteur="Autore";
$Mod_Liens_form_Mail="EMail";
$Mod_Liens_form_Rubrique="Intestazione";
$Mod_Liens_form_Titre="Titolo";
$Mod_Liens_form_Lien="Link";
$Mod_Liens_form_Desc="Descrizione";
$Mod_Liens_JS_Auteur="Il campo Autore deve essere riempito";
$Mod_Liens_JS_mail="Il campo EMail deve essere riempito";
$Mod_Liens_JS_Rubrique="Il campo Intestazione deve essere riempito";
$Mod_Liens_JS_Titre="Il campo Titolo deve essere riempito";
$Mod_Liens_JS_Lien="Il campo Link deve essere riempito";
$Mod_Liens_JS_Desc="Il campo Descrizione deve essere riempito";
$Mod_Lien_inde_Categorie="Tipo";
$Mod_Liens_inde_Date="Data";
$Mod_Liens_inde_Titre="Titolo";
$Mod_Liens_inde_Auteur="Referent";
$Mod_Liens_inde_Clics="Scatti";

?>
