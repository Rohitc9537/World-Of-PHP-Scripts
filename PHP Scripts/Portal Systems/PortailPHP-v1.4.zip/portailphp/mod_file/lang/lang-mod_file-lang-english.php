<?php
/*
Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr http://www.yoopla.net/portailphp/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// MODULE FILE
$Mod_File_Taille="2000000";// maximum file size when upload
$Mod_File_Etiquette="File to upload";
$Mod_File_Etiquette2="Heading";
$Mod_File_Etiquette3="Title";
$Mod_File_Etiquette4="Name";
$Mod_File_Etiquette5="E-mail";
$Mod_File_inde_Date="Date";
$Mod_File_inde_Cat="Headings";
$Mod_File_inde_Titre="Name";
$Mod_File_inde_Fichiers="Files";
$Mod_File_inde_Clics="Hits";
$Mod_File_PostPar="Posted by";
$Mod_File_Le="the";
$Mod_File_Telecharger="Download";
$Mod_File_PlRecent="10 most recent downloads";
$Mod_File_PlLu="10 most clicked downloads";
$Mod_File_JS_Nom="Name field must be filled";
$Mod_File_JS_Email="E-mail field must be filled";
$Mod_File_JS_Monfichier="File field must be filled";
$Mod_File_JS_Titre="Title field must be filled";
$Mod_File_Upload_OK="File upload OK";
$Mod_File_Upload_OK="File could not upload.";
?>
