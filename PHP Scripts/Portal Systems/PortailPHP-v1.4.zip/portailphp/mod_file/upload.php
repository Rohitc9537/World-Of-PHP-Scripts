<?php
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr
 * http://www.yoopla.net/portailphp/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
$chemin = "." ;
$res_file1 = sql_query("SELECT * FROM `$BD_Tab_file_cat` ORDER BY FIC_nom ASC", $sql_id) ;

echo "<img border='0' src='themes/" . $_SESSION["App_Theme"] . "/ico-puce01.gif' />&nbsp;<strong>$Rub_File ($SsRub_File_Proposer)</strong><br /><br />" ;

?>
<script language='JavaScript'>
function valider_formulaire(thisForm)
{
  if (thisForm.nom.value == '')
  {
    alert('<?php echo $Mod_File_JS_Nom ; ?>') ;
    thisForm.nom.focus() ;
    return false;
  }
  
  if (thisForm.email.value == '')
  {
      alert('<?php echo $Mod_File_JS_Email ; ?>') ;
      thisForm.email.focus() ;
      return false;
  }
  
  if (thisForm.monfichier.value == '')
  {
      alert('<?php echo $Mod_File_JS_Monfichier ; ?>') ;
      thisForm.monfichier.focus() ;
      return false;
  }
  
  if (thisForm.titre.value == '')
  {
    alert('<?php echo $Mod_File_JS_Titre ; ?>') ;
    thisForm.titre.focus() ;
    return false;
  }
  
  return true;
}
</script>

<form enctype='multipart/form-data' onSubmit='return valider_formulaire(this)'
      action='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=File-Upload&action=upload&App_Theme=<?php echo $_SESSION["App_Theme"] ; ?>' method='post'>
  <div align='left'>
    <table border='0' cellpadding='0' cellspacing='0' width='600'>
      <tr>
        <td width='155'><?php echo $Mod_File_Etiquette4 ; ?> :(100)</td>
        <td width='445'><input type='text' name='nom' size='50'></td>
      </tr>
      <tr>
        <td width='155'><?php echo $Mod_File_Etiquette5 ; ?> : (25)</td>
        <td width='445'><input type='text' name='email' size='50'></td>
      </tr>
      <tr>
        <td width='155'>
          <input type='hidden' name='MAX_FILE_SIZE' value='<?php echo $Mod_File_Taille ; ?>'>
          <?php echo $Mod_File_Etiquette ; ?> : </td>
        <td width='445'><input type='file' name='monfichier' ></td>
     </tr>
     <tr>
       <td width='155'><?php echo $Mod_File_Etiquette2 ; ?> : (50)</td>
       <td width='445'>
         <select size='1' name='categorie'>
         <?php
         while($row = mysql_fetch_object($res_file1))
         {
             echo "          <option value='" . $row->FIC_nom . "'>" . $row->FIC_nom . "</option>" ;
         }
         ?>
         </select>
       </td>
     </tr>
     <tr>
       <td width='155'><?php echo $Mod_File_Etiquette3 ; ?> : (100)</td>
       <td width='445'><input type='text' name='titre' size='25'></td>
     </tr>
     <tr>
         <td width='155'>&nbsp;</td>
         <td width='445'><input type='submit' value='OK'></td>
     </tr>
   </table>
 </div>
</form>
<?php

if ($action == "upload")
{
     if (move_uploaded_file($_FILES["monfichier"]["tmp_name"], "$chemin/mod_file/upload/" . $_FILES["monfichier"]["name"]))
     {        
         $res_file1 = sql_query("INSERT INTO $BD_Tab_file (FI_date, FI_cat, FI_nom, FI_titre,FI_aut,FI_mail ) VALUES (NOW()," .
                  " '" . AuAddSlashes($categorie)."', '" . AuAddSlashes($_FILES["monfichier"]["name"]) . "', '" .
                  AuAddSlashes($titre) . "'," . " '" . AuAddSlashes($nom)."', '" . AuAddSlashes($email) . "')", $sql_id) ;
         echo "<strong>$Mod_File_Upload_OK</strong>" ;
    }
    else
    {
        echo "<strong>$Mod_File_Upload_NOK</strong>" ;
    } 
}
?>