<?php
/*
Copyright (C) 2002 CLAIRE C�dric cedric.claire@voila.fr http://www.portailphp.com/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/ 

// Vous n'�tes pas authoris� a modifier les logos ni les liens ci dessous !
echo("<br /><font face='Arial' size='1'>");
echo("<a href='http://www.portailphp.com' target='_blank'><img border='0' src='images/logo-pphp.gif' /></a> ");
echo("<a href='http://www.apache.org' target='_blank'><img border='0' src='images/logo-apache.gif' /></a> ");
echo("<a href='http://www.php.net' target='_blank'><img border='0' src='images/logo-php.gif' /></a><br />");
echo("<strong>$App_Me_Titre</strong> a &eacute;t&eacute; construit avec <a href='http://www.portailphp.com' target='_blank'>Portail PHP</a>, distribu� librement sous licence <a href='http://www.gnu.org/home.fr.html' target='_blank'>GNU</a>/<a href='http://www.april.org/gnu/gpl_french.html' target='_blank'>GPL</a>.");
echo("<a href='http://www.portailphp.com' target='_blank'>Portail PHP</a> � 08/2002-11/2005 - <a href='mailto:cedric.claire@voila.fr' target='_blank'>Cedric CLAIRE</a>.");
echo("</font><br />");
?>
