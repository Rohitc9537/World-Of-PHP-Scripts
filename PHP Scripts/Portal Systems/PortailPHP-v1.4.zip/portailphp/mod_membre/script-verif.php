<?php
session_start();
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr
 * http://www.yoopla.net/portailphp/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
// V�rifie si les session PHP sont transmise pas URL et si elles sont
// automatiquement ajout�e
$sid = "" ;

if (get_cfg_var("session.use_cookies") == 0)
{
    if (get_cfg_var("session.use_trans_sid") == 0)
    {
        $sid = SID . "&";
    }
}

// V�rifie si on est en RegisterGlobals = On
$registerGlobalsOn = (get_cfg_var("register_globals") == 1) ;

$chemin="..";

include "$chemin/include/config.php";
include "$chemin/include/" . $_SESSION["App_Langue"] ;
include "$chemin/include/fonctions.php";

$login = AuAddSlashes($_POST["login"]) ;
$pass = $_POST["pass"] ;

if($login == '' || $pass == '')
{
    die(header("Location: $chemin/index.php?" . $sid . "affiche=Admin&erreur=1"));
}

// on recup�re le password de la table qui correspond au login du visiteur
$sql_id = sql_connect($BD_host, $BD_name, $BD_user, $BD_pass) ;

$req = mysql_query("select * from $BD_Tab_user where US_pseudo='$login'") or die("Erreur SQL !<br />" . $sql . "<br />" . mysql_error());

$data = mysql_fetch_array($req);

@mysql_close() ;

if (!$is_gd)
{
    $_SESSION["sc_code"] = "zut !!!" ;
    // Simule un envoie du code
    $_POST[$_SESSION["sc_field_name"]] = $_SESSION["sc_code"] ;
    $_SESSION["sc_time"] = time() ;
}

if (($data['US_pwd'] == md5($pass)) && ($_POST[$_SESSION["sc_field_name"]] == $_SESSION["sc_code"]) && (($_SESSION["sc_time"] + 300) > time()))
{
    $_SESSION["Admin_Nom"] = $data['US_nom'] ;
    $_SESSION["Admin_Mail"] = $data['US_mail'] ;
    $_SESSION["Admin_Pseudo"] = $data['US_pseudo'];
    $_SESSION["Admin_Droit"] = $data['US_droit'];
    $_SESSION["Admin_Img"] = $data['US_img'];
    $_SESSION["Admin_Web"] = $data['US_web'] ;
    $_SESSION["Admin"] = true ;
    $_SESSION["Admin_RegDatel"] = $data['US_regdate'] ;

    die(header("Location: $chemin/index.php?" . $sid . "affiche=Admin"));
}
else
{
    die(header("Location: $chemin/index.php?" . $sid . "affiche=Admin&erreur=1"));
}

if ($registerGlobalsOn)
{
//    session_register('_SESSION') ;
}
?>

