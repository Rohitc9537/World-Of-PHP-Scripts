<?php
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr
 * http://www.yoopla.net/portailphp/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
if (!$_SESSION["Admin"]) die("<strong>INTERDIT</strong>") ;

$res_liens = sql_query("SELECT * FROM $BD_Tab_liens_cat WHERE 1 ORDER BY LIC_nom ASC", $sql_id) ;

echo "<img border='0' src='themes/" . $_SESSION["App_Theme"] . "/ico-puce01.gif' />&nbsp;<strong>$Rub_Liens ($SsRub_Liens_Proposer)</strong><br /><br />" ;
?>
  <script language='JavaScript'>
    function valider_formulaire(thisForm)
    {
      if (thisForm.auteur.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_Auteur ; ?>') ;
        thisForm.auteur.focus() ;
        return false;
      }
      
      if (thisForm.mail.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_mail ; ?>') ;
        thisForm.mail.focus() ;
        return false;
      }
      
      if (thisForm.rub.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_Rubrique ; ?>') ;
        thisForm.rub.focus() ;
        return false ;
      }
      
      if (thisForm.titre.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_Titre ; ?>') ;
        thisForm.titre.focus() ;
        return false ;
      }
      
      if (thisForm.lien.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_Lien ; ?>') ;
        thisForm.lien.focus() ;
        return false ;
      }
      
      if (thisForm.contenu.value == '')
      {
        alert('<?php echo $Mod_Liens_JS_Desc ; ?>') ;
        thisForm.contenu.focus() ;
        return false ;
      }
      
      return true ;
    }
  </script>

<form name='formlienadd' method='post' onSubmit='return valider_formulaire(this)' 
      ACTION='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Admin&admin=Liens-Proposer&action=Liens-Add'>
  <div align='left'>
    <table border='0' cellpadding='0' cellspacing='0' width='600'>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Rubrique ; ?> : (50)</td>
        <td width='400'>
          <select size='1' name='rub'>
          <?php     
            while($row = mysql_fetch_object($res_liens))
            {
                echo "          <option value='" . $row->LIC_nom . "'>" . $row->LIC_nom . "</option>" ;
             }
          ?>
          </select>
        </td>
      </tr>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Auteur ; ?>: (50)</td>
        <td width='400'><input type='text' name='auteur' size='50'></td>
      </tr>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Mail ; ?>: (30)</td>
        <td width='400'><input type='text' name='mail' size='30'></td>
      </tr>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Titre ; ?> : (50)</td>
        <td width='400'><input type='text' name='titre' size='30'></td>
      </tr>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Lien ; ?> : (50)</td>
        <td width='400'><input type='text' name='lien' size='30'></td>
      </tr>
      <tr>
        <td width='200'><?php echo $Mod_Liens_form_Desc ; ?> : (200)</td>
        <td width='400'><input type='text' name='contenu' size='50'></td>
      </tr>
      <tr>
        <td width='200'>&nbsp;</td>
        <td width='400'><input type='submit' value='OK'></td>
      </tr>
    </table>
  </div>
</form>
<?php
if ($action == "Liens-Add")
{
    $res_faq = sql_query("INSERT INTO $BD_Tab_liens (LI_date,LI_aut,LI_mail,LI_rub,LI_suj,LI_lien,LI_cont ) " .
               "VALUES (NOW(),'$auteur','$mail','" . AuAddSlashes($rub) . "','" . AuAddSlashes($titre) . 
               "','" . AuAddSlashes($lien) . "','" . AuAddSlashes($contenu) . "')", $sql_id) or die("$Err_Insert") ;
    echo "<strong>$Mod_Membres_Liens_Add</strong>" ;
}

?>