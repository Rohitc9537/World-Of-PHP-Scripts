<?php
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr
 * http://www.yoopla.net/portailphp/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
if (!$_SESSION["Admin"]) die("<strong>INTERDIT</strong>") ;

echo "<img border='0' src='themes/" . $_SESSION["App_Theme"] . "/ico-puce01.gif' />&nbsp;<strong>$Mod_Membres_Rub_Del_Photo</strong><br /><br />" ;

if (isset($id))
{
    $req = " AND PO_uid='$id'" ;
}
else
{    
    $req = "" ;
}

$res_res1 = sql_query("SELECT * FROM $BD_Tab_photos WHERE 1 $req ORDER BY PO_titre ASC", $sql_id) ;

while($row = mysql_fetch_object($res_res1))
{
    if (!isset($id))
    {
        ?>
        <table>
        <tr>
          <td>
            <a href='index.php?<?php echo $sid ; ?>affiche=Admin&admin=Photo-Del&action=Photo-Del&id=<?php echo $row->PO_uid ; ?>'><img border='0' src='<?php echo $chemin ; ?>/images/ico_trash.gif' alt='<?php echo $Mod_Membres_Rub_News_Del2 ; ?>' /></a>&nbsp;<?php echo $row->PO_titre ; ?></td>
        </tr>
        </table>
        <?php
    }
    
    if ($action == "Photo-Del")
    {
        $res_res2 = sql_query("DELETE FROM $BD_Tab_photos WHERE PO_uid ='$id'", $sql_id) or die("$Err_Supp") ;
        $delete = @unlink("$chemin/mod_photos/photos/$row->PO_code") ;
        $delete = @unlink("$chemin/mod_photos/vignettes/$row->PO_code") ;
        echo "<strong>OK</strong>" ;
    }
}
?>