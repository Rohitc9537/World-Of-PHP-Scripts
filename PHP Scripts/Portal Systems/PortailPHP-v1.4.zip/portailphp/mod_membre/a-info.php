<?php
/*
Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr http://www.yoopla.net/portailphp/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/
if (!$_SESSION["Admin"]) die("<strong>INTERDIT</strong>") ;

echo("<img border='0' src='themes/" . $_SESSION["App_Theme"] . "/ico-puce01.gif' />&nbsp;<strong>$Mod_Membres_Rub_Info</strong><br /><br />");
echo("<br />$Mod_Membres_InfoUser<br /><br />");
echo("<div align='left'>");
echo("  <table border='0' cellpadding='0' cellspacing='0' width='600'>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Nom</strong></td>");
echo("      <td width='450'>" . $_SESSION["Admin_Nom"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Pseudo</strong></td>");
echo("      <td width='450'><a href='mailto:" . $_SESSION["Admin_Mail"] . "'>" . $_SESSION["Admin_Pseudo"] . "</a></td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Mail</strong></td>");
echo("      <td width='450'>" . $_SESSION["Admin_Mail"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Date</strong></td>");
echo("      <td width='450'>" . $_SESSION["Admin_RegDatel"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Droit</strong></td>");
echo("      <td width='450'>" . $_SESSION["Admin_Droit"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Web</strong></td>");
echo("      <td width='450'><a href='" . $_SESSION["Admin_Web"] . "' target='_blank'>" . $_SESSION["Admin_Web"] . "</a></td>");
echo("    </tr>");
echo("  </table>");
echo("</div>");
echo("<br />$Mod_Membres_Info<br /><br />");
echo("<div align='left'>");
echo("  <table border='0' cellpadding='0' cellspacing='0' width='600'>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_Theme</strong></td>");
echo("      <td width='450'>" . $_SESSION["App_Theme"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_Langue</strong></td>");
echo("      <td width='450'>" . $_SESSION["App_Langue"] . "</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_Titre</strong></td>");
echo("      <td width='450'>$App_Me_Titre</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_Version</strong></td>");
echo("      <td width='450'>$App_version</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_Couleur</strong></td>");
echo("      <td width='450'>$App_Couleur</td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_URL</strong></td>");
echo("      <td width='450'><a href='$App_Me_URL' target='_blank'>$App_Me_URL</a></td>");
echo("    </tr>");
echo("    <tr>");
echo("      <td width='150'><strong>$Mod_Membres_Info_UploadLimite</strong></td>");
echo("      <td width='450'>$Mod_File_Taille</td>");
echo("    </tr>");
echo("  </table>");
echo("</div>");
echo("<br />$Mod_Membres_Serveur_Info<br /><br />");

phpinfo();

?>