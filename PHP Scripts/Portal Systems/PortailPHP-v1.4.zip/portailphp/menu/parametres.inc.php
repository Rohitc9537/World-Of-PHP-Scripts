<?php
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric cedric.claire@safari-msi.com
 * http://www.portailphp.com/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
?>
<table width='100%'>
  <tr>
    <td width='100%' class='tabTitre' valign='middle' align='center'>
      <strong><?php echo $Lib_Rub_Param ; ?></strong>
    </td>
  </tr>
  <tr>
    <td  class='tabMenu' valign='top' align='center'>
      <form name='chx_theme' action='<?php echo $_SESSION["Page_Courante"] ; ?>' method='post'>
        <select name='New_Theme'>
        <?php
          $les_themes = dir("./themes") ;

          while ($le_theme=$les_themes->read())
          {
              if (($le_theme != ".") && ($le_theme != ".."))
              {
                  if ($le_theme == $_SESSION["App_Theme"])
                  {
                      echo "<option value=\"$le_theme\" selected>$le_theme</option>" ;
                  }
                  else
                  {
                      echo "<option value=\"$le_theme\">$le_theme</option>" ;
                  }
              }
          }
          
          $les_themes->close() ;
        ?>          
        </select>&nbsp;<input type='submit' value='OK'><br />
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-french' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_fr.png' /></a>
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-english' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_uk.png' /></a>
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-spanish' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_es.png' /></a>
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-italian' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_it.png' /></a>
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-portuguese' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_po.png' /></a>
        <a href='<?php echo $_SESSION["Page_Courante"] ; ?>&New_Langue=lang-dutch' ><img border='0' src='<?php echo $chemin ; ?>/images/flag_du.png' /></a>
        <br />
        <?php echo $Date ; ?>&nbsp;-&nbsp;<strong><?php echo $App_Me_Titre ; ?></strong><br /><?php echo $App_version ; ?>
      </form>  
    </td>       
  </tr>
</table>
