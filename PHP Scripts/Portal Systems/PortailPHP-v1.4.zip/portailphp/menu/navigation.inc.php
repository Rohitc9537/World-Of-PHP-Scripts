<?php
/*******************************************************************************
 * Copyright (C) 2002 CLAIRE C�dric cedric.claire@safari-msi.com
 * http://www.portailphp.com/
 *
 * Modifi� par Martineau Emeric Copyright (C) 2004
 *
 * Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le
 * modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU,
 * telle que publi�e par la Free Software Foundation ; version 2 de la licence,
 * ou encore (� votre choix) toute version ult�rieure.
 *
 * Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE
 * GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou
 * D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence
 * Publique G�n�rale GNU .
 *
 * Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en
 * m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free
 * Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
 *
 * Portail PHP
 * La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire �
 * incorporer son programme dans des programmes propri�taires. Si votre programme
 * est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus
 * int�ressant d'autoriser une �dition de liens des applications propri�taires
 * avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non
 * pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
 ***********************************************************************************/
?>
<table width='100%'>
  <tr>
    <td width='100%' class='tabTitre'  valign='middle' align='center'>
      <strong><?php echo $Lib_Rub_Navig ; ?></strong>
    </td>
  </tr>
  <tr>
    <td width='100%' class='tabMenu'  valign='top' align='left'>
      <table width='100%' border='0'>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>' target='_top'><?php echo $Rub_Home ; ?></a></td>
        </tr>
        <?php
        if ($_SESSION["Admin"])
        {
        ?>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Admin' target='_top'><?php echo $Rub_Membres ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Mon-Profil' target='_top'><?php echo $Mon_Profil ; ?></a></td>
        </tr>
        <?php
        }
        ?>

        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=News' target='_top'><?php echo "$Rub_News</a> ($nbenr)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo "$chemin" ; ?>/index.php?<?php echo $sid ; ?>affiche=News-pluslus' target='_top'><?php echo $SsRub_News_pluslus ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=News-plusrecents' target='_top'><?php echo $SsRub_News_plusrecents ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=File' target='_top'><?php echo "$Rub_File</a> ($nbenr2)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=File-plusclics' target='_top'><?php echo $SsRub_File_plusclics ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=File-plusrecents' target='_top'><?php echo $SsRub_File_plusrecents ; ?></a></td>
        </tr>
        <?php
        if($Aut_File)
        {
        ?>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=File-Upload' target='_top'><?php echo $SsRub_File_Proposer ; ?></a></td>
        </tr>
        <?php
        }
        ?>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Liens' target='_top'><?php echo "$Rub_Liens</a> ($nbenr3)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Liens-top' target='_top'><?php echo $SsRub_Liens_top ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Liens-plusrecents' target='_top'><?php echo $SsRub_Liens_plusrecents ; ?></a></td>
        </tr>
        <?php
        if ($Aut_Liens)
        {
        ?>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Faq' target='_top'><?php echo "$Rub_Faq</a> ($nbenr4)" ; ?></a></td>
        </tr>
        <?php
        }
        ?>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Faq' target='_top'><?php echo "$Rub_Faq</a> ($nbenr4)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Photo-Galerie' target='_top'><?php echo "$Rub_Photos</a> ($nbenr5)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Forum-Lire' target='_top'><?php echo "$Rub_Forum</a> ($nbenr6)" ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01-vide.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Forum-box_aj_me' target='_top'><?php echo $Mod_Forum_Ajouter ; ?></a></td>
        </tr>
        <tr>
          <td witdh='1'><img border='0' src='<?php echo "themes/" . $_SESSION["App_Theme"] ; ?>/ico-puce01.gif' /></td>
          <td width='100%'><a href='<?php echo $chemin ; ?>/index.php?<?php echo $sid ; ?>affiche=Search' target='_top'><?php echo $Rub_Search ; ?></a></td>
        </tr>
        <tr>
          <td colspan='2' align='center'><a href='http://www.portailphp.com'><img border='0' src='<?php echo $chemin ; ?>/images/logo-pphp.gif' /></a></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
