<?php
/*
Copyright (C) 2002 CLAIRE C�dric cedric.claire@safari-msi.com www.portailphp.com
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// LIBELLE DES RUBRIQUES
$Lib_Rub_Navig="<font size=4>N</font>AVIGATIE";
$Lib_Rub_ForumLive="<font size=4>F</font>ORUM <font size=4>L</font>IVE";
$Lib_Rub_WebRing="<font size=4>W</font>EBRING";
$Lib_Rub_Param="<font size=4>P</font>ARAMETERS";
$Lib_Rub_Parten="<font size=4>P</font>ARTNES";
$Lib_Rub_Pinup="<font size=4>P</font>INUP";
$Lib_Rub_News="<font size=4>N</font>EWS";

// LES RUBRIQUES
$Rub_Home="Start";
$Rub_Membres="Admin";
$Rub_Navigation="Navigatie";
$Rub_News="Artikels";
$Rub_Search="Zoeken";
$Rub_File="Downloads";
$Rub_Liens="Links";
$Rub_Faq="FAQ";
$Rub_Forum="Forum";
$Rub_Photos="Foto's";

//LES SOUS RUBRIQUES
$SsRub_News_plusrecents="Meest recent";
$SsRub_News_pluslus="Meest gelezen";
$SsRub_File_Proposer="Suggestie";
$SsRub_File_plusrecents="Meest recent";
$SsRub_File_plusclics="Top 10";
$SsRub_Liens_Proposer="Voorstel";
$SsRub_Liens_plusrecents="Meest recent";
$SsRub_Liens_top="Top 10";

//MESSAGES D'ERREURS
$Err_Serveur="Onmogelijk om met server te verbinden";
$Err_Db="Onmogelijk om verbinding te maken met de database";
$Err_Modif="Wijziging onmogelijk";
$Err_Search="Zoeken niet mogelijk";
$Err_Insert="Invoegen niet mogelijk";
$Err_Supp="Verwijderen niet mogelijk";
$Err_Upload_Chmod="Rechten veranderen niet mogelijk";
$Err_Upload_Move="Schrijven naar server niet mogelijk";
?>
