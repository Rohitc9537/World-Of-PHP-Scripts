<?php
/*
Copyright (C) 2002 CLAIRE C�dric cedric.claire@safari-msi.com www.portailphp.com
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// LIBELLE DES RUBRIQUES
$Lib_Rub_Navig="<font size=4>B</font>ROWSE";
$Lib_Rub_ForumLive="<font size=4>F</font>ORUM <font size=4>L</font>IVE";
$Lib_Rub_WebRing="<font size=4>W</font>EBRING";
$Lib_Rub_Param="<font size=4>P</font>ARAMETERS";
$Lib_Rub_Parten="<font size=4>P</font>ARTNERS";
$Lib_Rub_Pinup="<font size=4>P</font>INUP";
$Lib_Rub_News="<font size=4>N</font>EWS";

// LES RUBRIQUES
$Rub_Home="Home";
$Rub_Membres="Root";
$Rub_Navigation="Browse";
$Rub_News="News";
$Rub_Search="Seek";
$Rub_File="Download";
$Rub_Liens="Links";
$Rub_Faq="FAQ";
$Rub_Forum="Forum";
$Rub_Photos="Pictures";

//LES SOUS RUBRIQUES
$SsRub_News_plusrecents="Most recent";
$SsRub_News_pluslus="Most read";
$SsRub_File_Proposer="Suggest";
$SsRub_File_plusrecents="Most recent";
$SsRub_File_plusclics="Top 10";
$SsRub_Liens_Proposer="Suggest";
$SsRub_Liens_plusrecents="Most recent";
$SsRub_Liens_top="Top 10";

//MESSAGES D'ERREURS
$Err_Serveur="Impossible to connect the server";
$Err_Db="Impossible to connect the data-base";
$Err_Modif="Impossible to modify";
$Err_Search="Impossible to seek";
$Err_Insert="Impossible to insert";
$Err_Supp="Impossible to delete";
$Err_Upload_Chmod="Impossible modify rights";
$Err_Upload_Move="Impossible to write on the server";

$Mod_Membres_Login = "Login" ;
$Mon_Profil = "My profil" ;
?>
