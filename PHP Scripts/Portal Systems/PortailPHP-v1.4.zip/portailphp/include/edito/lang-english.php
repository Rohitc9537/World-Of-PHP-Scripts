<strong><?php echo $App_Me_Titre ; ?></strong> is a project of <strong>CMS</strong> gate wrote entirely in PHP and lunched by <a href='http://www.yoopla.net' target='_top'>Yoopla.Net</a> (CMS means Content Management System).
<br /><br />It is intended to function with MySql. PortailPHP is an ideal tool to conceive dynamic sites quickly.
<br /><br />Portail PHP will improve, we hope for it thanks to the contributions of the Net surfers.
<br /><br />Thank you to send me an e-mall or to add your site in the PortailPHP links if you use PortailPHP for your site.<br /><br />