<?php
/*
Copyright (C) 2002 CLAIRE C�dric cedric.claire@safari-msi.com www.portailphp.com
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// LIBELLE DES RUBRIQUES
$Lib_Rub_Navig="<font size=4>N</font>AVIGATION";
$Lib_Rub_ForumLive="<font size=4>F</font>ORUM <font size=4>L</font>IVE";
$Lib_Rub_WebRing="<font size=4>W</font>EBRING";
$Lib_Rub_Param="<font size=4>P</font>ARAMETRES";
$Lib_Rub_Parten="<font size=4>P</font>ARTENAIRES";
$Lib_Rub_Pinup="<font size=4>P</font>INUP";
$Lib_Rub_News="<font size=4>N</font>EWS";

// LES RUBRIQUES
$Rub_Home="Accueil";
$Rub_Membres="Admin";
$Rub_Navigation="Navigation";
$Rub_News="Articles";
$Rub_Search="Recherche";
$Rub_File="T�l�chargement";
$Rub_Liens="Liens";
$Rub_Faq="FAQ";
$Rub_Forum="Forum";
$Rub_Photos="Phototh�que";

//LES SOUS RUBRIQUES
$SsRub_News_plusrecents="Les plus r�cents";
$SsRub_News_pluslus="Le Top 10";
$SsRub_File_Proposer="Proposer";
$SsRub_File_plusrecents="Les plus r�cents";
$SsRub_File_plusclics="Le Top 10";
$SsRub_Liens_Proposer="Proposer";
$SsRub_Liens_plusrecents="Les plus r�cents";
$SsRub_Liens_top="Le Top 10";

//MESSAGES D'ERREURS
$Err_Serveur="Impossible de se connecter au serveur";
$Err_Db="Impossible de se connecter � la base";
$Err_Modif="Impossible d'effectuer la modification";
$Err_Search="Impossible d'effectuer la recherche";
$Err_Insert="Impossible d'effectuer l'insertion";
$Err_Supp="Impossible d'effectuer la suppression";
$Err_Upload_Chmod="Impossible d'effectuer une modification des droits";
$Err_Upload_Move="Impossible d'ecrire sur le serveur";

$Mod_Membres_Login = "Se connecter" ;
$Mon_Profil = "Mon profil" ;
?>
