<?php
/*
Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr http://www.yoopla.net/portailphp/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// MODULE NEWS
$Mod_News_PostPar="Gepost door";
$Mod_News_Le="op";
$Mod_News_PlRecent="10 meest recente artikels";
$Mod_News_PlLu="10 meest gelezen artikels";
$Mod_News_inde_Date="Datum";
$Mod_News_inde_Sujets="Onderwerp";
$Mod_News_inde_Auteurs="Auteur";
$Mod_News_inde_Lectures="Treffers";
$Mod_News_inde_Categorie="Rubriek";
$Mod_News_Form_Categorie="Rubriek";
$Mod_News_Form_Sujet="Onderwerp";
$Mod_News_Form_Date="Datum";
$Mod_News_Form_Corps="Inhoud (HTML)";
$Mod_News_JS_Categorie="Het veld Rubriek moet ingevuld worden";
$Mod_News_JS_Sujet="Het veld Onderwerp moet ingevuld worden";
$Mod_News_JS_Contenu="Het veld Onderwerp moet ingevuld worden";

?>
