<?php
/*
Copyright (C) 2002 CLAIRE C�dric claced@m6net.fr http://www.yoopla.net/portailphp/
Ce programme est un logiciel libre ; vous pouvez le redistribuer et/ou le modifier conform�ment aux dispositions de la Licence Publique G�n�rale GNU, telle que publi�e par la Free Software Foundation ; version 2 de la licence, ou encore (� votre choix) toute version ult�rieure.
Ce programme est distribu� dans l'espoir qu'il sera utile, mais SANS AUCUNE GARANTIE ; sans m�me la garantie implicite de COMMERCIALISATION ou D'ADAPTATION A UN OBJET PARTICULIER. Pour plus de d�tail, voir la Licence Publique G�n�rale GNU .
Vous devez avoir re�u un exemplaire de la Licence Publique G�n�rale GNU en m�me temps que ce programme ; si ce n'est pas le cas, �crivez � la Free Software Foundation Inc., 675 Mass Ave, Cambridge, MA 02139, Etats-Unis.
Portail PHP
La pr�sente Licence Publique G�n�rale n'autorise pas le concessionnaire � incorporer son programme dans des programmes propri�taires. Si votre programme est une biblioth�que de sous-programmes, vous pouvez consid�rer comme plus int�ressant d'autoriser une �dition de liens des applications propri�taires avec la biblioth�que. Si c'est ce que vous souhaitez, vous devrez utiliser non pas la pr�sente licence, mais la Licence Publique G�n�rale pour Biblioth�ques GNU.
*/

// MODULE NEWS
$Mod_News_PostPar="Scritto da";
$Mod_News_Le="su";
$Mod_News_PlRecent="10 articoli pi� recenti";
$Mod_News_PlLu="10 Articoli pi� letti";
$Mod_News_inde_Date="Data";
$Mod_News_inde_Sujets="Soggetto";
$Mod_News_inde_Auteurs="Autore";
$Mod_News_inde_Lectures="Letture";
$Mod_News_inde_Categorie="Categoria";
$Mod_News_Form_Categorie="Categoria";
$Mod_News_Form_Sujet="Soggetto";
$Mod_News_Form_Date="Data";
$Mod_News_Form_Corps="contenuto (HTML)";
$Mod_News_JS_Categorie="Il campo Categoria deve essere riempito";
$Mod_News_JS_Sujet="Il campo Soggetto deve essere riempito";
$Mod_News_JS_Contenu="Il campo contenuto essere riempito";

?>
