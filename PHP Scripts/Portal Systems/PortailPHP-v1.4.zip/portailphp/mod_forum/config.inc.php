<?php
include "include/config.php";
/* Infos G�n�rales ---------------------------------------------------------------- */
$limit = 10 ;                        // nombre de message � afficher dans la page Index
$align_boxarc = "right";              // alignement de la searchbox (left, center ou right)
$bgcolor_box = "#FFFFFF";             // couleur de fond des champs (uniquement sous IE)
$carac = 50 ;
/* Infos du tableau --------------------------------------------------------------- */
$largeur = "100%";                    // largeur du tableau (pixel ou %)
$align = "center";                    // alignement du tableau
?>