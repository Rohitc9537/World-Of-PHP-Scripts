<?PHP
function template_news($line) {
	global $newcomments, $new_messages, $pHNews;
	$timedate = template_dateformat($line['timestamp']);
	ob_start();
	?>
		<center>
			<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
				<center>
						<table border="0" cellpadding="0" cellspacing="0" align="center">
							<tr>
								<td align="center">
									<b><?=$line['title'] ?></b><br><br>
									<?=$line['body'] ?>
								</td>
							</tr>
							<tr>
								<td align="center">
									<br><BR>
									<small>Message posted by <a href="?mod=view_profile&user=<?=urlencode($line['user']) ?>" onMouseDown="" oncontextmenu="return false" oncontext="return false"><?=$line['user'] ?></a> on <?=gmdate("F dS Y \a\\t h:i a", $timedate); ?>
									<br>
									<?PHP if ($newcomments) { echo png_24_trans($new_messages, "20", "20"); }?>
									<a href="?mod=comments&id=<?=$line['id'] ?>">Comments [ <?=$pHNews->countcomments($line['id']); ?> ]</a>
									<?PHP if ($newcomments) { echo png_24_trans($new_messages, "20", "20"); }?></small>
								</td>
							</tr>
						</table>
					</center>
				<?=closetable() ?>
			</center>
		<?PHP
		$output .= ob_get_contents();
		ob_end_clean();
		return $output;		
}
function template_news_start() {
	ob_start();
	?>
	<center>
		<?=opentable("width=\"100%\"", "width=\"100%\"") ?>
			<center>
			<?=$GLOBALS['FirstMsg'] ?>
			</center>
		<?=closetable() ?>
	<?PHP
	$output .= ob_get_contents();
	ob_end_clean();
	$output .= opentable("width=\"100%\"", "width=\"100%\"");
	$output .= "<br><center>";
	return $output;
}
function template_news_end() {
	return "</center>" . closetable() . "</center>";
}
function template_edit_news(){
	extract($GLOBALS);
	ob_start();
	?>
	<br>
	<center>
	<?=template_news($newsitem) ?>
	<?=opentable("width=\"90%\"","width=\"90%\"") ?>
			<form action="?mod=admin&amod=edit_news&action=submitchanges&id=<?=$newsitem['id'] ?>" method="post" onsubmit="dosubmit()">
			<center>
			<b>Edit News Item</b><br><br>
			<table border=0 align="center" cellspacing="0">
				<tr>
					<td align="center">
						<table border=0 align=center cellspacing="0" width="100%">
							<tr>
								<td width="<?=$textsize ?>">
									<?=$lng_title ?>
								</td>
								<td >
									<input type="text" name="title" value="<?=$newsitem['title'] ?>">
								</td>
							</tr>
						</table>
					<br>
					<?PHP 
						$editor_text = $newsitem['body']; 
						$editor_text = mysql_escape_string($editor_text);
					?>
					<?php include $editor_location ?>
					</td>
				</tr>
			</table>
			
			</center>
			</form>
	<?=closetable() ?>
	<?PHP
	$output .= ob_get_contents();
	ob_end_clean();
	return $output;
}
function template_news_edit_top(){
	$output .= opentable("width=\"100%\"", "width=\"100%\"");
	$output .= "<br><center>";
	$output .= "<table border=\"0\" width=\"100%\" height=\"100%\">";
	return $output;
}
function template_news_edit_body() {
	extract($GLOBALS);
	$timedate = template_dateformat($line['timestamp']);
	ob_start();
	?>
		<tr>
			<td class="list_grey">
				<b><?=$line['title'] ?></b> <small>- (<a href="?mod=view_profile&user=<?=urlencode($line['user']) ?>"><?=$line['user'] ?></a>) - <?=gmdate("F dS Y \a\\t h:i a", $timedate); ?></small> |-| <a href="?mod=admin&amod=edit_news&action=edit&id=<?=$line['id'] ?>"><?=$lng_edit ?></a> | <a href="?mod=admin&amod=edit_news&action=delete&id=<?=$line['id'] ?>" onclick="return confirm('<?=$lng_delete_conf ?>');"><?=$lng_delete ?></a><br>
			</td>
		</tr>
	<?PHP
	$output .= ob_get_contents();
	ob_end_clean();
	return $output;
}
function template_news_edit_bottom() {
	return "</table></center>" . closetable();
}
?>