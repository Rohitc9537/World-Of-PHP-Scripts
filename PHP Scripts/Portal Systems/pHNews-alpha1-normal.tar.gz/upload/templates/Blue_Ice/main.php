<?PHP
/*
pHNews Template File
*/
function template_dateformat($date){
	global $pHNews;
	$date = $pHNews->mysql_timestamp_tophp($date);
	$timezone  = 0;
	return $date + 3600*($timezone+date("I")); 
}
function OpenTableint($args, $bodyargs, $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, $class) {
    return "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" {$args}><tr>
    <td width=\"15\" height=\"15\" bgcolor=\"\"><img src=\"$table_top_left\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td>
    <td background=\"$table_top\" align=\"center\" width=\"100%\" height=\"15\" style=\"background-repeat:repeat-x\" class=\"$class\"></td>
    <td><img src=\"$table_top_right\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    <tr>
    <td background=\"$table_body_left\" width=\"15\" class=\"$class\">&nbsp;</td>
    <td background=\"{$table_body}\" class=\"$class\" {$bodyargs}>";
}
function CloseTableint($table_body_right, $table_bottom, $table_bottom_left, $table_bottom_right, $class) {
    return "</td>
    <td background=\"$table_body_right\" class=\"$class\">&nbsp;</td></tr>
    <tr>
    <td width=\"15\" height=\"15\"><img src=\"$table_bottom_left\" alt=\"\" border=\"0\"></td>
    <td background=\"$table_bottom\" align=\"center\" height=\"15\" class=\"$class\"></td>
    <td><img src=\"$table_bottom_right\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    </td></tr></table>
    <br>";
}
function OpenTable($args="", $bodyargs="") {
	global $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, $table_body_right,
			$table_bottom, $table_bottom_left, $table_bottom_right;

	return OpenTableint($args, $bodyargs, $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, "thetables");
}
function CloseTable() {
	global $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, $table_body_right,
			$table_bottom, $table_bottom_left, $table_bottom_right;

	return CloseTableint($table_body_right, $table_bottom, $table_bottom_left, $table_bottom_right, "thetables");
}
function OpenTableins($args="", $bodyargs="") {
	global $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, $table_body_right,
			$table_bottom, $table_bottom_left, $table_bottom_right;

	return OpenTableint($args, "../".$bodyargs, "../".$table_top, "../".$table_top_left, "../".$table_top_right, "../".$table_body, "../".$table_body_left, "thetables");
}
function CloseTableins() {
	global $table_top, $table_top_left, $table_top_right, $table_body, $table_body_left, $table_body_right,
			$table_bottom, $table_bottom_left, $table_bottom_right;

	return CloseTableint("../".$table_body_right, "../".$table_bottom, "../".$table_bottom_left, "../".$table_bottom_right, "thetables");
}
function openmenutable($args, $bodyargs) {
		global $menu_top2, $menu_top_left, $menu_top_right, $menu_body2, $menu_body_left, $menu_body_right,
			$menu_bottom, $menu_bottom_left, $menu_bottom_right;
		return OpenTableint($args, $bodyargs, $menu_top2, $menu_top_left, $menu_top_right, $menu_body2, $menu_body_left, "");
}
function closemenutable() {
		global $menu_top2, $menu_top_left, $menu_top_right, $menu_body, $menu_body_left, $menu_body_right,
			$menu_bottom2, $menu_bottom_left, $menu_bottom_right;
		return CloseTableint($menu_body_right, $menu_bottom2, $menu_bottom_left, $menu_bottom_right, "");
}
function template_menu($part, $menu_width, $line) {
	switch($part) {
		case "top":
			$output .= openmenutable("width='$menu_width'","");
			$output .= "<table border=0 align=center cellspacing=\"0\">\n";
			$output .= "<tr align=center>
  			      		<td>			
				  			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td class=\"menutitleback\"> 
										<div class=\"menutitle\">{$line['Name']}</div> 					
									</td>
								</tr>
							</table>
						</td>
					</tr>";
			return $output;
		break;
		case "body":
			return "<tr align=center>
  			      	  <td background=\"{$menu_body}\"  style=\"background-repeat:repeat-y\">
					  	<a href=\"{$line['url']}\" class=\"menuitem\" title=\"{$line['desc']}\">{$line['Name']}</a> 
					  </td>
					</tr>";
		break;
		case "bottom":
			return "</table><br>".closemenutable();
		break;
		case "under":
			$output .= openmenutable("width='$menu_width'","");
			$output .= "<table border=0 align=center cellspacing=\"0\">\n";
			$output .= "<tr align=center>
  			      		<td>			
				  			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td class=\"menutitleback\"> 
										<div class=\"menutitle\">Adverts</div> 					
									</td>
								</tr>
							</table>
						</td>
					</tr>";
			$output .= "<tr align=center>
  			      	  		<td background=\"{$menu_body}\"  style=\"background-repeat:repeat-y\">";
			$output .= '		<center><a href="http://www.ciao.co.uk/reg.php?AffiliateId='.aid().'" target="_new"><img src="http://www.ciao.co.uk/load_file.php?Filename=/images/banner/affiliate/150x35_money_friends_heard.gif&AffiliateId=5657385" width="150" height="35" border="0"></a><br><br>
								 <A href="http://sourceforge.net"> <IMG src="http://sourceforge.net/sflogo.php?group_id=142404&amp;type=4" border="0" alt="SourceForge.net Logo"/><br><BR>
								 <a href="http://sourceforge.net/donate/index.php?group_id=142404"><img src="http://images.sourceforge.net/images/project-support.jpg" width="88" height="32" border="0" alt="Support pHNews" /> </a> 
								 
									   </A></center>';
			$output .= "	</td>
						</tr>";
			$output .= "</table><br>".closemenutable();
			return template_login().$output;
		break;
	}
}
function aid() {
	$random = rand(0, 1);
	if ($random == 0) {
		return "5658355";
	}else{
		return "5657385";
	}
}
function template_login() {
	extract($GLOBALS);
	ob_start();
	?>
		<form method="post" action="?mod=login">
	<?PHP
			if ($loggedin) {$tmp_title = $user_uname;} else {$tmp_title = $lng_login;} 
	
			echo openmenutable("width='$menuwidth'","");
			echo "<table border=0 align=center cellspacing=\"0\">\n";
			echo "<tr align=center>
  				      	<td>			
				  			<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td class=\"menutitleback\"> 
										<div class=\"menutitle\">$tmp_title</div> 					
									</td>
								</tr>
							</table>
						</td>
					</tr>";
	
	?>
	
		 <tr align=center>
		  	<td background="<?=$menu_body ?>" class="menutext" style="background-repeat:repeat-y" height="174">
				<?PHP
				if ($loggedin) {
				?>
					<?PHP 
					if ($user_pic != "") {
					echo "<img src=\"$user_pic\" width=\"150\" height=\"150\"><br>";
					}
					?>
					<?=$lng_user ?> <?=$user_uname ?><br>
					<?=$lng_rank ?> <?=$user_rank ?><br><br>
					<input type="hidden" value="logout" name="action">
					<input type="hidden" name="referer" value="<?=$mod ?>">
					<input type="submit" value="Log Out <?=$user_uname ?>">
				<?PHP
				} else {
				?>
					<?=$lng_user ?><br>
					<input type="text" name="user" class="logintb" size="15" style="background : #4645FC;" OnFocus="this.style.background =  '#0072ff'; this.style.color = '#000c37';" OnBlur="this.style.background = '#4645FC'; this.style.color = '000c37';" ><br>
					<?=$lng_passwd ?><br>
					<input type="hidden" name="referer" value="<?=$mod ?>">
					<input type="password" name="passwd" class="logintb" size="15" style="background : #4645FC;" OnFocus="this.style.background =  '#0072ff'; this.style.color = '#000c37';" OnBlur="this.style.background = '#4645FC'; this.style.color = '000c37';" ><br>
					<input type="checkbox" name="keeps" value="true"><?=$lng_keepsin ?><br>
					<input type="submit" value="<?=$lng_login ?>">
				<?PHP
				}
				?>
			</td>
		<?PHP
				echo "</table><br>".closemenutable()."</form>";
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
}
function template_head(){

	ob_start();
	?>
	<script language="JavaScript" type="text/javascript">
	<!--


	var start = new Date();
	start = start.getTime();
	function page_loaded()
	{
		var loaded = new Date();
		loaded = loaded.getTime();
		var secs = (loaded - start) /1000;
		secs = secs + exectime;
		secs = Math.round(secs*1000)/1000;
		document.all.loadedtime.innerHTML = "Page loaded in: " + secs + " seconds";
		window.status = "<?=$GLOBALS['statusbartext'] ?> - Page loaded in: " + secs + " seconds";
	}


	window.status = "<?=$GLOBALS['statusbartext'] ?> - Loading...";
		function addfav()
		{
		var curpage = window.location;
		var curtit = document.title;
	
		window.external.AddFavorite(curpage, curtit);
		}
	
	<?=$mod_jscript ?>
	function scc_rclick(user) {
		//alert(event.button);
		if (event.button == "2") {
			showcontactcard(user);
		}
	}
	function showcontactcard(user){
		var ccardpopup = window.createPopup();
 	   var ccardpopupBody = ccardpopup.document.body;
		var lefter = window.event.y;
		var topper = window.event.x;
		//ccardpopupBody.style.backgroundColor = "lightyellow";
   		 //ccardpopupBody.style.border = "solid black 1px";
    	url = "./extra/ccard.php?user=" + user;
    	ccardpopupBody.innerHTML = ccarddiv.innerHTML;
    	ccardpopup.show(topper, lefter, 250, 155, document.body);
	}
	function hidecontactcard() {
		ccardpopup.hide();
	}
	
	
	-->
	</script>
	<?PHP
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
}
function template_head_body() {
	extract($GLOBALS);
	ob_start();
	?>
	<div id="ccarddiv" style="visibility:hidden; display:none"><div style="font-size:150px" style="font-stretch:ultra-expanded"><marquee scrolldelay="0">Gay</marquee></div>
	</div>
	<iframe width="0" height="0" frameborder="0" id="ccardframe"></iframe>
	<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
	
	<tr>
	<td  valign="top">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td height="<?=$head_height ?>" width="14.5" valign="bottom">
				<center><?=png_24_trans("", "14.5", "46") ?></center>
				<table height="3" border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td></td></tr></table>
			</td>
			<td height="<?=$head_height ?>" width="161" background="<?=$menu_back ?>" valign="bottom">
				<center><?=png_24_trans($menu_connect, "161", "46") ?></center>
				<table height="3" border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td></td></tr></table>
			</td>
			<td height="<?=$head_height ?>" width="14.5" valign="bottom">
				<center><?=png_24_trans("", "14.5", "46") ?></center>
				<table height="3" border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td></td></tr></table>
			</td>
			<td background="<?PHP echo $head_extend ?>" height="<?=$head_height ?>" style="background-repeat:repeat-x" class="head">
				<center>
					<img src="<?PHP echo $head_logo ?>" height="<?=$head_height ?>">
				</center>
			</td>

			<?PHP if ($menurenabled) {?>
			<td height="<?=$head_height ?>" width="190" class="menu">
				<center><?=png_24_trans("", "190", "46") ?></center>
				<table height="3" border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td></td></tr></table>
			</td>
			<?PHP } ?>

		</tr>
		</table>
		<br>
	<!-- Continues on to: index.php -->
	<?PHP
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
}
function template_index() {
	extract($GLOBALS);
	ob_start();
	?>
		<table width="100%" height="83%" border="0" cellpadding="0" cellspacing="0">
		<tr>
		<td width="<?=$menu_width ?>" valign="top" align="left" background="<?=$menu_back ?>" id="menu">
			<?PHP include "menu.php" ?>
		</td>
		<td height="83%">
			<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="10">&nbsp;</td>
					<td width="100%" <?PHP echo $mod_td ?>><?PHP echo $mod_output ?></td>
					<td width="10">&nbsp;</td>
				</tr>	
			</table>
	</td>
		<?PHP if ($menurenabled) { ?>
		<script language="jscript">
			document.write("<td width=\"" + document.all.menu.width + "\" valign=\"top\" align=\"right\" class=\"menu\">")
		</script>
	
			<?PHP if ($mod_menur == "") { include "menur.php"; }  else { include $mod_menur; } ?>
		</td>
		<?PHP } ?>
		</tr>
		</table>
	<?PHP
	$output = ob_get_contents();
	ob_end_clean();
	return $output;
}
function pages($pagesm, $url) {
	global $page;
	$output .= "Page:";
	for ($i = 1; $i <= $pagesm; $i++) {
		if ($page == $i) {
			$output .= " ".$i."";
		} else {
			$output .= " <a href=\"".$url.$i."\">".$i."</a> ";
		}
	}
	return $output;
}


?>