<?PHP
function template_comments($newsitem) {
	extract($GLOBALS);
	ob_start();
	?>
		<br>
		<center>
		<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
			<center>
			<b><?=$newsitem['title'] ?></b><br><br>
			<?=$newsitem['body'] ?>
			<br><br>
			<small>Message posted by <a href="?mod=view_profile&user=<?=urlencode($newsitem['user']) ?>"><?=$newsitem['user'] ?></a> on <?=gmdate("F dS Y \a\\t h:i a", template_dateformat($newsitem['timestamp'])); ?></small>
			</center>
		<?=closetable() ?>
		<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
			<center>
			<b>Comments:</b><br><br>
			<?PHP include $modules_dir . "/comments/" . "commentdisplay.php" ?>
			<?=$comm_output ?>
			</center>
		<?=closetable() ?>
			<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
			<center>
			<b>Post Comment:</b><br><br>
			<?PHP $comm_output=""; include $modules_dir . "/comments/" . "post.php" ?>
			<?=$comm_output ?>
			</center>
		<?=closetable() ?>
	<?PHP
	$output .= ob_get_contents();
	ob_end_clean();
	return $output;
}
function template_comments_body($line) {
	$timedate = template_dateformat($line['Timestamp']);
	ob_start();
	?>
		<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
		<center>
		<b><a name="<?=$line['id'] ?>"></a><?=$line['Title'] ?></b><br><br>
		<?=$line['Body'] ?>
		<br><br>
		<small>Message posted by <a href="?mod=view_profile&user=<?=urlencode($line['User']) ?>"><?=$line['User'] ?></a> on <?=gmdate("F dS Y \a\\t h:i a", $timedate); ?></small>
		</center>
		<?=closetable() ?>
	<?PHP
	$output .= ob_get_contents();
	ob_end_clean();
	return $output;
}
?>