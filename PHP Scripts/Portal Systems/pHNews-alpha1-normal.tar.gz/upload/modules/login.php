<?PHP
if (eregi("login.php",$_SERVER['PHP_SELF'])) {
   Header("Location: index.php?mod=news");
   die();
}
$mod_td = "align='center'";
$referer = $_POST["referer"];
if ($referer == "login") { $referer = "news"; }
$tmp_location = "?mod=".$referer;

if ($_POST["action"] == "logout") { 
	setcookie(md5($sitename));
	$loggedin = false;
	$user_rank_id = 0;
	$pHNews->autorelocate($tmp_location, $lng_logout);

} else {
	$user = $_POST["user"];
	$passwd = $_POST["passwd"];
	$keeps = $_POST["keeps"];
	$error = $_GET["error"];
	$passwdmd5 = md5($passwd);
	$result = $pHNews->login($user, $passwdmd5);
  	if ($result == 1) {
		// User is now authencated, lets set a cookie...
		$cookie = base64_encode("$row[0]:$user:$passwdmd5:$row[1]:$row[9]");
		if ($keeps == "true") {
			setcookie(md5($sitename), "$cookie",time()+2592000);
		} else {
			setcookie(md5($sitename), "$cookie");
		}
		// Set variables
		$pHNews->set_user_vars();
		// reinclude the language file so it reflects the user change
		include $lngfile_location;
		// Print the text
		$pHNews->autorelocate($tmp_location, $lng_loginmsg);
 	} else {
		if ($result == "wrong_info") {
			$pHNews->infobox($lng_uperror);
		} elseif ($result == "no_passwd") {
			// The user hasnt entered a password (dumb!) lets tell them ... be nice!
			$pHNews->infobox($lng_nopasswd);
		}
 	}

}
?>