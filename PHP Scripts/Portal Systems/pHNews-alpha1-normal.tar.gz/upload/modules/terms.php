<?PHP
if (eregi("terms.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=terms");
    die();
}
$mod_td = "valign=\"top\"";
$mod_popup = true;
ob_start();
?>
<?=opentable("width=\"100%\"", "width=\"100%\"") ?>
<?=opentable("width=\"100%\"", "width=\"100%\"") ?>
<p><strong>Forum Rules</strong></p>
							
<p>Registration to this forum and website is free! We do insist that you abide by the rules and policies detailed
below. If you agree to the terms, please check the 'I agree' button on the registration form to complete your registration.</p>

<p>Although the administrators and moderators of IM-Century will attempt to keep all objectionable
messages off this forum, it is impossible for us to review all messages. All messages express the views of
the author, and the owners of IM-Century will not be held responsible for the content of any message.</p>

<p>By agreeing to these rules, you warrant that you will not post any messages that are obscene, vulgar,
sexually-orientated, hateful, threatening, or otherwise violative of any laws.</p>

<p>The owners of IM-Century reserve the right to remove, edit, move or close any thread for any reason and to delete or ban any account without notice.</p>
<?=closetable() ?>
<?=closetable() ?>
<?PHP
$mod_output = ob_get_contents();
ob_end_clean();
?>