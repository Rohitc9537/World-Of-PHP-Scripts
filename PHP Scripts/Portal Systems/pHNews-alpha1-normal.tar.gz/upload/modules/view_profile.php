<?PHP
$mod_td = "valign=\"top\"";
$menurenabled = true;
//$sql = "SELECT * FROM `Users` WHERE `UName`='{$_GET['user']}'";
//$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
//$row = mysql_fetch_array($result);
$row = $pHNews->get_user_info("", $_GET['user']);
if ($row['UName'] == "") {
	$pHNews->infobox($lng_user_profile_notexist);
} else {
	if ($row['picture'] == "") {
		$picture = $no_pic_icon;
	} else {
		$picture = $row['picture'];
	}
	// Print user's info!
	ob_start();
	echo "<center>";
	echo opentable("width=\"500\"", "width=\"500\"");
	?>
		<table cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td valign="top" width="160">
					<img src="<?=$picture ?>" width="150" height="150">
			</td>
			<td valign="top">
				<b><?=$lng_user ?></b> <?=$row['UName'] ?><br>
				<b><?=$lng_realname ?></b> <?=$row['FName'] ?> <?=$row['LName'] ?><br>
				<b><?=$lng_title ?></b> <?=$row['UTitle'] ?><br>
				<b><?=$lng_rank ?></b> <?=$pHNews->idtorank($row['Rankid']) ?><br>
			</td>
		</tr>
		</table>
		<table cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td valign="top">
				<a href="?mod=email&user=<?=$row['UName'] ?>"><?=$lng_email_this_person ?></a>
			</td>
		</tr>
		</table>
	<?PHP
	echo closetable();
	echo "</center>";
	$mod_output .= ob_get_contents();
	ob_end_clean();
}
?>