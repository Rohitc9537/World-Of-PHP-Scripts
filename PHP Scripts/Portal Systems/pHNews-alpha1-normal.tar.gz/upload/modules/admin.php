<?PHP
if (eregi("admin.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=admin");
    die();
}
$mod_td = "valign=\"top\"";
// Just a test to see if the user system works :)
/*	if ($loggedin) {
		$mod_output .= "<center>You are logged in!<br>
					Your user rank id is: {$user_rank_id} <br>
					Your user rank is: {$user_rank} <br>
					Your user title is: {$user_title} <br>
					Your currently seleced theme is: {$user_theme} <br>
					Your location is: {$user_location} <br>
					Your email address: {$user_email} <br>
					Your user ID is: {$user_id} </center>";
	} else {
		$mod_output .= "<center>You are not logged in!</center>";
	}
*/
	// Ok here we go, on the long journey that is the admin interface....
	// First we need to check if the user has admin or moderator rights
	if ($loggedin != true) {
		infobox ($lng_not_logged_in);
	}elseif ($user_rank_id <= 4) {
		$tmp_access_denied = str_replace ( "__rank__", "Moderator", $lng_access_denied);
		infobox ($tmp_access_denied);
		unset ($tmp_access_denied);
	} else {

$mod_menur = $modules_dir . "/admin/menu.php";
$menurenabled = true;
?>
<?PHP
// Admin-Module stuff
// Find out about the module that trying to be loaded
// Set the $mod variable for people with register globals off
$amod = $_GET["amod"];
// If no mod is selected select the default (edit news)
if ($amod == "") { $amod = "edit_news"; }
// Connect to the database...
$link = mysql_connect($mysql_host, $mysql_user, $mysql_password)
   or die('Could not connect: ' . mysql_error());
// Select the database...
mysql_select_db($mysql_database) or die('Could not select database');

// Submit the query... god soooo mmmuuuccchhh coooodeee
$query = "SELECT * FROM Admin_Modules WHERE name = '{$amod}'";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());

// Make it into an array...
$row = mysql_fetch_row($result);

// Ok nearly there, set the location of the module's php file...
$amod_location = $modules_dir . "/admin/" . $row[0];
// If the module doesnt exist in the database or dosent have its location set
// for some reason make it use the news module ... all that connecting to
// mySQL for nothing :'(
if ($amod_location == $modules_dir . "/admin/") { Header("Location: index.php?mod=admin"); }
// Include the module :D
include $amod_location
?>
<?PHP
ob_start();
?>
	<?=$amod_output ?>
<?PHP
$mod_output .= ob_get_contents();
				ob_end_clean();
}
?>