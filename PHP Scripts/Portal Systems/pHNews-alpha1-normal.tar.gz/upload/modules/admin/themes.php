<?PHP
switch ($_GET['action']){
	case "install_theme":
		$result = mysql_query("SELECT * FROM `Themes` WHERE theme_name='".$_GET['theme_name']."'");
		$row = mysql_fetch_row($result);
		if ($row[2] != "") { $pHNews->infobox("A theme with the name {$_GET['theme_name']} already exists!"); return;}
		$sql = 'INSERT INTO `Themes` (`id`, `Location`, `theme_name`, `theme_creator`, `theme_desc`, `theme_copyright`, `theme_preview`, `order`)';
		$sql .= " VALUES ('', '{$_GET['file']}', '{$_GET['theme_name']}', '{$_GET['theme_creator']}', '{$_GET['theme_desc']}', '{$_GET['theme_copyright']}', '{$_GET['theme_preview']}', '0')"; 
		$result = mysql_query($sql);
		if ($result) {
			$pHNews->autorelocate("?mod=admin&amod=themes", "{$_GET['theme_name']} was successfuly installed.");
		} else {
			$pHNews->infobox("There was a problem while trying to install this theme, please try again.");
		}
	break;
	case "set_default":
		$sql = "UPDATE `Preferences` SET `Theme` = '".$_GET['id']."';"; 
		$result = mysql_query($sql);
		if ($result) {
			$pHNews->autorelocate("?mod=admin&amod=themes", "Theme with the id {$_GET['id']} has been set as the default theme.");
		} else {
			$pHNews->infobox(str_replace("__mysqlerror__", mysql_error(), $lng_edit_mysqlerror));
			return;
		}
	break;
	case "view_theme":
		$amod_output .= opentable("width='90%'","");
		$amod_output .= "<center><table cellpadding='0' cellspacing='0' border='0'><tr><td><center><b>{$_GET['theme_name']}</b></center></td></tr>";
		$amod_output .= "<tr><td><center><img src='./$themes_dir/$file/{$_GET['theme_preview']}'></center></td></tr><tr><td>";
		$amod_output .= "<table cellpadding='0' cellspacing='0' border='0'>";
		$amod_output .= "<tr><td>Folder Name:</td><td> <small>{$_GET['file']}</small></td><br>";
		$amod_output .= "<tr><td>Made by:</td><td> <small>{$_GET['theme_creator']}</small></td><br>";
		$amod_output .= "<tr><td>Description:</td><td> <small>{$_GET['theme_desc']}</small></td><br>";
		$amod_output .= "</td></tr></table>";
		$amod_output .= "</table><Br><BR><small>".$_GET['theme_copyright']."</small>";
		$amod_output .= "</center>";
		$amod_output .= closetable();
	break;
	case "delete_theme":
		$sql = "DELETE FROM `Themes` WHERE `id` = ".$_GET['id'].";"; 
		$result = mysql_query($sql);
		if ($result) {
			$pHNews->autorelocate("?mod=admin&amod=themes", "Theme sucessfully deleted.");
		} else {
			$pHNews->infobox(str_replace("__mysqlerror__", mysql_error(), "Error deleteing theme: __mysqlerror__"));
			return;
		}
	break;
	default:
?>
<?PHP
$amod_output .=  "<center>".opentable("width='90%'","")."<center><strong>Manage Themes</strong><br>
					The following themes have been installed:<br><BR><table border=\"0\" width=\"100%\" height=\"100%\">";
// Connecting, selecting database
$linkf = mysql_connect($mysql_host, $mysql_user, $mysql_password)
   or die('Could not connect: ' . mysql_error());
   
// echo 'Connected successfully';
mysql_select_db($mysql_database) or die('Could not select database');

// Performing SQL query
$query = 'SELECT * FROM `Themes`';
$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
$page = $_GET['page'];
$page = $_GET['page'];
// Pageing stuff
if ($page == "") { $page = 1; }
$page--;
$messagesppp = 10;
$lownum = $page * $messagesppp;
$topnum = $lownum + $messagesppp;

$ii = 0;
while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
	if ($ii < $topnum & $ii >= $lownum) {
				extract($line);
				if ( $default_theme != $line['id'] ) {  
					$tmp_sasd = " | <a href='?mod=admin&amod=themes&action=delete_theme&id=$id'>Delete</a> | <a href='?mod=admin&amod=themes&action=set_default&id=$id'>Set as Default</a>"; 
				} else { 
					$tmp_sasd = " |-| DEFAULT";
				}
				$amod_output .= "<tr>
									<td class='list_grey'>
										<b>$theme_name</b> <small>- made by: $theme_creator |-| <a href='?mod=admin&amod=themes&action=view_theme&theme_name=$theme_name&file=$Location&theme_creator=$theme_creator&theme_desc=$theme_desc&theme_copyright=$theme_copyright&theme_preview=$theme_preview'>View Info</a>$tmp_sasd<br>
									</td>
								</tr>";
		}
		$ii++;
}
	// Find out if theres more than one page and print page numbers if there are
if ($ii >= $messagesppp) {
	// Find out how many pages
	$pages = $ii / $messagesppp;
	$pages = ceil($pages);
	$pages++;
	$page++;
	$pagesm = $pages - 1;
	$amod_output .= pages($pagesm,"?mod=admin&amod=themes&page=");
}
$amod_output .= "</table>".closetable();
?>
<?PHP
$amod_output .= opentable("width='90%'","")."<center><strong>Install themes</strong><br>
				pHNews found the following themes in your theme directory:<br><BR><table border=\"0\" width=\"100%\" height=\"100%\">";
if (is_dir($themes_dir)) {
	if ($dh = @opendir($themes_dir)) {
		while (($file = readdir($dh)) !== false) {
			if (filetype($themes_dir . "/" . $file) == "dir") {
				if ($file != ".." && $file != ".") {
					if ($dhb = @opendir($themes_dir . "/" . $file)) {
						while (($fileb = readdir($dhb)) !== false) {
							if ($fileb == "theme.php") {
								include $themes_dir . "/$file/" . $fileb;
								if ($theme_name == "") { echo "<b>Invalid theme file</b> - $file<br><br>"; } else {
										$amod_output .= "<tr>
											<td class='list_grey'>
												<b>$theme_name</b> <small>- made by: $theme_creator |-| <a href='?mod=admin&amod=themes&action=install_theme&theme_name=$theme_name&file=$file&theme_creator=$theme_creator&theme_desc=$theme_desc&theme_copyright=$theme_copyright&theme_preview=$theme_preview'>Install</a> | <a href='?mod=admin&amod=themes&action=view_theme&theme_name=$theme_name&file=$file&theme_creator=$theme_creator&theme_desc=$theme_desc&theme_copyright=$theme_copyright&theme_preview=$theme_preview'>View Info</a><br>
											</td>
										</tr>";
									unset($theme_name);
								}
							}
						}
					closedir($dhb);
					} else {
					$amod_output .= "Error opening theme directory for $file.<br><br>";
					}
				}
			}
		}
	closedir($dh);
	} else {
		$amod_output .= "Error opening theme directory for $file.<br><br>";
	}
} else {
	$amod_output .= "Invalid themes directory in config.php.";
}
$amod_output .= "</table></center>".closetable()."</center>";
	break;
}
?>