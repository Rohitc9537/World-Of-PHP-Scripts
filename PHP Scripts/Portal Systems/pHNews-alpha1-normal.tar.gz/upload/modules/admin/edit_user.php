<?PHP
switch ($_GET['action']) {
case "submit":
	// Check the input :)
	if ($_POST['passwd'] != $_POST['passwdagain']) { regerror($lng_passmatch); return;}
	if ($_POST['email'] == "") { regerror($lng_noemail); return;}
	
	$result = $pHNews->edit_user($_GET['id'], $_POST['rank'], $_POST['user'], $_POST['passwd'], $_POST['fname'], $_POST['lname'], $_POST['email'], $_POST['title'], $_POST['location'], $_POST['theme'], $_POST['image'], $_POST['privacy']);
	if ($result == 1) {
		$pHNews->autorelocate("?mod=admin&amod=edit_users", "User account successfully edited!");
	} else {
		$pHNews->regerror(str_replace("__mysqlerror__", $result, "There was an error while editing the account: __mysqlerror__"));
	}
	
break;
default:
$mod_output .= $_GET['user'];
$textsize = "180";
$result = $pHNews->get_user_info($_GET['id']);
$row = $result;
ob_start();
	echo opentable("","align='center'");
	?>
	<b>Edit User: <?=$row['UName'] ?></b>
	<b><font color="#FF0000"><br><?=$reg_error ?></font></b>
	<form method="post" action="?mod=admin&amod=edit_user&action=submit&id=<?=$_GET['id'] ?>">
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr >
			<td width="<?=$textsize ?>">
				<?=$lng_user ?><br><br>
			</td>
			<td>
				<input type="text" name="user" value="<?=$row['UName'] ?>"> <small><i><?=$lng_user_desc ?></i></small><br><br>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_passwd ?>
			</td>
			<td>
				<input type="password" name="passwd"> <small><i><?=$lng_passwd_desc ?></i></small>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_passwdagain ?><br><br>
			</td>
			<td>
				<input type="password" name="passwdagain"> <small><i><?=$lng_repasswd_desc ?></i></small><br><br>
			</td>
		</tr>
			<td width="<?=$textsize ?>">
				<?=$lng_emailaddress ?>
			</td>
			<td>
				<input type="text" name="email" value="<?=$row['Email'] ?>"> <small><i><?=$lng_email_desc ?></i></small>
			</td>
		</tr>
	</table>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_fname ?>
			</td>
			<td>
				<input type="text" name="fname" value="<?=$row['FName'] ?>"> <small><i><?=$lng_fname_desc ?></i></small>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_lname ?>
			</td>
			<td>
				<input type="text" name="lname" value="<?=$row['LName'] ?>"> <small><i><?=$lng_lname_desc ?></i></small>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_location ?>
			</td>
			<td>
				<input type="text" name="location" value="<?=$row['Location'] ?>"> <small><i><?=$lng_location_desc ?></i></small>
			</td>
		</tr>
		<tr >
			<td width="<?=$textsize ?>">
				Theme: <br><br>
			</td>
			<td>
				<select name="theme">
				<?PHP 
				$query = 'SELECT * FROM `Themes`';
				$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
				while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
						extract($line);
						if ($row['Theme'] == $id) { $selected = "SELECTED"; } 
						else { $selected = ""; }
						echo "<OPTION VALUE='$id' $selected>$theme_name";
				}
				?>
				
				</select> <small><i>-Select a theme, this will change the appearence of pHNews</i></small><br><br>
			</td>
		</tr>
	</table>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_image ?>
			</td>
			<td>
				<image src="<?=$row['picture'] ?>" height="150" width="150" name="imgprev"><br><button onclick="document.all.imgprev.src = document.all.image.value"><?=$lng_preview ?></button><br><br>
				<input type="text" name="image" size="50"  value="<?=$row['picture'] ?>"> <small><i><?=$lng_image_desc ?></i></small>
		
			</td>
		</tr>
	</table>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr>
			<td width="<?=$textsize ?>">
				Rank:
			</td>
			<td>
				<select name="rank">
					<option value="-1" <?PHP if ($row['Rankid'] == "-1") { ?>selected<?PHP } ?>><?=$pHNews->idtorank(-1) ?></option>
					<option value="0" <?PHP if ($row['Rankid'] == 0) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(0) ?></option>
					<option value="1" <?PHP if ($row['Rankid'] == 1) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(1) ?></option>
					<option value="2" <?PHP if ($row['Rankid'] == 2) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(2) ?></option>
					<option value="3" <?PHP if ($row['Rankid'] == 3) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(3) ?></option>
					<option value="4" <?PHP if ($row['Rankid'] == 4) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(4) ?></option>
					<option value="5" <?PHP if ($row['Rankid'] == 5) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(5) ?></option>
					<option value="6" <?PHP if ($row['Rankid'] == 6) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(6) ?></option>
					<option value="7" <?PHP if ($row['Rankid'] == 7) { ?>selected<?PHP } ?>><?=$pHNews->idtorank(7) ?></option>
				</select><small><i>- User's rank, sets what privlages the user has.</i></small>
			</td>
		</tr>
				<tr>
			<td width="<?=$textsize ?>">
				User Title:
			</td>
			<td>
				<input type="text" name="title" value="<?=$row['UTitle'] ?>"><small><i>- User's title, used to show what there role is.</i></small>
			</td>
		</tr>
	</table>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr>
			<td width="<?=$textsize ?>">
				<?=$lng_keepemail ?><br><br>
			</td>
			<td>
				<label for="privyes"><input type="radio" id="privyes" name="privacy" value="1" tabindex="1" /><?=$lng_keepemail_yes ?></label><br>
				<label for="privno"><input id="privno" type="radio" name="privacy" value="0" tabindex="1" checked="checked" /><?=$lng_keepemail_no ?></label> <small><i><?=$lng_keepemail_desc ?></i></small><br><br>
			</td>
		</tr>
	<tr>
		<td width="<?=$textsize ?>">
		
		</td>
		<td>
			<input type="submit" value="Save">
		</td>
	</tr>
	</table>
	<?=closetable() ?>
	</form>
	<?PHP
	echo closetable();
$mod_output = ob_get_contents();
ob_end_clean();
break;
}
?>