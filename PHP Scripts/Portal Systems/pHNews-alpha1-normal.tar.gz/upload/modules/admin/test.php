<?PHP
$textsize = "30";
?>
<center>
<form action="news_submit.php" method="post" onsubmit="dosubmit()">
	<center>
	<b>Post new news item</b><br><br>
		<table border=0 align="center" cellspacing="0">
			<tr>
				<td align="center">
					<table border=0 align=center cellspacing="0" width="100%">
						<tr>
							<td width="<?=$textsize ?>">
								title:
							</td>
							<td >
								<input type="text" name="title">
							</td>
						</tr>
					</table>
					<br>
					<textarea name="message"></textarea>
				</td>
			</tr>
		</table>
	</center>
</form>