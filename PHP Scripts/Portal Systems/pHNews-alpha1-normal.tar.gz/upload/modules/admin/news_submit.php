<?PHP
ob_start();
$text = $pHNews->parse_message($_POST['message']);
$text = $pHNews->parse_message_after($text);


#<img[^>]+src=(\'|")(.*)(\\1).*>#siU
//$text = preg_replace("<img[^>]+src=('|\")(.*)(\\1).*>", "<img src=\"\\2\" alt=\"user posted image\">", $text);
//echo $text . "<br>";
//$find = "<img";
//$replace = '<img style="clip: rect(200px, 200px, 200px, 200px);"';
//$text = str_Ireplace($find, $replace, $text);
//echo $text . "<br>";

// Do emoteicon stuff
$sql = "INSERT INTO `News` ( `id` , `title` , `body` , `user`) 
VALUES (
'', '{$_POST['title']}', '{$text}', '{$user_uname}');"; 
//echo $sql;

$resultb = mysql_query($sql);
//$row = mysql_fetch_row($result);
	if ($resultb) {
		$pHNews->autorelocate("?mod=admin", $lng_posted);
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", mysql_error(), $lng_post_mysqlerror));
	}

?>
<?PHP
$mod_output .= ob_get_contents();
ob_end_clean();
?>