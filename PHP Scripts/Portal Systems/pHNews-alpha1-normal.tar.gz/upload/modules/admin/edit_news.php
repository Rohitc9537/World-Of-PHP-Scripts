<?PHP
if (eregi("edit_news.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=admin");
    die();
}
include "./$templates_dir/$template/news.php";

$mod_td = "valign=\"top\"";
$action = $_GET['action'];
if ($action == "edit") {
	$menurenabled = true;
	$newsitem = $pHNews->get_news_item($id);
	$mod_output .= template_edit_news();
} elseif ($action == "submitchanges") {
	$text = $pHNews->parse_message($_POST['message']);
	$text = $pHNews->parse_message_after($text);
	$result = $pHNews->edit_news($text, $_POST['title'], $_GET['id']) ;
	if ($result == 1) {
		$pHNews->autorelocate("?mod=admin&amod=edit_news", $lng_news_edited);
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", $result, $lng_edit_mysqlerror));
	}
} elseif ($action == "delete") {
	$result = $pHNews->delete_news($_GET['id']);
	if ($result == 1) {
		$pHNews->autorelocate("?mod=admin&amod=edit_news", $lng_news_deleted);
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", $result, $lng_delete_mysqlerror));
	}
} else {
	$mod_output .= template_news_edit_top();
	// Return the news
	$news = $pHNews->return_news();

	// Pageing stuff
	$page = $_GET['page'];
	if ($page == "") { $page = 1; }
	$page--;
	$messagesppp = 50;
	$lownum = $page * $messagesppp;
	$topnum = $lownum + $messagesppp;
	
	$ii = 0;
	foreach ($news as $id => $line) {
		if ($ii < $topnum & $ii >= $lownum) {
			$mod_output .= template_news_edit_body();
		}
		$ii++;
	}
		// Find out if theres more than one page and print page numbers if there are
	if ($ii >= $messagesppp) {
		// Find out how many pages
		$pages = $ii / $messagesppp;
		$pages = ceil($pages);
		$pages++;
		$page++;
		$pagesm = $pages - 1;
		$mod_output .= pages($pagesm,"?mod=admin&page=");
	}
	$mod_output .= template_news_edit_bottom();
}
?>