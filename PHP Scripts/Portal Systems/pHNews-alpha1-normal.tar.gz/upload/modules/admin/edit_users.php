<?PHP
switch($_GET['action']) {
	case "search":
		$type = "UName";
		switch($_POST['type']) {
			case "UName":
				$type = "UName";
			break;
			case "Email":
				$type = "Email";
			break;
			case "FName":
				$type = "FName";
			break;
			case "LName":
				$type = "LName";
			break;
			case "UTitle":
				$type = "UTitle";
			break;
			case "Rankid":
				$type = "Rankid";
			break;
		}
		$mod_output .= opentable("width=\"100%\"", "width=\"100%\"");
		$mod_output .= "<br><center>";
		$mod_output .= "<table border=\"0\" width=\"100%\" height=\"100%\">";
		$users = $pHNews->search_users($_POST['string'], $type);
		foreach ($users as $id => $line) {
			ob_start();
			?>
			<tr>
				<td class="list_grey">
						<b><?=$line['UName'] ?></b> <small>- <?=$line['Email'] ?></small> |-| <a href="?mod=view_profile&user=<?=urlencode($line['UName']) ?>"><?=$lng_view ?></a> | <a href="?mod=admin&amod=edit_user&id=<?=urlencode($line['id']) ?>"><?=$lng_edit ?></a> | <a href="?mod=admin&amod=edit_users&action=ban&user=<?=urlencode($line['UName']) ?>"><?=$lng_ban ?></a> | <a href="?mod=admin&amod=edit_users&action=delete&id=<?=$line['id'] ?>&user=<?=urlencode($line['UName']) ?>"><?=$lng_delete ?></a><br>
				</td>
			</tr>
			<?PHP
			$mod_output .= ob_get_contents();
			ob_end_clean();
		}
		$mod_output .=  "</table></center>" . closetable();
	break;
	case "ban":
		$result = $pHNews->change_rank($_GET['user'], '-1');
		if ($result == 1) {
			autorelocate("?mod=admin&amod=edit_users", str_replace("__user__", $_GET['user'], $lng_user_banned));
		} else {
			infobox(str_replace("__mysqlerror__", $result, $lng_user_ban_mysqlerror));
			return;
		}
	break;
	case "delete":
		$result = $pHNews->delete_user($_GET['id']);
		if ($result == 1) {
			$pHNews->autorelocate("?mod=admin&amod=edit_users", str_replace("__user__", $_GET['id'],$lng_user_deleted));
		} else {
			$pHNews->infobox(str_replace("__mysqlerror__", $result, $lng_user_delete_mysqlerror));
		}
	break;
	case "":
		ob_start();
		?>
			<?=opentable("width=\"100%\"", "width=\"100%\"") ?>
			<center>
			<form action="?mod=admin&amod=edit_users&action=search" method="post">
				<?=$lng_search_for ?> <input type="text" name="string"> <?=$lng_in ?> <select name="type">
					<option value="UName"><?=$lng_username ?></option>
					<option value="Email"><?=$lng_email_address ?></option>
					<option value="FName"><?=$lng_first_name ?></option>
					<option value="LName"><?=$lng_last_name ?></option>
					<option value="UTitle"><?=$lng_user_title ?></option>
				</select>
				<input type="submit" value="Search">
			</form>
			<form action="?mod=admin&amod=edit_users&action=search" method="post">
				<input type="hidden" value="Rankid" name="type">
				<?=$lng_orsearch_rank ?>
				<select name="string">
					<option value="-1"><?=$pHNews->idtorank(-1) ?></option>
					<option value="0"><?=$pHNews->idtorank(0) ?></option>
					<option value="1"><?=$pHNews->idtorank(1) ?></option>
					<option value="2"><?=$pHNews->idtorank(2) ?></option>
					<option value="3"><?=$pHNews->idtorank(3) ?></option>
					<option value="4"><?=$pHNews->idtorank(4) ?></option>
					<option value="5"><?=$pHNews->idtorank(5) ?></option>
					<option value="6"><?=$pHNews->idtorank(6) ?></option>
					<option value="7"><?=$pHNews->idtorank(7) ?></option>
				</select>
				<input type="submit" value="Search">
			</form>
			</center>
			<?=closetable() ?>
		<?PHP
		$mod_output .= ob_get_contents();
		ob_end_clean();
	break;

}

?>