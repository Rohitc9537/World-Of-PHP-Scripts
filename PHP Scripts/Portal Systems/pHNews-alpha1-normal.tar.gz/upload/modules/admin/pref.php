<?PHP
switch ($_GET['action']) {
case submit:
	$result = $pHNews->set_preferences($_POST['Message_Parser'], $_POST['Page_Limit'], $_POST['Status_Bar'], $_POST['Site_name'], 
										$_POST['Language'], $_POST['Theme'], $_POST['Editor'], $_POST['message']);
	if ($result == 1) {
		$pHNews->autorelocate("?mod=admin", "Preferences successfully changed!");
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", $result, "There was an error while changeing the preferences: __mysqlerror__"));
	}
break;
default:
	$row = $pHNews->get_preferences();
	$textsize = "180";
	ob_start();
	echo opentable("","align='center'");
	?>
	<b>pHNews Preferences</b>
	<b><font color="#FF0000"><br><?=$reg_error ?></font></b>
	<form method="post" action="?mod=admin&amod=pref&action=submit" onsubmit="dosubmit()">
	<?=opentable("","") ?>
	<table border=0 align=center cellspacing="0" width="100%">
		<tr >
			<td width="<?=$textsize ?>">
				Site Name:
			</td>
			<td>
				<input type="text" name="Site_name" value="<?=$row['sitename'] ?>"> <small><i>- The name you want to give to this website.</i></small><br><br>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				Status Bar:
			</td>
			<td>
				<input type="text" name="Status_Bar" value="<?=$row['statusbartext'] ?>"> <small><i>- The text that is displayed in the status bar (the bar at the bottom of your browser).</i></small>
			</td>
		</tr>
		<tr>
			<td width="<?=$textsize ?>">
				Default Language:
			</td>
			<td>
				<input type="text" name="Language" value="<?=$row['lngfile_location'] ?>"> <small><i>- The default language for your website.</i></small><br><br>
			</td>
		</tr>
			<td width="<?=$textsize ?>">
				Default Theme: 
			</td>
			<td>
				<input type="text" name="Theme" value="<?=$row['default_theme'] ?>"> <small><i>- The default theme for your website (the id).</i></small>
			</td>
		</tr>
		</tr>
			<td width="<?=$textsize ?>">
				Message Parser: 
			</td>
			<td>
				<input type="text" name="Message_Parser" value="<?=$row['message_parser'] ?>"> <small><i>- The name of the message parser you want to use.</i></small>
			</td>
		</tr>
		</tr>
			<td width="<?=$textsize ?>">
				Editor: 
			</td>
			<td>
				<input type="text" name="Editor" value="<?=$row['editor_location'] ?>"> <small><i>- The name of the editor you want to use for messages.</i></small>
			</td>
		</tr>
		</tr>
			<td width="<?=$textsize ?>">
				Messages per page: 
			</td>
			<td>
				<input type="text" name="Page_Limit" value="<?=$row['Page_Limit'] ?>"> <small><i>- The number of messages to show on one page.</i></small>
			</td>
		</tr>
	</table>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<center>
	<table border=0 align=center cellspacing="0">
		</tr>
			<td valign="top">
				<center><b>Message Text</b><br> 
				<small><i>The message you want displayed on the fist page at the top (you can use html, leave blank for no message).</i></small> <br><br>
				<?PHP 
				$editor_text = mysql_escape_string($row['FirstMsg']);
				//$editor_center = "yes";
				$editor_submitbuttons = "no";
				include $editor_location; 
				?>
				</center>
			</td>
		</tr>
	</table>
	</center>
	<?=closetable() ?>
	<?=opentable("","") ?>
	<center><input type="submit" value="Save Changes"></Center>
	<?=closetable() ?>
	</form>
<?PHP
	echo closetable();
	$mod_output = ob_get_contents();
	ob_end_clean();
break;
}
?>