<?PHP
function adduser() {
	extract($GLOBALS);
	// Check the input :)
	if ($_POST['passwd'] != $_POST['passwdagain']) { $pHNews->regerror($lng_passmatch); return;}
	if ($_POST['passwd'] == "") { $pHNews->regerror($lng_nopassword); return;}
	if ($_POST['user'] == "") { $pHNews->regerror($lng_nouser); return;}
	if ($_POST['email'] == "") { $pHNews->regerror($lng_noemail); return;}

	// Check there isnt already a user with the same name, ages ago when i first started doing web programing
	// in asp (dont laugh :$) i didnt do this hehe, that was fun....
	$link = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die('Could not connect: ' . mysql_error());
	mysql_select_db($mysql_database);
	$result = mysql_query("SELECT * FROM Users WHERE UName='".$_POST['user']."'");
	$row = mysql_fetch_row($result);
	if ($row[2] != "") { $pHNews->regerror($lng_userexists); return;}
	$passwdmd5 = md5($_POST['passwd']);
	
	$sql = "INSERT INTO `Users` (`id`, `Rankid`, `UName`, `Paswd`, `FName`, `LName`, `Email`, `UTitle`, `Location`, `Theme`, `picture`, `forumsacct`, `privacy`) 
	VALUES ('', '1', '".$_POST['user']."', '".$passwdmd5."', '".$_POST['fname']."', '".$_POST['lname']."', '".$_POST['email']."', 'IMC Member', '".$_POST['location']."', '".$default_theme."', '".$_POST['image']."', '".$_POST['forums']."', '".$_POST['privacy']."')"; 
	//$mod_output .= "Sql query = ".$sql;
	$result = mysql_query($sql);
	if ($result) {
		$pHNews->infobox($lng_reg_successful);
	} else {
		$pHNews->regerror(str_replace("__mysqlerror__", mysql_error(), $lng_reg_mysqlerror));
		return;
	}
}
adduser();
?>