<?PHP
if (eregi("news.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=news");
    die();
}
// Include template for news:
include "./$templates_dir/$template/news.php";

$mod_td = "valign=\"top\"";
$menurenabled = true;

$news = $pHNews->return_news();
$mod_output .= template_news_start();
$page = $_GET['page'];
// Pageing stuff
if ($page == "") { $page = 1; }
$page--;
$messagesppp = $messagespp;
$lownum = $page * $messagesppp;
$topnum = $lownum + $messagespp;

$ii = 0;
foreach ($news as $id => $line) {
	if ($ii < $topnum & $ii >= $lownum) {
		$newcomments = $pHNews->isnew_comments($id);
		// For backwards compatability set comments field
		$line['comments'] = $comments_count[$id];
		$mod_output .= template_news($line);
		//$mod_output .= $newcomments;
	}
	$ii++;
}
// Find out if theres more than one page and print page numbers if there are
if ($ii >= $messagespp) {
	// Find out how many pages
	$pages = $ii / $messagespp;
	$pages = ceil($pages);
	$pages++;
	$page++;
	$pagesm = $pages - 1;
	$mod_output .= pages($pagesm,"?mod=news&page=");
}
$mod_output .= template_news_end();
?>