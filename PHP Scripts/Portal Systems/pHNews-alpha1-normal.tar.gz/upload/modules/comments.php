<?PHP
include "./$templates_dir/$template/comments.php";

$mod_td = "valign=\"top\"";
if ($_GET['action'] == "submit"){
	include $modules_dir . "/comments/" . "submit.php";
} else {
	$menurenabled = true;
	// Connecting, selecting database
	$linkf = mysql_connect($mysql_host, $mysql_user, $mysql_password)
	   or die('Could not connect: ' . mysql_error());
 	  
	// echo 'Connected successfully';
	mysql_select_db($mysql_database) or die('Could not select database');
	
	// Performing SQL query
	$newsitem = $pHNews->get_news_item($id);
/*
	$newsitem['body'] = $line['body'];
	$newsitem['title'] = $line['title'];
	$newsitem['user'] = $line['user'];
	$newsitem['date'] = $line['date'];
	$newsitem['time'] = $line['time'];
	$newsitem['comments'] = $line['comments'];
	$newsitem['id'] = $line['id'];
*/
	$mod_output .= template_comments($newsitem);
}
?>