<?PHP
if (eregi("about.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=about");
    die();
}
$mod_td = "valign=\"top\"";
ob_start();
?>
	<script language="jscript">
	function spawn_plan_tribute() {
		window.location.href = "#";
		tribute = document.open('', '_blank', 'height=1024, location=no, menubar=no, resizable=no, status=no, toolbar=no, width=1280');
		var sMarkup = "<HTML><HEAD><TITLE>Plan Tribute</TITLE><BODY><bgSound src=\"mott.mp3\"><center><p><strong>Plan-1130 Tribute:</strong><br>A tribute to the dumb but somewhat imaginative BeltSander&reg;&#8482;&#8482;&#8482;&reg;&copy; which you can purchase for: &yen;1. <br>A picture of the upgraded BeltSander codename BobSander&#8482; can be found below:<br><img src=\"http://www.bangalorenet.com/social/actionaid/images/dis-spastic.jpg\" width=\"1280\" onClick=\"spawn_plan_tribute();\"></center></BODY></HTML>";
		tribute.document.open();
		tribute.document.write(sMarkup);
    	tribute.document.close();
	}
	</script>
	<br>
	<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
		<center>
		<b>About Us</b>
		</center>
		<?=opentable("", "") ?>
			<p><strong>Admins:</strong><br>
			<br>
  			mrmt32 - <small>Hey, i made the background, not much else, o wel i did code it all but thats not that much....<br></small>
  			ff2k - <small>Hey, i'm the designer of this website, the good designer however not the crap one that designed the menus. I designed the main logo and menu-above-graphic-thing. <br></small>
  			Plan-1130 - <small>Hey, i'm the idiot who designed the menus and a crap logo which was then replaced by a far better one. My name has no meaning. Remove the 1 and 0 from either side and you have 13. Convert this to a B and there is Plan-B, my true name. But its not my real name, i never reveal my real name on the internet which is Sander, oh crap I just did. How do you use backspace? I don't know how to get rid of this. Oh crap. Please send me trojans so I may reveal my animal pornography to the public. Oh yes and im dutch, and crap at english. Zukuses please flame me at will. </small></p>
		<?=closetable() ?>

		<?=opentable("", "") ?>
			This website uses pHNews&reg;, a portal system coming soon from <a href="http://www.phmicroboard.com/">pHMicroboard</a>, it is still in development stages and many features have not yet been coded, a website will be set up soon when the project is nearer completion.
		<?=closetable() ?>
	<?=closetable() ?>
	<?=opentable("width=\"90%\"", "width=\"90%\"") ?>
			<center>Below is the "lets insult the admins" section, email me with your ideas and you can get to insult us, how fun! (dont take it seriously, were not realy anything of the below, hounest!)</center>
			<br><Br>
		<?=opentable("", "") ?>
			<center><p><strong>Plan-1130 Tribute:</strong><br>
			A tribute to the dumb but somewhat imaginative BeltSander&reg;&#8482;&#8482;&#8482;&reg;&copy; which you can purchase for: &yen;1. <br>
			A picture of the upgraded BeltSander codename BobSander&#8482; can be found below:<br>
			<img src="http://www.bangalorenet.com/social/actionaid/images/dis-spastic.jpg" onClick="spawn_plan_tribute();"></center>
		<?=closetable() ?>
	<?=closetable() ?>
<?PHP
$mod_output .= ob_get_contents();
ob_end_clean();
?>