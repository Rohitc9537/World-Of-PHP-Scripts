<?PHP
ob_start();
$textsize = "30";
//$guestallowed = true;
if ($loggedin || $guestallowed) {
?>
<a name="post"></a>
<center>
<form action="?mod=comments&action=submit&id=<?=$_GET['id'] ?>&page=<?=$_GET['page'] ?>" method="post" onsubmit="dosubmit()">
	<center>
		<table border=0 align="center" cellspacing="0">
			<tr>
				<td align="center">
					<table border=0 align=center cellspacing="0" width="100%">
						<tr>
							<td width="<?=$textsize ?>">
								<?=$lng_title ?>
							</td>
							<td >
								<input type="text" name="title">
							</td>
						</tr>
					</table>
					<br>
					<?php include $editor_location ?>
				</td>
			</tr>
		</table>
	</center>
</form>

<?PHP
} else {
	echo $pHNews->infoboxr($lng_post_notallowed);
}
$comm_output .= ob_get_contents();
ob_end_clean();
?>