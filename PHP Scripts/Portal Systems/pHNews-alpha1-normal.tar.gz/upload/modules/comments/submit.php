<?PHP
ob_start();
$debug_output .= "<textarea cols=200 rows=20>";
$debug_output .= "BPM: ".$_POST['message']."\n";
$text = $pHNews->parse_message($_POST['message']);

$debug_output .= "APM: ".$text."\n";
if ($user_rank_id <= "6") {

	$text = strip_tags($text, '<b><emote><strong><i><em><u><a><div><span><p><blockquote><ol><ul><li><font><br><h1><h2><h3><h4><h5><h6>');
	$debug_output .= "AST: ".$text."\n";
	$text = str_replace ( "style=", "stylenotallowed=", $text);

	$find = '#<a name=[^>]*>(.*)</a>#siU';
	$replace = '\1';
	$text = preg_replace($find, $replace, $text);
	$text = $pHNews->parse_message_after($text);
	$debug_output .= "APMA: ".$text."\n";
} else { 
	//$text = $_POST['message']; 
	$text = $pHNews->parse_message_after($text);
	$debug_output .= $text."\n";
}
$debug_output .= "</textarea>";
if ($_POST['debug'] == "debug") {
	$mod_output .= $debug_output;
}else{
	$comments = $pHNews->post_comment($_GET['id'], $text, $_POST['title'], $user);
	if ($comments == 1) {
		$pHNews->autorelocate("?mod=comments&id=".$_GET['id']."&page=".$_GET['page'], $lng_posted);
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", $comments, $lng_post_mysqlerror));
		return;
	}
}
?>
<?PHP
$mod_output .= ob_get_contents();
ob_end_clean();
?>