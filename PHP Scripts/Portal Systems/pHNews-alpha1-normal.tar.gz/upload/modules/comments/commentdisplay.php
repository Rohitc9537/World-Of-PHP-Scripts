<?PHP
// Performing SQL query

$comments = $pHNews->get_comments($newsitem['id']);

$comm_output .= "<br><center>";

$page = $_GET['page'];
// Pageing stuff
if ($page == "") { $page = 1; }
$page--;
$messagesppp = $messagespp;
$lownum = $page * $messagesppp;
$topnum = $lownum + $messagespp;
$ii = 0;
if ($comments == "") {
	$comm_output .= "No comments to display.<br><BR>";
} else {
	foreach ($comments as $id => $line) {
		if ($ii < $topnum & $ii >= $lownum) {
			$comm_output .= template_comments_body($line);
		}
		$ii++;
	}
}
// Find out if theres more than one page and print page numbers if there are
if ($ii >= $messagespp) {
	// Find out how many pages
	$pages = $ii / $messagespp;
	$pages = ceil($pages);
	$pages++;
	$page++;
	$pagesm = $pages - 1;
	$comm_output .= pages($pagesm,"?mod=comments&id=".$_GET['id']."&page=");
}
unset($tmp_ended);
$sql = "SELECT lastread FROM Users WHERE UName = '$user_uname'";
$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
$row = mysql_fetch_array($result, MYSQL_ASSOC);
$exploaded = $pHNews->explodeAssoc("&", $row['lastread']);
$exploaded[$_GET['id']] = time();
$sql = "UPDATE Users SET lastread='".$pHNews->implodeAssoc("&", $exploaded)."' WHERE UName = '$user_uname';";
mysql_query($sql);
$mod_output .= mysql_error();

?>