<?PHP
if (eregi("register.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=register");
    die();
}
$mod_td = "valign=\"top\"";
if ($_POST["user"] != "") {
	include $modules_dir . "/register/adduser.php";
}
if ($_POST["user"] == "" || $reg_fail) {
$textsize = "180";
ob_start();
echo opentable("","align='center'");
?>
<b><?=$lng_registration ?></b>
<b><font color="#FF0000"><br><?=$reg_error ?></font></b>
<form method="post" action="?mod=register">
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr >
		<td width="<?=$textsize ?>">
			<?=$lng_user ?><br><br>
		</td>
		<td>
			<input type="text" name="user" value="<?=$_POST['user'] ?>"> <small><i><?=$lng_user_desc ?></i></small><br><br>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_passwd ?>
		</td>
		<td>
			<input type="password" name="passwd"> <small><i><?=$lng_passwd_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_passwdagain ?><br><br>
		</td>
		<td>
			<input type="password" name="passwdagain"> <small><i><?=$lng_repasswd_desc ?></i></small><br><br>
		</td>
	</tr>
		<td width="<?=$textsize ?>">
			<?=$lng_emailaddress ?>
		</td>
		<td>
			<input type="text" name="email"> <small><i><?=$lng_email_desc ?></i></small>
		</td>
	</tr>
</table>
<?=closetable() ?>
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_fname ?>
		</td>
		<td>
			<input type="text" name="fname"> <small><i><?=$lng_fname_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_lname ?>
		</td>
		<td>
			<input type="text" name="lname"> <small><i><?=$lng_lname_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_location ?>
		</td>
		<td>
			<input type="text" name="location"> <small><i><?=$lng_location_desc ?></i></small>
		</td>
	</tr>
</table>
<?=closetable() ?>
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_image ?>
		</td>
		<td>
			<image src="" height="150" width="150" name="imgprev"><br><button onclick="document.all.imgprev.src = document.all.image.value"><?=$lng_preview ?></button><br><br>
			<input type="text" name="image" size="50"> <small><i><?=$lng_image_desc ?></i></small>
		
		</td>
	</tr>
</table>
<?=closetable() ?>
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_forums ?><br><br>
		</td>
		<td>
			<label for="forumsyes"><input type="radio" id="forumsyes" name="forums" value="1" tabindex="1" /><?=$lng_Yes ?></label> <small><i><?=$lng_forums_desc ?></i></small><br>
			<label for="forumsno"><input id="forumsno" type="radio" name="forums" value="0" tabindex="1" checked="checked" /><?=$lng_No ?></label><br><br>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_keepemail ?><br><br>
		</td>
		<td>
			<label for="privyes"><input type="radio" id="privyes" name="privacy" value="1" tabindex="1" /><?=$lng_keepemail_yes ?></label><br>
			<label for="privno"><input id="privno" type="radio" name="privacy" value="0" tabindex="1" checked="checked" /><?=$lng_keepemail_no ?></label> <small><i><?=$lng_keepemail_desc ?></i></small><br><br>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			
		</td>
		<td>
			<input type="submit" value="<?=$lng_iagree ?>"> <input type="submit" onclick="window.location.href='http://www.tribbs.co.uk/end_of_the_internet.php'; return false" value="<?=$lng_idecline ?>"> <small><i>-Read the rules <a onclick="window.open('?mod=terms', 'ruleswindow', 'height=365, location=no, menubar=no, resizable=no, status=no, toolbar=no, width=545')">here</a> then click whether you agree</i></small>
		</td>
	</tr>
</table>
<?=closetable() ?>
</form>
<?PHP
echo closetable();
$mod_output = ob_get_contents();
ob_end_clean();
}
?>