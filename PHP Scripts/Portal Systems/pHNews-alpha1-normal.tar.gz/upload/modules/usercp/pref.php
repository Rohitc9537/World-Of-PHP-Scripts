<?PHP
if ($_GET['action'] == "submit") {
	$result = $pHNews->edit_user($user_id, "[dontset]", "[dontset]", "", "[dontset]", "[dontset]", "[dontset]", "[dontset]", "[dontset]", $_POST['theme'], $_POST['image'], "[dontset]");
	if ($result == 1) {
		$pHNews->autorelocate("?mod=usercp", "Your preferences have been successfully saved.");
	} else {
		$pHNews->infobox(str_replace("__mysqlerror__", $result, "There was an error while saveing your preferences: __mysqlerror__"));
		return;
	}
} else {
$textsize = "180";
ob_start();
echo opentable("","align='center'");
?>
	<b>Prefrences</b>
	<b><font color="#FF0000"><br><?=$reg_error ?></font></b>
	<form method="post" action="?mod=usercp&umod=pref&action=submit">
	<?=opentable("","") ?>
		<table border=0 align=center cellspacing="0" width="100%">
			<tr >
				<td width="<?=$textsize ?>">
					Theme: <br><br>
				</td>
				<td>
					<select name="theme">
					<?PHP 
					$query = 'SELECT * FROM `Themes`';
					$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
					while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
							extract($line);
							if ($theme_id == $id) { $selected = "SELECTED"; } 
							else { $selected = ""; }
							echo "<OPTION VALUE='$id' $selected>$theme_name";
					}
					?>
					
					</select> <small><i>-Select a theme, this will change the appearence of pHNews</i></small><br><br>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<?=$lng_image ?>
				</td>
				<td>
					<image src="<?=$user_pic ?>" height="150" width="150" name="imgprev"><br><button onclick="document.all.imgprev.src = document.all.image.value"><?=$lng_preview ?></button><br><br>
					<input type="text" name="image" size="50" value="<?=$user_pic ?>"> <small><i><?=$lng_image_desc ?></i></small><br><BR>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					Submit Changes: 
				</td>
				<td>
					<input type="submit" value="Submit">
				</td>
			</tr>
		</table>
	<?=closetable() ?>
	</form>
<?=closetable() ?>
<?PHP
$mod_output = ob_get_contents();
ob_end_clean();
}
?>