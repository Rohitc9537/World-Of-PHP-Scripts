<?PHP
ob_start();
?>
<center>
<?=opentable("width='90%'", "height='90%'") ?>
	<center>
		Welcome to the User Control Panel, here you can change any of your settings. Please select an option on the right.
	</center>
<?=closetable() ?>
</center>
<?PHP
$mod_output .= ob_get_contents();
				ob_end_clean();
?>