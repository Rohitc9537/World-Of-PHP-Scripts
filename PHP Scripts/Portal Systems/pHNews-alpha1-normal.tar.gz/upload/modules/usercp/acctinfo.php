<?PHP
if (eregi("register.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=usercp&umod=acctinfo");
    die();
}
function updateuser() {
	extract($GLOBALS);
	// Check the input :)
	if ($_POST['passwd'] != $_POST['passwdagain']) { regerror($lng_passmatch); return;}
	//if ($_POST['passwd'] == "") { $passwdmd5 = $passwd; } else { $passwdmd5 = md5($_POST['passwd']); }
	if ($_POST['email'] == "") { regerror($lng_noemail); return;}
	

	$result = $pHNews->edit_user($user_id, "[dontset]", "[dontset]", $_POST['passwd'], $_POST['fname'], $_POST['lname'], $_POST['email'], "[dontset]", $_POST['location'], "[dontset]", "[dontset]", $_POST['privacy']);
	//$sql = "UPDATE `Users` SET `Paswd` = '$passwdmd5', `FName` = '{$_POST['fname']}', `LName` = '{$_POST['lname']}', `Email` = '{$_POST['email']}', `Location` = '{$_POST['location']}', `privacy` = '{$_POST['privacy']}' WHERE `UName` = '$user_uname'"; 
	//$mod_output .= "Sql query = ".$sql;
	//$result = mysql_query($sql);
	if ($result == 1) {
		$pHNews->autorelocate("?mod=usercp", "Your account information has been succesfully updated!");
	} else {
		$pHNews->regerror(str_replace("__mysqlerror__", $result, "There was an error while saveing your account information: __mysqlerror__"));
	}
}
if ($_GET['action'] == "submit") {
	updateuser();
} 
if ($reg_fail || $_GET['action'] != "submit") {
$textsize = "180";
ob_start();
echo opentable("","align='center'");
?>
<b>Account Information</b>
<b><font color="#FF0000"><br><?=$reg_error ?></font></b>
<form method="post" action="?mod=usercp&umod=acctinfo&action=submit">
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_passwd ?>
		</td>
		<td>
			<input type="password" name="passwd"> <small><i><?=$lng_passwd_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_passwdagain ?><br><br>
		</td>
		<td>
			<input type="password" name="passwdagain"> <small><i><?=$lng_repasswd_desc ?></i></small><br><br>
		</td>
	</tr>
		<td width="<?=$textsize ?>">
			<?=$lng_emailaddress ?>
		</td>
		<td>
			<input type="text" name="email" value="<?=$user_email ?>"> <small><i><?=$lng_email_desc ?></i></small>
		</td>
	</tr>
</table>
<?=closetable() ?>
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_fname ?>
		</td>
		<td>
			<input type="text" name="fname"  value="<?=$user_fname ?>"> <small><i><?=$lng_fname_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_lname ?>
		</td>
		<td>
			<input type="text" name="lname" value="<?=$user_lname ?>"> <small><i><?=$lng_lname_desc ?></i></small>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_location ?>
		</td>
		<td>
			<input type="text" name="location" value="<?=$user_location ?>"> <small><i><?=$lng_location_desc ?></i></small>
		</td>
	</tr>
</table>
<?=closetable() ?>
<?=opentable("","") ?>
<table border=0 align=center cellspacing="0" width="100%">
	<tr>
		<td width="<?=$textsize ?>">
			<?=$lng_keepemail ?><br><br>
		</td>
		<td>
			<label for="privyes"><input type="radio" id="privyes" name="privacy" value="1" tabindex="1" /><?=$lng_keepemail_yes ?></label><br>
			<label for="privno"><input id="privno" type="radio" name="privacy" value="0" tabindex="1" checked="checked" /><?=$lng_keepemail_no ?></label> <small><i><?=$lng_keepemail_desc ?></i></small><br><br>
		</td>
	</tr>
	<tr>
		<td width="<?=$textsize ?>">
			
		</td>
		<td>
			<input type="submit" value="Save">
		</td>
	</tr>
</table>
<?=closetable() ?>
</form>
<?PHP
echo closetable();
$mod_output = ob_get_contents();
ob_end_clean();
}
?>