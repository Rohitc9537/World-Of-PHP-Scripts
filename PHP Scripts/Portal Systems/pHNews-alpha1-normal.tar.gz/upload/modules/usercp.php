<?PHP
if (eregi("admin.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php?mod=userCP");
    die();
}
$mod_td = "valign=\"top\"";
if ($loggedin != true) {
	$pHNews->infobox ($lng_not_logged_in);
} else {
	$mod_menur = $modules_dir . "/usercp/menu.php";
	$menurenabled = true;
	// userCP-Module stuff
	// Find out about the module that trying to be loaded
	// Set the $mod variable for people with register globals off
	$umod = $_GET["umod"];
	// If no mod is selected select the default (edit news)
	if ($umod == "") { $umod = "welcome"; }
	// Connect to the database...
	$link = mysql_connect($mysql_host, $mysql_user, $mysql_password)
	   or die('Could not connect: ' . mysql_error());
	// Select the database...
	mysql_select_db($mysql_database) or die('Could not select database');

	// Submit the query... god soooo mmmuuuccchhh coooodeee
	$query = "SELECT * FROM usercp_Modules WHERE name = '{$umod}'";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	
	// Make it into an array...
	$row = mysql_fetch_row($result);

	// Ok nearly there, set the location of the module's php file...
	$umod_location = $modules_dir . "/usercp/" . $row[0];
	// If the module doesnt exist in the database or dosent have its location set
	// for some reason make it use the news module ... all that connecting to
	// mySQL for nothing :'(
	if ($umod_location == $modules_dir . "/usercp/") { Header("Location: index.php?mod=usercp"); }
	// Include the module :D
	include $umod_location;
}
?>