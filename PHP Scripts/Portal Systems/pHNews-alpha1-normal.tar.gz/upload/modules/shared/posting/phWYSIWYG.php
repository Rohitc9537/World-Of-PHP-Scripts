<?PHP
	$query = "SELECT * FROM Emoteicons LIMIT 0 , 30 ";
	$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
	
	while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
		$emotes_stuff .= "theemotes.write('<a onclick=\"window.parent.addemote(this)\"><img emote=\"".$line['text']."\" src=\"".$line['location']."\" alt=\"".$line['name']."\"></a>');\n";
	}
?>
<?PHP if($editor_center == "") {?><center><? } ?><textarea name="message" id="editor_text" style="visibility:hidden;display:none;" cols="70" rows="19" value="<?=$editor_text ?>"></textarea>
<iframe id="emotes" width="100" height="300"></iframe><iframe id="editor" width="450" height="300"></iframe><?PHP if($editor_center == "") {?></center><? } ?>
<script language="javascript">
	function addemote(handle) {
			if (typeof(document.selection) != "undefined" && document.selection.type != "Text" && document.selection.type != "None")
			{
				document.selection.clear();
			}
			document.all.editor.contentWindow.focus();
			document.all.editor.contentWindow.document.selection.createRange().pasteHTML(handle.innerHTML);
	}
	function dosubmit() {
		if (mode == 2) {
			return true;
		} else {
			var htmlCode=document.all.editor.contentWindow.document.body.innerHTML;
    		document.all.editor_text.value=htmlCode;
			return true;
		}
    							
	}
	function changemode(){
		mode = 2;
		var htmlCode=document.all.editor.contentWindow.document.body.innerHTML;
    	document.all.editor_text.value=htmlCode;
		document.all.editor.style.visibility = "hidden";
		document.all.emotes.style.visibility = "hidden";
		document.all.editor.style.display = "none";
		document.all.editor_text.style.visibility = "visible";
		document.all.editor_text.style.display = "inline";
		document.all.changemode.innerHTML = "Click <a href=\"#post\" onclick=\"changemodeb()\">here</a> for rich-text mode"	
	}
	function changemodeb(){
		mode = 1;
    	document.all.editor.contentWindow.document.body.innerHTML = document.all.editor_text.value;
		document.all.editor_text.style.visibility = "hidden";
		document.all.editor_text.style.display = "none";
		document.all.editor.style.visibility = "visible";
		document.all.emotes.style.visibility = "visible";
		document.all.editor.style.display = "inline";
		document.all.changemode.innerHTML = "Click <a href=\"#post\" onclick=\"changemode()\">here</a> for HTML mode"
	}
	mode = 1;
    // var thedoc = document.getElementById(editor).contentWindow.document;
	document.all.editor_text.value=this.content;
	var thedoc = document.all.editor.contentWindow.document
	var theemotes = document.all.emotes.contentWindow.document
	thedoc.designMode='On';
    thedoc.open();
	thedoc.write('<html><head>');
    thedoc.write('<style type="text/css">@import url("<?PHP echo $css ?>");</style>');
    thedoc.write('</head><body class="mod">');
    thedoc.write('</body></html>');
	thedoc.close();
	
	theemotes.open();
	theemotes.write('<html><head>');
    theemotes.write('<style type="text/css">@import url("<?PHP echo $css ?>");</style>');
    theemotes.write('</head><body class="mod"><B>Emoteicons</b><br>');
	<?=$emotes_stuff ?>
    theemotes.write('</body></html>');
	theemotes.close();
	thedoc.body.innerHTML = "<?=$editor_text ?>";
</script> &nbsp;<br>
<?PHP if ($editor_submitbuttons == "") {?><input type="submit" value="Post"><input type="submit" value="debug" name="debug"><?PHP } ?><div id="changemode">Click <a href="#post" onclick="changemode()">here</a> for HTML mode</div>