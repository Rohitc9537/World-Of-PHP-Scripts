<?PHP
$pagefinish = microtime_float();
$pagetime = $pagefinish - $pagestart;
?>
<script language="jscript">
	exectime = <?=round($pagetime, 4) ?>;
</script>
</td>
</tr>
<tr height="15"  valign="top">
	<td valign="top">
				<center>
				<?=opentable("width='500'","") ?>
						<br><center><small>
						pHNews Copyright <ACRONYM title="Copyright">&copy;</ACRONYM> pHMicroboard 2002 - <?PHP echo date(Y) ?> All Rights Reserved.<br>
						Running pHNews ALPHA 1<br>
						Page executed in <?=round($pagetime, 4); ?> seconds.<br>
						<div id="loadedtime">Page loading...</div><p>
						</small></center>
				<?=closetable() ?>
				</center>
	</td>
</tr>
</table>
</body>
</html>