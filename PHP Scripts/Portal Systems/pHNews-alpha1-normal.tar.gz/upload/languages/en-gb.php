<?PHP
/*
IMC Language File
English-GB

HTML can be used and so can some special things:

Text surrounded in braces are variables, here is a list:
{$user_rank_id} = Current logged in user's rank id (0-7) 0 being guest and 7 being God Admin
{$user_rank} = Current logged in user's rank in human readable form
{$user_uname} = Current logged in user's user name
{$user_fname} = Current logged in user's first name
{$user_lname} = Current logged in user's last name
{$user_title} = Current logged in user's user title (not used currently)
{$user_email} = Current logged in user's email address
($sitename) = Name of this website, set in prefrences in the admin cp

Also in some strings there are special words you can enter that get replaced when outputted:
$lng_access_denied: __rank__ (the rank that you need to be to access that page)
$lng_auto_relocate: __referer__ (the page to relocate to)
$lng_reg_mysqlerror: __mysqlerror__ (the error returned by mysql)
*/
// General
$lng_yes['lcase'] = "yes";
$lng_Yes = "Yes";
$lng_YES = "YES";
$lng_no = "no";
$lng_No = "No";
$lng_NO = "NO";

// News editing
$lng_news_deleted = "The news item has been deleted";
$lng_post_mysqlerror = "There was a problem while deleting the news item, the error was: __mysqlerror__";
$lng_edit = "Edit";
$lng_delete = "Delete";
$lng_delete_conf = "Are you sure you want to delete this post?";
$lng_news_edited = "The news item has been sucessfully edited!";
$lng_edit_mysqlerror = "There was a problem while editing the news item, the error was: __mysqlerror__";

// User profiles
$lng_user_profile_notexist = "The user who you are trying to view the profile of doesn't seem to exist...";
$lng_realname = "Real Name:";
$lng_title = "Title:";
$lng_rank = "Rank:";
$lng_email_this_person = "Email this person";

// User editing
$lng_user_banned = "The user: \"__user__\" was succesfuly banned!";
$lng_user_deleted = "The user: \"__user__\" has been deleted";
$lng_user_ban_mysqlerror = "There was a problem while banning the user, the error was: __mysqlerror__";
$lng_user_delete_mysqlerror = "There was a problem while deleteing the user, the error was: __mysqlerror__";
$lng_search_for = "Search for:";
$lng_in = "in";
$lng_username = "User Name";
$lng_email_address = "Email Address";
$lng_first_name = "First Name";
$lng_last_name = "Last Name";
$lng_user_title = "User Title";
$lng_orsearch_rank = "OR Search for people with the rank:";
$lng_ban = "Ban";
$lng_view = "View";

// Posting
$lng_post_notallowed = "You have to be logged in to post, please login useing the form on the left";
$lng_title = "Title:";
$lng_posted = "Your message was successfuly posted!";
$lng_post_mysqlerror = "There was a problem while posting your message, the error was: __mysqlerror__";

// For login and logout
$lng_logout = "Logged out successfuly!";
$lng_uperror = "The password and usename you entered do not match, try logging in again";
$lng_nopasswd = "You seem to have forgoten to enter a password! Please try again...";
$lng_user = "User Name:";
$lng_passwd = "Password:";
$lng_keepsin = "Keep me signed in";
$lng_login = "Login";
$lng_rank = "Rank:";
$lng_loginmsg = "You are now logged in as {$user_uname}, welcome back!";

// User Ranks
$lng_rank_banned = "Banned";
$lng_rank_guest = "Guest";
$lng_rank_newbie = "Newbie";
$lng_rank_member = "Member";
$lng_rank_advmember = "Advanced Member";
$lng_rank_mod = "Moderator";
$lng_rank_smod = "Super Moderator";
$lng_rank_admin = "Administrator";
$lng_rank_god = "God Admin";
			
// Access errors
$lng_not_logged_in = "Sorry but you are not logged in, to access this area you must be logged in. Please log in using the box on the left...";
$lng_access_denied = "Sorry but you do not have sufficiant rights to access this area. You need to be a __rank__ or above.";

// AutoRelocateing
$lng_auto_relocate = "Please wait while you are transfered. Or click <a href=\"__location__\">here</a> if you do not wish to wait.";

// Registration
$lng_registration = "Registration";
$lng_passwdagain = "Type Password Again:";
$lng_emailaddress = "Email Address:";
$lng_user_desc = "-Your user name, this will be used to identify you.";
$lng_passwd_desc = "-You password, you will need this every time you login.";
$lng_repasswd_desc = "-Type your password agen";
$lng_email_desc = "-Make sure this is your real email address";
$lng_fname = "First Name:";
$lng_fname_desc = "-Your first name. [optional]";
$lng_lname = "Last Name:";
$lng_lname_desc = "-Your last name. [optional]";
$lng_location = "Location:";
$lng_location_desc = "-Your location (e.g. Kent, UK) [optional]";
$lng_image = "Profile Image:";
$lng_image_desc = "-The URL to the image you want shown in you profile, needs to be 150x150. [optional].";
$lng_preview = "Preview image.";
$lng_forums = "Create a forums account?";
$lng_forums_desc = "-You will have a forums account instead of a pHNews-only one. Click here for more information";
$lng_keepemail = "Keep email address private?";
$lng_keepemail_yes = "Yes, hide my email address";
$lng_keepemail_no = "No, show my email address";
$lng_keepemail_desc = "-Your email address will be showen in your profile.";
$lng_iagree = "I Agree";
$lng_idecline = "I Decline";
$lng_terms = "-Read the rules <a onclick=\"window.open('?mod=terms', 'ruleswindow', 'height=365, location=no, menubar=no, resizable=no, status=no, toolbar=no, width=545')\">here</a> then click whether you agree";
$lng_passmatch = "Your passwords dont match!";
$lng_userexists = "The username you chose is already in use, please chose another.";
$lng_nopassword = "You forgot to enter a password!";
$lng_nouser = "You forgot to enter a username!";
$lng_noemail = "You forgot to enter an email address!";
$lng_reg_successful = "User created successfuly!, Thank you for registering with {$sitename}. You can now login useing the login form on the left!";
$lng_reg_mysqlerror = "There was a problem while adding your user to the database, the error was: __mysqlerror__"
?>