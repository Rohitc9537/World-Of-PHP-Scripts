<?PHP
$theme_name = "Test";
$theme_creator = "mrmt32";
$theme_desc = "Makes your website look erm strange...";
$theme_version = "pre";
$theme_copyright = "Copyright &copy; pHMicroboard 2002-2005 all rights reserved";
$theme_preview = "$theme_dir/preview.gif";
$template = "Blue_Ice";
if (!function_exists('set_theme_vars')) {
	function set_theme_vars() {
	}
}
?>