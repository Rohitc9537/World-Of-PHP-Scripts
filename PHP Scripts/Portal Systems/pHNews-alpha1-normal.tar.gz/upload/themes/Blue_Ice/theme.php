<?PHP
/*
	Theme info
*/
$theme_dir = $themes_dir . "/" . basename(dirname(__FILE__));
$theme_name = "Blue Ice";
$theme_creator = "ff2k(graphics) and mrmt32(implementation)";
$theme_desc = "Theme with blue ice-like structures, made for IM-Century.";
$theme_version = "pre";
$theme_copyright = "Copyright &copy; pHMicroboard 2002-2005 all rights reserved";
$theme_preview = "preview.gif";
$template = "Blue_Ice";
if (!function_exists('set_theme_vars')) {
function set_theme_vars() {
	global $themes_dir;
	$theme_dir = $themes_dir . "/" . basename(dirname(__FILE__));
	// Set background picture...
	$GLOBALS['background_pic'] = $theme_dir . "/" . "Background-possibility.gif";
	
	// Icon for new comments
	$GLOBALS['new_messages'] = $theme_dir . "/" . "alert.png";
	
	// Location for the picture that is displayed when a user
	// hasnt set a user picture
	$GLOBALS['no_pic_icon'] = $theme_dir . "/" . "no_pic.gif";
	
	/*
		Location of CSS file for setting colors etc...
	*/
	$GLOBALS['css'] = $theme_dir . "/" . "style.css";
	
	/*
		Location of images for the header (logo)
		See left.gif, extendable.gif, logo.gif and right.gif
		for examples...
	*/
	$GLOBALS['head_height'] = "100"; // height of the images
	$GLOBALS['head_logo'] = $theme_dir . "/" . "phnews-logo.gif";
	$GLOBALS['menu_connect'] = $theme_dir . "/" . "menu_connect.png";
	
	/*
		Menu-Bar Settings
		$menu_custom_graphics = Can be 1, 2 or 3:
								1 - Use custom graphics defined
								2 - Use custom graphics with border (works like tables)
								3 - Use graphics from tables
		$menu_width = Width of the menu
	
		MODE 1:
			$menu_top = The top bit /���������\
			$menu_top_height = Hight of the top bit
			$menu_body = The body, gets repeated downwards (see menubuttonbg2.gif)
			$menu_bottom = The bottom bit \__________/
			$menu_bottom_height = Height of the bottom bit
	
		MODE 2:
		
	*/
	$GLOBALS['menu_custom_graphics'] = 2;
	$GLOBALS['menu_width'] = "189";

	// MODE 1
	$GLOBALS['menu_top'] = $theme_dir . "/" . "";
	$GLOBALS['menu_top_height'] = "38";
	$GLOBALS['menu_body'] = $theme_dir . "/" . "";
	$GLOBALS['menu_bottom'] = $theme_dir . "/" . "";
	$GLOBALS['menu_bottom_height'] = "10";

	// MODE 2
	$GLOBALS['menu_top2'] = $theme_dir . "/" . "table_mt2.gif";	 		// Orange in gude [repeated accross]
	$GLOBALS['menu_top_left'] = $theme_dir . "/" . "table_lt2.gif";		// Dark blue in guide (the one on the left)
	$GLOBALS['menu_top_right'] = $theme_dir . "/" . "table_rt2.gif";		// Brown in guide
	$GLOBALS['menu_body2'] = $theme_dir . "/" . "";						// White in guide (in the middle) this is where the text goes...
	$GLOBALS['menu_body_left'] = $theme_dir . "/" . "table_lm2.gif";		// Bright green in guide [repeated down]
	$GLOBALS['menu_body_right'] = $theme_dir . "/" . "table_rm2.gif";		// Blue in guide [repeated down]
	$GLOBALS['menu_bottom2'] = $theme_dir . "/" . "table_mb2.gif";			// Bright blue in guide [repeated accross]
	$GLOBALS['menu_bottom_left'] = $theme_dir . "/" . "table_lb2.gif";		// Dark green in guide
	$GLOBALS['menu_bottom_right'] = $theme_dir . "/" . "table_rb2.gif";	// Bright yellow in guide
	
	/*
		Images for tables
		for info on what each image is see http://imc.phmicroboard.com/theme_table_guide.gif
	*/
	$GLOBALS['table_top'] = $theme_dir . "/" . "table_mt2.gif";	 		// Orange in gude [repeated accross]
	$GLOBALS['table_top_left'] = $theme_dir . "/" . "table_lt4.gif";		// Dark blue in guide (the one on the left)
	$GLOBALS['table_top_right'] = $theme_dir . "/" . "table_rt4.gif";		// Brown in guide
	$GLOBALS['table_body'] = $theme_dir . "/" . "";						// White in guide (in the middle) this is where the text goes...
	$GLOBALS['table_body_left'] = $theme_dir . "/" . "table_lm2.gif";		// Bright green in guide [repeated down]
	$GLOBALS['table_body_right'] = $theme_dir . "/" . "table_rm2.gif";		// Blue in guide [repeated down]
	$GLOBALS['table_bottom'] = $theme_dir . "/" . "table_mb2.gif";			// Bright blue in guide [repeated accross]
	$GLOBALS['table_bottom_left'] = $theme_dir . "/" . "table_lb4.gif";	// Dark green in guide
	$GLOBALS['table_bottom_right'] = $theme_dir . "/" . "table_rb4.gif";	// Bright yellow in guide
}
}
?>