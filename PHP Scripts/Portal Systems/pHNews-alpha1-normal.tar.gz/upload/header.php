<?PHP
// Stuff to find out how long it took to load...
function microtime_float()
{
   list($usec, $sec) = explode(" ", microtime());
   return ((float)$usec + (float)$sec);
}
$pagestart = microtime_float();

// Include the almighty config file, ok maby not that almighty....
include "config.php";

// Open preferences table:
// start the pHNews engine
include "./backend/engine2.php";
$pHNews = new pHNews($mysql_host, $mysql_user, $mysql_password, $mysql_database);

// Get preferences
$pref = $pHNews->get_preferences($shared_dir, $languages_dir);
if ($pref != "error"){
	extract($pref);
} else {
	die($pHNews->lasterror['error']);
}

$home_location = parse_url ("http://".$_SERVER['SERVER_NAME'].":".$_SERVER['SERVER_PORT'].$_SERVER['PHP_SELF']);
$version = "pHNews Preview 3";


// Allow PNG-24 transparency in IE
function png_24_trans($image, $width, $height){
	$text = "<span style=\"width:".$width."px;height:".$height."px; filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='".$image."');\"><br>
		<img style=\"filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0);\" src=\"".$image."\" width=\"".$width."\" height=\"".$height."\" border=\"0\" alt=\"\"></span>";
	return $text;
}
?>
<?PHP
// Protect variables, dont want people setting these...
		unset ( $logedin, $user_rank, $user_title);
		unset ($user_theme, $user_location, $user_email, $user_id );
// See if the person is logged in
  $IMClogin = $_COOKIE[md5($sitename)];
  $IMClogin = addslashes(base64_decode($IMClogin));
  $IMClogin = explode(":", $IMClogin);
  $uid = $IMClogin[0];
  $user = $IMClogin[1];
  $passwd = $IMClogin[2];
  $user_rank = $IMClogin[3];
  $user_theme = $IMClogin[4];
  
  $result = $pHNews->login($user, $passwd);
  if ($result == 1) {
	// Include language file
	include $lngfile_location;
	// Set users vars...
	$pHNews->set_user_vars();
  } else {
	// User didnt validate properly, maby a hack attempt
  	unset($passwd, $user_theme, $user, $uid);
  	$user_rank_id = 0;
  }
	
	/* CODE FOR THEMEING*/
	$resultb = mysql_query("SELECT * FROM Themes");
	while ($lineb = mysql_fetch_array($resultb, MYSQL_ASSOC)) {
		if ($lineb['id'] == $default_theme) { $default_theme_loc = $lineb['Location'];}
		if ($lineb['id'] == $user_theme && !$theme_included){
			include "./".$themes_dir."/{$lineb['Location']}/theme.php";
			set_theme_vars();
			// Include the main template file
			include "./$templates_dir/$template/main.php";
			$theme_included = true;
			$theme_id = $lineb['id'];
		}
	}
  	if (!$theme_included) {
			include "./".$themes_dir."/$default_theme_loc/theme.php";
			set_theme_vars();
			// Include the main template file
			include "./$templates_dir/$template/main.php";
			$theme_included = true;
			$theme_id = $default_theme;
	}
	/*        END      */
  
?>
<?PHP include $lngfile_location ?>
<?PHP
// Find out about the module that trying to be loaded
// Set the $mod variable for people with register globals off
$mod = $_GET["mod"];
// If no mod is selected select the default (news)
if ($mod == "") { $mod = "news"; }
if ($mod != "nomod") {

// Subit the query... god soooo mmmuuuccchhh coooodeee
$query = "SELECT * FROM Modules WHERE name = '{$mod}'";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());

// Make it into an array...
$row = mysql_fetch_row($result);

// Ok nearly there, set the location of the module's php file...
$mod_location = $modules_dir . "/" . $row[0];
// If the module doesnt exist in the database or dosent have its location set
// for some reason make it use the news module ... all that connecting to
// mySQL for nothing :'(
if ($mod_location == $modules_dir . "/") { Header("Location: index.php?mod=news"); }
// Include the module :D
include $mod_location;
}
?>


<html>
<head>
<?=template_head() ?>
<title><?=$sitename ?></title>
<?=$mod_meta ?>
<LINK href="<?PHP echo $css ?>" type=text/css rel=STYLESHEET>
</head>
<body background="<?=$background_pic ?>" onload="page_loaded()"><br>
<?PHP
if ($mod_popup) {
	// echo $mod_output;
}else{
	echo template_head_body();
} ?>