<?PHP
Header("Location: indexfix.php");
?>