<?PHP
// Config file

// MySQL stuff:
$mysql_host = "";
$mysql_user = "";
$mysql_password = "";
$mysql_database = "";

// Time stuff
$timeoffset = 5;

// Directiory Settings
$themes_dir = "themes";
$modules_dir = "modules";
$languages_dir = "languages";
$shared_dir = $modules_dir . "/shared";
$js_dir = "javascript";
$templates_dir = "templates";

/***********************************/
/*   DO NOT EDIT BELOW THIS LINE   */
/***********************************/
// Time offset stuff
$ctimedate = getdate();
$chour = $ctimedate["hours"] + $timeoffset;
if ($chour > 12) { $chour = $chour - 12; }

if (eregi("config.php",$_SERVER['PHP_SELF'])) {
	Header("Location: index.php");
	die();
}
?>