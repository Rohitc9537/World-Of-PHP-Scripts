<?PHP include "header.php" ?>
<?PHP
if ($mod_popup) {
	echo $mod_output;
	echo "</body></html>";
}else{
?>
	<?=template_index() ?>
	<?PHP include "footer.php" ?>
<?PHP } ?>