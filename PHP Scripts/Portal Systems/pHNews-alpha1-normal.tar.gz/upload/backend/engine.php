<?PHP
class pHNews {
	function pHNews() {
	
	}
	function parse_body($data) {
		//$data = preg_replace('/&(?!#[0-9]+;)/si', '&amp;', utf8_encode (htmlentities(strip_tags($data))));
		//return str_replace(array('<', '>', '"'), array('&lt;', '&gt;', '&quot;'), $data);
		$data = str_replace("&nbsp;", " ", $data);
		$data = htmlentities(html_entity_decode($data), ENT_NOQUOTES);
		$data = str_replace("�", "&trade;", $data);
		return $data;
	}
	function return_news($type="pHNews") {
		extract($GLOBALS);
		switch($type) {
			case "rss2":
				include "backend/rssfeed.php";
			break;
			case "pHNews":
			default:
				header("Content-type: text/xml");
				echo "<?xml version=\"1.0\"?>";
				?>
				<phnewsdata type="news">
				<?PHP
				// Performing SQL query
				$query = 'SELECT * FROM `News` ORDER BY `id` DESC';
				$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
		
				while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
					?>
					<post>
        		 		<title><?=$this->parse_body($line['title']) ?></title>
        		 		<link><?=$location."?mod=comments&amp;id=".$line['id'] ?></link>
						<body><![CDATA[<?=$this->parse_body($line['body']) ?>]]></body>
        				<timestamp><?=$line['timestamp'] ?></timestamp>
        				<id><?=$line['id'] ?></id>
						<author><?=$line['user'] ?></author>
					</post>
					<?PHP
				}
				?>
				</phnewsdata>
				<?PHP
			break;
		} 
	}
	function list_users() {
		header("Content-type: text/xml");
		echo "<?xml version=\"1.0\"?>";
		?>
		<phnewsdata type="userlist">
			<userlist>
				<?PHP
				$sql = "SELECT * FROM `Users`";
				$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
				while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
					?>
					<user>
						<id><?=$line['id'] ?></id>
						<username><?=htmlentities($line['UName']) ?></username>
						<title><?=htmlentities($line['UTitle']) ?></title>
						<fname><?=htmlentities($line['FName']) ?></fname>
						<lname><?=htmlentities($line['LName']) ?></lname>
						<location><?=htmlentities($line['Location']) ?></location>
						<picture><?=htmlentities($line['picture']) ?></picture>
						<rankid><?=$line['Rankid'] ?></rankid>
						<?PHP if($line['privacy'] == 1) { ?>
							<email><?=htmlentities($line['Email']) ?></email>
						<?PHP } ?>
					</user>
					<?PHP
				}
				?>
			</userlist>
		</phnewsdata>
		<?PHP
	}
	function get_user_info($id) {
		header("Content-type: text/xml");
		echo "<?xml version=\"1.0\"?>";
		?>
		<phnewsdata type="user">
			<?PHP
			$sql = "SELECT * FROM `Users` WHERE id = '$id'";
			$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
			$line = mysql_fetch_array($result, MYSQL_ASSOC)
			?>
			<user>
				<id><?=$line['id'] ?></id>
				<username><?=$this->parse_body($line['UName']) ?></username>
				<title><?=$this->parse_body($line['UTitle']) ?></title>
				<fname><?=$this->parse_body($line['FName']) ?></fname>
				<lname><?=$this->parse_body($line['LName']) ?></lname>
				<location><?=$this->parse_body($line['Location']) ?></location>
				<picture><?=$this->parse_body($line['picture']) ?></picture>
				<rankid><?=$line['Rankid'] ?></rankid>
				<?PHP if($line['privacy'] == 1) { ?>
					<email><?=parse_body($line['Email']) ?></email>
				<?PHP } ?>
			</user>
		</phnewsdata>
		<?PHP
	}
	function get_comments($id) {
		header("Content-type: text/xml");
		echo "<?xml version=\"1.0\"?>";
		?>
		<phnewsdata type="comments">
			<?PHP
			$query = "SELECT * FROM Comments WHERE Pid='{$id}' ORDER BY `id` DESC";
			$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
			while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
					?>
					<comment>
						<id><?=$line['id'] ?></id>
						<title><?=$line['Title'] ?></title>
						<body><?=$line['Body'] ?></body>
						<author><?=$line['User'] ?></author>
						<postid><?=$line['Pid'] ?></postid>
						<timestamp><?=$line['Timestamp'] ?></timestamp>
					</comment>
					<?PHP
			}
			?>
		</phnewsdata>
		<?PHP
	}
	function post_comment($id, $body, $title, $user, $password) {
		extract($GLOBALS);
		global $modules_dir;
		global $loggedin, $user_id, $user_rank_id, $user_uname, $user_fname, $user_lname, $user_email, $user_title, $user_location, $user_theme,
			$user_pic, $row, $user_rank, $idtorank, $user_views;
		$backend = true;
		$login = $this->temp_login($user, $password);
		$_POST['message'] = $body;
		$_POST['title'] = $title;
		$_GET['id'] = $id;

		if ($login == "success") {
			include "./$modules_dir/comments/submit.php";
		} else {
			return array("login", $login);
		}
		
		if ($fail) {
			return array("post", $error);
		} else {
			return true;
		}
	}
	function temp_login($user, $password) {
		global $loggedin, $user_id, $user_rank_id, $user_uname, $user_fname, $user_lname, $user_email, $user_title, $user_location, $user_theme,
			$user_pic, $row, $user_rank, $idtorank, $user_views;
		extract($GLOBALS);
		include "mod_functions.php";
		$passwdmd5 = md5($password);
		if ($passwdmd5 == "") {
			return "no_passwd";
		} else {
			$link = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die('Could not connect: ' . mysql_error());
			mysql_select_db($mysql_database) or die('Could not select database');
			$sql = "SELECT * FROM Users WHERE UName='$user'";
			$result = mysql_query($sql) or die(mysql_error());
			$row = mysql_fetch_row($result);
			// $mod_output = $passwd . $row[3];
			if ($row[3] != $passwdmd5) {
				return "wrong_info";
			}
			// User validated
			// Set variables
			set_user_vars();
			return "success";
		}
	}
	function get_news_item($id, $type="pHNews") {
		switch($type) {
			case "pHNews":
			default:
				header("Content-type: text/xml");
				echo "<?xml version=\"1.0\"?>";
				?>
				<phnewsdata type="news_item">
				<?PHP
				// Performing SQL query
				$query = "SELECT * FROM `News` WHERE `id` = '$id' ORDER BY `id` DESC";
				$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
				$line = mysql_fetch_array($resultf, MYSQL_ASSOC);
				?>
					<post>
        		 		<title><?=$this->parse_body($line['title']) ?></title>
        		 		<link><?=$location."?mod=comments&amp;id=".$line['id'] ?></link>
						<body><![CDATA[<?=$this->parse_body($line['body']) ?>]]></body>
        				<timestamp><?=$line['timestamp'] ?></timestamp>
        				<id><?=$line['id'] ?></id>
						<author><?=$line['user'] ?></author>
					</post>
				</phnewsdata>
				<?PHP
			break;
		}
	}
}
?>