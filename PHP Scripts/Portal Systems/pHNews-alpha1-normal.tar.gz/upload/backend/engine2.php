<?PHP
class pHNewsCore {
	var $lasterror;
	function __construct($mysql_host, $mysql_user, $mysql_password, $mysql_database) {
		// PHP5 Compatibility
		$this->pHNews($mysql_host, $mysql_user, $mysql_password, $mysql_database);
	}
	function pHNews($mysql_host, $mysql_user, $mysql_password, $mysql_database) {
		global $link;
		$link = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die('Could not connect: ' . mysql_error());
		mysql_select_db($mysql_database) or die('Could not select database'); 
	}
	function make_xml($data) {
		//$data = preg_replace('/&(?!#[0-9]+;)/si', '&amp;', utf8_encode (htmlentities(strip_tags($data))));
		//return str_replace(array('<', '>', '"'), array('&lt;', '&gt;', '&quot;'), $data);
		$data = str_replace("&nbsp;", " ", $data);
		$data = htmlentities(html_entity_decode($data), ENT_NOQUOTES);
		$data = str_replace("�", "&trade;", $data);
		return $data;
	}
	function get_preferences($shared_dir = "", $languages_dir = "") {
		$result = mysql_query("SELECT * FROM Preferences");
		if (!$result) {
			$this->lasterror = array('function' => "get_preferences", 'error' => mysql_error());
			return "error";
		} else {
  			$row = mysql_fetch_array($result, MYSQL_ASSOC);
			$thearr = $row;
			// Some backwars compatability stuff:
			$thearr['sitename'] = $row['Site_name'];
			$thearr['messagespp'] = $row['Page_Limit'];
			$thearr['statusbartext'] = $row['Status_Bar'];
			if ($shared_dir == "") {
				$thearr['message_parser'] = $row['Message_Parser'];
				$thearr['editor_location'] = $row['Editor'];
			} else {
				$thearr['message_parser'] = "./" . $shared_dir . "/".$row['Message_Parser'];
				$thearr['editor_location'] = "./" . $shared_dir . "/posting/".$row['Editor'];
			}
			if ($languages_dir == "") {
				$thearr['lngfile_location'] = $row['Language'];
			} else {
				$thearr['lngfile_location'] = "./".$languages_dir."/{$row['Language']}.php";
			}
			$thearr['language'] = $row['Language'];
			$thearr['default_theme'] = $row['Theme'];
			return $thearr;
		}
	}
	function set_preferences($msgparser, $pglimit, $status, $sname, $lan, $theme, $editor, $fmsg) {
		$sql = "UPDATE `Preferences` SET `Message_Parser` = '$msgparser', ";
		$sql .=	"`Page_Limit` = '$pglimit', ";
		$sql .=	"`Status_Bar` = '$status', ";
		$sql .=	"`Site_name` = '$sname', ";
		$sql .=	"`Language` = '$lan', ";
		$sql .=	"`Theme` = '$theme', ";
		$sql .=	"`Editor` = '$editor', ";
		$sql .=	"`FirstMsg` = '$fmsg'";
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
			//return $sql;
		}
	}
}
include "functions.php";
include "comments.php";
include "users.php";
include "news.php";
?>