<?PHP
class pHNewsComments extends pHNewsFunctions{
	function get_comments($id) {
		$query = "SELECT * FROM Comments WHERE Pid='{$id}' ORDER BY `id` DESC";
		$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
		while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
			$id = $line['id'];
			$comments[$id]['Title'] = $line['Title'];
			$comments[$id]['Body'] = $line['Body'];
			$comments[$id]['User'] = $line['User'];
			$comments[$id]['Pid'] = $line['Pid'];
			$comments[$id]['Timestamp'] = $line['Timestamp'];

		}
		return $comments;
	}
	function post_comment($id, $body, $title, $user) {
		extract($GLOBALS);
		global $modules_dir;
		$backend = true;
		$sql = "INSERT INTO `Comments` ( `id` , `Title` , `Body` , `User` , `Pid` ) 
			VALUES (
			'', '{$title}', '{$body}', '{$user}', '{$id}');"; 
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
		}
	}
	function countcomments($id) {
		global $user_views, $comments_count;
		$query = "SELECT * FROM Comments WHERE Pid='{$id}' ORDER BY `id` DESC";
		$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
		$i = 0;
		while ($lineb = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
			$i++;
		}
		mysql_free_result($resultf);
		return $i;
	}
}
?>