<?PHP
class pHNews extends pHNewsUsers {
	function get_news_item($id) {
		$query = "SELECT * FROM `News` WHERE `id` = '$id' ORDER BY `id` DESC";
		$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
		$line = mysql_fetch_array($resultf, MYSQL_ASSOC);
		$id = $line['id'];
		$news_item['title'] = $line['title'];
		$news_item['body'] = $line['body'];
        $news_item['timestamp'] = $line['timestamp'] ;
		$news_item['user'] = $line['user'];
		$news_item['id'] = $id;
		return $news_item;
	}
	function return_news() {
		extract($GLOBALS);
		// Performing SQL query
		$query = 'SELECT * FROM `News` ORDER BY `id` DESC';
		$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());

		while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
			$id = $line['id'];
			$news_items[$id]['title'] = $line['title'];
			$news_items[$id]['body'] = $line['body'];
        	$news_items[$id]['timestamp'] = $line['timestamp'] ;
			$news_items[$id]['user'] = $line['user'];
			$news_items[$id]['comments'] = $line['comments'];
			$news_items[$id]['id'] = $id;
		}
		return $news_items;
	}
	function edit_news($body, $title, $id) {
		$sql = "UPDATE `News` SET `body` = '".$body."', `title` = '".$title."' WHERE `id` = ".$id.";"; 
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
		}
	}
	function delete_news($id) {
		$sql = "DELETE FROM `News` WHERE `id` = ".$id.";"; 
		$result = mysql_query($sql);
		if ($result) {
			$sql = "DELETE FROM `Comments` WHERE `Pid` = ".$id.";"; 
			$result = mysql_query($sql);
			if ($result) {
				return true;
			} else {
				return mysql_error();
			}
		} else {
			return mysql_error();
		}
	}
}
?>