<?PHP
class pHNewsFunctions extends pHNewsCore {
// General functions
function isnew_comments($id) {
	global $user_views, $comments_count;
	$query = "SELECT Timestamp FROM Comments WHERE Pid='{$id}' ORDER BY `id` DESC";
	$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
	$i = 0;
	while ($lineb = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
		//echo $line['id']."-".date("l dS of F Y h:i:s A", mysql_timestamp_tophp($lineb['Timestamp']))."-".date("l dS of F Y h:i:s A", $user_views[$line['id']])."-".$lineb['TDiff']."<br>";
		if ($this->mysql_timestamp_tophp($lineb['Timestamp']) > $user_views[$id]) { return true; }
		$i++;
	}
	$comments_count[$id] = $i;
	mysql_free_result($resultf);
}
function mysql_timestamp_tophp($timestamp){
	$exploaded = preg_split('//', $timestamp, -1, PREG_SPLIT_NO_EMPTY);
	$year = $exploaded[0].$exploaded[1].$exploaded[2].$exploaded[3];
	$month = $exploaded[4].$exploaded[5];
	$day = $exploaded[6].$exploaded[7];
	$hour = $exploaded[8].$exploaded[9];
	$minute = $exploaded[10].$exploaded[11];
	$second = $exploaded[12].$exploaded[13];
	return mktime ($hour, $minute, $second, $month, $day, $year);
}
function implodeAssoc($glue,$arr) 
{ 
   $keys=array_keys($arr); 
   $values=array_values($arr); 

   return(implode($glue,$keys).$glue.implode($glue,$values)); 
}
function explodeAssoc($glue,$str) 
{ 
   $arr=explode($glue,$str); 

   $size=count($arr); 

   for ($i=0; $i < $size/2; $i++) 
       $out[$arr[$i]]=$arr[$i+($size/2)]; 

   return($out); 
}
function mott() {
	global $mod_output;
	$mod_output .= "MOTT";
}
function autorelocate($location, $text) {
	global $mod_output, $lng_auto_relocate, $mod_meta;
	$mod_meta .= "<meta http-equiv='refresh' content='1; url=$location' />";
	$this->infobox($text . "<br><br>" . str_replace ( "__location__", $location, $lng_auto_relocate));
}
function infobox($text) {
	global $mod_output;
	$mod_output .= opentable("","align=\"center\"")."<center>".$text."</center>".closetable();
}
function infoboxr($text) {
	global $mod_output;
	return opentable("","align=\"center\"")."<center>".$text."</center>".closetable();
}
function idtorank($id) {
		global $lng_rank_banned, $lng_rank_guest, $lng_rank_newbie, $lng_rank_member, $lng_rank_advmember,
				$lng_rank_mod, $lng_rank_smod, $lng_rank_admin, $lng_rank_god;
		switch($id) {
		case -1:
			$user_rank = $lng_rank_banned;
		break;
		case 0:
			$user_rank = $lng_rank_guest;
		break;
		case 1:
			$user_rank = $lng_rank_newbie;
		break;
		case 2:
			$user_rank = $lng_rank_member;
		break;
		case 3:
			$user_rank = $lng_rank_advmember;
		break;
		case 4:
			$user_rank = $lng_rank_mod;
		break;
		case 5:
			$user_rank = $lng_rank_smod;
		break;
		case 6:
			$user_rank = $lng_rank_admin;
		break;
		case 7:
			$user_rank = $lng_rank_god;
		break;
	}
	return $user_rank;
}
function set_user_vars() {
	global $loggedin, $user_id, $user_rank_id, $user_uname, $user_fname, $user_lname, $user_email, $user_title, $user_location, $user_theme,
			$user_pic, $row, $user_rank, $idtorank, $user_views;
		
	$loggedin = true;
	$user_id = $row[0];
	$user_rank_id = $row[1];
	$user_uname = $row[2];
	$user_fname = $row[4];
	$user_lname = $row[5];
	$user_email = $row[6];
	$user_title = $row[7];
	$user_location = $row[8];
	$user_views = $this->explodeAssoc("&", $row[13]);
	$user_theme = $row[9];
	$user_pic = $row[10];
	// Work out rank...
	$user_rank = $this->idtorank($user_rank_id);
	//if ($user_rank_id == -1) { return true; } else { return false; }
}

function str_Ireplace($search, $replace, $subject) {
  if (is_array($search)) {
   foreach ($search as $word) {
   $words[] = "/".$word."/i";
   }
  }
  else {
   $words = "/".$search."/i";
  }
  return preg_replace($words, $replace, $subject);
}
function regerror($text) {
	global $reg_error, $reg_fail;
	$reg_fail = true;
	$reg_error = $text;
}
function parse_message($text) {
	// Find emoteicon things :)
	$text = preg_replace("#<img[^>]+emote=\\\\\"(.*)\\\\\".*>#siU", "\\1", $text);
	// Performing SQL query
	$query = "SELECT * FROM Emoteicons";
	$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
	
	while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
		$text = str_replace($line['text'], "<emote id=\"".$line['id']."\">", $text);
	}
	return $text;
}
function parse_emote($id) {
	// Performing SQL query
	$query = "SELECT * FROM Emoteicons WHERE id=".$id;
	$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());
	$debug_output .= "id = ".$id."\n";
	while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
		$text = "<img emote=\"".$line['text']."\" src=\"".$line['location']."\" alt=\"".$line['name']."\">";
	}
	return $text;
}
function parse_message_after($text) {
	// Find emoteicon things :)
	$text = preg_replace("#<emote[^>]+id=\\\"(.*)\\\".*>#esiU", "$this->parse_emote(\\1)", $text);
	return $text;
}

}
?>