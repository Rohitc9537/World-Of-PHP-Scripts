<?PHP
class pHNewsUsers extends pHNewsComments {
	function edit_user($id, $rank, $user, $password, $fname, $lname, $email, $title, $location, $theme, $picture, $privacy){
		$passwdmd5 = md5($password);
		$sql = "UPDATE `Users` SET"; 
		if ($rank != "[dontset]") 		 $sql .= "`Rankid` = '$rank', ";
		if ($user != "[dontset]") 		 $sql .= "`UName` = '$user', ";
		if ($password != "") 			 $sql .= "`Paswd` = '$passwdmd5', ";
		if ($fname != "[dontset]")	 	 $sql .= "`FName` = '$fname', ";
		if ($lname != "[dontset]")	 	 $sql .= "`LName` = '$lname', ";
		if ($email != "[dontset]")		 $sql .= "`Email` = '$email', ";
		if ($title != "[dontset]")		 $sql .= "`UTitle` = '$title', ";
		if ($location != "[dontset]") 	 $sql .= "`Location` = '$location', ";
		if ($theme != "[dontset]") 		 $sql .= "`Theme` = '$theme', ";
		if ($picture != "[dontset]") 	 $sql .= "`picture` = '$picture', ";
		if ($privacy != "[dontset]") 	 $sql .= "`privacy` = '$privacy', "; 
										 $sql .= "`id` = '$id'";
										 $sql .= "WHERE `id` = $id";
		
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
		}
	}
	function delete_user($id) {
		$sql = "DELETE FROM `Users` WHERE `id` = '".$id."'"; 
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
		}
	}
	function change_rank($id, $rank) {
		$sql = "UPDATE `Users` SET `Rankid` = '$rank' WHERE `id` = '".$id."'"; 
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return mysql_error();
		}
	}
	function search_users($string, $type) {
		$sql = "SELECT * FROM `Users` WHERE `".$type."` LIKE '%{$string}%'";
		$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$id = $line['id']; 
			$users[$id]['id'] = $line['id'];
			$users[$id]['UName'] = $line['UName'];
			$users[$id]['UTitle'] = $line['UTitle'];
			$users[$id]['FName'] = $line['FName'];
			$users[$id]['LName'] = $line['LName'];
			$users[$id]['Location'] = $line['Location'];
			$users[$id]['picture'] = $line['picture'];
			$users[$id]['Rankid'] = $line['Rankid'];
			$users[$id]['privacy'] = $line['privacy'];
			$users[$id]['Email'] = $line['Email'];
		}
		return $users;
	}
	function list_users() {
		$sql = "SELECT * FROM `Users`";
		$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$id = $line['id']; 
			$users[$id]['UName'] = $line['UName'];
			$users[$id]['UTitle'] = $line['UTitle'];
			$users[$id]['FName'] = $line['FName'];
			$users[$id]['LName'] = $line['LName'];
			$users[$id]['Location'] = $line['Location'];
			$users[$id]['picture'] = $line['picture'];
			$users[$id]['Rankid'] = $line['Rankid'];
			$users[$id]['privacy'] = $line['privacy'];
			$users[$id]['Email'] = $line['Email'];
		}
		return $users;
	}
	function get_user_info($id, $usere = "") {
		if ($id != "") {
			$sql = "SELECT * FROM `Users` WHERE id = '$id'";
		} elseif ($usere != "") {
			$sql = "SELECT * FROM `Users` WHERE UName = '$usere'";
		} else {
			return false;
		}
		$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
		$line = mysql_fetch_array($result, MYSQL_ASSOC);
		$id = $line['id']; 
		$user['UName'] = $line['UName'];
		$user['UTitle'] = $line['UTitle'];
		$user['FName'] = $line['FName'];
		$user['LName'] = $line['LName'];
		$user['Location'] = $line['Location'];
		$user['picture'] = $line['picture'];
		$user['Rankid'] = $line['Rankid'];
		$user['privacy'] = $line['privacy'];
		$user['Email'] = $line['Email'];
		return $user;
	}
	function login($user, $password) {
		extract($GLOBALS);
		global $row;
		$passwdmd5 = $password;
		if ($passwdmd5 == "") {
			return "no_passwd";
		} else {
			$link = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die('Could not connect: ' . mysql_error());
			mysql_select_db($mysql_database) or die('Could not select database');
			$sql = "SELECT * FROM Users WHERE UName='$user'";
			$result = mysql_query($sql) or die(mysql_error());
			$row = mysql_fetch_row($result);
			// $mod_output = $passwd . $row[3];
			if ($row[3] != $passwdmd5) {
				return "wrong_info";
			}
			// User validated
			return true;
		}
	}
}
?>