<?PHP
header("Content-type: text/xml");
//header("Content-type: text/plain");
// Include core files
include "mod_functions.php";
$location = $home_location['scheme'] . "://" . $home_location['host'] . dirname($home_location['path'])."/";

?>
<?PHP echo "<?xml version=\"1.0\"?>"; ?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:syn="http://purl.org/rss/1.0/modules/syndication/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" encoding="ISO-8859-1;">
   <channel>
      <title><?=$sitename ?></title>
      <link><?=$location ?></link>
      <description><?=$site_desc ?></description>
      <language><?=$language ?></language>
      <docs>http://blogs.law.harvard.edu/tech/rss</docs>
      <generator><?=$version ?></generator>
      <managingEditor><?=$admin_email ?></managingEditor>
      <webMaster><?=$admin_email ?></webMaster>
      
	  	<?PHP
		// Performing SQL query
		$query = 'SELECT * FROM `News` ORDER BY `id` DESC';
		$resultf = mysql_query($query) or die('Query failed: ' . mysql_error());

		while ($line = mysql_fetch_array($resultf, MYSQL_ASSOC)) {
			?>
			<item>
         	<title><?=$line['title'] ?></title>
         	<link><?=$location."?mod=comments&amp;id=".$line['id'] ?></link>
			<content:encoded><![CDATA[<?=$this->parse_body($line['body']) ?>]]></content:encoded>
        	<pubDate><?=date ("r" ,mysql_timestamp_tophp($line['timestamp'])) ?></pubDate>
        	<guid><?=$location."?mod=comments&amp;id=".$line['id'] ?></guid>
			<dc:creator><?=$line['user'] ?></dc:creator>
			</item>
			<?PHP
		}
		?>
      
   </channel> 
</rss> 