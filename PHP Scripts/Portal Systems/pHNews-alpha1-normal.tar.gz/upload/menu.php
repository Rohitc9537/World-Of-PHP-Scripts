<?PHP
if (eregi("menu.php",$_SERVER['PHP_SELF'])) {
    Header("Location: index.php");
    die();
}
// Functions for tables in mode 2


// Unset custom graphics settings if custom graphics are disbled
if ($menu_custom_graphics) {
	
} else {
	unset( $menu_top, $menu_top_height, $menu_body, $menu_bottom, $menu_bottom_height);
}
// Connecting, selecting database
$link = mysql_connect($mysql_host, $mysql_user, $mysql_password)
   or die('Could not connect: ' . mysql_error());
// echo 'Connected successfully';
mysql_select_db($mysql_database) or die('Could not select database');

// Performing SQL query
$query = 'SELECT * FROM Sections ORDER BY `order` ASC';
$queryb = 'SELECT * FROM Items ORDER BY `order` ASC';
$result = mysql_query($query) or die('Query failed: ' . mysql_error());
$resultb = mysql_query($queryb) or die('Query failed: ' . mysql_error());

// Printing results in HTML
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	if ($line["userlevel"] <= $user_rank_id) {
		$sid = $line['sid'];
		echo template_menu('top', $menu_width, $line);
		while ($lineb = mysql_fetch_array($resultb, MYSQL_ASSOC)) {
			if ($lineb['catid'] == $line['sid'] & $lineb['userlevel'] <= $user_rank_id ){
				
				$iid = $lineb['id'];
				echo template_menu('body', $menu_width, $lineb);
			}
		}
		mysql_data_seek($resultb, 0);
		echo template_menu('bottom', $menu_width, "");
	}
	
}

	unset($tmp_ended, $tmp_endedb);
mysql_free_result($result);
mysql_close($link);


?> 
<?=template_menu('under', $menu_width, "") ?>
