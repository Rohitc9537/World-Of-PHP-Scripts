-- pHNews Installation mySQL script


-- pHNews info: StartCT

-- pHNews info: Table-Admin_Items

DROP TABLE IF EXISTS `Admin_Items`;
CREATE TABLE `Admin_Items` (
  `id` int(10) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL default '',
  `catid` int(10) NOT NULL default '0',
  `url` varchar(100) NOT NULL default '',
  `desc` varchar(50) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-Admin_Modules

DROP TABLE IF EXISTS `Admin_Modules`;
CREATE TABLE `Admin_Modules` (
  `Location` varchar(100) NOT NULL default '',
  `name` varchar(20) NOT NULL default ''
) TYPE=MyISAM;


-- pHNews info: Table-Admin_Sections

DROP TABLE IF EXISTS `Admin_Sections`;
CREATE TABLE `Admin_Sections` (
  `sid` int(10) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`sid`)
) TYPE=MyISAM;



-- pHNews info: Table-Comments

DROP TABLE IF EXISTS `Comments`;
CREATE TABLE `Comments` (
  `id` int(11) NOT NULL auto_increment,
  `Title` varchar(100) NOT NULL default '',
  `Body` text NOT NULL,
  `User` varchar(100) NOT NULL default '',
  `Pid` int(11) NOT NULL default '0',
  `Date` varchar(100) NOT NULL default '0000-00-00',
  `Timestamp` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-Emoteicons

DROP TABLE IF EXISTS `Emoteicons`;
CREATE TABLE `Emoteicons` (
  `id` int(10) NOT NULL auto_increment,
  `text` text NOT NULL,
  `location` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-Items

DROP TABLE IF EXISTS `Items`;
CREATE TABLE `Items` (
  `id` int(10) NOT NULL auto_increment,
  `Name` text NOT NULL,
  `catid` int(10) NOT NULL default '0',
  `url` text NOT NULL,
  `desc` varchar(50) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '0',
  `order` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-Modules

DROP TABLE IF EXISTS `Modules`;
CREATE TABLE `Modules` (
  `Location` varchar(100) NOT NULL default '',
  `name` varchar(20) NOT NULL default ''
) TYPE=MyISAM;


-- pHNews info: Table-News

DROP TABLE IF EXISTS `News`;
CREATE TABLE `News` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `body` text NOT NULL,
  `user` varchar(100) NOT NULL default '',
  `date` varchar(100) NOT NULL default '',
  `time` varchar(100) NOT NULL default '',
  `comments` int(11) NOT NULL default '0',
  `timestamp` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-Preferences

DROP TABLE IF EXISTS `Preferences`;
CREATE TABLE `Preferences` (
  `Message_Parser` text NOT NULL,
  `Page_Limit` int(11) NOT NULL default '0',
  `Status_Bar` text NOT NULL,
  `Site_name` text NOT NULL,
  `Language` text NOT NULL,
  `Theme` int(11) NOT NULL default '0',
  `Editor` text NOT NULL,
  `FirstMsg` text NOT NULL,
  FULLTEXT KEY `Language` (`Language`)
) TYPE=MyISAM;


-- pHNews info: Table-Sections

DROP TABLE IF EXISTS `Sections`;
CREATE TABLE `Sections` (
  `sid` int(10) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '0',
  `order` int(20) NOT NULL default '0',
  PRIMARY KEY  (`sid`)
) TYPE=MyISAM;


-- pHNews info: Table-Themes

DROP TABLE IF EXISTS `Themes`;
CREATE TABLE `Themes` (
  `id` int(11) NOT NULL auto_increment,
  `Location` text NOT NULL,
  `theme_name` text NOT NULL,
  `theme_creator` text NOT NULL,
  `theme_desc` text NOT NULL,
  `theme_copyright` text NOT NULL,
  `theme_preview` text NOT NULL,
  `order` int(11) NOT NULL default '0',
  `Default` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

-- pHNews info: Table-Users

DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `id` int(10) NOT NULL auto_increment,
  `Rankid` int(10) NOT NULL default '1',
  `UName` varchar(20) NOT NULL default '',
  `Paswd` varchar(100) NOT NULL default '',
  `FName` varchar(40) NOT NULL default '',
  `LName` varchar(40) NOT NULL default '',
  `Email` varchar(40) NOT NULL default '',
  `UTitle` varchar(50) NOT NULL default '',
  `Location` varchar(40) NOT NULL default '',
  `Theme` int(11) NOT NULL default '0',
  `picture` text NOT NULL,
  `forumsacct` double NOT NULL default '0',
  `privacy` double NOT NULL default '0',
  `lastread` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


-- pHNews info: Table-usercp_Items

DROP TABLE IF EXISTS `usercp_Items`;
CREATE TABLE `usercp_Items` (
  `id` int(10) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL default '',
  `catid` int(10) NOT NULL default '0',
  `url` varchar(100) NOT NULL default '',
  `desc` varchar(50) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

-- pHNews info: Table-usercp_Modules

DROP TABLE IF EXISTS `usercp_Modules`;
CREATE TABLE `usercp_Modules` (
  `Location` varchar(100) NOT NULL default '',
  `name` varchar(20) NOT NULL default ''
) TYPE=MyISAM;


-- pHNews info: Table-usercp_Sections

DROP TABLE IF EXISTS `usercp_Sections`;
CREATE TABLE `usercp_Sections` (
  `sid` int(10) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL default '',
  `userlevel` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`sid`)
) TYPE=MyISAM;

-- pHNews info: StartDump

-- pHNews info: Table-Admin_Items

INSERT INTO `Admin_Items` VALUES (1, 'Post Message', 1, '?mod=admin&amod=post_message', 'Post a new news item.', '6');
INSERT INTO `Admin_Items` VALUES (2, 'Edit News Items', 1, '?mod=admin&amod=edit_news', 'Edit and delete news items', '6');
INSERT INTO `Admin_Items` VALUES (3, 'Edit Users', 3, '?mod=admin&amod=edit_users', 'Edit the settings of registered user''s accounts', '6');
INSERT INTO `Admin_Items` VALUES (4, 'Themes', 4, '?mod=admin&amod=themes', 'Change the graphics of the site with themes!', '6');
INSERT INTO `Admin_Items` VALUES (5, 'Preferences', 5, '?mod=admin&amod=pref', 'Edit pHNews preferences', '6');

-- pHNews info: Table-Admin_Modules

INSERT INTO `Admin_Modules` VALUES ('post_message.php', 'post_message');
INSERT INTO `Admin_Modules` VALUES ('edit_news.php', 'edit_news');
INSERT INTO `Admin_Modules` VALUES ('news_submit.php', 'news_submit');
INSERT INTO `Admin_Modules` VALUES ('edit_users.php', 'edit_users');
INSERT INTO `Admin_Modules` VALUES ('themes.php', 'themes');
INSERT INTO `Admin_Modules` VALUES ('edit_user.php', 'edit_user');
INSERT INTO `Admin_Modules` VALUES ('pref.php', 'pref');

-- pHNews info: Table-Admin_Sections

INSERT INTO `Admin_Sections` VALUES (1, 'News', '4');
INSERT INTO `Admin_Sections` VALUES (3, 'Users', '6');
INSERT INTO `Admin_Sections` VALUES (4, 'Apperence', '6');
INSERT INTO `Admin_Sections` VALUES (5, 'General', '6');

-- pHNews info: Table-Items

INSERT INTO `Items` VALUES (2, 'Admin Home', 4, '?mod=admin', 'Main administration page', '6', 0);
INSERT INTO `Items` VALUES (3, 'News', 1, '?mod=news', 'Latest __sitename__ News!', '0', 0);
INSERT INTO `Items` VALUES (5, 'Register', 1, '?mod=register', 'Get an account with __sitename__!', '0', 0);
INSERT INTO `Items` VALUES (8, 'Add to Favorites', 1, 'javascript:addfav()', 'Add this website to your favorites', '0', 10);
INSERT INTO `Items` VALUES (9, 'UserCP', 5, '?mod=usercp', 'Modify your user settings in the userCP', '1', 0);
INSERT INTO `Items` VALUES (10, 'Post Message', 4, '?mod=admin&amod=post_message', 'Post a new news item.', '0', 20);

-- pHNews info: Table-Modules

INSERT INTO `Modules` VALUES ('news.php', 'news');
INSERT INTO `Modules` VALUES ('admin.php', 'admin');
INSERT INTO `Modules` VALUES ('login.php', 'login');
INSERT INTO `Modules` VALUES ('register.php', 'register');
INSERT INTO `Modules` VALUES ('terms.php', 'terms');
INSERT INTO `Modules` VALUES ('about.php', 'about');
INSERT INTO `Modules` VALUES ('comments.php', 'comments');
INSERT INTO `Modules` VALUES ('view_profile.php', 'view_profile');
INSERT INTO `Modules` VALUES ('usercp.php', 'usercp');

-- pHNews info: Table-News

INSERT INTO `News` VALUES (1, 'pHNews', 'pHNews successfully installed!', 'nobody', '', '', 0, '20050619155804');

-- pHNews info: Table-Preferences

INSERT INTO `Preferences` VALUES ('parse_message.php', 10, '__sbar__', '__sitename__', 'en-gb', 3, 'phWYSIWYG.php', '<CENTER>Welcome to __sitename__!<BR>For more information about pHNews please see <a href="http://www.phnews.org">www.phnews.org</a></CENTER>');

-- pHNews info: Table-Sections

INSERT INTO `Sections` VALUES (1, '__sitename__', '0', 10);
INSERT INTO `Sections` VALUES (4, 'Administration', '6', 100);
INSERT INTO `Sections` VALUES (5, 'Account', '1', 70);

-- pHNews info: Table-Themes

INSERT INTO `Themes` VALUES (3, 'Blue_Ice', 'Blue Ice', 'ff2k(graphics) and mrmt32(implementation)', 'Theme with blue ice-like structures, made for IM-Century.', 'Copyright � pHMicroboard 2002-2005 all rights reserved', 'preview.gif', 0, 0);
INSERT INTO `Themes` VALUES (6, 'Random', 'Test', 'mrmt32', 'Pointless', 'Copyright � pHMicroboard 2002-2005 all rights reserved', 'themes/Blue_Ice/preview.gif', 0, 0);

-- pHNews info: Table-Users

INSERT INTO `Users` VALUES (1, 7, '__user__', '__password__', '', '', '__email__', 'Admin', '', 3, '', 0, 0, '');

-- pHNews info: Table-usercp_Items

INSERT INTO `usercp_Items` VALUES (1, 'Preferences', 1, '?mod=usercp&umod=pref', 'Change your user prefrences like your theme.', '');
INSERT INTO `usercp_Items` VALUES (2, 'Account Information', 1, '?mod=usercp&umod=acctinfo', 'Change your account information.', '');

-- pHNews info: Table-usercp_Modules

INSERT INTO `usercp_Modules` VALUES ('welcome.php', 'welcome');
INSERT INTO `usercp_Modules` VALUES ('pref.php', 'pref');
INSERT INTO `usercp_Modules` VALUES ('acctinfo.php', 'acctinfo');

-- pHNews info: Table-usercp_Sections

INSERT INTO `usercp_Sections` VALUES (1, 'UserCP Menu', '0');
        
