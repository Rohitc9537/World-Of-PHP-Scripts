<?PHP
$currentdir = getcwd();
chdir("..");
$themes_dir = "themes";
include "themes/Blue_Ice/theme.php";
set_theme_vars();
include "templates/Blue_Ice/main.php";
chdir($currentdir);
?>
<html>
<head>
<title>pHNews ALPHA 1 - [Installation]</title>
<LINK href="../themes/Blue_Ice/style.css" type=text/css rel=STYLESHEET>
</head>
<body background="../themes/Blue_Ice/Background-possibility.gif">
<center>
<?php
/************************************************************************/
/*				************************************					*/
/*				**********pHNews Installer**********					*/
/*				************************************					*/
/*				*     Version: pHNews ALPHA 1      *					*/
/*				*       Install Type: Normal       *					*/
/*				************************************					*/
/*				*     Copyright (c) pHMicroboard   *					*/
/*				*   2002-2005 All Rights Reserved  *					*/
/*				************************************					*/
/************************************************************************/
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

switch ($_GET['action']) {
	case "done":
		?>
		<img src="../themes/Blue_Ice/phnews-logo.gif"><br><br>
		<?=opentableins("width='800'","") ?>
			<center>
			pHNews has been successfuly installed! To close this wizard and go to your newly installed pHNews click finish.
			<bR><BR>
			<font color="red">WARNING: It is highly recommended that you delete everything in the "install" folder before continuing.
			Not doing so will let anyone have complete access to you mySQL databases and be able to take over your website.</font>
			</center>
		<?=closetableins()?>
		<table width="800" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="400" align="left">
				<button disabled>Back</button>
			</td>
			<td width="400" align="right">
				<button onclick="window.location.href='../'">Finish</button>
			</td>
		</tr>
		</table>			
		<?PHP
	break;
	case "install":
		?>
		<img src="../themes/Blue_Ice/phnews-logo.gif"><br><br>
		<?=opentableins("width='800'","") ?>
		<center>
		<?PHP
		include "installer.php";
		$install = new pHNinstall;
		$install->database = $_POST['database'];
		$install->mysqluser = $_POST['mysqluser'];
		$install->mysqlpassword = $_POST['mysqlpassword'];
		$install->mysqlserver = $_POST['mysqlserver'];
		$install->user = $_POST['user'];
		$install->password = md5($_POST['password']);
		$install->sitename = $_POST['site_name'];
		$install->sbar = $_POST['statusbar'];
		$install->email = $_POST['email'];
		
		$theurl = "?database=".$install->database."&mysqluser=".$install->mysqluser."&statusbar=".$install->sbar.
				"&mysqlserver=".$install->mysqlserver."&user=".$install->user."&site_name=".$install->sitename.
				"&email=".$install->email;
				
		$install->dbconnect();
		if ($_POST['createdb'] == 1) 
			$install->createdb();
		$install->selectdb();
		$install->setupconfig();
		$install->execute_script("script.sql");

		?>
		</center>
		<?=closetableins() ?>
		<table width="800" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="400" align="left">
				<button onclick="window.location.href='<?=$theurl ?>'">Back</button>
			</td>
			<td width="400" align="right">
				<button onclick="window.location.href='?action=done'">Next</button>
			</td>
		</tr>
		</table>
		<?PHP
	break;
	default:
		$textsize = 180;
		?>
			<img src="../themes/Blue_Ice/phnews-logo.gif"><br><br>
			<?=opentableins("width='800'","") ?>
			<form method="post" action="?action=install">
			<center>
			Welcome to the pHNews install wizard, this will guide you through installing pHNews alpha 1.<br><BR>
			Please enter the following information:<br>
			<br>
			<?=opentableins("","") ?>
			<center><b>General</b></center><br>
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
			<tr>
				<td width="<?=$textsize ?>">
					<label for="site_name">Site Name:</label> 
				</td>
				<td>
					<input type="text" name="site_name" id="site_name" value="<?=$_GET['site_name'] ?>"> <small><i>- The name you want to give to your website</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="statusbar">Text to show in status bar:</label> 
				</td>
				<td>
					<input type="text" name="statusbar" id="statusbar" value="<?=$_GET['statusbar'] ?>"> <small><i>- The text that is displayed in the status bar (the bar at the bottom of your browser).</i></small>
				</td>
			</tr>
			</table>
			<br>
			<?=closetableins() ?>
			<?=opentableins("","") ?>
			<center><b>Admin Account</b></center><br>
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
			<tr>
				<td width="<?=$textsize ?>">
					<label for="user">Admin username:</label> 
				</td>
				<td>
					<input type="text" name="user" id="user" value="<?=$_GET['user'] ?>"> <small><i>- The username you want for the admin account.</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="password">Admin password:</label> 
				</td>
				<td>
					<input type="password" name="password" id="passwd"> <small><i>- The password you want to use for the admin account.</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="email">Admin email:</label>
				</td>
				<td>
					<input type="text" name="email" id="email" value="<?=$_GET['email'] ?>"> <small><i>- Your email address.</i></small>
				</td>
			</tr>
			</table>
			<br>
			<?=closetableins() ?>
			<?=opentableins("","") ?>
			<center><b>mySQL Information</b></center><br>
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
			<tr>
				<td width="<?=$textsize ?>">
					<label for="mysqlserver">Server:</label> 
				</td>
				<td>
					<input type="text" name="mysqlserver" id="mysqlserver" value="<?PHP if($_GET['mysqlserver'] == "") echo "localhost"; else echo $_GET['mysqlserver']; ?>"> <small><i>- Your mySQL server (normaly localhost).</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="mysqluser">User:</label>
				</td>
				<td>
					<input type="text" name="mysqluser" id="mysqluser" value="<?=$_GET['mysqluser'] ?>"> <small><i>- Your mySQL username.</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="mysqlpassword">Password:</label>
				</td>
				<td>
					<input type="password" name="mysqlpassword" id="mysqlpassword"> <small><i>- Your mySQL password.</i></small>
				</td>
			</tr>
			<tr>
				<td width="<?=$textsize ?>">
					<label for="database">Database:</label>
				</td>
				<td>
					<input type="text" name="database" id="database" value="<?=$_GET['database'] ?>"><input type="checkbox" name="createdb" value="1" id="createdb"><label for="createdb">Try to create the database for me.</label> <br>
				</td>
			</tr>
			</table>
			<?=closetableins() ?>
			
			
			</center>
			<?=closetableins() ?>
			<table width="800" cellpadding="0" cellspacing="0" border="0">
				<tr>
					<td width="400" align="left">
						<button disabled>Back</button>
					</td>
					<td width="400" align="right">
						<input type="submit" value="Next">
					</td>
				</tr>
			</table>
			</form>
			</center>
			</body>
			</html>
		<?PHP
	break;

}
?> 