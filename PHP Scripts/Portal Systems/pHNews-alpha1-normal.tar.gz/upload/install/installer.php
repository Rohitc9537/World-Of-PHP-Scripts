<?PHP
// pHNews install class 1.0 BETA
// Used for pHNews installation
class pHNinstall {
	var $database;
	var $mysqlserver;
	var $mysqluser;
	var $mysqlpassword;
	var $user;
	var $password;
	var $sitename;
	var $sbar;
	var $email;
	function death($text) {
		global $theurl;
		echo $text;
		?>
		</center>
		<?=closetableins() ?>
		<table width="800" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="400" align="left">
				<button onclick="window.location.href='<?=$theurl ?>'">Back</button>
			</td>
		</tr>
		</table>
		<?PHP
		die();
	}
	function dbconnect() {
		global $link;
		$link = mysql_connect($this->mysqlserver, $this->mysqluser, $this->mysqlpassword) or $this->death('Could not connect: ' . mysql_error());
	}
	function selectdb() {
		mysql_select_db($this->database) or die('Could not select database'); 
	}
	function dosql($sql, $end = false) {
		$result = mysql_query($sql);
		if ($end) { $end = "<br>"; };
		if ($result) {
			print(" - <font color='green'>Done</font>$end");
		} else {
			$this->death(" - <font color='red'>Failed: ".mysql_error()."</font><br>");
		}
	}
	function createdb() {
		$result = mysql_query("CREATE DATABASE ".$this->database."");
		if ($result) {
			print("<b>Database '".$this->database."' Created!</b><br><br>");
		} else {
			$this->death("<b><font color='red'>Failed to create database: ".mysql_error()."</font></b><br>
					<small>Try createing the database manualy...</small>");
		}
	}
	function setupconfig() {
		include "config.template.php";
		if (is_writable("../config.php")) {
			if (!$handle = fopen("../config.php", 'w')) {
				$this->death("<font color='red'>Failed: Cannot open config.php for writeing.</font>");
				exit;
			}
   			if (fwrite($handle, $config) === FALSE) {
   			    $this->death("<font color='red'>Failed: Cannot write to config.php!</font>");
   			    exit;
			}
   
  			echo "<b>Config.php configured.</b><br>";
   
			fclose($handle);
			
		} else {
			$this->death("<font color='red'>Failed: Cannot open config.php for writeing.</font>");
		}
	}
	function parsesql($sql) {
		extract($GLOBALS);
		$find = array("__sitename__", "__user__", "__password__", "__sbar__", "__email__");
		$replace = array($this->sitename, $this->user, $this->password, $this->sbar, $this->email);
		return str_replace($find, $replace, $sql);
	}
	function execute_script($file) {
		$handle = fopen($file, "r");
		while ($buffer = fgets($handle,4096)) {
			if (ereg ("-- pHNews info: StartCT", $buffer, $regs)) 
				print("<br><BR><b>Createing tables:</b><br>"); 
				
			if (ereg ("-- pHNews info: StartDump", $buffer, $regs)) 
				print("<br><BR><b>Inserting data</b><br>");
				
			if (ereg ("-- pHNews info: Table-(.*)", $buffer, $regs))
  				print("<br>".$regs[1]);
				
			if (ereg ("(.*;)", $buffer, $regs)){
				$sql .= $buffer;
				$sql = $this->parsesql($sql);
				$this->dosql($sql);
				$sql = "";
			} else {
				$sql .= $buffer;
			}
		}
		fclose($handle);
	}
}
?>