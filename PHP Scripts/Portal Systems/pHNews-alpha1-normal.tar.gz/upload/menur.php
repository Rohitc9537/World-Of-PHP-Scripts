<?=openmenutable("","") ?>
<!-- SiteSearch Google -->
<form method="get" action="http://www.google.co.uk/custom" target="_top">
<table border="0">
<tr><td nowrap="nowrap" valign="top" align="left" height="32">
<a href="http://www.google.com/">
<img src="http://www.google.com/logos/Logo_25gry.gif"
border="0" alt="Google"></img></a>
<br/>
<input type="hidden" name="domains" value="pHNews.org"></input>
<input type="text" name="q" size="20" maxlength="255" value=""></input>
</td></tr>
<tr>
<td nowrap="nowrap">
<table>
<tr>
<td>
<input type="radio" name="sitesearch" value="" checked="checked"></input>
<font size="-1" color="#000000">Web</font>
</td>
<td>
<input type="radio" name="sitesearch" value="pHNews.org"></input>
<font size="-1" color="#000000">pHNews.org</font>
</td>
</tr>
</table>
<input type="submit" name="sa" value="Search"></input>
<input type="hidden" name="client" value="pub-3015074498414980"></input>
<input type="hidden" name="forid" value="1"></input>
<input type="hidden" name="ie" value="ISO-8859-1"></input>
<input type="hidden" name="oe" value="ISO-8859-1"></input>
<input type="hidden" name="cof" value="GALT:#000000;GL:1;DIV:#2C41A3;VLC:000000;AH:center;BGC:2C41A3;LBGC:2C41A3;ALC:FFFF00;LC:FFFF00;T:FFFFFF;GFNT:000000;GIMP:000000;LH:100;LW:800;L:http://www.phnews.org/themes/Blue_Ice/phnews-logo.gif;S:http://www.phnews.com;FORID:1;"></input>
<input type="hidden" name="hl" value="en"></input>

</td></tr></table>
</form>
<!-- SiteSearch Google -->
<?=closemenutable() ?>
</form>
<?=openmenutable("","") ?>
<script type="text/javascript"><!--
google_ad_client = "pub-3015074498414980";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "2C41A3";
google_color_bg = "2C41A3";
google_color_link = "797FF8";
google_color_url = "797FF8";
google_color_text = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?=closemenutable() ?>