<?PHP
/*
pHNews Backend, allows external data access
copyright (c) pHMicroboard 2002-2005 all rights reserved.
*/
include "config.php";
include "./backend/engine.php";
$phnews = new pHNews;
switch ($_GET['action']) {
	case "return_news":
		$phnews->return_news($_GET['type']);
	break;
	case "list_users":
		$phnews->list_users();
	break;
	case "get_user_info":
		$phnews->get_user_info($_GET['id']);
	break;
	case "get_comments":
		$phnews->get_comments($_GET['id']);
	break;
	case "post_comment":
		$login = $phnews->post_comment($_GET['id'], $_POST['message'], $_POST['title'], $_POST['user'], $_POST['password']);
		header("Content-type: text/xml");
		echo "<?xml version=\"1.0\"?>";
		if ($login[0] == "login") {
			?>
			<phnewsstatus type="error" function="tmp_login()"><?=$login[1] ?></phnewsstatus>
			<?PHP
		} elseif ($login[0] == "post") {
			?>
			<phnewsstatus type="error" function="post_comment()"><?=$login[1] ?></phnewsstatus>
			<?PHP
		} else {
			?>
			<phnewsstatus type="success" function="post_comment()"><?=$_GET['id'] ?></phnewsstatus>
			<?PHP
		}
	break;
	case "get_news_item":
		$phnews->get_news_item($_GET['id'], $_GET['type']);
	break;
	default:
		?>
		pHNews backend, action list:<br><Br>
		<b>return_news()</b> - Format: <a href="?action=return_news">pHNews</a> <a href="?action=return_news&type=rss2">RSS2</a><Br />
		Shows all news items in either RSS2 or pHNews xml format (for more info on the pHNews xml format please see the help file)<br /><br />
		
		<b>list_users()</b> - <a href="?action=list_users">Click here</a><Br />
		Lists all users in pHNews xml format.<Br /><Br />
		
		<form><b>get_user_info()</b> - 
								<input type="hidden" name="action" value="get_user_info">
								id: <input type="text" name="id">
								<Br />
		Shows info about a specified user.</form>
		
		<form><b>get_comments()</b> - 
								<input type="hidden" name="action" value="get_comments">
								News post id: <input type="text" name="id">
								<Br />
		Get the comments for a specified news post.</form>
		
		<b>post_comment()</b> - <a href="test.php">Comment post example</a><Br />
		Post a comment.<Br /><br />
		
		For more information please see pHNews help files.
		<?PHP
	break;
}
?>