<?php 
function send_file($file, $filename){
	$ctype="application/force-download";
   //Begin writing headers
   header("Pragma: public");
   header("Expires: 0");
   header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
   header("Cache-Control: public"); 
   header("Content-Description: File Transfer");
   
   //Use the switch-generated Content-Type
   header("Content-Type: $ctype");

   //Force the download
   $header="Content-Disposition: attachment; filename=".$filename.";";
   $header="Content-Disposition: inline; filename=".$filename.";";
   header($header );
   header("Content-Transfer-Encoding: binary");
   header("Content-Length: ".$len);
   echo $file;
   exit;
}

if ($_GET['action'] == "go") { 
	//include "tar.class.php";
	//$tar = new tar;
	//$weee = $tar->addDirectory("/home/phmicrob/public_html/phnews/");
	//$weeeb = $tar->toTar("./backup.tar.gz",true);
	ob_start();
		passthru("tar -c ..");
	$weeeb .= ob_get_contents();
				ob_end_clean();
	$weeeb = gzencode($weeeb, 9);
	//$weeeb = exec("dir");
	//echo $weeeb;
	send_file($weeeb, "backup.tar.gz");
} elseif ($_GET['action'] == "sql") {
	include "../config.php";
	$command = "mysqldump --opt -Q -h$mysql_host -u$mysql_user -p$mysql_password $mysql_database | gzip -f";
	ob_start();
		passthru($command);
	$weeeb .= ob_get_contents();
				ob_end_clean();
	send_file($weeeb, "pHNews_backup_".date("d-M-Y").".sql.gz");
} else {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>pHNews backup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

This script will backup your pHNews installation into a tar.gz file and let you download it.<br>
<a href="?action=go">Get file backup</a> | <a href="?action=sql">Get sql backup</a>
</form>
</body>
</html>
<?PHP
}
?>