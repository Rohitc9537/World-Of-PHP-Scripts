genbackup is a simple tool to backup your pHNews installation, it reqires
tar installed on your system (it has only been tested on unix), zlib for php
and execute rights for tar. To use it upload the extra folder to where you installed
pHNews and goto http://www.yourwebsite.com/whereyouinstalledphnews/extra/genbackup.php
and click one of the options.