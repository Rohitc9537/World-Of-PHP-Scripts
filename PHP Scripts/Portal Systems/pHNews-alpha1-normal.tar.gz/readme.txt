************************************************************************
*		************************************		       *
*		***********    pHNews    ***********		       *
*		************************************		       *
*		*                                  *		       *
*		*            Version: ALPHA 1      *		       *
*		*       Install Type: Normal       *		       *
*		*				   *		       *
*		************************************		       *
*		*     Copyright (c) pHMicroboard   *		       *
*		*   2002-2005 All Rights Reserved  *		       *
*		************************************		       *
************************************************************************
* This program is free software. You can redistribute it and/or modify *
* it under the terms of the GNU General Public License as published by *
* the Free Software Foundation; either version 2 of the License.       *
************************************************************************

************************************************************************
*								       *
*			Install Instructions			       *
*                                                                      *
************************************************************************
*         1. Upload everything in the upload folder to you webserver   *
*         2. Goto http://www.yourwebserver.com/install/install.php     *
*         3. Follow the instructions to install pHNews!                *
************************************************************************

************************************************************************
*                                                                      *
*                              Credits                                 *
*                                                                      *
************************************************************************
*		    ::::Codeing and Development::::                    *
*			   Matthew Thornhill                           *
*			      (mrmt32)                                 *
*                                                                      *
*                                                                      *
*                     ::::Graphics and design::::                      *
*                           Jordan Bentley                             *
*                              (ff2k)                                  *
*                                                                      *
*                           Sander Skoning                             *
*                            (Plan-1130)                               *
*                                                                      *
************************************************************************