INSTALL OF AX V1.0 :

1 - Download and Unzip the archive in a local folder.

2 - Be sure that your apache is running and you are running a version of PHP 4 or superior

3 - If you are in UNIX system, you have to CHMOD correctly the folder /data/ with the permission for PHP to write in it.

4 - Just run ax.php or index.php script at the root.

5 - To access the admin just click on 'admin' and enter the Ax password (axpassword by default). Be sure to change it editing the ax.php file
