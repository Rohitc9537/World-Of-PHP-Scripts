<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="text/javascript" src="htmlarea.js"></script>
<script type="text/javascript" src="lang/en.js"></script>
<script type="text/javascript" src="dialog.js"></script>


</head>

<script type="text/javascript">
 var editor1 = null;
 var editor2 = null;
 function initEditor()
 {
  editor2 = new HTMLArea("home_text");

  editor2.generate();
  editor1 = new HTMLArea("body_text");

  editor1.generate();    return false;
}
</script>

<?
?>
