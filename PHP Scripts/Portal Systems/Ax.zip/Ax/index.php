<?
header("location:ax.php");
?>
