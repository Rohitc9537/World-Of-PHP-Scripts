<?php
$AdminUsername = "admin";			/* Username for the administration area */
$AdminPass = "123456789";			/* Password for the administration area */
$AdminEmail = "youremail@yourdomain.com";	/* Email address used with your admin account */

$hostname = "localhost";			/* Database Hostname (usually localhost) */
$user = "username";				/* Username for database */
$pass = "password";				/* Password for database */
$database = "database name";			/* Database name */
$userstable = "users";				/* table name for ther users table that will be inserted into the database, If your uncertain what this is leave it as it is */
$admintable = "admin";				/* table name for the admin table that will be inserted into the database, If you are uncertain what this is leave it as it is */

$domain = "yourdomain.com";			/* Do NOT enter www. or http:// */
$directory = "/login/";		/* this is the directory location of the script ie.. /login/ be sure to add a slash at the beginning and end */
?>