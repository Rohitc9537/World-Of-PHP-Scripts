/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/Chat Anywhere Php-Nuke Add-on  V1.0                         ********************************************************/
/This Add-on For PHP-Nuke Is Mady Possible By EveryWhereChat ********************************************************/
/http://www.everywherechat.com                               ********************************************************/
/       &													 ********************************************************/
/PHP-Nuke Tools v3.00                                        ********************************************************/
/http://www.disipal.net                                      ********************************************************/
/															 ********************************************************/
/Script Put Together For Php-Nuke 7.3 By    				 ********************************************************/
/Angela Stover                                               ********************************************************/
/Metal Hell                                      			 ********************************************************/
/Http://MetalHell.ServeMp3.Com								 ********************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/


BEFORE INSTALLING ANYTHING EVER ALWAYS BACKUP YOUR WEBSITE AND MYSQL DATABASE BELIEVE ME I HAD TO LEARN THE HARD WAY!!

------------------------------------------------------------------------------------------------------------------
- THIS PACKAGE IS RELEASED AS GPL/GNU SCRIPTING. FEEL FREE TO REDISTRIBUTE IT ANY WAY YOU SEE FIT.

------------------------------------------------------------------------------------------------------------------

Installation Instructions

I'm not gonna say unzip I'm sure you've already done that your reading this LOL...Duh)

---------Go To  Http://www.everywherechat.com and Click Add Chat from thier Navigation Menu Fill out the form to sign up
for the chat room. After the script is generated leave that window open and then go to where you unzipped The 
Chat Anywhere Add-on And Open:
 
                       html/blocks/block-Chat_Stats.php 
					   In The Scipt Edit The Lines 10 And 18 To Suit Your Needs
					   (NOTE: Replace YOUR_CHAT_ROOM_NAME With The Name You Registerd On ChatAnywhere.com) 

---------Next Open html/modules/chat_room/chat.htm And Edit Lines 13 And 27 The Same way you did with block-
         chat_stats.php

--------- Ok Thats It Your Done editing scripts.
		 
---------You can However edit The File 
 					   html/modules/Chat_Room/Chat.htm to Reflect The Theme On Your Website.
					   
---------Upload the files to your server

         html/blocks/block-chat_stats.php-------------------------> blocks/block-chat_stats.php
         html/modules/Chat_Room/index.php-------------------------> modules/Chat_Room/index.php
         html/modules/Chat_Room/Chat.htm-------------------------->modules/Chat_Room/chat.htm
		  
---------Activate the Chat Room Modules And Chat Stats Block From You Administrator 
         Control Panel On Your Website.

------------------------------------------------------------------------------------------------------------------
		 
		 
					   
                         