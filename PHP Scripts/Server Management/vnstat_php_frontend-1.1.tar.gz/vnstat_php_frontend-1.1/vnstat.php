<?php
    //
    // vnStat PHP frontend 1.1 (c)2005 Bjorge Dijkstra (bjd@jooz.net)
    //
    // This program is free software; you can redistribute it and/or modify
    // it under the terms of the GNU General Public License as published by
    // the Free Software Foundation; either version 2 of the License, or
    // (at your option) any later version.
    //
    // This program is distributed in the hope that it will be useful,
    // but WITHOUT ANY WARRANTY; without even the implied warranty of
    // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    // GNU General Public License for more details.
    //
    // You should have received a copy of the GNU General Public License
    // along with this program; if not, write to the Free Software
    // Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    //
    //
    // see file COPYING or at http://www.gnu.org/licenses/gpl.html 
    // for more information.
    //

    //
    // configuration parameters
    //
    // edit these to reflect your particular situation
    //

    // list of network interfaces
    $iface_list = array("eth0", "eth1", "sixxs");

    //
    // optional names for interfaces
    // if there's no name set for an interface the interface identifier
    // will be displayed instead
    //    
    $iface_title["eth0"] = "Internal";
    $iface_title["eth1"] = "Internet";
    $iface_title["sixxs"] = "SixXS IPv6";

    // path to the vnstat binary
    $vnstat_bin = "/usr/bin/vnstat";
    
    //
    // Valid values for other parameters you can pass to the script.
    // Input parameters will always be limited to one of the values listed here.
    // If a parameter is not provided or invalid it will revert to the default,
    // the first parameter in the list.
    //
    $page_list  = array("s","h","d","m");
    
    $graph_list = array("large","small","none");
    
    $page_title["s"] = "summary";
    $page_title["h"] = "hours";
    $page_title["d"] = "days";
    $page_title["m"] = "months";
    

    //
    // functions
    //
    function validate_input()
    {
	global $page,  $page_list;
	global $iface, $iface_list;
	global $graph, $graph_list;

	//
	// get interface data
	//
	$page = $_GET["page"];
	$iface = $_GET["if"];
	$graph = $_GET["graph"];

	$i = 0;	
	while (($i < count($page_list)) && ($page != $page_list[$i]))
	{
	    $i++;
	}
	if ($i == count($page_list))
	{
	    $page = $page_list[0];
	}

	$i = 0;	
	while (($i < count($iface_list)) && ($iface != $iface_list[$i]))
	{
	    $i++;
	}
	if ($i == count($iface_list))
	{
	    $iface = $iface_list[0];
	}
	
	$i = 0;	
	while (($i < count($graph_list)) && ($graph != $graph_list[$i]))
	{
	    $i++;
	}
	if ($i == count($graph_list))
	{
	    $graph = $graph_list[0];
	}	
    }
    
    function write_tab_header()
    {
	global $iface, $page, $graph;
	global $page_list, $page_title;
	$p = "&amp;if=$iface&amp;graph=$graph";

	print "<div class=\"toptab_spacer\"></div>\n";
	foreach ($page_list as $pg)
	{
	    $tabclass = ($page == $pg) ? "toptab_front" : "toptab_back";
    	    print "<div class=\"$tabclass\"><a class=\"tab\" href=\"?page=$pg$p\">".$page_title[$pg]."</a></div>\n";
	}
	print "<div class=\"toptab_filler\"></div>\n";
    }
    
    function write_side_bar()
    {
	global $iface, $page, $graph;
	global $iface_list, $iface_title;	
	$p = "&amp;page=$page&amp;graph=$graph";
	print "<div class=\"sidetab_spacer\"></div>";		
	foreach ($iface_list as $if)
	{
	    $tabclass= ($if == $iface) ? "sidetab_front" : "sidetab_back";
	    print "<div class=\"$tabclass\"><a class=\"tab\" href=\"?if=$if$p\">";
	    if (isset($iface_title[$if]))
	    {
		print $iface_title[$if];
	    }
	    else
	    {
		print $if;
	    }
	    print "</a></div>\n";
	}
	print "<div class=\"sidetab_filler\"></div>\n";	
    }
    
    function write_last_days()
    {    
    	global $day, $graph;
	
	write_page_header($graph != "none");	
	write_data_table("Last 30 days", $day,1);	
	write_page_footer();
    }


    function write_last_hours()
    {
	global $hour,$graph;
	
	write_page_header($graph != "none");
	write_data_table("Last 24 hours", $hour,0);	
	write_page_footer();
    }
    
    
    function write_last_months()
    {
	global $month,$graph;
	
	write_page_header($graph != "none");
	write_data_table("Last 12 months", $month,1);	
	write_page_footer();
    }
    
    function kbytes_to_string($kb)
    {
	$units = array("TB","GB","MB","KB");
	$scale = 1024*1024*1024;
	$ui = 0;
	
	while (($kb < $scale) && ($scale > 1))
	{
	    $ui++;
	    $scale = $scale / 1024;
	}	
	return sprintf("%0.2f %s", ($kb/$scale),$units[$ui]);
    }
    
    function write_summary()
    {
	global $summary,$top,$day,$hour,$month;
	
	$trx = $summary["totalrx"]*1024+$summary["totalrxk"];
	$ttx = $summary["totaltx"]*1024+$summary["totaltxk"];
	
	//
	// build array for write_data_table
	//
	$sum[0]["act"] = 1;
	$sum[0]["label"] = "This hour";
	$sum[0]["rx"] = $hour[0]["rx"];
	$sum[0]["tx"] = $hour[0]["tx"];
	
	$sum[1]["act"] = 1;
	$sum[1]["label"] = "This day";
	$sum[1]["rx"] = $day[0]["rx"];
	$sum[1]["tx"] = $day[0]["tx"];

	$sum[2]["act"] = 1;
	$sum[2]["label"] = "This month";
	$sum[2]["rx"] = $month[0]["rx"];
	$sum[2]["tx"] = $month[0]["tx"];

	$sum[3]["act"] = 1;
	$sum[3]["label"] = "All time";
	$sum[3]["rx"] = $trx;
	$sum[3]["tx"] = $ttx;
	
	write_page_header(0);
	
	write_data_table("Summary", $sum, 1);
	print "<br>\n";
	write_data_table("Top 10 days", $top,1);	
	write_page_footer();
    }
    
    
    function write_page_header($do_image)
    {
    	global $summary,$iface,$page,$graph;
	print "<div class=\"main_body\">";	
	if ($do_image)
	{
	    print "<img src=\"$iface-$page.png\" alt=\"graph\"/>\n";
	}
    }
    
    function write_page_footer()
    {
	print "</div>";
    }
    
    function write_data_table($caption, $tab, $supress)
    {
	print "<table class=\"datatable\" width=\"650\">\n";
	print "<caption>$caption</caption>\n";
	print "<tr>";
	print "<th class=\"label\" style=\"width:120px;\">&nbsp;</th>";
	print "<th class=\"label\" style=\"width:174px;\">In</th>";
	print "<th class=\"label\" style=\"width:174px;\">Out</th>";
	print "<th class=\"label\" style=\"width:174px;\">Total</th>";	
	print "</tr>\n";
	
	for ($i=0; $i<count($tab); $i++)
	{
	    if ($tab[$i]["act"] == 1 || ($supress == 0))
	    {
		$t = $tab[$i]["label"];
	        $rx = kbytes_to_string($tab[$i]["rx"]);
	        $tx = kbytes_to_string($tab[$i]["tx"]);
		$total = kbytes_to_string($tab[$i]["rx"]+$tab[$i]["tx"]);
    	        $id = ($i & 1) ? "odd" : "even";
	        print "<tr>";
		print "<td class=\"label_$id\">$t</td>";
		print "<td class=\"numeric_$id\">$rx</td>";
		print "<td class=\"numeric_$id\">$tx</td>";
		print "<td class=\"numeric_$id\">$total</td>";		
		print "</tr>\n";
    	    }	    
        }
	print "</table>\n";
    }

    function get_vnstat_data()
    {
	global $iface, $vnstat_bin;
	global $hour,$day,$month,$top,$summary;

	$vnstat_data = explode("\n", `$vnstat_bin --dumpdb -i $iface`);

	$day = array();
	$hour = array();
	$month = array();
	$top = array();
	
	//
	// extract data
	//
	foreach($vnstat_data as $line) 
	{
		$d = split(";", $line);
		if ($d[0] == 'd')
		{
			$day[$d[1]]["time"]  = $d[2];
			$day[$d[1]]["rx"]    = $d[3] * 1024 + $d[5];
			$day[$d[1]]["tx"]    = $d[4] * 1024 + $d[6];
			$day[$d[1]]["act"]   = $d[7];
			if ($d[2] != 0)
			{
			    $day[$d[1]]["label"] = date("d M Y", $d[2]);
			    $day[$d[1]]["img_label"] = date("d", $d[2]);
			}
			else
			{
			    $day[$d[1]]["label"] = "";
			    $day[$d[1]]["img_label"] = "";			
			}			
		}
		else if ($d[0] == 'm')
		{
			$month[$d[1]]["time"] = $d[2];
			$month[$d[1]]["rx"]   = $d[3] * 1024 + $d[5];
			$month[$d[1]]["tx"]   = $d[4] * 1024 + $d[6];
			$month[$d[1]]["act"]  = $d[7];
			if ($d[2] != 0)
			{
			    $month[$d[1]]["label"] = date("M Y", $d[2]);
			    $month[$d[1]]["img_label"] = date("M", $d[2]);
			}
			else
			{
			    $month[$d[1]]["label"] = "";
			    $month[$d[1]]["img_label"] = "";			
			}
		}
		else if ($d[0] == 'h')
		{
			$hour[$d[1]]["time"] = $d[2];
			$hour[$d[1]]["rx"]   = $d[3];
			$hour[$d[1]]["tx"]   = $d[4];
			$hour[$d[1]]["act"]  = $d[5];
			if ($d[2] != 0)
			{
			    $hour[$d[1]]["label"] = date("H", $d[2]).":00 - ".date("H", $d[2]+3600).":00";
			    $hour[$d[1]]["img_label"] = date("H", $d[2]);
			}
			else
			{
			    $hour[$d[1]]["label"] = "";
			    $hour[$d[1]]["img_label"] = "";
			}
		}
		else if ($d[0] == 't')
		{	
			$top[$d[1]]["time"] = $d[2];
			$top[$d[1]]["rx"]   = $d[3] * 1024 + $d[5];
			$top[$d[1]]["tx"]   = $d[4] * 1024 + $d[6];
			$top[$d[1]]["act"]  = $d[7];
			$top[$d[1]]["label"] = date("d M Y", $d[2]);
			$top[$d[1]]["img_label"] = date("d M", $d[2]);
		}
		else
		{
			$summary[$d[0]] = $d[1];
		}
	}
	if (count($day) == 0)
	    $day[0] = "nodata";
	rsort($day);
	
	if (count($month) == 0)
	    $month[0] = "nodata";
	rsort($month);
	
	if (count($hour) == 0)
	    $hour[0] = "nodata";
	rsort($hour);
    }

    function init_image()
    {
	global $im, $xlm, $xrm, $ytm, $ybm, $iw, $ih,$graph, $cl;
	
	if ($graph == "none")
		return;

	//
	// image object
	//    
	$xlm = 40;
	$xrm = 10;
	$ytm = 20;
	$ybm = 60;
	if ($graph == "small")
	{
		$iw = 300 + $xrm + $xlm;
		$ih = 100 + $ytm + $ybm;    
	}
	else
	{
		$iw = 600 + $xrm + $xlm;
		$ih = 200 + $ytm + $ybm;
	}
	
	$im = imagecreate($iw,$ih);
	
	//
	// colors
	//
	$cl["white"] = imagecolorallocate($im, 255, 255, 255);
	$cl["black"] = imagecolorallocate($im, 0, 0, 0);
	$cl["grey"]  = imagecolorallocate($im, 100, 100, 128);
	$cl["grid_stipple_1"] = imagecolorallocate($im, 140,140,120);
	$cl["grid_stipple_2"] = imagecolorallocate($im, 200,200,100);
	$cl["background"] = imagecolorallocate($im, 240, 240, 200);
	$cl["rx"] = imagecolorallocate($im, 100, 82, 40);
	$cl["tx"] = imagecolorallocate($im, 162, 110, 40);
	
	imagefilledrectangle($im,0,0,$iw,$ih,$cl["background"]);
	
    }

    function draw_border()
    {
	global $im,$cl,$iw,$ih;
	
	imageline($im,     0,    0,$iw-1,    0, $cl["black"]);
	imageline($im,     0,$ih-1,$iw-1,$ih-1, $cl["black"]);
	imageline($im,     0,    0,    0,$ih-1, $cl["black"]);	
	imageline($im, $iw-1,    0,$iw-1,$ih-1, $cl["black"]);
    }
    
    function draw_grid($x_ticks, $y_ticks)
    {
	global $im, $cl, $iw, $ih, $xlm, $xrm, $ytm, $ybm;
	
	$x_step = ($iw - $xlm - $xrm) / $x_ticks;
	$y_step = ($ih - $ytm - $ybm) / $y_ticks;
	
	$ls = array($cl["grid_stipple_1"],$cl["grid_stipple_2"]);
	imagesetstyle($im, $ls);
	for ($i=$xlm;$i<=($iw-$xrm); $i += $x_step)
	{
	    imageline($im, $i, $ytm, $i, $ih - $ybm, IMG_COLOR_STYLED);
	}
	for ($i=$ytm;$i<=($ih-$ybm); $i += $y_step)
	{
	    imageline($im, $xlm, $i, $iw - $xrm, $i, IMG_COLOR_STYLED);	
	}
	imageline($im, $xlm, $ytm, $xlm, $ih - $ybm, $cl["black"]);
	imageline($im, $xlm, $ih - $ybm, $iw - $xrm, $ih - $ybm, $cl["black"]);
    }
    
    
    function draw_data($data)
    {
	global $im,$cl,$iw,$ih,$xlm,$xrm,$ytm,$ybm;
	
	sort($data);
	
	$x_ticks = count($data);
	$y_ticks = 10;
	$y_scale = 1;
	$prescale = 1;
	$unit = 'K';
	$offset = 0;
	$gr_h = $ih - $ytm - $ybm;
	$x_step = ($iw - $xlm - $xrm) / $x_ticks;
	$y_step = ($ih - $ytm - $ybm) / $y_ticks;
	$bar_w = ($x_step / 2) - 1;
	
	//
	// determine scale
	//
	$low = 99999999999;
	$high = 0;
	for ($i=0; $i<$x_ticks; $i++)
	{
	    if ($data[$i]["rx"] < $low)
		$low = $data[$i]["rx"];
	    if ($data[$i]["tx"] < $low)
		$low = $data[$i]["tx"];
	    if ($data[$i]["rx"] > $high)
		$high = $data[$i]["rx"];
	    if ($data[$i]["tx"] > $high)
		$high = $data[$i]["tx"];
	}
			

	while ($high > ($prescale * $y_scale * $y_ticks))
	{
	    $y_scale = $y_scale * 2;
	    if ($y_scale >= 1024)
	    {
		$prescale = $prescale * 1024;
		$y_scale = $y_scale / 1024;
		if ($unit == "K") 
		    $unit = "M";
		else if ($unit == "M")
		    $unit = "G";
		else if ($unit == "G")
		    $unit = "T";
	    }
	}
	
	//
	// graph scale factor (per pixel)
	//
	$sf = ($prescale * $y_scale * $y_ticks) / $gr_h;
	
	if ($data[0] == "nodata")
	{
	    $font = 6;
	    $text = "no data available";
	    $textwidth = imagefontwidth($font) * strlen($text);
	    imagestring($im, $font, $xlm + (300 - ($textwidth/2)), $ytm + 80, $text, $cl["black"]);
	}
	else
	{
    	    //
	    // draw bars
	    //		
	    for ($i=0; $i<$x_ticks; $i++)
	    {
		$x = $xlm + ($i * $x_step);
		$y = $ytm + ($ih - $ytm - $ybm) - (($data[$i]["rx"] - $offset) / $sf);
		imagefilledrectangle($im, $x, $y, $x + $bar_w, $ih - $ybm, $cl["rx"]);
	    
		$y = $ytm + ($ih - $ytm - $ybm) - (($data[$i]["tx"] - $offset) / $sf);
		imagefilledrectangle($im, $x+$bar_w+2, $y, $x+$x_step, $ih - $ybm, $cl["tx"]);
	    }
	

	    //
	    // axis labels
	    //
    	    $font = 2;	
	    for ($i=0; $i<=$y_ticks; $i++)
	    {
		$label = ($i * $y_scale).$unit;
		$textwidth = imagefontwidth($font) * strlen($label);
    		imagestring($im, $font, $xlm - $textwidth - 3, ($ih - $ybm) - ($i * $y_step) - 8, $label, $cl["black"]);	
	    }
	
	    for ($i=0; $i<=$x_ticks; $i++)
	    {
		$label = $data[$i]["img_label"];
		$textwidth = imagefontwidth($font) * strlen($label);	
		imagestring($im, $font, $xlm + ($i * $x_step) + ($x_step / 2) - ($textwidth / 2), $ih - $ybm + 5, $label, $cl["black"]);	
    	    }
	}
	
	draw_border();
	draw_grid($x_ticks, $y_ticks);

	//
	// legend
	//
	imagefilledrectangle($im, $xlm, $ih-$ybm+25, $xlm+8,$ih-$ybm+33,$cl["rx"]);
	imagestring($im, 2, $xlm+14, $ih-$ybm+22,"bytes in",$cl["black"]);
	imagefilledrectangle($im, $xlm, $ih-$ybm+39, $xlm+8,$ih-$ybm+47,$cl["tx"]);	
	imagestring($im, 2, $xlm+14, $ih-$ybm+36,"bytes out",$cl["black"]);	
    }

    function update_image()
    {
	global $page,$hour,$day,$month,$im,$iface;

	if ($page == "summary")
		return;

	init_image();

	if ($page == "h")
	{
		draw_data($hour);
	}
	else if ($page == "d")
	{
		draw_data($day);
	}
	else if ($page == "m")
	{
		draw_data($month);
	}
	imagepng($im, "$iface-$page.png");
    }

    validate_input();

    get_vnstat_data();

    if ($page != "s" && $graph != "none")
	    update_image();

    //
    // html start
    //
    header("Content-type: text/html; charset=utf-8");
    print "<?xml version=\"1.0\"?>";
?>        
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
  <title>vnStat - PHP frontend</title>
  <link rel="stylesheet" type="text/css" href="vnstat_default.css"/>
</head>
<body>

<div style="width:806px">
  <div style="position:absolute; top:8px; left:8px; width:806px;">
     <div class="title">Traffic data for <?print "$iface"?></div>
  </div>
  <div style="float:left; position:relative; top:74px; z-index:1">
     <? write_side_bar();?>
  </div>
  <div style="float:left; position:relative; top:49px; z-index:1">
     <? write_tab_header($page);?>
  </div>
  <div style="float:left; position:relative; top:48px; z-index:0">
  <?
        if ($page == "s")
	{
	    write_summary();
	}
	else if ($page == "h")
	{	
	    write_last_hours();
	}
	else if ($page == "d")
	{
	    write_last_days();
	}
	else if ($page == "m")
	{
	    write_last_months();
	}
  ?>
  </div>
   <div style="float:left; position:relative; top:64px; width:806px;">
    <div class="footer">
      <small><a href="http://www.sqweek.com/vnstat">vnStat PHP frontend</a> 1.1 - &copy;2005 Bjorge Dijkstra (bjd _at_ jooz.net)</small>
    </div>
    <br>
  </div>
</div>

</body></html>
