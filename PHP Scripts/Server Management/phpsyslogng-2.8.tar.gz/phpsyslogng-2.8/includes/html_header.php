<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

?>
<html>
<head>
<?php echo "<title>".PAGETITLE." ".VERSION.": ".$addTitle."</title>"; ?>
<link rel=stylesheet type=text/css href='css/default.css'>
<META HTTP-EQUIV='Pragma' CONTENT='no-cache'>
</head>
<body>
<table class="header">
<tr><td>
	<a href="index.php"><h2 class="logo">php-syslog-ng</h2></a>
	Network Syslog Monitor
</td><td class="headerright">
	<?php echo date("l F dS, Y - H:i:s"); ?><br>
	Your IP: <?php echo $_SERVER['REMOTE_ADDR']; ?>
</td></tr></table>
<table class="headerbottom""><tr><td>
<?php
if(defined('REQUIRE_AUTH') && REQUIRE_AUTH == TRUE && $sessionVerified) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=login&logout=TRUE\">Logout</a>";
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=searchform\">Search</a>";
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=config\">Config</a>";
}
elseif(defined('REQUIRE_AUTH') && REQUIRE_AUTH == TRUE) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=login\">Login</a>";
}

if(!defined('REQUIRE_AUTH') || !REQUIRE_AUTH) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=searchform\">Search</a>";
}

if(defined('USE_CACHE') && USE_CACHE && !REQUIRE_AUTH) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=config\">Config</a>";
}

echo "<a class=\"vertmenu\" href=\"index.php?pageId=help\">Help</a>";
echo "<a class=\"vertmenu\"  href=\"index.php?pageId=about\">About</a>";
?>
	&nbsp
</td></tr></table>
<center>
