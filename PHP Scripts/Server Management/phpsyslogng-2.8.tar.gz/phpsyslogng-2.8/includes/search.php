<?php
// Copyright (C) 2001-2004 by Michael Earls, michael@michaelearls.com
// Copyright (C) 2004-2005 Jason Taylor, j@jtaylor.ca
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

require_once 'includes/html_header.php';

//------------------------------------------------------------------------
// See if the MERGELOGTABLE is configured and available
//------------------------------------------------------------------------
$mergelogtable = FALSE;
if(defined('MERGELOGTABLE') && MERGELOGTABLE) {
	if(table_exists(MERGELOGTABLE, $dbLink)) {
		$mergelogtable = TRUE;
	}
}

// Get list of log tables
$logTableArray = get_logtables($dbLink);

//------------------------------------------------------------------------
// Print the top of the form and the table selection if there are multiple
// log tables.
//------------------------------------------------------------------------
$table = get_input('table');
if($table && !validate_input($table, 'table')) {
	require_once 'includes/html_header.php';
	echo "The table has the wrong format.<p>";
	require_once 'includes/html_footer.php';
	exit;}
?>
<table class="pagecontent">
<tr><td>
<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="GET" name="results">
<table><tr><td>
<?php
if(count($logTableArray) > 1 && !$table) {
?>
        <table class="searchform">
        <tr class="lighter"><td>
                <b>SELECT TABLE:</b>
                <select name="table">
<?php
        echo "<option selected>".DEFAULTLOGTABLE."</option>";
        if($mergelogtable) {
                echo "<option>".MERGELOGTABLE."</option>";
        }
	rsort($logTableArray);
        foreach($logTableArray as $value) {
		if($value != DEFAULTLOGTABLE && $value != MERGELOGTABLE) {
	                echo "<option>".htmlentities($value)."</option>";
		}
        }
?>
                </select>
        </td></tr></table>
<?php
}
else {
	if(!$table) {
		$table = DEFAULTLOGTABLE;
	}
	echo "<table class=\"searchform\">";
	echo "<tr class=\"lighter\"><td>";
	echo "<b>USING TABLE: ".$table."</b>";
	echo "</td></tr></table>";
	echo "<input type=\"hidden\" name=\"table\" value=\"".$table."\">";
}


//------------------------------------------------------------------------
// If MERGELOGTABLE is not used and there are multiple log tables
// then make the user pick a table to search before showing the rest of
// the search form.
//------------------------------------------------------------------------
if(!$mergelogtable && count($logTableArray) > 0 && !$table) {
	?>
</td></tr>
        <table class="searchform">
        <tr><td class="darker">
		<input type="hidden" name="pageId" value="searchform">
        <input type="submit" value="Select database">
        </td></tr></table>
</td></tr></table>
</form>
</td></tr></table>
<?php

}
//------------------------------------------------------------------------
// Else show the rest of the form.
//------------------------------------------------------------------------
else {
	$hostarray = array();
	$facilityarray = array();

	// What table to use to fill in the HOST and FACILITY fields?
	if($mergelogtable) {
		$useTable = MERGELOGTABLE;
	}
	elseif($table) {
		$useTable = $table;
	}
	else {
		$useTable = DEFAULTLOGTABLE;
	}
	
	//------------------------------------------------------------------------
	// Use cache?
	//------------------------------------------------------------------------
	if(USE_CACHE && table_exists(CACHETABLENAME, $dbLink)) {
		// If the cache table is empty then reload it.
		$sql = "SELECT * FROM ".CACHETABLENAME." WHERE tablename='".$useTable."'";
		$queryresult = perform_query($sql, $dbLink);
		if(num_rows($queryresult) == 0) {
			reload_cache($useTable, $dbLink);
		}

		// Get the timestamp for the last update.
		$sql = "SELECT updatetime FROM ".CACHETABLENAME." WHERE tablename='"
			.$useTable."'";
		$queryresult = perform_query($sql, $dbLink);
		$row = fetch_array($queryresult);
		$cacheUpdate = $row['updatetime'];

		// Print info about the cache.
		echo "<table class=\"searchform\">";
		echo "<tr class=\"lighter\"><td>";
		echo "<b>USING CACHE TO POPULATE HOST AND FACILITY FIELDS.</b>";
		echo "<br />Cache last updated on ".$cacheUpdate.".";
		echo "</td></tr></table>";

		// Get the HOST list
		$sql = "SELECT DISTINCT value FROM ".CACHETABLENAME." WHERE type='HOST'
			AND tablename='".$useTable."'";
		$queryresult = perform_query($sql, $dbLink);
		while ($line = fetch_array($queryresult)) {
			array_push($hostarray, $line['value']);
		}
		sort($hostarray);

		// Get the FACILITY list
		$sql = "SELECT DISTINCT value FROM ".CACHETABLENAME." WHERE type='FACILITY'
			AND tablename='".$useTable."'";
		$queryresult = perform_query($sql, $dbLink);
		while ($line = fetch_array($queryresult)) {
			array_push($facilityarray, $line['value']);
		}
		sort($facilityarray);
	}
	else {
	//------------------------------------------------------------------------
	// If no cache then get possible values for facility and host from table.
	//------------------------------------------------------------------------
		$sql = "SELECT DISTINCT host FROM ".$useTable;
		$queryresult = perform_query($sql, $dbLink);
		while ($line = fetch_array($queryresult)) {
			array_push($hostarray, $line['host']);
		}
		sort($hostarray);

		$sql = "SELECT DISTINCT facility FROM ".$useTable;
		$queryresult = perform_query($sql, $dbLink);
		while ($line = fetch_array($queryresult)) {
			array_push($facilityarray, $line['facility']);
		}
		sort($facilityarray);
	}
	//------------------------------------------------------------------------
	// Print the rest of the form.
	//------------------------------------------------------------------------
?>
	<table class="searchform">
	<tr class="lighter"><td>
		<b>HOSTS:</b>
		<table align="center" class="formentry"><tr><td>
		Include
		</td><td>
		<input name="excludeHost" value="0" type="radio">
		</td></tr>
		<tr><td>
		Exclude
		</td><td>
		<input name="excludeHost" value="1" type="radio" checked>
		</td></tr>
		<tr><td>
		Hostname like
		</td><td>
		<input type=text name=host2 size=18>
		</td></tr>
		<tr><td valign="top">
		=====AND=====
		</td><td>
		<select name="host[]" multiple size=6>
<?php
	foreach($hostarray as $value) {
		echo "<option>".htmlentities($value)."</option>";
	}
?>
		</select>
		</td></tr></table>
	</td><td>
		<b> SYSLOG FACILITY:</b>
		<table align="center" class="formentry"><tr><td>
		Include
		</td><td>
		<input name="excludeFacility" value="0" type="radio">
		</td></tr>
		<tr><td>
		Exclude
		</td><td>
		<input name="excludeFacility" value="1" type="radio" checked>
		</td></tr>
		<tr><td colspan=2>
		<select name="facility[]" multiple size=8>
<?php
	foreach($facilityarray as $value) {
		echo "<option>".htmlentities($value)."</option>";
	}
?>
		</select>
		</td></tr></table>
	</td><td>
		<b> SYSLOG PRIORITY:</b>
		<table align="center" class="formentry"><tr><td>
		Include
		</td><td>
		<input name="excludePriority" value="0" type="radio">
		</td></tr>
		<tr><td>
		Exclude
		</td><td>
		<input name="excludePriority" value="1" type="radio" checked>
		</td></tr>
		<tr><td colspan=2>
		<select name="priority[]" multiple size=8>
		<option>debug
		<option>info
		<option>notice
		<option>warning
		<option>err
		<option>crit
		<option>alert
		<option>emerg
		</select>
		</td></tr></table>
	</td></tr></table>
	<table class="searchform">
	<tr class="lighter"><td>
		<table align="center" class="formentry">
		<tr><td></td><td>
		DATE
		</td><td>
		TIME
		</td></tr>
		<tr><td>
		<b>From:</b>
		</td><td>
		<input type="text" size=10 maxlength=10 name="date">
		</td><td>
		<input type="text" size=8 maxlength=8 name="time">
		</td></tr><tr><td>
		<b>To:</b>
		</td><td>
		<input type="text" size=10 maxlength=10 name="date2">
		</td><td>
		<input type="text" size=8 maxlength=8 name="time2">
		</td></tr></table>
		The date format is YYYY-MM-DD and the time format is HH:MM:SS.<br>
		Yesterday, today and now are also valid dates and now is also valid as a time.
	</td><td>
		<table align="center" class="formentry">
		<tr>
		<td><b>RECORDS PER PAGE</b></td>
		<td>
		<select name="limit">
		<option>25</option>
		<option>50</option>
		<option selected>100</option>
		<option>200</option>
		<option>500</option>
		<option>1000</option>
		</select>
		</td></tr>
		<tr>
		<td><b>ORDER BY</b></td>
		<td>
		<select name="orderby">
		<option>seq</option>
		<option>host</option>
		<option>facility</option>
		<option>priority</option>
		<option selected>datetime</option>
		</select>
		</td></tr>
		<tr>
		<td><b>SEARCH ORDER</b></td>
		<td>
		<select name="order">
		<option>ASC</option>
		<option selected>DESC</option>
		</select>
		</td></tr></table>
	</td></tr></table>
	<table class="searchform">
	<tr class="lighter"><td>
	<b>SEARCH MESSAGE:</b><br>
	Exclude <input type=checkbox name="ExcludeMsg1"> <input type=text name="msg1" size=75%> <b>AND</b><br>
	Exclude <input type=checkbox name="ExcludeMsg2"> <input type=text name="msg2" size=75%> <b>AND</b><br>
	Exclude <input type=checkbox name="ExcludeMsg3"> <input type=text name="msg3" size=75%>
	</td></tr>
	<tr class="lighter"><td>
	<b>COLLAPSE IDENTICAL MESSAGES INTO ONE LINE: </b>
	<input type=checkbox name="collapse" value="1" checked>
	</td></tr></table>
</td></tr>
	<table class="searchform">
	<tr><td class="darker">
	<input type="submit" name="pageId" value="Search">
	<input type="submit" name="pageId" value="tail">
	<input type="reset" value="Reset">
	</td></tr></table>
</td></tr></table>
</form>
</td></tr></table>
<?php
}
?>
