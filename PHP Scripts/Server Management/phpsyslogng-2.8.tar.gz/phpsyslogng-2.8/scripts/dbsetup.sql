# Make sure you edit the passwords of the three database users!
# Run it like this:
# shell> mysql -uroot -p < dbsetup.sql
#

CREATE DATABASE syslog;

USE syslog;

# create table logs under database syslog
CREATE TABLE logs (
host varchar(32) default NULL,
facility varchar(10) default NULL,
priority varchar(10) default NULL,
level varchar(10) default NULL,
tag varchar(10) default NULL,
datetime datetime default NULL,
program varchar(15) default NULL,
msg text,
seq bigint(20) unsigned NOT NULL auto_increment,
PRIMARY KEY (seq), KEY host (host),
KEY program (program), KEY datetime (datetime),
KEY priority (priority), KEY facility (facility)
) TYPE=MyISAM;

# create table users under database syslog
CREATE TABLE users (
username varchar(32) default NULL,
pwhash char(40) default NULL,
sessionid char(32) default NULL,
exptime datetime default NULL,
PRIMARY KEY (username)
) TYPE=MyISAM;

# Create the table for the cache function
CREATE TABLE search_cache (
tablename varchar(32) DEFAULT NULL,
type ENUM('HOST','FACILITY'),
value varchar(32) DEFAULT NULL,
updatetime datetime DEFAULT NULL,
INDEX type_name (type, tablename)
) TYPE=MyISAM;

# Create the two tables used by the access control function
CREATE TABLE user_access (
username varchar(32) DEFAULT NULL,
actionname varchar(32) DEFAULT NULL,
access ENUM('TRUE','FALSE'),
INDEX user_action (username, actionname)
) TYPE=MyISAM;

CREATE TABLE actions (
actionname varchar(32) NOT NULL,
actiondescr varchar(64) DEFAULT NULL,
defaultaccess ENUM('TRUE','FALSE'),
PRIMARY KEY (actionname)
) TYPE=MyISAM;

# Add the available actions to the access control table
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('add_user', 'Add users', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('edit_user', 'Edit users (delete and change password)', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('reload_cache', 'Reload search cache', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('edit_acl', 'Edit access control settings', 'TRUE');

# Create user with admin/admin login
INSERT INTO users (username, pwhash) VALUES('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997');

USE mysql;

# create users
INSERT INTO user (Host, User, Password) VALUES ('localhost','sysloguser', password('PW_HERE'));
INSERT INTO db (Host, Db, User) VALUES ('localhost','syslog','sysloguser');

INSERT INTO user (Host, User, Password) VALUES ('localhost','syslogfeeder', password('PW_HERE'));
INSERT INTO db (Host, Db, User) VALUES ('localhost','syslog','syslogfeeder');

INSERT INTO user (Host, User, Password) VALUES ('localhost','syslogadmin',password('PW_HERE'));
INSERT INTO db (Host, Db, User) VALUES ('localhost','syslog','syslogadmin');
COMMIT;
FLUSH PRIVILEGES;

# grant rights to user syslogadmin for backup purpose
GRANT USAGE ON *.* TO syslogadmin@localhost;
GRANT ALL ON syslog.* TO syslogadmin@localhost;
GRANT RELOAD ON *.* TO syslogadmin@localhost;

REVOKE ALL PRIVILEGES ON syslog.* FROM sysloguser@localhost;
GRANT USAGE ON *.* TO sysloguser@localhost;
GRANT SELECT ON syslog.* TO sysloguser@localhost;
GRANT UPDATE ON syslog.users TO sysloguser@localhost;

REVOKE ALL PRIVILEGES ON syslog.* FROM syslogfeeder@localhost;
GRANT USAGE ON *.* TO syslogfeeder@localhost;
GRANT INSERT ON syslog.* TO syslogfeeder@localhost;

GRANT ALL ON syslog.search_cache TO sysloguser@localhost;
GRANT SELECT ON syslog.user_access TO sysloguser@localhost;
GRANT ALL ON syslog.user_access TO syslogadmin@localhost;
GRANT SELECT ON syslog.actions TO sysloguser@localhost;
GRANT ALL ON syslog.actions TO syslogadmin@localhost;

COMMIT;
FLUSH PRIVILEGES;
