<?
define("_SERVERSTATUS_TITLE","Server Status");
?>