<?php @Zend;
6237;
// /************************************************************************
// *
// * FVsoftware(R) - PicoPortal(R)
// * Copyright (c) 2002-2005 FVsoftware
// * All Rights Reserved.
// *
// *************************************************************************
// *
// * Email: info@fvsoftware.com
// * Web: http://www.fvsoftware.com
// *
// * Distributor: FVsofware - Ing. Fabio Vaona
// *
// *************************************************************************
// *
// * This software is furnished under a license and may be used and copied
// * only  in  accordance  with  the  terms  of such  license and with the
// * inclusion of the above copyright notice.  This software  or any other
// * copies thereof may not be provided or otherwise made available to any
// * other person.  No title to and  ownership of the  software is  hereby
// * transferred.
// *
// * You may not reverse  engineer, decompile, defeat  license  encryption
// * mechanisms, or  disassemble this software product or software product
// * license.  FVsoftware (Fabio Vaona)  may terminate this license if you
// * fail to comply with any of the terms and conditions  set forth in our
// * end user license agreement  (EULA).  In such event,  licensee  agrees
// * to return licensor or destroy all copies of software upon termination
// * of the license.
// *
// * Please  see the LICENSE file for the full End User License Agreement.
// *
// ************************************************************************/

/*  �!This is not a text file!��   */
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>

2003120701 1 388 808 x�
�2eW�N�06���02�>A���߀P�R��Tb�B₥Ɖ��0� L�`�m�=xj�Nl�(����w��/*Ë�N��۴�iW�-p)F�PB����(��4Ϸ�9_��!#G�P=_�y!d�e3d�S4�H��w�z���ǾHb�Xl���_W�~6�^�$���e�_�� }�K�s�X���٥9l�� �e��ќK�[j���rM:Y�w�|��O�f��Ӿ�{Q�͆ד�>��j��z�%Y)��~\=T��u��QD��0���T������dv���"�(��Z{�����Ş��h6�#G���o�e��x�c�Q���S[��qG֨�z"{S�����q�P�(�S��V�Ot���a��%��}2