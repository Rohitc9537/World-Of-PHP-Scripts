Server Status Module for PHP-Nuke 7.8
===========================


Welcome!

First of all, thanks a lot to download this software, I hope that you
can enjoy it.

This PHP-Nuke Module speak with your Cpanel (hosting manager) and get
the status of the installed services.


This module is compatible with all the Cpanel theme skin!

Let's try it!

regards,
Ing. Fabio Vaona
(c) 2005 FVsoftware(r)
Application Service Provider
-Italy-