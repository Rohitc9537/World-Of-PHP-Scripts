#!/usr/bin/perl

# Copyright (c) 2005 Alessandro De Zorzi, Mirko Grava
# <phamm@rhx.it> http://phamm.rhx.it/
#
# Permission is granted to copy, distribute and/or modify this document
# under the terms of the GNU Free Documentation License, Version 1.2
# or any later version published by the Free Software Foundation;
# A copy of the license in DOCS.LICENSE file.

# many thanks to Marco Sanson for his time
# IMPORTANT IMPORTANT
# READ BEFORE USE IT!!
# at the moment you MUST change the line above the description
# CHANGE-THIS to set your correct parameters
# like basedn, binddn and gnarwl path

use Net::LDAP;
use Getopt::Std;
 
sub generate_random_string
{
        my $length_of_randomstring=shift;
 
        my @chars=('a'..'z','A'..'Z','0'..'9','_');
        my $random_string;
        foreach (1..$length_of_randomstring)
        {
                $random_string.=$chars[rand @chars];
        }
        return $random_string;
}
 
my $random_string=&generate_random_string(32);
 
$ldap = Net::LDAP->new("localhost");
$ldap->bind("cn=phamm,o=hosting,dc=example,dc=tld", password=>"your_phamm_password");
# CHANGE-THIS
# Change here your connection parameters binddn
 
getopt('m', \%opts);
$mail = $opts{m};
$path = '';
$vforward = '';
 
$mesg = $ldap->search(filter=>"(mail=$mail)", base=>"dc=example,dc=tld", attrs=> ['vdHome', 'mailbox', 'vacationForward'] ); 
# CHANGE-THIS
#Change also here the basedn
 
@entries = $mesg->entries;
foreach $entry (@entries) {
        $path = $entry->get_value('vdHome') . "/" . $entry->get_value('mailbox');
	$vforward = $entry->get_value('vacationForward');
}
 

# Command for stdin
$cmd1="" . $path . "new/" . $random_string . "";
#
$cmd2="/usr/bin/gnarwl";
# CHANGE-THIS
# change the path of gnarwl
#
$cmd3="/usr/sbin/sendmail " . $vforward;
 
# read stdin
$in="";
while (<>) {
  $in=join '',$in,$_;
}
chomp($in);
 
# Fork cmd1
# do not touch double fork!!
unless ($pid = fork) {
  unless (fork) {
    exec ("echo '$in' > $cmd1");
    die "exec failed!";
  }
  exit 0;
}
waitpid($pid,0);
 
# Fork cmd2
unless ($pid = fork) {
  unless (fork) {
    exec ("echo '$in' | $cmd2");
    die "exec failed!";
  }
  exit 0;
}
waitpid($pid,0);

#Fork cmd3
# here we use the attribute VactionForward for the mail delivery
# but the original destination receive the mail
# only a copy will be sent
if($vforward  =~ /\@/){
unless ($pid = fork) {
  unless (fork) {
    exec ("echo '$in' | $cmd3");
    die "exec failed!";
  }
  exit 0;
}
waitpid($pid,0);
}
#
 
exit;
