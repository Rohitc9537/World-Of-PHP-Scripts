<?php

// ** Require the library file with all functions
// require ('phamm_functions.inc.php');
// ** To develop include single file funtion
// ** this is not a safe way to include file :-P
$mydir = opendir("../plugins/mail/functions");
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require ("functions/$fn");
}
closedir($mydir);


$do = add_domain_mail ($domain_new, $password, $phamm_domain);

    if(DEBUG >= 1)
        echo  "vd=$domain_new,$LDAP_BASE <BR>";
		
    if(DEBUG >= 2)
        echo var_dump ($info);

// Add postmaster account
$do_postmaster = add_alias ($_POST["domain_new"], 'postmaster', 'postmaster','postmaster', $_POST["password1"]);

// Add abuse account
$do_abuse = add_alias ($_POST["domain_new"], 'abuse', '','postmaster','');
		
if ($do==1 && $do_postmaster == 1 && $do_abuse == 1)
	print_message ('success',$lang["domain"]." $domain_new ".$lang["added"]);

else
	print_message ('error',$lang["domain"]." $domain_new ".$lang["not_added"]);

?>
