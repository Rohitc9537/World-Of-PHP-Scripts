<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage mail
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Set Other Variables With Method GET or POST --> mail
if (isset($_GET["mail"]))
	$mail		= $_GET["mail"];
if (isset($_POST["domain_new"]))
	$domain_new	= $_POST["domain_new"];
if (isset($_POST["mail_new"]))
	$mail_new	= $_POST["mail_new"];
if (isset($_POST["alias_new"]))
	$alias_new	= $_POST["alias_new"];
if (isset($_POST["destinations_del"]))
	$destinations_del	= $_POST["destinations_del"];

// If User are logged
// *** unused *** check if can editaccounts
// then set the appropriate view 
//
if ($_SESSION["login"] != $_SESSION["username"] && $_SESSION["username"] != "postmaster")
{
    $mail = $_SESSION["login"];
	
	// Load self attributes to check if Account or Alias
	$self_values = self_values ("mail=$mail,vd=$_SESSION[domain],$LDAP_BASE",'');
	if (in_array('VirtualMailAlias',$self_values[0]["objectclass"]))
		$action = 'modify_alias';

	elseif (in_array('VirtualMailAccount',$self_values[0]["objectclass"]))
		$action = 'modify_mail';
}

// ** Require the library file with all functions
// require ('phamm_functions.inc.php');
// ** To develop include single file funtion
// ** this is not a safe way to include file :-P
$mydir = opendir("../plugins/mail/functions");
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require ("../plugins/mail/functions/$fn");
}
closedir($mydir);

// Some preliminare check to validate domain and mail format
//if (isset($domain_new))
//	$domain_valid	= domain_valid($domain_new);
if (isset($mail_new))
	$mail_valid		= checkSyntax('account',$mail_new);
if (isset($alias_new))
	$alias_valid	= checkSyntax('account',$alias_new);
if (isset($_GET["catch_all"]))
	$alias_valid	= TRUE;

// ********************************************************************
// Show all domain selected e-mails and aliases account
if (($domain && !$action && !$mail) || ($action=='add_mail' && !$mail_valid) || ($action=='add_alias' && !$alias_valid && !$_POST["catch_all"]))
{
	if (DEBUG)
		print_message ('debug',"case_1");

        if ($action=='add_mail' && !$mail_valid)
			print_message ('error',$lang["mail_is_not_valid"]);
			
	// Domain Property Menu
	echo ("<P>");
	echo "<A href=\"?domain=$domain&action=domain_modify\">".$lang["domain_property"]."</A>";
	if (is_catch_all($domain))
	echo " | <A href=\"?domain=$domain&action=modify_alias&catch_all=1&mail=@$domain\">".$lang["edit"]." ".$lang["catch_all"]."</A>";
	else
	echo " | <A href=\"?domain=$domain&action=add_alias&catch_all=1\">".$lang["catch_all"]."</A>";
	echo ("</P>");

	$do = is_domain_mail ($domain);
	
	if ($do)
	{
		form_add_mail ($domain);
	
		// Warning catch all active
		if (is_catch_all ($domain))
			print_message('warning',$lang["catch_all"]." ".$lang["active"]);
	
		mail_list ($domain);
	}
	else
	{
		print_message('warning',"mail_domain_dont_exists");
		form_add_domain ($domain);
	}
	
    echo ("<BR>");

    if ($action == 'add_alias' && !$alias_valid)
		print_message ('error',$lang["alias_is_not_valid"]);

	form_add_alias ($domain);
	
	// Warning catch all active
	if (is_catch_all ($domain))
		print_message('warning',$lang["catch_all"]." ".$lang["active"]);
		
	alias_list ($domain);

	if (PHAMM_LOG >= 2)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
}

// Print the second form to add mail if format mail is valid
elseif ($action == 'add_mail' && $mail_valid)
{
	if (DEBUG)
		print_message ('debug','case_3');
		
	if (isset($_POST["domain"]))
    	$domain		= $_POST["domain"];
	if (isset($_POST["quota"]))
	    $quota		= $_POST["quota"];
	if (isset($_POST["real_name"]))
	    $real_name	= $_POST["real_name"];
	if (isset($_POST["password1"]))
    	$password1	= $_POST["password1"];
	if (isset($_POST["password2"]))
	    $password2	= $_POST["password2"];

	if (isset($password1) && isset($password2))
	    $pw_is_ok = password_valid ($password1, $password2);

    if ($step == '2' && $real_name && ($pw_is_ok || $_POST["randompw"]))
    {
        $do = add_mail ($domain, $mail_new, $quota, $real_name, $password1,$_POST["randompw"]);
		
		if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
		
		if ($do=='1')
		{
			print_message ('success',"$mail_new@$domain ".$lang["added"]);

			// Send Welcome message to new mail account if required
			if (SEND_WELCOME)
			{
				if (version_compare(phpversion(), "4.3.0", ">="))
					$msg = file_get_contents($welcome_msg);
					
				$headers .= "From: $welcome_sender\r\n";
				$headers .= "BCc: $welcome_bcc\r\n";
				mail($mail_new."@".$domain, $welcome_subject, $msg, $headers);
			}

			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
			print_message ('error',"$mail_new ".$lang["not_added"]);
    }

    elseif ($step == 2 && (!$pw_is_ok || !$real_name))
    {
		if (!$pw_is_ok)
			print_message ('error',$lang["password_dont_match"]);
		if (!$real_name)
			print_message ('error',$lang["missing_real_name"]);
        form_add_mail_2 ($domain, $mail_new);
    }
	
    else
    {
        form_add_mail_2 ($domain, $mail_new);
    }

}

// Print the second form to add alias if format alias is valid
elseif (($action == 'add_alias' && $alias_valid) || ($action == 'add_alias' && $_POST["catch_all"]))
{
	if (DEBUG)
		print_message('debug','case_4');
		
    $domain		= $_POST["domain"];
	if (!$_POST["domain"])
    	$domain		= $_GET["domain"];
    $real_name	= $_POST["real_name"];
    $destinations	= $_POST["destinations"];
    $password1	= $_POST["password1"];
    $password2	= $_POST["password2"];

    $pw_is_ok = password_valid ($password1,$password2);

    if ($step=='2' && $pw_is_ok && $destinations)
    {
        $do = add_alias ($domain, $alias_new, $real_name, $destinations, $password1);
		if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
		
		if ($do=='1')
		{
			print_message ('success',"$alias_new@$domain ".$lang["added"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		
		else
			print_message ('error',"$alias_new@$domain ".$lang["not_added"]);

    }

    elseif (($step=='2' && $pw_is_ok == 'KO') || ($step=='2' && $pw_is_ok && !$destinations))
    {
		print_message('error',$lang["password_dont_match"]);
        form_add_alias_2 ($domain, $alias_new);
    }

    else
    {
        form_add_alias_2 ($domain, $alias_new);
    }
}

// Print form to modify mail values
//elseif ($domain && $action=='modify_mail' && $mail)
//elseif ($action == "modify_mail" && $mail && $step != 2)
elseif ($action == "modify_mail" && $mail && $step != 2)
{
	if (DEBUG)
		print_message ('debug','case_5');
		
    if (!$domain)
        $domain		= $_GET["domain"];

    if (!$mail)
        $mail		= $_GET["mail"];

    $mail_values	= mail_values ($mail);

    $quota		= $mail_values[0]["quota"][0];
    $quota		= $quota/$multi/$multi;
    $real_name	= $mail_values[0]["cn"][0];
    $vacation["active"]		= $mail_values[0]["vacationactive"][0];
    $vacation["info"]		= $mail_values[0]["vacationinfo"][0];
    $vacation["start"]		= $mail_values[0]["vacationstart"][0];
    $vacation["end"]		= $mail_values[0]["vacationend"][0];
    $vacation["forward"]	= $mail_values[0]["vacationforward"][0];
    $vacation["description"]= $mail_values[0]["description"][0];
    $amavis["amavisbypassviruschecks"]= $mail_values[0]["amavisbypassviruschecks"][0];
    $amavis["amavisbypassspamchecks"]= $mail_values[0]["amavisbypassspamchecks"][0];
    $amavis["amavisspamtaglevel"]= $mail_values[0]["amavisspamtaglevel"][0];
    $amavis["amavisspamtag2level"]= $mail_values[0]["amavisspamtag2level"][0];
    $amavis["amavisspamkilllevel"]= $mail_values[0]["amavisspamkilllevel"][0];
	
    $phamm["forwardactive"]= $mail_values[0]["forwardactive"][0];
    $phamm["maildrop"]= $mail_values[0]["maildrop"][0];

    form_add_mail_2 ($domain, $mail);
}

// Modify Mail values
elseif ($action=='modify_mail' && $step=='2')
{
	if (DEBUG)
		print_message ('debug',"case_6");
		
    $quota			= $_POST["quota"];
    $real_name		= $_POST["real_name"];
    $password1      = $_POST["password1"];
    $password2      = $_POST["password2"];
    $vacation		= $_POST["vacation"];
    $amavis			= $_POST["amavis"];
    $phamm			= $_POST["phamm"];

    $pw_is_ok = password_valid ($password1, $password2);

    if (($password1=='' &&  $password2 == '') || $pw_is_ok)
    {
        $do = modify_mail ($mail_new, $domain, $real_name, $quota, $password1, $vacation, $amavis, $phamm);

        if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

		if ($do == 1)
		{
			print_message ('success',"$mail_new ".$lang["modified"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
		{
			print_message ('error',"$mail_new ".$lang["not_modified"]);
		}

    }

    else
    {
		print_message('error',$lang["password_dont_match"]);
        form_add_mail_2 ($domain, $mail_new);
    }
}

// Print form to modify alias values
elseif (($domain && $action=='modify_alias' && $mail && !$step) || ($action == 'modify_alias' && $_GET["catch_all"]))
{
	if (DEBUG)
		print_message ('debug',"case_7");
	
	if ($_SESSION["domain"])
	    $domain		= $_SESSION["domain"];
	else
	    $domain		= $_GET["domain"];
		
	if (!isAdmin() && !isPostmaster())
	    $mail		= $_SESSION["login"];
	else
	    $mail		= $_GET["mail"];
	
    $alias_values	= alias_values ($mail);

    $real_name	= $alias_values[0]["cn"][0];
    $destinations	= $alias_values[0]["maildrop"];

    form_add_alias_2 ($domain, $mail);
}

// Modify Mail values
elseif ($action=='modify_alias' && $step=='2')
{
	if (DEBUG)
		print_message ('debug',"case_8");
		
    $real_name			= $_POST["real_name"];
    $alias_new			= $_POST["alias_new"];
    $destinations		= $_POST["destinations"];
    $destinations_del	= $_POST["destinations_del"];
    $password1			= $_POST["password1"];
    $password2			= $_POST["password2"];

    $pw_is_ok = password_valid ($password1, $password2);

    if (($password1=='' &&  $password2 == '') || $pw_is_ok)
    {
        $do = modify_alias ($alias_new, $domain, $real_name, $destinations, $password1, $destinations_del);
		
        if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

		if ($do == 1)
		{
			print_message ('success',"$alias_new ".$lang["modified"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
		{
			print_message ('error',"$alias_new ".$lang["not_modified"]);
		}
    }

    else
    {
		print_message('error',$lang["password_dont_match"]);
        form_add_alias_2 ($domain, $alias_new);
    }
}

elseif ($action=='mail_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_9");
		
    // var to mail_modify_group
    $mail_delete		= $_GET["mail_delete"];
    if (!$_GET["mail_delete"])
        $mail_delete		= $_POST["mail_delete"];

    $mail_active		= $_GET["mail_active"];
    if (!$_GET["mail_active"])
        $mail_active		= $_POST["mail_active"];

    $virus_check		= $_GET["virus_check"];
    if (!$_GET["virus_check"])
        $virus_check		= $_POST["virus_check"];

    $spam_check		= $_GET["spam_check"];
    if (!$_GET["spam_check"])
        $spam_check		= $_POST["spam_check"];
    
	$editaccounts		= $_GET["editaccounts"];
    if (!$_GET["editaccounts"])
        $editaccounts		= $_POST["editaccounts"];

	$smtpAuth		= $_GET["smtpAuth"];
    if (!$_GET["smtpAuth"])
        $smtpAuth		= $_POST["smtpAuth"];
	
	$mail_postmaster	= $_POST["mail_postmaster"];

    mail_modify_group ($mail_delete, $mail_active, $virus_check, $spam_check, $editaccounts,$smtpAuth);
	
	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
		
	refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
}

elseif ($action=='alias_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_10");
		
    // var to mail_modify_group
    $alias_delete		= $_GET["alias_delete"];
    if (!$_GET["alias_delete"])
        $alias_delete		= $_POST["alias_delete"];

    $alias_active		= $_GET["alias_active"];
    if (!$_GET["alias_active"])
        $alias_active		= $_POST["alias_active"];

	$editaccounts		= $_GET["editaccounts"];
    if (!$_GET["editaccounts"])
        $editaccounts		= $_POST["editaccounts"];

    alias_modify_group ($alias_delete, $alias_active, $editaccounts);
	
	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

	refresh("main.php"."?domain=".$domain."&initial=".$initial,'',REFRESH_TIME);
}

elseif ($action=='domains_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_11");
		
    // var to mail_modify_group
    if (isset($_GET["domains_delete"]))
	    $domains_delete		= $_GET["domains_delete"];
    if (isset($_POST["domains_delete"]))
        $domains_delete		= $_POST["domains_delete"];

    if (isset($_GET["domains_edit"]))
	    $domains_edit		= $_GET["domains_edit"];
    if (isset($_POST["domains_edit"]))
        $domains_edit		= $_POST["domains_edit"];

    if (isset($_GET["domains_active"]))
    	$domains_active		= $_GET["domains_active"];
    if (isset($_POST["domains_active"]))
        $domains_active		= $_POST["domains_active"];

    if (isset($_GET["domains_postmaster"]))
 	   $somains_postmaster	= $_GET["domains_postmaster"];
    if (isset($_POST["domains_postmaster"]))
        $somains_postmaster	= $_POST["domains_postmaster"];

    domains_modify_group ($domains_delete, $domains_edit, $domains_active, $somains_postmaster);

	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
	
	refresh("main.php",'',REFRESH_TIME);
}

// Domain Property
elseif ($action == 'domain_modify' && !$step)
{
	if (DEBUG)
		print_message ('debug',"case_12");
		
	form_add_domain_2 ($domain,$phamm_domain);
//    form_add_postmasters ($postmasters_new);
}

// Domain Property
elseif ($action=='domain_modify' && $step==2)
{
	if (DEBUG)
		print_message ('debug',"case_13");
		
    $password1	= $_POST["password1"];
    $password2	= $_POST["password2"];
    $domain		= $_POST["domain_new"];

    $pw_is_ok = password_valid ($password1, $password2);
	
	if ($pw_is_ok)
	{
		$do=domain_modify ($domain, $password1);
		refresh("main.php"."?domain=".$domain_new,'',REFRESH_TIME);
	}

	// move to main
	else
	{
		form_add_domain_2 ($domain,$phamm_domain);
	}
}

// Print all domains list or short its by initial
else
{
	if (DEBUG)
		print_message ('debug',"case_14");
		
    domains_list ($initial,$dottld);
}
?>
