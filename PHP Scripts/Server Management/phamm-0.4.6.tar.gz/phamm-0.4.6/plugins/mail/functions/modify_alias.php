<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function modify_alias ($alias, $domain, $real_name, $destinations, $password1, $destinations_del)
{

    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;

    // prepare data
    $info["lastChange"]		= time();
    if ($real_name)
        $info["cn"]			= "$real_name";

    if ($password1)
		$info["userPassword"]	= password_hash($password1);

    if ($destinations)
    {
        $delimitators = array(" ", ";", "\t", "\n", ":");
        $destinations=str_replace($delimitators,",","$destinations");
        $maildrop_add=explode (",",$destinations);

        for ($i=0; $i < count($maildrop_add); $i++)
        {
            $info_add["maildrop"][$i] = "$maildrop_add[$i]";
        }

        $r=ldap_mod_add($connect, "mail=$alias,vd=$domain,$LDAP_BASE", $info_add);

    }

    if ($destinations_del)
    {
        for ($i=0; $i < count($destinations_del); $i++)
        {
            $info_del["maildrop"][$i] = "$destinations_del[$i]";
        }

        $r=ldap_mod_del($connect, "mail=$alias,vd=$domain, $LDAP_BASE", $info_del);

    }

    if ($info)
        $r=ldap_modify($connect, "mail=$alias,vd=$domain,$LDAP_BASE", $info);
	
	return $r;

}
?>
