<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Print e-mail e alias list for a domain
// ********************************************************************

function alias_list ($domain)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
    global $td_width;
    global $td_width_box;
	global $initial;
	
	if (!$initial && DEFAULT_VIEW == 'none')
		$initial = '.oOo.';

    if ($initial == 'ALL')
        $initial = '';

    $filter = "(&(mail=$initial*@$domain)(objectClass=VirtualMailAlias)(!(maildrop=postmaster)))";

    $search = ldap_search($connect, $LDAP_BASE, $filter);

	// Order the results
	if (version_compare(phpversion(), "4.2.0", ">="))
		ldap_sort($connect, $search,"mail");

    $results = ldap_get_entries($connect, $search);

	// Free the memory
	ldap_free_result($search);

    $tr_header = ("<TR class=\"header\">
                  <TD></TD>
                  <TD width=\"$td_width\">$results[count] ".$lang["alias"]."</TD>
                  <TD width=\"$td_width\">".$lang["real_name"]."</TD>
                  <TD width=\"$td_width_box\">".$lang["destinations"]."</TD>
                  <TD width=\"$td_width_box\">".$lang["alias_is_active"]."</TD>
                  ");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>");
    echo ("<INPUT type='hidden' name='action' value='alias_modify_group'>");
    echo ("<INPUT type='hidden' name='domain' value=\"$domain\">");

    echo ("<TABLE class=\"data\">\n");
    echo $tr_header;
    for ($idx=0; $idx < $results["count"]; $idx++)
    {
		// Prevent empty value
        $delete = 'FALSE';
		$active = 'FALSE';
		$destinations = array();

        $mail = $results[$idx]["mail"][0];

		if (isset($results[$idx]["delete"][0]))
	        $delete = $results[$idx]["delete"][0];
		if (isset($results[$idx]["accountactive"][0]))
		    $active = $results[$idx]["accountactive"][0];
		if (isset($results[$idx]["maildrop"][0]))
	    	$destinations = $results[$idx]["maildrop"][0];

        echo ("<TR class=\"data\">");
		true_false_box ($delete, $mail,'alias_delete','alias_modify_group',0);
        echo ("<TD><A href=\"?domain=$domain&mail=$mail&action=modify_alias\">$mail</A></TD>");
        echo "<TD>";
		echo stripslashes($results[$idx]["cn"][0]);
		echo "</TD>";
        echo ("<TD>$destinations</TD>");
    	    true_false_box ($active, $mail,'alias_active','alias_modify_group',0);
        echo ("</TR>\n");
    }

	echo ("<TR class='footer'><TD></TD><TD>");
    form_modify('modify_aliases');
    echo ("</TD><TD colspan=\"\"></TD></TR>");

    echo ("</TABLE>\n");

    if ($initial == '')
        $initial = 'ALL';
}
?>
