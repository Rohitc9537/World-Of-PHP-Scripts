<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Add a mail
* 
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* 
* @var string domain
* @var string mail_new
* @var string quota
* @var string real_name
* @var string password
* @return bolean the result success=1 or insuccess=0
**/

function add_mail ($domain, $mail_new, $quota, $real_name, $password, $randompw=FALSE)
{
    $mail=$mail_new.'@'.$domain;

    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;
    global $is_quota;
    global $quota_default;
    global $vmail_path;
    global $accountActive;
    global $amavisBypassVirusChecks;
    global $amavisBypassSpamChecks;
    global $amavisSpamTagLevel;
    global $amavisSpamTag2Level;
    global $amavisSpamKillLevel;

    if (!$quota && $is_quota)
        $quota=$quota_default;

    $quota=$quota*$multi*$multi;

    // prepare data
    $info["objectclass"][]		= "top";
    $info["objectclass"][]		= "VirtualMailAccount";
    $info["objectclass"][]		= "Vacation";
    $info["objectclass"][]		= "amavisAccount";
    $info["objectclass"][]		= "VirtualForward";

    $info["mail"]			= "$mail";
    $info["sn"]				= "$real_name";
    // $info["homeDirectory"]	= "$vmail_path/domains";
	$info["vdHome"]  		= "$vmail_path/domains";
    $info["mailbox"]		= "$domain/$mail_new/";
    if ($quota)
        $info["quota"]		= "$quota";
		
	// Generate random password
	if ($randompw)
    	$password	= randstr(PASSWORD_RND_LENGHT);
		
	$info["userPassword"]	= password_hash($password);
	$info["cn"]				= "$real_name";
    $info["accountActive"]	= "$accountActive";
    $info["lastChange"]		= time();
    $info["delete"]			= "FALSE";
	$info["creationDate"]	= phamm_date($date_format);
	
    // Phamm only
    $info["forwardActive"]	= "FALSE";

    // vacation
    $info["vacationActive"]			= "FALSE";
    $info["otherTransport"]			= OTHER_TRANSPORT.':';

    // Amavis
    if (USE_AMAVIS == 1)
    {
        // $info["amavisVirusLover"]		= "TRUE";
        // $info["amavisBannedFilesLover"]	= "TRUE";
        $info["amavisBypassVirusChecks"]= "$amavisBypassVirusChecks";
        $info["amavisBypassSpamChecks"]	= "$amavisBypassSpamChecks";
        $info["amavisSpamTagLevel"]		= "$amavisSpamTagLevel";
        $info["amavisSpamTag2Level"]    = "$amavisSpamTag2Level";
        $info["amavisSpamKillLevel"]    = "$amavisSpamKillLevel";
        //$info["amavisSpamModifiesSubj"]	= "FALSE";
        //$info["amavisWhitelistSender"]	= "FALSE";
        //$info["amavisBlacklistSender"]	= "FALSE";
        //$info["amavisSpamQuarantineTo"]	= "FALSE";
        //$info["amavisSpamLover"]    	= "FALSE";
    }

    if (DEBUG)
        echo ("mail=$mail,vd=$domain,$LDAP_BASE");

    $r = ldap_add($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info);

    return $r;
}
?>
