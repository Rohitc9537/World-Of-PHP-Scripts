<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Modify some properties on multiple domains
*
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function domains_modify_group ($domains_delete, $domains_edit, $domains_active, $domains_postmaster)
{
    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;

    // Only for the Array domains_active the value change
    //
    for ($i=0; $i < count($domains_active); $i++)
    {
        // Search the domain
        $sth = ldap_list($connect,"$LDAP_BASE","vd=$domains_active[$i]");
        $results = ldap_get_entries($connect, $sth);

        $accountActive=$results[0]["accountactive"][0];

        if ($accountActive=="FALSE")
            $info_active["accountActive"] = "TRUE";

        elseif ($accountActive=="TRUE")
	        $info_active["accountActive"] = "FALSE";

        if ($info_active)
            $r=ldap_modify($connect, "vd=$domains_active[$i], $LDAP_BASE", $info_active);
    }

    // Only for the Array domains_edit the value change
    //
    for ($i=0; $i < count($domains_edit); $i++)
    {
        // Search the domain
        $sth = ldap_list($connect,"$LDAP_BASE","vd=$domains_edit[$i]");
        $results = ldap_get_entries($connect, $sth);

        $editAccounts=$results[0]["editaccounts"][0];

        if ($editAccounts=="FALSE")
            $info_edit["editAccounts"] = "TRUE";

        elseif ($editAccounts=="TRUE")
    	    $info_edit["editAccounts"] = "FALSE";

        if ($info_edit)
		{
			// Jamm compatibility
			//
            $r=ldap_modify($connect, "vd=$domains_edit[$i],$LDAP_BASE", $info_edit);
			// Also change the attribute in the Postmaster account
			// of this domain (Only when use phamm.schema)
            $r=ldap_modify($connect, "cn=postmaster,vd=$domains_edit[$i],$LDAP_BASE", $info_edit);
		}
    }

    // Only for the Array domains_delete the value change
    //
    for ($i=0; $i < count($domains_delete); $i++)
    {
        // Search the domain
        $sth = ldap_list($connect,"$LDAP_BASE","vd=$domains_delete[$i]");
        $results = ldap_get_entries($connect, $sth);

        $delete=$results[0]["delete"][0];

        if ($delete=="FALSE")
            $info_delete["delete"] = "TRUE";

        elseif ($delete=="TRUE")
	        $info_delete["delete"] = "FALSE";

        if ($info_delete)
            $r=ldap_modify($connect, "vd=$domains_delete[$i], $LDAP_BASE", $info_delete);
    }

    // Only for the Array domains_postmaster the value change
    //
    for ($i=0; $i < count($domains_postmaster); $i++)
    {
        // Search the domain
        $sth = ldap_list($connect,"$LDAP_BASE","vd=$domains_postmaster[$i]");
        $results = ldap_get_entries($connect, $sth);

        $editPostmasters=$results[0]["editpostmasters"][0];

        if ($editPostmasters=="FALSE")
            $info_postmaster["editPostmasters"] = "TRUE";

        elseif ($editPostmasters=="TRUE")
        	$info_postmaster["editPostmasters"] = "FALSE";

        if ($info_postmaster)
            $r=ldap_modify($connect, "vd=$domains_postmaster[$i], $LDAP_BASE", $info_postmaster);
    }


}
?>
