<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Print e-mail e alias list for a domain
// ********************************************************************

function alias_values ($mail)
{
    global $connect;
    global $LDAP_BASE;
    global $td_width;
    global $td_width_box;

    echo $results["count"];

    $filter="(&(mail=$mail)(objectClass=VirtualMailAlias))";

    $search=ldap_search($connect, $LDAP_BASE, $filter);
    $results = ldap_get_entries($connect, $search);

    return $results;
}
?>
