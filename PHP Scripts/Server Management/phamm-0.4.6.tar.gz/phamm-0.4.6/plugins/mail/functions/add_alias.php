<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Add an alias
* 
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* 
* @var string domain
* @var string alias_new
* @var string real_name
* @var string destinations
* @var string password
* @return bolean the result success=1 or insuccess=0
**/

function add_alias ($domain, $alias_new, $real_name, $destinations, $password)
{
    $mail=$alias_new.'@'.$domain;

    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $accountActive;
    global $editAccounts;

    // prepare data
    $info["objectclass"][0]		= "top";

    if ($alias_new != 'postmaster')
    {
        $info["objectclass"][1]		= "VirtualMailAlias";
		// Phamm only
		$info["editAccounts"] = "FALSE";
    }

    elseif ($alias_new == 'postmaster')
    {
		$real_name = 'Postmaster';

 //       $info["objectclass"][1]	= "JammPostmaster";
        $info["objectclass"][1]	= "VirtualMailAlias";
		// Phamm only
		$info["editAccounts"] = "$editAccounts";
    }
    
	if ($alias_new == 'abuse')
    {
		$real_name = 'Abuse';
    }

    $info["mail"]			= "$mail";
    $info["sn"]				= "$real_name";
//    if ($alias_new=='postmaster')
//        $info["roleOccupant"]="cn=postmaster,vd=$domain,$LDAP_BASE";
    $info["lastChange"]		= time();

    $delimitators = array(" ", ";", "\t", "\n", ":");
    $destinations=str_replace($delimitators,",","$destinations");
    $maildrop=explode (",",$destinations);

    for ($i=0; $i < count($maildrop); $i++)
    {
        $info["maildrop"][$i]	= "$maildrop[$i]";
    }

    $info["accountActive"]		= "$accountActive";
	$info["cn"]					= "$real_name";
    if ($password)
        $info["userPassword"]	= password_hash($password);
	$info["creationDate"]	= phamm_date($date_format);

    if ($debug)
        echo ("mail=$mail,vd=$domain,$LDAP_BASE");

    if ($alias_new=='postmaster')
    {
        $r=ldap_add($connect, "cn=postmaster,vd=$domain,$LDAP_BASE",$info);
    }

    else
    {
        $r=ldap_add($connect, "mail=$mail,vd=$domain,$LDAP_BASE",$info);
    }

	if (DEBUG)
		echo var_dump($info);

	return $r;
}
?>
