<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function mail_modify_group ($mail_delete, $mail_active, $virus_check, $spam_check, $editaccounts,$smtpAuth)
{
    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;

	// Only for the Array mail_active the value change
    //
    for ($i=0; $i < count($mail_active); $i++)
    {
        $username_domain = explode("@", $mail_active[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$mail_active[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $accountActive=$results[0]["accountactive"][0];

        if ($accountActive == "FALSE" || !$accountActive)
            $info_active["accountActive"] = "TRUE";

        elseif ($accountActive=="TRUE")
	        $info_active["accountActive"] = "FALSE";

        if ($info_active)
			$r=ldap_modify($connect, "mail=$mail_active[$i],vd=$domain,$LDAP_BASE", $info_active);
    }

	// Only for the Array mail_delete the value change
    //
    for ($i=0; $i < count($mail_delete); $i++)
    {
        $username_domain = explode("@", $mail_delete[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$mail_delete[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $delete=$results[0]["delete"][0];

        if ($delete == "FALSE")
            $info_delete["delete"] = "TRUE";

        elseif ($delete == "TRUE")
	        $info_delete["delete"] = "FALSE";

        if ($info_delete)
			$r=ldap_modify($connect, "mail=$mail_delete[$i],vd=$domain,$LDAP_BASE", $info_delete);
    }
	
    // Only for the Array virus_check
    //
    for ($i=0; $i < count($virus_check); $i++)
    {
        $username_domain = explode("@", $virus_check[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$virus_check[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $check=$results[0]["amavisbypassviruschecks"][0];

        if ($check == "FALSE" || !$check)
            $info_check["amavisBypassVirusChecks"] = "TRUE";

        elseif ($check == "TRUE")
	        $info_check["amavisBypassVirusChecks"] = "FALSE";

        if ($info_check)
			$r=ldap_modify($connect, "mail=$virus_check[$i],vd=$domain,$LDAP_BASE", $info_check);
    }



// Only for the Array spam_check
    //
    for ($i=0; $i < count($spam_check); $i++)
    {
        $username_domain = explode("@", $spam_check[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$spam_check[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $check=$results[0]["amavisbypassspamchecks"][0];

        if ($check == "FALSE" || !$check)
            $info_check["amavisBypassSpamChecks"] = "TRUE";

        elseif ($check=="TRUE")
	        $info_check["amavisBypassSpamChecks"] = "FALSE";

        if ($info_check)
			$r=ldap_modify($connect, "mail=$spam_check[$i],vd=$domain,$LDAP_BASE", $info_check);
    }
	
	// SMTP
    for ($i=0; $i < count($smtpAuth); $i++)
    {
        $username_domain = explode("@", $smtpAuth[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$smtpAuth[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $check = $results[0]["smtpauth"][0];

        if ($check == "FALSE" || !$check)
            $info_check["smtpauth"] = "TRUE";

        elseif ($check == "TRUE")
	        $info_check["smtpauth"] = "FALSE";

        if ($info_check)
			$r = ldap_modify($connect, "mail=$smtpAuth[$i],vd=$domain,$LDAP_BASE", $info_check);

    }

// Only for the Array editaccounts
    //

// Only for the Array editaccounts
    //
    for ($i=0; $i < count($editaccounts); $i++)
    {
        $username_domain = explode("@", $editaccounts[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$editaccounts[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $edit=$results[0]["editaccounts"][0];

        if ($edit == "FALSE" || !$edit)
            $info_editaccounts["editaccounts"] = "TRUE";

        elseif ($edit == "TRUE")
	        $info_editaccounts["editaccounts"] = "FALSE";

        if ($info_editaccounts)
			$r=ldap_modify($connect, "mail=$editaccounts[$i],vd=$domain,$LDAP_BASE", $info_editaccounts);
    }

}
?>
