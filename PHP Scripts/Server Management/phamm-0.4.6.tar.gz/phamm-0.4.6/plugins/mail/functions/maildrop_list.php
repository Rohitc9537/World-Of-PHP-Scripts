<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print e-mail e alias list for a domain
*
* @package functions
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* @param $alias The alias
* @return mixed
**/

function maildrop_list ($alias)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;

    $filter="(&(mail=$alias)(objectClass=VirtualMailAlias)(!(maildrop=postmaster)))";

    $search=ldap_search($connect, $LDAP_BASE, $filter);
    $results = ldap_get_entries($connect, $search);

    $n_maildrop = count($results[0]["maildrop"]);

    for ($idx=0; $idx < $n_maildrop; $idx++)
    {
        $maildrop=$results[0]["maildrop"][$idx];

        echo ("<TR><TD>");
        if ($maildrop && $idx==0)
            echo $lang["delete_destinations"];
        echo ("</TD><TD>");
        if ($maildrop)
            echo ("<INPUT type='checkbox'
                  name=\"destinations_del[]\" value=\"$maildrop\" $checked>");
        echo (" $maildrop</TD>");
        echo ("</TR>\n");
    }
}
?>
