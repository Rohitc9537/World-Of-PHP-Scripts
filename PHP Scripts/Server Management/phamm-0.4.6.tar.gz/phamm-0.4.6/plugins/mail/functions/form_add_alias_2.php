<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function form_add_alias_2 ($domain, $alias_new)
{
global $lang;
global $real_name;
// global $destinations;
global $action;

?>

<SCRIPT language="javascript">
function sf(){document.add.real_name.focus();}
</SCRIPT>

<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="action" value="<?php echo $action; ?>">
<INPUT type="hidden" name="step" value="2">
<INPUT type="hidden" name="domain" value="<?php echo $domain; ?>">
<?php
if ($_GET["catch_all"])
{
	echo "<INPUT type=\"hidden\" name=\"real_name\" value=\"Catch All\">\n";
	echo "<INPUT type=\"hidden\" name=\"catch_all\" value=\"1\">\n";
	echo "<FONT class=\"message\">".$lang["edit"]." ".$lang["catch_all"]."</FONT>";
}
?>
<INPUT type="hidden" name="alias_new" value="<?php echo $alias_new; ?>">
<TABLE class="data">
<?php
if (!$_GET["catch_all"])
{
?>
<TR><TD><?php echo $lang["email"]; ?></TD>
<TD><?php
echo $alias_new;
if ($action == 'add_alias')
	echo '@'.$domain;
?></TD></TR>
<TR><TD><?php echo $lang["real_name"]; ?></TD>
<TD><INPUT type="text" name="real_name" value="<?php echo stripslashes($real_name); ?>"></TD></TR>
<TR><TD><?php echo $lang["password"]; ?></TD>
<TD><INPUT type="password" name="password1" value=""></TD></TR>
<TR><TD><?php echo $lang["repeat_password"]; ?></TD>
<TD><INPUT type="password" name="password2" value=""></TD></TR>
<?php
}
?>
<TR><TD><?php echo $lang["add_destinations"]; ?></TD>
<TD><TEXTAREA name="destinations" class="textarea" rows="3"
 cols="50" wrap="hard"></TEXTAREA></TD></TR>
<?php

maildrop_list ($alias_new);

echo ("</TABLE>");

echo ("<INPUT type=\"submit\" value=\"$lang[$action]\">");

?>
</FORM>

<?php
}
?>
