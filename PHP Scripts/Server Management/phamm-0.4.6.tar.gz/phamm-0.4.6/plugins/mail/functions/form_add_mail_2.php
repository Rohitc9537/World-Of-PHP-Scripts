<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function form_add_mail_2 ($domain, $mail_new)
{
global $lang;
global $real_name;
global $quota;
global $action;
global $vacation;
global $amavis;
global $phamm;
global $spamKillLevels;
global $spamTagLevels;
global $spamTag2Levels;

?>

<SCRIPT language="javascript">
function sf(){document.add.real_name.focus();}
</SCRIPT>

<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="action" value="<?php echo $action; ?>">
<INPUT type="hidden" name="step" value="2">
<INPUT type="hidden" name="domain" value="<?php echo $domain; ?>">
<INPUT type="hidden" name="mail_new" value="<?php echo $mail_new; ?>">

<TABLE class="data">
<TR><TD><?php echo $lang["email"]; ?></TD>
<TD><?php
echo $mail_new;
if ($action=='add_mail')
	echo '@'.$domain;
?></TD></TR>
<TR><TD><?php echo $lang["quota"]; ?></TD>
<TD>

<?php
if ($_SESSION['username'] == 'postmaster' || $_SESSION['username'] == ADMINCN)
	echo ("<INPUT type=\"text\" name=\"quota\" value=\"$quota\" size=\"3\" maxlength=\"4\">");
else
	echo $quota;
?>
 Mb</TD></TR>
<TR><TD><?php echo $lang["real_name"]; ?></TD>
<TD><INPUT type="text" name="real_name" value="<?php echo stripslashes($real_name); ?>"></TD></TR>
<TR><TD><?php echo $lang["random"]; ?></TD>
<TD><INPUT type="checkbox" name="randompw" value="1">
<?php echo "Random ".$lang["password"]; ?></TD></TR>
<TR><TD><?php echo $lang["password"]; ?></TD>
<TD><INPUT type="password" name="password1" value=""></TD></TR>
<TR><TD><?php echo $lang["repeat_password"]; ?></TD>
<TD><INPUT type="password" name="password2" value=""></TD></TR>
<?php
	// Forward
	echo ("<TR><TD>".$lang["forward"]."</TD>");
	echo ("<TD>");
	if ($phamm["forwardactive"] == "TRUE")
	{
		echo ("<input type=\"checkbox\" name=\"phamm[forwardactive]\"
		value=\"FALSE\">".$lang["check_to_deactivate"]."");
	}
	if (!$phamm["forwardactive"] || $phamm["forwardactive"] == "FALSE")
	{
		echo ("<input type=\"checkbox\" name=\"phamm[forwardactive]\"
		value=\"TRUE\">".$lang["check_to_activate"]."");
	}
	echo ("</TD></TR>");
	
	// Forward Options
	if ($phamm["forwardactive"] == "TRUE")
	{
		echo ("<TR><TD>".$lang["virtualforward"]."</TD><TD>
		<INPUT type=\"text\" name=\"phamm[maildrop]\" size=\"50\"
		value=\"".$phamm["maildrop"]."\"></TD></TR>");
	}

if (USE_VACATION)
{
	// Ratio Vacation
	echo ("<TR><TD>".$lang["vacation"]."</TD>");
	echo ("<TD>");
	if ($vacation["active"] == "TRUE")
	{
		echo ("<input type=\"checkbox\" name=\"vacation[active]\"
		value=\"FALSE\">".$lang["check_to_deactivate"]."");
	}
	if (!$vacation["active"] || $vacation["active"] == "FALSE")
	{
		echo ("<input type=\"checkbox\" name=\"vacation[active]\"
		value=\"TRUE\">".$lang["check_to_activate"]."");
	}
	echo ("</TD></TR>");

	// Vacation Options
	if ($vacation["active"] == "TRUE")
	{
	echo ("<TR><TD>".$lang["vacation_description"]."</TD><TD>
	<INPUT type=\"text\" name=\"vacation[description]\" size=\"50\"
	value=\"".$vacation["description"]."\"></TD></TR>");
	echo ("<TR><TD>".$lang["vacation_info"]."</TD><TD>
	<TEXTAREA name=\"vacation[info]\" class=\"textarea\" rows=\"2\"
 cols=\"50\" wrap=\"hard\">".$vacation["info"]."</TEXTAREA></TD></TR>");
	echo ("<TR><TD>".$lang["vacation_start"]."</TD>
<TD><INPUT type=\"text\" name=\"vacation[start]\" value=\"".$vacation["start"]."\"></TD></TR>");
	echo ("<TR><TD>".$lang["vacation_end"]."</TD>
<TD><INPUT type=\"text\" name=\"vacation[end]\" value=\"".$vacation["end"]."\"></TD></TR>");
	echo ("<TR><TD>".$lang["vacation_forward"]."</TD>
<TD><INPUT type=\"text\" name=\"vacation[forward]\" value=\"".$vacation["forward"]."\"></TD></TR>");
	}
}

if (USE_AMAVIS)
{
	// Radio Virus Check
	echo ("<TR><TD>".$lang["virus_check"]."</TD>");
	echo ("<TD>");
	if ($amavis["amavisbypassviruschecks"] == "FALSE")
	echo ("
	<input type=\"checkbox\" name=\"amavis[amavisbypassviruschecks]\" value=\"TRUE\">".$lang["check_to_deactivate"]."");
	if (!$amavis["amavisbypassviruschecks"] || $amavis["amavisbypassviruschecks"] == "TRUE")
	echo ("<input type=\"checkbox\" name=\"amavis[amavisbypassviruschecks]\" value=\"FALSE\">".$lang["check_to_activate"]."");
	echo ("</TD></TR>");
	
	// Radio Spam Check
	echo ("<TR><TD>".$lang["spam_check"]."</TD>");
	echo ("<TD>");
	if ($amavis["amavisbypassspamchecks"] == "FALSE")
	echo ("
	<input type=\"checkbox\" name=\"amavis[amavisbypassspamchecks]\" value=\"TRUE\">".$lang["check_to_deactivate"]."");
	if (!$amavis["amavisbypassspamchecks"] || $amavis["amavisbypassspamchecks"] == "TRUE")
	echo ("<input type=\"checkbox\" name=\"amavis[amavisbypassspamchecks]\" value=\"FALSE\">".$lang["check_to_activate"]."");
	echo ("</TD></TR>");

	// Simple Spam Options
	if ($amavis["amavisbypassspamchecks"] == "FALSE")
	{
	
	echo ("<TR><TD>".$lang["spamkilllevel"]."</TD>
	<TD><SELECT name=\"amavis[amavisspamkilllevel]\">");
	scale_level($spamKillLevels,$amavis["amavisspamkilllevel"]);
	echo ("</SELECT></TD></TR>");
	}

	// Full Spam Options
	if ($amavis["amavisbypassspamchecks"] == "FALSE" && $_SESSION['login'] == ADMINCN)
	{
	echo ("<TR><TD>".$lang["spamtaglevel"]."</TD>
<TD><SELECT name=\"amavis[amavisspamtaglevel]\">");
	scale_level($spamTagLevels,$amavis["amavisspamtaglevel"]);
echo ("</SELECT></TD></TR>");

	echo ("<TR><TD>".$lang["spamtag2level"]."</TD>
<TD><SELECT name=\"amavis[amavisspamtag2level]\">");
	scale_level($spamTag2Levels,$amavis["amavisspamtag2level"]);
echo ("</SELECT></TD></TR>");

	}
}

?>

</TABLE>
<?php echo ("<INPUT type=\"submit\" value=\"".$lang["$action"]."\">"); ?>
</FORM>

<?php
}
?>
