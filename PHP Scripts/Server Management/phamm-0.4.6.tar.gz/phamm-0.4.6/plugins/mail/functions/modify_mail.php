<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function modify_mail ($mail, $domain, $real_name, $quota, $password1, $vacation, $amavis, $phamm)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;
    global $spamTagLevels;
    global $spamTag2Levels;
    global $spamKillLevels;

    $quota = $quota*$multi*$multi;

    // prepare data
    $info["lastChange"]		= time();
    if ($real_name)
        $info["cn"]			= "$real_name";
    if ($quota)
        $info["quota"]			= "$quota";
    if ($password1)
		$info["userPassword"]	= password_hash($password1);

    // Vacation attributes
    if ($vacation["active"])
        $info["vacationActive"]		= $vacation["active"];
    if ($vacation["info"])
        $info["vacationInfo"]		= $vacation["info"];
    if ($vacation["start"])
        $info["vacationStart"]		= $vacation["start"];
    if ($vacation["end"])
        $info["vacationEnd"]		= $vacation["end"];
    if ($vacation["forward"])
        $info["vacationForward"]	= $vacation["forward"];
    if ($vacation["description"])
        $info["description"]		= $vacation["description"];

    // Amavis attributes
    if ($amavis["amavisbypassviruschecks"])
        $info["amavisBypassVirusChecks"] = $amavis["amavisbypassviruschecks"];
    if ($amavis["amavisbypassspamchecks"])
        $info["amavisBypassSpamChecks"] = $amavis["amavisbypassspamchecks"];
    if ($amavis["amavisspamkilllevel"])
        $info["amavisSpamKillLevel"] = $amavis["amavisspamkilllevel"];

	// Phamm attributes
    if ($phamm["forwardactive"])
        $info["forwardActive"] = $phamm["forwardactive"];
    if ($phamm["maildrop"])
        $info["maildrop"] = $phamm["maildrop"];

    if ($_SESSION['login'] == ADMINCN && USE_AMAVIS == 1)
    {
        if ($amavis["amavisspamtag2level"])
            $info["amavisSpamTag2Level"] = $amavis["amavisspamtag2level"];
        if ($amavis["amavisspamtaglevel"])
            $info["amavisSpamTagLevel"]		= $amavis["amavisspamtaglevel"];
    }

    elseif ($_SESSION['login'] != ADMINCN && USE_AMAVIS == 1)
    {
		// Value Reference
		$refValue = $amavis["amavisspamkilllevel"];
		$level = $spamKillLevels["$refValue"];
		
		// 
		$info["amavisSpamTagLevel"] = array_search($level,$spamTagLevels);
		$info["amavisSpamTag2Level"] = array_search($level,$spamTag2Levels);
    }

    $r = ldap_modify($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info);

    return $r;
}

?>
