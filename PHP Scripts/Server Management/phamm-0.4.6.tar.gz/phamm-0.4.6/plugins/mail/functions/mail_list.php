<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @subpackage accessories
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Print e-mail e alias list for a domain
// ********************************************************************

function mail_list ($domain)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
    global $td_width;
    global $td_width_box;
	global $initial;
	global $AccountDataView;
	
	$AccountDataView_nr = (count($AccountDataView));

	if (!$initial && DEFAULT_VIEW == 'none')
		$initial = '.oOo.';
		
    if ($initial == 'ALL')
        $initial = '';

    $filter="(&(mail=$initial*@$domain)(objectClass=VirtualMailAccount))";

    $search=ldap_search($connect, $LDAP_BASE, $filter);

	// Order the results
	if (version_compare(phpversion(), "4.2.0", ">="))
		ldap_sort($connect, $search,"mail");

    $results = ldap_get_entries($connect, $search);

	// Free the memory
	ldap_free_result($search);

    $tr_header = "<TR class='header'>
                  <TD></TD>
                  <TD width=\"$td_width\">$results[count] $lang[accounts]</TD>
				  ";
				  
	if ($AccountDataView_nr > 0)
		$tr_header .= "<TD colspan=\"$AccountDataView_nr\"></TD>";
	
    $tr_header .= "<TD width=\"$td_width_box\">$lang[quota]</TD>
                  <TD width=\"$td_width_box\">$lang[account_is_active]</TD>
                  \n";
	
	if (USE_AMAVIS)
	{
		$tr_header .= ("<TD width=\"$td_width_box\">$lang[virus_check]</TD>");
		$tr_header .= ("<TD width=\"$td_width_box\">$lang[spam_check]</TD>");
	}
		$tr_header .= ("<TD width=\"$td_width_box\">$lang[smtpAuth]</TD>");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>");
    echo ("<INPUT type='hidden' name='action' value='mail_modify_group'>");
    echo ("<INPUT type='hidden' name='domain' value=\"$domain\">");

    echo ("<TABLE class='data'>\n");
    echo $tr_header;
    for ($idx=0; $idx < $results["count"]; $idx++)
    {
        $mail=$results[$idx]["mail"][0];
        $quota=$results[$idx]["quota"][0];
	    $delete=$results[$idx]["delete"][0];
	    $active=$results[$idx]["accountactive"][0];
		$virus_check = $results[$idx]["amavisbypassviruschecks"][0];
		$spam_check = $results[$idx]["amavisbypassspamchecks"][0];
		$smtpAuth = $results[$idx]["smtpauth"][0];
		
		// Prevent empty value
		if (!$smtpAuth)
			$smtpAuth = 'FALSE';
        if (!$delete)
			$delete = 'FALSE';
		if (!$active)	
			$active = 'FALSE';
		if (!$virus_check)
			$virus_check = 'FALSE';
		
		$spam_check = 'FALSE';

        $quotaf=quota_formatting($quota);

        echo ("<TR class=\"data\">");
        true_false_box ($delete, $mail,'mail_delete','mail_modify_group',0);
        echo ("<TD><A href=\"?domain=$domain&mail=$mail&action=modify_mail\">$mail</A></TD>");


		// Print costum attribute recursiv...
		for ($kdx=0; $kdx < count($AccountDataView); $kdx++)
	    {
			$attr = $AccountDataView[$kdx];
			
			echo "<TD>";
			
				for ($ldx=0; $ldx < count($results[$idx][$attr]); $ldx++)
				{
					if (isset($results[$idx]["$attr"][$ldx]))
	      				echo stripslashes($results[$idx]["$attr"][$ldx]);
					echo "<BR>";
				}
				
			echo "</TD>";
		}

		
        echo ("<TD>$quotaf</TD>");
        true_false_box ($active, $mail,'mail_active','mail_modify_group',0);
		
		if (USE_AMAVIS)
		{
	        true_false_box ($virus_check, $mail,'virus_check','mail_modify_group',1);
    	    true_false_box ($spam_check, $mail,'spam_check','mail_modify_group',1);
		}
    	    true_false_box ($smtpAuth, $mail,'smtpAuth','mail_modify_group',0);
		
        echo ("</TR>\n");
    }

	echo ("<TR class='footer'><TD></TD><TD>");
    form_modify('modify_mails');
    echo ("</TD><TD colspan=\"\"></TD></TR>");

    echo ("</TABLE>\n");
	
    if ($initial == '')
        $initial = 'ALL';
}
?>
