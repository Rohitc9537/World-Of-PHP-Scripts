<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage mail
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// MTA Settings (Postfix...)
$vmail_path		= '/home/vmail';	// without final /
define(TRANSPORT,'virtual');		// virtual or maildrop
define(OTHER_TRANSPORT,'phamm');	// vacation and vacation forward related

// Quota Settings
$multi			= '1024';		// byte in kB, kB in MB...
$is_quota				= '1';	// Quota is required 1,0
if ($is_quota)
    $quota_default		= '10';	// Default quota in Mb



// Default attribute Settings
define(EDIT_ACCOUNTS,0);
define(EDIT_ALIASES,1);
$editAccounts			= 'TRUE'; // Postmaster can add Account and Alias
//$editAliases			= 'TRUE'; // *unused*
$editPostmasters		= 'TRUE';
$accountActive			= 'TRUE';

// Welcome message Settings and template
define (SEND_WELCOME,0);
$welcome_msg			= '../plugins/mail/welcome_message.txt';
$welcome_subject		= 'Welcome!';
$welcome_sender			= '<root@localhost>';
$welcome_bcc			= '<root@localhost>';

// Vacation Settings
define (USE_VACATION, 1);

// *** Amavis Settings ***
// if unused change the the constant USE_AMAVIS -> 0
// and leave other values unchanged
define (USE_AMAVIS, 1);
$amavisBypassVirusChecks = "FALSE";
$amavisBypassSpamChecks = "FALSE";
$amavisSpamTagLevel = "3.0";
$amavisSpamTag2Level = "5.5";
$amavisSpamKillLevel = "6.0";
$editAV = "TRUE";

$spamTagLevels = array(
	"7.0" => 'low',
	"3.0" => 'medium',
//	"2.5" => '',
	"1.5" => 'high',
	"0.0" => 'very_high'
);

$spamTag2Levels = array(
	"9.5" => 'low',
	"5.5" => 'medium',
//	"5.0" => '',
	"4.0" => 'high',
	"2.5" => 'very_high'
);

$spamKillLevels = array(
	"10.0" => 'low',
	"6.0" => 'medium',
//	"5.5" => '',
	"4.5" => 'high',
	"3.0" => 'very_high'
);

// Optional Attributes
$AccountDataView = array();
$AccountDataView[] = 'cn';
// $AccountDataView[] = 'creationdate';

?>
