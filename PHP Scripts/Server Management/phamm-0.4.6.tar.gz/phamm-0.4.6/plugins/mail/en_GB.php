<?php

$lang["sasl"] = 'SASL';
$lang["smtpAuth"] = 'SMTP';

?>
