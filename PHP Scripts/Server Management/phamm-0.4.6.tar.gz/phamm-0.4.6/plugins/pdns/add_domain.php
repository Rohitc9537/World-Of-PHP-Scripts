<?php
// Special file call from Phamm when a new domain added
	require ('../plugins/pdns/functions.php');
					
	$do = add_domain_pdns($domain_new,$aRecordDefault,$zoneDefault,$zoneDefault_cName,$mXRecordDefault);
	
if ($do==1)
	print_message ('success',$lang["domain"]." $domain_new ".$lang["added"]);
else
	print_message ('error',$lang["domain"]." $domain_new ".$lang["not_added"]);

?>
