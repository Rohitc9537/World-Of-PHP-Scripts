<?php

// PDNS Plugin
$lang["add_zone"]		= 'Add Zone';
$lang["dns_only"]		= 'DNS Only';
$lang["or"]				= 'or';
$lang["a_record"]		= 'A Record (IP)';
$lang["c_name_record"]	= 'cNAME (address)';
$lang["modified"]	= 'Modified';
$lang["not_modified"]	= 'Not Modified';
$lang["nsrecord"]		= 'NS';
$lang["arecord"]		= 'A';
$lang["mxrecord"]		= 'MX';
$lang["pdns_domain_dont_exists"]	= 'PDNS domain don\'t exists';
$lang["new_mx"]			= 'New MX';
$lang["new_dns"]		= 'New DNS';


?>
