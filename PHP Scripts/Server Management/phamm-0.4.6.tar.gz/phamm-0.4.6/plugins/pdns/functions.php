<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage pdns
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

/**
* Get the IP (arecord) of an MX record
**/

function getMXIP ($dc)
{
    global $domain;
    global $DNS_LDAP_BASE;
    global $connect;

    $domain2 = explode (".",$domain);

    if (DNS_DN_MODE == 'full')
    {
        $filter = "(dc=$domain2[0])";
        $search = ldap_search($connect, "dc=$domain2[1],$DNS_LDAP_BASE",$filter);
    }

    else
    {
//        $filter = "(dc=$dc)";
  //      $search = ldap_search($connect, "dc=$domain,$DNS_LDAP_BASE",$filter)
  			$filter = "(dc=$domain)";
        $search = ldap_search($connect, "$DNS_LDAP_BASE",$filter);
    }

    $results = ldap_get_entries($connect, $search);

    ldap_free_result($search);

    // Return the results
    return $results[0]["arecord"][0];
}

/**
* Print the info zone of a domain
**/

function dnsZone ($domain)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;
    global $td_width;
    global $td_width_box;

    $domain2 = explode (".",$domain);

    if (DNS_DN_MODE == 'full')
    {
     //   $filter="(&(dc=*)(!(dc=$domain2[0]))(!(dc=mail*)))";
        $filter="(&(dc=*)(!(dc=$domain2[0])))";
        $search = ldap_search($connect, "dc=$domain2[1],$DNS_LDAP_BASE",$filter);
    }

    else
    {
        $filter="(&(dc=*)(!(dc=$domain)))";
		$search=ldap_search($connect, "dc=$domain,$DNS_LDAP_BASE", $filter);
    }

    // Order the results
    if (version_compare(phpversion(), "4.2.0", ">="))
        ldap_sort($connect, $search,"mail");

    $results = ldap_get_entries($connect, $search);

    // Free the memory
    ldap_free_result($search);

    $tr_header = ("<TR class='header'>
                  <TD></TD>
                  <TD width=\"$td_width_box\">dc</TD>
                  <TD width=\"$td_width_box\">aRecord<BR>
				  <FONT class=\"note\">(blank means cNAMERecord)</FONT></TD>
                  <TD width=\"$td_width_box\">cNAMERecord</TD></TR>");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>");
    echo ("<INPUT type='hidden' name='action' value='addZone'>");
    echo ("<INPUT type='hidden' name='domain' value=\"$domain\">");

    echo ("<TABLE class='data'>\n");
    echo $tr_header;
	
	echo ("<TR>");
    echo ("<TD></TD>");
	echo ("<TD>");
	echo ("<INPUT type=\"text\" size=\"15\" maxlength=\"25\"
              name=\"dc\" value=\"".$_POST["dc"]."\">");
	echo ("</TD><TD>");
	echo ("<INPUT type=\"text\" size=\"15\" maxlength=\"15\"
              name=\"aRecord\" value=\"".$_POST["aRecord"]."\">");
	echo ("</TD><TD>");
	cname_domain($domain);
	echo "<INPUT type=\"submit\" value=\"".$lang["add_zone"]."\">";
	echo "</FORM>";
	echo ("</TD>");
	echo ("</TR>");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>");
    echo ("<INPUT type='hidden' name='action' value='delZone'>");
    echo ("<INPUT type='hidden' name='domain' value=\"$domain\">");
	
    for ($idx=0; $idx < $results["count"]; $idx++)
    {
        $dc = $results[$idx]["dc"][0];
        $aRecord = $results[$idx]["arecord"][0];
        $cNAMERecord = $results[$idx]["cnamerecord"][0];

        echo ("<TR>");
        echo ("<TD><INPUT type=\"checkbox\"
		name=\"dns_zone_delete[]\" value=\"$dc\"></TD>");
        echo ("<TD><B>$dc</B></TD>");
        echo ("<TD>$aRecord</TD>");
        echo ("<TD>$cNAMERecord</TD>");
        echo ("</TR>\n");
    }

    echo ("<TR class='data'><TD></TD><TD>");
	echo "<INPUT type=\"submit\" value=\"".$lang["delete"]."\">";
	echo "</TD><TR";
	
	echo "</FORM>";


    echo ("</TABLE>\n");
}

/**
* Print a DNS info of a domain
*
* @param string $domain The domain
**/

function dnsDomain ($domain)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;
    global $td_width;
    global $td_width_box;

    $domain2 = explode (".",$domain);

    if (DNS_DN_MODE == 'full')
    {
        $filter = "(dc=$domain2[0])";
        $search = ldap_search($connect, "dc=$domain2[1],$DNS_LDAP_BASE",$filter);
    }

    else
    {
        $filter="(dc=$domain)";
 //       $search=ldap_search($connect, "dc=$domain,$DNS_LDAP_BASE",$filter);
        $search=ldap_search($connect, "$DNS_LDAP_BASE",$filter);
    }

    // Order the results
    if (version_compare(phpversion(), "4.2.0", ">="))
        ldap_sort($connect, $search,"mail");

    $results = ldap_get_entries($connect, $search);
	
	if ($results["count"] > 0)
	{

    $dc = $results[0]["dc"][0];
    $aRecord = $results[0]["arecord"];
    $cNAMERecord = $results[0]["cnamerecord"][0];
    $mXRecord = $results[0]["mxrecord"];
    $nSRecord = $results[0]["nsrecord"];

    $sOARecord = $results[0]["soarecord"];
	$SERIAL = explode(" ",$sOARecord[0]);

    // Free the memory
    ldap_free_result($search);

	//echo "<H1>".$domain2[0].".".$domain2[1]."</H1>";

    $tr_header = ("<TR class='header'>
                  <TD width=\"$td_width_box\"></TD>
                  <TD width=\"$td_width_box\">".$lang["values"]."</TD></TR>");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>\n");
    echo ("<INPUT type='hidden' name='action' value='dns_modify'>\n");
    echo ("<INPUT type='hidden' name='domain' value=\"$domain\">\n");
    echo ("<INPUT type='hidden' name='oldserial' value=\"".$SERIAL["2"]."\">\n");

    echo ("<TABLE class='data'>\n");

    echo $tr_header;

    // Print all aRecords
    for ($idx=0; $idx < $aRecord["count"]; $idx++)
    {
        echo ("<TR><TD>aRecord</TD><TD>");
        echo ("<INPUT type=\"text\" size=\"15\" maxlength=\"15\"
              name=\"aRecord[]\" value=\"".$results[0]["arecord"][$idx]."\">");
        echo ("</TD></TR>");
    }

	if ($aRecord["count"] == 0)
	{
        echo ("<TR><TD>aRecord</TD><TD>");
        echo ("<INPUT type=\"text\" size=\"15\" maxlength=\"15\"
              name=\"aRecord[]\" value=\"\">");
        echo ("</TD></TR>");
	}

    // Print all MX Records + 1 blank
    for ($idx=0; $idx < ($mXRecord["count"]+1); $idx++)
    {
        $mx = explode (" ",$results[0]["mxrecord"][$idx]);
        $mxX = explode (".",$mx[1]);
        $mxIP = getMXIP ($mxX[0]);


        if ($idx == $mXRecord["count"])
            echo "<TR><TD><B>".$lang["new_mx"]." -></TD><TD>";
        else
            echo ("<TR><TD>MX</TD><TD>");
			
        echo ("<INPUT type=\"text\" size=\"2\" maxlength=\"2\"");
        if ($idx == $mXRecord["count"])
            echo " class=\"add\" ";
       echo ("name=\"mxP[]\" value=\"".$mx[0]."\">");

       echo ("<INPUT type=\"text\" size=\"25\" maxlength=\"50\"");
        if ($idx == $mXRecord["count"])
            echo " class=\"add\" ";
       echo ("name=\"mxA[]\" value=\"".$mx[1]."\">");
	   
/*       echo ("<INPUT type=\"text\" size=\"15\" maxlength=\"15\"");
        if ($idx == $mXRecord["count"])
            echo " class=\"add\" ";
        echo ("name=\"mxIP[]\" value=\"".$mxIP."\">"); */
		
        echo ("</TD></TR>");
    }

    // Print all nSRecords + 1 blank
    for ($idx=0; $idx < ($nSRecord["count"]+1); $idx++)
    {
        if ($idx == $nSRecord["count"])
            echo "<TR><TD><B>".$lang["new_dns"]." -></B></TD><TD>";
        else
            echo ("<TR><TD>DNS</TD><TD>");
        echo ("<INPUT type=\"text\" size=\"25\" maxlength=\"50\"");
        if ($idx == $nSRecord["count"])
            echo " class=\"add\" ";
        echo ("name=\"nSRecord[]\" value=\"".$results[0]["nsrecord"][$idx]."\">");
        echo ("</TD></TR>");
    }


    // Print all sOARecords
    for ($idx=0; $idx < $sOARecord["count"]; $idx++)
    {
        echo ("<TR><TD>SOA</TD><TD>");
//      echo ("<INPUT type=\"text\" size=\"50\" maxlength=\"50\"
//              value=\"".$results[0]["soarecord"][$idx]."\">");
              echo $results[0]["soarecord"][$idx];
        echo ("</TD></TR>");
    }
    echo ("</TR>\n");

    echo ("</TABLE>\n");

	echo "<INPUT type=\"submit\" value=\"".$lang["modify"]."\">";
	echo "</FORM>";
	}
	
	return $results["count"];
}

/**
* Set a new SERIAL
*
* @param string $oldserial The old SOA Record
**/

function setSerial ($oldserial)
{
	$olddate = substr($oldserial,0,8);
	$oldsequence = substr($oldserial,8,2);

	if ($olddate == date(Ymd))
	{
		$sequence = ($oldsequence + 1);

		if (strlen($sequence) == 1)
			$sequence = (string)('0'.$sequence);
	}
	
	else
	{
		$sequence = '00';
	}
	
	// Prepare serial in format AAAAMMGG+NN
	$SERIAL = (int)(date(Ymd).$sequence);

	// If the new SERIAL...
	if ((int)$SERIAL <= (int)$oldserial)
	{	
		(int)$SERIAL = ($oldserial + 1);
	}

	return $SERIAL;
}


/**
* Modify the DNS attribute values
*
* @param string $domain
* @param array $aRecord
* @param array $nSRecord
* @param array $mxP
* @param array $mxA
* @param array $mxIP
* @param string $oldserial The old SOA Record
**/

function dnsModify ($domain,$aRecord,$nSRecord,$mxP,$mxA,$mxIP,$oldserial)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;

	$SERIAL = setSerial ($oldserial);
	
    for ($idx=0; $idx < count($aRecord); $idx++)
    {
        if ($aRecord[$idx] != "")
            $info["aRecord"][] = $aRecord[$idx];
    }

    for ($idx=0; $idx < count($nSRecord); $idx++)
    {
        if ($nSRecord[$idx] != "")
            $info["nSRecord"][] = $nSRecord[$idx];
    }

    for ($idx=0; $idx < count($mxA); $idx++)
    {
        if ($mxA[$idx] != "" && $mxP[$idx] != "")
            $info["mXRecord"][] = $mxP[$idx]." ".$mxA[$idx];

	// Add the zone if not exist and if same domain
	//	$mxDc = explode (".",$mxA);
	//	echo "$domain == $mxDc[1].'.'.$mxDc[2]";
	//		addZone ($domain,$mxDc[0],$mxIP,$mxDc[0].".".$domain);
    }

	if (DEBUG)
    	echo var_dump($info);

	// Create a new SOA Record
	$info["sOARecord"][] = $nSRecord[0].". root.".$nSRecord[0].". ".$SERIAL." ".ZONE_REFRESH." ".ZONE_RETRY." ".ZONE_EXPIRE." ".ZONE_MINIMUM;

    $r = ldap_modify($connect, "dc=$domain,$DNS_LDAP_BASE", $info);

    return $r;
}

/**
* Add a DNS zona
**/

function addZone ($domain,$dc,$aRecord,$cNAMERecord)
{
    global $DNS_LDAP_BASE;
    global $connect;

    $domain2 = explode (".",$domain);
	
	$info["objectclass"][]		= "top";
	$info["objectclass"][]		= "dnsdomain";
    $info["objectclass"][]		= "domainrelatedobject";
	
	$info["dc"] = "$dc";
	
	if ($aRecord)
		$info["arecord"] = "$aRecord";
	else
		$info["cNAMERecord"] = $cNAMERecord;
		
	$info["associateddomain"] = $dc.".".$domain;

    if (DNS_DN_MODE == 'full')
    {
	    $r=ldap_add($connect, "dc=$dc,dc=$domain2[0],dc=$domain2[1],$DNS_LDAP_BASE", $info);
	}
	
    else
    {
		if (DEBUG)
		    echo "dc=$dc,dc=$domain,$DNS_LDAP_BASE";
			
    	$r = ldap_add($connect, "dc=$dc,dc=$domain,$DNS_LDAP_BASE", $info);
	}

	return $r;
}


/**
* Insert new DNS domain zone
*
* @param domain_new string The domain (example.tpl)
* @return bool
**/

function add_domain_pdns($domain_new,$aRecordDefault,$zoneDefault,$zoneDefault_cName,$mXRecordDefault)
{
	global $DNS_LDAP_BASE;
	global $connect;


// Prepare serial in format AAAAMMGGHHMM
$SERIAL = date(YmdHi);
//$SERIAL = time();

  // Prepare the data
  $dn = "dc=$domain_new,$DNS_LDAP_BASE";

  $data["objectClass"][] = "top";
  $data["objectClass"][] = "dnsdomain2";
  $data["objectClass"][] = "domainrelatedobject";
  $data["dc"][] = $domain_new;
  $data["associatedDomain"][] = $domain_new;
  $data["sOARecord"][] = NS1.". root.".NS1.". ".$SERIAL." ".ZONE_REFRESH." ".ZONE_RETRY." ".ZONE_EXPIRE." ".ZONE_MINIMUM;
  $data["nSRecord"][] = NS1;
  $data["nSRecord"][] = NS2;
  $data["aRecord"][] = $aRecordDefault;

	for ($x=0; $x < count($mXRecordDefault); $x++)
	{
		$ppp = ($x + 1)*PREFERENCE;
		$data["mXRecord"][] = $ppp." ".$mXRecordDefault[$x];
	}
  
	if (DEBUG)
	{
		echo $dn;
		var_dump ($data);
	}
  
	$r = ldap_add($connect,$dn,$data);

    if (is_array($zoneDefault))
	{
		while (list($dc,$aRecord)=each($zoneDefault))
		{
			addZone ($domain_new,$dc,$aRecord,0);
		}
	}
	
	if (is_array($zoneDefault_cName))
	{
		while (list($dc,$cNAMERecord)=each($zoneDefault_cName))
		{
			addZone ($domain_new,$dc,0,$cNAMERecord.'.'.$domain_new);
		}
	}

  return $r;
}

/**
* Print a domains list
**/

function pdns_domains_list ($initial,$dottld,$search_filter,$pre_search_filter)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;
    global $r;
    global $td_width;
    global $td_width_box;
	global $dnsDataView;
	global $dns_search_filter;
	//global $idx;

	if ($search_filter == '')
		$search_filter = 'dc='.$initial.'*'.$dottld;
	
	if ($pre_search_filter)
		$search_filter = $pre_search_filter;
		
    $sth = ldap_list($connect,"$DNS_LDAP_BASE",$search_filter);

	// Order the results
	if (version_compare(phpversion(), "4.2.0", ">="))
		ldap_sort($connect, $sth,"dc");

    $entries = ldap_get_entries($connect, $sth);

	// Free the memory
	ldap_free_result($sth);

	$dnsDataView_nr = count($dnsDataView);
	$dnsDataView_span = ($dnsDataView_nr + 1);
	
	echo ("<FORM METHOD=\"GET\" ACTION=\"".$_SERVER["PHP_SELF"]."\" name=\"add\">\n");
	
    $tr_header = "<TR class=\"header\"><TD></TD>
                  <TD colspan=\"$dnsDataView_span\" width=\"$td_width\">".
				  $entries[count]." ".$lang["domains"];
	$tr_header .= " <INPUT type=\"text\" name=\"search_filter\" value=\"$initial\">";
	// Pre-defined Search
	if (count($dns_search_filter) > 0)
	{
		$tr_header .= "<SELECT name=\"pre_search_filter\">";
		$tr_header .= "<OPTION value=\"\">".$lang["select"];
		while (list($search_label,$search_f)=each($dns_search_filter))
		{
			$tr_header .= "<OPTION value=\"$search_f\">".$search_label;
		}
		$tr_header .= "</SELECT>";
	}
	
	$tr_header .= "<INPUT type=\"submit\" value=\"".$lang["search"]."\">";
	$tr_header .= "</TD></TR>";
	$tr_header .= "</FORM>";
	
	
	// Header costum attribute
	$tr_header .= "<TR class=\"header\"><TD></TD><TD></TD>";
	for ($kdx=0; $kdx < $dnsDataView_nr; $kdx++)
    {
		$attr = $dnsDataView[$kdx];

		$tr_header .= "<TD>";
		$tr_header .= $lang["$attr"];
		$tr_header .= "</TD>";
	}
	$tr_header .= "</TR>";

    echo ("<TABLE class='data'>\n");
    
	echo $tr_header;
	
    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='del'>");

	//while (list($dc,$aRecord)=each($zoneDefault))

	$domains_nr = $entries["count"];

			for ($idx=0; $idx < $domains_nr; $idx++)
		    {
				if ($idx%2 !=0)
					$class='data';
				else
					$class='zata';
					
        		$domain=$entries[$idx]["dc"][0];

		        echo ("<TR class=\"$class\" valign=\"top\">");
        		echo ("<TD class=\"box\"><INPUT type=\"checkbox\"
				name=\"dns_domain_delete[]\" value=\"$domain\"></TD>");
        		echo ("<TD><A href=\"?domain=$domain\">$domain</A></TD>");
				
				// Print costum attribute recursiv...
				for ($kdx=0; $kdx < $dnsDataView_nr; $kdx++)
			    {
					$attr = $dnsDataView[$kdx];
					
					echo "<TD>";
					for ($ldx=0; $ldx < count($entries[$idx][$attr]); $ldx++)
					{
						if (isset($entries[$idx]["$attr"][$ldx]))
	        				echo $entries[$idx]["$attr"][$ldx];
						echo "<BR>";
					}
					echo "</TD>";
				}

				echo ("</TR>");
			}
	
    echo ("<TR class='data'><TD></TD><TD colspan=\"1\">");
	echo "<INPUT type=\"submit\" value=\"".$lang["delete"]."\">";
	echo ("</TD></TR>");
	
	echo ("</TABLE>\n");
}

/**
* Delete a single domain
**/

function dns_domain_delete ($domain)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;

	$r = ldap_delete($connect, "dc=$domain,$DNS_LDAP_BASE");

	return $r;
}

/**
* Delete a single zone
**/

function dns_zone_delete ($domain,$zone)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;

	$r = ldap_delete($connect, "dc=$zone,dc=$domain,$DNS_LDAP_BASE");

	return $r;
}

/**
* Return a cname from a domain
**/

function cname_domain ($domain)
{
	global $connect;
	global $DNS_LDAP_BASE;


	$filter = "(aRecord=*)";
    $sth = ldap_search($connect,"dc=$domain,$DNS_LDAP_BASE","$filter");
	
	// Order the results
//	if (version_compare(phpversion(), "4.2.0", ">="))
//		ldap_sort($connect,$sth,"vd");

    $entries = ldap_get_entries($connect, $sth);

	echo "<SELECT name=\"cNAMERecord\">";
	echo "<OPTION value=\"\">---";
	echo "</OPTION>";
	for ($idx=0; $idx < $entries["count"]; $idx++)
	{
		$value = $entries[$idx]["associateddomain"][0];
		echo "<OPTION value=\"$value\">";
    	echo $value;
		echo "</OPTION>";
	}
	echo "</SELECT>";
	
	// Free the memory
	ldap_free_result($sth);
}

/**
* Update a SOA record
**/

function setSOA ($oldSOA)
{
	$oldSOA_fields = explode(" ",$oldSOA);

	$oldserial = $oldSOA_fields[2];

	$SERIAL = setSerial ($oldserial);
	
	// Create a new SOA Record
	$info["sOARecord"][] =	$oldSOA_fields[0]." ".
							$oldSOA_fields[1]." ".
							$SERIAL." ".
							$oldSOA_fields[2]." ".
							$oldSOA_fields[3]." ".
							$oldSOA_fields[4]." ".
							$oldSOA_fields[5]." ".
							$oldSOA_fields[6]." "
							;

 //   $r = ldap_modify($connect, "dc=$domain,$DNS_LDAP_BASE", $info);
	
	return TRUE;
}

?>
