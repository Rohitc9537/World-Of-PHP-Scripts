<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage pdns
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

require ('../plugins/pdns/functions.php');

$info = $_POST["info"];

if ($domain && !$action)
{
    $actionCode = 1;
}

elseif ($action == 'dns_modify')
{
    $aRecord = $_POST["aRecord"];
    $nSRecord = $_POST["nSRecord"];
    $mxP = $_POST["mxP"];
    $mxA = $_POST["mxA"];
    $mxIP = $_POST["mxIP"];
    $oldserial = $_POST["oldserial"];

	if (checkSyntax('ip',"$aRecord[0]"))
		$actionCode = 2;
	else
		$actionCode = 1;
}

elseif ($action == 'addZone')
{
    $actionCode = 3;
}

elseif (isset($_POST["dns_domain_delete"]))
{
    $actionCode = 4;
}

elseif (isset($_POST["dns_zone_delete"]))
{
    $actionCode = 5;
}

else
{
	$actionCode = 100;
}

if (DEBUG)
	echo "<H1>actionCode $actionCode</H1>";

// Logig actions
switch ($actionCode)
{
case "1" :
	$do = dnsDomain ($domain);
    echo "<BR>";
	if ($do)
	    dnsZone ($domain);
	else
	{
		print_message('warning',$lang["pdns_domain_dont_exists"]);
		form_add_domain ($domain);
	}
    break;

case "2" :
	print_message('message',$lang["modify"].'...');
    dnsModify ($domain,$aRecord,$nSRecord,$mxP,$mxA,$mxIP,$oldserial);
    refresh("main.php?domain=".$domain,'',REFRESH_TIME);
    break;
	
case "3" :
	addZone ("$domain",$_POST["dc"],$_POST["aRecord"],$_POST["cNAMERecord"]);
    refresh("main.php?domain=".$domain,'',REFRESH_TIME);

    break;
	
case "4" :
    foreach ($_POST["dns_domain_delete"] as $domain)
	{
		$r = myldap_delete($connect,"dc=$domain,$DNS_LDAP_BASE",$recursive=TRUE);
		if ($r == 1)
			$class = 'success';
		else
			$class = 'error';
		
		echo "<FONT class=\"$class\">".$lang["deleting"]." $domain</FONT><BR>";
	}
    refresh("main.php",'',REFRESH_TIME);
    break;
	
case "5" :
    foreach ($_POST["dns_zone_delete"] as $zone)
	{
		dns_zone_delete ($domain,$zone);
	}
    refresh("main.php?domain=".$domain,'',REFRESH_TIME);

    break;

case "100" :
	pdns_domains_list ($initial,$dottld,$_GET["search_filter"],$_GET["pre_search_filter"]);
	break;
}


?>
