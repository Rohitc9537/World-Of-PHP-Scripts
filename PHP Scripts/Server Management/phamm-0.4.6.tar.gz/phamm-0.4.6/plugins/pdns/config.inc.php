<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage pdns
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// DNS_LDAP_BASE
$DNS_LDAP_BASE		= 'ou=dns,dc=example,dc=tld';	// The container

// Dns dn syntax DNS_DN_MODE
//
// use 'compact' if you use this syntax
// dc=phamm.org,ou=dns,dc=example,dc=tld
// This is the default mode
//
// use 'full' if you use this dn syntax
// dc=example,dc=net,ou=dns,dc=example,dc=tld

define (DNS_DN_MODE,'compact');

define (NS1,'ns1.example.tld');
define (NS2,'ns2.example.tld');
define (ZONE_REFRESH,'86400');	// time in seconds
define (ZONE_RETRY,'3600');		// time in seconds
define (ZONE_EXPIRE,'1209600');	// time in seconds
define (ZONE_MINIMUM,'57600');	// time in seconds

// MX preference if MX for mXRecordDefault
define (PREFERENCE,'10');

$aRecordDefault = '192.168.1.1';

$mXRecordDefault = array();
$mXRecordDefault[] = 'mail.example.tld';
$mXRecordDefault[] = 'mail2.example.tld';
// $mXRecordDefault[] = 'mail3.example.tld';

// Add this zone by default
$zoneDefault = array (
'www' => '192.168.1.1',
'pop' => '192.168.1.2',
'webmail' => '192.168.1.3'
);

// Add this cName zone by default
/*
$zoneDefault_cName  = array (
'web' => 'www',
);
*/

$dnsDataView = array();
$dnsDataView[] = 'nsrecord';
$dnsDataView[] = 'arecord';
$dnsDataView[] = 'mxrecord';

// Pre-defined Search Filters
$dns_search_filter = array();
$dns_search_filter["my MX"] = 'arecord=192.168.1.2';
$dns_search_filter["my DNS"] = 'nsrecord=ns1.example.tld';


?>
