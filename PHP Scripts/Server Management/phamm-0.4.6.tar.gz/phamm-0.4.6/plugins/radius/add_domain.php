<?php

// ** Require the library file with all functions
// require ('phamm_functions.inc.php');
// ** To develop include single file funtion
// ** this is not a safe way to include file :-P
$mydir = opendir("../plugins/radius/functions");
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require_once ("functions/$fn");
}
closedir($mydir);


$do = add_realm ($domain_new, $password, $phamm_domain);

// Add postmaster account
require_once ("./plugins/mail/functions/add_alias.php");
$do_postmaster = add_alias ($_POST["domain_new"], 'postmaster', 'postmaster','postmaster', $_POST["password1"]);

    if(DEBUG >= 1)
        echo  "vd=$domain_new,$LDAP_BASE <BR>";
		
    if(DEBUG >= 2)
        echo var_dump ($info);

?>
