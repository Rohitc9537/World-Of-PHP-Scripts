<?php

/**
* @package Phamm
**/

// English
$lang['radius']                   = 'Radius';
$lang['realms']                   = 'Realms';
$lang['delete_realm']             = 'Delete realm';
$lang['domain_is_active']         = 'Realm active';
$lang['add_account']              = 'Add account';
$lang['account']                  = 'Account';
$lang['radiusGroupName']          = 'Radius group';
$lang['radiusFramedIPAddress']    = 'Radius dialup IP';
$lang['radiusClientIPAddress']    = 'Radius NAS IP';
$lang['radiusFramedIPNetmask']    = 'Radius netmask';
$lang['radiusClass']              = 'Radius class';
$lang['dialup_access']            = 'Dialup access';
$lang['modify_account']           = 'Modify account';
$lang['radiushuntGroup']          = 'Radius hunt group';
$lang['realm_property']           = 'Realm property';
$lang['realm_modify']             = 'Modify Realm';
$lang['attribute_error']          = 'Attribute error';

?>

