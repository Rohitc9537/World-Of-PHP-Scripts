<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage radius
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

// Set Other Variables With Method GET or POST --> mail
if (isset($_POST["step"]))
	$step		= $_POST["step"];
if (isset($_GET["mail"]))
	$mail		= $_GET["mail"];
if (isset($_POST["domain_new"]))
	$domain_new	= $_POST["domain_new"];
if (isset($_POST["mail_new"]))
	$mail_new	= $_POST["mail_new"];
if (isset($_POST["alias_new"]))
	$alias_new	= $_POST["alias_new"];
if (isset($_POST["destinations_del"]))
	$destinations_del	= $_POST["destinations_del"];

// If User are logged, check if can editaccounts
// then set the appropriate view 
//
if ($_SESSION["login"] != ADMINCN && $_SESSION["username"] != "postmaster" &&  $_SESSION["username"] != "matrix")
{
    	$mail=$_SESSION["login"];
	   	$action='modify_account';
}

// Set the domain
//=rm= if (isset($_SESSION["domain"]))
//=rm=    $domain = $_SESSION["domain"];
		
// ** Require the library file with all functions
// require ('phamm_functions.inc.php');
// ** To develop include single file funtion
// ** this is not a safe way to include file :-P
$mydir = opendir("../plugins/radius/functions");
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require ("functions/$fn");
}
closedir($mydir);

// Some preliminare check to validate domain and mail format
//if (isset($domain_new))
//	$domain_valid	= domain_valid($domain_new);
if (isset($mail_new))
	$mail_valid		= checkSyntax('account',$mail_new);
if (isset($alias_new))
	$alias_valid	= checkSyntax('account',$alias_new);
if (isset($_GET["catch_all"]))
	$alias_valid	= TRUE;

// ********************************************************************
// Show all domain selected e-mails and aliases account
if (($domain && !$action && !$mail) || ($action=='add_mail' && !$mail_valid) || ($action=='add_alias' && !$alias_valid && !$_POST["catch_all"]))
{
	if (DEBUG)
		print_message ('debug',"case_1");

        if ($action=='add_mail' && !$mail_valid)
			print_message ('error',$lang["mail_is_not_valid"]);
			
	// Domain Property Menu
	echo ("<P>");
	echo "<A href=\"?domain=$domain&action=realm_modify\">".$lang["realm_property"]."</A>";
	echo ("</P>");

	$do = is_realm_account ($domain);

	if ($do)
	{
		form_add_account ($domain);
	
		account_list ($domain);
	}
	else
	{
		print_message('warning',"mail_domain_dont_exists");
		form_add_realm ($domain);
	}
	
    echo ("<BR>");

	if (PHAMM_LOG >= 2)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
}

// Print the second form to add mail if format mail is valid
elseif ($action == 'add_mail' && $mail_valid)
{
	if (DEBUG)
		print_message ('debug','case_3');
		
	if (isset($_POST["domain"]))
    	$domain		= $_POST["domain"];
	if (isset($_POST["radius"]))
	    $radius		= $_POST["radius"];
	if (isset($_POST["real_name"]))
	    $real_name	= $_POST["real_name"];
	if (isset($_POST["password1"]))
    	$password1	= $_POST["password1"];
	if (isset($_POST["password2"]))
	    $password2	= $_POST["password2"];

	if (isset($password1) && isset($password2))
	    $pw_is_ok = password_valid ($password1, $password2);

      $syntax_ok=1;
        // check radius attributes
      if (strlen($radius["FramedIPAddress"]))
        $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["FramedIPAddress"]);
      if (strlen($radius["ClientIPAddress"]))
        $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["ClientIPAddress"]);
      if (strlen($radius["FramedIPNetmask"]))
        $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["FramedIPNetmask"]);

    if ($step == '2' && $real_name && ($pw_is_ok || $_POST["randompw"]) && $syntax_ok)
    {
        $do = add_account ($domain, $mail_new, $radius, $real_name, $password1,$_POST["randompw"]);
		
		if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
		
		if ($do=='1')
		{
			print_message ('success',"$mail_new@$domain ".$lang["added"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
			print_message ('error',"$mail_new ".$lang["not_added"]);
    }

    elseif ($step == 2 && (!$pw_is_ok || !$real_name))
    {
		if (!$pw_is_ok)
			print_message ('error',$lang["password_dont_match"]);
		if (!$real_name)
			print_message ('error',$lang["missing_real_name"]);
        form_add_account_2 ($domain, $mail_new);
    }
	
    else
    {
      // checks if mail exists
      $filter1="(&(mail=$mail_new@$domain)(objectClass=VirtualMailAccount)(!(objectClass=radiusprofile)))";
      $search1=ldap_search($connect, $LDAP_BASE, $filter1);
      $results1 = ldap_get_entries($connect, $search1);
      if ($results1['count']>0) {
	$mail=$mail_new."@".$domain;
        $mail_values	= account_values ($mail);
        $real_name	= $mail_values[0]["cn"][0];
	$action="modify_account";
        form_add_account_2 ($domain, $mail);
      }
      else
        form_add_account_2 ($domain, $mail_new);
    }
}

// Print form to modify mail values
//elseif ($domain && $action=='modify_mail' && $mail)
//elseif ($action == "modify_mail" && $mail && $step != 2)
elseif ($action == "modify_account" && $mail && $step != 2)
{
	if (DEBUG)
		print_message ('debug','case_5');
		
    if (!$domain)
        $domain		= $_GET["domain"];

    if (!$mail)
        $mail		= $_GET["mail"];

    $mail_values	= account_values ($mail);

    $real_name	= $mail_values[0]["cn"][0];
    $radius["GroupName"]	= $mail_values[0]["radiusgroupname"][0];
    $radius["huntGroup"]	= $mail_values[0]["radiushuntgroupname"][0];
    $radius["FramedIPAddress"]		= $mail_values[0]["radiusframedipaddress"][0];
    $radius["ClientIPAddress"]		= $mail_values[0]["radiusclientipaddress"][0];
    $radius["FramedNetmask"]		= $mail_values[0]["radiusframednetwork"][0];
    $radius["Class"]	= $mail_values[0]["radiusclass"][0];

    form_add_account_2 ($domain, $mail);
}

// Modify Mail values
elseif ($action=='modify_account' && $step=='2')
{
	if (DEBUG)
		print_message ('debug',"case_6");
		
    $real_name		= $_POST["real_name"];
    $password1      = $_POST["password1"];
    $password2      = $_POST["password2"];
    $radius		= $_POST["radius"];

    $pw_is_ok = password_valid ($password1, $password2);

    $syntax_ok=1;
      // check radius attributes
    if (strlen($radius["FramedIPAddress"]))
      $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["FramedIPAddress"]);      if (strlen($radius["ClientIPAddress"]))
      $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["ClientIPAddress"]);      if (strlen($radius["FramedIPNetmask"]))
       $syntax_ok = $syntax_ok & checkSyntax ('ip',$radius["FramedIPNetmask"]);

    if (!$syntax_ok)
    {
		print_message('error',$lang["attribute_error"]);
        form_add_account_2 ($domain, $mail_new);
    }
    else if (($password1=='' &&  $password2 == '') || $pw_is_ok)
    {
        $do = modify_account ($mail_new, $domain, $real_name, $password1, $radius, $phamm);

        if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

		if ($do == 1)
		{
			print_message ('success',"$mail_new ".$lang["modified"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
		{
			print_message ('error',"$mail_new ".$lang["not_modified"]);
		}

    }

    else
    {
		print_message('error',$lang["password_dont_match"]);
        form_add_account_2 ($domain, $mail_new);
    }
}

// Print form to modify alias values
elseif (($domain && $action=='modify_alias' && $mail) || ($action == 'modify_alias' && $_GET["catch_all"]))
{
	if (DEBUG)
		print_message ('debug',"case_7");
		
    $domain		= $_GET["domain"];
    $mail		= $_GET["mail"];

    $alias_values	= alias_values ($mail);

    $real_name	= $alias_values[0][cn][0];
    $destinations	= $alias_values[0][maildrop];

    form_add_alias_2 ($domain, $mail);
}

// Modify Mail values
elseif ($action=='modify_alias' && $step=='2')
{
	if (DEBUG)
		print_message ('debug',"case_8");
		
    $real_name			= $_POST["real_name"];
    $alias_new			= $_POST["alias_new"];
    $destinations		= $_POST["destinations"];
    $destinations_del	= $_POST["destinations_del"];
    $password1			= $_POST["password1"];
    $password2			= $_POST["password2"];


    $pw_is_ok = password_valid ($password1, $password2);

    if (($password1=='' &&  $password2 == '') || $pw_is_ok)
    {
        $do = modify_alias ($alias_new, $domain, $real_name, $destinations, $password, $destinations_del);
		
        if (PHAMM_LOG >= 1)
			phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

		if ($do == 1)
		{
			print_message ('success',"$alias_new ".$lang["modified"]);
			refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
		}
		else
		{
			print_message ('error',"$alias_new ".$lang["not_modified"]);
		}
    }

    else
    {
		print_message('error',$lang["password_dont_match"]);
        form_add_alias_2 ($domain, $alias_new);
    }
}

elseif ($action=='account_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_9");
		
    // var to mail_modify_group
    $mail_delete		= $_GET["mail_delete"];
    if (!$_GET["mail_delete"])
        $mail_delete		= $_POST["mail_delete"];

    $mail_active		= $_GET["mail_active"];
    if (!$_GET["mail_active"])
        $mail_active		= $_POST["mail_active"];

    $dialup_access		= $_GET["dialup_access"];
    if (!$_GET["dialup_access"])
        $dialup_access		= $_POST["dialup_access"];

    $spam_check		= $_GET["spam_check"];
    if (!$_GET["spam_check"])
        $spam_check		= $_POST["spam_check"];
    
	$editaccounts		= $_GET["editaccounts"];
    if (!$_GET["editaccounts"])
        $editaccounts		= $_POST["editaccounts"];

	$mail_postmaster	= $_POST["mail_postmaster"];

    account_modify_group ($mail_delete, $mail_active, $dialup_access, $editaccounts);
	
	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
		
	refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
}

elseif ($action=='alias_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_10");
		
    // var to mail_modify_group
    $alias_delete		= $_GET["alias_delete"];
    if (!$_GET["alias_delete"])
        $alias_delete		= $_POST["alias_delete"];

    $alias_active		= $_GET["alias_active"];
    if (!$_GET["alias_active"])
        $alias_active		= $_POST["alias_active"];

	$editaccounts		= $_GET["editaccounts"];
    if (!$_GET["editaccounts"])
        $editaccounts		= $_POST["editaccounts"];

    alias_modify_group ($alias_delete, $alias_active, $editaccounts);
	
	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);

	refresh("main.php"."?domain=".$domain,'',REFRESH_TIME);
}

elseif ($action=='domains_modify_group')
{
	if (DEBUG)
		print_message ('debug',"case_11");
		
    // var to mail_modify_group
    if (isset($_GET["domains_delete"]))
	    $domains_delete		= $_GET["domains_delete"];
    if (isset($_POST["domains_delete"]))
        $domains_delete		= $_POST["domains_delete"];

    if (isset($_GET["domains_edit"]))
	    $domains_edit		= $_GET["domains_edit"];
    if (isset($_POST["domains_edit"]))
        $domains_edit		= $_POST["domains_edit"];

    if (isset($_GET["domains_active"]))
    	$domains_active		= $_GET["domains_active"];
    if (isset($_POST["domains_active"]))
        $domains_active		= $_POST["domains_active"];

    if (isset($_GET["domains_postmaster"]))
 	   $somains_postmaster	= $_GET["domains_postmaster"];
    if (isset($_POST["domains_postmaster"]))
        $somains_postmaster	= $_POST["domains_postmaster"];

    realms_modify_group ($domains_delete, $domains_edit, $domains_active, $somains_postmaster);

	if (PHAMM_LOG >= 1)
		phamm_log ($_SESSION["pn"],$_SESSION["login"],$action,$do);
	
	refresh("main.php",'',REFRESH_TIME);
}

// Domain Property
elseif ($action=='realm_modify' && !$step)
{
	if (DEBUG)
		print_message ('debug',"case_12");
		
	form_add_realm_2 ($domain,$phamm_domain);
//    form_add_postmasters ($postmasters_new);
}

// Domain Property
elseif ($action=='realm_modify' && $step==2)
{
	if (DEBUG)
		print_message ('debug',"case_13");
		
    $password1	= $_POST["password1"];
    $password2	= $_POST["password2"];
    $domain		= $_POST["domain_new"];

    $pw_is_ok = password_valid ($password1, $password2);
	
	if ($pw_is_ok)
	{
		$do=realm_modify ($domain, $password1);
		refresh("main.php"."?domain=".$domain_new,'',REFRESH_TIME);
	}

	// move to main
	else
	{
		form_add_realm_2 ($domain,$phamm_domain);
	}
}

// Print all domains list or short its by initial
else
{
	if (DEBUG)
		print_message ('debug',"case_14");
		
    realms_list ($initial,$_GET["tld"]);
}
?>
