<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

function account_modify_group ($mail_delete, $mail_active, $dialup_access, $editaccounts)
{
    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;

	// Only for the Array mail_active the value change
    //
    for ($i=0; $i < count($mail_active); $i++)
    {
        $username_domain = explode("@", $mail_active[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$mail_active[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $accountActive=$results[0]["accountactive"][0];

        if ($accountActive=="FALSE")
            $info_active["accountActive"] = "TRUE";

        elseif ($accountActive=="TRUE")
	        $info_active["accountActive"] = "FALSE";

        if ($info_active)
			$r=ldap_modify($connect, "mail=$mail_active[$i],vd=$domain,$LDAP_BASE", $info_active);
    }

	// Only for the Array mail_delete the value change
    //
    for ($i=0; $i < count($mail_delete); $i++)
    {
        $username_domain = explode("@", $mail_delete[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$mail_delete[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $delete=$results[0]["delete"][0];

        if ($delete=="FALSE")
            $info_delete["delete"] = "TRUE";

        elseif ($delete=="TRUE")
	        $info_delete["delete"] = "FALSE";

        if ($info_delete)
			$r=ldap_modify($connect, "mail=$mail_delete[$i],vd=$domain,$LDAP_BASE", $info_delete);
    }
	
    // Only for the Array virus_check
    //
    for ($i=0; $i < count($dialup_access); $i++)
    {
        $username_domain = explode("@", $dialup_access[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$dialup_access[$i])(objectClass=VirtualMailAccount))(objectClass=radiusprofile)";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $check=$results[0]["dialupaccess"][0];

        if ($check=="FALSE")
            $info_check["dialupaccess"] = "TRUE";
        elseif ($check=="TRUE")
	        $info_check["dialupaccess"] = "FALSE";
        else
            $info_check["dialupaccess"] = "TRUE";

        if ($info_check)
			$r=ldap_modify($connect, "mail=$dialup_access[$i],vd=$domain,$LDAP_BASE", $info_check);
    }



// Only for the Array editaccounts
    //
    for ($i=0; $i < count($editaccounts); $i++)
    {
        $username_domain = explode("@", $editaccounts[$i]);
		$domain = $username_domain[1];

        // Search the single mail
	    $filter="(&(mail=$editaccounts[$i])(objectClass=VirtualMailAccount))";
	    $search=ldap_search($connect, $LDAP_BASE, $filter);
	    $results = ldap_get_entries($connect, $search);
		
        $edit=$results[0]["editaccounts"][0];

        if ($edit == "FALSE")
            $info_editaccounts["editaccounts"] = "TRUE";

        elseif ($edit == "TRUE")
	        $info_editaccounts["editaccounts"] = "FALSE";

        if ($info_editaccounts)
			$r=ldap_modify($connect, "mail=$editaccounts[$i],vd=$domain,$LDAP_BASE", $info_editaccounts);
    }

}
?>
