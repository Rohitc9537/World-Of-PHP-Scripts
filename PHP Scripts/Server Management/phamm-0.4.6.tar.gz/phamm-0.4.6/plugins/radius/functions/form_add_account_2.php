<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @subpackage accessories
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

function form_add_account_2 ($domain, $mail_new)
{
global $lang;
global $real_name;
global $action;
global $radius;

?>

<SCRIPT language="javascript">
function sf(){document.add.real_name.focus();}
</SCRIPT>

<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="action" value="<?php echo $action; ?>">
<INPUT type="hidden" name="step" value="2">
<INPUT type="hidden" name="domain" value="<?php echo $domain; ?>">
<INPUT type="hidden" name="mail_new" value="<?php echo $mail_new; ?>">

<TABLE class="data">
<TR><TD><?php echo $lang["account"]; ?></TD>
<TD><?php
echo $mail_new;
if ($action=='add_mail')
	echo '@'.$domain;
?></TD></TR>
<TR><TD><?php echo $lang["real_name"]; ?></TD>
<TD><INPUT type="text" name="real_name" value="<?php echo $real_name; ?>"></TD></TR>
<TR><TD><?php echo $lang["random"]; ?></TD>
<TD><INPUT type="checkbox" name="randompw" value="1">
<?php echo "Random ".$lang["password"]; ?></TD></TR>
<TR><TD><?php echo $lang["password"]; ?></TD>
<TD><INPUT type="password" name="password1" value=""></TD></TR>
<TR><TD><?php echo $lang["repeat_password"]; ?></TD>
<TD><INPUT type="password" name="password2" value=""></TD></TR>

<?php
if ($_SESSION["login"] == ADMINCN || $_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix")
{
?>
<TR><TD><?php echo $lang["radiusGroupName"]; ?></TD>
<TD><INPUT type="text" name="radius[GroupName]" value="<?php echo $radius["GroupName"]; ?>"></TD></TR>
<TR><TD><?php echo $lang["radiushuntGroup"]; ?></TD>
<TD><INPUT type="text" name="radius[huntGroup]" value="<?php echo $radius["huntGroup"]; ?>"></TD></TR>
<TR><TD><?php echo $lang["radiusFramedIPAddress"]; ?></TD>
<TD><INPUT type="text" name="radius[FramedIPAddress]" value="<?php echo $radius["FramedIPAddress"]; ?>"></TD></TR>
<TR><TD><?php echo $lang["radiusClientIPAddress"]; ?></TD>
<TD><INPUT type="text" name="radius[ClientIPAddress]" value="<?php echo $radius["ClientIPAddress"]; ?>"></TD></TR>
<TR><TD><?php echo $lang["radiusFramedIPNetmask"]; ?></TD>
<TD><INPUT type="text" name="radius[FramedIPNetmask]" value="<?php echo $radius["FramedIPNetmask"]; ?>"></TD></TR>
<TR><TD><?php echo $lang["radiusClass"]; ?></TD>
<TD><INPUT type="text" name="radius[Class]" value="<?php echo $radius["Class"]; ?>"></TD></TR>

<?php
}
?>
</TABLE>
<?php echo ("<INPUT type=\"submit\" value=\"".$lang["$action"]."\">"); ?>
</FORM>

<?php
}
?>
