<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package functions
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

function modify_account ($mail, $domain, $real_name, $password1, $radius, $phamm)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;

    // prepare data
    $info["lastChange"]		= time();
    if ($real_name)
        $info["cn"]			= "$real_name";
    if ($password1)
		$info["userPassword"]	= password_hash($password1);

    // Radius attributes
    if ($radius["FramedIPAddress"])
        $info["radiusFramedIPAddress"]		= $radius["FramedIPAddress"];
    else {
        unset($info2);
        $info2["radiusFramedIPAddress"]		= array();
        $r =  @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }
    if ($radius["GroupName"])
        $info["radiusGroupName"]		= $radius["GroupName"];
    else {
        unset($info2);
        $info2["radiusGroupName"]		= array();
        $r = @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }
    if ($radius["huntGroup"])
        $info["radiushuntgroupname"]		= $radius["huntGroup"];
    else {
        unset($info2);
        $info2["radiushuntgroupname"]		= array();
        $r = @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }
    if ($radius["ClientIPAddress"])
        $info["radiusClientIPAddress"]		= $radius["ClientIPAddress"];
    else {
        unset($info2);
        $info2["radiusClientIPAddress"]		= array();
        $r = @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }
    if ($radius["FramedIPNetmask"])
        $info["radiusFramedIPNetmask"]		= $radius["FramedIPNetmask"];
    else {
        unset($info2);
        $info2["radiusFramedIPNetmask"]		= array();
        $r = @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }
    if ($radius["Class"])
        $info["radiusClass"]			= $radius["Class"];
    else {
        unset($info2);
        $info2["radiusClass"]			= array();
        $r = @ldap_mod_del($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info2);
    }

    $r = ldap_modify($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info);

    // checks if mail exists
    $filter1="(&(mail=$mail)(objectClass=VirtualMailAccount)(!(objectClass=radiusprofile)))";
    $search1=ldap_search($connect, $LDAP_BASE, $filter1);
    $results1 = ldap_get_entries($connect, $search1);
    if ($results1['count']>0) {
      $info1["ObjectClass"][]="radiusprofile";
      $info1["dialupaccess"][0]="TRUE";
      $r = ldap_mod_add($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info1);
    }
    return $r;
}

?>
