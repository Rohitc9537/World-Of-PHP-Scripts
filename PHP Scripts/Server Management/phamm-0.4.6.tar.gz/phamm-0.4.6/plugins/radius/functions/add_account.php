<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Add an account
* 
* @package functions
* @author Tiziano D'Inca' <tiziano@asdasd.it>
* 
* @var string domain
* @var string mail_new
* @var string radius
* @var string real_name
* @var string password
* @return bolean the result success=1 or insuccess=0
**/

function add_account ($domain, $mail_new, $radius, $real_name, $password, $randompw=FALSE)
{
    $mail=$mail_new.'@'.$domain;

    global $connect;
    global $LDAP_BASE;
    global $SUFFIX;
    global $multi;
    global $accountActive;

    // prepare data
    $info["objectclass"][]		= "top";
    $info["objectclass"][]		= "VirtualMailAccount";
    $info["objectclass"][]		= "radiusprofile";

    $info["mail"]			= "$mail";
    $info["sn"]				= "$real_name";
    $info["vdHome"]                 = "$vmail_path/domains";
    $info["mailbox"]            = "$domain/$mail_new/";
    $info["cn"]				= "$real_name";
    $info["accountActive"]	= "$accountActive";
    $info["delete"]			= "FALSE";

    // Generate random password
    if ($randompw)
      $password	= randstr(PASSWORD_RND_LENGHT);
		
    if (strlen($password)>0)
      $info["userpassword"]	= password_hash($password);

    $info["lastchange"]		= time();
	
    // accesso dialup
    $info["dialupaccess"]  		= "TRUE";
    if (strlen($radius["GroupName"]))
      $info["radiusgroupname"]  		= $radius["GroupName"];
    if (strlen($radius["huntGroup"]))
      $info["radiushuntgroupname"]  		= $radius["huntGroup"];
    if (strlen($radius["FramedIPAddress"]))
      $info["radiusframedipaddress"]  	= $radius["FramedIPAddress"];
    if (strlen($radius["ClientIPAddress"]))
      $info["radiusclientipaddress"]  	= $radius["ClientIPAddress"];
    if (strlen($radius["FramendIPNetmask"]))
      $info["radiusframedipnetmask"]  	= $radius["FramendIPNetmask"];
    if (strlen($radius["Class"]))
      $info["radiusclass"]  		= $radius["Class"];

    if (DEBUG)
        echo ("mail=$mail,vd=$domain,$LDAP_BASE");

    $r = ldap_add($connect, "mail=$mail,vd=$domain,$LDAP_BASE", $info);

    return $r;
}
?>
