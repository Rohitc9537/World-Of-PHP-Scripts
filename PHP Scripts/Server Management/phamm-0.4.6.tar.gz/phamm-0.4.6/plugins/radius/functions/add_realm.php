<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Add a new realm
* 
* @package plugin
* @subpackage mail
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* 
* @param string $domain_new The new domain
* @param string $password The password for admin the domain
* @param array $phamm_domain
* @return bool The result
**/

function add_realm ($domain_new, $password, $phamm_domain)
{
    global $connect;
    global $lang;
    global $LDAP_BASE;
    global $SUFFIX;
    global $editAccounts;
    global $editPostmasters;
    global $accountActive;
    global $editAV;

    // prepare data
    $info["objectclass"][0]		= "top";
    $info["objectclass"][1]		= "VirtualDomain";
	
    $info["vd"]					= "$domain_new";
    $info["postfixTransport"]	= TRANSPORT.":";
    $info["accountActive"]		= "$accountActive";
    $info["lastChange"]			= time();
    $info["delete"]				= "FALSE";
	$info["editAV"]				= "$editAV";
	
	if ($phamm_domain["maxmail"])
	    $info["maxMail"]			= $phamm_domain["maxmail"];
	if ($phamm_domain["maxalias"])
	    $info["maxAlias"]			= $phamm_domain["maxalias"];
	if ($phamm_domain["maxquota"])
	    $info["maxQuota"]			= $phamm_domain["maxquota"];
	if ($info["adminID"])
		$info["adminID"] 			= "cn=".$_SESSION["username"].",ou=admin,dc=example,dc=tld";

    $r = ldap_add($connect, "vd=$domain_new,$LDAP_BASE", $info);
	return $r;
}
?>
