<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print a table with domains
*
* @package Phamm
* @subpackage radius
* @author Tiziano D'Inca' <tiziano@asdasd.it>
*
* @param string $initial The initial to short the domains
**/

function realms_list ($initial,$tld)
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
//    global $r;
    global $td_width;
    global $td_width_box;

		
	if (!$initial && DEFAULT_VIEW == 'none')
		$initial = '.oOo.';

    if ($initial == 'ALL')
        $initial = '';

    $sth = ldap_list($connect,"$LDAP_BASE","vd=$initial*$tld");
	
	// Order the results
	if (version_compare(phpversion(), "4.2.0", ">="))
		ldap_sort($connect, $sth,"vd");

    $entries = ldap_get_entries($connect, $sth);

	// Free the memory
	ldap_free_result($sth);

	// The header row
    $tr_header = ("<TR class='header'>
                  <TD>$entries[count] ".$lang["realms"]."</TD>
                  <TD>".$lang["accounts"]."</TD>
                  <TD width=\"$td_width_box\">".$lang["delete_realm"]."
				  </TD>
                  <TD width=\"$td_width_box\">".$lang["edit_accounts"]."
				  </TD>
				  <TD width=\"$td_width_box\">".$lang["domain_is_active"]."
				  </TD>
                  </TR>
                  ");

    echo ("<FORM METHOD='POST' ACTION=\"$_SERVER[PHP_SELF]\" name='add'>");
    echo ("<INPUT type='hidden' name='action' value='domains_modify_group'>");
    echo ("<INPUT type='hidden' name='domain' value=\"");
	if (isset($domain))
		echo "$domain";
	echo ("\">");

    echo ("<TABLE class=\"data\">\n");
	
    echo $tr_header;
	
	// The results
    for ($idx=0; $idx < $entries["count"]; $idx++)
    {
		
		// Prevent empty value
		$vd = '';
		$accountActive = 'FALSE';
		$delete = 'FALSE';
		$maxMail = '';
		$description = '';
		$editAccounts = 'FALSE';
		
        $vd = $entries[$idx]["vd"][0];
		$accountActive = $entries[$idx]["accountactive"][0];
        $delete = $entries[$idx]["delete"][0];
		$maxMail = $entries[$idx]["maxmail"][0];
		$description = $entries[$idx]["description"][0];
		
		if (DEFAULT_VIEW == 'all')
		{
			$usedMail = account_count ($vd);
		}
		elseif (DEFAULT_VIEW == 'none')
		{
			$usedMail = '--';
		}
		
		// Postmaster values
		$postmaster = self_values("cn=postmaster,vd=$vd,$LDAP_BASE","");

		$editAccounts = $postmaster[0]["editaccounts"][0];

		// Prevent empty link
		if (!$editAccounts)
			$editAccounts = "FALSE";

        echo ("<TR class=\"data\">");
        echo ("<TD><A href=\"?domain=$vd\">$vd</A></TD>");
        echo ("<TD align=\"center\">");
		echo $usedMail;
		if ($maxMail > 0)
			echo "/".$maxMail;
        echo ("</TD>");
        true_false_box ($delete, $vd,'domains_delete','domains_modify_group',0);
        true_false_box ($editAccounts, 'postmaster@'.$vd,'editaccounts','alias_modify_group',0);
        true_false_box ($accountActive, $vd,'domains_active','domains_modify_group',0);
        echo ("</TR>\n");
    }
	
    echo ("<TR class='footer'><TD colspan='6'>");
    form_modify('modify_domains');
    echo ("</TD><TD colspan='2'></TD>");
	echo ("</TR>");

    echo ("</TABLE>\n");
}
?>
