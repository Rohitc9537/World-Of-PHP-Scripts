<?php
require("config.inc.php");
require_once("DB.php");
$db = DB::connect($RADIUS_STATS_BASE);
if (DB::isError($db)) {
        die ($db->getMessage());
}
require("functions/select_accounting.php");

select_accounting();
?>
