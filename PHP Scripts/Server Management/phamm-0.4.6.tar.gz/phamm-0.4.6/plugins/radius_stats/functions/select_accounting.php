<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package phamm
* @subpackage radius_stats
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

// selects on db and prints out report
// ********************************************************************

function select_accounting() {
  global $lang;
  global $action;
  global $admin;
  global $db;
  global $LDAP_BASE;
  global $connect;
  global $ldap_credit_attribute;
  global $db_radius_cost_field;
  global $BILLING_CREDIT_BASE;

  $start_time=$_POST["start_time"];
  $start_hour=$_POST["start_hour"];
  $start_timed=substr($start_time,0,2);
  $start_timem=substr($start_time,3,2);
  $start_timey=substr($start_time,6,4);
  $start_time1=$start_timey."-".$start_timem."-".$start_timed." 00:00:00";
  $stop_time=$_POST["stop_time"];
  $stop_hour=$_POST["stop_hour"];
  $stop_timed=substr($stop_time,0,2);
  $stop_timem=substr($stop_time,3,2);
  $stop_timey=substr($stop_time,6,4);
  $stop_time1=$stop_timey."-".$stop_timem."-".$stop_timed." 23:59:59";
  $account=$_POST["account"];
  $type=$_POST["type"];
  $csv=$_POST["csv"];
  $realm=$_POST["domain"];
  $nasaddress=$_POST["nasaddress"];

  $fields=array("radiusUsername","radiusAcctStartTime","radiusAcctStopTime",
              "radiusAcctSessionTime","radiusAcctInputOctets",
              "radiusAcctOutputOctets","radiusCallingStationId",
              "radiusCalledStationId","radiusFramedIPAddress",
              "radiusNASIPAddress");
  if ($type=="billing") {
    $fields=array("radiusUsername","radiusAcctStartTime","radiusAcctStopTime",
              "radiusAcctSessionTime","radiusAcctInputOctets",
              "radiusCallingStationId","radiusCalledStationId");
    $lang["radius".$db_radius_cost_field]=$lang["call_cost"];
    if (strlen($account)>0 && $account!="all") {
      $filter1="(&(mail=$account)(objectClass=VirtualMailAccount)(objectClass=radiusprofile))";
      $search1=ldap_search($connect, $LDAP_BASE, $filter1);
      $results1 = ldap_get_entries($connect, $search1);
      ldap_free_result($search1);
      $credito=0;
      $credito=floor($results1[0][$ldap_credit_attribute][0])/$BILLING_CREDIT_BASE;
    }
  }
  if ($type=="statistics") {
    $fields=array("radiusAcctStartTime","radiusAcctStopTime",
              "radiusAcctSessionTime","radiusAcctInputOctets",
              "radiusAcctOutputOctets");
  }

  $sql = "select ".str_replace("radius","",implode(",",$fields))." from radacct where 1=1 ";

  if (strlen($nasaddress)>0 && $nasaddress!="all")
   $sql.=" and NASIPAddress='$nasaddress'";
  if (strlen($realm)>0 && $realm!="all")
   $sql.=" and Username like '%@$realm'";
  if (strlen($account)>0 && $account!="all")
   $sql.=" and Username='$account'";
  if (strlen($start_time1)>0)
   $sql.=" and AcctStartTime>='$start_time1'";
  if (strlen($stop_time1)>0)
   $sql.=" and AcctStopTime<='$stop_time1'";
  if ($type=="status") 
    $sql.=" and AcctStopTime='0000-00-00 00:00:00'";

  $sql.=" order by AcctStartTime ASC";
  $result = $db->query($sql);
  if (DB::isError($result)) {
    die ($result->getMessage());
  }
// RadAcctId | AcctSessionId | AcctUniqueId     | UserName       | Realm | NASIPAddress  | NASPortId | NASPortType | AcctStartTime       | AcctStopTime        | AcctSessionTime | AcctAuthentic | ConnectInfo_start | ConnectInfo_stop | AcctInputOctets | AcctOutputOctets | CalledStationId | CallingStationId | AcctTerminateCause | ServiceType   | FramedProtocol | FramedIPAddress | AcctStartDelay | AcctStopDelay
  if ($csv)
    ob_start();
  echo ("<TABLE class=\"data\">\n");


  if ($type=="statistics") {
    $fields=array(
              "radiusAcctSessionTime","radiusAcctInputOctets",
              "radiusAcctOutputOctets");
    $lang["radiusAcctInputOctets"]=$lang["total"]." ".$lang["radiusAcctInputOctets"];
    $lang["radiusAcctOutputOctets"]=$lang["total"]." ".$lang["radiusAcctOutputOctets"];
    $lang["radiusAcctSessionTime"]=$lang["total"]." ".$lang["radiusAcctSessionTime"];
  }
  echo "<TR class='header'>";
  for ($i=0;$i<count($fields);$i++) 
    echo "<TD>".$lang[$fields[$i]]."</TD>\n";
  echo "</TR>";

  while ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
    $costi+=$row[$db_radius_cost_field];
    if ($type=="statistics") {
      $hour_start=substr($row["AcctStartTime"],11,2);
      if ($hour_start>=$start_hour && ($hour_start<$stop_hour || $stop_hour=="00")) {
        $tot_radiusAcctSessionTime+=$row["AcctSessionTime"];
        $tot_radiusAcctInputOctets+=$row["AcctInputOctets"];
        $tot_radiusAcctOutputOctets+=$row["AcctOutputOctets"];
      }
    }
    else {
      echo ("<TR class=\"data\">");
      for ($i=0;$i<count($fields);$i++)
        if ($type=="billing") {
          if (str_replace("radius","",$fields[$i])==$db_radius_cost_field)
            $row[str_replace("radius","",$fields[$i])]=$row[str_replace("radius","",$fields[$i])]/$BILLING_CREDIT_BASE;
          echo "<TD>".ereg_replace("sip:","",ereg_replace("@.*","",$row[str_replace("radius","",$fields[$i])]))."</TD>\n";
        }
        else
          echo "<TD>".$row[str_replace("radius","",$fields[$i])]."</TD>\n";
      echo ("</TR>\n");
    }
  }
  if ($type=="statistics") {
    for ($i=0;$i<count($fields);$i++) {
      $field="tot_".$fields[$i];
      echo "<TD>".$$field."</TD>\n";
    }
    echo ("</TR>\n");
  }
  echo ("</TABLE>\n");
  if ($type=="billing" && strlen($account)>0 && $account!="all") {
    $start_euro=$credito+$costi/$BILLING_CREDIT_BASE;
    $stop_euro=$credito;
    echo $lang["starting_credit"].": ".$start_euro." &euro;\n";
    echo $lang["final_credit"].": ".$stop_euro." &euro;\n";
  }
  if (!$csv) {
?>
<br>
<FORM METHOD="POST" ACTION="plugins/radius_stats/csv_export.php" name="cvs">
<input type="hidden" name="domain" value="<?=$domain?>">
<input type="hidden" name="account" value="<?=$account?>">
<input type="hidden" name="start_time" value="<?=$start_time?>">
<input type="hidden" name="stop_time" value="<?=$stop_time?>">
<input type="hidden" name="start_hour" value="<?=$start_hour?>">
<input type="hidden" name="stop_hour" value="<?=$stop_hour?>">
<input type="hidden" name="nasaddress" value="<?=$nasaddress?>">
<input type="hidden" name="type" value="<?=$type?>">
<input type="hidden" name="csv" value="1">
<INPUT type="submit" value="CVS Export">
</FORM>
<?php
  }
  if ($csv) {
    $body=ob_get_contents();
    ob_end_clean();
    echo strip_tags(str_replace("</TD>",";",str_replace("</TR>","\n",str_replace("\n","",$body))));
  }
}
?>
