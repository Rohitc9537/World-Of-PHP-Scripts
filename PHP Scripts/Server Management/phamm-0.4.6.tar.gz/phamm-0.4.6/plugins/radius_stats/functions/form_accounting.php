<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004 Alessandro De Zorzi and Mirko Grava
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package phamm
* @subpackage radius_stats
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

// Print accounting form
// ********************************************************************

function form_accounting($initial,$tld) {
global $lang;
global $real_name;
global $action;
global $mail;
global $domain;
global $connect;
global $LDAP_BASE;
global $BILLING;
global $db;
global $td_width;
global $td_width_box;

?>
<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="select">
<INPUT type="hidden" name="action" value="select">
<INPUT type="hidden" name="step" value="2">

<TABLE class="data">
<?php
  if ($_SESSION['username'] == ADMINCN) {
    echo "<TR><TD>".$lang["realm"]."</TD><TD>";
    // select box realm
    if ($initial == 'ALL')
      $initial = '';

    $sth = ldap_list($connect,"$LDAP_BASE","vd=$initial*$tld");
    // Order the results
    if (version_compare(phpversion(), "4.2.0", ">="))
      ldap_sort($connect, $sth,"vd");

    $entries = ldap_get_entries($connect, $sth);
    // Free the memory
    ldap_free_result($sth);

    echo "<select name=domain onChange=\"document.select.submit()\">\n";
    if (strlen($domain)<1)
      echo "<option value=\"\" SELECTED >".$lang["none"]."\n";
    echo "<option value=\"all\">".$lang["all"]."\n";
    for ($idx=0; $idx < $entries["count"]; $idx++) {
      $vd = $entries[$idx]["vd"][0];
      if ($vd==$domain)
        $add="SELECTED ";
      echo "<option value=\"$vd\" $add>$vd\n";
      $add="";
    }
    echo "</select>\n";
    echo "</TD></TR>";
  }
  else echo "<input type=hidden name=domain value=\"$domain\">";
?>
<?php
  if ($_SESSION['username']== 'postmaster' || $_SESSION['username'] == ADMINCN) {
    echo "<TR><TD>".$lang["account"]."</TD><TD>";
    // select box accounts
    $filter="(&(mail=$initial*@$domain)(objectClass=VirtualMailAccount)(objectClass=radiusprofile))";
    if ($domain=="all")
      $filter="(&(mail=$initial*)(objectClass=VirtualMailAccount)(objectClass=radiusprofile))";
    $search=ldap_search($connect, $LDAP_BASE, $filter);

    // Order the results
    if (version_compare(phpversion(), "4.2.0", ">="))
      ldap_sort($connect, $search,"mail");
    $entries = ldap_get_entries($connect, $search);
    // Free the memory
    ldap_free_result($search);

    echo "<select name=account>\n";
    echo "<option value=\"all\">".$lang["all"]."\n";
    for ($idx=0; $idx < $entries["count"]; $idx++) {
      $maile = $entries[$idx]["mail"][0];
      if ($maile==$mail)
        $add="SELECTED ";
      echo "<option value=\"$maile\" $add>$maile\n";
      $add="";
    }
    echo "</select>\n";
    echo "</TD></TR>";
  }
  else echo "<input type=hidden name=account value=\"$mail\"";
?>
<TR><TD><?php echo $lang["start_time"]; ?></TD>
<TD><INPUT type="text" name="start_time" value="<?=date("d-m-Y",mktime(0,0,0,date("m")-1,date("d"),date("Y")));?>"></TD></TR>
<TR><TD><?php echo $lang["stop_time"]; ?></TD>
<TD><INPUT type="text" name="stop_time" value="<?=date("d-m-Y",mktime(0,0,0,date("m"),date("d"),date("Y")));?>"></TD></TR>
<TR><TD><?php echo $lang["time_window"]; ?></TD>
<TD>
<?php echo $lang["start_hour"]; ?>:&nbsp;<select name="start_hour">
<?php
$start_hour=0;
for ($hi=0;$hi<24;$hi++) {
  $add="";
  if ($hi==$start_hour)
    $add=" SELECTED ";
  if ($hi<10)
    $hour="0".$hi;
  else $hour=$hi;
  echo "<option value=$hour $add>$hour\n";
}
?>
</select>:00&nbsp;
<?php echo $lang["stop_hour"]; ?>:&nbsp;<select name="stop_hour">
<?php
$stop_hour=0;
for ($hi=0;$hi<24;$hi++) {
  $add="";
  if ($hi==$stop_hour)
    $add=" SELECTED ";
  if ($hi<10)
    $hour="0".$hi;
  else $hour=$hi;
  echo "<option value=$hour $add>$hour\n";
}
?>
</select>:00
</TD>
</TR>
<TR><TD><?php echo $lang["request_type"]; ?></TD>
<TD>
<select name=type>
<option value=none><?=$lang["none"]?>
<?php
  if($BILLING)
    echo "<option value=billing>".$lang["billing"]
?>
<option value=status><?=$lang["status"]?>
<option value=statistics><?=$lang["statistics"]?>
<option value=accounting><?=$lang["accounting"]?>
</select>
</TD></TR>
<TR><TD><?php echo $lang["NAS"]; ?></TD>
<TD>
<select name=nasaddress>
<option value=all><?=$lang["all"]?>
<?php
  $sql = "select nasname,shortname from nas order by shortname";
  $result = $db->query($sql);
  if (DB::isError($result)) {
    die ($result->getMessage());
  }
  while ($result->fetchInto($row)) {
    echo "<option value=\"$row[0]\" $add>$row[1]\n";
  }
?>
</select>
</TD></TR>
</TABLE>
<?php echo ("<INPUT type=\"submit\" value=\"".$lang["search"]."\">"); ?>
</FORM>

<?php
}
?>
