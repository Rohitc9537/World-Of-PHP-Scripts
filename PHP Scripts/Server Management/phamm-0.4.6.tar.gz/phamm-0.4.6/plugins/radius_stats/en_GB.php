<?php

/**
* @package Phamm
**/

// English
$lang['radius']                   = 'Radius';
$lang['realm']                    = 'Realm';
$lang['account']                  = 'Account';
$lang['radiusGroupName']          = 'Radius group';
$lang['radiusFramedIPAddress']    = 'Radius dialup IP';
$lang['radiusClientIPAddress']    = 'Radius NAS IP';
$lang['radiusFramedIPNetmask']    = 'Radius netmask';
$lang['radiusClass']              = 'Radius class';
$lang['radiushuntGroup']          = 'Radius hunt group';
$lang['start_time']               = 'Start day';
$lang['stop_time']                = 'Stop day';
$lang['search']                   = 'Search';
$lang['all']                      = 'All';
$lang['none']                     = 'None';
$lang['request_type']             = 'Request type';
$lang['billing']                  = 'Billing';
$lang['status']                   = 'Status';
$lang['statistics']               = 'Statistics';
$lang['accounting']               = 'Accounting';
$lang['NAS']                      = 'NAS';
$lang["radiusAcctStartTime"]      = 'Connect time';
$lang["radiusAcctStopTime"]       = 'Disconnect time';
$lang["radiusAcctSessionTime"]    = 'Session time';
$lang["radiusAcctInputOctets"]    = 'Bytes IN';
$lang["radiusAcctOutputOctets"]   = 'Bytes OUT';
$lang["radiusCalledStationId"]    = 'Called number';
$lang["radiusCallingStationId"]   = 'Calling number';
$lang["radiusNASIPAddress"]       = 'NAS IP';
$lang["radiusUsername"]           = 'Account';
$lang["start_hour"]               = 'Start hour';
$lang["stop_hour"]                = 'Stop hour';
$lang["time_window"]              = 'Time window';
$lang["call_cost"]                = 'Call cost';
$lang["total"]                    = 'TOTAL';
$lang["starting_credit"]          = 'Starting credit';
$lang["final_credit"]             = 'Final credit';

?>

