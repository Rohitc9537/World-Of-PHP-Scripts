<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage radius_stats
* @author Tiziano D'Inca' <tiziano@asdasd.it>
**/

require_once("DB.php");
$db = DB::connect($RADIUS_STATS_BASE);
if (DB::isError($db)) {
        die ($db->getMessage());
}

// Set Other Variables With Method GET or POST --> mail
if (isset($_POST["step"]))
	$step		= $_POST["step"];
if (isset($_GET["mail"]))
	$mail		= $_GET["mail"];
if (isset($_POST["type"]))
	$type	= $_POST["type"];
if (isset($_POST["realm"]))
	$realm	= $_POST["realm"];

// If User are logged, check if can editaccounts
// then set the appropriate view 
//
if ($_SESSION["login"] != "$admin" && $_SESSION["username"] != "postmaster" &&
$_SESSION["username"] != "matrix")
{
        $mail=$_SESSION["login"];
}

// Set the domain
if (isset($_SESSION["domain"]))
    $domain = $_SESSION["domain"];
		
// ** Require the library file with all functions
// require ('phamm_functions.inc.php');
// ** To develop include single file funtion
// ** this is not a safe way to include file :-P
$mydir = opendir("../plugins/radius_stats/functions");
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require ("functions/$fn");
}
closedir($mydir);

if ($action=="select" && $type!="none" && $domain!="none")
  $actionCode=1;
else
  $actionCode=0;

switch ($actionCode)
{
case "0" :
    form_accounting($initial,$_GET["tld"]);
    break;
case "1" :
    select_accounting();
    break;
}
?>
