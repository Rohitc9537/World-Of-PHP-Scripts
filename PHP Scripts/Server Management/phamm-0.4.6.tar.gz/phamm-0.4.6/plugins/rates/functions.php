<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage pdns
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function getFTPACTIVE ($dc)
{
    global $domain;
    global $FTP_LDAP_BASE;
    global $connect;

    $domain2 = explode (".",$domain);

    if (FTP_MODE == 'pureftpd')
    {
        $filter = "(objectClass=PureFTPdUser)";
        $search = ldap_search($connect, "vd=$domain,$FTP_LDAP_BASE",$filter);
    }

    else
    {
        $filter = "(objectClass=PureFTPdUser)";
        $search = ldap_search($connect, "vd=$domain,$DNS_LDAP_BASE",$filter);
    }

    $results = ldap_get_entries($connect, $search);

    ldap_free_result($search);

    // Return the results
    return $results[0]["FTPStatus"][0];
}
//
// ********************************************************************

/*
* Print the FTP user main table
*
* @param string $initial Initial to folter results
* @return mixed The results in HTML table
*/

function viewrates()
{
    global $lang;
    global $connect;
    global $LDAP_BASE;
    global $domain;
    global $ratesDataView;
    global $db;
    global $td_width;
    global $td_width_box;
    global $BILLING_CREDIT_BASE;

    $owner=$_GET["owner"];
    $owner=$_POST["owner"];
    if (strlen($owner)==0)
      $owner=$_SESSION["username"]."@".$_SESSION["domain"];

    $sql="select * from routes where owner='default'";
    $result = $db->query($sql);
    if (DB::isError($result)) {
      die ($result->getMessage());
    }
    while ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
        $rates[$row["pattern"]]["pattern"]=$row["pattern"];
      for ($i=0;$i<count($ratesDataView);$i++)
        $rates[$row["pattern"]][$ratesDataView[$i]]=$row[$ratesDataView[$i]];
    }
    if (ereg("^postmaster@",$owner))
      $default="postmaster";
    else
      $default=$domain;
    if (!ereg("^default","",$owner)) {
      $sql="select * from routes where owner='default_$default'";
      $result = $db->query($sql);
      if (DB::isError($result)) {
        die ($result->getMessage());
      }
      while ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
        $rates[$row["pattern"]]["pattern"]=$row["pattern"];
        for ($i=0;$i<count($ratesDataView);$i++)
          $rates[$row["pattern"]][$ratesDataView[$i]]=$row[$ratesDataView[$i]];
      }
    }

    $sql="select * from routes where owner='$owner'";
    $result = $db->query($sql);
    if (DB::isError($result)) {
      die ($result->getMessage());
    }
    while ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
        $rates[$row["pattern"]]["pattern"]=$row["pattern"];
      for ($i=0;$i<count($ratesDataView);$i++)
        $rates[$row["pattern"]][$ratesDataView[$i]]=$row[$ratesDataView[$i]];
    }
	// Otional attributes
	$ratesDataView_nr = count($ratesDataView);

    $tr_header = "<TR class='header'>
					<TD></TD>
                  <TD width=\"$td_width_box\">".$lang["pattern"]."</TD>
				 ";
	
	// Header costum attribute
	for ($kdx=0; $kdx < $ratesDataView_nr; $kdx++)
    {
		$attr = $ratesDataView[$kdx];

		$tr_header .= "<TD>";
		$tr_header .= $lang["$attr"];
		$tr_header .= "</TD>";
	}

	$tr_header .= "</TR>";

    if ($_SESSION["login"] == ADMINCN || $_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix") {
      echo ("<FORM METHOD=\"POST\" ACTION=\"$_SERVER[PHP_SELF]\" name=\"owner\">");
      echo ($lang["rates"].": <select name=\"owner\">");

      if ($_SESSION["login"] == ADMINCN)
        $filter="(&(cn=postmaster*)(objectClass=VirtualMailAlias))";
      else
        $filter="(&(mail=$initial*)(objectClass=VirtualMailAccount)(objectClass=radiusprofile))";
echo $filter;
      $search=ldap_search($connect, $LDAP_BASE, $filter);

      // Order the results
      if (version_compare(phpversion(), "4.2.0", ">="))
        ldap_sort($connect, $search,"mail");
      $entries = ldap_get_entries($connect, $search);
      // Free the memory
      ldap_free_result($search);

      echo "<option value=\"default\">default\n";
      if ($_SESSION["username"] == ADMINCN)
        echo "<option value=\"default_postmaster\">default_postmaster\n";
      if ($_SESSION["username"] == "postmaster")
        echo "<option value=\"default_$domain\">default_$domain\n";
      for ($idx=0; $idx < $entries["count"]; $idx++) {
        $maile = $entries[$idx]["mail"][0];
        if ($maile==$owner)
          $add="SELECTED ";
        echo "<option value=\"$maile\" $add>$maile\n";
        $add="";
      }
      echo ("</select>&nbsp;");
      echo "<INPUT type=\"submit\" value=\"".$lang["view"]."\">";
      echo ("</FORM>");
   }

    echo ("<FORM METHOD=\"POST\" ACTION=\"$_SERVER[PHP_SELF]\" name=\"add\">");
    echo ("<INPUT type=\"hidden\" name=\"action\" value=\"ftp_modify_group\">");
    echo ("<INPUT type=\"hidden\" name=\"domain\" value=\"$domain\">");

    echo ("<TABLE class=\"data\">\n");
	
    echo $tr_header;
	
    while(list($pattern,$arr)=each($rates))
    {
    	$mail = $arr["pattern"];
		
        echo ("<TR>");
        echo ("<TD>");
          if ($_SESSION["login"] == ADMINCN || (($_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix") && $owner!="default"))
          echo ("<INPUT type=\"checkbox\"
		name=\"ftp_delete[]\" value=\"$mail\">");
        echo ("</TD>");
		
        echo "<TD>";
          if ($_SESSION["login"] == ADMINCN || $_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix")
	    echo "<A href=\"?rate=$mail&owner=$owner&action=modifyrate\">$mail</A>";
          else
	    echo $mail;
		echo "</TD>";

		// Print costum attribute recursiv...
		for ($kdx=0; $kdx < $ratesDataView_nr; $kdx++)
	    {
			$attr = $ratesDataView[$kdx];
					
			
				echo "<TD>";
			if ($attr=="connectcost" || $attr=="cost")
		          echo (($arr["$attr"])/$BILLING_CREDIT_BASE);
			else
		          echo $arr["$attr"];
				echo "</TD>";
		}

		echo ("</TR>");
	}
	
    echo ("<TR class='footer'><TD></TD><TD>");
        if ($_SESSION["login"] == ADMINCN || (($_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix") && $owner!="default"))
	  echo "<INPUT type=\"submit\" value=\"".$lang["delete"]."\">";
	echo ("</TD></TR>");
	
	echo ("</TABLE>\n");
}

/**
* Delete a single domain
**/

function dns_domain_delete ($domain)
{
    global $lang;
    global $connect;
    global $DNS_LDAP_BASE;

	$r = ldap_delete($connect, "dc=$domain,$DNS_LDAP_BASE");

	return $r;
}

/**
* Delete a single zone
**/

function deleterate ($domain,$zone)
{
    global $lang;
    global $db;

	$r = ldap_delete($connect, "dc=$zone,dc=$domain,$DNS_LDAP_BASE");

		
        echo ("</TR>\n");
    
    echo ("</TABLE>\n");
}

function updaterate ($rate,$owner,$data)
{
    global $lang;
    global $connect;
    global $db;
    global $ratesDataEdit;

    $sql1="update routes set ";
    $info["mail"]=$account;
    for ($idx=0; $idx < count($ratesDataEdit); $idx++)
    {
      $sql1.=$ratesDataEdit[$idx]."='".$_POST[$ratesDataEdit[$idx]]."',";
    }
    $sql=substr($sql1,0,strlen($sql1)-1)." where pattern='$rate' and owner='$owner'";
    $r = $db->query($sql);

    return $r;
}


function form_add_rate()
{
  global $lang;
  global $connect;
  global $LDAP_BASE;
  global $domain;
  global $account_new;

  $owner=$_GET["owner"];
  $owner=$_POST["owner"];
  if (strlen($owner)==0 || ($owner=="default" && $_SESSION["login"] != ADMINCN))
    $owner=$_SESSION["username"]."@".$_SESSION["domain"];
?>

<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="action" value="add_rate_form_2">
<INPUT type="hidden" name="owner" value="<?php echo $owner; ?>">
<INPUT type="text" size="15" name="rate">
<INPUT type="submit" value="<?php echo $lang["add_rate"]; ?>">
</FORM>
<br>
<?php
}

function add_rate_form_2($rate,$owner,$data) {
  global $ratesDataEdit;
  global $lang;
  global $action;
  global $connect;
  global $db;

  $sql="select * from routes where owner='$owner' and pattern='$rate'";
  $result = $db->query($sql);
  if (DB::isError($result)) {
    die ($result->getMessage());
  }
  if ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
    $data["pattern"]=$row["pattern"];
    for ($i=0;$i<count($ratesDataEdit);$i++)
      $data[$ratesDataEdit[$i]]=$row[$ratesDataEdit[$i]];
    $action="updaterate";
  }
  else {
    $action="insertrate";
    $sql="select * from routes where owner='default' and pattern='$rate'";
    $result = $db->query($sql);
    if (DB::isError($result)) {
      die ($result->getMessage());
    }
    if ($result->fetchInto($row,DB_FETCHMODE_ASSOC)) {
      $data["pattern"]=$row["pattern"];
      for ($i=0;$i<count($ratesDataEdit);$i++)
        $data[$ratesDataEdit[$i]]=$row[$ratesDataEdit[$i]];
    }
  }
?>
<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="rate" value="<?php echo $rate; ?>">
<INPUT type="hidden" name="owner" value="<?php echo $owner; ?>">

<TABLE class="data">
<TR><TD><?php echo $lang["account"]; ?></TD>
<TD><?php
echo $account_new;
echo "<INPUT type=\"hidden\" name=\"action\" value=\"$action\">";
?></TD></TR>
<?php
  for($i=0; $i<count($ratesDataEdit);$i++) {
    echo "<TR><TD>".$lang[$ratesDataEdit[$i]]."</TD>";
    echo "<TD><INPUT type=\"text\" name=\"".$ratesDataEdit[$i]."\" value=\"".$data[$ratesDataEdit[$i]]."\"></TD></TR>";
  }
?>
</TABLE>
<?php echo ("<INPUT type=\"submit\" value=\"".$lang[$action]."\">"); ?>
</FORM>
<?php
}

function insertrate($rate,$owner,$data) {
  global $ratesDataEdit;
  global $lang;
  global $action;
  global $connect;
  global $db;

    $sql1="insert into routes (";
    for ($idx=0; $idx < count($ratesDataEdit); $idx++)
      $sql1.=$ratesDataEdit[$idx].",";
    $sql2=substr($sql1,0,strlen($sql1)-1).",pattern,owner) values ( ";
    for ($idx=0; $idx < count($ratesDataEdit); $idx++)
      $sql2.="'".$_POST[$ratesDataEdit[$idx]]."',";
    $sql=substr($sql2,0,strlen($sql2)-1).",'$rate','$owner')";
    $r = $db->query($sql);

    return $r;
}
?>
