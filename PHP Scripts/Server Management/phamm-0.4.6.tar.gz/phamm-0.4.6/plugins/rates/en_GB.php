<?php

$lang['pattern']="Route";
$lang['comment']="Destination";
$lang['connectcost']="Connect cost";
$lang['includedseconds']="Included seconds";
$lang['cost']="Minute cost";
$lang['step']="Step length";
$lang['updaterate']="Update rate";
$lang['insertrate']="Insert rate";
$lang['view']="View";
$lang['rates']="Rates";
$lang['add_rate']="Add rate";

?>
