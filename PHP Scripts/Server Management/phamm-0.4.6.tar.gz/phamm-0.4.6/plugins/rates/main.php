<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package application
* @subpackage pdns
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

require ('../plugins/rates/functions.php');

require_once("DB.php");
$db = DB::connect($RATES_STATS_BASE);
if (DB::isError($db)) {
        die ($db->getMessage());
}

$info = $_POST["info"];

// ====================================================================


// ====================================================================

switch ($action)
{
case "insertrate" :
    $rate=$_POST["rate"];
    $owner=$_POST["owner"];
    for ($i=0;$i<count($rateDataEdit);$i++)
      $data[$rateDataEdit[$i]]=$_POST[$rateDataEdit[$i]];
    insertrate($rate,$owner,$data);
    refresh("index.php"."?domain=".$domain,'',REFRESH_TIME);
    break;
	
case "modifyrate" :
	$rate=$_GET["rate"];
	$owner=$_GET["owner"];
	add_rate_form_2($rate,$owner,$data);
    break;

case "updaterate" :
    $rate=$_POST["rate"];
    $owner=$_POST["owner"];
    for ($i=0;$i<count($rateDataEdit);$i++)
      $data[$rateDataEdit[$i]]=$_POST[$rateDataEdit[$i]];
    updaterate($rate,$owner,$data);
    refresh("index.php"."?domain=".$domain,'',REFRESH_TIME);
    break;
	
case "deleterate" :
        $rate=$_POST["rate"];
        $owner=$_POST["owner"];
	deleterate();
    break;

case "add_rate_form_2" :
	$rate=$_POST["rate"];
	$owner=$_POST["owner"];
	add_rate_form_2($rate,$owner,$data);
    break;

default :
        $owner=$_POST["owner"];
	if ($_SESSION["login"] == ADMINCN || $_SESSION["username"] == "postmaster" || $_SESSION["username"] == "matrix") 
	  form_add_rate();
	viewrates($initial);
    break;
}

?>
