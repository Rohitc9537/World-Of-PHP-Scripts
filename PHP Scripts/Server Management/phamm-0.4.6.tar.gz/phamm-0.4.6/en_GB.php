<?php
/*
 * Phamm - http://www.phamm.org - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// English
$lang['server']				= 'Server';
$lang['domain']				= 'Domain';
$lang['domain_property']	= 'Domain Property';
$lang['domains']			= 'Domains';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']= 'Postmaster Password';
$lang['add_postmasters']	= 'Add Postmasters';
$lang['catch_all']			= 'Catch All';
$lang['postmasters']		= 'Postmasters';
$lang['appoint_postmasters']= 'Appoint Postmasters';
$lang['search'] 			= 'Search';
$lang['equals']				= 'Equals';
$lang['starts_with']		= 'Start with';
$lang['contains']			= 'Contains';
$lang['ends_with']			= 'Ends with';
$lang['sounds_like']		= 'Sounds link';
$lang['add_mail']			= 'Add Mail';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Add Alias';
$lang['add_domain']			= 'Add Domain';
$lang['accounts']			= 'Accounts';
$lang['alias']				= 'Alias';
$lang['aliases']			= 'Aliases';
$lang['edit_accounts']		= 'Can Edit Accounts';
$lang['active']				= 'Active';
$lang['domain_is_active']	= 'Domain is Active';
$lang['account_is_active']	= 'Account is Active';
$lang['alias_is_active']	= 'Alias is Active';
$lang['delete']				= 'Delete';
$lang['confirm_delete']		= 'Confirm Delete';
$lang['delete_account']		= 'Delete Account';
$lang['delete_domain']		= 'Delete Domain';
$lang['delete_alias']		= 'Delete Alias';
$lang['quota']				= 'Quota';
$lang['all']				= 'All';
$lang['real_name']			= 'Real Name';
$lang['return_to']			= 'Return to';
$lang['username']			= 'Username';
$lang['login']				= 'Login';
$lang['login_incorrect']	= 'Incorrect Login/Password, try Again';
$lang['modify_mail']		= 'Modify Mail';
$lang['modify_alias']		= 'Modify Alias';
$lang['modify_mails']		= 'Modify Mails';
$lang['modify_domains']		= 'Modify Domains';
$lang['modify_aliases']		= 'Modify Aliases';
$lang['domain_is_not_valid']= 'Domain is not Valid!';
$lang['mail_is_not_valid'] 	= 'Mail is not Valid!';
$lang['alias_is_not_valid'] = 'Alias is not Valid!';
$lang['password_dont_match']= 'Password don\'t Match';
$lang['password']			= 'Password';
$lang['repeat_password']	= 'Repeat Password';
$lang['error_connection']	= 'Connection Error';
$lang['destinations']		= 'Destinations';
$lang['add_destinations']	= 'Add Destinations';
$lang['delete_destinations']= 'Delete Destinations';
$lang['deleting']			= 'Deleting';
$lang['check_all']			= 'Check All';
$lang['virus_check']		= 'Virus Check';
$lang['spam_check']		= 'Spam Check';
$lang['change_postmaster_password']	= 'Change Postmaster Password';
$lang['warning_postmaster_password']	= 'Attention!';
$lang['error_config_file']	= 'Error. Config file don\'t found. Copy config.inc.php.template -> config.inc.php';
$lang['added']				= 'Added';
$lang['not_added']			= 'Not Added';
$lang['domain_modify']		= 'Modify Domain';
$lang['modify']				= 'Modify';
$lang['vacation']			= 'Vacation';
$lang["vacation_description"] = 'Vacation Description';
$lang["vacation_forward"]	= 'Vacation Forward';
$lang["vacation_info"]		= 'Vacation Info';
$lang["vacation_start"]		= 'Vacation Start';
$lang["vacation_end"]		= 'Vacation End';
$lang["check_to_activate"]	= 'Check to Activate';
$lang["check_to_deactivate"]= 'Check to Deactivate';
$lang["spamtaglevel"]		= 'Spam Tag Level';
$lang["spamtag2level"]		= 'Spam Tag2 Level';
$lang["spamkilllevel"]		= 'Spam Kill Level';
$lang["min"]			= 'Min';
$lang["max"]			= 'Max';
$lang["spam_control"]		= 'Spam Control';
$lang["low"]			= 'Low';
$lang["medium"]			= 'Medium';
$lang["high"]			= 'High';
$lang["very_high"]		= 'Very High';
$lang["return_to_domain"]	= 'Return to domain';

$lang["refresh_message"] = "You will be automatically redirect to a
new page within some seconds.<br>
If your browser doesn't support redirect,
please click";
$lang["missing_real_name"] = 'Missing Real Name';
$lang["max_mail"] = 'Max Mail';
$lang["max_alias"] = 'Max Alias';
$lang["max_quota"] = 'Max Quota';
$lang['edit_aliases']		= 'Can Edit Aliases';
$lang['edit']		= 'Edit';
$lang['plugin_problem']		= 'Plugin Problem!';

// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Forward';

$lang['go_to']				= 'Go to';
$lang["config_plugins_problem"] = 'Config plugins problem';
$lang['plugin']				= 'Plugin';
$lang['plugins']			= 'Plugins';
$lang['template']			= 'Template';
$lang['templates']			= 'Templates';
$lang['values']				= 'Values';

?>
