#!/bin/bash
#
 # Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 # Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 # 
 # Phamm is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # Phamm is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 # 
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software

# This file MUST be in this path ~vmail/bin
# and the dir bin MUST be in the vmail path

LDAP_BASE="ou=dns,dc=example,dc=tld"
ROOTDN="cn=manager,dc=example,dc=tld"
ROOTPW="rhx"
BINDDN="cn=phamm,o=hosting,dc=example,dc=tld"
BINDPW="rhx"

echo "Domain?"
read DOMAIN

FILE=virtual.$DOMAIN
SEARCH=search

# Search
ldapsearch -D $ROOTDN -w $ROOTPW -b "dc=$DOMAIN,$LDAP_BASE" -x -LLL "(objectClass=dNSDomain2)" aRecord cNAMERecord > $SEARCH

# Write virtual

echo "# Virtual $DOMAIN" > $FILE

echo "# created by Phamm virtual.sh" >> $FILE

echo "<VirtualHost $DOMAIN:80>" >> $FILE
echo "ServerAdmin webmaster@$DOMAIN" >> $FILE
echo "DocumentRoot /www/$DOMAIN/www" >> $FILE
echo "ServerName $DOMAIN" >> $FILE
echo "</VirtualHost>" >> $FILE

exit 0
