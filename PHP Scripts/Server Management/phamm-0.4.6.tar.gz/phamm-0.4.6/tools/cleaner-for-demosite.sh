#!/bin/bash
# IMPORTANT IMPORTANT IMPORTANT IMPORTANT
# this is only for demo-site
# delete all the attribute in LDAP and not the FileSystem
# IMPORTANT IMPORTANT IMPORTANT IMPORTANT
#
 # Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 # Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 # 
 # Phamm is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # Phamm is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 # 
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software

# WARNING THIS DELETE ALL THE TREE
ldapdelete -D "cn=manager,dc=example,dc=tld" -w "secret" -x -r -h localhost "dc=example,dc=tld"
# this add all with example file
ldapadd -D "cn=manager,dc=example,dc=tld" -w "secret" -x -h localhost -f sample-main.ldif
ldapadd -D "cn=manager,dc=example,dc=tld" -w "secret" -x -h localhost -f sample-mail.ldif
ldapadd -D "cn=manager,dc=example,dc=tld" -w "secret" -x -h localhost -f sample-pdns.ldif
