#!/bin/bash
#
 # Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 # Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 # 
 # Phamm is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # Phamm is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 # 
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software

# This file MUST be in this path ~vmail/bin
# and the dir bin MUST be in the vmail path

LDAP_BASE="o=hosting,dc=example,dc=tld"
admin="cn=manager"
SUFFIX="dc=example,dc=tld"
ROOTPW="secret"
BINDDN="cn=phamm,o=hosting,dc=example,dc=tld"
BINDPW="rhx"
OUTPUT="/home/vmail/bin/lista"
#

touch $OUTPUT
# ricerca mail da cancellare
ldapsearch -D $BINDDN -w $BINDPW -b $LDAP_BASE -x -LLL "(&(objectClass=VirtualMailAccount)(delete=TRUE))" mailbox > ~/mb$$
# creazione file per awk
sed \
-e ':a' \
-e '$!N;s/\n //;ta' \
-e 'P;D' \
~/mb$$ > ~/mb$$.1

cat ~/mb$$.1 | awk '{
			if ($1 == "dn:")
			{ print "ldapdelete -D \"'$admin','$SUFFIX'\" -w \"'$ROOTPW'\" -x \""$2"\"" > "'$OUTPUT'" }
			if ($1 == "mailbox:")
			{ print "rm -rf ~/domains/" $2 > "'$OUTPUT'" } 
			}'

# ricerca dominio da cancellare
ldapsearch -D $BINDDN -w $BINDPW -b $LDAP_BASE -x -LLL "(&(objectClass=VirtualDomain)(delete=TRUE))" vd > ~/vd$$
# creazione file per awk
sed \
-e ':a' \
-e '$!N;s/\n //;ta' \
-e 'P;D' \
~/vd$$ > ~/vd$$.1

cat ~/vd$$ | awk '{
			if ($1 == "dn:")
			{ print "ldapdelete -D \"'$admin','$SUFFIX'\" -w \"'$ROOTPW'\" -x -r \""$2"\"" > "'$OUTPUT'" }
			if ($1 == "vd:")
			{ print "rm -rf ~/domains/" $2 > "'$OUTPUT'" } 
			}'

# esecuzione e cancellazione file appoggio
chmod 700 $OUTPUT
$OUTPUT
rm -rf ~/mb* ~/vd* $OUTPUT
