#!/bin/bash
# tool to test the permission
# with the sample basedn
#
# Phamm - http://phamm.rhx.it - <phamm@rhx.it>
# Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
# 
# Phamm is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Phamm is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
#
BASEDN="dc=example,dc=tld"
MGR="cn=manager,dc=example,dc=tld"
PHM="cn=phamm,o=hosting,dc=example,dc=tld"
PST="cn=postmaster,vd=example.tld,o=hosting,dc=example,dc=tld"
USR="mail=john.doe@example.tld,vd=example.tld,o=hosting,dc=example,dc=tld"
SRV="localhost"
FILE="/tmp/result.ldif"

# like manager
echo "binding with manager" > $FILE
ldapsearch -LLL '(objectclass=*)' -D $MGR -W -b $BASEDN -v -x -h $SRV >> $FILE
echo "------------------------------------------------------------------------" >> $FILE
# like phamm
echo "binding with phamm" >> $FILE
ldapsearch -LLL '(objectclass=*)' -D $PHM -W -b $BASEDN -v -x -h $SRV >> $FILE
echo "------------------------------------------------------------------------" >> $FILE
# like postmaster
ldapsearch -LLL '(objectclass=*)' -D $PST -W -b $BASEDN -v -x -h $SRV >> $FILE
echo "------------------------------------------------------------------------" >> $FILE
# like user
ldapsearch -LLL '(objectclass=*)' -D $USR -W -b $BASEDN -v -x -h $SRV >> $FILE
echo "------------------------------------------------------------------------" >> $FILE
