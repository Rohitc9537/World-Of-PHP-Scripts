# migrate basedn
# IMPORTANT
# if you want that this script work every Account or Alias 
# must have a cn
# after this delete cn for manager and basedn
# I know that could be more easy but now we have only this :))
sed \
-e ':a' \
-e '$!N;s/\n //;ta' \
-e 'P;D' \
$1 > $1.$$
#
sed \
-e 's/jvd=/vd=/g' \
-e 's/jvd:/vd:/g' \
-e 's/homeDirectory/vdHome/g' \
-e 's/JammMailAccount/VirtualMailAccount/g' \
-e 's/JammMailAlias/VirtualMailAlias/g' \
-e 's/JammVirtualDomain/VirtualDomain/g' \
-e 's/PhammForward/VirtualForward/g' \
-e 's/editForward/forwardActive/g' \
-e '/^roleOccupant/D' \
-e '/JammPostmaster$/D' \
-e '/^editPostmaster/D' \
-e '/^editAccounts/D' \
-e '/^maildrop: postmaster/a\editAccounts: FALSE' \
-e '/^cn: .*/a\sn: Migrate from Jamm' \
-e '/^objectClass: VirtualMailAccount/a\objectClass: amavisAccount' \
-e '/^objectClass: VirtualMailAccount/a\objectClass: VirtualForward' \
-e '/^quota: /a\forwardActive: FALSE' \
-e '/^quota: /a\amavisSpamKillLevel: 6.0' \
-e '/^quota: /a\amavisSpamTag2Level: 5.5' \
-e '/^quota: /a\amavisSpamTagLevel: 3.0' \
-e '/^quota: /a\amavisBypassVirusChecks: FALSE' \
-e '/^quota: /a\amavisBypassSpamChecks: TRUE' \
-e '/^quota: /a\otherTransport: gnarwl:' \
-e '/^mail: abuse*/a\cn: Migrate from Jamm' \
-e '/^mail: abuse*/a\sn: Migrate from Jamm' \
$1.$$ > $1.new
rm $1.$$
