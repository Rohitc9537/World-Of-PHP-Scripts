<?php

/**
* @package Phamm
**/

// English
$lang['radius']             = 'Radius';

?>

