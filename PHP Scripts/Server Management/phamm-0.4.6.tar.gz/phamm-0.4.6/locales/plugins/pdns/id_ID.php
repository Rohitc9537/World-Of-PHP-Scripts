<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Indonesia 
$lang['server']				= 'Server';
$lang['domain']				= 'Domain';
$lang['domain_property']	= 'Pengaturan Domain';
$lang['domains']			= 'Semua domain';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']= 'Katakunci Postmaster';
$lang['add_postmasters']	= 'Tambah Postmaster';
$lang['catch_all']			= 'Ambil semua';
$lang['postmasters']		= 'Postmaster';
$lang['appoint_postmasters']= 'Jadikan sebagai Postmaster';
$lang['search'] 			= 'Cari';
$lang['equals']				= 'Sama dengan';
$lang['starts_with']		= 'Dimulai dari';
$lang['contains']			= 'Terdapat';
$lang['ends_with']			= 'Diakhiri dengan';
$lang['sounds_like']		= 'Sepertinya';
$lang['add_mail']			= 'Tambah Mail';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Tambah Alias';
$lang['add_domain']			= 'Tambah Domain';
$lang['accounts']			= 'Akount';
$lang['alias']				= 'Namalain';
$lang['aliases']			= 'Namalainnya';
$lang['edit_accounts']		= 'Dapat mengedit Akount';
$lang['active']				= 'Aktif';
$lang['domain_is_active']	= 'Domain Aktif';
$lang['account_is_active']	= 'Akount Aktif';
$lang['alias_is_active']	= 'Namalain Aktif';
$lang['delete']				= 'Hapus';
$lang['confirm_delete']		= 'Konfirmasi Hapus';
$lang['delete_account']		= 'Hapus Akount';
$lang['delete_domain']		= 'Hapus Domain';
$lang['delete_alias']		= 'Hapus Namalain';
$lang['quota']				= 'Kuota';
$lang['all']				= 'Semua';
$lang['real_name']			= 'Nama Sebenarnya';
$lang['return_to']			= 'Kembali ke';
$lang['username']			= 'Namauser';
$lang['login']				= 'Login';
$lang['login_incorrect']	= 'Login/Katakunci Salah, Cobalagi!';
$lang['modify_mail']		= 'Rubah Mail';
$lang['modify_alias']		= 'Rubah Namalain';
$lang['modify_mails']		= 'Rubah Mails';
$lang['modify_domains']		= 'Rubah Domain';
$lang['modify_aliases']		= 'Rubah Namalainnya';
$lang['domain_is_not_valid']= 'Domain tidak valid!';
$lang['mail_is_not_valid'] 	= 'Mail tidak valid!';
$lang['alias_is_not_valid'] = 'Nama lain tidak valid!';
$lang['password_dont_match']= 'Katakunci tidak sama';
$lang['password']			= 'Katakunci';
$lang['repeat_password']	= 'Ulangi katakunci';
$lang['error_connection']	= 'Koneksi Eror';
$lang['destinations']		= 'Tujuan';
$lang['add_destinations']	= 'Tambah tujuan';
$lang['delete_destinations']= 'Hapus Tujuan';
$lang['deleting']			= 'Hapus';
$lang['check_all']			= 'Cek Semua';
$lang['virus_check']		= 'Cek Virus';
$lang['spam_check']		= 'Cek Sampah';
$lang['change_postmaster_password']	= 'Rubah Katakundi Postmaster';
$lang['warning_postmaster_password']	= 'Perhatian!';
$lang['error_config_file']	= 'Eror. File config tidak ada. Salin file config.inc.php.template -> config.inc.php';
$lang['added']				= 'Tambahkan';
$lang['not_added']			= 'Batal';
$lang['domain_modify']		= 'Rubah Domain';
$lang['modify']				= 'Rubah';
$lang['vacation']			= 'Liburan';
$lang["vacation_description"] = 'Penjelasan Liburan';
$lang["vacation_forward"]	= 'Teruskan Liburan';
$lang["vacation_info"]		= 'Info Liburan';
$lang["vacation_start"]		= 'Mulai Liburan';
$lang["vacation_end"]		= 'Akhir Liburan';
$lang["check_to_activate"]	= 'Cek untuk mengaktifkan';
$lang["check_to_deactivate"]= 'Cek untuk menonaktifkan';
$lang["spamtaglevel"]		= 'Batas Tingkat Sampah';
$lang["spamtag2level"]		= 'Batas Tingkat2 Sampah';
$lang["spamkilllevel"]		= 'Tingkat Matikan Sampah';
$lang["min"]			= 'Minimal';
$lang["max"]			= 'Maksimal';
$lang["spam_control"]		= 'Kontrol Sampah';
$lang["low"]			= 'Rendah';
$lang["medium"]			= 'Sedang';
$lang["high"]			= 'Tinggi';
$lang["very_high"]		= 'Sangat Tinggi';
$lang["return_to_domain"]	= 'Kembali ke domain';

$lang["refresh_message"] = "Dalam beberapa saat anda akan segera beralih ke halaman baru. <br> Jika browser anda tidak mendukung pengalihan silahkan klik
";
$lang["missing_real_name"] = 'Kurang Nama Asli';
$lang["max_mail"] = 'Maksimal Mail';
$lang["max_alias"] = 'Maksimal Namalain';
$lang["max_quota"] = 'Maksimal Kuota';
$lang['edit_aliases']		= 'Dapat merubah namalainnya';
$lang['edit']		= 'Rubah';
$lang['plugin_problem']		= 'Masalah dengan Plugin!';


// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Teruskan';

$lang['go_to']				= 'Pergi ke';

?>
