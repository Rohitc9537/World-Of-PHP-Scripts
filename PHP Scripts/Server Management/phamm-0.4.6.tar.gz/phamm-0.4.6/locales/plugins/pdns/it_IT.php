<?php

// PDNS Plugin
$lang["add_zone"]		= 'Aggiungi Zone';
$lang["dns_only"]		= 'Solo DNS';
$lang["or"]				= 'o';
$lang["a_record"]		= 'A Record (IP)';
$lang["c_name_record"]	= 'cNAME (indirizzo)';
$lang["modified"]		= 'Modificato';
$lang["not_modified"]	= 'Non Modificato';
$lang["nsrecord"]		= 'NS';
$lang["arecord"]		= 'A';
$lang["mxrecord"]		= 'MX';
$lang["pdns_domain_dont_exists"]	= 'Il dominio PDNS non esiste';
$lang["new_mx"]			= 'Nuovo MX';
$lang["new_dns"]		= 'Nuovo DNS';

?>
