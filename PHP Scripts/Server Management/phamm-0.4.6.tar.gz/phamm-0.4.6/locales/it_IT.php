<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Renato Ben <renato AT civetta.net> (Translator)
**/

// Italiano
$lang['server']				= 'Server';
$lang['domain']				= 'Dominio';
$lang['domain_property']		= 'Proprieta\' Dominio';
$lang['domains']			= 'Domini';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']		= 'Postmaster Password';
$lang['add_postmasters']		= 'Aggiungi Postmasters';
$lang['catch_all']			= 'Catch All';
$lang['postmasters']			= 'Postmaster';
$lang['appoint_postmasters']		= 'Nomina postmaster';
$lang['search'] 			= 'Cerca';
$lang['equals']				= 'Uguale';
$lang['starts_with']			= 'Comincia con';
$lang['contains']			= 'Contiene';
$lang['ends_with']			= 'Finisce con';
$lang['sounds_like']			= 'Si pronuncia come';
$lang['add_mail']			= 'Aggiungi mail';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Aggiungi alias';
$lang['add_domain']			= 'Aggiungi dominio';
$lang['accounts']			= 'Account';
$lang['alias']				= 'Alias';
$lang['aliases']			= 'Alias';
$lang['edit_accounts']			= 'Modifica account';
$lang['active']				= 'Attivo';
$lang['domain_is_active']		= 'Dominio attivo';
$lang['account_is_active']		= 'Account attivo';
$lang['alias_is_active']		= 'Alias attivo';
$lang['delete']				= 'Cancella';
$lang['confirm_delete']			= 'Conferma Eliminazione';
$lang['delete_account']			= 'Cancella account';
$lang['delete_domain']			= 'Cancella dominio';
$lang['delete_alias']			= 'Cancella alias';
$lang['quota']				= 'Quota';
$lang['all']				= 'Tutti';
$lang['real_name']			= 'Nome';
$lang['return_to']			= 'Ritorna a';
$lang['username']			= 'Username';
$lang['login']				= 'Login';
$lang['login_incorrect']		= 'Login/password non corretti, riprova';
$lang['modify_mail']			= 'Modifica mail';
$lang['modify_alias']			= 'Modifica alias';
$lang['modify_mails']			= 'Modifica mails';
$lang['modify_domains']			= 'Modifica domains';
$lang['modify_aliases']			= 'Modifica aliases';
$lang['domain_is_not_valid'] 		= 'Il Dominio non e\' valido!';
$lang['mail_is_not_valid'] 		= 'Mail non valida!';
$lang['alias_is_not_valid'] 		= 'Alias non valido!';
$lang['password_dont_match']		= 'Password errata!';
$lang['password']			= 'Password';
$lang['repeat_password']		= 'Ripetere Password';
$lang['error_connection']		= 'Errore di Connessione';
$lang['destinations']			= 'Destinazioni';
$lang['add_destinations']		= 'Aggiungi Destinazioni';
$lang['delete_destinations']		= 'Cancella Destinazioni';
$lang['deleting']			= 'In cancellazione';
$lang['check_all']			= 'Seleziona tutto';
$lang['virus_check']			= 'Controllo Virus';
$lang['spam_check']			= 'Controllo Spam';
$lang['change_postmaster_password']	= 'Cambia la Password del Postmaster';
$lang['warning_postmaster_password']	= 'Attenzione!';
$lang['error_config_file']		= 'Errore. File di configurazione non trovato. Copia config.inc.php.template -> config.inc.php';
$lang['added']				= 'Aggiunto';
$lang['not_added']			= 'Non Aggiunto';
$lang['domain_modify']			= 'Modifica Dominio';
$lang['modify']				= 'Modifica';
$lang['vacation']			= 'Vacanza';
$lang["vacation_description"] 		= 'Descrizione della Vacanza'; // ADDED
$lang["vacation_forward"]		= 'Vacanza Forward';
$lang["vacation_info"]			= 'Vacanza Informazioni';
$lang["vacation_start"]			= 'Inizio Vacanza';
$lang["vacation_end"]			= 'Fine Vacanza';
$lang["check_to_activate"]		= 'Controllo per Attivare';
$lang["check_to_deactivate"]		= 'Controllo per Disattivare';
$lang["spamtaglevel"]			= 'Spam Tag Level';
$lang["spamtag2level"]			= 'Spam Tag2 Level';
$lang["spamkilllevel"]			= 'Livello di Spam';
$lang["min"]				= 'Min';
$lang["max"]				= 'Max';
$lang["spam_control"]			= 'Controllo Spam';
$lang["low"]				= 'Basso';
$lang["medium"]				= 'Medio';
$lang["high"]				= 'Alto';
$lang["very_high"]			= 'Molto Alto';
$lang["return_to_domain"]		= 'Ritorna al dominio';

$lang["refresh_message"] = "Sarai automaticamente ridirezionato a
una nuova pagina in alcuni secondi.<br>
Se il tuo browser non supporta il redirect,
clicca";
$lang["missing_real_name"] = 'Nome non presente';
$lang["max_mail"] = 'Massimo numero mail';
$lang["max_alias"] = 'Massimo numero alias';
$lang["max_quota"] = 'Massima quota';
$lang['edit_aliases']		= 'Può modificare gli alias';
$lang['edit']		= 'Modifica';
$lang['plugin_problem']		= 'Problema plugin!';

// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Forward';

$lang['go_to']				= 'Vai a ';
$lang["config_plugins_problem"] = 'Problema configurazione plugin';
$lang['plugin']				= 'Plugin';
$lang['plugins']			= 'Plugin';
$lang['template']			= 'Template';
$lang['templates']			= 'Templates';
$lang['values']				= 'Valori';

?>
