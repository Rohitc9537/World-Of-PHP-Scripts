<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Zoltan Gyula Beck <beckzg@midnight.hu> (Translator)
**/

// Magyar
$lang['server']				= 'Szerver';
$lang['domain']				= 'Tartom&aacute;ny';
$lang['domain_property']		= 'Tartom&aacute;ny Tulajdons&aacute;g';
$lang['domains']			= 'Tartom&aacute;ny';
$lang['postmaster']			= 'Postamester';
$lang['postmaster_password']		= 'Postamester Jelsz&oacute;';
$lang['add_postmasters']		= 'Postamester felv&eacute;tele';
$lang['catch_all']			= 'Elkap Mind';
$lang['postmasters']			= 'Postamesterek';
$lang['appoint_postmasters']		= 'Postamesternek Jel&ouml;l';
$lang['search'] 			= 'Keres';
$lang['equals']				= 'Egyenrang&uacute;';
$lang['starts_with']			= 'Kezd&otilde;dik';
$lang['contains']			= 'Tartalmaz';
$lang['ends_with']			= 'V&eacute;gz&otilde;dik';
$lang['sounds_like']			= 'Hang kapcsolat';
$lang['add_mail']			= 'Postafi&oacute;k Hozz&aacute;ad&aacute;s';
$lang['email']				= 'Postafi&oacute;k';
$lang['add_alias']			= '&Aacute;ln&eacute;v Hozz&aacute;ad&aacute;s';
$lang['add_domain']			= 'Tartom&aacute;ny Hozz&aacute;ad&aacute;s';
$lang['accounts']			= 'Postafi&oacute;k';
$lang['alias']				= '&Aacute;ln&eacute;v';
$lang['aliases']			= '&Aacute;lnevek';
$lang['edit_accounts']			= 'M&oacute;dos&iacute;that a Postafi&oacute;kokban';
$lang['active']				= 'Akt&iacute;v';
$lang['domain_is_active']		= 'Akt&iacute;v Tartom&aacute;ny';
$lang['account_is_active']		= 'Akt&iacute;v Postafi&oacute;k';
$lang['alias_is_active']		= 'Akt&iacute;v &Aacute;ln&eacute;v';
$lang['delete']				= 'T&ouml;rl&eacute;s';
$lang['confirm_delete']			= 'T&ouml;rl&eacute;s Jov&aacute;hagy&aacute;s';
$lang['delete_account']			= 'Postafi&oacute;k T&ouml;rl&eacute;s';
$lang['delete_domain']			= 'Tartom&aacute;ny T&ouml;rl&eacute;s';
$lang['delete_alias']			= '&Aacute;ln&eacute;v T&ouml;rl&eacute;s';
$lang['quota']				= 'Kv&oacute;ta';
$lang['all']				= '&Ouml;sszes';
$lang['real_name']			= 'Teljes N&eacute;v';
$lang['return_to']			= 'V&aacute;lasz C&iacute;m';
$lang['username']			= 'Felhaszn&aacute;l&oacute; N&eacute;v';
$lang['login']				= 'Bel&eacute;p&eacute;s';
$lang['login_incorrect']		= 'Hib&aacute;s felhaszn&aacute;l&oacute; n&eacute;v vagy jelsz&oacute;, prob&aacute;ld ujra';
$lang['modify_mail']			= 'Mail c&iacute;m m&oacute;dos&iacute;t&aacute;s';
$lang['modify_alias']			= '&Aacute;ln&eacute;v m&oacute;dos&iacute;t&aacute;s';
$lang['modify_mails']			= 'Mail c&iacute;mek m&oacute;dos&iacute;t&aacute;sa';
$lang['modify_domains']			= 'Tartom&aacute;nyok m&oacute;dos&iacute;t&aacute;sa';
$lang['modify_aliases']			= '&Aacute;lnevek m&oacute;dos&iacute;t&aacute;sa';
$lang['domain_is_not_valid']		= '&Eacute;rv&eacute;nytelen Tartom&aacute;ny!';
$lang['mail_is_not_valid'] 		= '&Aacute;rv&aacute;nytelen Mail c&iacute;m!';
$lang['alias_is_not_valid'] 		= '&Eacute;rv&eacute;nytelen &Aacute;ln&eacute;v!';
$lang['password_dont_match']		= 'A jelsz&oacute; nem egyezik';
$lang['password']			= 'Jelsz&oacute;';
$lang['repeat_password']		= 'Jelsz&oacute; Ism&eacute;t';
$lang['error_connection']		= 'Kapcsol&oacute;d&aacute;si Hiba';
$lang['destinations']			= 'C&iacute;mzettek';
$lang['add_destinations']		= 'C&iacute;mzettek Hozz&aacute;ad&aacute;s';
$lang['delete_destinations']		= 'C&iacute;mzettek T&ouml;rl&eacute;s';
$lang['deleting']			= 'T&ouml;rl&eacute;s';
$lang['check_all']			= 'Kijel&ouml;l Mind';
$lang['virus_check']			= 'V&iacute;rus Ellen&ouml;rz&eacute;s';
$lang['spam_check']			= 'Spam Ellen&ouml;rz&eacute;s';
$lang['change_postmaster_password']	= 'Postamester Jelsz&oacute;v&aacute;ltoztat&aacute;s';
$lang['warning_postmaster_password']	= 'Figyelem!';
$lang['error_config_file']		= 'Hiba. A konfigur&aacute;ci&oacute;s &aacute;llom&aacute;ny nem tal&aacute;lhat&oacute;. M&aacute;sold a config.inc.php.template -> config.inc.php';
$lang['added']				= 'Hozz&aacute;adva';
$lang['not_added']			= 'Hozz&aacute;ad&aacute;s Sikertelen';
$lang['domain_modify']			= 'Tartom&aacute;ny M&oacute;dos&iacute;t&aacute;s';
$lang['modify']				= 'M&oacute;dos&iacute;t';
$lang['vacation']			= 'T&aacute;voll&eacute;t';
$lang["vacation_description"] 		= 'T&aacute;voll&eacute;t Le&iacute;r&aacute;s';
$lang["vacation_forward"]		= 'T&aacute;voll&eacute;t Alatt Tov&aacute;bbk&uuml;ld';
$lang["vacation_info"]			= 'T&aacute;voll&eacute;t &Uuml;zenet';
$lang["vacation_start"]			= 'T&aacute;voll&eacute;t Kezdete';
$lang["vacation_end"]			= 'T&aacute;voll&eacute;t V&eacute;ge';
$lang["check_to_activate"]		= 'Bekapcsol';
$lang["check_to_deactivate"]		= 'Kikapcsol';
$lang["spamtaglevel"]			= 'Lev&eacute;lszem&eacute;t Tag Szint';
$lang["spamtag2level"]			= 'Lev&eacute;lszem&eacute;t Tag2 Szint';
$lang["spamkilllevel"]			= 'Lev&eacute;lszem&eacute;t Eldob Szint';
$lang["min"]				= 'Minim&aacute;lis';
$lang["max"]				= 'Maxim&aacute;lis';
$lang["spam_control"]			= 'Lev&eacute;lszem&eacute;t Be&aacute;ll&iacute;t&aacute;s';
$lang["low"]				= 'Alacsony';
$lang["medium"]				= 'K&ouml;zepes';
$lang["high"]				= 'Magas';
$lang["very_high"]			= 'Nagyon magas';
$lang["return_to_domain"]		= 'Vissza a tartom&aacute;nyhoz';

$lang["refresh_message"] 		= "N&eacute;h&aacute;ny m&aacute;sodperc mulva &aacute;tir&aacute;nyitodik egy &uacute;j oldalra<br>
Ha az &Ouml;n b&ouml;ng&eacute;sz&otilde;je nem t&aacute;mogatja az &aacute;tir&aacute;ny&iacute;t&aacute;st k&eacute;rem kattintson";
$lang["missing_real_name"] 		= 'Hi&aacute;nyz&oacute; Teljes N&eacute;v';
$lang["max_mail"] 			= 'Max Postafi&oacute;k';
$lang["max_alias"] 			= 'Max &Aacute;ln&eacute;v';
$lang["max_quota"] 			= 'Max Kv&oacute;ta';
$lang['edit_aliases']           	= 'M&oacute;dos&iacute;that az &Aacute;lnevekben';
$lang['edit']           		= 'Szerkeszt';
$lang['plugin_problem']         	= 'Plugin Probl&eacute;ma!';

// PDNS Plugin
$lang["add_zone"]               	= 'Z&oacute;na Hozz&aacute;ad&aacute;s';
$lang["dns_only"]               	= 'Csak DNS';
$lang["or"]                             = 'vagy';
$lang["a_record"]               	= 'A Record (IP)';
$lang["c_name_record"]  		= 'cNAME (c&iacute;m)';
$lang["modified"]       		= 'M&oacute;dos&iacute;tva';
$lang["not_modified"]   		= 'Nem M&oacute;dos&iacute;tott';

// Other Plugins
$lang['mail']                           = 'Postafi&oacute;k';
$lang['forward']                        = 'Tov&aacute;bbit';
?>
