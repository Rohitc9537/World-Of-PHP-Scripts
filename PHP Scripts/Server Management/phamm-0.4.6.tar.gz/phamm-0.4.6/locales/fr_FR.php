<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Tristan Defert <tristan.d AT alphamosa.fr> (Translator)
**/

// Francais
$lang['server']				= "Serveur";
$lang['domain']				= "Domaine(s)";
$lang['domain_property']	= "Propri&eacute;t&eacute;;s du domaine";
$lang['domains']			= "Domaines";
$lang['postmaster']			= "Postmaster";
$lang['postmaster_password']		= "Mot de Passe du Postmaster";
$lang['add_postmasters']	= "Ajouter des Postmasters";
$lang['catch_all']			= "Catch All";
$lang['postmasters']		= "Postmasters";
$lang['appoint_postmasters']		= "Annoter aux Postmasters";
$lang['search'] 			= "Rechercher";
$lang['equals']				= "Est &eacute;gal &agrave;";
$lang['starts_with']		= "Commence par";
$lang['contains']			= "Contient";
$lang['ends_with']			= "Finit par";
$lang['sounds_like']		= "Ressemble &agrave;";
$lang['add_mail']			= "Nouvelle Adresse mail";
$lang['email']				= "E-mail";
$lang['add_alias']			= "Nouvel Alias";
$lang['add_domain']			= "Nouveau Domaine";
$lang['accounts']			= "Comptes";
$lang['alias']				= "Alias";
$lang['aliases']			= "Alias";
$lang['edit_accounts']		= "Peut &eacute;diter les Comptes";
$lang['active']				= "Actif";
$lang['domain_is_active']	= "Le domaine est Actif";
$lang['account_is_active']	= "Le Compte est actif";
$lang['alias_is_active']	= "L'Alias est actif";
$lang['delete']				= "Supprimer";
$lang['confirm_delete']		= "Confirmer la suppression";
$lang['delete_account']		= "Supprimer le Compte";
$lang['delete_domain']		= "Supprimer le Domaine";
$lang['delete_alias']		= "Supprimer l'Alias";
$lang['quota']				= "Quota";
$lang['all']				= "Tous les";
$lang['real_name']			= "Pr&eacute;nom, Nom";
$lang['return_to']			= "Retourner &agrave;";
$lang['username']			= "Nom d'utilisateur";
$lang['login']				= "Login";
$lang['login_incorrect']	= "Mot de passe ou Login incorrect, veuillez r&eacute;essayer";
$lang['modify_mail']		= "Modifier l'adresse Mail";
$lang['modify_alias']		= "Modifier les Alias";
$lang['modify_mails']		= "Modifier les adresses Mail";
$lang['modify_domains']		= "Modifier les Domaines";
$lang['modify_aliases']		= "Modifier les Alias";
$lang['domain_is_not_valid'] 		= "Nom de Domaine non valide!";
$lang['mail_is_not_valid'] 	= "Adresse Mail invalide!";
$lang['alias_is_not_valid']	= "Alias invalide!";
$lang['password_dont_match']		= "Les mots de passe ne correspondent pas";
$lang['password']			= "Mot de passe";
$lang['repeat_password']	= "Mot de passe (confirmation)";
$lang['error_connection']	= "Erreur de connexion";
$lang['destinations']		= "Destinations";
$lang['add_destinations']	= "Ajouter des Destinations";
$lang['delete_destinations']			= "Supprimer des Destinations";
$lang['deleting']			= "Effacement en cours";
$lang['check_all']			= "Tout cocher";
$lang['virus_check']		= 'Virus Check';
$lang['spam_check']			= 'Spam Check';
$lang['change_postmaster_password']	= "Changer le Mot de Passe du postmaster";
$lang['warning_postmaster_password']	= "Attention!";
$lang['error_config_file']	= "Erreur. Fichier de configuration introuvable. Copiez le fichier config.inc.php.template en config.inc.php";
$lang['added']				= 'Added';
$lang['not_added']			= 'Not Added';
$lang['domain_modify']		= 'Modify Domain';
$lang['modify']				= 'Modify';
$lang['vacation']			= 'Vacation';
$lang["vacation_description"] = 'Vacation Description'; // ADDED
$lang["vacation_forward"]	= 'Vacation Forward';
$lang["vacation_info"]		= 'Vacation Info';
$lang["vacation_start"]		= 'Vacation Start';
$lang["vacation_end"]		= 'Vacation End';
$lang["check_to_activate"]	= 'Check to Activate';
$lang["check_to_deactivate"]= 'Check to Deactivate';
$lang["spamtaglevel"]		= 'Spam Tag Level';
$lang["spamtag2level"]		= 'Spam Tag2 Level';
$lang["spamkilllevel"]		= 'Spam Kill Level';
$lang["min"]			= 'Min';
$lang["max"]			= 'Max';
$lang["spam_control"]		= 'Spam Control';
$lang["low"]			= 'Low';
$lang["medium"]			= 'Medium';
$lang["high"]			= 'High';
$lang["very_high"]		= 'Very High';
$lang["return_to_domain"]	= 'Return to domain';

?>
