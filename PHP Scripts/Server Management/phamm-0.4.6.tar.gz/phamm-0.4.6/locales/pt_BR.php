<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Ronaldo Fabricio Reis Silva rfabriciors@hotmail.com (Translator)
**/

// Portugues Brasileiro
$lang['server']				= 'Servidor';
$lang['domain']				= 'Dominios';
$lang['domain_property']		= 'Dominio, Propriedades\'';
$lang['domains']			= 'Dominios';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']		= 'Senha do Postmaster';
$lang['add_postmasters']		= 'Adicionar Postmasters';
$lang['catch_all']			= 'Catch All';
$lang['postmasters']			= 'Postmaster';
$lang['appoint_postmasters']		= 'Nomear Postmaster';
$lang['search'] 			= 'Procurar';
$lang['equals']				= 'Igual';
$lang['starts_with']			= 'Iniciar com';
$lang['contains']			= 'Conteiner';
$lang['ends_with']			= 'Finalizar com';
$lang['sounds_like']			= 'Se pronuncia como';
$lang['add_mail']			= 'Adicionar mail';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Adicionar alias';
$lang['add_domain']			= 'Adicionar dominio';
$lang['accounts']			= 'Conta';
$lang['alias']				= 'Alias';
$lang['aliases']			= 'Alias';
$lang['edit_accounts']			= 'Modificar conta';
$lang['active']				= 'Ativo';
$lang['domain_is_active']		= 'Dominio ativo';
$lang['account_is_active']		= 'Conta ativa';
$lang['alias_is_active']		= 'Alias ativo';
$lang['delete']				= 'Cancelar';
$lang['confirm_delete']			= 'Confirma Remocao';
$lang['delete_account']			= 'Cancelar conta';
$lang['delete_domain']			= 'Cancelar dominio';
$lang['delete_alias']			= 'Cancelar alias';
$lang['quota']				= 'Quota';
$lang['all']				= 'Todos';
$lang['real_name']			= 'Nome';
$lang['return_to']			= 'Retornar a';
$lang['username']			= 'Usuario';
$lang['login']				= 'Login';
$lang['login_incorrect']		= 'Login ou Senha incorreta';
$lang['modify_mail']			= 'Modificar email';
$lang['modify_alias']			= 'Modificar alias';
$lang['modify_mails']			= 'Modificar emails';
$lang['modify_domains']			= 'Modificar dominios';
$lang['modify_aliases']			= 'Modificar aliases';
$lang['domain_is_not_valid'] 		= 'Dominio invalido!';
$lang['mail_is_not_valid'] 		= 'E-Mail invalido!';
$lang['alias_is_not_valid'] 		= 'Alias nao valido!';
$lang['password_dont_match']		= 'Senha Incorreta!';
$lang['password']			= 'Senha';
$lang['repeat_password']		= 'Repetir Senha';
$lang['error_connection']		= 'Falha na conexao';
$lang['destinations']			= 'Destino';
$lang['add_destinations']		= 'Adicionar Destino';
$lang['delete_destinations']		= 'Cancela Destino';
$lang['deleting']			= 'Removendo';
$lang['check_all']			= 'Selecionar todos';
$lang['virus_check']			= 'Virus Check';
$lang['spam_check']			= 'Spam Check';
$lang['change_postmaster_password']	= 'Trocar Senha do Postmaster';
$lang['warning_postmaster_password']	= 'Atencao!';
$lang['error_config_file']		= 'Erro. Arquivo de configuracao invalido. Copiar config.inc.php.template -> config.inc.php';
$lang['added']				= 'Adicionado';
$lang['not_added']			= 'Nao Adicionado';
$lang['domain_modify']			= 'Modificar Dominio';
$lang['modify']				= 'Modificar';
$lang['vacation']			= 'Ferias';
$lang["vacation_description"] 		= 'Descricao de ferias'; // ADDED
$lang["vacation_forward"]		= 'Ferias Forward';
$lang["vacation_info"]			= 'Ferias Info';
$lang["vacation_start"]			= 'Inicio de ferias';
$lang["vacation_end"]			= 'Fim de ferias';
$lang["check_to_activate"]		= 'Marcar para Ativar';
$lang["check_to_deactivate"]		= 'Marcar para desativar';
$lang["spamtaglevel"]			= 'Spam Tag Level';
$lang["spamtag2level"]			= 'Spam Tag2 Level';
$lang["spamkilllevel"]			= 'Spam Kill Level';
$lang["min"]				= 'Min';
$lang["max"]				= 'Max';
$lang["spam_control"]			= 'Controle de Spam';
$lang["low"]				= 'Baixo';
$lang["medium"]				= 'Medio';
$lang["high"]				= 'Alto';
$lang["very_high"]			= 'Muito Alto';
$lang["return_to_domain"]	= 'Return to domain';

?>
