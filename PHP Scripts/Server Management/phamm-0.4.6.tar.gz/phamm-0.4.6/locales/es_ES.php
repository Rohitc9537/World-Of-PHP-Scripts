<?php
/*
 * Phamm - http://www.phamm.org - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Javier Enrique Tiá Marín <javier@eftshlg.co.cu>(Translator)
**/

// Spanish
$lang['server']				= 'Servidor';
$lang['domain']				= 'Dominio';
$lang['domain_property']	= 'Dominio, Propiedades';
$lang['domains']			= 'Dominios';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']= 'Clave Postmaster';
$lang['add_postmasters']	= 'Agregar Postmasters';
$lang['catch_all']			= 'Marcar Todos';
$lang['postmasters']		= 'Postmasters';
$lang['appoint_postmasters']= 'Nombrar Postmasters';
$lang['search'] 			= 'Buscar';
$lang['equals']				= 'Igual';
$lang['starts_with']		= 'Comenzar con';
$lang['contains']			= 'Contiene ';
$lang['ends_with']		= 'Finalizar con';
$lang['sounds_like']		= 'Se pronuncia como';
$lang['add_mail']			= 'Adicionar Mail';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Adicionar Alias';
$lang['add_domain']			= 'Adidionar Dominio';
$lang['accounts']			= 'Cuentas';
$lang['alias']				= 'Alias';
$lang['aliases']			= 'Alias';
$lang['edit_accounts']		= 'Modificar Cuentas';
$lang['active']				= 'Activo';
$lang['domain_is_active']	= 'Dominio Activo';
$lang['account_is_active']	= 'Account Activo';
$lang['alias_is_active']	= 'Alias Activo';
$lang['delete']				= 'Eliminar';
$lang['confirm_delete']		= 'Confirmar Eliminar';
$lang['delete_account']		= 'Eliminar Cuenta';
$lang['delete_domain']		= 'Eliminar Dominio';
$lang['delete_alias']		= 'Eliminar Alias';
$lang['quota']				= 'Quota';
$lang['all']				= 'Todos';
$lang['real_name']			= 'Nombre Real';
$lang['return_to']			= 'Retornar a';
$lang['username']			= 'Usuario';
$lang['login']				= 'Login';
$lang['login_incorrect']	= 'Login/Clave incorrecto';
$lang['modify_mail']		= 'Modificar Mail';
$lang['modify_alias']		= 'Modificar Alias';
$lang['modify_mails']		= 'Modificar Mails';
$lang['modify_domains']		= 'Modificar Dominios';
$lang['modify_aliases']		= 'Modificar Aliases';
$lang['domain_is_not_valid']= 'Dominio inválido!';
$lang['mail_is_not_valid'] 	= 'Mail inválido!';
$lang['alias_is_not_valid'] = 'Alias inválido!';
$lang['password_dont_match']= 'Clave incorrecta';
$lang['password']			= 'Clave';
$lang['repeat_password']	= 'Repite Clave';
$lang['error_connection']	= 'Error Connección';
$lang['destinations']		= 'Destinaciones';
$lang['add_destinations']	= 'Adicionar Destinaciones';
$lang['delete_destinations']= 'Eliminar Destinaciones';
$lang['deleting']			= 'Eliminando';
$lang['check_all']			= 'Seleccionar Todos';
$lang['virus_check']		= 'Virus Check';
$lang['spam_check']		= 'Spam Check';
$lang['change_postmaster_password']	= 'Cambiar Clave Postmaster';
$lang['warning_postmaster_password']	= 'Atención!';
$lang['error_config_file']	= 'Error. Fichero de Configuración no encontrado. Copia config.inc.php.template -> config.inc.php';
$lang['added']				= 'Adicionado';
$lang['not_added']			= 'No Adicionado';
$lang['domain_modify']		= 'Modificar Dominio';
$lang['modify']				= 'Modificar';
$lang['vacation']			= 'Vacación';
$lang["vacation_description"] = 'Descripción de Vacación';
$lang["vacation_forward"]	= 'Vacación Forward';
$lang["vacation_info"]		= 'Vacación Info';
$lang["vacation_start"]		= 'Inicio de Vacación';
$lang["vacation_end"]		= 'Fin de Vacación';
$lang["check_to_activate"]	= 'Marcar para Activar';
$lang["check_to_deactivate"]= 'Marcar para Desactivar';
$lang["spamtaglevel"]		= 'Nivel Etiqueta Spam';
$lang["spamtag2level"]		= 'Nivel Etiqueta2 Spam';
$lang["spamkilllevel"]		= 'Nivel Muerto Spam';
$lang["min"]			= 'Mínimo';
$lang["max"]			= 'Máximo';
$lang["spam_control"]		= 'Control Spam';
$lang["low"]			= 'Bajo';
$lang["medium"]			= 'Medio';
$lang["high"]			= 'Alto';
$lang["very_high"]		= 'Muy Alto';
$lang["return_to_domain"]	= 'Retorno al Dominio';

$lang["refresh_message"] = "Automáticamente será redireccionado a una
nueva página dentro algunos segundos.<br>
Si tu Navegador no soporta redirección,
por favor haga click";
$lang["missing_real_name"] = 'Falta Nombre Real';
$lang["max_mail"] = 'Máximo Mail';
$lang["max_alias"] = 'Máxima Alias';
$lang["max_quota"] = 'Máxima Quota';
$lang['edit_aliases']		= 'Puede Modificar Alias';
$lang['edit']		= 'Modificar';
$lang['plugin_problem']		= 'Problema en Plugin!';

// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Forward';

$lang['go_to']				= 'Ir a';
$lang["config_plugins_problem"] = 'Configurar problema plugins';
$lang['plugin']				= 'Plugin';
$lang['plugins']			= 'Plugins';
$lang['template']			= 'Plantilla';
$lang['templates']			= 'Plantillas';
$lang['values']				= 'Valores';

?>
