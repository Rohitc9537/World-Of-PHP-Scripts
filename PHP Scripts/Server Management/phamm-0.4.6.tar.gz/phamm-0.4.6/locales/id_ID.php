<?php

// PDNS Plugin
$lang["add_zone"]		= 'Tambah Zone';
$lang["dns_only"]		= 'DNS Saja';
$lang["or"]				= 'atau';
$lang["a_record"]		= 'Rekaman (IP)';
$lang["c_name_record"]	= 'cNAME (Alamat)';
$lang["modified"]	= 'Rubah';
$lang["not_modified"]	= 'Batal';

?>
