<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @package Phamm
* @subpackage locale
* @author Igor V. Gots <igor gots.ru>
**/

// Russian
$lang['server']				= 'Сервер';
$lang['domain']				= 'Домен';
$lang['domain_property']	= 'Свойства домена';
$lang['domains']			= 'Домены';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']= 'Postmaster пароль';
$lang['add_postmasters']	= 'добавить Postmasters';
$lang['catch_all']			= 'Получает все';
$lang['postmasters']		= 'Postmasters';
$lang['appoint_postmasters']= 'Appoint Postmasters';
$lang['search'] 			= 'Искать';
$lang['equals']				= 'Equals';
$lang['starts_with']		= 'Start with';
$lang['contains']			= 'Contains';
$lang['ends_with']			= 'Ends with';
$lang['sounds_like']		= 'Sounds link';
$lang['add_mail']			= 'Добавить адрес';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'Добавить алиас';
$lang['add_domain']			= 'Добавить домен';
$lang['accounts']			= 'Аккаунтов';
$lang['alias']				= 'Алиас';
$lang['aliases']			= 'Алиасов';
$lang['edit_accounts']		= 'Может редактировать аккаунты';
$lang['active']				= 'Активный';
$lang['domain_is_active']	= 'Домен активен';
$lang['account_is_active']	= 'Аккаунт активен';
$lang['alias_is_active']	= 'Алиас активен';
$lang['delete']				= 'Удалить';
$lang['confirm_delete']		= 'Подтвердить удаление';
$lang['delete_account']		= 'Удалить аккаунт';
$lang['delete_domain']		= 'Удалить домен';
$lang['delete_alias']		= 'Удалить алиас';
$lang['quota']				= 'Квота';
$lang['all']				= 'Все';
$lang['real_name']			= 'Реальное имя';
$lang['return_to']			= 'Вернуть в';
$lang['username']			= 'Имя пользователя';
$lang['login']				= 'Логин';
$lang['login_incorrect']	= 'Неверные имя пользователя или пароль, попробуйте снова';
$lang['modify_mail']		= 'Редактировать адрес';
$lang['modify_alias']		= 'Редактировать алиас';
$lang['modify_mails']		= 'Редактировать адреса';
$lang['modify_domains']		= 'Редактировать домены';
$lang['modify_aliases']		= 'Редактировать алиасы';
$lang['domain_is_not_valid']= 'Домен не верен!';
$lang['mail_is_not_valid'] 	= 'Адрес не верен!';
$lang['alias_is_not_valid'] = 'Алиас не верен!';
$lang['password_dont_match']= 'Пароль не совпадает';
$lang['password']			= 'Пароль';
$lang['repeat_password']	= 'Повторить пароль';
$lang['error_connection']	= 'Ошибка соединения';
$lang['destinations']		= 'Получатели';
$lang['add_destinations']	= 'Добавить получателя';
$lang['delete_destinations']= 'Удалить получателей';
$lang['deleting']			= 'Удаление';
$lang['check_all']			= 'Отметить всех';
$lang['virus_check']		= 'Антивирусная проверка';
$lang['spam_check']		= 'Проверка спама';
$lang['change_postmaster_password']	= 'Изменить пароль Postmaster\'a';
$lang['warning_postmaster_password']	= 'Внимание!';
$lang['error_config_file']	= 'Error. Config file don\'t found. Copy config.inc.php.template -> config.inc.php';
$lang['added']				= 'Added';
$lang['not_added']			= 'Not Added';
$lang['domain_modify']		= 'Modify Domain';
$lang['modify']				= 'Modify';
$lang['vacation']			= 'Vacation';
$lang["vacation_description"] = 'Vacation Description';
$lang["vacation_forward"]	= 'Vacation Forward';
$lang["vacation_info"]		= 'Vacation Info';
$lang["vacation_start"]		= 'Vacation Start';
$lang["vacation_end"]		= 'Vacation End';
$lang["check_to_activate"]	= 'Check to Activate';
$lang["check_to_deactivate"]= 'Check to Deactivate';
$lang["spamtaglevel"]		= 'Spam Tag Level';
$lang["spamtag2level"]		= 'Spam Tag2 Level';
$lang["spamkilllevel"]		= 'Spam Kill Level';
$lang["min"]			= 'Min';
$lang["max"]			= 'Max';
$lang["spam_control"]		= 'Spam Control';
$lang["low"]			= 'Low';
$lang["medium"]			= 'Medium';
$lang["high"]			= 'High';
$lang["very_high"]		= 'Very High';
$lang["return_to_domain"]	= 'Return to domain';

$lang["refresh_message"] = "Вы будете автоматически перенаправлены на новую страницу через несколько секундю.<br>
Если Ваш браузер не поддерживает перенаправление, нажмите на ";
$lang["missing_real_name"] = 'Отсутствует реальное имя';
$lang["max_mail"] = 'Max Mail';
$lang["max_alias"] = 'Max Alias';
$lang["max_quota"] = 'Max Quota';
$lang['edit_aliases']		= 'Can Edit Aliases';
$lang['edit']		= 'Редактировать';
$lang['plugin_problem']		= 'Plugin Problem!';

// PDNS Plugin
$lang["add_zone"]		= 'Add Zone';
$lang["dns_only"]		= 'DNS Only';
$lang["or"]				= 'or';
$lang["a_record"]		= 'A Record (IP)';
$lang["c_name_record"]	= 'cNAME (address)';
$lang["modified"]	= 'Modified';
$lang["not_modified"]	= 'Not Modified';

// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Форвард';

?>
