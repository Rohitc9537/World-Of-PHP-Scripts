<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* @version $Id: de_DE.php,v 1.3 2005/04/28 19:07:10 dankert Exp $
* @package Phamm
* @subpackage locale
* @author Jan Dankert <phamm-translation@jandankert.de> (Translator)
**/

// Deutsch
$lang['server']				= 'Server';
$lang['domain']				= 'Domain';
$lang['domain_property']	= 'Domain Eigenschaft';
$lang['domains']			= 'Domains';
$lang['postmaster']			= 'Postmaster';
$lang['postmaster_password']= 'Postmaster Kennwort';
$lang['add_postmasters']	= 'F&uuml;ge Postmaster hinzu';
$lang['catch_all']			= 'Fange alle (catch all)';
$lang['postmasters']		= 'E-Mail Verwalter';
$lang['appoint_postmasters']= 'E-Mail Verwalter bestimmen';
$lang['search'] 			= 'Suche';
$lang['equals']				= 'Ist gleich';
$lang['starts_with']		= 'Beginnt mit';
$lang['contains']			= 'Enth&auml;lt';
$lang['ends_with']			= 'Endet mit';
$lang['sounds_like']		= 'Ist &auml;hnlich wie';
$lang['add_mail']			= 'F&uuml;ge Mail hinzu';
$lang['email']				= 'E-mail';
$lang['add_alias']			= 'F&uuml;ge Alias hinzu';
$lang['add_domain']			= 'F&uuml;ge Domain hinzu';
$lang['accounts']			= 'Accounts';
$lang['alias']				= 'Alias';
$lang['aliases']			= 'Aliases';
$lang['edit_accounts']		= 'Kann Accounts bearbeiten';
$lang['active']				= 'Aktiv';
$lang['domain_is_active']	= 'Domain ist aktiv';
$lang['account_is_active']	= 'Account ist aktiv';
$lang['alias_is_active']	= 'Alias ist aktiv';
$lang['delete']				= 'L&ouml;schen';
$lang['confirm_delete']		= 'Best&auml;tige L&ouml;schen';
$lang['delete_account']		= 'L&ouml;sche Account';
$lang['delete_domain']		= 'L&ouml;sche Domain';
$lang['delete_alias']		= 'L&ouml;sche Alias';
$lang['quota']				= 'Quota';
$lang['all']				= 'Alle';
$lang['real_name']			= 'Echter Name';
$lang['return_to']			= 'Zur&uuml;ck zu';
$lang['username']			= 'Benutzername';
$lang['login']				= 'Anmelden';
$lang['login_incorrect']	= 'Falscher Benutzername oder falsches Kennwort, bitte nochmal probieren';
$lang['modify_mail']		= 'Bearbeite E-Mail';
$lang['modify_alias']		= 'Bearbeite Alias';
$lang['modify_mails']		= 'Bearbeite E-Mails';
$lang['modify_domains']		= 'Bearbeite Dom&auml;nen';
$lang['modify_aliases']		= 'Bearbeite Aliase';
$lang['domain_is_not_valid']= 'Domain ist nicht g&uuml;ltig!';
$lang['mail_is_not_valid'] 	= 'Mail ist nicht g&uuml;ltig!';
$lang['alias_is_not_valid'] = 'Alias ist nicht g&uuml;ltig!';
$lang['password_dont_match']= 'Kennwort stimmt nicht &uuml;eberein';
$lang['password']			= 'Kennwort';
$lang['repeat_password']	= 'Kennwort Wiederholung';
$lang['error_connection']	= 'Verbindungsfehler';
$lang['destinations']		= 'Ziele';
$lang['add_destinations']	= 'F&uuml;ge Ziel hinzu';
$lang['delete_destinations']= 'L&ouml;sche Ziel';
$lang['deleting']			= 'L&ouml;sche';
$lang['check_all']			= '&Uuml;berpr&uuml;fe alle';
$lang['virus_check']		= 'Pr&uuml;fe auf Virus';
$lang['spam_check']			= 'Pr&uuml;fe auf Werbung (<em>Spam</em>)';
$lang['change_postmaster_password']	= '&Auml;ndern des Postmaster-Kennwortes';
$lang['warning_postmaster_password']	= 'Achtung!';
$lang['error_config_file']	= 'Fehler! Konfigurationsdatei nicht gefunden. Kopiere <tt>config.inc.php.template</tt> -> <tt>config.inc.php</tt>';
$lang['added']				= 'Hinzugef&uuml;gt';
$lang['not_added']			= 'Nicht hinzugef&uuml;gt';
$lang['domain_modify']		= 'Bearbeiter Domain';
$lang['modify']				= 'Bearbeiten';
$lang['vacation']			= 'Vacation';
$lang["vacation_description"] = 'Abwesenheit Beschreibung'; // ADDED
$lang["vacation_forward"]	= 'Abwesenheit Weiterleitung';
$lang["vacation_info"]		= 'Abwesenheit Info';
$lang["vacation_start"]		= 'Abwesenheit Beginn';
$lang["vacation_end"]		= 'Abwesenheit Ende';
$lang["check_to_activate"]	= 'Aktivieren';
$lang["check_to_deactivate"]= 'Deaktivieren';
$lang["spamtaglevel"]		= 'Spam Tag Stufe';
$lang["spamtag2level"]		= 'Spam Tag-2 Stufe';
$lang["spamkilllevel"]		= 'Spam L&ouml;sch-Stufe';
$lang["min"]			= 'Min';
$lang["max"]			= 'Max';
$lang["spam_control"]		= 'Spam Kontrolle';
$lang["low"]			= 'Gering';
$lang["medium"]			= 'Mittel';
$lang["high"]			= 'Hoch';
$lang["very_high"]		= 'Sehr hoch';
$lang["return_to_domain"]	= 'Zur&uuml;ck zur Domain';
$lang["refresh_message"] = "Aktualisieren";
$lang["missing_real_name"] = 'Echter Name fehlt';
$lang["max_mail"] = 'Maximale Anzahl E-Mail Adressen';
$lang["max_alias"] = 'Maximale Anzahl Aliases';
$lang["max_quota"] = 'Maximale Gr&ouml;&szlig;e der Quota';
$lang['edit_aliases']		= 'Bearbeite Aliases';
$lang['edit']		= 'Bearbeiten';
$lang['plugin_problem']		= 'Problem in Plugin-Schnittstelle!';


// Other Plugins
$lang['mail']				= 'E-mail';
$lang['forward']			= 'Weiterleitung';
$lang['go_to']				= 'Gehe zu';

?>
