<?php
/**
* Check if Admin
*
* @package Phamm
*
* @return bool
**/

function isAdmin()
{
        $username_domain = explode("@", $_SESSION["login"]);

		if ($username_domain[1] == '')
			return TRUE;
		else
			return FALSE;
}
?>
