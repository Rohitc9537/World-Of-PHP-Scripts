<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print the Phamm menu plugins
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function menu_plugins ()
{
    global $p_name;
    global $p_label;
    global $p_minAuthLevel;
    global $domain;
    global $initial;

    echo ("\n\n<TABLE><TR>");
    for ($p=0; $p < count($p_name); $p++)
    {
		if ($_SESSION["AuthLevel"] >= $p_minAuthLevel[$p])
		{		
        if ($_SESSION["pn"] == $p_name[$p])
            echo ("<TD class=\"plugin_active\">");
        else
            echo ("<TD class=\"plugin\">");
        echo ("<A href=\"?pn=$p_name[$p]&domain=$domain&initial=".$initial."\">$p_label[$p]</A>");
        echo ("</TD>\n");
		}

    }
    echo ("</TR></TABLE>\n\n");
}

?>
