<?php

/**
* Print a select with languages
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function language_selector()
{
global $supported_languages;

$keys = array_keys($supported_languages);
$values = array_values($supported_languages);

    echo ("\n<FORM ACTION=\"".$_SERVER["PHP_SELF"]."\" method=\"GET\" name=\"lang\">");
    echo ("<SELECT name=\"language\" class=\"\"
          onChange=\"document.lang.submit()\">\n");
	
	for ($i=0; $i < count($keys); $i++)
	//while (list($value,$label)=each($supported_languages))
	{
		echo "<OPTION value=\"$keys[$i]\"";
		if ($keys[$i] == $_SESSION["language"])
			echo " SELECTED ";
		echo ">";
		echo	$values[$i];
		echo "\n";
	}

    echo "</SELECT>\n";
    echo "</FORM>\n\n";
}

?>
