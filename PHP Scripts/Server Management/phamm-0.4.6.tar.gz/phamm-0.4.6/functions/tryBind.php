<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Try to bind
*
* @package Phamm
*
* @param string login
* @param string password_login
* @return bool $r
**/

function tryBind(&$login,$password_login)
{
    global $connect;
    global $LDAP_BASE;

    // Extract the admin CN from BINDDN and define BINDDN
    $admincn1 = explode(',',BINDDN);
    $admincn2 = explode('=',$admincn1[0]);
	
    define(ADMINCN,$admincn2[1]);

    // Explode the login to get the username and the domain (if present)
    $username_domain = explode('@', $login);

    // Try a bind as manager
    if (($username_domain[0] == ADMINCN) && ($username_domain[1] == ""))
    {
        $r = @ldap_bind($connect, BINDDN, "$password_login");

        if ($r)
        {
            $_SESSION["AuthLevel"] = 6;
            return $r;
        }
    }

    // Append the default domain if defined
    // TODO prevent user with name == manager ?
    //&& defined(DEFAULT_DOMAIN))
    elseif ($username_domain[1] == "" && defined('DEFAULT_DOMAIN'))
    {
        $username_domain[1] = DEFAULT_DOMAIN;
        $login = $login.'@'.DEFAULT_DOMAIN;
    }

    // Try a bind as Virtual Admin
    // TODO
    elseif ($username_domain[1] == "" && !defined('DEFAULT_DOMAIN'))
    {
    	$r = @ldap_bind($connect, "cn=$username_domain[0],ou=admin,".SUFFIX, "$password_login");

    	if ($r)
        {
    		$_SESSION["AuthLevel"] = 4;
            return $r;
        }

    }

    // Try a bind as postmaster
    if ($username_domain[0] == 'postmaster')
    {
        $r = @ldap_bind($connect, "cn=postmaster,vd=$username_domain[1],$LDAP_BASE", "$password_login");

        if ($r)
        {
            $_SESSION["AuthLevel"] = 2;
            return $r;
        }

    }

    // Try bind as user (account or alias)
    else
    {
        $r = @ldap_bind($connect, "mail=$login,vd=$username_domain[1],$LDAP_BASE", "$password_login");

        if ($r)
        {
            $_SESSION["mail"] = $login;
            $_SESSION["AuthLevel"] = 0;
            return $r;
        }

    }

    return $r;

}

?>
