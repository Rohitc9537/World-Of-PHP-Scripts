<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Load the Phamm's plugins
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function load_plugins ()
{
    global $plugins;
    global $domain;
    global $mail;

    $mydir = opendir('../plugins');

	$p_name = array();
	$p_label = array();
	$p_callAddDomainFunction = array();
	$p_minAuthLevel = array();

    for ($i=0; $i < count($plugins); $i++)
    {
        // Require plugin info file
        if (file_exists("../plugins/$plugins[$i]/info.php"))
        {
            include ("../plugins/$plugins[$i]/info.php");
            $p_name[] = $name;
            $p_label[] = $label;
			$p_minAuthLevel[] = $minAuthLevel;

			// Prevent undefined variables in info.php file
			$name = NULL;
			$label = NULL;
			$callAddDomainFunction = 0;
			$minAuthLevel = NULL;
        }

        // Require plugin config file
        /*if (file_exists("plugins/$plugins[$i]/config.inc.php"))
        {
        	echo ("./plugins/$plugins[$i]/config.inc.php");
        	require ("./plugins/$plugins[$i]/config.inc.php");
        }*/
    }

	return array($p_name,$p_label,$p_callAddDomainFunction,$p_minAuthLevel);
}

?>
