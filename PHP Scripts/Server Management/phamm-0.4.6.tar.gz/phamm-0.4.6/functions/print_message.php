<?php
/**
* Print a formatted message
* 
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* 
* @param string $class The CSS style name
* @param string $message The message
* @return mix
**/

function print_message ($class,$message)
{
	echo ("<FONT class=\"$class\">$message</FONT><BR>");
}
