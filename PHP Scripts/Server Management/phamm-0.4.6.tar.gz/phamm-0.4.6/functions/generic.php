<?php
/**
* @package Phamm
**/

/**
* Delete LDAP entry recursive
*
* @author gabriel at hrz dot uni-marburg dot de
* http://it2.php.net/manual/it/function.ldap-delete.php
* 
* @param $ds
* @param string $dn The DN
* @param bool $recursive
* @return bool
**/

function myldap_delete($ds,$dn,$recursive=false)
{
   if($recursive == false)
   {
       return(ldap_delete($ds,$dn));
   }
   else
   {
       //searching for sub entries
       $sr=ldap_list($ds,$dn,"ObjectClass=*",array(""));
       $info = ldap_get_entries($ds, $sr);
       for($i=0;$i<$info['count'];$i++)
	   {
           //deleting recursively sub entries
           $result=myldap_delete($ds,$info[$i]['dn'],$recursive);
           if(!$result)
		   {
               //return result code, if delete fails
               return($result);
           }
       }
       return(ldap_delete($ds,$dn));
   }
}

?>
