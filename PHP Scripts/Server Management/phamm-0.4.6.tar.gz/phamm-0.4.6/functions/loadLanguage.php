<?php
/**
* Load Language from locale files
*
* @package Phamm
*
* @param string $new_language The new language selected by user
* @return array $lang The Translation
**/

function loadLanguage($new_language)
{
	global $language;
	global $supported_languages;

	// Set the language defined in config file
	if (!isset($_SESSION["language"]))
    		$_SESSION["language"] = $language;

	// Change language is permit with GET method
	// Supported Languages defined in config.inc.php
	//
	if ($new_language && in_array($_GET["language"],array_keys($supported_languages)))
	{
    	// Change the language in current SESSION
	    // could be different by the default language
    	$_SESSION["language"] = $new_language;
	}

	// Before always loads the English Language File
	require_once ('../en_GB.php');

	$locale = $_SESSION["language"];
	
	// Require locale file if exists and overwrite available translations
	if (file_exists("../locales/$locale.php") && $locale != 'en_GB')
	{
    	include ("../locales/$locale.php");
	}

	// Require local file from plugin if exists
	$pn = $_SESSION["pn"];
	
	// Before always loads the English Language File
	if (file_exists("../plugins/$pn/en_GB.php"))
		include ("../plugins/$pn/en_GB.php");
	
	if (file_exists("../locales/plugins/$pn/$locale.php") && $locale != 'en_GB')
	{
    	include ("../locales/plugins/$pn/$locale.php");
	}

	return $lang;
}
?>
