<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print a form to add or modify a domain
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
*
* @param string $domain_new
**/

function form_add_domain_2 ($domain_new,$phamm_domain)
{
global $lang;
global $action;
global $plugins;
global $p_label;
global $p_name;

?>

<?php echo $lang["postmaster_password"]; ?><BR>
<?php
if ($action == 'add_domain')
	echo $lang["warning_postmaster_password"];
?>

<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="add">
<INPUT type="hidden" name="action" value="<?php echo $action; ?>">
<INPUT type="hidden" name="step" value="2">
<INPUT type="hidden" name="domain_new" value="<?php echo $domain_new; ?>">
<TABLE class="data">
<TR><TD><?php echo $lang["password"]; ?></TD>
<TD><INPUT type="password" name="password1" value="" size="10" maxlength="15"></TD></TR>
<TR><TD><?php echo $lang["repeat_password"]; ?></TD>
<TD><INPUT type="password" name="password2" value="" size="10" maxlength="15"></TD></TR>

<?php
if ($action == 'add_domain')
{
	echo "<TR><TD><B>".$lang["templates"]."</B></TD>";
	echo "<TD><B>".$lang["plugins"]."</B></TD></TR>";

	for ($i=0; $i < count($plugins); $i++)
	{
		echo "<TR><TD align=\"right\">";
		plugin_templates($p_name[$i]);
		echo "</TD>";
		echo "<TD>";
		echo "<INPUT type=\"checkbox\" name=\"confirmAddDomainFunction[$p_name[$i]]\" value=\"1\"";
			echo " CHECKED ";
		echo ">";
		echo $p_label[$i];
		echo "</TD></TR>\n";
	}
	echo "</TD></TR>";

}

?>
</TABLE>
<INPUT type="submit" value="<?php echo $lang[$action]; ?>">
</FORM>

<?php

}
?>
