<?php
/**
 * Hashes a password and returns the hash based on the specified enc_type. 
 *
 * Original function from phpLDAPadmin project.
 *
 * @author The phpLDAPadmin development team
 * @package Phamm
 *
 * @param string $password_clear The password to hash in clear text.
 * @costant string $enc_type Standard LDAP encryption type which must be one of
 *          crypt, md5 or clear.
 * @return string The hashed password.
 */
function password_hash($password_clear)
{
	global $lang;
	
    $enc_type = strtolower(ENC_TYPE);
	
    switch($enc_type)
    {
        case 'crypt':
            $password_hash = '{CRYPT}'.crypt($password_clear);
            break;
			
        case 'md5':
            $password_hash = '{MD5}'.md5($password_clear);
            break;
			
        case 'clear':
            $password_hash = $password_clear;
            break;

        default:
            $password_hash = '{CRYPT}'.crypt($password_clear);
            break;
	}
	
	return $password_hash;
}
?>
