<?php

/* {{{ Copyright 
    Copyright (C) 2004, Bruno Pelaia.

    This file is part of PFLAdmin.

    PFLAdmin is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    PFLAdmin is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with PFLAdmin; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    }}} */

// {{{ refresh url, [force_meta, [seconds]]
/** Redirect a client to the specified url.
 *  The 'url' should be HTTP/1.1 compliant: it should start with the
 *  protocol specification.
 *  The 'force_meta' and 'seconds' parameter are optional.
 *  The 'force_meta' behaviour is assumed if headers have been already sent.
 *
 * @package Phamm
 * @param url         string  The page to redirect to
 * @param force_meta  boolean Whenever you need an HTML-meta tag or not
 * @param seconds     integer The amount of seconds to wait before
 */
function refresh ( $url, $force_meta = false, $seconds = 0 )
{
	global $lang;
	
	// Check the protocol
	if ($_SERVER['HTTPS'] == "on")
		$PROTOCOL = 'https';
	else
		$PROTOCOL = 'http';
	
    // HTTP/1.1 requires an absolute URI
    $uri = ereg ( '^http', $url ) ? $url : "$PROTOCOL://".
           $_SERVER['HTTP_HOST'];

	// Server Root Check
	if(dirname ($_SERVER['PHP_SELF']) != '' && dirname ($_SERVER['PHP_SELF']) != '/')
		$uri .= dirname($_SERVER['PHP_SELF']);
		
	$uri .= '/'.$url;

	if ( $force_meta || headers_sent () )
	{
    ob_clean ();
		echo "<html>
  <head>
    <META HTTP-EQUIV=\"Refresh\" CONTENT=\"${seconds}; url=${uri}\">
  </head>
  <body>
    <p>".$lang["refresh_message"]."
	<A href=\"".${uri}."\">link</A></p>
  </body>
</html>";
    ob_end_flush ();
	}
	else
	{
    ob_end_clean ();
		header ( "Location: ${uri}" );
	}
	exit;
}
// }}}

?>
