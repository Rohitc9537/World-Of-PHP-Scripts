<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Add a new domain
*
* Execute each pluging action, trough include - if exists - the
* file add_domain.php inside each plugins/PLUGIN_NAME/ directory
* 
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
* 
* @param string $domain_new The new domain
* @param string $password The password for admin the domain
* @param array $confirmAddDomainFunction The array to confirm each active plugin
* @return bool The result
**/

function add_domain ($domain_new, $confirmAddDomainFunction, $templates)
{
    global $connect;
    global $lang;
    global $LDAP_BASE;
    global $SUFFIX;
    global $editAccounts;
    global $editPostmasters;
    global $accountActive;
    global $plugins;
    global $p_name;
    global $p_label;
    global $p_callAddDomainFunction;

    for ($i=0; $i < count($plugins); $i++)
    {
		$name = $p_name["$i"];

        if ($confirmAddDomainFunction[$name])
        {
            // Include each plugin custom file
            if (file_exists('../plugins/'.$name.'/add_domain.php'))
            {
                if (DEBUG)
                    echo "execute PLUGIN".$name."<BR>";

                print_message('message',"Adding domain ".$name);
		
		if ($templates[$name] != 1)
		{
			if (file_exists('../plugins/'.$name.'/templates/'.$templates[$name].'.php'))
			{
		                print_message('message','(using '.$templates[$name].')');
        	        	include ('../plugins/'.$name.'/templates/'.$templates[$name].'.php');
			}
		}
				
                include ('../plugins/'.$name.'/add_domain.php');
            }
        }
    }
	
    echo "<A href=\"?domain=$domain_new\">".$lang["go_to"]." $domain_new</A><BR>";
}
?>
