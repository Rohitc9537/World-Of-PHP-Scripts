<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print a custom checkbox
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
*
* @param bool $bolean
* @param string $object
* @param string $name
* @param string $action
* @param int $reverse
**/

function true_false_box ($bolean, $object, $name, $action, $reverse)
{
    global $lang;
    global $domain;
    global $style;
    global $initial;

    if ($reverse == 1)
    {
        if ($bolean == "TRUE" || !isset($bolean))
            $bolean = "FALSE";
        elseif ($bolean == "FALSE")
        $bolean = "TRUE";
    }

    echo ("<TD class=\"box_$bolean\">");

    // Show checkbox for delete action or advanced view
    if (ADVANCED_VIEW || ($name == 'alias_delete' || $name == 'mail_delete' || $name == 'domains_delete'))
    {
        if (!ADVANCED_VIEW)
        {
            if ($bolean == "FALSE" ||  $name == 'alias_delete')
                echo ("<INPUT type='checkbox' name=\"$name".'[]'."\" value=\"$object\">");
        if ($bolean == "TRUE")
            echo "<FONT class='check'>".$lang["deleting"]."</FONT>";
        }
        elseif (ADVANCED_VIEW)
		{
		    echo ("<INPUT type='checkbox' name=\"$name".'[]'."\" value=\"$object\">");
			if ($bolean == "TRUE" && ($name == 'alias_delete' || $name == 'mail_delete' || $name == 'domains_delete'))
				echo "<FONT class='check'>".$lang["deleting"]."</FONT>";
						
		}

    }


    // Hide image for delete action
    if ($name != 'alias_delete' && $name != 'mail_delete' && $name != 'domains_delete')
    {
	echo ("<A href=\"?action=$action&$name"."[]=$object&domain=$domain&initial=$initial\">");
        echo ("<IMG src=\"./style/$style/img/$bolean.png\" alt=\"$bolean\" border='0'></A>");
    }

    echo ("</TD>");

}
?>
