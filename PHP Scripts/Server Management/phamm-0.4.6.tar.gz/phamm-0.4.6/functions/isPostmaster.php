<?php
/**
* Check if Postmaster
*
* @package Phamm
*
* @return bool
**/

function isPostmaster()
{
        $username_domain = explode("@", $_SESSION["login"]);

		if ($username_domain[0] == 'postmaster')
			return TRUE;
		else
			return FALSE;
}
?>
