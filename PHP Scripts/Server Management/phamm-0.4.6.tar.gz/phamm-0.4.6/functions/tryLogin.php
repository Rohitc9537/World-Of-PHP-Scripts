<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Try to login
*
* @package Phamm
* @todo Change matrix
*
* @param string $login
* @param string $password_login
* @return bool $tryBind
**/

function tryLogin($login,$password_login)
{
    global $connect;
    global $lang;

	// Sanitize input
	$login = strip_tags($login);
	$login = addslashes($login);
	$password_login = strip_tags($password_login);
	$password_login = addslashes($password_login);

    // Try a BIND
    $tryBind = tryBind($login,$password_login);

    // If credential is not OK, destroys session and print login form again
    if ($tryBind != '1')
    {
        // Log the failed login
        if (PHAMM_LOG >= 1)
            phamm_log ('login',$login,'try login',0);

        session_unset();
        session_destroy();

        echo "<FONT class=\"error\">".$lang['login_incorrect']."</FONT><BR>";
        form_login ();
        echo ("</BODY></HTML>");
        exit;
    }

    elseif ($tryBind)
    {
        $username_domain = explode("@", $login);

        // Write login and password in session data
        // The authLevel alreay written... by tryBind
        $_SESSION["login"]			= $login;
        $_SESSION["password_login"]	= $password_login;
        $_SESSION["username"]		= $username_domain[0];

        // If is not admin write the domain in session
        if ($username_domain[1])
            $_SESSION['domain']	= $username_domain[1];

        // Log the successful login
        if (PHAMM_LOG >= 1)
            phamm_log ('login',$_SESSION["login"],'try login',1);
    }

    return $tryBind;
}
?>
