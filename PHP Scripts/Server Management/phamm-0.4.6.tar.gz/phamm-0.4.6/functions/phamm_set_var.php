<?php
/**
* Set Phamm var
*
* @param string $name The variable name
* @param array $values Possible values
* @param string $methods @todo
* @return mixed
**/

function phamm_set_var($name,$values=null,$methods=null)
{
	if (isset($_GET[$name]))
		$_SESSION[$name] = $_GET[$name];
	elseif (isset($_POST[$name]))
		$_SESSION[$name] = $_POST[$name];
	
	// Prevent non wanted values
	if (is_array($values) && !in_array($_SESSION["$name"],$values))
		return false;
	
	if (isset($_SESSION[$name]))
		return $_SESSION[$name];
	
	return false;
}

?>
