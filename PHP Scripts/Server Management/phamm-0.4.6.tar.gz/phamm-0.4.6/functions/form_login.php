<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004,2005 Alessandro De Zorzi and Mirko Grava
 *
 * This file is part of Phamm.
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Print a form to do login
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

function form_login ()
{
global $lang;

if (isset($_POST["login"]))
	$login = $_POST["login"];
else
	$login = '';

?>

<A href="http://phamm.rhx.it/">
<IMG src="./img/phamm_100.png" alt="Phamm logo" border="0"></A>
<?php
if (HIDE_VERSION != 1)
{
	echo "<FONT class=\"note\">";
	echo "ver. ".VERSION;
	echo "</FONT>";
}
?>
<BR>
<FORM METHOD="POST" ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" name="login">
<!-- <INPUT type="hidden" name="action" value="login"> -->
<TABLE class="data">
<TR><TD><?php echo $lang["login"]; ?></TD>
<TD><INPUT type="text" size="25" name="login" value="<?php echo $login; ?>" maxlength="60"></TD></TR>
<TR><TD><?php echo $lang["password"]; ?></TD>
<TD><INPUT type="password" size="25" name="password_login" value="" maxlength="50"></TD></TR>
</TABLE>

<INPUT type="submit" value="<?php echo $lang["login"]; ?>">
</FORM>
<?php

}
?>
