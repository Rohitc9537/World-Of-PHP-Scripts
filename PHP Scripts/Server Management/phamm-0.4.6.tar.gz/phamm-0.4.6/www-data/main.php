<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* The main Phamm file with business logic
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

// Start the Session
session_start();

if (DEBUG)
    $time_start = microtime();

// Set the HTTP Charset Parameter as UTF-8
header("Content-type: text/html; charset=utf-8");

// Set the Main Variables with Method GET or POST or Both
// This variables can be used by all plugins

// *** action ***
if (isset($_POST["action"]))
	$action		= $_POST["action"];
elseif (isset($_GET["action"]))
    $action = $_GET["action"];
	
// *** step ***
if (isset($_POST["step"]))
	$step		= $_POST["step"];
else
	unset($step);

if (isset($_GET["initial"]))
	$initial	= (string)$_GET["initial"];
elseif (!isset($_GET["initial"]))
    $initial = (string)$_POST["initial"];
else
	$initial = "";

// *** dottld is .tld ***
if (isset($_GET["dottld"]))
	$dottld	= $_GET["dottld"];
else
	$dottld = '';

// *+*+* PLUGIN CONFIG AND FUNCTIONS *+*+*+*+*+*+*+*+*+*+*+*+*+*+*+ //

// Require the main Phamm config file if exists
if (file_exists('../config.inc.php'))
{
    require ('../config.inc.php');
}

// If the main Phamm config file don't exists
// redirect to setup.php to create it
else
{
    header("location:setup.php");
    exit();
}

// Require all functions
$mydir = opendir('../functions');
while($fn = readdir($mydir))
{
    if (substr($fn,-3) == 'php')
        require_once ("../functions/$fn");
}
closedir($mydir);

// Number of active plugins
$plugins_active_nr = count($plugins);

// Checks the active plugins
if ($plugins_active_nr > 1)
{
    define(USE_PLUGINS,1);
}

// Require the plugins config file (one for each plugin) if exist
if (USE_PLUGINS == 1)
{
    for ($i=0; $i < $plugins_active_nr; $i++)
    {
        if (file_exists("../plugins/$plugins[$i]/config.inc.php"))
        {
            require ("../plugins/$plugins[$i]/config.inc.php");
        }
    }
}

// If don't use plugins, require only the default plugin config file
else
{
    if (file_exists("../plugins/".DEFAULT_PLUGIN."/config.inc.php"))
        require ("../plugins/".DEFAULT_PLUGIN."/config.inc.php");
}

// Force HTTPS if required
if (FORCE_SSL == 1 && (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] != "on"))
{
    $url=$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
    header ("Location: https://$url");
}

// Change the current plugin name
if ($_GET["pn"])
    $_SESSION["pn"] = $_GET["pn"];

// Set the default plugin if unchanged
elseif (!isset($_SESSION["pn"]))
	$_SESSION["pn"] = DEFAULT_PLUGIN;

// Load translation
$lang = loadLanguage($_GET["language"]);

// Set the PHP ERROL_LEVEL for DEBUG
php_error_level ();

// Open the LDAP connection
$connect = @ldap_connect(LDAP_HOST_NAME,LDAP_PORT)
           or die ("$lang[error_connection]");
		   
ldap_set_option($connect,LDAP_OPT_PROTOCOL_VERSION,LDAP_PROTOCOL_VERSION);

// Read the header template
include ('./style/'.$style.'/header.html.php');

// *=*=*= LOGIN SECTION *=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*= //

// Check if login system is not disable
if (NOLOGIN != 1)
{
    // If not logged and login and password do not sent
    // show the login form
    if (!checkLogin() && !isset($_POST["login"]) && !isset($_POST["password_login"]))
    {
        form_login ();
        echo ("</BODY></HTML>");
        exit;
    }

    elseif (!checkLogin() && isset($_POST["login"]) || isset($_POST["password_login"]))
    {
        tryLogin ($_POST["login"],$_POST["password_login"]);
    }

    // Try Bind usign the variables in session
    if (checkLogin())
    {
        $r = tryBind ($_SESSION["login"],$_SESSION["password_login"]);
    }

    // Secure stuff (unused)
    if (!$r)
    {
        form_login ();
        echo ("</BODY></HTML>");
        exit;
    }

}

// *** domain ***
if (isset($_SESSION["domain"]))
    $domain		= $_SESSION["domain"];
elseif (isset($_GET["domain"]))
    $domain = $_GET["domain"];
elseif (isset($_POST["domain"]))
    $domain = $_POST["domain"];

// *** domain ***
if (isset($_SESSION["mail"]))
    $mail		= $_SESSION["mail"];
elseif (isset($_GET["mail"]))
    $mail = $_GET["mail"];

// *** initial ***

// If login system is unused set the values from config.inc.php
if (NOLOGIN == 1)
{
    // Extract the admin CN from BINDDN and define BINDDN
    $admincn1 = explode(',',BINDDN);
    $admincn2 = explode('=',$admincn1[0]);
	
    $_SESSION['login']		= $admincn2[1];
    $_SESSION['password_login']	= SECRET;
    $_SESSION['username']		= $admincn2[1];

    $r = tryBind ($_SESSION["login"],$_SESSION["password_login"]);

    // Secure stuff (unused)
    if (!$r)
    {
        form_login ();
        echo ("</BODY></HTML>");
        exit;
    }
}


// Funny host color
if (FUNNY_COLOR == 1)
{
    // Set a color from the hostname
    $host_color = host_color ($_SERVER["HTTP_HOST"]);
}

else
{
    $host_color = '#FFFFFF';
}

// Print link to logout
echo ("\n\n<TABLE width='100%'><TR align='right'>");
if (NOLOGIN != 1 && isset($_SESSION["login"]))
{
    echo ("<TD align='left'><A href='logout.php'>Logout (".$_SESSION["login"]." - ");
    echo $_SERVER["HTTP_HOST"]."</A>)";
}
echo ("<TD align='left' bgcolor=\"$host_color\" width=\"100\"></TD> ");

// Choose the language
echo "<TD>";

// A way to choose the language [select,links,none]
if (LANG_MENU == 'select')
    language_selector();

elseif (LANG_MENU == 'links')
while (list($value,$label)=each($supported_languages))
{
    echo "<A href=\"?language=".$value."\">$label</A> ";
}


echo ("</TD></TR></TABLE><HR>\n\n");

// Plugins menu
// Load plugin preference
$p_values = load_plugins ();

// Extract plugin info from Array 2D
$p_name = $p_values[0];
$p_label = $p_values[1];
$p_callAddDomainFunction = $p_values[2];
$p_minAuthLevel = $p_values[3];

if (USE_PLUGINS == 1)
{
    // Print the top Menu bar
    menu_plugins ();
}

if (DEBUG)
{
    echo "<TABLE border='1'><TR>";
    echo "<TD>action ".$action."</TD>";
    echo "<TD>step ".$step."</TD>";
    echo "<TD>domain: ".$_SESSION["domain"]."</TD>";
    echo "<TD><B>domain selected: ".$domain."</B></TD>";
    echo "<TD>login: ".$_SESSION['login']."</TD>";
    echo "<TD>username: ".$_SESSION['username']."</TD>";
    echo "<TD>mail: ".$mail."</TD>";
    echo "</TR></TABLE>";
}

// Navigation links
echo ("<DIV class='navigation'>");
echo ("<A href='?initial='>$lang[all] $lang[domains]</A> ");

if (!$domain)
{
    while (list($value,$label)=each($tld))
    {
        if ($label != $dottld)
            echo "<A href=\"?dottld=$label\">$label</A>"." ";
        else
            echo "<FONT class=\"warning\">$label</FONT>"." ";
    }
}

elseif ($domain)
    echo (" &gt; <A href=\"?domain=$domain\" class=\"warning\">$domain</A> ");

if (isset($mail))
    echo " &gt; ".$mail;

echo ("</DIV>");

// Print the initials to varius search
if (!isset($_GET["mail"]) && !($_SESSION["pn"] == 'pdns' && $domain) && !$mail)
    initials ($initial);

// ############################### ADD DOMAIN #########################
if (isset($_POST["domain_new"]) && $action=='add_domain')
{
    // Check the domain syntax
    $domain_valid = checkSyntax('domain', $_POST["domain_new"]);

    // The domain is not valid
    if (!$domain_valid)
    {
        echo ("<FONT class='error'>$domain_new $lang[domain_is_not_valid]</FONT>");
    }

    elseif ($action=='add_domain' && $domain_valid)
    {
        // Second step
        if ($step != '2')
        {
            $hideBody = 1;
            form_add_domain_2 ($_POST["domain_new"],$_POST["phamm_domain"]);
        }

        // Password is wrong
        elseif ($step == '2')
        {
            if (!password_valid($_POST["password1"],$_POST["password2"]))
            {
                $hideBody = 1;
                echo ("<FONT class='error'>$lang[password_dont_match]</FONT><BR>");
                form_add_domain_2 ($_POST["domain_new"],$_POST["phamm_domain"]);
            }

            // Password is valid
            elseif (password_valid($_POST["password1"],$_POST["password2"]))
            {
                $hideBody = 1;
                add_domain ($_POST["domain_new"], $_POST["confirmAddDomainFunction"],$_POST["templates"]);

                if (PHAMM_LOG >= 1)
                    phamm_log ($_SESSION["pn"],$_SESSION["username"],$action,$do);
            }
        }
    }
}

if (!isset($hideBody))
{
    if (!$domain)
        form_add_domain ($domain);

    // Plugin includer
    if ($_SESSION["pn"])
    {
        echo "<TABLE class='plugin_body'><TR><TD>";
        if (file_exists("../plugins/".$_SESSION["pn"]."/main.php"))
        {
            include ("../plugins/".$_SESSION["pn"]."/main.php");
        }

        else
        {
            print_message('error',$lang["plugin_problem"]);
        }

        echo "</TD></TR></TABLE>";
    }

}

// Close the connection
ldap_close($connect);

if (DEBUG)
{
    $time_end = microtime();
    echo "<HR>";
    echo ($time_end-$time_start);
}

// Include footer templates
include ('./style/'.$style.'/footer.html.php');

?>
