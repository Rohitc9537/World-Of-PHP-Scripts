<?php

// Redirect to main file
header('Location: main.php');

?>
<html></html>
