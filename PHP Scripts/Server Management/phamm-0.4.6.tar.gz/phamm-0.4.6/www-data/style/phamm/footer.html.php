<HR>
<A href="<?php echo ORG_URL; ?>" target="_blank">
<IMG src="<?php echo ORG_LOGO; ?>"
width="<?php echo ORG_LOGO_WIDTH; ?>"
height="<?php echo ORG_LOGO_HEIGHT; ?>"
alt="<?php echo ORG_TITLE; ?>" border="0"></A>
<?php
if (HIDE_VERSION != 1)
{
	echo "<FONT class=\"note\">Phamm";
	echo " ver. ".VERSION;
	echo "</FONT>";
}
?>
</BODY>
</HTML>
