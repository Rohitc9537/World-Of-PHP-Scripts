<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<TITLE><?php echo ORG_TITLE; ?></TITLE>
<LINK rel="stylesheet" href="./style/<?php echo $style; ?>/main.css" media="screen">
<LINK rel="icon" href="./img/phamm_icon.png" type="image/png">
	<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
	<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
	<META NAME="GOOGLEBOT" CONTENT="NOARCHIVE, NOFOLLOW">
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<SCRIPT type="javascript" src="web/functions.js"></SCRIPT>
<!--[if gte IE 5.5000]>
<SCRIPT type="text/javascript" src="web/pngfix.js"></SCRIPT>
<![endif]-->
<?php
// Page where sf() are required
$form_sf = array('add_mail','add_alias');

echo "</HEAD>";
if (in_array($action,$form_sf))
	echo "<BODY onLoad=\"sf()\">";
else
	echo "<BODY>";
