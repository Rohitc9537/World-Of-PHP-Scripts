<?php
/*
 * Phamm - http://phamm.rhx.it - <phamm@rhx.it>
 * Copyright (C) 2004-2005 Alessandro De Zorzi and Mirko Grava
 *  
 * Phamm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Phamm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/**
* Do logout (destroy session)
*
* @package Phamm
* @author Alessandro De Zorzi <adezorzi@rhx.it>
**/

session_start();
	
	session_register("login");
	session_register("password_login");
	session_register("username");
	session_unset();
	session_destroy();	
?>
<html>
<head>
<title>Logout from Phamm</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="refresh" content="2;URL=index.php">
</head>

<body>
Logout from Phamm
</body>
</html>
