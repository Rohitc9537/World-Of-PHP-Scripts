<?php

// Redirect to main file
header('Location: www-data/main.php');

?>
<html></html>
