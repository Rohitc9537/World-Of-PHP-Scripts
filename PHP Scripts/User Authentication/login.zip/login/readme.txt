Simple Login Class v.1.0
Developed By: Jairus T. Bondoc jairusbondoc@yahoo.com
made in the Philippines

Usage:
see index.php