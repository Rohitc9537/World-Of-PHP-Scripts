ALTER TABLE `foo_sessions` CHANGE `addr` `addr` VARCHAR(100) NOT NULL 
