<?

session_start(install);

?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
</head>

<body>

<p>
<textarea rows="47" name="S1" cols="120" style="font-family: Tahoma; font-size: 8pt">$_SESSION[config]</textarea></p>

</body>

</html>