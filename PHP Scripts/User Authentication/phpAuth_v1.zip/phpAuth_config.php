<?

////////////////////////////////////
// Configuration file for phpAuth //
////////////////////////////////////

$database_name = "members.txt"; // Make sure you include the .txt in your database name

$login_redirect = "restricted_area_1.php"; // page to directed to when logged in
$logout_redirect = "index.php"; // redirect to your own logout page.

?>