<html> 
<head> 
<title>Main Admin Page</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
</head> 

<body> 
<div align="center" class="style1">
<p><B><i><font size="+3">ANGELINAPROTECT ADMIN PANEL</font></I></B></p> 
 
<p><a href="logout.php">Logout</a>
<b>|</b>
<a href="members.php">Members</a>
<b>|</b>
<a href="addmembers.php">Add new member</a> </center>