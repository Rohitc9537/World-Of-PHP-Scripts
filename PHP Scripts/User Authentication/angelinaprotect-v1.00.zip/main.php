<?php 
require("protect.php"); 
include('header.php');
?> 
<p>This is the main user page. <p> You are free to add as many pages as you want.<br> Only remember this:<br><i> the first line of the code MUST be</I> </p> 
<font color=red>&lt;?php require('protect.php');?&gt;</font>
<p>&nbsp;</p> 
</body> 
</html> 
<?php 
include('footer.php');
?>