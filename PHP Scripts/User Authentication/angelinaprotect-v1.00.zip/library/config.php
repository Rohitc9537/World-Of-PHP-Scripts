<?
$dbhost = "localhost";
$dbname = "database";
$dbuname = "root";
$dbpass = "";
?>
