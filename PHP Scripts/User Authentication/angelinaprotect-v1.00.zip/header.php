<html> 
<head> 
<title>User Section</title> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
</head> 

<body> 
<div align="center" class="style1">
<p><B><i><font size="+3">ANGELINAPROTECT USER SECTION</font></I></B></p> 
 
<p><a href="logout.php">Logout</a>
<b>|</b>
<a href="main.php">Page 01</a>
<b>|</b>
<a href="main02.php">Page 02</a> </center>