////////////////////////////////
//                            //
//   Angelina Protect V1.00   //
//                            //
//   Made By Mihailo Jevtic   //
//    www.belgradecafe.com    //
//                            //
// webmaster@belgradecafe.com //
//                            //
//        2005-05-26          //
//                            //
////////////////////////////////


This script was created to protect user sections of your website.

There is two sections :
- Admin section
- User section

From admin section you can manafe users, add new or delete old members.

Your default admin login is 
USER: admin
PASS: admin
Dont forget to change it!!!

Your default user login is 
USER: user
PASS: user

You can add as many pages as you want in your user section.

Your page must be :
yourpage.php

First line of the code MUST be :
<?php require("protect.php"); ?>

After first line you can add what ever you want.

//////////////////
//HOW TO INSTALL//
//////////////////

1. Edit config.php from library directory.
2. Edit tables.sql -> change admin password.
3. Set up tables using tables.sql
4. login to admin section at http://www.yourdomain.com/admin/login.php and manage users
5. add as many pages as you want
6. And dont forget to invite me to see and email me with your comments
