<?php
/* secret.php
 CONSTANT DECLARATIONS - DO NOT CHANGE UPPERCASE CONSTANTS.
 Change lowercase values only
*/
/* Administration */
define("ADMINUSER", "admin"); /* your administration login name - modify - you make it up */
define("ADMINPASSWORD", "admin"); /* your administration password - modify - you make it up */
/* below is the webpage you will go to if your login is successful */
define("ADMINHOME", "admin.php"); /* your administration page name - modify - the page you go to if the login is successful: Example: admin.php */
?>