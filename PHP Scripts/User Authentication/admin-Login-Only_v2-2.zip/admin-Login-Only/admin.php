<?php require_once("adminOnly.php");?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<link rel="stylesheet" type="text/css" href="admin-login-only.css">

		<TITLE>admin-Login-Only - Admin Center</TITLE>

		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<meta name="author" content="Globalissa - Global I.S. S.A.">
		<meta name="generator" content="World Impact">
		<meta name="robots" content="NOINDEX,NOFOLLOW">
		<meta name="revisit-after" content="7 days">
		<meta name="distribution" content="Global">
		<meta name="rating" content="General">
		<meta http-equiv="expires" content="0">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">
		<meta name="resource-type" content="document">
</HEAD>

<BODY>



<!-- navigation - start -->
<div align="center">
	<a href="setup.html">Setup | </a> 
	<a href="protect.html">Protect | </a> 
	<a href="tips.php">Tips | </a> 
	<a href="vote.php">Vote | </a> 
	<a href="index.html">About</a> 
</div>
<br />
<!-- navigation - end -->



<h1>Admin Center</h1>
<p>
A PHP session controls the entrance to this page.
</p>

<!-- Your content goes here - start -->
<div align="center" style="color:green;font-weight:bold;font-size:11px;">&lt;!-- Your content goes here - start --&gt;</div>


<br />
<br />
<br />
<br />



<div align="center" style="color:green;font-weight:bold;font-size:11px;">&lt;!-- Your content goes here - end --&gt;</div>
<!-- Your content goes here - end -->
</div>
<br />
<br />






<table cellspacing=15 cellpadding=7 align="center">
<tr>
	<td>
		<img src="images/boxes/box_deluxe_admin-login-only_90x120.gif" width="90" height="120" border=0 title="admin-Login-Only - FREE Single user authentication">
		<div style="font-size:11px;">
			FREE Single user authentication
		</div>
	</td>
	<td>
		<a href="http://www.globalissa.com/showcase.php?n=1&p=30">
			<img src="images/boxes/box_deluxe_acl-only_120x150.gif" width="120" height="150" border=0 title="acl-only - RETAIL Multi-user authentication">
		</a>
		<div style="font-size:11px;">
			RETAIL Multi-user authentication
		</div>
	</td>
</tr>
</table>
<?php //phpinfo();?>


</body>
</html>