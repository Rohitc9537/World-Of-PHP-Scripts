<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<link rel="stylesheet" type="text/css" href="admin-login-only.css">

	<TITLE>admin-Login-Only - Vote</TITLE>

		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<meta name="keywords" content="admin-Login-Only, protect, secure, authenticate, verify, make sure, restrict, admin, only">
		<meta name="description" content="This file is setup.html. It describes how to setup the Globalissa.com software called admin-Login-Only. admin-Login-Only lets you easily protect any web page using a PHP session.">
		<meta name="author" content="Globalissa - Global I.S. S.A.">
		<meta name="generator" content="World Impact">
		<meta name="robots" content="NOINDEX,NOFOLLOW">
		<meta name="revisit-after" content="7 days">
		<meta name="distribution" content="Global">
		<meta name="rating" content="General">
		<meta http-equiv="expires" content="0">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">
		<meta name="resource-type" content="document">
</HEAD>


<BODY>


<!-- navigation - start -->
<div align="center">
	<a href="setup.html">Setup | </a> 
	<a href="protect.html">Protect | </a> 
	<a href="tips.php">Tips | </a> 
	<a href="vote.php">Vote | </a> 
	<a href="index.html">About</a> 
</div>
<br />
<!-- navigation - end -->




<table width="800">
<tr>
	<td>
		<H1>Vote</H1>
		<H2>Cast your vote on Hotscripts</H2>
		<p>
			If you enjoy this FREEWARE vote now.

			<br />
			<br />
			<br />

			<!-- hotscripts code - start -->
<!------- Start of HTML Code ------->
<table width="150" border="1" cellpadding="0" cellspacing="0" bordercolor="#840300" bgcolor="#D70500">
  <form action="http://www.hotscripts.com/rate/16814.html" method="POST">
    <tr> 
      <td><table width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr align="center" bgcolor="#AA0400"> 
            <td colspan="2"><b><font color="#FFFFFF">Rate Our Program 
              <input type="hidden" name="external" value="1">
              </font></b></td>
          </tr>

          <tr> 
            <td align="right"><input type="radio" value="5" name="rate"></td>
            <td><font color="#FFFFFF">Excellent!</font></td>
          </tr>
          <tr> 
            <td align="right"><input type="radio" value="4" name="rate"></td>
            <td><font color="#FFFFFF">Very Good</font></td>
          </tr>
          <tr> 
            <td align="right"><input type="radio" value="3" name="rate"></td>

            <td><font color="#FFFFFF">Good</font></td>
          </tr>
          <tr> 
            <td align="right"><input type="radio" value="2" name="rate"></td>
            <td><font color="#FFFFFF">Fair</font></td>
          </tr>
          <tr> 
            <td align="right"><input type="radio" value="1" name="rate"></td>
            <td><font color="#FFFFFF">Poor</font></td>

          </tr>
          <tr align="center"> 
            <td colspan="2"><input name="submit2" type="submit" value="Cast My Vote!"></td>
          </tr>
        </table></td>
    </tr>
  </form>
</table>
<!------- End of HTML Code -------> 
		<!-- hotscripts code - end -->
		
		
		</p>	
	</td>
</tr>
</table>




<p><br></p>
<p><br></p>
<p><br></p>

</BODY>
</HTML>
