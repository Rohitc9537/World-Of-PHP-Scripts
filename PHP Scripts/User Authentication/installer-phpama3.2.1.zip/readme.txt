Hi,

Feel free to virus scan the .exe before running  ;-)

The installer will upload the files to your server and set the file permissions as required to complete the setup.

It will upload to a folder which, if it does not exist, it will be created named:  phpautomembersarea
(this can be renamed later)

When the installer has completed the upload, and file permission changes (to the file config.inc.php), the readme.html file will be opened in your browser to allow you to complete the setup.

Hope it works OK for you.

All the best

Dave
www.dwalker.co.uk

