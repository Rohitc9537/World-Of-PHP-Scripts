<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>fp_Form - template</title>
</head>

<body>
<?php
$path = dirname(__FILE__);

//include($path.'\helpfile_fp_Form.php');
include('fp_Form.php');

$f = new fp_Form('c:/apache2/htdocs/filepocket/public_html/');

$f->help('help');
?>
<p style="text-align:center"><a href="#">Top</a></p>
<p>&nbsp;</p>
</body>
</html>
