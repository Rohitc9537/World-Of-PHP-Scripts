<?php
/*
 * Declare Regular Expression patterns
 */
$regex_patterns['username'] = '/^[^\W]{5,16}$/';
// Alphanumeric '_' between 5 and 16 chars 

$regex_patterns['email'] = '/(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})/';
// regexlib.com Darren Neimke

$regex_patterns['emailorblank'] = '/(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})|(^\s*$)/';
// Email or blank

$regex_patterns['positive_number'] = '/([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/';
// modified from http://www.regular-expressions.info/floatingpoint.html

$regex_patterns['negpos_numbers'] = '/[-+]?([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/';
// Negative or positive, integer or floating point thanks to: http://www.regular-expressions.info/floatingpoint.html

$regex_patterns['nonempty'] = '/\S/';
// Any character but no tab, white space or new line character, not blank.

/* ***
// Filepocket > fp_Form version 0.5.10E (August 10, 05)
// PHP web form creation and validation class
// By Edward Hew <edward@filepocket.org>
// http://www.filepocket.org/rack/fp_Form/
// LGPL Licence

Working on a rewrite of this class in my free time.
*** */

class fp_Form
{
	var $f_method = '', $show_counters = '', $subgroup = 0, $subgroup_toggle = 0, $validate_check = -1, $f_validate = false, $required_array = array(),
	$submission_counted = 0, $js_validate_name = '', $ques_ico = '', $g_submit = '', $base_path = '', $show_alert_hdr = '', $group = array(),
	$gethelp = '', $helpfile = '', $show_req_line = '', $show_label = '', $accesskey = '', $tabindex = '', $tabindex_mem = array(), $htmlpage_encoding,$multiplart = '', $file_types = array(), $upload_dir = '',
	$external_crosscheck_msg = '';
	var $validate_alert_bgcolor = '#FCFFBC', $validate_pass_bgcolor = '#ffffff'; 
	var $as  = '<span class="failed">', $ae  = '</span>';

	function fp_Form( $path = '', $show_req_line = 'bottom', $show_label = true )
	{
		$this->ques_ico = "<img src='".$path."images/ques_mark.png' alt='(?)' border='0' />";
		$this->show_req_line = $show_req_line;
		$this->show_label = $show_label;
	}


	function form_start($action='',$nameid='',$method='post',$validate=false,$etc='') // PUBLIC
	{
		global $messages_fp_Form;
		static $counter = 0; $validate_eh = '';

		if( $nameid === '' )
			$nameid = 'form'.++$counter;

		$this->js_validate_name = 'validate_'.$nameid.'()';
		$this->f_method = $method;

		if( $method === 'post' )
		{
			$this->g_submit =& $_POST;
			$this->submission_counted = count($_POST);
		}
		else
		{
			$this->g_submit =& $_GET;
			$this->submission_counted = count($_GET);
		}

		if( $validate === true )
		{
			$validate_eh = ' onsubmit="return '.$this->js_validate_name.'"';
			$this->f_validate = true;
		}

		$this->form_name = $nameid;
        	$this->f_start = '<form id="'.$nameid.'" action="'.$action.'" method="'.$method.'" '.$etc.$validate_eh.'>
		<input type="hidden" name="'.$nameid.'" value="true" />'."\n";

		if( $validate === true && $this->show_req_line === 'top' )
			$this->f_start .= '<div class="req_line">'.sprintf($messages_fp_Form['required_line'],$messages_fp_Form['required_symbol']).'</div>';

		return $this->f_start;
	}


	function tabindex($num)
	{
		if(is_numeric($num))
			$this->tabindex = $num;
		else
			$this->tabindex = false;
	}


	function accesskey($key)
	{
		if(is_string($key))
			$this->accesskey = $key;
		else
			$this->accesskey = false;
	}


	function fieldset($action,$legend='',$etc='') // PUBLIC
	{
		$output = '';
		if($action == 'start')
		{
			$output = '<fieldset '.$etc.'>';
			if ($legend != '') $output .= '<legend>'.$legend."</legend>\n";
			$pos = 'fieldset_start';
		}
		else if($action == 'end')
		{
			$output = '</fieldset>';
			$pos = 'fieldset_end';
		}
		else
		{
			echo "<strong>Warning!</strong> fieldset object action only accepts 'start' and 'end' as first parameter<br />
			eg: fieldset('start','Fieldset Legend','class=\"section1\")";
		}
		$this->fields[] = array('name'=>'','label'=>'','right'=>'','required'=>'','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>$pos,'fieldset'=>$output);
	}


	function do_label($name,$label,$element_type,$required='',$left_extra='')
	{
		global $messages_fp_Form;
		$dlabel_extra = ''; $dlabel = '';
		$this->check_range_error($name,$element_type,$required);
		if( $label !== '' && $this->show_label == true )
		{
			if( is_array($label) ) 
			{
				$dlabel = $label[0];
				$dlabel_extra = $label[1];
			}
			else
				$dlabel = $label;
			if( $required!='' && $this->f_validate == true )
			{
				$show_ast = "<span class=\"req\">".$messages_fp_Form['required_symbol']."</span>";
				$s_start = '<strong>'; $s_end = '</strong>';
			}
			else
			{
				$show_ast = ''; $s_start = '';
				if( $dlabel !== '&nbsp;' )
					$s_end = ':';
				else $s_end = '' ;
			}
			if( $label == '&nbsp;' || $dlabel == '' || $element_type === 'radio' || $element_type === 'checkbox' || $element_type === 'textarea' )
				$label_check = '';
			else $label_check = ' for="'.$name.'"';
			
			return ('<label'.$label_check.'>'.$s_start.$dlabel.$s_end.$show_ast.$dlabel_extra.$left_extra.' </label>'."\n");
		} else
			return '';
	}


	function do_columns( $name, $initially_checked, $list_array, $columns, $id_name, $type )
	{
		$output = '';
		$clean_name = str_replace('[]','',$name);// strip []
		$num_items = count($list_array);
		$each_col = ceil( $num_items / $columns );
		$pointer = $each_col;

		$output .= "\n".'<table class="form_columns" summary="" id="'.$id_name.'">'."\n  <tr>\n";	
		$i = 0; $j = 1; $starter = true; $end = true;
		while (list($key, $val) = each($list_array))
		{
			if( $columns >= $j )
			{
				if( $starter == true )
					$output .= "\t<td>";
					
				if( $pointer >= ++$i )
				{
					if(is_array($val))
					{
						$etc = @$val[1];
						$val = $val[0];
					}
					else
					{
						$val = $val;
						$etc = '';
					}
					if($type=='radio')
					{
						if($initially_checked == $val) $checked = ' checked="checked"'; else $checked = '';
							$output .= '<input type="radio" name="'.$name.'" id="'.$clean_name.'_'.$key.'" value="'.$val.'"'.$checked.' '.$this->tabindex_process().' '.$etc.' /><label class="inline" for="'.$clean_name.'_'.$key.'">'.$val.'</label><br />';
					}
					else if($type=='checkbox')
					{
						if( @in_array($key,$initially_checked) )
							$checked = ' checked="checked"'; else $checked = '';
						$output .= '<input type="checkbox" name="'.$name.'[]" id="'.$clean_name.'_'.$key.'" value="'.$key.'"'.$checked.' '.$this->tabindex_process().' '.$etc.' /><label class="inline" for="'.$clean_name.'_'.$key.'">'.$val.'</label><br />';
					}
					$starter = false;
					$end = false;
				}
					
				if( $pointer == $i )
				{
					++$j;
					$output .= "</td>\n";
					$starter = true;
					$end = true;
					$pointer = $each_col * $j;
				}
			}
		}
		if($end == false)
			$output .= '</td>';

		$output .= "\n  </tr>\n</table>\n";
		return $output;
	}


	function wrong_type($type,$name)
	{
		echo '<strong style="color:red">**Alert**</strong> Wrong field type "'.$type.'" for field name <strong>'.$name.'</strong>';
	}


	function tabindex_process()
	{
		if( $this->tabindex !== false )
		{
			if(in_array($this->tabindex,$this->tabindex_mem))
				echo '<strong>Warning!</strong> tabindex '.$this->tabindex.' already used on this form!';
			else 
			{
				$this->tabindex_mem[] = $this->tabindex;
				$tabindex_relay = ' tabindex="'.($this->tabindex).'"';
				++$this->tabindex;
			}
		}
		else
		{
			$this->tabindex = false;
			$tabindex_relay = '';
		}
		return $tabindex_relay;
	}


	function accesskey_process($label)
	{
		$accesskey_relay = '';
		if( $this->accesskey !== false )
		{ 	// underline access key character
			// Clear the first TAG
			$pattern = '/(>[^<]*)('.$this->accesskey.')([^<>]*)/i';
			if(is_array($label))
			{
				// Grab the general area, if no match skip
				preg_match($pattern, $label[1], $matches , PREG_OFFSET_CAPTURE, 6);

				$str1 = preg_replace('/'.$this->accesskey.'/','<u title="Alt/Cmd key + &#39;'.$this->accesskey.'&#39;">'.$this->accesskey.'</u>', $matches[0][0], 1);
				$label[1] = str_replace($matches[0][0],$str1,$label[1]);
				$accesskey_relay = ' accesskey="'.$this->accesskey.'"';
				$this->accesskey = false;
			}
			else
			{
				$pattern = '/'.$this->accesskey.'/i';
				$label = preg_replace( $pattern, '<span class="u" title="Alt/Cmd key + &#39;'.$this->accesskey.'&#39;">'.$this->accesskey.'</span>', $label,1 );
				$accesskey_relay = ' accesskey="'.$this->accesskey.'"';
				$this->accesskey = false; // reset variable
			}
		}
		return (array('label'=>$label,'accesskey_line'=>$accesskey_relay));
	}


	function text_field($type,$label,$name,$value='',$required='',$size='20',$maxlength='',$helper='',$etc='',$post_text='')
	{
		$set_alertdiv = ''; $ques_ico = ''; $s = ''; $e = '';
		
		if( $type != 'text' && $type != 'password')
			$this->wrong_type($type,$name);

		if( $required !== '' || $this->submission_counted > 0 )
		{
			$check_submitted = $this->check_submission($name,$value,'text',$required);
			$this->required_fields[] = $name;
			if( count($check_submitted) > 0 )
				$value = @$check_submitted[$name]['value'];

			if( @$check_submitted[$name]['err_msg'] != '' )
			{
				$s = $this->as;
				$e = $this->ae;
			}
		}

		$accesskey_check = $this->accesskey_process($label);
		$left = $this->do_label($name,$accesskey_check['label'],$type,$required);
		$right = $s.'<input type="'.$type.'" name="'.$name.'" id="'.$name.'" value="'.$value.'" size="'.$size.'" maxlength="'.$maxlength.'" '.$etc.$accesskey_check['accesskey_line'].$this->tabindex_process().' />'.$e;

		$this->jsvalidate[$name] = array('label'=>$label,'type'=>'text','validate'=>$required,'subgroup'=>$this->subgroup);

		$this->fields[] = array('name'=>$name,'label'=>$left,'right'=>$right,'required'=>$required,'alert'=>@$check_submitted[$name]['err_msg'],'helper'=>$helper,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function text($label,$name,$value='',$required='',$size='20',$maxlength='',$helper='',$etc='',$post_text='') // PUBLIC
	{
		$this->text_field('text',$label,$name,$value,$required,$size,$maxlength,$helper,$etc,$post_text);
	}


	function password($label,$name,$value='',$required='',$size='20',$maxlength='',$helper='',$etc='',$post_text='') // PUBLIC
	{
		$this->text_field('password',$label,$name,$value,$required,$size,$maxlength,$helper,$etc,$post_text);
	}


	function hidden($name, $value='', $etc='') // PUBLIC
	{
		$check_submitted  = $this->check_submission($name,$value,'hidden','');
		if(count($check_submitted) > 0 )
			$value = $check_submitted[$name]['value'];
			
		$this->fields[] = array('name'=>$name,'label'=>'','right'=>'<input type="hidden" name="'.$name.'" id="'.$name.'" value="'.$value.'" '.$etc.' />'."\n",'required'=>'','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>'','fieldset'=>'');
	}


	function textarea( $label, $name, $value='' ,$required='' ,$cols='30' ,$rows='3' ,$helper='' ,$etc='', $post_text = '' ) // PUBLIC
	{
		global $messages_fp_Form;
		$left_extra = ''; $ques_ico = ''; $char_counter = false; $s = ''; $e = '';
		if( $required !== '' || $this->submission_counted > 0 )
		{
			$check_submitted  = $this->check_submission($name,$value,'textarea',$required);
			$this->required_fields[] = $name;

			if(count($check_submitted) > 0 )
				$value = @$check_submitted[$name]['value'];

			if( @$check_submitted[$name]['err_msg'] !== '' )
			{
				$s = $this->as;
				$e = $this->ae;
			}
		}

		if( is_numeric($required) )
		{
			$etc .= " onkeyup=\"countChars(this,'".$required."','".$this->form_name."','counter_".$name."','".$label."')\"";
			$left_extra = '<br /><span class="sublabel">'.sprintf($messages_fp_Form['characters_counter'],$required).'<script type="text/javascript"><!--'."\n\t".'document.write("<div>'.$messages_fp_Form['character_counter2']." <strong><span id='counter_".$name."'> </span></strong></div>".'");'."\n\t //--></script></span>";
			$this->show_counters .= 'countChars(document.getElementById("'.$this->form_name.'").'.$name.','.$required.',"'.$this->form_name.'","counter_'.$name.'","'.$label.'");';
			$char_counter = true;
		}
		$accesskey_check = $this->accesskey_process($label);
		$left = $this->do_label($name,$accesskey_check['label'],'textarea',$required,$left_extra);
		$right = $s.'<textarea name="'.$name.'" cols="'.$cols.'" rows="'.$rows.'" '.$etc.$accesskey_check['accesskey_line'].$this->tabindex_process().'>'.$value.'</textarea>'.$e;

		$this->jsvalidate[$name] = array('label'=>$label,'type'=>'textarea','validate'=>$required,'subgroup'=>$this->subgroup);

		$this->fields[] = array('name'=>$name,'label'=>$left,'right'=>$right,'required'=>$required,'alert'=>@$check_submitted[$name]['err_msg'],'helper'=>$helper,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function select( $label, $name, $initially_selected, $list_values, $required='', $helper='', $etc='', $post_text='', $mode='single', $rows=12 ) // PUBLIC
	{
		$ques_ico = ''; $name_checked=''; $s = ''; $e = '';

		if( $required !== '' || $this->submission_counted > 0 )
		{
			$check_submitted  = $this->check_submission($name,$initially_selected,$mode,$required);
			$this->required_fields[] = $name;

			if( count($check_submitted) > 0 )
				$initially_selected = @$check_submitted[$name]['value'];

			if( @$check_submitted[$name]['err_msg'] != '' )
			{
				$s = $this->as;
				$e = $this->ae;
			}
		}

		$multiple = ''; $size = '';
		if( $mode === 'multiple' )
		{
			$name_checked = $name.'[]';
			$multiple = ' multiple="multiple"';
			$size = ' size="'.$rows.'"';
		}
		else
		{
			$mode = 'select';
			$name_checked = $name;
		}
		
		$left = $this->do_label($name,$label,$mode,$required);

		$right = $s.'<select name="'.$name_checked.'" id="'.$name.'" '.$etc.$multiple.$size.' '.$this->tabindex_process().'>'."\n";

		foreach( $list_values as $key=>$val )
		{
			if ( @in_array($key, $initially_selected) )
				$selected = ' selected="selected"';
			else if ( $key == $initially_selected )
				$selected = ' selected="selected"';
			else
				$selected = '';

			$right .= "\t\t\t".'<option value="'.$key.'"'.$selected.'>'.$val.'</option>'."\n";
		}

		$right .= "\t\t".'</select>'.$e;
		if( is_array($label) )
			$label = $label[0];

		$this->jsvalidate[$name] = array( 'label'=>$label, 'type'=>$mode, 'validate'=>$required, 'subgroup'=>$this->subgroup );

		$this->fields[] = array( 'name'=>$name_checked, 'label'=>$left, 'right'=>$right, 'required'=>$required, 'alert'=>@$check_submitted[$name]['err_msg'], 'helper'=>$helper, 'post_text'=>$post_text, 'fieldset_pos'=>'', 'fieldset'=>'' );
	}


	function radio( $label, $group_name, $initially_checked, $radio_list_array, $required='', $position='horizontal', $helper='', $post_text='', $columns = '' ) // PUBLIC
	{
		global $messages_fp_Form;
		$lbreak = ''; $right = '';

		if($position=='vertical') $lbreak = '<br />';

		if( $required !== '' || $this->submission_counted > 0 )
		{
			$check_submitted = $this->check_submission($group_name,$initially_checked,'radio',$required);

			$this->required_fields[] = $group_name;

			if( count($check_submitted) > 0 )
			{
				if( empty($check_submitted[$group_name]['value']) )
				{
					$check_submitted[$group_name]['err_msg'] = $messages_fp_Form[$required];
					$initially_checked = '';
				}
				else
					$initially_checked = @$check_submitted[$group_name]['value'];
			}
		}

		$accesskey_check = $this->accesskey_process($label);
		$left = $this->do_label($group_name,$accesskey_check['label'],'radio',$required);

		if( $columns == '' )
		{
		   $right = '<div class="grouper" id="'.$group_name.'_span">'."\n";
		    foreach($radio_list_array as  $val => $name)
		    {
			if($initially_checked == $val)
				$checked = ' checked="checked"';
			else $checked = '';
			if(is_array($name))
			{
				$etc = @$name[1];
				$name = $name[0];
			}
			else
			{
				$name = $name;
				$etc = '';
			}
				$right .= "\t\t\t\t".'<input type="radio" name="'.$group_name.'" id="'.$val.'" value="'.$val.'"'.$checked.' '.$accesskey_check['accesskey_line'].
				$this->tabindex_process().' '.$etc.' /><label class="inline" for="'.$val.'">'.$name.'</label>';
				$right .= next($radio_list_array) ? $lbreak."\n":"\n";
		    }
		    $right .= "\t\t\t".'</div>';
		}
		else
		{
			if(!is_numeric($columns))
				echo 'Warning! Interger expected for field name '.$group_name;

			$right .= $this->do_columns( $group_name,$initially_checked,$radio_list_array,$columns,$group_name.'_span','radio' );
		}

		$this->jsvalidate[$group_name] = array('label'=>$label,'type'=>'radio','validate'=>$required,'subgroup'=>$this->subgroup);
		if(!is_array($radio_list_array))
		    echo $label.' Parameter 4 array expected.<br />';
		else
			$this->fields[] = array('name'=>$group_name,'label'=>$left,'right'=>$right,'required'=>$required,'alert'=>@$check_submitted[$group_name]['err_msg'],'helper'=>$helper,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function checkbox( $label, $group_name, $initially_checked_array, $checkbox_list_array, $required='', $position='horizontal', $helper='', $post_text='', $columns = '' ) // PUBLIC
	{
		$lbreak = ''; $right = '';
		if($position=='vertical') $lbreak = '<br />';

		if( $required !== '' || $this->submission_counted > 0 )
		{
			$counted_array = count($checkbox_list_array);
			$check_submitted = $this->check_submission($group_name,$initially_checked_array,'checkbox',$required,$counted_array);
			
			$this->required_fields[] = $group_name;
			if(count($check_submitted) > 0 )
				$initially_checked_array = @$check_submitted[$group_name]['value'];
		}
		$accesskey_check = $this->accesskey_process($label);

		$left = $this->do_label($group_name,$accesskey_check['label'],'checkbox',$required);

		if($initially_checked_array=='')
			$initially_checked_array = array();

		if( $columns == '' )
		{
		    $right = '<div class="grouper" id="'.$group_name.'_span">'."\n";
		    foreach( $checkbox_list_array as $val => $name )
		    {
			if(in_array($val,$initially_checked_array))
				$checked = ' checked="checked"';
			else
				$checked = '';
			if(is_array($name))
			{
				$etc = @$name[1];
				$name = $name[0];
			}
			else
			{
				$name = $name;
				$etc = '';
			}
			$right .= "\t\t\t\t".'<input type="checkbox" name="'.$group_name.'[]" id="'.$val.'" value="'.$val.'"'.$checked.' '.$accesskey_check['accesskey_line'].$this->tabindex_process().' '.$etc.' /><label class="inline" for="'.$val.'">'.$name.'</label>';
			$right .= next($checkbox_list_array) ? $lbreak."\n":"\n";
		    }
		    $right .= '</div>';
		}
		else
		{
			if(!is_numeric($columns))
				echo 'Warning! Interger expected for field name '.$group_name;
				$right .= $this->do_columns( $group_name,$initially_checked_array,$checkbox_list_array,$columns,$group_name.'_span','checkbox' );
		}

		$this->jsvalidate[$group_name] = array('label'=>$label,'type'=>'checkbox','validate'=>$required,'subgroup'=>$this->subgroup);

		if( !is_array($checkbox_list_array) )
			echo $group_name.' Parameter 4 array expected.<br />';
		else
			$this->fields[] = array('name'=>$group_name,'label'=>$left,'right'=>$right,'required'=>$required,'alert'=>@$check_submitted[$group_name]['err_msg'],'helper'=>$helper,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function button($type,$label,$name,$value_or_src,$etc='',$post_text='',$post_text_position='') // PUBLIC
	{
		$submit = '';
		if( $type!=='submit' && $type!=='button' && $type!=='reset' && $type!=='image' )
			$type = 'submit';

		$accesskey_check = $this->accesskey_process($label);
		$left = $this->do_label($name,$accesskey_check['label'],'button');

		if($post_text_position=='horizontal')
		{
			$submit .= '
<table summary="secondary action" class="form_button_table">
   <tr>
	<td>
';
		}
		if( $type === 'image' )
			$submit .='<input type="'.$type.'" name="'.$name.'" alt="'.$name.'" src="'.$value_or_src.'" '.$etc.$accesskey_check['accesskey_line'].$this->tabindex_process().' />';
		else
		$submit .='<input type="'.$type.'" name="'.$name.'" value="'.$value_or_src.'" '.$etc.$accesskey_check['accesskey_line'].$this->tabindex_process().' />';

		if($post_text_position=='horizontal')
		{
			$submit .= '
	</td>
	<td>
	'.$post_text.'
	</td>
   </tr>
</table>';
			// Post text reset
			$post_text = '';
		}
		$this->fields[] = array('name'=>$name,'label'=>$left,'required'=>'','right'=>$submit,'alert'=>false,'helper'=>false,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function browse( $label, $name, $required='', $MAX_FILE_SIZE=30000, $HTML_size = 20, $accept = '', $helper='', $etc='', $post_text='' )
	{
		static $counter = 0; $right = ''; $s = ''; $e = '';
		if( $this->upload_dir === '' ) // Print alert message if upload dir not set
			echo '<strong style="color:red"> Warning!</strong> Upload directory not defined. <br />$obj->set_upload_dir(upload_directory);';
		else if( !is_dir($this->upload_dir) )
			echo '<strong style="color:red"> Warning!</strong> Upload directory does not exist - '.$this->upload_dir.'<br />Set it with $obj->set_upload_dir(upload_directory);';
		$this->file_types = explode(',',$accept);
		$this->multiplart = 'enctype="multipart/form-data"';

		if( $required !== '' || $this->submission_counted > 0 )
		{
			$check_submitted = $this->check_submission($name,'','file',$required);
			$this->required_fields[] = $name;

			if(count($check_submitted) > 0 )
				$value = @$check_submitted[$name]['value'];

			if( @$check_submitted[$name]['err_msg'] !== '' )
			{
				$s = $this->as;
				$e = $this->ae;
			}
		}

		$this->jsvalidate[$name] = array('label'=>$label,'type'=>'file','validate'=>$required,'subgroup'=>$this->subgroup);

		$left = $this->do_label($name,$label,'button',$required);

		if( $counter++ === 0 )
		$right  = '<input type="hidden" name="MAX_FILE_SIZE" value="'.$MAX_FILE_SIZE.'" />'."\n\t\t";

		$right .= $s.'<input type="file" size="'.$HTML_size.'" name="'.$name.'" id="'.$name.'" accept="'.$accept.'" '.$etc.$this->tabindex_process().' />'.$e;
		$this->fields[] = array('name'=>$name,'label'=>$left,'right'=>$right,'required'=>$required,'alert'=>@$check_submitted[$name]['err_msg'],'helper'=>$helper,'post_text'=>$post_text,'fieldset_pos'=>'','fieldset'=>'');
	}


	function set_upload_dir($path)
	{
		$this->upload_dir = $path;
	}


	function form_end()
	{
		global $messages_fp_Form;
		$this->f_end .= "\n\n".'</form>'."\n";
		if( $this->f_validate === true && $this->show_req_line === 'bottom' )
			$this->f_end .= '<div class="req_line">'.sprintf($messages_fp_Form['required_line'], $messages_fp_Form['required_symbol']).'</div>';
		return $this->f_end;
	}


	function subgroup($toggle) // PUBLIC
	{
		static $nest_checks = 0;
		if( $nest_checks > 1 )
		{
			echo '<strong style="color:red">Oh!</strong> Cannot nest subgroups.';
		}
		if($toggle == 'start')
		{
			$this->subgroup = 'start';
			$this->fields[] = array('name'=>'','label'=>'','right'=>'startsubgroup','required'=>'','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>'','fieldset'=>'');
			++$nest_checks;
		}
		else if($toggle == 'end')
		{
			$this->subgroup = 'end';
			$this->fields[] = array('name'=>'','label'=>'','right'=>'endsubgroup','required'=>'','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>'','fieldset'=>'');
			$nest_checks = 0;
		}
		return $this->subgroup;
	}


	function group($toggle,$css='class="group"') // PUBLIC
	{
		static $nest_checks = 0; static $i = 0;
		if( $nest_checks > 1 )
		{
			echo '<strong style="color:red">**Alert**</strong> Cannot nest groups, sorry.';
		}
		if($toggle == 'start')
		{
			$this->group['toggle'] = 'start';
			$this->group[$i]['css'] = $css;
			$this->fields[] = array('name'=>'','label'=>'','right'=>'startgroup','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>'','fieldset'=>'');
			++$nest_checks; ++$i;
		}
		else if($toggle == 'end')
		{
			$this->group['toggle'] = 'end';
			$this->fields[] = array('name'=>'','label'=>'','right'=>'endgroup','alert'=>'','helper'=>'','post_text'=>'','fieldset_pos'=>'','fieldset'=>'');
			$nest_checks = 0;
		}
		return $this->group;
	}


	function display() // PUBLIC
	{
		global $messages_fp_Form;
		$halt_blocks = 0; $err_msg_span = ''; $f_helper = ''; $i = 0; $f_name = '';
		if($this->multiplart !== '')
			$this->f_start = str_replace('action=',$this->multiplart.' action=',$this->f_start);
		$output = "\n\n".$this->f_start;
		if( $this->f_start === '' )
			echo '<strong style="color:red">form_start()</strong> not defined!! <br />$obj->form_start( $action="", $name="", $method="post", $validate=false, $etc="" )';

		$counted = count($this->g_submit);
		if ( $counted > 0 )
			$output .=  '<div class="alert_header">';
		// Insert external error message header

		if( $this->validate_check > -1 )
			$output .= $messages_fp_Form['js_msg_start'];
		if ( $counted > 0 )
			$output .= '</div>';

		foreach( $this->fields as $key=>$val )
		{
			if($val['right'] === 'startgroup')
			{
				$output .= "\n\n\n".'<div '.$this->group[$i]['css'].'><!-- group START -->'; // start group
				++$i;
			}

			if( @$val['fieldset_pos'] === 'fieldset_start' )
				$output .= $val['fieldset'];
			else if( $val['label'] !== '' || $this->show_label === false )
				$output .= "\n".'<div class="fieldRow">'."\n\t".$val['label'];

			if( $halt_blocks === 'warmingup' )
				$halt_blocks = 'in_effect';

			if( $halt_blocks === 'begin' )
				$halt_blocks = 'warmingup';

			if( $val['label'] === '' && $val['right'] == 'startsubgroup' )
			{
				$output .= "\n".'<!-- Start Sub-grounp -->';
				$halt_blocks = 'begin';
			}

			if( $halt_blocks !== 'in_effect' && $val['label'] !== '' && $val['right'] != 'fieldset' )
				$output .= "\t".'<div class="fieldCell">';

			if( $val['right'] !== 'startsubgroup' && $val['right'] !== 'endsubgroup' && $val['right'] !== 'startgroup' && $val['right'] !== 'endgroup' )
			{
				$output .= $val['right'];

				if( $val['helper'] != '' && $halt_blocks === 'warmingup' )
				{
					$f_helper = $val['helper'];
				}
				if( $val['helper'] != '' && $halt_blocks !== 'warmingup' )
				{
					$output .= "\n\t".'<script type="text/javascript"><!--'."\n\t";
					$output .= 'document.write("<a href=\"#\" onclick=\"helper('."'".$this->form_name."','".$val['name']."'".');return false;\">'.$this->ques_ico.'</a>'.'");';
					$output .= "\n\t".'//--></script>';
					$f_name = $val['name'];
					$f_helper .= $val['helper'];
				}
				else
					$f_name = $val['name'];

				$output .= $val['post_text'];
				// External error msg
				if( @array_key_exists($val['name'], $this->external_crosscheck_msg) )
				{
					$val['alert'] = $this->external_crosscheck_msg[$val['name']]['errmsg'];
				}

				if( $val['alert'] !== false )
				{
					if( $this->show_label === false )
						$output .= "\n\t\t".'<div id="'.$val['name'].'_amsg" class="alertmsg">'.@$val['alert'].'</div>'."\n";
					
					if( $val['required'] !== '' )
					{
						$val['name'] = str_replace('[]','',$val['name']);
						$err_msg_span .= "\n\t\t".'<div id="'.$val['name'].'_amsg" class="alertmsg">'.@$val['alert'].'</div>';
					}
				}
			}

			if ( @$val['fieldset_pos'] === 'fieldset_end')
			{
				$output .= $val['fieldset'];
			}
			else
			{
			    if( $val['right'] === 'endsubgroup' && $halt_blocks === 'in_effect' )
			    {
					$halt_blocks = 0; // subgroup end

				if( $val['alert'] !== false )
					$output .= $err_msg_span."\n";
				if( $f_name !== '' && $f_helper !== '' )
				{
					$output .= "\n\t\t".'<noscript><div class="helper" style="display: block">'.$f_helper.'</div></noscript>';
					$output .= "\n\t\t".'<div class="helper" id="'.$f_name.'_helper">'.$f_helper."</div>";
				}
				$output .= "\n\t</div>\n</div>";
				// Reset variables
				$f_name = '';
				$f_helper = '';
				$err_msg_span = '';
					$output .= "\n".'<!-- End Sub-grounp -->';
			    }
			    else if( $val['label'] !== '' && $halt_blocks !== 'in_effect' && $halt_blocks !== 'warmingup' )
			    {
				if( $val['alert'] !== false )
					$output .= $err_msg_span;
				if( $f_name !== '' && $val['helper'] !== '' )
				{
					if( $f_helper !== '' )
					{
						$output .= "\n\t\t".'<noscript><div class="helper" style="display: block">'.$f_helper.'</div></noscript>';
						$output .= "\n\t\t".'<div class="helper" id="'.$val['name'].'_helper">'.$val['helper']."</div>";
					}
				}
				$output .= "\n\t</div>\n</div>\n\n";
				$err_msg_span = '';
			    }

			    if( $this->show_label === false )
			    	$output .= "\n</div>\n\n"; // End fieldRow block if show_label is false

			    if($val['right'] === 'endgroup')
			    {
				$output .= "</div><!-- group END -->\n"; // end group
			    }
			}
		}
		$output .= $this->form_end();

		if($this->show_counters != '')
		{
			$output .= '
<script type="text/javascript">
<!--
	var msgalerted = 0;
	'.$this->show_counters."\n\t\t\t".'
//-->
</script>';
		}
		return $output;
	}


	function validate_check()
	{
		if ( count($this->g_submit) > 0 && $this->validate_check < 0 )
			return true;
		else if ( count($this->g_submit) > 0 && $this->validate_check > -1 )
			return false;
	}


	function help($which='help') // PUBLIC
	{
		static $counter = -1;
		if( !is_array($this->helpfile) )
		{
			if( include_once(dirname(__FILE__).'\helpfile_fp_Form.php') )
				$this->helpfile =& $helpfile;
			else
				echo '<strong>Help file could not be found</strong>, <a href="www.filepocket.org/rack/fp_form/docs/">visit online documentation?</a>?';
		}
		if( is_array($this->helpfile) )
		{
			if( isset($this->helpfile[$which]) )
			{
				if( ++$counter < 1 )
				{
					echo $this->helpfile['css'];
				}
				if ( $which == 'css_selectors' )
				{
					$filepath = dirname(__FILE__);
					$filepath =  str_replace('\\','/',$filepath);
					
					$str = str_replace( '/', '\/', $_SERVER['DOCUMENT_ROOT'] );
					$pattern = '/'.$str.'/i';
					$filepath = preg_replace( $pattern, '', $filepath );
					$filepath .= '/images/css_selectors_all.png';
					echo str_replace( 'images/css_selectors_all.png', $filepath, $this->helpfile['css_selectors'] );
				}
				else echo $this->helpfile[$which];
			}
			else
			{
				echo '<strong>'.$which.'</strong> &gt; could not find item, please check the <strong>fp_Form</strong> directory if <strong>helpfile_fp_Form.php</strong> exist, or
				visit the <a href="http://www.filepocket.org/rack/fp_Form/docs.php" target="_blank">online documentation</a>?<br />';
			}
		}
	}


	function check_range_error($name,$element_type,$required)
	{
		global $regex_patterns;
		$warning = '<strong style="color:red">Warning!</strong> Field name: <strong>'.$name.'</strong>. Element type: <strong>'.$element_type.'</strong>';
		// This needs to be optimized
		if ( ($element_type !== 'checkbox' && $element_type !== 'multiple') && strpos($required,'|') > -1 )
		{
			echo $warning.'<br />Will not validate with the Range syntax for validation.<br />';
		}
		else if ( $element_type !== 'textarea' && is_numeric($required) )
		{
			echo $warning.'<br />Will not validate with integer as validation rule, only textarea elements support integer as character count limits.<br />';
		}
		if ( $element_type === 'checkbox' &&  $required !== '' )
		{
			$expected_msg = '<br />Only accepts the Range syntax. Eg: 1|*, 1|3 (type $obj->help("'.$element_type.'"); for more info)<br />';

			if( strpos($required,'|') < 0 )
            	echo 'Alert';

			$c = explode('|',$required);

			if( count($c) < 2 )
				echo $warning.$expected_msg;
			else
			{
				if( !preg_match('/[\d\*]/', $c[0]) || !preg_match('/[\d\*]/', $c[1]) )
				{
					echo $warning.'<br />Integer, * and | characters only eg: 1|* minimum one or 1|5 between 1 and 5 selections <br />';
				}
			}
		}
	}


	function external_crosscheck_msg( $error_array )
	{
		$this->external_crosscheck_msg = $error_array;
		++$this->validate_check;
	}


	function check_submission( $field_name, $field_value, $field_type, $required_type, $num_of_fields=1 )
	{
		global $messages_fp_Form, $regex_patterns; $alert_msg = '';

		if( $this->f_validate !== true && $this->submission_counted < 1 && $this->f_start !== '' )
			echo '<div>Warning: The <strong>form_start()</strong> validation (4th) parameter is set to false or empty, but a form element (<strong>'.$field_name.'</strong>) uses validation rules. <br />To fix: either remove the validation rules for this element or set the form_start() validation parameter to true.</div>';
		$submited_array = array();

		if( ($this->f_method==='post' || $this->f_method==='get') && @$this->g_submit[$this->form_name] === 'true' )
		{
			// Checkboxes, multi selection
			if( ( $field_type==='checkbox' || $field_type==='multiple') && $this->submission_counted > 0 && $required_type !== '' )
			{
				$req_range = explode('|',$required_type);
				$first_num = $req_range[0]; $second_num = @$req_range[1];
				if( $second_num === '*' )
					$checkbox2='';
				else
					$checkbox2 = sprintf($messages_fp_Form[$field_type.'_line2'],$second_num);

				$alert_msg = sprintf($messages_fp_Form[$field_type.'_line1'],$first_num).$checkbox2;

				if( !array_key_exists($field_name,$this->g_submit) )
				{
					@$submited_array[$key] = array('value'=>$this->g_submit[$field_name],'err_msg'=>$alert_msg);
					++$this->validate_check;
				}

				foreach( $this->g_submit as $key => $val )
				{
					if( $key === $field_name )
					{
						if( $second_num === '*' )
							$second_num = count($val);

						$counted_val = count($val);

						if( $counted_val >= $first_num && $counted_val <= $second_num )
							$submited_array[$key] = array('value'=>$val,'err_msg'=>'');
						else
						{
							$submited_array[$key] = array('value'=>$val,'err_msg'=>$alert_msg);
							++$this->validate_check;
						}
					}
				}
			}
			else if ( $field_type === 'textarea' &&  $this->submission_counted > 0 )
			{
				$counted_textarea = strlen($this->g_submit[$field_name]);
				if( is_numeric($required_type) )
				{
					if( $counted_textarea > $required_type )
					{
						$alert_msg = sprintf($messages_fp_Form['textarea'],$counted_textarea,$required_type);
						++$this->validate_check;
					}
					$submited_array[$field_name] = array('value'=>$this->g_submit[$field_name],'err_msg'=>$alert_msg);
				}
				else if ( $required_type !== '' )
				{
					if( !preg_match( $regex_patterns[$required_type], $this->g_submit[$field_name]) )
					{
						$alert_msg = $messages_fp_Form[$required_type];
						$submited_array[$field_name] = array('value'=>$this->g_submit[$field_name],'err_msg'=>$alert_msg);
						++$this->validate_check;
					}
					else
						$submited_array[$field_name] = array( 'value'=>$this->g_submit[$field_name], 'err_msg'=>'' );
				}
			}
			else if ( $field_type === 'file' )
			{
				if( $required_type !== '' && $_FILES[$field_name]['name'] === '' )
				{
					$submited_array[$field_name] = array('value'=>$_FILES[$field_name]['name'],'err_msg'=>$messages_fp_Form[$required_type]);
					++$this->validate_check;
				}
				else if( $_FILES[$field_name]['error'] !== 0 && $required_type !== '' )
				{
					$submited_array[$field_name] = array('value'=>$_FILES[$field_name]['name'], 'err_msg'=>$messages_fp_Form['UPLOAD_'.$_FILES[$field_name]['error']]);
					++$this->validate_check;
				}

				if( $_FILES[$field_name]['error'] === 0 )
				{
					if( $this->upload_dir !== '' )
						@move_uploaded_file($_FILES[$field_name]['tmp_name'], $this->upload_dir .'/'. basename($_FILES[$field_name]['name']));
				}
			}
			else
			{
			   foreach( $this->g_submit as $key => $val )
			   {
				if( $key===$field_name && $required_type!=='' )
				{	// @@ Regular Expression validation here
					if( !is_array($val) )
					{
						if( preg_match( $regex_patterns[$required_type], $val ) )
						{
							$submited_array[$key] = array( 'value' => $val, 'err_msg' => '' );
						}
						else
						{
							$submited_array[$key] = array( 'value'=>$val, 'err_msg'=>$messages_fp_Form[$required_type] );
							++$this->validate_check;
						}
					}
				}
				else
				{
				  if($required_type != 'emailorblank')
				  {
					if( empty($this->g_submit[$field_name]) && $required_type !== '' ) // For elements with no key or value passed (if nothing selected) 
					{
						$submited_array[$key] = array( 'value'=>$val, 'err_msg'=>$alert_msg );
						++$this->validate_check;
					}
					else {
						$submited_array[$key] = array( 'value'=>$val, 'err_msg'=>'' );
					}
				  }
				}
			   }
			}
		}
		return $submited_array;
	}


	function js_validate_code() // PUBLIC
	{
		global $messages_fp_Form, $regex_patterns;
		static $js_counter = 0; $output = '';

	   if( ++$js_counter < 2 )
	   {
		$output = '
<script type="text/javascript">
<!--
	var hrdotted = "\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
	var errMsg_startline = "'.$messages_fp_Form['js_msg_start'].'" + hrdotted + "\n";
	var errMsgEnd = hrdotted+"'.$messages_fp_Form['js_msg_end'].'";';

foreach( $regex_patterns as $key=>$arr )
{
	$output .= "\n\nvar ".$key.' = '.$regex_patterns[$key].';';
	$output .= "\nvar ".$key.'_msg = "'.$messages_fp_Form[$key].'";';
}
$output .= "\n".'//--></script>';
	   }

	$output .= '
<script type="text/javascript">
<!--
	function '.$this->js_validate_name.'{';
		$output .= "\n\t\tvar errorCheck = false;
		var i = 0; var errMsg = ''; var str = '';
";
		$i = 0; $amsg = ''; $popup_amsg = '';
		$output .= "\n\tvar formObj = document.getElementById('".$this->form_name."');\n";

		foreach( $this->jsvalidate as $key=>$value)
		{
			$use_id = false; $use_add_brackets = false;
			if( $value['subgroup'] === 'start' )
			{
				if($value['label'] === '')
				{
					$amsg = ucwords($messages_fp_Form['field']).' '.++$i.', ';
					$popup_amsg = $sglabel.' '.$messages_fp_Form['field'].' '.$i;
				}
				else
				{
					$i = 1;
					$amsg = ucwords($messages_fp_Form['field']).' '.$i.', ';
					$popup_amsg = '';
					$sglabel = $value['label'];
				}
			}
			else
			{
				$amsg = '';
				$popup_amsg = '';
			}

			if( $value['validate'] !== '' )
			{
				switch($value['type'])
				{
				  case "text": //#########
					$output .= '
		if(formObj.'.$key.'.value.match('.$value['validate'].') == null){
			formObj.'.$key.'.style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$value['validate'].'_msg;';
					break;

				  case "textarea": //#########
		 if( strpos($value['validate'],'|') )
			$key_relay = $value['validate'].'_msg';
		 else $key_relay = 'string_msg';
					$output .= '
		'.$key.'_check = false;
		if(isNaN('.$value['validate'].')){ // if not a number
			if(formObj.'.$key.'.value.match('.$value['validate'].') == null){
				'.$key.'_relay = '.$key_relay.';
				'.$key.'_check = true;
			}
		}
		else if ( formObj.'.$key.'.value.length > '.$value['validate'].' ) {
			'.$key.'_relay = " '.sprintf($messages_fp_Form['textarea'],0,$value['validate']).'";
			'.$key.'_relay = '.$key.'_relay.replace(/: 0\,/,": "+formObj.'.$key.'.value.length+", ");
			'.$key.'_check = true;
		}
		if( '.$key.'_check == true ){
			formObj.'.$key.'.style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$key.'_relay;';
					break;

				  case "radio": //#########
				  	$output .= '
		'.$key.'_count = formObj.'.$key.'.length;
		'.$key.'_check = false;

			for(i=0;i<'.$key.'_count;i++){
				if( formObj.'.$key.'[i].checked == true)
					'.$key.'_check = true;
			}
			if('.$key.'_check == false){
				document.getElementById("'.$key.'_span").style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
				document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$value['validate'].'_msg';
					$use_id = true;
				  	break;

				  case "checkbox": //#########
			$req_range = explode('|',$value['validate']);
				  	$output .= '
			'.$key.'_count = formObj["'.$key.'[]"].length;
			var first_num = "'.$req_range[0].'";
			var second_num = "'.@$req_range[1].'";
			var js_tally = 0;
			'.$key.'_check = false;

			for(i=0;i<'.$key.'_count;i++){
				if( formObj["'.$key.'[]"][i].checked == true)
					js_tally++;
			}';
					$output .= '
		checkbox_msg = '.sprintf('"'.$messages_fp_Form[$value['type'].'_line1'].'";', $value['validate'][0]);
					if( $value['validate'][2] > 0 )
						$output .= "\n".'checkbox_msg += '.sprintf('"'+$messages_fp_Form[$value['type'].'_line2'],$value['validate'][2]).'";';

					$output .= '
			if(second_num == "*")
				second_num = '.$key.'_count;
			if( js_tally >= first_num && js_tally <= second_num )
				'.$key.'_check = true;';

					$output .= '
		if('.$key.'_check == false){
			document.getElementById("'.$key.'_span").style.backgroundColor = "'.$this->validate_alert_bgcolor.'"; 
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.'checkbox_msg;';
					$use_id = true;
				  	break;

				  case 'multiple': //#########
			$key = $key.'[]';
			$key_clean = str_replace('[]','',$key);
				  	$output .= '
			'.$key_clean.'_count = formObj["'.$key.'"].length;
			var first_num = "'.$value['validate'][0].'";
			var second_num = "'.$value['validate'][2].'";
			var js_tally = 0;
			'.$key_clean.'_check = false;

			for(i=0;i<'.$key_clean.'_count;i++){
				if( formObj["'.$key.'"][i].selected == true){
					js_tally++;
				}
			}';

					$output .= '
		checkbox_msg = '.sprintf('"'.$messages_fp_Form[$value['type'].'_line1'].'";', $value['validate'][0]);
					if( $value['validate'][2] > 0 )
						$output .= "\n".'checkbox_msg += '.sprintf('"'+$messages_fp_Form[$value['type'].'_line2'],$value['validate'][2]).'";';

					$output .= '
			if( second_num == "*" )
				second_num = '.$key_clean.'_count;
			if( js_tally >= first_num && js_tally <= second_num )
				'.$key_clean.'_check = true;';

					$output .= '
		if('.$key_clean.'_check == false){
			formObj["'.$key.'"].style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key_clean.'_amsg").innerHTML = checkbox_msg;';
			$use_add_brackets = true;
				  break;

				  case "select": //#########
				  	$output .= '
		if(formObj.'.$key.'.value.match('.$value['validate'].') == null){
			formObj["'.$key.'"].style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$value['validate'].'_msg;';
				  	break;

				 case "file": //#########
					$output .= '
		if(formObj.'.$key.'.value.match('.$value['validate'].') == null){
			formObj.'.$key.'.style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$value['validate'].'_msg;';
				  	break;

				  default: //#########
				  	$output .= '
		if(formObj.'.$key.'.value.match('.$value['validate'].') == null){
			formObj["'.$key.'"].style.backgroundColor = "'.$this->validate_alert_bgcolor.'";
			document.getElementById("'.$key.'_amsg").innerHTML = "'.$amsg.'"+'.$value['validate'].'_msg;';
					break;
				}

				// This part universal $popup_amsg
				$output .= '
			errMsg += "     - '.$popup_amsg.$value['label'].'\n";
			errorCheck = true;
		} else {';

		if( $value['type'] === 'multiple' ) // exception for multiple select fileds only - needs to have [] in fieldname
			$output .= 'document.getElementById("'.$key_clean.'_amsg").innerHTML = ""; ';
		else
			$output .= 'document.getElementById("'.$key.'_amsg").innerHTML = ""; ';

		if($use_id == true)
			$output .= 'document.getElementById("'.$key.'_span").style.backgroundColor = "transparent";// '.$this->validate_pass_bgcolor.'';
		else if ( $use_add_brackets == true )
			$output .= 'formObj["'.$key.'"].style.backgroundColor = "'.$this->validate_pass_bgcolor.'";';
		else
			$output .= 'formObj.'.$key.'.style.backgroundColor = "'.$this->validate_pass_bgcolor.'";';

		$output .= "\n}\n";
			}
		}

		$output .= '
		if(errorCheck == true)
		{
		';
		if( ($this->validate_check > 0 && count($this->fields) > 5 ) || $this->show_alert_hdr == true )
			$output .= 'document.getElementById("alertHdr").innerHTML = errMsg_startline;';
		$output .= '
			alert( errMsg_startline + errMsg + errMsgEnd );
			return false;
		} else {
			return true;
		}';
		$output .= "\n}\n";
		$output .= '//--></script>'."\n";

		return $output;
	}
}
