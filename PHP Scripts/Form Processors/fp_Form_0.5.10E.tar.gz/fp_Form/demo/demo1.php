<?php
require 'demo_include.php';

if( !defined('BASE_PATH') || !defined('BASE_URL') )
{
	echo 'Please configure BASE_PATH and BASE_URL for on "demo_config.php" first.';
	exit;
}

include_once(BASE_PATH.'fp_form/fp_Form.php');
include_once(BASE_PATH.'fp_Form/languages/english.php');


$f =& new fp_Form( BASE_URL.'fp_Form/');
$f->form_start($_SERVER['PHP_SELF'],'example1','post',true,'class="eg1"');


$f->accesskey('x');
$f->tabindex(1);
// text field
$f->text( 'Text field', 'text_field', '', '', '', '', 
'This "helper" feature is good for long descriptions, its a built in feature' );

$f->password('Password field','password');

// Start <div> block element
$f->group('start','class="group"');
	// Start subgroup, "labels" for subgroups are hidden
	$f->subgroup('start');

		$f->text( 'Sub-grouping elements', 'quota_limit', 10, 'positive_number', 10, 30,
		'This uses custom Javascript + hidden field for the dynamic changes, ',
		"onchange=\"save_bytes('example1',this,'size_unit','quota_limit_bytes')\"", '' );

		$f->hidden( 'quota_limit_bytes', 10485760 );

		$show_size_formats = array( 
			'b'=>'Bytes',
			'kb'=>'Kilobytes',
			'mb'=>'Megabytes'
		);

		$f->select( '', 'size_unit', array('mb'), $show_size_formats, '', 
		'the onchange event is placed in the <em>$etc</em> parameter',
		"onchange=\"byte_converter('example1','quota_limit',this,'quota_limit_bytes')\"" );

	$f->subgroup( 'end' );
	
	$f->subgroup( 'start' );

		$f->text( 'Telephone', 'tel', '', 'positive_number', 3, 3, '', '', '-' );
		$f->show_label = false;
		$f->text( '', 'tel2', '', 'positive_number', 4, 4, '', '', '-');
		$f->text( '', 'tel3', '', 'positive_number', 3, 3, '', '', 
		'<br />&nbsp;<small>(123)&nbsp; &nbsp; &nbsp; (1234) &nbsp; &nbsp; (123)</small>' );
		$f->show_label = true;
	$f->subgroup('end');

// Output closing </div> block element
$f->group('end');

$show_dir_array = array(
	'h1' => 'Item 1',
	'h2' => 'Item 2',
	'h3' => 'Item 3'
);

$f->radio('Horizontal position', 'hor_pos', '', $show_dir_array, 'nonempty');

$vertical_position = array(
	'v1'=> array('This also works for checkboxes','onclick="alert(\'Placing onclick events into radio elements\');"'),
	'v2'=>'Good for long lines',
	'v3'=>'One more way to display radio and checkboxes'
);

$f->radio('Vertically', 'vertically', 'v1', $vertical_position, 'nonempty', 'vertical' );

$available_fruits = array (
	'rambutan' => 'Rambutan',
	'banana' => 'Banana',
	'mangga' => 'Mangga',
	'mango' => 'Mango',
	'honey_dew_melon' => 'Honey Dew Melon',
	'durian' => 'Durian',
	'orange' => 'Orange',
	'kiwi' => 'Kiwi',
	'watermelon' => 'Watermelon',
	'pear' => 'Pear',
	'apple' => 'Apple'
);


ksort($available_fruits);
reset($available_fruits);

$fruits_selected = array( 'rambutan', 'durian', 'kiwi' );
$f->checkbox( 'Multi-Columns', 'some_fruits', $fruits_selected, $available_fruits, '3|*', '', '', '', 2 );

$random_mamals = array (
	'giraffe' => array('Giraffe', 'onclick="alert(\'You choose Giraffe.\');"'),
	'alligator' => array('Alligator', 'onclick="alert(\'Alligator you clicked on.\');"'),
	'flamingo' => array('Flamingo', 'onclick="alert(\'Reminds me of Miami Vice TV show.\');"'),
	'mouse_deer' => array('Mouse Deer', 'onclick="alert(\'Tiny deer.\');"'),
	'orang_utan' => array('Orang-utan', 'onclick="alert(\'Pronouced as o-rang-oo-tan.\');"'),
	'elephant' => array('Elephant', 'onclick="alert(\'Cool but smelly.\');"'),
);


$f->checkbox( 'Multi-Columns 2', 'random_mamals', array(''), $random_mamals, '', '', '', '',3 );// last is 3

//$f->help('checkbox');

$f->group('start','class="group"');



$languages = array(
	''=>'Select',
	'english'=>'English',
	'chinese_simplified'=>'Chinese Simplified',
	'chinese_traditional'=>'Chinese Traditional'
);

$f->select( array('Select combo box', '<br /><small>(Label second line)</small>'), 
	'language', array('english'), $languages, 'nonempty' );


$f->select( 'Multi-select combo box', 'multi_select', $fruits_selected, $available_fruits, '2|*', '', '', '', 'multiple', 10 );
$f->group( 'end' );

$f->textarea( 'Textarea Basic', 'tb', '', '', 20, 2 );
$f->accesskey('a');
$f->textarea( 'Textarea Extra', 'te', 'Type here ... ', 50, 20, 5, 'No need for custom scripts, this is built in!' );


$f->group('start','class="group2"');
$f->button( 'submit', '&nbsp;', '', 'Try Validate', '', 
	'&bull; <a href="#">Secondary action</a>','horizontal');
$f->group('end');

if( $f->validate_check() === true )
{
	// All ok, do processing here
	// Redirect
}
else if( $f->validate_check() === false )
{
	// Form validation failed
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Demo 1</title>

<style type="text/css"><!--
	body {
		margin: 0 auto; 
		padding: 0; 
		font: .7em/1.4em Verdana, Arial, Helvetica, sans-serif; 
		width: 100%; 
		background: #fff;
	}
	form {
		margin: 10px auto;
		width: 80%;
	}
	label {
		display: block;
		float: left;
	}
	.helper {
		display: none;
	}
	.req {
		color: red;
	}
	.req_line {
		margin: 0 auto 20px auto;
		width: 80%;
	}
	.u {
		text-decoration: underline;
	}

	form.eg1 {
		border-top: 1px solid #666;
		border-bottom: 1px solid #666;
		background: #f6f6f6;
	}
	.eg1 td {
		vertical-align: top;
		padding-right: 15px;
	}
	.eg1 label {
		width: 180px;
		padding: 3px 0 3px 20px;
		clear: both;
	}
	.eg1 label.inline {
		display: inline;
		float: none;
		width: auto;
		padding: 0;
		clear: none;
	}
	.eg1 .fieldCell,
	.eg1 .fieldAlert {
		margin-left: 200px;
		vertical-align: middle;
		padding: 3px 0;
	}
	.eg1 .group {
		background: #DDF5FF;
		padding: 5px 0;
		border-top: 1px solid #999;
		border-bottom: 1px solid #999;
	}
	.eg1 .group2 {
		background: #333; color: #fff;
	}
	.eg1 .group2 a {
		color: #f6f6f6;
	}
	.eg1 .fieldRow {
		padding: 8px 0;
	}
	.eg1 .fieldAlert td {
		background: #FCFFBC;
	}
	.eg1 .failed input,
	.eg1 .failed select {
		background: #FCFFBC;
	}
	.eg1 .alertmsg {
		color: red;
	}
	.eg1 .helper {
		color: #666;
		padding: 5px 0;
		background: transparent;
	} 
	.eg1 .group .fieldRow {
		margin: 5px 0;
	}
	.eg1 .alert_header {
		font-weight: bold;
		padding: 5px 15px;
		color: #0000C9;
		background: #FFDCDB;
	}
	.eg1 noscript {
		color: #000;
		margin: 3px 10px;
		border-bottom: 1px solid #999;
	}
-->
</style>
<script type="text/javascript"><!--
function byte_converter(form_name,input_element,element,save_copy){

	var result = 0;
	var saved_byte = eval('document.'+form_name+'.'+save_copy);
	var input_field = eval('document.'+form_name+'.'+input_element);

	if(element.value == 'b')
		result = saved_byte.value;
	else if(element.value == 'kb')
		result = saved_byte.value / 1024;
	else if(element.value == 'mb')
		result = saved_byte.value / 1048576;
	// if not a number
	if(isNaN(input_field.value))
		alert('not a number');
	input_field.value = result;
}

function save_bytes(form_name,element,size_format,save_copy){

	var size_format_field = eval('document.'+form_name+'.'+size_format+'[document.'+form_name+'.'+size_format+'.selectedIndex]');
	
	if(size_format_field.value == 'b')
		result = element.value;
	else if(size_format_field.value == 'kb')
	    result = element.value * 1024;
	else if(size_format_field.value == 'mb')
	    result = element.value * 1048576;
	eval('document.'+form_name+'.'+save_copy).value = result;
}
//-->
</script>
<script type="text/javascript" src="<?php echo BASE_URL;?>fp_Form/fp_Form.js"></script>

<?php
	echo $f->js_validate_code();
?>
</head>
<body>
<?php
echo navi();

if( $f->validate_check() === true )
{
	$output = '<div style="border: 1px solid #e6e6e6; padding: 20px; background: #f6f6f6"><p><big>* All forms validated, <a href="'.$_SERVER['PHP_SELF'].'">go back</a></big></p>';
	$output .= '<strong>Submmited values:</strong><pre style="font-size: 12px;">'.print_r($_POST,1).'</pre></div>';
	echo $output;
}
else
	echo $f->display();
?>
</body>
</html>