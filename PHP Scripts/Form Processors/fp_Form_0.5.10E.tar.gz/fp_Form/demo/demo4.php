<?php
require 'demo_include.php';
// Sending email example, no HTML version for this since PHP is required for the email sending

if( !defined('BASE_PATH') || !defined('BASE_URL') )
{
	echo 'Please configure BASE_PATH and BASE_URL for on "demo_config.php" first.';
	exit;
}

include_once(BASE_PATH.'fp_Form/fp_Form.php');
include_once(BASE_PATH.'fp_Form/languages/english.php');

$messages_fp_Form['required_symbol'] = '';

$f4 = new fp_Form( BASE_URL.'fp_Form/', false ); 

$f4->form_start( $_SERVER['PHP_SELF'], "eg4", "post", true, 'class="eg4"' ); 

$f4->fieldset('start','Check Value'); 
// $f4->help();
$f4->text( 'Username', 'username', 'george', 'nonempty', 20, 40, 'Check if the username george is taken.' );

$some_macs = array (
	'x86_dc_3_6' => 'PowerMac x86 Dual Core 3.6 Ghz',
	'ppc_dc_2_7' => 'PowerMac PPC Dual Core 2.7 Ghz',
	'imac_2' => 'iMac 2 Ghz'
);

$f4->radio( 'Apple', 'macs', '', $some_macs, 'nonempty', 'vertical' );
$f4->button( 'submit', '&nbsp;', 'submit', 'Check' );

$f4->fieldset('end'); 


// CHECK POINT 1
if( $f4->validate_check() === true )
{
/* ****
	CHECK POINT 2 - check values against stored date - such as database
	$sql = "SELECT COUNT(id) FROM member_table WHERE member_name = '".$_POST['nombre']."'";
	$result = mysql_query($sql);
	
	if ( mysql_result($result,0) > 0 )
**** */
	$error_array = array();
	if ( $_POST['username'] == 'george' )
	{
		// CHECK POINT 2 - FAILED
		// Match found, return error halt form processing
		$match_found = 'The Username "'.$_POST['username'].'" already taken, please choose another.';
		$error_array['username']['errmsg'] = $match_found;
		
	}
	else if( $_POST['macs'] == 'x86_dc_3_6' )
	{
		$not_out = 'That Mac would indeed be sweet';
		$error_array['macs']['errmsg'] = $not_out;
	}
	else
	{
		// BOTH CHECKPOINT 1 & 2 PASSED
		// All ok, do processing here
		// header(""Location: go_to_page.php");
		// exit;
	}

	if(count($error_array) > 0)
		$f4->external_crosscheck_msg( $error_array );
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Demo 4</title>

<style type="text/css">
<!--
body {
	margin: 0;
	padding: 0; 
	font: .7em/1.4em Verdana, Arial, Helvetica, sans-serif;
	width: 100%;
	background: #fff;
}
.helper {
	display: none;
	padding: 10px;
	background: #f6f6f6;
}
.req { 
	color: red;
}
form {
	margin: 0;
}
label {
	display: block; float: left;
}
label.inline {
	display: inline;
	float: none;
	width: auto;
	padding: 0;
}
.eg4 fieldset {
	margin: 10px 0 0 20px;
	padding: 20px 10px;
	border: 1px solid #333;
	width: 330px;
}
.eg4 label {
	width: 80px;
}
.eg4 .fieldCell {
	margin-left: 80px;
}
.eg4 .fieldRow {
	padding-top: 15px;
}
.req_line {
	margin-left: 20px;
} 

.eg4 .alertmsg {
	color: #FF8682;
}
.eg4 legend {
	font-weight: bold;
}      
.u {
	text-decoration: underline;
}
-->
</style>
<?php
	echo $f4->js_validate_code();
?>
<script type="text/javascript" src="<?php echo BASE_URL;?>fp_Form/fp_Form.js"></script>
</head>
<body>
<?php
	echo navi();
	
if( $f4->validate_check() === true )
{
	$output = '<div style="border: 1px solid #e6e6e6; padding: 20px; background: #f6f6f6"><p><big>* All forms validated, <a href="'.$_SERVER['PHP_SELF'].'">go back</a></big></p>';
	$output .= '<strong>Submmited values:</strong><pre style="font-size: 12px;">'.print_r($_POST,1).'</pre></div>';
	echo $output;
}
else
	echo $f4->display();
?>

</body>
</html>
