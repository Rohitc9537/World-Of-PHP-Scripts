<?php
require 'demo_include.php';

if( !defined('BASE_PATH') || !defined('BASE_URL') )
{
	echo 'Please configure BASE_PATH and BASE_URL for on "demo_config.php" first.';
	exit;
}

include_once(BASE_PATH.'fp_Form/fp_Form.php');
include_once(BASE_PATH.'fp_Form/languages/english.php');

$f2 = new fp_Form( BASE_URL.'fp_Form/' ); 
  
$f2->form_start( $_SERVER['PHP_SELF'], "eg3", "post", true, 'class="eg3"' ); 

$f2->fieldset('start','Personal Information'); 
$f2->subgroup('start'); 

$f2->accesskey('N');
$f2->text( 'First Name', 'first_name', '', 'nonempty', 20, 40, '', '', ' Middle Name: ' ); 
$f2->text( '', 'middle_name', '', '', 6, 6 ); 
$f2->subgroup('end'); 

$f2->text( 'Last Name', 'last_name', '', 'nonempty', 20, 40 ); 
$f2->text( 'Date of birth', 'dob', '', '', 10, 40, '', '', ' (25/12/1970)'); 
$f2->text( 'Email', 'email', '', 'email', 25, 40 );
$f2->fieldset('end'); 

$f2->fieldset('start','Employment');
$f2->text( 'Current Employment', 'current_employ', '', 'nonempty', 40, 80 );

$f2->set_upload_dir(BASE_PATH.'upload_to_here');
$f2->browse( 'Upload Resume', 'uploadtry', 'nonempty', 4600000, 'application/msword,application/vnd.ms-excel, application/rtf,application/pdf' );

$f2->textarea( 'Job description', 'job_desc', '', 60, 30, 3, 'Use the helper feature to provide extra info for end user.' ); 
  
$f2->button( 'submit', '&nbsp;', 'submit', 'Submit' ); 
$f2->fieldset('end'); 

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Demo 2</title>

<style type="text/css">
	body { margin: 0 auto; padding: 0; font: .7em/1.4em Verdana, Arial, Helvetica, sans-serif; width: 100%; background: #fff; }
	.helper { display: none; padding: 10px; background: #f6f6f6; }
	.req { color: red; }
	form { margin: 0; }
	label { display: block; float: left; width: 120px; }
	label.inline { display: inline; float: none; width: auto; padding: 0; }
	.eg3 fieldset { margin-top: 10px; padding: 20px 10px; width: 80%; }
	.eg3 label { width: 150px; }
	.eg3 .alertmsg { color: #FF8682; }
	.u { text-decoration: underline; }

</style>
<?php
	echo $f2->js_validate_code();
?>
<script type="text/javascript" src="<?php echo BASE_URL;?>fp_Form/fp_Form.js"></script>
</head>
<body>
<?php
	echo navi();
	
	echo $f2->display();
?>

</body>
</html>
