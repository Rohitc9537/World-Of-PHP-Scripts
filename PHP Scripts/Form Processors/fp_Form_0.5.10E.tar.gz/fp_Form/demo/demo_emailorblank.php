﻿<?php

require 'demo_include.php';

if( !defined('BASE_PATH') || !defined('BASE_URL') )
{
	echo 'Please configure BASE_PATH and BASE_URL for on "demo_config.php" first.';
	exit;
}


include_once(BASE_PATH.'fp_form/fp_Form.php');
include_once(BASE_PATH.'fp_Form/languages/spanish.php');



$f =& new fp_Form( BASE_URL.'fp_Form/');
$f->form_start($_SERVER['PHP_SELF'],'example1','post',true,'class="eg1"');

// $f->text( 'E-mails', 'tomadorss_email', '', 'nonempty', 20, 40);
$f->text( 'E-mail', 'tomador_email', '', 'emailorblank', 20, 40);

$f->button( 'submit', '&nbsp;', '', 'Try Validate');



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Demo</title>

<style type="text/css"><!--
	body {
		margin: 0 auto;
		padding: 0;
		font: .7em/1.4em Verdana, Arial, Helvetica, sans-serif;
		width: 100%;
		background: #fff;
	}
	form {
		margin: 10px auto;
		width: 80%;
	}
	label {
		display: block;
		float: left;
	}
	.helper {
		display: none;
	}
	.req {
		color: red;
	}
	.req_line {
		margin: 0 auto 20px auto;
		width: 80%;
	}
	.u {
		text-decoration: underline;
	}

	form.eg1 {
		border-top: 1px solid #666;
		border-bottom: 1px solid #666;
		background: #f6f6f6;
	}
	.eg1 td {
		vertical-align: top;
		padding-right: 15px;
	}
	.eg1 label {
		width: 180px;
		padding: 3px 0 3px 20px;
		clear: both;
	}
	.eg1 label.inline {
		display: inline;
		float: none;
		width: auto;
		padding: 0;
		clear: none;
	}
	.eg1 .fieldCell,
	.eg1 .fieldAlert {
		margin-left: 200px;
		vertical-align: middle;
		padding: 3px 0;
	}
	.eg1 .group {
		background: #DDF5FF;
		padding: 5px 0;
		border-top: 1px solid #999;
		border-bottom: 1px solid #999;
	}
	.eg1 .group2 {
		background: #333; color: #fff;
	}
	.eg1 .group2 a {
		color: #f6f6f6;
	}
	.eg1 .fieldRow {
		padding: 8px 0;
	}
	.eg1 .fieldAlert td {
		background: #FCFFBC;
	}
	.eg1 .failed input,
	.eg1 .failed select {
		background: #FCFFBC;
	}
	.eg1 .alertmsg {
		color: red;
	}
	.eg1 .helper {
		color: #666;
		padding: 5px 0;
		background: transparent;
	}
	.eg1 .group .fieldRow {
		margin: 5px 0;
	}
	.eg1 .alert_header {
		font-weight: bold;
		padding: 5px 15px;
		color: #0000C9;
		background: #FFDCDB;
	}
	.eg1 noscript {
		color: #000;
		margin: 3px 10px;
		border-bottom: 1px solid #999;
	}
-->
</style>
<script type="text/javascript"><!--
function byte_converter(form_name,input_element,element,save_copy){

	var result = 0;
	var saved_byte = eval('document.'+form_name+'.'+save_copy);
	var input_field = eval('document.'+form_name+'.'+input_element);

	if(element.value == 'b')
		result = saved_byte.value;
	else if(element.value == 'kb')
		result = saved_byte.value / 1024;
	else if(element.value == 'mb')
		result = saved_byte.value / 1048576;
	// if not a number
	if(isNaN(input_field.value))
		alert('not a number');
	input_field.value = result;
}

function save_bytes(form_name,element,size_format,save_copy){

	var size_format_field = eval('document.'+form_name+'.'+size_format+'[document.'+form_name+'.'+size_format+'.selectedIndex]');

	if(size_format_field.value == 'b')
		result = element.value;
	else if(size_format_field.value == 'kb')
	    result = element.value * 1024;
	else if(size_format_field.value == 'mb')
	    result = element.value * 1048576;
	eval('document.'+form_name+'.'+save_copy).value = result;
}
//-->
</script>
<script type="text/javascript" src="<?php echo BASE_URL;?>fp_Form/fp_Form.js"></script>

<?php
	echo $f->js_validate_code();
?>
</head>
<body>
<?php

	if( $f->validate_check() === true )
	{
		echo ' <p>All OK!!!!!!!!!!!!!</p> <a href="'.$_SERVER['PHP_SELF'].'">Back</a>';
		echo '<pre>';
		print_r($_POST);
		echo '</pre>';
	}
	else
		echo $f->display();

	
?>
</body>
</html>