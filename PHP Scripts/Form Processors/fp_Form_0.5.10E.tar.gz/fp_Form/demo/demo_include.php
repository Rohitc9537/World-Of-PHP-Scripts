<?php
define('BASE_PATH','c:/Apache2/htdocs/filepocket/public_html/website/filepocket/libraries/fp_Form/');
define('BASE_URL','http://localhost/filepocket/public_html/website/filepocket/libraries/fp_Form/');
//echo 'Please define BASE_PATH and BASE_URL on fp_Form/demo/demo_include.php, then delete line 2 and 3 on it.';
//exit;
/*
define( 'BASE_PATH', '/system/path/to/fp_Form/' );
define( 'BASE_URL', 'http://localhost/filepocket/libraries/fp_Form/' );
*/
function navi()
{
?>
<table summary="" width="100%" style="background: #e6e6e6; border-bottom: 1px solid #ccc; margin-bottom: 20px;">
<tr>
	<td width="60">&nbsp; Navi:</td>
	<td width="60"><a href="demo1.php?">demo 1</a></td>
	<td width="60"><a href="demo2.php?">demo 2</a></td>
	<td width="60"><a href="demo3.php?">demo 3</a></td>
	<td width="60"><a href="demo4.php?">demo 4</a></td>
	<td>&nbsp</td>
</tr>
</table>

<?php
}
?>
