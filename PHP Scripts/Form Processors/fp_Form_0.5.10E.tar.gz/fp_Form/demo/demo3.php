<?php
require 'demo_include.php';

if( !defined('BASE_PATH') || !defined('BASE_URL') )
{
	echo 'Please configure BASE_PATH and BASE_URL for on "demo_config.php" first.';
	exit;
}

include_once(BASE_PATH.'fp_Form/fp_Form.php');
include_once(BASE_PATH.'fp_Form/languages/english.php');
$send_check = false;

$f3 = new fp_Form(); 
  
$f3->form_start( $_SERVER['PHP_SELF'], "eg4", "post", true, 'class="eg4"' ); 

$f3->fieldset('start','Send Email Example'); 

$f3->text( 'Name', 'user_name', '', '', 20, 40 ); 
$f3->text( 'Email', 'email', '', 'email', 25, 40 );

$f3->button( 'Send the email', '&nbsp;', 'submit', 'Submit' ); 
$f3->fieldset('end'); 


if( $f3->validate_check() === true )
{
	// All ok, do processing here
	// After fp_Form validates the form inputs, use the PHP global variables

	// Windows users set up your SMTP here
	//$SMTP = 'smtp.someisp.com';
	//ini_set( 'SMTP',$SMTP );
	
	// The From and Reply-to email
	$from_email = 'nobody@example.com';

	$to      = $_POST['email'];
	$subject = 'fp_Form sending email example';
	$message = "Hello ".$_POST['user_name'].",\n\nThis is a test message sent from a fp_Form example\n\n\n\n--End of message--";

	$headers = 'From: ' . $from_email ."\r\n" .
   'Reply-To: ' . $from_email . "\r\n" .
   'X-Mailer: PHP/' . phpversion();

	if( $send_check = mail($to, $subject, $message, $headers) )
	{
		$send_success_msg = '<p>Email was sent succesfully!</p>';
	}

	// Example taken from PHP.net -- http://www.php.net/manual/en/function.mail.php
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Demo 3</title>

<style type="text/css">
<!--
	body { margin: 0; padding: 0; font: .7em/1.4em Verdana, Arial, Helvetica, sans-serif; background: #fff; }
	.helper { display: none; padding: 10px; background: #f6f6f6; }
	.req { color: red; }
	form { margin: 0; }
	label { display: block; float: left; }
	label.inline { display: inline; float: none; width: auto; padding: 0; }
	.eg4 fieldset { margin-top: 10px; padding: 20px 10px; width: 300px; }
	.eg4 label { width: 80px; }
	.eg4 .alertmsg { color: #FF8682; }
	.eg4 legend { font-weight: bold; }      
	.u { text-decoration: underline; }
-->
</style>
<?php
if ( $send_check != 1 )
	echo $f3->js_validate_code();
?>
<script type="text/javascript" src="<?php echo BASE_URL;?>fp_Form/fp_Form.js"></script>
</head>
<body>


<?php
echo navi();

if ( $send_check == 1 )
{
	echo $send_success_msg;
}
else
	echo $f3->display();
?>

</body>
</html>
