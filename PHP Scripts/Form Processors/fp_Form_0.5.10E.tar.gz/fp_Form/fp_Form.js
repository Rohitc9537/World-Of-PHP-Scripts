function helper( form_name , field_name ){
	var formObj = document.getElementById(field_name+'_helper');
	if(formObj.style.visibility == 'visible'){
		formObj.style.visibility = 'hidden';
		formObj.style.display = 'none';
	}
	else{
		formObj.style.visibility = 'visible';
		formObj.style.display = 'block';
	}
}


function countChars(element,max_length,form_name,counter_name,field_label) {
	var checker_button = '';
	 if( element.value.length > max_length ) {
		if( msgalerted == 0 ){
			msgalerted = 1;
			alert("'"+ field_label +"' Max character reached, please trim where possible.");
		}
	 	element.focus();
	 }
	 if(element.value.length > max_length)
	 document.getElementById(counter_name).style.color = 'red';
	 else
	 document.getElementById(counter_name).style.color = '#333333'; // can be remoevd if colors clash
	 document.getElementById(counter_name).innerHTML = element.value.length+checker_button;
}
