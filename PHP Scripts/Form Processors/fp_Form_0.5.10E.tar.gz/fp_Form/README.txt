



||||||||| fp_Form 0.5.10E




WHAT IT DOES

fp_Form is a PHP OO class designed to handle the creation 
and validation of web forms with flexible visual formating 
controls.

So far have not yet run this on PHP5.



REQUIREMENTS

- PHP 4.1.x


START-UP

- Uncompress fp_Form_x.x.x.tar.gz onto a folder in your local or develoment web server
- Point your web browser to the new fp_Form directory
- Reference code can be found on help.php


WEBSITE

- http://www.filepocket.org/rack/fp_Form/



FILE DESCRIPTIONS & USAGE
|||||||||||||||||||||||||||||||||||||||

MINIMUM REQUIRED FILES:

 1. fp_Form.php
    - The main class file

 2. fp_Form.js
    - The Javascripts used for the Helper feature and Character counter

 3. languages/[LANGUAGE].php
    - You can move this to another location, be sure to update the path in your app.
    - this line -- include_once(BASE_PATH.'fp_Form/languages/english.php');


HELP FILES & IMAGES:

 1. help.htm / help.php
 2. helpfile_fp_Form.php
    - This is needed if you use $obj->help('text');
 3. images/css_selectors_all.png


DEMO FILES:

 1. demo/demo1.php
 2. demo/demo2.php
 3. demo/demo3.php
 4. demo/demo4.php
 5. images/graphics_bg.pnp
 6. images/graphics_submit.png

|||||||||||||||||||||||||||||||||||||||


LICENSE

fp_Form is distributed under the terms of
the GNU Lesser General Public License (LGPL).


CREDITS:

Date	: August 20, 2005
Version	: fp_Form 0.5.10E
Author	: Edward Hew
Email	: edward@filepocket.org


Contributors:
(In alphbethical order)

Alexander Shabuniewicz
For Russion translation, coding tips, bug reports and suggestions.

Azrina Binti Tumar
For Malay translation

Chris Ramakers (http://www.skyrocket.be/)
For Dutch translation

Moliere Hubert (http://www.natural-design.net/)
For French translation






Thank You!



