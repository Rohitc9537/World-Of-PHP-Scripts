<?php
$messages_fp_Form = array(

'required_line'		=>'<span class="req">%s</span>指必要领域',
'required_symbol'	=>'<sup title="必要领域">&dagger;</sup>',
'js_msg_start' 		=> '一些领域要求您的注意, 清单如下',//表格
'js_msg_end' 		=> '请检察强调领域',
'nonempty' 			=> '不能留空',
'positive_number' 	=> ' 请输入正数',
'negpos_numbers' 	=> ' 数据而已',
'checkbox_line1' 	=> ' - 请至少选择 %d',
'checkbox_line2' 	=> ', 但不多过 %d 项',
'multiple_line1' 	=> ' - 请至少选择 %d',
'multiple_line2' 	=> ', 但不多过 %d 项',
'textarea' 			=> '字符数量已超限.目前数目: %d, 请限%d以下',
'email' 			=> '只许有效电子邮件版式',
'emailorblank' 		=> '只许有效电子邮件版式',
'username' 			=> '必须是5-16字母之间或&quot;_&quot;字符而已',
'characters_counter'=> '字符数量限制%d',
'character_counter2'=> '目前数目',
'field' 			=> '-领域',
'counter_noscript' 	=> '字符计数器操作需要JavaScript功能',
// 'noscript_general' 	=> '浏览器JavaScript功能不存在,一些表格特徵无法使用.',

'UPLOAD_1' 			=> '文件大小超过了网络服务器的可上载文件大小限度设置! [Err No.1].', 
'UPLOAD_2'			=> '文件大小超过了这一页的可上载文件大小限度设置! [Err No.2].',
'UPLOAD_3'			=> '上载失败,只有部份被上载而已! [Err No.3.].',
'UPLOAD_4'			=> '文件上载失败!',
'UPLOAD_6'			=> '系统配置故障,暂时文件夹不存在. 请联络网点业主! [Err No.6]'
);
?>
