<?php
$messages_fp_Form = array(

'required_line'		=>'<span class="req">%s</span>指必要領域',
'required_symbol'	=>'<sup title="必要領域">&dagger;</sup>',
'js_msg_start' 		=> '一些領域要求您的注意, 清單如下',//表格
'js_msg_end' 		=> '請檢察強調領域',
'nonempty' 			=> '不能留空',
'positive_number' 	=> ' 請輸入正數',
'negpos_numbers' 	=> ' 數據而已',
'checkbox_line1' 	=> ' - 請至少選擇 %d',
'checkbox_line2' 	=> ', 但不多過 %d 項',
'multiple_line1' 	=> ' - 請至少選擇 %d',
'multiple_line2' 	=> ', 但不多過 %d 項',
'textarea' 			=> '字符數量已超限.目前數目: %d, 請限%d以下',
'email' 			=> '隻許有效電子郵件版式',
'emailorblank' 		=> '隻許有效電子郵件版式',
'username' 			=> '必須是5-16字母之間或&quot;_&quot;字符而已',
'characters_counter'=> '字符數量限制%d',
'character_counter2'=> '目前數目',
'field' 			=> '-領域',
'counter_noscript' 	=> '字符計數器操作需要JavaScript功能',
// 'noscript_general' 	=> '瀏覽器JavaScript功能不存在,一些表格特徵無法使用.',

'UPLOAD_1' 			=> '文件大小超過了網絡服務器的可上載文件大小限度設置! [Err No.1].', 
'UPLOAD_2'			=> '文件大小超過了這一頁的可上載文件大小限度設置! [Err No.2].',
'UPLOAD_3'			=> '上載失敗,隻有部份被上載而已! [Err No.3.].',
'UPLOAD_4'			=> '文件上載失敗!',
'UPLOAD_6'			=> '系統配置故障,暫時文件夾不存在. 請聯絡網點業主! [Err No.6]'
);
?>
