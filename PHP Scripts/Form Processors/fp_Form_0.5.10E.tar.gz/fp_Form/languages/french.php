<?php
// Contributed by MOLIERE Hubert 
$messages_fp_Form = array (
'required_line' 	=> '<span class="req">%s</span>Indique un champ obligatoire',
'required_symbol' 	=> '<sup title="Champ obligatoire">&dagger;</sup>',
'js_msg_start'      => 'Attention! Veuillez vérifier certains champs!',
'js_msg_end'        => 'Veuillez vérifier le(s) champ(s) en surbrillance',
'nonempty'          => 'Ne doit pas &ecirc;tre vide',
'positive_number' 	=> ' Nombre positif requis',
'negpos_numbers' 	=> ' Chiffres seulement',
'checkbox_line1'    => ' Veuillez s&eacute;lectionner au moins %d',
'checkbox_line2' 	=> ', mais pas plus de %d choix',
'multiple_line1'    => ' Veuillez s&eacute;lectionner au moins %d',
'multiple_line2'    => ', mais pas plus de %d (Presser Ctrl ou Cmd pour effectuer une s&eacute;lection multiple)',
'textarea'          => 'Nombre limite de caract&egrave;res d&eacute;pass&eacute;. Nombre actuel: %d, Limite: %d',
'email' 			=> ' Format d\'email non valide',
'emailorblank'      => ' Format d\'email non valide',
'username'          => ' Doit contenir entre 5 et 16 caract&egrave;res alphanumeriques ou le caract&egrave;re \'_\' seulement',
'characters_counter'=> ' Nombre limite de caract&egrave;res %d',
'character_counter2'=> ' Nombre actuel:',
'field' 			=> 'champ',
'counter_noscript'  => 'Note: La fonctionnalit&eacute; \'Nombre limite de caract&egrave;res\' n&eacute;cessite JavaScript pour fonctionner.',

'UPLOAD_1' 		=> 'File exceeds the maximum file size allowed set by the server. [Err No.1].', 
'UPLOAD_2'		=> 'File exceeds the maximum file size allowed set on this page. [Err No.2].',
'UPLOAD_3'		=> 'File was only partially uploaded. [Err No.3].',
'UPLOAD_4'		=> 'File was not uploaded.',
'UPLOAD_6'		=> 'System configuration error, missing a temporary folder. Please contact site owner. [Err No.6]'
);
// 'noscript_general'  => '(Note: JavaScript est d&eacute;sactiv&eacute;, certaines fonctionnalit&eacute;s de ce formulaire ne fonctionneront pas.)<br />'
?>


