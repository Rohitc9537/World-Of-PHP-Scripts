<?php
// Contributed by Chris Ramakers
$messages_fp_Form = array (
'required_line' 	=> '<span class="req">%s</span> Dit symbool geeft verplicht in te vullen velden weer',
'required_symbol' 	=> '<sup title="Verplicht in te vullen">&dagger;</sup>',
'js_msg_start' 		=> 'Opgelet! Sommige velden vereisen uw aandacht!',
'js_msg_end' 		=> 'Gelieve de aangeduide velden te controleren',
'nonempty' 			=> 'Moet ingevuld zijn',
'positive_number' 	=> ' Positief nummer vereist',
'negpos_numbers' 	=> ' Enkel nummers toegelaten',
'checkbox_line1' 	=> ' Gelieve minstens %d items te selecteren',
'checkbox_line2' 	=> ', maar niet meer dan %d items',
'multiple_line1' 	=> ' Gelieve meer dan %d velden te selecteren',
'multiple_line2' 	=> ', maar niet meer dan %d (Houd Ctrl or Cmd ingedrukt om meerdere items te selecteren)',
'textarea' 			=> 'Maximum lengte overschreden. Huidige lengte: %d, Maximum: %d',
'email' 			=> ' Email is geen geldig emailformaat',
'emailorblank' 		=> ' Email is geen geldig emailformaat',
'username' 			=> ' Moet tussen 5 en 16 alfanumerieke karakters of underscores (_) zijn.',
'characters_counter'=> ' Character Limit %d',
'character_counter2'=> ' Current count:',
'field' 			=> 'veld',
'counter_noscript' 	=> 'Nota: De veld-lengte teller vereist dat u javascript hebt geinstalleerd of geactiveerd!',

'UPLOAD_1' => 'Bestand is groter dan de maximum toegelaten bestandsgrootte op deze server. [Err No.1].',
'UPLOAD_2' => 'Bestand is groter dan de maximum toegelaten bestandsgrootte op deze pagina. [Err No.2].',
'UPLOAD_3' => 'Bestand maar gedeeltelijk geupload. [Err No.3].',
'UPLOAD_4' => 'Bestand niet geupload!',
'UPLOAD_6' => 'Configuratiefout, temporary folder werd niet gevonden. Gelieve de systeembeheerder te contacteren. [Err No.6]'
);
// Deprecated: 'noscript_general' 	=> '(NOTA: U hebt javascript uitgeschakeld, sommige functies van dit formulier zullen niet werken.)<br />'
?>
