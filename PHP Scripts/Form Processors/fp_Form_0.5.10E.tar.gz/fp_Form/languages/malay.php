<?php
// Contributed by Azrina Binti Tumar

$messages_fp_Form = array (
'required_line' 	=> '<span class="req">%s</span>Simbol tanda yang memerlukan bidang',
'required_symbol' 	=> '<sup title="Bidang yang dikehendaki">&dagger;</sup>',
'js_msg_start' 		=> 'Hati-hati! Sebahagian bidang memerlukan perhatian anda!',
'js_msg_end' 		=> 'Sila semak bidang-bidang yang telah ditandakan',
'nonempty' 			=> 'Tidak boleh dibiarkan kosong',
'positive_number' 	=> ' Nombor positif dikehendaki',
'negpos_numbers' 	=> ' Nombor sahaja',
'checkbox_line1' 	=> ' Sila pilih sekurang-kurangnya %d',
'checkbox_line2' 	=> ', tetapi tidak boleh lebih daripada %d pilihan',
'multiple_line1' 	=> ' Sila pilih sekurang-kurangnya %d',
'multiple_line2' 	=> ', tetapi tidak boleh lebih daripada %d (Tekan Ctrl atau Cmd untuk beberapa pilihan)',
'textarea' 			=> 'Melebihi had karakter. Kiraan semasa: %d, Had: %d',
'email' 			=> ' Format e-mail tidak sah',
'emailorblank' 		=> ' Format e-mail tidak sah',
'username' 			=> ' Mestilah berada antara 5-16 huruf abjad dengan nombor atau karakter _ sahaja',
'characters_counter'=> ' Had karakter %d',
'character_counter2'=> ' kiraan semasa:',
'field' 			=> 'bidang',
'counter_noscript' 	=> 'Nota: Ciri mengira karakter ini memerlukan Javascript untuk berfungsi.',

'UPLOAD_1' 		=> 'File exceeds the maximum file size allowed set by the server. [Err No.1].', 
'UPLOAD_2'		=> 'File exceeds the maximum file size allowed set on this page. [Err No.2].',
'UPLOAD_3'		=> 'File was only partially uploaded. [Err No.3].',
'UPLOAD_4'		=> 'File was not uploaded.',
'UPLOAD_6'		=> 'System configuration error, missing a temporary folder. Please contact site owner. [Err No.6]'
);
// 'noscript_general' 	=> '(Nota: Anda telah menutup Javascript, sebahagian ciri-ciri borang ini tidak boleh berfungsi.<br />'
?>
