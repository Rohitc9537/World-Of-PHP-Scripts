<?php
$messages_fp_Form = array (
'required_line' 	=> '<span class="req">%s</span>Symbol marks required fields',
'required_symbol' 	=> '<sup title="Required Field">&dagger;</sup>',
'js_msg_start' 		=> 'Alert! Some fields require your attention!',
'js_msg_end' 		=> 'Please check highlighted field(s)',
'nonempty' 			=> 'Cannot be empty',
'positive_number' 	=> ' Positive number expected',
'negpos_numbers' 	=> ' Numbers only',
'checkbox_line1' 	=> ' Please select at least %d',
'checkbox_line2' 	=> ', but no more than %d choices',
'multiple_line1' 	=> ' Please select at least %d',
'multiple_line2' 	=> ', but no more than %d (Hold down Ctrl or Cmd to select multiple)',
'textarea' 			=> 'Character limit exceeded. Current count: %d, Limit: %d',
'email' 			=> ' Email format not valid',
'emailorblank' 		=> ' Email format not valid',
'username' 			=> ' Must be between 5-16 alphanumeric or the _ character only',
'characters_counter'=> ' Character Limit %d',
'character_counter2'=> ' Current count:',
'field' 			=> 'field',
'counter_noscript' 	=> 'Note: The character counter feature requires JavaScript to function.',
// 'noscript_general' 	=> '(NOTE: You have JavaScript disabled, some features of this form will not work.)<br />',

'UPLOAD_1' 		=> 'File exceeds the maximum file size allowed set by the server. [Err No.1].', 
'UPLOAD_2'		=> 'File exceeds the maximum file size allowed set on this page. [Err No.2].',
'UPLOAD_3'		=> 'File was only partially uploaded. [Err No.3].',
'UPLOAD_4'		=> 'File was not uploaded.',
'UPLOAD_6'		=> 'System configuration error, missing a temporary folder. Please contact site owner. [Err No.6]'
);

?>
