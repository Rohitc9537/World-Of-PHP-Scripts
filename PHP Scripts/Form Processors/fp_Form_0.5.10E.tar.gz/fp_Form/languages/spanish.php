<?php
$messages_fp_Form = array (
'required_line' 	=> '<span class="req">%s</span>Campos obligatorios',
'required_symbol' 	=> '<sup title="Required Field">&dagger;</sup>',
'js_msg_start' 		=> 'Alerta! Algunos campos requieren de su atencion!',
'js_msg_end' 		=> 'Por favor verifique los campos resaltados',
'nonempty' 			=> 'No puede estar vacio',
'positive_number' 	=> ' Se esperaba un numero positivo',
'negpos_numbers' 	=> ' Sólo Numeros',
'checkbox_line1' 	=> ' Por favor seleccione al menos %d',
'checkbox_line2' 	=> ', pero no mas de %d opciones',
'multiple_line1' 	=> ' Por favor seleccione al menos %d',
'multiple_line2' 	=> ', pero no mas de %d (Presione Ctrl o Cmd para selección múltiple)',
'textarea' 			=> 'Limite de caracters excedido. Cantidad: %d, Límite: %d',
'email' 			=> ' Email invalido',
'emailorblank' 		=> ' Email invalido',
'username' 			=> ' Debe contener entre 5 y 16 caracteres alfanumericos o el caracter _ unicamente',
'characters_counter'=> ' Limite de caracteres %d',
'character_counter2'=> ' Cantidad:',
'field' 			=> 'campo',
'counter_noscript' 	=> 'Note: El contador de caracteres requiere JavaScript para poder funcionar.',
// 'noscript_general' 	=> '(NOTE: You have JavaScript disabled, some features of this form will not work.)<br />',

'UPLOAD_1' 		=> 'El archivo excede el tamanio maximo permitido por el servidor. [Err No.1].',
'UPLOAD_2'		=> 'El archivo excede el tamanio maximo permitido por esta pagina. [Err No.2].',
'UPLOAD_3'		=> 'El archivo ha subido parcialmente. [Err No.3].',
'UPLOAD_4'		=> 'El archino no ha subido.',
'UPLOAD_6'		=> 'Configuracion del sistema erronea, ausente o problemas en la carpeta temportal. Por favor contacte el propietario del sitio. [Err No.6]'
);

?>
