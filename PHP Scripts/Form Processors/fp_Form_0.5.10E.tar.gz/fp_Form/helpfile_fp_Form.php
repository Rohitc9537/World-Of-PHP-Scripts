<?php

$helpfile["css"] = '

<style type="text/css">
table { padding: 0; margin: 0; border: 0 none; border-collapse: collapse; }
.docswraps { padding: 15px; border-top: 1px dotted #ccc; border-right: 1px dotted #ccc; border-bottom: 3px dotted #ccc; border-left: 1px dotted #ccc; background: #FFF; margin: 10px; }
.docswraps .fright { float: right; font-size: 30px; color: #D3D9E5; }
.tl { border-top: 1px solid #D2D2D2; }
.rl,.dr { border-right: 1px solid #D2D2D2; }
.bl { border-bottom: 1px solid #D2D2D2; }
.ll,.dl { border-left: 1px solid #D2D2D2; }
tt { color: green; }
 .ht { border: 1px solid #ccc; padding: 20px; margin: 5px; color: #333; width: 90%; }
 .ht big { display: block; color: black; line-height: 190%; font-size: 12px; padding: 0 5px; background: #F2EDDE; margin-bottom: 2px; }
 .ht textarea { width: 100%; border: 0 none; background: #D4E4F7; margin-bottom: 3px; }
.cssColors li { margin-bottom: 5px; }
table.css_selectors { border-top: 1px solid #ccc; border-right: 1px solid #ccc; }
.css_selectors td { padding: 10px; border-left: 1px solid #ccc; border-bottom: 1px solid #ccc;  }
.css_selectors .greybg { background: #F2EFEE }
.black { color: black; }
.orange { color: #FF9901; }
.lightblue { color: #03CCFE; }
.green { color: #28B64D; }
.accesskeyTbl { border-top: 1px solid #333; border-right: 1px solid #333; }
.accesskeyTbl td, .accesskeyTbl th { border-bottom: 1px solid #333; border-left: 1px solid #333; padding: 1px 5px; }
.accesskeyTbl th { background: #49B7F8; }
.pl { padding-left: 10px; }
.white { color: #FFFFFF }
.windows {	background: #99CC00; text-align: center; }
.f11 { font-size: 11px; }
.red { color: #f00; }
</style>




';



$helpfile["accesskey"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>accesskey()</h2>
<p>For inserting <em>accesskey</em> onto a form field, use to provide keyboard navigation.</p>
  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;accesskey( character );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
    <ol>
      <li><tt>character</tt> [<em>alphanumeric</em>]<br /> 
      Define <tt>accesskey()</tt> just before the element you wish to assign an access key to. Example:<br /><br />
      <strong>Code:</strong>      <br />
      <tt>$obj-&gt;accesskey(&#39;x&#39;);<br />
      $obj-&gt;text( &#39;Text Label&#39;, &#39;textbox&#39;, &#39;&#39;);</tt><br />
      <br />
      <strong>Output:</strong>      <br />
      Te<u title="Alt/Cmd key + &#39;x&#39;">x</u>t Label: &nbsp;&nbsp;
      <input type="text" name="textbox" value="" size="20" maxlength="" accesskey="x" />
      <br />
      <br />
      Note the <em>accesskey</em> will be underlined if that letter can be found within &lt;label&gt; (mouse over the underlined character for HTML tooltip). Also note that the &lt;label&gt; element itself does not accept <em>accesskey</em> here. You may wish to use tabindex() instead or together with accesskey().<br />
      <br />
      A little about <em>accesskey</em> implementation in web browsers, <a href="http://www.w3.org/TR/REC-html40/interact/forms.html#h-17.11.2" target="_blank">w3&#39;s website</a> states that some form elements do not support the <em>accesskey</em> attribute such as the Select element. As such fp_Form  does not insert the <em>accesskey</em> element for Select elements.<br />
      <br />

      <strong>BEWARE</strong>: <em>Accesskey</em> functionality are accessed differently on some browsers, one example is IE and Firefox uses Alt + key, Opera uses Escape + ESC + key (numbers are accessed differently than letter keys on Opera, visit the links on the bottom of this page for more info on that).<br />

      <p><br />
  <strong>Test it out! Press Alt (on windows) / Cmd (on Mac) + the letters that appear on the form fields:</strong></p>

      <table width="96%" summary="" >
<colgroup>
	<col class="dr" />
	<col class="pl" />
</colgroup>
  <tr>
    <td width="50%">
      &nbsp; 
      <input name="textfield" type="text" accesskey="a" value="a" />
    </td>
    <td>
      &nbsp;
      <input type="checkbox" name="checkbox" value="checkbox" accesskey="b" />
B
<input type="checkbox" name="checkbox" value="checkbox" accesskey="c" />
C
<input type="checkbox" name="checkbox" value="checkbox" accesskey="d" />
D </td>
  </tr>
  <tr>
    <td>&nbsp; 
      <input name="radiobutton" type="radio" value="radiobutton" accesskey="e" />E
<input name="radiobutton" type="radio" value="radiobutton" accesskey="f" />F </td>
    <td>
&nbsp;
<input type="submit" name="Submit" value="Submit [P]" accesskey="p" />
</td>
  </tr>
  <tr>
    <td>
&nbsp;
<textarea name="textarea" cols="30" rows="3" accesskey="m">m</textarea>
    </td>
    <td>&nbsp;</td>
  </tr>
</table>
<br />
The matrix of some web browser implementations:<br />
<table width="96%" summary="" class="accesskeyTbl">
  <colgroup>
  <col />
  <col class="windows" />
  <col class="windows" />
  <col class="windows" />
  <col />
  <col />
  </colgroup>
  <tr>
    <td width="150" class="white">Neo my Hero ... :) </td>
    <td colspan="3" bgcolor="#000000">
      <div align="center" class="white">Windows</div>
    </td>
  </tr>
  <tr>
    <td class="white">Rocking kung-fu scenes!! </td>
    <th>IE 6 (Alt/Cmd + Key)</th>
    <th>Firefox 1.0.1 (Alt/Cmd + key) </th>
    <th>Opera (Shift + Esc + Key) </th>
  </tr>
  <tr>
    <td>Text field </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Checkbox</td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Radio</td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Select (Single row) </td>
    <td>
      <div align="center">1</div>
    </td>
    <td bgcolor="#FFCC00">
      <div align="center">X</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Select (Multiple rows) </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Textarea</td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
  </tr>
  <tr>
    <td>Submit button </td>
    <td>
      <div align="center">1</div>
    </td>
    <td>
      <div align="center">1</div>
    </td>
    <td bgcolor="#FFCC00">
      <div align="center">X</div>
    </td>
  </tr>
</table>
<br />
<div style="padding: 15px;" class="dt dr db dl">
<strong>Useful links:</strong><br />
Checkout these external pages for research on accesskey:<br />
&bull; <a href="http://www.wats.ca/resources/accesskeysandkeystrokes/38">http://www.wats.ca/resources/accesskeysandkeystrokes/38</a><br />
&bull; <a href="http://www.wats.ca/articles/accesskeys/19">http://www.wats.ca/articles/accesskeys/19</a> (Many other articles on the right hand menu, I&#39;m not associated with them btw ;-) <br />

</div>
</li>
    </ol>
</form></div>



';



$helpfile["browse"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>browse()</h2><br />
This outputs the HTML file upload form element
<p><small>Parameters expected</small><br />
  <tt></tt><tt>$obj-&gt;browse( $label, $name, $required=&#39;&#39;, $MAX_FILE_SIZE=30000, $accept=&#39;&#39;,  $html_size=20, $helper=&#39;&#39;, $etc=&#39;&#39;, $post_text=&#39;&#39; );<br />
      </tt><br />
      <strong>Troubleshooting tip</strong>
      <br />

    Print out the superglobal $_FILES to troubleshoot and display details about uploaded file. <br />
    <tt>&nbsp; &nbsp;echo &#39;&lt;pre&gt;&#39;;<br />
&nbsp; &nbsp;print_r($_FILES);<br />
&nbsp; &nbsp;echo &#39;&lt;/pre&gt;&#39;;</tt></p>

<br /><p><strong>File Upload Common pitfalls </strong><br />
      <a href="http://www.php.net/manual/en/features.file-upload.common-pitfalls.php" target="_blank">http://www.php.net/manual/en/features.file-upload.common-pitfalls.php<br />
  </a><br />
  <strong>Error Codes </strong><br />
  Error messages correspond to error codes returned by PHP:<br />
  <a href="http://my2.php.net/manual/en/features.file-upload.errors.php%20">http://my2.php.net/manual/en/features.file-upload.errors.php </a><br />
  On the language files it is displayed at the end of the message as [Err No. <em>n</em>] </p>
  
  <br />
  <p><small>Parameter descriptions</small></p>
<form action="#" method="get" onsubmit="return false">
  <ol>
      <li> <tt>$label</tt> [<em>string or array</em>]<br />
        HTML &lt;label&gt; <em>$label</em> &lt;/label&gt;. <br />
        <br />
        <strong>1.1. For single line just use </strong><br />
        <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
        <br />
        <strong>1.2. For double lines like:</strong><br />
        <table width="400" class="tl rl bl ll">
          <tr>
            <td width="120">First Line:<br />
Second line here</td>
            <td>
              <input type="file" value="C:\Documents and Settings\Hew\Desktop\TO DO.txt" />
            </td>
          </tr>
        </table>
        <br />
    Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ...  );<br />
    <br />
    Note: accesskey is not accepted on this element </tt><br /><br />
    </li>
      <li><tt>$name</tt> [<em>string</em>] <br />
    The NAME attribute of the HTML <tt>&lt;input&gt; </tt>element.<br />
        <br />
    </li>
      <li><tt>$required</tt> [<em>nonempty </em>or<em> null </em>] <br />
    Use only nonempty for required field or empty quotes &quot;&quot; for optional field<br />
        <br />
    </li>
      <li>      <tt>$MAX_FILE_SIZE</tt> [<em>bytes value - integer</em>] <br />
  This creates a hidden field <tt>&lt;input type=&quot;hidden&quot; name=&quot;MAX_FILE_SIZE&quot; value=&quot;&#39;.$MAX_FILE_SIZE.&#39;&quot; /&gt;, it </tt> controls the Maximum file size the script accepts, but only if its within the limits set with <em>upload_max_filesize</em> in php.ini<br />
  <br />
  If you do not have direct access to php.ini, then you can change it with the Apache .htaccess method.<br />
  Place this in the same directory the script is running with filename .htaccess (or the otherwise configured filename).<br />
  <tt># upload_max_filesize<br />
  php_value upload_max_filesize 32M</tt><br />
  <br />
  32M is short for 32 megabytes, otherwise enter as bytes.<br />
  <br />
  <strong>Issues:</strong> Using .htaccess to update PHP configurations will work only  if PHP is running as a module, not if PHP is run as CGI. It will also not work on Microsoft IIS (Author&#39;s note: I looked and I dugged, but did not find any ways to do this on Microsoft IIS, does anybody know a way?).<br />
  <br />
    </li>
      <li><tt>$accept </tt>[<em>accepted file types</em>] <br />
        Use this as a filter for accepted file types, although this is a valid <a href="http://www.w3.org/TR/REC-html40/interact/forms.html#adef-accept" target="_blank">w3 spec</a> and the <em>accepted</em>   attribute IS created within the tag, it does not seem to work on any client that was tested. however the file types are validated with PHP instead. File types looks like: &quot;application/msword,  application/rtf, application/pdf&quot;<br />
        <br />
    </li>
      <li><tt>$html_size</tt> [<em>integer</em>] <br />
This is the HTML SIZE attribute for TEXT fields.<br />
<br />  
    </li>
      <li><tt>  $helper</tt> [<em>any</em>]<br />
    The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
    will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
    <br />
    </li>
      <li><tt>    $etc</tt> [<em>custom form attributes</em>]  <br />
    Place additional code / parameters here such as user events or CSS stylings<br />
    <br />
    </li>
      <li><tt>    $post_text</tt> [s<em>tring</em>] <br />
    This will appear right after the form element, HTML tags can be placed here. This is great for short descriptions.<br />
    <br />
    eg: Label:&nbsp; &nbsp; &nbsp;    
    <input type="file" size="20" maxlength="5" /> 
    ... $post_text appears here ... </li>
  </ol>
</form></div>



';



$helpfile["button"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>button()</h2>

<p>Outputs submit, reset, image button or button element</p>
  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;button( $type, $label, $name, $value_or_src, $etc=&#39;&#39;, $post_text=&#39;&#39;, $post_text_position=&#39;horizontal&#39; );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
    <ol>
      <li><tt>$type</tt> ( <em>submit, reset, button or image </em> )<br />
Change the $type parameter to switch between button types.<br />
<br />
If $type is <em>image</em> then insert the SRC attribute on the <tt>$value_or_src</tt> parameter.<br /><br />
</li>
      <li><tt>$label</tt> [<em>string</em> or array]<br />
        HTML &lt;label&gt; <em>input</em> &lt;/label&gt; . <br />
        <br />
        <strong>1.1. For single line just use </strong><br />
        <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
        <br />
        <strong>1.2. For double lines like:</strong><br />
        <table width="400" class="tl rl bl ll">
    <tr>
      <td width="120">First Line:<br />
        Second line here</td>
      <td>        
        <input type="button" name="Button" value="Button" />
      </td>
    </tr>
        </table>
        <br />
Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ... ); <br />
<br />
</tt></li>
      <li>
    <tt>$name</tt> [<em>string</em>]<br />
    The NAME attribute of the HTML  element.<br />
    <br />
      </li>
      <li>    <tt>$value_or_src</tt> [<em>string</em>]<br />
        If $type is <em>button</em>, <em>submit</em> or <em>reset</em>, then input will be used for HTML VALUE attribute. <br />
        <br />
        If $type is <em>image</em>, this parameter accepts  the SRC attribute.<br />
The library internals uses the PHP function <em>getimagesize() </em> to get the image width and height. <br />
      <br />
      </li>
      <li>  <tt>$etc</tt> [<em>any</em>]<br />
  Place additional code / parameters here such as user events or CSS stylings<br />
    <br />
    </li>
      <li><tt> $post_text</tt> [s<em>tring</em>] <br />
This will appear right after the form element, HTML tags can be placed here. This is great for short descriptions.<br />
<br />
      </li>
      <li><tt>$post_text_position</tt> [<em>string</em>]<br />
	    Position of text that appear after the button. Example below is the default &quot;horizontal&quot; position<br />
	    <br />
	    <table summary="" class="tl rl bl ll">
<tbody><tr>
  <td><strong>
  <input value="Horizontal" type="button" />
  &nbsp;</strong></td>
<td class="ll"> . <small style="font-size: 10px;"><a href="{$thispage}#" onclick="return false">Secondary action</a></small>
</td>
</tr></tbody></table>

        <br />
      The <em>secondary action</em> link above is from <tt>$post_text</tt>.<br />
      <br />
      If <tt>$post_text_position</tt> not &quot;horizontal&quot;, <tt>$post_text</tt> will appear next to the button. Just include a &lt;br /&gt; to make it break to next line. <br />
        <br />
        <input value="No Table" type="button" />
        <br />
        . <small style="font-size: 10px;"><a href="{$thispage}#" onclick="return false">Secondary action</a></small>      </li>
    </ol>
</form></div>



';



$helpfile["checkbox"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>checkbox()</h2>
<p>Output checkbox form element.</p>
<p>ALERT! From 0.5.10B onwards the $etc parameter has been dropped. Please check point 4 below <tt>$radio_list_array</tt> on its implementation. </p>
<small>Parameters expected</small>
<tt><br />
$obj-&gt;checkbox( $label, $group_name, $initially_checked_array, $checkbox_list_array, $required=&#39;&#39;, $positions=&#39;horizontal&#39;, $helper=&#39;&#39;, $post_text=&#39;&#39;, $columns=&#39;&#39; );</tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
    <ol>
      <li><tt>$label</tt> [<em>string</em> or array]<br />
HTML &lt;label&gt; <em>input</em> &lt;/label&gt; . <br />
<br />
<strong>1.1. For single line just use </strong><br />
<tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
<br />
<strong>1.2. For double lines like:</strong><br />
<table width="400" class="tl rl bl ll">
  <tr>
    <td width="120">First Line:<br />
      Second line here</td>
    <td>
      <input type="checkbox" name="checkbox" value="checkbox" />Item one
      <input type="checkbox" name="checkbox" value="checkbox" />Item two
	</td>
  </tr>
</table>
<br />
Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ... ); <br />
<br />
</tt></li>
      <li>
    <tt>$group_name</tt> [<em>string</em>]<br />
    The NAME attribute of the HTML &lt;checkbox&gt; element.<br />
    <br />
      </li>
      <li>    <tt>$initially_checked</tt> [<em>string</em>]<br />
      The initial checked element<br />
      <br />
      </li>
      <li><tt> $checkbox_list_array</tt> [<em>array</em>]<br /> 
        Example:<br>
<tt>$checkbox_list_array[&quot;travel&quot;] = &quot;Traveling&quot;;<br />
$checkbox_list_array[&quot;movies&quot;] = &quot;Film Buff&quot;;<br />
$checkbox_list_array[&quot;music&quot;] = &quot;Music Lover&quot;;<br /></tt>
<br />
Output:<br>
<tt>&lt;input type=&quot;checkbox&quot; value=&quot;travel&quot; /&gt;Traveling</tt>

<p><strong>Adding $etc parameter </strong><br />
The $etc parameter is implemented differently on radio and checkbox elements<br />
<tt>$checkbox_list_array[&quot;travel&quot;] = array( &quot;Traveling&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );<br />
$checkbox_list_array[&quot;movies&quot;] = array( &quot;Film Buff&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );<br />
$checkbox_list_array[&quot;music&quot;] = array( &quot;Music Lover&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );</tt></p>

<br />

      </li>
      <li> <tt>$required</tt> [<em>validation rules: Range syntax eg: 1|5</em>]<br />
        &quot;<tt>0|0</tt>&quot; No selection possible<br />
&quot;<tt>0<a>|1</a></tt>&quot; Maximum 1<br />
&quot;<tt>1|*</tt>&quot; Minimum 1<br />
&quot;<tt>0|5</tt>&quot; Between 0 and 5<br />
&quot;<tt>2|6</tt>&quot; between 2 and 6<br />
&quot;&quot; Empty quotes denote optional field<br />
        <br />
      </li>
      <li> <tt>$positions</tt> [<em>string</em>. <em>Options: </em>&quot;<em>horizontal</em>&quot;<em> or </em>&quot;<em>vertical</em>&quot;]<br />
<br />
<table width="400" summary="" class="tl rl bl ll">
  <tr>
    <td class="bl"><strong>horizontal</strong> (default value):</td>
    <td class="bl">
		<input type="checkbox" name="checkbox" value="checkbox" />Banana
		<input name="checkbox" type="checkbox" value="checkbox" />Kiwi</td>
  </tr>
  <tr>
    <td><strong>vertical </strong>:</td>
    <td>
      <input type="checkbox" name="checkbox" value="checkbox" />Banana<br />
      <input name="checkbox" type="checkbox" value="checkbox" />Kiwi
	</td>
  </tr>
</table>




<br />
      </li>

      <li><tt>$helper</tt> [<em>string</em>]<br />
  The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
<br />
    </li>
      <li> <tt>$columns</tt> [<em>integer</em>]<br />
      Will be displayed in multi-column table, below is example when $column is 2 <br />
<table summary="" class="tl rl bl ll" width="300">
  <tbody><tr>
    <td>
      <input type="checkbox" name="checkbox" value="checkbox" />Banana<br />
      <input name="checkbox" type="checkbox" value="checkbox" />Kiwi</td>
    <td class="ll">
      <input type="checkbox" name="checkbox" value="checkbox" />Mango<br />
      <input type="checkbox" name="checkbox" value="checkbox" />Orange</td>
  </tr>
</tbody></table>
      </li>
    </ol>
	
</form></div>



';



$helpfile["css_selectors"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>CSS selectors used </h2>

<table width="99%" summary="" class="css_selectors">
  <tr>
    <td class="top f11">

    <h3>Custom Selectors:</h3>

<ol class="cssColors">
  <li><strong class="red">.fieldRow</strong> <span class="black">{ }<br />
    Wraps each row of elements</span></li>
  <li><strong class="orange">.helper</strong> <span class="black">{ }<br />
    Used for the $helper parameter, this should always be display: none; by default</span>  </li>
  <li><strong class="green">label</strong>  <span class="black">{ }<br />
    Customize the HTML label element</span>  </li>
  <li><strong class="red">.fieldCell</strong> <span class="black">{ }<br />
    Right hand side form elements, including all subgrouped elements</span>, alert messages and the helper box.  </li>
  <li><strong class="red">.req</strong> <span class="black">{ } <br />
    The required field mark</span>  </li>
  <li><strong class="red">.alertmsg</strong> <span class="black">{ }<br />
    For display of JavaScript validation alert  messages</span>  </li>
  <li><strong class="red">.grouper</strong> <span class="black">{ }<br />
    Used for wrapping checkbox, radio elements</span>  </li>
  <li><strong class="lightblue">.form_columns</strong> <span class="black">{ }<br />
    This controls the  multi-column table as seen on screenshot <span class="lightblue">(No.8)</span> </span></li>
  <li><strong class="red">.group</strong> <span class="black">{ }<br />
    Default selector for grouped elements</span></li>
  <li><strong class="red">.sublabel</strong> <span class="black">{ }<br />
    The textarea counter output display area</span>  </li>
  <li><strong class="lightblue">.form_button_table</strong> <span class="black">{ }<br />
    Holding table</span><span class="black"> for the button() element when in horizontal position</span> </li>
  <li><strong class="red">.req_line</strong> <span class="black">{ }<br />
    Mandatory fields footnote  &lt;div&gt; box  </span>  </li>
  <li><span style="text-decoration:line-through"><strong> .fieldAlert { }</strong></span> ** Deprecated <br />
    <span style="text-decoration:line-through">(not in image) For PHP validation use, if PHP validation failed, .fieldCell will be replaced with .fieldAlert. Appearance of radio or checkbox elements within this block is controlled through CSS inheritance.</span></li><li><strong> .failed</strong> { }<br />
    (not in image) For PHP validation use, if PHP validation failed, it is nested within .fieldAlert. This is for individual elements within .fieldAlert. ie: select, textarea, text fields.</span></li>
  <li>.<strong>alert_header</strong> { }<br />
    (not in image) For PHP validation use, displays the line &quot;Alert! some fields require your attention&quot;</li>
  <li>.<strong>u</strong> { text-decoration: underline }<br />
    Underlines accesskey character if found in &lt;label&gt; <br />
        <br />
  </li>
</ol>

<h3>HTML Tags </h3>
<p>Redefine these tags below in addition to the custom selectors for more formating control. </p>
<p>form, fieldset, label, legend, input, option, select, textarea, noscript.</p>
    </td>
    <td width="377" class="greybg" style="vertical-align:top"><img src="images/css_selectors_all.png" alt="Screenshot form screen capture" width="377" height="629" /></td>
  </tr>
</table>
</div>



';



$helpfile["external_crosscheck_msg"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>external_crosscheck_msg( associative array )</h2>

<p>Submitted form values can be crosschecked on an external data source such as a database, if certain form fields contain rejected data, error messages can be inserted into the form via this method.</p>
  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;external_crosscheck_msg( array(&quot;field_name&quot;=&gt; array(&quot;errmsg&quot;=&gt;&quot;Custom error message here&quot;) );<br />
  </tt>
  <p>IMPORTANT! Currently this feature works only for string values and not array values aka checkboxes and multi-select drop down boxes. </p>
  <p><small>Example usage</small></p>
  <pre>
// Code to create form
$obj = new fp_Form( BASE_URL );
$obj-&gt;form_start( $_SERVER['."'".'PHP_SELF'."'".'], &quot;eg4&quot;, &quot;post&quot;, true, '."'".'class=&quot;eg4&quot;'."'".' );
$obj-&gt;text( &quot;Username&quot;, &quot;username&quot;, &quot;&quot;, &quot;nonempty&quot; );

...

// After form submitted and all validation passed

if( $obj->validate_check() === true )
{
	/*
	* Check database if value exist.
	* Or in this case just hardcode expected value for example
	*/	
   if( $_POST["username"] == &quot;george&quot; )
   {
      $error_array = array();
      $match_found = &quot;The Username '."'".'.$_POST["username"].'."'".' already taken, please choose another.";
	  
      $error_array[&quot;username&quot;][&quot;errmsg&quot;] = $match_found;
      $obj->external_crosscheck_msg( $error_array );

	/*
	* Expected associative array
	*
	* $expected_array = array[<em>expected_field_name</em>][&quot;errmsg&quot;];
	*
	* or
	*
	* $errmsg_arr = array( &quot;errmsg&quot; =&gt; &quot;Error message placed here&quot; );
	* $expected_array =  array( <em>expected_field_name</em> =&gt; $errmsg_arr );
	*/
   }
}


Example output looks like:
<form>
<table width="300" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td><strong>Username</strong><span class="req"></span> </td>
    <td><input type="text" name="username" id="username" value="george" size="20" maxlength="40"  /></td>
  </tr>
</table>
<div id="username_amsg" class="alertmsg" style="color: red;">The Username '."'".'george'."'".' already taken, please choose another.</div>
<noscript><div class="helper" style="display: block">Check if the username george is taken.</div></noscript>
</form>
</pre>
</div>



';



$helpfile["fieldset"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>fieldset()</h2>
<p>Outputs the HTML fieldset element.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;fieldset( $action, $legend=&#39;&#39;, $etc=&#39;&#39; );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
  <ol>
    <li><tt>$action</tt> [&quot; <em>start&quot; or &quot;end&quot; only</em>]<br />
&quot;<strong>start</strong>&quot; will render the <tt>&lt;fieldset&gt;</tt> tag, while &quot;<strong>end</strong>&quot; will render the <tt>&lt;/fieldset&gt;</tt> tag<br />
      <br />
    </li>
    <li> <tt>$legend</tt> [ <em>string</em>]<br />
      The HTML <tt>&lt;legend&gt; tag &lt;/legend&gt; </tt><br />
      <br />
      </li>
    <li><tt>$etc</tt> [<em>any</em>]<br />
      Place additional code / parameters here such as user events or CSS stylings</li>
  </ol></div>



';



$helpfile["form_start"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>form_start()</h2>
<p>Outputs the starting &lt;form&gt; tag.</p>

  <small>Parameters expected</small>
  <p><tt>$obj-&gt;form_start( $action=&#39;&#39;, $name=&#39;&#39;, $method=&#39;post&#39;, $validate=false, $etc=&#39;&#39; );</tt></p>
  <p><small>Parameter descriptions </small></p>
  <ol>
    <li><p><tt>$action</tt> ( <em>URL</em> )<br />
    This is the form action</p>
    </li>
    <li>
      <p><tt>$name</tt> ( <em>string</em> )<br />
      The NAME attribute of this HTML element.<br />
      </p>
    </li>
    <li><p><tt>$method</tt> ( <em>get or post</em> )<br />
      The METHOD of the form tag <br />
    </p>
    </li>
    <li><p><tt>$validate</tt> (<em> true or false</em> )<br />
      Form will be validated if set to &quot;true&quot;</p>
    </li>
    <li><p><tt>$etc </tt>( <em>custom form attributes</em> )<br />
Place additional code / parameters here such as user events or CSS stylings</p></li>
  </ol></div>



';



$helpfile["fp_Form"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>fp_Form()</h2>

<p>Output the completed form.</p>

<tt>
  $obj-&gt;fp_Form( BASE_URL, $show_req_line, $show_label );</tt><br />
  <br />
  
<ol>
  <li><small><tt>BASE_URL</tt></small><br />
  BASE_URL is a constant here, its needed for getting the question mark icon for the '."'".'form helper'."'".' feature. 
  A web path that points to your site'."'".'s root like: http://www.filepocket.org/ is expected.<br />
  In this case it is assumed that the helper icon is located at http://www.filepocket.org/images/
<br /><br />
</li>

<li><small><tt>$show_req_line</tt></small> [<em>top, bottom or false</em>]<br />
Position and visibility of the Required line "* Denotes Required field"
$f2->show_req_line = '."'".'top'."'".';<br />
top - Will display on the top of the form.<br />
bottom - Default value, will display on the bottom of the form.<br /> 
false - Hides it. <br /><br />
</li>

<li><small><tt>$show_label</tt></small> [<em>true or false</em>]<br />
Shows or hides the 
  <tt>&lt;label&gt;</tt> tag and its contents.<br />
  true - Default value, shows label<br />
  false - hides label
  <br />
<br />
</li>


</ol>
</div>



';



$helpfile["group"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>group()</h2>

<p>Creates &lt;div&gt; block wrappers for visual formating.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;group( $toggle, $css=&#39;class=&quot;group&quot;&#39; );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
  <ol>
    <li>
      <tt>$toggle</tt> [&quot;<em>start</em>&quot;<em> or </em>&quot;<em>end</em>&quot;]<br />
&quot;<strong>start</strong>&quot; will render a wrapper <tt>&lt;div&gt;</tt> tag, while &quot;<strong>end</strong>&quot; will render the <tt>&lt;/div&gt;</tt> tag<br />
  <br />
    </li>
    <li><tt>$css</tt> [<em>custom CSS selector</em>] <br />
      Custom CSS class name can be inserted here, for controlling appearance
      such as making the grouped area background a different color. If left undefined, the default value will be  class=&quot;group&quot;.<br />
    </li>
  </ol></div>



';



$helpfile["help"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>help() - mini reference system</h2>

  <small>Parameters expected</small>  
  <p><tt>$obj-&gt;help( $which_element );</tt></p>
  <p><small> Parameter descriptions </small></p>
<ol>
<li><tt>$which_element</tt> [<em>methods name</em>]<br />
  Any public method to display detailed description
<p>use <tt>$obj-&gt;help();</tt> to output the code template like the following example .</p>
</li>
</ol>
<div class="ht">


<form action="#" method="get" onsubmit="return false;">

Click to show code.<br />
<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'accesskey'."'".'); return false;" >accesskey()</a></big></strong></div>
<div id="accesskey">
<textarea onclick="this.focus(); this.select();" rows="2" cols="50">
$f->accesskey( $key );
</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'accesskey'."'".'); return false;">browse() - File upload element</a></big></strong></div>
<div id="browse">
<textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->browse( 
	$label, $name, $required="", 
	$MAX_FILE_SIZE=30000, $accept = "", 
	$html_size=20, $helper="", $etc="", $post_text=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'button'."'".'); return false;">button() - submit, button and reset types</a></big></strong></div>
<div id="button"><textarea onclick="this.focus(); this.select();" rows="6" cols="50">
/*
$f->button(
	$type, $label, $name, $value,
	$etc="", $post_text="", $post_text_position=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'checkbox'."'".'); return false;">checkbox()</a></big></strong></div>
<div id="checkbox"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->checkbox(
	$label, $group_name,
	$initially_checked_array, $checkbox_list_array, $required="",
	$positions="horizontal", $helper="", $etc="", $post_text="", $columns=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'css_selectors'."'".'); return false;">CSS Selectors</a></big></strong></div>
<div id="css_selectors"><textarea onclick="this.focus(); this.select();" rows="21" cols="50">
form { }
fieldset { }
label { }
legend { }
input { }
option { }
select { }
textarea { }
.fieldRow { }
.helper { }
.fieldCell { }
.req { }
.alertmsg { }
.failed input, .failed select { }
.grouper { }
.form_columns { }
.group { }
.sublabel { }
.form_button_table { }
.req_line { }
.fieldAlert { }</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'external_crosscheck_msg'."'".'); return false;">external_crosscheck_msg()</a></big></strong></div>
<div id="external_crosscheck_msg"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
Place within
if ( $f->validate_check() === true )
*/
$error_array[<em>field_name</em>]["errmsg"] = $error_message;
      $obj->external_crosscheck_msg( $error_array );
</textarea></div>

<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'fieldset'."'".'); return false;">fieldset()</a></big></strong></div>
<div id="fieldset"><textarea onclick="this.focus(); this.select();" rows="5" cols="50">
/*
$f->fieldset(
	$start_or_end, $fieldset_legend="", $etc=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'form_start'."'".'); return false;">form_start()</a></big></strong></div>
<div id="form_start"><textarea onclick="this.focus(); this.select();" rows="4" cols="50">
$f = new fp_Form( BASE_URL );

$f->form_start($action="", $name="", $method="post", $validate=false ,$etc="" );</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'fp_Form'."'".'); return false;">fp_Form() - Class declaration</a></big></strong></div>
<div id="fp_Form"><textarea onclick="this.focus(); this.select();" rows="3" cols="50">
$f = new fp_Form( BASE_URL, $show_required_line = '."'".'bottom'."'".', $show_label = true );
// The second and third parameters are default values
</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'group'."'".'); return false;">group()</a></big></strong></div>
<div id="group"><textarea onclick="this.focus(); this.select();" rows="5" cols="50">
/*
$f->group(
	$start_or_end, $css=&#39;class="group"&#39;
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'hidden'."'".'); return false;">hidden()</a></big></strong></div>
<div id="hidden"><textarea onclick="this.focus(); this.select();" rows="4" cols="50">
/*
$f->hidden( $name, $value, $etc="" );
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'output'."'".'); return false;">Output Code</a></big></strong></div>
<div id="output"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
&lt;?php
echo $f->js_validate_code();
?&gt;
&lt;?php
echo $f->output();
?&gt;</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'passwordf'."'".'); return false;">password()</a></big></strong></div>
<div id="passwordf"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->password(
	$label, $name,
	$value, $required="",
	$html_size=20, $html_maxlength="", $helper="", $etc="", $post_text=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'radio'."'".'); return false;">radio()</a></big></strong></div>
<div id="radio"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->radio(
	$label, $group_name,
	$initially_checked, $radio_list_array, $required,
	$positions="horizontal", $helper="", $etc="", $post_text="", $columns=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'select'."'".'); return false;">select()</a></big></strong></div>
<div id="select"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->select(
	$label, $name,
	$initially_selected, $list_values, $required="",
	$helper="", $etc="", $post_text="", $mode="single", $html_rows=12
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'subgroup'."'".'); return false;">subgroup()</a></big></strong></div>
<div id="subgroup"><textarea onclick="this.focus(); this.select();" rows="5" cols="50">
/*
$f->subgroup(
	$start_or_end
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'tabindex'."'".'); return false;">tabindex()</a></big></strong></div>
<div id="tabindex"><textarea onclick="this.focus(); this.select();" rows="2" cols="50">
$f->tabindex( $integer );</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'text'."'".'); return false;">text()</a></big></strong></div>
<div id="text"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->text(
	$label, $name,
	$value, $required="",
	$html_size=20, $html_maxlength="", $helper="", $etc="", $post_text=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'textarea'."'".'); return false;">textarea()</a></big></strong></div>
<div id="textarea"><textarea onclick="this.focus(); this.select();" rows="7" cols="50">
/*
$f->textarea(
	$label, $name,
	$value, $required="",
	$html_cols=30, $html_rows=3, $helper="", $etc="", $post_text=""
);
*/</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'validation'."'".'); return false;">Validation rules</a></big></strong></div>
<div id="validation"><textarea rows="22" cols="50">
&#39;username&#39;
/^[^\W]{5,16}$/
Alphanumeric or &#39;_&#39; underscore, between 5 and 16 chars

&#39;email&#39;
/(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})/
Must be valid email address, from regexlib.com Darren Neimke

&#39;emailorblank&#39;
/(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})|(^\s*$)/
Email or blank (modified from regexlib.com Darren Neimke entry)

&#39;positive_number&#39;
/([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/
Modified from http://www.regular-expressions.info/floatingpoint.html

&#39;negpos_numbers&#39;
/[-+]?([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/
Negetive or positive, whole numbers or decimals, from http://www.regular-expressions.info/floatingpoint.html

&#39;nonempty&#39;
/\S/
Any character except tab, white space or new line character, not blank.

Range syntax &#39;n|n&#39;
For multiple selection fields
0|0 No selection possible
0|1 Maximum 1
1|* Minimum 1
0|5 Between 0 and 5
2|6 between 2 and 6
IMPORTANT! This will cause errors on elements where only a single value is expected.

Integer
Only used for the textarea element, the entered integer will be the limit of the textarea character counter. 
</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'variablesr'."'".'); return false;">Variables</a></big></strong></div>
<div id="variablesr">Running $f->help( <em>param</em> ) will display more details for each method, available are:

<textarea rows="10" cols="50">
1. validate_alert_bgcolor = [HTML color]
Reset the highlight color of form fields during validation error, Used for Javascript and PHP validation.
Expected format: #FF0000, transparent, #FF3300

2. validate_pass_bgcolor = [HTML color]
During Javascript validation, if a field is validated this color is used, default value is '."'".'transparent'."'".'.
</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'moreinfo'."'".'); return false;">More info</a></big></strong></div>
<div id="moreinfo">Running $f->help( <em>param</em> ) will display more details for each method, available are:

<textarea onclick="this.focus(); this.select();" rows="19" cols="50">
//$f->help("accesskey");
//$f->help("button");
//$f->help("checkbox");
//$f->help("css_selectors");
//$f->help("fieldset");
//$f->help("form_start");
//$f->help("group");
//$f->help("hidden");
//$f->help("output");
//$f->help("password");
//$f->help("radio");
//$f->help("select");
//$f->help("subgroup");
//$f->help("tabindex");
//$f->help("text");
//$f->help("textarea");
//$f->help("variables");
//$f->help("validation rules");</textarea></div>


<div>
<strong><big><a href="#" onclick="showhide( this , '."'".'getjs'."'".'); return false;">get JavaScript file</a></big></strong></div>
<div id="getjs">This is for the <em>textarea counter</em> and the <em>helper</em> (show / hide) functionality
<textarea onclick="this.focus(); this.select();" rows="3" cols="50">
&lt;script language=&quot;javascript&quot; type=&quot;text/javascript&quot; src=&quot;&lt;?php echo BASE_URL;?&gt;libraries/fp_Form/fp_Form.js&quot;&gt;&lt;/script&gt;
</textarea></div>


</form>


<script type="text/javascript">
<!--
// Hide all
var all_elements = new Array (
"accesskey", "browse", "button", "checkbox", "css_selectors", "external_crosscheck_msg", "fieldset", "form_start", "fp_Form",  "group",
"hidden", "output", "passwordf", "radio", "select", "subgroup", "tabindex", "text", "textarea", 
"validation", "variablesr", "moreinfo", "getjs"
);
counted = all_elements.length;

for ( i=0; i<counted; i++ )
{
	document.getElementById(all_elements[i]).style.display = "none";
}

function showhide( currentElement, element )
{
	var obj = document.getElementById(element);
	if( obj.style.display != "none" )
	{
		obj.style.display = "none";
	}
	else
	{
		obj.style.display = "block";
	}
	obj = "";
}
//-->
</script>

</div></div>



';



$helpfile["hidden"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>hidden()</h2>

<p>Creates a hidden form field.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;hidden( $name, $value=&#39;&#39; , $etc=&#39;&#39; );</tt>
  <p><small>Parameter descriptions</small></p>
  <ol>
    <li> <tt>$name</tt> [<em>string</em> or array]<br />
      The NAME attribute of the HTML  hidden  input element.<br />
      <br />
    </li>
    <li> <tt>$value</tt> [<em>any</em>] <br />
    The VALUE of the HTML form, just leave a pair of empty quotes if no default value<br />
    <br />
    </li>
    <li><tt> $etc</tt> [<em>any</em>] <br />
    Place additional code / parameters here such as user events or CSS stylings</li>
  </ol></div>



';



$helpfile["output"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>display()</h2>

<p>Output the completed form.</p>

<tt>
  $obj-&gt;display();</tt><br />
  <br />
  
  <small>Usage</small>:<br />
  On the location you want the form to appear do: <br />
<tt>echo $obj-&gt;display();</tt><br />
<br />


<h2>js_validation_code()</h2>
<p><tt>$obj-&gt;subgroup( $toggle );</tt><br /><br />
  <small>Usage</small>:<br />
  Place this within the <tt>&lt;head&gt;</tt> section of your page, it outputs the validation JavaScripts. <br />
<tt>echo $obj-&gt;js_validation_code();</tt> </p></div>



';



$helpfile["password"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>password()</h2>
<p>Creates a <em>password</em> form field.</p>

  <small>Parameters expected</small>
  <p><tt>$obj-&gt;password( $label, $name, $value=&#39;&#39;, $required=&#39;&#39;, $html_size=20, $html_maxlength=&#39;&#39;, $helper=&#39;&#39;, $etc=&#39;&#39;, $post_text=&#39;&#39; );</tt></p>
  <p><small>Parameter descriptions</small></p>
<form action="#" method="get" onsubmit="return false">
  <ol>
      <li> <tt>$label</tt> [<em>string or array</em>]<br />
        HTML &lt;label&gt; <em>input</em> &lt;/label&gt; . <br />
        <br />
        <strong>1.1. For single line just use </strong><br />
        <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
        <br />
        <strong>1.2. For double lines like:</strong><br />
        <table width="400" class="tl rl bl ll">
          <tr>
            <td width="120">First Line:<br />
Second line here</td>
            <td>
              <input value="form field" type="password" />
            </td>
          </tr>
        </table>
        <br />
    Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ...  ); </tt><br /><br />
    </li>
      <li><tt>$name</tt> [<em>string</em>] <br />
    The NAME attribute of the HTML <tt>&lt;input&gt; </tt>element.<br />
    <br />
    </li>
      <li><tt>$value</tt> [<em>any</em>] <br />
        The VALUE of the HTML form, just leave a pair of empty quotes if no default value.<br />
        <br />
      </li>
      <li><tt>$required</tt> [<em>available validation rules</em>] <br />
    Enter validation rule here, such as &quot;email&quot; or &quot;nonempty&quot;, leave blank if input is optional<br />
    <br />
    </li>
      <li><tt>$html_size</tt> [<em>integer</em>] <br />
        This is the HTML SIZE attribute for TEXT fields.<br />
        <br />
    </li>
      <li>      <tt>$html_maxlength</tt> [<em>integer</em>] <br />
  This is the HTML MAXLENGTH attribute for TEXT fields<br />
  <br />
    </li>
      <li><tt>  $helper</tt> [<em>any</em>]<br />
    The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
    <br />
    </li>
      <li><tt>    $etc</tt> [<em>custom form attributes</em>]  <br />
    Place additional code / parameters here such as user events or CSS stylings<br />
    <br />
    </li>
      <li><tt>    $post_text</tt> [s<em>tring</em>] <br />
    This will appear right after the form element, HTML tags can be placed here. This is great for short descriptions.<br />
    <br />
    eg: Label:&nbsp; &nbsp; &nbsp;    
    <input type="password" value="text" size="5" maxlength="5" /> 
    ... $post_text appears here ... </li>
  </ol>
</form>
  
  <p>&nbsp;</p>
  <p>This method is identical to text(), only difference is  the method name.</p></div>



';



$helpfile["radio"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>radio()</h2>
<p>Outputs radio form fields. </p>
<p>ALERT! From 0.5.10B onwards the $etc parameter has been dropped. Please check point 4 below <tt>$radio_list_array</tt> on its implementation. </p>
<small>Parameters expected</small>
<tt><br />
$obj-&gt;radio( $label, $group_name, $initially_checked, $radio_list_array, $required=&#39;&#39;, $positions=&#39;horizontal&#39;, $helper=&#39;&#39;, $columns=&#39;&#39; );</tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
    <ol>
      <li><tt>$label</tt> [<em>string</em> or array]<br />
HTML &lt;label&gt; <em>input</em> &lt;/label&gt; . <br />
<br />
<strong>1.1. For single line just use </strong><br />
<tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
<br />
<strong>1.2. For double lines like:</strong><br />
<table width="400" class="tl rl bl ll">
  <tr>
    <td width="120">First Line:<br />
      Second line here</td>
    <td>
      <input name="radiobutton" type="radio" value="radiobutton" /> 
      Item one 
      <input name="radiobutton" type="radio" value="radiobutton2" /> 
      Item 2 </td>
  </tr>
</table>
<br />
Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ... ); <br />
<br />
</tt></li>
      <li>
    <tt>$group_name</tt> [<em>string</em>]<br />
    The NAME attribute of the HTML &lt;radio&gt; element.<br />
    <br />
      </li>
      <li>    <tt>$initially_checked</tt> [<em>string</em>]<br />
      The initial checked element<br />
      <br />
      </li>
      <li><tt> $radio_list_array</tt> [<em>associative array</em>]<br />
      Example:<br>
      <tt>$checkbox_list_array[&quot;travel&quot;] = &quot;Traveling&quot;;<br />
$checkbox_list_array[&quot;movies&quot;] = &quot;Film Buff&quot;;<br />
$checkbox_list_array[&quot;music&quot;] = &quot;Music Lover&quot;;<br />
      </tt> <br />
Output:<br>
<tt>&lt;input type=&quot;checkbox&quot; value=&quot;travel&quot; /&gt;Traveling</tt>
<p><strong>Adding $etc parameter </strong><br />
  The $etc parameter is implemented differently on radio and checkbox elements<br />
  <tt>$checkbox_list_array[&quot;travel&quot;] = array( &quot;Traveling&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );<br />
  $checkbox_list_array[&quot;movies&quot;] = array( &quot;Film Buff&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );<br />
  $checkbox_list_array[&quot;music&quot;] = array( &quot;Music Lover&quot;, &quot;onclick='."'".'alert(\&quot;Do stuff\&quot;);'."'".'&quot; );</tt></p>
<br />

      </li>
      <li> <tt>$required</tt> [<em>validation rules</em>:<em> nonempty or other rule except the </em>&quot;<em>range</em>&quot;<em> rule</em>]<br />
        You can use &quot;nonempty&quot; or pre-select an initial value, if this is a required field<br />
        <br />
      </li>
      <li> <tt>$positions</tt> [<em>string</em>. <em>Options: </em>&quot;<em>horizontal</em>&quot;<em> or </em>&quot;<em>vertical</em>&quot;]<br />
<br />
<table width="400" summary="" class="tl rl bl ll">
  <tr>
    <td class="bl"><strong>horizontal</strong> (default value):</td>
    <td class="bl">
		<input name="a" type="radio" />Banana
		<input name="a" checked="checked" type="radio" />Kiwi</td>
  </tr>
  <tr>
    <td><strong>vertical </strong>:</td>
    <td><input name="b" type="radio" /> Banana<br />
		<input name="b" checked="checked" type="radio" /> Kiwi</td>
  </tr>
</table>




<br />
      </li>

      <li><tt>$helper</tt> [<em>string</em>]<br />
  The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
<br />
<br />
    </li>
      <li> <tt>$columns</tt> [<em>integer</em>]<br />
      Will be displayed in multi-column table, below is example when $column is 2 <br />
<table summary="" class="tl rl bl ll" width="300">
  <tbody><tr>
    <td>
	<input name="c" type="radio" /> Banana<br />
    <input name="c" checked="checked" type="radio" /> Kiwi</td>
    <td class="ll">
	<input name="c" type="radio" /> Mango<br />
    <input name="c" type="radio" /> Orange</td>
  </tr>
</tbody></table>
      </li>
    </ol>
    <p>&nbsp;</p>
</form></div>



';



$helpfile["select"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>select()</h2>
<p>Creates single or multiple <em>select</em> combo boxes.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;select( $label, $name, $initially_selected, $list_values, $required=&#39;&#39;, $helper=&#39;&#39;, $etc=&#39;&#39;, $post_text=&#39;&#39;, $mode=&#39;single&#39;, $html_rows=12 );</tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
 
    <ol>
      <li> <tt>$label</tt> [<em>string</em> or array]<br />
        HTML &lt;label&gt; <em>input</em> &lt;/label&gt; . <br />
        <br />
        <strong>1.1. For single line just use </strong><br />
        <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
        <br />
        <strong>1.2. For double lines like:</strong><br />
        <table width="400" class="tl rl bl ll">
          <tr>
            <td width="120">First Line:<br />
      Second line here</td>
            <td>
              <select name="select">
                <option>selection</option>
              </select>
</td>
          </tr>
        </table>
        <br />
Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ... ); </tt><br />
      <br />
      </li>
      <li>    <tt>$name</tt> [<em>string</em>]<br />
      The NAME attribute of the HTML &lt;select&gt; element.<br />
      <br />
      </li>
      <li>    <tt>$initially_selected</tt> [ <em>String or Array depending of $mode</em>]<br />
      The initial selected list value, if $mode is &quot;multiple&quot; array is expected, eg: array(&quot;value1&quot;,&quot;value2&quot;)<br />
      <br />
      </li>
      <li><tt>    $list_values</tt> [<em>associative array</em>]<br />
      Eg: <tt>array( &quot;DE&quot;=&gt;&quot;Germany&quot;, &quot;DJ&quot;=&gt;&quot;Djibouti&quot;, &quot;DK&quot;=&gt;&quot;Denmark&quot; );</tt><br />
      <br />
      <br />
      </li>
      <li>    <tt>$required </tt>[<em>validation rules: Range syntax eg: 1|5</em>]<br />
      <br />
      If <tt>$mode</tt> is &quot;<strong>multiple</strong>&quot;<br />
&quot;<tt>0|0</tt>&quot; No selection possible<br />
&quot;<tt>0<a>|1</a></tt>&quot; Maximum 1<br />
&quot;<tt>1|*</tt>&quot; Minimum 1<br />
&quot;<tt>0|5</tt>&quot; Between 0 and 5<br />
&quot;<tt>2|6</tt>&quot; between 2 and 6<br />
&quot;&quot; Empty quotes denote optional field<br />
  <br />
  If <tt>$mode</tt> is &quot;<strong>single</strong>&quot;<br />
  Use &quot;nonempty&quot; validation rule to make sure a valid non-blank item is selected.<br />
            <br />
            <br />
      </li>
      <li>      <tt>$helper</tt> [<em>string</em>]<br />
        The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
<br />
      </li>
      <li><tt>$etc</tt> [<em>any</em>]<br />
      Place additional code / parameters here such as user events or CSS stylings<br />
      <br />
      </li>
      <li><tt>    $post_text</tt> [<em>string</em>]<br />
  This will appear right after the form element, HTMl tags can be placed here. <br />
  <table width="400" class="tl rl bl ll">
    <tr>
      <td width="120">Label:</td>
      <td>
        <select>
          <option>Selection</option>
        </select>
... Post text appears here ... </td>
    </tr>
  </table>
    <br />
      </li>
      <li><tt> $mode</tt> [<em>string. Options: </em>&quot;<em>single</em>&quot;<em> or </em>&quot;<em>multiple</em>&quot;]<br />
        For multiple line selection box, use &quot;multiple&quot;, for single line, enter &quot;single&quot;. The default is &quot;single&quot;.<br />
        <br />
      </li>
      <li><tt> $html_rows</tt> [<em>integer</em>]<br />
  This is the HTML ROWS attribute for SELECT fields, for row height.<br />
      </li>
    </ol>
  </form></div>



';



$helpfile["set_upload_dir"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>set_upload_dir()</h2>
<p>Set active directory where files will be uploaded. Required by <tt>browse()</tt>.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;set_upload_dir( $directory );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
<form action="#" method="get" onsubmit="return false">
    <ol>
      <li><tt>$directory</tt> ( <em>system path to directory </em> )<br />
 This is tied to the <tt>browse()</tt> function for file uploads, files will be uploaded to <tt>$directory</tt>. <br />
        <br />
        Examples: <br />
        Linux: <tt>/home/filepocket/public_html/</tt><br />
Windows: <tt>c:/Apache2/htdocs/filepocket/public_html/</tt></li>
  </ol>
</form>
</div>



';



$helpfile["subgroup"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>subgroup()</h2>
<p>Create subgrouped elements, subgouped elements will reside within the same row as opposed to a new row for each element.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;subgroup( $toggle );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
  <ol>
    <li>
      <p> <tt>$toggle</tt> [&quot;<em>start</em>&quot;<em> or </em>&quot;<em>end</em>&quot;] <br />
  Everthing within <tt>$obj-&gt;subgroup(&quot;<strong>start</strong>&quot;)</tt> and <tt>$obj-&gt;subgroup(&quot;<strong>end</strong>&quot;)</tt> will be placed next to each other. Only the item immediately following the &quot;start&quot; declaration will have the <tt>&lt;label&gt;</tt> tag.</p>
  <form action="#" method="get" onsubmit="return false">
     <table width="80%" summary="" class="tl rl bl ll">
       <tr>
         <td width="80">Label here:</td>
         <td>
           <input value="subgrouped item 1" type="text" />
           <input value="subgrouped item 2" type="text" />
</td>
       </tr>
     </table>
     </form>
      <br />
    </li>
    </ol></div>



';



$helpfile["tabindex"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>tabindex()</h2>
<p>Inserts <em>tabindex</em> HTML attribute, use for keyboard navigation.</p>

  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;tabindex( interger [string to halt] );<br />
  </tt>
  <p><small>Parameter descriptions</small></p>
<form action="#" method="get" onsubmit="return false">
  <ol>
    <li><tt>interger</tt><br />
      This outputs the HTML attribute <em>tabindex</em> onto a form element, use it to control keyboard navigation or tab order.<br />
      <br />
      Insert <tt>tabindex()</tt> right before the item you wish to assign the <em>tabindex</em> to, all elements thereafter will increment the previous <em>tabindex</em> by 1 until the end of the form or you can explicitly stop <em>tabindex</em> insertion by declaring <tt>tabindex(&#39;stop&#39;);</tt><br />
      <tt><br />
      $obj-&gt;tabindex(1);<br />
      $obj-&gt;text(&#39;Field A&#39;, &#39;textboxA&#39; ); // tabindex = 1 <br />
      $obj-&gt;text(&#39;Field B&#39;, &#39;textboxB&#39; ); // tabindex = 2 <br />
      $obj-&gt;tabindex(&#39;stop&#39;);<br />
$obj-&gt;text(&#39;Field C&#39;, &#39;textboxC&#39; ); // No tabindex  here</tt><br />
<br /> 
You will get Warning messages if a <em>tabindex</em> number has already been taken up (by this script).<br />
<br />
      Google <a href="http://www.google.com/search?hl=en&lr=&rls=RNWF,RNWF%3A2004-28,RNWF%3Aen&q=tabindex+and+accessibility&btnG=Search" target="_blank">tabindex and accessibility</a> for research on <em>tabindex</em>.<br />
      <br />
    </li>
  </ol>
</form>
</div>



';



$helpfile["text"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>text()</h2>
<p>Creates a single line text input form field.</p>

  <small>Parameters expected</small>
  <p><tt>$obj-&gt;text( $label, $name, $value=&#39;&#39;, $required=&#39;&#39;, $html_size=20, $html_maxlength=&#39;&#39;, $helper=&#39;&#39;, $etc=&#39;&#39; , $post_text=&#39;&#39; );</tt></p>
  <p><small>Parameter descriptions</small></p>
<form action="#" method="get" onsubmit="return false">
  <ol>
      <li> <tt>$label</tt> [<em>string or array</em>]<br />
        HTML &lt;label&gt;<em> $label</em> &lt;/label&gt;. <br />
        <br />
        <strong>1.1. For single line just use </strong><br />
        <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
        <br />
        <strong>1.2. For double lines like:</strong><br />
        <table width="400" class="tl rl bl ll">
          <tr>
            <td width="120">First Line:<br />
Second line here</td>
            <td>
              <input value="form field" type="text" />
            </td>
          </tr>
        </table>
        <br />
    Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ...  ); </tt><br /><br />
    </li>
      <li><tt>$name</tt> [<em>string</em>] <br />
    The NAME attribute of the HTML <tt>&lt;input&gt; </tt>element.<br />
    <br />
    </li>
      <li><tt>$value</tt> [<em>any</em>] <br />
        The VALUE of the HTML form, just leave a pair of empty quotes if no default value.<br />
        <br />
      </li>
      <li><tt>$required</tt> [<em>available validation rules</em>] <br />
    Enter validation rule here, such as &quot;email&quot; or &quot;nonempty&quot;, leave blank if input is optional<br />
    <br />
    </li>
      <li><tt>$html_size</tt> [<em>integer</em>] <br />
        This is the HTML SIZE attribute for TEXT fields.<br />
        <br />
    </li>
      <li>      <tt>$html_maxlength</tt> [<em>integer</em>] <br />
  This is the HTML MAXLENGTH attribute for TEXT fields<br />
  <br />
    </li>
      <li><tt>  $helper</tt> [<em>any</em>]<br />
    The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
    will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
    <br />
    </li>
      <li><tt>    $etc</tt> [<em>custom form attributes</em>]  <br />
    Place additional code / parameters here such as user events or CSS stylings<br />
    <br />
    </li>
      <li><tt>    $post_text</tt> [s<em>tring</em>] <br />
    This will appear right after the form element, HTML tags can be placed here. This is great for short descriptions.<br />
    <br />
    eg: Label:&nbsp; &nbsp; &nbsp;    
    <input type="text" value="text" size="5" maxlength="5" /> 
    ... $post_text appears here ... </li>
  </ol>
</form></div>



';



$helpfile["textarea"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>textarea()</h2>
<p>Creates a multi-line text input field.</p>


  <small>Parameters expected</small>
  <tt><br />
  $obj-&gt;textarea( $label, $name, $value=&#39;&#39;, $required=&#39;&#39;, $html_cols=30, $html_rows=3, $helper=&#39;&#39;, $etc=&#39;&#39;, $post_text=&#39;&#39; );</tt>
  <p><small>Parameter descriptions</small></p>
  <form action="#" method="get" onsubmit="return false">
  <ol>
    <li> <tt>$label</tt> [<em>string or array </em>]<br />
      HTML &lt;label&gt; <em>input</em> &lt;/label&gt;. <br />
      <br />
      <strong>1.1. For single line just use </strong><br />
      <tt>$Obj-&gt;f( &quot;Label Line One&quot;, ... );</tt><br />
      <br />
      <strong>1.2. For double lines like:</strong><br />
      <table width="400" class="tl rl bl ll">
        <tr>
          <td width="120">First Line:<br />
      Second line here</td>
          <td>
            <input value="form field" type="text" />
          </td>
        </tr>
      </table>
      <br />
Use: <tt>$Obj-&gt;f( <strong>array(</strong>&quot;Label Line One&quot;,&quot;&lt;br /&gt;&lt;small&gt;Second line here&lt;/small&gt;&quot;) , ..., ... ); <br />
<br />
</tt></li>
    <li><tt>$name</tt> [<em>string</em>]<br />
      The NAME attribute of the HTML &lt;textarea&gt; form field.<br />
      <br />
    </li>
    <li>    <tt>$value</tt> [<em>any</em>] <br />
  The VALUE of the HTML form, just leave a pair of empty quotes if no default value<br />
  <br />
    </li>
    <li><tt>  $required</tt> [ <em>validation rules: string, integer </em>[<em>max characters</em>] ] <br />
    If an integer is detected, a character counter will be displayed, leave blank if input is optional<br />
    <br />
    </li>
    <li>    <tt>$html_cols</tt> [<em>integer</em>]<br />
    This is the HTML COLS attribute for TEXTAREA field.<br />
    <br />
    </li>
    <li><tt>    $html_rows</tt> [<em>integer</em>]<br />
    This is the HTML ROWS attribute for TEXTAREA field<br />
    <br />
    </li>
    <li><tt>$helper</tt> [<em>string</em>]<br />
      The &quot;?&quot; question mark icon will appear right after the element, entered values<br />
will be hidden initially until clicked. This is one available way to provide extra info for end-user.<br />
    <br />
    </li>
    <li> <tt>$etc</tt> [<em>any</em>]<br />
    Place additional code / parameters here such as user events or CSS stylings<br />
    <br />
    </li>
    <li><tt> $post_text</tt> [<em>string</em>]<br />
    This will appear right after the form element, HTML tags can be placed here. This is great for short descriptions.<br />
    <br />
    <table width="80%" class="tl rl bl ll">
      <tr>
        <td width="80" class="top">Label:</td>
        <td width="455">
          <textarea cols="20" rows="2">text</textarea>
          ... $post_text appears here ... <br />
</td>
      </tr>
    </table>
    </li>
  </ol>
  </form></div>



';



$helpfile["validation_rules"] = '<div class="docswraps"><div class="fright">fp_Form Help</div>
<h2>Default validation rules</h2>
They are regular expression patterns used for both Javascript and PHP validation
  <ol>
  <li><tt>username
    /^[^\W]{5,16}$/</tt><br />
    Alphanumeric or &#39;_&#39; underscore, between 5 and 16 chars<br />
    <br />
  </li>
  <li><tt> email /(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})/</tt><br />
  Must be valid email address, from regexlib.com Darren Neimke<br />
  <br />
  </li>
  <li><tt>emailorblank /(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})|(^\s*$)/</tt><br />
    Email or blank (modified from regexlib.com Darren Neimke entry) <br />
    <br />
  </li>
  <li>  <tt>positive_number /([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/</tt><br />
  Modified from <a href="http://www.regular-expressions.info/floatingpoint.html">http://www.regular-expressions.info/floatingpoint.html<br />
  <br />
  </a></li>
  <li><tt>negpos_numbers /[-+]?([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?/</tt><br />
    Negetive or positive, whole numbers or decimals, from <a href="http://www.regular-expressions.info/floatingpoint.html">http://www.regular-expressions.info/floatingpoint.html<br />
    <br />
    </a></li>
  <li><tt>nonempty /\S/</tt><br />
    Any character except tab, white space or new line character, not blank.<br />
    <br />
  </li>
  <li>Range syntax <tt><em>n</em>|<em>n</em></tt><br />
    For multiple selection fields<br />
<tt>0|0</tt> No selection possible<br />
<tt>0|1</tt> Maximum 1<br />
<tt>1|*</tt> Minimum 1<br />
<tt>0|5</tt> Between 0 and 5<br />
<tt>2|6</tt> between 2 and 6<br />
IMPORTANT! This will cause errors on elements where only a single value is expected.<br />
<br />
  </li>
  <li>Integer<br />
    Only used for the <em>textarea</em> element, the entered integer will be the limit of the <em>textarea</em> character counter. <br />
  </li>
</ol>
</div>



';



$helpfile["variables"] = '<div class="docswraps"><div class="fright">fp_Form Help</div><h2>Variables</h2>
<p>These variables can be reset to further customize the look and feel. <br />
    <br />
<!--   1. <tt class="f14"><strong>show_req_line</strong></tt> [<em>top, bottom, false</em>]

    <p>Hide or show the required line &quot;* Denotes Required field&quot;<br />
    <em>top</em> - Displays required line on top of form<br />
    <em>bottom</em> - Displays required line after the form - default value<br />
    <em>false</em> - Hide line<br />
    <br />
    <tt>$obj-&gt;show_req_line = &#39;bottom&#39;; // default </tt><br />
    <br /></p>
	
   4. <tt class="f14"><strong>show_label</strong></tt> [<em>true or false</em>]
  <p>Hides all <tt>&lt;label&gt;</tt> tags, default is true.</p> <br />
-->
	1. <tt class="f14"><strong>validate_alert_bgcolor</strong></tt> [<em>HTML color</em>]
    <p>Resets the highlight color of form fields during validation error<br />
    Expected format: #FF0000, transparent, #FF3300</p>    
    <br />
	
  2. <tt class="f14"><strong>validate_pass_bgcolor</strong></tt> [<em>HTML color</em>]<br />
  <p>For JS validation, if field is validated use this color.</p><br />
  


  </div>



';





?>