<html>
<head>
<title>Contact us</title>
</head>
<body>
<b>This is your contact us page.</b><br> You should insert the following line into the BODY section. <br> Also you should modify "ssconfig.php" file with your own settings.<br> See "ssconfig.php".<br><br>

<? include "contactus_a17.php";?>

</body>
</html>