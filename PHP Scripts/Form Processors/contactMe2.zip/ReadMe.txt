PHP contactMe form by Dave Lauderdale version 2.2b
This script was published at:  www.digi-dl.com

UPDATE: October 14th, 2003 - Bug fixed in email address input handling
UPDATE: November 18th, 2003 - Added input checks and fixed domain blocking issue

UPDATE: May 22nd, 2004 - Script was modified by Michal Hunger - modified php file 
is in enclosed zip called: modified.zip

UPDATE: Sept. 3rd 2005 - I recoded the script to work without register globals.


1) Set all your information in the "config.php" file.
2) Upload the "contactMe" folder to your webserver space.
3) Just link to: www.yoursite.com/php/contactMe/contactMe.htm 
4) To view log file go to: www.yoursite.com/php/contactMe/ipLog.htm


NOTE: You will have to set the "ipLog.htm" files' permission to 
writable inorder for the script to write the IP address to the log.


Product support: NONE...This script is distributed as is! Do NOT alter the
code in any file other that "config.php" unless you know what you are doing!
Do NOT rename ANY file or code will not work correctly! You may alter the
look of the HTML (hardcoded or generated) pages as you wish. 


-------------------------------------------------------------------------------

* If this version doesn't work as desired for you then you can get the code for 
the previous version at: http://www.digi-dl.com/free_stuff/contactMe-ORG.zip

 
