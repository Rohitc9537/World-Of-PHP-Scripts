Archive contents :
- create_tables.php :
	run it once (after editing its parameters ! ;) ) to create the data table.
- validation.php :
	the inscription and confirmation page.
- mypage.php :
	an example page that includes the form in a global valid XHTML page (with header + footer).
- GNUGPL.txt : 
	The GNU General Public License :)

Required : PHP and MySQL
Recommended : phpMyAdmin
Tested with : Apache/2.0.53 (Win32) - PHP/5.0.3 - MySQL 4.1.10a-nt
If you don't know how to install an Apache server on your Windows computer, see this tutorial :
	-> Installing an Apache server on Windows <http://www.patheticcockroach.com/mpam4/index.php?p=32>

How to get it to work :
1. Enter your database informations in create_tables.php and validation.php
2. Run create_table.php to create the tables
3. Edit validation.php (particularly the confirmation e-mail)


/*************************************************************************
*                                                                        *
* This script pre-registers and confirms a user by e-mail.               *
* It features an anti-spam protection by enabling the owner of the mail  *
* account to blacklist their e-mail address. IPs are logged.             *
*                                                                        *
* Copyright (C) 2005 PatheticCockroach                                   *
*                    http://www.patheticcockroach.com                    *
*                    Version 1.7                                         *
*                                                                        *
* This program is free software; you can redistribute it and/or modify   *
* it under the terms of the GNU General Public License as published by   *
* the Free Software Foundation; either version 2, or (at your option)    *
* any later version.                                                     *
*                                                                        *
* This program is distributed in the hope that it will be useful,        *
* but WITHOUT ANY WARRANTY; without even the implied warranty of         *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
* GNU General Public License for more details.                           *
*                                                                        *
* You should have received a copy of the GNU General Public License      *
* along with this program; if not, write to the Free Software            *
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              *
* You can also provide yourself with an online copy of the text:         *
* <http://www.gnu.org/copyleft/gpl.html>                                 *
* <http://www.gnu.org/copyleft/gpl.txt>                                  *
*                                                                        *
*************************************************************************/


!======> Change log <======!
2005-09-16 (1.7) :
	- SECURITY FIXES (email injection)
	- minor code fixes (cleaner SQL queries...)
	- example fix (now XHTML 1.1 compliant)
2005-04-13 (1.6) :
	- SECURITY FIXES (SQL insertion)
	- minor code fixes
	- example fix (removed the session_start() coming right from another script, lol)