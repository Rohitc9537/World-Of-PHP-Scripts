<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/2001/REC-xhtml11-20010531/DTD/xhtml11-flat.dtd">
<html>

<head>
<title>Pre inscription form</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

<body>
<div>Some header : a menu, whatever...</div>

<div style="border:1px solid #000; width:30em; padding:1px;">
<?php
include ("validation.php");
?>
</div>

<div>Some footer...<br/>
<a href="http://validator.w3.org/check?uri=referer">
<img src="http://www.w3.org/Icons/valid-xhtml11" alt="Valid XHTML 1.1" height="31" width="88" style="border:0px;" />
</a>
</div>

</body>
</html>