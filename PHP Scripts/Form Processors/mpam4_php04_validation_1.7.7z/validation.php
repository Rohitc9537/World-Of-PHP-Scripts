<?php
$serveur="http://".$_SERVER["HTTP_HOST"];	// Server root
$validity=7;					// Code validity, in days.
$db_host="127.0.0.1";			// DB parameters
$db_user="username";
$db_pass="password";
$database="db_name";

//************ End of parameters

$valid2=3600*24*$validity;
$er='';

if (isset($_POST["email"]))		// If the form has been submitted
{
mysql_connect($db_host,$db_user,$db_pass) or die("Unable to connect to database");
mysql_select_db($database) or die("Unable to select database");

$page=$serveur.$_SERVER["PHP_SELF"];
$nom=htmlentities(substr($_POST["nom"],0,100), ENT_QUOTES);		// we cut the entered values to 100 characters and remove any ' or "
$pass=htmlentities(substr($_POST["pass"],0,100), ENT_QUOTES);		// this is to avoid SQL insertions (or other injections), and limit the amount of code that could be executed
$pass2=htmlentities(substr($_POST["pass2"],0,100), ENT_QUOTES);		// in case an insertion should succeed
$email=htmlentities(substr($_POST["email"],0,100), ENT_QUOTES);
$IP=$_SERVER['REMOTE_ADDR'];
$heure=time();

if(!eregi('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]{2,})+$', $email))$er.='Please enter a valid e-mail address.<br/>';	// Once again, sth against email insertion
if(false!=strpos($nom,chr(92)) || false!=strpos($nom,":") || false!=strpos($nom,",") || false!=strpos($nom,";")) $er.='You used forbidden characters in your user name.<br/>';

do					// The code must be unique, but we don't need to tell the user ;)
{
$session=md5($heure.rand(100000,999999));
$resultat = mysql_query("SELECT * FROM w_members WHERE session ='$session'");
}
while(false!=($ligne = mysql_fetch_array ($resultat)));

if($nom=="" || $pass=="" || $email==""){$er.='One or more fields are missing.<br/>';}				// Fill in all fields, thank you
if($pass!=$pass2){$er.='Password and confirmation didn\'t match.<br/>';}					// The 2 passwords must be the same
$resultat = mysql_query("SELECT * FROM members WHERE nom ='".$nom."'"); 
if(false!=($ligne = mysql_fetch_array ($resultat))){$er.='This username ('.$nom.') is already taken.<br/>';}	// If the login is already taken (confirmed)
$resultat = mysql_query("SELECT * FROM w_members WHERE nom ='".$nom."'"); 
if(false!=($ligne = mysql_fetch_array ($resultat))){$er.='This username ('.$nom.') is already taken.<br/>';}	// If the login is already taken (not yet confirmed)
$resultat = mysql_query("SELECT * FROM blackl WHERE email ='".$email."'"); 
if(false!=($ligne = mysql_fetch_array ($resultat))){$er.='This e-mail ('.$email.') is blacklisted. You can\'t use it to sign up here.<br/>';}	// If the e-mail is in the blacklist

if($er=='')
{	//**** IF NO ERROR - START

//********* Confirmation e-mail
/* subject */
$subject = "Account confirmation";

/* message */
$message = '
<html>
<head>
 <title>Account confirmation</title>
</head>
<body>
Hello '.$nom.',<br/><br/>

You are receiving this e-mail because you or someone else used your address to sign up on our site.<br/>
To complete the sign-up process please follow <a href="'.$page.'?code='.$session.'">this link</a>.<br/><br/>

If you didn\'t sign up on our site, just ignore this message and please accept our apologies.<br/>
You can also choose to blacklist your e-mail so you won\'t hear from us anymore by following <a href="'.$page.'?code='.$session.'&BL=1">this link</a>.<br/>
Your e-mail was submitted from IP '.$IP.' on '.date("r").' (server time).<br/><br/>

Best regards,<br/>
Site Admin
</body>
</html>
';

/* To send HTML mail, you can set the Content-type header. */
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";

/* additional headers */
$headers .= "To: ".$nom." <".$email.">\r\n";
$headers .= "From: Site <do_not_reply@patheticcockroach.com>\r\n";

/* and now mail it */
if(mail($email, $subject, $message, $headers))
	{
	mysql_query("INSERT INTO w_members SET nom='".$nom."',pass='".md5($pass)."',email='".$email."',heure='".$heure."',session='".$session."',IP='".$IP."';");		// We insert the data into the waiting table

	echo 'Thank you.<br/>An e-mail was sent to '.$email.'. Please check your e-mail and confirm your membership within '.$validity.' days.';
	}
else {$er.='We weren&#39;t able to send you the confirmation e-mail. Please contact the webmaster.<br/>';}
}	//**** IF NO ERROR - END

mysql_close();
}	// If the form has been filled - END


else if(isset($_GET["code"]))					// If a code is entered
{
mysql_connect($db_host,$db_user,$db_pass) or die("Unable to connect to database");
mysql_select_db($database) or die("Unable to select database");

$heure=time();
$heure2=$heure-$valid2;						// We delete outdated codes
mysql_query("DELETE FROM w_members WHERE heure<".$heure2.";");

$session=htmlentities($_GET["code"], ENT_QUOTES);
$sql = "SELECT * FROM w_members WHERE session ='".$session."'";
$resultat = mysql_query($sql);

if(false==($ligne = mysql_fetch_assoc ($resultat))){$er.='This code is wrong or has expired, please fill in the form again.<br/>';}

if($er=='')
{	//**** IF NO ERROR - START

if(!isset($_GET["BL"]))						// If the user comes to confirm, we insert them into the members table and remove them from the waiting table
{
$nom=$ligne['nom'];
mysql_query("INSERT INTO members SET nom='".$nom."',pass='".$ligne['pass']."',email='".$ligne['email']."',IP='".$ligne['IP']."',heure='".$ligne['heure']."';");
mysql_query("DELETE FROM w_members WHERE session='".$session."'");

echo 'Thank you for confirming your inscription '.$nom.'. You are now a member of the site.';
}

else if($_GET["BL"]==1)						// If the user comes to be blacklisted, we ask for a confirmation
{
echo 'Click <a href="'.$_SERVER["PHP_SELF"].'?code='.$session.'&BL=2">here</a> to blacklist your e-mail. This CANNOT be undone.';
}

else								// If the user confirms they want to be blacklisted,  we insert them into the blacklist and remove them from the waiting table
{
$email=$ligne['email'];
mysql_query("INSERT INTO blackl SET email='".$email."',IP='".$ligne['IP']."',heure='".$ligne['heure']."';");
mysql_query("DELETE FROM w_members WHERE session='".$session."'");

echo 'Your e-mail, '.$email.', has been blacklisted. You won&#39;t receive anymore e-mails from us.';
}
}	//**** IF NO ERROR - END

mysql_close();
}	// If a code is entered - END



else{show_form();}		// If there is no form submitted nor a code, we show the form

if($er!='' && isset($_POST["email"])){show_form($nom,$pass,$pass2,$email,$er);}
else if($er!='' && !isset($_POST["email"])){show_form('','','','',$er);}

//************ Form display function
function show_form($nom="",$pass="",$pass2="",$email="",$er='')
{
echo '<div style="font-weight:bold;">'.$er.'</div>
Please fill in the sign up form&nbsp;:<br/>
<form action="'.$_SERVER["PHP_SELF"].'" method="post">
<table>
<tr>
<td><label for="nom">Desired login</label>&nbsp;:</td><td><input type="text" name="nom" id="nom" size="50" maxlength="20" value="'.$nom.'" /></td>
</tr>

<tr>
<td><label for="pass">Password</label>&nbsp;:</td><td><input type="password" name="pass" id="pass" size="50" maxlength="20" value="'.$pass.'" /></td>
</tr>

<tr>
<td><label for="pass2">Confirm password</label>&nbsp;:</td><td><input type="password" name="pass2" id="pass2" size="50" maxlength="20" value="'.$pass2.'" /></td>
</tr>

<tr>
<td><label for="email">E-mail</label>&nbsp;:</td><td><input type="text" name="email" id="email" size="50" maxlength="100" value="'.$email.'" /></td>
</tr>
<tr><td colspan="2" style="text-align:center;"><input type="submit" value=" Sign Up " /></td></tr>
</table>
</form>';
}

?>