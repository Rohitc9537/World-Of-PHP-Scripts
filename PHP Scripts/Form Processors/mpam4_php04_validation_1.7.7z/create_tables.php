<?php

$db_host="127.0.0.1";			// DB parameters
$db_user="username";
$db_pass="password";
$database="db_name";

mysql_connect($db_host,$db_user,$db_pass) or die("Unable to connect to database");
mysql_select_db($database) or die( "Unable to select database");
$er=0;

//****** table blacklist
$query ="CREATE TABLE blackl (
id INT UNSIGNED NOT NULL auto_increment,

email varchar(100) NOT NULL,
IP varchar(15) NOT NULL,
heure INT UNSIGNED NOT NULL,

PRIMARY KEY (id))";

if(mysql_query($query)==false){$er++;echo mysql_error().'<br/>';}
else echo 'Table blackl created<br/>';


//****** table members (validated members)
$query ="CREATE TABLE members (
id INT UNSIGNED NOT NULL auto_increment,

nom varchar(20) NOT NULL,
pass varchar(32) NOT NULL,
email varchar(100) NOT NULL,
IP varchar(15) NOT NULL,
heure INT UNSIGNED NOT NULL,

PRIMARY KEY (id))";

if(mysql_query($query)==false){$er++;echo mysql_error().'<br/>';}
else echo 'Table members created<br/>';


//****** table w_members (non validated members)
$query ="CREATE TABLE w_members (
id INT UNSIGNED NOT NULL auto_increment,

nom varchar(20) NOT NULL,
pass varchar(32) NOT NULL,
email varchar(100) NOT NULL,
heure INT UNSIGNED NOT NULL,
session varchar(32) NOT NULL,
IP varchar(15) NOT NULL,

PRIMARY KEY (id))";

if(mysql_query($query)==false){$er++;echo mysql_error().'<br/>';}
else echo 'Table w_members created<br/>';


//****** closing SQL connection
mysql_close();
if($er==0)echo 'All tables successfully created.';
else echo 'Errors occured&nbsp;: '.$er.' table(s) haven&#39;t been created.'
?>