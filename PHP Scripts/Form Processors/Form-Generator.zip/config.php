<?

//the relative or absolute path were generated forms are to be stored
$GENERATE_PATH = "generated/";

//username
$USERNAME = "admin";

//password
$PASSWORD = "admin";

?>