What is this script doing?
 It reads a simple form and writes all the values into a txt file.
 The txt file is included into the main page as u will see.
 It's very simple to use and install...

What do u need to make it work?
 1. PHP server (win98, winNT, win2000, winxp) -  I use ISS (phptriad works as well)
 2. copy all the files into the same directory on your server
 3. run the script :P

Terms of using this tutorial:
 1. Email me if u find it useful at: armand.niculescu@gmail.com
 2. Put a link in your webpage if u wanna help me grow (http://www.armandniculescu.com)

That's it! ;)
