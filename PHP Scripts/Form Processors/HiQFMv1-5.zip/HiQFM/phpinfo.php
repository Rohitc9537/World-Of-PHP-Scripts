<?php
phpinfo();


?>