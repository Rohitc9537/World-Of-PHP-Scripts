function openLink(link) {
	top.document.location.href = link;
}
