--------------------------------------------------------------
|MD Contact version 2.1                                      |
|(c)Matthew Dingley 2002                                     |
|For more scripts or assistance go to MD Web at:             |
|www.matthewdingley.co.uk                                    |
--------------------------------------------------------------


How to use
-Just put this code into your webpage and name it contact.php. It is important
 that you name it contact.php otherwise it will not work. 

-Make the changes to your e-mail address, the title of your site and the highlight colour in the first few
 lines of the code.

-If you would like the visitor to recieve a thank you message, set $autoresponder
to 1 for on, or 0 for off. You may want to change the variable $autobody to change the message
sent. Only do this if you are confident with PHP.

-Note : Some people may find the auto-responder annoying

-Your server needs php and the php mail function enabled.

For more information or help go to MD Web at
www.matthewdingley.co.uk

What's new in version 2.1
-Better syntax for faster exicution
-Lower case tags for xml/xhtml pages

Licence

-To use this program, you have to keep the copyright notice intact or provide
a mention back to my website at http://members.lycos.co.uk/matthewdingley/cubeweb/ and make it
clear that it is (c)Matthew Dingley 2002

-You may not distribute this program in any way. You can make a reasonable amount of copies
for your personal use only

-This program is free to use on a non-commercial site. If you want to use it on
a commercial site (excluding .org sites) go to the website for more information.