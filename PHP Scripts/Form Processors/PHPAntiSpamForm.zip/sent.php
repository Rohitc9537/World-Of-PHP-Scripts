<html>
<head>
<title>PHPAntiSpamForm - Demo</title>
</head>
<body>

<script>
<!--
var top = 150
var left = 200
function hosting() {
 if(screen.width) {
  top = screen.height/2 - 165
  left = screen.width/2 - 160
 }
 window.open('mail.php','contact','resizable,width=510,height=400,top='+top+',left='+left)
}
//-->
</script>

Your feedback has been sent! Thank you.<br><br>Now try it again<br><a href="javascript:hosting()">PHPAntiSpamForm</a>

</body>
</html>
