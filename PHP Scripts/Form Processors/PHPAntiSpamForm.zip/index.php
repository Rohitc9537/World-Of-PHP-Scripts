<html>
<head>
<title>PHPAntiSpamForm - Demo</title>
</head>
<body>

<script>
<!--
var top = 150
var left = 200
function hosting() {
 if(screen.width) {
  top = screen.height/2 - 165
  left = screen.width/2 - 160
 }
 window.open('mail.php','contact','resizable,width=510,height=400,top='+top+',left='+left)
}
//-->
</script>

<a href="javascript:hosting()">PHPAnitSpamForm</a>

</body>
</html>
