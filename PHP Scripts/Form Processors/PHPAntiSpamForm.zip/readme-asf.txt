http://www.sebflipper.com

PHPAntiSpamForm v1.0

Description:
This script will send a form by email, once submitted it will disable 
the submit button so the user cannot Spam the web master and also set 
a cookie so the user cannot load the form again. The script is has a 
wide range of options you can change as well as a good documentation.

Min Specs:
1. PHP Server
2. Sendmail Server

Instructions:
1. Open up mail.config.inc.php in a text editor
2. Read the comments in the config file and add your details and save
3. Upload all the *.php files
4. Test the script by finding the index file on your web site
5. Add the script into your web site by puting the pop script from the index page onto your main page
6. Edit the sent.php to your style
7. Sit back and relax