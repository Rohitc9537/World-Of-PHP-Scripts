THE VIEWFINDER FEEDBACK FORM
-----------------------------------------------------------
Written by Lee Penney
Visit Viewfinder Design at www.viewfinderdesign.co.uk
or, check out Lee's blog at www.thedigeratipeninsula.org.uk
-----------------------------------------------------------


This is a simple to use and install feedback form that requires PHP to work.

To use, edit the mail.php file and replace the email address, return page (this can remain at the default unless you have a reason for changing it) and the site name with your details.

Edit the contact.html and thankyou.html files so they match the look of your site.

Upload all of these files to your server (in the same directory), and test.

Voila, you're done, easy as that.

If you have any problems, check out the Viewfinder Design support forums at www.viewfinderdesign.co.uk/support/