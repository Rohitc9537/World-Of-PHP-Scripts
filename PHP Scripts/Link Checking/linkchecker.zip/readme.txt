Copyright (c) 2005 sam j. clarke.
All rights reserved.

#############################################################################
#             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            #
#         ~ THANK YOU FOR DOWNLOADING THIS PHP LINK CHECKER SCRIPT ~        #
#             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            #
#                                                                           #
# 1. HOW TO USE                                                             #
# 2. WARRANTY                                                               #
# 3. HELP                                                                   #
# 4. DISTRIBUTE                                                             #
#                                                                           #
#############################################################################

1. HOW TO USE
Just upload all the files in the zip file to your cgi-bin thats it but if you
need any help please use this form http://www.free-php.org.uk/help/index.php
or email us at admin@free-php.org.uk.

2. WARRANTY
For our protection, We want to make certain that everyone understands that 
there is no warranty for this free script. If the script is modified by 
someone else and passed on, We want its recipients to know that what they 
have is not the original, so that any problems introduced by others will not
reflect on our reputations.

3. HELP
If you need help please use this form http://www.free-php.org.uk/help/index.php
or email us at admin@free-php.org.uk.

4. DISTRIBUTE
You can distribute this script freely but you cannot charge for it or
claim it as your own. You do not have the copyright for this script but
you do have the right to distribute it. You cannot change for it and you 
can only distribute it as you got it.