<?php

require_once( 'headers.php' );




$SkaLinks = new SkaLinks( $_skalinks_mysql );
$smarty = new DirSmarty();
$SkaLinks->SetRootURL( $_skalinks_url['dir'] );
$SkaLinks->SetPrefix( $_skalinks_mysql['tbl_prefix'] );
$_output['title'] = $SkaLinks->GetTitleChain( -1, $_skalinks_page['title'], $_skalinks_page['title_dirtree'] );

$ADMIN = $SkaLinks->IsAdmin();

$_output['categories'] = $SkaLinks->GetCategories( 0, -1 );
$_output['show_dirtree'] = $SkaLinks->GetParam( 'show_dirtree' );

display( 'dirtree' );
?>

