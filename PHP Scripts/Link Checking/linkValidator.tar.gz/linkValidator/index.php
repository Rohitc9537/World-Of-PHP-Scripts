<?

if(!$argv[0]){
	echo "<p><h1>linkValidator</h1>by: daantje.nl<br>";
	echo "<form onsubmit=\"self.location.href='index.php?'+this.url.value;return false;\">url:<input type=text name=url></form>";
	die('I need one argument, a URL would be nice...');
}

//EXAMPLE CODE
include('linkValidator.class.php');

$linkValidator = new linkValidator($argv[0]);

echo "STATUS: ".($linkValidator->status() ? "VALID\n" : "FAILED\n");
echo "<br>\n".$linkValidator->message();
echo "\n<hr>linkValidator by daantje.nl";
?>
