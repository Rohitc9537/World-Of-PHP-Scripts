Link validator v0.1
by: me@daantje.nl

first written: 30 october 2003
last update: Mon Mar 28 15:45:54 CEST 2005

Documentation:
	This class will check if a link gives an error.
	Mind your firewall! You'll need outgoing tcp port 80 to be open!!

Changed:
	version 0.2: Now the class tries the HTTP/1.0 protocol first and
		than when a 400 status is given, tries the HTTP/1.1. This will
		fix hanging on some old servers. Thanx to __DireWolf for the
		bug report.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
(http://www.gnu.org/licenses/gpl.txt)


Syntax:

BOOL $status = linkValidator::linkValidator( [STRING $url] [, STRING $referer] )
		Does it all at ones... When referer is empty, it will be calculated from given url....
		When all arguments are empty, the constructor will do nothing.

ASSOC ARRAY $array = linkValidator::disectURL( STRING $url )
		Will disect an URL and will return it in an associative array.
		Available keys will be 'host', 'port' and 'get'

STRING $string = linkValidator::open(STRING $host, INT $port, STRING $get, STRING $referer [, STRING $protocol])
		Open a connection, check the $get URI and return the status...
		Returns 'Connection refused.' on no status found, or host down.
		Optional protocol can be 1.0 or 1.1. Default it will check 1.0
		and when that fails it will try 1.1 automaticly.

BOOL $works = linkValidator::status()
		Will return 'true' when the last link gave a status below 400.
		Else it will return 'false'.

STRING $string = linkValidator::message()
		returns the complete status message of the last link.


Some examples on how to use the class...

//EXAMPLE CODE
//check one URL
$linkValidator = new linkValidator('http://www.nlweed.com/');

echo $linkValidator->message();
echo "<hr>";
echo $linkValidator->status();
echo "<br>".($linkValidator->status() ? "worked" : "failed");



//EXAMPLE CODE 2
//check multiple URL's
$linkValidator = new linkValidator();

$checkThese = array(
	"http://www.nlweed.com/",
	"http://www.daantje.com/",
	"http://www.daantje.nl/",
	"http://www.daantje.nl/blah.html",
	"http://www.google.nl/"
);

foreach($checkThese as $url){
	$linkValidator->linkValidator($url);
	echo "$url<br>";
	echo $linkValidator->message();
	echo ($linkValidator->status() ? " - worked" : " - failed") ."<br>";
	echo "<hr>";
	flush();
}



//EXAMPLE CODE 3
//do it all manualy
$linkValidator = new linkValidator();

$array = $linkValidator->disectURL('http://www.daantje.nl/index.php');
$linkValidator->open($array['host'],$array['port'],$array['get'],'http://www.daantje.nl/','http://www.whole.world/fake/referer.html');
echo $linkValidator->message();
echo ($linkValidator->status() ? " - worked" : " - failed") ."<br>";



//EXAMPLE CODE 4
//check if it's allowd from this file as referer...
$linkValidator = new linkValidator('http://www.nlweed.com/welcome.php3',$_SERVER['REQUEST_URI']);

echo $linkValidator->message();
echo "<hr>";
echo $linkValidator->status();
echo "<br>".($linkValidator->status() ? "worked" : "failed");
