ZIP Contents
----------------------------------------------------------------------------
File: example_linkcheck.php
Description: This is the example file included with the script on how to use 
the script. This file contains a form in which is submitted to itself and 
when data is posted to it, it will include the linkcheck.php script.

File: linkcheck.php
Description: This is the file in which calls upon the function to determine 
if the specified link is found on the specified URL. Modify this file to 
determine the action to take depending if the link is found/not found.

File: lcfunction.php
Description: This file contains the function for checking if a link is found 
on a website.
-----------------------------------------------------------------------------

Author Notes
-----------------------------------------------------------------------------
The function was included in a seperate php file to allow people to easily
use the link checking capability to their liking. The other two files
example_linkcheck.php and linkcheck.php are just demonstrations of the use
for the function. Also note that the function for retrieve page data was
taken directly from www.php.net
-----------------------------------------------------------------------------
phpLinkCheck v0.88 RELEASED: November 19, 2005