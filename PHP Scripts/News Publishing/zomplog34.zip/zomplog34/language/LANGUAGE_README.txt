LANGUAGE README

Choose your preferred language in the zomplog settings control panel

If you want to create a new language, just copy an existing language file, and translate it to your preferred language! To activate the language, go to the settings page in the admin control panel, and pick the language file you've just created form the language dropdown menu. Once you've translated Zomplog, don't hesitate to upload your language file to the forum: http://zomplog.zomp.nl

Have fun!

CREDITS
German translation by Micha
Italian Translation by Kritaly
French translation by Monsieur Thomas Albert
English and Dutch by Gerben