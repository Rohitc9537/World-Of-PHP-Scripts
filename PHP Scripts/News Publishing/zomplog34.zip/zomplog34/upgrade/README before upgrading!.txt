IMPORTANT NOTE TO UPGRADING USERS:

This is an important message to all users who want to upgrade to version 3.3 from a previous version: in zomplog 3.3 the thumbnail system has drastically changed. It has changed so much that images you uploaded before upgrading to version 3.3 will not work anymore. The only solution is to re-upload those pictures. The original files are still in the "upload" directory and are still full-size, so that shouldn't cause too many problems.

The date system has also changed quite a bit, so there might be some issues with that too. There is a workaround for this too: in zomplog 3.3 you can manually change the date (in editentry.php), so every old entry will be back in place. 

Sorry for this drastic step, but sometimes you need to loose something in order to improve. Just like in real life, isn't it? :)

I hate to say this, but if there aren't any very strong reasons why you should upgrade, don't upgrade. Or install Zomplog 3.3 in a new directory, copy the old skins, and have a fresh start! I promise that upgrading from version 3.3 to all upcoming versions will be a lot easier again. I just had to get rid of some old ways of handling things.