<html>
<head>
<title>Image</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="100%" border="0" align="center" cellspacing="0">
  <tr>
    <td><?php echo "<div align='center'><img src='upload/thumbnail.php?gd=2&src=$_GET[image]&maxw=470'></div>"; ?></td>
  </tr>
</table>
</body>
</html>
