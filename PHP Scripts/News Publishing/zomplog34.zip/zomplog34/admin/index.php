<?
// fix in case apache shows the contents of a folder
header("Location: ../login.php");
?>