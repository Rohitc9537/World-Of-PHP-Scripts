OK, well fristly thx for using The_Infernos NULL NEWS.
The script is easy enough to use.
Upload everything to the your server
Change the values in config.php.
Run install.php.
Delete the install.php.
And your good to go.

Liecnce:
This software is FREEWARE.
*You may redistrabute it as Freeware.
*You may alter it, to remove bugs and such. but you may not remove the Powered by The_Infernos NULL NEWS on any page.
*You MAY donate. :P http://server47.dedicatedusa.com/~nullbran/fusion_pages/10.php
*If you have any questions please contact me at:
lost_twice@hotmail.com
Please do donate.
:p
oh yeah and have phun.
All works copyrighted to The_Inferno 7/26/2005.
Spectacuware.
Shoutz to all who gave me advice and tips. :D Thanks all!
