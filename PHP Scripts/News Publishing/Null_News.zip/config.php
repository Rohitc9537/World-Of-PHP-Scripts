
<?php
$Admin_Email = "your email";
$Site_Name = "your sites name";
$Site_URL = "your url";
$admin_Name = "your name";
//admin pass
$pass = "adminpass3";
//database pass
$password = "dbasebass";
//username
$username = "user";
//dbase name.
$dbase = "dbase";

?>
