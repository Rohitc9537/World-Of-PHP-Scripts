<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 10th September 2005                     #||
||#     Filename: mainNews.php                           #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");

/* the main class for all classes based off news */

class mainNews
{
    
    // main class variables
    var $dbObj;
    var $tplObj;
    var $config;
    var $GLOBALS;
    
    var $catid = null;
    var $newsQuery = "";
    var $newsQueryType = "";    // used for pagination method
    var $page = 0;
    
    /**
        Initiates the class variables
    
        @access protected - Only available within the extending class not outside
        @param Array config - The newsConfig Array
    */
    function mainNews($config)
    {
        global $dbclass, $tpl, $GLOBALS; // we do this here and here alone, globaling isnt good
        
        $this->dbObj = $dbclass;
        $this->tplObj = $tpl;
        $this->GLOBALS = $GLOBALS;
        $this->config = $config;
    }
    
    /**
        Sets the category id
        
        @access public
        @param String / INT catid - the id or name of the category
    */
    function setCategory($catid)
    {
        if ($this->dbObj->db_checkRows("SELECT id FROM " . TBL_CATEGORY . " WHERE id = '" . (int)$catid . "' OR name = '" . addslashes($catid) . "'"))
        {
            $cat = $this->dbObj->db_fetcharray($this->dbObj->db_query("SELECT id FROM " . TBL_CATEGORY . " WHERE id = '" . (int)$catid . "' OR name = '" . addslashes($catid) . "'"));
            $this->catid = $cat['id'];
        }
    }
    
    /**
        The proper way to retrieve the category id if set returns null otherwise
        @return int / null
    */
    function getCategory()
    {
        return $this->catid;
    }
    
    /**
        Returns true / false on whether a news post exists
        
        @access public
        @param int newsid - News Article ID
        @return boolean
    */
    function articleExists($newsid)
    {
        return $this->dbObj->db_checkRows("SELECT id FROM " . TBL_NEWS . " WHERE id = '" . (int)$newsid . "'");
    }
    
    /**
        @param String type  - all = All news Articles, Single = Specific Single, Latest = The very latest article, dategroup = Get List of Just Dates
        @param int page     - The page e.g. 0, 10, 20
        @param int newsid   - Set to get a single article
        @return resource
    */
    function getNews($type = 'all', $page = 0, $newsid = '')
    {
        
        $this->page = ($page < 0 ? 0 : $page);
        
        switch (strtolower($type))
        {
            
        case 'all':
            
            $this->newsQueryType = 'all';
            return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                           u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                           WHERE n.userid = u.userid
                                           " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           LIMIT " . ((int)$this->page  * $this->config['newslimit']) . ", " . $this->config['newslimit'] . "
                                           ");
        
        break;
        case 'single':
            // empty newsid or non existent display latest
            if ($this->dbObj->db_checkRows("SELECT id FROM " . TBL_NEWS . " WHERE id = '" . (int)$newsid . "'"))
            {
                $this->newsQueryType = 'single';
                return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                               DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`,
                                               DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                               u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                               FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                               LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                               LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                               WHERE n.userid = u.userid
                                               " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                               AND n.id = '" . (int)$newsid . "'
                                               GROUP BY n.id
                                               ORDER BY n.timeposted DESC
                                               LIMIT 1
                                               ");
            }
            else
            {
                $this->newsQueryType = 'latest';
                return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                               DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`,
                                               DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                               u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                               FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                               LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                               LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                               WHERE n.userid = u.userid
                                               " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                               GROUP BY n.id
                                               ORDER BY n.timeposted DESC
                                               LIMIT 1
                                               ");
            }
            
        break;
        case 'latest':
        
            $this->newsQueryType = 'latest';
        
            return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                           u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                           WHERE n.userid = u.userid
                                           " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           LIMIT 1
                                           ");
        
        break;
        case 'dategroup':
        
            //
            return $this->dbObj->db_query("SELECT DATE_FORMAT( FROM_UNIXTIME(timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '%W %D %M, %Y' ) as `date`
                                           FROM " . TBL_NEWS . "
                                           GROUP BY DATE_FORMAT( FROM_UNIXTIME(timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )) , '%W %D %M, %Y' )
                                           ORDER BY timeposted DESC
                                           ");
        break;
        case 'archive':

            $this->newsQueryType = 'archive';
            return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                           u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                           WHERE n.userid = u.userid
                                           AND DATE_FORMAT(FROM_UNIXTIME(n.timeposted), '%M %Y') = '" . addslashes($_GET['month']) . " " . addslashes($_GET['year']) . "'
                                           " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "AND n.catid <= '0'") . "
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           LIMIT " . ((int)$this->page  * $this->config['newslimit']) . ", " . $this->config['newslimit'] . "
                                           ");
        
        break;
        default:
        
            $this->newsQueryType = 'default';
        
            // only get news that isnt in a category
            return $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                           u.postname
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           WHERE n.userid = u.userid
                                           AND n.catid <= '0'
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           LIMIT " . ((int)$this->page  * $this->config['newslimit']) . ", " . $this->config['newslimit'] . "
                                           ");
        
        break;
            
        }
        
    }
    
}

?>
