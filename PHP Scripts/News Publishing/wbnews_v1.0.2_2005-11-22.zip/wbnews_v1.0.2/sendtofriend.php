<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 17th September 2005                     #||
||#     Filename: sendtofriend.php                       #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");

class sendToFriend extends news
{
    
var $formError;
var $isActive = false;
    
    /**
    */
    function sendToFriend($config)
    {
        $this->news($config);
        if ($this->articleExists($_GET['newsid']) && $this->config['sendtofriend'] != 0)
            $this->isActive = true;
    }
    
    function sendFriend()
    {
        if ($this->isActive == true)
        {
            $this->newsid = (int)$_GET['newsid'];
            if (!isset($_POST['sendto_submit']) || !$this->checkForm())
                return $this->displayForm();
            else
                return $this->sendEmail();

        }
        else
        {
            // error cant show anything
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_INVALIDURL']);
        }
    }
    
    /**
    */
    function checkForm()
    {
        
        if (!defined("LIB_FORMVAL"))
        {
            include $this->GLOBALS['installdir']."/includes/lib/formvalidation.php";
            $formVal = new formVal();
        }
        
        $formVal->validEmail($_POST['sendto_emailto']);
		$formVal->validEmail($_POST['sendto_emailfrom']);
        
		if (sizeof($formVal->errors) != 0)
		{
			$this->formError = $formVal->displayErrors();
			return false;
		}
		else
			return true;
        
    }
    
    /**
    */
    function displayForm()
    {
        $sendto = array(
						"error" => (($this->formError != '') ? $this->formError : ''),
						"action" => '?action=sendto&newsid=' . $this->newsid,
						"newsid" => $this->newsid,
						"news" => $this->displaySingleNews($this->newsid)
						);

		return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('sendtofriend'), $sendto));
    }
    
    /**
    */
    function sendEmail()
    {
        $headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
		$headers .= "From: " . $this->config['sitename'] . " <" . $this->config['adminemail'] . ">\r\n";
		$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
	
		$msg = $this->config['sendtomsg'];
		$url = $this->tplObj->replace($this->config['newsdisplay'], array("newsid" => $this->newsid) );

		$msg = str_replace("{email}", $_POST['sendto_emailfrom'], $msg);
		$msg = str_replace("{url}", str_replace("&amp;", "&", $url), $msg);
		$msg = str_replace("{usermsg}", $_POST['sendto_msg'], $msg);
		$msg = str_replace("{adminemail}", $this->config['adminemail'], $msg);
        
        // make sure we have no more than one email no , allowed
        $sendto = $_POST['sendto_emailto'];
        $sendto = substr($sendto, 0, strpos($sendto, ","));
        
        if (!defined("LIB_FORMVAL"))
        {
            include $this->GLOBALS['installdir']."/includes/lib/formvalidation.php";
            $formVal = new formVal();
        }
        
        $formVal->validEmail($sendto);
        if (sizeof($formVal->errors) == 0)
        {
            
            @mail($sendto, "View News Article", stripslashes($msg), $headers);
        
            $this->dbObj->db_query("INSERT INTO " . TBL_SEND . "
                                (id, newsid, time, email_to, email_from, message, ipaddress)
                                VALUES ('null', '" . (int)$_POST['newsid'] . "', '" . time() . "', '" . addslashes($_POST['sendto_emailto']) . "', 
                                '" . addslashes($_POST['sendto_emailfrom']) . "', '" . addslashes($_POST['sendto_msg']) . "', 
                                '" . $_SERVER['REMOTE_ADDR'] . "')
                                ");
        }
        
		return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('sendto_sent'), array("news" => $this->displaySingleNews($this->newsid)) ));
    }
    
}

?>
