<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 13th September 2005                     #||
||#     Filename: comments.php                           #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");


class comments extends news
{
    
var $newsid = null;
    
    function comments($config, $newsid)
    {
        $this->news($config);
        if ($this->articleExists($newsid))
            $this->newsid = (int)$newsid;
        else
        {
            // error cant show anything
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_INVALIDURL']);
        }
    }
    
    function showNews()
    {
        if ($this->newsid != null)
            return $this->displaySingleNews($this->newsid);
    }
    
    /**
        Returns true if comments can be posted for that news article
    
        @access private
        @return boolean
    */
    function allowComments()
    {
        return $this->dbObj->db_checkRows("SELECT id FROM " . TBL_NEWS . " WHERE id = '" . $this->newsid . "' AND allowcomments = '1'");
    }
    
    /**
        @access public
        @return string
    */
    function viewComments()
    {
        if ($this->newsid != null)
        {
            
            $getComments = $this->dbObj->db_query("SELECT c.newsid, c.name, c.message, DATE_FORMAT(FROM_UNIXTIME(c.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '%d-%m-%Y %h:%i%p') as `date`, ". TBL_USERS . ".username
                                                   FROM " . TBL_COMMENTS ." as c
                                                   LEFT JOIN ". TBL_USERS . " ON (". TBL_USERS . ".userid = c.userid) 
                                                   WHERE c.newsid = '" . $this->newsid . "' 
                                                   AND c.is_spam = '-1'
                                                   ");
                                                   
            $displayComments['comments'] = "";                                     
            if ($this->dbObj->db_numrows($getComments))
            {
                // get all comments
                while ($comments = $this->dbObj->db_fetcharray($getComments))
                {
                    $comments['name'] = ($comments['username'] != NULL ? $comments['username'] : $comments['name']);
                    
                    /*
                        Parse BBCode
                        Parse Emoticons
                        User Built Word Wrap Function
                        Filter out bad words
                        newline characters to line breaks in HTML
                    */
                    $comments['message'] = nl2br($comments['message']);
                    $comments['message'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($comments['message']) ), $this->config['wordwrap'], LINE_BREAK) );
                    
                    $displayComments['comments'] .= $this->tplObj->replace($this->tplObj->getTemplate('comment'), $comments);
                }
                
            }
            else
            {
                // no comments
                $displayComments['comments'] = $this->GLOBALS['ERROR_NOCOMMENTS'];
            }
            
            // return templates
            return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('displaycomment_view'), $displayComments));
            
        }
    }
    
    /**
        Validates the Comment Form and returns true if valid or a error string if not
        @access private
        @return boolean / string
    */
    function checkForm()
    {
        
        if (!defined("LIB_FORMVAL"))
        {
            include $this->GLOBALS['installdir']."/includes/lib/formvalidation.php";
            $formVal = new formVal();
        }
        
        if (isset($_POST['email']))
			$formVal->validEmail($_POST['email']); 
		
		if (isset($_POST['name']))
		{
			$formVal->checkEmpty($_POST['name'], "Name", 3);
			$formVal->checkMaxChars($_POST['name'], "Name", 150);
		}
        
        $formVal->checkEmpty($_POST['message'], "Message", 2);
        $formVal->checkMaxChars($_POST['message'], "Message", $this->config['max_comment_comment']);
		
		if (sizeof($formVal->errors)!=0)
			return $formVal->displayErrors();
		else
			return true;
        
    }
    
    /**
        Add Comment to Database and do flood filter and display msg
    */
    function addComment()
    {
        
        $name = (isset($_POST['name']) ? $_POST['name'] : "");
        $email = (isset($_POST['email']) ? $_POST['email'] : "");
        $userid = (isset($_SESSION['userid']) ? $_SESSION['userid'] : -1);
        $message = htmlentities(addslashes($_POST['message']));
        $is_spam = (isSpam($message, $this->config['spamfilter']) ? 1 : -1);
        
        $this->dbObj->db_query("INSERT INTO " . TBL_COMMENTS . "
                                (id, newsid, message, name, email, ipaddress, timeposted, userid, is_spam)
                                VALUES ('null', '" . $this->newsid . "', '" . $message . "', '" . $name . "', '" . $email . "', 
                                        '" . $_SERVER['REMOTE_ADDR'] . "', '" . time() . "', '". $userid . "', 
                                        '" . $is_spam . "')
                                ");
                                
        $_SESSION['floodfilter'] = time() + $this->config['floodfilter'];
        
        $comment = array(
                        "viewcomment" => "?action=viewcomment&amp;newsid=" . $this->newsid,
                        "newsid" => $this->newsid
                        );
        
        return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('commentadded'), $comment));
    }
    
    /**
        @access public
        @return string
    */
    function displayForm()
    {
        if ($this->newsid != null)
        {
            
            if (!$this->allowComments())
            {
                // error comments disallowed
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_COMMENTS_DISALLOWED']);
            }
            else if (isBanned($this->config['ipban']))
            {
                // error banned
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_BANNED']);
            }
            else if (isset($_SESSION['floodfilter']) && (time() < $_SESSION['floodfilter']))
            {
                // cannot post after x time
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_FLOODFILTER']);
            }
            else
            {
                // show form
                if (isset($_POST['submit']))
                    if (($errors = $this->checkForm()) === true)
                        return $this->addComment();
                        
                        
                // display form
                $comments = array(
                                  "error" => (isset($errors) ? $errors : ""),
                                  "action" => "?action=addcomment&amp;newsid=" . $this->newsid,
                                  "id" => $this->newsid,
                                  "username" => getUsername($this->dbObj, @$_SESSION['userid']),
                                  "name" => (isset($_POST['name']) ? $_POST['name'] : ""),
                                  "email" => (isset($_POST['email']) ? $_POST['email'] : ""),
                                  "message" => (isset($_POST['message']) ? $_POST['message'] : "")
                                  );
                
                if (isset($_SESSION['userid']))
                    return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('addcomment_user'), $comments));
                else
                    return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('addcomment'), $comments));
                
            }
            
        }
    }
    
}

?>
