<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 11th May 2005                           #||
||#     Filename: global.php                             #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
    
    @todo
        Load lang package
    
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");

// we are currently debugging so we must set this to true
define("DEBUG", true);

/* get wbnews install directory without config */
$installpath = substr(__FILE__, 0, (($pos = strpos(__FILE__, basename(__FILE__))) != -1 ? $pos : 0));
if (!is_dir($installpath))
    die ("Fatal Error: Cannot find WB News Install Path");
include $installpath . "config.php"; //get the config file

/* Check to see if we have v1.0.0 if not check if we are installing/upgrading */
if (!isset($config) || $config['version'] < '1.0.0')
{
	$file = basename($_SERVER['PHP_SELF']);
	$files = array('upgrade.php', 'install.php');
	if (!in_array($file, $files))
		die( (!isset($config) ? "Before integrating WB News please Install it first" : "Site Maintenance") );
}

include $config['installdir']."/includes/constants.php"; //holds constants for tables etc
include $config['installdir']."/includes/common.php"; // get the common file
include $config['installdir']."/includes/function.php"; // get the function file

// get database and template classes
include $config['installdir']."/includes/lib/db_mysql.php";
include $config['installdir']."/includes/lib/template.php";

/* initiate database properties and initiate a connection to the database */
$dbclass = new DB($config['dbhost'], base64_decode($config['dbname']), base64_decode($config['dbuser']), base64_decode($config['dbpass']));
$dbclass->db_connect();

//########################## NEWS CONFIGURATION ##########################//
if (!($newsConfig = $dbclass->db_fetchall("SELECT var, value FROM ".TBL_NEWSCONFIG, "var", "value")))
    die ("Fatal Error: Couldnt retrieve News Configuration Settings");

/* get theme, and configuration info */
$theme = $dbclass->db_fetcharray($dbclass->db_query("SELECT themepath as THEME_DIRECTORY FROM " . TBL_THEMES . " WHERE themeid = '" . $newsConfig['themeid'] . "'"));
/* */

// initiate user session
session_start();
// check if we have an Admin Logged in
if (isset($_SESSION['wbnews-admin_login']) && !isset($_SESSION['userid']))
    $_SESSION['userid'] = $_SESSION['wbnews-admin_login']['userid'];

/* initiate template object */
$tpl = new template($config['installdir']."/templates", "", $theme['THEME_DIRECTORY']);

//########################### UNSET CONFIG VARS ##########################//
unset($config['dbhost'], $config['dbname'], $config['dbuser'], $config['dbpass'], $config['prefix']);

/* Create GLOBAL Variables */
include $config['installdir']."/templates/" . $theme['THEME_DIRECTORY'] . "/theme_info.php";
$GLOBALS = array_merge($themeInfo, $config);

?>
