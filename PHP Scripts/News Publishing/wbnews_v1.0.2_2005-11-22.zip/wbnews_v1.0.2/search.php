<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 17th September 2005                     #||
||#     Filename: search.php                             #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");

class newsSearch extends news
{
    
    function displayEasy()
	{
		return $this->tplObj->displayTemplate($this->tplObj->getTemplate('search_easy'));
	}

	function displayAdvanced()
	{
		return $this->tplObj->displayTemplate($this->tplObj->getTemplate('search_advanced'));
	}

	function doSearch()
	{
		switch (@$_POST['searchtype'])
		{
		case 'easy':
			$getSearch = $this->dbObj->db_query("SELECT * FROM " . TBL_NEWS . "
										        WHERE title LIKE '".addslashes($_POST['search'])."%'
                                                OR news LIKE '".addslashes($_POST['search'])."%'
                                                ");
			return $getSearch;
		break;
		case 'advanced':
        	$sqlExtra = '';
			if (!empty($_POST['title']))
			{
				$sqlExtra.="WHERE title LIKE '".addslashes($_POST['search'])."%'";
			}
        
			if (!empty($_POST['news']))
			{
				if (empty($sqlExtra))
					$sqlExtra.="WHERE news LIKE '".addslashes($_POST['search'])."%'";
				else
					$sqlExtra.="AND news LIKE '".addslashes($_POST['search'])."%'";
			}              

			$getSearch = $this->dbObj->db_query("SELECT * FROM " . TBL_NEWS . "
										".$sqlExtra."
										");
			return $getSearch;
		break;
		}
	}

	function displayResults()
	{
		$searchQuery=$this->doSearch();
		if ($this->dbObj->db_numrows($searchQuery) != 0)
		{
			$searchlist='';
			while ($search=$this->dbObj->db_fetcharray($searchQuery))
				$searchlist .= $this->tplObj->replace($this->tplObj->getTemplate('search_results_list'),$search);

			$search = array(
						    "num" => $this->dbObj->db_numrows($searchQuery),
                            "searchlist" => $searchlist
                            );      

			return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('search_results'),$search));
		}
		else
			return $this->tplObj->displayTemplate($this->tplObj->getTemplate('search_noresults'));
	}
    
}

?>
