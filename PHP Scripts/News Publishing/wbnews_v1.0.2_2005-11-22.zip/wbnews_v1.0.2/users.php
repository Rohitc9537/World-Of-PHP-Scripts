<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 17th September 2005                     #||
||#     Filename: users.php                              #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");
    
class user
{
    
var $tplObj;
var $dbObj;
var $config;
var $GLOBALS;

var $formError;

    /**
    */
    function user($config)
    {
        global $tpl, $dbclass, $GLOBALS;
        
        $this->tplObj = $tpl;
        $this->GLOBALS = $GLOBALS;
        $this->dbObj = $dbclass;
        $this->config = $config;
    }
    
    /**
    */
    function protectedArea()
    {
        if ($this->config['systemstatus'] != 0)
            return;
        
        if (isset($_SESSION['userid']))
            return $this->dbObj->db_checkRows("SELECT userid FROM " . TBL_USERS . " WHERE userid = '" . (int)$_SESSION['userid'] . "'");
        else
            return false;
    }
    
    /**
    */
    function valRegistration()
    {
        
        
        if (!defined("LIB_FORMVAL"))
        {
            include $this->GLOBALS['installdir']."/includes/lib/formvalidation.php";
            $formVal = new formVal();
        }
        
        if ($this->dbObj->db_checkRows("SELECT username FROM " . TBL_USERS . " WHERE username = '" . htmlentities(addslashes($_POST['register_username'])) . "'"))
            $formVal->addError("Username Exists");
        
        $formVal->checkEmpty($_POST['register_username'],'Username',3);
		$formVal->checkEmpty($_POST['register_password'],'Password',5);
		$formVal->checkEmpty($_POST['postname'],'Post Name',2);
		$formVal->validEmail($_POST['email']);
		if (sizeof($formVal->errors) != 0)
		{
			$this->formError = $formVal->displayErrors();
			return false;
		}
		else
			return true;
        
    }
    
    /**
    */
    function register()
    {
        
        if ($this->config['systemstatus'] != 0)
            return;
        
        if (!$this->protectedArea())
        {
            
            if (isset($_POST['register_submit']))
			{
				if ($this->valRegistration() != false)
					return $this->addUser();
			} 
			
			//display user form
			$form = array(
                        "username" => (isset($_POST['register_username']) ? $_POST['register_username'] : ''),
                        "email" => (isset($_POST['email']) ? $_POST['email'] : ''),
                        "postname" => (isset($_POST['postname']) ? $_POST['postname'] : ''),
                        "error" => (isset($this->formError) ? $this->formError : "")
                        );
						
			return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('user_registerform'), $form));
            
        }
        else
            return $this->tplObj->displayTemplate($this->tplObj->getTemplate('user_register_logged'));
    }
    
    /**
    */
    function addUser()
    {
        $this->dbObj->query("INSERT INTO " . TBL_USERS . "
						(userid, usergroupid, username, password, email, postname)
						VALUES('null', '" . $this->config['default_usergroupid'] . "', 
                        '" . htmlentities(addslashes($_POST['register_username'])) . "', 
                        '" . md5($_POST['register_password'] . $this->GLOBALS['salt']) . "', '" . $_POST['email'] . "', 
                        '"  .addslashes(htmlentities($_POST['postname'])) . "')
						");
                        
		//user_added tpl
		return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('user_registered'), array('username'=> htmlentities(stripslashes($_POST['register_username']))) ));
    }
    
    /**
    */
    function valLogin()
    {
        if ($this->dbObj->db_checkRows("SELECT username FROM " . TBL_USERS . " WHERE username = '" .htmlentities(addslashes($_POST['login_username'])) . "' AND password = '" . md5($_POST['login_password'] . $this->GLOBALS['salt']) . "'"))
            return true;
        else
		{
			$this->formError = "Invalid User/Password";
			return false;
		}
    }
    
    /**
    */
    function logIn()
    {
        
        if ($this->config['systemstatus'] != 0)
            return;
        
        if (isset($_POST['login_submit']))
		{
			if ($this->valLogin()!=false)
				return $this->logUserIn();
		}
		
		$form = array(
					"error" => (!empty($this->formError) ? $this->formError : ''),
					"username" => (isset($_POST['login_username']) ? $_POST['login_username'] : '')
					);
					
   	 	return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('user_loginform'), $form));
    }
    
    function logUserIn()
    {
        $userInfo = $this->dbObj->db_fetcharray($this->dbObj->db_query("SELECT userid FROM " . TBL_USERS . " WHERE username = '" . htmlentities(addslashes($_POST['login_username']) . "'")));
		$_SESSION['userid'] = $userInfo['userid'];
		return $this->tplObj->displayTemplate($this->tplObj->getTemplate('user_loggedin'));
    }
    
    /**
    */
    function logout()
    {
        if ($this->config['systemstatus'] != 0)
            return;
        
        unset($_SESSION['userid']);
        return $this->tplObj->displayTemplate($this->tplObj->getTemplate('user_loggedout'));
    }

}
    
?>
