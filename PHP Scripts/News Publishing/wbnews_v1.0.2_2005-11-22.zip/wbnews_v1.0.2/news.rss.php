<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 18th September 2005                     #||
||#     Filename: news.rss.php                           #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	define('wbnews', true);

$installpath = substr(__FILE__, 0, (($pos = strpos(__FILE__, basename(__FILE__))) != -1 ? $pos : 0));
include $installpath . "global.php"; //get the global file

if ($newsConfig['rss_on'] == 1 && $newsConfig['systemstatus'] == 0)
{
    // RSS Header
    $display = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    
    // XSL Header
    if (file_exists($config['installdir'] . "/templates/" . $theme['THEME_DIRECTORY'] . "/rss/feed.xsl"))
    {
        $stylesheet = 'http://' . $_SERVER['HTTP_HOST'] . str_replace($_SERVER['DOCUMENT_ROOT'], "", $config['installdir']);
        $stylesheet .= '/templates/' . $theme['THEME_DIRECTORY'] . "/rss/feed.xsl";
        $display .= '<?xml-stylesheet type="text/xsl" href="' . $stylesheet . '"?>' . "\n";
    }
    
    $display .= '<rss version="2.0">' . "\n";
    $display .= '<channel>' . "\n";
    $display .= '<title>' . $newsConfig['sitename'] . '</title>' . "\n";
    $display .= '<link>' . $newsConfig['siteaddress'] . '</link>' . "\n";
    $display .= '<description>WB News Generated RSS File</description>' . "\n";
    $display .= '<generator>WB News v1.0.0 - http://webmobo.com</generator>' . "\n";
    $display .= '<language>en-us</language>' . "\n";
    
    // news items
    $getNews = $dbclass->db_query("SELECT *, DATE_FORMAT(FROM_UNIXTIME(timeposted), '%a, %e %b %Y %T " . date("O") . "') as timeposted
                                   FROM " . TBL_NEWS
                                   );
    if ($dbclass->db_numrows($getNews))
        while ($news = $dbclass->db_fetcharray($getNews))
        {
            $display .= '<item>' . "\n";
            
            $replace = array("\n", "\r");
            $news['news'] = str_replace($replace, "", $news['news']);
            
            $display .= '<title>' . $news['title'] . '</title>' . "\n";
            $display .= '<link>' . $tpl->replace($newsConfig['newsdisplay'], array("newsid" => $news['id'])) . '</link>' . "\n";
            
            if (preg_match("/<([^>]|\n)*>/is", $news['news']))
                $display .= '<description><![CDATA[' . $news['news'] . ']]></description>' . "\n";
            else
                $display .= '<description>' . $news['news'] . '</description>' . "\n";
            
            $display .= '<pubDate>' . $news['timeposted'] . '</pubDate>' . "\n";
            $display .= '</item>' . "\n";
        }
    
    // footer
    $display .= '</channel>'."\n";
    $display .= '</rss>';
    
    header('Content-type: application/xml');
    echo $display;
}

?>
