<?php

include '../news.rss.php';

?>
