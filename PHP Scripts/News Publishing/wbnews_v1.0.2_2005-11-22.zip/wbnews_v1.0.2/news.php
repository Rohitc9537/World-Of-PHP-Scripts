<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 11th September 2005                     #||
||#     Filename: news.php                               #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");
    
// include the mainNews class
if (isset($config['installdir']))
    include $config['installdir'] . "/mainNews.php";
else
    include substr(__FILE__, 0, (($pos = strpos(__FILE__, basename(__FILE__))) != -1 ? $pos : 0)) . "mainNews.php";
    
// we need to get the bbcode file too
include $config['installdir'] . "/includes/bbcode.php";

class news extends mainNews
{
    
    /**
        @access
        @return
    */
    function news($config)
    {
        // update the main constructor
        $this->mainNews($config);
    }
    
    /**
        @access
        @param
        @param int limitChars - If set it limits the amount of characters to display
        @return
    */
    function displayNews($news = '', $limitChars = '')
    {
        if ($this->config['systemstatus'] == 0)
        {
            $getNews = $this->getNews($news, (isset($_GET['p']) && is_numeric($_GET['p']) ? $_GET['p'] : 0) );
            
            if ($this->dbObj->db_numrows($getNews))
            {
                $display = "";
                while ($newsArray = $this->dbObj->db_fetcharray($getNews))
                {
                    $newsArray['sendtofriends'] = ($this->config['sendtofriend'] == 1 ? $this->tplObj->replace($this->GLOBALS['TPL_SENDFRIEND_LINK'], array("id" => $newsArray['newsid'])) : "");
                    
                    if ($limitChars > 0)
                        $newsArray['news'] = limitWords($newsArray['news'], $limitChars);
                    
                    /*
                        Parse BBCode
                        Parse Emoticons
                        User Built Word Wrap Function
                        Filter out bad words
                        newline characters to line breaks in HTML
                    */
                    $newsArray['news'] = nl2br($newsArray['news']);
                    $newsArray['news'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($newsArray['news']) ), $this->config['wordwrap'], LINE_BREAK) );
                    
                    /// Category Avatar / Picture
                    $newsArray['avatar'] = '';
                    if (isset($newsArray['avatar_url']) && isset($newsArray['avatar_name']))
                        if (!empty($newsArray['avatar_url']) || !empty($newsArray['avatar_name']))
                            $newsArray['avatar'] = $this->getAvatarImage($newsArray['catname'], $newsArray['avatar_name'], $newsArray['avatar_url']);
                    
                    $display .= $this->tplObj->replace($this->tplObj->getTemplate("displaynews"), $newsArray);
                }
                return $this->tplObj->displayTemplate($display);
                
            }
            else
            {
                // we have no news articles
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_NONEWS']);
            }
            
        }
        else
        {
            // news system is offline
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_SYSTEM_OFFLINE']);
        }
        
    }
    
    /**
        @access public
        @param int newsid - The News ID
        @return string
    */
    function displaySingleNews($newsid)
    {
        if ($this->config['systemstatus'] == 0)
        {
            
            $getNews = $this->getNews('single', '', $newsid);
            if ($this->dbObj->db_numrows($getNews))
            {
                
                $newsArray = $this->dbObj->db_fetcharray($getNews);
                
                $newsArray['sendtofriends'] = ($this->config['sendtofriend'] == 1 ? $this->tplObj->replace($this->GLOBALS['TPL_SENDFRIEND_LINK'], array("id" => $newsArray['newsid'])) : "");
                    
                /*
                    Parse BBCode
                    Parse Emoticons
                    User Built Word Wrap Function
                    Filter out bad words
                    newline characters to line breaks in HTML
                */
                $newsArray['news'] = nl2br($newsArray['news']);
                $newsArray['news'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($newsArray['news']) ), $this->config['wordwrap'], LINE_BREAK) );
                
                /// Category Avatar / Picture
                $newsArray['avatar'] = '';
                if ($newsArray['avatar_url'] !== NULL || $newsArray['avatar_name'] !== NULL)
                    $newsArray['avatar'] = $this->getAvatarImage($newsArray['catname'], $newsArray['avatar_name'], $newsArray['avatar_url']);
                    
                return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('singlenews'), $newsArray));
                
            }
            else
            {
                // we have no news articles
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_NONEWS']);
            }
            
        }
        else
        {
            // news system is offline
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_SYSTEM_OFFLINE']);
        }
        
    }
    
    /**
        @access
        @param
        @return string
    */
    function displayNewsDateGroup($news = '')
    {
        
        if ($this->config['systemstatus'] == 0)
        {
            
            $getDateGroup = $this->getNews('dategroup');
            $getNews = $this->getNews($news, (isset($_GET['p']) && is_numeric($_GET['p']) ? $_GET['p'] : 0) );
            
            if ($this->dbObj->db_numrows($getNews))
            {
                
                $newsList = array();
                while ($row = $this->dbObj->db_fetcharray($getNews))
                    $newsList[] = $row;
                
                $newsListSize = sizeof($newsList);
                $display = "";
                while ($group = $this->dbObj->db_fetcharray($getDateGroup))
                {
                    $numNews = 0;
                    $group['newslist'] = "";
                    for ($i = 0; $i < $newsListSize; $i++)
                    {
                        
                        if ($newsList[$i]['dateGroup'] == $group['date'])
                        {
                            
                            $newsList[$i]['sendtofriends'] = ($this->config['sendtofriend'] == 1 ? $this->tplObj->replace($this->GLOBALS['TPL_SENDFRIEND_LINK'], array("id" => $newsList[$i]['newsid'])) : "");
                    
                            /*
                                Parse BBCode
                                Parse Emoticons
                                User Built Word Wrap Function
                                Filter out bad words
                                newline characters to line breaks in HTML
                            */
                            $newsList[$i]['news'] = nl2br($newsList[$i]['news']);
                            $newsList[$i]['news'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($newsList[$i]['news']) ), $this->config['wordwrap'], LINE_BREAK) );
                            
                            /// Category Avatar / Picture
                            $newsList[$i]['avatar'] = '';
                            if (isset($newsList[$i]['avatar_url']) && isset($newsList[$i]['avatar_name']))
                                if ($newsList[$i]['avatar_url'] !== NULL || $newsList[$i]['avatar_name'] !== NULL)
                                    $newsList[$i]['avatar'] = $this->getAvatarImage($newsList[$i]['catname'], $newsList[$i]['avatar_name'], $newsList[$i]['avatar_url']);
                                
                            $group['newslist'] .= $this->tplObj->replace($this->tplObj->getTemplate('displaynews'), $newsList[$i]);
                            $numNews++;
                        }
                        
                    }
                    
                    if ($numNews != 0)
                        $display .= $this->tplObj->replace($this->tplObj->getTemplate('display_newsdategroup'), $group);
                }
                
                return $this->tplObj->displayTemplate($display);
                
            }
            else
            {
                // we have no news articles
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_NONEWS']);
            }
            
        }
        else
        {
            // news system is offline
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_SYSTEM_OFFLINE']);
        }
        
    }
    
    /**
        @access
        @return
    */
    function displayLastestNews()
    {
        
        if ($this->config['systemstatus'] == 0)
        {
            
            $getNews = $this->getNews('latest');
            if ($this->dbObj->db_numrows($getNews))
            {
                
                $newsArray = $this->dbObj->db_fetcharray($getNews);
                
                $newsArray['sendtofriends'] = ($this->config['sendtofriend'] == 1 ? $this->tplObj->replace($this->GLOBALS['TPL_SENDFRIEND_LINK'], array("id" => $newsArray['newsid'])) : "");
                    
                /*
                    Parse BBCode
                    Parse Emoticons
                    User Built Word Wrap Function
                    Filter out bad words
                    newline characters to line breaks in HTML
                */
                $newsArray['news'] = nl2br($newsArray['news']);
                $newsArray['news'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($newsArray['news']) ), $this->config['wordwrap'], LINE_BREAK) );
                
                /// Category Avatar / Picture
                $newsArray['avatar'] = '';
                if ($newsArray['avatar_url'] !== NULL || $newsArray['avatar_name'] !== NULL)
                    $newsArray['avatar'] = $this->getAvatarImage($newsArray['catname'], $newsArray['avatar_name'], $newsArray['avatar_url']);
                    
                return $this->tplObj->displayTemplate($this->tplObj->replace($this->tplObj->getTemplate('singlenews'), $newsArray));
                    
            }
            else
            {
                // we have no news articles
                return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_NONEWS']);
            }
            
        }
        else
        {
            // news system is offline
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_SYSTEM_OFFLINE']);
        }
        
    }
    
    /**
        @access public
        @param string title     - The name of the category
        @param string name      - The Avatar file name which is located in avatar directory if not NULL
        @param string url       - The Avatar Absolute path to avatar if not NULL
        @return string
    */
    function getAvatarImage($title, $name, $url)
    {
        if ($name !== NULL)
        {
            $url = 'http://' . $_SERVER['HTTP_HOST'] . "" . 
                   str_replace($_SERVER['DOCUMENT_ROOT'], "", $this->GLOBALS['installdir']) . "/avatar/" . $name;
            $contents = array("image" => $url,
                              "title" => $title
                              );
                              
            return $this->tplObj->replace($this->GLOBALS['TPL_AVATARIMAGE'], $contents);
        }
        else
        {
            $contents = array("image" => $url,
                              "title" => $title
                              );
                              
            return $this->tplObj->replace($this->GLOBALS['TPL_AVATARIMAGE'], $contents);
        }
    }
    
    /**
        Creates Previous Next Links
    
        @access public
        @return string
    */
    function pagination()
    {
        
        if ($this->config['systemstatus'] != 0)
            return;
        
        // we need to first get the number of rows
        switch ($this->newsQueryType)
        {
        
        case 'single':
        case 'latest':
            return NULL; // you cant use the pagination method
        break;
        case 'all':
        
            $rows = $this->dbObj->db_numrows(
                    $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted),'%W %D %M, %Y') as dateGroup,
                                           u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                           WHERE n.userid = u.userid
                                           " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           ") );
        
        break;
        case 'archive':
            
            $rows = $this->dbObj->db_numrows(
            $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted + (".toGMT().") + (3600 * ".$this->config['timezone']." )),'%W %D %M, %Y') as dateGroup,
                                           u.postname, cat.name as catname, cat.avatar_name, cat.avatar_url
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           LEFT JOIN " . TBL_CATEGORY . " as cat ON (cat.id = n.catid)
                                           WHERE n.userid = u.userid
                                           AND DATE_FORMAT(FROM_UNIXTIME(n.timeposted), '%M %Y') = '" . addslashes($_GET['month']) . " " . addslashes($_GET['year']) . "'
                                           " . ($this->catid !== null ? "AND cat.id = '" . $this->catid . "'" : "") . "
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           ") );
        
        break;
        case 'default':
        
            $rows = $this->dbObj->db_numrows(
                    $this->dbObj->db_query("SELECT COUNT(c.id) AS comments, n.id as newsid, n.title, n.news, n.allowcomments, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted), '" . $this->config['dateFormat'] . "') as `date`, 
                                           DATE_FORMAT(FROM_UNIXTIME(n.timeposted),'%W %D %M, %Y') as dateGroup,
                                           u.postname
                                           FROM " . TBL_NEWS . " as n, " . TBL_USERS . " as u
                                           LEFT JOIN " . TBL_COMMENTS . " as c ON (n.id = c.newsid)
                                           WHERE n.userid = u.userid
                                           AND n.catid <= '0'
                                           GROUP BY n.id
                                           ORDER BY n.timeposted DESC
                                           "));
        
        break;
            
        }
        
        // work out if previous allowed
        $contents = array("prev" => '', "next" => '');
        if (isset($_GET['p']) && $_GET['p'] >= 1)
            $contents['prev'] = $this->tplObj->replace($this->GLOBALS['TPL_PAGINATION_PREV'], array("p" => $this->page - 1));
            
        // work out if next allowed
        if (!isset($_GET['p']))
        {
            if ($rows > $this->config['newslimit'])
                $contents['next'] = $this->tplObj->replace($this->GLOBALS['TPL_PAGINATION_NEXT'], array("p" => $this->page + 1));
        }
        else if ((($_GET['p'] * $this->config['newslimit'] + $this->config['newslimit']) < $rows))
            $contents['next'] = $this->tplObj->replace($this->GLOBALS['TPL_PAGINATION_NEXT'], array("p" => $this->page + 1));
        
        return $this->tplObj->displayTemplate($this->tplObj->replace($this->GLOBALS['TPL_PAGINATION'], $contents));
        
    }

}

?>
