<?php

/*========================================================*\
||########################################################||
||#                                                      #||
||#     WB News v1.0.0                                   #||
||# ---------------------------------------------------- #||
||#     Copyright (c) 2004-2005                          #||
||#     Created: 14th September 2005                     #||
||#     Filename: archive.php                            #||
||#                                                      #||
||########################################################||
/*========================================================*/

/**
	@author Paul Mcilwaine - Webmobo
	@version 1.0
	@package main
*/

if (!defined('wbnews'))
	die ("Hacking Attempt");

class newsArchive extends news
{
    
    /**
    */
    function newsArchive($config)
    {
        $this->news($config);
    }
    
    /**
    */
    function archiveList()
    {
        if ($this->config['systemstatus'] != 0)
            return;
            
        $getArchive = $this->dbObj->db_query("SELECT DATE_FORMAT(FROM_UNIXTIME(timeposted),'%M') AS themonth,
						  			          DATE_FORMAT(FROM_UNIXTIME(timeposted),'%Y') AS theyear
                                              FROM " . TBL_NEWS . "
                                              WHERE DATE_FORMAT(FROM_UNIXTIME(timeposted),'%M %Y') != '".date("F Y")."'
                                              " . ($this->catid !== null ? "AND catid = '" . $this->catid . "'" : "") . "
                                              GROUP BY timeposted DESC
                                              ");
                                    
        $archiveList = array();
        while ($archive = $this->dbObj->db_fetcharray($getArchive))
            if (array_key_exists($archive['themonth'] . " " . $archive['theyear'], $archiveList))
                $archiveList[$archive['themonth']." ".$archive['theyear']]++;
            else
                $archiveList[$archive['themonth']." ".$archive['theyear']] = 1;
                
                
        if (!empty($archiveList))
        {
            $display = '';
			foreach ($archiveList as $key => $value)
			{
				$val = explode(" ",$key);
				$list = array(
							"date" => $key,
							"month" => $val['0'],
							"year" => $val['1'],
							"articles" => $value
							);
                            
				$display .= $this->tplObj->replace($this->tplObj->getTemplate('archivelist'), $list);
			}
			return $this->tplObj->displayTemplate($display);
        }
        
    }
    
    /**
    */
    function displayNewsArticles()
    {
        if ($this->config['systemstatus'] != 0)
            return;
        
        $getNews = $this->getNews('archive', (isset($_GET['p']) && is_numeric($_GET['p']) ? $_GET['p'] : 0) );
        
        if ($this->dbObj->db_numrows($getNews))
        {
            $display = "";
            while ($newsArray = $this->dbObj->db_fetcharray($getNews))
            {
                $newsArray['sendtofriends'] = ($this->config['sendtofriend'] == 1 ? $this->tplObj->replace($this->GLOBALS['TPL_SENDFRIEND_LINK'], array("id" => $newsArray['newsid'])) : "");

                /*
                    Parse BBCode
                    Parse Emoticons
                    User Built Word Wrap Function
                    Filter out bad words
                    newline characters to line breaks in HTML
                */
                $newsArray['news'] = nl2br($newsArray['news']);
                $newsArray['news'] = badWordFilter($this->config, word_wrap( emoticons( bbcode($newsArray['news']) ), $this->config['wordwrap'], LINE_BREAK) );
                
                /// Category Avatar / Picture
                $newsArray['avatar'] = '';
                if (isset($newsArray['avatar_url']) && isset($newsArray['avatar_name']))
                    if ($newsArray['avatar_url'] !== NULL || $newsArray['avatar_name'] !== NULL)
                        $newsArray['avatar'] = $this->getAvatarImage($newsArray['catname'], $newsArray['avatar_name'], $newsArray['avatar_url']);
                
                $display .= $this->tplObj->replace($this->tplObj->getTemplate("displaynews"), $newsArray);
            }
            return $this->tplObj->displayTemplate($display);
            
        }
        else
        {
            // we have no news articles
            return $this->tplObj->displayTemplate($this->GLOBALS['ERROR_INVALIDURL']);
        }
    }
    
}

?>
