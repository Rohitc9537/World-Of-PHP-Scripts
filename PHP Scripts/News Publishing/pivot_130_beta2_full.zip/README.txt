

-= Pivot 1.30 Beta 2 - Rippersnapper =-



If you're reading this, you've downloaded and extracted a build of Pivot. Look 

here for instructions on how to install:

http://www.pivotlog.net/help/help_get_files.php





