// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

/* Remember to namespace the language parameters <your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Ceci est un exmple pour le gabarit de popup',
template_desc : 'Ceci est un exmple pour le gabarit d\'un bouton'
});
