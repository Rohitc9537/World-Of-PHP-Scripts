// PL lang variables

tinyMCE.addToLang('',{
insert_flash : 'Wstaw/Edytuj animacje Flash',
insert_flash_file : 'Plik Flash (.swf)',
insert_flash_size : 'Rozmiar',
insert_flash_list : 'Pliki Flash',
flash_props : 'Wlasciwosci animacji Flash'
});
