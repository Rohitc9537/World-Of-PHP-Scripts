//IT lang variables

tinyMCE.addToLang('',{
insert_emotions_title : 'Inserisci una emoticon',
emotions_desc : 'Emoticon'
});
