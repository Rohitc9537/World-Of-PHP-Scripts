<?php
// Name: TinyMCE editor extension.
// Version: 0.1
// Author: Pivot Development Team
// License: GPL 2.0

// See pre_editor_wysi for instructions.


/**
 * 
 *
 */
function post_editor_wysi_init() {

		
}


/**
 * 
 *
 */
function post_editor_wysi() {

	
}


?>