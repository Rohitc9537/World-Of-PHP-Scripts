 ***************************************************************************
* Pivot template : Mojito version 1.0 108kB
* -------------------------------------------------------------------------
* created : September 29, 2004
* copyright : GPL version 2
* creator : Kevin Wetzels
* email : kevin.wetzels@gmail.com
* web : http://legion.gibbering.net/el/
 ***************************************************************************
*
* This template is free; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
 ***************************************************************************
*
* description / special instructions:
*
* Place the files in the pivot/templates/ folder.
*
* If you've configured Pivot to not use popups for entries, select 
* entrypage_template_nopopup.html. This adds the secondary information
* to the entry page (About, Last referrers, linkdump, etc.).
*
* If you have any questions regarding Pivot, visit http://pivotlog.net
* and the forums at http://forum.pivotlog.net/. If you have questions
* regarding this template, contact me via email or via my website (for
* details see top of this document).
*
* Enjoy and have fun blogging.
*
 ***************************************************************************