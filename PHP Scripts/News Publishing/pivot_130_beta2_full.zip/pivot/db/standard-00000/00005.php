<?php /* pivot */ die(); ?>a:17:{s:4:"code";i:5;s:4:"date";s:16:"2005-10-28-23-10";s:12:"introduction";s:645:"<p>If you can read this, you have succesfully installed a version of
Pivot. Yay!! To help you further on your way, the following links might
be of use to you:</p>

<ul>
  <li>The official <a href="http://www.pivotlog.net/">Pivot Homepage</a>.</li> <li>The online documentation at <a href="http://www.pivotlog.net/help">Pivot Help</a> should be
of help.</li>
  <li>There's always people willing to help on the <a href="http://www.pivotlog.net/forum">Pivot Forums</a></li>
  <li>If you're looking for a new template, go to <a href="http://www.pivotstyles.net/">Pivotstyles.net</a>.</li> 
</ul>
<p>And, of course: Have fun with Pivot!</p>";s:4:"body";s:0:"";s:8:"category";a:1:{i:0;s:7:"default";}s:12:"publish_date";s:16:"2005-10-29-12-00";s:9:"edit_date";s:16:"2005-10-29-12-17";s:5:"title";s:19:"Pivot 1.30 Beta 2..";s:8:"subtitle";s:0:"";s:4:"user";s:10:"Pivot team";s:10:"convert_lb";s:1:"0";s:6:"status";s:7:"publish";s:14:"allow_comments";s:1:"1";s:8:"keywords";s:0:"";s:7:"vialink";s:0:"";s:8:"viatitle";s:0:"";s:8:"comments";a:1:{i:0;a:9:{s:4:"name";s:3:"Bob";s:5:"email";s:0:"";s:3:"url";s:23:"http://www.pivotlog.net";s:2:"ip";s:13:"192.168.0.103";s:4:"date";s:16:"2005-10-29-12-15";s:7:"comment";s:38:"And this is what a comment looks like!";s:10:"registered";i:0;s:6:"notify";N;s:8:"discreet";N;}}}