<?php
/*
+--------------------------------------------------------------------------
|   Alex News Engine
|   ========================================
|   by Alex H�ntschel
|   (c) 2002 AlexScriptEngine
|   http://www.alexscriptengine.de
|   ========================================
|   Web: http://www.alexscriptengine.de
|   Email: info@alexscriptengine.de
+---------------------------------------------------------------------------
|
|   > Beschreibung
|   > Konfigurationsdatei
|
|	> Dieses Script ist KEINE Freeware. Bitte lesen Sie die Lizenz-
|	> bedingungen (read-me.html) f�r weitere Informationen.
|	>-----------------------------------------------------------------
|	> This script is NOT freeware! Please read the Copyright Notice
|	> (read-me_eng.html) for further information. 
|
|	> $Id: config.inc.php 2 2005-10-08 09:40:29Z alex $
|
+--------------------------------------------------------------------------
*/

#######################################
# ab hier, die entsprechenden Daten   #
# eingeben                            #
#######################################
# Please insert the required Data     #
#######################################

#// hier den entsprechenden Host
#// your Hostname
$hostname = "localhost";
#// hier Deinen Usernamen zur Datenbank
#// your Username to the Database
$dbUname = "root";
#// hier das Passwort zur Datenbank
#// your Password to the Database
$dbPasswort = "";
#// Bitte hier den Namen der Datenbank eingeben
#// The Name of the Database
$dbName = "engine_news";

#// nachfolgend die Sprache des Admincenters bestimmen (1= DEUTSCH; 2= ENGLISCH)
#// choose the language for the admin area (1= GERMAN; 2= ENGLISH)
$admin_lang = 1;

#######################################
# Header und Footer Setup.            #
# Dies ist nur sinnvoll, wenn Du die  #
# Engine in einen eigenen Rahmen ein- #
# binden willst                       #
#######################################
# Header and Footer Setup.            #
# It makes only sense, if you want to #
# put the script into your own HTML-  #
# frame.                              #
#######################################

#// legt die Kopfdatei fest, bitte keine URL, sondern den vollst�ndigen Pfad angeben
#// defines the file who will put into the head of the engine, please use the complete path
#// z. B. /usr/local/httpd/htdocs/projekte/header.html
$own_header = "";

#// legt die Fu�datei fest, bitte keine URL, sondern den vollst�ndigen Pfad angeben
#// defines the file who will put into the bottom of the engine, please use the complete path
#// z. B. /usr/local/httpd/htdocs/projekte/footer.html
$own_footer = "";

#######################################
# Tabellen Setup.                     #
# Bitte nur �nder, wenn mehrere       #
# Engines verwendet werden            #
#######################################
# Table Setup.                        # 
# Please do not change the things     #
# above if you have installed only    #
# one engine.                         #
#######################################

// Tabelle f�r die Einstellungen - Table for settings
$set_table = "news1_config";

// Tabelle f�r die Userdaten - evtl. �ndern, falls bereits eine Engine installiert ist. - Table for userdatas
$user_table = "news1_user";

// Tabelle f�r News - table to save the news
$news_table = "news1_news";

// Tabelle f�r Links - table to save the links
$newslinks_table = "news1_links";

// Tabelle f�r die Kategorien - table for categories
$newscat_table = "news1_cat";

// Tabelle f�r die Kommentare - table for comments
$newscomment_table = "news1_commments";

// Tabelle f�r die Avatars - evtl. �ndern, falls bereits eine Engine installiert ist. - table for avatars
$avat_table = "news1_avatar";

// Tabelle f�r die Usergruppen - evtl. �ndern, falls bereits eine Engine installiert ist. - table for usergroups
$group_table = "news1_groups";

$style_table = "news1_style";

$newsletter_table = "news1_newsletter";

define('APP_VERSION', '1.5.0');

define('ENG_TYPE', 'news');

define('BOARD_DRIVER', 'default');

// Kommentarzeichen entfernen, wenn diese Datei manuell eingestellt wird
//define('ENGINE_INSTALLED', true);
?>
