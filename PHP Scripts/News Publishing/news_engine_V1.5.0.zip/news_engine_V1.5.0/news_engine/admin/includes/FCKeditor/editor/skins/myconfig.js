FCKConfig.AutoDetectLanguage	= true ;
FCKConfig.DefaultLanguage		= 'de' ;