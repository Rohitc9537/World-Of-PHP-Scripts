b_text = "fetten Text einf�gen";
i_text = "kursiven Text einf�gen";
u_text = "unterstrichenen Text einf�gen";
p_text = "Absatz einf�gen";
hr_text = "Horizontale Linie einf�gen";
sub_text = "Tiefgestellten Text einf�gen";
sup_text = "Hochgestellten Text einf�gen";
icq_text = "ICQ-Adresse einf�gen";

size_text = "Textgr��e �ndern";
font_text = "Schriftart �ndern";
color_text = "Schriftfarbe �ndern";
align_text = "Text-Ausrichtung �ndern";

url_text = "Hyperlink einf�gen";
url2_text = "externen Hyperlink einf�gen";
email_text = "Email Adresse einf�gen";
img_text = "Grafik einf�gen";

code_text = "HTML Code einf�gen";
php_text = "PHP Code einf�gen";
list_text = "Liste einf�gen";
quote_text = "Zitat einf�gen";

norm_text = "einfacher Modus";
enha_text = "erweiterter Modus";

closecurrent_text = "aktuellen tag schlie�en";
closeall_text = "alle tags schlie�en";

enhanced_only_text = "<< nur im erweiterten Modus verf�gbar >>";
no_tags_text = "<< keine offenen tags vorhanden >>";
already_open_text = "<< es ist bereit der selbe tag offen >>";

HELPTEXT = "Einfaches Einf�gen von BBCode und Smilies.\n\nDiese Kontrollen erlauben das schnelle und einfache Einf�gen von BBcode in Nachrichten.\n\nBeim dr�cken eines Buttons �ffnet sich ein Pop-up Fenster,\nwo man den zu formatierenden Text eingeben kann\nDer Text wird dann automatisch an der aktuellen Position des Nachricht angehangen.\n\nUm einen Smilie in die Nachricht einzuf�gen, mu� man einfach auf den Gew�nschten klicken, sofern diese entsprechend aktiviert sind.";

tag_prompt = "Gebe einen Text ein:";
img_prompt = "Gebe hier die Url zum Bild an:";

font_formatter_prompt = "Gebe einen Text ein";

link_text_prompt = "Gebe einen Linknamen ein";
link_url_prompt = "Gebe die volle Adresse des Links ein";
link_email_prompt = "Gebe eine Email Adesse ein";

list_type_prompt = "was f�r eine Liste m�chtest du? Gebe 'ol' ein f�r eine nummerierte Liste oder gar nichts f�r eine einfache Punktliste.";
list_item_prompt = "Gebe eine Listepunkt ein.\nGebe nichts ein oder dr�cke 'Cancel' um die Liste fertigzustellen.";
