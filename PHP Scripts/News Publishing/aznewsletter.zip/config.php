<?php
// Datenbankvariablen
$dbserver="localhost";
$dbuser="root";
$dbpass="";
$db="test";
$dbtable="aznewsletter";
//
$adminmail="mail@zoerb.net";
?>