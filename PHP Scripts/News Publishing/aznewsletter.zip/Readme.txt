-----------------------------------------------------------------------------------------
---  AZNEWSLETTER v1.0 by zoerb.net - Internetdienste - (c) - Alle Rechte vorbehalten ---
---		  eMail: mail@zoerb.net - Phone/Fax: 0700 ZOERBNET (96372638) 	        ---
-----------------------------------------------------------------------------------------
--- Dieses Script wurde zu �bungszwecken programmiert, es wird keinerlei Haftung f�r  ---
---     evtl. Sch�den, durch den Betrieb dieses Scriptes �bernommen. Keine Gew�hr     ---
---               f�r Bedienkomfort, Funktionalit�t und Systemintegrit�t.             ---
-----------------------------------------------------------------------------------------
---                             http://www.zoerb.net 			     		        ---
-----------------------------------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------------------------------
- Anpassen der Variabeln in config.php
- Upload der Dateien auf den Server
- Aufrufen von admin/install.php -> Datenbankstruktur wird erstellt
- L�schen von admin/install.php
-----------------------------------------------------------------------------------------
FERTIG !
-----------------------------------------------------------------------------------------
Zur Anzeige des Eintragsformulars newsletter.php aufrufen oder in eine beliebige Datei
mit include("newsletter.php") einbinden (Dateiendung in .php �ndern !) Durch Aufrufen von
admin/admin.php k�nnen User gel�scht und bearbeitet werden. Ausserdem werden von hier
Nachrichten versendet. Es ist ratsam den Zugriff auf das Unterverzeichnis admin zu 
sch�tzen (z. Bsp. mit htaccess). 

Das Entfernen von Copyrighthinweisen aus dem Script ist untersagt, weiterhin sind �nderungen
am Layout (Bilder) der Administrationsoberfl�che nur mit Zustimmung von zoerb.netzul�ssig. 

Die Weitergabe dieses Scripts ist erw�nscht und uneingeschr�nkt gestattet.

Viel Spass
