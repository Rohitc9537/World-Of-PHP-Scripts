
<?

 $summary_template = "t_summary.html";

 $article_template = "t_article.html";

 $max_summary = 5;

 $max_latest = 5;  

 $password = "test";

?>
