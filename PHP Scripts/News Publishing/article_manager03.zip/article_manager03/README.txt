
Article Manager 0.3
Copyright 2000-2005 Aytekin Tank<aytekin@interlogy.com>
Please support us and check out our Free and cost-effective scripts at http://www.interlogy.com/
This software is under GPL license: http://www.gnu.org/copyleft/gpl.html


Installation:

1) Modify config.php, t_summary.html and t_article.html files if necessary
2) Create a folder for articles and php files and make it writable (chmod a+rw).
3) Ready to run

Files:

>Configuration:
config.php : Basic configuration file

>Templates:
t_summary.html : article summary template
t_article.html : article page template

>Script files
latest.php : Last n number of article summaries submitted
news.php : Submit articles
README.txt : This file
template.inc : PHPLib template library

>Files that will be created by the script:
article_(article_id_here).html :  article
article_summary : list of all articles submitted.

