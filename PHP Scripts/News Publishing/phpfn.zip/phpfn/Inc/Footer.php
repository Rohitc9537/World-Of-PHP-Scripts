<?php

/*	+--------------------------------------------------------------
	| PHPFreeNews - News Headlines on your website                |
	| Developed by Jim Willsher.                                  |
	| http://www.phpfreenews.co.uk                                |
	+-------------------------------------------------------------+
*/

if (! defined('IN_PHPFN'))
	die('Illegal attempt to access script directly!');

?>

<DIV class="FooterText" align="center">
	<HR width="740" size="2">
	News Management System by <A href="http://www.phpfreenews.co.uk" target="_blank">PHPFreeNews</A>, Version V<?= $ScriptVersion ?>
	<BR>
</DIV>