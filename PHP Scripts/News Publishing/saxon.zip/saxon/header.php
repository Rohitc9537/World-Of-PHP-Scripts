<?php include "config.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="url" content="" />
<meta name="revisit" content="30 days" />
<meta name="classification" content="" />
<meta name="description" content=""  />
<meta name="keywords" content="" />
<meta name="robots" content="index,follow" />
<meta name="distribution" content="Global" />
<meta name="copyright" content="" />
<meta name="SAXON author" content="esmi" />
<meta name="SAON URL" content="http://www.quirm.net/saxon/" />
<meta name="language" content="English" />
<meta name="doctype" content="Web Page" />
<meta name="docclass" content="Completed" />
<meta name="docrights" content="Copywritten Work" />
<link href="style.css" rel="stylesheet" media="screen" />
<link href="color.css" rel="stylesheet" media="screen" />
<title><?php echo $xml_title; ?></title>
</head>
<body>
<div id="wrapper">
<h1><acronym title="Simple Accessible XML Online News">SAXON</acronym>: News Management</h1>
<div id="skip-menu"><a href="#main-content">Skip Menu</a></div>
