<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Deity2</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="keywords" content="quirm CMS content managment systems chess league system design development elfin esmi" />
<meta name="Description" content="quirm net a design and development area set up by esmi and elfin" />
<meta name="author" content="elfin and esmi" />
<meta name="copyright" content="Copyright 2004 quirm.net. Most rights reserved." />
<link rel="stylesheet" href="templates/news-display.css" type="text/css" media="screen" />
</head>
<body>
