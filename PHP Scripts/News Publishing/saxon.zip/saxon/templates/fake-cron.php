<?php

// Set $lastrun = "never" to stop fake cron completely

$lastrun = "2005-10-07";

?>