<?php
include 'config.php';
?>
<!-- end content -->
</div>

<!-- end wrapper -->
</div>

<div id="footer">
SAXON <?php echo $version ?> &copy; 2005 <a href="http://www.blackwidows.co.uk">Black Widow</a>
</div>

</body>
</html>
