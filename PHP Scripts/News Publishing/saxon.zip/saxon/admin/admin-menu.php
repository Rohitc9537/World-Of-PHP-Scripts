<div id="menu">
<ul>
<li><a href="list-users.php">List Users</a></li>
<li><a href="add-user.php">Add User</a></li>
<li><a href="delete-user.php">Delete User</a></li>
<li><a href="change-user-pwd.php">Change User Password</a></li>
<li><a href="amend-user-status.php">Amend User Status</a></li>
<li><a href="../add.php">Main Menu</a></li>
</ul>
</div>

<!-- start content -->

<div id="content">
<a id="main-content" href="#main-content"></a>
