RTNews ver 0.3

This script is a very simple news poster that requires MySql.

INSTALLATION

1. Put your mysql params and change the html template in the file config.php;
2. In the page where you want to run your script write the following line of code as show in index.php:
   <?php include("/path_to/news.php"); ?> on the top of the page   
   <?php read_news(); ?> where you want to show your guestbook
3. Upload all files
4. Run from your browser install.php and set your password.
5. Delete install.php.

Ok, your script is ready, if you want to delete entries or change
your password, run admin.php from your browser.

If you have any comment or critic please write me(webmaster@toldo.info)