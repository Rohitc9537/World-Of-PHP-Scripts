<?php include("news.php"); ?>

<?php read_news(); ?>