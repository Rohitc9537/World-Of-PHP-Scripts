 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

  <title>Easy News Demo</title>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />

</head>

<body>

<!-- DO NOT USE THE NEXT ROW IN YOUR PAGE, THIS IS ONLY FOR ADMIN PREVIEW -->
<?php $easynewsPreview=true;  ?>


<!-- THE NEXT ROW SHOW YOU HOW INCLUDE NEWS IN YOUR PAGE -->
<?php include("easynews.php");?>




</body>

</html>
