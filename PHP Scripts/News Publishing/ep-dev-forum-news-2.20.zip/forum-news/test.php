<?php include_once("news.php");
$forum_obj = new EP_Dev_Forum_News();
$forum_obj->display_News("", "1", "", "0"); ?>