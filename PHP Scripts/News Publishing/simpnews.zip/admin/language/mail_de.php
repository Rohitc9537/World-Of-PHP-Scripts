<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_mail_general = "Allgemein";
$l_mail_undefined = "nicht definiert";
$l_mail_linkrequest = "{adminname} hat eine Verlinkung des Beitrags #{input_entrynr} ({entrytype}) in die Kategorie {destcatname} ({destcatnr}, {destlang}) angefordert.\r\n{actionlink}";
$l_mail_linkrequest_subj = "Anforderung einer Verlinkung (SimpNews)";
$l_mail_news = "News";
$l_mail_event = "Event";
$l_mail_readmore = "hier klicken, um mehr zu lesen";
?>