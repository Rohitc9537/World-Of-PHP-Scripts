<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_sub_email = "E-Mail";
$l_sub_mailtype = "E-Mailart";
$l_sub_mailtypes = array("HTML","nur Text");
$l_sub_subscribe = "bestellen";
$l_sub_unsubscribe = "abbestellen";
?>