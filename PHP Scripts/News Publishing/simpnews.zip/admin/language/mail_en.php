<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_mail_general = "General";
$l_mail_undefined = "undefined";
$l_mail_linkrequest = "{adminname} has requested to link entry #{input_entrynr} ({entrytype}) to category {destcatname} ({destcatnr}, {destlang}).\r\n{actionlink}";
$l_mail_linkrequest_subj = "Request to link entry (SimpNews)";
$l_mail_news = "News";
$l_mail_event = "Event";
$l_mail_readmore = "click here to read more";
?>