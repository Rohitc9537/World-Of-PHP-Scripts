<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_sub_email = "Email";
$l_sub_mailtype = "type of email";
$l_sub_mailtypes = array("HTML","plain text");
$l_sub_subscribe = "subscribe";
$l_sub_unsubscribe = "unsubscribe";
?>