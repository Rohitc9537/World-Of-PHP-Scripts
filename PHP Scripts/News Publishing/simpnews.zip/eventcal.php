<?php
/***************************************************************************
 * (c)2002-2005 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('./config.php');
require_once('./functions.php');
include_once("./includes/has_entries.inc");
if(!isset($category))
	$category=0;
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
setlocale(LC_TIME, $def_locales[$act_lang]);
require_once('./includes/get_settings.inc');
require_once('./includes/block_leacher.inc');
$lastvisitdate=0;
$actdate = date("Y-m-d 23:59:59");
$today_year = date("Y");
$heading=$eventheading;
if($eventheading)
	$pageheading=$eventheading;
else
	$pageheading=$l_events;
if($lastvisitcookie==1)
	include("./includes/lastvisit.inc");
if($evshowcalweek==1)
	$colspancols=8;
else
	$colspancols=7;
include('./includes/header.inc');
?>
<div align="<?php echo $tblalign?>">
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="<?php echo $tblalign?>" class="sntable">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<a name="top"></a>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if(strlen($eventheading)>0)
{
?>
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="<?php echo $colspancols?>"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $eventheading?></b></font></td></tr>
<?php
}
if(($enableevpropose==1) && ($maxpropose>0))
{
	$sql="select count(entrynr) as numpropose from ".$tableprefix."_tmpevents";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	if($myrow=mysql_fetch_array($result))
		if($myrow["numpropose"]>=$maxpropose)
			$enableevpropose=0;
}
if($category>0)
{
	$sql = "select * from ".$tableprefix."_categories where catnr='$category'";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	if($myrow=mysql_fetch_array($result))
	{
		$cattext=display_encoded(stripslashes($myrow["catname"]));
		$tmpsql="select * from ".$tableprefix."_catnames where catnr=".$myrow["catnr"]." and lang='".$act_lang."'";
		if(!$tmpresult=mysql_query($tmpsql,$db))
			die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		if($tmprow=mysql_fetch_array($tmpresult))
		{
			if(strlen($tmprow["catname"])>0)
				$cattext=display_encoded(stripslashes($tmprow["catname"]));
		}
		if($enableevpropose==1)
			$enableevpropose=$myrow["enablepropose"];
		echo "<tr bgcolor=\"$headingbgcolor\">";
		echo "<td align=\"center\" colspan=\"$colspancols\">";
		echo "<font face=\"$headingfont\" size=\"$contentfontsize\" color=\"$headingfontcolor\">";
		echo "<b>".$cattext."</b>";
		echo "</font></td></tr>";
	}
}
$acttime=transposetime(time(),$servertimezone,$displaytimezone);
if(!isset($sel_year))
	list($sel_year, $sel_month, $sel_day) = explode("-", date("Y-m-d",$acttime));
if(!isset($sel_day))
	$sel_day=1;
if(isset($mode))
{
	if($mode=="next")
	{
		if($sel_month<12)
			$sel_month++;
		else
		{
			$sel_month=1;
			$sel_year++;
		}
	}
	if($mode=="prev")
	{
		if($sel_month>1)
			$sel_month--;
		else
		{
			$sel_month=12;
			$sel_year--;
		}
	}
}
$workdate=getdate(mktime(0,0,0,$sel_month,1,$sel_year));
$act_month=$workdate["mon"];
$act_year=$workdate["year"];
$date_today=getdate();
$first_week_day=determine_weekday(mktime(0,0,0,$sel_month,1,$sel_year),$weekstart);
$continue=true;
$actday=27;
while(($actday<=32) && ($continue))
{
	$date_actday=getdate(mktime(0,0,0,$sel_month,$actday,$sel_year));
	if($date_actday["mon"]!=$act_month)
	{
		$lastday=$actday-1;
		$continue=false;
	}
	$actday++;
}
$day=1;
$wday=$first_week_day;
$firstweek=true;
echo "<tr bgcolor=\"$headingbgcolor\"><td colspan=\"$colspancols\">";
echo "<table align=\"left\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"><tr bgcolor=\"$headingbgcolor\">";
if(($enableevpropose==1) || ($enableevsearch==1))
{
	echo "<td align=\"center\" width=\"2%\">";
	$backurl="$act_script_url?$langvar=$act_lang&layout=$layout&category=$category&sel_year=$sel_year&sel_month=$sel_month&sel_day=$sel_day";
	if(($enableevpropose==1) && ($category>=0))
	{
		echo "<a href=\"evpropose.php?$langvar=$act_lang&amp;layout=$layout&amp;category=$category&amp;mode=new&amp;backurl=".urlencode($backurl)."\">";
		echo "<img src=\"$url_gfx/$proposepic\" border=\"0\" align=\"absmiddle\" title=\"$l_propose_event\" alt=\"$l_propose_event\"></a>";
	}
	if($enableevsearch==1)
	{
		echo "<a href=\"evsearch.php?$langvar=$act_lang&amp;layout=$layout&amp;category=$category&amp;backurl=";
		echo urlencode($backurl);
		echo "\">";
		echo "<img src=\"$url_gfx/$searchpic\" border=\"0\" align=\"absmiddle\" title=\"$l_search\" alt=\"$l_search\"></a>";
	}
	echo "</td>";
}
?>
<td align="center" width="98%">
<font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>">
<?php
	if($sel_year>1900)
		echo "<a href=\"$act_script_url?$langvar=$act_lang&amp;category=$category&amp;layout=$layout&amp;mode=prev&amp;sel_month=$sel_month&amp;sel_year=$sel_year\"><img src=\"$url_gfx/$prevpic\" title=\"$l_prevmonth\" alt=\"$l_prevmonth\" border=\"0\" align=\"absmiddle\"></a>&nbsp;&nbsp;&nbsp;&nbsp;";
	else if(($sel_year == 1900) && ($sel_month>1))
		echo "<a href=\"$act_script_url?$langvar=$act_lang&amp;category=$category&amp;layout=$layout&amp;mode=prev&amp;sel_month=$sel_month&amp;sel_year=$sel_year\"><img src=\"$url_gfx/$prevpic\" title=\"$l_prevmonth\" alt=\"$l_prevmonth\" border=\"0\" align=\"absmiddle\"></a>&nbsp;&nbsp;&nbsp;&nbsp;";
?>
<?php echo $l_monthname[$sel_month-1]." $sel_year"?>
<?php
	if($sel_year<2100)
		echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$act_script_url?$langvar=$act_lang&amp;category=$category&amp;layout=$layout&amp;mode=next&amp;sel_month=$sel_month&amp;sel_year=$sel_year\"><img src=\"$url_gfx/$fwdpic\" title=\"$l_nextmonth\" alt=\"$l_nextmonth\" border=\"0\" align=\"absmiddle\"></a>";
	else if(($sel_year == 2100) && ($sel_month<12))
		echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$act_script_url?$langvar=$act_lang&amp;category=$category&amp;layout=$layout&amp;mode=next&amp;sel_month=$sel_month&amp;sel_year=$sel_year\"><img src=\"$url_gfx/$fwdpic\" title=\"$l_nextmonth\" alt=\"$l_nextmonth\" border=\"0\" align=\"absmiddle\"></a>";
?>
</font></td></tr></table></td></tr>
<?php
list($today_year, $today_month, $today_day) = explode("-", date("Y-m-d",$acttime));
echo "<tr bgcolor=\"$contentbgcolor\">";
if($evshowcalweek==1)
{
	echo "<td align=\"center\" width=\"4%\">";
	echo "&nbsp;</td>";
}
for($i=0;$i<7;$i++)
{
	echo "<td align=\"center\" width=\"14%\">";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	echo $l_weekday[($i+$weekstart)%7];
	echo "</font></td>";
}
echo "</tr>";
while($day<=$lastday)
{
	if($firstweek)
	{
		echo "<tr bgcolor=\"$contentbgcolor\">";
		if(($first_week_day>1) && ($evshowcalweek==1))
		{
			$currtimestamp=mktime(0,1,0,$act_month,$day,$act_year);
			echo "<td align=\"center\">".week_of_year($currtimestamp,$weekstart)."</td>";
		}
		for($i=(1+$weekstart);$i<=$first_week_day;$i++)
			echo "<td>&nbsp;</td>";
		$firstweek=false;
	}
	if($wday==$weekstart)
	{
		$currtimestamp=mktime(0,1,0,$act_month,$day,$act_year);
		echo "<tr bgcolor=\"$contentbgcolor\">";
		if($evshowcalweek==1)
			echo "<td align=\"center\">".week_of_year($currtimestamp,$weekstart)."</td>";
	}
	if(intval($act_month)<10)
		$new_month_num="0$act_month";
	elseif (intval($act_month)>=10)
		$new_month_num=$act_month;
	if(intval($day)<10)
		$new_day="0$day";
	elseif (intval($day)>=10)
		$new_day=$day;
	$link_date="$act_year-$new_month_num-$new_day";
	if(($today_year==$act_year) && ($today_month==$sel_month) && ($today_day==$day))
		$bgcolor=$headingbgcolor;
	else
		$bgcolor=$contentbgcolor;
	echo "<td bgcolor=\"$bgcolor\" align=\"center\">";
	echo "<table width=\"100%\" height=\"100%\"><tr>";
	echo "<td align=\"left\" valign=\"top\" nowrap>";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	echo $new_day;
	if($caltabpic)
		echo " <img border=\"0\" align=\"absmiddle\" src=\"".$url_gfx."/$caltabpic\">";
	echo "</font></td><td align=\"right\" valign=\"top\" nowrap>";
	echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
	$hasentries=has_entries($link_date, $newsineventcal, $act_lang, $tableprefix, $db, $category, $lastvisitdate);
	$backurl="$act_script_url?$langvar=$act_lang&layout=$layout&category=$category&sel_year=$sel_year&sel_month=$sel_month&sel_day=$sel_day";
	if(($hasentries>0) && ($displayevnum==1))
	{
		$numevents=get_num_events($link_date, $newsineventcal, $act_lang, $tableprefix, $db, $category, $lastvisitdate);
		if($numevents>0)
		{
			echo "<a title=\"$l_showevents\" class=\"eventlink\" href=\"events.php?$langvar=$act_lang&amp;layout=$layout&amp;link_date=$link_date&amp;category=$category&amp;backurl=".urlencode($backurl)."\">";
			echo "($numevents)</a>";
		}
	}
	else
		echo "&nbsp;";
	echo "</font></td></tr>";
	if($hasentries>0)
	{
		echo "<tr><td align=\"center\">";
		echo "<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		if($eventcalshortnews==0)
		{
			if($eventcalonlymarkers==1)
			{
				echo "<a href=\"events.php?$langvar=$act_lang&amp;layout=$layout&amp;link_date=$link_date&amp;category=$category&backurl=".urlencode($backurl)."\">";
				event_markers($link_date, $newsineventcal, $act_lang, $tableprefix, $db, $category, $lastvisitdate);
				echo "</a>";
			}
			else
				echo "<a title=\"$l_showevents\" class=\"eventlink\" href=\"events.php?$langvar=$act_lang&amp;layout=$layout&amp;link_date=$link_date&amp;category=$category&backurl=".urlencode($backurl)."\">$l_entries</a>";
			if($hasentries>1)
				echo "&nbsp;<img src=\"$url_gfx/$newentrypic\" border=\"0\" align=\"absmiddle\">";
		}
		else
			display_event_shorts($link_date, $newsineventcal, $act_lang, $tableprefix, $db, $category, $lastvisitdate, $eventcalshortlength, $eventcalshortnum, $eventcalshortonlyheadings, $backurl);
		echo "</font></td></tr>";
	}
	echo "</table></td>";
	if($wday==(6+$weekstart))
		echo "</tr>";
	else if(($weekstart==1) && ($wday==0))
		echo "</tr>";
	$wday++;
	$wday=$wday%7;
	$day++;
}
if($wday>$weekstart)
	for($i=$wday+1;$i<=(7+$weekstart);$i++)
		echo "<td>&nbsp;</td>";
if(($weekstart==1) && ($wday<1))
	echo "<td>&nbsp;</td>";
echo "</tr>";
?>
<tr bgcolor="<?php echo $headingbgcolor?>">
<td align="center" colspan="<?php echo $colspancols?>" valign="middle">
<a class="actionlink" href="<?php echo "$act_script_url?$langvar=$act_lang&layout=$layout&category=$category"?>">
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<?php echo $l_goto_actdate?></font></a></td></tr>
<?php
if($caljumpbox==1)
{
?>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="layout" value="<?php echo $layout?>">
<input type="hidden" name="category" value="<?php echo $category?>">
<tr bgcolor="<?php echo $headingbgcolor?>">
<td align="center" colspan="<?php echo $colspancols?>" valign="middle">
<font face="<?php echo $headingfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $headingfontcolor?>">
<?php
	echo "$l_jumpto:&nbsp;";
	echo "<select class=\"snewsdropdown\" name=\"sel_month\">";
	for($i=1;$i<13;$i++)
	{
		echo "<option value=\"$i\"";
		if($i==$sel_month)
			echo " selected";
		echo ">".$l_monthname[$i-1]."</option>";
	}
	echo "</select>&nbsp;";
	echo "<select class=\"snewsdropdown\" name=\"sel_year\">";
	for($i=($today_year-$cjminyear);$i<=($today_year+$cjmaxyear);$i++)
	{
		echo "<option value=\"$i\"";
		if($i==$sel_year)
			echo " selected";
		echo ">".$i."</option>";
	}
	echo "</select>&nbsp;";
	echo "<input class=\"snewsbutton\" type=\"submit\" name=\"submit\" value=\"$l_ok\">";
	echo "</td></tr></form>";
}
echo "</table></td></tr></table></div>";
include ("./includes/footer.inc");
?>