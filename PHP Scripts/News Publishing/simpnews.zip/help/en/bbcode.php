<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../../config.php');
require_once('../../functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('../../language/lang_'.$act_lang.'.php');
include_once('../../includes/get_settings.inc');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
if(is_ns4() && $ns4style)
	echo"<link rel=stylesheet href=\"$ns4style\" type=\"text/css\">\n";
else if(is_ns6() && $ns6style)
	echo"<link rel=stylesheet href=\"$ns6style\" type=\"text/css\">\n";
else if(is_opera() && $operastyle)
	echo"<link rel=stylesheet href=\"$operastyle\" type=\"text/css\">\n";
else if(is_konqueror() && $konquerorstyle)
	echo"<link rel=stylesheet href=\"$konquerorstyle\" type=\"text/css\">\n";
else if(is_gecko() && $geckostyle)
	echo"<link rel=stylesheet href=\"$geckostyle\" type=\"text/css\">\n";
else
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">\n";
?>
<title>SimpNews - BBCode Help</title>
</head>
<body bgcolor="#cccccc">
<table width="95%" align="center">
<tr><td>
<font face="Verdana,Verdana,Geneva,Arial,Helvetica,sans-serif" size="3" color="#0000FF">
<b>Using BB Code</b></font>
</td>
</tr>
<tr bgcolor="#cccccc">
<td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
BBCode is a variation on the HTML tags you may already be familiar with.
Basically, it allows you to add functionality or style to your message that would normally require HTML.
You may want to use BBCode, because there is less coding required and it is safer to use (incorrect coding syntax will not lead to as many problems).
<br>
You can use BBCode for all textareas, where a link to this help is placed.</font><br><br>
<table border=0 cellpadding=0 cellspacing=0 width="100%" align="CENTER"><TR><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width="100%">
<TR bgcolor="#94AAD6">
<TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
URL Hyperlinking</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2">
If <i>automatically encode URL</i> is enabled for the administration interface,you no longer need to use the [URL] code to create a hyperlink.
Simply type the complete URL in either of the following manners and the hyperlink will be created automatically:
</font>
<UL>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">http://www.foo.de</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">www.foo.com</font>
</UL>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Notice that you can either use the complete http:// address or shorten it to the www domain.
If the site does not begin with &quot;www&quot;, you must use the complete &quot;http://&quot; address.
Also, you may use https and ftp URL prefixes in auto-link mode.
<br><br>
The old [URL] code will still work, as detailed below.
Just encase the link as shown in the following example (BBCode is in <font color="#0000FF">blue</FONT>).
<br><br></font><center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000FF">[url]</FONT><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">www.foo.de</font><font color="#0000FF">[/url]</FONT>
<P></center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">You can also have true hyperlinks using the [url] code.  Just use the following format:</font>
<BR><br><center>
<font color="#0000FF">[url=http://www.foo.de]</font>foo.de<font color="#0000FF">[/url]</font>
</center><p>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
In the examples above, the BBCode automatically generates a hyperlink to the URL that is encased.
It will also ensure that the link is opened in a new window when the user clicks on it.
Note that the &quot;http://&quot; part of the URL is completely optional.
In the second example above, the URL will hypelink the text to whatever URL you provide after the equal sign.
 Also note that you should NOT use quotation marks inside the URL tag.
</font>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Email Links</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
To add a hyperlinked email address within your message, just encase the email address as shown in the following example
(BBCode is in <font color="#0000FF">blue</FONT>).
<br><br>
</font>
<CENTER><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
<font color="#0000FF">[email]</FONT>bar@foo.de<font color="#0000FF">[/email]</FONT></font>
</CENTER>
<P>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
In the example above, the BBCode automatically generates a hyperlink to the email address that is encased.
</FONT>
</td></tr>
<TR bgcolor="#94AAD6"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Adding Images</font></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
To add a graphic within your message, just encase the URL of the graphic image as shown in the following example (BBCode is in <FONT COLOR="#0000FF">blue</FONT>).
<br><br>
<CENTER>
<FONT COLOR="#0000FF">[img]</FONT>http://www.foo.bar/images/image.gif<FONT COLOR="#0000FF">[/img]</FONT>
</CENTER>
<br><br>
In the example above, the BBCode automatically makes the graphic visible in your message.  Note: the "http://" part of the URL is REQUIRED for the <FONT COLOR="#0000FF">[img]</FONT> code.
</FONT>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Bold and Italics</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make italicized text or make text bold by encasing the applicable sections of your text with either the [b] [/b] or [i] [/i] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[b]</FONT><B>Tom</B><font color="#0000FF">[/b]</FONT><BR>
Hello, <font color="#0000FF">[i]</FONT><I>Jerry</I><font color="#0000FF">[/i]</FONT></font>
</CENTER>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
sub und super script</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make text sub or super script by encasing the applicable sections of your text with either the [sub] [/sub] or [sup] [/sup] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[sub]</FONT><sub>Tom</sub><font color="#0000FF">[/sub]</FONT><BR>
Hello, <font color="#0000FF">[sup]</FONT><sup>Jerry</sup><font color="#0000FF">[/sup]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
strike through text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make strike through text by encasing the applicable sections of your text with the [s] [/s] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[s]</FONT><s>Jerry</s><font color="#0000FF">[/s]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
typewriter text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make diplay text in typewriter style by encasing the applicable sections of your text with the [tt] [/tt] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[tt]</FONT><tt>Jerry</tt><font color="#0000FF">[/tt]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
centered text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can center text by encasing the applicable sections of your text with the [center] [/center] tags.
<br><br>
</font>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[center]</FONT>Jerry<font color="#0000FF">[/center]</FONT></font><br>
Will produce:<br>
Hello, <center>Jerry</center></font>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
changing alignment</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can change alignment of text by encasing the applicable sections of your text with the [align=alignment] [/align] tags.
<br><br>
</font>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[align=right]</FONT>Jerry<font color="#0000FF">[/align]</FONT></font><br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Will produce:<br>
Hello, <p align=right>Jerry</p></font>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
change textsize</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make change textsize by encasing the applicable sections of your text with the [size=size] [/size] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[size=5]</FONT><font size="5">Jerry</font><font color="#0000FF">[/size]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
change fontface</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can change fontface by encasing the applicable sections of your text with the [font=fontface] [/font] tags.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[font=Comic Sans MS]</FONT><Font face="Comic Sans MS">Tom</font><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000FF">[/font]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Color Text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make colored text by encasing the applicable sections of your text with [color=color] [/color] tags.
<br><br>
</font><CENTER><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[color=green]</FONT><FONT COLOR="green">Tom</Font><font color="#0000FF">[/font]</FONT><BR>
Hello, <font color="#0000FF">[color=yellow]</FONT><font color="yellow">Jerry</font><font color="#0000FF">[/font]</FONT></font>
</CENTER>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Bullets</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
You can make bulleted lists or ordered lists (by number or letter).
<br><br>
Unordered, bulleted list:
<br><br>
<font color="#0000FF">[list]</FONT>
<BR>
<font color="#0000FF">[*]</font>This is the first bulleted item.<BR>
<font color="#0000FF">[*]</font>This is the second bulleted item.<BR>
<font color="#0000FF">[/list]</font>
<br><br>
This produces:</font>
<ul>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">This is the first bulleted item.</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">This is the second bulleted item.</font>
</ul>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Note that you must include a closing [/list] when you end each list.
<br><br>
Making ordered lists is just as easy.  Just add either [LIST=A] or [LIST=1].  Typing [List=A] will produce a list from A to Z.  Using [List=1] will produce numbered lists.
<br><br>
Here's an example:
<br><br>
<FONT COLOR="#0000ff">[list=A]</FONT>
<BR>
<FONT COLOR="#0000ff">[*]</font> This is the first bulleted item.<BR>
<FONT COLOR="#0000ff">[*]</font> This is the second bulleted item.<BR>
<FONT COLOR="#0000ff">[/list]</font>
<br><br>
This produces:
</font>
<ol type=A>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">This is the first bulleted item.</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">This is the second bulleted item.</font>
</ul>
<TR bgcolor="#94AAD6"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
Quoting</font></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
To reference something specific enclose it as shown below (BBCode is in <FONT COLOR="#0000ff">blue</FONT>).
<br><br>
<CENTER>
<FONT COLOR="#0000ff">[QUOTE]</FONT>Ask not what your country can do for you....<BR>ask what you can do for your country.<FONT COLOR="#0000ff">[/QUOTE]</FONT>
</CENTER>
<br><br>
In the example above, the BBCode automatically blockquotes the text you reference.</FONT>
</td>
</tr>
<TR bgcolor="#94AAD6"><TD>
<FONT SIZE="2" FACE="Verdana,Geneva,Arial,Helvetica,sans-serif">
Code Tag</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<FONT SIZE="2" FACE="Verdana,Geneva,Arial,Helvetica,sans-serif">
Similar to the Quote tage, the Code tag adds some &lt;PRE&gt; tags to preserve formatting.  This useful for displaying programming code, for instance.
<br><br>
<FONT COLOR="#0000ff">[CODE]</FONT>#!/usr/bin/perl
<br><br>
print "Content-type: text/html\n\n";
<BR>
print "Hello World!";
<FONT COLOR="#0000ff">[/CODE]</FONT>
<br><br>
In the example above, the BBCode automatically blockquotes the text you reference and preserves the formatting of the coded text.</FONT>
</td>
</tr>
</td></tr>
</table>
</td></tr></table></td></tr></table>
</body>
</html>