<?php
/***************************************************************************
 * (c)2002-2004 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../../config.php');
require_once('../../functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('../../language/lang_'.$act_lang.'.php');
include_once('../../includes/get_settings.inc');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
if(is_ns4() && $ns4style)
	echo"<link rel=stylesheet href=\"$ns4style\" type=\"text/css\">\n";
else if(is_ns6() && $ns6style)
	echo"<link rel=stylesheet href=\"$ns6style\" type=\"text/css\">\n";
else if(is_opera() && $operastyle)
	echo"<link rel=stylesheet href=\"$operastyle\" type=\"text/css\">\n";
else if(is_konqueror() && $konquerorstyle)
	echo"<link rel=stylesheet href=\"$konquerorstyle\" type=\"text/css\">\n";
else if(is_gecko() && $geckostyle)
	echo"<link rel=stylesheet href=\"$geckostyle\" type=\"text/css\">\n";
else
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">\n";
?>
<title>SimpNews - BBCode Hilfe</title>
</head>
<body bgcolor="#cccccc">
<table width="95%" align="center">
<tr><td>
<font face="Verdana,Verdana,Geneva,Arial,Helvetica,sans-serif" size="3" color="#0000FF">
<b>Verwendung von BBCode / Was ist BBCode?</b></font>
</td>
</tr>
<tr bgcolor="#cccccc">
<td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
BBCode ist eine Variante von HTML-Tags, die Sie vielleicht schon kennen. Grunds&auml;tzlich k&ouml;nnen Sie mit BBCode
Formatierungen in Ihren Text einbringen, die normalerweise HTML erfordern w&uuml;rden, so zum Beispiel <b>Fettdruck</b>.
BBCode ist eine Alternative zu HTML-Code, weil BBCode weniger Fachwissen ben&ouml;tigt und sicherer zu benutzen ist.
Eventuell falsche Syntax wird Ihre Seite nicht unleserlich machen.<br>
Die Verwendung von BBCode ist bei allen Eingabefeldern m&ouml;glich, bei denen sich ein Link zu dieser Hilfe befindet.</font><br><br>
<table border=0 cellpadding=0 cellspacing=0 width="100%" align="CENTER"><TR><td bgcolor="#000000">
<table border=0 cellpadding=4 cellspacing=1 width="100%">
<TR bgcolor="#94AAD6">
<TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Verweise auf Internetadressen (URLs) einbinden</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2">
Falls <i>URLs automatisch umwandeln</i> f&uuml;r die Adminoberfl&auml;che aktiviert ist, brauchen Sie nicht mehr den [URL] -Code, um einen Hyperlink zu erzeugen.
Schreiben Sie einfach den kompletten Link auf eine der folgenden Wege und der Hyperlink wird automatisch erstellt.
Sie k&ouml;nnen so in Ihrem Beitrag ganz einfach auf eine beliebige andere Internetseite verweisen, die dann durch einen
einfachen Klick erreichbar ist:</font>
<UL>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">http://www.foo.de</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">www.foo.com</font>
</UL>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Benutzen Sie entweder die komplette http:// -Adresse oder k&uuml;rzen Sie mit www. ab. Wenn die Seite, auf die Sie
verweisen m&ouml;chten, nicht mit www. beginnt, m&uuml;ssen Sie die komplette URL http:// verwenden.
Sie k&ouml;nnen auch https:// oder ftp:// -Adressen in Links verwenden.
<br><br>
Der alte [URL] Code funktioniert weiterhin, wie weiter unten beschrieben.
Umklammern Sie einfach den Link wie folgt (BBCode ist <font color="#0000FF">blau</FONT> markiert).
<br><br></font><center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000FF">[url]</FONT><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">www.foo.de</font><font color="#0000FF">[/url]</FONT>
<P></center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Auch richtige Hyperlinks k&ouml;nnen Sie mit dem [url] -Code einbinden. Das Format ist:
</font>
<BR><br><center>
<font color="#0000FF">[url=http://www.foo.de]</font>foo.de<font color="#0000FF">[/url]</font>
</center><p>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">In den bisher genannten Beispielen erzeugt BBCode automatsich einen Hyperlink zur umklammerten URL (Internetadresse).
BBCode stellt auch sicher, dass der link in einem neuen Fenster ge&ouml;ffnet wird, wenn der Besucher auf den Link klickt.
Beachten Sie, dass der Teil &quot;http://&quot; der URL optional ist. Mit dem zweiten der obigen Beispiele k&ouml;nnen Sie die URL zu einer
beliebigen Seite lenken, die nach dem Gleichheitszeichen steht.
Bitte beachten Sie, dass Sie innerhalb der URL-Adresse KEINE Anf&uuml;hrungszeichen verwenden.
</font>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
email-Adressen einbinden</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Um eine email-Adresse innerhalb Ihrer Nachricht anzugeben, umklammern Sie die Adresse wie im folgenden Beispiel:
(BBCode ist <font color="#0000FF">blau</FONT> markiert).
<br><br>
</font>
<CENTER><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
<font color="#0000FF">[email]</FONT>bar@foo.de<font color="#0000FF">[/email]</FONT></font>
</CENTER>
<P>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">In diesem Beispiel erzeugt BBCode daraus einen Link, der automatisch das email-Programm des Besuchers startet, um
an bar@foo.de eine email schreiben zu k&ouml;nnen.
</FONT>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Bilder hinzuf&uuml;gen</font></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Verwenden Sie einfach den [img] - Code wie im folgenden Beispiel, um ein Bild in Ihren Text einzubinden.
 (BBCode ist <FONT COLOR="#0000ff">blau</FONT> dargestellt).
<br><br>
<CENTER>
<FONT COLOR="#0000ff">[img]</FONT>http://www.foo.bar/images/bild.gif<FONT COLOR="#0000ff">[/img]</FONT>
</CENTER>
<br><br>
In diesem Beispiel bindet BBCode das Bild automatisch in Ihren Beitrag ein. Beachten Sie bitte, dass der
"http://" -Teil der URL f&uuml;r das  <FONT COLOR="#0000ff">[img]</FONT>-Tag unverzichtbar ist.
</FONT>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Fettdruck und Kursivschrift</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen Text mit den [b] [/b] oder [i] [/i] - Markierungen (Tags) <b>fettdrucken</b> oder <i>schr&auml;gstellen</i>
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[b]</FONT><B>Tom</B><font color="#0000FF">[/b]</FONT><BR>
Hello, <font color="#0000FF">[i]</FONT><I>Jerry</I><font color="#0000FF">[/i]</FONT></font>
</CENTER>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sub- und Superscript</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen Text mit den [sub] [/sub] oder [sup] [/sup] - Markierungen (Tags) <sub>tief</sub> oder <sup>hoch</sup> stellen.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[sub]</FONT><sub>Tom</sub><font color="#0000FF">[/sub]</FONT><BR>
Hello, <font color="#0000FF">[sup]</FONT><sup>Jerry</sup><font color="#0000FF">[/sup]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Durchgestrichener Text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen mit den [s] [/s] - Markierungen (Tags) durchgestrichenen Text erzeugen.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[s]</FONT><s>Tom</s><font color="#0000FF">[/s]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Typewriter Text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen mit den [tt] [/tt] - Markierungen (Tags) Text in <tt>Schreibmaschinenart</tt> erzeugen.
<br><br>
</font><CENTER>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[tt]</FONT><tt>Tom</tt><font color="#0000FF">[/tt]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Zentrierter Text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen Text mit [center] [/center] - Markierungen (Tags) zentrieren.
<br><br>
</font>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[center]</FONT>Tom<font color="#0000FF">[/center]</FONT><br>
erzeugt:<br>
Hello, <center>Tom</center></font></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Textausrichtung &auml;ndern</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen die Textausrichtung mit den [align=ausrichtung] [/align] - Markierungen (Tags)&auml;ndern.
<br><br>
</font>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[align=right]</FONT>Tom<font color="#0000FF">[/align]</FONT><br>
erzeugt:<br>
Hello, <p align=right>Tom</p></font></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Textgr&ouml;sse &auml;ndern</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen mit den [size=gr&ouml;sse] [/size] - Markierungen (Tags) die Textgr&ouml;sse &auml;ndern.
<br><br></font><center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[size=5]</FONT><Font size="5">Tom</font><font color="#0000FF">[/size]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Zeichensatz &auml;ndern</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen mit den [font=zeichensatz] [/font] - Markierungen (Tags) den Zeichensatz &auml;ndern.
<br><br></font><center>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Hello, <font color="#0000FF">[font=Comic Sans MS]</FONT><Font face="Comic Sans MS">Tom</font><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#0000FF">[/font]</FONT></font>
</CENTER></td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Farbiger Text</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen Text mit [color=farbe] [/color] - Markierungen (Tags) farbig darstellen
<br><br>
</font><CENTER><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hello, <font color="#0000FF">[color=green]</FONT><FONT COLOR="green">Tom</Font><font color="#0000FF">[/font]</FONT><BR>
Hello, <font color="#0000FF">[color=yellow]</FONT><font color="yellow">Jerry</font><font color="#0000FF">[/font]</FONT></font>
</CENTER>
</td></tr>
<tr bgcolor="#94AAD6"><td>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Aufz&auml;hlungen</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Sie k&ouml;nnen auch Listen mit Aufz&auml;hlungspunkten (Punkt oder Zahl) erzeugen:
<br><br>
Liste mit Aufz&auml;hlungspunkten:
<br><br>
<font color="#0000FF">[list]</FONT>
<BR>
<font color="#0000FF">[*]</font> Dieses ist der erste Streich.<BR>
<font color="#0000FF">[*]</font> Und der zweite folgt sogleich.<BR>
<font color="#0000FF">[/list]</font>
<br><br>
Dies erzeugt:</font>
<ul>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Dieses ist der erste Streich.</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Und der zweite folgt sogleich.</font>
</ul>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Beachten Sie, dass Sie jede Liste mit [/list] abschliessen m&uuml;ssen.</font>
<br><br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Numerierte Listen sind genauso einfach. Schreiben Sie einfach [LIST=A] oder [LIST=1].
[List=A] erzeugt eine Liste, die von A bis Z numeriert ist, [List=1] erzeugt eine numerierte Liste.
</font>
<br><br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
Hier ein Beispiel:
</font>
<br><br>
<font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">
<FONT COLOR="#0000ff">[list=A]</FONT>
<BR>
<FONT COLOR="#0000ff">[*]</font> Dieses ist der erste Streich.<BR>
<FONT COLOR="#0000ff">[*]</font> Und der zweite folgt sogleich.<BR>
<FONT COLOR="#0000ff">[/list]</font>
<br><br>
Dies erzeugt:</font>
<ol type=A>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Dieses ist der erste Streich.</font>
<LI><font face="Verdana,Geneva,Arial,Helvetica,sans-serif" size="2" color="#000000">Und der zweite folgt sogleich.</font>
</ul>
</td></tr>
<TR bgcolor="#94AAD6"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
Zitieren</font></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
Um etwas zu zitieren umklammern Sie das Zitat wie folgt:
(BBCode ist wieder <FONT COLOR="#0000FF">blau</FONT> markiert).
<P>
<CENTER>
<FONT COLOR="#0000FF">[QUOTE]</FONT>Dies ist ein Zitat<FONT COLOR="#0000FF">[/QUOTE]</FONT>
</CENTER>
<P>
In diesem Beispiel r&uuml;ckt BBCode diesen Text als Zitat ein.</FONT>
</td>
</tr>
<TR bgcolor="#94AAD6"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
Code Tag</FONT></td></tr>
<TR bgcolor="#c0c0c0"><TD>
<FONT SIZE="2" FACE="Verdana, Arial">
&Auml;hnlich wie beim "Quote"-Tag [QUOTE] k&ouml;nnen Sie mit dem [CODE] Tag den Zeilenumbruch erhalten.
Das ist bei der Wiedergabe von Gedichten oder von Programmcode sinnvoll.
<br><br>
<FONT COLOR="#0000FF">[CODE]</FONT>#!/usr/bin/perl
<br><br>
print "Content-type: text/html\n\n";
<BR>
print "Hallo Welt!";
<FONT COLOR="#0000FF">[/CODE]</FONT>
<br><br>
In diesem Beispiel r&uuml;ckt BBCode den Text als Zitat ein und erh&auml;lt zus&auml;tzlich den
Zeilenumbruch.
</FONT>
</td>
</tr>
</table>
</td></tr></table></td></tr></table>
</body>
</html>