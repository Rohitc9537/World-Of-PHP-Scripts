</td>
</tr>
</table>
<table width="796" cellspacing="0" cellpadding="0" border="0">
 <tr><td bgcolor="#000000" height="1"></td></tr>
 <tr>
  <td class="SmallT" bgcolor="#9EC5E4" align="center">
   Powered by phpNewMan Version <?=$newman_ver;?><br />
   Copyright &copy; 2000 - 2003 The <a href="http://skintech.skinbase.org">SkinTech</a> Group 
  </td>
 </tr>
</table>
</body>
</html>