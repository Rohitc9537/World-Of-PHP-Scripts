<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //**                                                                                      **
  //** Language module: English                                                             **
  //******************************************************************************************

define("_CHARSET","ISO-8859-1");
define("_STATISTICS","Statistik");
define("_ACTUAL","Faktisk");
define("_LASTVISIT","Senast bes�kt");
define("_NEW","Ny");
define("_ONLINENEWS","Nyheter Online");
define("_WEEKLYPOLLQ","Vecko Fr�geenk�t");
define("_WEEKLYPOLLA","Vecko Svarsenk�t");
define("_PUBLICNEWS","Publika Nyheter");
define("_REGISTEREDUSERS","Registrerade anv�ndare");
define("_NEWSCOMMENTS","Nyhetskommentarer");
define("_ADDNEWS","L�gg till nyheter");
define("_SUBMITEDNEWS","Inskickade nyheter");
define("_OPTIONS","Valm�jligheter");
define("_NEWSHEADLINE","Huvudnyheter");
define("_AUTHOR","F�rfattare");
define("_DATE","Datum");
define("_SECTION","Avdelning");
define("_PREVIEW","F�rhandsgranska");
define("_MESSAGE","Meddelande");
define("_SUBMIT","Skicka in");
define("_HOME","Hem");
define("_NEWSMANAGER","Nyhetsmeny");
define("_MODIFYNEWS","Modifiera Nyhet");
define("_ADDNEWS","L�gg till Nyhet");
define("_ADDPARTNERS","L�gg till Partner");
define("_UPLOADLOGO","Ladda upp Logo");
define("_IMAGE","Bild");
define("_NAME","Namn");
define("_NUMBER","#");define("_","#");
define("_CATEGORYNAME","Kategorinamn");
define("_MAINMENU","Huvudmeny");
define("_KEEPIT","Spara det!");
define("_DELETEIT","Kasta det!");
define("_EDITCATEGORY","�ndra Kategori");
define("_UPLOADPICTURE","Ladda upp bild");
define("_ADDCATEGORY","L�gg till kategori");
define("_OURPARTNERS","V�ra Partners");
define("_SELECTPAGE","V�lj sida");
define("_LINK","L�nk");
define("_IN","In");
define("_OUT","Ut");
define("_AFFILIATES","Affiliates");
define("_GFX","Gfx");
define("_PREVIOUS","F�reg�ende");
define("_NEXT","Next");
define("_DESCRIPTION","Beskrivning");
define("_MODIFYPARTNERS","�ndra Partners");
define("_RSSSETTINGS","RSS Inst�llningar");
define("_NAMEOFRSSFILE","RSS filens namn");
define("_NUMBEROFNEWS","Number of news");
define("_RSSTITLE","RSS Titel");
define("_RSSLINK","RSS L�nk");
define("_RSSDESCRIPTION","RSS Beskrivning");
define("_AUTOCREATERSS","Skapa en RSS fil automatiskt efter varje nyhets�ndring");
define("_OPTIMIZED","Optimerad");
define("_OPTIMIZEDATABASE","Optimera Databas");
define("_ADDSMILEY","L�gg till Smiley");
define("_UPLOADSMILEY","Ladda upp Smiley");
define("_SMILEYEMOTION","K�nsla");
define("_SMILEYEDITOR","Smiley Editor");
define("_SMILEYCODE","Kod");
define("_EDITSMILEY","Editera Smiley");
define("_DELETESMILEY","Ta bort Smiley");
define("_NEWS","Nyheter");
define("_CATEGORY","Kategori");
define("_PARTNERS","Partners");
define("_WEEKLYPOLL","Veckofr�ga");
define("_SMILEYS","Smileys");
define("_BROWSENEWS","Bl�ddra nyheter");
define("_GROUPS","Grupper");
define("_ADMINS","Administrat�rer");
define("_USERS","Anv�ndare");
define("_USERINFO","Anv�ndarinfo");
define("_ADMINISTRATION","Administration");
define("_YOULOGOUT","Du har precis loggat ut.");
define("_LOGIN","Logga in");
define("_PASSWORD","L�senord");
define("_USERNAME","Anv�ndarnamn");
define("_WEBCONTROLPANEL","WEB CONTROL PANEL");
define("_ADDUSER","L�gg till anv�ndare");
define("_EMAIL","Email");
define("_PRIVILEGES","Beh�righeter");
define("_EMAIL","Email");
define("_EDITUSER","Editera anv�ndare");
define("_DELETEUSER","Radera anv�ndare");
define("_INFO","Info");
define("_ADDGROUP","L�gg till grupp");
define("_ADMIN","Administration");
define("_RSS","RSS");
define("_MODIFY","Modifiera");
define("_ADD","L�gg till");
define("_EDIT","�ndra");
define("_DELETE","Radera");
define("_UPLOAD","Ladda upp");
define("_GROUPNAME","Gruppnamn");
define("_SELECT","V�lj");
define("_ADDWEEKLYPOLL","L�gg till Veckofr�ga");
define("_SUBMITEDPOLLS","Inskickade fr�gor");
define("_QUESTION","Fr�ga");
define("_ANSWERS","Svar");
define("_SEPERATEANSWERSWITH","Separera svar med");
define("_EDITWEEKLYPOLL","�ndra Veckofr�ga");
define("_SUCCESS","Success");
define("_DELETENEWS","Radera Nyheter");
define("_NOTENOUGHPRIV","Du har inte tillr�cklig beh�righet!");
define("_LANGUAGE","Spr�k");
define("_CONTENT","Inneh�ll");
?>