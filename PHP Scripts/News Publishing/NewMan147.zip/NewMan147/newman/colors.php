<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

 $logo = "gfx/logos.jpg";

define("_COLOR01","000000");
define("_COLOR02","9EC5E4");
define("_COLOR03","888899");
define("_COLOR04","CCCCDD");
define("_COLOR05","000000");
define("_COLOR06","FFFEFF");
define("_COLOR_TEXT","000000");
define("_COLOR_LINK","0E2544");
define("_COLOR_VLINK","0E2544");
define("_COLOR_ALINK","0E2544");
define("_COLOR_BACK","FFFFFF");
?>