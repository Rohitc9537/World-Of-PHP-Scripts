<div class="title">Help/Info</div>
  <p><strong>Posting News</strong><br/>
      You can post news by <a href="index.php?page=postnews">clicking here.</a><br/>
      Please make sure you dont leave any blank fields.<br/>
  </p>
  <p><strong>Modifying News</strong><br/>
      Modify news by picking the news title from the news archieve menu from the right side.<br/>
      You can also click the "Modify News!" link from the main page.
  </p>
  <p><strong>Deleting News</strong><br/>
      Delete news by picking the news title from news archieve menu from the right side.<br/> 
      Click the "Delete this news!" link to delete news, this will delete the news from the database and cannot be retrieve!
  </p>
  <p><strong>qliteNews Information</strong><br/>
      qliteNews is an <a href="http://www.r2xdesign.net">r2xDesign.net</a> project.<br/>
      qliteNews or "quick" and "lite" news management system allows you to post,edit,delete news easily with no other useless options!<br/>
      If you have any comments, suggestions, bug reports please post in our <a href="http://www.r2xdesign.net/forums">forums.</a><br/>
  </p>