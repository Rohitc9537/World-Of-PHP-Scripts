<div>
  <form method="post" action="loginprocess.php">
    <strong>Username:</strong><br/>
    <input type="text" name="qname" maxlength="20" size="40"/><br/>
    <strong>Password:</strong><br/>
    <input type="text" name="qpass" size="40"/><br/>
    <input type="submit" name="qlogin" value="Login"/>
  </form>
</div>