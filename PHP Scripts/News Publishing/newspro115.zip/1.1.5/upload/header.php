<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $sitetitle ?> News - Powered by Utopia News Pro</title>
<link rel="stylesheet" href="style.css" media="all" />
<meta name="generator" content="Utopia News Pro - http://www.utopiasoftware.net/" />
<meta name="robots" content="noindex, nofollow" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>

<center>
<div align="left" class="hbox">
<div class="lbox"><a href="index.php"><img src="images/unp_logo.jpg" alt="Utopia News Pro" style="border: 0;" /></a></div>
<span class="smallfont">&nbsp;
		<a href="index.php">Main</a> | 
		<a href="postnews.php?action=post">Post News</a> | 
		<a href="editnews.php?action=edit">Edit News</a> | 
		<a href="newscache.php">News Cache</a> | 
		<a href="settings.php?action=edit">Settings</a> | 
		<a href="templates.php?action=list">Templates</a> | 
		<a href="styles.php?action=edit">Style</a> | 
		<a href="profile.php?action=edit">Profile</a> | 
		<a href="users.php?action=main">Users</a> | 
		<a href="faq.php">FAQ</a> | 
		<a href="about.php">About</a> | 
		<a href="login.php?action=logout">Logout</a>
</span>
</div></center>
<br />