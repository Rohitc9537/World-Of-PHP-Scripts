<br />
<center>
<div align="center" class="fbox smallfont">
<!-- Copyright -->
Powered By: <a href="about.php">Utopia News Pro</a> <?php echo $version ?><br />
Copyright &copy;2003 - 2005, UtopiaSoft, UtopiaSoftware.net
<!-- Copyright -->
</div></center>
<?php
if (DEV_BUILD == true)
{
?>
<br />
<center><div align="center" class="qbox smallfont">
Page generated using <?php echo $query_count ?> queries</div></center>
<?php
}
?>
</body>
</html>