<?
mysql_connect("$host", "$user", "$mysql_pass") or die(mysql_error());
mysql_select_db("$db") or die(mysql_error());
?>

