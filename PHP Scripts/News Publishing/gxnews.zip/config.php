<?php

/* All that is needed to install GX News is to edit this file accordingly, and then point your browser to install.php */

// First, some MySQL info is needed

// Your MySQL host name. Most likely, the default should work.
$host = "localhost";
// Your MySQL database name. This can be a pre-existing or new database.
$db = "database";
// Your MySQL user name. This must have the correct permissions for the selected
// database!
$user = "user";
// Your MySQL password. This was selected when you created the above user
$pass = "mysql_pass";

// These are some general options

// What do you want the password to be on the 'Add News' page?
$admin_pass = "password";
// How many entries do you want to appear in the 'latest entries' section (only titles shown)?
$num_latest = "3";

?>

