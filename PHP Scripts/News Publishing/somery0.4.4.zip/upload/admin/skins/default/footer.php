<?php
// Somery, a weblogging script by Robin de Graaf, copyright 2001-2005
// Somery is distributed under the Artistic License (see LICENSE.txt)
//
// ADMIN/SKINS/DEFAULT/FOOTER.PHP > 03-11-2005
?>

</div>

</body>
</html>
