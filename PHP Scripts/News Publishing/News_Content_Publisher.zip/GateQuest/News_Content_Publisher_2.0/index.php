<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>GateQuest php News/Content Publisher</title>
	<link rel="stylesheet" href="docs/misc/styles.css" type="text/css">
</head>

<body>

<table style="height: 100%; text-align: center; width: 90%">
	<tr>
		<td style="height: 65px; padding: 10px 0px 0px 10px; text-align: left"><a href="http://www.gatequest.net/products/News_Content_Publisher/"><img alt="" border="0" width="100" height="50" src="docs/misc/gfx/gq_logo.gif"></a></td>
	</tr>
	<tr>
		<td style="vertical-align: middle">
		<div align="center"><fieldset style="border: 1px solid #CCC; width: 50%"><legend style="margin-left: 8px">&nbsp;News/Content Target Area&nbsp;</legend>
		<div style="padding: 20px; text-align: left"><? include("edit/news.txt") ?></div></fieldset></div></td>
	</tr>
	<tr>
		<td><a href="edit/"> Edit Page &raquo; </a></td>
	</tr>
</table>

</body>
</html>
