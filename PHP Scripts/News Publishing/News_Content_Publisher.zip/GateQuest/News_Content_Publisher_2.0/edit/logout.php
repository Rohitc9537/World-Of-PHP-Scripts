<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>GateQuest php News/Content Publisher</title>
	<link rel="stylesheet" href="../docs/misc/styles.css" type="text/css">
</head>

<body>

<table style="height: 100%; text-align: center; width: 90%">
	<tr>
		<td style="height: 65px; padding: 10px 0px 0px 10px; text-align: left"><a href="http://www.gatequest.net/products/News_Content_Publisher/"><img alt="" border="0" width="100" height="50" src="../docs/misc/gfx/gq_logo.gif"></a></td>
	</tr>
	<tr>
		<td style="vertical-align: middle">
		<p>Thanks for your visit!
		<p>Click <a href="index.php">here</a> to login again.</p></td>
	</tr>
</table>

</body>
</html>
