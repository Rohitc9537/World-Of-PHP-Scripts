<style type="text/css">
<!--
body {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px; background-color: white; }
table {
font-family: verdana, arial, helvetica, sans-serif; font-size: 11px;}
a:link { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }
a:visited { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }
a:active { font-family: verdana; font-size: 11px; color: blue; text-decoration: none; }
a:hover { font-family: verdana; font-size: 11px; color: blue; text-decoration: underline; }
div.boxxy {position: absolute; display: block; width: 300px; padding: 0px; margin-bottom: 2px; margin-right: 2px; margin-left: 202px; margin-top: 168px; border: 1px solid gray; background-color: white;}
div.boxtext {position: absolute; display: block; height:18px padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: 211px; margin-top: 162px; background-color: white;}
div.tbord {border-left: 1px solid gray; border-top: 1px solid gray; border-bottom: 1px solid gray; background-color: white;}
div.grey-box {width: 400px; background: #DDDDDD; margin-top: 2px; border: 1px solid gray; text-align: left;}
div.nav-box {width: 100%; padding: 1px; background: #FAE5B0; margin-top: 2px; border: 1px solid #FAD163; text-align: center;}
div.bluein-box {width: 400px; padding: 1px; background: #e5ecf9; margin-bottom: 2px; margin-top: 2px; border: 1px solid blue; text-align: center;}
div.bluein-box2 {width: 500px; padding: 1px; background: #e5ecf9; margin-bottom: 2px; margin-top: 2px; border: 1px solid blue; text-align: left;}
div.green-box {width:400px; background:#D0EED0; margin-top: 2px; border: 1px solid green; text-align: center;}


div.content {display: block; width: 700px; padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: auto; margin-top: 2px; text-align: center; border: 1px solid #006666; background-color: white;}
div.mainframe {display: block; width: 700px; padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: auto; margin-top: auto; text-align: center;}
div.header {display: block; width: 700px; height:60px; padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: auto; margin-top: auto; text-align: center; border: 1px solid #006600; background-color: white;}
div.footer {display: block; width: 700px; padding: 0px; margin-bottom: auto; margin-right: auto; margin-left: auto; margin-top: 2px; text-align: center; border: 1px solid #006600; background-color: white;}
div.buttonsbar {display: block; width: 700px; padding: 0px margin-bottom: auto; margin-right: auto; margin-left: auto; margin-top: auto; text-align: center; border-top: 0px solid #006600; background-color: #006666;}
div.main-box {margin-left:2px; padding:1px; width: 692px; background:#FFFFFF; margin-bottom: 2px; margin-right: 2px; margin-top: 2px; border: 1px dashed black; text-align: left;}
div.main2-box {margin-left:2px; padding-left:2px; width: 77%; background:#FFFFFF; margin-bottom: 2px; margin-right: 2px; margin-top: 0px; border: 0px inset black; text-align: left;}
div.side-box {position:absolute; margin-left:80%; width:139px; padding-left:2px; background:#FFFFFF; margin-bottom: 2px; margin-right: 2px; margin-top: 65px; border: 1px dotted black; text-align: left;}
div.error-box {width:200px; background:pink; margin-top: 2px; border: 1px solid red; text-align: center;}
div.blue-box {width:600px; background:#e5ecf9; margin-top: 2px; border: 1px solid blue; text-align: left;}
div.side-headline {background:#FFFFFF; margin-bottom: 2px; margin-right: 2px; margin-top: 2px; border-bottom: 1px solid blue; text-align: left;}
div.breaker {margin-bottom: 2px; margin-right: 2px; margin-left: 2px; margin-top: 2px; border-bottom: 1px solid blue; text-align: left;}
div.right1 {background-color: #FFFFFF;}

//-->
</style>	