<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 TRANSITIONAL//EN">
<html>

	<head>
		<title>aWebNews</title>
	</head>
	<body><table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td width="250">
<a href="index.php"><img src="images/logo.png" border="0"></a></td><td valign="top" align="right"><b><font color="red">Admin Section</font></b></td></tr></table>
<div align="center"><div class="nav-box"><a href="view.php">View All</a> | <a href="post.php">Post News</a> | <a href="viewn.php">Comments</a> | <a href="category.php">Categories</a> | <a href="accounts.php">Accounts</a> | <a href="<?=$_SERVER['PHP_SELF'];?>?mode=logout">Logout</a>
</div></div>