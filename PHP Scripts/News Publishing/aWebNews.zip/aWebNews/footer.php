<div align="center"><div class="nav-box"><a href="http://labs.aweb.com.au/awebnews.php">aWebNews</a> is developed by <a href="http://labs.aweb.com.au">aWeb Labs</a>
</div></div>
	</body>
</html>